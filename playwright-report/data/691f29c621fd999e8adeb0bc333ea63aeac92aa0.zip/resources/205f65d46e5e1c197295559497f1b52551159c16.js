import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/SalesReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import { FaUsers, FaUserFriends, FaMoneyBillWave } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
const formatDate = (date) => date.toISOString().split("T")[0];
const SalesReport = () => {
  _s();
  const [formattedAgents, setFormattedAgents] = useState([]);
  const [allAgentsData, setAllAgentsData] = useState([]);
  const [selectedAgentId, setSelectedAgentId] = useState("all");
  const [selectedAgentDetails, setSelectedAgentDetails] = useState(null);
  const [tableReportData, setTableReportData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [totalLeads, setTotalLeads] = useState(0);
  const [totalCustomers, setTotalCustomers] = useState(0);
  const [totalSales, setTotalSales] = useState(0);
  const [targetData, setTargetData] = useState({
    target: 0,
    achieved: 0,
    remaining: 0,
    startDate: "",
    endDate: ""
  });
  const [formData, setFormData] = useState({
    // user: "",
    filterType: "Today"
  });
  const [showModal, setShowModal] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);
  const today = formatDate(/* @__PURE__ */ new Date());
  const [fromDate, setFromDate] = useState(today);
  const [toDate, setToDate] = useState(today);
  const [showFilterField, setShowFilterField] = useState(false);
  useEffect(() => {
    const fetchAgents = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/agent/get-agent");
        const agents = response?.data || [];
        setAllAgentsData(agents);
        const formatted = agents.map((agent, index) => ({
          _id: agent._id,
          id: index + 1,
          name: agent.name,
          phone: agent.phone_number,
          label: `${agent.name} (${agent.phone_number})`
        }));
        setFormattedAgents(formatted);
      } catch (err) {
        console.error("Fetch failed:", err);
        setFormattedAgents([]);
      } finally {
        setIsLoading(false);
      }
    };
    fetchAgents();
  }, []);
  useEffect(() => {
    fetchSalesReport();
  }, [selectedAgentId, fromDate, toDate]);
  const fetchTargetData = async (agentId) => {
    try {
      const targetRes = await api.get("/target/get-targets", {
        params: { fromDate, toDate, agentId }
      });
      const targets = targetRes.data.filter(
        (t) => (t.agentId?._id || t.agentId) === agentId
      );
      const monthMap = {};
      targets.forEach((t) => {
        const date = new Date(t.startDate);
        const key = `${date.getFullYear()}-${date.getMonth()}`;
        if (!monthMap[key]) monthMap[key] = t.totalTarget || 0;
      });
      const defaultTarget = Object.values(monthMap).length > 0 ? Object.values(monthMap)[0] : 0;
      let total = 0;
      let loop = new Date(fromDate);
      const end = new Date(toDate);
      while (loop <= end) {
        const year = loop.getFullYear();
        const month = loop.getMonth();
        const key = `${year}-${month}`;
        const monthTarget = monthMap[key] ?? defaultTarget;
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const perDayTarget = monthTarget / daysInMonth;
        total += perDayTarget;
        loop.setDate(loop.getDate() + 1);
      }
      const { data: commData } = await api.get(
        `/enroll/get-detailed-commission/${agentId}`,
        {
          params: { from_date: fromDate, to_date: toDate }
        }
      );
      let achieved = commData?.summary?.actual_business || 0;
      if (typeof achieved === "string") {
        achieved = Number(achieved.replace(/[^0-9.-]+/g, ""));
      }
      const remaining = Math.max(total - achieved, 0);
      const difference = total - achieved;
      const designation = targets.find((t) => (t.agentId?._id || t.agentId) === agentId)?.agentId?.designation_id?.title || "N/A";
      let incentiveAmount = 0;
      let incentivePercent = "0%";
      const title = designation.toLowerCase();
      if (title === "business agent" && achieved >= total) {
        incentiveAmount = achieved * 5e-3;
        incentivePercent = "0.5%";
      } else if (difference < 0) {
        incentiveAmount = Math.abs(difference) * 0.01;
        incentivePercent = "1%";
      }
      const startDate = targets.reduce(
        (min, t) => t.startDate < min ? t.startDate : min,
        targets[0]?.startDate || ""
      );
      const endDate = targets.reduce(
        (max, t) => t.endDate > max ? t.endDate : max,
        targets[0]?.endDate || ""
      );
      setTargetData({
        target: total,
        achieved,
        remaining,
        startDate: startDate.split("T")[0],
        endDate: endDate.split("T")[0],
        designation,
        incentiveAmount: `₹${incentiveAmount.toFixed(2)}`,
        incentivePercent
      });
    } catch (err) {
      console.error("Error fetching target data:", err);
      setTargetData({
        target: 0,
        achieved: 0,
        remaining: 0,
        startDate: "",
        endDate: "",
        designation: "",
        incentiveAmount: "₹0.00",
        incentivePercent: "0%"
      });
    }
  };
  const handleSelectFilter = (value) => {
    setShowFilterField(false);
    const today2 = /* @__PURE__ */ new Date();
    let from = "";
    let to = "";
    if (value === "Today") {
      from = to = formatDate(today2);
    } else if (value === "Yesterday") {
      const y = new Date(today2);
      y.setDate(today2.getDate() - 1);
      from = to = formatDate(y);
    } else if (value === "ThisMonth") {
      const start = new Date(today2.getFullYear(), today2.getMonth(), 1);
      const end = new Date(today2.getFullYear(), today2.getMonth() + 1, 0);
      from = formatDate(start);
      to = formatDate(end);
    } else if (value === "Custom") {
      setShowFilterField(true);
      return;
    }
    setFromDate(from);
    setToDate(to);
  };
  useEffect(() => {
    handleSelectFilter(formData.filterType);
  }, [formData.filterType]);
  const fetchSalesReport = async () => {
    try {
      setIsLoading(true);
      const params = {
        from_date: fromDate,
        to_date: toDate,
        agentId: selectedAgentId !== "all" ? selectedAgentId : "all"
      };
      const response = await api.get("/report/sales-report", { params });
      const res = response.data;
      const formatted = [];
      res.data.forEach((item) => {
        const agentName = item.agentName;
        const agentPhone = item.phone;
        const date = item.date || fromDate;
        const groupName = item.groupName || "-";
        const groupValue = Number(item.groupValue) || 0;
        (item.customerDetails || []).forEach((cust) => {
          formatted.push({
            id: formatted.length + 1,
            agentName,
            agentPhone,
            leadCustomerName: cust.name,
            customerPhone: cust.phone,
            date,
            groupName,
            groupValue,
            sales: groupValue,
            type: "Customer"
          });
        });
        (item.leadDetails || []).forEach((lead) => {
          formatted.push({
            id: formatted.length + 1,
            agentName,
            agentPhone,
            leadCustomerName: lead.name,
            customerPhone: lead.phone,
            date,
            groupName,
            groupValue: 0,
            sales: 0,
            type: "Lead"
          });
        });
      });
      setTableReportData(formatted);
      const totalLeadsCount = formatted.filter((row) => row.type === "Lead").length;
      const totalCustomersCount = formatted.filter((row) => row.type === "Customer").length;
      const totalSalesAmount = formatted.reduce((sum, row) => sum + row.sales, 0);
      setTotalLeads(totalLeadsCount);
      setTotalCustomers(totalCustomersCount);
      setTotalSales(totalSalesAmount);
      if (selectedAgentId !== "all") {
        const found = allAgentsData.find((a) => a._id === selectedAgentId);
        setSelectedAgentDetails(found || null);
        await fetchTargetData(selectedAgentId);
      } else {
        setSelectedAgentDetails(null);
        setTargetData({
          target: 0,
          achieved: 0,
          remaining: 0,
          startDate: "",
          endDate: "",
          designation: "",
          incentiveAmount: "₹0.00",
          incentivePercent: "0%"
        });
      }
    } catch (error) {
      console.error("Error fetching sales report:", error);
      setTableReportData([]);
    } finally {
      setIsLoading(false);
    }
  };
  const handleAntDSelect = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };
  const openModal = (row) => {
    setSelectedRow(row);
    setShowModal(true);
  };
  const closeModal = () => {
    setShowModal(false);
    setSelectedRow(null);
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "agentName", header: "Agent" },
    { key: "agentPhone", header: "Phone Number" },
    { key: "type", header: "Type" },
    { key: "leadCustomerName", header: "Lead/Customer" },
    // { key: "customerName", header: "Customers" },
    { key: "date", header: "Date" },
    { key: "groupName", header: "Group" },
    { key: "groupValue", header: "Group Value" },
    { key: "sales", header: "Sales" }
    // Two extra columns that will be included in Excel export
    // { key: "leadDetailsStr", header: "Lead Details" },
    // { key: "customerDetailsStr", header: "Customer Details" },
    // Actions column (render function required)
    // {
    //   key: "actions",
    //   header: "Actions",
    //   render: (row) => (
    //     <button
    //       onClick={() => openModal(row)}
    //       className="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded text-sm transition"
    //     >
    //       View Details
    //     </button>
    //   ),
    // },
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-h-screen", children: [
    /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
      lineNumber: 351,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-6", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold text-center mb-6", children: "Reports - Sales" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
        lineNumber: 353,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-full ", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 font-semibold", children: "Select Employee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 358,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              className: "border px-4 py-2 rounded w-full",
              value: selectedAgentId,
              onChange: (e) => setSelectedAgentId(e.target.value),
              children: [
                /* @__PURE__ */ jsxDEV("option", { value: "all", children: "-- All Agents --" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                  lineNumber: 364,
                  columnNumber: 15
                }, this),
                formattedAgents.map(
                  (a) => /* @__PURE__ */ jsxDEV("option", { value: a._id, children: a.label }, a._id, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                    lineNumber: 366,
                    columnNumber: 15
                  }, this)
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 359,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
          lineNumber: 357,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full ", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 font-semibold", children: "Filter Type" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 374,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full h-[42px]",
              value: formData.filterType,
              onChange: (val) => handleAntDSelect("filterType", val),
              children: [
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "Today", children: "Today" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                  lineNumber: 380,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "Yesterday", children: "Yesterday" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                  lineNumber: 381,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "ThisMonth", children: "This Month" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                  lineNumber: 382,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "Custom", children: "Custom" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                  lineNumber: 383,
                  columnNumber: 15
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 375,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
          lineNumber: 373,
          columnNumber: 11
        }, this),
        showFilterField && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-full ", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 font-semibold", children: "From Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 389,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                value: fromDate,
                max: today,
                onChange: (e) => setFromDate(e.target.value),
                className: "border px-4 py-2 rounded w-full"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                lineNumber: 390,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 388,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-full ", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 font-semibold", children: "To Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 399,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                value: toDate,
                min: fromDate,
                max: today,
                onChange: (e) => setToDate(e.target.value),
                className: "border px-4 py-2 rounded w-full"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                lineNumber: 400,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 398,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
          lineNumber: 387,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
        lineNumber: 356,
        columnNumber: 9
      }, this),
      selectedAgentDetails && /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-gray-200 shadow-lg rounded-xl p-6 mb-6", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-indigo-700 flex items-center gap-2 mb-4", children: [
          /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 419,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 418,
            columnNumber: 17
          }, this),
          "Agent Details"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
          lineNumber: 417,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-5", children: [
          { label: "Name", value: selectedAgentDetails.name || "-" },
          { label: "Phone", value: selectedAgentDetails.phone_number || "-" },
          { label: "Email", value: selectedAgentDetails.email || "-" }
        ].map(
          (field, i) => /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-600 mb-1", children: field.label }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 430,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 border border-gray-200 rounded-lg px-4 py-2.5 text-gray-800 font-medium", children: field.value }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 431,
              columnNumber: 21
            }, this)
          ] }, i, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 429,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
          lineNumber: 423,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-5 mt-5", children: [
          { label: "PAN", value: selectedAgentDetails.pan_no || "-" },
          { label: "Aadhaar", value: selectedAgentDetails.adhaar_no || "-" },
          { label: "Pincode", value: selectedAgentDetails.pincode || "-" }
        ].map(
          (field, i) => /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-600 mb-1", children: field.label }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 444,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 border border-gray-200 rounded-lg px-4 py-2.5 text-gray-800 font-medium", children: field.value }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 445,
              columnNumber: 21
            }, this)
          ] }, i, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 443,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
          lineNumber: 437,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-5", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-600 mb-1", children: "Address" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 452,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 border border-gray-200 rounded-lg px-4 py-2.5 text-gray-800 font-medium", children: selectedAgentDetails.address || "-" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 453,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
          lineNumber: 451,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
        lineNumber: 416,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
        lineNumber: 415,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-gray-200 shadow-md rounded-xl p-5 flex items-start gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 text-2xl", children: /* @__PURE__ */ jsxDEV(FaUsers, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 496,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 495,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-semibold text-gray-500 uppercase tracking-wide", children: "Total Leads" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 499,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-gray-800", children: totalLeads.toLocaleString("en-IN") }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 500,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500 font-mono mt-0.5", children: numberToIndianWords(totalLeads || 0) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 501,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 498,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
          lineNumber: 494,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-gray-200 shadow-md rounded-xl p-5 flex items-start gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 text-2xl", children: /* @__PURE__ */ jsxDEV(FaUserFriends, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 509,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 508,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-semibold text-gray-500 uppercase tracking-wide", children: "Total Customers" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 512,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-gray-800", children: totalCustomers.toLocaleString("en-IN") }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 513,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500 font-mono mt-0.5", children: numberToIndianWords(totalCustomers || 0) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 514,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 511,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
          lineNumber: 507,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-gray-200 shadow-md rounded-xl p-5 flex items-start gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-full bg-green-100 flex items-center justify-center text-green-600 text-2xl", children: /* @__PURE__ */ jsxDEV(FaMoneyBillWave, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 522,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 521,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-sm font-semibold text-gray-500 uppercase tracking-wide", children: "Total Sales" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 525,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-gray-800", children: [
              "₹",
              totalSales.toLocaleString("en-IN")
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 526,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500 font-mono mt-0.5", children: numberToIndianWords(totalSales || 0) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 527,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 524,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
          lineNumber: 520,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
        lineNumber: 493,
        columnNumber: 9
      }, this),
      isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
        lineNumber: 537,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
        lineNumber: 536,
        columnNumber: 9
      }, this) : /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: tableReportData,
          columns,
          exportedFileName: "SalesReport.csv",
          exportedPdfName: "Sales Report",
          printHeaderKeys: [
            "Agent Name",
            "From Date",
            "To Date",
            "Total Leads",
            "Total Customers",
            "Total Sales",
            "Target Set",
            "Achieved",
            "Remaining"
          ],
          printHeaderValues: [
            selectedAgentDetails?.name || "All Agents",
            fromDate || "-",
            toDate || "-",
            totalLeads.toLocaleString("en-IN"),
            totalCustomers.toLocaleString("en-IN"),
            `₹${totalSales.toLocaleString("en-IN")}`,
            `₹${targetData.target.toLocaleString("en-IN")}`,
            `₹${targetData.achieved.toLocaleString("en-IN")}`,
            `₹${targetData.remaining.toLocaleString("en-IN")}`
          ]
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
          lineNumber: 540,
          columnNumber: 9
        },
        this
      ),
      showModal && selectedRow && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-800", children: [
            "Details for ",
            selectedRow.name,
            " - ",
            selectedRow.groupName
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 575,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: closeModal,
              className: "text-gray-400 hover:text-gray-600 text-2xl leading-none",
              children: "×"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 578,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
          lineNumber: 574,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-semibold text-blue-700 mb-3 flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "👤" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                lineNumber: 590,
                columnNumber: 21
              }, this),
              " Lead Details (",
              selectedRow.leadDetails?.length || 0,
              ")"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 589,
              columnNumber: 19
            }, this),
            selectedRow.leadDetails && selectedRow.leadDetails.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200 border", children: [
              /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "#" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                  lineNumber: 597,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "Name" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                  lineNumber: 598,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "Phone" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                  lineNumber: 599,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                lineNumber: 596,
                columnNumber: 27
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                lineNumber: 595,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-gray-200", children: selectedRow.leadDetails.map(
                (lead, index) => /* @__PURE__ */ jsxDEV("tr", { children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-gray-600", children: index + 1 }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                    lineNumber: 605,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-gray-800", children: lead.name }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                    lineNumber: 606,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-gray-600", children: lead.phone }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                    lineNumber: 607,
                    columnNumber: 31
                  }, this)
                ] }, index, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                  lineNumber: 604,
                  columnNumber: 23
                }, this)
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                lineNumber: 602,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 594,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 593,
              columnNumber: 17
            }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm", children: "No leads recorded for this entry." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 614,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 588,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-semibold text-green-700 mb-3 flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "🧑‍🤝‍🧑" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                lineNumber: 621,
                columnNumber: 21
              }, this),
              " Customer Details (",
              selectedRow.customerDetails?.length || 0,
              ")"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 620,
              columnNumber: 19
            }, this),
            selectedRow.customerDetails && selectedRow.customerDetails.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200 border", children: [
              /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "#" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                  lineNumber: 628,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "Name" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                  lineNumber: 629,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase", children: "Phone" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                  lineNumber: 630,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                lineNumber: 627,
                columnNumber: 27
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                lineNumber: 626,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-gray-200", children: selectedRow.customerDetails.map(
                (customer, index) => /* @__PURE__ */ jsxDEV("tr", { children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-gray-600", children: index + 1 }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                    lineNumber: 636,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-gray-800", children: customer.name }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                    lineNumber: 637,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-gray-600", children: customer.phone }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                    lineNumber: 638,
                    columnNumber: 31
                  }, this)
                ] }, index, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                  lineNumber: 635,
                  columnNumber: 23
                }, this)
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
                lineNumber: 633,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 625,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 624,
              columnNumber: 17
            }, this) : /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm", children: "No customers recorded for this entry." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
              lineNumber: 645,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 619,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
          lineNumber: 586,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "sticky bottom-0 bg-gray-50 border-t border-gray-200 px-6 py-4 flex justify-end", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: closeModal,
            className: "bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-lg transition",
            children: "Close"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
            lineNumber: 651,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
          lineNumber: 650,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
        lineNumber: 573,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
        lineNumber: 572,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
      lineNumber: 352,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx",
    lineNumber: 350,
    columnNumber: 5
  }, this);
};
_s(SalesReport, "qOa2V51KoWS6DUff1pf7ccD7ahU=");
_c = SalesReport;
export default SalesReport;
var _c;
$RefreshReg$(_c, "SalesReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalesReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOFZNLFNBb0NNLFVBcENOOzJCQTlWTjtBQUFvQkEsb0JBQWdCLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDM0MsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQyxTQUFTQyxlQUFlQyx1QkFBdUI7QUFDeEQsU0FBU0MsY0FBYztBQUV2QixNQUFNQyxhQUFhQSxDQUFDQyxTQUFTQSxLQUFLQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFFNUQsTUFBTUMsY0FBY0EsTUFBTTtBQUFBQyxLQUFBO0FBQ3hCLFFBQU0sQ0FBQ0MsaUJBQWlCQyxrQkFBa0IsSUFBSWpCLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUNrQixlQUFlQyxnQkFBZ0IsSUFBSW5CLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNvQixpQkFBaUJDLGtCQUFrQixJQUFJckIsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ3NCLHNCQUFzQkMsdUJBQXVCLElBQUl2QixTQUFTLElBQUk7QUFDckUsUUFBTSxDQUFDd0IsaUJBQWlCQyxrQkFBa0IsSUFBSXpCLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUMwQixXQUFXQyxZQUFZLElBQUkzQixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDNEIsWUFBWUMsYUFBYSxJQUFJN0IsU0FBUyxDQUFDO0FBQzlDLFFBQU0sQ0FBQzhCLGdCQUFnQkMsaUJBQWlCLElBQUkvQixTQUFTLENBQUM7QUFDdEQsUUFBTSxDQUFDZ0MsWUFBWUMsYUFBYSxJQUFJakMsU0FBUyxDQUFDO0FBQzlDLFFBQU0sQ0FBQ2tDLFlBQVlDLGFBQWEsSUFBSW5DLFNBQVM7QUFBQSxJQUMzQ29DLFFBQVE7QUFBQSxJQUNSQyxVQUFVO0FBQUEsSUFDVkMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxJQUNYQyxTQUFTO0FBQUEsRUFDWCxDQUFDO0FBQ0QsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUkxQyxTQUFTO0FBQUE7QUFBQSxJQUV2QzJDLFlBQVk7QUFBQSxFQUNkLENBQUM7QUFHRCxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSTdDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUM4QyxhQUFhQyxjQUFjLElBQUkvQyxTQUFTLElBQUk7QUFFbkQsUUFBTWdELFFBQVF0QyxXQUFXLG9CQUFJdUMsS0FBSyxDQUFDO0FBQ25DLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJbkQsU0FBU2dELEtBQUs7QUFDOUMsUUFBTSxDQUFDSSxRQUFRQyxTQUFTLElBQUlyRCxTQUFTZ0QsS0FBSztBQUMxQyxRQUFNLENBQUNNLGlCQUFpQkMsa0JBQWtCLElBQUl2RCxTQUFTLEtBQUs7QUFFNUR3RCxZQUFVLE1BQU07QUFDZCxVQUFNQyxjQUFjLFlBQVk7QUFDOUIsVUFBSTtBQUNGOUIscUJBQWEsSUFBSTtBQUNqQixjQUFNK0IsV0FBVyxNQUFNekQsSUFBSTBELElBQUksa0JBQWtCO0FBQ2pELGNBQU1DLFNBQVNGLFVBQVVHLFFBQVE7QUFFakMxQyx5QkFBaUJ5QyxNQUFNO0FBRXZCLGNBQU1FLFlBQVlGLE9BQU9HLElBQUksQ0FBQ0MsT0FBT0MsV0FBVztBQUFBLFVBQzlDQyxLQUFLRixNQUFNRTtBQUFBQSxVQUNYQyxJQUFJRixRQUFRO0FBQUEsVUFDWkcsTUFBTUosTUFBTUk7QUFBQUEsVUFDWkMsT0FBT0wsTUFBTU07QUFBQUEsVUFDYkMsT0FBTyxHQUFHUCxNQUFNSSxJQUFJLEtBQUtKLE1BQU1NLFlBQVk7QUFBQSxRQUM3QyxFQUFFO0FBRUZyRCwyQkFBbUI2QyxTQUFTO0FBQUEsTUFDOUIsU0FBU1UsS0FBSztBQUNaQyxnQkFBUUMsTUFBTSxpQkFBaUJGLEdBQUc7QUFDbEN2RCwyQkFBbUIsRUFBRTtBQUFBLE1BQ3ZCLFVBQUM7QUFDQ1UscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUVBOEIsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsRUFBRTtBQUVMRCxZQUFVLE1BQU07QUFDZG1CLHFCQUFpQjtBQUFBLEVBQ25CLEdBQUcsQ0FBQ3ZELGlCQUFpQjhCLFVBQVVFLE1BQU0sQ0FBQztBQUV0QyxRQUFNd0Isa0JBQWtCLE9BQU9DLFlBQVk7QUFDekMsUUFBSTtBQUNGLFlBQU1DLFlBQVksTUFBTTdFLElBQUkwRCxJQUFJLHVCQUF1QjtBQUFBLFFBQ3JEb0IsUUFBUSxFQUFFN0IsVUFBVUUsUUFBUXlCLFFBQVE7QUFBQSxNQUN0QyxDQUFDO0FBRUQsWUFBTUcsVUFBVUYsVUFBVWpCLEtBQUtvQjtBQUFBQSxRQUM3QixDQUFDQyxPQUFPQSxFQUFFTCxTQUFTWCxPQUFPZ0IsRUFBRUwsYUFBYUE7QUFBQUEsTUFDM0M7QUFHQSxZQUFNTSxXQUFXLENBQUM7QUFDbEJILGNBQVFJLFFBQVEsQ0FBQ0YsTUFBTTtBQUNyQixjQUFNdkUsT0FBTyxJQUFJc0MsS0FBS2lDLEVBQUUzQyxTQUFTO0FBQ2pDLGNBQU04QyxNQUFNLEdBQUcxRSxLQUFLMkUsWUFBWSxDQUFDLElBQUkzRSxLQUFLNEUsU0FBUyxDQUFDO0FBQ3BELFlBQUksQ0FBQ0osU0FBU0UsR0FBRyxFQUFHRixVQUFTRSxHQUFHLElBQUlILEVBQUVNLGVBQWU7QUFBQSxNQUN2RCxDQUFDO0FBRUQsWUFBTUMsZ0JBQ0pDLE9BQU9DLE9BQU9SLFFBQVEsRUFBRVMsU0FBUyxJQUFJRixPQUFPQyxPQUFPUixRQUFRLEVBQUUsQ0FBQyxJQUFJO0FBR3BFLFVBQUlVLFFBQVE7QUFDWixVQUFJQyxPQUFPLElBQUk3QyxLQUFLQyxRQUFRO0FBQzVCLFlBQU02QyxNQUFNLElBQUk5QyxLQUFLRyxNQUFNO0FBQzNCLGFBQU8wQyxRQUFRQyxLQUFLO0FBQ2xCLGNBQU1DLE9BQU9GLEtBQUtSLFlBQVk7QUFDOUIsY0FBTVcsUUFBUUgsS0FBS1AsU0FBUztBQUM1QixjQUFNRixNQUFNLEdBQUdXLElBQUksSUFBSUMsS0FBSztBQUM1QixjQUFNQyxjQUFjZixTQUFTRSxHQUFHLEtBQUtJO0FBQ3JDLGNBQU1VLGNBQWMsSUFBSWxELEtBQUsrQyxNQUFNQyxRQUFRLEdBQUcsQ0FBQyxFQUFFRyxRQUFRO0FBQ3pELGNBQU1DLGVBQWVILGNBQWNDO0FBRW5DTixpQkFBU1E7QUFDVFAsYUFBS1EsUUFBUVIsS0FBS00sUUFBUSxJQUFJLENBQUM7QUFBQSxNQUNqQztBQUdBLFlBQU0sRUFBRXZDLE1BQU0wQyxTQUFTLElBQUksTUFBTXRHLElBQUkwRDtBQUFBQSxRQUNuQyxtQ0FBbUNrQixPQUFPO0FBQUEsUUFDMUM7QUFBQSxVQUNFRSxRQUFRLEVBQUV5QixXQUFXdEQsVUFBVXVELFNBQVNyRCxPQUFPO0FBQUEsUUFDakQ7QUFBQSxNQUNGO0FBRUEsVUFBSWYsV0FBV2tFLFVBQVVHLFNBQVNDLG1CQUFtQjtBQUNyRCxVQUFJLE9BQU90RSxhQUFhLFVBQVU7QUFDaENBLG1CQUFXdUUsT0FBT3ZFLFNBQVN3RSxRQUFRLGNBQWMsRUFBRSxDQUFDO0FBQUEsTUFDdEQ7QUFFQSxZQUFNdkUsWUFBWXdFLEtBQUtDLElBQUlsQixRQUFReEQsVUFBVSxDQUFDO0FBQzlDLFlBQU0yRSxhQUFhbkIsUUFBUXhEO0FBRzNCLFlBQU00RSxjQUNKakMsUUFBUWtDLEtBQUssQ0FBQ2hDLE9BQU9BLEVBQUVMLFNBQVNYLE9BQU9nQixFQUFFTCxhQUFhQSxPQUFPLEdBQUdBLFNBQzVEc0MsZ0JBQWdCQyxTQUFTO0FBRy9CLFVBQUlDLGtCQUFrQjtBQUN0QixVQUFJQyxtQkFBbUI7QUFDdkIsWUFBTUYsUUFBUUgsWUFBWU0sWUFBWTtBQUV0QyxVQUFJSCxVQUFVLG9CQUFvQi9FLFlBQVl3RCxPQUFPO0FBQ25Ed0IsMEJBQWtCaEYsV0FBVztBQUM3QmlGLDJCQUFtQjtBQUFBLE1BQ3JCLFdBQVdOLGFBQWEsR0FBRztBQUN6QkssMEJBQWtCUCxLQUFLVSxJQUFJUixVQUFVLElBQUk7QUFDekNNLDJCQUFtQjtBQUFBLE1BQ3JCO0FBR0EsWUFBTS9FLFlBQVl5QyxRQUFReUM7QUFBQUEsUUFDeEIsQ0FBQ0MsS0FBS3hDLE1BQU9BLEVBQUUzQyxZQUFZbUYsTUFBTXhDLEVBQUUzQyxZQUFZbUY7QUFBQUEsUUFDL0MxQyxRQUFRLENBQUMsR0FBR3pDLGFBQWE7QUFBQSxNQUMzQjtBQUNBLFlBQU1DLFVBQVV3QyxRQUFReUM7QUFBQUEsUUFDdEIsQ0FBQ1YsS0FBSzdCLE1BQU9BLEVBQUUxQyxVQUFVdUUsTUFBTTdCLEVBQUUxQyxVQUFVdUU7QUFBQUEsUUFDM0MvQixRQUFRLENBQUMsR0FBR3hDLFdBQVc7QUFBQSxNQUN6QjtBQUVBTCxvQkFBYztBQUFBLFFBQ1pDLFFBQVF5RDtBQUFBQSxRQUNSeEQ7QUFBQUEsUUFDQUM7QUFBQUEsUUFDQUMsV0FBV0EsVUFBVTFCLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxRQUNqQzJCLFNBQVNBLFFBQVEzQixNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsUUFDN0JvRztBQUFBQSxRQUNBSSxpQkFBaUIsSUFBSUEsZ0JBQWdCTSxRQUFRLENBQUMsQ0FBQztBQUFBLFFBQy9DTDtBQUFBQSxNQUNGLENBQUM7QUFBQSxJQUNILFNBQVM5QyxLQUFLO0FBQ1pDLGNBQVFDLE1BQU0sK0JBQStCRixHQUFHO0FBQ2hEckMsb0JBQWM7QUFBQSxRQUNaQyxRQUFRO0FBQUEsUUFDUkMsVUFBVTtBQUFBLFFBQ1ZDLFdBQVc7QUFBQSxRQUNYQyxXQUFXO0FBQUEsUUFDWEMsU0FBUztBQUFBLFFBQ1R5RSxhQUFhO0FBQUEsUUFDYkksaUJBQWlCO0FBQUEsUUFDakJDLGtCQUFrQjtBQUFBLE1BQ3BCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUdBLFFBQU1NLHFCQUFxQkEsQ0FBQ0MsVUFBVTtBQUNwQ3RFLHVCQUFtQixLQUFLO0FBRXhCLFVBQU1QLFNBQVEsb0JBQUlDLEtBQUs7QUFDdkIsUUFBSTZFLE9BQU87QUFDWCxRQUFJQyxLQUFLO0FBRVQsUUFBSUYsVUFBVSxTQUFTO0FBQ3JCQyxhQUFPQyxLQUFLckgsV0FBV3NDLE1BQUs7QUFBQSxJQUM5QixXQUFXNkUsVUFBVSxhQUFhO0FBQ2hDLFlBQU1HLElBQUksSUFBSS9FLEtBQUtELE1BQUs7QUFDeEJnRixRQUFFMUIsUUFBUXRELE9BQU1vRCxRQUFRLElBQUksQ0FBQztBQUM3QjBCLGFBQU9DLEtBQUtySCxXQUFXc0gsQ0FBQztBQUFBLElBQzFCLFdBQVdILFVBQVUsYUFBYTtBQUNoQyxZQUFNSSxRQUFRLElBQUloRixLQUFLRCxPQUFNc0MsWUFBWSxHQUFHdEMsT0FBTXVDLFNBQVMsR0FBRyxDQUFDO0FBQy9ELFlBQU1RLE1BQU0sSUFBSTlDLEtBQUtELE9BQU1zQyxZQUFZLEdBQUd0QyxPQUFNdUMsU0FBUyxJQUFJLEdBQUcsQ0FBQztBQUNqRXVDLGFBQU9wSCxXQUFXdUgsS0FBSztBQUN2QkYsV0FBS3JILFdBQVdxRixHQUFHO0FBQUEsSUFDckIsV0FBVzhCLFVBQVUsVUFBVTtBQUM3QnRFLHlCQUFtQixJQUFJO0FBQ3ZCO0FBQUEsSUFDRjtBQUVBSixnQkFBWTJFLElBQUk7QUFDaEJ6RSxjQUFVMEUsRUFBRTtBQUFBLEVBQ2Q7QUFHQXZFLFlBQVUsTUFBTTtBQUNkb0UsdUJBQW1CbkYsU0FBU0UsVUFBVTtBQUFBLEVBQ3hDLEdBQUcsQ0FBQ0YsU0FBU0UsVUFBVSxDQUFDO0FBRXhCLFFBQU1nQyxtQkFBbUIsWUFBWTtBQUNuQyxRQUFJO0FBQ0ZoRCxtQkFBYSxJQUFJO0FBRWpCLFlBQU1vRCxTQUFTO0FBQUEsUUFDYnlCLFdBQVd0RDtBQUFBQSxRQUNYdUQsU0FBU3JEO0FBQUFBLFFBQ1R5QixTQUFTekQsb0JBQW9CLFFBQVFBLGtCQUFrQjtBQUFBLE1BQ3pEO0FBRUEsWUFBTXNDLFdBQVcsTUFBTXpELElBQUkwRCxJQUFJLHdCQUF3QixFQUFFb0IsT0FBTyxDQUFDO0FBQ2pFLFlBQU1tRCxNQUFNeEUsU0FBU0c7QUFFckIsWUFBTUMsWUFBWTtBQUNsQm9FLFVBQUlyRSxLQUFLdUIsUUFBUSxDQUFDK0MsU0FBUztBQUN6QixjQUFNQyxZQUFZRCxLQUFLQztBQUN2QixjQUFNQyxhQUFhRixLQUFLOUQ7QUFDeEIsY0FBTTFELE9BQU93SCxLQUFLeEgsUUFBUXVDO0FBQzFCLGNBQU1vRixZQUFZSCxLQUFLRyxhQUFhO0FBQ3BDLGNBQU1DLGFBQWEzQixPQUFPdUIsS0FBS0ksVUFBVSxLQUFLO0FBRzlDLFNBQUNKLEtBQUtLLG1CQUFtQixJQUFJcEQsUUFBUSxDQUFDcUQsU0FBUztBQUM3QzNFLG9CQUFVNEUsS0FBSztBQUFBLFlBQ2J2RSxJQUFJTCxVQUFVOEIsU0FBUztBQUFBLFlBQ3ZCd0M7QUFBQUEsWUFDQUM7QUFBQUEsWUFDQU0sa0JBQWtCRixLQUFLckU7QUFBQUEsWUFDdkJ3RSxlQUFlSCxLQUFLcEU7QUFBQUEsWUFDcEIxRDtBQUFBQSxZQUNBMkg7QUFBQUEsWUFDQUM7QUFBQUEsWUFDQU0sT0FBT047QUFBQUEsWUFDUE8sTUFBTTtBQUFBLFVBQ1IsQ0FBQztBQUFBLFFBQ0gsQ0FBQztBQUdELFNBQUNYLEtBQUtZLGVBQWUsSUFBSTNELFFBQVEsQ0FBQzRELFNBQVM7QUFDekNsRixvQkFBVTRFLEtBQUs7QUFBQSxZQUNidkUsSUFBSUwsVUFBVThCLFNBQVM7QUFBQSxZQUN2QndDO0FBQUFBLFlBQ0FDO0FBQUFBLFlBQ0FNLGtCQUFrQkssS0FBSzVFO0FBQUFBLFlBQ3ZCd0UsZUFBZUksS0FBSzNFO0FBQUFBLFlBQ3BCMUQ7QUFBQUEsWUFDQTJIO0FBQUFBLFlBQ0FDLFlBQVk7QUFBQSxZQUNaTSxPQUFPO0FBQUEsWUFDUEMsTUFBTTtBQUFBLFVBQ1IsQ0FBQztBQUFBLFFBQ0gsQ0FBQztBQUFBLE1BQ0gsQ0FBQztBQUVEckgseUJBQW1CcUMsU0FBUztBQUU1QixZQUFNbUYsa0JBQWtCbkYsVUFBVW1CLE9BQU8sQ0FBQWlFLFFBQU9BLElBQUlKLFNBQVMsTUFBTSxFQUFFbEQ7QUFDckUsWUFBTXVELHNCQUFzQnJGLFVBQVVtQixPQUFPLENBQUFpRSxRQUFPQSxJQUFJSixTQUFTLFVBQVUsRUFBRWxEO0FBQzdFLFlBQU13RCxtQkFBbUJ0RixVQUFVMkQsT0FBTyxDQUFDNEIsS0FBS0gsUUFBUUcsTUFBTUgsSUFBSUwsT0FBTyxDQUFDO0FBRTFFaEgsb0JBQWNvSCxlQUFlO0FBQzdCbEgsd0JBQWtCb0gsbUJBQW1CO0FBQ3JDbEgsb0JBQWNtSCxnQkFBZ0I7QUFFOUIsVUFBSWhJLG9CQUFvQixPQUFPO0FBQzdCLGNBQU1rSSxRQUFRcEksY0FBY2dHLEtBQUssQ0FBQ3FDLE1BQU1BLEVBQUVyRixRQUFROUMsZUFBZTtBQUNqRUcsZ0NBQXdCK0gsU0FBUyxJQUFJO0FBRXJDLGNBQU0xRSxnQkFBZ0J4RCxlQUFlO0FBQUEsTUFDdkMsT0FBTztBQUNMRyxnQ0FBd0IsSUFBSTtBQUM1Qlksc0JBQWM7QUFBQSxVQUNaQyxRQUFRO0FBQUEsVUFDUkMsVUFBVTtBQUFBLFVBQ1ZDLFdBQVc7QUFBQSxVQUNYQyxXQUFXO0FBQUEsVUFDWEMsU0FBUztBQUFBLFVBQ1R5RSxhQUFhO0FBQUEsVUFDYkksaUJBQWlCO0FBQUEsVUFDakJDLGtCQUFrQjtBQUFBLFFBQ3BCLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixTQUFTNUMsT0FBTztBQUNkRCxjQUFRQyxNQUFNLGdDQUFnQ0EsS0FBSztBQUNuRGpELHlCQUFtQixFQUFFO0FBQUEsSUFDdkIsVUFBQztBQUNDRSxtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUEsUUFBTTZILG1CQUFtQkEsQ0FBQ0MsT0FBTzVCLFVBQVU7QUFDekNuRixnQkFBWSxDQUFDZ0gsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0QsS0FBSyxHQUFHNUIsTUFBTSxFQUFFO0FBQUEsRUFDckQ7QUFFQSxRQUFNOEIsWUFBWUEsQ0FBQ1QsUUFBUTtBQUN6Qm5HLG1CQUFlbUcsR0FBRztBQUNsQnJHLGlCQUFhLElBQUk7QUFBQSxFQUNuQjtBQUVBLFFBQU0rRyxhQUFhQSxNQUFNO0FBQ3ZCL0csaUJBQWEsS0FBSztBQUNsQkUsbUJBQWUsSUFBSTtBQUFBLEVBQ3JCO0FBR0EsUUFBTThHLFVBQVU7QUFBQSxJQUNkLEVBQUV4RSxLQUFLLE1BQU15RSxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFekUsS0FBSyxhQUFheUUsUUFBUSxRQUFRO0FBQUEsSUFDcEMsRUFBRXpFLEtBQUssY0FBY3lFLFFBQVEsZUFBZTtBQUFBLElBQzVDLEVBQUV6RSxLQUFLLFFBQVF5RSxRQUFRLE9BQU87QUFBQSxJQUM5QixFQUFFekUsS0FBSyxvQkFBb0J5RSxRQUFRLGdCQUFnQjtBQUFBO0FBQUEsSUFFbkQsRUFBRXpFLEtBQUssUUFBUXlFLFFBQVEsT0FBTztBQUFBLElBQzlCLEVBQUV6RSxLQUFLLGFBQWF5RSxRQUFRLFFBQVE7QUFBQSxJQUNwQyxFQUFFekUsS0FBSyxjQUFjeUUsUUFBUSxjQUFjO0FBQUEsSUFDM0MsRUFBRXpFLEtBQUssU0FBU3lFLFFBQVEsUUFBUTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFnQmhDO0FBR0YsU0FDRSx1QkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSwyQkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBTztBQUFBLElBQ1AsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsdUNBQXNDLCtCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1FO0FBQUEsTUFHbkUsdUJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLFdBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsNEJBQTJCLCtCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRDtBQUFBLFVBQzNEO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixPQUFPMUk7QUFBQUEsY0FDUCxVQUFVLENBQUMySSxNQUFNMUksbUJBQW1CMEksRUFBRTNILE9BQU95RixLQUFLO0FBQUEsY0FFbEQ7QUFBQSx1Q0FBQyxZQUFPLE9BQU0sT0FBTSxnQ0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0M7QUFBQSxnQkFDbkM3RyxnQkFBZ0IrQztBQUFBQSxrQkFBSSxDQUFDd0YsTUFDcEIsdUJBQUMsWUFBbUIsT0FBT0EsRUFBRXJGLEtBQzFCcUYsWUFBRWhGLFNBRFFnRixFQUFFckYsS0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBO0FBQUEsWUFWSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFXQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsV0FDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSw0QkFBMkIsMkJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVEO0FBQUEsVUFDdkQ7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE9BQU96QixTQUFTRTtBQUFBQSxjQUNoQixVQUFVLENBQUNxSCxRQUFRUixpQkFBaUIsY0FBY1EsR0FBRztBQUFBLGNBRXJEO0FBQUEsdUNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxTQUFRLHFCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQztBQUFBLGdCQUNsQyx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLGFBQVkseUJBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBDO0FBQUEsZ0JBQzFDLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sYUFBWSwwQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkM7QUFBQSxnQkFDM0MsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxVQUFTLHNCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvQztBQUFBO0FBQUE7QUFBQSxZQVJ0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFTQTtBQUFBLGFBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsUUFDQzFHLG1CQUNDLG1DQUNFO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFdBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsNEJBQTJCLHlCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRDtBQUFBLFlBQ3JEO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU9KO0FBQUFBLGdCQUNQLEtBQUtGO0FBQUFBLGdCQUNMLFVBQVUsQ0FBQytHLE1BQU01RyxZQUFZNEcsRUFBRTNILE9BQU95RixLQUFLO0FBQUEsZ0JBQzNDLFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSzZDO0FBQUEsZUFQL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLFdBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsNEJBQTJCLHVCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRDtBQUFBLFlBQ25EO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU96RTtBQUFBQSxnQkFDUCxLQUFLRjtBQUFBQSxnQkFDTCxLQUFLRjtBQUFBQSxnQkFDTCxVQUFVLENBQUMrRyxNQUFNMUcsVUFBVTBHLEVBQUUzSCxPQUFPeUYsS0FBSztBQUFBLGdCQUN6QyxXQUFVO0FBQUE7QUFBQSxjQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU02QztBQUFBLGVBUi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxhQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0JBO0FBQUEsV0FyREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVEQTtBQUFBLE1BR0N2Ryx3QkFDQyxtQ0FDRSxpQ0FBQyxTQUFJLFdBQVUsaUVBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsa0VBQ1o7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsV0FBVSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQ2pFLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUseUVBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBJLEtBRDVJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUFNO0FBQUEsYUFIUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDWjtBQUFBLFVBQ0MsRUFBRWlELE9BQU8sUUFBUXNELE9BQU92RyxxQkFBcUI4QyxRQUFRLElBQUk7QUFBQSxVQUN6RCxFQUFFRyxPQUFPLFNBQVNzRCxPQUFPdkcscUJBQXFCZ0QsZ0JBQWdCLElBQUk7QUFBQSxVQUNsRSxFQUFFQyxPQUFPLFNBQVNzRCxPQUFPdkcscUJBQXFCMkksU0FBUyxJQUFJO0FBQUEsUUFBQyxFQUM1RGxHO0FBQUFBLFVBQUksQ0FBQzBGLE9BQU9TLE1BQ1osdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxrREFBa0RULGdCQUFNbEYsU0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0U7QUFBQSxZQUMvRSx1QkFBQyxTQUFJLFdBQVUsc0ZBQ1prRixnQkFBTTVCLFNBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSlFxQyxHQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxRQUNELEtBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsOENBQ1o7QUFBQSxVQUNDLEVBQUUzRixPQUFPLE9BQU9zRCxPQUFPdkcscUJBQXFCNkksVUFBVSxJQUFJO0FBQUEsVUFDMUQsRUFBRTVGLE9BQU8sV0FBV3NELE9BQU92RyxxQkFBcUI4SSxhQUFhLElBQUk7QUFBQSxVQUNqRSxFQUFFN0YsT0FBTyxXQUFXc0QsT0FBT3ZHLHFCQUFxQitJLFdBQVcsSUFBSTtBQUFBLFFBQUMsRUFDaEV0RztBQUFBQSxVQUFJLENBQUMwRixPQUFPUyxNQUNaLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsa0RBQWtEVCxnQkFBTWxGLFNBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStFO0FBQUEsWUFDL0UsdUJBQUMsU0FBSSxXQUFVLHNGQUNaa0YsZ0JBQU01QixTQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpRcUMsR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsUUFDRCxLQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsa0RBQWlELHVCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RTtBQUFBLFVBQ3pFLHVCQUFDLFNBQUksV0FBVSxzRkFDWjVJLCtCQUFxQmdKLFdBQVcsT0FEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0F4Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlDQSxLQTFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEVBO0FBQUEsTUFJRix1QkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsbUZBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsOEZBQ2IsaUNBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFRLEtBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFNBQUksV0FBVSwrREFBOEQsMkJBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdGO0FBQUEsWUFDeEYsdUJBQUMsU0FBSSxXQUFVLG9DQUFvQzFJLHFCQUFXMkksZUFBZSxPQUFPLEtBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNGO0FBQUEsWUFDdEYsdUJBQUMsU0FBSSxXQUFVLDBDQUNabEssOEJBQW9CdUIsY0FBYyxDQUFDLEtBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxhQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLG1GQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGtHQUNiLGlDQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWMsS0FEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFNBQUksV0FBVSwrREFBOEQsK0JBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRGO0FBQUEsWUFDNUYsdUJBQUMsU0FBSSxXQUFVLG9DQUFvQ0UseUJBQWV5SSxlQUFlLE9BQU8sS0FBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEY7QUFBQSxZQUMxRix1QkFBQyxTQUFJLFdBQVUsMENBQ1psSyw4QkFBb0J5QixrQkFBa0IsQ0FBQyxLQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsYUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxtRkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxnR0FDYixpQ0FBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQixLQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLCtEQUE4RCwyQkFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Y7QUFBQSxZQUN4Rix1QkFBQyxTQUFJLFdBQVUsb0NBQW1DO0FBQUE7QUFBQSxjQUFFRSxXQUFXdUksZUFBZSxPQUFPO0FBQUEsaUJBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVGO0FBQUEsWUFDdkYsdUJBQUMsU0FBSSxXQUFVLDBDQUNabEssOEJBQW9CMkIsY0FBYyxDQUFDLEtBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxhQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFdBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1Q0E7QUFBQSxNQUdDTixZQUNDLHVCQUFDLFNBQUksV0FBVSxvQ0FDYixpQ0FBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWUsS0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLElBRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU1GO0FBQUFBLFVBQ047QUFBQSxVQUNBLGtCQUFpQjtBQUFBLFVBQ2pCLGlCQUFnQjtBQUFBLFVBQ2hCLGlCQUFpQjtBQUFBLFlBQ2Y7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQVc7QUFBQSxVQUViLG1CQUFtQjtBQUFBLFlBQ2pCRixzQkFBc0I4QyxRQUFRO0FBQUEsWUFDOUJsQixZQUFZO0FBQUEsWUFDWkUsVUFBVTtBQUFBLFlBQ1Z4QixXQUFXMkksZUFBZSxPQUFPO0FBQUEsWUFDakN6SSxlQUFleUksZUFBZSxPQUFPO0FBQUEsWUFDckMsSUFBSXZJLFdBQVd1SSxlQUFlLE9BQU8sQ0FBQztBQUFBLFlBQ3RDLElBQUlySSxXQUFXRSxPQUFPbUksZUFBZSxPQUFPLENBQUM7QUFBQSxZQUM3QyxJQUFJckksV0FBV0csU0FBU2tJLGVBQWUsT0FBTyxDQUFDO0FBQUEsWUFDL0MsSUFBSXJJLFdBQVdJLFVBQVVpSSxlQUFlLE9BQU8sQ0FBQztBQUFBLFVBQUU7QUFBQTtBQUFBLFFBekJ0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUEwQkk7QUFBQSxNQUtMM0gsYUFBYUUsZUFDWix1QkFBQyxTQUFJLFdBQVUsa0ZBQ2IsaUNBQUMsU0FBSSxXQUFVLGdGQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDhGQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLG1DQUFrQztBQUFBO0FBQUEsWUFDakNBLFlBQVlzQjtBQUFBQSxZQUFLO0FBQUEsWUFBSXRCLFlBQVl3RjtBQUFBQSxlQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBU3NCO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBQXlEO0FBQUE7QUFBQSxZQUZyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLGFBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsT0FFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLG9FQUNaO0FBQUEscUNBQUMsVUFBSyxrQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFRO0FBQUEsY0FBTztBQUFBLGNBQWdCOUcsWUFBWWlHLGFBQWFuRCxVQUFVO0FBQUEsY0FBRTtBQUFBLGlCQUR0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQzlDLFlBQVlpRyxlQUFlakcsWUFBWWlHLFlBQVluRCxTQUFTLElBQzNELHVCQUFDLFNBQUksV0FBVSxtQkFDYixpQ0FBQyxXQUFNLFdBQVUsOENBQ2Y7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsY0FDZixpQ0FBQyxRQUNDO0FBQUEsdUNBQUMsUUFBRyxXQUFVLG1FQUFrRSxpQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUY7QUFBQSxnQkFDakYsdUJBQUMsUUFBRyxXQUFVLG1FQUFrRSxvQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0Y7QUFBQSxnQkFDcEYsdUJBQUMsUUFBRyxXQUFVLG1FQUFrRSxxQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUY7QUFBQSxtQkFIdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSw0QkFDZDlDLHNCQUFZaUcsWUFBWWhGO0FBQUFBLGdCQUFJLENBQUNpRixNQUFNL0UsVUFDbEMsdUJBQUMsUUFDQztBQUFBLHlDQUFDLFFBQUcsV0FBVSxtQ0FBbUNBLGtCQUFRLEtBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJEO0FBQUEsa0JBQzNELHVCQUFDLFFBQUcsV0FBVSxtQ0FBbUMrRSxlQUFLNUUsUUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkQ7QUFBQSxrQkFDM0QsdUJBQUMsUUFBRyxXQUFVLG1DQUFtQzRFLGVBQUszRSxTQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0RDtBQUFBLHFCQUhyREosT0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsY0FDRCxLQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxpQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtQkEsSUFFQSx1QkFBQyxPQUFFLFdBQVUseUJBQXdCLGlEQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRTtBQUFBLGVBMUIxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTRCQTtBQUFBLFVBR0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSxxRUFDWjtBQUFBLHFDQUFDLFVBQUssd0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBYztBQUFBLGNBQU87QUFBQSxjQUFvQm5CLFlBQVkwRixpQkFBaUI1QyxVQUFVO0FBQUEsY0FBRTtBQUFBLGlCQURwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQzlDLFlBQVkwRixtQkFBbUIxRixZQUFZMEYsZ0JBQWdCNUMsU0FBUyxJQUNuRSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2IsaUNBQUMsV0FBTSxXQUFVLDhDQUNmO0FBQUEscUNBQUMsV0FBTSxXQUFVLGNBQ2YsaUNBQUMsUUFDQztBQUFBLHVDQUFDLFFBQUcsV0FBVSxtRUFBa0UsaUJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlGO0FBQUEsZ0JBQ2pGLHVCQUFDLFFBQUcsV0FBVSxtRUFBa0Usb0JBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9GO0FBQUEsZ0JBQ3BGLHVCQUFDLFFBQUcsV0FBVSxtRUFBa0UscUJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFGO0FBQUEsbUJBSHZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUEsS0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1BO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsNEJBQ2Q5QyxzQkFBWTBGLGdCQUFnQnpFO0FBQUFBLGdCQUFJLENBQUN5RyxVQUFVdkcsVUFDMUMsdUJBQUMsUUFDQztBQUFBLHlDQUFDLFFBQUcsV0FBVSxtQ0FBbUNBLGtCQUFRLEtBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJEO0FBQUEsa0JBQzNELHVCQUFDLFFBQUcsV0FBVSxtQ0FBbUN1RyxtQkFBU3BHLFFBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStEO0FBQUEsa0JBQy9ELHVCQUFDLFFBQUcsV0FBVSxtQ0FBbUNvRyxtQkFBU25HLFNBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdFO0FBQUEscUJBSHpESixPQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxjQUNELEtBUEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQTtBQUFBLGlCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQSxLQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1CQSxJQUVBLHVCQUFDLE9BQUUsV0FBVSx5QkFBd0IscURBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBFO0FBQUEsZUExQjlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNEJBO0FBQUEsYUE3REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThEQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGtGQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTMkY7QUFBQUEsWUFDVCxXQUFVO0FBQUEsWUFBNkU7QUFBQTtBQUFBLFVBRnpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0FwRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFGQSxLQXRGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUZBO0FBQUEsU0FuVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFUQTtBQUFBLE9BdlRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3VEE7QUFFSjtBQUFFN0ksR0E1b0JJRCxhQUFXO0FBQUEySixLQUFYM0o7QUE4b0JOLGVBQWVBO0FBQVksSUFBQTJKO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsImFwaSIsIkRhdGFUYWJsZSIsIk5hdmJhciIsIkNpcmN1bGFyTG9hZGVyIiwibnVtYmVyVG9JbmRpYW5Xb3JkcyIsIkZhVXNlcnMiLCJGYVVzZXJGcmllbmRzIiwiRmFNb25leUJpbGxXYXZlIiwiU2VsZWN0IiwiZm9ybWF0RGF0ZSIsImRhdGUiLCJ0b0lTT1N0cmluZyIsInNwbGl0IiwiU2FsZXNSZXBvcnQiLCJfcyIsImZvcm1hdHRlZEFnZW50cyIsInNldEZvcm1hdHRlZEFnZW50cyIsImFsbEFnZW50c0RhdGEiLCJzZXRBbGxBZ2VudHNEYXRhIiwic2VsZWN0ZWRBZ2VudElkIiwic2V0U2VsZWN0ZWRBZ2VudElkIiwic2VsZWN0ZWRBZ2VudERldGFpbHMiLCJzZXRTZWxlY3RlZEFnZW50RGV0YWlscyIsInRhYmxlUmVwb3J0RGF0YSIsInNldFRhYmxlUmVwb3J0RGF0YSIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsInRvdGFsTGVhZHMiLCJzZXRUb3RhbExlYWRzIiwidG90YWxDdXN0b21lcnMiLCJzZXRUb3RhbEN1c3RvbWVycyIsInRvdGFsU2FsZXMiLCJzZXRUb3RhbFNhbGVzIiwidGFyZ2V0RGF0YSIsInNldFRhcmdldERhdGEiLCJ0YXJnZXQiLCJhY2hpZXZlZCIsInJlbWFpbmluZyIsInN0YXJ0RGF0ZSIsImVuZERhdGUiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwiZmlsdGVyVHlwZSIsInNob3dNb2RhbCIsInNldFNob3dNb2RhbCIsInNlbGVjdGVkUm93Iiwic2V0U2VsZWN0ZWRSb3ciLCJ0b2RheSIsIkRhdGUiLCJmcm9tRGF0ZSIsInNldEZyb21EYXRlIiwidG9EYXRlIiwic2V0VG9EYXRlIiwic2hvd0ZpbHRlckZpZWxkIiwic2V0U2hvd0ZpbHRlckZpZWxkIiwidXNlRWZmZWN0IiwiZmV0Y2hBZ2VudHMiLCJyZXNwb25zZSIsImdldCIsImFnZW50cyIsImRhdGEiLCJmb3JtYXR0ZWQiLCJtYXAiLCJhZ2VudCIsImluZGV4IiwiX2lkIiwiaWQiLCJuYW1lIiwicGhvbmUiLCJwaG9uZV9udW1iZXIiLCJsYWJlbCIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImZldGNoU2FsZXNSZXBvcnQiLCJmZXRjaFRhcmdldERhdGEiLCJhZ2VudElkIiwidGFyZ2V0UmVzIiwicGFyYW1zIiwidGFyZ2V0cyIsImZpbHRlciIsInQiLCJtb250aE1hcCIsImZvckVhY2giLCJrZXkiLCJnZXRGdWxsWWVhciIsImdldE1vbnRoIiwidG90YWxUYXJnZXQiLCJkZWZhdWx0VGFyZ2V0IiwiT2JqZWN0IiwidmFsdWVzIiwibGVuZ3RoIiwidG90YWwiLCJsb29wIiwiZW5kIiwieWVhciIsIm1vbnRoIiwibW9udGhUYXJnZXQiLCJkYXlzSW5Nb250aCIsImdldERhdGUiLCJwZXJEYXlUYXJnZXQiLCJzZXREYXRlIiwiY29tbURhdGEiLCJmcm9tX2RhdGUiLCJ0b19kYXRlIiwic3VtbWFyeSIsImFjdHVhbF9idXNpbmVzcyIsIk51bWJlciIsInJlcGxhY2UiLCJNYXRoIiwibWF4IiwiZGlmZmVyZW5jZSIsImRlc2lnbmF0aW9uIiwiZmluZCIsImRlc2lnbmF0aW9uX2lkIiwidGl0bGUiLCJpbmNlbnRpdmVBbW91bnQiLCJpbmNlbnRpdmVQZXJjZW50IiwidG9Mb3dlckNhc2UiLCJhYnMiLCJyZWR1Y2UiLCJtaW4iLCJ0b0ZpeGVkIiwiaGFuZGxlU2VsZWN0RmlsdGVyIiwidmFsdWUiLCJmcm9tIiwidG8iLCJ5Iiwic3RhcnQiLCJyZXMiLCJpdGVtIiwiYWdlbnROYW1lIiwiYWdlbnRQaG9uZSIsImdyb3VwTmFtZSIsImdyb3VwVmFsdWUiLCJjdXN0b21lckRldGFpbHMiLCJjdXN0IiwicHVzaCIsImxlYWRDdXN0b21lck5hbWUiLCJjdXN0b21lclBob25lIiwic2FsZXMiLCJ0eXBlIiwibGVhZERldGFpbHMiLCJsZWFkIiwidG90YWxMZWFkc0NvdW50Iiwicm93IiwidG90YWxDdXN0b21lcnNDb3VudCIsInRvdGFsU2FsZXNBbW91bnQiLCJzdW0iLCJmb3VuZCIsImEiLCJoYW5kbGVBbnREU2VsZWN0IiwiZmllbGQiLCJwcmV2Iiwib3Blbk1vZGFsIiwiY2xvc2VNb2RhbCIsImNvbHVtbnMiLCJoZWFkZXIiLCJlIiwidmFsIiwiZW1haWwiLCJpIiwicGFuX25vIiwiYWRoYWFyX25vIiwicGluY29kZSIsImFkZHJlc3MiLCJ0b0xvY2FsZVN0cmluZyIsImN1c3RvbWVyIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2FsZXNSZXBvcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgbnVtYmVyVG9JbmRpYW5Xb3JkcyB9IGZyb20gXCIuLi9oZWxwZXJzL251bWJlclRvSW5kaWFuV29yZHNcIjtcclxuaW1wb3J0IHsgRmFVc2VycywgRmFVc2VyRnJpZW5kcywgRmFNb25leUJpbGxXYXZlIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IFNlbGVjdCB9IGZyb20gXCJhbnRkXCI7XHJcblxyXG5jb25zdCBmb3JtYXREYXRlID0gKGRhdGUpID0+IGRhdGUudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcblxyXG5jb25zdCBTYWxlc1JlcG9ydCA9ICgpID0+IHtcclxuICBjb25zdCBbZm9ybWF0dGVkQWdlbnRzLCBzZXRGb3JtYXR0ZWRBZ2VudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthbGxBZ2VudHNEYXRhLCBzZXRBbGxBZ2VudHNEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0ZWRBZ2VudElkLCBzZXRTZWxlY3RlZEFnZW50SWRdID0gdXNlU3RhdGUoXCJhbGxcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkQWdlbnREZXRhaWxzLCBzZXRTZWxlY3RlZEFnZW50RGV0YWlsc10gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbdGFibGVSZXBvcnREYXRhLCBzZXRUYWJsZVJlcG9ydERhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3RvdGFsTGVhZHMsIHNldFRvdGFsTGVhZHNdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW3RvdGFsQ3VzdG9tZXJzLCBzZXRUb3RhbEN1c3RvbWVyc10gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbdG90YWxTYWxlcywgc2V0VG90YWxTYWxlc10gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbdGFyZ2V0RGF0YSwgc2V0VGFyZ2V0RGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICB0YXJnZXQ6IDAsXHJcbiAgICBhY2hpZXZlZDogMCxcclxuICAgIHJlbWFpbmluZzogMCxcclxuICAgIHN0YXJ0RGF0ZTogXCJcIixcclxuICAgIGVuZERhdGU6IFwiXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICAvLyB1c2VyOiBcIlwiLFxyXG4gICAgZmlsdGVyVHlwZTogXCJUb2RheVwiLFxyXG4gIH0pO1xyXG5cclxuICAvLyBGb3IgbW9kYWxcclxuICBjb25zdCBbc2hvd01vZGFsLCBzZXRTaG93TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFJvdywgc2V0U2VsZWN0ZWRSb3ddID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIGNvbnN0IHRvZGF5ID0gZm9ybWF0RGF0ZShuZXcgRGF0ZSgpKTtcclxuICBjb25zdCBbZnJvbURhdGUsIHNldEZyb21EYXRlXSA9IHVzZVN0YXRlKHRvZGF5KTtcclxuICBjb25zdCBbdG9EYXRlLCBzZXRUb0RhdGVdID0gdXNlU3RhdGUodG9kYXkpO1xyXG4gIGNvbnN0IFtzaG93RmlsdGVyRmllbGQsIHNldFNob3dGaWx0ZXJGaWVsZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEFnZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2FnZW50L2dldC1hZ2VudFwiKTtcclxuICAgICAgICBjb25zdCBhZ2VudHMgPSByZXNwb25zZT8uZGF0YSB8fCBbXTtcclxuXHJcbiAgICAgICAgc2V0QWxsQWdlbnRzRGF0YShhZ2VudHMpO1xyXG5cclxuICAgICAgICBjb25zdCBmb3JtYXR0ZWQgPSBhZ2VudHMubWFwKChhZ2VudCwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICBfaWQ6IGFnZW50Ll9pZCxcclxuICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICBuYW1lOiBhZ2VudC5uYW1lLFxyXG4gICAgICAgICAgcGhvbmU6IGFnZW50LnBob25lX251bWJlcixcclxuICAgICAgICAgIGxhYmVsOiBgJHthZ2VudC5uYW1lfSAoJHthZ2VudC5waG9uZV9udW1iZXJ9KWAsXHJcbiAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICBzZXRGb3JtYXR0ZWRBZ2VudHMoZm9ybWF0dGVkKTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkZldGNoIGZhaWxlZDpcIiwgZXJyKTtcclxuICAgICAgICBzZXRGb3JtYXR0ZWRBZ2VudHMoW10pO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hBZ2VudHMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaFNhbGVzUmVwb3J0KCk7XHJcbiAgfSwgW3NlbGVjdGVkQWdlbnRJZCwgZnJvbURhdGUsIHRvRGF0ZV0pO1xyXG5cclxuICBjb25zdCBmZXRjaFRhcmdldERhdGEgPSBhc3luYyAoYWdlbnRJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgdGFyZ2V0UmVzID0gYXdhaXQgYXBpLmdldChcIi90YXJnZXQvZ2V0LXRhcmdldHNcIiwge1xyXG4gICAgICAgIHBhcmFtczogeyBmcm9tRGF0ZSwgdG9EYXRlLCBhZ2VudElkIH0sXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgdGFyZ2V0cyA9IHRhcmdldFJlcy5kYXRhLmZpbHRlcihcclxuICAgICAgICAodCkgPT4gKHQuYWdlbnRJZD8uX2lkIHx8IHQuYWdlbnRJZCkgPT09IGFnZW50SWRcclxuICAgICAgKTtcclxuXHJcbiAgICAgIC8vIFN0ZXAgMTogTW9udGhseSB0YXJnZXQgbWFwcGluZ1xyXG4gICAgICBjb25zdCBtb250aE1hcCA9IHt9O1xyXG4gICAgICB0YXJnZXRzLmZvckVhY2goKHQpID0+IHtcclxuICAgICAgICBjb25zdCBkYXRlID0gbmV3IERhdGUodC5zdGFydERhdGUpO1xyXG4gICAgICAgIGNvbnN0IGtleSA9IGAke2RhdGUuZ2V0RnVsbFllYXIoKX0tJHtkYXRlLmdldE1vbnRoKCl9YDtcclxuICAgICAgICBpZiAoIW1vbnRoTWFwW2tleV0pIG1vbnRoTWFwW2tleV0gPSB0LnRvdGFsVGFyZ2V0IHx8IDA7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgZGVmYXVsdFRhcmdldCA9XHJcbiAgICAgICAgT2JqZWN0LnZhbHVlcyhtb250aE1hcCkubGVuZ3RoID4gMCA/IE9iamVjdC52YWx1ZXMobW9udGhNYXApWzBdIDogMDtcclxuXHJcbiAgICAgIC8vIFN0ZXAgMjogQWdncmVnYXRlIHRvdGFsIHRhcmdldCBiZXR3ZWVuIGZyb21EYXRlICYgdG9EYXRlXHJcbiAgICAgIGxldCB0b3RhbCA9IDA7XHJcbiAgICAgIGxldCBsb29wID0gbmV3IERhdGUoZnJvbURhdGUpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b0RhdGUpO1xyXG4gICAgICB3aGlsZSAobG9vcCA8PSBlbmQpIHtcclxuICAgICAgICBjb25zdCB5ZWFyID0gbG9vcC5nZXRGdWxsWWVhcigpO1xyXG4gICAgICAgIGNvbnN0IG1vbnRoID0gbG9vcC5nZXRNb250aCgpOyAvLyAwLWJhc2VkIGluZGV4XHJcbiAgICAgICAgY29uc3Qga2V5ID0gYCR7eWVhcn0tJHttb250aH1gO1xyXG4gICAgICAgIGNvbnN0IG1vbnRoVGFyZ2V0ID0gbW9udGhNYXBba2V5XSA/PyBkZWZhdWx0VGFyZ2V0O1xyXG4gICAgICAgIGNvbnN0IGRheXNJbk1vbnRoID0gbmV3IERhdGUoeWVhciwgbW9udGggKyAxLCAwKS5nZXREYXRlKCk7XHJcbiAgICAgICAgY29uc3QgcGVyRGF5VGFyZ2V0ID0gbW9udGhUYXJnZXQgLyBkYXlzSW5Nb250aDtcclxuXHJcbiAgICAgICAgdG90YWwgKz0gcGVyRGF5VGFyZ2V0O1xyXG4gICAgICAgIGxvb3Auc2V0RGF0ZShsb29wLmdldERhdGUoKSArIDEpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBTdGVwIDM6IEdldCBhY2hpZXZlZCB2YWx1ZSB2aWEgZW5yb2xsIGNvbW1pc3Npb25cclxuICAgICAgY29uc3QgeyBkYXRhOiBjb21tRGF0YSB9ID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL2Vucm9sbC9nZXQtZGV0YWlsZWQtY29tbWlzc2lvbi8ke2FnZW50SWR9YCxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBwYXJhbXM6IHsgZnJvbV9kYXRlOiBmcm9tRGF0ZSwgdG9fZGF0ZTogdG9EYXRlIH0sXHJcbiAgICAgICAgfVxyXG4gICAgICApO1xyXG5cclxuICAgICAgbGV0IGFjaGlldmVkID0gY29tbURhdGE/LnN1bW1hcnk/LmFjdHVhbF9idXNpbmVzcyB8fCAwO1xyXG4gICAgICBpZiAodHlwZW9mIGFjaGlldmVkID09PSBcInN0cmluZ1wiKSB7XHJcbiAgICAgICAgYWNoaWV2ZWQgPSBOdW1iZXIoYWNoaWV2ZWQucmVwbGFjZSgvW14wLTkuLV0rL2csIFwiXCIpKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgcmVtYWluaW5nID0gTWF0aC5tYXgodG90YWwgLSBhY2hpZXZlZCwgMCk7XHJcbiAgICAgIGNvbnN0IGRpZmZlcmVuY2UgPSB0b3RhbCAtIGFjaGlldmVkO1xyXG5cclxuICAgICAgLy8gU3RlcCA0OiBHZXQgZGVzaWduYXRpb24gZm9yIGluY2VudGl2ZSBsb2dpY1xyXG4gICAgICBjb25zdCBkZXNpZ25hdGlvbiA9XHJcbiAgICAgICAgdGFyZ2V0cy5maW5kKCh0KSA9PiAodC5hZ2VudElkPy5faWQgfHwgdC5hZ2VudElkKSA9PT0gYWdlbnRJZCk/LmFnZW50SWRcclxuICAgICAgICAgID8uZGVzaWduYXRpb25faWQ/LnRpdGxlIHx8IFwiTi9BXCI7XHJcblxyXG4gICAgICAvLyBTdGVwIDU6IENhbGN1bGF0ZSBpbmNlbnRpdmVcclxuICAgICAgbGV0IGluY2VudGl2ZUFtb3VudCA9IDA7XHJcbiAgICAgIGxldCBpbmNlbnRpdmVQZXJjZW50ID0gXCIwJVwiO1xyXG4gICAgICBjb25zdCB0aXRsZSA9IGRlc2lnbmF0aW9uLnRvTG93ZXJDYXNlKCk7XHJcblxyXG4gICAgICBpZiAodGl0bGUgPT09IFwiYnVzaW5lc3MgYWdlbnRcIiAmJiBhY2hpZXZlZCA+PSB0b3RhbCkge1xyXG4gICAgICAgIGluY2VudGl2ZUFtb3VudCA9IGFjaGlldmVkICogMC4wMDU7XHJcbiAgICAgICAgaW5jZW50aXZlUGVyY2VudCA9IFwiMC41JVwiO1xyXG4gICAgICB9IGVsc2UgaWYgKGRpZmZlcmVuY2UgPCAwKSB7XHJcbiAgICAgICAgaW5jZW50aXZlQW1vdW50ID0gTWF0aC5hYnMoZGlmZmVyZW5jZSkgKiAwLjAxO1xyXG4gICAgICAgIGluY2VudGl2ZVBlcmNlbnQgPSBcIjElXCI7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIFN0ZXAgNjogRWFybGllc3Qgc3RhcnQgYW5kIGxhdGVzdCBlbmQgZnJvbSByZWFsIHRhcmdldCByb3dzXHJcbiAgICAgIGNvbnN0IHN0YXJ0RGF0ZSA9IHRhcmdldHMucmVkdWNlKFxyXG4gICAgICAgIChtaW4sIHQpID0+ICh0LnN0YXJ0RGF0ZSA8IG1pbiA/IHQuc3RhcnREYXRlIDogbWluKSxcclxuICAgICAgICB0YXJnZXRzWzBdPy5zdGFydERhdGUgfHwgXCJcIlxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCBlbmREYXRlID0gdGFyZ2V0cy5yZWR1Y2UoXHJcbiAgICAgICAgKG1heCwgdCkgPT4gKHQuZW5kRGF0ZSA+IG1heCA/IHQuZW5kRGF0ZSA6IG1heCksXHJcbiAgICAgICAgdGFyZ2V0c1swXT8uZW5kRGF0ZSB8fCBcIlwiXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBzZXRUYXJnZXREYXRhKHtcclxuICAgICAgICB0YXJnZXQ6IHRvdGFsLFxyXG4gICAgICAgIGFjaGlldmVkLFxyXG4gICAgICAgIHJlbWFpbmluZyxcclxuICAgICAgICBzdGFydERhdGU6IHN0YXJ0RGF0ZS5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgICAgZW5kRGF0ZTogZW5kRGF0ZS5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgICAgZGVzaWduYXRpb24sXHJcbiAgICAgICAgaW5jZW50aXZlQW1vdW50OiBg4oK5JHtpbmNlbnRpdmVBbW91bnQudG9GaXhlZCgyKX1gLFxyXG4gICAgICAgIGluY2VudGl2ZVBlcmNlbnQsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB0YXJnZXQgZGF0YTpcIiwgZXJyKTtcclxuICAgICAgc2V0VGFyZ2V0RGF0YSh7XHJcbiAgICAgICAgdGFyZ2V0OiAwLFxyXG4gICAgICAgIGFjaGlldmVkOiAwLFxyXG4gICAgICAgIHJlbWFpbmluZzogMCxcclxuICAgICAgICBzdGFydERhdGU6IFwiXCIsXHJcbiAgICAgICAgZW5kRGF0ZTogXCJcIixcclxuICAgICAgICBkZXNpZ25hdGlvbjogXCJcIixcclxuICAgICAgICBpbmNlbnRpdmVBbW91bnQ6IFwi4oK5MC4wMFwiLFxyXG4gICAgICAgIGluY2VudGl2ZVBlcmNlbnQ6IFwiMCVcIixcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gRmlsdGVyIExvZ2ljXHJcbiAgY29uc3QgaGFuZGxlU2VsZWN0RmlsdGVyID0gKHZhbHVlKSA9PiB7XHJcbiAgICBzZXRTaG93RmlsdGVyRmllbGQoZmFsc2UpO1xyXG5cclxuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICAgIGxldCBmcm9tID0gXCJcIjtcclxuICAgIGxldCB0byA9IFwiXCI7XHJcblxyXG4gICAgaWYgKHZhbHVlID09PSBcIlRvZGF5XCIpIHtcclxuICAgICAgZnJvbSA9IHRvID0gZm9ybWF0RGF0ZSh0b2RheSk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlllc3RlcmRheVwiKSB7XHJcbiAgICAgIGNvbnN0IHkgPSBuZXcgRGF0ZSh0b2RheSk7XHJcbiAgICAgIHkuc2V0RGF0ZSh0b2RheS5nZXREYXRlKCkgLSAxKTtcclxuICAgICAgZnJvbSA9IHRvID0gZm9ybWF0RGF0ZSh5KTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc01vbnRoXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSArIDEsIDApO1xyXG4gICAgICBmcm9tID0gZm9ybWF0RGF0ZShzdGFydCk7XHJcbiAgICAgIHRvID0gZm9ybWF0RGF0ZShlbmQpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJDdXN0b21cIikge1xyXG4gICAgICBzZXRTaG93RmlsdGVyRmllbGQodHJ1ZSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRGcm9tRGF0ZShmcm9tKTtcclxuICAgIHNldFRvRGF0ZSh0byk7XHJcbiAgfTtcclxuXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBoYW5kbGVTZWxlY3RGaWx0ZXIoZm9ybURhdGEuZmlsdGVyVHlwZSk7XHJcbiAgfSwgW2Zvcm1EYXRhLmZpbHRlclR5cGVdKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hTYWxlc1JlcG9ydCA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHtcclxuICAgICAgICBmcm9tX2RhdGU6IGZyb21EYXRlLFxyXG4gICAgICAgIHRvX2RhdGU6IHRvRGF0ZSxcclxuICAgICAgICBhZ2VudElkOiBzZWxlY3RlZEFnZW50SWQgIT09IFwiYWxsXCIgPyBzZWxlY3RlZEFnZW50SWQgOiBcImFsbFwiLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3JlcG9ydC9zYWxlcy1yZXBvcnRcIiwgeyBwYXJhbXMgfSk7XHJcbiAgICAgIGNvbnN0IHJlcyA9IHJlc3BvbnNlLmRhdGE7XHJcblxyXG4gICAgICBjb25zdCBmb3JtYXR0ZWQgPSBbXTtcclxuICAgICAgcmVzLmRhdGEuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGFnZW50TmFtZSA9IGl0ZW0uYWdlbnROYW1lO1xyXG4gICAgICAgIGNvbnN0IGFnZW50UGhvbmUgPSBpdGVtLnBob25lO1xyXG4gICAgICAgIGNvbnN0IGRhdGUgPSBpdGVtLmRhdGUgfHwgZnJvbURhdGU7XHJcbiAgICAgICAgY29uc3QgZ3JvdXBOYW1lID0gaXRlbS5ncm91cE5hbWUgfHwgJy0nO1xyXG4gICAgICAgIGNvbnN0IGdyb3VwVmFsdWUgPSBOdW1iZXIoaXRlbS5ncm91cFZhbHVlKSB8fCAwO1xyXG5cclxuICAgICAgICAvLyBGbGF0dGVuIGN1c3RvbWVyc1xyXG4gICAgICAgIChpdGVtLmN1c3RvbWVyRGV0YWlscyB8fCBbXSkuZm9yRWFjaCgoY3VzdCkgPT4ge1xyXG4gICAgICAgICAgZm9ybWF0dGVkLnB1c2goe1xyXG4gICAgICAgICAgICBpZDogZm9ybWF0dGVkLmxlbmd0aCArIDEsXHJcbiAgICAgICAgICAgIGFnZW50TmFtZSxcclxuICAgICAgICAgICAgYWdlbnRQaG9uZSxcclxuICAgICAgICAgICAgbGVhZEN1c3RvbWVyTmFtZTogY3VzdC5uYW1lLFxyXG4gICAgICAgICAgICBjdXN0b21lclBob25lOiBjdXN0LnBob25lLFxyXG4gICAgICAgICAgICBkYXRlLFxyXG4gICAgICAgICAgICBncm91cE5hbWUsXHJcbiAgICAgICAgICAgIGdyb3VwVmFsdWUsXHJcbiAgICAgICAgICAgIHNhbGVzOiBncm91cFZhbHVlLFxyXG4gICAgICAgICAgICB0eXBlOiAnQ3VzdG9tZXInLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIC8vIChPcHRpb25hbCkgRmxhdHRlbiBsZWFkc1xyXG4gICAgICAgIChpdGVtLmxlYWREZXRhaWxzIHx8IFtdKS5mb3JFYWNoKChsZWFkKSA9PiB7XHJcbiAgICAgICAgICBmb3JtYXR0ZWQucHVzaCh7XHJcbiAgICAgICAgICAgIGlkOiBmb3JtYXR0ZWQubGVuZ3RoICsgMSxcclxuICAgICAgICAgICAgYWdlbnROYW1lLFxyXG4gICAgICAgICAgICBhZ2VudFBob25lLFxyXG4gICAgICAgICAgICBsZWFkQ3VzdG9tZXJOYW1lOiBsZWFkLm5hbWUsXHJcbiAgICAgICAgICAgIGN1c3RvbWVyUGhvbmU6IGxlYWQucGhvbmUsXHJcbiAgICAgICAgICAgIGRhdGUsXHJcbiAgICAgICAgICAgIGdyb3VwTmFtZSxcclxuICAgICAgICAgICAgZ3JvdXBWYWx1ZTogMCxcclxuICAgICAgICAgICAgc2FsZXM6IDAsXHJcbiAgICAgICAgICAgIHR5cGU6ICdMZWFkJyxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHNldFRhYmxlUmVwb3J0RGF0YShmb3JtYXR0ZWQpO1xyXG5cclxuICAgICAgY29uc3QgdG90YWxMZWFkc0NvdW50ID0gZm9ybWF0dGVkLmZpbHRlcihyb3cgPT4gcm93LnR5cGUgPT09ICdMZWFkJykubGVuZ3RoO1xyXG4gICAgICBjb25zdCB0b3RhbEN1c3RvbWVyc0NvdW50ID0gZm9ybWF0dGVkLmZpbHRlcihyb3cgPT4gcm93LnR5cGUgPT09ICdDdXN0b21lcicpLmxlbmd0aDtcclxuICAgICAgY29uc3QgdG90YWxTYWxlc0Ftb3VudCA9IGZvcm1hdHRlZC5yZWR1Y2UoKHN1bSwgcm93KSA9PiBzdW0gKyByb3cuc2FsZXMsIDApO1xyXG5cclxuICAgICAgc2V0VG90YWxMZWFkcyh0b3RhbExlYWRzQ291bnQpO1xyXG4gICAgICBzZXRUb3RhbEN1c3RvbWVycyh0b3RhbEN1c3RvbWVyc0NvdW50KTtcclxuICAgICAgc2V0VG90YWxTYWxlcyh0b3RhbFNhbGVzQW1vdW50KTtcclxuXHJcbiAgICAgIGlmIChzZWxlY3RlZEFnZW50SWQgIT09IFwiYWxsXCIpIHtcclxuICAgICAgICBjb25zdCBmb3VuZCA9IGFsbEFnZW50c0RhdGEuZmluZCgoYSkgPT4gYS5faWQgPT09IHNlbGVjdGVkQWdlbnRJZCk7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRBZ2VudERldGFpbHMoZm91bmQgfHwgbnVsbCk7XHJcblxyXG4gICAgICAgIGF3YWl0IGZldGNoVGFyZ2V0RGF0YShzZWxlY3RlZEFnZW50SWQpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldFNlbGVjdGVkQWdlbnREZXRhaWxzKG51bGwpO1xyXG4gICAgICAgIHNldFRhcmdldERhdGEoe1xyXG4gICAgICAgICAgdGFyZ2V0OiAwLFxyXG4gICAgICAgICAgYWNoaWV2ZWQ6IDAsXHJcbiAgICAgICAgICByZW1haW5pbmc6IDAsXHJcbiAgICAgICAgICBzdGFydERhdGU6IFwiXCIsXHJcbiAgICAgICAgICBlbmREYXRlOiBcIlwiLFxyXG4gICAgICAgICAgZGVzaWduYXRpb246IFwiXCIsXHJcbiAgICAgICAgICBpbmNlbnRpdmVBbW91bnQ6IFwi4oK5MC4wMFwiLFxyXG4gICAgICAgICAgaW5jZW50aXZlUGVyY2VudDogXCIwJVwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgc2FsZXMgcmVwb3J0OlwiLCBlcnJvcik7XHJcbiAgICAgIHNldFRhYmxlUmVwb3J0RGF0YShbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgLy8gSGFuZGxlIFNlbGVjdFxyXG4gIGNvbnN0IGhhbmRsZUFudERTZWxlY3QgPSAoZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHsgLi4ucHJldiwgW2ZpZWxkXTogdmFsdWUgfSkpO1xyXG4gIH07XHJcbiAgLy8gTW9kYWwgaGFuZGxlcnNcclxuICBjb25zdCBvcGVuTW9kYWwgPSAocm93KSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZFJvdyhyb3cpO1xyXG4gICAgc2V0U2hvd01vZGFsKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNsb3NlTW9kYWwgPSAoKSA9PiB7XHJcbiAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgc2V0U2VsZWN0ZWRSb3cobnVsbCk7XHJcbiAgfTtcclxuXHJcbiAgLy8gQ29sdW1ucyBmb3IgRGF0YVRhYmxlXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiYWdlbnROYW1lXCIsIGhlYWRlcjogXCJBZ2VudFwiIH0sXHJcbiAgICB7IGtleTogXCJhZ2VudFBob25lXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwidHlwZVwiLCBoZWFkZXI6IFwiVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJsZWFkQ3VzdG9tZXJOYW1lXCIsIGhlYWRlcjogXCJMZWFkL0N1c3RvbWVyXCIgfSxcclxuICAgIC8vIHsga2V5OiBcImN1c3RvbWVyTmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXJzXCIgfSxcclxuICAgIHsga2V5OiBcImRhdGVcIiwgaGVhZGVyOiBcIkRhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBOYW1lXCIsIGhlYWRlcjogXCJHcm91cFwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cFZhbHVlXCIsIGhlYWRlcjogXCJHcm91cCBWYWx1ZVwiIH0sXHJcbiAgICB7IGtleTogXCJzYWxlc1wiLCBoZWFkZXI6IFwiU2FsZXNcIiB9LFxyXG4gICAgLy8gVHdvIGV4dHJhIGNvbHVtbnMgdGhhdCB3aWxsIGJlIGluY2x1ZGVkIGluIEV4Y2VsIGV4cG9ydFxyXG4gICAgLy8geyBrZXk6IFwibGVhZERldGFpbHNTdHJcIiwgaGVhZGVyOiBcIkxlYWQgRGV0YWlsc1wiIH0sXHJcbiAgICAvLyB7IGtleTogXCJjdXN0b21lckRldGFpbHNTdHJcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIERldGFpbHNcIiB9LFxyXG4gICAgLy8gQWN0aW9ucyBjb2x1bW4gKHJlbmRlciBmdW5jdGlvbiByZXF1aXJlZClcclxuICAgIC8vIHtcclxuICAgIC8vICAga2V5OiBcImFjdGlvbnNcIixcclxuICAgIC8vICAgaGVhZGVyOiBcIkFjdGlvbnNcIixcclxuICAgIC8vICAgcmVuZGVyOiAocm93KSA9PiAoXHJcbiAgICAvLyAgICAgPGJ1dHRvblxyXG4gICAgLy8gICAgICAgb25DbGljaz17KCkgPT4gb3Blbk1vZGFsKHJvdyl9XHJcbiAgICAvLyAgICAgICBjbGFzc05hbWU9XCJiZy1ibHVlLTUwMCBob3ZlcjpiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHB4LTMgcHktMSByb3VuZGVkIHRleHQtc20gdHJhbnNpdGlvblwiXHJcbiAgICAvLyAgICAgPlxyXG4gICAgLy8gICAgICAgVmlldyBEZXRhaWxzXHJcbiAgICAvLyAgICAgPC9idXR0b24+XHJcbiAgICAvLyAgICksXHJcbiAgICAvLyB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4taC1zY3JlZW5cIj5cclxuICAgICAgPE5hdmJhciAvPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBwLTZcIj5cclxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtY2VudGVyIG1iLTZcIj5SZXBvcnRzIC0gU2FsZXM8L2gxPlxyXG5cclxuICAgICAgICB7LyogRmlsdGVycyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTQgbWItNlwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgXCI+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xIGZvbnQtc2VtaWJvbGRcIj5TZWxlY3QgRW1wbG95ZWU8L2xhYmVsPlxyXG4gICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTQgcHktMiByb3VuZGVkIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQWdlbnRJZH1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkQWdlbnRJZChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWxsXCI+LS0gQWxsIEFnZW50cyAtLTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIHtmb3JtYXR0ZWRBZ2VudHMubWFwKChhKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17YS5faWR9IHZhbHVlPXthLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgIHthLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICB7LyogRmlsdGVyIFR5cGUgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBcIj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTEgZm9udC1zZW1pYm9sZFwiPkZpbHRlciBUeXBlPC9sYWJlbD5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLVs0MnB4XVwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmZpbHRlclR5cGV9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IGhhbmRsZUFudERTZWxlY3QoXCJmaWx0ZXJUeXBlXCIsIHZhbCl9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlRvZGF5XCI+VG9kYXk8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJZZXN0ZXJkYXlcIj5ZZXN0ZXJkYXk8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJUaGlzTW9udGhcIj5UaGlzIE1vbnRoPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiQ3VzdG9tXCI+Q3VzdG9tPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAge3Nob3dGaWx0ZXJGaWVsZCAmJiAoXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMSBmb250LXNlbWlib2xkXCI+RnJvbSBEYXRlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmcm9tRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgbWF4PXt0b2RheX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGcm9tRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBweC00IHB5LTIgcm91bmRlZCB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xIGZvbnQtc2VtaWJvbGRcIj5UbyBEYXRlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt0b0RhdGV9XHJcbiAgICAgICAgICAgICAgICAgIG1pbj17ZnJvbURhdGV9XHJcbiAgICAgICAgICAgICAgICAgIG1heD17dG9kYXl9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VG9EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTQgcHktMiByb3VuZGVkIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBBZ2VudCBEZXRhaWxzICYgVGFyZ2V0IERldGFpbHMgLSBzYW1lIGFzIGJlZm9yZSAqL31cclxuICAgICAgICB7c2VsZWN0ZWRBZ2VudERldGFpbHMgJiYgKFxyXG4gICAgICAgICAgPD5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHNoYWRvdy1sZyByb3VuZGVkLXhsIHAtNiBtYi02XCI+XHJcbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtaW5kaWdvLTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNSBoLTVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cclxuICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTYgN2E0IDQgMCAxMS04IDAgNCA0IDAgMDE4IDB6TTEyIDE0YTcgNyAwIDAwLTcgN2gxNGE3IDcgMCAwMC03LTd6XCIgLz5cclxuICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgQWdlbnQgRGV0YWlsc1xyXG4gICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC01XCI+XHJcbiAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICB7IGxhYmVsOiAnTmFtZScsIHZhbHVlOiBzZWxlY3RlZEFnZW50RGV0YWlscy5uYW1lIHx8ICctJyB9LFxyXG4gICAgICAgICAgICAgICAgICB7IGxhYmVsOiAnUGhvbmUnLCB2YWx1ZTogc2VsZWN0ZWRBZ2VudERldGFpbHMucGhvbmVfbnVtYmVyIHx8ICctJyB9LFxyXG4gICAgICAgICAgICAgICAgICB7IGxhYmVsOiAnRW1haWwnLCB2YWx1ZTogc2VsZWN0ZWRBZ2VudERldGFpbHMuZW1haWwgfHwgJy0nIH0sXHJcbiAgICAgICAgICAgICAgICBdLm1hcCgoZmllbGQsIGkpID0+IChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBtYi0xXCI+e2ZpZWxkLmxhYmVsfTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSB0ZXh0LWdyYXktODAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZmllbGQudmFsdWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC01IG10LTVcIj5cclxuICAgICAgICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgICAgICAgIHsgbGFiZWw6ICdQQU4nLCB2YWx1ZTogc2VsZWN0ZWRBZ2VudERldGFpbHMucGFuX25vIHx8ICctJyB9LFxyXG4gICAgICAgICAgICAgICAgICB7IGxhYmVsOiAnQWFkaGFhcicsIHZhbHVlOiBzZWxlY3RlZEFnZW50RGV0YWlscy5hZGhhYXJfbm8gfHwgJy0nIH0sXHJcbiAgICAgICAgICAgICAgICAgIHsgbGFiZWw6ICdQaW5jb2RlJywgdmFsdWU6IHNlbGVjdGVkQWdlbnREZXRhaWxzLnBpbmNvZGUgfHwgJy0nIH0sXHJcbiAgICAgICAgICAgICAgICBdLm1hcCgoZmllbGQsIGkpID0+IChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBtYi0xXCI+e2ZpZWxkLmxhYmVsfTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSB0ZXh0LWdyYXktODAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZmllbGQudmFsdWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC01XCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgbWItMVwiPkFkZHJlc3M8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSB0ZXh0LWdyYXktODAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZEFnZW50RGV0YWlscy5hZGRyZXNzIHx8ICctJ31cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0yMDAgc2hhZG93LWxnIHJvdW5kZWQteGwgcC02IG1iLTYgcmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC15ZWxsb3ctNzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy01IGgtNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk05IDE5di02YTIgMiAwIDAwLTItMkg1YTIgMiAwIDAwLTIgMnY2YTIgMiAwIDAwMiAyaDJhMiAyIDAgMDAyLTJ6bTAgMFY5YTIgMiAwIDAxMi0yaDJhMiAyIDAgMDEyIDJ2MTBtLTYgMGEyIDIgMCAwMDIgMmgyYTIgMiAwIDAwMi0ybTAgMFY1YTIgMiAwIDAxMi0yaDJhMiAyIDAgMDEyIDJ2MTRhMiAyIDAgMDEtMiAyaC0yYTIgMiAwIDAxLTItMnpcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICBUYXJnZXQgRGV0YWlsc1xyXG4gICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgIHt0YXJnZXREYXRhLnRhcmdldCA+IDAgJiYgdGFyZ2V0RGF0YS5hY2hpZXZlZCA+PSB0YXJnZXREYXRhLnRhcmdldCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC00IHJpZ2h0LTYgYmctZ3JlZW4tMTAwIGJvcmRlciBib3JkZXItZ3JlZW4tMzAwIHRleHQtZ3JlZW4tODAwIHB4LTQgcHktMS41IHJvdW5kZWQtZnVsbCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgc2hhZG93LXNtIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGdcIj7wn46JPC9zcGFuPiBUYXJnZXQgQWNoaWV2ZWRcclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgICAge1tcclxuICAgICAgICAgICAgICAgICAgeyBsYWJlbDogJ1RhcmdldCBTZXQnLCB2YWx1ZTogYOKCuSR7dGFyZ2V0RGF0YS50YXJnZXQudG9Mb2NhbGVTdHJpbmcoJ2VuLUlOJyl9YCwgd29yZDogdGFyZ2V0RGF0YS50YXJnZXQgfSxcclxuICAgICAgICAgICAgICAgICAgeyBsYWJlbDogJ0FjaGlldmVkJywgdmFsdWU6IGDigrkke3RhcmdldERhdGEuYWNoaWV2ZWQudG9Mb2NhbGVTdHJpbmcoJ2VuLUlOJyl9YCwgd29yZDogdGFyZ2V0RGF0YS5hY2hpZXZlZCB9LFxyXG4gICAgICAgICAgICAgICAgICB7IGxhYmVsOiAnUmVtYWluaW5nJywgdmFsdWU6IGDigrkke3RhcmdldERhdGEucmVtYWluaW5nLnRvTG9jYWxlU3RyaW5nKCdlbi1JTicpfWAsIHdvcmQ6IHRhcmdldERhdGEucmVtYWluaW5nIH0sXHJcbiAgICAgICAgICAgICAgICBdLm1hcCgoaXRlbSwgaWR4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpZHh9IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcm91bmRlZC14bCBwLTQgYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBtYi0xXCI+e2l0ZW0ubGFiZWx9PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+e2l0ZW0udmFsdWV9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JlZW4tNzAwIGZvbnQtbW9ubyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhpdGVtLndvcmQgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PiAqL31cclxuICAgICAgICAgIDwvPlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIHsvKiBTdW1tYXJ5IENvdW50ZXJzIC0gdW5jaGFuZ2VkICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMyBnYXAtNCBtYi02XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0yMDAgc2hhZG93LW1kIHJvdW5kZWQteGwgcC01IGZsZXggaXRlbXMtc3RhcnQgZ2FwLTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgcm91bmRlZC1mdWxsIGJnLWJsdWUtMTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtYmx1ZS02MDAgdGV4dC0yeGxcIj5cclxuICAgICAgICAgICAgICA8RmFVc2VycyAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+VG90YWwgTGVhZHM8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+e3RvdGFsTGVhZHMudG9Mb2NhbGVTdHJpbmcoJ2VuLUlOJyl9PC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgZm9udC1tb25vIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHModG90YWxMZWFkcyB8fCAwKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0yMDAgc2hhZG93LW1kIHJvdW5kZWQteGwgcC01IGZsZXggaXRlbXMtc3RhcnQgZ2FwLTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgcm91bmRlZC1mdWxsIGJnLXB1cnBsZS0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1wdXJwbGUtNjAwIHRleHQtMnhsXCI+XHJcbiAgICAgICAgICAgICAgPEZhVXNlckZyaWVuZHMgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlRvdGFsIEN1c3RvbWVyczwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj57dG90YWxDdXN0b21lcnMudG9Mb2NhbGVTdHJpbmcoJ2VuLUlOJyl9PC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgZm9udC1tb25vIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHModG90YWxDdXN0b21lcnMgfHwgMCl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHNoYWRvdy1tZCByb3VuZGVkLXhsIHAtNSBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC00XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHJvdW5kZWQtZnVsbCBiZy1ncmVlbi0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1ncmVlbi02MDAgdGV4dC0yeGxcIj5cclxuICAgICAgICAgICAgICA8RmFNb25leUJpbGxXYXZlIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5Ub3RhbCBTYWxlczwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj7igrl7dG90YWxTYWxlcy50b0xvY2FsZVN0cmluZygnZW4tSU4nKX08L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBmb250LW1vbm8gbXQtMC41XCI+XHJcbiAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyh0b3RhbFNhbGVzIHx8IDApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogRGF0YVRhYmxlICovfVxyXG4gICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgZGF0YT17dGFibGVSZXBvcnREYXRhfVxyXG4gICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiU2FsZXNSZXBvcnQuY3N2XCJcclxuICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiU2FsZXMgUmVwb3J0XCJcclxuICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtbXHJcbiAgICAgICAgICAgICAgXCJBZ2VudCBOYW1lXCIsXHJcbiAgICAgICAgICAgICAgXCJGcm9tIERhdGVcIixcclxuICAgICAgICAgICAgICBcIlRvIERhdGVcIixcclxuICAgICAgICAgICAgICBcIlRvdGFsIExlYWRzXCIsXHJcbiAgICAgICAgICAgICAgXCJUb3RhbCBDdXN0b21lcnNcIixcclxuICAgICAgICAgICAgICBcIlRvdGFsIFNhbGVzXCIsXHJcbiAgICAgICAgICAgICAgXCJUYXJnZXQgU2V0XCIsXHJcbiAgICAgICAgICAgICAgXCJBY2hpZXZlZFwiLFxyXG4gICAgICAgICAgICAgIFwiUmVtYWluaW5nXCIsXHJcbiAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbXHJcbiAgICAgICAgICAgICAgc2VsZWN0ZWRBZ2VudERldGFpbHM/Lm5hbWUgfHwgXCJBbGwgQWdlbnRzXCIsXHJcbiAgICAgICAgICAgICAgZnJvbURhdGUgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgdG9EYXRlIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgIHRvdGFsTGVhZHMudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKSxcclxuICAgICAgICAgICAgICB0b3RhbEN1c3RvbWVycy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpLFxyXG4gICAgICAgICAgICAgIGDigrkke3RvdGFsU2FsZXMudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gLFxyXG4gICAgICAgICAgICAgIGDigrkke3RhcmdldERhdGEudGFyZ2V0LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgICAgICAgICAgICBg4oK5JHt0YXJnZXREYXRhLmFjaGlldmVkLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgICAgICAgICAgICBg4oK5JHt0YXJnZXREYXRhLnJlbWFpbmluZy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWAsXHJcbiAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIHsvKiA9PT09PSBEZXRhaWxzIE1vZGFsID09PT09ICovfVxyXG4gICAgICAgIHtzaG93TW9kYWwgJiYgc2VsZWN0ZWRSb3cgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYmxhY2sgYmctb3BhY2l0eS01MCBwLTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy0yeGwgbWF4LXctNHhsIHctZnVsbCBtYXgtaC1bOTB2aF0gb3ZlcmZsb3cteS1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGlja3kgdG9wLTAgYmctd2hpdGUgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwIHB4LTYgcHktNCBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIERldGFpbHMgZm9yIHtzZWxlY3RlZFJvdy5uYW1lfSAtIHtzZWxlY3RlZFJvdy5ncm91cE5hbWV9XHJcbiAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtjbG9zZU1vZGFsfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtZ3JheS02MDAgdGV4dC0yeGwgbGVhZGluZy1ub25lXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgJnRpbWVzO1xyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02XCI+XHJcbiAgICAgICAgICAgICAgICB7LyogTGVhZCBEZXRhaWxzICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ibHVlLTcwMCBtYi0zIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+8J+RpDwvc3Bhbj4gTGVhZCBEZXRhaWxzICh7c2VsZWN0ZWRSb3cubGVhZERldGFpbHM/Lmxlbmd0aCB8fCAwfSlcclxuICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAge3NlbGVjdGVkUm93LmxlYWREZXRhaWxzICYmIHNlbGVjdGVkUm93LmxlYWREZXRhaWxzLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMCBib3JkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+IzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+TmFtZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+UGhvbmU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRSb3cubGVhZERldGFpbHMubWFwKChsZWFkLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17aW5kZXh9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPntpbmRleCArIDF9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXNtIHRleHQtZ3JheS04MDBcIj57bGVhZC5uYW1lfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+e2xlYWQucGhvbmV9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1zbVwiPk5vIGxlYWRzIHJlY29yZGVkIGZvciB0aGlzIGVudHJ5LjwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBDdXN0b21lciBEZXRhaWxzICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyZWVuLTcwMCBtYi0zIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+8J+nkeKAjfCfpJ3igI3wn6eRPC9zcGFuPiBDdXN0b21lciBEZXRhaWxzICh7c2VsZWN0ZWRSb3cuY3VzdG9tZXJEZXRhaWxzPy5sZW5ndGggfHwgMH0pXHJcbiAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFJvdy5jdXN0b21lckRldGFpbHMgJiYgc2VsZWN0ZWRSb3cuY3VzdG9tZXJEZXRhaWxzLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMCBib3JkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+IzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+TmFtZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+UGhvbmU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRSb3cuY3VzdG9tZXJEZXRhaWxzLm1hcCgoY3VzdG9tZXIsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtpbmRleH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+e2luZGV4ICsgMX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtc20gdGV4dC1ncmF5LTgwMFwiPntjdXN0b21lci5uYW1lfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+e2N1c3RvbWVyLnBob25lfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQtc21cIj5ObyBjdXN0b21lcnMgcmVjb3JkZWQgZm9yIHRoaXMgZW50cnkuPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RpY2t5IGJvdHRvbS0wIGJnLWdyYXktNTAgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwIHB4LTYgcHktNCBmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2Nsb3NlTW9kYWx9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktMzAwIGhvdmVyOmJnLWdyYXktNDAwIHRleHQtZ3JheS04MDAgcHgtNCBweS0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIENsb3NlXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTYWxlc1JlcG9ydDsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvU2FsZXNSZXBvcnQuanN4In0=