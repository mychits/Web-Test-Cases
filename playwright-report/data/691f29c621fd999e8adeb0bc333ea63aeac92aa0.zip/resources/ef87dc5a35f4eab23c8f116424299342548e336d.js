import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/SuspendedCustomerReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import API from "/src/instance/TokenInstance.js";
import { notification, Pagination, Spin, Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { AlertCircle, Download } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { UserOutlined, CalendarOutlined, FilterOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
function SuspendedCustomerReport() {
  _s();
  const [loading, setLoading] = useState(false);
  const [suspendedData, setSuspendedData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0
  });
  const [selectedFromDate, setSelectedFromDate] = useState("");
  const [selectedToDate, setSelectedToDate] = useState("");
  const [showFilterField, setShowFilterField] = useState(false);
  const [selectedUser, setSelectedUser] = useState("");
  const [users, setUsers] = useState([]);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [formData, setFormData] = useState({
    user: "",
    filterType: "Today"
  });
  const formatDate = (date) => {
    if (!date) return "";
    return date.toLocaleDateString("en-CA");
  };
  const handleAntDSelect = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };
  const handleSelectFilter = (value) => {
    setShowFilterField(false);
    const today = /* @__PURE__ */ new Date();
    let from = "";
    let to = "";
    if (value === "Today") {
      from = to = formatDate(today);
    } else if (value === "Yesterday") {
      const y = new Date(today);
      y.setDate(today.getDate() - 1);
      from = to = formatDate(y);
    } else if (value === "ThisMonth") {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      from = formatDate(start);
      to = formatDate(end);
    } else if (value === "Custom") {
      setShowFilterField(true);
      return;
    }
    setSelectedFromDate(from);
    setSelectedToDate(to);
  };
  useEffect(() => {
    handleSelectFilter(formData.filterType);
  }, [formData.filterType]);
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await API.get("/user/get-user");
        setUsers(res.data || []);
      } catch (err) {
        console.error("Error fetching users:", err);
      }
    };
    fetchUsers();
  }, []);
  const formatDateDisplay = (dateString) => {
    if (!dateString) return "-";
    const date = new Date(dateString);
    return date.toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  };
  const fetchSuspendedCustomers = async (page = 1, limit = 10) => {
    setLoading(true);
    try {
      let url = `/v1/admin/enrolls/removal-reason/Suspend?page=${page}&limit=${limit}`;
      const params = new URLSearchParams();
      if (selectedUser) params.append("user_id", selectedUser);
      if (selectedFromDate) params.append("from_date", selectedFromDate);
      if (selectedToDate) params.append("to_date", selectedToDate);
      if (params.toString()) url += `&${params.toString()}`;
      const response = await API.get(url);
      if (response.data.success) {
        const rawData = response.data.data || [];
        const formattedData = rawData.map((item, index) => ({
          ...item,
          slNo: (page - 1) * limit + index + 1,
          customer_id: item.user_id?.customer_id || "-",
          full_name: item.user_id?.full_name || "-",
          phone_number: item.user_id?.phone_number || "-",
          group_name: item.group_id?.group_name || "-",
          formatted_deleted_at: formatDateDisplay(item.deleted_at),
          removal_reason: item.removal_reason || "-",
          statusBadge: /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800", children: "Suspended" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
            lineNumber: 140,
            columnNumber: 11
          }, this),
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center", children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-xl cursor-pointer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
            lineNumber: 146,
            columnNumber: 29
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
            lineNumber: 145,
            columnNumber: 11
          }, this)
        }));
        setSuspendedData(formattedData);
        setFilteredData(formattedData);
        setPagination({
          ...pagination,
          current: page,
          total: response.data.total || rawData.length
        });
      } else {
        notification.error({
          message: "Error",
          description: response.data.message || "Failed to fetch suspended customers"
        });
      }
    } catch (error) {
      console.error("Error fetching suspended customers:", error);
      notification.error({
        message: "Error",
        description: error.response?.data?.message || "Failed to fetch suspended customers"
      });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    if (selectedFromDate && selectedToDate) {
      fetchSuspendedCustomers(1, pagination.pageSize);
    } else if (!showFilterField && formData.filterType !== "Custom") {
      fetchSuspendedCustomers(1, pagination.pageSize);
    }
  }, [selectedFromDate, selectedToDate, selectedUser]);
  const handlePageChange = (page, pageSize) => {
    fetchSuspendedCustomers(page, pageSize);
  };
  const handleExport = () => {
    const exportData = filteredData.map((item) => ({
      "S.No": item.slNo,
      "Enroll Code": item.enroll_code || "-",
      "Customer ID": item.customer_id,
      "Customer Name": item.full_name,
      "Phone Number": item.phone_number,
      "Group Name": item.group_name,
      "Tickets": item.tickets || "-",
      "Payment Type": item.payment_type || "-",
      "Referred Type": item.referred_type || "-",
      "Suspended Date": item.formatted_deleted_at,
      "Removal Reason": item.removal_reason
    }));
    const headers = Object.keys(exportData[0] || {});
    const csvContent = [
      headers.join(","),
      ...exportData.map((row) => headers.map((h) => `"${row[h]}"`).join(","))
    ].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Suspended_Customers_Report_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };
  const columns = useMemo(
    () => [
      { key: "slNo", header: "S.No" },
      { key: "enroll_code", header: "Enroll Code" },
      { key: "customer_id", header: "Customer ID" },
      { key: "full_name", header: "Customer Name" },
      { key: "phone_number", header: "Phone Number" },
      { key: "group_name", header: "Group Name" },
      { key: "tickets", header: "Tickets" },
      { key: "payment_type", header: "Payment Type" },
      { key: "referred_type", header: "Referred Type" },
      { key: "formatted_deleted_at", header: "Suspended Date" },
      { key: "removal_reason", header: "Remove Reason" },
      { key: "statusBadge", header: "Status" },
      { key: "action", header: "Action" }
    ],
    []
  );
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-screen bg-gray-50 overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 flex flex-col min-h-screen min-w-0", children: [
    /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
      lineNumber: 236,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
        lineNumber: 238,
        columnNumber: 17
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-4 overflow-auto", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm p-4 mb-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-gray-800", children: "Suspended Customers Report" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
            lineNumber: 251,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "List of all customers with suspended status" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
            lineNumber: 254,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
          lineNumber: 250,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 bg-red-100 text-red-700 rounded-full text-sm", children: [
          "Total: ",
          pagination.total
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
          lineNumber: 260,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
          lineNumber: 258,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
        lineNumber: 249,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
        lineNumber: 248,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm p-4 mb-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-end gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "min-w-[200px] ", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-600 mb-1 flex items-center gap-1", children: [
            /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-blue-500 text-xs" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
              lineNumber: 272,
              columnNumber: 37
            }, this),
            "Select Customer"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
            lineNumber: 271,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full",
              placeholder: "All Customers",
              showSearch: true,
              size: "middle",
              filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
              value: selectedUser || void 0,
              onChange: (val) => setSelectedUser(val),
              children: [
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
                  lineNumber: 289,
                  columnNumber: 37
                }, this),
                users.map(
                  (u) => /* @__PURE__ */ jsxDEV(Select.Option, { value: u._id, children: [
                    u.full_name,
                    " - ",
                    u.phone_number
                  ] }, u._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
                    lineNumber: 291,
                    columnNumber: 19
                  }, this)
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
              lineNumber: 275,
              columnNumber: 33
            },
            this
          ),
          selectedUser && /* @__PURE__ */ jsxDEV("div", { className: "mt-1 text-xs text-gray-500", children: [
            "Selected: ",
            users.find((u) => u._id === selectedUser)?.full_name
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
            lineNumber: 297,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
          lineNumber: 270,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "min-w-[150px] ", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-600 mb-1 flex items-center gap-1", children: [
            /* @__PURE__ */ jsxDEV(CalendarOutlined, { className: "text-green-500 text-xs" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
              lineNumber: 306,
              columnNumber: 37
            }, this),
            "Date Filter"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
            lineNumber: 305,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full",
              size: "middle",
              value: formData.filterType,
              onChange: (val) => handleAntDSelect("filterType", val),
              children: [
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "Today", children: "Today" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
                  lineNumber: 315,
                  columnNumber: 37
                }, this),
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "Yesterday", children: "Yesterday" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
                  lineNumber: 316,
                  columnNumber: 37
                }, this),
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "ThisMonth", children: "This Month" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
                  lineNumber: 317,
                  columnNumber: 37
                }, this),
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "Custom", children: "Custom" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
                  lineNumber: 318,
                  columnNumber: 37
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
              lineNumber: 309,
              columnNumber: 33
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
          lineNumber: 304,
          columnNumber: 29
        }, this),
        showFilterField && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-[150px] flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-600 mb-1 flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV(CalendarOutlined, { className: "text-orange-500 text-xs" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
                lineNumber: 327,
                columnNumber: 45
              }, this),
              "From Date"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
              lineNumber: 326,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                className: "w-full h-10 px-3 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                value: selectedFromDate,
                onChange: (e) => setSelectedFromDate(e.target.value)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
                lineNumber: 330,
                columnNumber: 41
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
            lineNumber: 325,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-[150px] flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-600 mb-1 flex items-center gap-1", children: [
              /* @__PURE__ */ jsxDEV(CalendarOutlined, { className: "text-orange-500 text-xs" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
                lineNumber: 339,
                columnNumber: 45
              }, this),
              "To Date"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
              lineNumber: 338,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                className: "w-full h-10 px-3 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                value: selectedToDate,
                onChange: (e) => setSelectedToDate(e.target.value)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
                lineNumber: 342,
                columnNumber: 41
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
            lineNumber: 337,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
          lineNumber: 324,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
        lineNumber: 268,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
        lineNumber: 267,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm", children: loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center h-64", children: /* @__PURE__ */ jsxDEV(Spin, { size: "large", tip: "Loading..." }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
        lineNumber: 357,
        columnNumber: 33
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
        lineNumber: 356,
        columnNumber: 13
      }, this) : filteredData.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center h-64 text-gray-500", children: [
        /* @__PURE__ */ jsxDEV(AlertCircle, { className: "w-12 h-12 mb-2 text-gray-400" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
          lineNumber: 361,
          columnNumber: 33
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-lg", children: "No suspended customers found" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
          lineNumber: 362,
          columnNumber: 33
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
        lineNumber: 360,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          columns,
          data: filteredData,
          rowKey: "_id",
          scroll: { x: 1200 },
          pagination: false
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
          lineNumber: 366,
          columnNumber: 33
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
        lineNumber: 365,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
        lineNumber: 354,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
      lineNumber: 247,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
    lineNumber: 235,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx",
    lineNumber: 234,
    columnNumber: 5
  }, this);
}
_s(SuspendedCustomerReport, "9pyIfngpdaNipjYodzYg5v1riPU=");
_c = SuspendedCustomerReport;
export default SuspendedCustomerReport;
var _c;
$RefreshReg$(_c, "SuspendedCustomerReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspendedCustomerReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkl3QixTQXdMUSxVQXhMUjsyQkEzSXhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsVUFBVUMsZUFBZTtBQUM3QyxPQUFPQyxTQUFTO0FBQ2hCLFNBQVNDLGNBQWNDLFlBQVlDLE1BQU1DLGNBQWM7QUFDdkQsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLGFBQWFDLGdCQUFnQjtBQUN0QyxPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLG9CQUFvQjtBQUMzQixTQUFTQyxnQkFBZ0I7QUFDekIsT0FBT0MsdUJBQXVCO0FBQzlCLFNBQVNDLGNBQWNDLGtCQUFrQkMsc0JBQXNCO0FBRS9ELFNBQVNDLDBCQUEwQjtBQUFBQyxLQUFBO0FBQy9CLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJckIsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ3NCLGVBQWVDLGdCQUFnQixJQUFJdkIsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ3dCLGNBQWNDLGVBQWUsSUFBSXpCLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUMwQixZQUFZQyxhQUFhLElBQUkzQixTQUFTO0FBQUEsSUFDekM0QixTQUFTO0FBQUEsSUFDVEMsVUFBVTtBQUFBLElBQ1ZDLE9BQU87QUFBQSxFQUNYLENBQUM7QUFHRCxRQUFNLENBQUNDLGtCQUFrQkMsbUJBQW1CLElBQUloQyxTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDaUMsZ0JBQWdCQyxpQkFBaUIsSUFBSWxDLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNtQyxpQkFBaUJDLGtCQUFrQixJQUFJcEMsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ3FDLGNBQWNDLGVBQWUsSUFBSXRDLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUN1QyxPQUFPQyxRQUFRLElBQUl4QyxTQUFTLEVBQUU7QUFHckMsUUFBTSxDQUFDeUMsYUFBYUMsY0FBYyxJQUFJMUMsU0FBUztBQUFBLElBQzNDMkMsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsRUFDVixDQUFDO0FBRUQsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUkvQyxTQUFTO0FBQUEsSUFDckNnRCxNQUFNO0FBQUEsSUFDTkMsWUFBWTtBQUFBLEVBQ2hCLENBQUM7QUFHRCxRQUFNQyxhQUFhQSxDQUFDQyxTQUFTO0FBQ3pCLFFBQUksQ0FBQ0EsS0FBTSxRQUFPO0FBQ2xCLFdBQU9BLEtBQUtDLG1CQUFtQixPQUFPO0FBQUEsRUFDMUM7QUFHQSxRQUFNQyxtQkFBbUJBLENBQUNDLE9BQU9DLFVBQVU7QUFDdkNSLGdCQUFZLENBQUNTLFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUNGLEtBQUssR0FBR0MsTUFBTSxFQUFFO0FBQUEsRUFDdkQ7QUFHQSxRQUFNRSxxQkFBcUJBLENBQUNGLFVBQVU7QUFDbENuQix1QkFBbUIsS0FBSztBQUV4QixVQUFNc0IsUUFBUSxvQkFBSUMsS0FBSztBQUN2QixRQUFJQyxPQUFPO0FBQ1gsUUFBSUMsS0FBSztBQUVULFFBQUlOLFVBQVUsU0FBUztBQUNuQkssYUFBT0MsS0FBS1gsV0FBV1EsS0FBSztBQUFBLElBQ2hDLFdBQVdILFVBQVUsYUFBYTtBQUM5QixZQUFNTyxJQUFJLElBQUlILEtBQUtELEtBQUs7QUFDeEJJLFFBQUVDLFFBQVFMLE1BQU1NLFFBQVEsSUFBSSxDQUFDO0FBQzdCSixhQUFPQyxLQUFLWCxXQUFXWSxDQUFDO0FBQUEsSUFDNUIsV0FBV1AsVUFBVSxhQUFhO0FBQzlCLFlBQU1VLFFBQVEsSUFBSU4sS0FBS0QsTUFBTVEsWUFBWSxHQUFHUixNQUFNUyxTQUFTLEdBQUcsQ0FBQztBQUMvRCxZQUFNQyxNQUFNLElBQUlULEtBQUtELE1BQU1RLFlBQVksR0FBR1IsTUFBTVMsU0FBUyxJQUFJLEdBQUcsQ0FBQztBQUNqRVAsYUFBT1YsV0FBV2UsS0FBSztBQUN2QkosV0FBS1gsV0FBV2tCLEdBQUc7QUFBQSxJQUN2QixXQUFXYixVQUFVLFVBQVU7QUFDM0JuQix5QkFBbUIsSUFBSTtBQUN2QjtBQUFBLElBQ0o7QUFFQUosd0JBQW9CNEIsSUFBSTtBQUN4QjFCLHNCQUFrQjJCLEVBQUU7QUFBQSxFQUN4QjtBQUVBOUQsWUFBVSxNQUFNO0FBQ1owRCx1QkFBbUJYLFNBQVNHLFVBQVU7QUFBQSxFQUMxQyxHQUFHLENBQUNILFNBQVNHLFVBQVUsQ0FBQztBQUd4QmxELFlBQVUsTUFBTTtBQUNaLFVBQU1zRSxhQUFhLFlBQVk7QUFDM0IsVUFBSTtBQUNBLGNBQU1DLE1BQU0sTUFBTXBFLElBQUlxRSxJQUFJLGdCQUFnQjtBQUMxQy9CLGlCQUFTOEIsSUFBSUUsUUFBUSxFQUFFO0FBQUEsTUFDM0IsU0FBU0MsS0FBSztBQUNWQyxnQkFBUUMsTUFBTSx5QkFBeUJGLEdBQUc7QUFBQSxNQUM5QztBQUFBLElBQ0o7QUFDQUosZUFBVztBQUFBLEVBQ2YsR0FBRyxFQUFFO0FBR0wsUUFBTU8sb0JBQW9CQSxDQUFDQyxlQUFlO0FBQ3RDLFFBQUksQ0FBQ0EsV0FBWSxRQUFPO0FBQ3hCLFVBQU0xQixPQUFPLElBQUlRLEtBQUtrQixVQUFVO0FBQ2hDLFdBQU8xQixLQUFLQyxtQkFBbUIsU0FBUztBQUFBLE1BQ3BDMEIsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxNQUFNO0FBQUEsTUFDTkMsTUFBTTtBQUFBLE1BQ05DLFFBQVE7QUFBQSxJQUNaLENBQUM7QUFBQSxFQUNMO0FBR0EsUUFBTUMsMEJBQTBCLE9BQU9DLE9BQU8sR0FBR0MsUUFBUSxPQUFPO0FBQzVEaEUsZUFBVyxJQUFJO0FBQ2YsUUFBSTtBQUNBLFVBQUlpRSxNQUFNLGlEQUFpREYsSUFBSSxVQUFVQyxLQUFLO0FBQzlFLFlBQU1FLFNBQVMsSUFBSUMsZ0JBQWdCO0FBRW5DLFVBQUluRCxhQUFja0QsUUFBT0UsT0FBTyxXQUFXcEQsWUFBWTtBQUN2RCxVQUFJTixpQkFBa0J3RCxRQUFPRSxPQUFPLGFBQWExRCxnQkFBZ0I7QUFDakUsVUFBSUUsZUFBZ0JzRCxRQUFPRSxPQUFPLFdBQVd4RCxjQUFjO0FBRTNELFVBQUlzRCxPQUFPRyxTQUFTLEVBQUdKLFFBQU8sSUFBSUMsT0FBT0csU0FBUyxDQUFDO0FBRW5ELFlBQU1DLFdBQVcsTUFBTXpGLElBQUlxRSxJQUFJZSxHQUFHO0FBRWxDLFVBQUlLLFNBQVNuQixLQUFLb0IsU0FBUztBQUN2QixjQUFNQyxVQUFVRixTQUFTbkIsS0FBS0EsUUFBUTtBQUV0QyxjQUFNc0IsZ0JBQWdCRCxRQUFRRSxJQUFJLENBQUNDLE1BQU1DLFdBQVc7QUFBQSxVQUNoRCxHQUFHRDtBQUFBQSxVQUNIRSxPQUFPZCxPQUFPLEtBQUtDLFFBQVFZLFFBQVE7QUFBQSxVQUNuQ0UsYUFBYUgsS0FBS0ksU0FBU0QsZUFBZTtBQUFBLFVBQzFDRSxXQUFXTCxLQUFLSSxTQUFTQyxhQUFhO0FBQUEsVUFDdENDLGNBQWNOLEtBQUtJLFNBQVNFLGdCQUFnQjtBQUFBLFVBQzVDQyxZQUFZUCxLQUFLUSxVQUFVRCxjQUFjO0FBQUEsVUFDekNFLHNCQUFzQjdCLGtCQUFrQm9CLEtBQUtVLFVBQVU7QUFBQSxVQUN2REMsZ0JBQWdCWCxLQUFLVyxrQkFBa0I7QUFBQSxVQUN2Q0MsYUFDSSx1QkFBQyxVQUFLLFdBQVUsd0VBQXVFLHlCQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFSkMsUUFDSSx1QkFBQyxTQUFJLFdBQVUsdUJBQ1gsaUNBQUMsWUFBUyxXQUFVLDRCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QyxLQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsUUFFUixFQUFFO0FBRUZ0Rix5QkFBaUJ1RSxhQUFhO0FBQzlCckUsd0JBQWdCcUUsYUFBYTtBQUM3Qm5FLHNCQUFjO0FBQUEsVUFDVixHQUFHRDtBQUFBQSxVQUNIRSxTQUFTd0Q7QUFBQUEsVUFDVHRELE9BQU82RCxTQUFTbkIsS0FBSzFDLFNBQVMrRCxRQUFRaUI7QUFBQUEsUUFDMUMsQ0FBQztBQUFBLE1BQ0wsT0FBTztBQUNIM0cscUJBQWF3RSxNQUFNO0FBQUEsVUFDZi9CLFNBQVM7QUFBQSxVQUNUbUUsYUFBYXBCLFNBQVNuQixLQUFLNUIsV0FBVztBQUFBLFFBQzFDLENBQUM7QUFBQSxNQUNMO0FBQUEsSUFDSixTQUFTK0IsT0FBTztBQUNaRCxjQUFRQyxNQUFNLHVDQUF1Q0EsS0FBSztBQUMxRHhFLG1CQUFhd0UsTUFBTTtBQUFBLFFBQ2YvQixTQUFTO0FBQUEsUUFDVG1FLGFBQWFwQyxNQUFNZ0IsVUFBVW5CLE1BQU01QixXQUFXO0FBQUEsTUFDbEQsQ0FBQztBQUFBLElBQ0wsVUFBQztBQUNHdkIsaUJBQVcsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDSjtBQUVBdEIsWUFBVSxNQUFNO0FBQ1osUUFBSWdDLG9CQUFvQkUsZ0JBQWdCO0FBQ3BDa0QsOEJBQXdCLEdBQUd6RCxXQUFXRyxRQUFRO0FBQUEsSUFDbEQsV0FBVyxDQUFDTSxtQkFBbUJXLFNBQVNHLGVBQWUsVUFBVTtBQUM3RGtDLDhCQUF3QixHQUFHekQsV0FBV0csUUFBUTtBQUFBLElBQ2xEO0FBQUEsRUFDSixHQUFHLENBQUNFLGtCQUFrQkUsZ0JBQWdCSSxZQUFZLENBQUM7QUFFbkQsUUFBTTJFLG1CQUFtQkEsQ0FBQzVCLE1BQU12RCxhQUFhO0FBQ3pDc0QsNEJBQXdCQyxNQUFNdkQsUUFBUTtBQUFBLEVBQzFDO0FBRUEsUUFBTW9GLGVBQWVBLE1BQU07QUFDdkIsVUFBTUMsYUFBYTFGLGFBQWF1RSxJQUFJLENBQUFDLFVBQVM7QUFBQSxNQUN6QyxRQUFRQSxLQUFLRTtBQUFBQSxNQUNiLGVBQWVGLEtBQUttQixlQUFlO0FBQUEsTUFDbkMsZUFBZW5CLEtBQUtHO0FBQUFBLE1BQ3BCLGlCQUFpQkgsS0FBS0s7QUFBQUEsTUFDdEIsZ0JBQWdCTCxLQUFLTTtBQUFBQSxNQUNyQixjQUFjTixLQUFLTztBQUFBQSxNQUNuQixXQUFXUCxLQUFLb0IsV0FBVztBQUFBLE1BQzNCLGdCQUFnQnBCLEtBQUtxQixnQkFBZ0I7QUFBQSxNQUNyQyxpQkFBaUJyQixLQUFLc0IsaUJBQWlCO0FBQUEsTUFDdkMsa0JBQWtCdEIsS0FBS1M7QUFBQUEsTUFDdkIsa0JBQWtCVCxLQUFLVztBQUFBQSxJQUMzQixFQUFFO0FBRUYsVUFBTVksVUFBVUMsT0FBT0MsS0FBS1AsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQy9DLFVBQU1RLGFBQWE7QUFBQSxNQUNmSCxRQUFRSSxLQUFLLEdBQUc7QUFBQSxNQUNoQixHQUFHVCxXQUFXbkIsSUFBSSxDQUFBNkIsUUFBT0wsUUFBUXhCLElBQUksQ0FBQThCLE1BQUssSUFBSUQsSUFBSUMsQ0FBQyxDQUFDLEdBQUcsRUFBRUYsS0FBSyxHQUFHLENBQUM7QUFBQSxJQUFDLEVBQ3JFQSxLQUFLLElBQUk7QUFFWCxVQUFNRyxPQUFPLElBQUlDLEtBQUssQ0FBQ0wsVUFBVSxHQUFHLEVBQUU3RSxNQUFNLFdBQVcsQ0FBQztBQUN4RCxVQUFNeUMsTUFBTTBDLE9BQU9DLElBQUlDLGdCQUFnQkosSUFBSTtBQUMzQyxVQUFNSyxJQUFJQyxTQUFTQyxjQUFjLEdBQUc7QUFDcENGLE1BQUVHLE9BQU9oRDtBQUNUNkMsTUFBRUksV0FBVywrQkFBOEIsb0JBQUk1RSxLQUFLLEdBQUU2RSxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUMsQ0FBQztBQUNqRk4sTUFBRU8sTUFBTTtBQUNSVixXQUFPQyxJQUFJVSxnQkFBZ0JyRCxHQUFHO0FBQUEsRUFDbEM7QUFFQSxRQUFNc0QsVUFBVTNJO0FBQUFBLElBQVEsTUFBTTtBQUFBLE1BQzFCLEVBQUU0SSxLQUFLLFFBQVFDLFFBQVEsT0FBTztBQUFBLE1BQzlCLEVBQUVELEtBQUssZUFBZUMsUUFBUSxjQUFjO0FBQUEsTUFDNUMsRUFBRUQsS0FBSyxlQUFlQyxRQUFRLGNBQWM7QUFBQSxNQUM1QyxFQUFFRCxLQUFLLGFBQWFDLFFBQVEsZ0JBQWdCO0FBQUEsTUFDNUMsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZUFBZTtBQUFBLE1BQzlDLEVBQUVELEtBQUssY0FBY0MsUUFBUSxhQUFhO0FBQUEsTUFDMUMsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLFVBQVU7QUFBQSxNQUNwQyxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxlQUFlO0FBQUEsTUFDOUMsRUFBRUQsS0FBSyxpQkFBaUJDLFFBQVEsZ0JBQWdCO0FBQUEsTUFDaEQsRUFBRUQsS0FBSyx3QkFBd0JDLFFBQVEsaUJBQWlCO0FBQUEsTUFDeEQsRUFBRUQsS0FBSyxrQkFBa0JDLFFBQVEsZ0JBQWdCO0FBQUEsTUFDakQsRUFBRUQsS0FBSyxlQUFlQyxRQUFRLFNBQVM7QUFBQSxNQUN2QyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLElBQUM7QUFBQSxJQUNwQztBQUFBLEVBQUU7QUFFTCxTQUNJLHVCQUFDLFNBQUksV0FBVSw0Q0FDWCxpQ0FBQyxTQUFJLFdBQVUsNkNBQ1g7QUFBQSwyQkFBQyxVQUFPLFlBQVksUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QjtBQUFBLElBRXpCO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDRyxNQUFNckcsWUFBWUk7QUFBQUEsUUFDbEIsV0FBV0osWUFBWUU7QUFBQUEsUUFDdkIsU0FBU0YsWUFBWUc7QUFBQUEsUUFDckIsU0FBUyxNQUNMRixlQUFlLENBQUNjLFVBQVUsRUFBRSxHQUFHQSxNQUFNYixZQUFZLE1BQU0sRUFBRTtBQUFBO0FBQUEsTUFMakU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUs7QUFBQSxJQUdMLHVCQUFDLFNBQUksV0FBVSw0QkFDWDtBQUFBLDZCQUFDLFNBQUksV0FBVSwwQ0FDWCxpQ0FBQyxTQUFJLFdBQVUscUNBQ1g7QUFBQSwrQkFBQyxTQUNHO0FBQUEsaUNBQUMsUUFBRyxXQUFVLG9DQUFtQywwQ0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLHlCQUF3QiwyREFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBRVgsaUNBQUMsVUFBSyxXQUFVLDBEQUF5RDtBQUFBO0FBQUEsVUFDN0RqQixXQUFXSTtBQUFBQSxhQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsS0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQSxLQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUJBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ1gsaUNBQUMsU0FBSSxXQUFVLGtDQUVYO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGtCQUNYO0FBQUEsaUNBQUMsV0FBTSxXQUFVLHdFQUNiO0FBQUEsbUNBQUMsZ0JBQWEsV0FBVSwyQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0M7QUFBQSxZQUFHO0FBQUEsZUFEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaO0FBQUEsY0FDQSxNQUFLO0FBQUEsY0FDTCxjQUFjLENBQUNpSCxPQUFPQyxXQUNsQkEsT0FBT0MsU0FDRnZELFNBQVMsRUFDVHdELFlBQVksRUFDWkMsU0FBU0osTUFBTUcsWUFBWSxDQUFDO0FBQUEsY0FFckMsT0FBTzdHLGdCQUFnQitHO0FBQUFBLGNBQ3ZCLFVBQVUsQ0FBQ0MsUUFBUS9HLGdCQUFnQitHLEdBQUc7QUFBQSxjQUV0QztBQUFBLHVDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyw2QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUM7QUFBQSxnQkFDcEM5RyxNQUFNd0Q7QUFBQUEsa0JBQUksQ0FBQ3VELE1BQ1IsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU9BLEVBQUVDLEtBQy9CRDtBQUFBQSxzQkFBRWpEO0FBQUFBLG9CQUFVO0FBQUEsb0JBQUlpRCxFQUFFaEQ7QUFBQUEsdUJBREhnRCxFQUFFQyxLQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0g7QUFBQTtBQUFBO0FBQUEsWUFuQkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBb0JBO0FBQUEsVUFDQ2xILGdCQUNHLHVCQUFDLFNBQUksV0FBVSw4QkFBNkI7QUFBQTtBQUFBLFlBQzdCRSxNQUFNaUgsS0FBSyxDQUFBRixNQUFLQSxFQUFFQyxRQUFRbEgsWUFBWSxHQUFHZ0U7QUFBQUEsZUFEeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBN0JSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErQkE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSxrQkFDWDtBQUFBLGlDQUFDLFdBQU0sV0FBVSx3RUFDYjtBQUFBLG1DQUFDLG9CQUFpQixXQUFVLDRCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRDtBQUFBLFlBQUc7QUFBQSxlQUQzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csV0FBVTtBQUFBLGNBQ1YsTUFBSztBQUFBLGNBQ0wsT0FBT3ZELFNBQVNHO0FBQUFBLGNBQ2hCLFVBQVUsQ0FBQ29HLFFBQVFoRyxpQkFBaUIsY0FBY2dHLEdBQUc7QUFBQSxjQUVyRDtBQUFBLHVDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sU0FBUSxxQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0M7QUFBQSxnQkFDbEMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxhQUFZLHlCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwQztBQUFBLGdCQUMxQyx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLGFBQVksMEJBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJDO0FBQUEsZ0JBQzNDLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sVUFBUyxzQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0M7QUFBQTtBQUFBO0FBQUEsWUFUeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxhQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxRQUdDbEgsbUJBQ0csbUNBQ0k7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsd0JBQ1g7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsd0VBQ2I7QUFBQSxxQ0FBQyxvQkFBaUIsV0FBVSw2QkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUQ7QUFBQSxjQUFHO0FBQUEsaUJBRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixPQUFPSjtBQUFBQSxnQkFDUCxVQUFVLENBQUMwSCxNQUFNekgsb0JBQW9CeUgsRUFBRUMsT0FBT25HLEtBQUs7QUFBQTtBQUFBLGNBSnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUl5RDtBQUFBLGVBVDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx3QkFDWDtBQUFBLG1DQUFDLFdBQU0sV0FBVSx3RUFDYjtBQUFBLHFDQUFDLG9CQUFpQixXQUFVLDZCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRDtBQUFBLGNBQUc7QUFBQSxpQkFENUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUNWLE9BQU90QjtBQUFBQSxnQkFDUCxVQUFVLENBQUN3SCxNQUFNdkgsa0JBQWtCdUgsRUFBRUMsT0FBT25HLEtBQUs7QUFBQTtBQUFBLGNBSnJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUl1RDtBQUFBLGVBVDNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxhQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUJBO0FBQUEsV0FqRlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1GQSxLQXBGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUZBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsaUNBQ1ZuQyxvQkFDRyx1QkFBQyxTQUFJLFdBQVUseUNBQ1gsaUNBQUMsUUFBSyxNQUFLLFNBQVEsS0FBSSxnQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQyxLQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsSUFDQUksYUFBYXNGLFdBQVcsSUFDeEIsdUJBQUMsU0FBSSxXQUFVLGdFQUNYO0FBQUEsK0JBQUMsZUFBWSxXQUFVLGtDQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFEO0FBQUEsUUFDckQsdUJBQUMsT0FBRSxXQUFVLFdBQVUsNENBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUQ7QUFBQSxXQUZ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0EsSUFFQSxtQ0FDSTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0c7QUFBQSxVQUNBLE1BQU10RjtBQUFBQSxVQUNOLFFBQU87QUFBQSxVQUNQLFFBQVEsRUFBRW1JLEdBQUcsS0FBSztBQUFBLFVBQ2xCLFlBQVk7QUFBQTtBQUFBLFFBTGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtzQixLQU4xQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0EsS0FwQlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNCQTtBQUFBLFNBaklKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrSUE7QUFBQSxPQTlJSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0lBLEtBaEpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpSkE7QUFFUjtBQUFDeEksR0EvV1FELHlCQUF1QjtBQUFBMEksS0FBdkIxSTtBQWlYVCxlQUFlQTtBQUF3QixJQUFBMEk7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlTWVtbyIsIkFQSSIsIm5vdGlmaWNhdGlvbiIsIlBhZ2luYXRpb24iLCJTcGluIiwiU2VsZWN0IiwiU2lkZWJhciIsIk5hdmJhciIsIkFsZXJ0Q2lyY2xlIiwiRG93bmxvYWQiLCJEYXRhVGFibGUiLCJDaXJjdWxhckxvYWRlciIsIklvTWRNb3JlIiwiQ3VzdG9tQWxlcnREaWFsb2ciLCJVc2VyT3V0bGluZWQiLCJDYWxlbmRhck91dGxpbmVkIiwiRmlsdGVyT3V0bGluZWQiLCJTdXNwZW5kZWRDdXN0b21lclJlcG9ydCIsIl9zIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzdXNwZW5kZWREYXRhIiwic2V0U3VzcGVuZGVkRGF0YSIsImZpbHRlcmVkRGF0YSIsInNldEZpbHRlcmVkRGF0YSIsInBhZ2luYXRpb24iLCJzZXRQYWdpbmF0aW9uIiwiY3VycmVudCIsInBhZ2VTaXplIiwidG90YWwiLCJzZWxlY3RlZEZyb21EYXRlIiwic2V0U2VsZWN0ZWRGcm9tRGF0ZSIsInNlbGVjdGVkVG9EYXRlIiwic2V0U2VsZWN0ZWRUb0RhdGUiLCJzaG93RmlsdGVyRmllbGQiLCJzZXRTaG93RmlsdGVyRmllbGQiLCJzZWxlY3RlZFVzZXIiLCJzZXRTZWxlY3RlZFVzZXIiLCJ1c2VycyIsInNldFVzZXJzIiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwidHlwZSIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJ1c2VyIiwiZmlsdGVyVHlwZSIsImZvcm1hdERhdGUiLCJkYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiaGFuZGxlQW50RFNlbGVjdCIsImZpZWxkIiwidmFsdWUiLCJwcmV2IiwiaGFuZGxlU2VsZWN0RmlsdGVyIiwidG9kYXkiLCJEYXRlIiwiZnJvbSIsInRvIiwieSIsInNldERhdGUiLCJnZXREYXRlIiwic3RhcnQiLCJnZXRGdWxsWWVhciIsImdldE1vbnRoIiwiZW5kIiwiZmV0Y2hVc2VycyIsInJlcyIsImdldCIsImRhdGEiLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJmb3JtYXREYXRlRGlzcGxheSIsImRhdGVTdHJpbmciLCJkYXkiLCJtb250aCIsInllYXIiLCJob3VyIiwibWludXRlIiwiZmV0Y2hTdXNwZW5kZWRDdXN0b21lcnMiLCJwYWdlIiwibGltaXQiLCJ1cmwiLCJwYXJhbXMiLCJVUkxTZWFyY2hQYXJhbXMiLCJhcHBlbmQiLCJ0b1N0cmluZyIsInJlc3BvbnNlIiwic3VjY2VzcyIsInJhd0RhdGEiLCJmb3JtYXR0ZWREYXRhIiwibWFwIiwiaXRlbSIsImluZGV4Iiwic2xObyIsImN1c3RvbWVyX2lkIiwidXNlcl9pZCIsImZ1bGxfbmFtZSIsInBob25lX251bWJlciIsImdyb3VwX25hbWUiLCJncm91cF9pZCIsImZvcm1hdHRlZF9kZWxldGVkX2F0IiwiZGVsZXRlZF9hdCIsInJlbW92YWxfcmVhc29uIiwic3RhdHVzQmFkZ2UiLCJhY3Rpb24iLCJsZW5ndGgiLCJkZXNjcmlwdGlvbiIsImhhbmRsZVBhZ2VDaGFuZ2UiLCJoYW5kbGVFeHBvcnQiLCJleHBvcnREYXRhIiwiZW5yb2xsX2NvZGUiLCJ0aWNrZXRzIiwicGF5bWVudF90eXBlIiwicmVmZXJyZWRfdHlwZSIsImhlYWRlcnMiLCJPYmplY3QiLCJrZXlzIiwiY3N2Q29udGVudCIsImpvaW4iLCJyb3ciLCJoIiwiYmxvYiIsIkJsb2IiLCJ3aW5kb3ciLCJVUkwiLCJjcmVhdGVPYmplY3RVUkwiLCJhIiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50IiwiaHJlZiIsImRvd25sb2FkIiwidG9JU09TdHJpbmciLCJzcGxpdCIsImNsaWNrIiwicmV2b2tlT2JqZWN0VVJMIiwiY29sdW1ucyIsImtleSIsImhlYWRlciIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwidW5kZWZpbmVkIiwidmFsIiwidSIsIl9pZCIsImZpbmQiLCJlIiwidGFyZ2V0IiwieCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlN1c3BlbmRlZEN1c3RvbWVyUmVwb3J0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSByZWFjdC9wcm9wLXR5cGVzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZU1lbW8gfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IEFQSSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgeyBub3RpZmljYXRpb24sIFBhZ2luYXRpb24sIFNwaW4sIFNlbGVjdCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCB7IEFsZXJ0Q2lyY2xlLCBEb3dubG9hZCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCB7IFVzZXJPdXRsaW5lZCwgQ2FsZW5kYXJPdXRsaW5lZCwgRmlsdGVyT3V0bGluZWQgfSBmcm9tICdAYW50LWRlc2lnbi9pY29ucyc7XHJcblxyXG5mdW5jdGlvbiBTdXNwZW5kZWRDdXN0b21lclJlcG9ydCgpIHtcclxuICAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtzdXNwZW5kZWREYXRhLCBzZXRTdXNwZW5kZWREYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFtmaWx0ZXJlZERhdGEsIHNldEZpbHRlcmVkRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgICBjb25zdCBbcGFnaW5hdGlvbiwgc2V0UGFnaW5hdGlvbl0gPSB1c2VTdGF0ZSh7XHJcbiAgICAgICAgY3VycmVudDogMSxcclxuICAgICAgICBwYWdlU2l6ZTogMTAsXHJcbiAgICAgICAgdG90YWw6IDAsXHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyBGaWx0ZXIgc3RhdGVzXHJcbiAgICBjb25zdCBbc2VsZWN0ZWRGcm9tRGF0ZSwgc2V0U2VsZWN0ZWRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFtzZWxlY3RlZFRvRGF0ZSwgc2V0U2VsZWN0ZWRUb0RhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbc2hvd0ZpbHRlckZpZWxkLCBzZXRTaG93RmlsdGVyRmllbGRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW3NlbGVjdGVkVXNlciwgc2V0U2VsZWN0ZWRVc2VyXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4gICAgLy8gQWxlcnQgc3RhdGVcclxuICAgIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICAgICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgICAgICB1c2VyOiBcIlwiLFxyXG4gICAgICAgIGZpbHRlclR5cGU6IFwiVG9kYXlcIixcclxuICAgIH0pO1xyXG5cclxuICAgIC8vIEZvcm1hdCBkYXRlXHJcbiAgICBjb25zdCBmb3JtYXREYXRlID0gKGRhdGUpID0+IHtcclxuICAgICAgICBpZiAoIWRhdGUpIHJldHVybiBcIlwiO1xyXG4gICAgICAgIHJldHVybiBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUNBXCIpO1xyXG4gICAgfTtcclxuXHJcbiAgICAvLyBIYW5kbGUgU2VsZWN0XHJcbiAgICBjb25zdCBoYW5kbGVBbnREU2VsZWN0ID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbZmllbGRdOiB2YWx1ZSB9KSk7XHJcbiAgICB9O1xyXG5cclxuICAgIC8vIEZpbHRlciBMb2dpY1xyXG4gICAgY29uc3QgaGFuZGxlU2VsZWN0RmlsdGVyID0gKHZhbHVlKSA9PiB7XHJcbiAgICAgICAgc2V0U2hvd0ZpbHRlckZpZWxkKGZhbHNlKTtcclxuXHJcbiAgICAgICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICAgIGxldCBmcm9tID0gXCJcIjtcclxuICAgICAgICBsZXQgdG8gPSBcIlwiO1xyXG5cclxuICAgICAgICBpZiAodmFsdWUgPT09IFwiVG9kYXlcIikge1xyXG4gICAgICAgICAgICBmcm9tID0gdG8gPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuICAgICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlllc3RlcmRheVwiKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHkgPSBuZXcgRGF0ZSh0b2RheSk7XHJcbiAgICAgICAgICAgIHkuc2V0RGF0ZSh0b2RheS5nZXREYXRlKCkgLSAxKTtcclxuICAgICAgICAgICAgZnJvbSA9IHRvID0gZm9ybWF0RGF0ZSh5KTtcclxuICAgICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNNb250aFwiKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMSk7XHJcbiAgICAgICAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgKyAxLCAwKTtcclxuICAgICAgICAgICAgZnJvbSA9IGZvcm1hdERhdGUoc3RhcnQpO1xyXG4gICAgICAgICAgICB0byA9IGZvcm1hdERhdGUoZW5kKTtcclxuICAgICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkN1c3RvbVwiKSB7XHJcbiAgICAgICAgICAgIHNldFNob3dGaWx0ZXJGaWVsZCh0cnVlKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmcm9tKTtcclxuICAgICAgICBzZXRTZWxlY3RlZFRvRGF0ZSh0byk7XHJcbiAgICB9O1xyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgaGFuZGxlU2VsZWN0RmlsdGVyKGZvcm1EYXRhLmZpbHRlclR5cGUpO1xyXG4gICAgfSwgW2Zvcm1EYXRhLmZpbHRlclR5cGVdKTtcclxuXHJcbiAgICAvLyBGZXRjaCBVc2Vyc1xyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBjb25zdCBmZXRjaFVzZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgQVBJLmdldChcIi91c2VyL2dldC11c2VyXCIpO1xyXG4gICAgICAgICAgICAgICAgc2V0VXNlcnMocmVzLmRhdGEgfHwgW10pO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyczpcIiwgZXJyKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICAgICAgZmV0Y2hVc2VycygpO1xyXG4gICAgfSwgW10pO1xyXG5cclxuICAgIC8vIEZvcm1hdCBkYXRlIGZvciBkaXNwbGF5XHJcbiAgICBjb25zdCBmb3JtYXREYXRlRGlzcGxheSA9IChkYXRlU3RyaW5nKSA9PiB7XHJcbiAgICAgICAgaWYgKCFkYXRlU3RyaW5nKSByZXR1cm4gXCItXCI7XHJcbiAgICAgICAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKGRhdGVTdHJpbmcpO1xyXG4gICAgICAgIHJldHVybiBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgZGF5OiBcIjItZGlnaXRcIixcclxuICAgICAgICAgICAgbW9udGg6IFwiMi1kaWdpdFwiLFxyXG4gICAgICAgICAgICB5ZWFyOiBcIm51bWVyaWNcIixcclxuICAgICAgICAgICAgaG91cjogXCIyLWRpZ2l0XCIsXHJcbiAgICAgICAgICAgIG1pbnV0ZTogXCIyLWRpZ2l0XCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG5cclxuICAgIC8vIEZldGNoIHN1c3BlbmRlZCBjdXN0b21lcnMgZGF0YVxyXG4gICAgY29uc3QgZmV0Y2hTdXNwZW5kZWRDdXN0b21lcnMgPSBhc3luYyAocGFnZSA9IDEsIGxpbWl0ID0gMTApID0+IHtcclxuICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGxldCB1cmwgPSBgL3YxL2FkbWluL2Vucm9sbHMvcmVtb3ZhbC1yZWFzb24vU3VzcGVuZD9wYWdlPSR7cGFnZX0mbGltaXQ9JHtsaW1pdH1gO1xyXG4gICAgICAgICAgICBjb25zdCBwYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKCk7XHJcblxyXG4gICAgICAgICAgICBpZiAoc2VsZWN0ZWRVc2VyKSBwYXJhbXMuYXBwZW5kKFwidXNlcl9pZFwiLCBzZWxlY3RlZFVzZXIpO1xyXG4gICAgICAgICAgICBpZiAoc2VsZWN0ZWRGcm9tRGF0ZSkgcGFyYW1zLmFwcGVuZChcImZyb21fZGF0ZVwiLCBzZWxlY3RlZEZyb21EYXRlKTtcclxuICAgICAgICAgICAgaWYgKHNlbGVjdGVkVG9EYXRlKSBwYXJhbXMuYXBwZW5kKFwidG9fZGF0ZVwiLCBzZWxlY3RlZFRvRGF0ZSk7XHJcblxyXG4gICAgICAgICAgICBpZiAocGFyYW1zLnRvU3RyaW5nKCkpIHVybCArPSBgJiR7cGFyYW1zLnRvU3RyaW5nKCl9YDtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldCh1cmwpO1xyXG5cclxuICAgICAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEuc3VjY2Vzcykge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcmF3RGF0YSA9IHJlc3BvbnNlLmRhdGEuZGF0YSB8fCBbXTtcclxuXHJcbiAgICAgICAgICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmF3RGF0YS5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgIC4uLml0ZW0sXHJcbiAgICAgICAgICAgICAgICAgICAgc2xObzogKHBhZ2UgLSAxKSAqIGxpbWl0ICsgaW5kZXggKyAxLFxyXG4gICAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiBpdGVtLnVzZXJfaWQ/LmN1c3RvbWVyX2lkIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGZ1bGxfbmFtZTogaXRlbS51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBpdGVtLnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIi1cIixcclxuICAgICAgICAgICAgICAgICAgICBncm91cF9uYW1lOiBpdGVtLmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGZvcm1hdHRlZF9kZWxldGVkX2F0OiBmb3JtYXREYXRlRGlzcGxheShpdGVtLmRlbGV0ZWRfYXQpLFxyXG4gICAgICAgICAgICAgICAgICAgIHJlbW92YWxfcmVhc29uOiBpdGVtLnJlbW92YWxfcmVhc29uIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIHN0YXR1c0JhZGdlOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1mdWxsIGJnLXJlZC0xMDAgdGV4dC1yZWQtODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBTdXNwZW5kZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQteGwgY3Vyc29yLXBvaW50ZXJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICAgICAgICAgIHNldFN1c3BlbmRlZERhdGEoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgICAgICAgICAgICBzZXRGaWx0ZXJlZERhdGEoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgICAgICAgICAgICBzZXRQYWdpbmF0aW9uKHtcclxuICAgICAgICAgICAgICAgICAgICAuLi5wYWdpbmF0aW9uLFxyXG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbnQ6IHBhZ2UsXHJcbiAgICAgICAgICAgICAgICAgICAgdG90YWw6IHJlc3BvbnNlLmRhdGEudG90YWwgfHwgcmF3RGF0YS5sZW5ndGgsXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIG5vdGlmaWNhdGlvbi5lcnJvcih7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogXCJFcnJvclwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiByZXNwb25zZS5kYXRhLm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gZmV0Y2ggc3VzcGVuZGVkIGN1c3RvbWVyc1wiLFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgc3VzcGVuZGVkIGN1c3RvbWVyczpcIiwgZXJyb3IpO1xyXG4gICAgICAgICAgICBub3RpZmljYXRpb24uZXJyb3Ioe1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogXCJFcnJvclwiLFxyXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIGZldGNoIHN1c3BlbmRlZCBjdXN0b21lcnNcIixcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGlmIChzZWxlY3RlZEZyb21EYXRlICYmIHNlbGVjdGVkVG9EYXRlKSB7XHJcbiAgICAgICAgICAgIGZldGNoU3VzcGVuZGVkQ3VzdG9tZXJzKDEsIHBhZ2luYXRpb24ucGFnZVNpemUpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoIXNob3dGaWx0ZXJGaWVsZCAmJiBmb3JtRGF0YS5maWx0ZXJUeXBlICE9PSBcIkN1c3RvbVwiKSB7XHJcbiAgICAgICAgICAgIGZldGNoU3VzcGVuZGVkQ3VzdG9tZXJzKDEsIHBhZ2luYXRpb24ucGFnZVNpemUpO1xyXG4gICAgICAgIH1cclxuICAgIH0sIFtzZWxlY3RlZEZyb21EYXRlLCBzZWxlY3RlZFRvRGF0ZSwgc2VsZWN0ZWRVc2VyXSk7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlUGFnZUNoYW5nZSA9IChwYWdlLCBwYWdlU2l6ZSkgPT4ge1xyXG4gICAgICAgIGZldGNoU3VzcGVuZGVkQ3VzdG9tZXJzKHBhZ2UsIHBhZ2VTaXplKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlRXhwb3J0ID0gKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGV4cG9ydERhdGEgPSBmaWx0ZXJlZERhdGEubWFwKGl0ZW0gPT4gKHtcclxuICAgICAgICAgICAgXCJTLk5vXCI6IGl0ZW0uc2xObyxcclxuICAgICAgICAgICAgXCJFbnJvbGwgQ29kZVwiOiBpdGVtLmVucm9sbF9jb2RlIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICBcIkN1c3RvbWVyIElEXCI6IGl0ZW0uY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICAgIFwiQ3VzdG9tZXIgTmFtZVwiOiBpdGVtLmZ1bGxfbmFtZSxcclxuICAgICAgICAgICAgXCJQaG9uZSBOdW1iZXJcIjogaXRlbS5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgIFwiR3JvdXAgTmFtZVwiOiBpdGVtLmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgIFwiVGlja2V0c1wiOiBpdGVtLnRpY2tldHMgfHwgXCItXCIsXHJcbiAgICAgICAgICAgIFwiUGF5bWVudCBUeXBlXCI6IGl0ZW0ucGF5bWVudF90eXBlIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICBcIlJlZmVycmVkIFR5cGVcIjogaXRlbS5yZWZlcnJlZF90eXBlIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICBcIlN1c3BlbmRlZCBEYXRlXCI6IGl0ZW0uZm9ybWF0dGVkX2RlbGV0ZWRfYXQsXHJcbiAgICAgICAgICAgIFwiUmVtb3ZhbCBSZWFzb25cIjogaXRlbS5yZW1vdmFsX3JlYXNvbixcclxuICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgIGNvbnN0IGhlYWRlcnMgPSBPYmplY3Qua2V5cyhleHBvcnREYXRhWzBdIHx8IHt9KTtcclxuICAgICAgICBjb25zdCBjc3ZDb250ZW50ID0gW1xyXG4gICAgICAgICAgICBoZWFkZXJzLmpvaW4oJywnKSxcclxuICAgICAgICAgICAgLi4uZXhwb3J0RGF0YS5tYXAocm93ID0+IGhlYWRlcnMubWFwKGggPT4gYFwiJHtyb3dbaF19XCJgKS5qb2luKCcsJykpXHJcbiAgICAgICAgXS5qb2luKCdcXG4nKTtcclxuXHJcbiAgICAgICAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtjc3ZDb250ZW50XSwgeyB0eXBlOiAndGV4dC9jc3YnIH0pO1xyXG4gICAgICAgIGNvbnN0IHVybCA9IHdpbmRvdy5VUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xyXG4gICAgICAgIGNvbnN0IGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XHJcbiAgICAgICAgYS5ocmVmID0gdXJsO1xyXG4gICAgICAgIGEuZG93bmxvYWQgPSBgU3VzcGVuZGVkX0N1c3RvbWVyc19SZXBvcnRfJHtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXX0uY3N2YDtcclxuICAgICAgICBhLmNsaWNrKCk7XHJcbiAgICAgICAgd2luZG93LlVSTC5yZXZva2VPYmplY3RVUkwodXJsKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgY29sdW1ucyA9IHVzZU1lbW8oKCkgPT4gW1xyXG4gICAgICAgIHsga2V5OiBcInNsTm9cIiwgaGVhZGVyOiBcIlMuTm9cIiB9LFxyXG4gICAgICAgIHsga2V5OiBcImVucm9sbF9jb2RlXCIsIGhlYWRlcjogXCJFbnJvbGwgQ29kZVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiY3VzdG9tZXJfaWRcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIElEXCIgfSxcclxuICAgICAgICB7IGtleTogXCJmdWxsX25hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgICAgICB7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgICAgICB7IGtleTogXCJ0aWNrZXRzXCIsIGhlYWRlcjogXCJUaWNrZXRzXCIgfSxcclxuICAgICAgICB7IGtleTogXCJwYXltZW50X3R5cGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgVHlwZVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwicmVmZXJyZWRfdHlwZVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgVHlwZVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiZm9ybWF0dGVkX2RlbGV0ZWRfYXRcIiwgaGVhZGVyOiBcIlN1c3BlbmRlZCBEYXRlXCIgfSxcclxuICAgICAgICB7IGtleTogXCJyZW1vdmFsX3JlYXNvblwiLCBoZWFkZXI6IFwiUmVtb3ZlIFJlYXNvblwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwic3RhdHVzQmFkZ2VcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gICAgXSwgW10pO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtc2NyZWVuIGJnLWdyYXktNTAgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggZmxleC1jb2wgbWluLWgtc2NyZWVuIG1pbi13LTBcIj5cclxuICAgICAgICAgICAgICAgIDxOYXZiYXIgdmlzaWJpbGl0eT17dHJ1ZX0gLz5cclxuXHJcbiAgICAgICAgICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIHAtNCBvdmVyZmxvdy1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBwLTQgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU3VzcGVuZGVkIEN1c3RvbWVycyBSZXBvcnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBMaXN0IG9mIGFsbCBjdXN0b21lcnMgd2l0aCBzdXNwZW5kZWQgc3RhdHVzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTMgcHktMSBiZy1yZWQtMTAwIHRleHQtcmVkLTcwMCByb3VuZGVkLWZ1bGwgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbDoge3BhZ2luYXRpb24udG90YWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIHAtNCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtZW5kIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQ3VzdG9tZXIgRmlsdGVyICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy1bMjAwcHhdIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgbWItMSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VXNlck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDAgdGV4dC14c1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBDdXN0b21lclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFsbCBDdXN0b21lcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJtaWRkbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFVzZXIgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4gc2V0U2VsZWN0ZWRVc2VyKHZhbCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPkFsbCBDdXN0b21lcnM8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dS5faWR9IHZhbHVlPXt1Ll9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3UuZnVsbF9uYW1lfSAtIHt1LnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkVXNlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdGVkOiB7dXNlcnMuZmluZCh1ID0+IHUuX2lkID09PSBzZWxlY3RlZFVzZXIpPy5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogRGF0ZSBGaWx0ZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LVsxNTBweF0gXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBtYi0xIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDYWxlbmRhck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNTAwIHRleHQteHNcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEYXRlIEZpbHRlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibWlkZGxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmZpbHRlclR5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwiZmlsdGVyVHlwZVwiLCB2YWwpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJUb2RheVwiPlRvZGF5PC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlllc3RlcmRheVwiPlllc3RlcmRheTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJUaGlzTW9udGhcIj5UaGlzIE1vbnRoPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIkN1c3RvbVwiPkN1c3RvbTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBDdXN0b20gRGF0ZSBSYW5nZSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93RmlsdGVyRmllbGQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctWzE1MHB4XSBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgbWItMSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDYWxlbmRhck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtb3JhbmdlLTUwMCB0ZXh0LXhzXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBGcm9tIERhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTAgcHgtMyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgdGV4dC1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRGcm9tRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkRnJvbURhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctWzE1MHB4XSBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgbWItMSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDYWxlbmRhck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtb3JhbmdlLTUwMCB0ZXh0LXhzXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUbyBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEwIHB4LTMgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHRleHQtc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkVG9EYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRUb0RhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7bG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgaC02NFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTcGluIHNpemU9XCJsYXJnZVwiIHRpcD1cIkxvYWRpbmcuLi5cIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiBmaWx0ZXJlZERhdGEubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBoLTY0IHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QWxlcnRDaXJjbGUgY2xhc3NOYW1lPVwidy0xMiBoLTEyIG1iLTIgdGV4dC1ncmF5LTQwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZ1wiPk5vIHN1c3BlbmRlZCBjdXN0b21lcnMgZm91bmQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJlZERhdGF9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvd0tleT1cIl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNjcm9sbD17eyB4OiAxMjAwIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZ2luYXRpb249e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTdXNwZW5kZWRDdXN0b21lclJlcG9ydDsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvU3VzcGVuZGVkQ3VzdG9tZXJSZXBvcnQuanN4In0=