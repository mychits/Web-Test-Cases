import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ChitAskingMonthReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select, Button, Empty } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import filterOption from "/src/helpers/filterOption.js";
const ChitAskingMonthReport = () => {
  _s();
  const now = /* @__PURE__ */ new Date();
  const [customers, setCustomers] = useState([]);
  const [groups, setGroups] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState("");
  const [loading, setLoading] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState(
    // String(now.getMonth() + 1).padStart(2, "0")
    ""
  );
  const [selectedYear, setSelectedYear] = useState(
    // now.getFullYear().toString()
    ""
  );
  const months = [
    { label: "January", value: "01" },
    { label: "February", value: "02" },
    { label: "March", value: "03" },
    { label: "April", value: "04" },
    { label: "May", value: "05" },
    { label: "June", value: "06" },
    { label: "July", value: "07" },
    { label: "August", value: "08" },
    { label: "September", value: "09" },
    { label: "October", value: "10" },
    { label: "November", value: "11" },
    { label: "December", value: "12" }
  ];
  const years = [];
  for (let y = 2e3; y <= 2040; y++) {
    years.push({ label: y.toString(), value: y.toString() });
  }
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const res = await api.get("/group/get-group-admin");
        setGroups(
          res.data?.map((g) => ({
            label: g.group_name,
            value: g._id
          })) || []
        );
      } catch (error) {
        console.error("Error loading groups", error);
      }
    };
    fetchGroups();
  }, []);
  const fetchCustomers = async () => {
    try {
      setLoading(true);
      const finalMonth = !selectedYear && !selectedMonth ? "" : `${selectedYear}-${selectedMonth}`;
      const res = await api.get("/enroll/get-customers-by-chit-asking-month", {
        params: {
          chit_asking_month: finalMonth,
          group_id: selectedGroup || ""
        }
      });
      setCustomers(res.data?.data || []);
    } catch (error) {
      console.error("Error loading customers", error);
    } finally {
      setLoading(false);
    }
  };
  const formattedData = customers?.filter((item) => item?.chit_asking_month != null && item?.chit_asking_month !== "").map((item, index) => ({
    sl_no: index + 1,
    customer_name: item?.user_id?.full_name,
    customer_id: item?.user_id?.customer_id,
    phone: item?.user_id?.phone_number,
    group: item?.group_id?.group_name,
    ticket: item?.tickets,
    groupValue: item?.group_id?.group_value,
    payment_type: item?.payment_type,
    chit_asking_month: item?.chit_asking_month,
    referred_by: item?.agent?.name && item?.agent?.phone_number ? `${item.agent.name} | ${item.agent.phone_number}` : item?.referred_customer?.full_name && item?.referred_customer?.phone_number ? `${item.referred_customer.full_name} | ${item.referred_customer.phone_number}` : item?.referred_lead?.lead_name && item?.referred_lead?.agent_number ? `${item.referred_lead.lead_name} | ${item.referred_lead.agent_number}` : item?.employee?.name && item?.employee?.phone_number ? `${item.employee.name} | ${item.employee.phone_number}` : "N/A"
  }));
  const totalCustomers = formattedData.length;
  const referredByCount = {};
  formattedData.forEach((item) => {
    const key = item.referred_by || "N/A";
    referredByCount[key] = (referredByCount[key] || 0) + 1;
  });
  const groupWiseCount = {};
  formattedData.forEach((item) => {
    const groupName = item.group || "N/A";
    groupWiseCount[groupName] = (groupWiseCount[groupName] || 0) + 1;
  });
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-8", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-gray-800", children: [
      "Reports — ",
      /* @__PURE__ */ jsxDEV("span", { className: "text-violet-600", children: "Chit Asking Month" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
        lineNumber: 150,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
      lineNumber: 149,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
      lineNumber: 148,
      columnNumber: 11
    }, this),
    formattedData.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold mb-4 text-gray-800", children: "Report Summary" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
        lineNumber: 157,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-violet-500 to-violet-600 text-white p-6 rounded-xl shadow-lg mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-violet-100 text-sm uppercase tracking-wide", children: "Total Customers" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
            lineNumber: 163,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold mt-1", children: totalCustomers }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
            lineNumber: 166,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
          lineNumber: 162,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white bg-opacity-20 p-3 rounded-full", children: /* @__PURE__ */ jsxDEV(
          "svg",
          {
            xmlns: "http://www.w3.org/2000/svg",
            className: "h-8 w-8",
            fill: "none",
            viewBox: "0 0 24 24",
            stroke: "currentColor",
            children: /* @__PURE__ */ jsxDEV(
              "path",
              {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
                lineNumber: 176,
                columnNumber: 23
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
            lineNumber: 169,
            columnNumber: 21
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
          lineNumber: 168,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
        lineNumber: 161,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
        lineNumber: 160,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-lg border border-gray-100", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800", children: "Referral Sources" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
              lineNumber: 192,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "bg-violet-100 text-violet-800 text-xs font-medium px-2.5 py-0.5 rounded", children: [
              Object.keys(referredByCount).length,
              " Sources"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
              lineNumber: 195,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
            lineNumber: 191,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
            Object.entries(referredByCount).sort((a, b) => b[1] - a[1]).slice(0, 5).map(
              ([name, count]) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-2 h-2 bg-violet-500 rounded-full mr-3" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
                    lineNumber: 206,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 text-sm truncate max-w-xs", children: name }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
                    lineNumber: 207,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
                  lineNumber: 205,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-24 bg-gray-200 rounded-full h-2 mr-3", children: /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "bg-violet-500 h-2 rounded-full",
                      style: { width: `${count / totalCustomers * 100}%` }
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
                      lineNumber: 213,
                      columnNumber: 31
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
                    lineNumber: 212,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 w-8 text-right", children: count }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
                    lineNumber: 218,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
                  lineNumber: 211,
                  columnNumber: 27
                }, this)
              ] }, name, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
                lineNumber: 204,
                columnNumber: 19
              }, this)
            ),
            Object.keys(referredByCount).length > 5 && /* @__PURE__ */ jsxDEV("div", { className: "text-center pt-2", children: /* @__PURE__ */ jsxDEV("button", { className: "text-violet-600 text-sm font-medium", children: "View All Sources" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
              lineNumber: 226,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
              lineNumber: 225,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
            lineNumber: 199,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
          lineNumber: 190,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-lg border border-gray-100", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800", children: "Group Distribution" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
              lineNumber: 237,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded", children: [
              Object.keys(groupWiseCount).length,
              " Groups"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
              lineNumber: 240,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
            lineNumber: 236,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
            Object.entries(groupWiseCount).sort((a, b) => b[1] - a[1]).slice(0, 5).map(
              ([group, count]) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-2 h-2 bg-green-500 rounded-full mr-3" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
                    lineNumber: 251,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 text-sm truncate max-w-xs", children: group }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
                    lineNumber: 252,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
                  lineNumber: 250,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-24 bg-gray-200 rounded-full h-2 mr-3", children: /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "bg-green-500 h-2 rounded-full",
                      style: { width: `${count / totalCustomers * 100}%` }
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
                      lineNumber: 258,
                      columnNumber: 31
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
                    lineNumber: 257,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 w-8 text-right", children: count }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
                    lineNumber: 263,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
                  lineNumber: 256,
                  columnNumber: 27
                }, this)
              ] }, group, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
                lineNumber: 249,
                columnNumber: 19
              }, this)
            ),
            Object.keys(groupWiseCount).length > 5 && /* @__PURE__ */ jsxDEV("div", { className: "text-center pt-2", children: /* @__PURE__ */ jsxDEV("button", { className: "text-green-600 text-sm font-medium", children: "View All Groups" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
              lineNumber: 271,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
              lineNumber: 270,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
            lineNumber: 244,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
          lineNumber: 235,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
        lineNumber: 188,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 mt-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-lg border border-gray-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "p-3 rounded-full bg-purple-100 text-purple-600 mr-4", children: /* @__PURE__ */ jsxDEV(
            "svg",
            {
              xmlns: "http://www.w3.org/2000/svg",
              className: "h-6 w-6",
              fill: "none",
              viewBox: "0 0 24 24",
              stroke: "currentColor",
              children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
                  lineNumber: 292,
                  columnNumber: 25
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
              lineNumber: 285,
              columnNumber: 23
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
            lineNumber: 284,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm", children: "Selected Period" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
              lineNumber: 301,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: selectedMonth && selectedYear ? `${months.find((m) => m.value === selectedMonth)?.label} ${selectedYear}` : "All Time" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
              lineNumber: 302,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
            lineNumber: 300,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
          lineNumber: 283,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
          lineNumber: 282,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-lg border border-gray-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "p-3 rounded-full bg-amber-100 text-amber-600 mr-4", children: /* @__PURE__ */ jsxDEV(
            "svg",
            {
              xmlns: "http://www.w3.org/2000/svg",
              className: "h-6 w-6",
              fill: "none",
              viewBox: "0 0 24 24",
              stroke: "currentColor",
              children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
                  lineNumber: 321,
                  columnNumber: 25
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
              lineNumber: 314,
              columnNumber: 23
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
            lineNumber: 313,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm", children: "Active Groups" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
              lineNumber: 330,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: Object.keys(groupWiseCount).length }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
              lineNumber: 331,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
            lineNumber: 329,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
          lineNumber: 312,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
          lineNumber: 311,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-lg border border-gray-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "p-3 rounded-full bg-red-100 text-red-600 mr-4", children: /* @__PURE__ */ jsxDEV(
            "svg",
            {
              xmlns: "http://www.w3.org/2000/svg",
              className: "h-6 w-6",
              fill: "none",
              viewBox: "0 0 24 24",
              stroke: "currentColor",
              children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
                  lineNumber: 348,
                  columnNumber: 25
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
              lineNumber: 341,
              columnNumber: 23
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
            lineNumber: 340,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm", children: "Avg. Customers/Group" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
              lineNumber: 357,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: Object.keys(groupWiseCount).length > 0 ? (totalCustomers / Object.keys(groupWiseCount).length).toFixed(1) : "0" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
              lineNumber: 358,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
            lineNumber: 356,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
          lineNumber: 339,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
          lineNumber: 338,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
        lineNumber: 281,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
      lineNumber: 156,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-lg border mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-6 items-end", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "mb-1 font-semibold text-gray-700", children: "Year Filter" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
          lineNumber: 375,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            style: { width: 150 },
            value: selectedYear || null,
            options: years,
            placeholder: "Select Year",
            onChange: setSelectedYear,
            className: "h-12"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
            lineNumber: 376,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
        lineNumber: 374,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "mb-1 font-semibold text-gray-700", children: "Month Filter" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
          lineNumber: 388,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            style: { width: 150 },
            value: selectedMonth || null,
            options: months,
            placeholder: "Select Month",
            onChange: setSelectedMonth,
            className: "h-12"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
            lineNumber: 389,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
        lineNumber: 387,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "mb-1 font-semibold text-gray-700", children: "Group Filter" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
          lineNumber: 401,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            style: { width: 200 },
            value: selectedGroup,
            options: [{ label: "All Groups", value: "" }, ...groups],
            onChange: (val) => setSelectedGroup(val),
            className: "h-12",
            placeholder: "Select Group"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
            lineNumber: 402,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
        lineNumber: 400,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "mb-1 opacity-0", children: "." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
          lineNumber: 414,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            type: "primary",
            onClick: fetchCustomers,
            loading,
            className: "h-12",
            children: "Continue"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
            lineNumber: 415,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
        lineNumber: 413,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
      lineNumber: 372,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
      lineNumber: 371,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-lg border", children: loading ? /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: loading }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
      lineNumber: 430,
      columnNumber: 13
    }, this) : formattedData.length > 0 ? /* @__PURE__ */ jsxDEV(
      DataTable,
      {
        catcher: "sl_no",
        data: formattedData,
        columns: [
          { key: "sl_no", header: "SL. NO" },
          { key: "customer_id", header: "Customer ID" },
          { key: "customer_name", header: "Customer Name" },
          { key: "phone", header: "Phone Number" },
          { key: "group", header: "Group Name" },
          { key: "ticket", header: "Ticket" },
          { key: "groupValue", header: "Group Value" },
          { key: "payment_type", header: "Payment Type" },
          { key: "chit_asking_month", header: "Chit Asking Month" },
          { key: "referred_by", header: "Referred By" }
        ],
        exportedFileName: "Chit Asking Month Report.csv",
        exportedPdfName: "Chit Asking Month Report"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
        lineNumber: 432,
        columnNumber: 13
      },
      this
    ) : /* @__PURE__ */ jsxDEV(Empty, { description: "No Chit Asking Month Data Found" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
      lineNumber: 451,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
      lineNumber: 428,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
    lineNumber: 146,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
    lineNumber: 145,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx",
    lineNumber: 144,
    columnNumber: 5
  }, this);
};
_s(ChitAskingMonthReport, "KHIMVw/B5uVZold6LsqryBgM17k=");
_c = ChitAskingMonthReport;
export default ChitAskingMonthReport;
var _c;
$RefreshReg$(_c, "ChitAskingMonthReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitAskingMonthReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUp3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFuSnhCLFNBQVNBLFdBQVdDLGdCQUFnQjtBQUNwQyxPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsdUJBQXVCO0FBQzlCLE9BQU9DLG9CQUFvQjtBQUMzQixTQUFTQyxRQUFRQyxRQUFRQyxhQUFhO0FBQ3RDLE9BQU9DLGtCQUFrQjtBQUt6QixNQUFNQyx3QkFBd0JBLE1BQU07QUFBQUMsS0FBQTtBQUNsQyxRQUFNQyxNQUFNLG9CQUFJQyxLQUFLO0FBRXJCLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJakIsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ2tCLFFBQVFDLFNBQVMsSUFBSW5CLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNvQixlQUFlQyxnQkFBZ0IsSUFBSXJCLFNBQVMsRUFBRTtBQUVyRCxRQUFNLENBQUNzQixTQUFTQyxVQUFVLElBQUl2QixTQUFTLEtBQUs7QUFFNUMsUUFBTSxDQUFDd0IsZUFBZUMsZ0JBQWdCLElBQUl6QjtBQUFBQTtBQUFBQSxJQUV4QztBQUFBLEVBQ0Y7QUFDQSxRQUFNLENBQUMwQixjQUFjQyxlQUFlLElBQUkzQjtBQUFBQTtBQUFBQSxJQUV0QztBQUFBLEVBQ0Y7QUFHQSxRQUFNNEIsU0FBUztBQUFBLElBQ2IsRUFBRUMsT0FBTyxXQUFXQyxPQUFPLEtBQUs7QUFBQSxJQUNoQyxFQUFFRCxPQUFPLFlBQVlDLE9BQU8sS0FBSztBQUFBLElBQ2pDLEVBQUVELE9BQU8sU0FBU0MsT0FBTyxLQUFLO0FBQUEsSUFDOUIsRUFBRUQsT0FBTyxTQUFTQyxPQUFPLEtBQUs7QUFBQSxJQUM5QixFQUFFRCxPQUFPLE9BQU9DLE9BQU8sS0FBSztBQUFBLElBQzVCLEVBQUVELE9BQU8sUUFBUUMsT0FBTyxLQUFLO0FBQUEsSUFDN0IsRUFBRUQsT0FBTyxRQUFRQyxPQUFPLEtBQUs7QUFBQSxJQUM3QixFQUFFRCxPQUFPLFVBQVVDLE9BQU8sS0FBSztBQUFBLElBQy9CLEVBQUVELE9BQU8sYUFBYUMsT0FBTyxLQUFLO0FBQUEsSUFDbEMsRUFBRUQsT0FBTyxXQUFXQyxPQUFPLEtBQUs7QUFBQSxJQUNoQyxFQUFFRCxPQUFPLFlBQVlDLE9BQU8sS0FBSztBQUFBLElBQ2pDLEVBQUVELE9BQU8sWUFBWUMsT0FBTyxLQUFLO0FBQUEsRUFBQztBQUlwQyxRQUFNQyxRQUFRO0FBQ2QsV0FBU0MsSUFBSSxLQUFNQSxLQUFLLE1BQU1BLEtBQUs7QUFDakNELFVBQU1FLEtBQUssRUFBRUosT0FBT0csRUFBRUUsU0FBUyxHQUFHSixPQUFPRSxFQUFFRSxTQUFTLEVBQUUsQ0FBQztBQUFBLEVBQ3pEO0FBR0FuQyxZQUFVLE1BQU07QUFDZCxVQUFNb0MsY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRixjQUFNQyxNQUFNLE1BQU0vQixJQUFJZ0MsSUFBSSx3QkFBd0I7QUFDbERsQjtBQUFBQSxVQUNFaUIsSUFBSUUsTUFBTUMsSUFBSSxDQUFDQyxPQUFPO0FBQUEsWUFDcEJYLE9BQU9XLEVBQUVDO0FBQUFBLFlBQ1RYLE9BQU9VLEVBQUVFO0FBQUFBLFVBQ1gsRUFBRSxLQUFLO0FBQUEsUUFDVDtBQUFBLE1BQ0YsU0FBU0MsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSx3QkFBd0JBLEtBQUs7QUFBQSxNQUM3QztBQUFBLElBQ0Y7QUFFQVIsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsRUFBRTtBQUdMLFFBQU1VLGlCQUFpQixZQUFZO0FBQ2pDLFFBQUk7QUFDRnRCLGlCQUFXLElBQUk7QUFFZixZQUFNdUIsYUFDSixDQUFDcEIsZ0JBQWdCLENBQUNGLGdCQUFnQixLQUFLLEdBQUdFLFlBQVksSUFBSUYsYUFBYTtBQUV6RSxZQUFNWSxNQUFNLE1BQU0vQixJQUFJZ0MsSUFBSSw4Q0FBOEM7QUFBQSxRQUN0RVUsUUFBUTtBQUFBLFVBQ05DLG1CQUFtQkY7QUFBQUEsVUFDbkJHLFVBQVU3QixpQkFBaUI7QUFBQSxRQUM3QjtBQUFBLE1BQ0YsQ0FBQztBQUlESCxtQkFBYW1CLElBQUlFLE1BQU1BLFFBQVEsRUFBRTtBQUFBLElBQ25DLFNBQVNLLE9BQU87QUFDZEMsY0FBUUQsTUFBTSwyQkFBMkJBLEtBQUs7QUFBQSxJQUNoRCxVQUFDO0FBQ0NwQixpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBR0EsUUFBTTJCLGdCQUFnQmxDLFdBQVdtQyxPQUFPLENBQUFDLFNBQVFBLE1BQU1KLHFCQUFxQixRQUFRSSxNQUFNSixzQkFBc0IsRUFBRSxFQUFFVCxJQUFJLENBQUNhLE1BQU1DLFdBQVc7QUFBQSxJQUN2SUMsT0FBT0QsUUFBUTtBQUFBLElBQ2ZFLGVBQWVILE1BQU1JLFNBQVNDO0FBQUFBLElBQzlCQyxhQUFhTixNQUFNSSxTQUFTRTtBQUFBQSxJQUM1QkMsT0FBT1AsTUFBTUksU0FBU0k7QUFBQUEsSUFDdEJDLE9BQU9ULE1BQU1ILFVBQVVSO0FBQUFBLElBQ3ZCcUIsUUFBUVYsTUFBTVc7QUFBQUEsSUFDZEMsWUFBWVosTUFBTUgsVUFBVWdCO0FBQUFBLElBQzVCQyxjQUFjZCxNQUFNYztBQUFBQSxJQUNwQmxCLG1CQUFtQkksTUFBTUo7QUFBQUEsSUFFekJtQixhQUNFZixNQUFNZ0IsT0FBT0MsUUFBUWpCLE1BQU1nQixPQUFPUixlQUM5QixHQUFHUixLQUFLZ0IsTUFBTUMsSUFBSSxNQUFNakIsS0FBS2dCLE1BQU1SLFlBQVksS0FDL0NSLE1BQU1rQixtQkFBbUJiLGFBQ3pCTCxNQUFNa0IsbUJBQW1CVixlQUN6QixHQUFHUixLQUFLa0Isa0JBQWtCYixTQUFTLE1BQU1MLEtBQUtrQixrQkFBa0JWLFlBQVksS0FDNUVSLE1BQU1tQixlQUFlQyxhQUFhcEIsTUFBTW1CLGVBQWVFLGVBQ3ZELEdBQUdyQixLQUFLbUIsY0FBY0MsU0FBUyxNQUFNcEIsS0FBS21CLGNBQWNFLFlBQVksS0FDcEVyQixNQUFNc0IsVUFBVUwsUUFBUWpCLE1BQU1zQixVQUFVZCxlQUN4QyxHQUFHUixLQUFLc0IsU0FBU0wsSUFBSSxNQUFNakIsS0FBS3NCLFNBQVNkLFlBQVksS0FDckQ7QUFBQSxFQUNSLEVBQUU7QUFHRixRQUFNZSxpQkFBaUJ6QixjQUFjMEI7QUFHckMsUUFBTUMsa0JBQWtCLENBQUM7QUFDekIzQixnQkFBYzRCLFFBQVEsQ0FBQzFCLFNBQVM7QUFDOUIsVUFBTTJCLE1BQU0zQixLQUFLZSxlQUFlO0FBQ2hDVSxvQkFBZ0JFLEdBQUcsS0FBS0YsZ0JBQWdCRSxHQUFHLEtBQUssS0FBSztBQUFBLEVBQ3ZELENBQUM7QUFHRCxRQUFNQyxpQkFBaUIsQ0FBQztBQUN4QjlCLGdCQUFjNEIsUUFBUSxDQUFDMUIsU0FBUztBQUM5QixVQUFNNkIsWUFBWTdCLEtBQUtTLFNBQVM7QUFDaENtQixtQkFBZUMsU0FBUyxLQUFLRCxlQUFlQyxTQUFTLEtBQUssS0FBSztBQUFBLEVBQ2pFLENBQUM7QUFFRCxTQUNHLHVCQUFDLFNBQUksV0FBVSxVQUNkLGlDQUFDLFNBQUksV0FBVSxVQUNiLGlDQUFDLFNBQUksV0FBVSxpQkFFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUNiLGlDQUFDLFFBQUcsV0FBVSxvQ0FBbUM7QUFBQTtBQUFBLE1BQ3JDLHVCQUFDLFVBQUssV0FBVSxtQkFBa0IsaUNBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUQ7QUFBQSxTQUQvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxJQUdDL0IsY0FBYzBCLFNBQVMsS0FDdEIsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsNENBQTJDLDhCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVFO0FBQUEsTUFHdkUsdUJBQUMsU0FBSSxXQUFVLDJGQUNiLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsbURBQWtELCtCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsMkJBQTJCRCw0QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUQ7QUFBQSxhQUp6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sV0FBVTtBQUFBLFlBQ1YsTUFBSztBQUFBLFlBQ0wsU0FBUTtBQUFBLFlBQ1IsUUFBTztBQUFBLFlBRVA7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxlQUFjO0FBQUEsZ0JBQ2QsZ0JBQWU7QUFBQSxnQkFDZixhQUFhO0FBQUEsZ0JBQ2IsR0FBRTtBQUFBO0FBQUEsY0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJNFE7QUFBQTtBQUFBLFVBWDlRO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWFBLEtBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsV0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVCQSxLQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUJBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUseUNBRWI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsdUNBQXNDLGdDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLFdBQVUsMkVBQ2JPO0FBQUFBLHFCQUFPQyxLQUFLTixlQUFlLEVBQUVEO0FBQUFBLGNBQU87QUFBQSxpQkFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ1pNO0FBQUFBLG1CQUFPRSxRQUFRUCxlQUFlLEVBQzVCUSxLQUFLLENBQUNDLEdBQUdDLE1BQU1BLEVBQUUsQ0FBQyxJQUFJRCxFQUFFLENBQUMsQ0FBQyxFQUMxQkUsTUFBTSxHQUFHLENBQUMsRUFDVmpEO0FBQUFBLGNBQUksQ0FBQyxDQUFDOEIsTUFBTW9CLEtBQUssTUFDaEIsdUJBQUMsU0FBZSxXQUFVLHFDQUN4QjtBQUFBLHVDQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSw2Q0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RDtBQUFBLGtCQUN6RCx1QkFBQyxVQUFLLFdBQVUsMkNBQ2JwQixrQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsT0FBTyxFQUFFcUIsT0FBTyxHQUFJRCxRQUFRZCxpQkFBa0IsR0FBRyxJQUFJO0FBQUE7QUFBQSxvQkFGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUdDLEtBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGtCQUNBLHVCQUFDLFVBQUssV0FBVSw4Q0FDYmMsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQSxtQkFqQlFwQixNQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa0JBO0FBQUEsWUFDRDtBQUFBLFlBQ0ZhLE9BQU9DLEtBQUtOLGVBQWUsRUFBRUQsU0FBUyxLQUNyQyx1QkFBQyxTQUFJLFdBQVUsb0JBQ2IsaUNBQUMsWUFBTyxXQUFVLHVDQUFzQyxnQ0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxlQTlCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdDQTtBQUFBLGFBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQ0E7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSw0REFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSx1Q0FBc0Msa0NBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSx5RUFDYk07QUFBQUEscUJBQU9DLEtBQUtILGNBQWMsRUFBRUo7QUFBQUEsY0FBTztBQUFBLGlCQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDWk07QUFBQUEsbUJBQU9FLFFBQVFKLGNBQWMsRUFDM0JLLEtBQUssQ0FBQ0MsR0FBR0MsTUFBTUEsRUFBRSxDQUFDLElBQUlELEVBQUUsQ0FBQyxDQUFDLEVBQzFCRSxNQUFNLEdBQUcsQ0FBQyxFQUNWakQ7QUFBQUEsY0FBSSxDQUFDLENBQUNzQixPQUFPNEIsS0FBSyxNQUNqQix1QkFBQyxTQUFnQixXQUFVLHFDQUN6QjtBQUFBLHVDQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSw0Q0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3RDtBQUFBLGtCQUN4RCx1QkFBQyxVQUFLLFdBQVUsMkNBQ2I1QixtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsT0FBTyxFQUFFNkIsT0FBTyxHQUFJRCxRQUFRZCxpQkFBa0IsR0FBRyxJQUFJO0FBQUE7QUFBQSxvQkFGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUdDLEtBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGtCQUNBLHVCQUFDLFVBQUssV0FBVSw4Q0FDYmMsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQSxtQkFqQlE1QixPQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa0JBO0FBQUEsWUFDRDtBQUFBLFlBQ0ZxQixPQUFPQyxLQUFLSCxjQUFjLEVBQUVKLFNBQVMsS0FDcEMsdUJBQUMsU0FBSSxXQUFVLG9CQUNiLGlDQUFDLFlBQU8sV0FBVSxzQ0FBcUMsK0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsZUE5Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQ0E7QUFBQSxhQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMENBO0FBQUEsV0F6RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBGQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDREQUNiLGlDQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSx1REFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sV0FBVTtBQUFBLGNBQ1YsTUFBSztBQUFBLGNBQ0wsU0FBUTtBQUFBLGNBQ1IsUUFBTztBQUFBLGNBRVA7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsZUFBYztBQUFBLGtCQUNkLGdCQUFlO0FBQUEsa0JBQ2YsYUFBYTtBQUFBLGtCQUNiLEdBQUU7QUFBQTtBQUFBLGdCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUk0RjtBQUFBO0FBQUEsWUFYOUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBYUEsS0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsT0FBRSxXQUFVLHlCQUF3QiwrQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Q7QUFBQSxZQUNwRCx1QkFBQyxPQUFFLFdBQVUsK0JBQ1ZwRCwyQkFBaUJFLGVBQ2QsR0FBR0UsT0FBTytELEtBQUssQ0FBQ0MsTUFBTUEsRUFBRTlELFVBQVVOLGFBQWEsR0FBR0ssS0FBSyxJQUFJSCxZQUFZLEtBQ3ZFLGNBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5QkEsS0ExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDREQUNiLGlDQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxxREFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sV0FBVTtBQUFBLGNBQ1YsTUFBSztBQUFBLGNBQ0wsU0FBUTtBQUFBLGNBQ1IsUUFBTztBQUFBLGNBRVA7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsZUFBYztBQUFBLGtCQUNkLGdCQUFlO0FBQUEsa0JBQ2YsYUFBYTtBQUFBLGtCQUNiLEdBQUU7QUFBQTtBQUFBLGdCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUk0UTtBQUFBO0FBQUEsWUFYOVE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBYUEsS0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsT0FBRSxXQUFVLHlCQUF3Qiw2QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0Q7QUFBQSxZQUNsRCx1QkFBQyxPQUFFLFdBQVUsK0JBQ1Z3RCxpQkFBT0MsS0FBS0gsY0FBYyxFQUFFSixVQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVCQSxLQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUJBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsNERBQ2IsaUNBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlEQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixXQUFVO0FBQUEsY0FDVixNQUFLO0FBQUEsY0FDTCxTQUFRO0FBQUEsY0FDUixRQUFPO0FBQUEsY0FFUDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxlQUFjO0FBQUEsa0JBQ2QsZ0JBQWU7QUFBQSxrQkFDZixhQUFhO0FBQUEsa0JBQ2IsR0FBRTtBQUFBO0FBQUEsZ0JBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSW9DO0FBQUE7QUFBQSxZQVh0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxPQUFFLFdBQVUseUJBQXdCLG9DQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RDtBQUFBLFlBQ3pELHVCQUFDLE9BQUUsV0FBVSwrQkFDVk0saUJBQU9DLEtBQUtILGNBQWMsRUFBRUosU0FBUyxLQUNqQ0QsaUJBQWlCTyxPQUFPQyxLQUFLSCxjQUFjLEVBQUVKLFFBQVFpQixRQUFRLENBQUMsSUFDL0QsT0FITjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlCQSxLQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkJBO0FBQUEsV0FwRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFGQTtBQUFBLFNBbE5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtTkE7QUFBQSxJQUlGLHVCQUFDLFNBQUksV0FBVSxpREFDYixpQ0FBQyxTQUFJLFdBQVUsd0JBRWI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsb0NBQW1DLDJCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStEO0FBQUEsUUFDL0Q7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU8sRUFBRUgsT0FBTyxJQUFJO0FBQUEsWUFDcEIsT0FBT2hFLGdCQUFnQjtBQUFBLFlBQ3ZCLFNBQVNLO0FBQUFBLFlBQ1QsYUFBWTtBQUFBLFlBQ1osVUFBVUo7QUFBQUEsWUFDVixXQUFVO0FBQUE7QUFBQSxVQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1rQjtBQUFBLFdBUnBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLG9DQUFtQyw0QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRTtBQUFBLFFBQ2hFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPLEVBQUUrRCxPQUFPLElBQUk7QUFBQSxZQUNwQixPQUFPbEUsaUJBQWlCO0FBQUEsWUFDeEIsU0FBU0k7QUFBQUEsWUFDVCxhQUFZO0FBQUEsWUFDWixVQUFVSDtBQUFBQSxZQUNWLFdBQVU7QUFBQTtBQUFBLFVBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTWtCO0FBQUEsV0FScEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsb0NBQW1DLDRCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdFO0FBQUEsUUFDaEU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU8sRUFBRWlFLE9BQU8sSUFBSTtBQUFBLFlBQ3BCLE9BQU90RTtBQUFBQSxZQUNQLFNBQVMsQ0FBQyxFQUFFUyxPQUFPLGNBQWNDLE9BQU8sR0FBRyxHQUFHLEdBQUdaLE1BQU07QUFBQSxZQUN2RCxVQUFVLENBQUM0RSxRQUFRekUsaUJBQWlCeUUsR0FBRztBQUFBLFlBQ3ZDLFdBQVU7QUFBQSxZQUNWLGFBQVk7QUFBQTtBQUFBLFVBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTTRCO0FBQUEsV0FSOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsa0JBQWlCLGlCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1DO0FBQUEsUUFDbkM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVNqRDtBQUFBQSxZQUNUO0FBQUEsWUFDQSxXQUFVO0FBQUEsWUFBTTtBQUFBO0FBQUEsVUFKbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0E7QUFBQSxXQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLFNBbkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvREEsS0FyREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNEQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLDRDQUNadkIsb0JBQ0MsdUJBQUMsa0JBQWUsV0FBV0EsV0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtQyxJQUNqQzRCLGNBQWMwQixTQUFTLElBQ3pCO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFRO0FBQUEsUUFDUixNQUFNMUI7QUFBQUEsUUFDTixTQUFTO0FBQUEsVUFDUCxFQUFFNkIsS0FBSyxTQUFTZ0IsUUFBUSxTQUFTO0FBQUEsVUFDakMsRUFBRWhCLEtBQUssZUFBZWdCLFFBQVEsY0FBYztBQUFBLFVBQzVDLEVBQUVoQixLQUFLLGlCQUFpQmdCLFFBQVEsZ0JBQWdCO0FBQUEsVUFDaEQsRUFBRWhCLEtBQUssU0FBU2dCLFFBQVEsZUFBZTtBQUFBLFVBQ3ZDLEVBQUVoQixLQUFLLFNBQVNnQixRQUFRLGFBQWE7QUFBQSxVQUNyQyxFQUFDaEIsS0FBSyxVQUFVZ0IsUUFBUSxTQUFRO0FBQUEsVUFDaEMsRUFBRWhCLEtBQUssY0FBY2dCLFFBQVEsY0FBYztBQUFBLFVBQzNDLEVBQUVoQixLQUFLLGdCQUFnQmdCLFFBQVEsZUFBZTtBQUFBLFVBQzlDLEVBQUVoQixLQUFLLHFCQUFxQmdCLFFBQVEsb0JBQW9CO0FBQUEsVUFDeEQsRUFBRWhCLEtBQUssZUFBZWdCLFFBQVEsY0FBYztBQUFBLFFBQUM7QUFBQSxRQUUvQyxrQkFBaUI7QUFBQSxRQUNqQixpQkFBZ0I7QUFBQTtBQUFBLE1BaEJsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFnQjRDLElBRzVDLHVCQUFDLFNBQU0sYUFBWSxxQ0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRCxLQXZCeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLE9BblRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvVEEsS0FyVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNUQSxLQXZURDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd1REO0FBRUo7QUFBRWxGLEdBemJJRCx1QkFBcUI7QUFBQW9GLEtBQXJCcEY7QUE2Yk4sZUFBZUE7QUFBc0IsSUFBQW9GO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJOYXZiYXIiLCJEYXRhVGFibGUiLCJNb2RhbCIsImFwaSIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwiQ2lyY3VsYXJMb2FkZXIiLCJTZWxlY3QiLCJCdXR0b24iLCJFbXB0eSIsImZpbHRlck9wdGlvbiIsIkNoaXRBc2tpbmdNb250aFJlcG9ydCIsIl9zIiwibm93IiwiRGF0ZSIsImN1c3RvbWVycyIsInNldEN1c3RvbWVycyIsImdyb3VwcyIsInNldEdyb3VwcyIsInNlbGVjdGVkR3JvdXAiLCJzZXRTZWxlY3RlZEdyb3VwIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzZWxlY3RlZE1vbnRoIiwic2V0U2VsZWN0ZWRNb250aCIsInNlbGVjdGVkWWVhciIsInNldFNlbGVjdGVkWWVhciIsIm1vbnRocyIsImxhYmVsIiwidmFsdWUiLCJ5ZWFycyIsInkiLCJwdXNoIiwidG9TdHJpbmciLCJmZXRjaEdyb3VwcyIsInJlcyIsImdldCIsImRhdGEiLCJtYXAiLCJnIiwiZ3JvdXBfbmFtZSIsIl9pZCIsImVycm9yIiwiY29uc29sZSIsImZldGNoQ3VzdG9tZXJzIiwiZmluYWxNb250aCIsInBhcmFtcyIsImNoaXRfYXNraW5nX21vbnRoIiwiZ3JvdXBfaWQiLCJmb3JtYXR0ZWREYXRhIiwiZmlsdGVyIiwiaXRlbSIsImluZGV4Iiwic2xfbm8iLCJjdXN0b21lcl9uYW1lIiwidXNlcl9pZCIsImZ1bGxfbmFtZSIsImN1c3RvbWVyX2lkIiwicGhvbmUiLCJwaG9uZV9udW1iZXIiLCJncm91cCIsInRpY2tldCIsInRpY2tldHMiLCJncm91cFZhbHVlIiwiZ3JvdXBfdmFsdWUiLCJwYXltZW50X3R5cGUiLCJyZWZlcnJlZF9ieSIsImFnZW50IiwibmFtZSIsInJlZmVycmVkX2N1c3RvbWVyIiwicmVmZXJyZWRfbGVhZCIsImxlYWRfbmFtZSIsImFnZW50X251bWJlciIsImVtcGxveWVlIiwidG90YWxDdXN0b21lcnMiLCJsZW5ndGgiLCJyZWZlcnJlZEJ5Q291bnQiLCJmb3JFYWNoIiwia2V5IiwiZ3JvdXBXaXNlQ291bnQiLCJncm91cE5hbWUiLCJPYmplY3QiLCJrZXlzIiwiZW50cmllcyIsInNvcnQiLCJhIiwiYiIsInNsaWNlIiwiY291bnQiLCJ3aWR0aCIsImZpbmQiLCJtIiwidG9GaXhlZCIsInZhbCIsImhlYWRlciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNoaXRBc2tpbmdNb250aFJlcG9ydC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiXHJcblxyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydERpYWxvZyBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2dcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjsgLy8g4pyFIHJlbW92ZWQgZHVwbGljYXRlIGltcG9ydFxyXG5pbXBvcnQgeyBTZWxlY3QsIEJ1dHRvbiwgRW1wdHkgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5cclxuXHJcblxyXG5cclxuY29uc3QgQ2hpdEFza2luZ01vbnRoUmVwb3J0ID0gKCkgPT4ge1xyXG4gIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCk7XHJcblxyXG4gIGNvbnN0IFtjdXN0b21lcnMsIHNldEN1c3RvbWVyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2dyb3Vwcywgc2V0R3JvdXBzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0ZWRHcm91cCwgc2V0U2VsZWN0ZWRHcm91cF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbc2VsZWN0ZWRNb250aCwgc2V0U2VsZWN0ZWRNb250aF0gPSB1c2VTdGF0ZShcclxuICAgIC8vIFN0cmluZyhub3cuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsIFwiMFwiKVxyXG4gICAgXCJcIlxyXG4gICk7XHJcbiAgY29uc3QgW3NlbGVjdGVkWWVhciwgc2V0U2VsZWN0ZWRZZWFyXSA9IHVzZVN0YXRlKFxyXG4gICAgLy8gbm93LmdldEZ1bGxZZWFyKCkudG9TdHJpbmcoKVxyXG4gICAgXCJcIlxyXG4gICk7XHJcblxyXG4gIC8vIE1vbnRoIGxpc3RcclxuICBjb25zdCBtb250aHMgPSBbXHJcbiAgICB7IGxhYmVsOiBcIkphbnVhcnlcIiwgdmFsdWU6IFwiMDFcIiB9LFxyXG4gICAgeyBsYWJlbDogXCJGZWJydWFyeVwiLCB2YWx1ZTogXCIwMlwiIH0sXHJcbiAgICB7IGxhYmVsOiBcIk1hcmNoXCIsIHZhbHVlOiBcIjAzXCIgfSxcclxuICAgIHsgbGFiZWw6IFwiQXByaWxcIiwgdmFsdWU6IFwiMDRcIiB9LFxyXG4gICAgeyBsYWJlbDogXCJNYXlcIiwgdmFsdWU6IFwiMDVcIiB9LFxyXG4gICAgeyBsYWJlbDogXCJKdW5lXCIsIHZhbHVlOiBcIjA2XCIgfSxcclxuICAgIHsgbGFiZWw6IFwiSnVseVwiLCB2YWx1ZTogXCIwN1wiIH0sXHJcbiAgICB7IGxhYmVsOiBcIkF1Z3VzdFwiLCB2YWx1ZTogXCIwOFwiIH0sXHJcbiAgICB7IGxhYmVsOiBcIlNlcHRlbWJlclwiLCB2YWx1ZTogXCIwOVwiIH0sXHJcbiAgICB7IGxhYmVsOiBcIk9jdG9iZXJcIiwgdmFsdWU6IFwiMTBcIiB9LFxyXG4gICAgeyBsYWJlbDogXCJOb3ZlbWJlclwiLCB2YWx1ZTogXCIxMVwiIH0sXHJcbiAgICB7IGxhYmVsOiBcIkRlY2VtYmVyXCIsIHZhbHVlOiBcIjEyXCIgfSxcclxuICBdO1xyXG5cclxuICAvLyBHZW5lcmF0ZSB5ZWFyc1xyXG4gIGNvbnN0IHllYXJzID0gW107XHJcbiAgZm9yIChsZXQgeSA9IDIwMDA7IHkgPD0gMjA0MDsgeSsrKSB7XHJcbiAgICB5ZWFycy5wdXNoKHsgbGFiZWw6IHkudG9TdHJpbmcoKSwgdmFsdWU6IHkudG9TdHJpbmcoKSB9KTtcclxuICB9XHJcblxyXG4gIC8vIOKtkCBGZXRjaCBHcm91cHNcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hHcm91cHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgICAgc2V0R3JvdXBzKFxyXG4gICAgICAgICAgcmVzLmRhdGE/Lm1hcCgoZykgPT4gKHtcclxuICAgICAgICAgICAgbGFiZWw6IGcuZ3JvdXBfbmFtZSxcclxuICAgICAgICAgICAgdmFsdWU6IGcuX2lkLFxyXG4gICAgICAgICAgfSkpIHx8IFtdXHJcbiAgICAgICAgKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgbG9hZGluZyBncm91cHNcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoR3JvdXBzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICAvLyDirZAgRmV0Y2ggQ3VzdG9tZXJzIEJhc2VkIG9uIEZpbHRlcnNcclxuICBjb25zdCBmZXRjaEN1c3RvbWVycyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgICBjb25zdCBmaW5hbE1vbnRoID1cclxuICAgICAgICAhc2VsZWN0ZWRZZWFyICYmICFzZWxlY3RlZE1vbnRoID8gXCJcIiA6IGAke3NlbGVjdGVkWWVhcn0tJHtzZWxlY3RlZE1vbnRofWA7XHJcblxyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2Vucm9sbC9nZXQtY3VzdG9tZXJzLWJ5LWNoaXQtYXNraW5nLW1vbnRoXCIsIHtcclxuICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgIGNoaXRfYXNraW5nX21vbnRoOiBmaW5hbE1vbnRoLFxyXG4gICAgICAgICAgZ3JvdXBfaWQ6IHNlbGVjdGVkR3JvdXAgfHwgXCJcIixcclxuICAgICAgICB9LFxyXG4gICAgICB9KTtcclxuXHJcblxyXG5cclxuICAgICAgc2V0Q3VzdG9tZXJzKHJlcy5kYXRhPy5kYXRhIHx8IFtdKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBsb2FkaW5nIGN1c3RvbWVyc1wiLCBlcnJvcik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyDirZAgRm9ybWF0IFRhYmxlIERhdGFcclxuICBjb25zdCBmb3JtYXR0ZWREYXRhID0gY3VzdG9tZXJzPy5maWx0ZXIoaXRlbSA9PiBpdGVtPy5jaGl0X2Fza2luZ19tb250aCAhPSBudWxsICYmIGl0ZW0/LmNoaXRfYXNraW5nX21vbnRoICE9PSBcIlwiKS5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoe1xyXG4gICAgc2xfbm86IGluZGV4ICsgMSxcclxuICAgIGN1c3RvbWVyX25hbWU6IGl0ZW0/LnVzZXJfaWQ/LmZ1bGxfbmFtZSxcclxuICAgIGN1c3RvbWVyX2lkOiBpdGVtPy51c2VyX2lkPy5jdXN0b21lcl9pZCxcclxuICAgIHBob25lOiBpdGVtPy51c2VyX2lkPy5waG9uZV9udW1iZXIsXHJcbiAgICBncm91cDogaXRlbT8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUsXHJcbiAgICB0aWNrZXQ6IGl0ZW0/LnRpY2tldHMsXHJcbiAgICBncm91cFZhbHVlOiBpdGVtPy5ncm91cF9pZD8uZ3JvdXBfdmFsdWUsXHJcbiAgICBwYXltZW50X3R5cGU6IGl0ZW0/LnBheW1lbnRfdHlwZSxcclxuICAgIGNoaXRfYXNraW5nX21vbnRoOiBpdGVtPy5jaGl0X2Fza2luZ19tb250aCxcclxuXHJcbiAgICByZWZlcnJlZF9ieTpcclxuICAgICAgaXRlbT8uYWdlbnQ/Lm5hbWUgJiYgaXRlbT8uYWdlbnQ/LnBob25lX251bWJlclxyXG4gICAgICAgID8gYCR7aXRlbS5hZ2VudC5uYW1lfSB8ICR7aXRlbS5hZ2VudC5waG9uZV9udW1iZXJ9YFxyXG4gICAgICAgIDogaXRlbT8ucmVmZXJyZWRfY3VzdG9tZXI/LmZ1bGxfbmFtZSAmJlxyXG4gICAgICAgICAgaXRlbT8ucmVmZXJyZWRfY3VzdG9tZXI/LnBob25lX251bWJlclxyXG4gICAgICAgID8gYCR7aXRlbS5yZWZlcnJlZF9jdXN0b21lci5mdWxsX25hbWV9IHwgJHtpdGVtLnJlZmVycmVkX2N1c3RvbWVyLnBob25lX251bWJlcn1gXHJcbiAgICAgICAgOiBpdGVtPy5yZWZlcnJlZF9sZWFkPy5sZWFkX25hbWUgJiYgaXRlbT8ucmVmZXJyZWRfbGVhZD8uYWdlbnRfbnVtYmVyXHJcbiAgICAgICAgPyBgJHtpdGVtLnJlZmVycmVkX2xlYWQubGVhZF9uYW1lfSB8ICR7aXRlbS5yZWZlcnJlZF9sZWFkLmFnZW50X251bWJlcn1gXHJcbiAgICAgICAgOiBpdGVtPy5lbXBsb3llZT8ubmFtZSAmJiBpdGVtPy5lbXBsb3llZT8ucGhvbmVfbnVtYmVyXHJcbiAgICAgICAgPyBgJHtpdGVtLmVtcGxveWVlLm5hbWV9IHwgJHtpdGVtLmVtcGxveWVlLnBob25lX251bWJlcn1gXHJcbiAgICAgICAgOiBcIk4vQVwiLFxyXG4gIH0pKTtcclxuXHJcbiAgLy8gU1VNTUFSWSBDQUxDVUxBVElPTlNcclxuICBjb25zdCB0b3RhbEN1c3RvbWVycyA9IGZvcm1hdHRlZERhdGEubGVuZ3RoO1xyXG5cclxuICAvLyBDb3VudCBieSBSZWZlcnJlZCBCeVxyXG4gIGNvbnN0IHJlZmVycmVkQnlDb3VudCA9IHt9O1xyXG4gIGZvcm1hdHRlZERhdGEuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgY29uc3Qga2V5ID0gaXRlbS5yZWZlcnJlZF9ieSB8fCBcIk4vQVwiO1xyXG4gICAgcmVmZXJyZWRCeUNvdW50W2tleV0gPSAocmVmZXJyZWRCeUNvdW50W2tleV0gfHwgMCkgKyAxO1xyXG4gIH0pO1xyXG5cclxuICAvLyBDb3VudCBieSBHcm91cFxyXG4gIGNvbnN0IGdyb3VwV2lzZUNvdW50ID0ge307XHJcbiAgZm9ybWF0dGVkRGF0YS5mb3JFYWNoKChpdGVtKSA9PiB7XHJcbiAgICBjb25zdCBncm91cE5hbWUgPSBpdGVtLmdyb3VwIHx8IFwiTi9BXCI7XHJcbiAgICBncm91cFdpc2VDb3VudFtncm91cE5hbWVdID0gKGdyb3VwV2lzZUNvdW50W2dyb3VwTmFtZV0gfHwgMCkgKyAxO1xyXG4gIH0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC04XCI+XHJcbiAgICAgICAgICB7LyogUEFHRSBUSVRMRSAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICBSZXBvcnRzIOKAlCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDBcIj5DaGl0IEFza2luZyBNb250aDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBJTVBST1ZFRCBTVU1NQVJZIENBUkQgKi99XHJcbiAgICAgICAgICB7Zm9ybWF0dGVkRGF0YS5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XHJcbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCBtYi00IHRleHQtZ3JheS04MDBcIj5SZXBvcnQgU3VtbWFyeTwvaDI+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBUT1RBTCBDVVNUT01FUlMgQ0FSRCAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS12aW9sZXQtNTAwIHRvLXZpb2xldC02MDAgdGV4dC13aGl0ZSBwLTYgcm91bmRlZC14bCBzaGFkb3ctbGcgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC0xMDAgdGV4dC1zbSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgVG90YWwgQ3VzdG9tZXJzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCBtdC0xXCI+e3RvdGFsQ3VzdG9tZXJzfTwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYmctb3BhY2l0eS0yMCBwLTMgcm91bmRlZC1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTggdy04XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNMTcgMjBoNXYtMmEzIDMgMCAwMC01LjM1Ni0xLjg1N00xNyAyMEg3bTEwIDB2LTJjMC0uNjU2LS4xMjYtMS4yODMtLjM1Ni0xLjg1N003IDIwSDJ2LTJhMyAzIDAgMDE1LjM1Ni0xLjg1N003IDIwdi0yYzAtLjY1Ni4xMjYtMS4yODMuMzU2LTEuODU3bTAgMGE1LjAwMiA1LjAwMiAwIDAxOS4yODggME0xNSA3YTMgMyAwIDExLTYgMCAzIDMgMCAwMTYgMHptNiAzYTIgMiAwIDExLTQgMCAyIDIgMCAwMTQgMHpNNyAxMGEyIDIgMCAxMS00IDAgMiAyIDAgMDE0IDB6XCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBTVU1NQVJZIEdSSUQgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0yIGdhcC02XCI+XHJcbiAgICAgICAgICAgICAgICB7LyogUkVGRVJSRUQgQlkgQ09VTlQgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNiByb3VuZGVkLXhsIHNoYWRvdy1sZyBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFJlZmVycmFsIFNvdXJjZXNcclxuICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJnLXZpb2xldC0xMDAgdGV4dC12aW9sZXQtODAwIHRleHQteHMgZm9udC1tZWRpdW0gcHgtMi41IHB5LTAuNSByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7T2JqZWN0LmtleXMocmVmZXJyZWRCeUNvdW50KS5sZW5ndGh9IFNvdXJjZXNcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtPYmplY3QuZW50cmllcyhyZWZlcnJlZEJ5Q291bnQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAuc29ydCgoYSwgYikgPT4gYlsxXSAtIGFbMV0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAuc2xpY2UoMCwgNSlcclxuICAgICAgICAgICAgICAgICAgICAgIC5tYXAoKFtuYW1lLCBjb3VudF0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e25hbWV9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0yIGgtMiBiZy12aW9sZXQtNTAwIHJvdW5kZWQtZnVsbCBtci0zXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNzAwIHRleHQtc20gdHJ1bmNhdGUgbWF4LXcteHNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTI0IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBoLTIgbXItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctdmlvbGV0LTUwMCBoLTIgcm91bmRlZC1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7KGNvdW50IC8gdG90YWxDdXN0b21lcnMpICogMTAwfSVgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIHctOCB0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICB7T2JqZWN0LmtleXMocmVmZXJyZWRCeUNvdW50KS5sZW5ndGggPiA1ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTYwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgVmlldyBBbGwgU291cmNlc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIEdST1VQIFdJU0UgQ09VTlQgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNiByb3VuZGVkLXhsIHNoYWRvdy1sZyBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEdyb3VwIERpc3RyaWJ1dGlvblxyXG4gICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwIHRleHQteHMgZm9udC1tZWRpdW0gcHgtMi41IHB5LTAuNSByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7T2JqZWN0LmtleXMoZ3JvdXBXaXNlQ291bnQpLmxlbmd0aH0gR3JvdXBzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICB7T2JqZWN0LmVudHJpZXMoZ3JvdXBXaXNlQ291bnQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAuc29ydCgoYSwgYikgPT4gYlsxXSAtIGFbMV0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAuc2xpY2UoMCwgNSlcclxuICAgICAgICAgICAgICAgICAgICAgIC5tYXAoKFtncm91cCwgY291bnRdKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtncm91cH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTIgaC0yIGJnLWdyZWVuLTUwMCByb3VuZGVkLWZ1bGwgbXItM1wiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMCB0ZXh0LXNtIHRydW5jYXRlIG1heC13LXhzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMjQgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIGgtMiBtci0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmVlbi01MDAgaC0yIHJvdW5kZWQtZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IGAkeyhjb3VudCAvIHRvdGFsQ3VzdG9tZXJzKSAqIDEwMH0lYCB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCB3LTggdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y291bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAge09iamVjdC5rZXlzKGdyb3VwV2lzZUNvdW50KS5sZW5ndGggPiA1ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwIHRleHQtc20gZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBWaWV3IEFsbCBHcm91cHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogQURESVRJT05BTCBNRVRSSUNTICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNiBtdC02XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNiByb3VuZGVkLXhsIHNoYWRvdy1sZyBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLWZ1bGwgYmctcHVycGxlLTEwMCB0ZXh0LXB1cnBsZS02MDAgbXItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC02IHctNlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkPVwiTTggN1YzbTggNFYzbS05IDhoMTBNNSAyMWgxNGEyIDIgMCAwMDItMlY3YTIgMiAwIDAwLTItMkg1YTIgMiAwIDAwLTIgMnYxMmEyIDIgMCAwMDIgMnpcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1zbVwiPlNlbGVjdGVkIFBlcmlvZDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRNb250aCAmJiBzZWxlY3RlZFllYXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IGAke21vbnRocy5maW5kKChtKSA9PiBtLnZhbHVlID09PSBzZWxlY3RlZE1vbnRoKT8ubGFiZWx9ICR7c2VsZWN0ZWRZZWFyfWBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiQWxsIFRpbWVcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNiByb3VuZGVkLXhsIHNoYWRvdy1sZyBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLWZ1bGwgYmctYW1iZXItMTAwIHRleHQtYW1iZXItNjAwIG1yLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtNiB3LTZcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZD1cIk0xNyAyMGg1di0yYTMgMyAwIDAwLTUuMzU2LTEuODU3TTE3IDIwSDdtMTAgMHYtMmMwLS42NTYtLjEyNi0xLjI4My0uMzU2LTEuODU3TTcgMjBIMnYtMmEzIDMgMCAwMTUuMzU2LTEuODU3TTcgMjB2LTJjMC0uNjU2LjEyNi0xLjI4My4zNTYtMS44NTdtMCAwYTUuMDAyIDUuMDAyIDAgMDE5LjI4OCAwTTE1IDdhMyAzIDAgMTEtNiAwIDMgMyAwIDAxNiAwem02IDNhMiAyIDAgMTEtNCAwIDIgMiAwIDAxNCAwek03IDEwYTIgMiAwIDExLTQgMCAyIDIgMCAwMTQgMHpcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1zbVwiPkFjdGl2ZSBHcm91cHM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge09iamVjdC5rZXlzKGdyb3VwV2lzZUNvdW50KS5sZW5ndGh9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTYgcm91bmRlZC14bCBzaGFkb3ctbGcgYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC1mdWxsIGJnLXJlZC0xMDAgdGV4dC1yZWQtNjAwIG1yLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtNiB3LTZcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZD1cIk0xMyA3aDhtMCAwdjhtMC04bC04IDgtNC00LTYgNlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LXNtXCI+QXZnLiBDdXN0b21lcnMvR3JvdXA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge09iamVjdC5rZXlzKGdyb3VwV2lzZUNvdW50KS5sZW5ndGggPiAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAodG90YWxDdXN0b21lcnMgLyBPYmplY3Qua2V5cyhncm91cFdpc2VDb3VudCkubGVuZ3RoKS50b0ZpeGVkKDEpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIjBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHsvKiBGSUxURVIgQ0FSRCAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC02IHJvdW5kZWQteGwgc2hhZG93LWxnIGJvcmRlciBtYi04XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNiBpdGVtcy1lbmRcIj5cclxuICAgICAgICAgICAgICB7LyogWUVBUiBGSUxURVIgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWItMSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5ZZWFyIEZpbHRlcjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAxNTAgfX1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkWWVhciB8fCBudWxsfVxyXG4gICAgICAgICAgICAgICAgICBvcHRpb25zPXt5ZWFyc31cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgWWVhclwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXRTZWxlY3RlZFllYXJ9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTJcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIE1PTlRIIEZJTFRFUiAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJtYi0xIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPk1vbnRoIEZpbHRlcjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAxNTAgfX1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkTW9udGggfHwgbnVsbH1cclxuICAgICAgICAgICAgICAgICAgb3B0aW9ucz17bW9udGhzfVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBNb250aFwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXRTZWxlY3RlZE1vbnRofVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTEyXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBHUk9VUCBGSUxURVIgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWItMSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5Hcm91cCBGaWx0ZXI8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogMjAwIH19XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEdyb3VwfVxyXG4gICAgICAgICAgICAgICAgICBvcHRpb25zPXtbeyBsYWJlbDogXCJBbGwgR3JvdXBzXCIsIHZhbHVlOiBcIlwiIH0sIC4uLmdyb3Vwc119XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiBzZXRTZWxlY3RlZEdyb3VwKHZhbCl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTJcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBHcm91cFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogQ29udGludWUgQnV0dG9uICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTEgb3BhY2l0eS0wXCI+LjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17ZmV0Y2hDdXN0b21lcnN9XHJcbiAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBDb250aW51ZVxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIFRBQkxFICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTYgcm91bmRlZC14bCBzaGFkb3ctbGcgYm9yZGVyXCI+XHJcbiAgICAgICAgICAgIHtsb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e2xvYWRpbmd9IC8+XHJcbiAgICAgICAgICAgICkgOiBmb3JtYXR0ZWREYXRhLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgY2F0Y2hlcj1cInNsX25vXCJcclxuICAgICAgICAgICAgICAgIGRhdGE9e2Zvcm1hdHRlZERhdGF9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtbXHJcbiAgICAgICAgICAgICAgICAgIHsga2V5OiBcInNsX25vXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgICAgICAgICAgICAgICB7IGtleTogXCJjdXN0b21lcl9pZFwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgSURcIiB9LFxyXG4gICAgICAgICAgICAgICAgICB7IGtleTogXCJjdXN0b21lcl9uYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgICAgICAgICAgICAgICAgeyBrZXk6IFwicGhvbmVcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICAgICAgICAgICAgICAgIHsga2V5OiBcImdyb3VwXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgICAgICAgICAgICAgICAge2tleTogXCJ0aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwifSxcclxuICAgICAgICAgICAgICAgICAgeyBrZXk6IFwiZ3JvdXBWYWx1ZVwiLCBoZWFkZXI6IFwiR3JvdXAgVmFsdWVcIiB9LFxyXG4gICAgICAgICAgICAgICAgICB7IGtleTogXCJwYXltZW50X3R5cGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgVHlwZVwiIH0sXHJcbiAgICAgICAgICAgICAgICAgIHsga2V5OiBcImNoaXRfYXNraW5nX21vbnRoXCIsIGhlYWRlcjogXCJDaGl0IEFza2luZyBNb250aFwiIH0sXHJcbiAgICAgICAgICAgICAgICAgIHsga2V5OiBcInJlZmVycmVkX2J5XCIsIGhlYWRlcjogXCJSZWZlcnJlZCBCeVwiIH0sXHJcbiAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIkNoaXQgQXNraW5nIE1vbnRoIFJlcG9ydC5jc3ZcIlxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiQ2hpdCBBc2tpbmcgTW9udGggUmVwb3J0XCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxFbXB0eSBkZXNjcmlwdGlvbj1cIk5vIENoaXQgQXNraW5nIE1vbnRoIERhdGEgRm91bmRcIiAvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2hpdEFza2luZ01vbnRoUmVwb3J0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvQ2hpdEFza2luZ01vbnRoUmVwb3J0LmpzeCJ9