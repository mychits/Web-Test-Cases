import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/SalaryPayment.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import {
  DatePicker,
  Drawer,
  Dropdown,
  Modal,
  Input,
  Form,
  Select,
  Button,
  message,
  Popconfirm,
  Empty
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import __vite__cjsImport7_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport7_react["useEffect"]; const useState = __vite__cjsImport7_react["useState"]; const useMemo = __vite__cjsImport7_react["useMemo"];
import API from "/src/instance/TokenInstance.js";
import __vite__cjsImport9_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport9_dayjs.__esModule ? __vite__cjsImport9_dayjs.default : __vite__cjsImport9_dayjs;
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { PlusOutlined, DeleteOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import { MdOutlineMan } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { RiMoneyRupeeCircleFill } from "/node_modules/.vite/deps/react-icons_ri.js?v=819e0a34";
import { Flex, Spin } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { LoadingOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import moment from "/node_modules/.vite/deps/moment.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
import { User } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
const SalaryPayment = () => {
  _s();
  const navigate = useNavigate();
  const [adjustmentAmount, setAdjustmentAmount] = useState(0);
  const [isOpenUpdateModal, setIsOpenUpdateModal] = useState(false);
  const [updateLoading, setUpdateLoading] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [employees, setEmployees] = useState([]);
  const [employeeDetails, setEmployeeDetails] = useState({});
  const [allSalaryPayments, setAllSalarypayments] = useState([]);
  const [employeeDetailsLoading, setEmployeeDetailsLoading] = useState(false);
  const [currentSalaryId, setCurrentSalaryId] = useState(null);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [form] = Form.useForm();
  const [updateForm] = Form.useForm();
  const [alreadyPaidModalOpen, setAlreadyPaidModalOpen] = useState(false);
  const [existingSalaryRecord, setExistingSalaryRecord] = useState(null);
  const [dataTableLoading, setDataTableLoading] = useState(false);
  const [updateFormData, setUpdateFormData] = useState({
    employee_id: "",
    month: "",
    year: "",
    earnings: {
      basic: 0,
      hra: 0,
      travel_allowance: 0,
      medical_allowance: 0,
      basket_of_benifits: 0,
      performance_bonus: 0,
      other_allowances: 0,
      conveyance: 0
    },
    deductions: {
      income_tax: 0,
      esi: 0,
      epf: 0,
      professional_tax: 0
    },
    additional_payments: [],
    additional_deductions: [],
    advance_payments: [],
    calculated_incentive: 0,
    payment_method: "Cash",
    transaction_id: "",
    is_salary_paid: true,
    monthly_business_info: {
      target: 0,
      total_business_closed: 0,
      previous_remaining_target: 0,
      current_remaining_target: 0
    }
  });
  const thisYear = dayjs().format("YYYY");
  const earningsObject = {
    basic: 0,
    hra: 0,
    travel_allowance: 0,
    medical_allowance: 0,
    basket_of_benifits: 0,
    performance_bonus: 0,
    other_allowances: 0,
    conveyance: 0
  };
  const deductionsObject = {
    income_tax: 0,
    esi: 0,
    epf: 0,
    professional_tax: 0
  };
  const columns = [
    { key: "siNo", header: "SL. NO" },
    { key: "employeeName", header: "Employee Name" },
    { key: "employeeCode", header: "Employee Id" },
    { key: "salaryMonth", header: "Salary Month" },
    { key: "salaryYear", header: "Year" },
    { key: "netPayable", header: "Net Payable" },
    { key: "action", header: "Action" }
  ];
  const months = [
    { label: "January", value: "January", disabled: false },
    { label: "February", value: "February", disabled: false },
    { label: "March", value: "March", disabled: false },
    { label: "April", value: "April", disabled: false },
    { label: "May", value: "May", disabled: false },
    { label: "June", value: "June", disabled: false },
    { label: "July", value: "July", disabled: false },
    { label: "August", value: "August", disabled: false },
    {
      label: "September",
      value: "September",
      disabled: false
    },
    { label: "October", value: "October", disabled: false },
    { label: "November", value: "November", disabled: false },
    { label: "December", value: "December", disabled: false }
  ];
  const previousMonth = months[dayjs().subtract(2, "month").format("MM")]?.label;
  const [formData, setFormData] = useState({
    employee_id: "",
    month: previousMonth,
    year: thisYear,
    earnings: {
      basic: 0,
      hra: 0,
      travel_allowance: 0,
      medical_allowance: 0,
      basket_of_benifits: 0,
      performance_bonus: 0,
      other_allowances: 0,
      conveyance: 0
    },
    deductions: {
      income_tax: 0,
      esi: 0,
      epf: 0,
      professional_tax: 0
    },
    additional_payments: [],
    additional_deductions: [],
    advance_payments: [],
    calculated_incentive: 0,
    total_salary_payable: 0,
    paid_amount: 0,
    payment_method: "Cash",
    transaction_id: "",
    target: 0,
    incentive: 0,
    status: "Paid"
  });
  async function fetchEmployees() {
    try {
      const responseData = await API.get("/employee");
      const filteredEmployee = responseData?.data?.employee?.map((emp) => ({
        value: emp?._id,
        label: `${emp?.name} | ${emp?.phone_number}` || "Unknown Employee"
      }));
      setEmployees(filteredEmployee || []);
    } catch (error) {
      setEmployees([]);
    }
  }
  useEffect(() => {
    fetchEmployees();
  }, []);
  async function getSalaryById(id) {
    try {
      const response = await API.get(`/salary-payment/${id}`);
      return response.data.data;
    } catch (error) {
      console.error("Error fetching salary by ID:", error);
      return null;
    }
  }
  const fetchEmployeeTarget = async (employeeId, start_date, end_date) => {
    try {
      const response = await API.get(`/target/employees/${employeeId}`, {
        params: { start_date, end_date }
      });
      return response.data?.total_target || 0;
    } catch (err) {
      console.error("Failed to fetch target:", err);
      return 0;
    }
  };
  const fetchEmployeeIncentive = async (employeeId, start_date, end_date) => {
    try {
      const response = await API.get(
        `/enroll/employee/${employeeId}/incentive`,
        { params: { start_date, end_date } }
      );
      return response.data?.incentiveSummary?.total_incentive_value || 0;
    } catch (err) {
      console.error("Failed to fetch incentive:", err);
      return 0;
    }
  };
  useEffect(() => {
    if (!isOpenUpdateModal) {
      setAdjustmentAmount(0);
    }
  }, [isOpenUpdateModal]);
  const getValidMonths = (joiningDateStr, selectedYear) => {
    if (!joiningDateStr || !selectedYear) {
      return months.map((m) => ({ ...m, disabled: true }));
    }
    const joining = dayjs(joiningDateStr);
    const today = dayjs();
    const joinYear = joining.year();
    const currentYear = today.year();
    const selectedYearNum = Number(selectedYear);
    return months.map((month, index) => {
      const isBeforeJoining = selectedYearNum === joinYear && index < joining.month();
      const isAfterToday = selectedYearNum === currentYear && index > today.month();
      const disabled = selectedYearNum < joinYear || selectedYearNum > currentYear || isBeforeJoining || isAfterToday;
      return { ...month, disabled };
    });
  };
  useEffect(() => {
    if (formData.employee_id && formData.year && employeeDetails?.joining_date) {
      const validMonths = getValidMonths(
        employeeDetails.joining_date,
        formData.year
      );
      const currentMonthValid = validMonths.some(
        (m) => m.value === formData.month && !m.disabled
      );
      if (!currentMonthValid) {
        const firstValid = validMonths.find((m) => !m.disabled);
        if (firstValid) {
          setFormData((prev) => ({
            ...prev,
            month: firstValid.value
          }));
        }
      }
    }
  }, [formData.year, formData.employee_id, employeeDetails?.joining_date]);
  const handleEdit = async (id) => {
    try {
      setUpdateLoading(true);
      setIsOpenUpdateModal(true);
      setAdjustmentAmount(0);
      const salaryData = await getSalaryById(id);
      if (salaryData) {
        setCurrentSalaryId(id);
        const yearAsDayjs = dayjs(salaryData.salary_year, "YYYY");
        const paidAmount = salaryData.paid_amount || salaryData.total_salary_payable || 0;
        const formData2 = {
          employee_id: salaryData?.employee_id?._id,
          month: salaryData?.salary_month,
          year: yearAsDayjs,
          earnings: salaryData?.earnings,
          deductions: salaryData?.deductions,
          additional_payments: salaryData?.additional_payments || [],
          additional_deductions: salaryData?.additional_deductions || [],
          advance_payments: salaryData?.advance_payments || [],
          calculated_incentive: salaryData?.calculated_incentive || 0,
          total_salary_payable: salaryData?.total_salary_payable || 0,
          paid_amount: paidAmount,
          // Use the defaulted value
          payment_method: salaryData?.payment_method || "Cash",
          transaction_id: salaryData?.transaction_id || "",
          pay_date: salaryData?.pay_date ? moment(salaryData?.pay_date) : moment(),
          attendance_details: salaryData?.attendance_details || {},
          monthly_business_info: salaryData?.monthly_business_info || {
            target: 0,
            total_business_closed: 0,
            previous_remaining_target: 0,
            current_remaining_target: 0
          },
          status: "Paid",
          is_salary_paid: true
        };
        setUpdateFormData(formData2);
        updateForm.setFieldsValue(formData2);
      }
    } catch (error) {
      message.error("Failed to fetch salary details");
    } finally {
      setUpdateLoading(false);
    }
  };
  const handleDeleteConfirm = async (id) => {
    try {
      setDeleteLoading(true);
      await API.delete(`/salary-payment/${id}`);
      message.success("Salary Payment deleted successfully");
      setDeleteModalOpen(false);
      getAllSalary();
    } catch (error) {
      message.error("Failed to delete Salary Payment");
    } finally {
      setDeleteLoading(false);
    }
  };
  const handleUpdateChange = (changedValues, allValues) => {
    if (changedValues.year && dayjs.isDayjs(changedValues.year)) {
      changedValues.year = changedValues.year.format("YYYY");
    }
    setUpdateFormData({
      ...updateFormData,
      ...changedValues,
      ...allValues
    });
  };
  const handleUpdateSubmit = async () => {
    try {
      setUpdateLoading(true);
      const formValues = updateForm.getFieldsValue();
      const totalPayable = Number(formValues.total_salary_payable || 0);
      const adjAmount = adjustmentAmount;
      const computedPaidAmount = totalPayable + adjAmount;
      const remaining_balance = totalPayable - computedPaidAmount;
      const updateData = {
        ...formValues,
        paid_amount: computedPaidAmount,
        remaining_balance,
        monthly_business_info: formValues.monthly_business_info || {
          target: 0,
          total_business_closed: 0,
          previous_remaining_target: 0,
          current_remaining_target: 0
        }
      };
      await API.put(`/salary-payment/${currentSalaryId}`, updateData);
      message.success("Salary updated successfully");
      setIsOpenUpdateModal(false);
      getAllSalary();
    } catch (error) {
      console.error("Error updating salary:", error);
      message.error("Failed to update salary");
    } finally {
      setUpdateLoading(false);
    }
  };
  const handlePrint = (salaryPaymentId) => {
    navigate("/salary-slip-print/" + salaryPaymentId);
  };
  const dropDownItems = (salaryPayment) => {
    const dropDownItemList = [
      {
        key: "1",
        label: /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "text-green-600",
            onClick: () => handlePrint(salaryPayment?._id),
            children: "Print"
          },
          salaryPayment?._id,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 373,
            columnNumber: 7
          },
          this
        )
      },
      {
        key: "2",
        label: /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "text-green-600",
            onClick: () => handleEdit(salaryPayment._id),
            children: "Pay Now"
          },
          salaryPayment?._id,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 384,
            columnNumber: 7
          },
          this
        )
      },
      {
        key: "3",
        label: /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "text-red-600",
            onClick: () => {
              setDeleteId(salaryPayment?._id);
              setDeleteModalOpen(true);
            },
            children: "Delete"
          },
          salaryPayment?._id,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 395,
            columnNumber: 7
          },
          this
        )
      }
    ];
    return dropDownItemList;
  };
  async function fetchSalaryDetails() {
    try {
      setEmployeeDetailsLoading(true);
      const responseData = await API.get(`/employee/${formData.employee_id}`);
      const emp = responseData?.data?.data;
      const updatedEarnings = {
        ...earningsObject,
        ...emp?.earnings,
        salary: emp?.salary || 0
      };
      const updatedDeductions = {
        ...deductionsObject,
        ...emp?.deductions
      };
      setEmployeeDetails(emp);
      setFormData((prev) => ({
        ...prev,
        earnings: updatedEarnings,
        deductions: updatedDeductions
      }));
    } catch (error) {
      setEmployeeDetails({});
    } finally {
      setEmployeeDetailsLoading(false);
    }
  }
  useEffect(() => {
    if (formData.employee_id && formData.month && formData.year) {
      loadTargetAndIncentive();
    }
  }, [formData.employee_id, formData.month, formData.year]);
  const loadTargetAndIncentive = async () => {
    try {
      const monthIndex = moment().month(formData.month).month();
      const year = formData.year;
      const start_date = moment().year(year).month(monthIndex).startOf("month").format("YYYY-MM-DD");
      const end_date = moment().year(year).month(monthIndex).endOf("month").format("YYYY-MM-DD");
      const targetValue = await fetchEmployeeTarget(
        formData.employee_id,
        start_date,
        end_date
      );
      const incentiveValue = await fetchEmployeeIncentive(
        formData.employee_id,
        start_date,
        end_date
      );
      setFormData((prev) => ({
        ...prev,
        target: targetValue,
        incentive: incentiveValue
      }));
    } catch (err) {
      console.error("Failed to auto-load target & incentive", err);
    }
  };
  useEffect(() => {
    if (formData.employee_id) {
      fetchSalaryDetails();
    }
  }, [formData?.employee_id, formData.month, formData.month]);
  const updateTotalEarnings = useMemo(() => {
    const earnings = updateFormData?.earnings || {};
    return Object.values(earnings).reduce((sum, v) => sum + Number(v || 0), 0);
  }, [updateFormData]);
  const updateTotalDeductions = useMemo(() => {
    const deductions = updateFormData?.deductions || {};
    const additional = updateFormData?.additional_deductions || [];
    const base = Object.values(deductions).reduce(
      (sum, v) => sum + Number(v || 0),
      0
    );
    const extra = additional.reduce((sum, d) => sum + Number(d.value || 0), 0);
    return base + extra;
  }, [updateFormData]);
  async function getAllSalary() {
    try {
      setDataTableLoading(true);
      const response = await API.get("/salary-payment/status/pending");
      const responseData = response?.data?.data || [];
      const filteredData = responseData.map((data, index) => ({
        siNo: index + 1,
        _id: data?._id,
        employeeName: data?.employee_id?.name,
        employeeCode: data?.employee_id?.employeeCode,
        salaryMonth: data?.salary_month,
        salaryYear: data?.salary_year,
        netPayable: data?.total_salary_payable,
        paidAmount: data?.paid_amount,
        action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
          Dropdown,
          {
            trigger: ["click"],
            menu: {
              items: dropDownItems(data)
            },
            placement: "bottomLeft",
            children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 515,
              columnNumber: 15
            }, this)
          },
          data?._id,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 508,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
          lineNumber: 507,
          columnNumber: 9
        }, this)
      }));
      setAllSalarypayments([...filteredData]);
    } catch (error) {
      setAllSalarypayments([]);
    } finally {
      setDataTableLoading(false);
    }
  }
  useEffect(() => {
    getAllSalary();
  }, []);
  const NAV_LINKS = [
    {
      to: "/staff-menu/employee-menu/employee-statement",
      icon: /* @__PURE__ */ jsxDEV(User, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
        lineNumber: 535,
        columnNumber: 11
      }, this),
      label: "Salary Ledger"
    },
    {
      to: "/staff-menu/employee-menu/salary-management",
      icon: /* @__PURE__ */ jsxDEV(MdOutlineMan, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
        lineNumber: 540,
        columnNumber: 11
      }, this),
      label: "Salary management"
    },
    {
      to: "/payment-menu/payment-in-out-menu/pay-in-menu/advance-payment-in",
      icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
        lineNumber: 545,
        columnNumber: 11
      }, this),
      label: "Advance repayment"
    },
    {
      to: "/payment-menu/payment-in-out-menu/pay-out-menu/salary-incentive",
      icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
        lineNumber: 550,
        columnNumber: 11
      }, this),
      label: "Salary incentive"
    },
    {
      to: "/payment-menu/payment-in-out-menu/pay-out-menu/additional-salary",
      icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
        lineNumber: 555,
        columnNumber: 11
      }, this),
      label: "Additional salary"
    }
  ];
  const totalPayableSum = useMemo(() => {
    return allSalaryPayments.reduce(
      (sum, item) => sum + (Number(item.netPayable) || 0),
      0
    );
  }, [allSalaryPayments]);
  return /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
      lineNumber: 570,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
      lineNumber: 571,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-3", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
        lineNumber: 573,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "mb-2", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-widest text-gray-400 mb-3", children: "Quick navigator" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
          lineNumber: 576,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: NAV_LINKS.map(
          (link) => /* @__PURE__ */ jsxDEV(
            Link,
            {
              to: link.to,
              className: "flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-600 hover:border-blue-400 hover:text-blue-600 hover:bg-blue-50 transition-all",
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-blue-500", children: link.icon }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 586,
                  columnNumber: 19
                }, this),
                link.label
              ]
            },
            link.to,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 581,
              columnNumber: 15
            },
            this
          )
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
          lineNumber: 579,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
        lineNumber: 575,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-1", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Salary Payment" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
          lineNumber: 594,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-100 border border-blue-300 rounded-xl px-5 py-2 shadow-sm flex items-center gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-blue-900 font-medium", children: "Pending Payments:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 602,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-blue-900 font-bold", children: allSalaryPayments.length }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 605,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 601,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "h-5 w-px bg-blue-300" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 611,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-blue-900 font-medium", children: "Total Payable:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 615,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-blue-900 font-bold", children: [
              "₹",
              totalPayableSum.toLocaleString("en-IN")
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 618,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 614,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
          lineNumber: 598,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
        lineNumber: 592,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-2 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-10" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
          lineNumber: 627,
          columnNumber: 13
        }, this),
        dataTableLoading ? /* @__PURE__ */ jsxDEV(
          Spin,
          {
            indicator: /* @__PURE__ */ jsxDEV(LoadingOutlined, { style: { fontSize: 48 }, spin: true }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 630,
              columnNumber: 26
            }, this),
            className: "w-full"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 629,
            columnNumber: 13
          },
          this
        ) : allSalaryPayments.length > 0 ? /* @__PURE__ */ jsxDEV(DataTable, { columns, data: allSalaryPayments, exportedFileName: "Salary Payments.csv", exportedPdfName: "Salary Payments" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
          lineNumber: 634,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV(Empty, { description: "No Salary Payment Data Found" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
          lineNumber: 636,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
        lineNumber: 626,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
      lineNumber: 572,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        title: "Update Salary Payment",
        width: "70%",
        className: "payment-drawer",
        open: isOpenUpdateModal,
        onClose: () => setIsOpenUpdateModal(false),
        closable: true,
        footer: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-2", children: [
          /* @__PURE__ */ jsxDEV(Button, { onClick: () => setIsOpenUpdateModal(false), children: "Cancel" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 649,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "primary",
              onClick: handleUpdateSubmit,
              loading: updateLoading,
              children: "Update Salary Payment"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 652,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
          lineNumber: 648,
          columnNumber: 11
        }, this),
        children: /* @__PURE__ */ jsxDEV(
          Form,
          {
            form: updateForm,
            layout: "vertical",
            initialValues: updateFormData,
            onValuesChange: handleUpdateChange,
            children: [
              /* @__PURE__ */ jsxDEV(
                Form.Item,
                {
                  name: "employee_id",
                  label: "Employee ID",
                  rules: [
                    { required: true, message: "Please select an employee" }
                  ],
                  children: /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      disabled: true,
                      showSearch: true,
                      optionFilterProp: "label",
                      filterOption: (input, option) => (option?.label ?? "").toLowerCase().includes(input.toLowerCase()),
                      filterSort: (optionA, optionB) => (optionA?.label ?? "").toLowerCase().localeCompare((optionB?.label ?? "").toLowerCase()),
                      placeholder: "Select Employee",
                      options: employees
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 671,
                      columnNumber: 15
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 665,
                  columnNumber: 13
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Form.Item,
                {
                  name: "month",
                  label: "Month",
                  rules: [{ required: true, message: "Please select a month" }],
                  children: /* @__PURE__ */ jsxDEV(Select, { disabled: true, placeholder: "Select Month", children: months.map(
                    (month) => /* @__PURE__ */ jsxDEV(Select.Option, { value: month.value, children: month.label }, month.value, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 695,
                      columnNumber: 17
                    }, this)
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 693,
                    columnNumber: 15
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 689,
                  columnNumber: 13
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Form.Item,
                {
                  name: "year",
                  label: "Year",
                  rules: [{ required: true, message: "Please select a year" }],
                  getValueFromEvent: (value) => value ? value.format("YYYY") : "",
                  children: /* @__PURE__ */ jsxDEV(DatePicker, { disabled: true, picker: "year", style: { width: "100%" } }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 708,
                    columnNumber: 15
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 701,
                  columnNumber: 13
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-green-50 p-4 rounded-lg mb-4", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-green-800 mb-4", children: "Earnings" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 711,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                  /* @__PURE__ */ jsxDEV(Form.Item, { name: ["earnings", "basic"], label: "Basic Salary", children: /* @__PURE__ */ jsxDEV(Input, { disabled: true, type: "number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 716,
                    columnNumber: 19
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 715,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(Form.Item, { name: ["earnings", "hra"], label: "HRA", children: /* @__PURE__ */ jsxDEV(Input, { disabled: true, type: "number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 719,
                    columnNumber: 19
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 718,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Form.Item,
                    {
                      name: ["earnings", "travel_allowance"],
                      label: "Travel Allowance",
                      children: /* @__PURE__ */ jsxDEV(Input, { disabled: true, type: "number" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                        lineNumber: 724,
                        columnNumber: 19
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 721,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Form.Item,
                    {
                      name: ["earnings", "medical_allowance"],
                      label: "Medical Allowance",
                      children: /* @__PURE__ */ jsxDEV(Input, { disabled: true, type: "number" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                        lineNumber: 729,
                        columnNumber: 19
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 726,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Form.Item,
                    {
                      name: ["earnings", "basket_of_benifits"],
                      label: "Basket of Benefits",
                      children: /* @__PURE__ */ jsxDEV(Input, { disabled: true, type: "number" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                        lineNumber: 734,
                        columnNumber: 19
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 731,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Form.Item,
                    {
                      name: ["earnings", "performance_bonus"],
                      label: "Performance Bonus",
                      children: /* @__PURE__ */ jsxDEV(Input, { disabled: true, type: "number" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                        lineNumber: 739,
                        columnNumber: 19
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 736,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Form.Item,
                    {
                      name: ["earnings", "other_allowances"],
                      label: "Other Allowances",
                      children: /* @__PURE__ */ jsxDEV(Input, { disabled: true, type: "number" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                        lineNumber: 744,
                        columnNumber: 19
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 741,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(Form.Item, { name: ["earnings", "conveyance"], label: "Conveyance", children: /* @__PURE__ */ jsxDEV(Input, { disabled: true, type: "number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 747,
                    columnNumber: 19
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 746,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 714,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-group mt-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Total Earnings" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 751,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      disabled: true,
                      value: updateTotalEarnings.toFixed(2),
                      className: "bg-gray-100"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 754,
                      columnNumber: 17
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 750,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 710,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-red-50 p-4 rounded-lg mb-4", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-red-800 mb-4", children: "Deductions" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 762,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                  /* @__PURE__ */ jsxDEV(
                    Form.Item,
                    {
                      name: ["deductions", "income_tax"],
                      label: "Income Tax",
                      children: /* @__PURE__ */ jsxDEV(Input, { disabled: true, type: "number" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                        lineNumber: 769,
                        columnNumber: 19
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 766,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(Form.Item, { name: ["deductions", "esi"], label: "ESI", children: /* @__PURE__ */ jsxDEV(Input, { disabled: true, type: "number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 772,
                    columnNumber: 19
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 771,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(Form.Item, { name: ["deductions", "epf"], label: "EPF", children: /* @__PURE__ */ jsxDEV(Input, { disabled: true, type: "number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 775,
                    columnNumber: 19
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 774,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Form.Item,
                    {
                      name: ["deductions", "professional_tax"],
                      label: "Professional Tax",
                      children: /* @__PURE__ */ jsxDEV(Input, { disabled: true, type: "number" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                        lineNumber: 780,
                        columnNumber: 19
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 777,
                      columnNumber: 17
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 765,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-group mt-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Total Deductions" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 784,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      disabled: true,
                      value: updateTotalDeductions.toFixed(2),
                      className: "bg-gray-100"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 787,
                      columnNumber: 17
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 783,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 761,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-50 p-4 rounded-lg mb-4", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-violet-800 mb-4", children: "Attendance Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 795,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4", children: [
                  /* @__PURE__ */ jsxDEV(
                    Form.Item,
                    {
                      label: "Total Days",
                      name: ["attendance_details", "total_days"],
                      children: /* @__PURE__ */ jsxDEV(Input, { type: "number", disabled: true }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                        lineNumber: 802,
                        columnNumber: 19
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 799,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Form.Item,
                    {
                      label: "Present Days",
                      name: ["attendance_details", "present_days"],
                      children: /* @__PURE__ */ jsxDEV(Input, { type: "number", disabled: true }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                        lineNumber: 807,
                        columnNumber: 19
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 804,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Form.Item,
                    {
                      label: "Paid Days",
                      name: ["attendance_details", "paid_days"],
                      children: /* @__PURE__ */ jsxDEV(Input, { type: "number", disabled: true }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                        lineNumber: 812,
                        columnNumber: 19
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 809,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Form.Item,
                    {
                      label: "LOP Days",
                      name: ["attendance_details", "lop_days"],
                      children: /* @__PURE__ */ jsxDEV(Input, { type: "number", disabled: true }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                        lineNumber: 817,
                        columnNumber: 19
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 814,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Form.Item,
                    {
                      label: "Per Day Salary",
                      name: ["attendance_details", "per_day_salary"],
                      children: /* @__PURE__ */ jsxDEV(Input, { type: "number", disabled: true }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                        lineNumber: 822,
                        columnNumber: 19
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 819,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Form.Item,
                    {
                      label: "Calculated Salary",
                      name: ["attendance_details", "calculated_salary"],
                      children: /* @__PURE__ */ jsxDEV(Input, { type: "number", disabled: true }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                        lineNumber: 827,
                        columnNumber: 19
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 824,
                      columnNumber: 17
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 798,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 p-4 rounded-lg mb-4", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-lg mb-3", children: "Monthly Target & Business Details" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 831,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                    /* @__PURE__ */ jsxDEV(
                      Form.Item,
                      {
                        label: "Total Target (₹)",
                        name: ["monthly_business_info", "target"],
                        children: /* @__PURE__ */ jsxDEV(Input, { type: "number", disabled: true }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                          lineNumber: 838,
                          columnNumber: 21
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                        lineNumber: 835,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Form.Item,
                      {
                        label: "Previous Remaining Target (₹)",
                        name: [
                          "monthly_business_info",
                          "previous_remaining_target"
                        ],
                        children: /* @__PURE__ */ jsxDEV(Input, { type: "number", disabled: true }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                          lineNumber: 846,
                          columnNumber: 21
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                        lineNumber: 840,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Form.Item,
                      {
                        label: "Total Business Closed (₹)",
                        name: ["monthly_business_info", "total_business_closed"],
                        children: /* @__PURE__ */ jsxDEV(Input, { type: "number", disabled: true }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                          lineNumber: 851,
                          columnNumber: 21
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                        lineNumber: 848,
                        columnNumber: 19
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Form.Item,
                      {
                        label: "Current Remaining Target (₹)",
                        name: ["monthly_business_info", "current_remaining_target"],
                        tooltip: "Target minus total business closed",
                        children: /* @__PURE__ */ jsxDEV(Input, { type: "number", disabled: true }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                          lineNumber: 857,
                          columnNumber: 21
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                        lineNumber: 853,
                        columnNumber: 19
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 834,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 830,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 794,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-50 p-4 rounded-lg mb-4", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-lg mb-3", children: "Incentive Adjustment" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 863,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Calculated Incentive" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 867,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV(Form.Item, { name: "calculated_incentive", children: /* @__PURE__ */ jsxDEV(Input, { type: "number", disabled: true }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 871,
                    columnNumber: 19
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 870,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 866,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 862,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-indigo-50 p-4 rounded-lg mb-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4", children: /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-indigo-800", children: "Advance Payments" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 877,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 876,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(Form.List, { name: "advance_payments", children: (fields, { add, remove }) => /* @__PURE__ */ jsxDEV(Fragment, { children: fields.map(
                  ({ key, name, ...restField }) => /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "grid grid-cols-1 md:grid-cols-2 gap-4 mb-4",
                      children: [
                        /* @__PURE__ */ jsxDEV(
                          Form.Item,
                          {
                            ...restField,
                            name: [name, "name"],
                            label: "Advance Name",
                            children: /* @__PURE__ */ jsxDEV(Input, { placeholder: "e.g., Festival Advance" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                              lineNumber: 892,
                              columnNumber: 27
                            }, this)
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                            lineNumber: 888,
                            columnNumber: 25
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV("div", { className: "flex items-end gap-2", children: [
                          /* @__PURE__ */ jsxDEV("div", { className: "flex-grow", children: /* @__PURE__ */ jsxDEV(
                            Form.Item,
                            {
                              ...restField,
                              onWheel: (e) => {
                                e.preventDefault();
                                e.currentTarget.blur();
                              },
                              name: [name, "value"],
                              label: "Amount",
                              children: /* @__PURE__ */ jsxDEV(Input, { type: "number", placeholder: "Enter amount" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                                lineNumber: 904,
                                columnNumber: 31
                              }, this)
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                              lineNumber: 896,
                              columnNumber: 29
                            },
                            this
                          ) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                            lineNumber: 895,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            Button,
                            {
                              type: "primary",
                              danger: true,
                              icon: /* @__PURE__ */ jsxDEV(DeleteOutlined, {}, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                                lineNumber: 910,
                                columnNumber: 31
                              }, this),
                              onClick: () => remove(name)
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                              lineNumber: 907,
                              columnNumber: 27
                            },
                            this
                          )
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                          lineNumber: 894,
                          columnNumber: 25
                        }, this)
                      ]
                    },
                    key,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 885,
                      columnNumber: 19
                    },
                    this
                  )
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 883,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 881,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 875,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-purple-50 p-4 rounded-lg mb-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4", children: /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-purple-800", children: "Additional Payments" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 922,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 921,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(Form.List, { name: "additional_payments", children: (fields, { add, remove }) => /* @__PURE__ */ jsxDEV(Fragment, { children: fields.map(
                  ({ key, name, ...restField }) => /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "grid grid-cols-1 md:grid-cols-2 gap-4 mb-4",
                      children: [
                        /* @__PURE__ */ jsxDEV(
                          Form.Item,
                          {
                            ...restField,
                            name: [name, "name"],
                            label: "Payment Name",
                            children: /* @__PURE__ */ jsxDEV(Input, { placeholder: "Enter payment name" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                              lineNumber: 937,
                              columnNumber: 27
                            }, this)
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                            lineNumber: 933,
                            columnNumber: 25
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV("div", { className: "flex items-end gap-2", children: [
                          /* @__PURE__ */ jsxDEV("div", { className: "flex-grow", children: /* @__PURE__ */ jsxDEV(
                            Form.Item,
                            {
                              ...restField,
                              onWheel: (e) => {
                                e.preventDefault();
                                e.currentTarget.blur();
                              },
                              name: [name, "value"],
                              label: "Amount",
                              children: /* @__PURE__ */ jsxDEV(Input, { type: "number", placeholder: "Enter amount" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                                lineNumber: 949,
                                columnNumber: 31
                              }, this)
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                              lineNumber: 941,
                              columnNumber: 29
                            },
                            this
                          ) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                            lineNumber: 940,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            Button,
                            {
                              type: "primary",
                              danger: true,
                              icon: /* @__PURE__ */ jsxDEV(DeleteOutlined, {}, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                                lineNumber: 955,
                                columnNumber: 31
                              }, this),
                              onClick: () => remove(name)
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                              lineNumber: 952,
                              columnNumber: 27
                            },
                            this
                          )
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                          lineNumber: 939,
                          columnNumber: 25
                        }, this)
                      ]
                    },
                    key,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 930,
                      columnNumber: 19
                    },
                    this
                  )
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 928,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 926,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 920,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-orange-50 p-4 rounded-lg mb-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4", children: /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-orange-800", children: "Additional Deductions" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 967,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 966,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(Form.List, { name: "additional_deductions", children: (fields, { remove }) => /* @__PURE__ */ jsxDEV(Fragment, { children: fields.map(
                  ({ key, name, ...restField }) => /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "grid grid-cols-1 md:grid-cols-2 gap-4 mb-4",
                      children: [
                        /* @__PURE__ */ jsxDEV(
                          Form.Item,
                          {
                            ...restField,
                            name: [name, "name"],
                            label: "Deduction Name",
                            children: /* @__PURE__ */ jsxDEV(Input, { placeholder: "Enter deduction name" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                              lineNumber: 982,
                              columnNumber: 27
                            }, this)
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                            lineNumber: 978,
                            columnNumber: 25
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV("div", { className: "flex items-end gap-2", children: [
                          /* @__PURE__ */ jsxDEV("div", { className: "flex-grow", children: /* @__PURE__ */ jsxDEV(
                            Form.Item,
                            {
                              ...restField,
                              name: [name, "value"],
                              label: "Amount",
                              children: /* @__PURE__ */ jsxDEV(
                                Input,
                                {
                                  type: "number",
                                  placeholder: "Enter amount",
                                  min: 0
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                                  lineNumber: 990,
                                  columnNumber: 31
                                },
                                this
                              )
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                              lineNumber: 986,
                              columnNumber: 29
                            },
                            this
                          ) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                            lineNumber: 985,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            Button,
                            {
                              type: "primary",
                              danger: true,
                              icon: /* @__PURE__ */ jsxDEV(DeleteOutlined, {}, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                                lineNumber: 1e3,
                                columnNumber: 31
                              }, this),
                              onClick: () => remove(name)
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                              lineNumber: 997,
                              columnNumber: 27
                            },
                            this
                          )
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                          lineNumber: 984,
                          columnNumber: 25
                        }, this)
                      ]
                    },
                    key,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 975,
                      columnNumber: 19
                    },
                    this
                  )
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 973,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 971,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 965,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-violet-50 to-violet-100 p-6 rounded-xl shadow-sm border border-violet-200 mb-6", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-violet-900 mb-6 pb-3 border-b border-violet-300", children: "Payment Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1011,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-5 rounded-lg shadow-sm", children: [
                    /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-semibold text-gray-700 mb-4 uppercase tracking-wide", children: "Salary Information" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 1018,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [
                      /* @__PURE__ */ jsxDEV(
                        Form.Item,
                        {
                          name: "total_salary_payable",
                          label: /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700", children: "Total Salary Payable" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                            lineNumber: 1025,
                            columnNumber: 23
                          }, this),
                          className: "mb-0",
                          children: /* @__PURE__ */ jsxDEV(
                            Input,
                            {
                              type: "number",
                              disabled: true,
                              className: "bg-gray-50 font-semibold",
                              prefix: "₹"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                              lineNumber: 1030,
                              columnNumber: 23
                            },
                            this
                          )
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                          lineNumber: 1022,
                          columnNumber: 21
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        Form.Item,
                        {
                          label: /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700", children: "Adjustment Amount" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                            lineNumber: 1039,
                            columnNumber: 23
                          }, this),
                          className: "mb-0",
                          children: [
                            /* @__PURE__ */ jsxDEV(
                              Input,
                              {
                                type: "number",
                                value: adjustmentAmount,
                                prefix: "₹",
                                className: "font-semibold",
                                onChange: (e) => {
                                  const value = e.target.value === "" ? 0 : Number(e.target.value);
                                  setAdjustmentAmount(value);
                                  const totalPayable = updateForm.getFieldValue("total_salary_payable") || 0;
                                  const newPayableAmount = Number(totalPayable) + value;
                                  updateForm.setFieldsValue({
                                    paid_amount: newPayableAmount
                                  });
                                },
                                placeholder: "Enter adjustment amount"
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                                lineNumber: 1044,
                                columnNumber: 23
                              },
                              this
                            ),
                            /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-amber-600 mt-2 flex items-start gap-1 bg-amber-50 p-2 rounded border border-amber-200", children: [
                              /* @__PURE__ */ jsxDEV("span", { className: "text-amber-600 font-bold", children: "ⓘ" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                                lineNumber: 1064,
                                columnNumber: 25
                              }, this),
                              /* @__PURE__ */ jsxDEV("span", { children: [
                                "This amount will be added to the payable amount",
                                " "
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                                lineNumber: 1065,
                                columnNumber: 25
                              }, this)
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                              lineNumber: 1063,
                              columnNumber: 23
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                          lineNumber: 1037,
                          columnNumber: 21
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        Form.Item,
                        {
                          name: "paid_amount",
                          label: /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700", children: "Payable Amount" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                            lineNumber: 1073,
                            columnNumber: 23
                          }, this),
                          rules: [
                            {
                              required: true,
                              message: "Please enter payable amount"
                            }
                          ],
                          className: "mb-0",
                          children: /* @__PURE__ */ jsxDEV(
                            Input,
                            {
                              type: "number",
                              prefix: "₹",
                              className: "font-semibold",
                              onChange: (e) => {
                                const totalPayable = updateForm.getFieldValue("total_salary_payable") || 0;
                                const newPaidAmount = Number(e.target.value || 0);
                                const newAdjustment = newPaidAmount - totalPayable;
                                setAdjustmentAmount(newAdjustment);
                              }
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                              lineNumber: 1084,
                              columnNumber: 23
                            },
                            this
                          )
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                          lineNumber: 1070,
                          columnNumber: 21
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 1021,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 1017,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-5 rounded-lg shadow-sm", children: [
                    /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-semibold text-gray-700 mb-4 uppercase tracking-wide", children: "Transaction Details" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 1103,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
                      /* @__PURE__ */ jsxDEV(
                        Form.Item,
                        {
                          name: "payment_method",
                          label: /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700", children: "Payment Mode" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                            lineNumber: 1110,
                            columnNumber: 23
                          }, this),
                          rules: [
                            {
                              required: true,
                              message: "Please select payment mode"
                            }
                          ],
                          className: "mb-0",
                          children: /* @__PURE__ */ jsxDEV(
                            Select,
                            {
                              placeholder: "Select payment mode",
                              size: "large",
                              options: [
                                { label: "Cash", value: "Cash" },
                                { label: "Online / UPI", value: "Online/UPI" },
                                { label: "Online / NEFT", value: "Online/NEFT" },
                                { label: "Online / IMPS", value: "Online/IMPS" },
                                { label: "Online / RTGS", value: "Online/RTGS" },
                                { label: "Bank Transfer", value: "Bank Transfer" },
                                { label: "Cheque", value: "Cheque" },
                                { label: "Direct Deposit", value: "Direct Deposit" }
                              ]
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                              lineNumber: 1121,
                              columnNumber: 23
                            },
                            this
                          )
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                          lineNumber: 1107,
                          columnNumber: 21
                        },
                        this
                      ),
                      updateForm.getFieldValue("payment_method") !== "Cash" && /* @__PURE__ */ jsxDEV(
                        Form.Item,
                        {
                          name: "transaction_id",
                          label: /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700", children: "Transaction ID" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                            lineNumber: 1141,
                            columnNumber: 23
                          }, this),
                          rules: [
                            {
                              required: updateForm.getFieldValue("payment_method") !== "Cash",
                              message: "Transaction ID is required"
                            }
                          ],
                          className: "mb-0",
                          children: /* @__PURE__ */ jsxDEV(
                            Input,
                            {
                              placeholder: "Enter transaction reference",
                              size: "large",
                              className: "font-mono"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                              lineNumber: 1154,
                              columnNumber: 25
                            },
                            this
                          )
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                          lineNumber: 1138,
                          columnNumber: 21
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        Form.Item,
                        {
                          name: "pay_date",
                          label: /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700", children: "Pay Date" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                            lineNumber: 1165,
                            columnNumber: 23
                          }, this),
                          rules: [
                            { required: true, message: "Please select pay date" }
                          ],
                          getValueProps: (value) => ({
                            value: value ? dayjs(value) : null
                          }),
                          getValueFromEvent: (date) => date ? date.toDate() : null,
                          className: "mb-0",
                          children: /* @__PURE__ */ jsxDEV(
                            DatePicker,
                            {
                              style: { width: "100%" },
                              size: "large",
                              format: "DD MMM YYYY",
                              disabledDate: (current) => current && current.isAfter(dayjs().endOf("day"))
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                              lineNumber: 1179,
                              columnNumber: 23
                            },
                            this
                          )
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                          lineNumber: 1162,
                          columnNumber: 21
                        },
                        this
                      )
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 1106,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 1102,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1015,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1010,
                columnNumber: 13
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 660,
            columnNumber: 11
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
        lineNumber: 640,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: "Delete Salary",
        open: deleteModalOpen,
        onCancel: () => setDeleteModalOpen(false),
        footer: [
          /* @__PURE__ */ jsxDEV(Button, { onClick: () => setDeleteModalOpen(false), children: "Cancel" }, "cancel", false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 1199,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "primary",
              danger: true,
              loading: deleteLoading,
              onClick: () => handleDeleteConfirm(deleteId),
              children: "Delete"
            },
            "delete",
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1202,
              columnNumber: 11
            },
            this
          )
        ],
        children: /* @__PURE__ */ jsxDEV("p", { children: "Are you sure you want to delete this salary? This action cannot be undone." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
          lineNumber: 1211,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
        lineNumber: 1194,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: /* @__PURE__ */ jsxDEV("span", { className: "text-amber-800 text-lg font-semibold flex items-center", children: "Salary Already Processed" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
          lineNumber: 1219,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
          lineNumber: 1218,
          columnNumber: 11
        }, this),
        open: alreadyPaidModalOpen,
        onCancel: () => setAlreadyPaidModalOpen(false),
        width: 920,
        footer: [
          /* @__PURE__ */ jsxDEV(Button, { onClick: () => setAlreadyPaidModalOpen(false), children: "Close" }, "close", false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 1228,
            columnNumber: 11
          }, this),
          existingSalaryRecord?.status === "Pending" && /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "primary",
              style: {
                backgroundColor: "#D4AF37",
                borderColor: "#B8860B",
                color: "#000"
              },
              onClick: () => {
                handleEdit(existingSalaryRecord._id);
                setAlreadyPaidModalOpen(false);
              },
              children: "Edit Record"
            },
            "edit",
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1232,
              columnNumber: 11
            },
            this
          )
        ],
        style: {
          padding: "24px",
          maxHeight: "70vh",
          overflowY: "auto",
          backgroundColor: "#fafafa"
        },
        children: existingSalaryRecord ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 text-sm", children: [
          /* @__PURE__ */ jsxDEV("section", { className: "bg-white p-5 rounded-lg shadow-sm border border-gray-200", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-gray-900 mb-3 flex items-center text-base", children: "Salary Period" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1257,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-3 text-gray-700", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("strong", { children: "Month:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1262,
                  columnNumber: 21
                }, this),
                " ",
                existingSalaryRecord.salary_month,
                " ",
                existingSalaryRecord.salary_year
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1261,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("strong", { children: "From:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1266,
                  columnNumber: 21
                }, this),
                " ",
                moment(existingSalaryRecord.salary_from_date).format(
                  "DD MMM YYYY"
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1265,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("strong", { children: "To:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1272,
                  columnNumber: 21
                }, this),
                " ",
                moment(existingSalaryRecord.salary_to_date).subtract(1, "day").format("DD MMM YYYY")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1271,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1260,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 1256,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("section", { className: "bg-white p-5 rounded-lg shadow-sm border border-gray-200", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-gray-900 mb-3 flex items-center text-base", children: "Attendance Summary" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1281,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-4 gap-3 text-gray-700", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("strong", { children: "Total Days:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1286,
                  columnNumber: 21
                }, this),
                " ",
                existingSalaryRecord.total_days || 0
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1285,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("strong", { children: "Paid Days:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1290,
                  columnNumber: 21
                }, this),
                " ",
                existingSalaryRecord.paid_days || 0
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1289,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("strong", { children: "LOP Days:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1294,
                  columnNumber: 21
                }, this),
                " ",
                existingSalaryRecord.lop_days || 0
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1293,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("strong", { children: "Present:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1298,
                  columnNumber: 21
                }, this),
                " ",
                existingSalaryRecord.present_days || 0
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1297,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("strong", { children: "Absent:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1302,
                  columnNumber: 21
                }, this),
                " ",
                existingSalaryRecord.absent_days || 0
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1301,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("strong", { children: "On Leave:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1306,
                  columnNumber: 21
                }, this),
                " ",
                existingSalaryRecord.leave_days || 0
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1305,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("strong", { children: "Half Days:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1310,
                  columnNumber: 21
                }, this),
                " ",
                existingSalaryRecord.half_days || 0
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1309,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1284,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 1280,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("section", { className: "bg-white p-5 rounded-lg shadow-sm border border-gray-200", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-gray-900 mb-3 flex items-center text-base", children: "Monthly Target & Business Details" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1317,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3 text-gray-700", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("strong", { children: "Total Target:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1322,
                  columnNumber: 21
                }, this),
                " ₹",
                Number(
                  existingSalaryRecord.monthly_business_info?.target || 0
                ).toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1321,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("strong", { children: "Previous Remaining Target:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1328,
                  columnNumber: 21
                }, this),
                " ₹",
                Number(
                  existingSalaryRecord.monthly_business_info?.previous_remaining_target || 0
                ).toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1327,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("strong", { children: "Total Business Closed:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1335,
                  columnNumber: 21
                }, this),
                " ₹",
                Number(
                  existingSalaryRecord.monthly_business_info?.total_business_closed || 0
                ).toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1334,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("strong", { children: "Current Remaining Target:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1342,
                  columnNumber: 21
                }, this),
                " ₹",
                Number(
                  existingSalaryRecord.monthly_business_info?.current_remaining_target || 0
                ).toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1341,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1320,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 1316,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("section", { className: "bg-white p-5 rounded-lg shadow-sm border border-gray-200", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-gray-900 mb-3 flex items-center text-base", children: "Earnings" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1352,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2 text-gray-700", children: Object.entries(existingSalaryRecord.earnings || {}).map(
              ([key, val]) => /* @__PURE__ */ jsxDEV(
                "li",
                {
                  className: "flex justify-between border-b border-gray-100 pb-1",
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "capitalize", children: key.replace(/_/g, " ") }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 1361,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: [
                      "₹",
                      Number(val).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 1364,
                      columnNumber: 25
                    }, this)
                  ]
                },
                key,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1358,
                  columnNumber: 19
                },
                this
              )
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1355,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 1351,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("section", { className: "bg-white p-5 rounded-lg shadow-sm border border-gray-200", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-gray-900 mb-3 flex items-center text-base", children: "Deductions" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1378,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2 text-gray-700", children: Object.entries(existingSalaryRecord.deductions || {}).map(
              ([key, val]) => /* @__PURE__ */ jsxDEV(
                "li",
                {
                  className: "flex justify-between border-b border-gray-100 pb-1",
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "capitalize", children: key.replace(/_/g, " ") }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 1387,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: [
                      "₹",
                      Number(val).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 1390,
                      columnNumber: 25
                    }, this)
                  ]
                },
                key,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1384,
                  columnNumber: 19
                },
                this
              )
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1381,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 1377,
            columnNumber: 15
          }, this),
          existingSalaryRecord.additional_payments?.length > 0 && /* @__PURE__ */ jsxDEV("section", { className: "bg-white p-5 rounded-lg shadow-sm border border-gray-200", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-gray-900 mb-3 flex items-center text-base", children: "Additional Payments" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1405,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2 text-gray-700", children: existingSalaryRecord.additional_payments.map(
              (pay, i) => /* @__PURE__ */ jsxDEV(
                "li",
                {
                  className: "flex justify-between border-b border-gray-100 pb-1",
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { children: pay.name || "Payment" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 1413,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: [
                      "₹",
                      Number(pay.value).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 1414,
                      columnNumber: 25
                    }, this)
                  ]
                },
                i,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1410,
                  columnNumber: 17
                },
                this
              )
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1408,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 1404,
            columnNumber: 13
          }, this),
          existingSalaryRecord.additional_deductions?.length > 0 && /* @__PURE__ */ jsxDEV("section", { className: "bg-white p-5 rounded-lg shadow-sm border border-gray-200", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-gray-900 mb-3 flex items-center text-base", children: "Additional Deductions" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1429,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2 text-gray-700", children: existingSalaryRecord.additional_deductions.map(
              (ded, i) => /* @__PURE__ */ jsxDEV(
                "li",
                {
                  className: "flex justify-between border-b border-gray-100 pb-1",
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { children: ded.name || "Deduction" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 1438,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-red-600", children: [
                      "₹",
                      Number(ded.value).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 1439,
                      columnNumber: 27
                    }, this)
                  ]
                },
                i,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1435,
                  columnNumber: 19
                },
                this
              )
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1432,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 1428,
            columnNumber: 13
          }, this),
          existingSalaryRecord.advance_payments?.length > 0 && /* @__PURE__ */ jsxDEV("section", { className: "bg-white p-5 rounded-lg shadow-sm border border-gray-200", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-gray-900 mb-3 flex items-center text-base", children: "Advance Payments" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1454,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2 text-gray-700", children: existingSalaryRecord.advance_payments.map(
              (pay, i) => /* @__PURE__ */ jsxDEV(
                "li",
                {
                  className: "flex justify-between border-b border-gray-100 pb-1",
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { children: pay.name || "Advance Payment" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 1462,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: [
                      "₹",
                      Number(pay.value).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                      lineNumber: 1463,
                      columnNumber: 25
                    }, this)
                  ]
                },
                i,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1459,
                  columnNumber: 17
                },
                this
              )
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1457,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 1453,
            columnNumber: 13
          }, this),
          existingSalaryRecord.calculated_incentive !== 0 && /* @__PURE__ */ jsxDEV("section", { className: "bg-white p-5 rounded-lg shadow-sm border border-gray-200", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-gray-900 mb-3 flex items-center text-base", children: "Incentive Adjustment" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1477,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center py-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 font-medium", children: "Calculated Incentive:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1481,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: `font-medium ${existingSalaryRecord.calculated_incentive > 0 ? "text-green-700" : "text-red-700"}`,
                  children: [
                    "₹",
                    Math.abs(
                      existingSalaryRecord.calculated_incentive
                    ).toLocaleString("en-IN", {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    }),
                    existingSalaryRecord.calculated_incentive > 0 ? " (Bonus)" : " (Deduction)"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1484,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1480,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 1476,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("section", { className: "bg-gradient-to-r from-amber-50 to-white border border-amber-200 p-5 rounded-lg shadow-sm", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-bold text-gray-900 mb-3 flex items-center text-base", children: "Payment Summary" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1504,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 text-gray-800 font-medium", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                /* @__PURE__ */ jsxDEV("span", { children: "Base Calculated Salary:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1509,
                  columnNumber: 21
                }, this),
                " ",
                /* @__PURE__ */ jsxDEV("span", { children: [
                  "₹",
                  Number(
                    existingSalaryRecord?.attendance_details?.calculated_salary
                  ).toLocaleString("en-IN", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  })
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1510,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1508,
                columnNumber: 19
              }, this),
              existingSalaryRecord.advance_payments?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                /* @__PURE__ */ jsxDEV("span", { children: "Advance Payments:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1523,
                  columnNumber: 23
                }, this),
                " ",
                /* @__PURE__ */ jsxDEV("span", { children: [
                  "₹",
                  Number(
                    existingSalaryRecord.advance_payments.reduce(
                      (sum, p) => sum + Number(p.value),
                      0
                    )
                  ).toLocaleString("en-IN", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  })
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1524,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1522,
                columnNumber: 17
              }, this),
              existingSalaryRecord.additional_payments?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                /* @__PURE__ */ jsxDEV("span", { children: "Additional Payments:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1540,
                  columnNumber: 23
                }, this),
                " ",
                /* @__PURE__ */ jsxDEV("span", { children: [
                  "₹",
                  Number(
                    existingSalaryRecord.additional_payments.reduce(
                      (sum, p) => sum + Number(p.value),
                      0
                    )
                  ).toLocaleString("en-IN", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  })
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1541,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1539,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                /* @__PURE__ */ jsxDEV("span", { children: "Total Base Deductions:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1556,
                  columnNumber: 21
                }, this),
                " ",
                /* @__PURE__ */ jsxDEV("span", { children: [
                  "₹",
                  Number(
                    existingSalaryRecord.total_deductions
                  ).toLocaleString("en-IN", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  })
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1557,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1555,
                columnNumber: 19
              }, this),
              existingSalaryRecord?.additional_deductions?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                /* @__PURE__ */ jsxDEV("span", { children: "Additional Deductions:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1569,
                  columnNumber: 23
                }, this),
                " ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-600", children: [
                  "₹",
                  Number(
                    existingSalaryRecord.additional_deductions.reduce(
                      (sum, d) => sum + Number(d.value),
                      0
                    )
                  ).toLocaleString("en-IN", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  })
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1570,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1568,
                columnNumber: 17
              }, this),
              existingSalaryRecord.calculated_incentive !== 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                /* @__PURE__ */ jsxDEV("span", { children: "Incentive Adjustment:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1586,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "span",
                  {
                    className: existingSalaryRecord.calculated_incentive > 0 ? "text-green-600" : "text-red-600",
                    children: [
                      "₹",
                      Math.abs(
                        existingSalaryRecord.calculated_incentive
                      ).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      }),
                      existingSalaryRecord.calculated_incentive > 0 ? "" : " (Deduction)"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 1587,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1585,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-lg font-bold text-gray-900 border-t pt-2 mt-2", children: [
                /* @__PURE__ */ jsxDEV("span", { children: "Net Payable:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1607,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: [
                  "₹",
                  Number(existingSalaryRecord.net_payable).toLocaleString(
                    "en-IN",
                    {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    }
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1608,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1606,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                /* @__PURE__ */ jsxDEV("span", { children: "Paid Amount:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1620,
                  columnNumber: 21
                }, this),
                " ",
                /* @__PURE__ */ jsxDEV("span", { children: [
                  "₹",
                  Number(existingSalaryRecord.paid_amount).toLocaleString(
                    "en-IN",
                    {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    }
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1621,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1619,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                /* @__PURE__ */ jsxDEV("span", { children: "Remaining Balance:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1633,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "span",
                  {
                    className: Number(existingSalaryRecord.remaining_balance) > 0 ? "text-red-600 font-bold" : "text-green-600",
                    children: [
                      "₹",
                      Number(
                        existingSalaryRecord.remaining_balance
                      ).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 1634,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1632,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                /* @__PURE__ */ jsxDEV("span", { children: "Status:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1650,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "span",
                  {
                    className: existingSalaryRecord.status === "Paid" ? "text-green-700 font-bold" : "text-amber-700 font-bold",
                    children: existingSalaryRecord.status
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                    lineNumber: 1651,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1649,
                columnNumber: 19
              }, this),
              existingSalaryRecord.transaction_id && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                /* @__PURE__ */ jsxDEV("span", { children: "Transaction ID:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1662,
                  columnNumber: 23
                }, this),
                " ",
                /* @__PURE__ */ jsxDEV("span", { children: existingSalaryRecord.transaction_id }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1663,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1661,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                /* @__PURE__ */ jsxDEV("span", { children: "Payment Method:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1667,
                  columnNumber: 21
                }, this),
                " ",
                /* @__PURE__ */ jsxDEV("span", { children: existingSalaryRecord.payment_method || "N/A" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                  lineNumber: 1668,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
                lineNumber: 1666,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
              lineNumber: 1507,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
            lineNumber: 1503,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
          lineNumber: 1255,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center h-32 text-gray-500", children: "Loading salary details..." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
          lineNumber: 1674,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
        lineNumber: 1216,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
    lineNumber: 569,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx",
    lineNumber: 568,
    columnNumber: 5
  }, this);
};
_s(SalaryPayment, "PEZKszxeTFjkQWYPOorPe8GKsts=", false, function() {
  return [useNavigate, Form.useForm, Form.useForm];
});
_c = SalaryPayment;
export default SalaryPayment;
var _c;
$RefreshReg$(_c, "SalaryPayment");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SalaryPayment.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb1hVLFNBOGZRLFVBOWZSOzJCQXBYVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFDRUE7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxlQUFlO0FBQ3RCLFNBQVNDLFdBQVdDLFVBQVVDLGVBQWU7QUFDN0MsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxXQUFXO0FBQ2xCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxNQUFNQyxtQkFBbUI7QUFDbEMsU0FBU0MsY0FBY0Msc0JBQXNCO0FBQzdDLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyw4QkFBOEI7QUFDdkMsU0FBU0MsTUFBTUMsWUFBWTtBQUMzQixTQUFTQyx1QkFBdUI7QUFDaEMsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxnQkFBZ0I7QUFDdkIsU0FBU0MsWUFBWTtBQUNyQixNQUFNQyxnQkFBZ0JBLE1BQU07QUFBQUMsS0FBQTtBQUMxQixRQUFNQyxXQUFXYixZQUFZO0FBQzdCLFFBQU0sQ0FBQ2Msa0JBQWtCQyxtQkFBbUIsSUFBSXJCLFNBQVMsQ0FBQztBQUMxRCxRQUFNLENBQUNzQixtQkFBbUJDLG9CQUFvQixJQUFJdkIsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQ3dCLGVBQWVDLGdCQUFnQixJQUFJekIsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQzBCLGVBQWVDLGdCQUFnQixJQUFJM0IsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQzRCLFdBQVdDLFlBQVksSUFBSTdCLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUM4QixpQkFBaUJDLGtCQUFrQixJQUFJL0IsU0FBUyxDQUFDLENBQUM7QUFDekQsUUFBTSxDQUFDZ0MsbUJBQW1CQyxvQkFBb0IsSUFBSWpDLFNBQVMsRUFBRTtBQUM3RCxRQUFNLENBQUNrQyx3QkFBd0JDLHlCQUF5QixJQUFJbkMsU0FBUyxLQUFLO0FBQzFFLFFBQU0sQ0FBQ29DLGlCQUFpQkMsa0JBQWtCLElBQUlyQyxTQUFTLElBQUk7QUFDM0QsUUFBTSxDQUFDc0MsaUJBQWlCQyxrQkFBa0IsSUFBSXZDLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUN3QyxVQUFVQyxXQUFXLElBQUl6QyxTQUFTLElBQUk7QUFDN0MsUUFBTSxDQUFDMEMsSUFBSSxJQUFJcEQsS0FBS3FELFFBQVE7QUFDNUIsUUFBTSxDQUFDQyxVQUFVLElBQUl0RCxLQUFLcUQsUUFBUTtBQUNsQyxRQUFNLENBQUNFLHNCQUFzQkMsdUJBQXVCLElBQUk5QyxTQUFTLEtBQUs7QUFDdEUsUUFBTSxDQUFDK0Msc0JBQXNCQyx1QkFBdUIsSUFBSWhELFNBQVMsSUFBSTtBQUNyRSxRQUFNLENBQUNpRCxrQkFBa0JDLG1CQUFtQixJQUFJbEQsU0FBUyxLQUFLO0FBQzlELFFBQU0sQ0FBQ21ELGdCQUFnQkMsaUJBQWlCLElBQUlwRCxTQUFTO0FBQUEsSUFDbkRxRCxhQUFhO0FBQUEsSUFDYkMsT0FBTztBQUFBLElBQ1BDLE1BQU07QUFBQSxJQUNOQyxVQUFVO0FBQUEsTUFDUkMsT0FBTztBQUFBLE1BQ1BDLEtBQUs7QUFBQSxNQUNMQyxrQkFBa0I7QUFBQSxNQUNsQkMsbUJBQW1CO0FBQUEsTUFDbkJDLG9CQUFvQjtBQUFBLE1BQ3BCQyxtQkFBbUI7QUFBQSxNQUNuQkMsa0JBQWtCO0FBQUEsTUFDbEJDLFlBQVk7QUFBQSxJQUNkO0FBQUEsSUFDQUMsWUFBWTtBQUFBLE1BQ1ZDLFlBQVk7QUFBQSxNQUNaQyxLQUFLO0FBQUEsTUFDTEMsS0FBSztBQUFBLE1BQ0xDLGtCQUFrQjtBQUFBLElBQ3BCO0FBQUEsSUFDQUMscUJBQXFCO0FBQUEsSUFDckJDLHVCQUF1QjtBQUFBLElBQ3ZCQyxrQkFBa0I7QUFBQSxJQUNsQkMsc0JBQXNCO0FBQUEsSUFDdEJDLGdCQUFnQjtBQUFBLElBQ2hCQyxnQkFBZ0I7QUFBQSxJQUNoQkMsZ0JBQWdCO0FBQUEsSUFDaEJDLHVCQUF1QjtBQUFBLE1BQ3JCQyxRQUFRO0FBQUEsTUFDUkMsdUJBQXVCO0FBQUEsTUFDdkJDLDJCQUEyQjtBQUFBLE1BQzNCQywwQkFBMEI7QUFBQSxJQUM1QjtBQUFBLEVBQ0YsQ0FBQztBQUNELFFBQU1DLFdBQVcvRSxNQUFNLEVBQUVnRixPQUFPLE1BQU07QUFDdEMsUUFBTUMsaUJBQWlCO0FBQUEsSUFDckIzQixPQUFPO0FBQUEsSUFDUEMsS0FBSztBQUFBLElBQ0xDLGtCQUFrQjtBQUFBLElBQ2xCQyxtQkFBbUI7QUFBQSxJQUNuQkMsb0JBQW9CO0FBQUEsSUFDcEJDLG1CQUFtQjtBQUFBLElBQ25CQyxrQkFBa0I7QUFBQSxJQUNsQkMsWUFBWTtBQUFBLEVBQ2Q7QUFDQSxRQUFNcUIsbUJBQW1CO0FBQUEsSUFDdkJuQixZQUFZO0FBQUEsSUFDWkMsS0FBSztBQUFBLElBQ0xDLEtBQUs7QUFBQSxJQUNMQyxrQkFBa0I7QUFBQSxFQUNwQjtBQUNBLFFBQU1pQixVQUFVO0FBQUEsSUFDZCxFQUFFQyxLQUFLLFFBQVFDLFFBQVEsU0FBUztBQUFBLElBQ2hDLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGdCQUFnQjtBQUFBLElBQy9DLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGNBQWM7QUFBQSxJQUM3QyxFQUFFRCxLQUFLLGVBQWVDLFFBQVEsZUFBZTtBQUFBLElBQzdDLEVBQUVELEtBQUssY0FBY0MsUUFBUSxPQUFPO0FBQUEsSUFDcEMsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFFckMsUUFBTUMsU0FBUztBQUFBLElBQ2IsRUFBRUMsT0FBTyxXQUFXQyxPQUFPLFdBQVdDLFVBQVUsTUFBTTtBQUFBLElBQ3RELEVBQUVGLE9BQU8sWUFBWUMsT0FBTyxZQUFZQyxVQUFVLE1BQU07QUFBQSxJQUN4RCxFQUFFRixPQUFPLFNBQVNDLE9BQU8sU0FBU0MsVUFBVSxNQUFNO0FBQUEsSUFDbEQsRUFBRUYsT0FBTyxTQUFTQyxPQUFPLFNBQVNDLFVBQVUsTUFBTTtBQUFBLElBQ2xELEVBQUVGLE9BQU8sT0FBT0MsT0FBTyxPQUFPQyxVQUFVLE1BQU07QUFBQSxJQUM5QyxFQUFFRixPQUFPLFFBQVFDLE9BQU8sUUFBUUMsVUFBVSxNQUFNO0FBQUEsSUFDaEQsRUFBRUYsT0FBTyxRQUFRQyxPQUFPLFFBQVFDLFVBQVUsTUFBTTtBQUFBLElBQ2hELEVBQUVGLE9BQU8sVUFBVUMsT0FBTyxVQUFVQyxVQUFVLE1BQU07QUFBQSxJQUNwRDtBQUFBLE1BQ0VGLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsTUFDUEMsVUFBVTtBQUFBLElBQ1o7QUFBQSxJQUNBLEVBQUVGLE9BQU8sV0FBV0MsT0FBTyxXQUFXQyxVQUFVLE1BQU07QUFBQSxJQUN0RCxFQUFFRixPQUFPLFlBQVlDLE9BQU8sWUFBWUMsVUFBVSxNQUFNO0FBQUEsSUFDeEQsRUFBRUYsT0FBTyxZQUFZQyxPQUFPLFlBQVlDLFVBQVUsTUFBTTtBQUFBLEVBQUM7QUFFM0QsUUFBTUMsZ0JBQWdCSixPQUFPdEYsTUFBTSxFQUFFMkYsU0FBUyxHQUFHLE9BQU8sRUFBRVgsT0FBTyxJQUFJLENBQUMsR0FBR087QUFDekUsUUFBTSxDQUFDSyxVQUFVQyxXQUFXLElBQUloRyxTQUFTO0FBQUEsSUFDdkNxRCxhQUFhO0FBQUEsSUFDYkMsT0FBT3VDO0FBQUFBLElBQ1B0QyxNQUFNMkI7QUFBQUEsSUFDTjFCLFVBQVU7QUFBQSxNQUNSQyxPQUFPO0FBQUEsTUFDUEMsS0FBSztBQUFBLE1BQ0xDLGtCQUFrQjtBQUFBLE1BQ2xCQyxtQkFBbUI7QUFBQSxNQUNuQkMsb0JBQW9CO0FBQUEsTUFDcEJDLG1CQUFtQjtBQUFBLE1BQ25CQyxrQkFBa0I7QUFBQSxNQUNsQkMsWUFBWTtBQUFBLElBQ2Q7QUFBQSxJQUNBQyxZQUFZO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLEtBQUs7QUFBQSxNQUNMQyxLQUFLO0FBQUEsTUFDTEMsa0JBQWtCO0FBQUEsSUFDcEI7QUFBQSxJQUNBQyxxQkFBcUI7QUFBQSxJQUNyQkMsdUJBQXVCO0FBQUEsSUFDdkJDLGtCQUFrQjtBQUFBLElBQ2xCQyxzQkFBc0I7QUFBQSxJQUN0QndCLHNCQUFzQjtBQUFBLElBQ3RCQyxhQUFhO0FBQUEsSUFDYnhCLGdCQUFnQjtBQUFBLElBQ2hCQyxnQkFBZ0I7QUFBQSxJQUNoQkcsUUFBUTtBQUFBLElBQ1JxQixXQUFXO0FBQUEsSUFDWEMsUUFBUTtBQUFBLEVBQ1YsQ0FBQztBQUNELGlCQUFlQyxpQkFBaUI7QUFDOUIsUUFBSTtBQUNGLFlBQU1DLGVBQWUsTUFBTXBHLElBQUlxRyxJQUFJLFdBQVc7QUFDOUMsWUFBTUMsbUJBQW1CRixjQUFjRyxNQUFNQyxVQUFVQyxJQUFJLENBQUNDLFNBQVM7QUFBQSxRQUNuRWpCLE9BQU9pQixLQUFLQztBQUFBQSxRQUNabkIsT0FBTyxHQUFHa0IsS0FBS0UsSUFBSSxNQUFNRixLQUFLRyxZQUFZLE1BQU07QUFBQSxNQUNsRCxFQUFFO0FBQ0ZsRixtQkFBYTJFLG9CQUFvQixFQUFFO0FBQUEsSUFDckMsU0FBU1EsT0FBTztBQUNkbkYsbUJBQWEsRUFBRTtBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUNBOUIsWUFBVSxNQUFNO0FBQ2RzRyxtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsRUFBRTtBQUNMLGlCQUFlWSxjQUFjQyxJQUFJO0FBQy9CLFFBQUk7QUFDRixZQUFNQyxXQUFXLE1BQU1qSCxJQUFJcUcsSUFBSSxtQkFBbUJXLEVBQUUsRUFBRTtBQUN0RCxhQUFPQyxTQUFTVixLQUFLQTtBQUFBQSxJQUN2QixTQUFTTyxPQUFPO0FBQ2RJLGNBQVFKLE1BQU0sZ0NBQWdDQSxLQUFLO0FBQ25ELGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUNBLFFBQU1LLHNCQUFzQixPQUFPQyxZQUFZQyxZQUFZQyxhQUFhO0FBQ3RFLFFBQUk7QUFDRixZQUFNTCxXQUFXLE1BQU1qSCxJQUFJcUcsSUFBSSxxQkFBcUJlLFVBQVUsSUFBSTtBQUFBLFFBQ2hFRyxRQUFRLEVBQUVGLFlBQVlDLFNBQVM7QUFBQSxNQUNqQyxDQUFDO0FBQ0QsYUFBT0wsU0FBU1YsTUFBTWlCLGdCQUFnQjtBQUFBLElBQ3hDLFNBQVNDLEtBQUs7QUFDWlAsY0FBUUosTUFBTSwyQkFBMkJXLEdBQUc7QUFDNUMsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQ0EsUUFBTUMseUJBQXlCLE9BQU9OLFlBQVlDLFlBQVlDLGFBQWE7QUFDekUsUUFBSTtBQUNGLFlBQU1MLFdBQVcsTUFBTWpILElBQUlxRztBQUFBQSxRQUN6QixvQkFBb0JlLFVBQVU7QUFBQSxRQUM5QixFQUFFRyxRQUFRLEVBQUVGLFlBQVlDLFNBQVMsRUFBRTtBQUFBLE1BQ3JDO0FBQ0EsYUFBT0wsU0FBU1YsTUFBTW9CLGtCQUFrQkMseUJBQXlCO0FBQUEsSUFDbkUsU0FBU0gsS0FBSztBQUNaUCxjQUFRSixNQUFNLDhCQUE4QlcsR0FBRztBQUMvQyxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFDQTVILFlBQVUsTUFBTTtBQUNkLFFBQUksQ0FBQ3VCLG1CQUFtQjtBQUN0QkQsMEJBQW9CLENBQUM7QUFBQSxJQUN2QjtBQUFBLEVBQ0YsR0FBRyxDQUFDQyxpQkFBaUIsQ0FBQztBQUN0QixRQUFNeUcsaUJBQWlCQSxDQUFDQyxnQkFBZ0JDLGlCQUFpQjtBQUN2RCxRQUFJLENBQUNELGtCQUFrQixDQUFDQyxjQUFjO0FBQ3BDLGFBQU94QyxPQUFPa0IsSUFBSSxDQUFDdUIsT0FBTyxFQUFFLEdBQUdBLEdBQUd0QyxVQUFVLEtBQUssRUFBRTtBQUFBLElBQ3JEO0FBQ0EsVUFBTXVDLFVBQVVoSSxNQUFNNkgsY0FBYztBQUNwQyxVQUFNSSxRQUFRakksTUFBTTtBQUNwQixVQUFNa0ksV0FBV0YsUUFBUTVFLEtBQUs7QUFDOUIsVUFBTStFLGNBQWNGLE1BQU03RSxLQUFLO0FBQy9CLFVBQU1nRixrQkFBa0JDLE9BQU9QLFlBQVk7QUFDM0MsV0FBT3hDLE9BQU9rQixJQUFJLENBQUNyRCxPQUFPbUYsVUFBVTtBQUNsQyxZQUFNQyxrQkFDSkgsb0JBQW9CRixZQUFZSSxRQUFRTixRQUFRN0UsTUFBTTtBQUN4RCxZQUFNcUYsZUFDSkosb0JBQW9CRCxlQUFlRyxRQUFRTCxNQUFNOUUsTUFBTTtBQUN6RCxZQUFNc0MsV0FDSjJDLGtCQUFrQkYsWUFDbEJFLGtCQUFrQkQsZUFDbEJJLG1CQUNBQztBQUNGLGFBQU8sRUFBRSxHQUFHckYsT0FBT3NDLFNBQVM7QUFBQSxJQUM5QixDQUFDO0FBQUEsRUFDSDtBQUNBN0YsWUFBVSxNQUFNO0FBQ2QsUUFDRWdHLFNBQVMxQyxlQUNUMEMsU0FBU3hDLFFBQ1R6QixpQkFBaUI4RyxjQUNqQjtBQUNBLFlBQU1DLGNBQWNkO0FBQUFBLFFBQ2xCakcsZ0JBQWdCOEc7QUFBQUEsUUFDaEI3QyxTQUFTeEM7QUFBQUEsTUFDWDtBQUNBLFlBQU11RixvQkFBb0JELFlBQVlFO0FBQUFBLFFBQ3BDLENBQUNiLE1BQU1BLEVBQUV2QyxVQUFVSSxTQUFTekMsU0FBUyxDQUFDNEUsRUFBRXRDO0FBQUFBLE1BQzFDO0FBQ0EsVUFBSSxDQUFDa0QsbUJBQW1CO0FBQ3RCLGNBQU1FLGFBQWFILFlBQVlJLEtBQUssQ0FBQ2YsTUFBTSxDQUFDQSxFQUFFdEMsUUFBUTtBQUN0RCxZQUFJb0QsWUFBWTtBQUNkaEQsc0JBQVksQ0FBQ2tELFVBQVU7QUFBQSxZQUNyQixHQUFHQTtBQUFBQSxZQUNINUYsT0FBTzBGLFdBQVdyRDtBQUFBQSxVQUNwQixFQUFFO0FBQUEsUUFDSjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRixHQUFHLENBQUNJLFNBQVN4QyxNQUFNd0MsU0FBUzFDLGFBQWF2QixpQkFBaUI4RyxZQUFZLENBQUM7QUFDdkUsUUFBTU8sYUFBYSxPQUFPakMsT0FBTztBQUMvQixRQUFJO0FBQ0Z6Rix1QkFBaUIsSUFBSTtBQUNyQkYsMkJBQXFCLElBQUk7QUFDekJGLDBCQUFvQixDQUFDO0FBQ3JCLFlBQU0rSCxhQUFhLE1BQU1uQyxjQUFjQyxFQUFFO0FBQ3pDLFVBQUlrQyxZQUFZO0FBQ2QvRywyQkFBbUI2RSxFQUFFO0FBQ3JCLGNBQU1tQyxjQUFjbEosTUFBTWlKLFdBQVdFLGFBQWEsTUFBTTtBQUV4RCxjQUFNQyxhQUNKSCxXQUFXbEQsZUFBZWtELFdBQVduRCx3QkFBd0I7QUFFL0QsY0FBTUYsWUFBVztBQUFBLFVBQ2YxQyxhQUFhK0YsWUFBWS9GLGFBQWF3RDtBQUFBQSxVQUN0Q3ZELE9BQU84RixZQUFZSTtBQUFBQSxVQUNuQmpHLE1BQU04RjtBQUFBQSxVQUNON0YsVUFBVTRGLFlBQVk1RjtBQUFBQSxVQUN0QlMsWUFBWW1GLFlBQVluRjtBQUFBQSxVQUN4QksscUJBQXFCOEUsWUFBWTlFLHVCQUF1QjtBQUFBLFVBQ3hEQyx1QkFBdUI2RSxZQUFZN0UseUJBQXlCO0FBQUEsVUFDNURDLGtCQUFrQjRFLFlBQVk1RSxvQkFBb0I7QUFBQSxVQUNsREMsc0JBQXNCMkUsWUFBWTNFLHdCQUF3QjtBQUFBLFVBQzFEd0Isc0JBQXNCbUQsWUFBWW5ELHdCQUF3QjtBQUFBLFVBQzFEQyxhQUFhcUQ7QUFBQUE7QUFBQUEsVUFDYjdFLGdCQUFnQjBFLFlBQVkxRSxrQkFBa0I7QUFBQSxVQUM5Q0MsZ0JBQWdCeUUsWUFBWXpFLGtCQUFrQjtBQUFBLFVBQzlDOEUsVUFBVUwsWUFBWUssV0FDbEIzSSxPQUFPc0ksWUFBWUssUUFBUSxJQUMzQjNJLE9BQU87QUFBQSxVQUNYNEksb0JBQW9CTixZQUFZTSxzQkFBc0IsQ0FBQztBQUFBLFVBQ3ZEN0UsdUJBQXVCdUUsWUFBWXZFLHlCQUF5QjtBQUFBLFlBQzFEQyxRQUFRO0FBQUEsWUFDUkMsdUJBQXVCO0FBQUEsWUFDdkJDLDJCQUEyQjtBQUFBLFlBQzNCQywwQkFBMEI7QUFBQSxVQUM1QjtBQUFBLFVBQ0FtQixRQUFRO0FBQUEsVUFDUnhCLGdCQUFnQjtBQUFBLFFBQ2xCO0FBRUF4QiwwQkFBa0IyQyxTQUFRO0FBQzFCbkQsbUJBQVcrRyxlQUFlNUQsU0FBUTtBQUFBLE1BQ3BDO0FBQUEsSUFDRixTQUFTaUIsT0FBTztBQUNkdkgsY0FBUXVILE1BQU0sZ0NBQWdDO0FBQUEsSUFDaEQsVUFBQztBQUNDdkYsdUJBQWlCLEtBQUs7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFDQSxRQUFNbUksc0JBQXNCLE9BQU8xQyxPQUFPO0FBQ3hDLFFBQUk7QUFDRnZGLHVCQUFpQixJQUFJO0FBQ3JCLFlBQU16QixJQUFJMkosT0FBTyxtQkFBbUIzQyxFQUFFLEVBQUU7QUFDeEN6SCxjQUFRcUssUUFBUSxxQ0FBcUM7QUFDckR2SCx5QkFBbUIsS0FBSztBQUN4QndILG1CQUFhO0FBQUEsSUFDZixTQUFTL0MsT0FBTztBQUNkdkgsY0FBUXVILE1BQU0saUNBQWlDO0FBQUEsSUFDakQsVUFBQztBQUNDckYsdUJBQWlCLEtBQUs7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFDQSxRQUFNcUkscUJBQXFCQSxDQUFDQyxlQUFlQyxjQUFjO0FBQ3ZELFFBQUlELGNBQWMxRyxRQUFRcEQsTUFBTWdLLFFBQVFGLGNBQWMxRyxJQUFJLEdBQUc7QUFDM0QwRyxvQkFBYzFHLE9BQU8wRyxjQUFjMUcsS0FBSzRCLE9BQU8sTUFBTTtBQUFBLElBQ3ZEO0FBQ0EvQixzQkFBa0I7QUFBQSxNQUNoQixHQUFHRDtBQUFBQSxNQUNILEdBQUc4RztBQUFBQSxNQUNILEdBQUdDO0FBQUFBLElBQ0wsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNRSxxQkFBcUIsWUFBWTtBQUNyQyxRQUFJO0FBQ0YzSSx1QkFBaUIsSUFBSTtBQUdyQixZQUFNNEksYUFBYXpILFdBQVcwSCxlQUFlO0FBQzdDLFlBQU1DLGVBQWUvQixPQUFPNkIsV0FBV3BFLHdCQUF3QixDQUFDO0FBQ2hFLFlBQU11RSxZQUFZcEo7QUFDbEIsWUFBTXFKLHFCQUFxQkYsZUFBZUM7QUFFMUMsWUFBTUUsb0JBQW9CSCxlQUFlRTtBQUV6QyxZQUFNRSxhQUFhO0FBQUEsUUFDakIsR0FBR047QUFBQUEsUUFDSG5FLGFBQWF1RTtBQUFBQSxRQUNiQztBQUFBQSxRQUNBN0YsdUJBQXVCd0YsV0FBV3hGLHlCQUF5QjtBQUFBLFVBQ3pEQyxRQUFRO0FBQUEsVUFDUkMsdUJBQXVCO0FBQUEsVUFDdkJDLDJCQUEyQjtBQUFBLFVBQzNCQywwQkFBMEI7QUFBQSxRQUM1QjtBQUFBLE1BQ0Y7QUFFQSxZQUFNL0UsSUFBSTBLLElBQUksbUJBQW1CeEksZUFBZSxJQUFJdUksVUFBVTtBQUM5RGxMLGNBQVFxSyxRQUFRLDZCQUE2QjtBQUM3Q3ZJLDJCQUFxQixLQUFLO0FBQzFCd0ksbUJBQWE7QUFBQSxJQUNmLFNBQVMvQyxPQUFPO0FBQ2RJLGNBQVFKLE1BQU0sMEJBQTBCQSxLQUFLO0FBQzdDdkgsY0FBUXVILE1BQU0seUJBQXlCO0FBQUEsSUFDekMsVUFBQztBQUNDdkYsdUJBQWlCLEtBQUs7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFDQSxRQUFNb0osY0FBY0EsQ0FBQ0Msb0JBQW9CO0FBQ3ZDM0osYUFBUyx3QkFBd0IySixlQUFlO0FBQUEsRUFDbEQ7QUFDQSxRQUFNQyxnQkFBZ0JBLENBQUNDLGtCQUFrQjtBQUN2QyxVQUFNQyxtQkFBbUI7QUFBQSxNQUN2QjtBQUFBLFFBQ0UxRixLQUFLO0FBQUEsUUFDTEcsT0FDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsV0FBVTtBQUFBLFlBQ1YsU0FBUyxNQUFNbUYsWUFBWUcsZUFBZW5FLEdBQUc7QUFBQSxZQUFHO0FBQUE7QUFBQSxVQUYzQ21FLGVBQWVuRTtBQUFBQSxVQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxNQUVKO0FBQUEsTUFDQTtBQUFBLFFBQ0V0QixLQUFLO0FBQUEsUUFDTEcsT0FDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsV0FBVTtBQUFBLFlBQ1YsU0FBUyxNQUFNeUQsV0FBVzZCLGNBQWNuRSxHQUFHO0FBQUEsWUFBRztBQUFBO0FBQUEsVUFGekNtRSxlQUFlbkU7QUFBQUEsVUFEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsTUFFSjtBQUFBLE1BQ0E7QUFBQSxRQUNFdEIsS0FBSztBQUFBLFFBQ0xHLE9BQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLFdBQVU7QUFBQSxZQUNWLFNBQVMsTUFBTTtBQUNiakQsMEJBQVl1SSxlQUFlbkUsR0FBRztBQUM5QnRFLGlDQUFtQixJQUFJO0FBQUEsWUFDekI7QUFBQSxZQUFHO0FBQUE7QUFBQSxVQUxFeUksZUFBZW5FO0FBQUFBLFVBRHRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQTtBQUFBLE1BRUo7QUFBQSxJQUFDO0FBRUgsV0FBT29FO0FBQUFBLEVBQ1Q7QUFDQSxpQkFBZUMscUJBQXFCO0FBQ2xDLFFBQUk7QUFDRi9JLGdDQUEwQixJQUFJO0FBQzlCLFlBQU1tRSxlQUFlLE1BQU1wRyxJQUFJcUcsSUFBSSxhQUFhUixTQUFTMUMsV0FBVyxFQUFFO0FBQ3RFLFlBQU11RCxNQUFNTixjQUFjRyxNQUFNQTtBQUNoQyxZQUFNMEUsa0JBQWtCO0FBQUEsUUFDdEIsR0FBRy9GO0FBQUFBLFFBQ0gsR0FBR3dCLEtBQUtwRDtBQUFBQSxRQUNSNEgsUUFBUXhFLEtBQUt3RSxVQUFVO0FBQUEsTUFDekI7QUFDQSxZQUFNQyxvQkFBb0I7QUFBQSxRQUN4QixHQUFHaEc7QUFBQUEsUUFDSCxHQUFHdUIsS0FBSzNDO0FBQUFBLE1BQ1Y7QUFDQWxDLHlCQUFtQjZFLEdBQUc7QUFDdEJaLGtCQUFZLENBQUNrRCxVQUFVO0FBQUEsUUFDckIsR0FBR0E7QUFBQUEsUUFDSDFGLFVBQVUySDtBQUFBQSxRQUNWbEgsWUFBWW9IO0FBQUFBLE1BQ2QsRUFBRTtBQUFBLElBQ0osU0FBU3JFLE9BQU87QUFDZGpGLHlCQUFtQixDQUFDLENBQUM7QUFBQSxJQUN2QixVQUFDO0FBQ0NJLGdDQUEwQixLQUFLO0FBQUEsSUFDakM7QUFBQSxFQUNGO0FBQ0FwQyxZQUFVLE1BQU07QUFDZCxRQUFJZ0csU0FBUzFDLGVBQWUwQyxTQUFTekMsU0FBU3lDLFNBQVN4QyxNQUFNO0FBQzNEK0gsNkJBQXVCO0FBQUEsSUFDekI7QUFBQSxFQUNGLEdBQUcsQ0FBQ3ZGLFNBQVMxQyxhQUFhMEMsU0FBU3pDLE9BQU95QyxTQUFTeEMsSUFBSSxDQUFDO0FBQ3hELFFBQU0rSCx5QkFBeUIsWUFBWTtBQUN6QyxRQUFJO0FBQ0YsWUFBTUMsYUFBYXpLLE9BQU8sRUFBRXdDLE1BQU15QyxTQUFTekMsS0FBSyxFQUFFQSxNQUFNO0FBQ3hELFlBQU1DLE9BQU93QyxTQUFTeEM7QUFDdEIsWUFBTWdFLGFBQWF6RyxPQUFPLEVBQ3ZCeUMsS0FBS0EsSUFBSSxFQUNURCxNQUFNaUksVUFBVSxFQUNoQkMsUUFBUSxPQUFPLEVBQ2ZyRyxPQUFPLFlBQVk7QUFDdEIsWUFBTXFDLFdBQVcxRyxPQUFPLEVBQ3JCeUMsS0FBS0EsSUFBSSxFQUNURCxNQUFNaUksVUFBVSxFQUNoQkUsTUFBTSxPQUFPLEVBQ2J0RyxPQUFPLFlBQVk7QUFDdEIsWUFBTXVHLGNBQWMsTUFBTXJFO0FBQUFBLFFBQ3hCdEIsU0FBUzFDO0FBQUFBLFFBQ1RrRTtBQUFBQSxRQUNBQztBQUFBQSxNQUNGO0FBQ0EsWUFBTW1FLGlCQUFpQixNQUFNL0Q7QUFBQUEsUUFDM0I3QixTQUFTMUM7QUFBQUEsUUFDVGtFO0FBQUFBLFFBQ0FDO0FBQUFBLE1BQ0Y7QUFDQXhCLGtCQUFZLENBQUNrRCxVQUFVO0FBQUEsUUFDckIsR0FBR0E7QUFBQUEsUUFDSHBFLFFBQVE0RztBQUFBQSxRQUNSdkYsV0FBV3dGO0FBQUFBLE1BQ2IsRUFBRTtBQUFBLElBQ0osU0FBU2hFLEtBQUs7QUFDWlAsY0FBUUosTUFBTSwwQ0FBMENXLEdBQUc7QUFBQSxJQUM3RDtBQUFBLEVBQ0Y7QUFDQTVILFlBQVUsTUFBTTtBQUNkLFFBQUlnRyxTQUFTMUMsYUFBYTtBQUN4QjZILHlCQUFtQjtBQUFBLElBQ3JCO0FBQUEsRUFDRixHQUFHLENBQUNuRixVQUFVMUMsYUFBYTBDLFNBQVN6QyxPQUFPeUMsU0FBU3pDLEtBQUssQ0FBQztBQUMxRCxRQUFNc0ksc0JBQXNCM0wsUUFBUSxNQUFNO0FBQ3hDLFVBQU11RCxXQUFXTCxnQkFBZ0JLLFlBQVksQ0FBQztBQUM5QyxXQUFPcUksT0FBT0MsT0FBT3RJLFFBQVEsRUFBRXVJLE9BQU8sQ0FBQ0MsS0FBS0MsTUFBTUQsTUFBTXhELE9BQU95RCxLQUFLLENBQUMsR0FBRyxDQUFDO0FBQUEsRUFDM0UsR0FBRyxDQUFDOUksY0FBYyxDQUFDO0FBQ25CLFFBQU0rSSx3QkFBd0JqTSxRQUFRLE1BQU07QUFDMUMsVUFBTWdFLGFBQWFkLGdCQUFnQmMsY0FBYyxDQUFDO0FBQ2xELFVBQU1rSSxhQUFhaEosZ0JBQWdCb0IseUJBQXlCO0FBQzVELFVBQU02SCxPQUFPUCxPQUFPQyxPQUFPN0gsVUFBVSxFQUFFOEg7QUFBQUEsTUFDckMsQ0FBQ0MsS0FBS0MsTUFBTUQsTUFBTXhELE9BQU95RCxLQUFLLENBQUM7QUFBQSxNQUMvQjtBQUFBLElBQ0Y7QUFDQSxVQUFNSSxRQUFRRixXQUFXSixPQUFPLENBQUNDLEtBQUtNLE1BQU1OLE1BQU14RCxPQUFPOEQsRUFBRTNHLFNBQVMsQ0FBQyxHQUFHLENBQUM7QUFDekUsV0FBT3lHLE9BQU9DO0FBQUFBLEVBQ2hCLEdBQUcsQ0FBQ2xKLGNBQWMsQ0FBQztBQUNuQixpQkFBZTRHLGVBQWU7QUFDNUIsUUFBSTtBQUNGN0csMEJBQW9CLElBQUk7QUFDeEIsWUFBTWlFLFdBQVcsTUFBTWpILElBQUlxRyxJQUFJLGdDQUFnQztBQUMvRCxZQUFNRCxlQUFlYSxVQUFVVixNQUFNQSxRQUFRO0FBQzdDLFlBQU04RixlQUFlakcsYUFBYUssSUFBSSxDQUFDRixNQUFNZ0MsV0FBVztBQUFBLFFBQ3REK0QsTUFBTS9ELFFBQVE7QUFBQSxRQUNkNUIsS0FBS0osTUFBTUk7QUFBQUEsUUFDWDRGLGNBQWNoRyxNQUFNcEQsYUFBYXlEO0FBQUFBLFFBQ2pDNEYsY0FBY2pHLE1BQU1wRCxhQUFhcUo7QUFBQUEsUUFDakNDLGFBQWFsRyxNQUFNK0M7QUFBQUEsUUFDbkJvRCxZQUFZbkcsTUFBTTZDO0FBQUFBLFFBQ2xCdUQsWUFBWXBHLE1BQU1SO0FBQUFBLFFBQ2xCc0QsWUFBWTlDLE1BQU1QO0FBQUFBLFFBQ2xCNEcsUUFDRSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUVDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsWUFDakIsTUFBTTtBQUFBLGNBQ0pDLE9BQU9oQyxjQUFjdEUsSUFBSTtBQUFBLFlBQzNCO0FBQUEsWUFDQSxXQUFVO0FBQUEsWUFDVixpQ0FBQyxZQUFTLFdBQVUsZUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0I7QUFBQTtBQUFBLFVBTjFCQSxNQUFNSTtBQUFBQSxVQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLE1BRUosRUFBRTtBQUNGNUUsMkJBQXFCLENBQUMsR0FBR3NLLFlBQVksQ0FBQztBQUFBLElBQ3hDLFNBQVN2RixPQUFPO0FBQ2QvRSwyQkFBcUIsRUFBRTtBQUFBLElBQ3pCLFVBQUM7QUFDQ2lCLDBCQUFvQixLQUFLO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBQ0FuRCxZQUFVLE1BQU07QUFDZGdLLGlCQUFhO0FBQUEsRUFDZixHQUFHLEVBQUU7QUFHTCxRQUFNaUQsWUFBWTtBQUFBLElBQ2hCO0FBQUEsTUFDRUMsSUFBSTtBQUFBLE1BQ0pDLE1BQU0sdUJBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlO0FBQUEsTUFDckJ4SCxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFdUgsSUFBSTtBQUFBLE1BQ0pDLE1BQU0sdUJBQUMsZ0JBQWEsTUFBTSxNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVCO0FBQUEsTUFDN0J4SCxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFdUgsSUFBSTtBQUFBLE1BQ0pDLE1BQU0sdUJBQUMsMEJBQXVCLE1BQU0sTUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQ3ZDeEgsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNBO0FBQUEsTUFDRXVILElBQUk7QUFBQSxNQUNKQyxNQUFNLHVCQUFDLDBCQUF1QixNQUFNLE1BQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUN2Q3hILE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0V1SCxJQUFJO0FBQUEsTUFDSkMsTUFBTSx1QkFBQywwQkFBdUIsTUFBTSxNQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDdkN4SCxPQUFPO0FBQUEsSUFDVDtBQUFBLEVBQUM7QUFHSCxRQUFNeUgsa0JBQWtCbE4sUUFBUSxNQUFNO0FBQ3BDLFdBQU8rQixrQkFBa0IrSjtBQUFBQSxNQUN2QixDQUFDQyxLQUFLb0IsU0FBU3BCLE9BQU94RCxPQUFPNEUsS0FBS1AsVUFBVSxLQUFLO0FBQUEsTUFDakQ7QUFBQSxJQUNGO0FBQUEsRUFDRixHQUFHLENBQUM3SyxpQkFBaUIsQ0FBQztBQUV0QixTQUNFLHVCQUFDLFNBQ0MsaUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwyQkFBQyxVQUFPLFlBQVksUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QjtBQUFBLElBQ3pCLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFRO0FBQUEsSUFDUix1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSw2QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVc7QUFBQSxNQUVYLHVCQUFDLGFBQVEsV0FBVSxRQUNqQjtBQUFBLCtCQUFDLE9BQUUsV0FBVSxzRUFBcUUsK0JBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNaZ0wsb0JBQVVyRztBQUFBQSxVQUFJLENBQUMwRyxTQUNkO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxJQUFJQSxLQUFLSjtBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsVUFBSyxXQUFVLGlCQUFpQkksZUFBS0gsUUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkM7QUFBQSxnQkFDMUNHLEtBQUszSDtBQUFBQTtBQUFBQTtBQUFBQSxZQUxEMkgsS0FBS0o7QUFBQUEsWUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxRQUNELEtBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsV0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsMENBRWI7QUFBQSwrQkFBQyxRQUFHLFdBQVUsMEJBQXlCLDhCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSw2RkFHYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFVBQUssV0FBVSw2QkFBNEIsaUNBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSwyQkFDYmpMLDRCQUFrQnNMLFVBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUdBLHVCQUFDLFVBQUssV0FBVSwwQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUM7QUFBQSxVQUd2Qyx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsNkJBQTRCLDhCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLFdBQVUsMkJBQTBCO0FBQUE7QUFBQSxjQUN0Q0gsZ0JBQWdCSSxlQUFlLE9BQU87QUFBQSxpQkFEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5QkE7QUFBQSxXQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUNBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxXQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUI7QUFBQSxRQUN0QnRLLG1CQUNDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFXLHVCQUFDLG1CQUFnQixPQUFPLEVBQUV1SyxVQUFVLEdBQUcsR0FBRyxNQUFJLFFBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThDO0FBQUEsWUFDekQsV0FBVTtBQUFBO0FBQUEsVUFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFb0IsSUFFbEJ4TCxrQkFBa0JzTCxTQUFTLElBQzdCLHVCQUFDLGFBQVUsU0FBa0IsTUFBTXRMLG1CQUFtQixrQkFBaUIsdUJBQXNCLGlCQUFnQixxQkFBN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4SCxJQUU5SCx1QkFBQyxTQUFNLGFBQVksa0NBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUQ7QUFBQSxXQVZyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxTQWxFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUVBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTTtBQUFBLFFBQ04sT0FBTztBQUFBLFFBQ1AsV0FBVTtBQUFBLFFBQ1YsTUFBTVY7QUFBQUEsUUFDTixTQUFTLE1BQU1DLHFCQUFxQixLQUFLO0FBQUEsUUFDekMsVUFBVTtBQUFBLFFBQ1YsUUFDRSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxpQ0FBQyxVQUFPLFNBQVMsTUFBTUEscUJBQXFCLEtBQUssR0FBRyxzQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVM2STtBQUFBQSxjQUNULFNBQVM1STtBQUFBQSxjQUFlO0FBQUE7QUFBQSxZQUgxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLGFBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFFRjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBTW9CO0FBQUFBLFlBQ04sUUFBTztBQUFBLFlBQ1AsZUFBZU87QUFBQUEsWUFDZixnQkFBZ0I2RztBQUFBQSxZQUNoQjtBQUFBO0FBQUEsZ0JBQUMsS0FBSztBQUFBLGdCQUFMO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU07QUFBQSxrQkFDTixPQUFPO0FBQUEsb0JBQ0wsRUFBRXlELFVBQVUsTUFBTWhPLFNBQVMsNEJBQTRCO0FBQUEsa0JBQUM7QUFBQSxrQkFFMUQ7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0M7QUFBQSxzQkFDQTtBQUFBLHNCQUNBLGtCQUFpQjtBQUFBLHNCQUNqQixjQUFjLENBQUNpTyxPQUFPQyxZQUNuQkEsUUFBUWpJLFNBQVMsSUFDZmtJLFlBQVksRUFDWkMsU0FBU0gsTUFBTUUsWUFBWSxDQUFDO0FBQUEsc0JBRWpDLFlBQVksQ0FBQ0UsU0FBU0MsYUFDbkJELFNBQVNwSSxTQUFTLElBQ2hCa0ksWUFBWSxFQUNaSSxlQUFlRCxTQUFTckksU0FBUyxJQUFJa0ksWUFBWSxDQUFDO0FBQUEsc0JBRXZELGFBQVk7QUFBQSxzQkFDWixTQUFTaE07QUFBQUE7QUFBQUEsb0JBZlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQWVxQjtBQUFBO0FBQUEsZ0JBckJ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0F1QkE7QUFBQSxjQUNBO0FBQUEsZ0JBQUMsS0FBSztBQUFBLGdCQUFMO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU07QUFBQSxrQkFDTixPQUFPLENBQUMsRUFBRTZMLFVBQVUsTUFBTWhPLFNBQVMsd0JBQXdCLENBQUM7QUFBQSxrQkFDNUQsaUNBQUMsVUFBTyxVQUFRLE1BQUMsYUFBWSxnQkFDMUJnRyxpQkFBT2tCO0FBQUFBLG9CQUFJLENBQUNyRCxVQUNYLHVCQUFDLE9BQU8sUUFBUCxFQUFnQyxPQUFPQSxNQUFNcUMsT0FDM0NyQyxnQkFBTW9DLFNBRFdwQyxNQUFNcUMsT0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBO0FBQUEsZ0JBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBV0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUMsS0FBSztBQUFBLGdCQUFMO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU07QUFBQSxrQkFDTixPQUFPLENBQUMsRUFBRThILFVBQVUsTUFBTWhPLFNBQVMsdUJBQXVCLENBQUM7QUFBQSxrQkFDM0QsbUJBQW1CLENBQUNrRyxVQUNsQkEsUUFBUUEsTUFBTVIsT0FBTyxNQUFNLElBQUk7QUFBQSxrQkFFakMsaUNBQUMsY0FBVyxVQUFRLE1BQUMsUUFBTyxRQUFPLE9BQU8sRUFBRThJLE9BQU8sT0FBTyxLQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0RDtBQUFBO0FBQUEsZ0JBUDlEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsNkNBQTRDLHdCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEseUNBQUMsS0FBSyxNQUFMLEVBQVUsTUFBTSxDQUFDLFlBQVksT0FBTyxHQUFHLE9BQU0sZ0JBQzVDLGlDQUFDLFNBQU0sVUFBUSxNQUFDLE1BQUssWUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkIsS0FEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE1BQU0sQ0FBQyxZQUFZLEtBQUssR0FBRyxPQUFNLE9BQzFDLGlDQUFDLFNBQU0sVUFBUSxNQUFDLE1BQUssWUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkIsS0FEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUMsS0FBSztBQUFBLG9CQUFMO0FBQUEsc0JBQ0MsTUFBTSxDQUFDLFlBQVksa0JBQWtCO0FBQUEsc0JBQ3JDLE9BQU07QUFBQSxzQkFDTixpQ0FBQyxTQUFNLFVBQVEsTUFBQyxNQUFLLFlBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTZCO0FBQUE7QUFBQSxvQkFIL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUlBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQyxLQUFLO0FBQUEsb0JBQUw7QUFBQSxzQkFDQyxNQUFNLENBQUMsWUFBWSxtQkFBbUI7QUFBQSxzQkFDdEMsT0FBTTtBQUFBLHNCQUNOLGlDQUFDLFNBQU0sVUFBUSxNQUFDLE1BQUssWUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkI7QUFBQTtBQUFBLG9CQUgvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDLEtBQUs7QUFBQSxvQkFBTDtBQUFBLHNCQUNDLE1BQU0sQ0FBQyxZQUFZLG9CQUFvQjtBQUFBLHNCQUN2QyxPQUFNO0FBQUEsc0JBQ04saUNBQUMsU0FBTSxVQUFRLE1BQUMsTUFBSyxZQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE2QjtBQUFBO0FBQUEsb0JBSC9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUMsS0FBSztBQUFBLG9CQUFMO0FBQUEsc0JBQ0MsTUFBTSxDQUFDLFlBQVksbUJBQW1CO0FBQUEsc0JBQ3RDLE9BQU07QUFBQSxzQkFDTixpQ0FBQyxTQUFNLFVBQVEsTUFBQyxNQUFLLFlBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTZCO0FBQUE7QUFBQSxvQkFIL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUlBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQyxLQUFLO0FBQUEsb0JBQUw7QUFBQSxzQkFDQyxNQUFNLENBQUMsWUFBWSxrQkFBa0I7QUFBQSxzQkFDckMsT0FBTTtBQUFBLHNCQUNOLGlDQUFDLFNBQU0sVUFBUSxNQUFDLE1BQUssWUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkI7QUFBQTtBQUFBLG9CQUgvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSUE7QUFBQSxrQkFDQSx1QkFBQyxLQUFLLE1BQUwsRUFBVSxNQUFNLENBQUMsWUFBWSxZQUFZLEdBQUcsT0FBTSxjQUNqRCxpQ0FBQyxTQUFNLFVBQVEsTUFBQyxNQUFLLFlBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZCLEtBRC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFtQ0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLDhCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0M7QUFBQSxzQkFDQSxPQUFPckMsb0JBQW9Cc0MsUUFBUSxDQUFDO0FBQUEsc0JBQ3BDLFdBQVU7QUFBQTtBQUFBLG9CQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFHeUI7QUFBQSxxQkFQM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFTQTtBQUFBLG1CQWpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWtEQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGlDQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDJDQUEwQywwQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBO0FBQUEsb0JBQUMsS0FBSztBQUFBLG9CQUFMO0FBQUEsc0JBQ0MsTUFBTSxDQUFDLGNBQWMsWUFBWTtBQUFBLHNCQUNqQyxPQUFNO0FBQUEsc0JBQ04saUNBQUMsU0FBTSxVQUFRLE1BQUMsTUFBSyxZQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE2QjtBQUFBO0FBQUEsb0JBSC9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJQTtBQUFBLGtCQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE1BQU0sQ0FBQyxjQUFjLEtBQUssR0FBRyxPQUFNLE9BQzVDLGlDQUFDLFNBQU0sVUFBUSxNQUFDLE1BQUssWUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkIsS0FEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE1BQU0sQ0FBQyxjQUFjLEtBQUssR0FBRyxPQUFNLE9BQzVDLGlDQUFDLFNBQU0sVUFBUSxNQUFDLE1BQUssWUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkIsS0FEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUMsS0FBSztBQUFBLG9CQUFMO0FBQUEsc0JBQ0MsTUFBTSxDQUFDLGNBQWMsa0JBQWtCO0FBQUEsc0JBQ3ZDLE9BQU07QUFBQSxzQkFDTixpQ0FBQyxTQUFNLFVBQVEsTUFBQyxNQUFLLFlBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTZCO0FBQUE7QUFBQSxvQkFIL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUlBO0FBQUEscUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaUJBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQyxnQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDO0FBQUEsc0JBQ0EsT0FBT2hDLHNCQUFzQmdDLFFBQVEsQ0FBQztBQUFBLHNCQUN0QyxXQUFVO0FBQUE7QUFBQSxvQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBR3lCO0FBQUEscUJBUDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBU0E7QUFBQSxtQkEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQ0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSw4Q0FBNkMsa0NBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQTtBQUFBLG9CQUFDLEtBQUs7QUFBQSxvQkFBTDtBQUFBLHNCQUNDLE9BQU07QUFBQSxzQkFDTixNQUFNLENBQUMsc0JBQXNCLFlBQVk7QUFBQSxzQkFDekMsaUNBQUMsU0FBTSxNQUFLLFVBQVMsVUFBUSxRQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE2QjtBQUFBO0FBQUEsb0JBSC9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUMsS0FBSztBQUFBLG9CQUFMO0FBQUEsc0JBQ0MsT0FBTTtBQUFBLHNCQUNOLE1BQU0sQ0FBQyxzQkFBc0IsY0FBYztBQUFBLHNCQUMzQyxpQ0FBQyxTQUFNLE1BQUssVUFBUyxVQUFRLFFBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTZCO0FBQUE7QUFBQSxvQkFIL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUlBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQyxLQUFLO0FBQUEsb0JBQUw7QUFBQSxzQkFDQyxPQUFNO0FBQUEsc0JBQ04sTUFBTSxDQUFDLHNCQUFzQixXQUFXO0FBQUEsc0JBQ3hDLGlDQUFDLFNBQU0sTUFBSyxVQUFTLFVBQVEsUUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkI7QUFBQTtBQUFBLG9CQUgvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDLEtBQUs7QUFBQSxvQkFBTDtBQUFBLHNCQUNDLE9BQU07QUFBQSxzQkFDTixNQUFNLENBQUMsc0JBQXNCLFVBQVU7QUFBQSxzQkFDdkMsaUNBQUMsU0FBTSxNQUFLLFVBQVMsVUFBUSxRQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE2QjtBQUFBO0FBQUEsb0JBSC9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUMsS0FBSztBQUFBLG9CQUFMO0FBQUEsc0JBQ0MsT0FBTTtBQUFBLHNCQUNOLE1BQU0sQ0FBQyxzQkFBc0IsZ0JBQWdCO0FBQUEsc0JBQzdDLGlDQUFDLFNBQU0sTUFBSyxVQUFTLFVBQVEsUUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkI7QUFBQTtBQUFBLG9CQUgvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDLEtBQUs7QUFBQSxvQkFBTDtBQUFBLHNCQUNDLE9BQU07QUFBQSxzQkFDTixNQUFNLENBQUMsc0JBQXNCLG1CQUFtQjtBQUFBLHNCQUNoRCxpQ0FBQyxTQUFNLE1BQUssVUFBUyxVQUFRLFFBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTZCO0FBQUE7QUFBQSxvQkFIL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUlBO0FBQUEscUJBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBK0JBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGtDQUNiO0FBQUEseUNBQUMsUUFBRyxXQUFVLDhCQUE2QixpREFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBO0FBQUEsc0JBQUMsS0FBSztBQUFBLHNCQUFMO0FBQUEsd0JBQ0MsT0FBTTtBQUFBLHdCQUNOLE1BQU0sQ0FBQyx5QkFBeUIsUUFBUTtBQUFBLHdCQUN4QyxpQ0FBQyxTQUFNLE1BQUssVUFBUyxVQUFRLFFBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTZCO0FBQUE7QUFBQSxzQkFIL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUlBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQyxLQUFLO0FBQUEsc0JBQUw7QUFBQSx3QkFDQyxPQUFNO0FBQUEsd0JBQ04sTUFBTTtBQUFBLDBCQUNKO0FBQUEsMEJBQ0E7QUFBQSx3QkFBMkI7QUFBQSx3QkFFN0IsaUNBQUMsU0FBTSxNQUFLLFVBQVMsVUFBUSxRQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE2QjtBQUFBO0FBQUEsc0JBTi9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUMsS0FBSztBQUFBLHNCQUFMO0FBQUEsd0JBQ0MsT0FBTTtBQUFBLHdCQUNOLE1BQU0sQ0FBQyx5QkFBeUIsdUJBQXVCO0FBQUEsd0JBQ3ZELGlDQUFDLFNBQU0sTUFBSyxVQUFTLFVBQVEsUUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBNkI7QUFBQTtBQUFBLHNCQUgvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDLEtBQUs7QUFBQSxzQkFBTDtBQUFBLHdCQUNDLE9BQU07QUFBQSx3QkFDTixNQUFNLENBQUMseUJBQXlCLDBCQUEwQjtBQUFBLHdCQUMxRCxTQUFRO0FBQUEsd0JBQ1IsaUNBQUMsU0FBTSxNQUFLLFVBQVMsVUFBUSxRQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE2QjtBQUFBO0FBQUEsc0JBSi9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLHVCQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXlCQTtBQUFBLHFCQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQThCQTtBQUFBLG1CQWxFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1FQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDhCQUE2QixvQ0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQyxvQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE1BQUssd0JBQ2QsaUNBQUMsU0FBTSxNQUFLLFVBQVMsVUFBUSxRQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QixLQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFPQTtBQUFBLG1CQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwwQ0FDYixpQ0FBQyxRQUFHLFdBQVUseUNBQXdDLGdDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLGdCQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE1BQUssb0JBQ2IsV0FBQ0MsUUFBUSxFQUFFQyxLQUFLQyxPQUFPLE1BQ3RCLG1DQUNHRixpQkFBT3hIO0FBQUFBLGtCQUFJLENBQUMsRUFBRXBCLEtBQUt1QixNQUFNLEdBQUd3SCxVQUFVLE1BQ3JDO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUVDLFdBQVU7QUFBQSxzQkFDVjtBQUFBO0FBQUEsMEJBQUMsS0FBSztBQUFBLDBCQUFMO0FBQUEsNEJBQ0MsR0FBSUE7QUFBQUEsNEJBQ0osTUFBTSxDQUFDeEgsTUFBTSxNQUFNO0FBQUEsNEJBQ25CLE9BQU07QUFBQSw0QkFDTixpQ0FBQyxTQUFNLGFBQVksNEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQTJDO0FBQUE7QUFBQSwwQkFKN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUtBO0FBQUEsd0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsaURBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSw0QkFBQyxLQUFLO0FBQUEsNEJBQUw7QUFBQSw4QkFDQyxHQUFJd0g7QUFBQUEsOEJBQ0osU0FBUyxDQUFDQyxNQUFNO0FBQ2RBLGtDQUFFQyxlQUFlO0FBQ2pCRCxrQ0FBRUUsY0FBY0MsS0FBSztBQUFBLDhCQUN2QjtBQUFBLDhCQUNBLE1BQU0sQ0FBQzVILE1BQU0sT0FBTztBQUFBLDhCQUNwQixPQUFNO0FBQUEsOEJBQ04saUNBQUMsU0FBTSxNQUFLLFVBQVMsYUFBWSxrQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBK0M7QUFBQTtBQUFBLDRCQVJqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQVdBO0FBQUEsMEJBQ0E7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsTUFBSztBQUFBLDhCQUNMO0FBQUEsOEJBQ0EsTUFBTSx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUFlO0FBQUEsOEJBQ3JCLFNBQVMsTUFBTXVILE9BQU92SCxJQUFJO0FBQUE7QUFBQSw0QkFKNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUk4QjtBQUFBLDZCQWpCaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFtQkE7QUFBQTtBQUFBO0FBQUEsb0JBM0JLdkI7QUFBQUEsb0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkE2QkE7QUFBQSxnQkFDRCxLQWhDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlDQSxLQW5DSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXFDQTtBQUFBLG1CQTNDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTRDQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDBDQUNiLGlDQUFDLFFBQUcsV0FBVSx5Q0FBd0MsbUNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsZ0JBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyx1QkFDYixXQUFDNEksUUFBUSxFQUFFQyxLQUFLQyxPQUFPLE1BQ3RCLG1DQUNHRixpQkFBT3hIO0FBQUFBLGtCQUFJLENBQUMsRUFBRXBCLEtBQUt1QixNQUFNLEdBQUd3SCxVQUFVLE1BQ3JDO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUVDLFdBQVU7QUFBQSxzQkFDVjtBQUFBO0FBQUEsMEJBQUMsS0FBSztBQUFBLDBCQUFMO0FBQUEsNEJBQ0MsR0FBSUE7QUFBQUEsNEJBQ0osTUFBTSxDQUFDeEgsTUFBTSxNQUFNO0FBQUEsNEJBQ25CLE9BQU07QUFBQSw0QkFDTixpQ0FBQyxTQUFNLGFBQVksd0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQXVDO0FBQUE7QUFBQSwwQkFKekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUtBO0FBQUEsd0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsaURBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSw0QkFBQyxLQUFLO0FBQUEsNEJBQUw7QUFBQSw4QkFDQyxHQUFJd0g7QUFBQUEsOEJBQ0osU0FBUyxDQUFDQyxNQUFNO0FBQ2RBLGtDQUFFQyxlQUFlO0FBQ2pCRCxrQ0FBRUUsY0FBY0MsS0FBSztBQUFBLDhCQUN2QjtBQUFBLDhCQUNBLE1BQU0sQ0FBQzVILE1BQU0sT0FBTztBQUFBLDhCQUNwQixPQUFNO0FBQUEsOEJBQ04saUNBQUMsU0FBTSxNQUFLLFVBQVMsYUFBWSxrQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBK0M7QUFBQTtBQUFBLDRCQVJqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQVdBO0FBQUEsMEJBQ0E7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsTUFBSztBQUFBLDhCQUNMO0FBQUEsOEJBQ0EsTUFBTSx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUFlO0FBQUEsOEJBQ3JCLFNBQVMsTUFBTXVILE9BQU92SCxJQUFJO0FBQUE7QUFBQSw0QkFKNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUk4QjtBQUFBLDZCQWpCaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFtQkE7QUFBQTtBQUFBO0FBQUEsb0JBM0JLdkI7QUFBQUEsb0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkE2QkE7QUFBQSxnQkFDRCxLQWhDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlDQSxLQW5DSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXFDQTtBQUFBLG1CQTNDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTRDQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDBDQUNiLGlDQUFDLFFBQUcsV0FBVSx5Q0FBd0MscUNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsZ0JBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyx5QkFDYixXQUFDNEksUUFBUSxFQUFFRSxPQUFPLE1BQ2pCLG1DQUNHRixpQkFBT3hIO0FBQUFBLGtCQUFJLENBQUMsRUFBRXBCLEtBQUt1QixNQUFNLEdBQUd3SCxVQUFVLE1BQ3JDO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUVDLFdBQVU7QUFBQSxzQkFDVjtBQUFBO0FBQUEsMEJBQUMsS0FBSztBQUFBLDBCQUFMO0FBQUEsNEJBQ0MsR0FBSUE7QUFBQUEsNEJBQ0osTUFBTSxDQUFDeEgsTUFBTSxNQUFNO0FBQUEsNEJBQ25CLE9BQU07QUFBQSw0QkFDTixpQ0FBQyxTQUFNLGFBQVksMEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQXlDO0FBQUE7QUFBQSwwQkFKM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUtBO0FBQUEsd0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsaURBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSw0QkFBQyxLQUFLO0FBQUEsNEJBQUw7QUFBQSw4QkFDQyxHQUFJd0g7QUFBQUEsOEJBQ0osTUFBTSxDQUFDeEgsTUFBTSxPQUFPO0FBQUEsOEJBQ3BCLE9BQU07QUFBQSw4QkFDTjtBQUFBLGdDQUFDO0FBQUE7QUFBQSxrQ0FDQyxNQUFLO0FBQUEsa0NBQ0wsYUFBWTtBQUFBLGtDQUNaLEtBQUs7QUFBQTtBQUFBLGdDQUhQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFHUztBQUFBO0FBQUEsNEJBUFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FXQTtBQUFBLDBCQUNBO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLE1BQUs7QUFBQSw4QkFDTDtBQUFBLDhCQUNBLE1BQU0sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBZTtBQUFBLDhCQUNyQixTQUFTLE1BQU11SCxPQUFPdkgsSUFBSTtBQUFBO0FBQUEsNEJBSjVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFJOEI7QUFBQSw2QkFqQmhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBbUJBO0FBQUE7QUFBQTtBQUFBLG9CQTNCS3ZCO0FBQUFBLG9CQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBNkJBO0FBQUEsZ0JBQ0QsS0FoQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFpQ0EsS0FuQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFxQ0E7QUFBQSxtQkEzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE0Q0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSx5R0FDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSwwRUFBeUUsK0JBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsYUFFYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLDJDQUFDLFFBQUcsV0FBVSxvRUFBbUUsa0NBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQTtBQUFBLHdCQUFDLEtBQUs7QUFBQSx3QkFBTDtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxPQUNFLHVCQUFDLFVBQUssV0FBVSw2QkFBNEIsb0NBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSwwQkFFRixXQUFVO0FBQUEsMEJBQ1Y7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsTUFBSztBQUFBLDhCQUNMO0FBQUEsOEJBQ0EsV0FBVTtBQUFBLDhCQUNWLFFBQU87QUFBQTtBQUFBLDRCQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFJWTtBQUFBO0FBQUEsd0JBWmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQWNBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQyxLQUFLO0FBQUEsd0JBQUw7QUFBQSwwQkFDQyxPQUNFLHVCQUFDLFVBQUssV0FBVSw2QkFBNEIsaUNBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSwwQkFFRixXQUFVO0FBQUEsMEJBQ1Y7QUFBQTtBQUFBLDhCQUFDO0FBQUE7QUFBQSxnQ0FDQyxNQUFLO0FBQUEsZ0NBQ0wsT0FBT25FO0FBQUFBLGdDQUNQLFFBQU87QUFBQSxnQ0FDUCxXQUFVO0FBQUEsZ0NBQ1YsVUFBVSxDQUFDbU4sTUFBTTtBQUNmLHdDQUFNNUksUUFDSjRJLEVBQUV6SixPQUFPYSxVQUFVLEtBQUssSUFBSTZDLE9BQU8rRixFQUFFekosT0FBT2EsS0FBSztBQUNuRHRFLHNEQUFvQnNFLEtBQUs7QUFDekIsd0NBQU00RSxlQUNKM0gsV0FBVytMLGNBQWMsc0JBQXNCLEtBQy9DO0FBQ0Ysd0NBQU1DLG1CQUFtQnBHLE9BQU8rQixZQUFZLElBQUk1RTtBQUNoRC9DLDZDQUFXK0csZUFBZTtBQUFBLG9DQUN4QnpELGFBQWEwSTtBQUFBQSxrQ0FDZixDQUFDO0FBQUEsZ0NBQ0g7QUFBQSxnQ0FDQSxhQUFZO0FBQUE7QUFBQSw4QkFqQmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQWlCdUM7QUFBQSw0QkFFdkMsdUJBQUMsU0FBSSxXQUFVLHNHQUNiO0FBQUEscURBQUMsVUFBSyxXQUFVLDRCQUEyQixpQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBNEM7QUFBQSw4QkFDNUMsdUJBQUMsVUFBSztBQUFBO0FBQUEsZ0NBQzRDO0FBQUEsbUNBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBRUE7QUFBQSxpQ0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUtBO0FBQUE7QUFBQTtBQUFBLHdCQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBZ0NBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQyxLQUFLO0FBQUEsd0JBQUw7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsT0FDRSx1QkFBQyxVQUFLLFdBQVUsNkJBQTRCLDhCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsMEJBRUYsT0FBTztBQUFBLDRCQUNMO0FBQUEsOEJBQ0VuQixVQUFVO0FBQUEsOEJBQ1ZoTyxTQUFTO0FBQUEsNEJBQ1g7QUFBQSwwQkFBQztBQUFBLDBCQUVILFdBQVU7QUFBQSwwQkFDVjtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxNQUFLO0FBQUEsOEJBQ0wsUUFBTztBQUFBLDhCQUNQLFdBQVU7QUFBQSw4QkFDVixVQUFVLENBQUM4TyxNQUFNO0FBQ2Ysc0NBQU1oRSxlQUNKM0gsV0FBVytMLGNBQWMsc0JBQXNCLEtBQy9DO0FBQ0Ysc0NBQU1FLGdCQUFnQnJHLE9BQU8rRixFQUFFekosT0FBT2EsU0FBUyxDQUFDO0FBQ2hELHNDQUFNbUosZ0JBQWdCRCxnQkFBZ0J0RTtBQUN0Q2xKLG9EQUFvQnlOLGFBQWE7QUFBQSw4QkFDbkM7QUFBQTtBQUFBLDRCQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFXSTtBQUFBO0FBQUEsd0JBekJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkEyQkE7QUFBQSx5QkE1RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkE2RUE7QUFBQSx1QkFqRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFrRkE7QUFBQSxrQkFHQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSwyQ0FBQyxRQUFHLFdBQVUsb0VBQW1FLG1DQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUE7QUFBQSx3QkFBQyxLQUFLO0FBQUEsd0JBQUw7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsT0FDRSx1QkFBQyxVQUFLLFdBQVUsNkJBQTRCLDRCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsMEJBRUYsT0FBTztBQUFBLDRCQUNMO0FBQUEsOEJBQ0VyQixVQUFVO0FBQUEsOEJBQ1ZoTyxTQUFTO0FBQUEsNEJBQ1g7QUFBQSwwQkFBQztBQUFBLDBCQUVILFdBQVU7QUFBQSwwQkFDVjtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxhQUFZO0FBQUEsOEJBQ1osTUFBSztBQUFBLDhCQUNMLFNBQVM7QUFBQSxnQ0FDUCxFQUFFaUcsT0FBTyxRQUFRQyxPQUFPLE9BQU87QUFBQSxnQ0FDL0IsRUFBRUQsT0FBTyxnQkFBZ0JDLE9BQU8sYUFBYTtBQUFBLGdDQUM3QyxFQUFFRCxPQUFPLGlCQUFpQkMsT0FBTyxjQUFjO0FBQUEsZ0NBQy9DLEVBQUVELE9BQU8saUJBQWlCQyxPQUFPLGNBQWM7QUFBQSxnQ0FDL0MsRUFBRUQsT0FBTyxpQkFBaUJDLE9BQU8sY0FBYztBQUFBLGdDQUMvQyxFQUFFRCxPQUFPLGlCQUFpQkMsT0FBTyxnQkFBZ0I7QUFBQSxnQ0FDakQsRUFBRUQsT0FBTyxVQUFVQyxPQUFPLFNBQVM7QUFBQSxnQ0FDbkMsRUFBRUQsT0FBTyxrQkFBa0JDLE9BQU8saUJBQWlCO0FBQUEsOEJBQUM7QUFBQTtBQUFBLDRCQVh4RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBWUk7QUFBQTtBQUFBLHdCQTFCTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBNEJBO0FBQUEsc0JBRUMvQyxXQUFXK0wsY0FBYyxnQkFBZ0IsTUFBTSxVQUM5QztBQUFBLHdCQUFDLEtBQUs7QUFBQSx3QkFBTDtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxPQUNFLHVCQUFDLFVBQUssV0FBVSw2QkFBNEIsOEJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSwwQkFFRixPQUFPO0FBQUEsNEJBQ0w7QUFBQSw4QkFDRWxCLFVBQ0U3SyxXQUFXK0wsY0FBYyxnQkFBZ0IsTUFDekM7QUFBQSw4QkFDRmxQLFNBQVM7QUFBQSw0QkFDWDtBQUFBLDBCQUFDO0FBQUEsMEJBRUgsV0FBVTtBQUFBLDBCQUNWO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLGFBQVk7QUFBQSw4QkFDWixNQUFLO0FBQUEsOEJBQ0wsV0FBVTtBQUFBO0FBQUEsNEJBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUd1QjtBQUFBO0FBQUEsd0JBbkJ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBcUJBO0FBQUEsc0JBR0Y7QUFBQSx3QkFBQyxLQUFLO0FBQUEsd0JBQUw7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsT0FDRSx1QkFBQyxVQUFLLFdBQVUsNkJBQTRCLHdCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsMEJBRUYsT0FBTztBQUFBLDRCQUNMLEVBQUVnTyxVQUFVLE1BQU1oTyxTQUFTLHlCQUF5QjtBQUFBLDBCQUFDO0FBQUEsMEJBRXZELGVBQWUsQ0FBQ2tHLFdBQVc7QUFBQSw0QkFDekJBLE9BQU9BLFFBQVF4RixNQUFNd0YsS0FBSyxJQUFJO0FBQUEsMEJBQ2hDO0FBQUEsMEJBQ0EsbUJBQW1CLENBQUNvSixTQUNsQkEsT0FBT0EsS0FBS0MsT0FBTyxJQUFJO0FBQUEsMEJBRXpCLFdBQVU7QUFBQSwwQkFDVjtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxPQUFPLEVBQUVmLE9BQU8sT0FBTztBQUFBLDhCQUN2QixNQUFLO0FBQUEsOEJBQ0wsUUFBTztBQUFBLDhCQUNQLGNBQWMsQ0FBQ2dCLFlBQ2JBLFdBQVdBLFFBQVFDLFFBQVEvTyxNQUFNLEVBQUVzTCxNQUFNLEtBQUssQ0FBQztBQUFBO0FBQUEsNEJBTG5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFNRztBQUFBO0FBQUEsd0JBdkJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkF5QkE7QUFBQSx5QkFqRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFrRkE7QUFBQSx1QkF0RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF1RkE7QUFBQSxxQkE5S0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkErS0E7QUFBQSxtQkFwTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxTEE7QUFBQTtBQUFBO0FBQUEsVUFuaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQW9oQkE7QUFBQTtBQUFBLE1BeGlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF5aUJBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTTtBQUFBLFFBQ04sTUFBTW5KO0FBQUFBLFFBQ04sVUFBVSxNQUFNQyxtQkFBbUIsS0FBSztBQUFBLFFBQ3hDLFFBQVE7QUFBQSxVQUNOLHVCQUFDLFVBQW9CLFNBQVMsTUFBTUEsbUJBQW1CLEtBQUssR0FBRyxzQkFBbkQsVUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsTUFBSztBQUFBLGNBQ0w7QUFBQSxjQUNBLFNBQVNiO0FBQUFBLGNBQ1QsU0FBUyxNQUFNa0ksb0JBQW9CcEgsUUFBUTtBQUFBLGNBQUc7QUFBQTtBQUFBLFlBSjFDO0FBQUEsWUFETjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxRQUFTO0FBQUEsUUFFWCxpQ0FBQyxPQUFFLDBGQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBO0FBQUEsTUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBcUJBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FDRSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2IsaUNBQUMsVUFBSyxXQUFVLDBEQUF5RCx3Q0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsUUFFRixNQUFNSztBQUFBQSxRQUNOLFVBQVUsTUFBTUMsd0JBQXdCLEtBQUs7QUFBQSxRQUM3QyxPQUFPO0FBQUEsUUFDUCxRQUFRO0FBQUEsVUFDTix1QkFBQyxVQUFtQixTQUFTLE1BQU1BLHdCQUF3QixLQUFLLEdBQUcscUJBQXZELFNBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0FDLHNCQUFzQnFELFdBQVcsYUFDL0I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLE1BQUs7QUFBQSxjQUNMLE9BQU87QUFBQSxnQkFDTCtJLGlCQUFpQjtBQUFBLGdCQUNqQkMsYUFBYTtBQUFBLGdCQUNiQyxPQUFPO0FBQUEsY0FDVDtBQUFBLGNBQ0EsU0FBUyxNQUFNO0FBQ2JsRywyQkFBV3BHLHFCQUFxQjhELEdBQUc7QUFDbkMvRCx3Q0FBd0IsS0FBSztBQUFBLGNBQy9CO0FBQUEsY0FBRztBQUFBO0FBQUEsWUFWQztBQUFBLFlBRE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWFBO0FBQUEsUUFDRDtBQUFBLFFBRUgsT0FBTztBQUFBLFVBQ0x3TSxTQUFTO0FBQUEsVUFDVEMsV0FBVztBQUFBLFVBQ1hDLFdBQVc7QUFBQSxVQUNYTCxpQkFBaUI7QUFBQSxRQUNuQjtBQUFBLFFBQ0NwTSxpQ0FDQyx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxpQ0FBQyxhQUFRLFdBQVUsNERBQ2pCO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDREQUEyRCw2QkFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHVEQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFlBQU8sc0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBYztBQUFBLGdCQUFTO0FBQUEsZ0JBQUVBLHFCQUFxQnlHO0FBQUFBLGdCQUFjO0FBQUEsZ0JBQzNEekcscUJBQXFCdUc7QUFBQUEsbUJBRnhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxZQUFPLHFCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWE7QUFBQSxnQkFBVTtBQUFBLGdCQUN0QnhJLE9BQU9pQyxxQkFBcUIwTSxnQkFBZ0IsRUFBRXRLO0FBQUFBLGtCQUM3QztBQUFBLGdCQUNGO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFlBQU8sbUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBVztBQUFBLGdCQUFVO0FBQUEsZ0JBQ3BCckUsT0FBT2lDLHFCQUFxQjJNLGNBQWMsRUFDeEM1SixTQUFTLEdBQUcsS0FBSyxFQUNqQlgsT0FBTyxhQUFhO0FBQUEsbUJBSnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxpQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxlQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBLFVBRUEsdUJBQUMsYUFBUSxXQUFVLDREQUNqQjtBQUFBLG1DQUFDLFFBQUcsV0FBVSw0REFBMkQsa0NBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSx1REFDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxZQUFPLDJCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1CO0FBQUEsZ0JBQVU7QUFBQSxnQkFDNUJwQyxxQkFBcUI0TSxjQUFjO0FBQUEsbUJBRnRDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxZQUFPLDBCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtCO0FBQUEsZ0JBQVU7QUFBQSxnQkFDM0I1TSxxQkFBcUI2TSxhQUFhO0FBQUEsbUJBRnJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxZQUFPLHlCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlCO0FBQUEsZ0JBQVU7QUFBQSxnQkFDMUI3TSxxQkFBcUI4TSxZQUFZO0FBQUEsbUJBRnBDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxZQUFPLHdCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdCO0FBQUEsZ0JBQVU7QUFBQSxnQkFDekI5TSxxQkFBcUIrTSxnQkFBZ0I7QUFBQSxtQkFGeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFlBQU8sdUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZTtBQUFBLGdCQUFVO0FBQUEsZ0JBQ3hCL00scUJBQXFCZ04sZUFBZTtBQUFBLG1CQUZ2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsWUFBTyx5QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQjtBQUFBLGdCQUFVO0FBQUEsZ0JBQzFCaE4scUJBQXFCaU4sY0FBYztBQUFBLG1CQUZ0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsWUFBTywwQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQjtBQUFBLGdCQUFVO0FBQUEsZ0JBQzNCak4scUJBQXFCa04sYUFBYTtBQUFBLG1CQUZyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkJBO0FBQUEsZUFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQ0E7QUFBQSxVQUVBLHVCQUFDLGFBQVEsV0FBVSw0REFDakI7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsNERBQTJELGlEQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsdURBQ2I7QUFBQSxxQ0FBQyxTQUNDO0FBQUEsdUNBQUMsWUFBTyw2QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxQjtBQUFBLGdCQUFTO0FBQUEsZ0JBQzdCekg7QUFBQUEsa0JBQ0N6RixxQkFBcUI4Qix1QkFBdUJDLFVBQVU7QUFBQSxnQkFDeEQsRUFBRXlJLGVBQWUsT0FBTztBQUFBLG1CQUoxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsWUFBTywwQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQztBQUFBLGdCQUFTO0FBQUEsZ0JBQzFDL0U7QUFBQUEsa0JBQ0N6RixxQkFBcUI4Qix1QkFDakJHLDZCQUE2QjtBQUFBLGdCQUNuQyxFQUFFdUksZUFBZSxPQUFPO0FBQUEsbUJBTDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTUE7QUFBQSxjQUNBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxZQUFPLHNDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThCO0FBQUEsZ0JBQVM7QUFBQSxnQkFDdEMvRTtBQUFBQSxrQkFDQ3pGLHFCQUFxQjhCLHVCQUNqQkUseUJBQXlCO0FBQUEsZ0JBQy9CLEVBQUV3SSxlQUFlLE9BQU87QUFBQSxtQkFMMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFNQTtBQUFBLGNBQ0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFlBQU8seUNBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUM7QUFBQSxnQkFBUztBQUFBLGdCQUN6Qy9FO0FBQUFBLGtCQUNDekYscUJBQXFCOEIsdUJBQ2pCSSw0QkFBNEI7QUFBQSxnQkFDbEMsRUFBRXNJLGVBQWUsT0FBTztBQUFBLG1CQUwxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1BO0FBQUEsaUJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNEJBO0FBQUEsZUFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQ0E7QUFBQSxVQUVBLHVCQUFDLGFBQVEsV0FBVSw0REFDakI7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsNERBQTJELHdCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxRQUFHLFdBQVUsMkJBQ1gxQixpQkFBT3FFLFFBQVFuTixxQkFBcUJTLFlBQVksQ0FBQyxDQUFDLEVBQUVtRDtBQUFBQSxjQUNuRCxDQUFDLENBQUNwQixLQUFLNEssR0FBRyxNQUNSO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUVDLFdBQVU7QUFBQSxrQkFDVjtBQUFBLDJDQUFDLFVBQUssV0FBVSxjQUNiNUssY0FBSTZLLFFBQVEsTUFBTSxHQUFHLEtBRHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxVQUFLLFdBQVUsZUFBYztBQUFBO0FBQUEsc0JBRTNCNUgsT0FBTzJILEdBQUcsRUFBRTVDLGVBQWUsU0FBUztBQUFBLHdCQUNuQzhDLHVCQUF1QjtBQUFBLHdCQUN2QkMsdUJBQXVCO0FBQUEsc0JBQ3pCLENBQUM7QUFBQSx5QkFMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU1BO0FBQUE7QUFBQTtBQUFBLGdCQVhLL0s7QUFBQUEsZ0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWFBO0FBQUEsWUFFSixLQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1CQTtBQUFBLGVBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0JBO0FBQUEsVUFFQSx1QkFBQyxhQUFRLFdBQVUsNERBQ2pCO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDREQUEyRCwwQkFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLDJCQUNYc0csaUJBQU9xRSxRQUFRbk4scUJBQXFCa0IsY0FBYyxDQUFDLENBQUMsRUFBRTBDO0FBQUFBLGNBQ3JELENBQUMsQ0FBQ3BCLEtBQUs0SyxHQUFHLE1BQ1I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBRUMsV0FBVTtBQUFBLGtCQUNWO0FBQUEsMkNBQUMsVUFBSyxXQUFVLGNBQ2I1SyxjQUFJNkssUUFBUSxNQUFNLEdBQUcsS0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFVBQUssV0FBVSxlQUFjO0FBQUE7QUFBQSxzQkFFM0I1SCxPQUFPMkgsR0FBRyxFQUFFNUMsZUFBZSxTQUFTO0FBQUEsd0JBQ25DOEMsdUJBQXVCO0FBQUEsd0JBQ3ZCQyx1QkFBdUI7QUFBQSxzQkFDekIsQ0FBQztBQUFBLHlCQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTUE7QUFBQTtBQUFBO0FBQUEsZ0JBWEsvSztBQUFBQSxnQkFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBYUE7QUFBQSxZQUVKLEtBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbUJBO0FBQUEsZUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3QkE7QUFBQSxVQUVDeEMscUJBQXFCdUIscUJBQXFCZ0osU0FBUyxLQUNsRCx1QkFBQyxhQUFRLFdBQVUsNERBQ2pCO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDREQUEyRCxtQ0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLDJCQUNYdkssK0JBQXFCdUIsb0JBQW9CcUM7QUFBQUEsY0FBSSxDQUFDNEosS0FBS0MsTUFDbEQ7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBRUMsV0FBVTtBQUFBLGtCQUNWO0FBQUEsMkNBQUMsVUFBTUQsY0FBSXpKLFFBQVEsYUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkI7QUFBQSxvQkFDN0IsdUJBQUMsVUFBSyxXQUFVLGVBQWM7QUFBQTtBQUFBLHNCQUUzQjBCLE9BQU8rSCxJQUFJNUssS0FBSyxFQUFFNEgsZUFBZSxTQUFTO0FBQUEsd0JBQ3pDOEMsdUJBQXVCO0FBQUEsd0JBQ3ZCQyx1QkFBdUI7QUFBQSxzQkFDekIsQ0FBQztBQUFBLHlCQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTUE7QUFBQTtBQUFBO0FBQUEsZ0JBVEtFO0FBQUFBLGdCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FXQTtBQUFBLFlBQ0QsS0FkSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWVBO0FBQUEsZUFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxVQUdEek4scUJBQXFCd0IsdUJBQXVCK0ksU0FBUyxLQUNwRCx1QkFBQyxhQUFRLFdBQVUsNERBQ2pCO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDREQUEyRCxxQ0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLDJCQUNYdkssK0JBQXFCd0Isc0JBQXNCb0M7QUFBQUEsY0FDMUMsQ0FBQzhKLEtBQUtELE1BQ0o7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBRUMsV0FBVTtBQUFBLGtCQUNWO0FBQUEsMkNBQUMsVUFBTUMsY0FBSTNKLFFBQVEsZUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0I7QUFBQSxvQkFDL0IsdUJBQUMsVUFBSyxXQUFVLDRCQUEyQjtBQUFBO0FBQUEsc0JBRXhDMEIsT0FBT2lJLElBQUk5SyxLQUFLLEVBQUU0SCxlQUFlLFNBQVM7QUFBQSx3QkFDekM4Qyx1QkFBdUI7QUFBQSx3QkFDdkJDLHVCQUF1QjtBQUFBLHNCQUN6QixDQUFDO0FBQUEseUJBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFNQTtBQUFBO0FBQUE7QUFBQSxnQkFUS0U7QUFBQUEsZ0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVdBO0FBQUEsWUFFSixLQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLGVBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0JBO0FBQUEsVUFFRHpOLHFCQUFxQnlCLGtCQUFrQjhJLFNBQVMsS0FDL0MsdUJBQUMsYUFBUSxXQUFVLDREQUNqQjtBQUFBLG1DQUFDLFFBQUcsV0FBVSw0REFBMkQsZ0NBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSwyQkFDWHZLLCtCQUFxQnlCLGlCQUFpQm1DO0FBQUFBLGNBQUksQ0FBQzRKLEtBQUtDLE1BQy9DO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUVDLFdBQVU7QUFBQSxrQkFDVjtBQUFBLDJDQUFDLFVBQU1ELGNBQUl6SixRQUFRLHFCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFxQztBQUFBLG9CQUNyQyx1QkFBQyxVQUFLLFdBQVUsZUFBYztBQUFBO0FBQUEsc0JBRTNCMEIsT0FBTytILElBQUk1SyxLQUFLLEVBQUU0SCxlQUFlLFNBQVM7QUFBQSx3QkFDekM4Qyx1QkFBdUI7QUFBQSx3QkFDdkJDLHVCQUF1QjtBQUFBLHNCQUN6QixDQUFDO0FBQUEseUJBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFNQTtBQUFBO0FBQUE7QUFBQSxnQkFUS0U7QUFBQUEsZ0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVdBO0FBQUEsWUFDRCxLQWRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxlQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CQTtBQUFBLFVBRUR6TixxQkFBcUIwQix5QkFBeUIsS0FDN0MsdUJBQUMsYUFBUSxXQUFVLDREQUNqQjtBQUFBLG1DQUFDLFFBQUcsV0FBVSw0REFBMkQsb0NBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSw2QkFBNEIscUNBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVcsZUFBZTFCLHFCQUFxQjBCLHVCQUF1QixJQUNsRSxtQkFDQSxjQUFjO0FBQUEsa0JBQ1o7QUFBQTtBQUFBLG9CQUVMaU0sS0FBS0M7QUFBQUEsc0JBQ0o1TixxQkFBcUIwQjtBQUFBQSxvQkFDdkIsRUFBRThJLGVBQWUsU0FBUztBQUFBLHNCQUN4QjhDLHVCQUF1QjtBQUFBLHNCQUN2QkMsdUJBQXVCO0FBQUEsb0JBQ3pCLENBQUM7QUFBQSxvQkFDQXZOLHFCQUFxQjBCLHVCQUF1QixJQUN6QyxhQUNBO0FBQUE7QUFBQTtBQUFBLGdCQWROO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWVBO0FBQUEsaUJBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0JBO0FBQUEsZUF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5QkE7QUFBQSxVQUVGLHVCQUFDLGFBQVEsV0FBVSw0RkFDakI7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsNERBQTJELCtCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSx1Q0FBQyxVQUFLLHVDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZCO0FBQUEsZ0JBQVE7QUFBQSxnQkFDckMsdUJBQUMsVUFBSztBQUFBO0FBQUEsa0JBRUgrRDtBQUFBQSxvQkFDQ3pGLHNCQUFzQjJHLG9CQUNsQmtIO0FBQUFBLGtCQUNOLEVBQUVyRCxlQUFlLFNBQVM7QUFBQSxvQkFDeEI4Qyx1QkFBdUI7QUFBQSxvQkFDdkJDLHVCQUF1QjtBQUFBLGtCQUN6QixDQUFDO0FBQUEscUJBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFTQTtBQUFBLG1CQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWUE7QUFBQSxjQUNDdk4scUJBQXFCeUIsa0JBQWtCOEksU0FBUyxLQUMvQyx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSx1Q0FBQyxVQUFLLGlDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVCO0FBQUEsZ0JBQVE7QUFBQSxnQkFDL0IsdUJBQUMsVUFBSztBQUFBO0FBQUEsa0JBRUg5RTtBQUFBQSxvQkFDQ3pGLHFCQUFxQnlCLGlCQUFpQnVIO0FBQUFBLHNCQUNwQyxDQUFDQyxLQUFLNkUsTUFBTTdFLE1BQU14RCxPQUFPcUksRUFBRWxMLEtBQUs7QUFBQSxzQkFDaEM7QUFBQSxvQkFDRjtBQUFBLGtCQUNGLEVBQUU0SCxlQUFlLFNBQVM7QUFBQSxvQkFDeEI4Qyx1QkFBdUI7QUFBQSxvQkFDdkJDLHVCQUF1QjtBQUFBLGtCQUN6QixDQUFDO0FBQUEscUJBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFXQTtBQUFBLG1CQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxjQUVEdk4scUJBQXFCdUIscUJBQXFCZ0osU0FBUyxLQUNsRCx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSx1Q0FBQyxVQUFLLG9DQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBCO0FBQUEsZ0JBQVE7QUFBQSxnQkFDbEMsdUJBQUMsVUFBSztBQUFBO0FBQUEsa0JBRUg5RTtBQUFBQSxvQkFDQ3pGLHFCQUFxQnVCLG9CQUFvQnlIO0FBQUFBLHNCQUN2QyxDQUFDQyxLQUFLNkUsTUFBTTdFLE1BQU14RCxPQUFPcUksRUFBRWxMLEtBQUs7QUFBQSxzQkFDaEM7QUFBQSxvQkFDRjtBQUFBLGtCQUNGLEVBQUU0SCxlQUFlLFNBQVM7QUFBQSxvQkFDeEI4Qyx1QkFBdUI7QUFBQSxvQkFDdkJDLHVCQUF1QjtBQUFBLGtCQUN6QixDQUFDO0FBQUEscUJBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFXQTtBQUFBLG1CQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxjQUVGLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLHVDQUFDLFVBQUssc0NBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEI7QUFBQSxnQkFBUTtBQUFBLGdCQUNwQyx1QkFBQyxVQUFLO0FBQUE7QUFBQSxrQkFFSDlIO0FBQUFBLG9CQUNDekYscUJBQXFCK047QUFBQUEsa0JBQ3ZCLEVBQUV2RCxlQUFlLFNBQVM7QUFBQSxvQkFDeEI4Qyx1QkFBdUI7QUFBQSxvQkFDdkJDLHVCQUF1QjtBQUFBLGtCQUN6QixDQUFDO0FBQUEscUJBUEg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFRQTtBQUFBLG1CQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxjQUNDdk4sc0JBQXNCd0IsdUJBQXVCK0ksU0FBUyxLQUNyRCx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSx1Q0FBQyxVQUFLLHNDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRCO0FBQUEsZ0JBQVE7QUFBQSxnQkFDcEMsdUJBQUMsVUFBSyxXQUFVLGdCQUFlO0FBQUE7QUFBQSxrQkFFNUI5RTtBQUFBQSxvQkFDQ3pGLHFCQUFxQndCLHNCQUFzQndIO0FBQUFBLHNCQUN6QyxDQUFDQyxLQUFLTSxNQUFNTixNQUFNeEQsT0FBTzhELEVBQUUzRyxLQUFLO0FBQUEsc0JBQ2hDO0FBQUEsb0JBQ0Y7QUFBQSxrQkFDRixFQUFFNEgsZUFBZSxTQUFTO0FBQUEsb0JBQ3hCOEMsdUJBQXVCO0FBQUEsb0JBQ3ZCQyx1QkFBdUI7QUFBQSxrQkFDekIsQ0FBQztBQUFBLHFCQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBV0E7QUFBQSxtQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWNBO0FBQUEsY0FFRHZOLHFCQUFxQjBCLHlCQUF5QixLQUM3Qyx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSx1Q0FBQyxVQUFLLHFDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJCO0FBQUEsZ0JBQzNCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQ0UxQixxQkFBcUIwQix1QkFBdUIsSUFDeEMsbUJBQ0E7QUFBQSxvQkFDSjtBQUFBO0FBQUEsc0JBRURpTSxLQUFLQztBQUFBQSx3QkFDSjVOLHFCQUFxQjBCO0FBQUFBLHNCQUN2QixFQUFFOEksZUFBZSxTQUFTO0FBQUEsd0JBQ3hCOEMsdUJBQXVCO0FBQUEsd0JBQ3ZCQyx1QkFBdUI7QUFBQSxzQkFDekIsQ0FBQztBQUFBLHNCQUNBdk4scUJBQXFCMEIsdUJBQXVCLElBQ3pDLEtBQ0E7QUFBQTtBQUFBO0FBQUEsa0JBZk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWdCQTtBQUFBLG1CQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1CQTtBQUFBLGNBRUYsdUJBQUMsU0FBSSxXQUFVLDJFQUNiO0FBQUEsdUNBQUMsVUFBSyw0QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQjtBQUFBLGdCQUNsQix1QkFBQyxVQUFLO0FBQUE7QUFBQSxrQkFFSCtELE9BQU96RixxQkFBcUJnTyxXQUFXLEVBQUV4RDtBQUFBQSxvQkFDeEM7QUFBQSxvQkFDQTtBQUFBLHNCQUNFOEMsdUJBQXVCO0FBQUEsc0JBQ3ZCQyx1QkFBdUI7QUFBQSxvQkFDekI7QUFBQSxrQkFDRjtBQUFBLHFCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBU0E7QUFBQSxtQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSx1Q0FBQyxVQUFLLDRCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtCO0FBQUEsZ0JBQVE7QUFBQSxnQkFDMUIsdUJBQUMsVUFBSztBQUFBO0FBQUEsa0JBRUg5SCxPQUFPekYscUJBQXFCbUQsV0FBVyxFQUFFcUg7QUFBQUEsb0JBQ3hDO0FBQUEsb0JBQ0E7QUFBQSxzQkFDRThDLHVCQUF1QjtBQUFBLHNCQUN2QkMsdUJBQXVCO0FBQUEsb0JBQ3pCO0FBQUEsa0JBQ0Y7QUFBQSxxQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVNBO0FBQUEsbUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsdUNBQUMsVUFBSyxrQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3QjtBQUFBLGdCQUN4QjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUNFOUgsT0FBT3pGLHFCQUFxQjJILGlCQUFpQixJQUFJLElBQzdDLDJCQUNBO0FBQUEsb0JBQ0o7QUFBQTtBQUFBLHNCQUVEbEM7QUFBQUEsd0JBQ0N6RixxQkFBcUIySDtBQUFBQSxzQkFDdkIsRUFBRTZDLGVBQWUsU0FBUztBQUFBLHdCQUN4QjhDLHVCQUF1QjtBQUFBLHdCQUN2QkMsdUJBQXVCO0FBQUEsc0JBQ3pCLENBQUM7QUFBQTtBQUFBO0FBQUEsa0JBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWFBO0FBQUEsbUJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLHVDQUFDLFVBQUssdUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBYTtBQUFBLGdCQUNiO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQ0V2TixxQkFBcUJxRCxXQUFXLFNBQzVCLDZCQUNBO0FBQUEsb0JBRUxyRCwrQkFBcUJxRDtBQUFBQTtBQUFBQSxrQkFOeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BO0FBQUEsbUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGNBQ0NyRCxxQkFBcUI0QixrQkFDcEIsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsdUNBQUMsVUFBSywrQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxQjtBQUFBLGdCQUFRO0FBQUEsZ0JBQzdCLHVCQUFDLFVBQU01QiwrQkFBcUI0QixrQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkM7QUFBQSxtQkFGN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBRUYsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsdUNBQUMsVUFBSywrQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxQjtBQUFBLGdCQUFRO0FBQUEsZ0JBQzdCLHVCQUFDLFVBQU01QiwrQkFBcUIyQixrQkFBa0IsU0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0Q7QUFBQSxtQkFGdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQWxLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1LQTtBQUFBLGVBdktGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0tBO0FBQUEsYUFoYUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlhQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx1REFBc0QseUNBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBO0FBQUEsTUE1Y0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBOGNBO0FBQUEsT0FybENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzbENBLEtBdmxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd2xDQTtBQUVKO0FBQUV4RCxHQXBuRElELGVBQWE7QUFBQSxVQUNBWCxhQVlGaEIsS0FBS3FELFNBQ0NyRCxLQUFLcUQsT0FBTztBQUFBO0FBQUFxTyxLQWQ3Qi9QO0FBcW5ETixlQUFlQTtBQUFjLElBQUErUDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiRGF0ZVBpY2tlciIsIkRyYXdlciIsIkRyb3Bkb3duIiwiTW9kYWwiLCJJbnB1dCIsIkZvcm0iLCJTZWxlY3QiLCJCdXR0b24iLCJtZXNzYWdlIiwiUG9wY29uZmlybSIsIkVtcHR5IiwiTmF2YmFyIiwiU2lkZWJhciIsIkRhdGFUYWJsZSIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlTWVtbyIsIkFQSSIsImRheWpzIiwiSW9NZE1vcmUiLCJMaW5rIiwidXNlTmF2aWdhdGUiLCJQbHVzT3V0bGluZWQiLCJEZWxldGVPdXRsaW5lZCIsIk1kT3V0bGluZU1hbiIsIlJpTW9uZXlSdXBlZUNpcmNsZUZpbGwiLCJGbGV4IiwiU3BpbiIsIkxvYWRpbmdPdXRsaW5lZCIsIm1vbWVudCIsIkJyZWFkY3J1bWIiLCJVc2VyIiwiU2FsYXJ5UGF5bWVudCIsIl9zIiwibmF2aWdhdGUiLCJhZGp1c3RtZW50QW1vdW50Iiwic2V0QWRqdXN0bWVudEFtb3VudCIsImlzT3BlblVwZGF0ZU1vZGFsIiwic2V0SXNPcGVuVXBkYXRlTW9kYWwiLCJ1cGRhdGVMb2FkaW5nIiwic2V0VXBkYXRlTG9hZGluZyIsImRlbGV0ZUxvYWRpbmciLCJzZXREZWxldGVMb2FkaW5nIiwiZW1wbG95ZWVzIiwic2V0RW1wbG95ZWVzIiwiZW1wbG95ZWVEZXRhaWxzIiwic2V0RW1wbG95ZWVEZXRhaWxzIiwiYWxsU2FsYXJ5UGF5bWVudHMiLCJzZXRBbGxTYWxhcnlwYXltZW50cyIsImVtcGxveWVlRGV0YWlsc0xvYWRpbmciLCJzZXRFbXBsb3llZURldGFpbHNMb2FkaW5nIiwiY3VycmVudFNhbGFyeUlkIiwic2V0Q3VycmVudFNhbGFyeUlkIiwiZGVsZXRlTW9kYWxPcGVuIiwic2V0RGVsZXRlTW9kYWxPcGVuIiwiZGVsZXRlSWQiLCJzZXREZWxldGVJZCIsImZvcm0iLCJ1c2VGb3JtIiwidXBkYXRlRm9ybSIsImFscmVhZHlQYWlkTW9kYWxPcGVuIiwic2V0QWxyZWFkeVBhaWRNb2RhbE9wZW4iLCJleGlzdGluZ1NhbGFyeVJlY29yZCIsInNldEV4aXN0aW5nU2FsYXJ5UmVjb3JkIiwiZGF0YVRhYmxlTG9hZGluZyIsInNldERhdGFUYWJsZUxvYWRpbmciLCJ1cGRhdGVGb3JtRGF0YSIsInNldFVwZGF0ZUZvcm1EYXRhIiwiZW1wbG95ZWVfaWQiLCJtb250aCIsInllYXIiLCJlYXJuaW5ncyIsImJhc2ljIiwiaHJhIiwidHJhdmVsX2FsbG93YW5jZSIsIm1lZGljYWxfYWxsb3dhbmNlIiwiYmFza2V0X29mX2JlbmlmaXRzIiwicGVyZm9ybWFuY2VfYm9udXMiLCJvdGhlcl9hbGxvd2FuY2VzIiwiY29udmV5YW5jZSIsImRlZHVjdGlvbnMiLCJpbmNvbWVfdGF4IiwiZXNpIiwiZXBmIiwicHJvZmVzc2lvbmFsX3RheCIsImFkZGl0aW9uYWxfcGF5bWVudHMiLCJhZGRpdGlvbmFsX2RlZHVjdGlvbnMiLCJhZHZhbmNlX3BheW1lbnRzIiwiY2FsY3VsYXRlZF9pbmNlbnRpdmUiLCJwYXltZW50X21ldGhvZCIsInRyYW5zYWN0aW9uX2lkIiwiaXNfc2FsYXJ5X3BhaWQiLCJtb250aGx5X2J1c2luZXNzX2luZm8iLCJ0YXJnZXQiLCJ0b3RhbF9idXNpbmVzc19jbG9zZWQiLCJwcmV2aW91c19yZW1haW5pbmdfdGFyZ2V0IiwiY3VycmVudF9yZW1haW5pbmdfdGFyZ2V0IiwidGhpc1llYXIiLCJmb3JtYXQiLCJlYXJuaW5nc09iamVjdCIsImRlZHVjdGlvbnNPYmplY3QiLCJjb2x1bW5zIiwia2V5IiwiaGVhZGVyIiwibW9udGhzIiwibGFiZWwiLCJ2YWx1ZSIsImRpc2FibGVkIiwicHJldmlvdXNNb250aCIsInN1YnRyYWN0IiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInRvdGFsX3NhbGFyeV9wYXlhYmxlIiwicGFpZF9hbW91bnQiLCJpbmNlbnRpdmUiLCJzdGF0dXMiLCJmZXRjaEVtcGxveWVlcyIsInJlc3BvbnNlRGF0YSIsImdldCIsImZpbHRlcmVkRW1wbG95ZWUiLCJkYXRhIiwiZW1wbG95ZWUiLCJtYXAiLCJlbXAiLCJfaWQiLCJuYW1lIiwicGhvbmVfbnVtYmVyIiwiZXJyb3IiLCJnZXRTYWxhcnlCeUlkIiwiaWQiLCJyZXNwb25zZSIsImNvbnNvbGUiLCJmZXRjaEVtcGxveWVlVGFyZ2V0IiwiZW1wbG95ZWVJZCIsInN0YXJ0X2RhdGUiLCJlbmRfZGF0ZSIsInBhcmFtcyIsInRvdGFsX3RhcmdldCIsImVyciIsImZldGNoRW1wbG95ZWVJbmNlbnRpdmUiLCJpbmNlbnRpdmVTdW1tYXJ5IiwidG90YWxfaW5jZW50aXZlX3ZhbHVlIiwiZ2V0VmFsaWRNb250aHMiLCJqb2luaW5nRGF0ZVN0ciIsInNlbGVjdGVkWWVhciIsIm0iLCJqb2luaW5nIiwidG9kYXkiLCJqb2luWWVhciIsImN1cnJlbnRZZWFyIiwic2VsZWN0ZWRZZWFyTnVtIiwiTnVtYmVyIiwiaW5kZXgiLCJpc0JlZm9yZUpvaW5pbmciLCJpc0FmdGVyVG9kYXkiLCJqb2luaW5nX2RhdGUiLCJ2YWxpZE1vbnRocyIsImN1cnJlbnRNb250aFZhbGlkIiwic29tZSIsImZpcnN0VmFsaWQiLCJmaW5kIiwicHJldiIsImhhbmRsZUVkaXQiLCJzYWxhcnlEYXRhIiwieWVhckFzRGF5anMiLCJzYWxhcnlfeWVhciIsInBhaWRBbW91bnQiLCJzYWxhcnlfbW9udGgiLCJwYXlfZGF0ZSIsImF0dGVuZGFuY2VfZGV0YWlscyIsInNldEZpZWxkc1ZhbHVlIiwiaGFuZGxlRGVsZXRlQ29uZmlybSIsImRlbGV0ZSIsInN1Y2Nlc3MiLCJnZXRBbGxTYWxhcnkiLCJoYW5kbGVVcGRhdGVDaGFuZ2UiLCJjaGFuZ2VkVmFsdWVzIiwiYWxsVmFsdWVzIiwiaXNEYXlqcyIsImhhbmRsZVVwZGF0ZVN1Ym1pdCIsImZvcm1WYWx1ZXMiLCJnZXRGaWVsZHNWYWx1ZSIsInRvdGFsUGF5YWJsZSIsImFkakFtb3VudCIsImNvbXB1dGVkUGFpZEFtb3VudCIsInJlbWFpbmluZ19iYWxhbmNlIiwidXBkYXRlRGF0YSIsInB1dCIsImhhbmRsZVByaW50Iiwic2FsYXJ5UGF5bWVudElkIiwiZHJvcERvd25JdGVtcyIsInNhbGFyeVBheW1lbnQiLCJkcm9wRG93bkl0ZW1MaXN0IiwiZmV0Y2hTYWxhcnlEZXRhaWxzIiwidXBkYXRlZEVhcm5pbmdzIiwic2FsYXJ5IiwidXBkYXRlZERlZHVjdGlvbnMiLCJsb2FkVGFyZ2V0QW5kSW5jZW50aXZlIiwibW9udGhJbmRleCIsInN0YXJ0T2YiLCJlbmRPZiIsInRhcmdldFZhbHVlIiwiaW5jZW50aXZlVmFsdWUiLCJ1cGRhdGVUb3RhbEVhcm5pbmdzIiwiT2JqZWN0IiwidmFsdWVzIiwicmVkdWNlIiwic3VtIiwidiIsInVwZGF0ZVRvdGFsRGVkdWN0aW9ucyIsImFkZGl0aW9uYWwiLCJiYXNlIiwiZXh0cmEiLCJkIiwiZmlsdGVyZWREYXRhIiwic2lObyIsImVtcGxveWVlTmFtZSIsImVtcGxveWVlQ29kZSIsInNhbGFyeU1vbnRoIiwic2FsYXJ5WWVhciIsIm5ldFBheWFibGUiLCJhY3Rpb24iLCJpdGVtcyIsIk5BVl9MSU5LUyIsInRvIiwiaWNvbiIsInRvdGFsUGF5YWJsZVN1bSIsIml0ZW0iLCJsaW5rIiwibGVuZ3RoIiwidG9Mb2NhbGVTdHJpbmciLCJmb250U2l6ZSIsInJlcXVpcmVkIiwiaW5wdXQiLCJvcHRpb24iLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwib3B0aW9uQSIsIm9wdGlvbkIiLCJsb2NhbGVDb21wYXJlIiwid2lkdGgiLCJ0b0ZpeGVkIiwiZmllbGRzIiwiYWRkIiwicmVtb3ZlIiwicmVzdEZpZWxkIiwiZSIsInByZXZlbnREZWZhdWx0IiwiY3VycmVudFRhcmdldCIsImJsdXIiLCJnZXRGaWVsZFZhbHVlIiwibmV3UGF5YWJsZUFtb3VudCIsIm5ld1BhaWRBbW91bnQiLCJuZXdBZGp1c3RtZW50IiwiZGF0ZSIsInRvRGF0ZSIsImN1cnJlbnQiLCJpc0FmdGVyIiwiYmFja2dyb3VuZENvbG9yIiwiYm9yZGVyQ29sb3IiLCJjb2xvciIsInBhZGRpbmciLCJtYXhIZWlnaHQiLCJvdmVyZmxvd1kiLCJzYWxhcnlfZnJvbV9kYXRlIiwic2FsYXJ5X3RvX2RhdGUiLCJ0b3RhbF9kYXlzIiwicGFpZF9kYXlzIiwibG9wX2RheXMiLCJwcmVzZW50X2RheXMiLCJhYnNlbnRfZGF5cyIsImxlYXZlX2RheXMiLCJoYWxmX2RheXMiLCJlbnRyaWVzIiwidmFsIiwicmVwbGFjZSIsIm1pbmltdW1GcmFjdGlvbkRpZ2l0cyIsIm1heGltdW1GcmFjdGlvbkRpZ2l0cyIsInBheSIsImkiLCJkZWQiLCJNYXRoIiwiYWJzIiwiY2FsY3VsYXRlZF9zYWxhcnkiLCJwIiwidG90YWxfZGVkdWN0aW9ucyIsIm5ldF9wYXlhYmxlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2FsYXJ5UGF5bWVudC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICBEYXRlUGlja2VyLFxyXG4gIERyYXdlcixcclxuICBEcm9wZG93bixcclxuICBNb2RhbCxcclxuICBJbnB1dCxcclxuICBGb3JtLFxyXG4gIFNlbGVjdCxcclxuICBCdXR0b24sXHJcbiAgbWVzc2FnZSxcclxuICBQb3Bjb25maXJtLFxyXG4gIEVtcHR5LFxyXG59IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlTWVtbyB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgQVBJIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBkYXlqcyBmcm9tIFwiZGF5anNcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBQbHVzT3V0bGluZWQsIERlbGV0ZU91dGxpbmVkIH0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcbmltcG9ydCB7IE1kT3V0bGluZU1hbiB9IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5pbXBvcnQgeyBSaU1vbmV5UnVwZWVDaXJjbGVGaWxsIH0gZnJvbSBcInJlYWN0LWljb25zL3JpXCI7XHJcbmltcG9ydCB7IEZsZXgsIFNwaW4gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBMb2FkaW5nT3V0bGluZWQgfSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuaW1wb3J0IG1vbWVudCBmcm9tIFwibW9tZW50XCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuaW1wb3J0IHsgVXNlciB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuY29uc3QgU2FsYXJ5UGF5bWVudCA9ICgpID0+IHtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbiAgY29uc3QgW2FkanVzdG1lbnRBbW91bnQsIHNldEFkanVzdG1lbnRBbW91bnRdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW2lzT3BlblVwZGF0ZU1vZGFsLCBzZXRJc09wZW5VcGRhdGVNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3VwZGF0ZUxvYWRpbmcsIHNldFVwZGF0ZUxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtkZWxldGVMb2FkaW5nLCBzZXREZWxldGVMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtlbXBsb3llZURldGFpbHMsIHNldEVtcGxveWVlRGV0YWlsc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2FsbFNhbGFyeVBheW1lbnRzLCBzZXRBbGxTYWxhcnlwYXltZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2VtcGxveWVlRGV0YWlsc0xvYWRpbmcsIHNldEVtcGxveWVlRGV0YWlsc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50U2FsYXJ5SWQsIHNldEN1cnJlbnRTYWxhcnlJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZGVsZXRlTW9kYWxPcGVuLCBzZXREZWxldGVNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtkZWxldGVJZCwgc2V0RGVsZXRlSWRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2Zvcm1dID0gRm9ybS51c2VGb3JtKCk7XHJcbiAgY29uc3QgW3VwZGF0ZUZvcm1dID0gRm9ybS51c2VGb3JtKCk7XHJcbiAgY29uc3QgW2FscmVhZHlQYWlkTW9kYWxPcGVuLCBzZXRBbHJlYWR5UGFpZE1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2V4aXN0aW5nU2FsYXJ5UmVjb3JkLCBzZXRFeGlzdGluZ1NhbGFyeVJlY29yZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZGF0YVRhYmxlTG9hZGluZywgc2V0RGF0YVRhYmxlTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3VwZGF0ZUZvcm1EYXRhLCBzZXRVcGRhdGVGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBlbXBsb3llZV9pZDogXCJcIixcclxuICAgIG1vbnRoOiBcIlwiLFxyXG4gICAgeWVhcjogXCJcIixcclxuICAgIGVhcm5pbmdzOiB7XHJcbiAgICAgIGJhc2ljOiAwLFxyXG4gICAgICBocmE6IDAsXHJcbiAgICAgIHRyYXZlbF9hbGxvd2FuY2U6IDAsXHJcbiAgICAgIG1lZGljYWxfYWxsb3dhbmNlOiAwLFxyXG4gICAgICBiYXNrZXRfb2ZfYmVuaWZpdHM6IDAsXHJcbiAgICAgIHBlcmZvcm1hbmNlX2JvbnVzOiAwLFxyXG4gICAgICBvdGhlcl9hbGxvd2FuY2VzOiAwLFxyXG4gICAgICBjb252ZXlhbmNlOiAwLFxyXG4gICAgfSxcclxuICAgIGRlZHVjdGlvbnM6IHtcclxuICAgICAgaW5jb21lX3RheDogMCxcclxuICAgICAgZXNpOiAwLFxyXG4gICAgICBlcGY6IDAsXHJcbiAgICAgIHByb2Zlc3Npb25hbF90YXg6IDAsXHJcbiAgICB9LFxyXG4gICAgYWRkaXRpb25hbF9wYXltZW50czogW10sXHJcbiAgICBhZGRpdGlvbmFsX2RlZHVjdGlvbnM6IFtdLFxyXG4gICAgYWR2YW5jZV9wYXltZW50czogW10sXHJcbiAgICBjYWxjdWxhdGVkX2luY2VudGl2ZTogMCxcclxuICAgIHBheW1lbnRfbWV0aG9kOiBcIkNhc2hcIixcclxuICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgaXNfc2FsYXJ5X3BhaWQ6IHRydWUsXHJcbiAgICBtb250aGx5X2J1c2luZXNzX2luZm86IHtcclxuICAgICAgdGFyZ2V0OiAwLFxyXG4gICAgICB0b3RhbF9idXNpbmVzc19jbG9zZWQ6IDAsXHJcbiAgICAgIHByZXZpb3VzX3JlbWFpbmluZ190YXJnZXQ6IDAsXHJcbiAgICAgIGN1cnJlbnRfcmVtYWluaW5nX3RhcmdldDogMCxcclxuICAgIH0sXHJcbiAgfSk7XHJcbiAgY29uc3QgdGhpc1llYXIgPSBkYXlqcygpLmZvcm1hdChcIllZWVlcIik7XHJcbiAgY29uc3QgZWFybmluZ3NPYmplY3QgPSB7XHJcbiAgICBiYXNpYzogMCxcclxuICAgIGhyYTogMCxcclxuICAgIHRyYXZlbF9hbGxvd2FuY2U6IDAsXHJcbiAgICBtZWRpY2FsX2FsbG93YW5jZTogMCxcclxuICAgIGJhc2tldF9vZl9iZW5pZml0czogMCxcclxuICAgIHBlcmZvcm1hbmNlX2JvbnVzOiAwLFxyXG4gICAgb3RoZXJfYWxsb3dhbmNlczogMCxcclxuICAgIGNvbnZleWFuY2U6IDAsXHJcbiAgfTtcclxuICBjb25zdCBkZWR1Y3Rpb25zT2JqZWN0ID0ge1xyXG4gICAgaW5jb21lX3RheDogMCxcclxuICAgIGVzaTogMCxcclxuICAgIGVwZjogMCxcclxuICAgIHByb2Zlc3Npb25hbF90YXg6IDAsXHJcbiAgfTtcclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwic2lOb1wiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImVtcGxveWVlTmFtZVwiLCBoZWFkZXI6IFwiRW1wbG95ZWUgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJlbXBsb3llZUNvZGVcIiwgaGVhZGVyOiBcIkVtcGxveWVlIElkXCIgfSxcclxuICAgIHsga2V5OiBcInNhbGFyeU1vbnRoXCIsIGhlYWRlcjogXCJTYWxhcnkgTW9udGhcIiB9LFxyXG4gICAgeyBrZXk6IFwic2FsYXJ5WWVhclwiLCBoZWFkZXI6IFwiWWVhclwiIH0sXHJcbiAgICB7IGtleTogXCJuZXRQYXlhYmxlXCIsIGhlYWRlcjogXCJOZXQgUGF5YWJsZVwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuICBjb25zdCBtb250aHMgPSBbXHJcbiAgICB7IGxhYmVsOiBcIkphbnVhcnlcIiwgdmFsdWU6IFwiSmFudWFyeVwiLCBkaXNhYmxlZDogZmFsc2UgfSxcclxuICAgIHsgbGFiZWw6IFwiRmVicnVhcnlcIiwgdmFsdWU6IFwiRmVicnVhcnlcIiwgZGlzYWJsZWQ6IGZhbHNlIH0sXHJcbiAgICB7IGxhYmVsOiBcIk1hcmNoXCIsIHZhbHVlOiBcIk1hcmNoXCIsIGRpc2FibGVkOiBmYWxzZSB9LFxyXG4gICAgeyBsYWJlbDogXCJBcHJpbFwiLCB2YWx1ZTogXCJBcHJpbFwiLCBkaXNhYmxlZDogZmFsc2UgfSxcclxuICAgIHsgbGFiZWw6IFwiTWF5XCIsIHZhbHVlOiBcIk1heVwiLCBkaXNhYmxlZDogZmFsc2UgfSxcclxuICAgIHsgbGFiZWw6IFwiSnVuZVwiLCB2YWx1ZTogXCJKdW5lXCIsIGRpc2FibGVkOiBmYWxzZSB9LFxyXG4gICAgeyBsYWJlbDogXCJKdWx5XCIsIHZhbHVlOiBcIkp1bHlcIiwgZGlzYWJsZWQ6IGZhbHNlIH0sXHJcbiAgICB7IGxhYmVsOiBcIkF1Z3VzdFwiLCB2YWx1ZTogXCJBdWd1c3RcIiwgZGlzYWJsZWQ6IGZhbHNlIH0sXHJcbiAgICB7XHJcbiAgICAgIGxhYmVsOiBcIlNlcHRlbWJlclwiLFxyXG4gICAgICB2YWx1ZTogXCJTZXB0ZW1iZXJcIixcclxuICAgICAgZGlzYWJsZWQ6IGZhbHNlLFxyXG4gICAgfSxcclxuICAgIHsgbGFiZWw6IFwiT2N0b2JlclwiLCB2YWx1ZTogXCJPY3RvYmVyXCIsIGRpc2FibGVkOiBmYWxzZSB9LFxyXG4gICAgeyBsYWJlbDogXCJOb3ZlbWJlclwiLCB2YWx1ZTogXCJOb3ZlbWJlclwiLCBkaXNhYmxlZDogZmFsc2UgfSxcclxuICAgIHsgbGFiZWw6IFwiRGVjZW1iZXJcIiwgdmFsdWU6IFwiRGVjZW1iZXJcIiwgZGlzYWJsZWQ6IGZhbHNlIH0sXHJcbiAgXTtcclxuICBjb25zdCBwcmV2aW91c01vbnRoID0gbW9udGhzW2RheWpzKCkuc3VidHJhY3QoMiwgXCJtb250aFwiKS5mb3JtYXQoXCJNTVwiKV0/LmxhYmVsO1xyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgZW1wbG95ZWVfaWQ6IFwiXCIsXHJcbiAgICBtb250aDogcHJldmlvdXNNb250aCxcclxuICAgIHllYXI6IHRoaXNZZWFyLFxyXG4gICAgZWFybmluZ3M6IHtcclxuICAgICAgYmFzaWM6IDAsXHJcbiAgICAgIGhyYTogMCxcclxuICAgICAgdHJhdmVsX2FsbG93YW5jZTogMCxcclxuICAgICAgbWVkaWNhbF9hbGxvd2FuY2U6IDAsXHJcbiAgICAgIGJhc2tldF9vZl9iZW5pZml0czogMCxcclxuICAgICAgcGVyZm9ybWFuY2VfYm9udXM6IDAsXHJcbiAgICAgIG90aGVyX2FsbG93YW5jZXM6IDAsXHJcbiAgICAgIGNvbnZleWFuY2U6IDAsXHJcbiAgICB9LFxyXG4gICAgZGVkdWN0aW9uczoge1xyXG4gICAgICBpbmNvbWVfdGF4OiAwLFxyXG4gICAgICBlc2k6IDAsXHJcbiAgICAgIGVwZjogMCxcclxuICAgICAgcHJvZmVzc2lvbmFsX3RheDogMCxcclxuICAgIH0sXHJcbiAgICBhZGRpdGlvbmFsX3BheW1lbnRzOiBbXSxcclxuICAgIGFkZGl0aW9uYWxfZGVkdWN0aW9uczogW10sXHJcbiAgICBhZHZhbmNlX3BheW1lbnRzOiBbXSxcclxuICAgIGNhbGN1bGF0ZWRfaW5jZW50aXZlOiAwLFxyXG4gICAgdG90YWxfc2FsYXJ5X3BheWFibGU6IDAsXHJcbiAgICBwYWlkX2Ftb3VudDogMCxcclxuICAgIHBheW1lbnRfbWV0aG9kOiBcIkNhc2hcIixcclxuICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgdGFyZ2V0OiAwLFxyXG4gICAgaW5jZW50aXZlOiAwLFxyXG4gICAgc3RhdHVzOiBcIlBhaWRcIixcclxuICB9KTtcclxuICBhc3luYyBmdW5jdGlvbiBmZXRjaEVtcGxveWVlcygpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9IGF3YWl0IEFQSS5nZXQoXCIvZW1wbG95ZWVcIik7XHJcbiAgICAgIGNvbnN0IGZpbHRlcmVkRW1wbG95ZWUgPSByZXNwb25zZURhdGE/LmRhdGE/LmVtcGxveWVlPy5tYXAoKGVtcCkgPT4gKHtcclxuICAgICAgICB2YWx1ZTogZW1wPy5faWQsXHJcbiAgICAgICAgbGFiZWw6IGAke2VtcD8ubmFtZX0gfCAke2VtcD8ucGhvbmVfbnVtYmVyfWAgfHwgXCJVbmtub3duIEVtcGxveWVlXCIsXHJcbiAgICAgIH0pKTtcclxuICAgICAgc2V0RW1wbG95ZWVzKGZpbHRlcmVkRW1wbG95ZWUgfHwgW10pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgc2V0RW1wbG95ZWVzKFtdKTtcclxuICAgIH1cclxuICB9XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoRW1wbG95ZWVzKCk7XHJcbiAgfSwgW10pO1xyXG4gIGFzeW5jIGZ1bmN0aW9uIGdldFNhbGFyeUJ5SWQoaWQpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldChgL3NhbGFyeS1wYXltZW50LyR7aWR9YCk7XHJcbiAgICAgIHJldHVybiByZXNwb25zZS5kYXRhLmRhdGE7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgc2FsYXJ5IGJ5IElEOlwiLCBlcnJvcik7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gIH1cclxuICBjb25zdCBmZXRjaEVtcGxveWVlVGFyZ2V0ID0gYXN5bmMgKGVtcGxveWVlSWQsIHN0YXJ0X2RhdGUsIGVuZF9kYXRlKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEFQSS5nZXQoYC90YXJnZXQvZW1wbG95ZWVzLyR7ZW1wbG95ZWVJZH1gLCB7XHJcbiAgICAgICAgcGFyYW1zOiB7IHN0YXJ0X2RhdGUsIGVuZF9kYXRlIH0sXHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YT8udG90YWxfdGFyZ2V0IHx8IDA7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCB0YXJnZXQ6XCIsIGVycik7XHJcbiAgICAgIHJldHVybiAwO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgZmV0Y2hFbXBsb3llZUluY2VudGl2ZSA9IGFzeW5jIChlbXBsb3llZUlkLCBzdGFydF9kYXRlLCBlbmRfZGF0ZSkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBUEkuZ2V0KFxyXG4gICAgICAgIGAvZW5yb2xsL2VtcGxveWVlLyR7ZW1wbG95ZWVJZH0vaW5jZW50aXZlYCxcclxuICAgICAgICB7IHBhcmFtczogeyBzdGFydF9kYXRlLCBlbmRfZGF0ZSB9IH1cclxuICAgICAgKTtcclxuICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE/LmluY2VudGl2ZVN1bW1hcnk/LnRvdGFsX2luY2VudGl2ZV92YWx1ZSB8fCAwO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggaW5jZW50aXZlOlwiLCBlcnIpO1xyXG4gICAgICByZXR1cm4gMDtcclxuICAgIH1cclxuICB9O1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoIWlzT3BlblVwZGF0ZU1vZGFsKSB7XHJcbiAgICAgIHNldEFkanVzdG1lbnRBbW91bnQoMCk7XHJcbiAgICB9XHJcbiAgfSwgW2lzT3BlblVwZGF0ZU1vZGFsXSk7XHJcbiAgY29uc3QgZ2V0VmFsaWRNb250aHMgPSAoam9pbmluZ0RhdGVTdHIsIHNlbGVjdGVkWWVhcikgPT4ge1xyXG4gICAgaWYgKCFqb2luaW5nRGF0ZVN0ciB8fCAhc2VsZWN0ZWRZZWFyKSB7XHJcbiAgICAgIHJldHVybiBtb250aHMubWFwKChtKSA9PiAoeyAuLi5tLCBkaXNhYmxlZDogdHJ1ZSB9KSk7XHJcbiAgICB9XHJcbiAgICBjb25zdCBqb2luaW5nID0gZGF5anMoam9pbmluZ0RhdGVTdHIpO1xyXG4gICAgY29uc3QgdG9kYXkgPSBkYXlqcygpO1xyXG4gICAgY29uc3Qgam9pblllYXIgPSBqb2luaW5nLnllYXIoKTtcclxuICAgIGNvbnN0IGN1cnJlbnRZZWFyID0gdG9kYXkueWVhcigpO1xyXG4gICAgY29uc3Qgc2VsZWN0ZWRZZWFyTnVtID0gTnVtYmVyKHNlbGVjdGVkWWVhcik7XHJcbiAgICByZXR1cm4gbW9udGhzLm1hcCgobW9udGgsIGluZGV4KSA9PiB7XHJcbiAgICAgIGNvbnN0IGlzQmVmb3JlSm9pbmluZyA9XHJcbiAgICAgICAgc2VsZWN0ZWRZZWFyTnVtID09PSBqb2luWWVhciAmJiBpbmRleCA8IGpvaW5pbmcubW9udGgoKTtcclxuICAgICAgY29uc3QgaXNBZnRlclRvZGF5ID1cclxuICAgICAgICBzZWxlY3RlZFllYXJOdW0gPT09IGN1cnJlbnRZZWFyICYmIGluZGV4ID4gdG9kYXkubW9udGgoKTtcclxuICAgICAgY29uc3QgZGlzYWJsZWQgPVxyXG4gICAgICAgIHNlbGVjdGVkWWVhck51bSA8IGpvaW5ZZWFyIHx8XHJcbiAgICAgICAgc2VsZWN0ZWRZZWFyTnVtID4gY3VycmVudFllYXIgfHxcclxuICAgICAgICBpc0JlZm9yZUpvaW5pbmcgfHxcclxuICAgICAgICBpc0FmdGVyVG9kYXk7XHJcbiAgICAgIHJldHVybiB7IC4uLm1vbnRoLCBkaXNhYmxlZCB9O1xyXG4gICAgfSk7XHJcbiAgfTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKFxyXG4gICAgICBmb3JtRGF0YS5lbXBsb3llZV9pZCAmJlxyXG4gICAgICBmb3JtRGF0YS55ZWFyICYmXHJcbiAgICAgIGVtcGxveWVlRGV0YWlscz8uam9pbmluZ19kYXRlXHJcbiAgICApIHtcclxuICAgICAgY29uc3QgdmFsaWRNb250aHMgPSBnZXRWYWxpZE1vbnRocyhcclxuICAgICAgICBlbXBsb3llZURldGFpbHMuam9pbmluZ19kYXRlLFxyXG4gICAgICAgIGZvcm1EYXRhLnllYXJcclxuICAgICAgKTtcclxuICAgICAgY29uc3QgY3VycmVudE1vbnRoVmFsaWQgPSB2YWxpZE1vbnRocy5zb21lKFxyXG4gICAgICAgIChtKSA9PiBtLnZhbHVlID09PSBmb3JtRGF0YS5tb250aCAmJiAhbS5kaXNhYmxlZFxyXG4gICAgICApO1xyXG4gICAgICBpZiAoIWN1cnJlbnRNb250aFZhbGlkKSB7XHJcbiAgICAgICAgY29uc3QgZmlyc3RWYWxpZCA9IHZhbGlkTW9udGhzLmZpbmQoKG0pID0+ICFtLmRpc2FibGVkKTtcclxuICAgICAgICBpZiAoZmlyc3RWYWxpZCkge1xyXG4gICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgIG1vbnRoOiBmaXJzdFZhbGlkLnZhbHVlLFxyXG4gICAgICAgICAgfSkpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH0sIFtmb3JtRGF0YS55ZWFyLCBmb3JtRGF0YS5lbXBsb3llZV9pZCwgZW1wbG95ZWVEZXRhaWxzPy5qb2luaW5nX2RhdGVdKTtcclxuICBjb25zdCBoYW5kbGVFZGl0ID0gYXN5bmMgKGlkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRVcGRhdGVMb2FkaW5nKHRydWUpO1xyXG4gICAgICBzZXRJc09wZW5VcGRhdGVNb2RhbCh0cnVlKTtcclxuICAgICAgc2V0QWRqdXN0bWVudEFtb3VudCgwKTtcclxuICAgICAgY29uc3Qgc2FsYXJ5RGF0YSA9IGF3YWl0IGdldFNhbGFyeUJ5SWQoaWQpO1xyXG4gICAgICBpZiAoc2FsYXJ5RGF0YSkge1xyXG4gICAgICAgIHNldEN1cnJlbnRTYWxhcnlJZChpZCk7XHJcbiAgICAgICAgY29uc3QgeWVhckFzRGF5anMgPSBkYXlqcyhzYWxhcnlEYXRhLnNhbGFyeV95ZWFyLCBcIllZWVlcIik7XHJcblxyXG4gICAgICAgIGNvbnN0IHBhaWRBbW91bnQgPVxyXG4gICAgICAgICAgc2FsYXJ5RGF0YS5wYWlkX2Ftb3VudCB8fCBzYWxhcnlEYXRhLnRvdGFsX3NhbGFyeV9wYXlhYmxlIHx8IDA7XHJcblxyXG4gICAgICAgIGNvbnN0IGZvcm1EYXRhID0ge1xyXG4gICAgICAgICAgZW1wbG95ZWVfaWQ6IHNhbGFyeURhdGE/LmVtcGxveWVlX2lkPy5faWQsXHJcbiAgICAgICAgICBtb250aDogc2FsYXJ5RGF0YT8uc2FsYXJ5X21vbnRoLFxyXG4gICAgICAgICAgeWVhcjogeWVhckFzRGF5anMsXHJcbiAgICAgICAgICBlYXJuaW5nczogc2FsYXJ5RGF0YT8uZWFybmluZ3MsXHJcbiAgICAgICAgICBkZWR1Y3Rpb25zOiBzYWxhcnlEYXRhPy5kZWR1Y3Rpb25zLFxyXG4gICAgICAgICAgYWRkaXRpb25hbF9wYXltZW50czogc2FsYXJ5RGF0YT8uYWRkaXRpb25hbF9wYXltZW50cyB8fCBbXSxcclxuICAgICAgICAgIGFkZGl0aW9uYWxfZGVkdWN0aW9uczogc2FsYXJ5RGF0YT8uYWRkaXRpb25hbF9kZWR1Y3Rpb25zIHx8IFtdLFxyXG4gICAgICAgICAgYWR2YW5jZV9wYXltZW50czogc2FsYXJ5RGF0YT8uYWR2YW5jZV9wYXltZW50cyB8fCBbXSxcclxuICAgICAgICAgIGNhbGN1bGF0ZWRfaW5jZW50aXZlOiBzYWxhcnlEYXRhPy5jYWxjdWxhdGVkX2luY2VudGl2ZSB8fCAwLFxyXG4gICAgICAgICAgdG90YWxfc2FsYXJ5X3BheWFibGU6IHNhbGFyeURhdGE/LnRvdGFsX3NhbGFyeV9wYXlhYmxlIHx8IDAsXHJcbiAgICAgICAgICBwYWlkX2Ftb3VudDogcGFpZEFtb3VudCwgLy8gVXNlIHRoZSBkZWZhdWx0ZWQgdmFsdWVcclxuICAgICAgICAgIHBheW1lbnRfbWV0aG9kOiBzYWxhcnlEYXRhPy5wYXltZW50X21ldGhvZCB8fCBcIkNhc2hcIixcclxuICAgICAgICAgIHRyYW5zYWN0aW9uX2lkOiBzYWxhcnlEYXRhPy50cmFuc2FjdGlvbl9pZCB8fCBcIlwiLFxyXG4gICAgICAgICAgcGF5X2RhdGU6IHNhbGFyeURhdGE/LnBheV9kYXRlXHJcbiAgICAgICAgICAgID8gbW9tZW50KHNhbGFyeURhdGE/LnBheV9kYXRlKVxyXG4gICAgICAgICAgICA6IG1vbWVudCgpLFxyXG4gICAgICAgICAgYXR0ZW5kYW5jZV9kZXRhaWxzOiBzYWxhcnlEYXRhPy5hdHRlbmRhbmNlX2RldGFpbHMgfHwge30sXHJcbiAgICAgICAgICBtb250aGx5X2J1c2luZXNzX2luZm86IHNhbGFyeURhdGE/Lm1vbnRobHlfYnVzaW5lc3NfaW5mbyB8fCB7XHJcbiAgICAgICAgICAgIHRhcmdldDogMCxcclxuICAgICAgICAgICAgdG90YWxfYnVzaW5lc3NfY2xvc2VkOiAwLFxyXG4gICAgICAgICAgICBwcmV2aW91c19yZW1haW5pbmdfdGFyZ2V0OiAwLFxyXG4gICAgICAgICAgICBjdXJyZW50X3JlbWFpbmluZ190YXJnZXQ6IDAsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgc3RhdHVzOiBcIlBhaWRcIixcclxuICAgICAgICAgIGlzX3NhbGFyeV9wYWlkOiB0cnVlLFxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKGZvcm1EYXRhKTtcclxuICAgICAgICB1cGRhdGVGb3JtLnNldEZpZWxkc1ZhbHVlKGZvcm1EYXRhKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBzYWxhcnkgZGV0YWlsc1wiKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldFVwZGF0ZUxvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlQ29uZmlybSA9IGFzeW5jIChpZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0RGVsZXRlTG9hZGluZyh0cnVlKTtcclxuICAgICAgYXdhaXQgQVBJLmRlbGV0ZShgL3NhbGFyeS1wYXltZW50LyR7aWR9YCk7XHJcbiAgICAgIG1lc3NhZ2Uuc3VjY2VzcyhcIlNhbGFyeSBQYXltZW50IGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5XCIpO1xyXG4gICAgICBzZXREZWxldGVNb2RhbE9wZW4oZmFsc2UpO1xyXG4gICAgICBnZXRBbGxTYWxhcnkoKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gZGVsZXRlIFNhbGFyeSBQYXltZW50XCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0RGVsZXRlTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVVcGRhdGVDaGFuZ2UgPSAoY2hhbmdlZFZhbHVlcywgYWxsVmFsdWVzKSA9PiB7XHJcbiAgICBpZiAoY2hhbmdlZFZhbHVlcy55ZWFyICYmIGRheWpzLmlzRGF5anMoY2hhbmdlZFZhbHVlcy55ZWFyKSkge1xyXG4gICAgICBjaGFuZ2VkVmFsdWVzLnllYXIgPSBjaGFuZ2VkVmFsdWVzLnllYXIuZm9ybWF0KFwiWVlZWVwiKTtcclxuICAgIH1cclxuICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgIC4uLmNoYW5nZWRWYWx1ZXMsXHJcbiAgICAgIC4uLmFsbFZhbHVlcyxcclxuICAgIH0pO1xyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlU3VibWl0ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0VXBkYXRlTG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgIC8vIEdldCBsYXRlc3QgdmFsdWVzIGZyb20gZm9ybVxyXG4gICAgICBjb25zdCBmb3JtVmFsdWVzID0gdXBkYXRlRm9ybS5nZXRGaWVsZHNWYWx1ZSgpO1xyXG4gICAgICBjb25zdCB0b3RhbFBheWFibGUgPSBOdW1iZXIoZm9ybVZhbHVlcy50b3RhbF9zYWxhcnlfcGF5YWJsZSB8fCAwKTtcclxuICAgICAgY29uc3QgYWRqQW1vdW50ID0gYWRqdXN0bWVudEFtb3VudDsgLy8gVXNlIHlvdXIgc3RhdGVcclxuICAgICAgY29uc3QgY29tcHV0ZWRQYWlkQW1vdW50ID0gdG90YWxQYXlhYmxlICsgYWRqQW1vdW50O1xyXG5cclxuICAgICAgY29uc3QgcmVtYWluaW5nX2JhbGFuY2UgPSB0b3RhbFBheWFibGUgLSBjb21wdXRlZFBhaWRBbW91bnQ7XHJcblxyXG4gICAgICBjb25zdCB1cGRhdGVEYXRhID0ge1xyXG4gICAgICAgIC4uLmZvcm1WYWx1ZXMsXHJcbiAgICAgICAgcGFpZF9hbW91bnQ6IGNvbXB1dGVkUGFpZEFtb3VudCxcclxuICAgICAgICByZW1haW5pbmdfYmFsYW5jZSxcclxuICAgICAgICBtb250aGx5X2J1c2luZXNzX2luZm86IGZvcm1WYWx1ZXMubW9udGhseV9idXNpbmVzc19pbmZvIHx8IHtcclxuICAgICAgICAgIHRhcmdldDogMCxcclxuICAgICAgICAgIHRvdGFsX2J1c2luZXNzX2Nsb3NlZDogMCxcclxuICAgICAgICAgIHByZXZpb3VzX3JlbWFpbmluZ190YXJnZXQ6IDAsXHJcbiAgICAgICAgICBjdXJyZW50X3JlbWFpbmluZ190YXJnZXQ6IDAsXHJcbiAgICAgICAgfSxcclxuICAgICAgfTtcclxuXHJcbiAgICAgIGF3YWl0IEFQSS5wdXQoYC9zYWxhcnktcGF5bWVudC8ke2N1cnJlbnRTYWxhcnlJZH1gLCB1cGRhdGVEYXRhKTtcclxuICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiU2FsYXJ5IHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5XCIpO1xyXG4gICAgICBzZXRJc09wZW5VcGRhdGVNb2RhbChmYWxzZSk7XHJcbiAgICAgIGdldEFsbFNhbGFyeSgpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIHNhbGFyeTpcIiwgZXJyb3IpO1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIHVwZGF0ZSBzYWxhcnlcIik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRVcGRhdGVMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVByaW50ID0gKHNhbGFyeVBheW1lbnRJZCkgPT4ge1xyXG4gICAgbmF2aWdhdGUoXCIvc2FsYXJ5LXNsaXAtcHJpbnQvXCIgKyBzYWxhcnlQYXltZW50SWQpO1xyXG4gIH07XHJcbiAgY29uc3QgZHJvcERvd25JdGVtcyA9IChzYWxhcnlQYXltZW50KSA9PiB7XHJcbiAgICBjb25zdCBkcm9wRG93bkl0ZW1MaXN0ID0gW1xyXG4gICAgICB7XHJcbiAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICBrZXk9e3NhbGFyeVBheW1lbnQ/Ll9pZH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVQcmludChzYWxhcnlQYXltZW50Py5faWQpfT5cclxuICAgICAgICAgICAgUHJpbnRcclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICksXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIGtleT17c2FsYXJ5UGF5bWVudD8uX2lkfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUVkaXQoc2FsYXJ5UGF5bWVudC5faWQpfT5cclxuICAgICAgICAgICAgUGF5IE5vd1xyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSxcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgIGtleTogXCIzXCIsXHJcbiAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAga2V5PXtzYWxhcnlQYXltZW50Py5faWR9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICBzZXREZWxldGVJZChzYWxhcnlQYXltZW50Py5faWQpO1xyXG4gICAgICAgICAgICAgIHNldERlbGV0ZU1vZGFsT3Blbih0cnVlKTtcclxuICAgICAgICAgICAgfX0+XHJcbiAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSxcclxuICAgICAgfSxcclxuICAgIF07XHJcbiAgICByZXR1cm4gZHJvcERvd25JdGVtTGlzdDtcclxuICB9O1xyXG4gIGFzeW5jIGZ1bmN0aW9uIGZldGNoU2FsYXJ5RGV0YWlscygpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldEVtcGxveWVlRGV0YWlsc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9IGF3YWl0IEFQSS5nZXQoYC9lbXBsb3llZS8ke2Zvcm1EYXRhLmVtcGxveWVlX2lkfWApO1xyXG4gICAgICBjb25zdCBlbXAgPSByZXNwb25zZURhdGE/LmRhdGE/LmRhdGE7XHJcbiAgICAgIGNvbnN0IHVwZGF0ZWRFYXJuaW5ncyA9IHtcclxuICAgICAgICAuLi5lYXJuaW5nc09iamVjdCxcclxuICAgICAgICAuLi5lbXA/LmVhcm5pbmdzLFxyXG4gICAgICAgIHNhbGFyeTogZW1wPy5zYWxhcnkgfHwgMCxcclxuICAgICAgfTtcclxuICAgICAgY29uc3QgdXBkYXRlZERlZHVjdGlvbnMgPSB7XHJcbiAgICAgICAgLi4uZGVkdWN0aW9uc09iamVjdCxcclxuICAgICAgICAuLi5lbXA/LmRlZHVjdGlvbnMsXHJcbiAgICAgIH07XHJcbiAgICAgIHNldEVtcGxveWVlRGV0YWlscyhlbXApO1xyXG4gICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIGVhcm5pbmdzOiB1cGRhdGVkRWFybmluZ3MsXHJcbiAgICAgICAgZGVkdWN0aW9uczogdXBkYXRlZERlZHVjdGlvbnMsXHJcbiAgICAgIH0pKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNldEVtcGxveWVlRGV0YWlscyh7fSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRFbXBsb3llZURldGFpbHNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChmb3JtRGF0YS5lbXBsb3llZV9pZCAmJiBmb3JtRGF0YS5tb250aCAmJiBmb3JtRGF0YS55ZWFyKSB7XHJcbiAgICAgIGxvYWRUYXJnZXRBbmRJbmNlbnRpdmUoKTtcclxuICAgIH1cclxuICB9LCBbZm9ybURhdGEuZW1wbG95ZWVfaWQsIGZvcm1EYXRhLm1vbnRoLCBmb3JtRGF0YS55ZWFyXSk7XHJcbiAgY29uc3QgbG9hZFRhcmdldEFuZEluY2VudGl2ZSA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IG1vbnRoSW5kZXggPSBtb21lbnQoKS5tb250aChmb3JtRGF0YS5tb250aCkubW9udGgoKTtcclxuICAgICAgY29uc3QgeWVhciA9IGZvcm1EYXRhLnllYXI7XHJcbiAgICAgIGNvbnN0IHN0YXJ0X2RhdGUgPSBtb21lbnQoKVxyXG4gICAgICAgIC55ZWFyKHllYXIpXHJcbiAgICAgICAgLm1vbnRoKG1vbnRoSW5kZXgpXHJcbiAgICAgICAgLnN0YXJ0T2YoXCJtb250aFwiKVxyXG4gICAgICAgIC5mb3JtYXQoXCJZWVlZLU1NLUREXCIpO1xyXG4gICAgICBjb25zdCBlbmRfZGF0ZSA9IG1vbWVudCgpXHJcbiAgICAgICAgLnllYXIoeWVhcilcclxuICAgICAgICAubW9udGgobW9udGhJbmRleClcclxuICAgICAgICAuZW5kT2YoXCJtb250aFwiKVxyXG4gICAgICAgIC5mb3JtYXQoXCJZWVlZLU1NLUREXCIpO1xyXG4gICAgICBjb25zdCB0YXJnZXRWYWx1ZSA9IGF3YWl0IGZldGNoRW1wbG95ZWVUYXJnZXQoXHJcbiAgICAgICAgZm9ybURhdGEuZW1wbG95ZWVfaWQsXHJcbiAgICAgICAgc3RhcnRfZGF0ZSxcclxuICAgICAgICBlbmRfZGF0ZVxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCBpbmNlbnRpdmVWYWx1ZSA9IGF3YWl0IGZldGNoRW1wbG95ZWVJbmNlbnRpdmUoXHJcbiAgICAgICAgZm9ybURhdGEuZW1wbG95ZWVfaWQsXHJcbiAgICAgICAgc3RhcnRfZGF0ZSxcclxuICAgICAgICBlbmRfZGF0ZVxyXG4gICAgICApO1xyXG4gICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIHRhcmdldDogdGFyZ2V0VmFsdWUsXHJcbiAgICAgICAgaW5jZW50aXZlOiBpbmNlbnRpdmVWYWx1ZSxcclxuICAgICAgfSkpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gYXV0by1sb2FkIHRhcmdldCAmIGluY2VudGl2ZVwiLCBlcnIpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChmb3JtRGF0YS5lbXBsb3llZV9pZCkge1xyXG4gICAgICBmZXRjaFNhbGFyeURldGFpbHMoKTtcclxuICAgIH1cclxuICB9LCBbZm9ybURhdGE/LmVtcGxveWVlX2lkLCBmb3JtRGF0YS5tb250aCwgZm9ybURhdGEubW9udGhdKTtcclxuICBjb25zdCB1cGRhdGVUb3RhbEVhcm5pbmdzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBlYXJuaW5ncyA9IHVwZGF0ZUZvcm1EYXRhPy5lYXJuaW5ncyB8fCB7fTtcclxuICAgIHJldHVybiBPYmplY3QudmFsdWVzKGVhcm5pbmdzKS5yZWR1Y2UoKHN1bSwgdikgPT4gc3VtICsgTnVtYmVyKHYgfHwgMCksIDApO1xyXG4gIH0sIFt1cGRhdGVGb3JtRGF0YV0pO1xyXG4gIGNvbnN0IHVwZGF0ZVRvdGFsRGVkdWN0aW9ucyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgZGVkdWN0aW9ucyA9IHVwZGF0ZUZvcm1EYXRhPy5kZWR1Y3Rpb25zIHx8IHt9O1xyXG4gICAgY29uc3QgYWRkaXRpb25hbCA9IHVwZGF0ZUZvcm1EYXRhPy5hZGRpdGlvbmFsX2RlZHVjdGlvbnMgfHwgW107XHJcbiAgICBjb25zdCBiYXNlID0gT2JqZWN0LnZhbHVlcyhkZWR1Y3Rpb25zKS5yZWR1Y2UoXHJcbiAgICAgIChzdW0sIHYpID0+IHN1bSArIE51bWJlcih2IHx8IDApLFxyXG4gICAgICAwXHJcbiAgICApO1xyXG4gICAgY29uc3QgZXh0cmEgPSBhZGRpdGlvbmFsLnJlZHVjZSgoc3VtLCBkKSA9PiBzdW0gKyBOdW1iZXIoZC52YWx1ZSB8fCAwKSwgMCk7XHJcbiAgICByZXR1cm4gYmFzZSArIGV4dHJhO1xyXG4gIH0sIFt1cGRhdGVGb3JtRGF0YV0pO1xyXG4gIGFzeW5jIGZ1bmN0aW9uIGdldEFsbFNhbGFyeSgpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldERhdGFUYWJsZUxvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldChcIi9zYWxhcnktcGF5bWVudC9zdGF0dXMvcGVuZGluZ1wiKTtcclxuICAgICAgY29uc3QgcmVzcG9uc2VEYXRhID0gcmVzcG9uc2U/LmRhdGE/LmRhdGEgfHwgW107XHJcbiAgICAgIGNvbnN0IGZpbHRlcmVkRGF0YSA9IHJlc3BvbnNlRGF0YS5tYXAoKGRhdGEsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgIHNpTm86IGluZGV4ICsgMSxcclxuICAgICAgICBfaWQ6IGRhdGE/Ll9pZCxcclxuICAgICAgICBlbXBsb3llZU5hbWU6IGRhdGE/LmVtcGxveWVlX2lkPy5uYW1lLFxyXG4gICAgICAgIGVtcGxveWVlQ29kZTogZGF0YT8uZW1wbG95ZWVfaWQ/LmVtcGxveWVlQ29kZSxcclxuICAgICAgICBzYWxhcnlNb250aDogZGF0YT8uc2FsYXJ5X21vbnRoLFxyXG4gICAgICAgIHNhbGFyeVllYXI6IGRhdGE/LnNhbGFyeV95ZWFyLFxyXG4gICAgICAgIG5ldFBheWFibGU6IGRhdGE/LnRvdGFsX3NhbGFyeV9wYXlhYmxlLFxyXG4gICAgICAgIHBhaWRBbW91bnQ6IGRhdGE/LnBhaWRfYW1vdW50LFxyXG4gICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgIGtleT17ZGF0YT8uX2lkfVxyXG4gICAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICAgIGl0ZW1zOiBkcm9wRG93bkl0ZW1zKGRhdGEpLFxyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiPlxyXG4gICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4gICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSxcclxuICAgICAgfSkpO1xyXG4gICAgICBzZXRBbGxTYWxhcnlwYXltZW50cyhbLi4uZmlsdGVyZWREYXRhXSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzZXRBbGxTYWxhcnlwYXltZW50cyhbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXREYXRhVGFibGVMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGdldEFsbFNhbGFyeSgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8gUXVpY2sgbmF2aWdhdG9yIGxpbmsgZGF0YVxyXG4gIGNvbnN0IE5BVl9MSU5LUyA9IFtcclxuICAgIHtcclxuICAgICAgdG86IFwiL3N0YWZmLW1lbnUvZW1wbG95ZWUtbWVudS9lbXBsb3llZS1zdGF0ZW1lbnRcIixcclxuICAgICAgaWNvbjogPFVzZXIgc2l6ZT17MTZ9IC8+LFxyXG4gICAgICBsYWJlbDogXCJTYWxhcnkgTGVkZ2VyXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0bzogXCIvc3RhZmYtbWVudS9lbXBsb3llZS1tZW51L3NhbGFyeS1tYW5hZ2VtZW50XCIsXHJcbiAgICAgIGljb246IDxNZE91dGxpbmVNYW4gc2l6ZT17MTZ9IC8+LFxyXG4gICAgICBsYWJlbDogXCJTYWxhcnkgbWFuYWdlbWVudFwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdG86IFwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1pbi1tZW51L2FkdmFuY2UtcGF5bWVudC1pblwiLFxyXG4gICAgICBpY29uOiA8UmlNb25leVJ1cGVlQ2lyY2xlRmlsbCBzaXplPXsxNn0gLz4sXHJcbiAgICAgIGxhYmVsOiBcIkFkdmFuY2UgcmVwYXltZW50XCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0bzogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LW91dC1tZW51L3NhbGFyeS1pbmNlbnRpdmVcIixcclxuICAgICAgaWNvbjogPFJpTW9uZXlSdXBlZUNpcmNsZUZpbGwgc2l6ZT17MTZ9IC8+LFxyXG4gICAgICBsYWJlbDogXCJTYWxhcnkgaW5jZW50aXZlXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0bzogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LW91dC1tZW51L2FkZGl0aW9uYWwtc2FsYXJ5XCIsXHJcbiAgICAgIGljb246IDxSaU1vbmV5UnVwZWVDaXJjbGVGaWxsIHNpemU9ezE2fSAvPixcclxuICAgICAgbGFiZWw6IFwiQWRkaXRpb25hbCBzYWxhcnlcIixcclxuICAgIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgdG90YWxQYXlhYmxlU3VtID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICByZXR1cm4gYWxsU2FsYXJ5UGF5bWVudHMucmVkdWNlKFxyXG4gICAgICAoc3VtLCBpdGVtKSA9PiBzdW0gKyAoTnVtYmVyKGl0ZW0ubmV0UGF5YWJsZSkgfHwgMCksXHJcbiAgICAgIDAsXHJcbiAgICApO1xyXG4gIH0sIFthbGxTYWxhcnlQYXltZW50c10pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgPE5hdmJhciB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG4gICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC0zXCI+XHJcbiAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4gICAgICAgICAgey8qIOKUgOKUgCBRdWljayBOYXZpZ2F0b3Ig4pSA4pSAICovfVxyXG4gICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwibWItMlwiPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LWdyYXktNDAwIG1iLTNcIj5cclxuICAgICAgICAgICAgICBRdWljayBuYXZpZ2F0b3JcclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAge05BVl9MSU5LUy5tYXAoKGxpbmspID0+IChcclxuICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgIGtleT17bGluay50b31cclxuICAgICAgICAgICAgICAgICAgdG89e2xpbmsudG99XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMiBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgdGV4dC1zbSB0ZXh0LWdyYXktNjAwIGhvdmVyOmJvcmRlci1ibHVlLTQwMCBob3Zlcjp0ZXh0LWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAgdHJhbnNpdGlvbi1hbGxcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNTAwXCI+e2xpbmsuaWNvbn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIHtsaW5rLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTFcIj5cclxuXHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgU2FsYXJ5IFBheW1lbnRcclxuICAgICAgICAgICAgPC9oMT5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS0xMDAgYm9yZGVyIGJvcmRlci1ibHVlLTMwMCByb3VuZGVkLXhsIHB4LTUgcHktMiBzaGFkb3ctc20gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTZcIj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFBlbmRpbmcgUGF5bWVudHMgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ibHVlLTkwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICBQZW5kaW5nIFBheW1lbnRzOlxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ibHVlLTkwMCBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAge2FsbFNhbGFyeVBheW1lbnRzLmxlbmd0aH1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIERpdmlkZXIgKi99XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaC01IHctcHggYmctYmx1ZS0zMDBcIj48L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBUb3RhbCBQYXlhYmxlICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmx1ZS05MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgVG90YWwgUGF5YWJsZTpcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmx1ZS05MDAgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgIOKCuXt0b3RhbFBheWFibGVTdW0udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIG1iLThcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0xMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICB7ZGF0YVRhYmxlTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICA8U3BpblxyXG4gICAgICAgICAgICAgICAgaW5kaWNhdG9yPXs8TG9hZGluZ091dGxpbmVkIHN0eWxlPXt7IGZvbnRTaXplOiA0OCB9fSBzcGluIC8+fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApIDogYWxsU2FsYXJ5UGF5bWVudHMubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICA8RGF0YVRhYmxlIGNvbHVtbnM9e2NvbHVtbnN9IGRhdGE9e2FsbFNhbGFyeVBheW1lbnRzfSBleHBvcnRlZEZpbGVOYW1lPVwiU2FsYXJ5IFBheW1lbnRzLmNzdlwiIGV4cG9ydGVkUGRmTmFtZT1cIlNhbGFyeSBQYXltZW50c1wiIC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPEVtcHR5IGRlc2NyaXB0aW9uPVwiTm8gU2FsYXJ5IFBheW1lbnQgRGF0YSBGb3VuZFwiIC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8RHJhd2VyXHJcbiAgICAgICAgICB0aXRsZT1cIlVwZGF0ZSBTYWxhcnkgUGF5bWVudFwiXHJcbiAgICAgICAgICB3aWR0aD17XCI3MCVcIn1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInBheW1lbnQtZHJhd2VyXCJcclxuICAgICAgICAgIG9wZW49e2lzT3BlblVwZGF0ZU1vZGFsfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0SXNPcGVuVXBkYXRlTW9kYWwoZmFsc2UpfVxyXG4gICAgICAgICAgY2xvc2FibGU9e3RydWV9XHJcbiAgICAgICAgICBmb290ZXI9e1xyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldElzT3BlblVwZGF0ZU1vZGFsKGZhbHNlKX0+XHJcbiAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVVcGRhdGVTdWJtaXR9XHJcbiAgICAgICAgICAgICAgICBsb2FkaW5nPXt1cGRhdGVMb2FkaW5nfT5cclxuICAgICAgICAgICAgICAgIFVwZGF0ZSBTYWxhcnkgUGF5bWVudFxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIH0+XHJcbiAgICAgICAgICA8Rm9ybVxyXG4gICAgICAgICAgICBmb3JtPXt1cGRhdGVGb3JtfVxyXG4gICAgICAgICAgICBsYXlvdXQ9XCJ2ZXJ0aWNhbFwiXHJcbiAgICAgICAgICAgIGluaXRpYWxWYWx1ZXM9e3VwZGF0ZUZvcm1EYXRhfVxyXG4gICAgICAgICAgICBvblZhbHVlc0NoYW5nZT17aGFuZGxlVXBkYXRlQ2hhbmdlfT5cclxuICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgIG5hbWU9XCJlbXBsb3llZV9pZFwiXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJFbXBsb3llZSBJRFwiXHJcbiAgICAgICAgICAgICAgcnVsZXM9e1tcclxuICAgICAgICAgICAgICAgIHsgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiUGxlYXNlIHNlbGVjdCBhbiBlbXBsb3llZVwiIH0sXHJcbiAgICAgICAgICAgICAgXX0+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJsYWJlbFwiXHJcbiAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAob3B0aW9uPy5sYWJlbCA/PyBcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBmaWx0ZXJTb3J0PXsob3B0aW9uQSwgb3B0aW9uQikgPT5cclxuICAgICAgICAgICAgICAgICAgKG9wdGlvbkE/LmxhYmVsID8/IFwiXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAubG9jYWxlQ29tcGFyZSgob3B0aW9uQj8ubGFiZWwgPz8gXCJcIikudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEVtcGxveWVlXCJcclxuICAgICAgICAgICAgICAgIG9wdGlvbnM9e2VtcGxveWVlc31cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgIG5hbWU9XCJtb250aFwiXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJNb250aFwiXHJcbiAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIlBsZWFzZSBzZWxlY3QgYSBtb250aFwiIH1dfT5cclxuICAgICAgICAgICAgICA8U2VsZWN0IGRpc2FibGVkIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE1vbnRoXCI+XHJcbiAgICAgICAgICAgICAgICB7bW9udGhzLm1hcCgobW9udGgpID0+IChcclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXttb250aC52YWx1ZX0gdmFsdWU9e21vbnRoLnZhbHVlfT5cclxuICAgICAgICAgICAgICAgICAgICB7bW9udGgubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgIG5hbWU9XCJ5ZWFyXCJcclxuICAgICAgICAgICAgICBsYWJlbD1cIlllYXJcIlxyXG4gICAgICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJQbGVhc2Ugc2VsZWN0IGEgeWVhclwiIH1dfVxyXG4gICAgICAgICAgICAgIGdldFZhbHVlRnJvbUV2ZW50PXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICB2YWx1ZSA/IHZhbHVlLmZvcm1hdChcIllZWVlcIikgOiBcIlwiXHJcbiAgICAgICAgICAgICAgfT5cclxuICAgICAgICAgICAgICA8RGF0ZVBpY2tlciBkaXNhYmxlZCBwaWNrZXI9XCJ5ZWFyXCIgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19IC8+XHJcbiAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyZWVuLTUwIHAtNCByb3VuZGVkLWxnIG1iLTRcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JlZW4tODAwIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgIEVhcm5pbmdzXHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbmFtZT17W1wiZWFybmluZ3NcIiwgXCJiYXNpY1wiXX0gbGFiZWw9XCJCYXNpYyBTYWxhcnlcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0IGRpc2FibGVkIHR5cGU9XCJudW1iZXJcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9e1tcImVhcm5pbmdzXCIsIFwiaHJhXCJdfSBsYWJlbD1cIkhSQVwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXQgZGlzYWJsZWQgdHlwZT1cIm51bWJlclwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgbmFtZT17W1wiZWFybmluZ3NcIiwgXCJ0cmF2ZWxfYWxsb3dhbmNlXCJdfVxyXG4gICAgICAgICAgICAgICAgICBsYWJlbD1cIlRyYXZlbCBBbGxvd2FuY2VcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0IGRpc2FibGVkIHR5cGU9XCJudW1iZXJcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9e1tcImVhcm5pbmdzXCIsIFwibWVkaWNhbF9hbGxvd2FuY2VcIl19XHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPVwiTWVkaWNhbCBBbGxvd2FuY2VcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0IGRpc2FibGVkIHR5cGU9XCJudW1iZXJcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9e1tcImVhcm5pbmdzXCIsIFwiYmFza2V0X29mX2JlbmlmaXRzXCJdfVxyXG4gICAgICAgICAgICAgICAgICBsYWJlbD1cIkJhc2tldCBvZiBCZW5lZml0c1wiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXQgZGlzYWJsZWQgdHlwZT1cIm51bWJlclwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgbmFtZT17W1wiZWFybmluZ3NcIiwgXCJwZXJmb3JtYW5jZV9ib251c1wiXX1cclxuICAgICAgICAgICAgICAgICAgbGFiZWw9XCJQZXJmb3JtYW5jZSBCb251c1wiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXQgZGlzYWJsZWQgdHlwZT1cIm51bWJlclwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgbmFtZT17W1wiZWFybmluZ3NcIiwgXCJvdGhlcl9hbGxvd2FuY2VzXCJdfVxyXG4gICAgICAgICAgICAgICAgICBsYWJlbD1cIk90aGVyIEFsbG93YW5jZXNcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0IGRpc2FibGVkIHR5cGU9XCJudW1iZXJcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9e1tcImVhcm5pbmdzXCIsIFwiY29udmV5YW5jZVwiXX0gbGFiZWw9XCJDb252ZXlhbmNlXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dCBkaXNhYmxlZCB0eXBlPVwibnVtYmVyXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cCBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgVG90YWwgRWFybmluZ3NcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZVRvdGFsRWFybmluZ3MudG9GaXhlZCgyKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS0xMDBcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcmVkLTUwIHAtNCByb3VuZGVkLWxnIG1iLTRcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtcmVkLTgwMCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICBEZWR1Y3Rpb25zXHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgbmFtZT17W1wiZGVkdWN0aW9uc1wiLCBcImluY29tZV90YXhcIl19XHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPVwiSW5jb21lIFRheFwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXQgZGlzYWJsZWQgdHlwZT1cIm51bWJlclwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbmFtZT17W1wiZGVkdWN0aW9uc1wiLCBcImVzaVwiXX0gbGFiZWw9XCJFU0lcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0IGRpc2FibGVkIHR5cGU9XCJudW1iZXJcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9e1tcImRlZHVjdGlvbnNcIiwgXCJlcGZcIl19IGxhYmVsPVwiRVBGXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dCBkaXNhYmxlZCB0eXBlPVwibnVtYmVyXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICBuYW1lPXtbXCJkZWR1Y3Rpb25zXCIsIFwicHJvZmVzc2lvbmFsX3RheFwiXX1cclxuICAgICAgICAgICAgICAgICAgbGFiZWw9XCJQcm9mZXNzaW9uYWwgVGF4XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dCBkaXNhYmxlZCB0eXBlPVwibnVtYmVyXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cCBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgVG90YWwgRGVkdWN0aW9uc1xyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlVG90YWxEZWR1Y3Rpb25zLnRvRml4ZWQoMil9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktMTAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXZpb2xldC01MCBwLTQgcm91bmRlZC1sZyBtYi00XCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXZpb2xldC04MDAgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgQXR0ZW5kYW5jZSBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgbGFiZWw9XCJUb3RhbCBEYXlzXCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT17W1wiYXR0ZW5kYW5jZV9kZXRhaWxzXCIsIFwidG90YWxfZGF5c1wiXX0+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dCB0eXBlPVwibnVtYmVyXCIgZGlzYWJsZWQgLz5cclxuICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICBsYWJlbD1cIlByZXNlbnQgRGF5c1wiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9e1tcImF0dGVuZGFuY2VfZGV0YWlsc1wiLCBcInByZXNlbnRfZGF5c1wiXX0+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dCB0eXBlPVwibnVtYmVyXCIgZGlzYWJsZWQgLz5cclxuICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICBsYWJlbD1cIlBhaWQgRGF5c1wiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9e1tcImF0dGVuZGFuY2VfZGV0YWlsc1wiLCBcInBhaWRfZGF5c1wiXX0+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dCB0eXBlPVwibnVtYmVyXCIgZGlzYWJsZWQgLz5cclxuICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICBsYWJlbD1cIkxPUCBEYXlzXCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT17W1wiYXR0ZW5kYW5jZV9kZXRhaWxzXCIsIFwibG9wX2RheXNcIl19PlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXQgdHlwZT1cIm51bWJlclwiIGRpc2FibGVkIC8+XHJcbiAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgbGFiZWw9XCJQZXIgRGF5IFNhbGFyeVwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9e1tcImF0dGVuZGFuY2VfZGV0YWlsc1wiLCBcInBlcl9kYXlfc2FsYXJ5XCJdfT5cclxuICAgICAgICAgICAgICAgICAgPElucHV0IHR5cGU9XCJudW1iZXJcIiBkaXNhYmxlZCAvPlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPVwiQ2FsY3VsYXRlZCBTYWxhcnlcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPXtbXCJhdHRlbmRhbmNlX2RldGFpbHNcIiwgXCJjYWxjdWxhdGVkX3NhbGFyeVwiXX0+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dCB0eXBlPVwibnVtYmVyXCIgZGlzYWJsZWQgLz5cclxuICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBwLTQgcm91bmRlZC1sZyBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWxnIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgTW9udGhseSBUYXJnZXQgJiBCdXNpbmVzcyBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlRvdGFsIFRhcmdldCAo4oK5KVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT17W1wibW9udGhseV9idXNpbmVzc19pbmZvXCIsIFwidGFyZ2V0XCJdfT5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXQgdHlwZT1cIm51bWJlclwiIGRpc2FibGVkIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJQcmV2aW91cyBSZW1haW5pbmcgVGFyZ2V0ICjigrkpXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIm1vbnRobHlfYnVzaW5lc3NfaW5mb1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJwcmV2aW91c19yZW1haW5pbmdfdGFyZ2V0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgXX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0IHR5cGU9XCJudW1iZXJcIiBkaXNhYmxlZCAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiVG90YWwgQnVzaW5lc3MgQ2xvc2VkICjigrkpXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPXtbXCJtb250aGx5X2J1c2luZXNzX2luZm9cIiwgXCJ0b3RhbF9idXNpbmVzc19jbG9zZWRcIl19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dCB0eXBlPVwibnVtYmVyXCIgZGlzYWJsZWQgLz5cclxuICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkN1cnJlbnQgUmVtYWluaW5nIFRhcmdldCAo4oK5KVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT17W1wibW9udGhseV9idXNpbmVzc19pbmZvXCIsIFwiY3VycmVudF9yZW1haW5pbmdfdGFyZ2V0XCJdfVxyXG4gICAgICAgICAgICAgICAgICAgIHRvb2x0aXA9XCJUYXJnZXQgbWludXMgdG90YWwgYnVzaW5lc3MgY2xvc2VkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0IHR5cGU9XCJudW1iZXJcIiBkaXNhYmxlZCAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy12aW9sZXQtNTAgcC00IHJvdW5kZWQtbGcgbWItNFwiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtbGcgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgSW5jZW50aXZlIEFkanVzdG1lbnRcclxuICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIENhbGN1bGF0ZWQgSW5jZW50aXZlXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPEZvcm0uSXRlbSBuYW1lPVwiY2FsY3VsYXRlZF9pbmNlbnRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0IHR5cGU9XCJudW1iZXJcIiBkaXNhYmxlZCAvPlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWluZGlnby01MCBwLTQgcm91bmRlZC1sZyBtYi00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWluZGlnby04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgQWR2YW5jZSBQYXltZW50c1xyXG4gICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8Rm9ybS5MaXN0IG5hbWU9XCJhZHZhbmNlX3BheW1lbnRzXCI+XHJcbiAgICAgICAgICAgICAgICB7KGZpZWxkcywgeyBhZGQsIHJlbW92ZSB9KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAge2ZpZWxkcy5tYXAoKHsga2V5LCBuYW1lLCAuLi5yZXN0RmllbGQgfSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2tleX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Li4ucmVzdEZpZWxkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9e1tuYW1lLCBcIm5hbWVcIl19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJBZHZhbmNlIE5hbWVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXQgcGxhY2Vob2xkZXI9XCJlLmcuLCBGZXN0aXZhbCBBZHZhbmNlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1lbmQgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3Jvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Li4ucmVzdEZpZWxkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbldoZWVsPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLmN1cnJlbnRUYXJnZXQuYmx1cigpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPXtbbmFtZSwgXCJ2YWx1ZVwiXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJBbW91bnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0IHR5cGU9XCJudW1iZXJcIiBwbGFjZWhvbGRlcj1cIkVudGVyIGFtb3VudFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYW5nZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGljb249ezxEZWxldGVPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlbW92ZShuYW1lKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9Gb3JtLkxpc3Q+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXB1cnBsZS01MCBwLTQgcm91bmRlZC1sZyBtYi00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXB1cnBsZS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgQWRkaXRpb25hbCBQYXltZW50c1xyXG4gICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8Rm9ybS5MaXN0IG5hbWU9XCJhZGRpdGlvbmFsX3BheW1lbnRzXCI+XHJcbiAgICAgICAgICAgICAgICB7KGZpZWxkcywgeyBhZGQsIHJlbW92ZSB9KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAge2ZpZWxkcy5tYXAoKHsga2V5LCBuYW1lLCAuLi5yZXN0RmllbGQgfSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2tleX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Li4ucmVzdEZpZWxkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9e1tuYW1lLCBcIm5hbWVcIl19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJQYXltZW50IE5hbWVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXQgcGxhY2Vob2xkZXI9XCJFbnRlciBwYXltZW50IG5hbWVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWVuZCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsuLi5yZXN0RmllbGR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uV2hlZWw9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUuY3VycmVudFRhcmdldC5ibHVyKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9e1tuYW1lLCBcInZhbHVlXCJdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkFtb3VudFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXQgdHlwZT1cIm51bWJlclwiIHBsYWNlaG9sZGVyPVwiRW50ZXIgYW1vdW50XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhbmdlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj17PERlbGV0ZU91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcmVtb3ZlKG5hbWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L0Zvcm0uTGlzdD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctb3JhbmdlLTUwIHAtNCByb3VuZGVkLWxnIG1iLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtb3JhbmdlLTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBBZGRpdGlvbmFsIERlZHVjdGlvbnNcclxuICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPEZvcm0uTGlzdCBuYW1lPVwiYWRkaXRpb25hbF9kZWR1Y3Rpb25zXCI+XHJcbiAgICAgICAgICAgICAgICB7KGZpZWxkcywgeyByZW1vdmUgfSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgIHtmaWVsZHMubWFwKCh7IGtleSwgbmFtZSwgLi4ucmVzdEZpZWxkIH0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtrZXl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTQgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey4uLnJlc3RGaWVsZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPXtbbmFtZSwgXCJuYW1lXCJdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiRGVkdWN0aW9uIE5hbWVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXQgcGxhY2Vob2xkZXI9XCJFbnRlciBkZWR1Y3Rpb24gbmFtZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtZW5kIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey4uLnJlc3RGaWVsZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT17W25hbWUsIFwidmFsdWVcIl19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiQW1vdW50XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW49ezB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYW5nZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGljb249ezxEZWxldGVPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlbW92ZShuYW1lKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9Gb3JtLkxpc3Q+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tdmlvbGV0LTUwIHRvLXZpb2xldC0xMDAgcC02IHJvdW5kZWQteGwgc2hhZG93LXNtIGJvcmRlciBib3JkZXItdmlvbGV0LTIwMCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtdmlvbGV0LTkwMCBtYi02IHBiLTMgYm9yZGVyLWIgYm9yZGVyLXZpb2xldC0zMDBcIj5cclxuICAgICAgICAgICAgICAgIFBheW1lbnQgRGV0YWlsc1xyXG4gICAgICAgICAgICAgIDwvaDM+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgICAgICAgICAgICB7LyogU2FsYXJ5IEluZm9ybWF0aW9uIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNSByb3VuZGVkLWxnIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItNCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFNhbGFyeSBJbmZvcm1hdGlvblxyXG4gICAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwidG90YWxfc2FsYXJ5X3BheWFibGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgU2FsYXJ5IFBheWFibGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwcmVmaXg9XCLigrlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbD17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBBZGp1c3RtZW50IEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXthZGp1c3RtZW50QW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwcmVmaXg9XCLigrlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsdWUgPVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWUgPT09IFwiXCIgPyAwIDogTnVtYmVyKGUudGFyZ2V0LnZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRBZGp1c3RtZW50QW1vdW50KHZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0b3RhbFBheWFibGUgPVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybS5nZXRGaWVsZFZhbHVlKFwidG90YWxfc2FsYXJ5X3BheWFibGVcIikgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV3UGF5YWJsZUFtb3VudCA9IE51bWJlcih0b3RhbFBheWFibGUpICsgdmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybS5zZXRGaWVsZHNWYWx1ZSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWlkX2Ftb3VudDogbmV3UGF5YWJsZUFtb3VudCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBhZGp1c3RtZW50IGFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtYW1iZXItNjAwIG10LTIgZmxleCBpdGVtcy1zdGFydCBnYXAtMSBiZy1hbWJlci01MCBwLTIgcm91bmRlZCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTYwMCBmb250LWJvbGRcIj7ik5g8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFRoaXMgYW1vdW50IHdpbGwgYmUgYWRkZWQgdG8gdGhlIHBheWFibGUgYW1vdW50e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGFpZF9hbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUGF5YWJsZSBBbW91bnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcnVsZXM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIGVudGVyIHBheWFibGUgYW1vdW50XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwcmVmaXg9XCLigrlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdG90YWxQYXlhYmxlID1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm0uZ2V0RmllbGRWYWx1ZShcInRvdGFsX3NhbGFyeV9wYXlhYmxlXCIpIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG5ld1BhaWRBbW91bnQgPSBOdW1iZXIoZS50YXJnZXQudmFsdWUgfHwgMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV3QWRqdXN0bWVudCA9IG5ld1BhaWRBbW91bnQgLSB0b3RhbFBheWFibGU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QWRqdXN0bWVudEFtb3VudChuZXdBZGp1c3RtZW50KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFBheW1lbnQgVHJhbnNhY3Rpb24gU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC01IHJvdW5kZWQtbGcgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi00IHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVHJhbnNhY3Rpb24gRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGF5bWVudF9tZXRob2RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBNb2RlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBzZWxlY3QgcGF5bWVudCBtb2RlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBwYXltZW50IG1vZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogXCJDYXNoXCIsIHZhbHVlOiBcIkNhc2hcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiT25saW5lIC8gVVBJXCIsIHZhbHVlOiBcIk9ubGluZS9VUElcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiT25saW5lIC8gTkVGVFwiLCB2YWx1ZTogXCJPbmxpbmUvTkVGVFwiIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogXCJPbmxpbmUgLyBJTVBTXCIsIHZhbHVlOiBcIk9ubGluZS9JTVBTXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiBcIk9ubGluZSAvIFJUR1NcIiwgdmFsdWU6IFwiT25saW5lL1JUR1NcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiQmFuayBUcmFuc2ZlclwiLCB2YWx1ZTogXCJCYW5rIFRyYW5zZmVyXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiBcIkNoZXF1ZVwiLCB2YWx1ZTogXCJDaGVxdWVcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiRGlyZWN0IERlcG9zaXRcIiwgdmFsdWU6IFwiRGlyZWN0IERlcG9zaXRcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm0uZ2V0RmllbGRWYWx1ZShcInBheW1lbnRfbWV0aG9kXCIpICE9PSBcIkNhc2hcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0cmFuc2FjdGlvbl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBUcmFuc2FjdGlvbiBJRFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBydWxlcz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtLmdldEZpZWxkVmFsdWUoXCJwYXltZW50X21ldGhvZFwiKSAhPT1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJDYXNoXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlRyYW5zYWN0aW9uIElEIGlzIHJlcXVpcmVkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRyYW5zYWN0aW9uIHJlZmVyZW5jZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb250LW1vbm9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBheV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFBheSBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiUGxlYXNlIHNlbGVjdCBwYXkgZGF0ZVwiIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgZ2V0VmFsdWVQcm9wcz17KHZhbHVlKSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogdmFsdWUgPyBkYXlqcyh2YWx1ZSkgOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBnZXRWYWx1ZUZyb21FdmVudD17KGRhdGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGUgPyBkYXRlLnRvRGF0ZSgpIDogbnVsbFxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPERhdGVQaWNrZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1hdD1cIkREIE1NTSBZWVlZXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWREYXRlPXsoY3VycmVudCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50ICYmIGN1cnJlbnQuaXNBZnRlcihkYXlqcygpLmVuZE9mKFwiZGF5XCIpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvRm9ybT5cclxuICAgICAgICA8L0RyYXdlcj5cclxuICAgICAgICA8TW9kYWxcclxuICAgICAgICAgIHRpdGxlPVwiRGVsZXRlIFNhbGFyeVwiXHJcbiAgICAgICAgICBvcGVuPXtkZWxldGVNb2RhbE9wZW59XHJcbiAgICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0RGVsZXRlTW9kYWxPcGVuKGZhbHNlKX1cclxuICAgICAgICAgIGZvb3Rlcj17W1xyXG4gICAgICAgICAgICA8QnV0dG9uIGtleT1cImNhbmNlbFwiIG9uQ2xpY2s9eygpID0+IHNldERlbGV0ZU1vZGFsT3BlbihmYWxzZSl9PlxyXG4gICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICA8L0J1dHRvbj4sXHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICBrZXk9XCJkZWxldGVcIlxyXG4gICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICBkYW5nZXJcclxuICAgICAgICAgICAgICBsb2FkaW5nPXtkZWxldGVMb2FkaW5nfVxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZUNvbmZpcm0oZGVsZXRlSWQpfT5cclxuICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgPC9CdXR0b24+LFxyXG4gICAgICAgICAgXX0+XHJcbiAgICAgICAgICA8cD5cclxuICAgICAgICAgICAgQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSB0aGlzIHNhbGFyeT8gVGhpcyBhY3Rpb24gY2Fubm90IGJlXHJcbiAgICAgICAgICAgIHVuZG9uZS5cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1hbWJlci04MDAgdGV4dC1sZyBmb250LXNlbWlib2xkIGZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICBTYWxhcnkgQWxyZWFkeSBQcm9jZXNzZWRcclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgb3Blbj17YWxyZWFkeVBhaWRNb2RhbE9wZW59XHJcbiAgICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0QWxyZWFkeVBhaWRNb2RhbE9wZW4oZmFsc2UpfVxyXG4gICAgICAgICAgd2lkdGg9ezkyMH1cclxuICAgICAgICAgIGZvb3Rlcj17W1xyXG4gICAgICAgICAgICA8QnV0dG9uIGtleT1cImNsb3NlXCIgb25DbGljaz17KCkgPT4gc2V0QWxyZWFkeVBhaWRNb2RhbE9wZW4oZmFsc2UpfT5cclxuICAgICAgICAgICAgICBDbG9zZVxyXG4gICAgICAgICAgICA8L0J1dHRvbj4sXHJcbiAgICAgICAgICAgIGV4aXN0aW5nU2FsYXJ5UmVjb3JkPy5zdGF0dXMgPT09IFwiUGVuZGluZ1wiICYmIChcclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICBrZXk9XCJlZGl0XCJcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogXCIjRDRBRjM3XCIsXHJcbiAgICAgICAgICAgICAgICAgIGJvcmRlckNvbG9yOiBcIiNCODg2MEJcIixcclxuICAgICAgICAgICAgICAgICAgY29sb3I6IFwiIzAwMFwiLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgaGFuZGxlRWRpdChleGlzdGluZ1NhbGFyeVJlY29yZC5faWQpO1xyXG4gICAgICAgICAgICAgICAgICBzZXRBbHJlYWR5UGFpZE1vZGFsT3BlbihmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICB9fT5cclxuICAgICAgICAgICAgICAgIEVkaXQgUmVjb3JkXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgICBdfVxyXG4gICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgcGFkZGluZzogXCIyNHB4XCIsXHJcbiAgICAgICAgICAgIG1heEhlaWdodDogXCI3MHZoXCIsXHJcbiAgICAgICAgICAgIG92ZXJmbG93WTogXCJhdXRvXCIsXHJcbiAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogXCIjZmFmYWZhXCIsXHJcbiAgICAgICAgICB9fT5cclxuICAgICAgICAgIHtleGlzdGluZ1NhbGFyeVJlY29yZCA/IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTYgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNSByb3VuZGVkLWxnIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDAgbWItMyBmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LWJhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgU2FsYXJ5IFBlcmlvZFxyXG4gICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtMyB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5Nb250aDo8L3N0cm9uZz4ge2V4aXN0aW5nU2FsYXJ5UmVjb3JkLnNhbGFyeV9tb250aH17XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAge2V4aXN0aW5nU2FsYXJ5UmVjb3JkLnNhbGFyeV95ZWFyfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPkZyb206PC9zdHJvbmc+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIHttb21lbnQoZXhpc3RpbmdTYWxhcnlSZWNvcmQuc2FsYXJ5X2Zyb21fZGF0ZSkuZm9ybWF0KFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJERCBNTU0gWVlZWVwiXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5Ubzo8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAge21vbWVudChleGlzdGluZ1NhbGFyeVJlY29yZC5zYWxhcnlfdG9fZGF0ZSlcclxuICAgICAgICAgICAgICAgICAgICAgIC5zdWJ0cmFjdCgxLCBcImRheVwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgLmZvcm1hdChcIkREIE1NTSBZWVlZXCIpfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICAgICAgICB7LyogQXR0ZW5kYW5jZSBTdW1tYXJ5ICovfVxyXG4gICAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNSByb3VuZGVkLWxnIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDAgbWItMyBmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LWJhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgQXR0ZW5kYW5jZSBTdW1tYXJ5XHJcbiAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy00IGdhcC0zIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPlRvdGFsIERheXM6PC9zdHJvbmc+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIHtleGlzdGluZ1NhbGFyeVJlY29yZC50b3RhbF9kYXlzIHx8IDB9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+UGFpZCBEYXlzOjwvc3Ryb25nPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICB7ZXhpc3RpbmdTYWxhcnlSZWNvcmQucGFpZF9kYXlzIHx8IDB9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+TE9QIERheXM6PC9zdHJvbmc+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIHtleGlzdGluZ1NhbGFyeVJlY29yZC5sb3BfZGF5cyB8fCAwfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPlByZXNlbnQ6PC9zdHJvbmc+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIHtleGlzdGluZ1NhbGFyeVJlY29yZC5wcmVzZW50X2RheXMgfHwgMH1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5BYnNlbnQ6PC9zdHJvbmc+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIHtleGlzdGluZ1NhbGFyeVJlY29yZC5hYnNlbnRfZGF5cyB8fCAwfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPk9uIExlYXZlOjwvc3Ryb25nPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICB7ZXhpc3RpbmdTYWxhcnlSZWNvcmQubGVhdmVfZGF5cyB8fCAwfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPkhhbGYgRGF5czo8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAge2V4aXN0aW5nU2FsYXJ5UmVjb3JkLmhhbGZfZGF5cyB8fCAwfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICAgICAgICB7LyogTW9udGhseSBCdXNpbmVzcyBJbmZvIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiYmctd2hpdGUgcC01IHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBtYi0zIGZsZXggaXRlbXMtY2VudGVyIHRleHQtYmFzZVwiPlxyXG4gICAgICAgICAgICAgICAgICBNb250aGx5IFRhcmdldCAmIEJ1c2luZXNzIERldGFpbHNcclxuICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTMgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+VG90YWwgVGFyZ2V0Ojwvc3Ryb25nPiDigrlcclxuICAgICAgICAgICAgICAgICAgICB7TnVtYmVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgZXhpc3RpbmdTYWxhcnlSZWNvcmQubW9udGhseV9idXNpbmVzc19pbmZvPy50YXJnZXQgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5QcmV2aW91cyBSZW1haW5pbmcgVGFyZ2V0Ojwvc3Ryb25nPiDigrlcclxuICAgICAgICAgICAgICAgICAgICB7TnVtYmVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgZXhpc3RpbmdTYWxhcnlSZWNvcmQubW9udGhseV9idXNpbmVzc19pbmZvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8ucHJldmlvdXNfcmVtYWluaW5nX3RhcmdldCB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPlRvdGFsIEJ1c2luZXNzIENsb3NlZDo8L3N0cm9uZz4g4oK5XHJcbiAgICAgICAgICAgICAgICAgICAge051bWJlcihcclxuICAgICAgICAgICAgICAgICAgICAgIGV4aXN0aW5nU2FsYXJ5UmVjb3JkLm1vbnRobHlfYnVzaW5lc3NfaW5mb1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA/LnRvdGFsX2J1c2luZXNzX2Nsb3NlZCB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPkN1cnJlbnQgUmVtYWluaW5nIFRhcmdldDo8L3N0cm9uZz4g4oK5XHJcbiAgICAgICAgICAgICAgICAgICAge051bWJlcihcclxuICAgICAgICAgICAgICAgICAgICAgIGV4aXN0aW5nU2FsYXJ5UmVjb3JkLm1vbnRobHlfYnVzaW5lc3NfaW5mb1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA/LmN1cnJlbnRfcmVtYWluaW5nX3RhcmdldCB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICAgICAgICB7LyogRWFybmluZ3MgKi99XHJcbiAgICAgICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiYmctd2hpdGUgcC01IHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBtYi0zIGZsZXggaXRlbXMtY2VudGVyIHRleHQtYmFzZVwiPlxyXG4gICAgICAgICAgICAgICAgICBFYXJuaW5nc1xyXG4gICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTIgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICB7T2JqZWN0LmVudHJpZXMoZXhpc3RpbmdTYWxhcnlSZWNvcmQuZWFybmluZ3MgfHwge30pLm1hcChcclxuICAgICAgICAgICAgICAgICAgICAoW2tleSwgdmFsXSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17a2V5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBib3JkZXItZ3JheS0xMDAgcGItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXBpdGFsaXplXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2tleS5yZXBsYWNlKC9fL2csIFwiIFwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtOdW1iZXIodmFsKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICAgICAgICB7LyogRGVkdWN0aW9ucyAqL31cclxuICAgICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIG1iLTMgZmxleCBpdGVtcy1jZW50ZXIgdGV4dC1iYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgIERlZHVjdGlvbnNcclxuICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwic3BhY2UteS0yIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAge09iamVjdC5lbnRyaWVzKGV4aXN0aW5nU2FsYXJ5UmVjb3JkLmRlZHVjdGlvbnMgfHwge30pLm1hcChcclxuICAgICAgICAgICAgICAgICAgICAoW2tleSwgdmFsXSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17a2V5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBib3JkZXItZ3JheS0xMDAgcGItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJjYXBpdGFsaXplXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2tleS5yZXBsYWNlKC9fL2csIFwiIFwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtOdW1iZXIodmFsKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICAgICAgICB7LyogQWRkaXRpb25hbCBQYXltZW50cyAqL31cclxuICAgICAgICAgICAgICB7ZXhpc3RpbmdTYWxhcnlSZWNvcmQuYWRkaXRpb25hbF9wYXltZW50cz8ubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDAgbWItMyBmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LWJhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICBBZGRpdGlvbmFsIFBheW1lbnRzXHJcbiAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTIgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtleGlzdGluZ1NhbGFyeVJlY29yZC5hZGRpdGlvbmFsX3BheW1lbnRzLm1hcCgocGF5LCBpKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGlcclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBib3JkZXItZ3JheS0xMDAgcGItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57cGF5Lm5hbWUgfHwgXCJQYXltZW50XCJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtOdW1iZXIocGF5LnZhbHVlKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIHsvKiBBZGRpdGlvbmFsIERlZHVjdGlvbnMgKi99XHJcbiAgICAgICAgICAgICAge2V4aXN0aW5nU2FsYXJ5UmVjb3JkLmFkZGl0aW9uYWxfZGVkdWN0aW9ucz8ubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDAgbWItMyBmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LWJhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICBBZGRpdGlvbmFsIERlZHVjdGlvbnNcclxuICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInNwYWNlLXktMiB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2V4aXN0aW5nU2FsYXJ5UmVjb3JkLmFkZGl0aW9uYWxfZGVkdWN0aW9ucy5tYXAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAoZGVkLCBpKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsaVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBib3JkZXItZ3JheS0xMDAgcGItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntkZWQubmFtZSB8fCBcIkRlZHVjdGlvblwifTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge051bWJlcihkZWQudmFsdWUpLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIiwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAge2V4aXN0aW5nU2FsYXJ5UmVjb3JkLmFkdmFuY2VfcGF5bWVudHM/Lmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiYmctd2hpdGUgcC01IHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIG1iLTMgZmxleCBpdGVtcy1jZW50ZXIgdGV4dC1iYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQWR2YW5jZSBQYXltZW50c1xyXG4gICAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwic3BhY2UteS0yIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7ZXhpc3RpbmdTYWxhcnlSZWNvcmQuYWR2YW5jZV9wYXltZW50cy5tYXAoKHBheSwgaSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIHBiLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3BheS5uYW1lIHx8IFwiQWR2YW5jZSBQYXltZW50XCJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtOdW1iZXIocGF5LnZhbHVlKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIHtleGlzdGluZ1NhbGFyeVJlY29yZC5jYWxjdWxhdGVkX2luY2VudGl2ZSAhPT0gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDAgbWItMyBmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LWJhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICBJbmNlbnRpdmUgQWRqdXN0bWVudFxyXG4gICAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ2FsY3VsYXRlZCBJbmNlbnRpdmU6XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Bmb250LW1lZGl1bSAke2V4aXN0aW5nU2FsYXJ5UmVjb3JkLmNhbGN1bGF0ZWRfaW5jZW50aXZlID4gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFwidGV4dC1ncmVlbi03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1yZWQtNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAg4oK5XHJcbiAgICAgICAgICAgICAgICAgICAgICB7TWF0aC5hYnMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4aXN0aW5nU2FsYXJ5UmVjb3JkLmNhbGN1bGF0ZWRfaW5jZW50aXZlXHJcbiAgICAgICAgICAgICAgICAgICAgICApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIiwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAge2V4aXN0aW5nU2FsYXJ5UmVjb3JkLmNhbGN1bGF0ZWRfaW5jZW50aXZlID4gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFwiIChCb251cylcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiIChEZWR1Y3Rpb24pXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1hbWJlci01MCB0by13aGl0ZSBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCBwLTUgcm91bmRlZC1sZyBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBtYi0zIGZsZXggaXRlbXMtY2VudGVyIHRleHQtYmFzZVwiPlxyXG4gICAgICAgICAgICAgICAgICBQYXltZW50IFN1bW1hcnlcclxuICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMiB0ZXh0LWdyYXktODAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5CYXNlIENhbGN1bGF0ZWQgU2FsYXJ5Ojwvc3Bhbj57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgICAgICAgIHtOdW1iZXIoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4aXN0aW5nU2FsYXJ5UmVjb3JkPy5hdHRlbmRhbmNlX2RldGFpbHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/LmNhbGN1bGF0ZWRfc2FsYXJ5XHJcbiAgICAgICAgICAgICAgICAgICAgICApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIiwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIHtleGlzdGluZ1NhbGFyeVJlY29yZC5hZHZhbmNlX3BheW1lbnRzPy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5BZHZhbmNlIFBheW1lbnRzOjwvc3Bhbj57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAg4oK5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtOdW1iZXIoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZXhpc3RpbmdTYWxhcnlSZWNvcmQuYWR2YW5jZV9wYXltZW50cy5yZWR1Y2UoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoc3VtLCBwKSA9PiBzdW0gKyBOdW1iZXIocC52YWx1ZSksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIiwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICB7ZXhpc3RpbmdTYWxhcnlSZWNvcmQuYWRkaXRpb25hbF9wYXltZW50cz8ubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+QWRkaXRpb25hbCBQYXltZW50czo8L3NwYW4+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7TnVtYmVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGV4aXN0aW5nU2FsYXJ5UmVjb3JkLmFkZGl0aW9uYWxfcGF5bWVudHMucmVkdWNlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKHN1bSwgcCkgPT4gc3VtICsgTnVtYmVyKHAudmFsdWUpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlRvdGFsIEJhc2UgRGVkdWN0aW9uczo8L3NwYW4+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAg4oK5XHJcbiAgICAgICAgICAgICAgICAgICAgICB7TnVtYmVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBleGlzdGluZ1NhbGFyeVJlY29yZC50b3RhbF9kZWR1Y3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIiwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIHtleGlzdGluZ1NhbGFyeVJlY29yZD8uYWRkaXRpb25hbF9kZWR1Y3Rpb25zPy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5BZGRpdGlvbmFsIERlZHVjdGlvbnM6PC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgICAgICAgICAge051bWJlcihcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBleGlzdGluZ1NhbGFyeVJlY29yZC5hZGRpdGlvbmFsX2RlZHVjdGlvbnMucmVkdWNlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKHN1bSwgZCkgPT4gc3VtICsgTnVtYmVyKGQudmFsdWUpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAge2V4aXN0aW5nU2FsYXJ5UmVjb3JkLmNhbGN1bGF0ZWRfaW5jZW50aXZlICE9PSAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5JbmNlbnRpdmUgQWRqdXN0bWVudDo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGV4aXN0aW5nU2FsYXJ5UmVjb3JkLmNhbGN1bGF0ZWRfaW5jZW50aXZlID4gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcInRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgICAgICAgICAge01hdGguYWJzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGV4aXN0aW5nU2FsYXJ5UmVjb3JkLmNhbGN1bGF0ZWRfaW5jZW50aXZlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtleGlzdGluZ1NhbGFyeVJlY29yZC5jYWxjdWxhdGVkX2luY2VudGl2ZSA+IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiIChEZWR1Y3Rpb24pXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1sZyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBib3JkZXItdCBwdC0yIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5OZXQgUGF5YWJsZTo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgICAgICAgIHtOdW1iZXIoZXhpc3RpbmdTYWxhcnlSZWNvcmQubmV0X3BheWFibGUpLnRvTG9jYWxlU3RyaW5nKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcImVuLUlOXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5QYWlkIEFtb3VudDo8L3NwYW4+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAg4oK5XHJcbiAgICAgICAgICAgICAgICAgICAgICB7TnVtYmVyKGV4aXN0aW5nU2FsYXJ5UmVjb3JkLnBhaWRfYW1vdW50KS50b0xvY2FsZVN0cmluZyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJlbi1JTlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+UmVtYWluaW5nIEJhbGFuY2U6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBOdW1iZXIoZXhpc3RpbmdTYWxhcnlSZWNvcmQucmVtYWluaW5nX2JhbGFuY2UpID4gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJ0ZXh0LXJlZC02MDAgZm9udC1ib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgfT5cclxuICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAge051bWJlcihcclxuICAgICAgICAgICAgICAgICAgICAgICAgZXhpc3RpbmdTYWxhcnlSZWNvcmQucmVtYWluaW5nX2JhbGFuY2VcclxuICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlN0YXR1czo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4aXN0aW5nU2FsYXJ5UmVjb3JkLnN0YXR1cyA9PT0gXCJQYWlkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwidGV4dC1ncmVlbi03MDAgZm9udC1ib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1hbWJlci03MDAgZm9udC1ib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgIH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXhpc3RpbmdTYWxhcnlSZWNvcmQuc3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIHtleGlzdGluZ1NhbGFyeVJlY29yZC50cmFuc2FjdGlvbl9pZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+VHJhbnNhY3Rpb24gSUQ6PC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntleGlzdGluZ1NhbGFyeVJlY29yZC50cmFuc2FjdGlvbl9pZH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5QYXltZW50IE1ldGhvZDo8L3NwYW4+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPntleGlzdGluZ1NhbGFyeVJlY29yZC5wYXltZW50X21ldGhvZCB8fCBcIk4vQVwifTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBoLTMyIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICBMb2FkaW5nIHNhbGFyeSBkZXRhaWxzLi4uXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcbmV4cG9ydCBkZWZhdWx0IFNhbGFyeVBheW1lbnQ7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9TYWxhcnlQYXltZW50LmpzeCJ9