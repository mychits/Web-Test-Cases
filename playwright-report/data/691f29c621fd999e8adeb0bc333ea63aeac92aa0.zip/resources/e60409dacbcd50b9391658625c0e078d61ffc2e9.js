import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Profile.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport5_react["useEffect"]; const useState = __vite__cjsImport5_react["useState"];
import api from "/src/instance/TokenInstance.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
const Profile = () => {
  _s();
  const GlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  useEffect(() => {
    function getAdminUser() {
      const user = localStorage.getItem("user");
      const userObj = JSON.parse(user);
      if (userObj && userObj._id) {
        setId(userObj._id);
      }
    }
    getAdminUser();
  }, []);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [id, setId] = useState("");
  const [error, setError] = useState(null);
  const [currentUpdateAdminUser, setCurrentUpdateAdminUser] = useState(null);
  const [screenLoading, setScreenLoading] = useState(true);
  const [upDateProfileData, setUpDateProfileData] = useState({
    name: "",
    password: "",
    admin_name: ""
  });
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpDateProfileData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  useEffect(() => {
    setScreenLoading(true);
    handleUpdateModalOpen(id);
  }, [id]);
  const handleUpdateModalOpen = async (adminId) => {
    try {
      const response = await api.get(`/admin/get-admin/${adminId}`);
      setPhoneNumber(response.data?.phoneNumber || "");
      setCurrentUpdateAdminUser(response.data);
      setUpDateProfileData({
        name: response.data?.name || "",
        password: response.data?.password || "",
        admin_name: response.data?.admin_name || ""
      });
      setScreenLoading(false);
    } catch (error2) {
      console.error("Error fetching profile:", error2);
    }
  };
  if (screenLoading)
    return /* @__PURE__ */ jsxDEV("div", { className: "w-screen m-24", children: [
      /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-green-600" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
        lineNumber: 90,
        columnNumber: 9
      }, this),
      ";"
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
      lineNumber: 89,
      columnNumber: 5
    }, this);
  const handleUpdate = async () => {
    console.log(upDateProfileData, "updtatebbhhgb");
    try {
      const response = await api.put(`/admin/update-admin/${id}`, {
        phoneNumber,
        name: upDateProfileData.name,
        password: upDateProfileData.password,
        admin_name: upDateProfileData.admin_name
      });
      alert("Profile Updated Successfully");
    } catch (error2) {
      console.error("Error updating profile:", error2);
      setError("Error updating profile");
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
      lineNumber: 126,
      columnNumber: 19
    }, this),
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: GlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
        lineNumber: 127,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold mb-4", children: "Profile" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
        lineNumber: 132,
        columnNumber: 25
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "max-w-md mx-auto p-5 rounded-lg", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "phone", className: "block text-sm font-medium text-gray-700", children: "Phone Number" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
            lineNumber: 135,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "tel",
              id: "phone",
              value: phoneNumber,
              onChange: (e) => setPhoneNumber(e.target.value),
              className: "mt-1 block w-full p-2 border border-gray-300 rounded-md",
              placeholder: "Enter your phone number"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
              lineNumber: 136,
              columnNumber: 33
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
          lineNumber: 134,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "name", className: "block text-sm font-medium text-gray-700", children: "Name" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
            lineNumber: 146,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              id: "name",
              name: "name",
              value: upDateProfileData?.name,
              onChange: handleInputChange,
              className: "mt-1 block w-full p-2 border border-gray-300 rounded-md",
              placeholder: "Update name"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
              lineNumber: 147,
              columnNumber: 33
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
          lineNumber: 145,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "pass", className: "block text-sm font-medium text-gray-700", children: "Password" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
            lineNumber: 158,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              id: "pass",
              name: "password",
              value: upDateProfileData?.password,
              onChange: handleInputChange,
              className: "mt-1 block w-full p-2 border border-gray-300 rounded-md",
              placeholder: "Update Password"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
              lineNumber: 159,
              columnNumber: 33
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
          lineNumber: 157,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
          /* @__PURE__ */ jsxDEV("label", { htmlFor: "aname", className: "block text-sm font-medium text-gray-700", children: "Admin Name" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
            lineNumber: 170,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              id: "aname",
              name: "admin_name",
              value: upDateProfileData?.admin_name,
              onChange: handleInputChange,
              className: "mt-1 block w-full p-2 border border-gray-300 rounded-md",
              placeholder: "Update Admin name"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
              lineNumber: 171,
              columnNumber: 33
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
          lineNumber: 169,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: handleUpdate,
            className: "w-full bg-violet-500 text-white p-2 rounded-md hover:bg-violet-700",
            children: "Update"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
            lineNumber: 182,
            columnNumber: 29
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
        lineNumber: 133,
        columnNumber: 25
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
      lineNumber: 131,
      columnNumber: 21
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
    lineNumber: 125,
    columnNumber: 17
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
    lineNumber: 124,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx",
    lineNumber: 123,
    columnNumber: 5
  }, this);
};
_s(Profile, "UlvqHNj6PZ55Z4o0+iZEYfGcvzE=");
_c = Profile;
export default Profile;
var _c;
$RefreshReg$(_c, "Profile");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Profile.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUZRLFNBaUNBLFVBakNBOzJCQXpGUjtBQUFvQixpREFBK0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDbkQsT0FBT0EsWUFBWTtBQUNuQixTQUFTQyxXQUFXQyxnQkFBZ0I7QUFDcEMsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxvQkFBb0I7QUFHM0IsTUFBTUMsVUFBVUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hCLFFBQU1DLDRCQUE0QkEsQ0FBQ0MsTUFBTTtBQUMzQyxVQUFNLEVBQUVDLE1BQU0sSUFBSUQsRUFBRUU7QUFDcEJDLGtCQUFjRixLQUFLO0FBQUEsRUFDckI7QUFDRVIsWUFBVSxNQUFNO0FBQ1osYUFBU1csZUFBZTtBQUNwQixZQUFNQyxPQUFPQyxhQUFhQyxRQUFRLE1BQU07QUFDeEMsWUFBTUMsVUFBVUMsS0FBS0MsTUFBTUwsSUFBSTtBQUUvQixVQUNJRyxXQUNBQSxRQUFRRyxLQUNWO0FBRUVDLGNBQU1KLFFBQVFHLEdBQUc7QUFBQSxNQUNyQjtBQUFBLElBQ0o7QUFFQVAsaUJBQWE7QUFBQSxFQUNqQixHQUFHLEVBQUU7QUFFTCxRQUFNLENBQUNTLGFBQWFDLGNBQWMsSUFBSXBCLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUNxQixJQUFJSCxLQUFLLElBQUlsQixTQUFTLEVBQUU7QUFDL0IsUUFBTSxDQUFDc0IsT0FBT0MsUUFBUSxJQUFJdkIsU0FBUyxJQUFJO0FBQ3ZDLFFBQU0sQ0FBQ3dCLHdCQUF3QkMseUJBQXlCLElBQUl6QixTQUFTLElBQUk7QUFDeEUsUUFBTSxDQUFDMEIsZUFBZUMsZ0JBQWdCLElBQUkzQixTQUFTLElBQUk7QUFDeEQsUUFBTSxDQUFDNEIsbUJBQW1CQyxvQkFBb0IsSUFBSTdCLFNBQVM7QUFBQSxJQUN2RDhCLE1BQU07QUFBQSxJQUNOQyxVQUFVO0FBQUEsSUFDVkMsWUFBWTtBQUFBLEVBQ2hCLENBQUM7QUFpQkQsUUFBTUMsb0JBQW9CQSxDQUFDM0IsTUFBTTtBQUM3QixVQUFNLEVBQUV3QixNQUFNdkIsTUFBTSxJQUFJRCxFQUFFRTtBQUMxQnFCLHlCQUFxQixDQUFDSyxjQUFjO0FBQUEsTUFDaEMsR0FBR0E7QUFBQUEsTUFDSCxDQUFDSixJQUFJLEdBQUd2QjtBQUFBQSxJQUNaLEVBQUU7QUFBQSxFQUNOO0FBQ0FSLFlBQVUsTUFBTTtBQUNaNEIscUJBQWlCLElBQUk7QUFDckJRLDBCQUFzQmQsRUFBRTtBQUFBLEVBQzVCLEdBQUcsQ0FBQ0EsRUFBRSxDQUFDO0FBR1AsUUFBTWMsd0JBQXdCLE9BQU9DLFlBQVk7QUFDN0MsUUFBSTtBQUNBLFlBQU1DLFdBQVcsTUFBTXBDLElBQUlxQyxJQUFJLG9CQUFvQkYsT0FBTyxFQUFFO0FBRzVEaEIscUJBQWVpQixTQUFTRSxNQUFNcEIsZUFBZSxFQUFFO0FBQy9DTSxnQ0FBMEJZLFNBQVNFLElBQUk7QUFDdkNWLDJCQUFxQjtBQUFBLFFBQ2pCQyxNQUFNTyxTQUFTRSxNQUFNVCxRQUFRO0FBQUEsUUFDN0JDLFVBQVVNLFNBQVNFLE1BQU1SLFlBQVk7QUFBQSxRQUNyQ0MsWUFBWUssU0FBU0UsTUFBTVAsY0FBYztBQUFBLE1BQzdDLENBQUM7QUFDREwsdUJBQWlCLEtBQUs7QUFBQSxJQUUxQixTQUFTTCxRQUFPO0FBQ1prQixjQUFRbEIsTUFBTSwyQkFBMkJBLE1BQUs7QUFBQSxJQUNsRDtBQUFBLEVBQ0o7QUFDQyxNQUFJSTtBQUNMLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsNkJBQUMsa0JBQWUsT0FBTSxvQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQztBQUFBLE1BQUc7QUFBQSxTQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFlRixRQUFNZSxlQUFlLFlBQVk7QUFDN0JELFlBQVFFLElBQUlkLG1CQUFrQixlQUFlO0FBQzdDLFFBQUk7QUFDQSxZQUFNUyxXQUFXLE1BQU1wQyxJQUFJMEMsSUFBSSx1QkFBdUJ0QixFQUFFLElBQUk7QUFBQSxRQUN4REY7QUFBQUEsUUFDQVcsTUFBTUYsa0JBQWtCRTtBQUFBQSxRQUN4QkMsVUFBVUgsa0JBQWtCRztBQUFBQSxRQUM1QkMsWUFBWUosa0JBQWtCSTtBQUFBQSxNQUNsQyxDQUFDO0FBQ0RZLFlBQU0sOEJBQThCO0FBQUEsSUFDeEMsU0FBU3RCLFFBQU87QUFDWmtCLGNBQVFsQixNQUFNLDJCQUEyQkEsTUFBSztBQUM5Q0MsZUFBUyx3QkFBd0I7QUFBQSxJQUNyQztBQUFBLEVBQ0o7QUFFQSxTQUNJLG1DQUNJLGlDQUFDLFNBQ0csaUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwyQkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUTtBQUFBLElBQ2hCO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyw2QkFBNkJsQjtBQUFBQSxRQUM3QixZQUFZO0FBQUE7QUFBQSxNQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUVtQjtBQUFBLElBRVQsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsNkJBQUMsUUFBRyxXQUFVLCtCQUE4Qix1QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRDtBQUFBLE1BQ25ELHVCQUFDLFNBQUksV0FBVSxtQ0FDWDtBQUFBLCtCQUFDLFNBQUksV0FBVSxRQUNYO0FBQUEsaUNBQUMsV0FBTSxTQUFRLFNBQVEsV0FBVSwyQ0FBMEMsNEJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVGO0FBQUEsVUFDdkY7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLElBQUc7QUFBQSxjQUNILE9BQU9jO0FBQUFBLGNBQ1AsVUFBVSxDQUFDYixNQUFNYyxlQUFlZCxFQUFFRSxPQUFPRCxLQUFLO0FBQUEsY0FDOUMsV0FBVTtBQUFBLGNBQ1YsYUFBWTtBQUFBO0FBQUEsWUFOaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTXlDO0FBQUEsYUFSN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsUUFDWDtBQUFBLGlDQUFDLFdBQU0sU0FBUSxRQUFPLFdBQVUsMkNBQTBDLG9CQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RTtBQUFBLFVBQzlFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxJQUFHO0FBQUEsY0FDSCxNQUFLO0FBQUEsY0FDTCxPQUFPcUIsbUJBQW1CRTtBQUFBQSxjQUMxQixVQUFVRztBQUFBQSxjQUNWLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQTtBQUFBLFlBUGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU82QjtBQUFBLGFBVGpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLFFBQ1g7QUFBQSxpQ0FBQyxXQUFNLFNBQVEsUUFBTyxXQUFVLDJDQUEwQyx3QkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Y7QUFBQSxVQUNsRjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsSUFBRztBQUFBLGNBQ0gsTUFBSztBQUFBLGNBQ0wsT0FBT0wsbUJBQW1CRztBQUFBQSxjQUMxQixVQUFVRTtBQUFBQSxjQUNWLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQTtBQUFBLFlBUGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9pQztBQUFBLGFBVHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLFFBQ1g7QUFBQSxpQ0FBQyxXQUFNLFNBQVEsU0FBUSxXQUFVLDJDQUEwQywwQkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUY7QUFBQSxVQUNyRjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsSUFBRztBQUFBLGNBQ0gsTUFBSztBQUFBLGNBQ0wsT0FBT0wsbUJBQW1CSTtBQUFBQSxjQUMxQixVQUFVQztBQUFBQSxjQUNWLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQTtBQUFBLFlBUGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9tQztBQUFBLGFBVHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLFNBQVNRO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBQW9FO0FBQUE7QUFBQSxVQUZsRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFdBdERKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1REE7QUFBQSxTQXpESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMERBO0FBQUEsT0FoRUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlFQSxLQWxFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUVBLEtBcEVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxRUE7QUFFUjtBQUFFckMsR0ExTElELFNBQU87QUFBQTBDLEtBQVAxQztBQTRMTixlQUFlQTtBQXNJZixJQUFBMEM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIk5hdmJhciIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiYXBpIiwiQ2lyY3VsYXJMb2FkZXIiLCJQcm9maWxlIiwiX3MiLCJHbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInZhbHVlIiwidGFyZ2V0Iiwic2V0U2VhcmNoVGV4dCIsImdldEFkbWluVXNlciIsInVzZXIiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwidXNlck9iaiIsIkpTT04iLCJwYXJzZSIsIl9pZCIsInNldElkIiwicGhvbmVOdW1iZXIiLCJzZXRQaG9uZU51bWJlciIsImlkIiwiZXJyb3IiLCJzZXRFcnJvciIsImN1cnJlbnRVcGRhdGVBZG1pblVzZXIiLCJzZXRDdXJyZW50VXBkYXRlQWRtaW5Vc2VyIiwic2NyZWVuTG9hZGluZyIsInNldFNjcmVlbkxvYWRpbmciLCJ1cERhdGVQcm9maWxlRGF0YSIsInNldFVwRGF0ZVByb2ZpbGVEYXRhIiwibmFtZSIsInBhc3N3b3JkIiwiYWRtaW5fbmFtZSIsImhhbmRsZUlucHV0Q2hhbmdlIiwicHJldkRhdGEiLCJoYW5kbGVVcGRhdGVNb2RhbE9wZW4iLCJhZG1pbklkIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwiY29uc29sZSIsImhhbmRsZVVwZGF0ZSIsImxvZyIsInB1dCIsImFsZXJ0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUHJvZmlsZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbi8vaW1wb3J0IFBhc3N3b3JkIGZyb20gXCJhbnRkL2VzL2lucHV0L1Bhc3N3b3JkXCI7XHJcblxyXG5jb25zdCBQcm9maWxlID0gKCkgPT4ge1xyXG4gICAgICBjb25zdCBHbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0U2VhcmNoVGV4dCh2YWx1ZSk7XHJcbiAgfTtcclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgZnVuY3Rpb24gZ2V0QWRtaW5Vc2VyKCkge1xyXG4gICAgICAgICAgICBjb25zdCB1c2VyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgICAgICAgICBjb25zdCB1c2VyT2JqID0gSlNPTi5wYXJzZSh1c2VyKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICAgIHVzZXJPYmogJiZcclxuICAgICAgICAgICAgICAgIHVzZXJPYmouX2lkXHJcbiAgICAgICAgICAgICkge1xyXG5cclxuICAgICAgICAgICAgICAgIHNldElkKHVzZXJPYmouX2lkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZ2V0QWRtaW5Vc2VyKClcclxuICAgIH0sIFtdKVxyXG5cclxuICAgIGNvbnN0IFtwaG9uZU51bWJlciwgc2V0UGhvbmVOdW1iZXJdID0gdXNlU3RhdGUoJycpO1xyXG4gICAgY29uc3QgW2lkLCBzZXRJZF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gICAgY29uc3QgW2N1cnJlbnRVcGRhdGVBZG1pblVzZXIsIHNldEN1cnJlbnRVcGRhdGVBZG1pblVzZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgICAgY29uc3QgW3NjcmVlbkxvYWRpbmcsIHNldFNjcmVlbkxvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgICBjb25zdCBbdXBEYXRlUHJvZmlsZURhdGEsIHNldFVwRGF0ZVByb2ZpbGVEYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgICAgICBuYW1lOiBcIlwiLFxyXG4gICAgICAgIHBhc3N3b3JkOiBcIlwiLFxyXG4gICAgICAgIGFkbWluX25hbWU6IFwiXCIsXHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgLy8gICAgIGNvbnN0IGZldGNoQWRtaW4gPSBhc3luYyAoKSA9PiB7XHJcbiAgICAvLyAgICAgICAgIHRyeSB7XHJcbiAgICAvLyAgICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9hZG1pbi9nZXQtYWRtaW4vJHtpZH1gKTtcclxuICAgIC8vICAgICAgICAgICAgIHNldFBob25lTnVtYmVyKHJlc3BvbnNlLmRhdGEucGhvbmVOdW1iZXIpO1xyXG4gICAgLy8gICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgLy8gICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGFkbWluOlwiLCBlcnJvcik7XHJcbiAgICAvLyAgICAgICAgICAgICBzZXRFcnJvcihcIkVycm9yIGZldGNoaW5nIGFkbWluIGRhdGFcIik7XHJcbiAgICAvLyAgICAgICAgIH1cclxuICAgIC8vICAgICB9O1xyXG4gICAgLy8gICAgIGZldGNoQWRtaW4oKTtcclxuICAgIC8vIH0sIFtpZF0pO1xyXG5cclxuXHJcblxyXG4gICAgY29uc3QgaGFuZGxlSW5wdXRDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgICAgIHNldFVwRGF0ZVByb2ZpbGVEYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgICAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgfTtcclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgc2V0U2NyZWVuTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBoYW5kbGVVcGRhdGVNb2RhbE9wZW4oaWQpO1xyXG4gICAgfSwgW2lkXSk7XHJcbiAgIFxyXG5cclxuICAgIGNvbnN0IGhhbmRsZVVwZGF0ZU1vZGFsT3BlbiA9IGFzeW5jIChhZG1pbklkKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvYWRtaW4vZ2V0LWFkbWluLyR7YWRtaW5JZH1gKTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUuaW5mbyhyZXNwb25zZS5kYXRhLFwiZGF0YSBhZG1pblwiKVxyXG4gICAgICAgICAgICBzZXRQaG9uZU51bWJlcihyZXNwb25zZS5kYXRhPy5waG9uZU51bWJlciB8fCBcIlwiKTtcclxuICAgICAgICAgICAgc2V0Q3VycmVudFVwZGF0ZUFkbWluVXNlcihyZXNwb25zZS5kYXRhKTtcclxuICAgICAgICAgICAgc2V0VXBEYXRlUHJvZmlsZURhdGEoe1xyXG4gICAgICAgICAgICAgICAgbmFtZTogcmVzcG9uc2UuZGF0YT8ubmFtZSB8fCBcIlwiLFxyXG4gICAgICAgICAgICAgICAgcGFzc3dvcmQ6IHJlc3BvbnNlLmRhdGE/LnBhc3N3b3JkIHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICBhZG1pbl9uYW1lOiByZXNwb25zZS5kYXRhPy5hZG1pbl9uYW1lIHx8IFwiXCIsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBzZXRTY3JlZW5Mb2FkaW5nKGZhbHNlKTtcclxuXHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHByb2ZpbGU6XCIsIGVycm9yKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG4gICAgIGlmIChzY3JlZW5Mb2FkaW5nKVxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LXNjcmVlbiBtLTI0XCI+XHJcbiAgICAgICAgPENpcmN1bGFyTG9hZGVyIGNvbG9yPVwidGV4dC1ncmVlbi02MDBcIiAvPjtcclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG5cclxuICAgIC8vIGNvbnN0IGhhbmRsZVVwZGF0ZSA9IGFzeW5jICgpID0+IHtcclxuICAgIC8vICAgICB0cnkge1xyXG4gICAgLy8gICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wdXQoYC9hZG1pbi91cGRhdGUtYWRtaW4vJHtpZH1gLCB7XHJcbiAgICAvLyAgICAgICAgICAgICBwaG9uZU51bWJlcjogcGhvbmVOdW1iZXIsXHJcblxyXG4gICAgLy8gICAgICAgICB9KTtcclxuICAgIC8vICAgICAgICAgYWxlcnQoXCJQcm9maWxlIFVwZGF0ZWQgU3VjY2Vzc2Z1bGx5XCIpXHJcbiAgICAvLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIC8vICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIHByb2ZpbGU6XCIsIGVycm9yKTtcclxuICAgIC8vICAgICAgICAgc2V0RXJyb3IoXCJFcnJvciB1cGRhdGluZyBwcm9maWxlXCIpO1xyXG4gICAgLy8gICAgIH1cclxuICAgIC8vIH07XHJcbiAgICBjb25zdCBoYW5kbGVVcGRhdGUgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2codXBEYXRlUHJvZmlsZURhdGEsXCJ1cGR0YXRlYmJoaGdiXCIpXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucHV0KGAvYWRtaW4vdXBkYXRlLWFkbWluLyR7aWR9YCwge1xyXG4gICAgICAgICAgICAgICAgcGhvbmVOdW1iZXIsXHJcbiAgICAgICAgICAgICAgICBuYW1lOiB1cERhdGVQcm9maWxlRGF0YS5uYW1lLFxyXG4gICAgICAgICAgICAgICAgcGFzc3dvcmQ6IHVwRGF0ZVByb2ZpbGVEYXRhLnBhc3N3b3JkLFxyXG4gICAgICAgICAgICAgICAgYWRtaW5fbmFtZTogdXBEYXRlUHJvZmlsZURhdGEuYWRtaW5fbmFtZSxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIGFsZXJ0KFwiUHJvZmlsZSBVcGRhdGVkIFN1Y2Nlc3NmdWxseVwiKTtcclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgcHJvZmlsZTpcIiwgZXJyb3IpO1xyXG4gICAgICAgICAgICBzZXRFcnJvcihcIkVycm9yIHVwZGF0aW5nIHByb2ZpbGVcIik7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgICAgICAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXtHbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbWItNFwiPlByb2ZpbGU8L2gxPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LW1kIG14LWF1dG8gcC01IHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicGhvbmVcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5QaG9uZSBOdW1iZXI8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGVsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJwaG9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwaG9uZU51bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQaG9uZU51bWJlcihlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdy1mdWxsIHAtMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHlvdXIgcGhvbmUgbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm5hbWVcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5OYW1lPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cERhdGVQcm9maWxlRGF0YT8ubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBwLTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJVcGRhdGUgbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJwYXNzXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+UGFzc3dvcmQ8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwicGFzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cERhdGVQcm9maWxlRGF0YT8ucGFzc3dvcmR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMSBibG9jayB3LWZ1bGwgcC0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVXBkYXRlIFBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImFuYW1lXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+QWRtaW4gTmFtZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJhbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhZG1pbl9uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwRGF0ZVByb2ZpbGVEYXRhPy5hZG1pbl9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdy1mdWxsIHAtMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlVwZGF0ZSBBZG1pbiBuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVVwZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctdmlvbGV0LTUwMCB0ZXh0LXdoaXRlIHAtMiByb3VuZGVkLW1kIGhvdmVyOmJnLXZpb2xldC03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFVwZGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvPlxyXG4gICAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFByb2ZpbGU7XHJcblxyXG5cclxuXHJcbi8vIGNvbnN0IFByb2ZpbGUgPSAoKSA9PiB7XHJcbi8vICAgY29uc3QgW3Bob25lTnVtYmVyLCBzZXRQaG9uZU51bWJlcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbaWQsIHNldElkXSA9IHVzZVN0YXRlKFwiNjc0YTc0ZGJiNmRhOGI2ZTAzNWU5NjUzXCIpOyAvLyBSZXBsYWNlIHdpdGggYWN0dWFsIElEIGxvZ2ljXHJcbi8vICAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuLy8gICBjb25zdCBbdXBEYXRlUHJvZmlsZURhdGEsIHNldFVwRGF0ZVByb2ZpbGVEYXRhXSA9IHVzZVN0YXRlKHtcclxuLy8gICAgIG5hbWU6IFwiXCIsXHJcbi8vICAgICBwYXNzd29yZDogXCJcIixcclxuLy8gICAgIGFkbWluX25hbWU6IFwiXCIsXHJcbi8vICAgfSk7XHJcblxyXG4vLyAgIC8vIEZldGNoIGRhdGEgb24gbW91bnRcclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgaGFuZGxlVXBkYXRlTW9kYWxPcGVuKGlkKTtcclxuLy8gICB9LCBbaWRdKTtcclxuXHJcbi8vICAgLy8gRmV0Y2ggYWRtaW4gcHJvZmlsZSBkZXRhaWxzXHJcbi8vICAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxPcGVuID0gYXN5bmMgKGFkbWluSWQpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL2FkbWluL2dldC1hZG1pbi8ke2FkbWluSWR9YCk7XHJcbi8vICAgICAgIGNvbnN0IGRhdGEgPSByZXNwb25zZS5kYXRhO1xyXG4vLyAgICAgICBzZXRQaG9uZU51bWJlcihkYXRhLnBob25lTnVtYmVyIHx8IFwiXCIpO1xyXG4vLyAgICAgICBzZXRVcERhdGVQcm9maWxlRGF0YSh7XHJcbi8vICAgICAgICAgbmFtZTogZGF0YS5uYW1lIHx8IFwiXCIsXHJcbi8vICAgICAgICAgcGFzc3dvcmQ6IGRhdGEucGFzc3dvcmQgfHwgXCJcIixcclxuLy8gICAgICAgICBhZG1pbl9uYW1lOiBkYXRhLmFkbWluX25hbWUgfHwgXCJcIixcclxuLy8gICAgICAgfSk7XHJcbi8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcHJvZmlsZTpcIiwgZXJyb3IpO1xyXG4vLyAgICAgICBzZXRFcnJvcihcIkVycm9yIGZldGNoaW5nIHByb2ZpbGUgZGF0YVwiKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBJbnB1dCBmaWVsZCBjaGFuZ2UgaGFuZGxlclxyXG4vLyAgIGNvbnN0IGhhbmRsZUlucHV0Q2hhbmdlID0gKGUpID0+IHtcclxuLy8gICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4vLyAgICAgc2V0VXBEYXRlUHJvZmlsZURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4vLyAgICAgICAuLi5wcmV2RGF0YSxcclxuLy8gICAgICAgW25hbWVdOiB2YWx1ZSxcclxuLy8gICAgIH0pKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBVcGRhdGUgcHJvZmlsZVxyXG4vLyAgIGNvbnN0IGhhbmRsZVVwZGF0ZSA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGF3YWl0IGFwaS5wdXQoYC9hZG1pbi91cGRhdGUtYWRtaW4vJHtpZH1gLCB7XHJcbi8vICAgICAgICAgcGhvbmVOdW1iZXIsXHJcbi8vICAgICAgICAgbmFtZTogdXBEYXRlUHJvZmlsZURhdGEubmFtZSxcclxuLy8gICAgICAgICBwYXNzd29yZDogdXBEYXRlUHJvZmlsZURhdGEucGFzc3dvcmQsXHJcbi8vICAgICAgICAgYWRtaW5fbmFtZTogdXBEYXRlUHJvZmlsZURhdGEuYWRtaW5fbmFtZSxcclxuLy8gICAgICAgfSk7XHJcbi8vICAgICAgIGFsZXJ0KFwiUHJvZmlsZSBVcGRhdGVkIFN1Y2Nlc3NmdWxseVwiKTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBwcm9maWxlOlwiLCBlcnJvcik7XHJcbi8vICAgICAgIHNldEVycm9yKFwiRXJyb3IgdXBkYXRpbmcgcHJvZmlsZVwiKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICByZXR1cm4gKFxyXG4vLyAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbi8vICAgICAgIDxTaWRlYmFyIC8+XHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4vLyAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG1iLTRcIj5Qcm9maWxlPC9oMT5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LW1kIG14LWF1dG8gcC01IHJvdW5kZWQtbGdcIj5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4vLyAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInBob25lXCIgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbi8vICAgICAgICAgICAgICAgUGhvbmUgTnVtYmVyXHJcbi8vICAgICAgICAgICAgIDwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgIHR5cGU9XCJ0ZWxcIlxyXG4vLyAgICAgICAgICAgICAgIGlkPVwicGhvbmVcIlxyXG4vLyAgICAgICAgICAgICAgIHZhbHVlPXtwaG9uZU51bWJlcn1cclxuLy8gICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFBob25lTnVtYmVyKGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBwLTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kXCJcclxuLy8gICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHlvdXIgcGhvbmUgbnVtYmVyXCJcclxuLy8gICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbi8vICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwibmFtZVwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4vLyAgICAgICAgICAgICAgIE5hbWVcclxuLy8gICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4vLyAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbi8vICAgICAgICAgICAgICAgbmFtZT1cIm5hbWVcIlxyXG4vLyAgICAgICAgICAgICAgIHZhbHVlPXt1cERhdGVQcm9maWxlRGF0YS5uYW1lfVxyXG4vLyAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBwLTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kXCJcclxuLy8gICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlVwZGF0ZSBuYW1lXCJcclxuLy8gICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbi8vICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicGFzc3dvcmRcIiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuLy8gICAgICAgICAgICAgICBQYXNzd29yZFxyXG4vLyAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbi8vICAgICAgICAgICAgICAgaWQ9XCJwYXNzd29yZFwiXHJcbi8vICAgICAgICAgICAgICAgbmFtZT1cInBhc3N3b3JkXCJcclxuLy8gICAgICAgICAgICAgICB2YWx1ZT17dXBEYXRlUHJvZmlsZURhdGEucGFzc3dvcmR9XHJcbi8vICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgdy1mdWxsIHAtMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWRcIlxyXG4vLyAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVXBkYXRlIHBhc3N3b3JkXCJcclxuLy8gICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbi8vICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiYWRtaW5fbmFtZVwiIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4vLyAgICAgICAgICAgICAgIEFkbWluIE5hbWVcclxuLy8gICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4vLyAgICAgICAgICAgICAgIGlkPVwiYWRtaW5fbmFtZVwiXHJcbi8vICAgICAgICAgICAgICAgbmFtZT1cImFkbWluX25hbWVcIlxyXG4vLyAgICAgICAgICAgICAgIHZhbHVlPXt1cERhdGVQcm9maWxlRGF0YS5hZG1pbl9uYW1lfVxyXG4vLyAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0xIGJsb2NrIHctZnVsbCBwLTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kXCJcclxuLy8gICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlVwZGF0ZSBhZG1pbiBuYW1lXCJcclxuLy8gICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVVcGRhdGV9XHJcbi8vICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zZWNvbmRhcnkgdGV4dC13aGl0ZSBwLTIgcm91bmRlZC1tZCBob3ZlcjpiZy1zZWNvbmRhcnlcIlxyXG4vLyAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICBVcGRhdGVcclxuLy8gICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgIDwvZGl2PlxyXG4vLyAgICk7XHJcbi8vIH07XHJcblxyXG4vLyBleHBvcnQgZGVmYXVsdCBQcm9maWxlO1xyXG5cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1Byb2ZpbGUuanN4In0=