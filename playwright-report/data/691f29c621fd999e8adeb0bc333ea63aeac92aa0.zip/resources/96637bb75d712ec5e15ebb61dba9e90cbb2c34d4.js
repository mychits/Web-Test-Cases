import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/receipts/CustomReceiptOne.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const Receipt = ({ id, orderType, user_name, others, status, collectedBy, createdAt, viewMode = "grid" }) => {
  const getStatusStyles = (stat) => {
    switch (stat?.toUpperCase()) {
      case "PAID":
        return "bg-green-100 text-green-700 border-green-200";
      case "ACTIVE":
        return "bg-violet-100 text-violet-700 border-violet-200";
      default:
        return "bg-red-100 text-red-700 border-red-200";
    }
  };
  if (viewMode === "list") {
    return /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-[60px_120px_1fr_1.5fr_120px_100px_120px] items-center bg-white p-4 border-b border-gray-200 hover:bg-gray-50 font-mono text-xs transition-colors gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "text-gray-400", children: [
        "#",
        id
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
        lineNumber: 16,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500 truncate", children: createdAt || "" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
        lineNumber: 18,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "font-bold uppercase truncate", children: user_name || "N/A" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
        lineNumber: 22,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-gray-600 italic truncate pr-4", children: others || "N/A" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
        lineNumber: 26,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "font-semibold truncate uppercase", children: orderType || "N/A" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
        lineNumber: 30,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-start", children: /* @__PURE__ */ jsxDEV("span", { className: `px-2 py-0.5 rounded border text-[10px] font-bold whitespace-nowrap ${getStatusStyles(status)}`, children: status || "N/A" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
        lineNumber: 35,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
        lineNumber: 34,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-right text-gray-500 truncate", children: collectedBy || "Admin" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
        lineNumber: 40,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
      lineNumber: 14,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-5 shadow-md border border-gray-200 rounded-sm font-mono text-xs text-gray-800 w-full hover:shadow-lg transition-shadow", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "text-center mb-3", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-sm font-bold uppercase tracking-tighter", children: "Transaction Receipt" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
        lineNumber: 52,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "opacity-60 text-[10px]", children: [
        "# ",
        id
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
        lineNumber: 53,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
      lineNumber: 51,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "border-t border-dashed border-gray-300 my-3" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
      lineNumber: 55,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between gap-2", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 uppercase", children: "Type:" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
          lineNumber: 58,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-right", children: orderType }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
          lineNumber: 59,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
        lineNumber: 57,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between gap-2", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 uppercase", children: "Customer:" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
          lineNumber: 62,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-right", children: user_name || "N/A" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
          lineNumber: 63,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
        lineNumber: 61,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between gap-2", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 uppercase", children: "Status:" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
          lineNumber: 66,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: `px-1.5 py-0.5 rounded border font-bold ${getStatusStyles(status)}`, children: status }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
          lineNumber: 67,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
        lineNumber: 65,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
      lineNumber: 56,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "border-t border-dashed border-gray-300 my-3" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
      lineNumber: 72,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "min-h-[40px]", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 uppercase block mb-1", children: "Details:" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
        lineNumber: 74,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "italic text-[10px] leading-tight text-gray-600 line-clamp-2", children: others || "N/A" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
        lineNumber: 75,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
      lineNumber: 73,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "border-t-2 border-double border-gray-300 mt-4 pt-2 text-center", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] text-gray-400 uppercase", children: "Collected By" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
        lineNumber: 78,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "font-bold text-gray-700 uppercase", children: collectedBy || "ADMIN" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
        lineNumber: 79,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
      lineNumber: 77,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "border-t-2 border-double border-gray-300 mt-4 pt-2 text-center", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] text-gray-400 uppercase", children: "Transaction Date" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
        lineNumber: 83,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "font-bold text-gray-700 uppercase", children: createdAt || "N/A" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
        lineNumber: 84,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
      lineNumber: 82,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx",
    lineNumber: 50,
    columnNumber: 5
  }, this);
};
_c = Receipt;
export default Receipt;
var _c;
$RefreshReg$(_c, "Receipt");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/receipts/CustomReceiptOne.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZVE7QUFmUixPQUFNQSxvQkFBaUJDO0FBQXNCQyxNQUFNLGNBQVVDLE9BQVcsc0JBQXFCLGVBQWdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUUzRyxRQUFNQyxrQkFBa0JBLENBQUNDLFNBQVM7QUFDaEMsWUFBUUEsTUFBTUMsWUFBWSxHQUFDO0FBQUEsTUFDekIsS0FBSztBQUFRLGVBQU87QUFBQSxNQUNwQixLQUFLO0FBQVUsZUFBTztBQUFBLE1BQ3RCO0FBQVMsZUFBTztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUVBLE1BQUlDLGFBQWEsUUFBUTtBQUV2QixXQUNFLHVCQUFDLFNBQUksV0FBVSx5S0FFYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxpQkFBZ0I7QUFBQTtBQUFBLFFBQUVDO0FBQUFBLFdBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0M7QUFBQSxNQUVwQyx1QkFBQyxTQUFJLFdBQVUsMEJBQ1pDLHVCQUFhLE1BRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGdDQUNaQyx1QkFBYSxTQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxzQ0FDWlIsb0JBQVUsU0FEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxvQ0FDWkQsdUJBQWEsU0FEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsc0JBQ2IsaUNBQUMsVUFBSyxXQUFXLHNFQUFzRUcsZ0JBQWdCTyxNQUFNLENBQUMsSUFDM0dBLG9CQUFVLFNBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUscUNBQ1pSLHlCQUFlLFdBRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4QkE7QUFBQSxFQUVKO0FBR0EsU0FDRSx1QkFBQyxTQUFJLFdBQVUscUlBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsZ0RBQStDLG1DQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdGO0FBQUEsTUFDaEYsdUJBQUMsT0FBRSxXQUFVLDBCQUF5QjtBQUFBO0FBQUEsUUFBR0s7QUFBQUEsV0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QztBQUFBLFNBRjlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLGlEQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEQ7QUFBQSxJQUM1RCx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBLCtCQUFDLFVBQUssV0FBVSwyQkFBMEIscUJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0M7QUFBQSxRQUMvQyx1QkFBQyxVQUFLLFdBQVUsd0JBQXdCUCx1QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRDtBQUFBLFdBRnBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUEsK0JBQUMsVUFBSyxXQUFVLDJCQUEwQix5QkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRDtBQUFBLFFBQ25ELHVCQUFDLFVBQUssV0FBVSx3QkFBd0JTLHVCQUFhLFNBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkQ7QUFBQSxXQUY3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBLCtCQUFDLFVBQUssV0FBVSwyQkFBMEIsdUJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUQ7QUFBQSxRQUNqRCx1QkFBQyxVQUFLLFdBQVcsMENBQTBDTixnQkFBZ0JPLE1BQU0sQ0FBQyxJQUMvRUEsb0JBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxTQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLGlEQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEQ7QUFBQSxJQUM1RCx1QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSw2QkFBQyxVQUFLLFdBQVUsc0NBQXFDLHdCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZEO0FBQUEsTUFDN0QsdUJBQUMsT0FBRSxXQUFVLCtEQUErRFQsb0JBQVUsU0FBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RjtBQUFBLFNBRjlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLGtFQUNiO0FBQUEsNkJBQUMsT0FBRSxXQUFVLHVDQUFzQyw0QkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRDtBQUFBLE1BQy9ELHVCQUFDLE9BQUUsV0FBVSxxQ0FBcUNDLHlCQUFlLFdBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUU7QUFBQSxTQUYzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxrRUFDYjtBQUFBLDZCQUFDLE9BQUUsV0FBVSx1Q0FBc0MsZ0NBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUU7QUFBQSxNQUNuRSx1QkFBQyxPQUFFLFdBQVUscUNBQXFDTSx1QkFBYSxTQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFFO0FBQUEsU0FGdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsT0FuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9DQTtBQUVKO0FBQUVHLEtBdkZJWjtBQXlGTixlQUFlQTtBQUFRLElBQUFZO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWNlaXB0Iiwib3JkZXJUeXBlIiwib3RoZXJzIiwiY29sbGVjdGVkQnkiLCJnZXRTdGF0dXNTdHlsZXMiLCJzdGF0IiwidG9VcHBlckNhc2UiLCJ2aWV3TW9kZSIsImlkIiwiY3JlYXRlZEF0IiwidXNlcl9uYW1lIiwic3RhdHVzIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ3VzdG9tUmVjZWlwdE9uZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgUmVjZWlwdCA9ICh7IGlkLCBvcmRlclR5cGUsIHVzZXJfbmFtZSwgb3RoZXJzLCBzdGF0dXMsIGNvbGxlY3RlZEJ5LCBjcmVhdGVkQXQsIHZpZXdNb2RlID0gJ2dyaWQnIH0pID0+IHtcclxuXHJcbiAgY29uc3QgZ2V0U3RhdHVzU3R5bGVzID0gKHN0YXQpID0+IHtcclxuICAgIHN3aXRjaCAoc3RhdD8udG9VcHBlckNhc2UoKSkge1xyXG4gICAgICBjYXNlICdQQUlEJzogcmV0dXJuICdiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi03MDAgYm9yZGVyLWdyZWVuLTIwMCc7XHJcbiAgICAgIGNhc2UgJ0FDVElWRSc6IHJldHVybiAnYmctdmlvbGV0LTEwMCB0ZXh0LXZpb2xldC03MDAgYm9yZGVyLXZpb2xldC0yMDAnO1xyXG4gICAgICBkZWZhdWx0OiByZXR1cm4gJ2JnLXJlZC0xMDAgdGV4dC1yZWQtNzAwIGJvcmRlci1yZWQtMjAwJztcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBpZiAodmlld01vZGUgPT09ICdsaXN0Jykge1xyXG4gICAgLy8gTGlzdCBWaWV3IChUYWJsZSBSb3cgU3R5bGUpXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLVs2MHB4XzEyMHB4XzFmcl8xLjVmcl8xMjBweF8xMDBweF8xMjBweF0gaXRlbXMtY2VudGVyIGJnLXdoaXRlIHAtNCBib3JkZXItYiBib3JkZXItZ3JheS0yMDAgaG92ZXI6YmctZ3JheS01MCBmb250LW1vbm8gdGV4dC14cyB0cmFuc2l0aW9uLWNvbG9ycyBnYXAtNFwiPlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIj4je2lkfTwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdHJ1bmNhdGVcIj5cclxuICAgICAgICAgIHtjcmVhdGVkQXQgfHwgJyd9XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHVwcGVyY2FzZSB0cnVuY2F0ZVwiPlxyXG4gICAgICAgICAge3VzZXJfbmFtZSB8fCBcIk4vQVwifVxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgaXRhbGljIHRydW5jYXRlIHByLTRcIj5cclxuICAgICAgICAgIHtvdGhlcnMgfHwgXCJOL0FcIn1cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRydW5jYXRlIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAge29yZGVyVHlwZSB8fCBcIk4vQVwifVxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1zdGFydFwiPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgcHgtMiBweS0wLjUgcm91bmRlZCBib3JkZXIgdGV4dC1bMTBweF0gZm9udC1ib2xkIHdoaXRlc3BhY2Utbm93cmFwICR7Z2V0U3RhdHVzU3R5bGVzKHN0YXR1cyl9YH0+XHJcbiAgICAgICAgICAgIHtzdGF0dXMgfHwgXCJOL0FcIn1cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0IHRleHQtZ3JheS01MDAgdHJ1bmNhdGVcIj5cclxuICAgICAgICAgIHtjb2xsZWN0ZWRCeSB8fCAnQWRtaW4nfVxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNSBzaGFkb3ctbWQgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLXNtIGZvbnQtbW9ubyB0ZXh0LXhzIHRleHQtZ3JheS04MDAgdy1mdWxsIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLXNoYWRvd1wiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIG1iLTNcIj5cclxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXRpZ2h0ZXJcIj5UcmFuc2FjdGlvbiBSZWNlaXB0PC9oMj5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJvcGFjaXR5LTYwIHRleHQtWzEwcHhdXCI+IyB7aWR9PC9wPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItZGFzaGVkIGJvcmRlci1ncmF5LTMwMCBteS0zXCIgLz5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPlR5cGU6PC9zcGFuPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtcmlnaHRcIj57b3JkZXJUeXBlfTwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPkN1c3RvbWVyOjwvc3Bhbj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXJpZ2h0XCI+e3VzZXJfbmFtZSB8fCBcIk4vQVwifTwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPlN0YXR1czo8L3NwYW4+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0xLjUgcHktMC41IHJvdW5kZWQgYm9yZGVyIGZvbnQtYm9sZCAke2dldFN0YXR1c1N0eWxlcyhzdGF0dXMpfWB9PlxyXG4gICAgICAgICAgICB7c3RhdHVzfVxyXG4gICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItZGFzaGVkIGJvcmRlci1ncmF5LTMwMCBteS0zXCIgLz5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1bNDBweF1cIj5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSBibG9jayBtYi0xXCI+RGV0YWlsczo8L3NwYW4+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiaXRhbGljIHRleHQtWzEwcHhdIGxlYWRpbmctdGlnaHQgdGV4dC1ncmF5LTYwMCBsaW5lLWNsYW1wLTJcIj57b3RoZXJzIHx8IFwiTi9BXCJ9PC9wPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItdC0yIGJvcmRlci1kb3VibGUgYm9yZGVyLWdyYXktMzAwIG10LTQgcHQtMiB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtZ3JheS00MDAgdXBwZXJjYXNlXCI+Q29sbGVjdGVkIEJ5PC9wPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWdyYXktNzAwIHVwcGVyY2FzZVwiPntjb2xsZWN0ZWRCeSB8fCAnQURNSU4nfTwvcD5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci10LTIgYm9yZGVyLWRvdWJsZSBib3JkZXItZ3JheS0zMDAgbXQtNCBwdC0yIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1ncmF5LTQwMCB1cHBlcmNhc2VcIj5UcmFuc2FjdGlvbiBEYXRlPC9wPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWdyYXktNzAwIHVwcGVyY2FzZVwiPntjcmVhdGVkQXQgfHwgJ04vQSd9PC9wPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBSZWNlaXB0OyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9jb21wb25lbnRzL3JlY2VpcHRzL0N1c3RvbVJlY2VpcHRPbmUuanN4In0=