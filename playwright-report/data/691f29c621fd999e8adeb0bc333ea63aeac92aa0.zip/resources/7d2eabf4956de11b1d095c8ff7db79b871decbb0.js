import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/UserMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { Users, ChevronRight, Zap, Shield, UserCheck, Sparkles, ArrowUpRight, Grid3x3, UserMinus, AlertTriangle } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import { IoIosPersonAdd } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { MdCancel } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { FaPlus } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import __vite__cjsImport10_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport10_react["useEffect"]; const useState = __vite__cjsImport10_react["useState"];
import User from "/src/pages/User.jsx";
import UnApprovedCustomer from "/src/pages/UnApprovedCustomer.jsx";
import { GoDotFill } from "/node_modules/.vite/deps/react-icons_go.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
const UserMenu = () => {
  _s();
  const [filter, setFilter] = useState("customers");
  const [showTips, setShowTips] = useState(false);
  const [total, setTotal] = useState({ totalCustomer: 0, totalUnverifiedCustomers: 0 });
  const navigate = useNavigate();
  const [showUserModal, setShowUserModal] = useState(false);
  const [errors, setErrors] = useState({});
  const [areas, setAreas] = useState([]);
  const cardData = [
    {
      title: "Total Customers",
      value: total.totalCustomer,
      description: "Overall Registered Users",
      icon: /* @__PURE__ */ jsxDEV(Users, { size: 20 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
        lineNumber: 55,
        columnNumber: 11
      }, this),
      iconColor: "text-blue-500",
      iconBgColor: "bg-blue-50",
      titleColor: "text-blue-600",
      dividerColor: "bg-blue-200"
    },
    {
      title: "Active Customers",
      value: "560",
      description: "Verified & Active Users",
      icon: /* @__PURE__ */ jsxDEV(UserCheck, { size: 20 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
        lineNumber: 65,
        columnNumber: 11
      }, this),
      iconColor: "text-emerald-500",
      iconBgColor: "bg-emerald-50",
      titleColor: "text-emerald-600",
      dividerColor: "bg-emerald-200"
    },
    {
      title: "Unverified Customers",
      value: total.totalUnverifiedCustomers,
      description: "Pending Verification",
      icon: /* @__PURE__ */ jsxDEV(UserMinus, { size: 20 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
        lineNumber: 75,
        columnNumber: 11
      }, this),
      iconColor: "text-amber-500",
      iconBgColor: "bg-amber-50",
      titleColor: "text-amber-600",
      dividerColor: "bg-amber-200"
    },
    {
      title: "Overdue Payments",
      value: "₹1,50,000",
      description: "Pending Collections",
      icon: /* @__PURE__ */ jsxDEV(AlertTriangle, { size: 20 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
        lineNumber: 85,
        columnNumber: 11
      }, this),
      iconColor: "text-red-500",
      iconBgColor: "bg-red-50",
      titleColor: "text-red-600",
      dividerColor: "bg-red-200"
    }
  ];
  useEffect(() => {
    const fetchTotalCount = async () => {
      try {
        const [response1, response2] = await Promise.all(
          [
            api.get("/user/get-new-user"),
            api.get("/user/approval-status/false")
          ]
        );
        const data1 = await response1.data;
        const data2 = await response2.data;
        setTotal((prev) => ({
          ...prev,
          // keep existing values
          totalCustomer: data1?.length,
          totalUnverifiedCustomers: data2?.length || 0
        }));
      } catch (error) {
        console.error("Error fetching total counts:", error);
      }
    };
    fetchTotalCount();
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen w-full relative overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
        lineNumber: 127,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-hidden", children: [
        /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
          lineNumber: 129,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-8 relative", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "relative group", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "absolute -inset-1 bg-gradient-to-r from-violet-600 to-purple-600 rounded-2xl blur-lg opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-tilt" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
                  lineNumber: 136,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "relative w-12 h-12 rounded-2xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-2xl", children: /* @__PURE__ */ jsxDEV(Users, { className: "w-6 h-6 text-white" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
                  lineNumber: 138,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
                  lineNumber: 137,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
                lineNumber: 135,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold bg-gradient-to-r from-slate-900 via-purple-900 to-slate-900 bg-clip-text text-transparent", children: "Customer Management" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
                  lineNumber: 142,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-slate-600 mt-1 text-sm", children: "Manage and organize your customer base" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
                  lineNumber: 145,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
                lineNumber: 141,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
              lineNumber: 134,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => {
                    setFilter("customers");
                    setShowUserModal(true);
                    setErrors({});
                  },
                  className: "ml-4 bg-violet-500 text-white px-4 py-2 rounded shadow-md hover:bg-blue-800 transition duration-200",
                  children: "+ Add Customer"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
                  lineNumber: 150,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setShowTips((prev) => !prev),
                  className: "text-violet-500 font-medium hover:underline mb-2",
                  children: showTips ? "Hide Quick Tips" : "Show Quick Tips"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
                  lineNumber: 163,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
              lineNumber: 149,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
            lineNumber: 133,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
            lineNumber: 132,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative w-full h-0 top-1", children: /* @__PURE__ */ jsxDEV("div", { className: "absolute top-12 right-4", children: showTips && /* @__PURE__ */ jsxDEV("div", { className: "absolute bottom-full right-0  mb-2 \r\n                      w-80 p-3 bg-gray-800 text-white text-xs rounded-md \r\n                      shadow-lg z-[9999]", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setShowTips(false),
                className: "absolute  right-1 text-red text-sm font-bold hover:text-gray-300",
                children: "×"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
                lineNumber: 182,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold mb-1 inline-block border-b-2 border-violet-500", children: "Quick Tips" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
              lineNumber: 188,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "leading-relaxed flex items-start gap-2", children: [
              /* @__PURE__ */ jsxDEV(GoDotFill, { className: "text-red-500 mt-1" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
                lineNumber: 190,
                columnNumber: 23
              }, this),
              "Use the Customer directory to manage customer information, update customer details all in one place."
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
              lineNumber: 189,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "leading-relaxed flex items-start gap-2", children: [
              /* @__PURE__ */ jsxDEV(GoDotFill, { className: "text-red-500 mt-1" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
                lineNumber: 194,
                columnNumber: 23
              }, this),
              "Use the Customer directory to manage Unverified Customers Information, update customer information all in one place."
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
              lineNumber: 193,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
            lineNumber: 179,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
            lineNumber: 175,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
            lineNumber: 172,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 mb-6 mt-5", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setFilter("customers"),
                className: `px-4 py-2 rounded ${filter === "customers" ? "bg-violet-500 text-white" : "bg-gray-200"}`,
                children: [
                  "Customers",
                  /* @__PURE__ */ jsxDEV("span", { className: `
      ml-2 px-2 py-0.5 text-xs font-bold rounded-full bg-purple-400 text-black"
      }
    `, children: total?.totalCustomer }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
                    lineNumber: 253,
                    columnNumber: 17
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
                lineNumber: 245,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setFilter("unverified"),
                className: `px-4 py-2 rounded ${filter === "unverified" ? "bg-violet-500 text-white" : "bg-gray-200"}`,
                children: [
                  "Unverified Customers",
                  /* @__PURE__ */ jsxDEV("span", { className: `ml-2 px-2 py-0.5 text-xs font-bold rounded-full bg-purple-400 text-black"}`, children: total?.totalUnverifiedCustomers }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
                    lineNumber: 269,
                    columnNumber: 17
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
                lineNumber: 261,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
            lineNumber: 244,
            columnNumber: 13
          }, this),
          filter === "customers" && /* @__PURE__ */ jsxDEV(
            User,
            {
              showUserModal,
              setShowUserModal,
              errors,
              setErrors
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
              lineNumber: 276,
              columnNumber: 40
            },
            this
          ),
          filter === "unverified" && /* @__PURE__ */ jsxDEV(UnApprovedCustomer, { hideSidebar: true }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
            lineNumber: 283,
            columnNumber: 41
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
          lineNumber: 130,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
        lineNumber: 128,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
      lineNumber: 117,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("style", { jsx: true, children: `
        @keyframes blob {
          0% {
            transform: translate(0px, 0px) scale(1);
          }
          33% {
            transform: translate(30px, -50px) scale(1.1);
          }
          66% {
            transform: translate(-20px, 20px) scale(0.9);
          }
          100% {
            transform: translate(0px, 0px) scale(1);
          }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
        @keyframes tilt {
          0%, 50%, 100% {
            transform: rotate(0deg);
          }
          25% {
            transform: rotate(0.5deg);
          }
          75% {
            transform: rotate(-0.5deg);
          }
        }
        .animate-tilt {
          animation: tilt 10s infinite;
        }
      ` }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
      lineNumber: 321,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx",
    lineNumber: 116,
    columnNumber: 5
  }, this);
};
_s(UserMenu, "Qy2sUS1uQ5fp8La2zURp7X3ppl4=", false, function() {
  return [useNavigate];
});
_c = UserMenu;
export default UserMenu;
var _c;
$RefreshReg$(_c, "UserMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserMenu.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0RZOzJCQXREWjtBQUFlQSxNQUFXLGNBQVEsNkJBQWtCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3BELE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsYUFBYTtBQUNwQixTQUFTQyxPQUFPQyxjQUFjQyxLQUFLQyxRQUFRQyxXQUFXQyxVQUFVQyxjQUFjQyxTQUFTQyxXQUFXQyxxQkFBcUI7QUFDdkgsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLFdBQVdDLGdCQUFnQjtBQUNwQyxPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLHdCQUF3QjtBQUMvQixTQUFTQyxpQkFBaUI7QUFDMUIsT0FBT0MsU0FBUztBQUVoQixNQUFNQyxXQUFXQSxNQUFNO0FBQUFDLEtBQUE7QUFDckIsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUlSLFNBQVMsV0FBVztBQUNoRCxRQUFNLENBQUNTLFVBQVVDLFdBQVcsSUFBSVYsU0FBUyxLQUFLO0FBQzlDLFFBQU0sQ0FBQ1csT0FBT0MsUUFBUSxJQUFJWixTQUFTLEVBQUVhLGVBQWUsR0FBR0MsMEJBQTBCLEVBQUUsQ0FBQztBQUNwRixRQUFNQyxXQUFXaEMsWUFBWTtBQUM3QixRQUFNLENBQUNpQyxlQUFlQyxnQkFBZ0IsSUFBSWpCLFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUNrQixRQUFRQyxTQUFTLElBQUluQixTQUFTLENBQUMsQ0FBQztBQTZCdkMsUUFBTSxDQUFDb0IsT0FBT0MsUUFBUSxJQUFJckIsU0FBUyxFQUFFO0FBQ3JDLFFBQU1zQixXQUFXO0FBQUEsSUFDZjtBQUFBLE1BQ0VDLE9BQU87QUFBQSxNQUNQQyxPQUFPYixNQUFNRTtBQUFBQSxNQUNiWSxhQUFhO0FBQUEsTUFDYkMsTUFBTSx1QkFBQyxTQUFNLE1BQU0sTUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdCO0FBQUEsTUFDdEJDLFdBQVc7QUFBQSxNQUNYQyxhQUFhO0FBQUEsTUFDYkMsWUFBWTtBQUFBLE1BQ1pDLGNBQWM7QUFBQSxJQUNoQjtBQUFBLElBQ0E7QUFBQSxNQUNFUCxPQUFPO0FBQUEsTUFDUEMsT0FBTztBQUFBLE1BQ1BDLGFBQWE7QUFBQSxNQUNiQyxNQUFNLHVCQUFDLGFBQVUsTUFBTSxNQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9CO0FBQUEsTUFDMUJDLFdBQVc7QUFBQSxNQUNYQyxhQUFhO0FBQUEsTUFDYkMsWUFBWTtBQUFBLE1BQ1pDLGNBQWM7QUFBQSxJQUNoQjtBQUFBLElBQ0E7QUFBQSxNQUNFUCxPQUFPO0FBQUEsTUFDUEMsT0FBT2IsTUFBTUc7QUFBQUEsTUFDYlcsYUFBYTtBQUFBLE1BQ2JDLE1BQU0sdUJBQUMsYUFBVSxNQUFNLE1BQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0I7QUFBQSxNQUMxQkMsV0FBVztBQUFBLE1BQ1hDLGFBQWE7QUFBQSxNQUNiQyxZQUFZO0FBQUEsTUFDWkMsY0FBYztBQUFBLElBQ2hCO0FBQUEsSUFDQTtBQUFBLE1BQ0VQLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE1BQU0sdUJBQUMsaUJBQWMsTUFBTSxNQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdCO0FBQUEsTUFDOUJDLFdBQVc7QUFBQSxNQUNYQyxhQUFhO0FBQUEsTUFDYkMsWUFBWTtBQUFBLE1BQ1pDLGNBQWM7QUFBQSxJQUNoQjtBQUFBLEVBQUM7QUFFSC9CLFlBQVUsTUFBTTtBQUVkLFVBQU1nQyxrQkFBa0IsWUFBWTtBQUNsQyxVQUFJO0FBQ0YsY0FBTSxDQUFDQyxXQUFXQyxTQUFTLElBQUksTUFBTUMsUUFBUUM7QUFBQUEsVUFBSTtBQUFBLFlBQy9DL0IsSUFBSWdDLElBQUksb0JBQW9CO0FBQUEsWUFDNUJoQyxJQUFJZ0MsSUFBSSw2QkFBNkI7QUFBQSxVQUFDO0FBQUEsUUFDdkM7QUFDRCxjQUFNQyxRQUFRLE1BQU1MLFVBQVVNO0FBQzlCLGNBQU1DLFFBQVEsTUFBTU4sVUFBVUs7QUFDN0IxQixpQkFBUyxDQUFBNEIsVUFBUztBQUFBLFVBQ2pCLEdBQUdBO0FBQUFBO0FBQUFBLFVBQ0gzQixlQUFld0IsT0FBT0k7QUFBQUEsVUFDdEIzQiwwQkFBMEJ5QixPQUFPRSxVQUFVO0FBQUEsUUFFN0MsRUFBRTtBQUFBLE1BQ0osU0FBU0MsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFBQSxNQUNyRDtBQUFBLElBQ0Y7QUFDQVgsb0JBQWdCO0FBQUEsRUFDbEIsR0FBRyxFQUFFO0FBRUwsU0FDRSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxxREFVYjtBQUFBLDZCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUix1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSwrQkFBQyxVQUFPLFlBQVksUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QjtBQUFBLFFBQ3pCLHVCQUFDLFNBQUksV0FBVSxnQkFFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxRQUNiLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSw0TEFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3TTtBQUFBLGdCQUN4TSx1QkFBQyxTQUFJLFdBQVUsOEhBQ2IsaUNBQUMsU0FBTSxXQUFVLHdCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxQyxLQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFFBQUcsV0FBVSxnSEFBK0csbUNBQTdIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsK0JBQThCLHNEQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpRjtBQUFBLG1CQUpuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsaUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFjQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUyxNQUFNO0FBQ2J2Qiw4QkFBVSxXQUFXO0FBQ3JCUyxxQ0FBaUIsSUFBSTtBQUNyQkUsOEJBQVUsQ0FBQyxDQUFDO0FBQUEsa0JBQ2Q7QUFBQSxrQkFJQSxXQUFVO0FBQUEsa0JBQXFHO0FBQUE7QUFBQSxnQkFUakg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBWUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVMsTUFBTVQsWUFBWSxDQUFBOEIsU0FBUSxDQUFDQSxJQUFJO0FBQUEsa0JBQ3hDLFdBQVU7QUFBQSxrQkFFVC9CLHFCQUFXLG9CQUFvQjtBQUFBO0FBQUEsZ0JBSmxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsaUJBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0JBO0FBQUEsZUFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQ0EsS0F0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1Q0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSw2QkFHYixpQ0FBQyxTQUFJLFdBQVUsMkJBR1pBLHNCQUNDLHVCQUFDLFNBQUksV0FBVSxnS0FHYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNQyxZQUFZLEtBQUs7QUFBQSxnQkFDaEMsV0FBVTtBQUFBLGdCQUFrRTtBQUFBO0FBQUEsY0FGOUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSxnRUFBK0QsMEJBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVGO0FBQUEsWUFDdkYsdUJBQUMsT0FBRSxXQUFVLDBDQUNYO0FBQUEscUNBQUMsYUFBVSxXQUFVLHVCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QztBQUFBLGNBQUc7QUFBQSxpQkFEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLDBDQUNYO0FBQUEscUNBQUMsYUFBVSxXQUFVLHVCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QztBQUFBLGNBQUc7QUFBQSxpQkFEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBLEtBdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0JBLEtBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNEJBO0FBQUEsVUE0Q0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU1GLFVBQVUsV0FBVztBQUFBLGdCQUNwQyxXQUFXLHFCQUFxQkQsV0FBVyxjQUN2Qyw2QkFDQSxhQUFhO0FBQUEsZ0JBQ1o7QUFBQTtBQUFBLGtCQUdMLHVCQUFDLFVBQUssV0FBVztBQUFBO0FBQUE7QUFBQSxPQUlkSSxpQkFBT0UsaUJBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBO0FBQUE7QUFBQSxjQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWNBO0FBQUEsWUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTUwsVUFBVSxZQUFZO0FBQUEsZ0JBQ3JDLFdBQVcscUJBQXFCRCxXQUFXLGVBQ3ZDLDZCQUNBLGFBQWE7QUFBQSxnQkFDWjtBQUFBO0FBQUEsa0JBR0wsdUJBQUMsVUFBSyxXQUFXLDhFQUNkSSxpQkFBT0csNEJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBO0FBQUE7QUFBQSxjQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVdBO0FBQUEsZUE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE4QkE7QUFBQSxVQUVDUCxXQUFXLGVBQWU7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUMxQjtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBO0FBQUEsWUFKeUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSUo7QUFBQSxVQUd0QkEsV0FBVyxnQkFBZ0IsdUJBQUMsc0JBQW1CLGFBQWEsUUFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0M7QUFBQSxhQXpKcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJMQTtBQUFBLFdBN0xGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4TEE7QUFBQSxTQXpNRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBME1BO0FBQUEsSUFFQSx1QkFBQyxXQUFNLEtBQUcsTUFBRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0NFO0FBQUEsT0FuUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9QQTtBQUVKO0FBQUVELEdBNVZJRCxVQUFRO0FBQUEsVUFJS3RCLFdBQVc7QUFBQTtBQUFBNkQsS0FKeEJ2QztBQThWTixlQUFlQTtBQUFTLElBQUF1QztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlTmF2aWdhdGUiLCJOYXZiYXIiLCJTaWRlYmFyIiwiVXNlcnMiLCJDaGV2cm9uUmlnaHQiLCJaYXAiLCJTaGllbGQiLCJVc2VyQ2hlY2siLCJTcGFya2xlcyIsIkFycm93VXBSaWdodCIsIkdyaWQzeDMiLCJVc2VyTWludXMiLCJBbGVydFRyaWFuZ2xlIiwiSW9Jb3NQZXJzb25BZGQiLCJNZENhbmNlbCIsIkZhUGx1cyIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiVXNlciIsIlVuQXBwcm92ZWRDdXN0b21lciIsIkdvRG90RmlsbCIsImFwaSIsIlVzZXJNZW51IiwiX3MiLCJmaWx0ZXIiLCJzZXRGaWx0ZXIiLCJzaG93VGlwcyIsInNldFNob3dUaXBzIiwidG90YWwiLCJzZXRUb3RhbCIsInRvdGFsQ3VzdG9tZXIiLCJ0b3RhbFVudmVyaWZpZWRDdXN0b21lcnMiLCJuYXZpZ2F0ZSIsInNob3dVc2VyTW9kYWwiLCJzZXRTaG93VXNlck1vZGFsIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwiYXJlYXMiLCJzZXRBcmVhcyIsImNhcmREYXRhIiwidGl0bGUiLCJ2YWx1ZSIsImRlc2NyaXB0aW9uIiwiaWNvbiIsImljb25Db2xvciIsImljb25CZ0NvbG9yIiwidGl0bGVDb2xvciIsImRpdmlkZXJDb2xvciIsImZldGNoVG90YWxDb3VudCIsInJlc3BvbnNlMSIsInJlc3BvbnNlMiIsIlByb21pc2UiLCJhbGwiLCJnZXQiLCJkYXRhMSIsImRhdGEiLCJkYXRhMiIsInByZXYiLCJsZW5ndGgiLCJlcnJvciIsImNvbnNvbGUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJVc2VyTWVudS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgeyBVc2VycywgQ2hldnJvblJpZ2h0LCBaYXAsIFNoaWVsZCwgVXNlckNoZWNrLCBTcGFya2xlcywgQXJyb3dVcFJpZ2h0LCBHcmlkM3gzLCBVc2VyTWludXMsIEFsZXJ0VHJpYW5nbGUgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IElvSW9zUGVyc29uQWRkIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCB7IE1kQ2FuY2VsIH0gZnJvbSBcInJlYWN0LWljb25zL21kXCI7XHJcbmltcG9ydCB7IEZhUGx1cyB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBVc2VyIGZyb20gXCIuL1VzZXJcIjtcclxuaW1wb3J0IFVuQXBwcm92ZWRDdXN0b21lciBmcm9tIFwiLi9VbkFwcHJvdmVkQ3VzdG9tZXJcIjtcclxuaW1wb3J0IHsgR29Eb3RGaWxsIH0gZnJvbSBcInJlYWN0LWljb25zL2dvXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuXHJcbmNvbnN0IFVzZXJNZW51ID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtmaWx0ZXIsIHNldEZpbHRlcl0gPSB1c2VTdGF0ZShcImN1c3RvbWVyc1wiKTtcclxuICBjb25zdCBbc2hvd1RpcHMsIHNldFNob3dUaXBzXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdG90YWwsIHNldFRvdGFsXSA9IHVzZVN0YXRlKHsgdG90YWxDdXN0b21lcjogMCwgdG90YWxVbnZlcmlmaWVkQ3VzdG9tZXJzOiAwIH0pO1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICBjb25zdCBbc2hvd1VzZXJNb2RhbCwgc2V0U2hvd1VzZXJNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuICAvLyBjb25zdCB1c2VyQ2F0ZWdvcmllcyA9IFtcclxuICAvLyAgIHtcclxuICAvLyAgICAgaWQ6IDEsXHJcbiAgLy8gICAgIHRpdGxlOiBcIkN1c3RvbWVyc1wiLFxyXG4gIC8vICAgICBkZXNjcmlwdGlvbjogXCJNYW5hZ2UgY3VzdG9tZXIgcmVjb3JkcyBhbmQgaW5mb3JtYXRpb25cIixcclxuICAvLyAgICAgaWNvbjogSW9Jb3NQZXJzb25BZGQsXHJcbiAgLy8gICAgIGdyYWRpZW50OiBcImZyb20tdmlvbGV0LTUwMCB2aWEtcHVycGxlLTUwMCB0by1waW5rLTUwMFwiLFxyXG4gIC8vICAgICBiZ0dyYWRpZW50OiBcImZyb20tdmlvbGV0LTUwIHZpYS1wdXJwbGUtNTAgdG8tcGluay01MFwiLFxyXG4gIC8vICAgICBocmVmOiBcIi9jdXN0b21lci1tZW51L3VzZXJcIixcclxuICAvLyAgICAgc3RhdHM6IFwiQWN0aXZlIEN1c3RvbWVyc1wiLFxyXG4gIC8vICAgICBzZWNvbmRhcnlJY29uOiBTaGllbGQsXHJcbiAgLy8gICAgIGljb25Db2xvcjogXCJ0ZXh0LXZpb2xldC02MDBcIixcclxuICAvLyAgICAgYmdDb2xvcjogXCJiZy12aW9sZXQtMTAwXCJcclxuICAvLyAgIH0sXHJcbiAgLy8gICB7XHJcbiAgLy8gICAgIGlkOiAyLFxyXG4gIC8vICAgICB0aXRsZTogXCJVbnZlcmlmaWVkIEN1c3RvbWVyc1wiLFxyXG4gIC8vICAgICBkZXNjcmlwdGlvbjogXCJNYW5hZ2UgdW52ZXJpZmllZCBjdXN0b21lciByZWNvcmRzXCIsXHJcbiAgLy8gICAgIGljb246IE1kQ2FuY2VsLFxyXG4gIC8vICAgICBncmFkaWVudDogXCJmcm9tLWFtYmVyLTUwMCB2aWEtb3JhbmdlLTUwMCB0by1yZWQtNTAwXCIsXHJcbiAgLy8gICAgIGJnR3JhZGllbnQ6IFwiZnJvbS1hbWJlci01MCB2aWEtb3JhbmdlLTUwIHRvLXJlZC01MFwiLFxyXG4gIC8vICAgICBocmVmOiBcIi9jdXN0b21lci1tZW51L3VuLWFwcHJvdmVkLWN1c3RvbWVyXCIsXHJcbiAgLy8gICAgIHN0YXRzOiBcIlVudmVyaWZpZWQgQ3VzdG9tZXJzXCIsXHJcbiAgLy8gICAgIHNlY29uZGFyeUljb246IFVzZXJDaGVjayxcclxuICAvLyAgICAgaWNvbkNvbG9yOiBcInRleHQtYW1iZXItNjAwXCIsXHJcbiAgLy8gICAgIGJnQ29sb3I6IFwiYmctYW1iZXItMTAwXCJcclxuICAvLyAgIH0sXHJcbiAgLy8gXTtcclxuICBjb25zdCBbYXJlYXMsIHNldEFyZWFzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBjYXJkRGF0YSA9IFtcclxuICAgIHtcclxuICAgICAgdGl0bGU6IFwiVG90YWwgQ3VzdG9tZXJzXCIsXHJcbiAgICAgIHZhbHVlOiB0b3RhbC50b3RhbEN1c3RvbWVyLFxyXG4gICAgICBkZXNjcmlwdGlvbjogXCJPdmVyYWxsIFJlZ2lzdGVyZWQgVXNlcnNcIixcclxuICAgICAgaWNvbjogPFVzZXJzIHNpemU9ezIwfSAvPixcclxuICAgICAgaWNvbkNvbG9yOiBcInRleHQtYmx1ZS01MDBcIixcclxuICAgICAgaWNvbkJnQ29sb3I6IFwiYmctYmx1ZS01MFwiLFxyXG4gICAgICB0aXRsZUNvbG9yOiBcInRleHQtYmx1ZS02MDBcIixcclxuICAgICAgZGl2aWRlckNvbG9yOiBcImJnLWJsdWUtMjAwXCJcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRpdGxlOiBcIkFjdGl2ZSBDdXN0b21lcnNcIixcclxuICAgICAgdmFsdWU6IFwiNTYwXCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIlZlcmlmaWVkICYgQWN0aXZlIFVzZXJzXCIsXHJcbiAgICAgIGljb246IDxVc2VyQ2hlY2sgc2l6ZT17MjB9IC8+LFxyXG4gICAgICBpY29uQ29sb3I6IFwidGV4dC1lbWVyYWxkLTUwMFwiLFxyXG4gICAgICBpY29uQmdDb2xvcjogXCJiZy1lbWVyYWxkLTUwXCIsXHJcbiAgICAgIHRpdGxlQ29sb3I6IFwidGV4dC1lbWVyYWxkLTYwMFwiLFxyXG4gICAgICBkaXZpZGVyQ29sb3I6IFwiYmctZW1lcmFsZC0yMDBcIlxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdGl0bGU6IFwiVW52ZXJpZmllZCBDdXN0b21lcnNcIixcclxuICAgICAgdmFsdWU6IHRvdGFsLnRvdGFsVW52ZXJpZmllZEN1c3RvbWVycyxcclxuICAgICAgZGVzY3JpcHRpb246IFwiUGVuZGluZyBWZXJpZmljYXRpb25cIixcclxuICAgICAgaWNvbjogPFVzZXJNaW51cyBzaXplPXsyMH0gLz4sXHJcbiAgICAgIGljb25Db2xvcjogXCJ0ZXh0LWFtYmVyLTUwMFwiLFxyXG4gICAgICBpY29uQmdDb2xvcjogXCJiZy1hbWJlci01MFwiLFxyXG4gICAgICB0aXRsZUNvbG9yOiBcInRleHQtYW1iZXItNjAwXCIsXHJcbiAgICAgIGRpdmlkZXJDb2xvcjogXCJiZy1hbWJlci0yMDBcIlxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdGl0bGU6IFwiT3ZlcmR1ZSBQYXltZW50c1wiLFxyXG4gICAgICB2YWx1ZTogXCLigrkxLDUwLDAwMFwiLFxyXG4gICAgICBkZXNjcmlwdGlvbjogXCJQZW5kaW5nIENvbGxlY3Rpb25zXCIsXHJcbiAgICAgIGljb246IDxBbGVydFRyaWFuZ2xlIHNpemU9ezIwfSAvPixcclxuICAgICAgaWNvbkNvbG9yOiBcInRleHQtcmVkLTUwMFwiLFxyXG4gICAgICBpY29uQmdDb2xvcjogXCJiZy1yZWQtNTBcIixcclxuICAgICAgdGl0bGVDb2xvcjogXCJ0ZXh0LXJlZC02MDBcIixcclxuICAgICAgZGl2aWRlckNvbG9yOiBcImJnLXJlZC0yMDBcIlxyXG4gICAgfVxyXG4gIF07XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIC8vIEZldGNoIHRvdGFsIGNvdW50cyBmcm9tIEFQSVxyXG4gICAgY29uc3QgZmV0Y2hUb3RhbENvdW50ID0gYXN5bmMgKCkgPT4geyAgICAgICAgICAgICAgICAgIFxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IFtyZXNwb25zZTEsIHJlc3BvbnNlMl0gPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgICBhcGkuZ2V0KFwiL3VzZXIvZ2V0LW5ldy11c2VyXCIpLFxyXG4gICAgICAgICAgYXBpLmdldChcIi91c2VyL2FwcHJvdmFsLXN0YXR1cy9mYWxzZVwiKVxyXG4gICAgICAgIF0pO1xyXG4gICAgICAgIGNvbnN0IGRhdGExID0gYXdhaXQgcmVzcG9uc2UxLmRhdGE7XHJcbiAgICAgICAgY29uc3QgZGF0YTIgPSBhd2FpdCByZXNwb25zZTIuZGF0YTtcclxuICAgICAgICAgc2V0VG90YWwocHJldiA9PiAoe1xyXG4gICAgICAgICAgLi4ucHJldiwgICAgICAgICAgICAgICAvLyBrZWVwIGV4aXN0aW5nIHZhbHVlc1xyXG4gICAgICAgICAgdG90YWxDdXN0b21lcjogZGF0YTE/Lmxlbmd0aCxcclxuICAgICAgICAgIHRvdGFsVW52ZXJpZmllZEN1c3RvbWVyczogZGF0YTI/Lmxlbmd0aCB8fCAwXHJcblxyXG4gICAgICAgIH0pKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdG90YWwgY291bnRzOlwiLCBlcnJvcik7XHJcbiAgICAgIH0gICBcclxuICAgIH07XHJcbiAgICBmZXRjaFRvdGFsQ291bnQoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLXNjcmVlbiB3LWZ1bGwgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcblxyXG4gICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1zbGF0ZS01MCB2aWEtd2hpdGUgdG8tZ3JheS01MFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgLWxlZnQtNCB3LTcyIGgtNzIgYmctcHVycGxlLTMwMCByb3VuZGVkLWZ1bGwgbWl4LWJsZW5kLW11bHRpcGx5IGZpbHRlciBibHVyLXhsIG9wYWNpdHktMjAgYW5pbWF0ZS1ibG9iXCI+PC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgLXJpZ2h0LTQgdy03MiBoLTcyIGJnLXllbGxvdy0zMDAgcm91bmRlZC1mdWxsIG1peC1ibGVuZC1tdWx0aXBseSBmaWx0ZXIgYmx1ci14bCBvcGFjaXR5LTIwIGFuaW1hdGUtYmxvYiBhbmltYXRpb24tZGVsYXktMjAwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIC1ib3R0b20tOCBsZWZ0LTIwIHctNzIgaC03MiBiZy1waW5rLTMwMCByb3VuZGVkLWZ1bGwgbWl4LWJsZW5kLW11bHRpcGx5IGZpbHRlciBibHVyLXhsIG9wYWNpdHktMjAgYW5pbWF0ZS1ibG9iIGFuaW1hdGlvbi1kZWxheS00MDAwXCI+PC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj4gKi99XHJcblxyXG4gICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICA8TmF2YmFyIHZpc2liaWxpdHk9e3RydWV9IC8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtOCByZWxhdGl2ZVwiPlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLWluc2V0LTEgYmctZ3JhZGllbnQtdG8tciBmcm9tLXZpb2xldC02MDAgdG8tcHVycGxlLTYwMCByb3VuZGVkLTJ4bCBibHVyLWxnIG9wYWNpdHktNzUgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0xMDAwIGdyb3VwLWhvdmVyOmR1cmF0aW9uLTIwMCBhbmltYXRlLXRpbHRcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctMTIgaC0xMiByb3VuZGVkLTJ4bCBiZy1ncmFkaWVudC10by1iciBmcm9tLXZpb2xldC01MDAgdG8tcHVycGxlLTYwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaGFkb3ctMnhsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8VXNlcnMgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LXdoaXRlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCBiZy1ncmFkaWVudC10by1yIGZyb20tc2xhdGUtOTAwIHZpYS1wdXJwbGUtOTAwIHRvLXNsYXRlLTkwMCBiZy1jbGlwLXRleHQgdGV4dC10cmFuc3BhcmVudFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXIgTWFuYWdlbWVudFxyXG4gICAgICAgICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDAgbXQtMSB0ZXh0LXNtXCI+TWFuYWdlIGFuZCBvcmdhbml6ZSB5b3VyIGN1c3RvbWVyIGJhc2U8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0RmlsdGVyKFwiY3VzdG9tZXJzXCIpOyAgIC8vIHN3aXRjaCB0YWJcclxuICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dVc2VyTW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICB3aW5kb3cub3BlbihcIi9hZGQtbmV3LWN1c3RvbWVyXCIsIFwiX2JsYW5rXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIH19XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtNCBiZy12aW9sZXQtNTAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLWJsdWUtODAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICsgQWRkIEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1RpcHMocHJldiA9PiAhcHJldil9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNTAwIGZvbnQtbWVkaXVtIGhvdmVyOnVuZGVybGluZSBtYi0yXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtzaG93VGlwcyA/IFwiSGlkZSBRdWljayBUaXBzXCIgOiBcIlNob3cgUXVpY2sgVGlwc1wifVxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgaC0wIHRvcC0xXCI+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBJbmZvIEljb24gKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMTIgcmlnaHQtNFwiPlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBUb29sdGlwICovfVxyXG4gICAgICAgICAgICAgICAge3Nob3dUaXBzICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tZnVsbCByaWdodC0wICBtYi0yIFxyXG4gICAgICAgICAgICAgICAgICAgICAgdy04MCBwLTMgYmctZ3JheS04MDAgdGV4dC13aGl0ZSB0ZXh0LXhzIHJvdW5kZWQtbWQgXHJcbiAgICAgICAgICAgICAgICAgICAgICBzaGFkb3ctbGcgei1bOTk5OV1cIj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93VGlwcyhmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSAgcmlnaHQtMSB0ZXh0LXJlZCB0ZXh0LXNtIGZvbnQtYm9sZCBob3Zlcjp0ZXh0LWdyYXktMzAwXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICDDl1xyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIG1iLTEgaW5saW5lLWJsb2NrIGJvcmRlci1iLTIgYm9yZGVyLXZpb2xldC01MDBcIj5RdWljayBUaXBzPC9oND5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJsZWFkaW5nLXJlbGF4ZWQgZmxleCBpdGVtcy1zdGFydCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEdvRG90RmlsbCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgbXQtMVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICBVc2UgdGhlIEN1c3RvbWVyIGRpcmVjdG9yeSB0byBtYW5hZ2UgY3VzdG9tZXIgaW5mb3JtYXRpb24sIHVwZGF0ZSBjdXN0b21lciBkZXRhaWxzIGFsbCBpbiBvbmUgcGxhY2UuXHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImxlYWRpbmctcmVsYXhlZCBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8R29Eb3RGaWxsIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBtdC0xXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIFVzZSB0aGUgQ3VzdG9tZXIgZGlyZWN0b3J5IHRvIG1hbmFnZSBVbnZlcmlmaWVkIEN1c3RvbWVycyBJbmZvcm1hdGlvbiwgdXBkYXRlIGN1c3RvbWVyIGluZm9ybWF0aW9uIGFsbCBpbiBvbmUgcGxhY2UuXHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7LyogTWFpbiBNZXRyaWMgQ2FyZHMgUm93ICovfVxyXG5cclxuXHJcbiAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTYgZ2FwLTZcIj5cclxuICAgICAgICAgICAgICB7Y2FyZERhdGEubWFwKChjYXJkLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICBrZXk9e2luZGV4fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC0yeGwgcC0yIGJnLXdoaXRlIHNoYWRvdy1sZyBob3ZlcjpzaGFkb3cteGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGhvdmVyOi10cmFuc2xhdGUteS0yIGN1cnNvci1kZWZhdWx0IGJvcmRlciBib3JkZXItZ3JheS0xMDBcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIC1yaWdodC00IC10b3AtNCBvcGFjaXR5LTEwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B0ZXh0LTV4bCAke2NhcmQuaWNvbkNvbG9yfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2NhcmQuaWNvbn1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIHRleHQtY2VudGVyIHNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQtZnVsbCAke2NhcmQuaWNvbkJnQ29sb3J9IHNoYWRvdy1tZGB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2Ake2NhcmQuaWNvbkNvbG9yfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Y2FyZC5pY29ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPXtgdGV4dC1zbSBmb250LXNlbWlib2xkIHRyYWNraW5nLXdpZGUgdXBwZXJjYXNlICR7Y2FyZC50aXRsZUNvbG9yfSBtYi0yYH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtjYXJkLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIG1iLTIgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Y2FyZC52YWx1ZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgaC0xIHctMTYgbXgtYXV0byByb3VuZGVkLWZ1bGwgJHtjYXJkLmRpdmlkZXJDb2xvcn1gfSAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIHRleHQtZ3JheS02MDAgbXQtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Y2FyZC5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9kaXY+ICovfVxyXG4gICAgICAgICAgICB7LyogRmlsdGVyICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTQgbWItNiBtdC01XCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RmlsdGVyKFwiY3VzdG9tZXJzXCIpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQgJHtmaWx0ZXIgPT09IFwiY3VzdG9tZXJzXCJcclxuICAgICAgICAgICAgICAgICAgPyBcImJnLXZpb2xldC01MDAgdGV4dC13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmF5LTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIEN1c3RvbWVyc1xyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgXHJcbiAgICAgIG1sLTIgcHgtMiBweS0wLjUgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC1mdWxsIGJnLXB1cnBsZS00MDAgdGV4dC1ibGFja1wiXHJcbiAgICAgIH1cclxuICAgIGB9PlxyXG4gICAgICAgICAgICAgICAgICB7dG90YWw/LnRvdGFsQ3VzdG9tZXJ9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZpbHRlcihcInVudmVyaWZpZWRcIil9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTIgcm91bmRlZCAke2ZpbHRlciA9PT0gXCJ1bnZlcmlmaWVkXCJcclxuICAgICAgICAgICAgICAgICAgPyBcImJnLXZpb2xldC01MDAgdGV4dC13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmF5LTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFVudmVyaWZpZWQgQ3VzdG9tZXJzXHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BtbC0yIHB4LTIgcHktMC41IHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQtZnVsbCBiZy1wdXJwbGUtNDAwIHRleHQtYmxhY2tcIn1gfT5cclxuICAgICAgICAgICAgICAgICAge3RvdGFsPy50b3RhbFVudmVyaWZpZWRDdXN0b21lcnN9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgey8qIFJlbmRlciBDb21wb25lbnQgQmFzZWQgb24gRmlsdGVyICovfVxyXG4gICAgICAgICAgICB7ZmlsdGVyID09PSBcImN1c3RvbWVyc1wiICYmIDxVc2VyXHJcbiAgICAgICAgICAgICAgc2hvd1VzZXJNb2RhbD17c2hvd1VzZXJNb2RhbH1cclxuICAgICAgICAgICAgICBzZXRTaG93VXNlck1vZGFsPXtzZXRTaG93VXNlck1vZGFsfVxyXG4gICAgICAgICAgICAgIGVycm9ycz17ZXJyb3JzfVxyXG4gICAgICAgICAgICAgIHNldEVycm9ycz17c2V0RXJyb3JzfVxyXG4gICAgICAgICAgICAvPn1cclxuXHJcbiAgICAgICAgICAgIHtmaWx0ZXIgPT09IFwidW52ZXJpZmllZFwiICYmIDxVbkFwcHJvdmVkQ3VzdG9tZXIgaGlkZVNpZGViYXI9e3RydWV9Lz59XHJcblxyXG4gICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC04IG1iLTEyXCI+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8L2Rpdj4gKi99XHJcblxyXG5cclxuICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcC04IGJnLWdyYWRpZW50LXRvLWJyIGZyb20tdmlvbGV0LTUwIHZpYS1wdXJwbGUtNTAgdG8tcGluay01MCByb3VuZGVkLTN4bCBib3JkZXIgYm9yZGVyLXdoaXRlLzUwIHNoYWRvdy0yeGwgb3ZlcmZsb3ctaGlkZGVuIG10LTRcIj5cclxuICAgICAgIFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCB3LTQwIGgtNDAgYmctZ3JhZGllbnQtdG8tYmwgZnJvbS12aW9sZXQtMjAwLzMwIHRvLXRyYW5zcGFyZW50IHJvdW5kZWQtZnVsbCBibHVyLTN4bFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTAgbGVmdC0wIHctNDAgaC00MCBiZy1ncmFkaWVudC10by10ciBmcm9tLXB1cnBsZS0yMDAvMzAgdG8tdHJhbnNwYXJlbnQgcm91bmRlZC1mdWxsIGJsdXItM3hsXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIC1pbnNldC0yIGJnLWdyYWRpZW50LXRvLXIgZnJvbS12aW9sZXQtNTAwIHRvLXB1cnBsZS01MDAgcm91bmRlZC0yeGwgYmx1ci1sZyBvcGFjaXR5LTUwIGdyb3VwLWhvdmVyOm9wYWNpdHktNzUgdHJhbnNpdGlvbiBkdXJhdGlvbi0zMDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LTE0IGgtMTQgcm91bmRlZC0yeGwgYmctd2hpdGUgc2hhZG93LXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFphcCBjbGFzc05hbWU9XCJ3LTcgaC03IHRleHQtdmlvbGV0LTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgbWItMiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFF1aWNrIFRpcHNcclxuICAgICAgICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXZpb2xldC01MDAgYW5pbWF0ZS1wdWxzZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNzAwIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFVzZSB0aGUgQ3VzdG9tZXIgZGlyZWN0b3J5IHRvIG1hbmFnZSBjdXN0b21lciBpbmZvcm1hdGlvbiwgdXBkYXRlIGN1c3RvbWVyIGRldGFpbHMgYWxsIGluIG9uZSBwbGFjZS5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTcwMCBsZWFkaW5nLXJlbGF4ZWQgbXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFVzZSB0aGUgQ3VzdG9tZXIgZGlyZWN0b3J5IHRvIG1hbmFnZSBVbnZlcmlmaWVkIEN1c3RvbWVycyBJbmZvcm1hdGlvbiwgdXBkYXRlIGN1c3RvbWVyIGluZm9ybWF0aW9uIGFsbCBpbiBvbmUgcGxhY2UuXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj4gKi99XHJcblxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPHN0eWxlIGpzeD57YFxyXG4gICAgICAgIEBrZXlmcmFtZXMgYmxvYiB7XHJcbiAgICAgICAgICAwJSB7XHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKDBweCwgMHB4KSBzY2FsZSgxKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIDMzJSB7XHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKDMwcHgsIC01MHB4KSBzY2FsZSgxLjEpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgNjYlIHtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTIwcHgsIDIwcHgpIHNjYWxlKDAuOSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICAxMDAlIHtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoMHB4LCAwcHgpIHNjYWxlKDEpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAuYW5pbWF0ZS1ibG9iIHtcclxuICAgICAgICAgIGFuaW1hdGlvbjogYmxvYiA3cyBpbmZpbml0ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLmFuaW1hdGlvbi1kZWxheS0yMDAwIHtcclxuICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMnM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5hbmltYXRpb24tZGVsYXktNDAwMCB7XHJcbiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDRzO1xyXG4gICAgICAgIH1cclxuICAgICAgICBAa2V5ZnJhbWVzIHRpbHQge1xyXG4gICAgICAgICAgMCUsIDUwJSwgMTAwJSB7XHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogcm90YXRlKDBkZWcpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgMjUlIHtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoMC41ZGVnKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIDc1JSB7XHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogcm90YXRlKC0wLjVkZWcpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAuYW5pbWF0ZS10aWx0IHtcclxuICAgICAgICAgIGFuaW1hdGlvbjogdGlsdCAxMHMgaW5maW5pdGU7XHJcbiAgICAgICAgfVxyXG4gICAgICBgfTwvc3R5bGU+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVXNlck1lbnU7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1VzZXJNZW51LmpzeCJ9