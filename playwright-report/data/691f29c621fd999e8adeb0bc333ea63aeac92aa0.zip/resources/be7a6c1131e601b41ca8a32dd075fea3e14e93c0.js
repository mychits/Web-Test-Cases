import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PigmyPaymentOut.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { Input, Select, Dropdown, Popover, Button, message } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { Drawer } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { FiEye } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { Link, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { showConfirm } from "/src/components/alerts/ShowConfirm.jsx";
import {
  CheckCircleOutlined,
  ClockCircleOutlined,
  CloseCircleOutlined,
  ExclamationCircleOutlined,
  QuestionCircleOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
import ChitCancelPaymentForm from "/src/pages/ChitCancelPaymentForm.jsx";
import ChitTransferPaymentForm from "/src/pages/ChitTransferPaymentForm.jsx";
const INITIAL_PAYMENT_STATE = {
  payment_amount: "",
  payment_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
  payment_mode: null,
  transaction_id: "",
  service_charges: "",
  document_charges: "",
  daily_payment_amount: "",
  start_date: "",
  end_date: "",
  loan_id: "",
  cheque_number: "",
  note: ""
};
const PigmyPaymentOut = ({ isShowSidebar: showSidebar }) => {
  _s();
  const [rawLoans, setRawLoans] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [customerId, setCustomerId] = useState(null);
  const [currentBorrower, setCurrentBorrower] = useState(null);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [paymentFormData, setPaymentFormData] = useState(INITIAL_PAYMENT_STATE);
  const [paymentErrors, setPaymentErrors] = useState({});
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "",
    type: "info"
  });
  const [thirdPartyEnable, setThirdPartyEnable] = useState({
    whatsapp: true
  });
  const [modifyPayment, setModifyPayment] = useState(false);
  const [modifyMinMaxPaymentDate, setModifyMinMaxPaymentDate] = useState(false);
  const [adminId, setAdminId] = useState("");
  const [showTransferModal, setShowTransferModal] = useState(false);
  const [transferUserId, setTransferUserId] = useState(null);
  const [showTransactionDrawer, setShowTransactionDrawer] = useState(false);
  const [transactionsData, setTransactionsData] = useState([]);
  const [transactionsLoading, setTransactionsLoading] = useState(false);
  const location = useLocation();
  const isChitTransferPayIn = location.pathname.endsWith("/chit-transfer-pay-in");
  const isStandalonePage = location.pathname.endsWith("/chit-cancelation-pay-out") || location.pathname.endsWith("/chit-transfer-pay-in");
  const isShowSidebar = isStandalonePage ? true : showSidebar;
  const fetchApprovedLoans = useCallback(async () => {
    try {
      setIsLoading(true);
      const [accountsResponse, transactionsResponse] = await Promise.all(
        [
          api.get("/v1/admin/user-accounts/"),
          api.get("/v1/admin/transaction-history/")
        ]
      );
      const accounts = accountsResponse?.data?.data || [];
      const transactions = transactionsResponse?.data?.data || transactionsResponse?.data || [];
      const pigmyWithdrawalUserIds = /* @__PURE__ */ new Set();
      transactions.forEach((txn) => {
        const reason = txn?.reason?.trim()?.toLowerCase();
        if (reason !== "pigmy withdrawal") {
          const enrollUserId = txn?.enroll_id?.user_id?._id;
          if (enrollUserId) {
            pigmyWithdrawalUserIds.add(enrollUserId);
          }
          const pigmyUserId = txn?.pigme_id?.customer?._id;
          if (pigmyUserId) {
            pigmyWithdrawalUserIds.add(pigmyUserId);
          }
          const directUserId = txn?.user_id?._id || txn?.user_id;
          if (directUserId) {
            pigmyWithdrawalUserIds.add(directUserId);
          }
        }
      });
      const filteredAccounts = accounts.filter((account) => {
        const accountUserId = account?.userDetails?._id;
        return !pigmyWithdrawalUserIds.has(accountUserId);
      });
      setRawLoans(filteredAccounts);
    } catch (error) {
      console.error("Failed to fetch accounts:", error);
      showAlert("Failed to fetch cancelled chits", "error");
    } finally {
      setIsLoading(false);
    }
  }, []);
  useEffect(() => {
    fetchApprovedLoans();
  }, [fetchApprovedLoans, reloadTrigger]);
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    const userAdminId = userObj?._id;
    setAdminId(userAdminId);
    console.log(JSON.stringify(userObj), "this is userObje");
    if (userObj) {
      const adminAccessPermissions = userObj.admin_access_right_id?.access_permissions;
      if (adminAccessPermissions?.edit_payment === "true") {
        setModifyPayment(true);
      }
      if (adminAccessPermissions?.edit_limited_payment === "true") {
        setModifyPayment(true);
        setModifyMinMaxPaymentDate(true);
      }
    }
  }, []);
  const showAlert = (message2, type = "info") => {
    setAlertConfig({ visibility: true, message: message2, type });
  };
  const resetForm = () => {
    setPaymentFormData(INITIAL_PAYMENT_STATE);
    setPaymentErrors({});
    setShowPaymentModal(false);
    setCurrentBorrower(null);
  };
  const handleTransferModalOpen = (userId) => {
    setTransferUserId(userId);
    setShowTransferModal(true);
  };
  const buildNoteString = (fd) => {
    const parts = [];
    if (fd.note?.trim()) parts.push(fd.note.trim());
    if (fd.payment_mode === "Bank Transfer") {
      if (fd.transaction_id) parts.push(`Txn: ${fd.transaction_id}`);
      if (fd.bank_name) parts.push(`Bank: ${fd.bank_name}`);
    }
    if (fd.payment_mode === "Cheque" && fd.cheque_number) {
      parts.push(`Chq: ${fd.cheque_number}`);
    } else if (fd.payment_mode === "Online" && fd.transaction_id) {
      parts.push(`Txn: ${fd.transaction_id}`);
    }
    return parts.join(" | ");
  };
  const handlePaymentOutModalOpen = async (userId) => {
    try {
      const response = await api.get(`v1/admin/loans/${userId}`);
      const data = response.data?.data;
      setCurrentBorrower(data || {});
      setCustomerId(userId);
      setShowPaymentModal(true);
    } catch (error) {
      showAlert("Failed to fetch borrower details", "error");
    }
  };
  const validate = () => {
    const errors = {};
    if (!paymentFormData.payment_amount || paymentFormData.payment_amount <= 0)
      errors.payment_amount = "Required";
    if (!paymentFormData.payment_date) errors.payment_date = "Required";
    if (!paymentFormData.payment_mode) errors.payment_mode = "Required";
    if (paymentFormData.payment_mode === "Bank Transfer" && !paymentFormData.transaction_id)
      errors.transaction_id = "Transaction ID required";
    if (paymentFormData.payment_mode === "Cheque" && !paymentFormData.cheque_number)
      errors.cheque_number = "Cheque number required";
    if (paymentErrors.pay_date === "Online" && !paymentFormData.transaction_id)
      errors.transaction_id = "Transaction ID required";
    setPaymentErrors(errors);
    return Object.keys(errors).length === 0;
  };
  const handlePaymentOutSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    try {
      const payload = {
        loan: currentBorrower?._id || currentBorrower?._id,
        user_id: currentBorrower?.borrower?._id || currentBorrower?.user_id,
        pay_date: paymentFormData.payment_date,
        amount: paymentFormData.payment_amount.toString(),
        pay_type: paymentFormData.payment_mode,
        pay_for: "Loan",
        note: paymentFormData.note,
        transaction_id: paymentFormData.transaction_id,
        admin_type: adminId,
        ...thirdPartyEnable
      };
      await api.patch("/v1/admin/loans/completed", payload);
      showAlert("Payment processed successfully", "success");
      setReloadTrigger((p) => p + 1);
      resetForm();
    } catch (error) {
      showAlert(
        error.response?.data?.message || error.response?.data?.statusCode || "Transaction failed",
        "error"
      );
    }
  };
  const updateLoanStatus = async (loan, newStatus) => {
    showConfirm({
      title: `${newStatus} Loan Request`,
      content: `Are you sure you want to change the status of this loan to ${newStatus}?`,
      onConfirm: async () => {
        try {
          await api.patch("/v1/admin/loans/approval-status", {
            id: loan._id,
            approval_status: newStatus
          });
          message.success(`Loan status updated to ${newStatus} successfully`);
          setReloadTrigger((prev) => prev + 1);
        } catch (error) {
          console.error("Error updating loan status:", error);
          message.error("Failed to update loan status");
        }
      }
    });
  };
  const tableData = useMemo(() => {
    const statusOptions = [
      {
        label: "Accept",
        value: "ACCEPTED",
        icon: /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
          lineNumber: 846,
          columnNumber: 13
        }, this),
        className: "bg-green-700 text-white hover:bg-green-800"
      },
      {
        label: "Pending",
        value: "PENDING",
        icon: /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
          lineNumber: 852,
          columnNumber: 13
        }, this),
        className: "border-yellow-400 text-yellow-600 hover:bg-yellow-50"
      },
      {
        label: "Reject",
        value: "REJECTED",
        icon: /* @__PURE__ */ jsxDEV(CloseCircleOutlined, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
          lineNumber: 858,
          columnNumber: 13
        }, this),
        className: "border-red-400 text-red-600 hover:bg-red-50"
      },
      {
        label: "Unknown",
        value: "UNKNOWN",
        icon: /* @__PURE__ */ jsxDEV(QuestionCircleOutlined, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
          lineNumber: 864,
          columnNumber: 13
        }, this),
        className: "border-yellow-400 text-yellow-600 hover:bg-yellow-50"
      },
      {
        label: "Requested",
        value: "REQUESTED",
        icon: /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
          lineNumber: 870,
          columnNumber: 13
        }, this),
        className: "border-blue-400 text-blue-600 hover:bg-blue-50"
      }
    ];
    const popoverContent = (borrower) => /* @__PURE__ */ jsxDEV("div", { className: "w-40 bg-white rounded-lg shadow-md p-2 space-y-2", children: statusOptions.map(
      (opt) => /* @__PURE__ */ jsxDEV(
        Button,
        {
          icon: opt.icon,
          className: `flex items-center justify-start w-full ${opt.className}`,
          onClick: () => updateLoanStatus(borrower, opt.value),
          children: opt.label
        },
        opt.value,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
          lineNumber: 877,
          columnNumber: 7
        },
        this
      )
    ) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
      lineNumber: 875,
      columnNumber: 5
    }, this);
    const formatted = rawLoans?.map((item, index) => ({
      ...item,
      sl_no: index + 1,
      id: `#PC${String(index + 1).padStart(3, "0")}`,
      full_name: item?.userDetails?.full_name,
      customer_id: item?.userDetails?.customer_id || 0,
      phone_number: Number(item?.userDetails?.phone_number || 0),
      balance: Number(item?.balance || 0),
      approval_status: item.approval_status || "APPROVED",
      action: /* @__PURE__ */ jsxDEV(
        Dropdown,
        {
          menu: {
            items: isChitTransferPayIn ? [
              {
                key: "2",
                label: "Transfer",
                onClick: () => handleTransferModalOpen(item.userDetails?._id)
              },
              {
                key: "1",
                label: "Payment Out",
                onClick: () => handlePaymentOutModalOpen(item.userDetails?._id)
              }
            ] : [
              {
                key: "1",
                label: "Payment Out",
                onClick: () => handlePaymentOutModalOpen(item.userDetails?._id)
              },
              {
                key: "2",
                label: "Transfer",
                onClick: () => handleTransferModalOpen(item.userDetails?._id)
              }
            ]
          },
          trigger: ["click"],
          children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-xl cursor-pointer hover:text-blue-600 transition-colors" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
            lineNumber: 933,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
          lineNumber: 899,
          columnNumber: 7
        },
        this
      )
      // view_transactions: (
      //   <button
      //     onClick={() => handleViewTransactions(item.userDetails?._id)}
      //     className="text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center gap-1 transition-colors"
      //   >
      //     <FiEye size={14} />
      //     View
      //   </button>
      // ),
    }));
    return filterOption(formatted, searchText);
  }, [rawLoans, searchText]);
  const columns = [
    { key: "sl_no", header: "SL" },
    { key: "id", header: "ID" },
    { key: "full_name", header: "Full Name" },
    { key: "customer_id", header: "Customer ID" },
    { key: "phone_number", header: "Phone Number" },
    { key: "balance", header: "Balance" },
    { key: "approval_status", header: "Approval Status" },
    // { key: "view_transactions", header: "Transactions" },
    { key: "action", header: "Action" }
  ];
  const commonInputClass = `bg-gray-50 border border-gray-300 ${fieldSize.height} text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`;
  const totalPayableSum = useMemo(() => {
    return tableData.reduce(
      (sum, item) => sum + (Number(item.balance) || 0),
      0
    );
  }, [tableData]);
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gray-50", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        visibility: true,
        onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
        lineNumber: 970,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((p) => ({ ...p, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
        lineNumber: 974,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: isShowSidebar ? "flex mt-0" : "flex mt-20", children: [
      !isShowSidebar && /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
        lineNumber: 983,
        columnNumber: 28
      }, this),
      /* @__PURE__ */ jsxDEV("main", { className: "flex-grow p-3", children: [
        !isShowSidebar && /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
          lineNumber: 985,
          columnNumber: 30
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-end mb-2", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-gray-800", children: isChitTransferPayIn ? "Chit Transfer Payments In" : " Pigmy Payment out" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
              lineNumber: 988,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: isChitTransferPayIn ? "Process incoming payments for chit transfer transactions." : "Process payment for Pigmy payouts." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
              lineNumber: 994,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
            lineNumber: 987,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end items-center mb-3 gap-3", children: [
            /* @__PURE__ */ jsxDEV(
              Link,
              {
                to: "/other-transactions",
                className: " inline-flex items-center px-5 py-2.5  border border-blue-500 text-blue-600  rounded-xl bg-white hover:bg-blue-50 hover:text-blue-700 \r\n                          hover:border-blue-600  transition-all duration-200  font-semibold shadow-sm mt-1 ",
                children: "Other Transactions"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
                lineNumber: 1001,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-blue-50 to-emerald-50 border border-blue-300 rounded-xl px-5 py-3 shadow-sm flex items-center gap-6", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "w-2.5 h-2.5 rounded-full bg-orange-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
                  lineNumber: 1013,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-blue-900 font-medium", children: "Pending Payments:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
                  lineNumber: 1014,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-blue-900 font-bold", children: tableData.length }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
                  lineNumber: 1017,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
                lineNumber: 1012,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "h-5 w-px bg-blue-300" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
                lineNumber: 1023,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "w-2.5 h-2.5 rounded-full bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
                  lineNumber: 1027,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-blue-900 font-medium", children: "Total Payable:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
                  lineNumber: 1028,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-blue-900 font-bold", children: [
                  "₹",
                  totalPayableSum.toLocaleString("en-IN")
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
                  lineNumber: 1031,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
                lineNumber: 1026,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
              lineNumber: 1009,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
            lineNumber: 1e3,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
          lineNumber: 986,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm border border-gray-100 p-4", children: isLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
          lineNumber: 1042,
          columnNumber: 13
        }, this) : tableData.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-20 text-gray-400", children: "No pending payments found." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
          lineNumber: 1044,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: tableData,
            columns,
            exportedFileName: "Loan_Payments"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
            lineNumber: 1048,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
          lineNumber: 1040,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
        lineNumber: 984,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
      lineNumber: 982,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        title: "Transaction History",
        placement: "right",
        open: showTransactionDrawer,
        onClose: () => setShowTransactionDrawer(false),
        width: 800,
        loading: transactionsLoading,
        className: "transaction-drawer",
        children: !Array.isArray(transactionsData) || transactionsData.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "text-center text-gray-500 py-8", children: "No transactions found" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
          lineNumber: 1068,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: transactionsData.map(
          (txn) => /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 p-4 rounded-lg border border-gray-200 shadow-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-2 text-sm", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Transaction ID:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
                lineNumber: 1074,
                columnNumber: 24
              }, this),
              " ",
              txn.transaction_id || "—"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
              lineNumber: 1074,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Date:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
                lineNumber: 1075,
                columnNumber: 24
              }, this),
              " ",
              new Date(txn.transaction_date).toLocaleString()
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
              lineNumber: 1075,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Amount:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
                lineNumber: 1076,
                columnNumber: 24
              }, this),
              " ₹",
              Number(txn.amount).toLocaleString("en-IN")
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
              lineNumber: 1076,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Type:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
                lineNumber: 1077,
                columnNumber: 24
              }, this),
              " ",
              txn.transaction_type
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
              lineNumber: 1077,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "col-span-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Reason:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
                lineNumber: 1078,
                columnNumber: 47
              }, this),
              " ",
              txn.reason
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
              lineNumber: 1078,
              columnNumber: 19
            }, this),
            txn.enroll_id?.group_id && /* @__PURE__ */ jsxDEV("div", { className: "col-span-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Group:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
                lineNumber: 1081,
                columnNumber: 23
              }, this),
              " ",
              txn.enroll_id.group_id.group_name,
              "  | ",
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Ticket:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
                lineNumber: 1082,
                columnNumber: 23
              }, this),
              " ",
              txn.enroll_id.tickets
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
              lineNumber: 1080,
              columnNumber: 15
            }, this),
            txn.pigme_id && /* @__PURE__ */ jsxDEV("div", { className: "col-span-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Pigmy:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
                lineNumber: 1087,
                columnNumber: 23
              }, this),
              " ",
              txn.pigme_id.pigme_id,
              "  | ",
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Customer:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
                lineNumber: 1088,
                columnNumber: 23
              }, this),
              " ",
              txn.pigme_id.customer?.full_name
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
              lineNumber: 1086,
              columnNumber: 15
            }, this),
            txn.admin_id && /* @__PURE__ */ jsxDEV("div", { className: "col-span-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Processed by:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
                lineNumber: 1093,
                columnNumber: 23
              }, this),
              " ",
              txn.admin_id.name,
              " (",
              txn.admin_id.admin_name,
              ")"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
              lineNumber: 1092,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
            lineNumber: 1073,
            columnNumber: 17
          }, this) }, txn._id, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
            lineNumber: 1072,
            columnNumber: 11
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
          lineNumber: 1070,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
        lineNumber: 1058,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showPaymentModal,
        onClose: resetForm,
        width: "90%",
        maxWidth: "800px",
        children: /* @__PURE__ */ jsxDEV(
          ChitCancelPaymentForm,
          {
            userId: customerId,
            onClose: () => {
              setTimeout(() => {
                resetForm();
              }, 300);
            },
            onSuccess: () => {
              setReloadTrigger((p) => p + 1);
              resetForm();
              showAlert("Cancellation payment successful", "success");
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
            lineNumber: 1328,
            columnNumber: 9
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
        lineNumber: 1322,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showTransferModal,
        onClose: () => setShowTransferModal(false),
        width: "90%",
        maxWidth: "900px",
        children: /* @__PURE__ */ jsxDEV(
          ChitTransferPaymentForm,
          {
            userId: transferUserId,
            onClose: () => setShowTransferModal(false),
            onSuccess: () => {
              setReloadTrigger((p) => p + 1);
              setShowTransferModal(false);
              showAlert("Transfer processed successfully", "success");
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
            lineNumber: 1350,
            columnNumber: 9
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
        lineNumber: 1344,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx",
    lineNumber: 969,
    columnNumber: 5
  }, this);
};
_s(PigmyPaymentOut, "HLUpeHMyID0QDneL7mcA9/nLkmM=", false, function() {
  return [useLocation];
});
_c = PigmyPaymentOut;
export default PigmyPaymentOut;
var _c;
$RefreshReg$(_c, "PigmyPaymentOut");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPaymentOut.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNjBCYzsyQkE3MEJkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBaWdCQSxTQUFTQSxXQUFXQyxVQUFVQyxTQUFTQyxtQkFBbUI7QUFDMUQsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyx1QkFBdUI7QUFDOUIsU0FBU0MsT0FBT0MsUUFBUUMsVUFBVUMsU0FBU0MsUUFBUUMsZUFBZTtBQUNsRSxTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLG9CQUFvQjtBQUMzQixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLE1BQU1DLG1CQUFtQjtBQUNsQyxTQUFTQyxtQkFBbUI7QUFDNUI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE9BQU9DLDJCQUEyQjtBQUNsQyxPQUFPQyw2QkFBNkI7QUFFcEMsTUFBTUMsd0JBQXdCO0FBQUEsRUFDNUJDLGdCQUFnQjtBQUFBLEVBQ2hCQyxlQUFjLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQ25EQyxjQUFjO0FBQUEsRUFDZEMsZ0JBQWdCO0FBQUEsRUFDaEJDLGlCQUFpQjtBQUFBLEVBQ2pCQyxrQkFBa0I7QUFBQSxFQUNsQkMsc0JBQXNCO0FBQUEsRUFDdEJDLFlBQVk7QUFBQSxFQUNaQyxVQUFVO0FBQUEsRUFDVkMsU0FBUztBQUFBLEVBQ1RDLGVBQWU7QUFBQSxFQUNmQyxNQUFNO0FBQ1I7QUFFQSxNQUFNQyxrQkFBa0JBLENBQUMsRUFBRUMsZUFBZUMsWUFBWSxNQUFNO0FBQUFDLEtBQUE7QUFDMUQsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUl0RCxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDdUQsWUFBWUMsYUFBYSxJQUFJeEQsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ3lELFdBQVdDLFlBQVksSUFBSTFELFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMyRCxrQkFBa0JDLG1CQUFtQixJQUFJNUQsU0FBUyxLQUFLO0FBQzlELFFBQU0sQ0FBQzZELFlBQVlDLGFBQWEsSUFBSTlELFNBQVMsSUFBSTtBQUNqRCxRQUFNLENBQUMrRCxpQkFBaUJDLGtCQUFrQixJQUFJaEUsU0FBUyxJQUFJO0FBQzNELFFBQU0sQ0FBQ2lFLGVBQWVDLGdCQUFnQixJQUFJbEUsU0FBUyxDQUFDO0FBQ3BELFFBQU0sQ0FBQ21FLGlCQUFpQkMsa0JBQWtCLElBQUlwRSxTQUFTaUMscUJBQXFCO0FBQzVFLFFBQU0sQ0FBQ29DLGVBQWVDLGdCQUFnQixJQUFJdEUsU0FBUyxDQUFDLENBQUM7QUFDckQsUUFBTSxDQUFDdUUsYUFBYUMsY0FBYyxJQUFJeEUsU0FBUztBQUFBLElBQzdDeUUsWUFBWTtBQUFBLElBQ1o1RCxTQUFTO0FBQUEsSUFDVDZELE1BQU07QUFBQSxFQUNSLENBQUM7QUFDRCxRQUFNLENBQUNDLGtCQUFrQkMsbUJBQW1CLElBQUk1RSxTQUFTO0FBQUEsSUFDdkQ2RSxVQUFVO0FBQUEsRUFDWixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSS9FLFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUNnRix5QkFBeUJDLDBCQUEwQixJQUFJakYsU0FBUyxLQUFLO0FBQzVFLFFBQU0sQ0FBQ2tGLFNBQVNDLFVBQVUsSUFBSW5GLFNBQVMsRUFBRTtBQUN6QyxRQUFNLENBQUNvRixtQkFBbUJDLG9CQUFvQixJQUFJckYsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQ3NGLGdCQUFnQkMsaUJBQWlCLElBQUl2RixTQUFTLElBQUk7QUFDekQsUUFBTSxDQUFDd0YsdUJBQXVCQyx3QkFBd0IsSUFBSXpGLFNBQVMsS0FBSztBQUN4RSxRQUFNLENBQUMwRixrQkFBa0JDLG1CQUFtQixJQUFJM0YsU0FBUyxFQUFFO0FBQzNELFFBQU0sQ0FBQzRGLHFCQUFxQkMsc0JBQXNCLElBQUk3RixTQUFTLEtBQUs7QUFFcEUsUUFBTThGLFdBQVd2RSxZQUFZO0FBQzdCLFFBQU13RSxzQkFBc0JELFNBQVNFLFNBQVNDLFNBQVMsdUJBQXdCO0FBQy9FLFFBQU1DLG1CQUNKSixTQUFTRSxTQUFTQyxTQUFTLDJCQUEyQixLQUN0REgsU0FBU0UsU0FBU0MsU0FBUyx1QkFBdUI7QUFDcEQsUUFBTS9DLGdCQUFnQmdELG1CQUFtQixPQUFPL0M7QUE4QmhELFFBQU1nRCxxQkFBcUJqRyxZQUFZLFlBQVk7QUFDakQsUUFBSTtBQUNGd0QsbUJBQWEsSUFBSTtBQUVqQixZQUFNLENBQUMwQyxrQkFBa0JDLG9CQUFvQixJQUFJLE1BQU1DLFFBQVFDO0FBQUFBLFFBQUk7QUFBQSxVQUNqRWxHLElBQUltRyxJQUFJLDBCQUEwQjtBQUFBLFVBQ2xDbkcsSUFBSW1HLElBQUksZ0NBQWdDO0FBQUEsUUFBQztBQUFBLE1BQzFDO0FBRUQsWUFBTUMsV0FBV0wsa0JBQWtCTSxNQUFNQSxRQUFRO0FBRWpELFlBQU1DLGVBQ0pOLHNCQUFzQkssTUFBTUEsUUFDNUJMLHNCQUFzQkssUUFDdEI7QUFHRixZQUFNRSx5QkFBeUIsb0JBQUlDLElBQUk7QUFFdkNGLG1CQUFhRyxRQUFRLENBQUNDLFFBQVE7QUFDNUIsY0FBTUMsU0FBU0QsS0FBS0MsUUFBUUMsS0FBSyxHQUFHQyxZQUFZO0FBRWhELFlBQUlGLFdBQVcsb0JBQW9CO0FBRWpDLGdCQUFNRyxlQUFlSixLQUFLSyxXQUFXQyxTQUFTQztBQUU5QyxjQUFJSCxjQUFjO0FBQ2hCUCxtQ0FBdUJXLElBQUlKLFlBQVk7QUFBQSxVQUN6QztBQUdBLGdCQUFNSyxjQUFjVCxLQUFLVSxVQUFVQyxVQUFVSjtBQUU3QyxjQUFJRSxhQUFhO0FBQ2ZaLG1DQUF1QlcsSUFBSUMsV0FBVztBQUFBLFVBQ3hDO0FBR0EsZ0JBQU1HLGVBQWVaLEtBQUtNLFNBQVNDLE9BQU9QLEtBQUtNO0FBRS9DLGNBQUlNLGNBQWM7QUFDaEJmLG1DQUF1QlcsSUFBSUksWUFBWTtBQUFBLFVBQ3pDO0FBQUEsUUFDRjtBQUFBLE1BQ0YsQ0FBQztBQUVELFlBQU1DLG1CQUFtQm5CLFNBQVNvQixPQUFPLENBQUNDLFlBQVk7QUFDcEQsY0FBTUMsZ0JBQWdCRCxTQUFTRSxhQUFhVjtBQUU1QyxlQUFPLENBQUNWLHVCQUF1QnFCLElBQUlGLGFBQWE7QUFBQSxNQUNsRCxDQUFDO0FBRUR6RSxrQkFBWXNFLGdCQUFnQjtBQUFBLElBQzlCLFNBQVNNLE9BQU87QUFDZEMsY0FBUUQsTUFBTSw2QkFBNkJBLEtBQUs7QUFDaERFLGdCQUFVLG1DQUFtQyxPQUFPO0FBQUEsSUFDdEQsVUFBQztBQUNDMUUsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTDNELFlBQVUsTUFBTTtBQUNkb0csdUJBQW1CO0FBQUEsRUFDckIsR0FBRyxDQUFDQSxvQkFBb0JsQyxhQUFhLENBQUM7QUFFdENsRSxZQUFVLE1BQU07QUFDZCxVQUFNc0ksT0FBT0MsYUFBYUMsUUFBUSxNQUFNO0FBQ3hDLFVBQU1DLFVBQVVDLEtBQUtDLE1BQU1MLElBQUk7QUFDL0IsVUFBTU0sY0FBY0gsU0FBU2xCO0FBQzdCbkMsZUFBV3dELFdBQVc7QUFDdEJSLFlBQVFTLElBQUlILEtBQUtJLFVBQVVMLE9BQU8sR0FBRyxrQkFBa0I7QUFFdkQsUUFBSUEsU0FBUztBQUNYLFlBQU1NLHlCQUNKTixRQUFRTyx1QkFBdUJDO0FBRWpDLFVBQUlGLHdCQUF3QkcsaUJBQWlCLFFBQVE7QUFDbkRsRSx5QkFBaUIsSUFBSTtBQUFBLE1BQ3ZCO0FBRUEsVUFBSStELHdCQUF3QkkseUJBQXlCLFFBQVE7QUFDM0RuRSx5QkFBaUIsSUFBSTtBQUNyQkUsbUNBQTJCLElBQUk7QUFBQSxNQUNqQztBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFFBQU1tRCxZQUFZQSxDQUFDdkgsVUFBUzZELE9BQU8sV0FBVztBQUM1Q0YsbUJBQWUsRUFBRUMsWUFBWSxNQUFNNUQsbUJBQVM2RCxLQUFLLENBQUM7QUFBQSxFQUNwRDtBQUVBLFFBQU15RSxZQUFZQSxNQUFNO0FBQ3RCL0UsdUJBQW1CbkMscUJBQXFCO0FBQ3hDcUMscUJBQWlCLENBQUMsQ0FBQztBQUNuQlYsd0JBQW9CLEtBQUs7QUFDekJJLHVCQUFtQixJQUFJO0FBQUEsRUFDekI7QUFHQSxRQUFNb0YsMEJBQTBCQSxDQUFDQyxXQUFXO0FBQzFDOUQsc0JBQWtCOEQsTUFBTTtBQUN4QmhFLHlCQUFxQixJQUFJO0FBQUEsRUFDM0I7QUFFQSxRQUFNaUUsa0JBQWtCQSxDQUFDQyxPQUFPO0FBQzlCLFVBQU1DLFFBQVE7QUFDZCxRQUFJRCxHQUFHdkcsTUFBTWlFLEtBQUssRUFBR3VDLE9BQU1DLEtBQUtGLEdBQUd2RyxLQUFLaUUsS0FBSyxDQUFDO0FBQzlDLFFBQUlzQyxHQUFHaEgsaUJBQWlCLGlCQUFpQjtBQUN2QyxVQUFJZ0gsR0FBRy9HLGVBQWdCZ0gsT0FBTUMsS0FBSyxRQUFRRixHQUFHL0csY0FBYyxFQUFFO0FBQzdELFVBQUkrRyxHQUFHRyxVQUFXRixPQUFNQyxLQUFLLFNBQVNGLEdBQUdHLFNBQVMsRUFBRTtBQUFBLElBQ3REO0FBQ0EsUUFBSUgsR0FBR2hILGlCQUFpQixZQUFZZ0gsR0FBR3hHLGVBQWU7QUFDcER5RyxZQUFNQyxLQUFLLFFBQVFGLEdBQUd4RyxhQUFhLEVBQUU7QUFBQSxJQUN2QyxXQUFXd0csR0FBR2hILGlCQUFpQixZQUFZZ0gsR0FBRy9HLGdCQUFnQjtBQUM1RGdILFlBQU1DLEtBQUssUUFBUUYsR0FBRy9HLGNBQWMsRUFBRTtBQUFBLElBQ3hDO0FBQ0EsV0FBT2dILE1BQU1HLEtBQUssS0FBSztBQUFBLEVBQ3pCO0FBRUEsUUFBTUMsNEJBQTRCLE9BQU9QLFdBQVc7QUFDbEQsUUFBSTtBQUNGLFlBQU1RLFdBQVcsTUFBTXhKLElBQUltRyxJQUFJLGtCQUFrQjZDLE1BQU0sRUFBRTtBQUN6RCxZQUFNM0MsT0FBT21ELFNBQVNuRCxNQUFNQTtBQUM1QjFDLHlCQUFtQjBDLFFBQVEsQ0FBQyxDQUFDO0FBQzdCNUMsb0JBQWN1RixNQUFNO0FBZ0JwQnpGLDBCQUFvQixJQUFJO0FBQUEsSUFDMUIsU0FBU3NFLE9BQU87QUFDZEUsZ0JBQVUsb0NBQW9DLE9BQU87QUFBQSxJQUN2RDtBQUFBLEVBQ0Y7QUFFQSxRQUFNMEIsV0FBV0EsTUFBTTtBQUNyQixVQUFNQyxTQUFTLENBQUM7QUFDaEIsUUFBSSxDQUFDNUYsZ0JBQWdCakMsa0JBQWtCaUMsZ0JBQWdCakMsa0JBQWtCO0FBQ3ZFNkgsYUFBTzdILGlCQUFpQjtBQUMxQixRQUFJLENBQUNpQyxnQkFBZ0JoQyxhQUFjNEgsUUFBTzVILGVBQWU7QUFDekQsUUFBSSxDQUFDZ0MsZ0JBQWdCNUIsYUFBY3dILFFBQU94SCxlQUFlO0FBRXpELFFBQ0U0QixnQkFBZ0I1QixpQkFBaUIsbUJBQ2pDLENBQUM0QixnQkFBZ0IzQjtBQUVqQnVILGFBQU92SCxpQkFBaUI7QUFDMUIsUUFDRTJCLGdCQUFnQjVCLGlCQUFpQixZQUNqQyxDQUFDNEIsZ0JBQWdCcEI7QUFFakJnSCxhQUFPaEgsZ0JBQWdCO0FBRXpCLFFBQUlzQixjQUFjMkYsYUFBYSxZQUFZLENBQUM3RixnQkFBZ0IzQjtBQUMxRHVILGFBQU92SCxpQkFBaUI7QUFFMUI4QixxQkFBaUJ5RixNQUFNO0FBQ3ZCLFdBQU9FLE9BQU9DLEtBQUtILE1BQU0sRUFBRUksV0FBVztBQUFBLEVBQ3hDO0FBRUEsUUFBTUMseUJBQXlCLE9BQU9DLE1BQU07QUFDMUNBLE1BQUVDLGVBQWU7QUFDakIsUUFBSSxDQUFDUixTQUFTLEVBQUc7QUFFakIsUUFBSTtBQUNGLFlBQU1TLFVBQVU7QUFBQSxRQUNkQyxNQUFNekcsaUJBQWlCdUQsT0FBT3ZELGlCQUFpQnVEO0FBQUFBLFFBQy9DRCxTQUFTdEQsaUJBQWlCMEcsVUFBVW5ELE9BQU92RCxpQkFBaUJzRDtBQUFBQSxRQUM1RDJDLFVBQVU3RixnQkFBZ0JoQztBQUFBQSxRQUMxQnVJLFFBQVF2RyxnQkFBZ0JqQyxlQUFleUksU0FBUztBQUFBLFFBQ2hEQyxVQUFVekcsZ0JBQWdCNUI7QUFBQUEsUUFDMUJzSSxTQUFTO0FBQUEsUUFDVDdILE1BQU1tQixnQkFBZ0JuQjtBQUFBQSxRQUN0QlIsZ0JBQWdCMkIsZ0JBQWdCM0I7QUFBQUEsUUFDaENzSSxZQUFZNUY7QUFBQUEsUUFDWixHQUFHUDtBQUFBQSxNQUNMO0FBRUEsWUFBTXRFLElBQUkwSyxNQUFNLDZCQUE2QlIsT0FBTztBQUNwRG5DLGdCQUFVLGtDQUFrQyxTQUFTO0FBQ3JEbEUsdUJBQWlCLENBQUM4RyxNQUFNQSxJQUFJLENBQUM7QUFDN0I3QixnQkFBVTtBQUFBLElBQ1osU0FBU2pCLE9BQU87QUFDZEU7QUFBQUEsUUFDRUYsTUFBTTJCLFVBQVVuRCxNQUFNN0YsV0FDdEJxSCxNQUFNMkIsVUFBVW5ELE1BQU11RSxjQUN0QjtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxRQUFNQyxtQkFBbUIsT0FBT1YsTUFBTVcsY0FBYztBQUNsRDNKLGdCQUFZO0FBQUEsTUFDVjRKLE9BQU8sR0FBR0QsU0FBUztBQUFBLE1BQ25CRSxTQUFTLDhEQUE4REYsU0FBUztBQUFBLE1BQ2hGRyxXQUFXLFlBQVk7QUFDckIsWUFBSTtBQUNGLGdCQUFNakwsSUFBSTBLLE1BQU0sbUNBQW1DO0FBQUEsWUFDakRRLElBQUlmLEtBQUtsRDtBQUFBQSxZQUNUa0UsaUJBQWlCTDtBQUFBQSxVQUNuQixDQUFDO0FBQ0R0SyxrQkFBUTRLLFFBQVEsMEJBQTBCTixTQUFTLGVBQWU7QUFDbEVqSCwyQkFBaUIsQ0FBQ3dILFNBQVNBLE9BQU8sQ0FBQztBQUFBLFFBQ3JDLFNBQVN4RCxPQUFPO0FBQ2RDLGtCQUFRRCxNQUFNLCtCQUErQkEsS0FBSztBQUNsRHJILGtCQUFRcUgsTUFBTSw4QkFBOEI7QUFBQSxRQUM5QztBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTXlELFlBQVkxTCxRQUFRLE1BQU07QUFDOUIsVUFBTTJMLGdCQUFnQjtBQUFBLE1BQ3BCO0FBQUEsUUFDRUMsT0FBTztBQUFBLFFBQ1BDLE9BQU87QUFBQSxRQUNQQyxNQUFNLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0I7QUFBQSxRQUMxQkMsV0FBVztBQUFBLE1BQ2I7QUFBQSxNQUNBO0FBQUEsUUFDRUgsT0FBTztBQUFBLFFBQ1BDLE9BQU87QUFBQSxRQUNQQyxNQUFNLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0I7QUFBQSxRQUMxQkMsV0FBVztBQUFBLE1BQ2I7QUFBQSxNQUNBO0FBQUEsUUFDRUgsT0FBTztBQUFBLFFBQ1BDLE9BQU87QUFBQSxRQUNQQyxNQUFNLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0I7QUFBQSxRQUMxQkMsV0FBVztBQUFBLE1BQ2I7QUFBQSxNQUNBO0FBQUEsUUFDRUgsT0FBTztBQUFBLFFBQ1BDLE9BQU87QUFBQSxRQUNQQyxNQUFNLHVCQUFDLDRCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUI7QUFBQSxRQUM3QkMsV0FBVztBQUFBLE1BQ2I7QUFBQSxNQUNBO0FBQUEsUUFDRUgsT0FBTztBQUFBLFFBQ1BDLE9BQU87QUFBQSxRQUNQQyxNQUFNLHVCQUFDLCtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEI7QUFBQSxRQUNoQ0MsV0FBVztBQUFBLE1BQ2I7QUFBQSxJQUFDO0FBRUgsVUFBTUMsaUJBQWlCQSxDQUFDeEIsYUFDdEIsdUJBQUMsU0FBSSxXQUFVLG9EQUNabUIsd0JBQWNNO0FBQUFBLE1BQUksQ0FBQ0MsUUFDbEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDLE1BQU1BLElBQUlKO0FBQUFBLFVBQ1YsV0FBVywwQ0FBMENJLElBQUlILFNBQVM7QUFBQSxVQUNsRSxTQUFTLE1BQU1kLGlCQUFpQlQsVUFBVTBCLElBQUlMLEtBQUs7QUFBQSxVQUVsREssY0FBSU47QUFBQUE7QUFBQUEsUUFMQU0sSUFBSUw7QUFBQUEsUUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxJQUNELEtBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBR0YsVUFBTU0sWUFBWS9JLFVBQVU2SSxJQUFJLENBQUNHLE1BQU1DLFdBQVc7QUFBQSxNQUNoRCxHQUFHRDtBQUFBQSxNQUNIRSxPQUFPRCxRQUFRO0FBQUEsTUFDZmYsSUFBSSxNQUFNaUIsT0FBT0YsUUFBUSxDQUFDLEVBQUVHLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFBQSxNQUM1Q0MsV0FBV0wsTUFBTXJFLGFBQWEwRTtBQUFBQSxNQUM5QkMsYUFBYU4sTUFBTXJFLGFBQWEyRSxlQUFlO0FBQUEsTUFDL0NDLGNBQWNDLE9BQU9SLE1BQU1yRSxhQUFhNEUsZ0JBQWdCLENBQUM7QUFBQSxNQUN6REUsU0FBU0QsT0FBT1IsTUFBTVMsV0FBVyxDQUFDO0FBQUEsTUFDbEN0QixpQkFBaUJhLEtBQUtiLG1CQUFtQjtBQUFBLE1BQ3pDdUIsUUFDRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTTtBQUFBLFlBQ0pDLE9BQU9qSCxzQkFDSDtBQUFBLGNBQ0E7QUFBQSxnQkFDRWtILEtBQUs7QUFBQSxnQkFDTHBCLE9BQU87QUFBQSxnQkFDUHFCLFNBQVNBLE1BQ1A5RCx3QkFBd0JpRCxLQUFLckUsYUFBYVYsR0FBRztBQUFBLGNBQ2pEO0FBQUEsY0FDQTtBQUFBLGdCQUNFMkYsS0FBSztBQUFBLGdCQUNMcEIsT0FBTztBQUFBLGdCQUNQcUIsU0FBU0EsTUFDUHRELDBCQUEwQnlDLEtBQUtyRSxhQUFhVixHQUFHO0FBQUEsY0FDbkQ7QUFBQSxZQUFDLElBRUQ7QUFBQSxjQUNBO0FBQUEsZ0JBQ0UyRixLQUFLO0FBQUEsZ0JBQ0xwQixPQUFPO0FBQUEsZ0JBQ1BxQixTQUFTQSxNQUNQdEQsMEJBQTBCeUMsS0FBS3JFLGFBQWFWLEdBQUc7QUFBQSxjQUNuRDtBQUFBLGNBQ0E7QUFBQSxnQkFDRTJGLEtBQUs7QUFBQSxnQkFDTHBCLE9BQU87QUFBQSxnQkFDUHFCLFNBQVNBLE1BQ1A5RCx3QkFBd0JpRCxLQUFLckUsYUFBYVYsR0FBRztBQUFBLGNBQ2pEO0FBQUEsWUFBQztBQUFBLFVBRVA7QUFBQSxVQUNBLFNBQVMsQ0FBQyxPQUFPO0FBQUEsVUFFakIsaUNBQUMsWUFBUyxXQUFVLGtFQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRjtBQUFBO0FBQUEsUUFsQ3BGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQW1DQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBV0osRUFBRTtBQUNGLFdBQU9wRyxhQUFha0wsV0FBVzdJLFVBQVU7QUFBQSxFQUMzQyxHQUFHLENBQUNGLFVBQVVFLFVBQVUsQ0FBQztBQUV6QixRQUFNNEosVUFBVTtBQUFBLElBQ2QsRUFBRUYsS0FBSyxTQUFTRyxRQUFRLEtBQUs7QUFBQSxJQUM3QixFQUFFSCxLQUFLLE1BQU1HLFFBQVEsS0FBSztBQUFBLElBQzFCLEVBQUVILEtBQUssYUFBYUcsUUFBUSxZQUFZO0FBQUEsSUFDeEMsRUFBRUgsS0FBSyxlQUFlRyxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFSCxLQUFLLGdCQUFnQkcsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRUgsS0FBSyxXQUFXRyxRQUFRLFVBQVU7QUFBQSxJQUNwQyxFQUFFSCxLQUFLLG1CQUFtQkcsUUFBUSxrQkFBa0I7QUFBQTtBQUFBLElBRXBELEVBQUVILEtBQUssVUFBVUcsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQyxRQUFNQyxtQkFBbUIscUNBQXFDak0sVUFBVWtNLE1BQU07QUFDOUUsUUFBTUMsa0JBQWtCdE4sUUFBUSxNQUFNO0FBQ3BDLFdBQU8wTCxVQUFVNkI7QUFBQUEsTUFDZixDQUFDQyxLQUFLcEIsU0FBU29CLE9BQU9aLE9BQU9SLEtBQUtTLE9BQU8sS0FBSztBQUFBLE1BQzlDO0FBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxDQUFDbkIsU0FBUyxDQUFDO0FBQ2QsU0FDRSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsWUFBWTtBQUFBLFFBQ1osNkJBQTZCLENBQUN0QixNQUFNN0csY0FBYzZHLEVBQUVxRCxPQUFPNUIsS0FBSztBQUFBO0FBQUEsTUFGbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRW9FO0FBQUEsSUFFcEU7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU12SCxZQUFZRztBQUFBQSxRQUNsQixXQUFXSCxZQUFZRTtBQUFBQSxRQUN2QixTQUFTRixZQUFZMUQ7QUFBQUEsUUFDckIsU0FBUyxNQUFNMkQsZUFBZSxDQUFDd0csT0FBTyxFQUFFLEdBQUdBLEdBQUd2RyxZQUFZLE1BQU0sRUFBRTtBQUFBO0FBQUEsTUFKcEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSXNFO0FBQUEsSUFJdEUsdUJBQUMsU0FBSSxXQUFXdkIsZ0JBQWdCLGNBQWMsY0FDM0M7QUFBQSxPQUFDQSxpQkFBaUIsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUMzQix1QkFBQyxVQUFLLFdBQVUsaUJBQ2I7QUFBQSxTQUFDQSxpQkFBaUIsdUJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFXO0FBQUEsUUFDOUIsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSxvQ0FDWDZDLGdDQUNHLDhCQUNBLHdCQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxZQUVBLHVCQUFDLE9BQUUsV0FBVSx5QkFDVkEsZ0NBQ0csOERBQ0Esd0NBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxJQUFHO0FBQUEsZ0JBQ0gsV0FBVTtBQUFBLGdCQUNrRjtBQUFBO0FBQUEsY0FIOUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSw2SEFHYjtBQUFBLHFDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSw0Q0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUQ7QUFBQSxnQkFDekQsdUJBQUMsVUFBSyxXQUFVLDZCQUE0QixpQ0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssV0FBVSwyQkFDYjRGLG9CQUFVeEIsVUFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQTtBQUFBLGNBR0EsdUJBQUMsVUFBSyxXQUFVLDBCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QztBQUFBLGNBR3ZDLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSwwQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUQ7QUFBQSxnQkFDdkQsdUJBQUMsVUFBSyxXQUFVLDZCQUE0Qiw4QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssV0FBVSwyQkFBMEI7QUFBQTtBQUFBLGtCQUN0Q29ELGdCQUFnQkksZUFBZSxPQUFPO0FBQUEscUJBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsaUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkJBO0FBQUEsZUFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQ0E7QUFBQSxhQW5ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0RBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsNERBQ1psSyxzQkFDQyx1QkFBQyxrQkFBZSxXQUFXLFFBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0MsSUFDOUJrSSxVQUFVeEIsV0FBVyxJQUN2Qix1QkFBQyxTQUFJLFdBQVUsbUNBQWtDLDBDQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBTXdCO0FBQUFBLFlBQ047QUFBQSxZQUNBLGtCQUFpQjtBQUFBO0FBQUEsVUFIbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR2tDLEtBWHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFdBdEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1RUE7QUFBQSxTQXpFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEVBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTTtBQUFBLFFBQ04sV0FBVTtBQUFBLFFBQ1YsTUFBTW5HO0FBQUFBLFFBQ04sU0FBUyxNQUFNQyx5QkFBeUIsS0FBSztBQUFBLFFBQzdDLE9BQU87QUFBQSxRQUNQLFNBQVNHO0FBQUFBLFFBQ1QsV0FBVTtBQUFBLFFBRVQsV0FBQ2dJLE1BQU1DLFFBQVFuSSxnQkFBZ0IsS0FBS0EsaUJBQWlCeUUsV0FBVyxJQUMvRCx1QkFBQyxTQUFJLFdBQVUsa0NBQWlDLHFDQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFFLElBRXJFLHVCQUFDLFNBQUksV0FBVSxhQUNaekUsMkJBQWlCd0c7QUFBQUEsVUFBSSxDQUFDbkYsUUFDckIsdUJBQUMsU0FBa0IsV0FBVSw4REFDM0IsaUNBQUMsU0FBSSxXQUFVLGtDQUNiO0FBQUEsbUNBQUMsU0FBSTtBQUFBLHFDQUFDLFVBQUssV0FBVSxpQkFBZ0IsK0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStDO0FBQUEsY0FBTztBQUFBLGNBQUVBLElBQUl2RSxrQkFBa0I7QUFBQSxpQkFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUY7QUFBQSxZQUN2Rix1QkFBQyxTQUFJO0FBQUEscUNBQUMsVUFBSyxXQUFVLGlCQUFnQixxQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUM7QUFBQSxjQUFPO0FBQUEsY0FBRSxJQUFJSixLQUFLMkUsSUFBSStHLGdCQUFnQixFQUFFSCxlQUFlO0FBQUEsaUJBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1HO0FBQUEsWUFDbkcsdUJBQUMsU0FBSTtBQUFBLHFDQUFDLFVBQUssV0FBVSxpQkFBZ0IsdUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVDO0FBQUEsY0FBTztBQUFBLGNBQUdkLE9BQU85RixJQUFJMkQsTUFBTSxFQUFFaUQsZUFBZSxPQUFPO0FBQUEsaUJBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlHO0FBQUEsWUFDakcsdUJBQUMsU0FBSTtBQUFBLHFDQUFDLFVBQUssV0FBVSxpQkFBZ0IscUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFDO0FBQUEsY0FBTztBQUFBLGNBQUU1RyxJQUFJZ0g7QUFBQUEsaUJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdFO0FBQUEsWUFDeEUsdUJBQUMsU0FBSSxXQUFVLGNBQWE7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsaUJBQWdCLHVCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QztBQUFBLGNBQU87QUFBQSxjQUFFaEgsSUFBSUM7QUFBQUEsaUJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVGO0FBQUEsWUFDdEZELElBQUlLLFdBQVc0RyxZQUNkLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLGlCQUFnQixzQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0M7QUFBQSxjQUFPO0FBQUEsY0FBRWpILElBQUlLLFVBQVU0RyxTQUFTQztBQUFBQSxjQUFXO0FBQUEsY0FDakYsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQix1QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUM7QUFBQSxjQUFPO0FBQUEsY0FBRWxILElBQUlLLFVBQVU4RztBQUFBQSxpQkFGaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBRURuSCxJQUFJVSxZQUNILHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLGlCQUFnQixzQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0M7QUFBQSxjQUFPO0FBQUEsY0FBRVYsSUFBSVUsU0FBU0E7QUFBQUEsY0FBUztBQUFBLGNBQ3JFLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IseUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlDO0FBQUEsY0FBTztBQUFBLGNBQUVWLElBQUlVLFNBQVNDLFVBQVVnRjtBQUFBQSxpQkFGM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBRUQzRixJQUFJb0gsWUFDSCx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxpQkFBZ0IsNkJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZDO0FBQUEsY0FBTztBQUFBLGNBQUVwSCxJQUFJb0gsU0FBU0M7QUFBQUEsY0FBSztBQUFBLGNBQUdySCxJQUFJb0gsU0FBU0U7QUFBQUEsY0FBVztBQUFBLGlCQURyRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFyQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1QkEsS0F4QlF0SCxJQUFJTyxLQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUJBO0FBQUEsUUFDRCxLQTVCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkJBO0FBQUE7QUFBQSxNQXpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUEyQ0E7QUFBQSxJQTZOQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVzNEO0FBQUFBLFFBQ1gsU0FBU3dGO0FBQUFBLFFBQ1QsT0FBTTtBQUFBLFFBQ04sVUFBUztBQUFBLFFBRVQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFFBQVF0RjtBQUFBQSxZQUNSLFNBQVMsTUFBTTtBQUVieUsseUJBQVcsTUFBTTtBQUNmbkYsMEJBQVU7QUFBQSxjQUNaLEdBQUcsR0FBRztBQUFBLFlBQ1I7QUFBQSxZQUNBLFdBQVcsTUFBTTtBQUNmakYsK0JBQWlCLENBQUM4RyxNQUFNQSxJQUFJLENBQUM7QUFDN0I3Qix3QkFBVTtBQUNWZix3QkFBVSxtQ0FBbUMsU0FBUztBQUFBLFlBQ3hEO0FBQUE7QUFBQSxVQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVlJO0FBQUE7QUFBQSxNQWxCTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFvQkE7QUFBQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXaEQ7QUFBQUEsUUFDWCxTQUFTLE1BQU1DLHFCQUFxQixLQUFLO0FBQUEsUUFDekMsT0FBTTtBQUFBLFFBQ04sVUFBUztBQUFBLFFBRVQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFFBQVFDO0FBQUFBLFlBQ1IsU0FBUyxNQUFNRCxxQkFBcUIsS0FBSztBQUFBLFlBQ3pDLFdBQVcsTUFBTTtBQUNmbkIsK0JBQWlCLENBQUM4RyxNQUFNQSxJQUFJLENBQUM7QUFDN0IzRixtQ0FBcUIsS0FBSztBQUMxQitDLHdCQUFVLG1DQUFtQyxTQUFTO0FBQUEsWUFDeEQ7QUFBQTtBQUFBLFVBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT0k7QUFBQTtBQUFBLE1BYk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZUE7QUFBQSxPQXRZRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdVlBO0FBRUo7QUFBRWhGLEdBcnlCSUgsaUJBQWU7QUFBQSxVQTJCRjFCLFdBQVc7QUFBQTtBQUFBZ04sS0EzQnhCdEw7QUF1eUJOLGVBQWVBO0FBQWdCLElBQUFzTDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VNZW1vIiwidXNlQ2FsbGJhY2siLCJTaWRlYmFyIiwiTW9kYWwiLCJhcGkiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydERpYWxvZyIsIklucHV0IiwiU2VsZWN0IiwiRHJvcGRvd24iLCJQb3BvdmVyIiwiQnV0dG9uIiwibWVzc2FnZSIsIkRyYXdlciIsIkZpRXllIiwiSW9NZE1vcmUiLCJOYXZiYXIiLCJmaWx0ZXJPcHRpb24iLCJDaXJjdWxhckxvYWRlciIsImZpZWxkU2l6ZSIsIkZhV2hhdHNhcHAiLCJMaW5rIiwidXNlTG9jYXRpb24iLCJzaG93Q29uZmlybSIsIkNoZWNrQ2lyY2xlT3V0bGluZWQiLCJDbG9ja0NpcmNsZU91dGxpbmVkIiwiQ2xvc2VDaXJjbGVPdXRsaW5lZCIsIkV4Y2xhbWF0aW9uQ2lyY2xlT3V0bGluZWQiLCJRdWVzdGlvbkNpcmNsZU91dGxpbmVkIiwiQnJlYWRjcnVtYiIsIkNoaXRDYW5jZWxQYXltZW50Rm9ybSIsIkNoaXRUcmFuc2ZlclBheW1lbnRGb3JtIiwiSU5JVElBTF9QQVlNRU5UX1NUQVRFIiwicGF5bWVudF9hbW91bnQiLCJwYXltZW50X2RhdGUiLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsInBheW1lbnRfbW9kZSIsInRyYW5zYWN0aW9uX2lkIiwic2VydmljZV9jaGFyZ2VzIiwiZG9jdW1lbnRfY2hhcmdlcyIsImRhaWx5X3BheW1lbnRfYW1vdW50Iiwic3RhcnRfZGF0ZSIsImVuZF9kYXRlIiwibG9hbl9pZCIsImNoZXF1ZV9udW1iZXIiLCJub3RlIiwiUGlnbXlQYXltZW50T3V0IiwiaXNTaG93U2lkZWJhciIsInNob3dTaWRlYmFyIiwiX3MiLCJyYXdMb2FucyIsInNldFJhd0xvYW5zIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJzaG93UGF5bWVudE1vZGFsIiwic2V0U2hvd1BheW1lbnRNb2RhbCIsImN1c3RvbWVySWQiLCJzZXRDdXN0b21lcklkIiwiY3VycmVudEJvcnJvd2VyIiwic2V0Q3VycmVudEJvcnJvd2VyIiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJwYXltZW50Rm9ybURhdGEiLCJzZXRQYXltZW50Rm9ybURhdGEiLCJwYXltZW50RXJyb3JzIiwic2V0UGF5bWVudEVycm9ycyIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwidHlwZSIsInRoaXJkUGFydHlFbmFibGUiLCJzZXRUaGlyZFBhcnR5RW5hYmxlIiwid2hhdHNhcHAiLCJtb2RpZnlQYXltZW50Iiwic2V0TW9kaWZ5UGF5bWVudCIsIm1vZGlmeU1pbk1heFBheW1lbnREYXRlIiwic2V0TW9kaWZ5TWluTWF4UGF5bWVudERhdGUiLCJhZG1pbklkIiwic2V0QWRtaW5JZCIsInNob3dUcmFuc2Zlck1vZGFsIiwic2V0U2hvd1RyYW5zZmVyTW9kYWwiLCJ0cmFuc2ZlclVzZXJJZCIsInNldFRyYW5zZmVyVXNlcklkIiwic2hvd1RyYW5zYWN0aW9uRHJhd2VyIiwic2V0U2hvd1RyYW5zYWN0aW9uRHJhd2VyIiwidHJhbnNhY3Rpb25zRGF0YSIsInNldFRyYW5zYWN0aW9uc0RhdGEiLCJ0cmFuc2FjdGlvbnNMb2FkaW5nIiwic2V0VHJhbnNhY3Rpb25zTG9hZGluZyIsImxvY2F0aW9uIiwiaXNDaGl0VHJhbnNmZXJQYXlJbiIsInBhdGhuYW1lIiwiZW5kc1dpdGgiLCJpc1N0YW5kYWxvbmVQYWdlIiwiZmV0Y2hBcHByb3ZlZExvYW5zIiwiYWNjb3VudHNSZXNwb25zZSIsInRyYW5zYWN0aW9uc1Jlc3BvbnNlIiwiUHJvbWlzZSIsImFsbCIsImdldCIsImFjY291bnRzIiwiZGF0YSIsInRyYW5zYWN0aW9ucyIsInBpZ215V2l0aGRyYXdhbFVzZXJJZHMiLCJTZXQiLCJmb3JFYWNoIiwidHhuIiwicmVhc29uIiwidHJpbSIsInRvTG93ZXJDYXNlIiwiZW5yb2xsVXNlcklkIiwiZW5yb2xsX2lkIiwidXNlcl9pZCIsIl9pZCIsImFkZCIsInBpZ215VXNlcklkIiwicGlnbWVfaWQiLCJjdXN0b21lciIsImRpcmVjdFVzZXJJZCIsImZpbHRlcmVkQWNjb3VudHMiLCJmaWx0ZXIiLCJhY2NvdW50IiwiYWNjb3VudFVzZXJJZCIsInVzZXJEZXRhaWxzIiwiaGFzIiwiZXJyb3IiLCJjb25zb2xlIiwic2hvd0FsZXJ0IiwidXNlciIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJ1c2VyT2JqIiwiSlNPTiIsInBhcnNlIiwidXNlckFkbWluSWQiLCJsb2ciLCJzdHJpbmdpZnkiLCJhZG1pbkFjY2Vzc1Blcm1pc3Npb25zIiwiYWRtaW5fYWNjZXNzX3JpZ2h0X2lkIiwiYWNjZXNzX3Blcm1pc3Npb25zIiwiZWRpdF9wYXltZW50IiwiZWRpdF9saW1pdGVkX3BheW1lbnQiLCJyZXNldEZvcm0iLCJoYW5kbGVUcmFuc2Zlck1vZGFsT3BlbiIsInVzZXJJZCIsImJ1aWxkTm90ZVN0cmluZyIsImZkIiwicGFydHMiLCJwdXNoIiwiYmFua19uYW1lIiwiam9pbiIsImhhbmRsZVBheW1lbnRPdXRNb2RhbE9wZW4iLCJyZXNwb25zZSIsInZhbGlkYXRlIiwiZXJyb3JzIiwicGF5X2RhdGUiLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwiaGFuZGxlUGF5bWVudE91dFN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInBheWxvYWQiLCJsb2FuIiwiYm9ycm93ZXIiLCJhbW91bnQiLCJ0b1N0cmluZyIsInBheV90eXBlIiwicGF5X2ZvciIsImFkbWluX3R5cGUiLCJwYXRjaCIsInAiLCJzdGF0dXNDb2RlIiwidXBkYXRlTG9hblN0YXR1cyIsIm5ld1N0YXR1cyIsInRpdGxlIiwiY29udGVudCIsIm9uQ29uZmlybSIsImlkIiwiYXBwcm92YWxfc3RhdHVzIiwic3VjY2VzcyIsInByZXYiLCJ0YWJsZURhdGEiLCJzdGF0dXNPcHRpb25zIiwibGFiZWwiLCJ2YWx1ZSIsImljb24iLCJjbGFzc05hbWUiLCJwb3BvdmVyQ29udGVudCIsIm1hcCIsIm9wdCIsImZvcm1hdHRlZCIsIml0ZW0iLCJpbmRleCIsInNsX25vIiwiU3RyaW5nIiwicGFkU3RhcnQiLCJmdWxsX25hbWUiLCJjdXN0b21lcl9pZCIsInBob25lX251bWJlciIsIk51bWJlciIsImJhbGFuY2UiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsIm9uQ2xpY2siLCJjb2x1bW5zIiwiaGVhZGVyIiwiY29tbW9uSW5wdXRDbGFzcyIsImhlaWdodCIsInRvdGFsUGF5YWJsZVN1bSIsInJlZHVjZSIsInN1bSIsInRhcmdldCIsInRvTG9jYWxlU3RyaW5nIiwiQXJyYXkiLCJpc0FycmF5IiwidHJhbnNhY3Rpb25fZGF0ZSIsInRyYW5zYWN0aW9uX3R5cGUiLCJncm91cF9pZCIsImdyb3VwX25hbWUiLCJ0aWNrZXRzIiwiYWRtaW5faWQiLCJuYW1lIiwiYWRtaW5fbmFtZSIsInNldFRpbWVvdXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQaWdteVBheW1lbnRPdXQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIGltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZU1lbW8sIHVzZUNhbGxiYWNrIH0gZnJvbSBcInJlYWN0XCI7XHJcbi8vIGltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG4vLyBpbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbi8vIGltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuLy8gaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG4vLyBpbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbi8vIGltcG9ydCB7IElucHV0LCBTZWxlY3QsIERyb3Bkb3duLCBCdXR0b24sIG1lc3NhZ2UsIE1lbnUgfSBmcm9tIFwiYW50ZFwiO1xyXG4vLyBpbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG4vLyBpbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbi8vIGltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcbi8vIGltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbi8vIGltcG9ydCB7IGZpZWxkU2l6ZSB9IGZyb20gXCIuLi9kYXRhL2ZpZWxkU2l6ZVwiO1xyXG4vLyBpbXBvcnQgeyBGYVdoYXRzYXBwIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbi8vIGltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG4vLyBpbXBvcnQgeyBzaG93Q29uZmlybSB9IGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9TaG93Q29uZmlybVwiO1xyXG4vLyBpbXBvcnQge1xyXG4vLyAgIENoZWNrQ2lyY2xlT3V0bGluZWQsXHJcbi8vICAgQ2xvY2tDaXJjbGVPdXRsaW5lZCxcclxuLy8gICBDbG9zZUNpcmNsZU91dGxpbmVkLFxyXG4vLyAgIEV4Y2xhbWF0aW9uQ2lyY2xlT3V0bGluZWQsXHJcbi8vICAgUXVlc3Rpb25DaXJjbGVPdXRsaW5lZCxcclxuLy8gfSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuLy8gaW1wb3J0IEJyZWFkY3J1bWIgZnJvbSBcIi4uL2hlbHBlcnMvQnJlYWRjcnVtYlwiO1xyXG5cclxuLy8gY29uc3QgSU5JVElBTF9QQVlNRU5UX1NUQVRFID0ge1xyXG4vLyAgIHBheW1lbnRfZGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXSxcclxuLy8gICBwYXlfdHlwZTogbnVsbCxcclxuLy8gICB0cmFuc2FjdGlvbl9pZDogXCJcIixcclxuLy8gICBjaGVxdWVfbnVtYmVyOiBcIlwiLFxyXG4vLyAgIG5vdGU6IFwiXCIsXHJcbi8vIH07XHJcblxyXG4vLyBjb25zdCBQaWdteVBheW1lbnRPdXQgPSAoKSA9PiB7XHJcbi8vICAgY29uc3QgW3Jhd1BpZ21pZXMsIHNldFJhd1BpZ21pZXNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW3Nob3dQYXltZW50TW9kYWwsIHNldFNob3dQYXltZW50TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFtjdXJyZW50UGlnbXksIHNldEN1cnJlbnRQaWdteV0gPSB1c2VTdGF0ZShudWxsKTtcclxuLy8gICBjb25zdCBbcmVsb2FkVHJpZ2dlciwgc2V0UmVsb2FkVHJpZ2dlcl0gPSB1c2VTdGF0ZSgwKTtcclxuLy8gICBjb25zdCBbcGF5bWVudEZvcm1EYXRhLCBzZXRQYXltZW50Rm9ybURhdGFdID0gdXNlU3RhdGUoSU5JVElBTF9QQVlNRU5UX1NUQVRFKTtcclxuLy8gICBjb25zdCBbcGF5bWVudEVycm9ycywgc2V0UGF5bWVudEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbi8vICAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbi8vICAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuLy8gICAgIG1lc3NhZ2U6IFwiXCIsXHJcbi8vICAgICB0eXBlOiBcImluZm9cIixcclxuLy8gICB9KTtcclxuLy8gICBjb25zdCBbdGhpcmRQYXJ0eUVuYWJsZSwgc2V0VGhpcmRQYXJ0eUVuYWJsZV0gPSB1c2VTdGF0ZSh7XHJcbi8vICAgICB3aGF0c2FwcDogdHJ1ZSxcclxuLy8gICB9KTtcclxuLy8gICBjb25zdCBbYWRtaW5JZCwgc2V0QWRtaW5JZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbi8vICAgLy8gRmV0Y2ggYXBwcm92ZWQgcGlnbXkgcmVjb3Jkc1xyXG4vLyAgIGNvbnN0IGZldGNoQXBwcm92ZWRQaWdtaWVzID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4vLyAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdjEvYWRtaW4vcGlnbWVzL2FwcHJvdmVcIik7XHJcbi8vICAgICAgIC8vIHJlc3BvbnNlLmRhdGEgaXMgdGhlIGFycmF5IGRpcmVjdGx5XHJcbi8vICAgICAgIHNldFJhd1BpZ21pZXMocmVzcG9uc2UuZGF0YT8uZGF0YSB8fCBbXSk7XHJcbi8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICBzaG93QWxlcnQoXCJGYWlsZWQgdG8gZmV0Y2ggYXBwcm92ZWQgcGlnbXkgcmVjb3Jkc1wiLCBcImVycm9yXCIpO1xyXG4vLyAgICAgfSBmaW5hbGx5IHtcclxuLy8gICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuLy8gICAgIH1cclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBmZXRjaEFwcHJvdmVkUGlnbWllcygpO1xyXG4vLyAgIH0sIFtmZXRjaEFwcHJvdmVkUGlnbWllcywgcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgdXNlciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuLy8gICAgIGlmICh1c2VyKSB7XHJcbi8vICAgICAgIGNvbnN0IHVzZXJPYmogPSBKU09OLnBhcnNlKHVzZXIpO1xyXG4vLyAgICAgICBzZXRBZG1pbklkKHVzZXJPYmo/Ll9pZCk7XHJcbi8vICAgICB9XHJcbi8vICAgfSwgW10pO1xyXG5cclxuLy8gICBjb25zdCBzaG93QWxlcnQgPSAobWVzc2FnZSwgdHlwZSA9IFwiaW5mb1wiKSA9PiB7XHJcbi8vICAgICBzZXRBbGVydENvbmZpZyh7IHZpc2liaWxpdHk6IHRydWUsIG1lc3NhZ2UsIHR5cGUgfSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgcmVzZXRGb3JtID0gKCkgPT4ge1xyXG4vLyAgICAgc2V0UGF5bWVudEZvcm1EYXRhKElOSVRJQUxfUEFZTUVOVF9TVEFURSk7XHJcbi8vICAgICBzZXRQYXltZW50RXJyb3JzKHt9KTtcclxuLy8gICAgIHNldFNob3dQYXltZW50TW9kYWwoZmFsc2UpO1xyXG4vLyAgICAgc2V0Q3VycmVudFBpZ215KG51bGwpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZVBheW1lbnRPdXRNb2RhbE9wZW4gPSBhc3luYyAocGlnbXlJZCkgPT4ge1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvdjEvYWRtaW4vcGlnbWVzL2FwcHJvdmUvJHtwaWdteUlkfWApO1xyXG4vLyAgICAgICBjb25zdCBkYXRhID0gcmVzcG9uc2UuZGF0YT8uZGF0YSB8fCByZXNwb25zZS5kYXRhO1xyXG4vLyAgICAgICBzZXRDdXJyZW50UGlnbXkoZGF0YSB8fCB7fSk7XHJcbi8vICAgICAgIHNldFBheW1lbnRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuLy8gICAgICAgICAuLi5wcmV2LFxyXG4vLyAgICAgICAgIHBheW1lbnRfZGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXSxcclxuLy8gICAgICAgfSkpO1xyXG4vLyAgICAgICBzZXRTaG93UGF5bWVudE1vZGFsKHRydWUpO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgc2hvd0FsZXJ0KFwiRmFpbGVkIHRvIGZldGNoIHBpZ215IGRldGFpbHNcIiwgXCJlcnJvclwiKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCB2YWxpZGF0ZSA9ICgpID0+IHtcclxuLy8gICAgIGNvbnN0IGVycm9ycyA9IHt9O1xyXG4vLyAgICAgaWYgKCFwYXltZW50Rm9ybURhdGEucGF5bWVudF9kYXRlKSBlcnJvcnMucGF5bWVudF9kYXRlID0gXCJSZXF1aXJlZFwiO1xyXG4vLyAgICAgaWYgKCFwYXltZW50Rm9ybURhdGEucGF5X3R5cGUpIGVycm9ycy5wYXlfdHlwZSA9IFwiUmVxdWlyZWRcIjtcclxuXHJcbi8vICAgICBpZiAocGF5bWVudEZvcm1EYXRhLnBheV90eXBlID09PSBcIkJhbmsgVHJhbnNmZXJcIiAmJiAhcGF5bWVudEZvcm1EYXRhLnRyYW5zYWN0aW9uX2lkKVxyXG4vLyAgICAgICBlcnJvcnMudHJhbnNhY3Rpb25faWQgPSBcIlRyYW5zYWN0aW9uIElEIHJlcXVpcmVkXCI7XHJcbi8vICAgICBpZiAocGF5bWVudEZvcm1EYXRhLnBheV90eXBlID09PSBcIkNoZXF1ZVwiICYmICFwYXltZW50Rm9ybURhdGEuY2hlcXVlX251bWJlcilcclxuLy8gICAgICAgZXJyb3JzLmNoZXF1ZV9udW1iZXIgPSBcIkNoZXF1ZSBudW1iZXIgcmVxdWlyZWRcIjtcclxuLy8gICAgIGlmIChwYXltZW50Rm9ybURhdGEucGF5X3R5cGUgPT09IFwiT25saW5lXCIgJiYgIXBheW1lbnRGb3JtRGF0YS50cmFuc2FjdGlvbl9pZClcclxuLy8gICAgICAgZXJyb3JzLnRyYW5zYWN0aW9uX2lkID0gXCJUcmFuc2FjdGlvbiBJRCByZXF1aXJlZFwiO1xyXG5cclxuLy8gICAgIHNldFBheW1lbnRFcnJvcnMoZXJyb3JzKTtcclxuLy8gICAgIHJldHVybiBPYmplY3Qua2V5cyhlcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVQYXltZW50T3V0U3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuLy8gICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuLy8gICAgIGlmICghdmFsaWRhdGUoKSkgcmV0dXJuO1xyXG5cclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbi8vICAgICAgICAgcGlnbWVJZDogY3VycmVudFBpZ215Py5faWQsXHJcbi8vICAgICAgICAgdXNlcl9pZDogY3VycmVudFBpZ215Py5jdXN0b21lcj8uX2lkLFxyXG4vLyAgICAgICAgIHBheV9kYXRlOiBwYXltZW50Rm9ybURhdGEucGF5bWVudF9kYXRlLFxyXG4vLyAgICAgICAgIHBheV90eXBlOiBwYXltZW50Rm9ybURhdGEucGF5X3R5cGUsXHJcbi8vICAgICAgICAgYWRtaW5fdHlwZTogYWRtaW5JZCxcclxuLy8gICAgICAgICAuLi4ocGF5bWVudEZvcm1EYXRhLnRyYW5zYWN0aW9uX2lkICYmIHsgdHJhbnNhY3Rpb25faWQ6IHBheW1lbnRGb3JtRGF0YS50cmFuc2FjdGlvbl9pZCB9KSxcclxuLy8gICAgICAgICAuLi4ocGF5bWVudEZvcm1EYXRhLmNoZXF1ZV9udW1iZXIgJiYgeyBjaGVxdWVfbnVtYmVyOiBwYXltZW50Rm9ybURhdGEuY2hlcXVlX251bWJlciB9KSxcclxuLy8gICAgICAgICAuLi4ocGF5bWVudEZvcm1EYXRhLm5vdGUgJiYgeyBub3RlOiBwYXltZW50Rm9ybURhdGEubm90ZSB9KSxcclxuLy8gICAgICAgICAuLi50aGlyZFBhcnR5RW5hYmxlLFxyXG4vLyAgICAgICB9O1xyXG5cclxuLy8gICAgICAgYXdhaXQgYXBpLnBvc3QoXCIvdjEvYWRtaW4vcGF5bWVudHMtb3V0L1wiLCBwYXlsb2FkKTtcclxuLy8gICAgICAgc2hvd0FsZXJ0KFwiUGF5bWVudCBkaXNidXJzZWQgc3VjY2Vzc2Z1bGx5XCIsIFwic3VjY2Vzc1wiKTtcclxuLy8gICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocCkgPT4gcCArIDEpO1xyXG4vLyAgICAgICByZXNldEZvcm0oKTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgIHNob3dBbGVydChcclxuLy8gICAgICAgICBlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBlcnJvci5yZXNwb25zZT8uZGF0YT8uc3RhdHVzQ29kZSB8fCBcIlRyYW5zYWN0aW9uIGZhaWxlZFwiLFxyXG4vLyAgICAgICAgIFwiZXJyb3JcIlxyXG4vLyAgICAgICApO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IHVwZGF0ZVBpZ215U3RhdHVzID0gYXN5bmMgKHBpZ215LCBuZXdTdGF0dXMpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGF3YWl0IGFwaS5wYXRjaChgL3YxL2FkbWluL3BpZ21lcy9zdGF0dXMvJHtwaWdteS5faWR9YCwge1xyXG4vLyAgICAgICAgIHJlcXVlc3Rfc3RhdHVzOiBuZXdTdGF0dXMsXHJcbi8vICAgICAgIH0pO1xyXG4vLyAgICAgICBtZXNzYWdlLnN1Y2Nlc3MoYFBpZ215IHN0YXR1cyB1cGRhdGVkIHRvICR7bmV3U3RhdHVzfSBzdWNjZXNzZnVsbHlgKTtcclxuLy8gICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIHBpZ215IHN0YXR1czpcIiwgZXJyb3IpO1xyXG4vLyAgICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIHVwZGF0ZSBwaWdteSBzdGF0dXNcIik7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgdGFibGVEYXRhID0gdXNlTWVtbygoKSA9PiB7XHJcblxyXG4vLyAgICAgLy8gUG9wb3ZlciBjb250ZW50IGZvciBzdGF0dXMgdXBkYXRlIChzaG93biBvbiBob3ZlcilcclxuLy8gICAgIGNvbnN0IHNob3dSZXF1ZXN0ZWRDb25maXJtID0gKHBpZ215KSA9PiB7XHJcbi8vICAgICAgIGNvbnN0IGN1c3RvbWVyTmFtZSA9IHBpZ215LmN1c3RvbWVyPy5mdWxsX25hbWUgfHwgJ+KAlCc7XHJcbi8vICAgICAgIGNvbnN0IHBpZ215SWQgPSBwaWdteS5waWdtZV9pZCB8fCAn4oCUJztcclxuLy8gICAgICAgY29uc3QgYW1vdW50ID0gcGlnbXkucGF5YWJsZV9hbW91bnQgfHwgMDtcclxuLy8gICAgICAgc2hvd0NvbmZpcm0oe1xyXG4vLyAgICAgICAgIHRpdGxlOiAnQ29uZmlybSBTdGF0dXMgQ2hhbmdlJyxcclxuLy8gICAgICAgICBjb250ZW50OiBgRG8geW91IHdhbnQgdG8gY2hhbmdlIHN0YXR1cyBvZiBjdXN0b21lciBcIiR7Y3VzdG9tZXJOYW1lfVwiIChQaWdteSBJRDogJHtwaWdteUlkfSwgQW1vdW50OiDigrkke2Ftb3VudH0pIHRvIFwiUmVxdWVzdGVkXCI/YCxcclxuLy8gICAgICAgICBva1RleHQ6ICdZZXMnLFxyXG4vLyAgICAgICAgIGNhbmNlbFRleHQ6ICdObycsXHJcbi8vICAgICAgICAgb25Db25maXJtOiAoKSA9PiB1cGRhdGVQaWdteVN0YXR1cyhwaWdteSwgJ1JFUVVFU1RFRCcpLFxyXG4vLyAgICAgICB9KTtcclxuLy8gICAgIH07XHJcblxyXG4vLyAgICAgY29uc3QgZm9ybWF0dGVkID0gcmF3UGlnbWllcy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoe1xyXG4vLyAgICAgICAuLi5pdGVtLFxyXG4vLyAgICAgICBzbF9ubzogaW5kZXggKyAxLFxyXG4vLyAgICAgICBwaWdteV9pZDogaXRlbS5waWdtZV9pZCB8fCBcIuKAlFwiLFxyXG4vLyAgICAgICB1c2VyX25hbWU6IGl0ZW0uY3VzdG9tZXI/LmZ1bGxfbmFtZSB8fCBcIuKAlFwiLFxyXG4vLyAgICAgICBwaG9uZV9udW1iZXI6IGl0ZW0uY3VzdG9tZXI/LnBob25lX251bWJlciB8fCBcIuKAlFwiLFxyXG4vLyAgICAgICBkdXJhdGlvbjogaXRlbS5kdXJhdGlvbiA/IGAke2l0ZW0uZHVyYXRpb259IG1vbnRoc2AgOiBcIuKAlFwiLFxyXG4vLyAgICAgICBtYXR1cml0eV9pbmZvOiBgJHtpdGVtLm1hdHVyaXR5X3BlcmlvZCB8fCAwfSAvIOKCuSR7aXRlbS5wYXlhYmxlX2Ftb3VudCB8fCAwfWAsXHJcbi8vICAgICAgIHBpZ215X2Ftb3VudDogaXRlbS5wYXlhYmxlX2Ftb3VudCB8fCAwLFxyXG4vLyAgICAgICB0b3RhbF9wYWlkOiBpdGVtLnRvdGFsX3BhaWQgfHwgXCLigJRcIixcclxuLy8gICAgICAgLy8gbWF0dXJpdHlfYW1vdW50OiBpdGVtLm1hdHVyaXR5X2Ftb3VudCB8fCBcIuKAlFwiLFxyXG4vLyAgICAgICBjbG9zdXJlX3R5cGU6IGl0ZW0uY2xvc3VyZV90eXBlIHx8IFwi4oCUXCIsXHJcbi8vICAgICAgIGFjdGlvbjogKFxyXG4vLyAgICAgICAgIDxEcm9wZG93blxyXG4vLyAgICAgICAgICAgb3ZlcmxheT17XHJcbi8vICAgICAgICAgICAgIDxNZW51PlxyXG4vLyAgICAgICAgICAgICAgIDxNZW51Lkl0ZW0ga2V5PVwicGF5bWVudFwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZVBheW1lbnRPdXRNb2RhbE9wZW4oaXRlbS5faWQpfT5cclxuLy8gICAgICAgICAgICAgICAgIFBheW1lbnQgT3V0XHJcbi8vICAgICAgICAgICAgICAgPC9NZW51Lkl0ZW0+XHJcbi8vICAgICAgICAgICAgICAgPE1lbnUuSXRlbSBrZXk9XCJwcmludC1wcmVjbG9zdXJlXCIgb25DbGljaz17KCkgPT5cclxuLy8gICAgICAgICAgICAgICAgIHdpbmRvdy5vcGVuKFxyXG4vLyAgICAgICAgICAgICAgICAgICBgL3BpZ215LXByZWNsb3N1cmUtcHJpbnQvJHtpdGVtLl9pZH1gLFxyXG4vLyAgICAgICAgICAgICAgICAgICBcIl9ibGFua1wiXHJcbi8vICAgICAgICAgICAgICAgICApXHJcbi8vICAgICAgICAgICAgICAgfT5cclxuLy8gICAgICAgICAgICAgICAgIPCflqjvuI8gUHJlY2xvc3VyZSBGb3JtXHJcbi8vICAgICAgICAgICAgICAgPC9NZW51Lkl0ZW0+XHJcbi8vICAgICAgICAgICAgICAgPE1lbnUuU3ViTWVudSBrZXk9XCJzdGF0dXNcIiB0aXRsZT17PHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiPlVwZGF0ZSBTdGF0dXM8L3NwYW4+fT5cclxuLy8gICAgICAgICAgICAgICAgIDxNZW51Lkl0ZW1cclxuLy8gICAgICAgICAgICAgICAgICAga2V5PVwicmVxdWVzdGVkXCJcclxuLy8gICAgICAgICAgICAgICAgICAgaWNvbj17PEV4Y2xhbWF0aW9uQ2lyY2xlT3V0bGluZWQgLz59XHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzaG93UmVxdWVzdGVkQ29uZmlybShpdGVtKX1cclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgUmVxdWVzdGVkXHJcbi8vICAgICAgICAgICAgICAgICA8L01lbnUuSXRlbT5cclxuLy8gICAgICAgICAgICAgICA8L01lbnUuU3ViTWVudT5cclxuLy8gICAgICAgICAgICAgPC9NZW51PlxyXG4vLyAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgdHJpZ2dlcj17WydjbGljayddfVxyXG4vLyAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbi8vICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQteGwgY3Vyc29yLXBvaW50ZXIgaG92ZXI6dGV4dC1ibHVlLTYwMCB0cmFuc2l0aW9uLWNvbG9yc1wiIC8+XHJcbi8vICAgICAgICAgPC9Ecm9wZG93bj5cclxuLy8gICAgICAgKSxcclxuLy8gICAgIH0pKTtcclxuXHJcbi8vICAgICByZXR1cm4gZmlsdGVyT3B0aW9uKGZvcm1hdHRlZCwgc2VhcmNoVGV4dCwgW1widXNlcl9uYW1lXCIsIFwicGlnbXlfaWRcIl0pO1xyXG4vLyAgIH0sIFtyYXdQaWdtaWVzLCBzZWFyY2hUZXh0XSk7XHJcblxyXG4vLyAgIGNvbnN0IGNvbHVtbnMgPSBbXHJcbi8vICAgICB7IGtleTogXCJzbF9ub1wiLCBoZWFkZXI6IFwiU0xcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwicGlnbXlfaWRcIiwgaGVhZGVyOiBcIlBpZ215IElEXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInVzZXJfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lXCIgfSxcclxuLy8gICAgIHtcclxuLy8gICAgICAga2V5OiBcIm1hdHVyaXR5X2luZm9cIixcclxuLy8gICAgICAgaGVhZGVyOiBgUGlnbXkgQW1vdW50YFxyXG4vLyAgICAgfSxcclxuLy8gICAgIHsga2V5OiBcImR1cmF0aW9uXCIsIGhlYWRlcjogXCJEdXJhdGlvblwiIH0sXHJcbi8vICAgICB7IGtleTogXCJ0b3RhbF9wYWlkXCIsIGhlYWRlcjogXCJ0b3RhbCBwYWlkXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImNsb3N1cmVfdHlwZVwiLCBoZWFkZXI6IFwiQ2xvc3VyZSBUeXBlXCIgfSxcclxuLy8gICAgIC8vIHsga2V5OiBcInBpZ215X2Ftb3VudFwiLCBoZWFkZXI6IFwiQW1vdW50ICjigrkpXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInJlcXVlc3Rfc3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4vLyAgIF07XHJcblxyXG4vLyAgIGNvbnN0IGNvbW1vbklucHV0Q2xhc3MgPSBgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWA7XHJcblxyXG4vLyAgIHJldHVybiAoXHJcbi8vICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1ncmF5LTUwXCI+XHJcbi8vICAgICAgIDxOYXZiYXJcclxuLy8gICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4vLyAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17KGUpID0+IHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAvPlxyXG4vLyAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuLy8gICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4vLyAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuLy8gICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4vLyAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEFsZXJ0Q29uZmlnKChwKSA9PiAoeyAuLi5wLCB2aXNpYmlsaXR5OiBmYWxzZSB9KSl9XHJcbi8vICAgICAgIC8+XHJcblxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuLy8gICAgICAgICA8U2lkZWJhciAvPlxyXG4vLyAgICAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTZcIj5cclxuLy8gICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWVuZCBtYi0yXCI+XHJcblxyXG4vLyAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPlBpZ215IFBheW1lbnQgT3V0PC9oMT5cclxuLy8gICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5EaXNidXJzZSBhcHByb3ZlZCBwaWdteSBmdW5kcyB0byB1c2VyczwvcD5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgbWItMiBnYXAtM1wiPlxyXG4vLyAgICAgICAgICAgICA8TGlua1xyXG4vLyAgICAgICAgICAgICAgIHRvPVwiL290aGVyLXNlcnZpY2UtbWVudS9waWdtZVwiXHJcbi8vICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWJsdWUtNTAwIHRleHQtYmx1ZS02MDAgcm91bmRlZC1sZyBcclxuLy8gICAgICAgICAgICAgICAgaG92ZXI6YmctYmx1ZS01MCBob3Zlcjp0ZXh0LWJsdWUtNzAwIGhvdmVyOmJvcmRlci1ibHVlLTYwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgZm9udC1tZWRpdW1cIlxyXG4vLyAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgT3RoZXIgU2VydmljZXMgLyBQaWdteVxyXG4vLyAgICAgICAgICAgICA8L0xpbms+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS0xMDAgdGV4dC1ibHVlLTcwMCBweC00IHB5LTMgcm91bmRlZC1mdWxsIHRleHQtc20gZm9udC1tZWRpdW1cIj5cclxuLy8gICAgICAgICAgICAgICBQZW5kaW5nIFBheW1lbnRzOiB7dGFibGVEYXRhLmxlbmd0aH1cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0xMDAgcC00XCI+XHJcbi8vICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbi8vICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGlzTG9hZGluZz17dHJ1ZX0gLz5cclxuLy8gICAgICAgICAgICAgKSA6IHRhYmxlRGF0YS5sZW5ndGggPT09IDAgPyAoXHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0yMCB0ZXh0LWdyYXktNDAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICBObyBwZW5kaW5nIHBpZ215IHBheW1lbnRzIGZvdW5kLlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuLy8gICAgICAgICAgICAgICAgIGRhdGE9e3RhYmxlRGF0YX1cclxuLy8gICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbi8vICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiUGlnbXlfUGF5bWVudHNcIlxyXG4vLyAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L21haW4+XHJcbi8vICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgey8qIFBheW1lbnQgRGlzYnVyc2VtZW50IE1vZGFsICovfVxyXG4vLyAgICAgICA8TW9kYWwgaXNWaXNpYmxlPXtzaG93UGF5bWVudE1vZGFsfSBvbkNsb3NlPXtyZXNldEZvcm19PlxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02XCI+XHJcbi8vICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgbWItNCBib3JkZXItYiBwYi0yXCI+Q29uZmlybSBQaWdteSBEaXNidXJzZW1lbnQ8L2gzPlxyXG5cclxuLy8gICAgICAgICAgIHtjdXJyZW50UGlnbXkgJiYgKFxyXG4vLyAgICAgICAgICAgICA8PlxyXG4vLyAgICAgICAgICAgICAgIHsvKiBNYWluIGluZm8gcm93ICovfVxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBtZDpncmlkLWNvbHMtNCBnYXAtNCBtYi02IGJnLWdyYXktNTAgcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1kYXNoZWRcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSB0ZXh0LWdyYXktNTAwIGZvbnQtYm9sZFwiPlVzZXI8L3A+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50UGlnbXk/LmN1c3RvbWVyPy5mdWxsX25hbWUgfHwgXCLigJRcIn1cclxuLy8gICAgICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgbXQtMVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50UGlnbXk/LmN1c3RvbWVyPy5waG9uZV9udW1iZXIgfHwgXCLigJRcIn1cclxuLy8gICAgICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdGV4dC1ncmF5LTUwMCBmb250LWJvbGRcIj5QaWdteSBJRDwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1vbm9cIj57Y3VycmVudFBpZ215Py5waWdtZV9pZCB8fCBcIuKAlFwifTwvcD5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRleHQtZ3JheS01MDAgZm9udC1ib2xkXCI+VG90YWwgQW1vdW50IFBhaWQ8L3A+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JlZW4tNjAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAg4oK5e2N1cnJlbnRQaWdteT8udG90YWxfcGFpZD8udG9Mb2NhbGVTdHJpbmcoKSB8fCAwfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSB0ZXh0LWdyYXktNTAwIGZvbnQtYm9sZFwiPiB7Y3VycmVudFBpZ215Py5jbG9zdXJlX3R5cGUgPT09IFwiUFJFLU1BVFVSRURcIiA/IFwiUHJlbWF0dXJlIFdpdGhkcmF3YWwgRGVkdWN0aW9uXCIgOiBcIk1hdHVyaXR5IEludGVyZXN0ICglKVwifTwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPXtgdGV4dC1zbSBmb250LXNlbWlib2xkICR7Y3VycmVudFBpZ215Py5jbG9zdXJlX3R5cGUgPT09IFwiUFJFLU1BVFVSRURcIiA/IFwidGV4dC1yZWQtNjAwXCIgOiBcInRleHQtcHVycGxlLTYwMFwifWB9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50UGlnbXk/LmNsb3N1cmVfdHlwZSA9PT0gXCJQUkUtTUFUVVJFRFwiID8gY3VycmVudFBpZ215Py5wcmVfbWF0dXJlZF9pbnRlcmVzdCA6IGN1cnJlbnRQaWdteT8ubWF0dXJpdHlfaW50ZXJlc3QgfHwgMH0lXHJcbi8vICAgICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgey8qIEFkZGl0aW9uYWwgcGlnbXkgZGV0YWlscyAqL31cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTQgbWItNiBiZy13aGl0ZSBwLTQgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCI+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRleHQtZ3JheS01MDAgZm9udC1ib2xkXCI+Q2xvc3VyZSBUeXBlPC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBweC0yIHB5LTEgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1tZWRpdW0gYmcteWVsbG93LTEwMCB0ZXh0LXllbGxvdy04MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7Y3VycmVudFBpZ215Py5jbG9zdXJlX3R5cGUgfHwgXCLigJRcIn1cclxuLy8gICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdGV4dC1ncmF5LTUwMCBmb250LWJvbGRcIj5EdXJhdGlvbjwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRQaWdteT8uZHVyYXRpb24gfHwgMH0gbW9udGhzXHJcbi8vICAgICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAge2N1cnJlbnRQaWdteT8uY2xvc3VyZV9kYXRlICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgPD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRleHQtZ3JheS01MDAgZm9udC1ib2xkXCI+Q2xvc3VyZSBEYXRlPC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShjdXJyZW50UGlnbXkuY2xvc3VyZV9kYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1HQlwiKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSB0ZXh0LWdyYXktNTAwIGZvbnQtYm9sZFwiPk1hdHVyaXR5IEFtb3VudDwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JlZW4tNjAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtjdXJyZW50UGlnbXk/Lm1hdHVyaXR5X2Ftb3VudD8udG9Mb2NhbGVTdHJpbmcoKSB8fCAwfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8Lz5cclxuLy8gICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgIHsvKiBJZiBubyBjbG9zdXJlIGRhdGEsIHNob3cgYSBwbGFjZWhvbGRlciByb3cgKG9wdGlvbmFsKSAqL31cclxuLy8gICAgICAgICAgICAgICB7IWN1cnJlbnRQaWdteT8uY2xvc3VyZV9kYXRlICYmIChcclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwIGl0YWxpYyBtYi00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIE5vIGNsb3N1cmUgaW5mb3JtYXRpb24gYXZhaWxhYmxlIChhY3RpdmUgcGlnbXkpLlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgPC8+XHJcbi8vICAgICAgICAgICApfVxyXG5cclxuLy8gICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVQYXltZW50T3V0U3VibWl0fSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuLy8gICAgICAgICAgICAgey8qIFBheW1lbnQgZm9ybSBmaWVsZHMgcmVtYWluIHVuY2hhbmdlZCAqL31cclxuLy8gICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDBcIj5QYXltZW50IERhdGU8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgIDxJbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgdmFsdWU9e3BheW1lbnRGb3JtRGF0YS5wYXltZW50X2RhdGV9XHJcbi8vICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbi8vICAgICAgICAgICAgICAgICAgIHNldFBheW1lbnRGb3JtRGF0YSgocCkgPT4gKHsgLi4ucCwgcGF5bWVudF9kYXRlOiBlLnRhcmdldC52YWx1ZSB9KSlcclxuLy8gICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y29tbW9uSW5wdXRDbGFzc31cclxuLy8gICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgIHtwYXltZW50RXJyb3JzLnBheW1lbnRfZGF0ZSAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1bMTBweF1cIj57cGF5bWVudEVycm9ycy5wYXltZW50X2RhdGV9PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDBcIj5QYXltZW50IE1vZGU8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgIDxTZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtdC0xXCJcclxuLy8gICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE1vZGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgdmFsdWU9e3BheW1lbnRGb3JtRGF0YS5wYXlfdHlwZX1cclxuLy8gICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodikgPT4gc2V0UGF5bWVudEZvcm1EYXRhKChwKSA9PiAoeyAuLi5wLCBwYXlfdHlwZTogdiB9KSl9XHJcbi8vICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJDYXNoXCI+Q2FzaDwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiQmFuayBUcmFuc2ZlclwiPkJhbmsgVHJhbnNmZXI8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIkNoZXF1ZVwiPkNoZXF1ZTwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiT25saW5lXCI+T25saW5lPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgIHtwYXltZW50RXJyb3JzLnBheV90eXBlICYmIChcclxuLy8gICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LVsxMHB4XVwiPntwYXltZW50RXJyb3JzLnBheV90eXBlfTwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgIHtwYXltZW50Rm9ybURhdGEucGF5X3R5cGUgPT09IFwiQmFuayBUcmFuc2ZlclwiICYmIChcclxuLy8gICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPElucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVHJhbnNhY3Rpb24gSUQgKlwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXltZW50Rm9ybURhdGEudHJhbnNhY3Rpb25faWR9XHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICBzZXRQYXltZW50Rm9ybURhdGEoKHApID0+ICh7IC4uLnAsIHRyYW5zYWN0aW9uX2lkOiBlLnRhcmdldC52YWx1ZSB9KSlcclxuLy8gICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NvbW1vbklucHV0Q2xhc3N9XHJcbi8vICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAge3BheW1lbnRFcnJvcnMudHJhbnNhY3Rpb25faWQgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1bMTBweF1cIj57cGF5bWVudEVycm9ycy50cmFuc2FjdGlvbl9pZH08L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICApfVxyXG5cclxuLy8gICAgICAgICAgICAge3BheW1lbnRGb3JtRGF0YS5wYXlfdHlwZSA9PT0gXCJDaGVxdWVcIiAmJiAoXHJcbi8vICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNoZXF1ZSBOdW1iZXIgKlwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXltZW50Rm9ybURhdGEuY2hlcXVlX251bWJlcn1cclxuLy8gICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHNldFBheW1lbnRGb3JtRGF0YSgocCkgPT4gKHsgLi4ucCwgY2hlcXVlX251bWJlcjogZS50YXJnZXQudmFsdWUgfSkpXHJcbi8vICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjb21tb25JbnB1dENsYXNzfVxyXG4vLyAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgIHtwYXltZW50RXJyb3JzLmNoZXF1ZV9udW1iZXIgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1bMTBweF1cIj57cGF5bWVudEVycm9ycy5jaGVxdWVfbnVtYmVyfTwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICl9XHJcblxyXG4vLyAgICAgICAgICAgICB7cGF5bWVudEZvcm1EYXRhLnBheV90eXBlID09PSBcIk9ubGluZVwiICYmIChcclxuLy8gICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPElucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVHJhbnNhY3Rpb24gSUQgKlwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXltZW50Rm9ybURhdGEudHJhbnNhY3Rpb25faWR9XHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICBzZXRQYXltZW50Rm9ybURhdGEoKHApID0+ICh7IC4uLnAsIHRyYW5zYWN0aW9uX2lkOiBlLnRhcmdldC52YWx1ZSB9KSlcclxuLy8gICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NvbW1vbklucHV0Q2xhc3N9XHJcbi8vICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAge3BheW1lbnRFcnJvcnMudHJhbnNhY3Rpb25faWQgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1bMTBweF1cIj57cGF5bWVudEVycm9ycy50cmFuc2FjdGlvbl9pZH08L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICApfVxyXG5cclxuLy8gICAgICAgICAgICAgPElucHV0LlRleHRBcmVhXHJcbi8vICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOb3RlIChJbnRlcm5hbCByZWNvcmQpXCJcclxuLy8gICAgICAgICAgICAgICByb3dzPXsyfVxyXG4vLyAgICAgICAgICAgICAgIHZhbHVlPXtwYXltZW50Rm9ybURhdGEubm90ZX1cclxuLy8gICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFBheW1lbnRGb3JtRGF0YSgocCkgPT4gKHsgLi4ucCwgbm90ZTogZS50YXJnZXQudmFsdWUgfSkpfVxyXG4vLyAgICAgICAgICAgICAvPlxyXG5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtM1wiPlxyXG4vLyAgICAgICAgICAgICAgICAgPEZhV2hhdHNhcHAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDAgdy01IGgtNVwiIC8+XHJcbi8vICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwXCI+RW5hYmxlIFdoYXRzQXBwIFNlbmRpbmc8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4vLyAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcmRQYXJ0eUVuYWJsZS53aGF0c2FwcH1cclxuLy8gICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICBzZXRUaGlyZFBhcnR5RW5hYmxlKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB3aGF0c2FwcDogIXByZXYud2hhdHNhcHAgfSkpXHJcbi8vICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01IGFjY2VudC1ncmVlbi02MDAgY3Vyc29yLXBvaW50ZXJcIlxyXG4vLyAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0yIHB0LTRcIj5cclxuLy8gICAgICAgICAgICAgICA8YnV0dG9uXHJcbi8vICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuLy8gICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3Jlc2V0Rm9ybX1cclxuLy8gICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXNtIHRleHQtZ3JheS01MDAgaG92ZXI6YmctZ3JheS0xMDAgcm91bmRlZFwiXHJcbi8vICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgQ2FuY2VsXHJcbi8vICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbi8vICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC02IHB5LTIgdGV4dC1zbSBiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQgZm9udC1ib2xkIGhvdmVyOmJnLWJsdWUtNzAwIHNoYWRvdy1sZ1wiXHJcbi8vICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgQ29uZmlybSBEaXNidXJzZW1lbnRcclxuLy8gICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8L2Zvcm0+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgIDwvTW9kYWw+XHJcbi8vICAgICA8L2Rpdj5cclxuLy8gICApO1xyXG4vLyB9O1xyXG5cclxuLy8gZXhwb3J0IGRlZmF1bHQgUGlnbXlQYXltZW50T3V0O1xyXG5cclxuXHJcblxyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VNZW1vLCB1c2VDYWxsYmFjayB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0RGlhbG9nIGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydERpYWxvZ1wiO1xyXG5pbXBvcnQgeyBJbnB1dCwgU2VsZWN0LCBEcm9wZG93biwgUG9wb3ZlciwgQnV0dG9uLCBtZXNzYWdlIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgRHJhd2VyIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgRmlFeWUgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmlcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgeyBmaWVsZFNpemUgfSBmcm9tIFwiLi4vZGF0YS9maWVsZFNpemVcIjtcclxuaW1wb3J0IHsgRmFXaGF0c2FwcCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VMb2NhdGlvbiB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IHNob3dDb25maXJtIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL1Nob3dDb25maXJtXCI7XHJcbmltcG9ydCB7XHJcbiAgQ2hlY2tDaXJjbGVPdXRsaW5lZCxcclxuICBDbG9ja0NpcmNsZU91dGxpbmVkLFxyXG4gIENsb3NlQ2lyY2xlT3V0bGluZWQsXHJcbiAgRXhjbGFtYXRpb25DaXJjbGVPdXRsaW5lZCxcclxuICBRdWVzdGlvbkNpcmNsZU91dGxpbmVkLFxyXG59IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5pbXBvcnQgQnJlYWRjcnVtYiBmcm9tIFwiLi4vaGVscGVycy9CcmVhZGNydW1iXCI7XHJcbmltcG9ydCBDaGl0Q2FuY2VsUGF5bWVudEZvcm0gZnJvbSBcIi4vQ2hpdENhbmNlbFBheW1lbnRGb3JtXCI7XHJcbmltcG9ydCBDaGl0VHJhbnNmZXJQYXltZW50Rm9ybSBmcm9tIFwiLi9DaGl0VHJhbnNmZXJQYXltZW50Rm9ybVwiO1xyXG5cclxuY29uc3QgSU5JVElBTF9QQVlNRU5UX1NUQVRFID0ge1xyXG4gIHBheW1lbnRfYW1vdW50OiBcIlwiLFxyXG4gIHBheW1lbnRfZGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXSxcclxuICBwYXltZW50X21vZGU6IG51bGwsXHJcbiAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgc2VydmljZV9jaGFyZ2VzOiBcIlwiLFxyXG4gIGRvY3VtZW50X2NoYXJnZXM6IFwiXCIsXHJcbiAgZGFpbHlfcGF5bWVudF9hbW91bnQ6IFwiXCIsXHJcbiAgc3RhcnRfZGF0ZTogXCJcIixcclxuICBlbmRfZGF0ZTogXCJcIixcclxuICBsb2FuX2lkOiBcIlwiLFxyXG4gIGNoZXF1ZV9udW1iZXI6IFwiXCIsXHJcbiAgbm90ZTogXCJcIixcclxufTtcclxuXHJcbmNvbnN0IFBpZ215UGF5bWVudE91dCA9ICh7IGlzU2hvd1NpZGViYXI6IHNob3dTaWRlYmFyIH0pID0+IHtcclxuICBjb25zdCBbcmF3TG9hbnMsIHNldFJhd0xvYW5zXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93UGF5bWVudE1vZGFsLCBzZXRTaG93UGF5bWVudE1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VzdG9tZXJJZCwgc2V0Q3VzdG9tZXJJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbY3VycmVudEJvcnJvd2VyLCBzZXRDdXJyZW50Qm9ycm93ZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3JlbG9hZFRyaWdnZXIsIHNldFJlbG9hZFRyaWdnZXJdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW3BheW1lbnRGb3JtRGF0YSwgc2V0UGF5bWVudEZvcm1EYXRhXSA9IHVzZVN0YXRlKElOSVRJQUxfUEFZTUVOVF9TVEFURSk7XHJcbiAgY29uc3QgW3BheW1lbnRFcnJvcnMsIHNldFBheW1lbnRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW3RoaXJkUGFydHlFbmFibGUsIHNldFRoaXJkUGFydHlFbmFibGVdID0gdXNlU3RhdGUoe1xyXG4gICAgd2hhdHNhcHA6IHRydWUsXHJcbiAgfSk7XHJcbiAgY29uc3QgW21vZGlmeVBheW1lbnQsIHNldE1vZGlmeVBheW1lbnRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFttb2RpZnlNaW5NYXhQYXltZW50RGF0ZSwgc2V0TW9kaWZ5TWluTWF4UGF5bWVudERhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFthZG1pbklkLCBzZXRBZG1pbklkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzaG93VHJhbnNmZXJNb2RhbCwgc2V0U2hvd1RyYW5zZmVyTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpOyAvLyBuZXdcclxuICBjb25zdCBbdHJhbnNmZXJVc2VySWQsIHNldFRyYW5zZmVyVXNlcklkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzaG93VHJhbnNhY3Rpb25EcmF3ZXIsIHNldFNob3dUcmFuc2FjdGlvbkRyYXdlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3RyYW5zYWN0aW9uc0RhdGEsIHNldFRyYW5zYWN0aW9uc0RhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt0cmFuc2FjdGlvbnNMb2FkaW5nLCBzZXRUcmFuc2FjdGlvbnNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xyXG4gIGNvbnN0IGlzQ2hpdFRyYW5zZmVyUGF5SW4gPSBsb2NhdGlvbi5wYXRobmFtZS5lbmRzV2l0aChcIi9jaGl0LXRyYW5zZmVyLXBheS1pblwiLCk7XHJcbiAgY29uc3QgaXNTdGFuZGFsb25lUGFnZSA9XHJcbiAgICBsb2NhdGlvbi5wYXRobmFtZS5lbmRzV2l0aChcIi9jaGl0LWNhbmNlbGF0aW9uLXBheS1vdXRcIikgfHxcclxuICAgIGxvY2F0aW9uLnBhdGhuYW1lLmVuZHNXaXRoKFwiL2NoaXQtdHJhbnNmZXItcGF5LWluXCIpO1xyXG4gIGNvbnN0IGlzU2hvd1NpZGViYXIgPSBpc1N0YW5kYWxvbmVQYWdlID8gdHJ1ZSA6IHNob3dTaWRlYmFyO1xyXG4gIC8vIGNvbnN0IGhhbmRsZVZpZXdUcmFuc2FjdGlvbnMgPSBhc3luYyAodXNlcklkKSA9PiB7XHJcbiAgLy8gICBpZiAoIXVzZXJJZCkge1xyXG4gIC8vICAgICBtZXNzYWdlLndhcm5pbmcoXCJVc2VyIElEIG1pc3NpbmdcIik7XHJcbiAgLy8gICAgIHJldHVybjtcclxuICAvLyAgIH1cclxuXHJcbiAgLy8gICBzZXRUcmFuc2FjdGlvbnNMb2FkaW5nKHRydWUpO1xyXG4gIC8vICAgdHJ5IHtcclxuICAvLyAgICAgLy8gRmV0Y2ggYWxsIHRyYW5zYWN0aW9ucyAod2l0aG91dCBhbnkgcXVlcnkgcGFyYW0pXHJcbiAgLy8gICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi92MS9hZG1pbi90cmFuc2FjdGlvbi1oaXN0b3J5L1wiKTtcclxuICAvLyAgICAgY29uc3QgcmF3RGF0YSA9IHJlc3BvbnNlLmRhdGE7XHJcbiAgLy8gICAgIGNvbnN0IGFsbFRyYW5zYWN0aW9ucyA9IEFycmF5LmlzQXJyYXkocmF3RGF0YSkgPyByYXdEYXRhIDogcmF3RGF0YT8uZGF0YSB8fCBbXTtcclxuXHJcbiAgLy8gICAgIC8vIEZpbHRlciB0cmFuc2FjdGlvbnMgdGhhdCBiZWxvbmcgdG8gdGhpcyB1c2VyXHJcbiAgLy8gICAgIGNvbnN0IGZpbHRlcmVkVHJhbnNhY3Rpb25zID0gYWxsVHJhbnNhY3Rpb25zLmZpbHRlcihcclxuICAvLyAgICAgICAodHhuKSA9PlxyXG4gIC8vICAgICAgICAgdHhuLmVucm9sbF9pZD8udXNlcl9pZD8uX2lkID09PSB1c2VySWQgfHxcclxuICAvLyAgICAgICAgIHR4bi5waWdtZV9pZD8uY3VzdG9tZXI/Ll9pZCA9PT0gdXNlcklkXHJcbiAgLy8gICAgICk7XHJcblxyXG4gIC8vICAgICBzZXRUcmFuc2FjdGlvbnNEYXRhKGZpbHRlcmVkVHJhbnNhY3Rpb25zKTtcclxuICAvLyAgICAgc2V0U2hvd1RyYW5zYWN0aW9uRHJhd2VyKHRydWUpO1xyXG4gIC8vICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAvLyAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCB0cmFuc2FjdGlvbnM6XCIsIGVycm9yKTtcclxuICAvLyAgICAgbWVzc2FnZS5lcnJvcihcIkNvdWxkIG5vdCBsb2FkIHRyYW5zYWN0aW9uIGhpc3RvcnlcIik7XHJcbiAgLy8gICB9IGZpbmFsbHkge1xyXG4gIC8vICAgICBzZXRUcmFuc2FjdGlvbnNMb2FkaW5nKGZhbHNlKTtcclxuICAvLyAgIH1cclxuICAvLyB9O1xyXG4gIGNvbnN0IGZldGNoQXBwcm92ZWRMb2FucyA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgIGNvbnN0IFthY2NvdW50c1Jlc3BvbnNlLCB0cmFuc2FjdGlvbnNSZXNwb25zZV0gPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgYXBpLmdldChcIi92MS9hZG1pbi91c2VyLWFjY291bnRzL1wiKSxcclxuICAgICAgICBhcGkuZ2V0KFwiL3YxL2FkbWluL3RyYW5zYWN0aW9uLWhpc3RvcnkvXCIpLFxyXG4gICAgICBdKTtcclxuXHJcbiAgICAgIGNvbnN0IGFjY291bnRzID0gYWNjb3VudHNSZXNwb25zZT8uZGF0YT8uZGF0YSB8fCBbXTtcclxuXHJcbiAgICAgIGNvbnN0IHRyYW5zYWN0aW9ucyA9XHJcbiAgICAgICAgdHJhbnNhY3Rpb25zUmVzcG9uc2U/LmRhdGE/LmRhdGEgfHxcclxuICAgICAgICB0cmFuc2FjdGlvbnNSZXNwb25zZT8uZGF0YSB8fFxyXG4gICAgICAgIFtdO1xyXG5cclxuICAgICAgLy8gR2V0IGFsbCB1c2VycyB3aG8gaGF2ZSBQaWdteSBXaXRoZHJhd2FsIHRyYW5zYWN0aW9uc1xyXG4gICAgICBjb25zdCBwaWdteVdpdGhkcmF3YWxVc2VySWRzID0gbmV3IFNldCgpO1xyXG5cclxuICAgICAgdHJhbnNhY3Rpb25zLmZvckVhY2goKHR4bikgPT4ge1xyXG4gICAgICAgIGNvbnN0IHJlYXNvbiA9IHR4bj8ucmVhc29uPy50cmltKCk/LnRvTG93ZXJDYXNlKCk7XHJcblxyXG4gICAgICAgIGlmIChyZWFzb24gIT09IFwicGlnbXkgd2l0aGRyYXdhbFwiKSB7XHJcbiAgICAgICAgICAvLyBOb3JtYWwgY2hpdCB0cmFuc2FjdGlvbiB1c2VyXHJcbiAgICAgICAgICBjb25zdCBlbnJvbGxVc2VySWQgPSB0eG4/LmVucm9sbF9pZD8udXNlcl9pZD8uX2lkO1xyXG5cclxuICAgICAgICAgIGlmIChlbnJvbGxVc2VySWQpIHtcclxuICAgICAgICAgICAgcGlnbXlXaXRoZHJhd2FsVXNlcklkcy5hZGQoZW5yb2xsVXNlcklkKTtcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAvLyBQaWdteSB0cmFuc2FjdGlvbiB1c2VyXHJcbiAgICAgICAgICBjb25zdCBwaWdteVVzZXJJZCA9IHR4bj8ucGlnbWVfaWQ/LmN1c3RvbWVyPy5faWQ7XHJcblxyXG4gICAgICAgICAgaWYgKHBpZ215VXNlcklkKSB7XHJcbiAgICAgICAgICAgIHBpZ215V2l0aGRyYXdhbFVzZXJJZHMuYWRkKHBpZ215VXNlcklkKTtcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAvLyBTb21lIEFQSXMgbWF5IGRpcmVjdGx5IHByb3ZpZGUgdXNlcl9pZFxyXG4gICAgICAgICAgY29uc3QgZGlyZWN0VXNlcklkID0gdHhuPy51c2VyX2lkPy5faWQgfHwgdHhuPy51c2VyX2lkO1xyXG5cclxuICAgICAgICAgIGlmIChkaXJlY3RVc2VySWQpIHtcclxuICAgICAgICAgICAgcGlnbXlXaXRoZHJhd2FsVXNlcklkcy5hZGQoZGlyZWN0VXNlcklkKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgICAvLyBSZW1vdmUgUGlnbXkgV2l0aGRyYXdhbCB1c2Vyc1xyXG4gICAgICBjb25zdCBmaWx0ZXJlZEFjY291bnRzID0gYWNjb3VudHMuZmlsdGVyKChhY2NvdW50KSA9PiB7XHJcbiAgICAgICAgY29uc3QgYWNjb3VudFVzZXJJZCA9IGFjY291bnQ/LnVzZXJEZXRhaWxzPy5faWQ7XHJcblxyXG4gICAgICAgIHJldHVybiAhcGlnbXlXaXRoZHJhd2FsVXNlcklkcy5oYXMoYWNjb3VudFVzZXJJZCk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc2V0UmF3TG9hbnMoZmlsdGVyZWRBY2NvdW50cyk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIGFjY291bnRzOlwiLCBlcnJvcik7XHJcbiAgICAgIHNob3dBbGVydChcIkZhaWxlZCB0byBmZXRjaCBjYW5jZWxsZWQgY2hpdHNcIiwgXCJlcnJvclwiKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hBcHByb3ZlZExvYW5zKCk7XHJcbiAgfSwgW2ZldGNoQXBwcm92ZWRMb2FucywgcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdXNlciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGNvbnN0IHVzZXJPYmogPSBKU09OLnBhcnNlKHVzZXIpO1xyXG4gICAgY29uc3QgdXNlckFkbWluSWQgPSB1c2VyT2JqPy5faWQ7XHJcbiAgICBzZXRBZG1pbklkKHVzZXJBZG1pbklkKTtcclxuICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KHVzZXJPYmopLCBcInRoaXMgaXMgdXNlck9iamVcIik7XHJcblxyXG4gICAgaWYgKHVzZXJPYmopIHtcclxuICAgICAgY29uc3QgYWRtaW5BY2Nlc3NQZXJtaXNzaW9ucyA9XHJcbiAgICAgICAgdXNlck9iai5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQ/LmFjY2Vzc19wZXJtaXNzaW9ucztcclxuXHJcbiAgICAgIGlmIChhZG1pbkFjY2Vzc1Blcm1pc3Npb25zPy5lZGl0X3BheW1lbnQgPT09IFwidHJ1ZVwiKSB7XHJcbiAgICAgICAgc2V0TW9kaWZ5UGF5bWVudCh0cnVlKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKGFkbWluQWNjZXNzUGVybWlzc2lvbnM/LmVkaXRfbGltaXRlZF9wYXltZW50ID09PSBcInRydWVcIikge1xyXG4gICAgICAgIHNldE1vZGlmeVBheW1lbnQodHJ1ZSk7XHJcbiAgICAgICAgc2V0TW9kaWZ5TWluTWF4UGF5bWVudERhdGUodHJ1ZSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IHNob3dBbGVydCA9IChtZXNzYWdlLCB0eXBlID0gXCJpbmZvXCIpID0+IHtcclxuICAgIHNldEFsZXJ0Q29uZmlnKHsgdmlzaWJpbGl0eTogdHJ1ZSwgbWVzc2FnZSwgdHlwZSB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCByZXNldEZvcm0gPSAoKSA9PiB7XHJcbiAgICBzZXRQYXltZW50Rm9ybURhdGEoSU5JVElBTF9QQVlNRU5UX1NUQVRFKTtcclxuICAgIHNldFBheW1lbnRFcnJvcnMoe30pO1xyXG4gICAgc2V0U2hvd1BheW1lbnRNb2RhbChmYWxzZSk7XHJcbiAgICBzZXRDdXJyZW50Qm9ycm93ZXIobnVsbCk7XHJcbiAgfTtcclxuXHJcbiAgLy8gTmV3IGZ1bmN0aW9uIHRvIG9wZW4gdHJhbnNmZXIgbW9kYWxcclxuICBjb25zdCBoYW5kbGVUcmFuc2Zlck1vZGFsT3BlbiA9ICh1c2VySWQpID0+IHtcclxuICAgIHNldFRyYW5zZmVyVXNlcklkKHVzZXJJZCk7XHJcbiAgICBzZXRTaG93VHJhbnNmZXJNb2RhbCh0cnVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBidWlsZE5vdGVTdHJpbmcgPSAoZmQpID0+IHtcclxuICAgIGNvbnN0IHBhcnRzID0gW107XHJcbiAgICBpZiAoZmQubm90ZT8udHJpbSgpKSBwYXJ0cy5wdXNoKGZkLm5vdGUudHJpbSgpKTtcclxuICAgIGlmIChmZC5wYXltZW50X21vZGUgPT09IFwiQmFuayBUcmFuc2ZlclwiKSB7XHJcbiAgICAgIGlmIChmZC50cmFuc2FjdGlvbl9pZCkgcGFydHMucHVzaChgVHhuOiAke2ZkLnRyYW5zYWN0aW9uX2lkfWApO1xyXG4gICAgICBpZiAoZmQuYmFua19uYW1lKSBwYXJ0cy5wdXNoKGBCYW5rOiAke2ZkLmJhbmtfbmFtZX1gKTtcclxuICAgIH1cclxuICAgIGlmIChmZC5wYXltZW50X21vZGUgPT09IFwiQ2hlcXVlXCIgJiYgZmQuY2hlcXVlX251bWJlcikge1xyXG4gICAgICBwYXJ0cy5wdXNoKGBDaHE6ICR7ZmQuY2hlcXVlX251bWJlcn1gKTtcclxuICAgIH0gZWxzZSBpZiAoZmQucGF5bWVudF9tb2RlID09PSBcIk9ubGluZVwiICYmIGZkLnRyYW5zYWN0aW9uX2lkKSB7XHJcbiAgICAgIHBhcnRzLnB1c2goYFR4bjogJHtmZC50cmFuc2FjdGlvbl9pZH1gKTtcclxuICAgIH1cclxuICAgIHJldHVybiBwYXJ0cy5qb2luKFwiIHwgXCIpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVBheW1lbnRPdXRNb2RhbE9wZW4gPSBhc3luYyAodXNlcklkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYHYxL2FkbWluL2xvYW5zLyR7dXNlcklkfWApO1xyXG4gICAgICBjb25zdCBkYXRhID0gcmVzcG9uc2UuZGF0YT8uZGF0YTtcclxuICAgICAgc2V0Q3VycmVudEJvcnJvd2VyKGRhdGEgfHwge30pO1xyXG4gICAgICBzZXRDdXN0b21lcklkKHVzZXJJZCk7XHJcbiAgICAgIC8vIHNldFBheW1lbnRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgLy8gICAuLi5wcmV2LFxyXG4gICAgICAvLyAgIHBheW1lbnRfYW1vdW50OlxyXG4gICAgICAvLyAgICAgTnVtYmVyKGRhdGE/LmxvYW5fYW1vdW50IHx8IDApIC1cclxuICAgICAgLy8gICAgIE51bWJlcihkYXRhLnNlcnZpY2VfY2hhcmdlcyB8fCAwKSAtXHJcbiAgICAgIC8vICAgICBOdW1iZXIoZGF0YS5kb2N1bWVudF9jaGFyZ2VzIHx8IDApIHx8IDAsXHJcbiAgICAgIC8vICAgc2VydmljZV9jaGFyZ2VzOiBkYXRhLnNlcnZpY2VfY2hhcmdlcyB8fCBcIlwiLFxyXG4gICAgICAvLyAgIGRvY3VtZW50X2NoYXJnZXM6IGRhdGEuZG9jdW1lbnRfY2hhcmdlcyB8fCBcIlwiLFxyXG4gICAgICAvLyAgIGRhaWx5X3BheW1lbnRfYW1vdW50OiBkYXRhLmRhaWx5X3BheW1lbnRfYW1vdW50IHx8IFwiXCIsXHJcbiAgICAgIC8vICAgc3RhcnRfZGF0ZTogZGF0YS5zdGFydF9kYXRlLFxyXG4gICAgICAvLyAgIGVuZF9kYXRlOiBkYXRhLmVuZF9kYXRlLFxyXG4gICAgICAvLyAgIGxvYW5faWQ6IGRhdGEubG9hbl9pZCxcclxuXHJcbiAgICAgIC8vICAgcGF5bWVudF9kYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICAvLyB9KSk7XHJcbiAgICAgIHNldFNob3dQYXltZW50TW9kYWwodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzaG93QWxlcnQoXCJGYWlsZWQgdG8gZmV0Y2ggYm9ycm93ZXIgZGV0YWlsc1wiLCBcImVycm9yXCIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHZhbGlkYXRlID0gKCkgPT4ge1xyXG4gICAgY29uc3QgZXJyb3JzID0ge307XHJcbiAgICBpZiAoIXBheW1lbnRGb3JtRGF0YS5wYXltZW50X2Ftb3VudCB8fCBwYXltZW50Rm9ybURhdGEucGF5bWVudF9hbW91bnQgPD0gMClcclxuICAgICAgZXJyb3JzLnBheW1lbnRfYW1vdW50ID0gXCJSZXF1aXJlZFwiO1xyXG4gICAgaWYgKCFwYXltZW50Rm9ybURhdGEucGF5bWVudF9kYXRlKSBlcnJvcnMucGF5bWVudF9kYXRlID0gXCJSZXF1aXJlZFwiO1xyXG4gICAgaWYgKCFwYXltZW50Rm9ybURhdGEucGF5bWVudF9tb2RlKSBlcnJvcnMucGF5bWVudF9tb2RlID0gXCJSZXF1aXJlZFwiO1xyXG5cclxuICAgIGlmIChcclxuICAgICAgcGF5bWVudEZvcm1EYXRhLnBheW1lbnRfbW9kZSA9PT0gXCJCYW5rIFRyYW5zZmVyXCIgJiZcclxuICAgICAgIXBheW1lbnRGb3JtRGF0YS50cmFuc2FjdGlvbl9pZFxyXG4gICAgKVxyXG4gICAgICBlcnJvcnMudHJhbnNhY3Rpb25faWQgPSBcIlRyYW5zYWN0aW9uIElEIHJlcXVpcmVkXCI7XHJcbiAgICBpZiAoXHJcbiAgICAgIHBheW1lbnRGb3JtRGF0YS5wYXltZW50X21vZGUgPT09IFwiQ2hlcXVlXCIgJiZcclxuICAgICAgIXBheW1lbnRGb3JtRGF0YS5jaGVxdWVfbnVtYmVyXHJcbiAgICApXHJcbiAgICAgIGVycm9ycy5jaGVxdWVfbnVtYmVyID0gXCJDaGVxdWUgbnVtYmVyIHJlcXVpcmVkXCI7XHJcblxyXG4gICAgaWYgKHBheW1lbnRFcnJvcnMucGF5X2RhdGUgPT09IFwiT25saW5lXCIgJiYgIXBheW1lbnRGb3JtRGF0YS50cmFuc2FjdGlvbl9pZClcclxuICAgICAgZXJyb3JzLnRyYW5zYWN0aW9uX2lkID0gXCJUcmFuc2FjdGlvbiBJRCByZXF1aXJlZFwiO1xyXG5cclxuICAgIHNldFBheW1lbnRFcnJvcnMoZXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhlcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQYXltZW50T3V0U3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGlmICghdmFsaWRhdGUoKSkgcmV0dXJuO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgbG9hbjogY3VycmVudEJvcnJvd2VyPy5faWQgfHwgY3VycmVudEJvcnJvd2VyPy5faWQsXHJcbiAgICAgICAgdXNlcl9pZDogY3VycmVudEJvcnJvd2VyPy5ib3Jyb3dlcj8uX2lkIHx8IGN1cnJlbnRCb3Jyb3dlcj8udXNlcl9pZCxcclxuICAgICAgICBwYXlfZGF0ZTogcGF5bWVudEZvcm1EYXRhLnBheW1lbnRfZGF0ZSxcclxuICAgICAgICBhbW91bnQ6IHBheW1lbnRGb3JtRGF0YS5wYXltZW50X2Ftb3VudC50b1N0cmluZygpLFxyXG4gICAgICAgIHBheV90eXBlOiBwYXltZW50Rm9ybURhdGEucGF5bWVudF9tb2RlLFxyXG4gICAgICAgIHBheV9mb3I6IFwiTG9hblwiLFxyXG4gICAgICAgIG5vdGU6IHBheW1lbnRGb3JtRGF0YS5ub3RlLFxyXG4gICAgICAgIHRyYW5zYWN0aW9uX2lkOiBwYXltZW50Rm9ybURhdGEudHJhbnNhY3Rpb25faWQsXHJcbiAgICAgICAgYWRtaW5fdHlwZTogYWRtaW5JZCxcclxuICAgICAgICAuLi50aGlyZFBhcnR5RW5hYmxlLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgYXdhaXQgYXBpLnBhdGNoKFwiL3YxL2FkbWluL2xvYW5zL2NvbXBsZXRlZFwiLCBwYXlsb2FkKTtcclxuICAgICAgc2hvd0FsZXJ0KFwiUGF5bWVudCBwcm9jZXNzZWQgc3VjY2Vzc2Z1bGx5XCIsIFwic3VjY2Vzc1wiKTtcclxuICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocCkgPT4gcCArIDEpO1xyXG4gICAgICByZXNldEZvcm0oKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNob3dBbGVydChcclxuICAgICAgICBlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fFxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlPy5kYXRhPy5zdGF0dXNDb2RlIHx8XHJcbiAgICAgICAgXCJUcmFuc2FjdGlvbiBmYWlsZWRcIixcclxuICAgICAgICBcImVycm9yXCIsXHJcbiAgICAgICk7XHJcbiAgICB9XHJcbiAgfTtcclxuICBjb25zdCB1cGRhdGVMb2FuU3RhdHVzID0gYXN5bmMgKGxvYW4sIG5ld1N0YXR1cykgPT4ge1xyXG4gICAgc2hvd0NvbmZpcm0oe1xyXG4gICAgICB0aXRsZTogYCR7bmV3U3RhdHVzfSBMb2FuIFJlcXVlc3RgLFxyXG4gICAgICBjb250ZW50OiBgQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGNoYW5nZSB0aGUgc3RhdHVzIG9mIHRoaXMgbG9hbiB0byAke25ld1N0YXR1c30/YCxcclxuICAgICAgb25Db25maXJtOiBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGFwaS5wYXRjaChcIi92MS9hZG1pbi9sb2Fucy9hcHByb3ZhbC1zdGF0dXNcIiwge1xyXG4gICAgICAgICAgICBpZDogbG9hbi5faWQsXHJcbiAgICAgICAgICAgIGFwcHJvdmFsX3N0YXR1czogbmV3U3RhdHVzLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBtZXNzYWdlLnN1Y2Nlc3MoYExvYW4gc3RhdHVzIHVwZGF0ZWQgdG8gJHtuZXdTdGF0dXN9IHN1Y2Nlc3NmdWxseWApO1xyXG4gICAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgbG9hbiBzdGF0dXM6XCIsIGVycm9yKTtcclxuICAgICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gdXBkYXRlIGxvYW4gc3RhdHVzXCIpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHRhYmxlRGF0YSA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3Qgc3RhdHVzT3B0aW9ucyA9IFtcclxuICAgICAge1xyXG4gICAgICAgIGxhYmVsOiBcIkFjY2VwdFwiLFxyXG4gICAgICAgIHZhbHVlOiBcIkFDQ0VQVEVEXCIsXHJcbiAgICAgICAgaWNvbjogPENoZWNrQ2lyY2xlT3V0bGluZWQgLz4sXHJcbiAgICAgICAgY2xhc3NOYW1lOiBcImJnLWdyZWVuLTcwMCB0ZXh0LXdoaXRlIGhvdmVyOmJnLWdyZWVuLTgwMFwiLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgbGFiZWw6IFwiUGVuZGluZ1wiLFxyXG4gICAgICAgIHZhbHVlOiBcIlBFTkRJTkdcIixcclxuICAgICAgICBpY29uOiA8Q2xvY2tDaXJjbGVPdXRsaW5lZCAvPixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYm9yZGVyLXllbGxvdy00MDAgdGV4dC15ZWxsb3ctNjAwIGhvdmVyOmJnLXllbGxvdy01MFwiLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgbGFiZWw6IFwiUmVqZWN0XCIsXHJcbiAgICAgICAgdmFsdWU6IFwiUkVKRUNURURcIixcclxuICAgICAgICBpY29uOiA8Q2xvc2VDaXJjbGVPdXRsaW5lZCAvPixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYm9yZGVyLXJlZC00MDAgdGV4dC1yZWQtNjAwIGhvdmVyOmJnLXJlZC01MFwiLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgbGFiZWw6IFwiVW5rbm93blwiLFxyXG4gICAgICAgIHZhbHVlOiBcIlVOS05PV05cIixcclxuICAgICAgICBpY29uOiA8UXVlc3Rpb25DaXJjbGVPdXRsaW5lZCAvPixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYm9yZGVyLXllbGxvdy00MDAgdGV4dC15ZWxsb3ctNjAwIGhvdmVyOmJnLXllbGxvdy01MFwiLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgbGFiZWw6IFwiUmVxdWVzdGVkXCIsXHJcbiAgICAgICAgdmFsdWU6IFwiUkVRVUVTVEVEXCIsXHJcbiAgICAgICAgaWNvbjogPEV4Y2xhbWF0aW9uQ2lyY2xlT3V0bGluZWQgLz4sXHJcbiAgICAgICAgY2xhc3NOYW1lOiBcImJvcmRlci1ibHVlLTQwMCB0ZXh0LWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTBcIixcclxuICAgICAgfSxcclxuICAgIF07XHJcbiAgICBjb25zdCBwb3BvdmVyQ29udGVudCA9IChib3Jyb3dlcikgPT4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNDAgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctbWQgcC0yIHNwYWNlLXktMlwiPlxyXG4gICAgICAgIHtzdGF0dXNPcHRpb25zLm1hcCgob3B0KSA9PiAoXHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIGtleT17b3B0LnZhbHVlfVxyXG4gICAgICAgICAgICBpY29uPXtvcHQuaWNvbn1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1zdGFydCB3LWZ1bGwgJHtvcHQuY2xhc3NOYW1lfWB9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZUxvYW5TdGF0dXMoYm9ycm93ZXIsIG9wdC52YWx1ZSl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtvcHQubGFiZWx9XHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICApKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG5cclxuICAgIGNvbnN0IGZvcm1hdHRlZCA9IHJhd0xvYW5zPy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoe1xyXG4gICAgICAuLi5pdGVtLFxyXG4gICAgICBzbF9ubzogaW5kZXggKyAxLFxyXG4gICAgICBpZDogYCNQQyR7U3RyaW5nKGluZGV4ICsgMSkucGFkU3RhcnQoMywgXCIwXCIpfWAsXHJcbiAgICAgIGZ1bGxfbmFtZTogaXRlbT8udXNlckRldGFpbHM/LmZ1bGxfbmFtZSxcclxuICAgICAgY3VzdG9tZXJfaWQ6IGl0ZW0/LnVzZXJEZXRhaWxzPy5jdXN0b21lcl9pZCB8fCAwLFxyXG4gICAgICBwaG9uZV9udW1iZXI6IE51bWJlcihpdGVtPy51c2VyRGV0YWlscz8ucGhvbmVfbnVtYmVyIHx8IDApLFxyXG4gICAgICBiYWxhbmNlOiBOdW1iZXIoaXRlbT8uYmFsYW5jZSB8fCAwKSxcclxuICAgICAgYXBwcm92YWxfc3RhdHVzOiBpdGVtLmFwcHJvdmFsX3N0YXR1cyB8fCBcIkFQUFJPVkVEXCIsXHJcbiAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICBpdGVtczogaXNDaGl0VHJhbnNmZXJQYXlJblxyXG4gICAgICAgICAgICAgID8gW1xyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgICAgICAgICAgICBsYWJlbDogXCJUcmFuc2ZlclwiLFxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrOiAoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZVRyYW5zZmVyTW9kYWxPcGVuKGl0ZW0udXNlckRldGFpbHM/Ll9pZCksXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgICAgICAgICAgICBsYWJlbDogXCJQYXltZW50IE91dFwiLFxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrOiAoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZVBheW1lbnRPdXRNb2RhbE9wZW4oaXRlbS51c2VyRGV0YWlscz8uX2lkKSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgIDogW1xyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgICAgICAgICAgICBsYWJlbDogXCJQYXltZW50IE91dFwiLFxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrOiAoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZVBheW1lbnRPdXRNb2RhbE9wZW4oaXRlbS51c2VyRGV0YWlscz8uX2lkKSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgIGtleTogXCIyXCIsXHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsOiBcIlRyYW5zZmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s6ICgpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlVHJhbnNmZXJNb2RhbE9wZW4oaXRlbS51c2VyRGV0YWlscz8uX2lkKSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC14bCBjdXJzb3ItcG9pbnRlciBob3Zlcjp0ZXh0LWJsdWUtNjAwIHRyYW5zaXRpb24tY29sb3JzXCIgLz5cclxuICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICApLFxyXG4gICAgICAvLyB2aWV3X3RyYW5zYWN0aW9uczogKFxyXG4gICAgICAvLyAgIDxidXR0b25cclxuICAgICAgLy8gICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVZpZXdUcmFuc2FjdGlvbnMoaXRlbS51c2VyRGV0YWlscz8uX2lkKX1cclxuICAgICAgLy8gICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgaG92ZXI6dGV4dC1ibHVlLTgwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgLy8gICA+XHJcbiAgICAgIC8vICAgICA8RmlFeWUgc2l6ZT17MTR9IC8+XHJcbiAgICAgIC8vICAgICBWaWV3XHJcbiAgICAgIC8vICAgPC9idXR0b24+XHJcbiAgICAgIC8vICksXHJcbiAgICB9KSk7XHJcbiAgICByZXR1cm4gZmlsdGVyT3B0aW9uKGZvcm1hdHRlZCwgc2VhcmNoVGV4dCk7XHJcbiAgfSwgW3Jhd0xvYW5zLCBzZWFyY2hUZXh0XSk7XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJzbF9ub1wiLCBoZWFkZXI6IFwiU0xcIiB9LFxyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIklEXCIgfSxcclxuICAgIHsga2V5OiBcImZ1bGxfbmFtZVwiLCBoZWFkZXI6IFwiRnVsbCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImN1c3RvbWVyX2lkXCIsIGhlYWRlcjogXCJDdXN0b21lciBJRFwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJiYWxhbmNlXCIsIGhlYWRlcjogXCJCYWxhbmNlXCIgfSxcclxuICAgIHsga2V5OiBcImFwcHJvdmFsX3N0YXR1c1wiLCBoZWFkZXI6IFwiQXBwcm92YWwgU3RhdHVzXCIgfSxcclxuICAgIC8vIHsga2V5OiBcInZpZXdfdHJhbnNhY3Rpb25zXCIsIGhlYWRlcjogXCJUcmFuc2FjdGlvbnNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGNvbW1vbklucHV0Q2xhc3MgPSBgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWA7XHJcbiAgY29uc3QgdG90YWxQYXlhYmxlU3VtID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICByZXR1cm4gdGFibGVEYXRhLnJlZHVjZShcclxuICAgICAgKHN1bSwgaXRlbSkgPT4gc3VtICsgKE51bWJlcihpdGVtLmJhbGFuY2UpIHx8IDApLFxyXG4gICAgICAwLFxyXG4gICAgKTtcclxuICB9LCBbdGFibGVEYXRhXSk7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLWdyYXktNTBcIj5cclxuICAgICAgPE5hdmJhclxyXG4gICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbiAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXsoZSkgPT4gc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgIC8+XHJcbiAgICAgIDxDdXN0b21BbGVydERpYWxvZ1xyXG4gICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0QWxlcnRDb25maWcoKHApID0+ICh7IC4uLnAsIHZpc2liaWxpdHk6IGZhbHNlIH0pKX1cclxuICAgICAgLz5cclxuXHJcbiAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj4gKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtpc1Nob3dTaWRlYmFyID8gXCJmbGV4IG10LTBcIiA6IFwiZmxleCBtdC0yMFwifT5cclxuICAgICAgICB7IWlzU2hvd1NpZGViYXIgJiYgPFNpZGViYXIgLz59XHJcbiAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtM1wiPlxyXG4gICAgICAgICAgeyFpc1Nob3dTaWRlYmFyICYmIDxCcmVhZGNydW1iIC8+fVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1lbmQgbWItMlwiPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAge2lzQ2hpdFRyYW5zZmVyUGF5SW5cclxuICAgICAgICAgICAgICAgICAgPyBcIkNoaXQgVHJhbnNmZXIgUGF5bWVudHMgSW5cIlxyXG4gICAgICAgICAgICAgICAgICA6IFwiIFBpZ215IFBheW1lbnQgb3V0XCJ9XHJcbiAgICAgICAgICAgICAgPC9oMT5cclxuXHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICB7aXNDaGl0VHJhbnNmZXJQYXlJblxyXG4gICAgICAgICAgICAgICAgICA/IFwiUHJvY2VzcyBpbmNvbWluZyBwYXltZW50cyBmb3IgY2hpdCB0cmFuc2ZlciB0cmFuc2FjdGlvbnMuXCJcclxuICAgICAgICAgICAgICAgICAgOiBcIlByb2Nlc3MgcGF5bWVudCBmb3IgUGlnbXkgcGF5b3V0cy5cIn1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgaXRlbXMtY2VudGVyIG1iLTMgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgdG89XCIvb3RoZXItdHJhbnNhY3Rpb25zXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIiBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtNSBweS0yLjUgIGJvcmRlciBib3JkZXItYmx1ZS01MDAgdGV4dC1ibHVlLTYwMCAgcm91bmRlZC14bCBiZy13aGl0ZSBob3ZlcjpiZy1ibHVlLTUwIGhvdmVyOnRleHQtYmx1ZS03MDAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaG92ZXI6Ym9yZGVyLWJsdWUtNjAwICB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgIGZvbnQtc2VtaWJvbGQgc2hhZG93LXNtIG10LTEgXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBPdGhlciBUcmFuc2FjdGlvbnNcclxuICAgICAgICAgICAgICA8L0xpbms+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNTAgdG8tZW1lcmFsZC01MCBib3JkZXIgYm9yZGVyLWJsdWUtMzAwIHJvdW5kZWQteGwgcHgtNSBweS0zIHNoYWRvdy1zbSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNlwiPlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBQZW5kaW5nIFBheW1lbnRzICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTIuNSBoLTIuNSByb3VuZGVkLWZ1bGwgYmctb3JhbmdlLTUwMFwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ibHVlLTkwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFBlbmRpbmcgUGF5bWVudHM6XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ibHVlLTkwMCBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dGFibGVEYXRhLmxlbmd0aH1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIERpdmlkZXIgKi99XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoLTUgdy1weCBiZy1ibHVlLTMwMFwiPjwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogVG90YWwgUGF5YWJsZSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yLjUgaC0yLjUgcm91bmRlZC1mdWxsIGJnLWJsdWUtNjAwXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtOTAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVG90YWwgUGF5YWJsZTpcclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtOTAwIGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIOKCuXt0b3RhbFBheWFibGVTdW0udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBwLTRcIj5cclxuICAgICAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXt0cnVlfSAvPlxyXG4gICAgICAgICAgICApIDogdGFibGVEYXRhLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTIwIHRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAgICAgIE5vIHBlbmRpbmcgcGF5bWVudHMgZm91bmQuXHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgZGF0YT17dGFibGVEYXRhfVxyXG4gICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJMb2FuX1BheW1lbnRzXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9tYWluPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxEcmF3ZXJcclxuICAgICAgICB0aXRsZT1cIlRyYW5zYWN0aW9uIEhpc3RvcnlcIlxyXG4gICAgICAgIHBsYWNlbWVudD1cInJpZ2h0XCJcclxuICAgICAgICBvcGVuPXtzaG93VHJhbnNhY3Rpb25EcmF3ZXJ9XHJcbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd1RyYW5zYWN0aW9uRHJhd2VyKGZhbHNlKX1cclxuICAgICAgICB3aWR0aD17ODAwfVxyXG4gICAgICAgIGxvYWRpbmc9e3RyYW5zYWN0aW9uc0xvYWRpbmd9XHJcbiAgICAgICAgY2xhc3NOYW1lPVwidHJhbnNhY3Rpb24tZHJhd2VyXCJcclxuICAgICAgPlxyXG4gICAgICAgIHshQXJyYXkuaXNBcnJheSh0cmFuc2FjdGlvbnNEYXRhKSB8fCB0cmFuc2FjdGlvbnNEYXRhLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgdGV4dC1ncmF5LTUwMCBweS04XCI+Tm8gdHJhbnNhY3Rpb25zIGZvdW5kPC9kaXY+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgIHt0cmFuc2FjdGlvbnNEYXRhLm1hcCgodHhuKSA9PiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e3R4bi5faWR9IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMiB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+PHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPlRyYW5zYWN0aW9uIElEOjwvc3Bhbj4ge3R4bi50cmFuc2FjdGlvbl9pZCB8fCBcIuKAlFwifTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PjxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5EYXRlOjwvc3Bhbj4ge25ldyBEYXRlKHR4bi50cmFuc2FjdGlvbl9kYXRlKS50b0xvY2FsZVN0cmluZygpfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PjxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5BbW91bnQ6PC9zcGFuPiDigrl7TnVtYmVyKHR4bi5hbW91bnQpLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+PHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPlR5cGU6PC9zcGFuPiB7dHhuLnRyYW5zYWN0aW9uX3R5cGV9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMlwiPjxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5SZWFzb246PC9zcGFuPiB7dHhuLnJlYXNvbn08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAge3R4bi5lbnJvbGxfaWQ/Lmdyb3VwX2lkICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5Hcm91cDo8L3NwYW4+IHt0eG4uZW5yb2xsX2lkLmdyb3VwX2lkLmdyb3VwX25hbWV9ICZuYnNwO3wmbmJzcDtcclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5UaWNrZXQ6PC9zcGFuPiB7dHhuLmVucm9sbF9pZC50aWNrZXRzfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICB7dHhuLnBpZ21lX2lkICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5QaWdteTo8L3NwYW4+IHt0eG4ucGlnbWVfaWQucGlnbWVfaWR9ICZuYnNwO3wmbmJzcDtcclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5DdXN0b21lcjo8L3NwYW4+IHt0eG4ucGlnbWVfaWQuY3VzdG9tZXI/LmZ1bGxfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAge3R4bi5hZG1pbl9pZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+UHJvY2Vzc2VkIGJ5Ojwvc3Bhbj4ge3R4bi5hZG1pbl9pZC5uYW1lfSAoe3R4bi5hZG1pbl9pZC5hZG1pbl9uYW1lfSlcclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvRHJhd2VyPlxyXG4gICAgICB7LyogXHJcbiAgICAgIDxNb2RhbCBpc1Zpc2libGU9e3Nob3dQYXltZW50TW9kYWx9IG9uQ2xvc2U9e3Jlc2V0Rm9ybX0+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTZcIj5cclxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCBtYi00IGJvcmRlci1iIHBiLTJcIj5cclxuICAgICAgICAgICAgQ29uZmlybSBEaXNidXJzZW1lbnRcclxuICAgICAgICAgIDwvaDM+XHJcblxyXG4gICAgICAgICAge2N1cnJlbnRCb3Jyb3dlciAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtNCBtYi02IGJnLWdyYXktNTAgcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1kYXNoZWRcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRleHQtZ3JheS01MDAgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgIEJvcnJvd2VyXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAge2N1cnJlbnRCb3Jyb3dlcj8uYm9ycm93ZXI/LmZ1bGxfbmFtZX1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRleHQtZ3JheS01MDAgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgIExvYW4gQW1vdW50XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICDigrl7Y3VycmVudEJvcnJvd2VyPy5sb2FuX2Ftb3VudH1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVQYXltZW50T3V0U3VibWl0fSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBTZXJ2aWNlcyBDaGFyZ2VzXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3BheW1lbnRGb3JtRGF0YS5zZXJ2aWNlX2NoYXJnZXMgfHwgMH1cclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHtjb21tb25JbnB1dENsYXNzfSBkaXNhYmxlZDp0ZXh0LWdyYXktOTAwIGRpc2FibGVkOmJnLWdyYXktMTAwYH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBEb2N1bWVudGF0aW9uIENoYXJnZXNcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17cGF5bWVudEZvcm1EYXRhLmRvY3VtZW50X2NoYXJnZXMgfHwgMH1cclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHtjb21tb25JbnB1dENsYXNzfSBkaXNhYmxlZDp0ZXh0LWdyYXktOTAwIGRpc2FibGVkOmJnLWdyYXktMTAwYH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBBbW91bnRcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXltZW50Rm9ybURhdGE/LnBheW1lbnRfYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0UGF5bWVudEZvcm1EYXRhKChwKSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgLi4ucCxcclxuICAgICAgICAgICAgICAgICAgICAgIHBheW1lbnRfYW1vdW50OiBlLnRhcmdldC52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICB9KSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NvbW1vbklucHV0Q2xhc3N9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAge3BheW1lbnRFcnJvcnMucGF5bWVudF9hbW91bnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1bMTBweF1cIj5cclxuICAgICAgICAgICAgICAgICAgICB7cGF5bWVudEVycm9ycy5wYXltZW50X2Ftb3VudH1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIERhdGVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17cGF5bWVudEZvcm1EYXRhLnBheW1lbnRfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHNldFBheW1lbnRGb3JtRGF0YSgocCkgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLnAsXHJcbiAgICAgICAgICAgICAgICAgICAgICBwYXltZW50X2RhdGU6IGUudGFyZ2V0LnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y29tbW9uSW5wdXRDbGFzc31cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgIFBheW1lbnQgTW9kZVxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG10LTFcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgTW9kZVwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17cGF5bWVudEZvcm1EYXRhLnBheW1lbnRfbW9kZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodikgPT5cclxuICAgICAgICAgICAgICAgICAgc2V0UGF5bWVudEZvcm1EYXRhKChwKSA9PiAoeyAuLi5wLCBwYXltZW50X21vZGU6IHYgfSkpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJDYXNoXCI+Q2FzaDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiQmFuayBUcmFuc2ZlclwiPlxyXG4gICAgICAgICAgICAgICAgICBCYW5rIFRyYW5zZmVyXHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIkNoZXF1ZVwiPkNoZXF1ZTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiT25saW5lXCI+T25saW5lPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIHtwYXltZW50RXJyb3JzLnBheW1lbnRfbW9kZSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1bMTBweF1cIj5cclxuICAgICAgICAgICAgICAgICAge3BheW1lbnRFcnJvcnMucGF5bWVudF9tb2RlfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAge3BheW1lbnRGb3JtRGF0YS5wYXltZW50X21vZGUgPT09IFwiQmFuayBUcmFuc2ZlclwiICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFuaW1hdGUtZmFkZUluXCI+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJUcmFuc2FjdGlvbiBJRCAqXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3BheW1lbnRGb3JtRGF0YS50cmFuc2FjdGlvbl9pZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHNldFBheW1lbnRGb3JtRGF0YSgocCkgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLnAsXHJcbiAgICAgICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvbl9pZDogZS50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHtjb21tb25JbnB1dENsYXNzfSBtYi0yYH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJCYW5rIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17cGF5bWVudEZvcm1EYXRhLmJhbmtfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHNldFBheW1lbnRGb3JtRGF0YSgocCkgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLnAsXHJcbiAgICAgICAgICAgICAgICAgICAgICBiYW5rX25hbWU6IGUudGFyZ2V0LnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y29tbW9uSW5wdXRDbGFzc31cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7cGF5bWVudEZvcm1EYXRhLnBheW1lbnRfbW9kZSA9PT0gXCJDaGVxdWVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNoZXF1ZSBOdW1iZXIgKlwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17cGF5bWVudEZvcm1EYXRhLmNoZXF1ZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgIHNldFBheW1lbnRGb3JtRGF0YSgocCkgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAuLi5wLFxyXG4gICAgICAgICAgICAgICAgICAgIGNoZXF1ZV9udW1iZXI6IGUudGFyZ2V0LnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICB9KSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y29tbW9uSW5wdXRDbGFzc31cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAge3BheW1lbnRGb3JtRGF0YS5wYXltZW50X21vZGUgPT09IFwiT25saW5lXCIgJiYgKFxyXG4gICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJUcmFuc2FjdGlvbiBJRCAqXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtwYXltZW50Rm9ybURhdGEudHJhbnNhY3Rpb25faWR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgIHNldFBheW1lbnRGb3JtRGF0YSgocCkgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAuLi5wLFxyXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zYWN0aW9uX2lkOiBlLnRhcmdldC52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NvbW1vbklucHV0Q2xhc3N9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIDxJbnB1dC5UZXh0QXJlYVxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTm90ZSAoSW50ZXJuYWwgcmVjb3JkKVwiXHJcbiAgICAgICAgICAgICAgcm93cz17Mn1cclxuICAgICAgICAgICAgICB2YWx1ZT17cGF5bWVudEZvcm1EYXRhLm5vdGV9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgc2V0UGF5bWVudEZvcm1EYXRhKChwKSA9PiAoeyAuLi5wLCBub3RlOiBlLnRhcmdldC52YWx1ZSB9KSlcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zXCI+XHJcbiAgICAgICAgICAgICAgICA8RmFXaGF0c2FwcCBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMCB3LTUgaC01XCIgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS04MDBcIj5FbmFibGUgV2hhdHNBcHAgU2VuZGluZzwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICBjaGVja2VkPXt0aGlyZFBhcnR5RW5hYmxlLndoYXRzYXBwfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgIHNldFRoaXJkUGFydHlFbmFibGUoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICB3aGF0c2FwcDogIXByZXYud2hhdHNhcHAsXHJcbiAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy01IGgtNSBhY2NlbnQtZ3JlZW4tNjAwIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMiBwdC00XCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtyZXNldEZvcm19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1zbSB0ZXh0LWdyYXktNTAwIGhvdmVyOmJnLWdyYXktMTAwIHJvdW5kZWRcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS0yIHRleHQtc20gYmctYmx1ZS02MDAgdGV4dC13aGl0ZSByb3VuZGVkIGZvbnQtYm9sZCBob3ZlcjpiZy1ibHVlLTcwMCBzaGFkb3ctbGdcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIENvbmZpcm0gRGlzYnVyc2VtZW50XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L01vZGFsPiAqL31cclxuICAgICAgPE1vZGFsXHJcbiAgICAgICAgaXNWaXNpYmxlPXtzaG93UGF5bWVudE1vZGFsfVxyXG4gICAgICAgIG9uQ2xvc2U9e3Jlc2V0Rm9ybX1cclxuICAgICAgICB3aWR0aD1cIjkwJVwiXHJcbiAgICAgICAgbWF4V2lkdGg9XCI4MDBweFwiXHJcbiAgICAgID5cclxuICAgICAgICA8Q2hpdENhbmNlbFBheW1lbnRGb3JtXHJcbiAgICAgICAgICB1c2VySWQ9e2N1c3RvbWVySWR9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIC8vIEdpdmUgYSBzbWFsbCBkZWxheSB0byBsZXQgdGhlIHBhcmVudCByZWZyZXNoIGZpbmlzaFxyXG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICByZXNldEZvcm0oKTtcclxuICAgICAgICAgICAgfSwgMzAwKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgICBvblN1Y2Nlc3M9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocCkgPT4gcCArIDEpO1xyXG4gICAgICAgICAgICByZXNldEZvcm0oKTtcclxuICAgICAgICAgICAgc2hvd0FsZXJ0KFwiQ2FuY2VsbGF0aW9uIHBheW1lbnQgc3VjY2Vzc2Z1bFwiLCBcInN1Y2Nlc3NcIik7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICA8TW9kYWxcclxuICAgICAgICBpc1Zpc2libGU9e3Nob3dUcmFuc2Zlck1vZGFsfVxyXG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dUcmFuc2Zlck1vZGFsKGZhbHNlKX1cclxuICAgICAgICB3aWR0aD1cIjkwJVwiXHJcbiAgICAgICAgbWF4V2lkdGg9XCI5MDBweFwiXHJcbiAgICAgID5cclxuICAgICAgICA8Q2hpdFRyYW5zZmVyUGF5bWVudEZvcm1cclxuICAgICAgICAgIHVzZXJJZD17dHJhbnNmZXJVc2VySWR9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTaG93VHJhbnNmZXJNb2RhbChmYWxzZSl9XHJcbiAgICAgICAgICBvblN1Y2Nlc3M9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocCkgPT4gcCArIDEpO1xyXG4gICAgICAgICAgICBzZXRTaG93VHJhbnNmZXJNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgICAgIHNob3dBbGVydChcIlRyYW5zZmVyIHByb2Nlc3NlZCBzdWNjZXNzZnVsbHlcIiwgXCJzdWNjZXNzXCIpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICAvPlxyXG4gICAgICA8L01vZGFsPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFBpZ215UGF5bWVudE91dDsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvUGlnbXlQYXltZW50T3V0LmpzeCJ9