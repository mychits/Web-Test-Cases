import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Visitor.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import API from "/src/instance/TokenInstance.js";
import { notification, Pagination } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { NavbarMenu } from "/src/data/menu.js";
import {
  Users,
  IndianRupee,
  ChevronRight,
  Zap,
  ClipboardCheck,
  Lightbulb
} from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import DataTable from "/src/components/layouts/Datatable.jsx";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
function Visitor() {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
      lineNumber: 24,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex w-screen mt-20 bg-gray-50 min-h-screen", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
        lineNumber: 28,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-6 md:p-8 overflow-y-auto", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-3xl font-extrabold text-gray-800 tracking-tight", children: "Visitor Details" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
            lineNumber: 34,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 mt-2 text-sm", children: "Overview of portal visitors and activity." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
            lineNumber: 37,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
          lineNumber: 33,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: /* @__PURE__ */ jsxDEV(Link, { to: "/visitor-list", className: "group block", children: /* @__PURE__ */ jsxDEV("div", { className: "relative h-full overflow-hidden rounded-xl bg-white border border-violet-200 shadow-md hover:shadow-lg transition-all duration-300", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-violet-600 to-violet-700 opacity-5 group-hover:opacity-10 rounded-full -mr-16 -mt-16 transition-all duration-300 blur-xl" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
            lineNumber: 50,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative p-7", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center justify-center w-14 h-14 bg-violet-50 rounded-lg mb-5 group-hover:scale-105 transition-transform duration-300", children: /* @__PURE__ */ jsxDEV(Users, { size: 28, className: "text-violet-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
              lineNumber: 56,
              columnNumber: 41
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
              lineNumber: 55,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-5", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900 mb-2 group-hover:text-gray-950 transition-colors", children: "Visitor List" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
                lineNumber: 61,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600 leading-relaxed", children: "Manage visitor records and daily logs efficiently." }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
                lineNumber: 64,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
              lineNumber: 60,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-4 border-t border-gray-100 group-hover:border-gray-200 transition-colors", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-gray-500 uppercase tracking-wide group-hover:text-gray-700 transition-colors", children: "Active Visitors" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
                lineNumber: 71,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "p-1.5 rounded-lg bg-gradient-to-br from-violet-600 to-violet-700 opacity-0 group-hover:opacity-100 transform translate-x-1 group-hover:translate-x-0 transition-all duration-300", children: /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-4 h-4 text-white" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
                lineNumber: 75,
                columnNumber: 45
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
                lineNumber: 74,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
              lineNumber: 70,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
            lineNumber: 52,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-violet-600 to-violet-700 opacity-0 group-hover:opacity-100 transition-opacity duration-300" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
            lineNumber: 81,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
          lineNumber: 47,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
          lineNumber: 46,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
          lineNumber: 43,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-16 p-8 bg-gradient-to-br from-violet-50 to-indigo-50 rounded-2xl border border-violet-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsxDEV(Zap, { className: "w-6 h-6 text-violet-600 mt-1" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
            lineNumber: 93,
            columnNumber: 33
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
            lineNumber: 92,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-slate-900 mb-2", children: "Quick Tips" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
              lineNumber: 96,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-slate-700 mb-2", children: [
              "Use the ",
              /* @__PURE__ */ jsxDEV("span", { className: "font-bold", children: "Visitor List" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
                lineNumber: 98,
                columnNumber: 45
              }, this),
              " to manage visitor information, update entry/exit times, and track visitor history all in one place."
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
              lineNumber: 97,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-slate-700", children: 'Click on the card above to view all registered visitors or add a new entry using the "+ Add Details" button inside the list.' }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
              lineNumber: 100,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
            lineNumber: 95,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
          lineNumber: 91,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
          lineNumber: 90,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
        lineNumber: 31,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
      lineNumber: 27,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx",
    lineNumber: 23,
    columnNumber: 5
  }, this);
}
_c = Visitor;
export default Visitor;
var _c;
$RefreshReg$(_c, "Visitor");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Visitor.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JRLG1CQUNJLGNBREo7QUF0QlIsT0FBT0Esb0JBQW9CQztBQUFnQixNQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNsRCxPQUFPQyxTQUFTO0FBQ2hCLFNBQVNDLGNBQWNDLGtCQUFrQjtBQUN6QyxTQUFTQyxZQUFZO0FBQ3JCLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsWUFBWTtBQUNuQixTQUFTQyxrQkFBa0I7QUFFM0I7QUFBQSxFQUNJQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNHO0FBRVAsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxnQkFBZ0I7QUFFdkIsU0FBU0MsVUFBVTtBQUNmLFNBQ0ksbUNBQ0k7QUFBQSwyQkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBTztBQUFBLElBR1AsdUJBQUMsU0FBSSxXQUFVLCtDQUNYO0FBQUEsNkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUdSLHVCQUFDLFNBQUksV0FBVSxxQ0FFWDtBQUFBLCtCQUFDLFNBQUksV0FBVSxRQUNYO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdEQUF1RCwrQkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLDhCQUE2Qix5REFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUseUNBR1gsaUNBQUMsUUFBSyxJQUFHLGlCQUFnQixXQUFVLGVBQy9CLGlDQUFDLFNBQUksV0FBVSxzSUFHWDtBQUFBLGlDQUFDLFNBQUksV0FBVSxzTEFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpTTtBQUFBLFVBRWpNLHVCQUFDLFNBQUksV0FBVSxnQkFHWDtBQUFBLG1DQUFDLFNBQUksV0FBVSwwSUFDWCxpQ0FBQyxTQUFNLE1BQU0sSUFBSSxXQUFVLHFCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QyxLQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDWDtBQUFBLHFDQUFDLFFBQUcsV0FBVSxvRkFBbUYsNEJBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSx5Q0FBd0Msa0VBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsaUhBQ1g7QUFBQSxxQ0FBQyxVQUFLLFdBQVUseUdBQXdHLCtCQUF4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsb0xBQ1gsaUNBQUMsZ0JBQWEsV0FBVSx3QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEMsS0FEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxlQXpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBCQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLDBKQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFLO0FBQUEsYUFsQ3pLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQ0EsS0FwQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFDQSxLQXhDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkNBO0FBQUEsUUFJQSx1QkFBQyxTQUFJLFdBQVUsZ0dBQ1gsaUNBQUMsU0FBSSxXQUFVLGNBQ1g7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsaUJBQ1gsaUNBQUMsT0FBSSxXQUFVLGtDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZDLEtBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQ0c7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsNkNBQTRDLDBCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRTtBQUFBLFlBQ3BFLHVCQUFDLE9BQUUsV0FBVSx1QkFBc0I7QUFBQTtBQUFBLGNBQ3ZCLHVCQUFDLFVBQUssV0FBVSxhQUFZLDRCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QztBQUFBLGNBQU87QUFBQSxpQkFEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLGtCQUFpQiw0SUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLGFBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBLEtBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsV0ExRUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZFQTtBQUFBLFNBakZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrRkE7QUFBQSxPQXRGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUZBO0FBRVI7QUFBQ0MsS0EzRlFEO0FBNkZULGVBQWVBO0FBQVEsSUFBQUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJBUEkiLCJub3RpZmljYXRpb24iLCJQYWdpbmF0aW9uIiwiTGluayIsIlNpZGViYXIiLCJOYXZiYXIiLCJOYXZiYXJNZW51IiwiVXNlcnMiLCJJbmRpYW5SdXBlZSIsIkNoZXZyb25SaWdodCIsIlphcCIsIkNsaXBib2FyZENoZWNrIiwiTGlnaHRidWxiIiwiRGF0YVRhYmxlIiwiQnJlYWRjcnVtYiIsIlZpc2l0b3IiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJWaXNpdG9yLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgQVBJIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCB7IG5vdGlmaWNhdGlvbiwgUGFnaW5hdGlvbiB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgeyBOYXZiYXJNZW51IH0gZnJvbSBcIi4uL2RhdGEvbWVudVwiO1xyXG5cclxuaW1wb3J0IHtcclxuICAgIFVzZXJzLFxyXG4gICAgSW5kaWFuUnVwZWUsXHJcbiAgICBDaGV2cm9uUmlnaHQsXHJcbiAgICBaYXAsXHJcbiAgICBDbGlwYm9hcmRDaGVjayxcclxuICAgIExpZ2h0YnVsYiwgLy8gQWRkZWQgZm9yIFF1aWNrIFRpcHNcclxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcblxyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuXHJcbmZ1bmN0aW9uIFZpc2l0b3IoKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxOYXZiYXIgLz5cclxuXHJcbiAgICAgICAgICAgIHsvKiAtLS0tLS0tLS0tLS0tLS0tIExBWU9VVCAtLS0tLS0tLS0tLS0tLS0tICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggdy1zY3JlZW4gbXQtMjAgYmctZ3JheS01MCBtaW4taC1zY3JlZW5cIj5cclxuICAgICAgICAgICAgICAgIDxTaWRlYmFyIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIE1BSU4gQ09OVEVOVCBBUkVBICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgcC02IG1kOnAtOCBvdmVyZmxvdy15LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICB7LyogSEVBREVSICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1leHRyYWJvbGQgdGV4dC1ncmF5LTgwMCB0cmFja2luZy10aWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVmlzaXRvciBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgbXQtMiB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBPdmVydmlldyBvZiBwb3J0YWwgdmlzaXRvcnMgYW5kIGFjdGl2aXR5LlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PSBDQVJEIFNFQ1RJT04gKE1hdGNoaW5nIFVzZXJNZW51IFN0eWxlKSA9PT09PT09PT09PT09PT09PSAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBWaXNpdG9yIENhcmQgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPVwiL3Zpc2l0b3ItbGlzdFwiIGNsYXNzTmFtZT1cImdyb3VwIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGgtZnVsbCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXZpb2xldC0yMDAgc2hhZG93LW1kIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQmFja2dyb3VuZCBHcmFkaWVudCBCbG9iICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCB3LTMyIGgtMzIgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS12aW9sZXQtNjAwIHRvLXZpb2xldC03MDAgb3BhY2l0eS01IGdyb3VwLWhvdmVyOm9wYWNpdHktMTAgcm91bmRlZC1mdWxsIC1tci0xNiAtbXQtMTYgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGJsdXIteGxcIiAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHAtN1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEljb24gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMTQgaC0xNCBiZy12aW9sZXQtNTAgcm91bmRlZC1sZyBtYi01IGdyb3VwLWhvdmVyOnNjYWxlLTEwNSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxVc2VycyBzaXplPXsyOH0gY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogVGV4dCBDb250ZW50ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIG1iLTIgZ3JvdXAtaG92ZXI6dGV4dC1ncmF5LTk1MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZpc2l0b3IgTGlzdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBNYW5hZ2UgdmlzaXRvciByZWNvcmRzIGFuZCBkYWlseSBsb2dzIGVmZmljaWVudGx5LlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBCb3R0b20gU3RhdHMgJiBBcnJvdyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZ3JvdXAtaG92ZXI6Ym9yZGVyLWdyYXktMjAwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgZ3JvdXAtaG92ZXI6dGV4dC1ncmF5LTcwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFjdGl2ZSBWaXNpdG9yc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTEuNSByb3VuZGVkLWxnIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tdmlvbGV0LTYwMCB0by12aW9sZXQtNzAwIG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2Zvcm0gdHJhbnNsYXRlLXgtMSBncm91cC1ob3Zlcjp0cmFuc2xhdGUteC0wIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXdoaXRlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFRvcCBBY2NlbnQgTGluZSBvbiBIb3ZlciAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0wIGxlZnQtMCByaWdodC0wIGgtMC41IGJnLWdyYWRpZW50LXRvLXIgZnJvbS12aW9sZXQtNjAwIHRvLXZpb2xldC03MDAgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eSBkdXJhdGlvbi0zMDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PSBFTkQgQ0FSRCBTRUNUSU9OID09PT09PT09PT09PT09PT09ICovfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogPT09PT09PT09PT09PT09PT0gUVVJQ0sgVElQUyBTRUNUSU9OIChVcGRhdGVkIHRvIE1hdGNoIFJlZmVyZW5jZSBTdHlsZSkgPT09PT09PT09PT09PT09PT0gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xNiBwLTggYmctZ3JhZGllbnQtdG8tYnIgZnJvbS12aW9sZXQtNTAgdG8taW5kaWdvLTUwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItdmlvbGV0LTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LXZpb2xldC02MDAgbXQtMVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMCBtYi0yXCI+UXVpY2sgVGlwczwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBVc2UgdGhlIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPlZpc2l0b3IgTGlzdDwvc3Bhbj4gdG8gbWFuYWdlIHZpc2l0b3IgaW5mb3JtYXRpb24sIHVwZGF0ZSBlbnRyeS9leGl0IHRpbWVzLCBhbmQgdHJhY2sgdmlzaXRvciBoaXN0b3J5IGFsbCBpbiBvbmUgcGxhY2UuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENsaWNrIG9uIHRoZSBjYXJkIGFib3ZlIHRvIHZpZXcgYWxsIHJlZ2lzdGVyZWQgdmlzaXRvcnMgb3IgYWRkIGEgbmV3IGVudHJ5IHVzaW5nIHRoZSBcIisgQWRkIERldGFpbHNcIiBidXR0b24gaW5zaWRlIHRoZSBsaXN0LlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICB7LyogPT09PT09PT09PT09PT09PT0gRU5EIFFVSUNLIFRJUFMgPT09PT09PT09PT09PT09PT0gKi99XHJcblxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvPlxyXG4gICAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgVmlzaXRvcjsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvVmlzaXRvci5qc3gifQ==