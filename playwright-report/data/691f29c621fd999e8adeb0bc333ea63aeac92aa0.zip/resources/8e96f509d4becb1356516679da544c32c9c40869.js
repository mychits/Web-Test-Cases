import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ChitCancellationReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import api from "/src/instance/TokenInstance.js";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
const ChitCancellationReport = () => {
  _s();
  const [chitCancelDataTable, setChitCancelDataTable] = useState([]);
  const [loading, setLoading] = useState(true);
  const [groups, setGroups] = useState([]);
  const [users, setUsers] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState();
  const [selectedUser, setSelectedUser] = useState();
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setGroups(response.data);
      } catch (error) {
        console.error("failed to fetch group data", error);
      }
    };
    fetchGroups();
  }, []);
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await api.get("/user/get-user");
        setUsers(response.data);
      } catch (error) {
        console.error("failed to fetch users", error);
      }
    };
    fetchUsers();
  }, []);
  useEffect(() => {
    const fetchChitCancellation = async () => {
      try {
        const response = await api.get(
          "/enroll/chit-cancellation",
          {
            params: {
              group_id: selectedGroup,
              user_id: selectedUser
            }
          }
        );
        const formattedData = response.data?.data?.map((chit, index) => ({
          id: chit?._id,
          slNo: index + 1,
          userName: chit?.user_name,
          userPhone: chit?.user_phone,
          groupName: chit?.group_name,
          ticket: chit?.tickets,
          groupValue: chit?.group_value,
          totalPaidAmount: chit?.totalPaidAmount,
          cancellationDate: chit?.cancellation_date?.split("T")[0],
          joinedOn: chit?.createdAt?.split("T")[0]
        }));
        setChitCancelDataTable(formattedData);
      } catch (error) {
        console.error("failed to fetch chit cancelation report", error);
      } finally {
        setLoading(false);
      }
    };
    fetchChitCancellation();
  }, [selectedGroup, selectedUser]);
  const chitColumns = [
    { key: "slNo", header: "Sl No" },
    { key: "userName", header: "Customer Name" },
    { key: "userPhone", header: "Phone Number" },
    { key: "joinedOn", header: "Joined On" },
    { key: "groupName", header: "Group Name" },
    { key: "ticket", header: "Ticket" },
    { key: "groupValue", header: "Group Value" },
    { key: "totalPaidAmount", header: "Paid Amount" },
    { key: "cancellationDate", header: "Cancellation Date" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "max-w-screen", children: /* @__PURE__ */ jsxDEV("div", { className: " mx-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold flex items-center gap-3", children: "Chit Cancellation Report" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx",
      lineNumber: 95,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx",
      lineNumber: 94,
      columnNumber: 9
    }, this),
    loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center h-96", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx",
      lineNumber: 103,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx",
      lineNumber: 102,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Select Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx",
            lineNumber: 110,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
              showSearch: true,
              popupMatchSelectWidth: false,
              placeholder: "Select Group",
              value: selectedGroup,
              onChange: setSelectedGroup,
              allowClear: true,
              filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
              children: [
                /* @__PURE__ */ jsxDEV(Select.Option, { children: "All Groups" }, "", false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx",
                  lineNumber: 129,
                  columnNumber: 19
                }, this),
                groups.map(
                  (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx",
                    lineNumber: 131,
                    columnNumber: 17
                  }, this)
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx",
              lineNumber: 114,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx",
          lineNumber: 109,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Select User" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx",
            lineNumber: 140,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              showSearch: true,
              placeholder: "Select User",
              value: selectedUser,
              onChange: setSelectedUser,
              allowClear: true,
              className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
              filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
              children: [
                /* @__PURE__ */ jsxDEV(Select.Option, { children: "All Users" }, "", false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx",
                  lineNumber: 158,
                  columnNumber: 19
                }, this),
                users.map(
                  (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: user.full_name }, user._id, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx",
                    lineNumber: 160,
                    columnNumber: 17
                  }, this)
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx",
              lineNumber: 144,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx",
          lineNumber: 139,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx",
        lineNumber: 107,
        columnNumber: 14
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "max-w-screen", children: /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          columns: chitColumns,
          data: chitCancelDataTable,
          exportedPdfName: "Chit Cancellation  Report",
          exportedFileName: "Chit Cancellation Report.csv"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx",
          lineNumber: 169,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx",
        lineNumber: 168,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx",
      lineNumber: 106,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx",
    lineNumber: 92,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx",
    lineNumber: 91,
    columnNumber: 5
  }, this);
};
_s(ChitCancellationReport, "wM0Xls3KFjuqtBt34CtiXuj/BC0=");
_c = ChitCancellationReport;
export default ChitCancellationReport;
var _c;
$RefreshReg$(_c, "ChitCancellationReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ChitCancellationReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEZVLFNBV0EsVUFYQTsyQkE5RlY7QUFBZ0JBLE1BQVdDLGNBQVEsT0FBUSxzQkFBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNsRCxPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxTQUFTO0FBQ2hCLFNBQVFDLGNBQWE7QUFHckIsTUFBTUMseUJBQXlCQSxNQUFNO0FBQUFDLEtBQUE7QUFDckMsUUFBTSxDQUFDQyxxQkFBcUJDLHNCQUFzQixJQUFJUixTQUFTLEVBQUU7QUFDL0QsUUFBTSxDQUFDUyxTQUFTQyxVQUFVLElBQUlWLFNBQVMsSUFBSTtBQUk1QyxRQUFNLENBQUNXLFFBQVFDLFNBQVMsSUFBSVosU0FBUyxFQUFFO0FBQ3RDLFFBQU0sQ0FBQ2EsT0FBT0MsUUFBUSxJQUFJZCxTQUFTLEVBQUU7QUFFckMsUUFBTSxDQUFDZSxlQUFlQyxnQkFBZ0IsSUFBSWhCLFNBQVM7QUFDbkQsUUFBTSxDQUFDaUIsY0FBY0MsZUFBZSxJQUFJbEIsU0FBUztBQUNqREQsWUFBVSxNQUFJO0FBQ1osVUFBTW9CLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTUMsV0FBVyxNQUFNakIsSUFBSWtCLElBQUksd0JBQXdCO0FBQ3ZEVCxrQkFBVVEsU0FBU0UsSUFBSTtBQUFBLE1BRXpCLFNBQVNDLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sOEJBQThCQSxLQUFLO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBQ0FKLGdCQUFZO0FBQUEsRUFDZCxHQUFFLEVBQUU7QUFFSnBCLFlBQVUsTUFBSztBQUNiLFVBQU0wQixhQUFhLFlBQVk7QUFDN0IsVUFBSTtBQUNGLGNBQU1MLFdBQVcsTUFBTWpCLElBQUlrQixJQUFJLGdCQUFnQjtBQUMvQ1AsaUJBQVNNLFNBQVNFLElBQUk7QUFBQSxNQUN4QixTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLHlCQUF5QkEsS0FBSztBQUFBLE1BQzlDO0FBQUEsSUFDRjtBQUNBRSxlQUFXO0FBQUEsRUFDYixHQUFFLEVBQUU7QUFFRjFCLFlBQVUsTUFBSztBQUNYLFVBQU0yQix3QkFBd0IsWUFBWTtBQUN0QyxVQUFJO0FBQ0EsY0FBTU4sV0FBVyxNQUFNakIsSUFBSWtCO0FBQUFBLFVBQUk7QUFBQSxVQUM3QjtBQUFBLFlBQ1ZNLFFBQVE7QUFBQSxjQUNOQyxVQUFVYjtBQUFBQSxjQUNWYyxTQUFTWjtBQUFBQSxZQUNYO0FBQUEsVUFDRjtBQUFBLFFBQ1U7QUFFQSxjQUFNYSxnQkFBZ0JWLFNBQVNFLE1BQU1BLE1BQU1TLElBQUksQ0FBQ0MsTUFBTUMsV0FBVztBQUFBLFVBQzdEQyxJQUFJRixNQUFNRztBQUFBQSxVQUNWQyxNQUFNSCxRQUFRO0FBQUEsVUFDZEksVUFBVUwsTUFBTU07QUFBQUEsVUFDaEJDLFdBQVdQLE1BQU1RO0FBQUFBLFVBQ2pCQyxXQUFXVCxNQUFNVTtBQUFBQSxVQUNqQkMsUUFBUVgsTUFBTVk7QUFBQUEsVUFDZEMsWUFBWWIsTUFBTWM7QUFBQUEsVUFDbEJDLGlCQUFpQmYsTUFBTWU7QUFBQUEsVUFDdkJDLGtCQUFrQmhCLE1BQU1pQixtQkFBbUJDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxVQUN2REMsVUFBVW5CLE1BQU1vQixXQUFXRixNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsUUFDM0MsRUFBRTtBQUNGMUMsK0JBQXVCc0IsYUFBYTtBQUFBLE1BRXhDLFNBQVNQLE9BQU87QUFDWkMsZ0JBQVFELE1BQU0sMkNBQTJDQSxLQUFLO0FBQUEsTUFDbEUsVUFBQztBQUNMYixtQkFBVyxLQUFLO0FBQUEsTUFDWjtBQUFBLElBQ0o7QUFDQWdCLDBCQUFzQjtBQUFBLEVBQzFCLEdBQUUsQ0FBQ1gsZUFBZUUsWUFBWSxDQUFDO0FBRS9CLFFBQU1vQyxjQUFjO0FBQUEsSUFDaEIsRUFBQ0MsS0FBSyxRQUFRQyxRQUFRLFFBQU87QUFBQSxJQUM3QixFQUFDRCxLQUFLLFlBQVlDLFFBQVEsZ0JBQWU7QUFBQSxJQUN6QyxFQUFDRCxLQUFLLGFBQWFDLFFBQVEsZUFBYztBQUFBLElBQ3pDLEVBQUNELEtBQUssWUFBWUMsUUFBUSxZQUFXO0FBQUEsSUFDckMsRUFBQ0QsS0FBSyxhQUFhQyxRQUFRLGFBQVk7QUFBQSxJQUN2QyxFQUFDRCxLQUFLLFVBQVVDLFFBQVEsU0FBUTtBQUFBLElBQ2hDLEVBQUNELEtBQUssY0FBY0MsUUFBUSxjQUFhO0FBQUEsSUFDekMsRUFBQ0QsS0FBSyxtQkFBbUJDLFFBQVEsY0FBYTtBQUFBLElBQzlDLEVBQUNELEtBQUssb0JBQW9CQyxRQUFRLG9CQUFtQjtBQUFBLEVBQUM7QUFFNUQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsZ0JBQ2IsaUNBQUMsU0FBSSxXQUFVLFlBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxRQUFHLFdBQVUsOENBQTZDLHdDQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUVDOUMsVUFDQyx1QkFBQyxTQUFJLFdBQVUseUNBQ2IsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxJQUVBLG1DQUNHO0FBQUEsNkJBQUMsU0FBSSxXQUFVLCtCQUVkO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxrQ0FBaUMsNEJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVjtBQUFBLGNBQ0UsdUJBQXVCO0FBQUEsY0FDekIsYUFBWTtBQUFBLGNBQ1osT0FBT007QUFBQUEsY0FDUCxVQUFVQztBQUFBQSxjQUNWO0FBQUEsY0FDQSxjQUFjLENBQUN3QyxPQUFPQyxXQUNsQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUQyxZQUFZLEVBQ1pDLFNBQVNMLE1BQU1JLFlBQVksQ0FBQztBQUFBLGNBR25DO0FBQUEsdUNBQUMsT0FBTyxRQUFQLEVBQXNCLDBCQUFILElBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlDO0FBQUEsZ0JBQ2hDakQsT0FBT29CO0FBQUFBLGtCQUFJLENBQUMrQixVQUNYLHVCQUFDLE9BQU8sUUFBUCxFQUE4QixPQUFPQSxNQUFNM0IsS0FDekMyQixnQkFBTXBCLGNBRFdvQixNQUFNM0IsS0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGdCQUNEO0FBQUE7QUFBQTtBQUFBLFlBcEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXFCQTtBQUFBLGFBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyQkE7QUFBQSxRQUdBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsa0NBQWlDLDJCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0M7QUFBQSxjQUNBLGFBQVk7QUFBQSxjQUNaLE9BQU9sQjtBQUFBQSxjQUNQLFVBQVVDO0FBQUFBLGNBQ1Y7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUNULGNBQWMsQ0FBQ3NDLE9BQU9DLFdBQ25CQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1RDLFlBQVksRUFDWkMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsY0FHbkM7QUFBQSx1Q0FBQyxPQUFPLFFBQVAsRUFBc0IseUJBQUgsSUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxnQkFDL0IvQyxNQUFNa0I7QUFBQUEsa0JBQUksQ0FBQ2dDLFNBQ1YsdUJBQUMsT0FBTyxRQUFQLEVBQTZCLE9BQU9BLEtBQUs1QixLQUN2QzRCLGVBQUtDLGFBRFlELEtBQUs1QixLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBO0FBQUEsWUFuQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBb0JBO0FBQUEsYUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBCQTtBQUFBLFdBMUREO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0REQ7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBU2tCO0FBQUFBLFVBQ1QsTUFBTTlDO0FBQUFBLFVBRU4saUJBQWdCO0FBQUEsVUFDaEIsa0JBQWlCO0FBQUE7QUFBQSxRQUxuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLaUQsS0FObkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsU0F0RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVFQTtBQUFBLE9BckZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1RkEsS0F4RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlGQTtBQUVKO0FBQUNELEdBOUtLRCx3QkFBc0I7QUFBQTRELEtBQXRCNUQ7QUFnTE4sZUFBZUE7QUFBc0IsSUFBQTREO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIkNpcmN1bGFyTG9hZGVyIiwiRGF0YVRhYmxlIiwiYXBpIiwiU2VsZWN0IiwiQ2hpdENhbmNlbGxhdGlvblJlcG9ydCIsIl9zIiwiY2hpdENhbmNlbERhdGFUYWJsZSIsInNldENoaXRDYW5jZWxEYXRhVGFibGUiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImdyb3VwcyIsInNldEdyb3VwcyIsInVzZXJzIiwic2V0VXNlcnMiLCJzZWxlY3RlZEdyb3VwIiwic2V0U2VsZWN0ZWRHcm91cCIsInNlbGVjdGVkVXNlciIsInNldFNlbGVjdGVkVXNlciIsImZldGNoR3JvdXBzIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwiZXJyb3IiLCJjb25zb2xlIiwiZmV0Y2hVc2VycyIsImZldGNoQ2hpdENhbmNlbGxhdGlvbiIsInBhcmFtcyIsImdyb3VwX2lkIiwidXNlcl9pZCIsImZvcm1hdHRlZERhdGEiLCJtYXAiLCJjaGl0IiwiaW5kZXgiLCJpZCIsIl9pZCIsInNsTm8iLCJ1c2VyTmFtZSIsInVzZXJfbmFtZSIsInVzZXJQaG9uZSIsInVzZXJfcGhvbmUiLCJncm91cE5hbWUiLCJncm91cF9uYW1lIiwidGlja2V0IiwidGlja2V0cyIsImdyb3VwVmFsdWUiLCJncm91cF92YWx1ZSIsInRvdGFsUGFpZEFtb3VudCIsImNhbmNlbGxhdGlvbkRhdGUiLCJjYW5jZWxsYXRpb25fZGF0ZSIsInNwbGl0Iiwiam9pbmVkT24iLCJjcmVhdGVkQXQiLCJjaGl0Q29sdW1ucyIsImtleSIsImhlYWRlciIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJ0b1N0cmluZyIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJncm91cCIsInVzZXIiLCJmdWxsX25hbWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDaGl0Q2FuY2VsbGF0aW9uUmVwb3J0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSAnLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyJztcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tICcuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlJztcclxuaW1wb3J0IGFwaSBmcm9tICcuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlJztcclxuaW1wb3J0IHtTZWxlY3R9IGZyb20gXCJhbnRkXCI7XHJcblxyXG5cclxuY29uc3QgQ2hpdENhbmNlbGxhdGlvblJlcG9ydCA9ICgpID0+IHtcclxuY29uc3QgW2NoaXRDYW5jZWxEYXRhVGFibGUsIHNldENoaXRDYW5jZWxEYXRhVGFibGVdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG5cclxuXHJcblxyXG4gY29uc3QgW2dyb3Vwcywgc2V0R3JvdXBzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXAsIHNldFNlbGVjdGVkR3JvdXBdID0gdXNlU3RhdGUoKTtcclxuICBjb25zdCBbc2VsZWN0ZWRVc2VyLCBzZXRTZWxlY3RlZFVzZXJdID0gdXNlU3RhdGUoKTtcclxuICB1c2VFZmZlY3QoKCk9PntcclxuICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgICAgc2V0R3JvdXBzKHJlc3BvbnNlLmRhdGEpXHJcbiAgICAgICAgXHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcImZhaWxlZCB0byBmZXRjaCBncm91cCBkYXRhXCIsIGVycm9yKVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBmZXRjaEdyb3VwcygpXHJcbiAgfSxbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKT0+IHtcclxuICAgIGNvbnN0IGZldGNoVXNlcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgICAgc2V0VXNlcnMocmVzcG9uc2UuZGF0YSlcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiZmFpbGVkIHRvIGZldGNoIHVzZXJzXCIsIGVycm9yKVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBmZXRjaFVzZXJzKClcclxuICB9LFtdKVxyXG5cclxuICAgIHVzZUVmZmVjdCgoKT0+IHtcclxuICAgICAgICBjb25zdCBmZXRjaENoaXRDYW5jZWxsYXRpb24gPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvZW5yb2xsL2NoaXQtY2FuY2VsbGF0aW9uXCIsXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgIGdyb3VwX2lkOiBzZWxlY3RlZEdyb3VwLFxyXG4gICAgICAgICAgdXNlcl9pZDogc2VsZWN0ZWRVc2VyXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhPy5kYXRhPy5tYXAoKGNoaXQsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgIGlkOiBjaGl0Py5faWQsXHJcbiAgICAgICAgICAgICAgICAgICAgc2xObzogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJOYW1lOiBjaGl0Py51c2VyX25hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlclBob25lOiBjaGl0Py51c2VyX3Bob25lLFxyXG4gICAgICAgICAgICAgICAgICAgIGdyb3VwTmFtZTogY2hpdD8uZ3JvdXBfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgICB0aWNrZXQ6IGNoaXQ/LnRpY2tldHMsXHJcbiAgICAgICAgICAgICAgICAgICAgZ3JvdXBWYWx1ZTogY2hpdD8uZ3JvdXBfdmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgdG90YWxQYWlkQW1vdW50OiBjaGl0Py50b3RhbFBhaWRBbW91bnQsXHJcbiAgICAgICAgICAgICAgICAgICAgY2FuY2VsbGF0aW9uRGF0ZTogY2hpdD8uY2FuY2VsbGF0aW9uX2RhdGU/LnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICAgICAgICAgICAgICBqb2luZWRPbjogY2hpdD8uY3JlYXRlZEF0Py5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgICAgICBzZXRDaGl0Q2FuY2VsRGF0YVRhYmxlKGZvcm1hdHRlZERhdGEpXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJmYWlsZWQgdG8gZmV0Y2ggY2hpdCBjYW5jZWxhdGlvbiByZXBvcnRcIiwgZXJyb3IpXHJcbiAgICAgICAgICAgIH0gZmluYWxseXtcclxuICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBmZXRjaENoaXRDYW5jZWxsYXRpb24oKTtcclxuICAgIH0sW3NlbGVjdGVkR3JvdXAsIHNlbGVjdGVkVXNlcl0pO1xyXG5cclxuICAgIGNvbnN0IGNoaXRDb2x1bW5zID0gW1xyXG4gICAgICAgIHtrZXk6IFwic2xOb1wiLCBoZWFkZXI6IFwiU2wgTm9cIn0sXHJcbiAgICAgICAge2tleTogXCJ1c2VyTmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwifSxcclxuICAgICAgICB7a2V5OiBcInVzZXJQaG9uZVwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCJ9LFxyXG4gICAgICAgIHtrZXk6IFwiam9pbmVkT25cIiwgaGVhZGVyOiBcIkpvaW5lZCBPblwifSxcclxuICAgICAgICB7a2V5OiBcImdyb3VwTmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwifSxcclxuICAgICAgICB7a2V5OiBcInRpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0XCJ9LFxyXG4gICAgICAgIHtrZXk6IFwiZ3JvdXBWYWx1ZVwiLCBoZWFkZXI6IFwiR3JvdXAgVmFsdWVcIn0sXHJcbiAgICAgICAge2tleTogXCJ0b3RhbFBhaWRBbW91bnRcIiwgaGVhZGVyOiBcIlBhaWQgQW1vdW50XCJ9LFxyXG4gICAgICAgIHtrZXk6IFwiY2FuY2VsbGF0aW9uRGF0ZVwiLCBoZWFkZXI6IFwiQ2FuY2VsbGF0aW9uIERhdGVcIn0sXHJcbiAgICBdXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctc2NyZWVuXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiIG14LWF1dG9cIj5cclxuICAgICAgICB7LyogSGVhZGVyICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgQ2hpdCBDYW5jZWxsYXRpb24gUmVwb3J0XHJcbiAgICAgICAgICA8L2gxPlxyXG4gICAgICAgIFxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7bG9hZGluZyA/IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgaC05NlwiPlxyXG4gICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00IG1iLTZcIj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgU2VsZWN0IEdyb3VwXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEdyb3VwXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkR3JvdXB9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXRTZWxlY3RlZEdyb3VwfVxyXG4gICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9IFwiXCI+QWxsIEdyb3VwczwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAge2dyb3Vwcy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtncm91cC5faWR9IHZhbHVlPXtncm91cC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgU2VsZWN0IFVzZXJcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFVzZXJcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRVc2VyfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRVc2VyfVxyXG4gICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PSBcIlwiPkFsbCBVc2VyczwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAge3VzZXJzLm1hcCgodXNlcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dXNlci5faWR9IHZhbHVlPXt1c2VyLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7dXNlci5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctc2NyZWVuXCI+XHJcbiAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgY29sdW1ucz17Y2hpdENvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICBkYXRhPXtjaGl0Q2FuY2VsRGF0YVRhYmxlfVxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJDaGl0IENhbmNlbGxhdGlvbiAgUmVwb3J0XCJcclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJDaGl0IENhbmNlbGxhdGlvbiBSZXBvcnQuY3N2XCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDaGl0Q2FuY2VsbGF0aW9uUmVwb3J0XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9DaGl0Q2FuY2VsbGF0aW9uUmVwb3J0LmpzeCJ9