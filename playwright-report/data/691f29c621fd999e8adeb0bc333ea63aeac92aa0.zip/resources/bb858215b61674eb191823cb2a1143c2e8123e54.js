import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PrizedCustomerReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select, Modal as AntModal, DatePicker, Tag, Empty, Tooltip } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { FaFileInvoiceDollar, FaEye, FaUserShield } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import __vite__cjsImport9_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport9_dayjs.__esModule ? __vite__cjsImport9_dayjs.default : __vite__cjsImport9_dayjs;
const { RangePicker } = DatePicker;
const PrizedCustomerReport = () => {
  _s();
  const [reports, setReports] = useState([]);
  const [groups, setGroups] = useState([]);
  const [users, setUsers] = useState([]);
  const [admins, setAdmins] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [filters, setFilters] = useState({
    groupId: "",
    userId: "",
    adminType: "",
    startDate: "",
    endDate: ""
  });
  const [showModalView, setShowModalView] = useState(false);
  const [currentReport, setCurrentReport] = useState(null);
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "payDate", header: "Payment Date" },
    { key: "transactionDate", header: "Transaction Date" },
    { key: "userName", header: "Customer Name" },
    { key: "groupName", header: "Group Name" },
    { key: "ticket", header: "Ticket" },
    { key: "totalPaidAmount", header: "Total Paid Amount" },
    { key: "totalPayable", header: "Total Payable" },
    { key: "balance", header: "Balance" },
    { key: "amount", header: "Payout Amount" },
    { key: "status", header: "Status" },
    { key: "adminName", header: "Handled By" },
    { key: "action", header: "Action" }
  ];
  const exportColumns = [
    { key: "id", header: "SL. NO" },
    { key: "payDate", header: "Payment Date" },
    { key: "transactionDate", header: "Transaction Date" },
    { key: "userName", header: "Customer Name" },
    { key: "groupName", header: "Group Name" },
    { key: "ticket", header: "Ticket" },
    { key: "totalPayableRaw", header: "Total Payable" },
    { key: "totalPaidAmountRaw", header: "Total Paid Amount" },
    { key: "balanceRaw", header: "Balance" },
    { key: "amountRaw", header: "Payout Amount" },
    { key: "statusRaw", header: "Status" },
    { key: "adminName", header: "Handled By" }
  ];
  const fetchInitialData = async () => {
    try {
      const [groupRes, userRes, adminRes] = await Promise.all(
        [
          api.get("/group/get-group-admin"),
          api.get("user/verified"),
          api.get("/admin/get-sub-admins")
        ]
      );
      setGroups(groupRes.data || []);
      setUsers(userRes.data?.data || []);
      setAdmins(adminRes.data || []);
    } catch (error) {
      console.error("Error fetching initial data", error);
    }
  };
  const fetchReportData = async () => {
    setIsLoading(true);
    try {
      const params = {};
      if (filters.groupId) params.groupId = filters.groupId;
      if (filters.userId) params.userId = filters.userId;
      if (filters.adminType) params.adminType = filters.adminType;
      if (filters.startDate) params.startDate = filters.startDate;
      if (filters.endDate) params.endDate = filters.endDate;
      const response = await api.get("/payment-out/prized", { params });
      if (response.data && response.data.data) {
        const formattedData = response.data.data.map((item, index) => ({
          ...item,
          id: index + 1,
          payDate: item.pay_date ? dayjs(item.pay_date).format("YYYY-MM-DD") : "N/A",
          groupName: item.group_details?.group_name || "N/A",
          userName: item.user_details?.full_name || "N/A",
          ticket: item.ticket,
          adminName: item.admin_details?.name || "N/A",
          amount: `₹${item.amount?.toLocaleString("en-IN")}`,
          amountRaw: item.amount,
          transactionDate: item.createdAt ? `${item.createdAt.split("T")[0]}` : "",
          status: /* @__PURE__ */ jsxDEV(Tag, { color: "green", children: "PAID" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
            lineNumber: 102,
            columnNumber: 19
          }, this),
          statusRaw: "PAID",
          balance: `${item.auctions?.balance?.toLocaleString("en-IN")}`,
          balanceRaw: item.auctions?.balance,
          totalPaidAmount: `${item?.payments?.totalPaidAmount?.toLocaleString("en-IN") || 0}`,
          totalPaidAmountRaw: item?.payments?.totalPaidAmount || 0,
          totalPayable: `${item?.auctions?.to_be_paid_amount?.toLocaleString("en-IN") || 0}`,
          totalPayableRaw: item?.auctions?.to_be_paid_amount || 0,
          status_raw: "Paid",
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center", children: /* @__PURE__ */ jsxDEV(Tooltip, { title: "View Receipt", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setCurrentReport(item);
                setShowModalView(true);
              },
              className: "p-2 bg-violet-50 text-violet-600 rounded-full hover:bg-violet-100",
              children: /* @__PURE__ */ jsxDEV(FaEye, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
                lineNumber: 122,
                columnNumber: 19
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
              lineNumber: 115,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
            lineNumber: 114,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
            lineNumber: 113,
            columnNumber: 11
          }, this)
        }));
        setReports(formattedData);
      }
    } catch (error) {
      setReports([]);
      console.error("Error fetching report:", error);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchInitialData();
  }, []);
  useEffect(() => {
    fetchReportData();
  }, [filters]);
  const onDateRangeChange = (dates) => {
    if (dates) {
      setFilters((prev) => ({
        ...prev,
        startDate: dates[0].format("YYYY-MM-DD"),
        endDate: dates[1].format("YYYY-MM-DD")
      }));
    } else {
      setFilters((prev) => ({ ...prev, startDate: "", endDate: "" }));
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 bg-gray-50 min-h-screen", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(FaFileInvoiceDollar, { className: "text-violet-900" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
          lineNumber: 163,
          columnNumber: 13
        }, this),
        " Prized Customer Report"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
        lineNumber: 162,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
        lineNumber: 161,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-sm mb-8 border border-gray-100", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-bold text-gray-500 uppercase", children: "Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
            lineNumber: 172,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              placeholder: "All Groups",
              className: "w-full h-10 mt-1",
              allowClear: true,
              onChange: (val) => setFilters((prev) => ({ ...prev, groupId: val })),
              children: groups.map(
                (g) => /* @__PURE__ */ jsxDEV(Select.Option, { value: g._id, children: g.group_name }, g._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
                  lineNumber: 180,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
              lineNumber: 173,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
          lineNumber: 171,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-bold text-gray-500 uppercase", children: "Customer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
            lineNumber: 186,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              placeholder: "All Customers",
              className: "w-full h-10 mt-1",
              allowClear: true,
              showSearch: true,
              filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
              onChange: (val) => setFilters((prev) => ({ ...prev, userId: val })),
              children: users.map(
                (u) => /* @__PURE__ */ jsxDEV(Select.Option, { value: u._id, children: u.full_name }, u._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
                  lineNumber: 196,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
              lineNumber: 187,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
          lineNumber: 185,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-bold text-gray-500 uppercase", children: "Date Range" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
            lineNumber: 202,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(RangePicker, { className: "w-full h-10 mt-1", onChange: onDateRangeChange }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
            lineNumber: 203,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
          lineNumber: 201,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-bold text-gray-500 uppercase", children: "Admin / Staff" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
            lineNumber: 207,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              placeholder: "Filtered by Admin",
              className: "w-full h-10 mt-1",
              allowClear: true,
              onChange: (val) => setFilters((prev) => ({ ...prev, adminType: val })),
              children: admins.map(
                (a) => /* @__PURE__ */ jsxDEV(Select.Option, { value: a._id, children: a.name }, a._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
                  lineNumber: 215,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
              lineNumber: 208,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
          lineNumber: 206,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
        lineNumber: 169,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
        lineNumber: 168,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm p-4", children: isLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true, data: "Reports" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
        lineNumber: 226,
        columnNumber: 11
      }, this) : reports.length <= 0 ? /* @__PURE__ */ jsxDEV(Empty, { description: "No Payout Data Found" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
        lineNumber: 228,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: reports,
          columns,
          exportCols: exportColumns,
          exportedPdfName: "Prized_Customer_Payout_Report",
          exportedFileName: "Prized_Customer_Payout_Report.csv"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
          lineNumber: 230,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
        lineNumber: 224,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
      lineNumber: 160,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      AntModal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-bold border-b pb-2", children: "Payout Details" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
          lineNumber: 243,
          columnNumber: 16
        }, this),
        open: showModalView,
        onCancel: () => setShowModalView(false),
        footer: null,
        width: 600,
        children: currentReport && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-y-4 py-4", children: [
          /* @__PURE__ */ jsxDEV(DetailItem, { label: "Group Name", value: currentReport.group_details?.group_name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
            lineNumber: 251,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(DetailItem, { label: "Customer Name", value: currentReport.user_details?.full_name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
            lineNumber: 252,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(DetailItem, { label: "Payment Date", value: dayjs(currentReport.pay_date).format("DD-MM-YYYY") }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
            lineNumber: 253,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(DetailItem, { label: "Disbursement Type", value: currentReport.disbursement_type }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
            lineNumber: 254,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(DetailItem, { label: "Payout Amount", value: `₹${currentReport.amount?.toLocaleString()}` }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
            lineNumber: 255,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(DetailItem, { label: "Handled By", value: currentReport.admin_details?.name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
            lineNumber: 256,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(DetailItem, { label: "Payment For", value: currentReport.pay_for }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
            lineNumber: 257,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            DetailItem,
            {
              label: "Status",
              value: /* @__PURE__ */ jsxDEV(Tag, { color: "green", children: "SUCCESSFUL" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
                lineNumber: 260,
                columnNumber: 20
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
              lineNumber: 258,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
          lineNumber: 250,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
        lineNumber: 242,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
    lineNumber: 159,
    columnNumber: 5
  }, this);
};
_s(PrizedCustomerReport, "FExiC23XTUBfVaLh1+nKcd8UMCg=");
_c = PrizedCustomerReport;
const DetailItem = ({ label, value }) => /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col border-b border-gray-50 pb-2 mr-4", children: [
  /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-bold text-gray-400 uppercase tracking-wider", children: label }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
    lineNumber: 271,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800", children: value || "N/A" }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
    lineNumber: 272,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx",
  lineNumber: 270,
  columnNumber: 1
}, this);
_c2 = DetailItem;
export default PrizedCustomerReport;
var _c, _c2;
$RefreshReg$(_c, "PrizedCustomerReport");
$RefreshReg$(_c2, "DetailItem");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PrizedCustomerReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUdrQjsyQkFyR2xCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0MsUUFBUUMsU0FBU0MsVUFBVUMsWUFBWUMsS0FBS0MsT0FBT0MsZUFBZTtBQUMzRSxTQUFTQyxxQkFBcUJDLE9BQU9DLG9CQUFvQjtBQUN6RCxPQUFPQyxXQUFXO0FBRWxCLE1BQU0sRUFBRUMsWUFBWSxJQUFJUjtBQUV4QixNQUFNUyx1QkFBdUJBLE1BQU07QUFBQUMsS0FBQTtBQUNqQyxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSW5CLFNBQVMsRUFBRTtBQUN6QyxRQUFNLENBQUNvQixRQUFRQyxTQUFTLElBQUlyQixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDc0IsT0FBT0MsUUFBUSxJQUFJdkIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ3dCLFFBQVFDLFNBQVMsSUFBSXpCLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUMwQixXQUFXQyxZQUFZLElBQUkzQixTQUFTLEtBQUs7QUFFaEQsUUFBTSxDQUFDNEIsU0FBU0MsVUFBVSxJQUFJN0IsU0FBUztBQUFBLElBQ3JDOEIsU0FBUztBQUFBLElBQ1RDLFFBQVE7QUFBQSxJQUNSQyxXQUFXO0FBQUEsSUFDWEMsV0FBVztBQUFBLElBQ1hDLFNBQVM7QUFBQSxFQUNYLENBQUM7QUFFRCxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJcEMsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQ3FDLGVBQWVDLGdCQUFnQixJQUFJdEMsU0FBUyxJQUFJO0FBRXZELFFBQU11QyxVQUFVO0FBQUEsSUFDZCxFQUFFQyxLQUFLLE1BQU1DLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVELEtBQUssV0FBV0MsUUFBUSxlQUFlO0FBQUEsSUFDekMsRUFBRUQsS0FBSyxtQkFBbUJDLFFBQVEsbUJBQW1CO0FBQUEsSUFDckQsRUFBRUQsS0FBSyxZQUFZQyxRQUFRLGdCQUFnQjtBQUFBLElBQzNDLEVBQUVELEtBQUssYUFBYUMsUUFBUSxhQUFhO0FBQUEsSUFDekMsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFRCxLQUFLLG1CQUFtQkMsUUFBUSxvQkFBb0I7QUFBQSxJQUN0RCxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxnQkFBZ0I7QUFBQSxJQUMvQyxFQUFFRCxLQUFLLFdBQVdDLFFBQVEsVUFBVTtBQUFBLElBRXBDLEVBQUVELEtBQUssVUFBVUMsUUFBUSxnQkFBZ0I7QUFBQSxJQUN6QyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVELEtBQUssYUFBYUMsUUFBUSxhQUFhO0FBQUEsSUFDekMsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFFBQU1DLGdCQUFnQjtBQUFBLElBQ3BCLEVBQUVGLEtBQUssTUFBTUMsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLGVBQWU7QUFBQSxJQUN0QyxFQUFFRCxLQUFLLG1CQUFtQkMsUUFBUSxtQkFBbUI7QUFBQSxJQUNyRCxFQUFFRCxLQUFLLFlBQVlDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDOUMsRUFBRUQsS0FBSyxhQUFhQyxRQUFRLGFBQWE7QUFBQSxJQUN6QyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVELEtBQUssbUJBQW1CQyxRQUFRLGdCQUFnQjtBQUFBLElBQ2xELEVBQUVELEtBQUssc0JBQXNCQyxRQUFRLG9CQUFvQjtBQUFBLElBQ3pELEVBQUVELEtBQUssY0FBY0MsUUFBUSxVQUFVO0FBQUEsSUFDdkMsRUFBRUQsS0FBSyxhQUFhQyxRQUFRLGdCQUFnQjtBQUFBLElBQzVDLEVBQUVELEtBQUssYUFBYUMsUUFBUSxTQUFTO0FBQUEsSUFDckMsRUFBRUQsS0FBSyxhQUFhQyxRQUFRLGFBQWE7QUFBQSxFQUFDO0FBRzVDLFFBQU1FLG1CQUFtQixZQUFZO0FBQ25DLFFBQUk7QUFFRixZQUFNLENBQUNDLFVBQVVDLFNBQVNDLFFBQVEsSUFBSSxNQUFNQyxRQUFRQztBQUFBQSxRQUFJO0FBQUEsVUFDdEQvQyxJQUFJZ0QsSUFBSSx3QkFBd0I7QUFBQSxVQUNoQ2hELElBQUlnRCxJQUFJLGVBQWU7QUFBQSxVQUN2QmhELElBQUlnRCxJQUFJLHVCQUF1QjtBQUFBLFFBQUM7QUFBQSxNQUNqQztBQUNENUIsZ0JBQVV1QixTQUFTTSxRQUFRLEVBQUU7QUFDN0IzQixlQUFTc0IsUUFBUUssTUFBTUEsUUFBUSxFQUFFO0FBQ2pDekIsZ0JBQVVxQixTQUFTSSxRQUFRLEVBQUU7QUFBQSxJQUMvQixTQUFTQyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sK0JBQStCQSxLQUFLO0FBQUEsSUFDcEQ7QUFBQSxFQUNGO0FBRUEsUUFBTUUsa0JBQWtCLFlBQVk7QUFDbEMxQixpQkFBYSxJQUFJO0FBQ2pCLFFBQUk7QUFDRixZQUFNMkIsU0FBUyxDQUFDO0FBQ2hCLFVBQUkxQixRQUFRRSxRQUFTd0IsUUFBT3hCLFVBQVVGLFFBQVFFO0FBQzlDLFVBQUlGLFFBQVFHLE9BQVF1QixRQUFPdkIsU0FBU0gsUUFBUUc7QUFDNUMsVUFBSUgsUUFBUUksVUFBV3NCLFFBQU90QixZQUFZSixRQUFRSTtBQUNsRCxVQUFJSixRQUFRSyxVQUFXcUIsUUFBT3JCLFlBQVlMLFFBQVFLO0FBQ2xELFVBQUlMLFFBQVFNLFFBQVNvQixRQUFPcEIsVUFBVU4sUUFBUU07QUFFOUMsWUFBTXFCLFdBQVcsTUFBTXRELElBQUlnRCxJQUFJLHVCQUF1QixFQUFFSyxPQUFPLENBQUM7QUFFaEUsVUFBSUMsU0FBU0wsUUFBUUssU0FBU0wsS0FBS0EsTUFBTTtBQUN2QyxjQUFNTSxnQkFBZ0JELFNBQVNMLEtBQUtBLEtBQUtPLElBQUksQ0FBQ0MsTUFBTUMsV0FBVztBQUFBLFVBQzdELEdBQUdEO0FBQUFBLFVBQ0hFLElBQUlELFFBQVE7QUFBQSxVQUNaRSxTQUFTSCxLQUFLSSxXQUFXaEQsTUFBTTRDLEtBQUtJLFFBQVEsRUFBRUMsT0FBTyxZQUFZLElBQUk7QUFBQSxVQUNyRUMsV0FBV04sS0FBS08sZUFBZUMsY0FBYztBQUFBLFVBQzdDQyxVQUFVVCxLQUFLVSxjQUFjQyxhQUFhO0FBQUEsVUFDMUNDLFFBQVFaLEtBQUtZO0FBQUFBLFVBQ2JDLFdBQVdiLEtBQUtjLGVBQWVDLFFBQVE7QUFBQSxVQUN2Q0MsUUFBUSxJQUFJaEIsS0FBS2dCLFFBQVFDLGVBQWUsT0FBTyxDQUFDO0FBQUEsVUFDaERDLFdBQVdsQixLQUFLZ0I7QUFBQUEsVUFDaEJHLGlCQUFnQm5CLEtBQUtvQixZQUFZLEdBQUdwQixLQUFLb0IsVUFBVUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDLEtBQUk7QUFBQSxVQUNwRUMsUUFBUSx1QkFBQyxPQUFJLE9BQU0sU0FBUSxvQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUI7QUFBQSxVQUMvQkMsV0FBVztBQUFBLFVBQ1hDLFNBQVMsR0FBR3hCLEtBQUt5QixVQUFVRCxTQUFTUCxlQUFlLE9BQU8sQ0FBQztBQUFBLFVBQzNEUyxZQUFZMUIsS0FBS3lCLFVBQVVEO0FBQUFBLFVBQzNCRyxpQkFBaUIsR0FBRzNCLE1BQU00QixVQUFVRCxpQkFBaUJWLGVBQWUsT0FBTyxLQUFLLENBQUM7QUFBQSxVQUNqRlksb0JBQW9CN0IsTUFBTTRCLFVBQVVELG1CQUFtQjtBQUFBLFVBQ3ZERyxjQUFlLEdBQUc5QixNQUFNeUIsVUFBVU0sbUJBQW1CZCxlQUFlLE9BQU8sS0FBSyxDQUFDO0FBQUEsVUFDakZlLGlCQUFrQmhDLE1BQU15QixVQUFVTSxxQkFBcUI7QUFBQSxVQUV2REUsWUFBWTtBQUFBLFVBQ1pDLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLHVCQUNiLGlDQUFDLFdBQVEsT0FBTSxnQkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNO0FBQ2J0RCxpQ0FBaUJvQixJQUFJO0FBQ3JCdEIsaUNBQWlCLElBQUk7QUFBQSxjQUN2QjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVYsaUNBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFNO0FBQUE7QUFBQSxZQVBSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxRQUVKLEVBQUU7QUFDRmpCLG1CQUFXcUMsYUFBYTtBQUFBLE1BQzFCO0FBQUEsSUFDRixTQUFTTCxPQUFPO0FBQ2RoQyxpQkFBVyxFQUFFO0FBQ2JpQyxjQUFRRCxNQUFNLDBCQUEwQkEsS0FBSztBQUFBLElBQy9DLFVBQUM7QUFDQ3hCLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQTVCLFlBQVUsTUFBTTtBQUNkNEMscUJBQWlCO0FBQUEsRUFDbkIsR0FBRyxFQUFFO0FBRUw1QyxZQUFVLE1BQU07QUFDZHNELG9CQUFnQjtBQUFBLEVBQ2xCLEdBQUcsQ0FBQ3pCLE9BQU8sQ0FBQztBQUVaLFFBQU1pRSxvQkFBb0JBLENBQUNDLFVBQVU7QUFDbkMsUUFBSUEsT0FBTztBQUNUakUsaUJBQVcsQ0FBQWtFLFVBQVM7QUFBQSxRQUNsQixHQUFHQTtBQUFBQSxRQUNIOUQsV0FBVzZELE1BQU0sQ0FBQyxFQUFFL0IsT0FBTyxZQUFZO0FBQUEsUUFDdkM3QixTQUFTNEQsTUFBTSxDQUFDLEVBQUUvQixPQUFPLFlBQVk7QUFBQSxNQUN2QyxFQUFFO0FBQUEsSUFDSixPQUFPO0FBQ0xsQyxpQkFBVyxDQUFBa0UsVUFBUyxFQUFFLEdBQUdBLE1BQU05RCxXQUFXLElBQUlDLFNBQVMsR0FBRyxFQUFFO0FBQUEsSUFDOUQ7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSwwQ0FDYixpQ0FBQyxRQUFHLFdBQVUsOENBQ1o7QUFBQSwrQkFBQyx1QkFBb0IsV0FBVSxxQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRDtBQUFBLFFBQUc7QUFBQSxXQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxpRUFDYixpQ0FBQyxTQUFJLFdBQVUsd0RBRWI7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDZDQUE0QyxxQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0U7QUFBQSxVQUNsRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsYUFBWTtBQUFBLGNBQ1osV0FBVTtBQUFBLGNBQ1Y7QUFBQSxjQUNBLFVBQVUsQ0FBQzhELFFBQVFuRSxXQUFXLENBQUFrRSxVQUFTLEVBQUUsR0FBR0EsTUFBTWpFLFNBQVNrRSxJQUFJLEVBQUU7QUFBQSxjQUVoRTVFLGlCQUFPcUM7QUFBQUEsZ0JBQUksQ0FBQXdDLE1BQ1YsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU9BLEVBQUVDLEtBQU1ELFlBQUUvQixjQUF4QitCLEVBQUVDLEtBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVEO0FBQUEsY0FDeEQ7QUFBQTtBQUFBLFlBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0E7QUFBQSxhQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSw2Q0FBNEMsd0JBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFFO0FBQUEsVUFDckU7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLGFBQVk7QUFBQSxjQUNaLFdBQVU7QUFBQSxjQUNWO0FBQUEsY0FDQTtBQUFBLGNBQ0EsY0FBYyxDQUFDQyxPQUFPQyxXQUFXQSxPQUFPQyxTQUFTQyxZQUFZLEVBQUVDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLGNBQzNGLFVBQVUsQ0FBQ04sUUFBUW5FLFdBQVcsQ0FBQWtFLFVBQVMsRUFBRSxHQUFHQSxNQUFNaEUsUUFBUWlFLElBQUksRUFBRTtBQUFBLGNBRS9EMUUsZ0JBQU1tQztBQUFBQSxnQkFBSSxDQUFBK0MsTUFDVCx1QkFBQyxPQUFPLFFBQVAsRUFBMEIsT0FBT0EsRUFBRU4sS0FBTU0sWUFBRW5DLGFBQXhCbUMsRUFBRU4sS0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0Q7QUFBQSxjQUN2RDtBQUFBO0FBQUEsWUFWSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFXQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDZDQUE0QywwQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUU7QUFBQSxVQUN2RSx1QkFBQyxlQUFZLFdBQVUsb0JBQW1CLFVBQVVMLHFCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRTtBQUFBLGFBRnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSw2Q0FBNEMsNkJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBFO0FBQUEsVUFDMUU7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLGFBQVk7QUFBQSxjQUNaLFdBQVU7QUFBQSxjQUNWO0FBQUEsY0FDQSxVQUFVLENBQUNHLFFBQVFuRSxXQUFXLENBQUFrRSxVQUFTLEVBQUUsR0FBR0EsTUFBTS9ELFdBQVdnRSxJQUFJLEVBQUU7QUFBQSxjQUVsRXhFLGlCQUFPaUM7QUFBQUEsZ0JBQUksQ0FBQWdELE1BQ1YsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU9BLEVBQUVQLEtBQU1PLFlBQUVoQyxRQUF4QmdDLEVBQUVQLEtBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlEO0FBQUEsY0FDbEQ7QUFBQTtBQUFBLFlBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0E7QUFBQSxhQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFdBakRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtREEsS0FwREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFEQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNaeEUsc0JBQ0MsdUJBQUMsa0JBQWUsV0FBVyxNQUFNLE1BQUssYUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQyxJQUM3Q1IsUUFBUXdGLFVBQVUsSUFDcEIsdUJBQUMsU0FBTSxhQUFZLDBCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlDLElBRXpDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFNeEY7QUFBQUEsVUFDTjtBQUFBLFVBQ0EsWUFBWXdCO0FBQUFBLFVBQ1osaUJBQWdCO0FBQUEsVUFDYixrQkFBaUI7QUFBQTtBQUFBLFFBTHRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUt5RCxLQVg3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxTQTlFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0VBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTyx1QkFBQyxTQUFJLFdBQVUsbUNBQWtDLDhCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStEO0FBQUEsUUFDdEUsTUFBTVA7QUFBQUEsUUFDTixVQUFVLE1BQU1DLGlCQUFpQixLQUFLO0FBQUEsUUFDdEMsUUFBUTtBQUFBLFFBQ1IsT0FBTztBQUFBLFFBRU5DLDJCQUNDLHVCQUFDLFNBQUksV0FBVSxpQ0FDYjtBQUFBLGlDQUFDLGNBQVcsT0FBTSxjQUFhLE9BQU9BLGNBQWM0QixlQUFlQyxjQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RTtBQUFBLFVBQzlFLHVCQUFDLGNBQVcsT0FBTSxpQkFBZ0IsT0FBTzdCLGNBQWMrQixjQUFjQyxhQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErRTtBQUFBLFVBQy9FLHVCQUFDLGNBQVcsT0FBTSxnQkFBZSxPQUFPdkQsTUFBTXVCLGNBQWN5QixRQUFRLEVBQUVDLE9BQU8sWUFBWSxLQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRjtBQUFBLFVBQzNGLHVCQUFDLGNBQVcsT0FBTSxxQkFBb0IsT0FBTzFCLGNBQWNzRSxxQkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkU7QUFBQSxVQUM3RSx1QkFBQyxjQUFXLE9BQU0saUJBQWdCLE9BQU8sSUFBSXRFLGNBQWNxQyxRQUFRQyxlQUFlLENBQUMsTUFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Y7QUFBQSxVQUN0Rix1QkFBQyxjQUFXLE9BQU0sY0FBYSxPQUFPdEMsY0FBY21DLGVBQWVDLFFBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdFO0FBQUEsVUFDeEUsdUJBQUMsY0FBVyxPQUFNLGVBQWMsT0FBT3BDLGNBQWN1RSxXQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RDtBQUFBLFVBQzdEO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxPQUFNO0FBQUEsY0FDTixPQUFPLHVCQUFDLE9BQUksT0FBTSxTQUFRLDBCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QjtBQUFBO0FBQUEsWUFGeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRStDO0FBQUEsYUFWakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUE7QUFBQSxNQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFzQkE7QUFBQSxPQXpHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMEdBO0FBRUo7QUFBRTNGLEdBL1BJRCxzQkFBb0I7QUFBQTZGLEtBQXBCN0Y7QUFpUU4sTUFBTThGLGFBQWFBLENBQUMsRUFBRUMsT0FBT0MsTUFBTSxNQUNqQyx1QkFBQyxTQUFJLFdBQVUsbURBQ2I7QUFBQSx5QkFBQyxVQUFLLFdBQVUsZ0VBQWdFRCxtQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFzRjtBQUFBLEVBQ3RGLHVCQUFDLFVBQUssV0FBVSx1Q0FBdUNDLG1CQUFTLFNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBc0U7QUFBQSxLQUZ4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BR0E7QUFDQUMsTUFMSUg7QUFPTixlQUFlOUY7QUFBcUIsSUFBQTZGLElBQUFJO0FBQUFDLGFBQUFMLElBQUE7QUFBQUssYUFBQUQsS0FBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiYXBpIiwiRGF0YVRhYmxlIiwiQ2lyY3VsYXJMb2FkZXIiLCJTZWxlY3QiLCJNb2RhbCIsIkFudE1vZGFsIiwiRGF0ZVBpY2tlciIsIlRhZyIsIkVtcHR5IiwiVG9vbHRpcCIsIkZhRmlsZUludm9pY2VEb2xsYXIiLCJGYUV5ZSIsIkZhVXNlclNoaWVsZCIsImRheWpzIiwiUmFuZ2VQaWNrZXIiLCJQcml6ZWRDdXN0b21lclJlcG9ydCIsIl9zIiwicmVwb3J0cyIsInNldFJlcG9ydHMiLCJncm91cHMiLCJzZXRHcm91cHMiLCJ1c2VycyIsInNldFVzZXJzIiwiYWRtaW5zIiwic2V0QWRtaW5zIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwiZmlsdGVycyIsInNldEZpbHRlcnMiLCJncm91cElkIiwidXNlcklkIiwiYWRtaW5UeXBlIiwic3RhcnREYXRlIiwiZW5kRGF0ZSIsInNob3dNb2RhbFZpZXciLCJzZXRTaG93TW9kYWxWaWV3IiwiY3VycmVudFJlcG9ydCIsInNldEN1cnJlbnRSZXBvcnQiLCJjb2x1bW5zIiwia2V5IiwiaGVhZGVyIiwiZXhwb3J0Q29sdW1ucyIsImZldGNoSW5pdGlhbERhdGEiLCJncm91cFJlcyIsInVzZXJSZXMiLCJhZG1pblJlcyIsIlByb21pc2UiLCJhbGwiLCJnZXQiLCJkYXRhIiwiZXJyb3IiLCJjb25zb2xlIiwiZmV0Y2hSZXBvcnREYXRhIiwicGFyYW1zIiwicmVzcG9uc2UiLCJmb3JtYXR0ZWREYXRhIiwibWFwIiwiaXRlbSIsImluZGV4IiwiaWQiLCJwYXlEYXRlIiwicGF5X2RhdGUiLCJmb3JtYXQiLCJncm91cE5hbWUiLCJncm91cF9kZXRhaWxzIiwiZ3JvdXBfbmFtZSIsInVzZXJOYW1lIiwidXNlcl9kZXRhaWxzIiwiZnVsbF9uYW1lIiwidGlja2V0IiwiYWRtaW5OYW1lIiwiYWRtaW5fZGV0YWlscyIsIm5hbWUiLCJhbW91bnQiLCJ0b0xvY2FsZVN0cmluZyIsImFtb3VudFJhdyIsInRyYW5zYWN0aW9uRGF0ZSIsImNyZWF0ZWRBdCIsInNwbGl0Iiwic3RhdHVzIiwic3RhdHVzUmF3IiwiYmFsYW5jZSIsImF1Y3Rpb25zIiwiYmFsYW5jZVJhdyIsInRvdGFsUGFpZEFtb3VudCIsInBheW1lbnRzIiwidG90YWxQYWlkQW1vdW50UmF3IiwidG90YWxQYXlhYmxlIiwidG9fYmVfcGFpZF9hbW91bnQiLCJ0b3RhbFBheWFibGVSYXciLCJzdGF0dXNfcmF3IiwiYWN0aW9uIiwib25EYXRlUmFuZ2VDaGFuZ2UiLCJkYXRlcyIsInByZXYiLCJ2YWwiLCJnIiwiX2lkIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJ1IiwiYSIsImxlbmd0aCIsImRpc2J1cnNlbWVudF90eXBlIiwicGF5X2ZvciIsIl9jIiwiRGV0YWlsSXRlbSIsImxhYmVsIiwidmFsdWUiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUHJpemVkQ3VzdG9tZXJSZXBvcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgTW9kYWwgYXMgQW50TW9kYWwsIERhdGVQaWNrZXIsIFRhZywgRW1wdHksIFRvb2x0aXAgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBGYUZpbGVJbnZvaWNlRG9sbGFyLCBGYUV5ZSwgRmFVc2VyU2hpZWxkIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCBkYXlqcyBmcm9tIFwiZGF5anNcIjtcclxuXHJcbmNvbnN0IHsgUmFuZ2VQaWNrZXIgfSA9IERhdGVQaWNrZXI7XHJcblxyXG5jb25zdCBQcml6ZWRDdXN0b21lclJlcG9ydCA9ICgpID0+IHtcclxuICBjb25zdCBbcmVwb3J0cywgc2V0UmVwb3J0c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2dyb3Vwcywgc2V0R3JvdXBzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYWRtaW5zLCBzZXRBZG1pbnNdID0gdXNlU3RhdGUoW10pOyAvLyBOZXcgc3RhdGUgZm9yIGFkbWluIHR5cGVzXHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBcclxuICBjb25zdCBbZmlsdGVycywgc2V0RmlsdGVyc10gPSB1c2VTdGF0ZSh7XHJcbiAgICBncm91cElkOiBcIlwiLFxyXG4gICAgdXNlcklkOiBcIlwiLFxyXG4gICAgYWRtaW5UeXBlOiBcIlwiLFxyXG4gICAgc3RhcnREYXRlOiBcIlwiLFxyXG4gICAgZW5kRGF0ZTogXCJcIlxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbc2hvd01vZGFsVmlldywgc2V0U2hvd01vZGFsVmlld10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2N1cnJlbnRSZXBvcnQsIHNldEN1cnJlbnRSZXBvcnRdID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcInBheURhdGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0cmFuc2FjdGlvbkRhdGVcIiwgaGVhZGVyOiBcIlRyYW5zYWN0aW9uIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlck5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBOYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInRpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0XCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsUGFpZEFtb3VudFwiLCBoZWFkZXI6IFwiVG90YWwgUGFpZCBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxQYXlhYmxlXCIsIGhlYWRlcjogXCJUb3RhbCBQYXlhYmxlXCIgfSxcclxuICAgIHsga2V5OiBcImJhbGFuY2VcIiwgaGVhZGVyOiBcIkJhbGFuY2VcIiB9LFxyXG4gICAgXHJcbiAgICB7IGtleTogXCJhbW91bnRcIiwgaGVhZGVyOiBcIlBheW91dCBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWRtaW5OYW1lXCIsIGhlYWRlcjogXCJIYW5kbGVkIEJ5XCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCBleHBvcnRDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJwYXlEYXRlXCIsIGhlYWRlcjogXCJQYXltZW50IERhdGVcIiB9LFxyXG4gICAgICAgeyBrZXk6IFwidHJhbnNhY3Rpb25EYXRlXCIsIGhlYWRlcjogXCJUcmFuc2FjdGlvbiBEYXRlXCIgfSxcclxuICAgICAgIHsga2V5OiBcInVzZXJOYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwTmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwiIH0sXHJcbiAgICB7IGtleTogXCJ0b3RhbFBheWFibGVSYXdcIiwgaGVhZGVyOiBcIlRvdGFsIFBheWFibGVcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxQYWlkQW1vdW50UmF3XCIsIGhlYWRlcjogXCJUb3RhbCBQYWlkIEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJiYWxhbmNlUmF3XCIsIGhlYWRlcjogXCJCYWxhbmNlXCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudFJhd1wiLCBoZWFkZXI6IFwiUGF5b3V0IEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJzdGF0dXNSYXdcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgICB7IGtleTogXCJhZG1pbk5hbWVcIiwgaGVhZGVyOiBcIkhhbmRsZWQgQnlcIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGZldGNoSW5pdGlhbERhdGEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgIFxyXG4gICAgICBjb25zdCBbZ3JvdXBSZXMsIHVzZXJSZXMsIGFkbWluUmVzXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICBhcGkuZ2V0KFwiL2dyb3VwL2dldC1ncm91cC1hZG1pblwiKSxcclxuICAgICAgICBhcGkuZ2V0KFwidXNlci92ZXJpZmllZFwiKSxcclxuICAgICAgICBhcGkuZ2V0KFwiL2FkbWluL2dldC1zdWItYWRtaW5zXCIpIFxyXG4gICAgICBdKTtcclxuICAgICAgc2V0R3JvdXBzKGdyb3VwUmVzLmRhdGEgfHwgW10pO1xyXG4gICAgICBzZXRVc2Vycyh1c2VyUmVzLmRhdGE/LmRhdGEgfHwgW10pO1xyXG4gICAgICBzZXRBZG1pbnMoYWRtaW5SZXMuZGF0YSB8fCBbXSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgaW5pdGlhbCBkYXRhXCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaFJlcG9ydERhdGEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBwYXJhbXMgPSB7fTtcclxuICAgICAgaWYgKGZpbHRlcnMuZ3JvdXBJZCkgcGFyYW1zLmdyb3VwSWQgPSBmaWx0ZXJzLmdyb3VwSWQ7XHJcbiAgICAgIGlmIChmaWx0ZXJzLnVzZXJJZCkgcGFyYW1zLnVzZXJJZCA9IGZpbHRlcnMudXNlcklkO1xyXG4gICAgICBpZiAoZmlsdGVycy5hZG1pblR5cGUpIHBhcmFtcy5hZG1pblR5cGUgPSBmaWx0ZXJzLmFkbWluVHlwZTtcclxuICAgICAgaWYgKGZpbHRlcnMuc3RhcnREYXRlKSBwYXJhbXMuc3RhcnREYXRlID0gZmlsdGVycy5zdGFydERhdGU7XHJcbiAgICAgIGlmIChmaWx0ZXJzLmVuZERhdGUpIHBhcmFtcy5lbmREYXRlID0gZmlsdGVycy5lbmREYXRlO1xyXG5cclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3BheW1lbnQtb3V0L3ByaXplZFwiLCB7IHBhcmFtcyB9KTtcclxuXHJcbiAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEuZGF0YSkge1xyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLmRhdGEubWFwKChpdGVtLCBpbmRleCkgPT4gKHtcclxuICAgICAgICAgIC4uLml0ZW0sXHJcbiAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgcGF5RGF0ZTogaXRlbS5wYXlfZGF0ZSA/IGRheWpzKGl0ZW0ucGF5X2RhdGUpLmZvcm1hdChcIllZWVktTU0tRERcIikgOiBcIk4vQVwiLFxyXG4gICAgICAgICAgZ3JvdXBOYW1lOiBpdGVtLmdyb3VwX2RldGFpbHM/Lmdyb3VwX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIHVzZXJOYW1lOiBpdGVtLnVzZXJfZGV0YWlscz8uZnVsbF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICB0aWNrZXQ6IGl0ZW0udGlja2V0LFxyXG4gICAgICAgICAgYWRtaW5OYW1lOiBpdGVtLmFkbWluX2RldGFpbHM/Lm5hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIGFtb3VudDogYOKCuSR7aXRlbS5hbW91bnQ/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgICAgICAgIGFtb3VudFJhdzogaXRlbS5hbW91bnQsXHJcbiAgICAgICAgICB0cmFuc2FjdGlvbkRhdGU6aXRlbS5jcmVhdGVkQXQgPyBgJHtpdGVtLmNyZWF0ZWRBdC5zcGxpdChcIlRcIilbMF19YCA6XCJcIixcclxuICAgICAgICAgIHN0YXR1czogPFRhZyBjb2xvcj1cImdyZWVuXCI+UEFJRDwvVGFnPixcclxuICAgICAgICAgIHN0YXR1c1JhdzogXCJQQUlEXCIsXHJcbiAgICAgICAgICBiYWxhbmNlOiBgJHtpdGVtLmF1Y3Rpb25zPy5iYWxhbmNlPy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWAsXHJcbiAgICAgICAgICBiYWxhbmNlUmF3OiBpdGVtLmF1Y3Rpb25zPy5iYWxhbmNlLFxyXG4gICAgICAgICAgdG90YWxQYWlkQW1vdW50OiBgJHtpdGVtPy5wYXltZW50cz8udG90YWxQYWlkQW1vdW50Py50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpIHx8IDB9YCxcclxuICAgICAgICAgIHRvdGFsUGFpZEFtb3VudFJhdzogaXRlbT8ucGF5bWVudHM/LnRvdGFsUGFpZEFtb3VudCB8fCAwLFxyXG4gICAgICAgICAgdG90YWxQYXlhYmxlIDogYCR7aXRlbT8uYXVjdGlvbnM/LnRvX2JlX3BhaWRfYW1vdW50Py50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpIHx8IDB9YCxcclxuICAgICAgICAgIHRvdGFsUGF5YWJsZVJhdyA6IGl0ZW0/LmF1Y3Rpb25zPy50b19iZV9wYWlkX2Ftb3VudCB8fCAwLFxyXG5cclxuICAgICAgICAgIHN0YXR1c19yYXc6IFwiUGFpZFwiLFxyXG4gICAgICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxUb29sdGlwIHRpdGxlPVwiVmlldyBSZWNlaXB0XCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRDdXJyZW50UmVwb3J0KGl0ZW0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFNob3dNb2RhbFZpZXcodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiBiZy12aW9sZXQtNTAgdGV4dC12aW9sZXQtNjAwIHJvdW5kZWQtZnVsbCBob3ZlcjpiZy12aW9sZXQtMTAwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPEZhRXllIC8+XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L1Rvb2x0aXA+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSxcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgc2V0UmVwb3J0cyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgc2V0UmVwb3J0cyhbXSk7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyByZXBvcnQ6XCIsIGVycm9yKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoSW5pdGlhbERhdGEoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaFJlcG9ydERhdGEoKTtcclxuICB9LCBbZmlsdGVyc10pO1xyXG5cclxuICBjb25zdCBvbkRhdGVSYW5nZUNoYW5nZSA9IChkYXRlcykgPT4ge1xyXG4gICAgaWYgKGRhdGVzKSB7XHJcbiAgICAgIHNldEZpbHRlcnMocHJldiA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgc3RhcnREYXRlOiBkYXRlc1swXS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpLFxyXG4gICAgICAgIGVuZERhdGU6IGRhdGVzWzFdLmZvcm1hdChcIllZWVktTU0tRERcIilcclxuICAgICAgfSkpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0RmlsdGVycyhwcmV2ID0+ICh7IC4uLnByZXYsIHN0YXJ0RGF0ZTogXCJcIiwgZW5kRGF0ZTogXCJcIiB9KSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtNyBiZy1ncmF5LTUwIG1pbi1oLXNjcmVlblwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTZcIj5cclxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgPEZhRmlsZUludm9pY2VEb2xsYXIgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtOTAwXCIgLz4gUHJpemVkIEN1c3RvbWVyIFJlcG9ydFxyXG4gICAgICAgICAgPC9oMT5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIEZpbHRlciBTZWN0aW9uICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC02IHJvdW5kZWQteGwgc2hhZG93LXNtIG1iLTggYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC00XCI+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPkdyb3VwPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFsbCBHcm91cHNcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTAgbXQtMVwiXHJcbiAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4gc2V0RmlsdGVycyhwcmV2ID0+ICh7IC4uLnByZXYsIGdyb3VwSWQ6IHZhbCB9KSl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge2dyb3Vwcy5tYXAoZyA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Zy5faWR9IHZhbHVlPXtnLl9pZH0+e2cuZ3JvdXBfbmFtZX08L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPkN1c3RvbWVyPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFsbCBDdXN0b21lcnNcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTAgbXQtMVwiXHJcbiAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PiBvcHRpb24uY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiBzZXRGaWx0ZXJzKHByZXYgPT4gKHsgLi4ucHJldiwgdXNlcklkOiB2YWwgfSkpfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAodSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dS5faWR9IHZhbHVlPXt1Ll9pZH0+e3UuZnVsbF9uYW1lfTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+RGF0ZSBSYW5nZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFJhbmdlUGlja2VyIGNsYXNzTmFtZT1cInctZnVsbCBoLTEwIG10LTFcIiBvbkNoYW5nZT17b25EYXRlUmFuZ2VDaGFuZ2V9IC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5BZG1pbiAvIFN0YWZmPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkZpbHRlcmVkIGJ5IEFkbWluXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEwIG10LTFcIlxyXG4gICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IHNldEZpbHRlcnMocHJldiA9PiAoeyAuLi5wcmV2LCBhZG1pblR5cGU6IHZhbCB9KSl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge2FkbWlucy5tYXAoYSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17YS5faWR9IHZhbHVlPXthLl9pZH0+e2EubmFtZX08L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBUYWJsZSBTZWN0aW9uICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctc20gcC00XCI+XHJcbiAgICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXt0cnVlfSBkYXRhPVwiUmVwb3J0c1wiIC8+XHJcbiAgICAgICAgICApIDogcmVwb3J0cy5sZW5ndGggPD0gMCA/IChcclxuICAgICAgICAgICAgPEVtcHR5IGRlc2NyaXB0aW9uPVwiTm8gUGF5b3V0IERhdGEgRm91bmRcIiAvPlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgIGRhdGE9e3JlcG9ydHN9XHJcbiAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICBleHBvcnRDb2xzPXtleHBvcnRDb2x1bW5zfVxyXG4gICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIlByaXplZF9DdXN0b21lcl9QYXlvdXRfUmVwb3J0XCJcclxuICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiUHJpemVkX0N1c3RvbWVyX1BheW91dF9SZXBvcnQuY3N2XCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIERldGFpbHMgTW9kYWwgKi99XHJcbiAgICAgIDxBbnRNb2RhbFxyXG4gICAgICAgIHRpdGxlPXs8ZGl2IGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIGJvcmRlci1iIHBiLTJcIj5QYXlvdXQgRGV0YWlsczwvZGl2Pn1cclxuICAgICAgICBvcGVuPXtzaG93TW9kYWxWaWV3fVxyXG4gICAgICAgIG9uQ2FuY2VsPXsoKSA9PiBzZXRTaG93TW9kYWxWaWV3KGZhbHNlKX1cclxuICAgICAgICBmb290ZXI9e251bGx9XHJcbiAgICAgICAgd2lkdGg9ezYwMH1cclxuICAgICAgPlxyXG4gICAgICAgIHtjdXJyZW50UmVwb3J0ICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAteS00IHB5LTRcIj5cclxuICAgICAgICAgICAgPERldGFpbEl0ZW0gbGFiZWw9XCJHcm91cCBOYW1lXCIgdmFsdWU9e2N1cnJlbnRSZXBvcnQuZ3JvdXBfZGV0YWlscz8uZ3JvdXBfbmFtZX0gLz5cclxuICAgICAgICAgICAgPERldGFpbEl0ZW0gbGFiZWw9XCJDdXN0b21lciBOYW1lXCIgdmFsdWU9e2N1cnJlbnRSZXBvcnQudXNlcl9kZXRhaWxzPy5mdWxsX25hbWV9IC8+XHJcbiAgICAgICAgICAgIDxEZXRhaWxJdGVtIGxhYmVsPVwiUGF5bWVudCBEYXRlXCIgdmFsdWU9e2RheWpzKGN1cnJlbnRSZXBvcnQucGF5X2RhdGUpLmZvcm1hdChcIkRELU1NLVlZWVlcIil9IC8+XHJcbiAgICAgICAgICAgIDxEZXRhaWxJdGVtIGxhYmVsPVwiRGlzYnVyc2VtZW50IFR5cGVcIiB2YWx1ZT17Y3VycmVudFJlcG9ydC5kaXNidXJzZW1lbnRfdHlwZX0gLz5cclxuICAgICAgICAgICAgPERldGFpbEl0ZW0gbGFiZWw9XCJQYXlvdXQgQW1vdW50XCIgdmFsdWU9e2Digrkke2N1cnJlbnRSZXBvcnQuYW1vdW50Py50b0xvY2FsZVN0cmluZygpfWB9IC8+XHJcbiAgICAgICAgICAgIDxEZXRhaWxJdGVtIGxhYmVsPVwiSGFuZGxlZCBCeVwiIHZhbHVlPXtjdXJyZW50UmVwb3J0LmFkbWluX2RldGFpbHM/Lm5hbWV9IC8+XHJcbiAgICAgICAgICAgIDxEZXRhaWxJdGVtIGxhYmVsPVwiUGF5bWVudCBGb3JcIiB2YWx1ZT17Y3VycmVudFJlcG9ydC5wYXlfZm9yfSAvPlxyXG4gICAgICAgICAgICA8RGV0YWlsSXRlbSBcclxuICAgICAgICAgICAgICAgIGxhYmVsPVwiU3RhdHVzXCIgXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17PFRhZyBjb2xvcj1cImdyZWVuXCI+U1VDQ0VTU0ZVTDwvVGFnPn0gXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L0FudE1vZGFsPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmNvbnN0IERldGFpbEl0ZW0gPSAoeyBsYWJlbCwgdmFsdWUgfSkgPT4gKFxyXG4gIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBib3JkZXItYiBib3JkZXItZ3JheS01MCBwYi0yIG1yLTRcIj5cclxuICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPntsYWJlbH08L3NwYW4+XHJcbiAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPnt2YWx1ZSB8fCBcIk4vQVwifTwvc3Bhbj5cclxuICA8L2Rpdj5cclxuKTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFByaXplZEN1c3RvbWVyUmVwb3J0OyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9Qcml6ZWRDdXN0b21lclJlcG9ydC5qc3gifQ==