import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/BulkChitPaymentLink.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useRef = __vite__cjsImport3_react["useRef"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import Modal from "/src/components/modals/Modal.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Select, Dropdown, notification, Alert } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import __vite__cjsImport14_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport14_dayjs.__esModule ? __vite__cjsImport14_dayjs.default : __vite__cjsImport14_dayjs;
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const BulkChitPaymentLink = () => {
  _s();
  const [groups, setGroups] = useState([]);
  const [users, setUsers] = useState([]);
  const [TableEnrolls, setTableEnrolls] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState("");
  const [loading, setLoading] = useState(false);
  const [isDataTableLoading, setIsDataTableLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [selectedEnrollments, setSelectedEnrollments] = useState([]);
  const [selectAll, setSelectAll] = useState(false);
  const [showPaymentLinkModal, setShowPaymentLinkModal] = useState(false);
  const [paymentLinkForm, setPaymentLinkForm] = useState({
    amount: "",
    expiry: dayjs().add(1, "day").format("YYYY-MM-DD"),
    send_sms: true,
    send_email: true
  });
  const [paymentLinkErrors, setPaymentLinkErrors] = useState({});
  const [alert, setAlert] = useState({
    visible: false,
    message: "",
    type: "info"
  });
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [admin, setAdmin] = useState("");
  const date = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const [allEnrollUrl, setAllEnrollUrl] = useState(true);
  const [leads, setLeads] = useState([]);
  const [agents, setAgents] = useState([]);
  const selectAllCheckboxRef = useRef(null);
  const GlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    const adminId = userObj?._id;
    if (adminId) {
      setAdmin(userObj?._id);
    } else {
      setAdmin("");
    }
  }, []);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setGroups(response.data);
      } catch (error) {
        console.error("Error fetching group ", error);
      }
    };
    fetchGroups();
  }, []);
  useEffect(() => {
    async function fetchAllEnrollmentData() {
      setAllEnrollUrl(true);
      let url = `/enroll-report/get-enroll-report?from_date=${date}&to_date=${date}`;
      try {
        setTableEnrolls([]);
        setIsDataTableLoading(true);
        const response = await api.get(url);
        if (response.data && response.data.length > 0) {
          setFilteredUsers(response.data);
          const formattedData = response.data.map((group, index) => {
            if (!group?.group_id || !group?.user_id) return {};
            return {
              select: /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  checked: selectedEnrollments.includes(group._id),
                  onChange: (e) => handleEnrollmentSelect(group._id, e),
                  className: "form-checkbox h-4 w-4 text-violet-600"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                  lineNumber: 96,
                  columnNumber: 15
                },
                this
              ),
              _id: group?._id,
              id: index + 1,
              name: group?.user_id?.full_name,
              phone_number: group?.user_id?.phone_number,
              group_name: group?.group_id?.group_name,
              payment_type: group?.payment_type,
              enrollment_date: group?.createdAt ? group?.createdAt?.split("T")[0] : "",
              chit_asking_month: group?.chit_asking_month,
              referred_type: group?.referred_type,
              referred_by: group?.agent?.name && group?.agent?.phone_number ? `${group.agent.name} | ${group.agent.phone_number}` : group?.referred_customer?.full_name && group?.referred_customer?.phone_number ? `${group.referred_customer.full_name} | ${group?.referred_customer?.phone_number}` : group?.referred_lead?.lead_name && group?.referred_lead?.agent_number ? `${group.referred_lead.lead_name} | ${group.referred_lead.agent_number}` : "N/A",
              ticket: group.tickets,
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  menu: {
                    items: [
                      {
                        key: "1",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-green-600",
                            onClick: () => handleViewDetails(group._id),
                            children: "View Details"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                            lineNumber: 133,
                            columnNumber: 23
                          },
                          this
                        )
                      }
                    ]
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                    lineNumber: 145,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                  lineNumber: 127,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                lineNumber: 126,
                columnNumber: 15
              }, this)
            };
          });
          setTableEnrolls(formattedData);
        } else {
          setFilteredUsers([]);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredUsers([]);
        setTableEnrolls([]);
        setAlert({
          visible: true,
          message: "Failed to load enrollment data",
          type: "error"
        });
      } finally {
        setIsDataTableLoading(false);
      }
    }
    fetchAllEnrollmentData();
  }, []);
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await api.get("/user/get-user");
        setUsers(response.data);
      } catch (error) {
        console.error("Error fetching user ", error);
      }
    };
    fetchUsers();
  }, []);
  useEffect(() => {
    const fetchAgents = async () => {
      try {
        const response = await api.get("/agent/get-agent");
        setAgents(response.data);
      } catch (err) {
        console.error("Failed to fetch Agents", err);
      }
    };
    fetchAgents();
  }, []);
  useEffect(() => {
    const fetchLeads = async () => {
      try {
        const response = await api.get("/lead/get-lead");
        setLeads(response.data);
      } catch (err) {
        console.error("Failed to fetch Leads", err);
      }
    };
    fetchLeads();
  }, []);
  useEffect(() => {
    if (TableEnrolls.length === 0) {
      setSelectAll(false);
      return;
    }
    const allVisibleSelected = TableEnrolls.every(
      (enroll) => selectedEnrollments.includes(enroll._id)
    );
    setSelectAll(allVisibleSelected);
  }, [TableEnrolls, selectedEnrollments]);
  useEffect(() => {
    if (selectAllCheckboxRef.current) {
      const totalVisible = TableEnrolls.length;
      const selectedCount = selectedEnrollments.filter(
        (id) => TableEnrolls.some((enroll) => enroll._id === id)
      ).length;
      selectAllCheckboxRef.current.indeterminate = selectedCount > 0 && selectedCount < totalVisible;
    }
  }, [selectedEnrollments, TableEnrolls]);
  const handleGroupChange = async (groupId) => {
    setSelectedGroup(groupId);
    if (groupId) {
      let url;
      if (groupId === "today") {
        url = `/enroll-report/get-enroll-report?from_date=${date}&to_date=${date}`;
        setAllEnrollUrl(true);
      } else {
        url = `/enroll/get-group-enroll/${groupId}`;
        setAllEnrollUrl(false);
      }
      try {
        setTableEnrolls([]);
        setIsDataTableLoading(true);
        const response = await api.get(url);
        if (response.data && response.data.length > 0) {
          setFilteredUsers(response.data);
          const formattedData = response.data.map((group, index) => {
            if (!group?.group_id || !group?.user_id) return {};
            return {
              select: /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  checked: selectedEnrollments.includes(group._id),
                  onChange: (e) => handleEnrollmentSelect(group._id, e),
                  className: "form-checkbox h-4 w-4 text-violet-600"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                  lineNumber: 253,
                  columnNumber: 15
                },
                this
              ),
              _id: group?._id,
              id: index + 1,
              name: group?.user_id?.full_name,
              phone_number: group?.user_id?.phone_number,
              group_name: group?.group_id?.group_name,
              payment_type: group?.payment_type,
              enrollment_date: group?.createdAt?.split("T")[0],
              chit_asking_month: group?.chit_asking_month,
              referred_type: group?.referred_type,
              referred_by: group?.agent?.name && group?.agent?.phone_number ? `${group.agent.name} | ${group.agent.phone_number}` : group?.referred_customer?.full_name && group?.referred_customer?.phone_number ? `${group.referred_customer.full_name} | ${group?.referred_customer?.phone_number}` : group?.referred_lead?.lead_name && group?.referred_lead?.agent_number ? `${group.referred_lead.lead_name} | ${group.referred_lead.agent_number}` : "N/A",
              ticket: group.tickets,
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  menu: {
                    items: [
                      {
                        key: "1",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-green-600",
                            onClick: () => handleViewDetails(group._id),
                            children: "View Details"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                            lineNumber: 288,
                            columnNumber: 23
                          },
                          this
                        )
                      }
                    ]
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                    lineNumber: 300,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                  lineNumber: 282,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                lineNumber: 281,
                columnNumber: 15
              }, this)
            };
          });
          setTableEnrolls(formattedData);
        } else {
          setFilteredUsers([]);
          setTableEnrolls([]);
        }
      } catch (error) {
        console.error("Error fetching enrollment ", error);
        setFilteredUsers([]);
        setTableEnrolls([]);
      } finally {
        setIsDataTableLoading(false);
      }
    } else {
      setFilteredUsers([]);
      setTableEnrolls([]);
    }
  };
  const handleSelectAll = (e) => {
    if (e.target.checked) {
      const allIds = TableEnrolls.map((enroll) => enroll._id);
      setSelectedEnrollments(allIds);
    } else {
      setSelectedEnrollments([]);
    }
  };
  const handleEnrollmentSelect = (id) => {
    setSelectedEnrollments(
      (prev) => prev.includes(id) ? prev.filter((en) => en !== id) : [...prev, id]
    );
  };
  const handleViewDetails = async (enrollmentId) => {
    try {
      const response = await api.get(`/enroll/get-enroll-by-id/${enrollmentId}`);
      const enrollment = response.data;
      notification.info({
        message: "Enrollment Details",
        description: /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "Customer:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
              lineNumber: 352,
              columnNumber: 16
            }, this),
            " ",
            enrollment.user_id?.full_name
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
            lineNumber: 352,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "Phone:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
              lineNumber: 353,
              columnNumber: 16
            }, this),
            " ",
            enrollment.user_id?.phone_number
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
            lineNumber: 353,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "Group:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
              lineNumber: 354,
              columnNumber: 16
            }, this),
            " ",
            enrollment.group_id?.group_name
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
            lineNumber: 354,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "Ticket:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
              lineNumber: 355,
              columnNumber: 16
            }, this),
            " ",
            enrollment.tickets
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
            lineNumber: 355,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "Payment Type:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
              lineNumber: 356,
              columnNumber: 16
            }, this),
            " ",
            enrollment.payment_type
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
            lineNumber: 356,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "Enrollment Date:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
              lineNumber: 357,
              columnNumber: 16
            }, this),
            " ",
            new Date(enrollment.createdAt).toLocaleDateString()
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
            lineNumber: 357,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
          lineNumber: 351,
          columnNumber: 9
        }, this),
        duration: 5
      });
    } catch (error) {
      console.error("Error fetching enrollment details:", error);
      notification.error({
        message: "Error",
        description: "Failed to fetch enrollment details"
      });
    }
  };
  const handleOpenPaymentLinkModal = () => {
    if (selectedEnrollments.length === 0) {
      notification.warning({
        message: "No Selection",
        description: "Please select at least one enrollment to create payment links"
      });
      return;
    }
    setShowPaymentLinkModal(true);
  };
  const handlePaymentLinkChange = (e) => {
    const { name, value, type, checked } = e.target;
    setPaymentLinkForm((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
    setPaymentLinkErrors((prev) => ({
      ...prev,
      [name]: ""
    }));
  };
  const validatePaymentLinkForm = () => {
    const errors = {};
    const amount = parseFloat(paymentLinkForm.amount);
    if (!paymentLinkForm.amount || isNaN(amount) || amount <= 0) {
      errors.amount = "Please enter a valid positive amount";
    }
    setPaymentLinkErrors(errors);
    return Object.keys(errors).length === 0;
  };
  const handlePaymentLinkSubmit = async (e) => {
    e.preventDefault();
    if (!validatePaymentLinkForm()) {
      return;
    }
    try {
      setLoading(true);
      const selectedDetails = TableEnrolls.filter(
        (enroll) => selectedEnrollments.includes(enroll._id)
      );
      const payloads = selectedDetails.map((enrollment) => ({
        user_id: enrollment.user_id,
        group_id: enrollment.group_id?._id,
        ticket: enrollment.ticket,
        amount: parseFloat(paymentLinkForm.amount),
        expiry: paymentLinkForm.expiry,
        send_sms: paymentLinkForm.send_sms,
        send_email: paymentLinkForm.send_email,
        payment_group_tickets: [
          `chit-${enrollment.group_id?._id}|${enrollment.ticket}`
        ]
      }));
      const results = [];
      for (const payload of payloads) {
        try {
          const response = await api.post("/paymentapi/payment-link", payload);
          results.push({ success: true, enrollment: payload, response });
        } catch (error) {
          results.push({ success: false, enrollment: payload, error });
        }
      }
      const successCount = results.filter((r) => r.success).length;
      const failureCount = results.length - successCount;
      if (successCount > 0) {
        setAlert({
          visible: true,
          message: `Successfully created ${successCount} payment link${successCount > 1 ? "s" : ""}`,
          type: "success"
        });
        setSelectAll(false);
        setSelectedEnrollments([]);
        setShowPaymentLinkModal(false);
        setPaymentLinkForm({
          amount: "",
          expiry: dayjs().add(1, "day").format("YYYY-MM-DD"),
          send_sms: true,
          send_email: true
        });
      }
      if (failureCount > 0) {
        notification.error({
          message: "Payment Link Creation",
          description: `Failed to create ${failureCount} payment link${failureCount > 1 ? "s" : ""}`
        });
      }
    } catch (error) {
      console.error("Error creating payment links:", error);
      setAlert({
        visible: true,
        message: "Error creating payment links",
        type: "error"
      });
    } finally {
      setLoading(false);
    }
  };
  const columns = [
    {
      key: "select",
      header: /* @__PURE__ */ jsxDEV(
        "input",
        {
          ref: selectAllCheckboxRef,
          type: "checkbox",
          checked: selectedEnrollments.length === TableEnrolls.length && TableEnrolls.length > 0,
          onChange: handleSelectAll,
          className: "form-checkbox h-4 w-4 text-violet-600"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
          lineNumber: 487,
          columnNumber: 5
        },
        this
      ),
      render: (row) => /* @__PURE__ */ jsxDEV("div", { className: selectedEnrollments.includes(row._id) ? "bg-violet-100" : "", children: /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "checkbox",
          checked: selectedEnrollments.includes(row._id),
          onChange: () => handleEnrollmentSelect(row._id),
          className: "form-checkbox h-4 w-4 text-violet-600"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
          lineNumber: 497,
          columnNumber: 7
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
        lineNumber: 496,
        columnNumber: 5
      }, this)
    },
    { key: "id", header: "SL. NO" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Customer Phone Number" }
  ];
  if (allEnrollUrl) {
    columns.push({ key: "group_name", header: "Enrolled Group" });
  }
  columns.push(
    { key: "ticket", header: "Ticket Number" },
    { key: "referred_type", header: "Referred Type" },
    { key: "payment_type", header: "Payment Type" },
    { key: "enrollment_date", header: "Enrollment Date" },
    { key: "chit_asking_month", header: "Chit Asking Month" },
    { key: "referred_by", header: "Referred By" },
    { key: "action", header: "Action" }
  );
  const selectednewGroup = groups.find((g) => g._id === selectedGroup);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
        lineNumber: 532,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: GlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
          lineNumber: 533,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
          lineNumber: 537,
          columnNumber: 11
        },
        this
      ),
      alert.visible && /* @__PURE__ */ jsxDEV("div", { className: "fixed top-4 right-4 z-50 w-96", children: /* @__PURE__ */ jsxDEV(
        Alert,
        {
          message: alert.message,
          type: alert.type,
          showIcon: true,
          closable: true,
          onClose: () => setAlert({ ...alert, visible: false })
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
          lineNumber: 548,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
        lineNumber: 547,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
          lineNumber: 559,
          columnNumber: 16
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Bulk Payment Link" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
          lineNumber: 560,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: /* @__PURE__ */ jsxDEV("label", { children: "Search or Select Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
            lineNumber: 563,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
            lineNumber: 562,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full mb-4", children: [
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                popupMatchSelectWidth: false,
                value: selectedGroup || "today",
                filterOption: (input, option) => option.children?.toString()?.toLowerCase().includes(input?.toLowerCase()),
                placeholder: "Search or Select Group",
                onChange: handleGroupChange,
                className: "border h-14   w-full max-w-md",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "today", children: "Today's Enrollment" }, "today", false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                    lineNumber: 579,
                    columnNumber: 19
                  }, this),
                  groups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                      lineNumber: 583,
                      columnNumber: 19
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                lineNumber: 566,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: selectedEnrollments.length > 0 && /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: handleOpenPaymentLinkModal,
                className: "bg-violet-600 text-white px-4 py-2 rounded hover:bg-violet-700",
                children: [
                  "Add Payment Link (",
                  selectedEnrollments.length,
                  ")"
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                lineNumber: 590,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
              lineNumber: 588,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
            lineNumber: 565,
            columnNumber: 15
          }, this),
          TableEnrolls?.length > 0 ? /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: filterOption(TableEnrolls, searchText),
              columns,
              exportedFileName: `Enrollments-${TableEnrolls.length > 0 ? TableEnrolls[0].name + " to " + TableEnrolls[TableEnrolls.length - 1].name : "empty"}.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
              lineNumber: 601,
              columnNumber: 15
            },
            this
          ) : /* @__PURE__ */ jsxDEV(
            CircularLoader,
            {
              isLoading: isDataTableLoading,
              failure: TableEnrolls?.length <= 0 && selectedGroup,
              data: "Enrollment Data"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
              lineNumber: 613,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
          lineNumber: 561,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
        lineNumber: 558,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
      lineNumber: 531,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showPaymentLinkModal,
        onClose: () => {
          setShowPaymentLinkModal(false);
          setPaymentLinkErrors({});
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-6 text-xl font-bold text-gray-900 border-b pb-2", children: "Create Payment Links" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
            lineNumber: 631,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-4 p-3 bg-violet-50 rounded", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-violet-700", children: [
              "Creating payment links for ",
              selectedEnrollments.length,
              " selected enrollment",
              selectedEnrollments.length > 1 ? "s" : ""
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
              lineNumber: 636,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-2 max-h-40 overflow-y-auto", children: TableEnrolls.filter((enroll) => selectedEnrollments.includes(enroll._id)).map(
              (enrollment, index) => /* @__PURE__ */ jsxDEV("div", { className: "text-sm py-1 border-b border-violet-100 last:border-0", children: [
                enrollment.name,
                " | ",
                enrollment.phone_number,
                " | ",
                enrollment.group_name,
                " | Ticket ",
                enrollment.ticket
              ] }, index, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                lineNumber: 641,
                columnNumber: 17
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
              lineNumber: 639,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
            lineNumber: 635,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-5", onSubmit: handlePaymentLinkSubmit, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 font-medium text-gray-700", children: [
                "Amount ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                  lineNumber: 651,
                  columnNumber: 26
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                lineNumber: 650,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "number",
                  name: "amount",
                  value: paymentLinkForm.amount,
                  onChange: handlePaymentLinkChange,
                  placeholder: "Enter amount",
                  className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-violet-500",
                  min: "0.01",
                  step: "0.01"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                  lineNumber: 653,
                  columnNumber: 17
                },
                this
              ),
              paymentLinkErrors.amount && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: paymentLinkErrors.amount }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                lineNumber: 664,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
              lineNumber: 649,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 font-medium text-gray-700", children: "Expiry Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                lineNumber: 669,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  name: "expiry",
                  value: paymentLinkForm.expiry,
                  min: dayjs().format("YYYY-MM-DD"),
                  onChange: handlePaymentLinkChange,
                  className: "w-full px-3 py-2 border border-gray-300 rounded-md"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                  lineNumber: 672,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
              lineNumber: 668,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    id: "send_sms",
                    type: "checkbox",
                    name: "send_sms",
                    checked: paymentLinkForm.send_sms,
                    onChange: handlePaymentLinkChange,
                    className: "h-4 w-4 text-violet-600"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                    lineNumber: 684,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("label", { htmlFor: "send_sms", className: "ml-2 text-sm text-gray-700", children: "Send SMS" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                  lineNumber: 692,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                lineNumber: 683,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    id: "send_email",
                    type: "checkbox",
                    name: "send_email",
                    checked: paymentLinkForm.send_email,
                    onChange: handlePaymentLinkChange,
                    className: "h-4 w-4 text-violet-600"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                    lineNumber: 698,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("label", { htmlFor: "send_email", className: "ml-2 text-sm text-gray-700", children: "Send Email" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                  lineNumber: 706,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                lineNumber: 697,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
              lineNumber: 682,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-4", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                disabled: loading,
                className: `px-5 py-2.5 rounded-lg font-medium transition-colors ${loading ? "bg-gray-400 cursor-not-allowed" : "bg-violet-950 text-white hover:bg-violet-800"}`,
                children: loading ? "Creating..." : "Create Payment Links"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
                lineNumber: 713,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
              lineNumber: 712,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
            lineNumber: 648,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
          lineNumber: 630,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
        lineNumber: 623,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
    lineNumber: 529,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx",
    lineNumber: 528,
    columnNumber: 5
  }, this);
};
_s(BulkChitPaymentLink, "+znMevIf5yb3YXQurYcbRhKOwzA=");
_c = BulkChitPaymentLink;
export default BulkChitPaymentLink;
var _c;
$RefreshReg$(_c, "BulkChitPaymentLink");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BulkChitPaymentLink.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0ZnQixTQWdiWixVQWhiWTsyQkEvRmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsVUFBVUMsY0FBYztBQUM1QyxPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxlQUFlO0FBQ3RCLFNBQVNDLFFBQVFDLFVBQVVDLGNBQWNDLGFBQWE7QUFDdEQsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxnQkFBZ0I7QUFFdkIsTUFBTUMsc0JBQXNCQSxNQUFNO0FBQUFDLEtBQUE7QUFDaEMsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUlwQixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDcUIsT0FBT0MsUUFBUSxJQUFJdEIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ3VCLGNBQWNDLGVBQWUsSUFBSXhCLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUN5QixlQUFlQyxnQkFBZ0IsSUFBSTFCLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUMyQixlQUFlQyxnQkFBZ0IsSUFBSTVCLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUM2QixTQUFTQyxVQUFVLElBQUk5QixTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDK0Isb0JBQW9CQyxxQkFBcUIsSUFBSWhDLFNBQVMsS0FBSztBQUNsRSxRQUFNLENBQUNpQyxZQUFZQyxhQUFhLElBQUlsQyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDbUMscUJBQXFCQyxzQkFBc0IsSUFBSXBDLFNBQVMsRUFBRTtBQUNqRSxRQUFNLENBQUNxQyxXQUFXQyxZQUFZLElBQUl0QyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDdUMsc0JBQXNCQyx1QkFBdUIsSUFBSXhDLFNBQVMsS0FBSztBQUN0RSxRQUFNLENBQUN5QyxpQkFBaUJDLGtCQUFrQixJQUFJMUMsU0FBUztBQUFBLElBQ3JEMkMsUUFBUTtBQUFBLElBQ1JDLFFBQVE3QixNQUFNLEVBQUU4QixJQUFJLEdBQUcsS0FBSyxFQUFFQyxPQUFPLFlBQVk7QUFBQSxJQUNqREMsVUFBVTtBQUFBLElBQ1ZDLFlBQVk7QUFBQSxFQUNkLENBQUM7QUFDRCxRQUFNLENBQUNDLG1CQUFtQkMsb0JBQW9CLElBQUlsRCxTQUFTLENBQUMsQ0FBQztBQUM3RCxRQUFNLENBQUNtRCxPQUFPQyxRQUFRLElBQUlwRCxTQUFTO0FBQUEsSUFDakNxRCxTQUFTO0FBQUEsSUFDVEMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFFQSxRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSXpELFNBQVM7QUFBQSxJQUM1QzBELFlBQVk7QUFBQSxJQUNaSixTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUVILFFBQU0sQ0FBQ0ksT0FBT0MsUUFBUSxJQUFJNUQsU0FBUyxFQUFFO0FBQ3JDLFFBQU02RCxRQUFPLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNsRCxRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSWxFLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUNtRSxPQUFPQyxRQUFRLElBQUlwRSxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDcUUsUUFBUUMsU0FBUyxJQUFJdEUsU0FBUyxFQUFFO0FBQ3ZDLFFBQU11RSx1QkFBdUJ0RSxPQUFPLElBQUk7QUFFeEMsUUFBTXVFLDRCQUE0QkEsQ0FBQ0MsTUFBTTtBQUN2QyxVQUFNLEVBQUVDLE1BQU0sSUFBSUQsRUFBRUU7QUFDcEJ6QyxrQkFBY3dDLEtBQUs7QUFBQSxFQUNyQjtBQUVBM0UsWUFBVSxNQUFNO0FBQ2QsVUFBTTZFLE9BQU9DLGFBQWFDLFFBQVEsTUFBTTtBQUN4QyxVQUFNQyxVQUFVQyxLQUFLQyxNQUFNTCxJQUFJO0FBQy9CLFVBQU1NLFVBQVVILFNBQVNJO0FBQ3pCLFFBQUlELFNBQVM7QUFDWHRCLGVBQVNtQixTQUFTSSxHQUFHO0FBQUEsSUFDdkIsT0FBTztBQUNMdkIsZUFBUyxFQUFFO0FBQUEsSUFDYjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUw3RCxZQUFVLE1BQU07QUFDZCxVQUFNcUYsY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRixjQUFNQyxXQUFXLE1BQU1sRixJQUFJbUYsSUFBSSx3QkFBd0I7QUFDdkRsRSxrQkFBVWlFLFNBQVNFLElBQUk7QUFBQSxNQUN6QixTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLHlCQUF5QkEsS0FBSztBQUFBLE1BQzlDO0FBQUEsSUFDRjtBQUNBSixnQkFBWTtBQUFBLEVBQ2QsR0FBRyxFQUFFO0FBRUxyRixZQUFVLE1BQU07QUFDZCxtQkFBZTJGLHlCQUF5QjtBQUN0Q3hCLHNCQUFnQixJQUFJO0FBQ3BCLFVBQUl5QixNQUFNLDhDQUE4QzlCLElBQUksWUFBWUEsSUFBSTtBQUM1RSxVQUFJO0FBQ0ZyQyx3QkFBZ0IsRUFBRTtBQUNsQlEsOEJBQXNCLElBQUk7QUFDMUIsY0FBTXFELFdBQVcsTUFBTWxGLElBQUltRixJQUFJSyxHQUFHO0FBQ2xDLFlBQUlOLFNBQVNFLFFBQVFGLFNBQVNFLEtBQUtLLFNBQVMsR0FBRztBQUM3Q2xFLDJCQUFpQjJELFNBQVNFLElBQUk7QUFDOUIsZ0JBQU1NLGdCQUFnQlIsU0FBU0UsS0FBS08sSUFBSSxDQUFDQyxPQUFPQyxVQUFVO0FBQ3hELGdCQUFJLENBQUNELE9BQU9FLFlBQVksQ0FBQ0YsT0FBT0csUUFBUyxRQUFPLENBQUM7QUFDakQsbUJBQU87QUFBQSxjQUNMQyxRQUNFO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTaEUsb0JBQW9CaUUsU0FBU0wsTUFBTVosR0FBRztBQUFBLGtCQUMvQyxVQUFVLENBQUNWLE1BQU00Qix1QkFBdUJOLE1BQU1aLEtBQUtWLENBQUM7QUFBQSxrQkFDcEQsV0FBVTtBQUFBO0FBQUEsZ0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSW1EO0FBQUEsY0FHckRVLEtBQUtZLE9BQU9aO0FBQUFBLGNBQ1ptQixJQUFJTixRQUFRO0FBQUEsY0FDWk8sTUFBTVIsT0FBT0csU0FBU007QUFBQUEsY0FDdEJDLGNBQWNWLE9BQU9HLFNBQVNPO0FBQUFBLGNBQzlCQyxZQUFZWCxPQUFPRSxVQUFVUztBQUFBQSxjQUM3QkMsY0FBY1osT0FBT1k7QUFBQUEsY0FDckJDLGlCQUFpQmIsT0FBT2MsWUFDcEJkLE9BQU9jLFdBQVc3QyxNQUFNLEdBQUcsRUFBRSxDQUFDLElBQzlCO0FBQUEsY0FDSjhDLG1CQUFtQmYsT0FBT2U7QUFBQUEsY0FDMUJDLGVBQWVoQixPQUFPZ0I7QUFBQUEsY0FDdEJDLGFBQ0VqQixPQUFPa0IsT0FBT1YsUUFBUVIsT0FBT2tCLE9BQU9SLGVBQ2hDLEdBQUdWLE1BQU1rQixNQUFNVixJQUFJLE1BQU1SLE1BQU1rQixNQUFNUixZQUFZLEtBQ2pEVixPQUFPbUIsbUJBQW1CVixhQUMxQlQsT0FBT21CLG1CQUFtQlQsZUFDMUIsR0FBR1YsTUFBTW1CLGtCQUFrQlYsU0FBUyxNQUFNVCxPQUFPbUIsbUJBQW1CVCxZQUFZLEtBQ2hGVixPQUFPb0IsZUFBZUMsYUFDdEJyQixPQUFPb0IsZUFBZUUsZUFDdEIsR0FBR3RCLE1BQU1vQixjQUFjQyxTQUFTLE1BQU1yQixNQUFNb0IsY0FBY0UsWUFBWSxLQUN0RTtBQUFBLGNBQ05DLFFBQVF2QixNQUFNd0I7QUFBQUEsY0FDZEMsUUFDRSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBTTtBQUFBLG9CQUNKQyxPQUFPO0FBQUEsc0JBQ0w7QUFBQSx3QkFDRUMsS0FBSztBQUFBLHdCQUNMQyxPQUNFO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVU7QUFBQSw0QkFDVixTQUFTLE1BQU1DLGtCQUFrQjdCLE1BQU1aLEdBQUc7QUFBQSw0QkFBRTtBQUFBO0FBQUEsMEJBRjlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHNCQUVKO0FBQUEsb0JBQUM7QUFBQSxrQkFFTDtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFFVixpQ0FBQyxZQUFTLFdBQVUsZUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQTtBQUFBLGdCQWxCakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBbUJBLEtBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsWUFFSjtBQUFBLFVBQ0YsQ0FBQztBQUNEM0QsMEJBQWdCcUUsYUFBYTtBQUFBLFFBQy9CLE9BQU87QUFDTG5FLDJCQUFpQixFQUFFO0FBQUEsUUFDckI7QUFBQSxNQUNGLFNBQVM4RCxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLG1DQUFtQ0EsS0FBSztBQUN0RDlELHlCQUFpQixFQUFFO0FBQ25CRix3QkFBZ0IsRUFBRTtBQUNsQjRCLGlCQUFTO0FBQUEsVUFDUEMsU0FBUztBQUFBLFVBQ1RDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSCxVQUFDO0FBQ0N2Qiw4QkFBc0IsS0FBSztBQUFBLE1BQzdCO0FBQUEsSUFDRjtBQUNBMEQsMkJBQXVCO0FBQUEsRUFDekIsR0FBRyxFQUFFO0FBRUwzRixZQUFVLE1BQU07QUFDZCxVQUFNOEgsYUFBYSxZQUFZO0FBQzdCLFVBQUk7QUFDRixjQUFNeEMsV0FBVyxNQUFNbEYsSUFBSW1GLElBQUksZ0JBQWdCO0FBQy9DaEUsaUJBQVMrRCxTQUFTRSxJQUFJO0FBQUEsTUFDeEIsU0FBU0MsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSx3QkFBd0JBLEtBQUs7QUFBQSxNQUM3QztBQUFBLElBQ0Y7QUFDQXFDLGVBQVc7QUFBQSxFQUNiLEdBQUcsRUFBRTtBQUVMOUgsWUFBVSxNQUFNO0FBQ2QsVUFBTStILGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTXpDLFdBQVcsTUFBTWxGLElBQUltRixJQUFJLGtCQUFrQjtBQUNqRGhCLGtCQUFVZSxTQUFTRSxJQUFJO0FBQUEsTUFDekIsU0FBU3dDLEtBQUs7QUFDWnRDLGdCQUFRRCxNQUFNLDBCQUEwQnVDLEdBQUc7QUFBQSxNQUM3QztBQUFBLElBQ0Y7QUFDQUQsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsRUFBRTtBQUVML0gsWUFBVSxNQUFNO0FBQ2QsVUFBTWlJLGFBQWEsWUFBWTtBQUM3QixVQUFJO0FBQ0YsY0FBTTNDLFdBQVcsTUFBTWxGLElBQUltRixJQUFJLGdCQUFnQjtBQUMvQ2xCLGlCQUFTaUIsU0FBU0UsSUFBSTtBQUFBLE1BQ3hCLFNBQVN3QyxLQUFLO0FBQ1p0QyxnQkFBUUQsTUFBTSx5QkFBeUJ1QyxHQUFHO0FBQUEsTUFDNUM7QUFBQSxJQUNGO0FBQ0FDLGVBQVc7QUFBQSxFQUNiLEdBQUcsRUFBRTtBQUdMakksWUFBVSxNQUFNO0FBQ2QsUUFBSXdCLGFBQWFxRSxXQUFXLEdBQUc7QUFDN0J0RCxtQkFBYSxLQUFLO0FBQ2xCO0FBQUEsSUFDRjtBQUNBLFVBQU0yRixxQkFBcUIxRyxhQUFhMkc7QUFBQUEsTUFBTSxDQUFDQyxXQUM3Q2hHLG9CQUFvQmlFLFNBQVMrQixPQUFPaEQsR0FBRztBQUFBLElBQ3pDO0FBQ0E3QyxpQkFBYTJGLGtCQUFrQjtBQUFBLEVBQ2pDLEdBQUcsQ0FBQzFHLGNBQWNZLG1CQUFtQixDQUFDO0FBR3RDcEMsWUFBVSxNQUFNO0FBQ2QsUUFBSXdFLHFCQUFxQjZELFNBQVM7QUFDaEMsWUFBTUMsZUFBZTlHLGFBQWFxRTtBQUNsQyxZQUFNMEMsZ0JBQWdCbkcsb0JBQW9Cb0c7QUFBQUEsUUFBTyxDQUFDakMsT0FDaEQvRSxhQUFhaUgsS0FBSyxDQUFDTCxXQUFXQSxPQUFPaEQsUUFBUW1CLEVBQUU7QUFBQSxNQUNqRCxFQUFFVjtBQUVGckIsMkJBQXFCNkQsUUFBUUssZ0JBQzNCSCxnQkFBZ0IsS0FBS0EsZ0JBQWdCRDtBQUFBQSxJQUN6QztBQUFBLEVBQ0YsR0FBRyxDQUFDbEcscUJBQXFCWixZQUFZLENBQUM7QUFFdEMsUUFBTW1ILG9CQUFvQixPQUFPQyxZQUFZO0FBQzNDL0cscUJBQWlCK0csT0FBTztBQUN4QixRQUFJQSxTQUFTO0FBQ1gsVUFBSWhEO0FBQ0osVUFBSWdELFlBQVksU0FBUztBQUN2QmhELGNBQU0sOENBQThDOUIsSUFBSSxZQUFZQSxJQUFJO0FBQ3hFSyx3QkFBZ0IsSUFBSTtBQUFBLE1BQ3RCLE9BQU87QUFDTHlCLGNBQU0sNEJBQTRCZ0QsT0FBTztBQUN6Q3pFLHdCQUFnQixLQUFLO0FBQUEsTUFDdkI7QUFDQSxVQUFJO0FBQ0YxQyx3QkFBZ0IsRUFBRTtBQUNsQlEsOEJBQXNCLElBQUk7QUFDMUIsY0FBTXFELFdBQVcsTUFBTWxGLElBQUltRixJQUFJSyxHQUFHO0FBQ2xDLFlBQUlOLFNBQVNFLFFBQVFGLFNBQVNFLEtBQUtLLFNBQVMsR0FBRztBQUM3Q2xFLDJCQUFpQjJELFNBQVNFLElBQUk7QUFDOUIsZ0JBQU1NLGdCQUFnQlIsU0FBU0UsS0FBS08sSUFBSSxDQUFDQyxPQUFPQyxVQUFVO0FBQ3hELGdCQUFJLENBQUNELE9BQU9FLFlBQVksQ0FBQ0YsT0FBT0csUUFBUyxRQUFPLENBQUM7QUFDakQsbUJBQU87QUFBQSxjQUNMQyxRQUNFO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTaEUsb0JBQW9CaUUsU0FBU0wsTUFBTVosR0FBRztBQUFBLGtCQUMvQyxVQUFVLENBQUNWLE1BQU00Qix1QkFBdUJOLE1BQU1aLEtBQUtWLENBQUM7QUFBQSxrQkFDcEQsV0FBVTtBQUFBO0FBQUEsZ0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSW1EO0FBQUEsY0FHckRVLEtBQUtZLE9BQU9aO0FBQUFBLGNBQ1ptQixJQUFJTixRQUFRO0FBQUEsY0FDWk8sTUFBTVIsT0FBT0csU0FBU007QUFBQUEsY0FDdEJDLGNBQWNWLE9BQU9HLFNBQVNPO0FBQUFBLGNBQzlCQyxZQUFZWCxPQUFPRSxVQUFVUztBQUFBQSxjQUM3QkMsY0FBY1osT0FBT1k7QUFBQUEsY0FDckJDLGlCQUFpQmIsT0FBT2MsV0FBVzdDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxjQUMvQzhDLG1CQUFtQmYsT0FBT2U7QUFBQUEsY0FDMUJDLGVBQWVoQixPQUFPZ0I7QUFBQUEsY0FDdEJDLGFBQ0VqQixPQUFPa0IsT0FBT1YsUUFBUVIsT0FBT2tCLE9BQU9SLGVBQ2hDLEdBQUdWLE1BQU1rQixNQUFNVixJQUFJLE1BQU1SLE1BQU1rQixNQUFNUixZQUFZLEtBQ2pEVixPQUFPbUIsbUJBQW1CVixhQUMxQlQsT0FBT21CLG1CQUFtQlQsZUFDMUIsR0FBR1YsTUFBTW1CLGtCQUFrQlYsU0FBUyxNQUFNVCxPQUFPbUIsbUJBQW1CVCxZQUFZLEtBQ2hGVixPQUFPb0IsZUFBZUMsYUFDdEJyQixPQUFPb0IsZUFBZUUsZUFDdEIsR0FBR3RCLE1BQU1vQixjQUFjQyxTQUFTLE1BQU1yQixNQUFNb0IsY0FBY0UsWUFBWSxLQUN0RTtBQUFBLGNBQ05DLFFBQVF2QixNQUFNd0I7QUFBQUEsY0FDZEMsUUFDRSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBTTtBQUFBLG9CQUNKQyxPQUFPO0FBQUEsc0JBQ0w7QUFBQSx3QkFDRUMsS0FBSztBQUFBLHdCQUNMQyxPQUNFO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVU7QUFBQSw0QkFDVixTQUFTLE1BQU1DLGtCQUFrQjdCLE1BQU1aLEdBQUc7QUFBQSw0QkFBRTtBQUFBO0FBQUEsMEJBRjlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHNCQUVKO0FBQUEsb0JBQUM7QUFBQSxrQkFFTDtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFFVixpQ0FBQyxZQUFTLFdBQVUsZUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQTtBQUFBLGdCQWxCakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBbUJBLEtBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsWUFFSjtBQUFBLFVBQ0YsQ0FBQztBQUNEM0QsMEJBQWdCcUUsYUFBYTtBQUFBLFFBQy9CLE9BQU87QUFDTG5FLDJCQUFpQixFQUFFO0FBQ25CRiwwQkFBZ0IsRUFBRTtBQUFBLFFBQ3BCO0FBQUEsTUFDRixTQUFTZ0UsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw4QkFBOEJBLEtBQUs7QUFDakQ5RCx5QkFBaUIsRUFBRTtBQUNuQkYsd0JBQWdCLEVBQUU7QUFBQSxNQUNwQixVQUFDO0FBQ0NRLDhCQUFzQixLQUFLO0FBQUEsTUFDN0I7QUFBQSxJQUNGLE9BQU87QUFDTE4sdUJBQWlCLEVBQUU7QUFDbkJGLHNCQUFnQixFQUFFO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBSUYsUUFBTW9ILGtCQUFrQkEsQ0FBQ25FLE1BQU07QUFDN0IsUUFBSUEsRUFBRUUsT0FBT2tFLFNBQVM7QUFDcEIsWUFBTUMsU0FBU3ZILGFBQWF1RSxJQUFJLENBQUNxQyxXQUFXQSxPQUFPaEQsR0FBRztBQUN0RC9DLDZCQUF1QjBHLE1BQU07QUFBQSxJQUMvQixPQUFPO0FBQ0wxRyw2QkFBdUIsRUFBRTtBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUVBLFFBQU1pRSx5QkFBeUJBLENBQUNDLE9BQU87QUFDckNsRTtBQUFBQSxNQUF1QixDQUFDMkcsU0FDdEJBLEtBQUszQyxTQUFTRSxFQUFFLElBQ1p5QyxLQUFLUixPQUFPLENBQUNTLE9BQU9BLE9BQU8xQyxFQUFFLElBQzdCLENBQUMsR0FBR3lDLE1BQU16QyxFQUFFO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUUsUUFBTXNCLG9CQUFvQixPQUFPcUIsaUJBQWlCO0FBQ2hELFFBQUk7QUFDRixZQUFNNUQsV0FBVyxNQUFNbEYsSUFBSW1GLElBQUksNEJBQTRCMkQsWUFBWSxFQUFFO0FBQ3pFLFlBQU1DLGFBQWE3RCxTQUFTRTtBQUU1Qi9FLG1CQUFhMkksS0FBSztBQUFBLFFBQ2hCN0YsU0FBUztBQUFBLFFBQ1Q4RixhQUNFLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxPQUFFO0FBQUEsbUNBQUMsWUFBTyx5QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQjtBQUFBLFlBQVM7QUFBQSxZQUFFRixXQUFXaEQsU0FBU007QUFBQUEsZUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkQ7QUFBQSxVQUM3RCx1QkFBQyxPQUFFO0FBQUEsbUNBQUMsWUFBTyxzQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFjO0FBQUEsWUFBUztBQUFBLFlBQUUwQyxXQUFXaEQsU0FBU087QUFBQUEsZUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkQ7QUFBQSxVQUM3RCx1QkFBQyxPQUFFO0FBQUEsbUNBQUMsWUFBTyxzQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFjO0FBQUEsWUFBUztBQUFBLFlBQUV5QyxXQUFXakQsVUFBVVM7QUFBQUEsZUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEQ7QUFBQSxVQUM1RCx1QkFBQyxPQUFFO0FBQUEsbUNBQUMsWUFBTyx1QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFlO0FBQUEsWUFBUztBQUFBLFlBQUV3QyxXQUFXM0I7QUFBQUEsZUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Q7QUFBQSxVQUNoRCx1QkFBQyxPQUFFO0FBQUEsbUNBQUMsWUFBTyw2QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxQjtBQUFBLFlBQVM7QUFBQSxZQUFFMkIsV0FBV3ZDO0FBQUFBLGVBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJEO0FBQUEsVUFDM0QsdUJBQUMsT0FBRTtBQUFBLG1DQUFDLFlBQU8sZ0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0I7QUFBQSxZQUFTO0FBQUEsWUFBRSxJQUFJN0MsS0FBS29GLFdBQVdyQyxTQUFTLEVBQUV3QyxtQkFBbUI7QUFBQSxlQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRjtBQUFBLGFBTjVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBRUZDLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFBQSxJQUNILFNBQVM5RCxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sc0NBQXNDQSxLQUFLO0FBQ3pEaEYsbUJBQWFnRixNQUFNO0FBQUEsUUFDakJsQyxTQUFTO0FBQUEsUUFDVDhGLGFBQWE7QUFBQSxNQUNmLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU1HLDZCQUE2QkEsTUFBTTtBQUN2QyxRQUFJcEgsb0JBQW9CeUQsV0FBVyxHQUFHO0FBQ3BDcEYsbUJBQWFnSixRQUFRO0FBQUEsUUFDbkJsRyxTQUFTO0FBQUEsUUFDVDhGLGFBQWE7QUFBQSxNQUNmLENBQUM7QUFDRDtBQUFBLElBQ0Y7QUFDQTVHLDRCQUF3QixJQUFJO0FBQUEsRUFDOUI7QUFFQSxRQUFNaUgsMEJBQTBCQSxDQUFDaEYsTUFBTTtBQUNyQyxVQUFNLEVBQUU4QixNQUFNN0IsT0FBT25CLE1BQU1zRixRQUFRLElBQUlwRSxFQUFFRTtBQUN6Q2pDLHVCQUFtQixDQUFDcUcsVUFBVTtBQUFBLE1BQzVCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ3hDLElBQUksR0FBR2hELFNBQVMsYUFBYXNGLFVBQVVuRTtBQUFBQSxJQUMxQyxFQUFFO0FBQ0Z4Qix5QkFBcUIsQ0FBQzZGLFVBQVU7QUFBQSxNQUM5QixHQUFHQTtBQUFBQSxNQUNILENBQUN4QyxJQUFJLEdBQUc7QUFBQSxJQUNWLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTW1ELDBCQUEwQkEsTUFBTTtBQUNwQyxVQUFNQyxTQUFTLENBQUM7QUFDaEIsVUFBTWhILFNBQVNpSCxXQUFXbkgsZ0JBQWdCRSxNQUFNO0FBRWhELFFBQUksQ0FBQ0YsZ0JBQWdCRSxVQUFVa0gsTUFBTWxILE1BQU0sS0FBS0EsVUFBVSxHQUFHO0FBQzNEZ0gsYUFBT2hILFNBQVM7QUFBQSxJQUNsQjtBQUVBTyx5QkFBcUJ5RyxNQUFNO0FBQzNCLFdBQU9HLE9BQU9DLEtBQUtKLE1BQU0sRUFBRS9ELFdBQVc7QUFBQSxFQUN4QztBQUVBLFFBQU1vRSwwQkFBMEIsT0FBT3ZGLE1BQU07QUFDM0NBLE1BQUV3RixlQUFlO0FBRWpCLFFBQUksQ0FBQ1Asd0JBQXdCLEdBQUc7QUFDOUI7QUFBQSxJQUNGO0FBRUEsUUFBSTtBQUNGNUgsaUJBQVcsSUFBSTtBQUVmLFlBQU1vSSxrQkFBa0IzSSxhQUFhZ0g7QUFBQUEsUUFBTyxDQUFDSixXQUMzQ2hHLG9CQUFvQmlFLFNBQVMrQixPQUFPaEQsR0FBRztBQUFBLE1BQ3pDO0FBRUEsWUFBTWdGLFdBQVdELGdCQUFnQnBFLElBQUksQ0FBQ29ELGdCQUFnQjtBQUFBLFFBQ3BEaEQsU0FBU2dELFdBQVdoRDtBQUFBQSxRQUNwQkQsVUFBVWlELFdBQVdqRCxVQUFVZDtBQUFBQSxRQUMvQm1DLFFBQVE0QixXQUFXNUI7QUFBQUEsUUFDbkIzRSxRQUFRaUgsV0FBV25ILGdCQUFnQkUsTUFBTTtBQUFBLFFBQ3pDQyxRQUFRSCxnQkFBZ0JHO0FBQUFBLFFBQ3hCRyxVQUFVTixnQkFBZ0JNO0FBQUFBLFFBQzFCQyxZQUFZUCxnQkFBZ0JPO0FBQUFBLFFBQzVCb0gsdUJBQXVCO0FBQUEsVUFDckIsUUFBUWxCLFdBQVdqRCxVQUFVZCxHQUFHLElBQUkrRCxXQUFXNUIsTUFBTTtBQUFBLFFBQUU7QUFBQSxNQUUzRCxFQUFFO0FBRUYsWUFBTStDLFVBQVU7QUFDaEIsaUJBQVdDLFdBQVdILFVBQVU7QUFDOUIsWUFBSTtBQUNGLGdCQUFNOUUsV0FBVyxNQUFNbEYsSUFBSW9LLEtBQUssNEJBQTRCRCxPQUFPO0FBQ25FRCxrQkFBUUcsS0FBSyxFQUFFQyxTQUFTLE1BQU12QixZQUFZb0IsU0FBU2pGLFNBQVMsQ0FBQztBQUFBLFFBQy9ELFNBQVNHLE9BQU87QUFDZDZFLGtCQUFRRyxLQUFLLEVBQUVDLFNBQVMsT0FBT3ZCLFlBQVlvQixTQUFTOUUsTUFBTSxDQUFDO0FBQUEsUUFDN0Q7QUFBQSxNQUNGO0FBRUEsWUFBTWtGLGVBQWVMLFFBQVE5QixPQUFPLENBQUFvQyxNQUFLQSxFQUFFRixPQUFPLEVBQUU3RTtBQUNwRCxZQUFNZ0YsZUFBZVAsUUFBUXpFLFNBQVM4RTtBQUV0QyxVQUFJQSxlQUFlLEdBQUc7QUFDcEJ0SCxpQkFBUztBQUFBLFVBQ1BDLFNBQVM7QUFBQSxVQUNUQyxTQUFTLHdCQUF3Qm9ILFlBQVksZ0JBQWdCQSxlQUFlLElBQUksTUFBTSxFQUFFO0FBQUEsVUFDeEZuSCxNQUFNO0FBQUEsUUFDUixDQUFDO0FBRURqQixxQkFBYSxLQUFLO0FBQ2xCRiwrQkFBdUIsRUFBRTtBQUN6QkksZ0NBQXdCLEtBQUs7QUFDN0JFLDJCQUFtQjtBQUFBLFVBQ2pCQyxRQUFRO0FBQUEsVUFDUkMsUUFBUTdCLE1BQU0sRUFBRThCLElBQUksR0FBRyxLQUFLLEVBQUVDLE9BQU8sWUFBWTtBQUFBLFVBQ2pEQyxVQUFVO0FBQUEsVUFDVkMsWUFBWTtBQUFBLFFBQ2QsQ0FBQztBQUFBLE1BQ0g7QUFFQSxVQUFJNEgsZUFBZSxHQUFHO0FBQ3BCcEsscUJBQWFnRixNQUFNO0FBQUEsVUFDakJsQyxTQUFTO0FBQUEsVUFDVDhGLGFBQWEsb0JBQW9Cd0IsWUFBWSxnQkFBZ0JBLGVBQWUsSUFBSSxNQUFNLEVBQUU7QUFBQSxRQUMxRixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsU0FBU3BGLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxpQ0FBaUNBLEtBQUs7QUFDcERwQyxlQUFTO0FBQUEsUUFDUEMsU0FBUztBQUFBLFFBQ1RDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSCxVQUFDO0FBQ0N6QixpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBR0EsUUFBTStJLFVBQVU7QUFBQSxJQUNkO0FBQUEsTUFDRm5ELEtBQUs7QUFBQSxNQUNMb0QsUUFDRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsS0FBS3ZHO0FBQUFBLFVBQ0wsTUFBSztBQUFBLFVBQ0wsU0FBU3BDLG9CQUFvQnlELFdBQVdyRSxhQUFhcUUsVUFBVXJFLGFBQWFxRSxTQUFTO0FBQUEsVUFDckYsVUFBVWdEO0FBQUFBLFVBQ1YsV0FBVTtBQUFBO0FBQUEsUUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLbUQ7QUFBQSxNQUdyRG1DLFFBQVFBLENBQUNDLFFBQ1AsdUJBQUMsU0FBSSxXQUFXN0ksb0JBQW9CaUUsU0FBUzRFLElBQUk3RixHQUFHLElBQUksa0JBQWtCLElBQ3hFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxTQUFTaEQsb0JBQW9CaUUsU0FBUzRFLElBQUk3RixHQUFHO0FBQUEsVUFDN0MsVUFBVSxNQUFNa0IsdUJBQXVCMkUsSUFBSTdGLEdBQUc7QUFBQSxVQUM5QyxXQUFVO0FBQUE7QUFBQSxRQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUltRCxLQUxyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxJQUVKO0FBQUEsSUFDSSxFQUFFdUMsS0FBSyxNQUFNb0QsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRXBELEtBQUssUUFBUW9ELFFBQVEsZ0JBQWdCO0FBQUEsSUFDdkMsRUFBRXBELEtBQUssZ0JBQWdCb0QsUUFBUSx3QkFBd0I7QUFBQSxFQUFDO0FBRzFELE1BQUk3RyxjQUFjO0FBQ2hCNEcsWUFBUUwsS0FBSyxFQUFFOUMsS0FBSyxjQUFjb0QsUUFBUSxpQkFBaUIsQ0FBQztBQUFBLEVBQzlEO0FBRUFELFVBQVFMO0FBQUFBLElBQ04sRUFBRTlDLEtBQUssVUFBVW9ELFFBQVEsZ0JBQWdCO0FBQUEsSUFDekMsRUFBRXBELEtBQUssaUJBQWlCb0QsUUFBUSxnQkFBZ0I7QUFBQSxJQUNoRCxFQUFFcEQsS0FBSyxnQkFBZ0JvRCxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFcEQsS0FBSyxtQkFBbUJvRCxRQUFRLGtCQUFrQjtBQUFBLElBQ3BELEVBQUVwRCxLQUFLLHFCQUFxQm9ELFFBQVEsb0JBQW9CO0FBQUEsSUFDeEQsRUFBRXBELEtBQUssZUFBZW9ELFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUVwRCxLQUFLLFVBQVVvRCxRQUFRLFNBQVM7QUFBQSxFQUNwQztBQUVBLFFBQU1HLG1CQUFtQjlKLE9BQU8rSixLQUFLLENBQUNDLE1BQU1BLEVBQUVoRyxRQUFReEQsYUFBYTtBQUVuRSxTQUNFLG1DQUNFLGlDQUFDLFNBRUM7QUFBQSwyQkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDZCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsNkJBQTZCNkM7QUFBQUEsVUFDN0IsWUFBWTtBQUFBO0FBQUEsUUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFbUI7QUFBQSxNQUVuQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTWhCLFlBQVlEO0FBQUFBLFVBQ2xCLFdBQVdDLFlBQVlFO0FBQUFBLFVBQ3ZCLFNBQVNGLFlBQVlGO0FBQUFBLFVBQ3JCLFNBQVMsTUFDUEcsZUFBZSxDQUFDc0YsVUFBVSxFQUFFLEdBQUdBLE1BQU1yRixZQUFZLE1BQU0sRUFBRTtBQUFBO0FBQUEsUUFMN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUc7QUFBQSxNQUdGUCxNQUFNRSxXQUNMLHVCQUFDLFNBQUksV0FBVSxpQ0FDYjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBU0YsTUFBTUc7QUFBQUEsVUFDZixNQUFNSCxNQUFNSTtBQUFBQSxVQUNaO0FBQUEsVUFDQTtBQUFBLFVBQ0EsU0FBUyxNQUFNSCxTQUFTLEVBQUUsR0FBR0QsT0FBT0UsU0FBUyxNQUFNLENBQUM7QUFBQTtBQUFBLFFBTHREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUt3RCxLQU4xRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUdGLHVCQUFDLFNBQUksV0FBVSxpQkFDVjtBQUFBLCtCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVztBQUFBLFFBQ2QsdUJBQUMsUUFBRyxXQUFVLDBCQUF5QixpQ0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RDtBQUFBLFFBQ3hELHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFFBQ2IsaUNBQUMsV0FBTSxzQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QixLQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsaURBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDO0FBQUEsZ0JBQ0EsdUJBQXVCO0FBQUEsZ0JBQ3ZCLE9BQU8xQixpQkFBaUI7QUFBQSxnQkFDeEIsY0FBYyxDQUFDeUosT0FBT0MsV0FDcEJBLE9BQU9DLFVBQVVDLFNBQVMsR0FDdEJDLFlBQVksRUFDYnBGLFNBQVNnRixPQUFPSSxZQUFZLENBQUM7QUFBQSxnQkFFbEMsYUFBWTtBQUFBLGdCQUNaLFVBQVU5QztBQUFBQSxnQkFDVixXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBMEIsT0FBTSxTQUFRLGtDQUF0QixTQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0N2SCxPQUFPMkU7QUFBQUEsb0JBQUksQ0FBQ0MsVUFDWCx1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsTUFBTVosS0FDekNZLGdCQUFNVyxjQURXWCxNQUFNWixLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBO0FBQUEsY0FwQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBcUJBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDWmhELDhCQUFvQnlELFNBQVMsS0FDNUI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTMkQ7QUFBQUEsZ0JBQ1QsV0FBVTtBQUFBLGdCQUFnRTtBQUFBO0FBQUEsa0JBRXZEcEgsb0JBQW9CeUQ7QUFBQUEsa0JBQU87QUFBQTtBQUFBO0FBQUEsY0FKaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0EsS0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsZUFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQ0E7QUFBQSxVQUVDckUsY0FBY3FFLFNBQVMsSUFDdEI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU1oRixhQUFhVyxjQUFjVSxVQUFVO0FBQUEsY0FDM0M7QUFBQSxjQUNBLGtCQUFrQixlQUNoQlYsYUFBYXFFLFNBQVMsSUFDbEJyRSxhQUFhLENBQUMsRUFBRWdGLE9BQ2hCLFNBQ0FoRixhQUFhQSxhQUFhcUUsU0FBUyxDQUFDLEVBQUVXLE9BQ3RDLE9BQU87QUFBQTtBQUFBLFlBUmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU1MsSUFHVDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBV3hFO0FBQUFBLGNBQ1gsU0FBU1IsY0FBY3FFLFVBQVUsS0FBS2pFO0FBQUFBLGNBQ3RDLE1BQU07QUFBQTtBQUFBLFlBSFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBRzBCO0FBQUEsYUF2RDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwREE7QUFBQSxXQTdERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOERBO0FBQUEsU0F6RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBGQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVdZO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JDLGtDQUF3QixLQUFLO0FBQzdCVSwrQkFBcUIsQ0FBQyxDQUFDO0FBQUEsUUFDekI7QUFBQSxRQUVBLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSxzREFBcUQsb0NBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxpQ0FDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSwyQkFBMEI7QUFBQTtBQUFBLGNBQ1RmLG9CQUFvQnlEO0FBQUFBLGNBQU87QUFBQSxjQUFxQnpELG9CQUFvQnlELFNBQVMsSUFBSSxNQUFNO0FBQUEsaUJBRHJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxpQ0FDWnJFLHVCQUFhZ0gsT0FBTyxDQUFBSixXQUFVaEcsb0JBQW9CaUUsU0FBUytCLE9BQU9oRCxHQUFHLENBQUMsRUFBRVc7QUFBQUEsY0FBSSxDQUFDb0QsWUFBWWxELFVBQ3hGLHVCQUFDLFNBQWdCLFdBQVUseURBQ3hCa0Q7QUFBQUEsMkJBQVczQztBQUFBQSxnQkFBSztBQUFBLGdCQUFJMkMsV0FBV3pDO0FBQUFBLGdCQUFhO0FBQUEsZ0JBQUl5QyxXQUFXeEM7QUFBQUEsZ0JBQVc7QUFBQSxnQkFBV3dDLFdBQVc1QjtBQUFBQSxtQkFEckZ0QixPQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxZQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLGVBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLFVBRUEsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVWdFLHlCQUNwQztBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsd0NBQXVDO0FBQUE7QUFBQSxnQkFDL0MsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU92SCxnQkFBZ0JFO0FBQUFBLGtCQUN2QixVQUFVOEc7QUFBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLFdBQVU7QUFBQSxrQkFDVixLQUFJO0FBQUEsa0JBQ0osTUFBSztBQUFBO0FBQUEsZ0JBUlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUWE7QUFBQSxjQUVaeEcsa0JBQWtCTixVQUNqQix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCTSw0QkFBa0JOLFVBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1FO0FBQUEsaUJBZnZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsWUFFQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLHdDQUF1QywyQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPRixnQkFBZ0JHO0FBQUFBLGtCQUN2QixLQUFLN0IsTUFBTSxFQUFFK0IsT0FBTyxZQUFZO0FBQUEsa0JBQ2hDLFVBQVUyRztBQUFBQSxrQkFDVixXQUFVO0FBQUE7QUFBQSxnQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNZ0U7QUFBQSxpQkFWbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsSUFBRztBQUFBLG9CQUNILE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsU0FBU2hILGdCQUFnQk07QUFBQUEsb0JBQ3pCLFVBQVUwRztBQUFBQSxvQkFDVixXQUFVO0FBQUE7QUFBQSxrQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTXFDO0FBQUEsZ0JBRXJDLHVCQUFDLFdBQU0sU0FBUSxZQUFXLFdBQVUsOEJBQTZCLHdCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsSUFBRztBQUFBLG9CQUNILE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsU0FBU2hILGdCQUFnQk87QUFBQUEsb0JBQ3pCLFVBQVV5RztBQUFBQSxvQkFDVixXQUFVO0FBQUE7QUFBQSxrQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTXFDO0FBQUEsZ0JBRXJDLHVCQUFDLFdBQU0sU0FBUSxjQUFhLFdBQVUsOEJBQTZCLDBCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQTtBQUFBLGlCQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTRCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFVBQVU1SDtBQUFBQSxnQkFDVixXQUFXLHdEQUNUQSxVQUFVLG1DQUFtQyw4Q0FBOEM7QUFBQSxnQkFHNUZBLG9CQUFVLGdCQUFnQjtBQUFBO0FBQUEsY0FQN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsZUExRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyRUE7QUFBQSxhQTdGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOEZBO0FBQUE7QUFBQSxNQXJHRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFzR0E7QUFBQSxPQXBNRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcU1BLEtBdE1GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1TUE7QUFFSjtBQUFFWCxHQXpzQklELHFCQUFtQjtBQUFBd0ssS0FBbkJ4SztBQTJzQk4sZUFBZUE7QUFBb0IsSUFBQXdLO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInVzZVJlZiIsIlNpZGViYXIiLCJhcGkiLCJNb2RhbCIsIkRhdGFUYWJsZSIsIlNlbGVjdCIsIkRyb3Bkb3duIiwibm90aWZpY2F0aW9uIiwiQWxlcnQiLCJJb01kTW9yZSIsIk5hdmJhciIsImZpbHRlck9wdGlvbiIsIkNpcmN1bGFyTG9hZGVyIiwiQ3VzdG9tQWxlcnREaWFsb2ciLCJkYXlqcyIsIkJyZWFkY3J1bWIiLCJCdWxrQ2hpdFBheW1lbnRMaW5rIiwiX3MiLCJncm91cHMiLCJzZXRHcm91cHMiLCJ1c2VycyIsInNldFVzZXJzIiwiVGFibGVFbnJvbGxzIiwic2V0VGFibGVFbnJvbGxzIiwiZmlsdGVyZWRVc2VycyIsInNldEZpbHRlcmVkVXNlcnMiLCJzZWxlY3RlZEdyb3VwIiwic2V0U2VsZWN0ZWRHcm91cCIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiaXNEYXRhVGFibGVMb2FkaW5nIiwic2V0SXNEYXRhVGFibGVMb2FkaW5nIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJzZWxlY3RlZEVucm9sbG1lbnRzIiwic2V0U2VsZWN0ZWRFbnJvbGxtZW50cyIsInNlbGVjdEFsbCIsInNldFNlbGVjdEFsbCIsInNob3dQYXltZW50TGlua01vZGFsIiwic2V0U2hvd1BheW1lbnRMaW5rTW9kYWwiLCJwYXltZW50TGlua0Zvcm0iLCJzZXRQYXltZW50TGlua0Zvcm0iLCJhbW91bnQiLCJleHBpcnkiLCJhZGQiLCJmb3JtYXQiLCJzZW5kX3NtcyIsInNlbmRfZW1haWwiLCJwYXltZW50TGlua0Vycm9ycyIsInNldFBheW1lbnRMaW5rRXJyb3JzIiwiYWxlcnQiLCJzZXRBbGVydCIsInZpc2libGUiLCJtZXNzYWdlIiwidHlwZSIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwiYWRtaW4iLCJzZXRBZG1pbiIsImRhdGUiLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsImFsbEVucm9sbFVybCIsInNldEFsbEVucm9sbFVybCIsImxlYWRzIiwic2V0TGVhZHMiLCJhZ2VudHMiLCJzZXRBZ2VudHMiLCJzZWxlY3RBbGxDaGVja2JveFJlZiIsIkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIiLCJlIiwidmFsdWUiLCJ0YXJnZXQiLCJ1c2VyIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInVzZXJPYmoiLCJKU09OIiwicGFyc2UiLCJhZG1pbklkIiwiX2lkIiwiZmV0Y2hHcm91cHMiLCJyZXNwb25zZSIsImdldCIsImRhdGEiLCJlcnJvciIsImNvbnNvbGUiLCJmZXRjaEFsbEVucm9sbG1lbnREYXRhIiwidXJsIiwibGVuZ3RoIiwiZm9ybWF0dGVkRGF0YSIsIm1hcCIsImdyb3VwIiwiaW5kZXgiLCJncm91cF9pZCIsInVzZXJfaWQiLCJzZWxlY3QiLCJpbmNsdWRlcyIsImhhbmRsZUVucm9sbG1lbnRTZWxlY3QiLCJpZCIsIm5hbWUiLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJncm91cF9uYW1lIiwicGF5bWVudF90eXBlIiwiZW5yb2xsbWVudF9kYXRlIiwiY3JlYXRlZEF0IiwiY2hpdF9hc2tpbmdfbW9udGgiLCJyZWZlcnJlZF90eXBlIiwicmVmZXJyZWRfYnkiLCJhZ2VudCIsInJlZmVycmVkX2N1c3RvbWVyIiwicmVmZXJyZWRfbGVhZCIsImxlYWRfbmFtZSIsImFnZW50X251bWJlciIsInRpY2tldCIsInRpY2tldHMiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImxhYmVsIiwiaGFuZGxlVmlld0RldGFpbHMiLCJmZXRjaFVzZXJzIiwiZmV0Y2hBZ2VudHMiLCJlcnIiLCJmZXRjaExlYWRzIiwiYWxsVmlzaWJsZVNlbGVjdGVkIiwiZXZlcnkiLCJlbnJvbGwiLCJjdXJyZW50IiwidG90YWxWaXNpYmxlIiwic2VsZWN0ZWRDb3VudCIsImZpbHRlciIsInNvbWUiLCJpbmRldGVybWluYXRlIiwiaGFuZGxlR3JvdXBDaGFuZ2UiLCJncm91cElkIiwiaGFuZGxlU2VsZWN0QWxsIiwiY2hlY2tlZCIsImFsbElkcyIsInByZXYiLCJlbiIsImVucm9sbG1lbnRJZCIsImVucm9sbG1lbnQiLCJpbmZvIiwiZGVzY3JpcHRpb24iLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJkdXJhdGlvbiIsImhhbmRsZU9wZW5QYXltZW50TGlua01vZGFsIiwid2FybmluZyIsImhhbmRsZVBheW1lbnRMaW5rQ2hhbmdlIiwidmFsaWRhdGVQYXltZW50TGlua0Zvcm0iLCJlcnJvcnMiLCJwYXJzZUZsb2F0IiwiaXNOYU4iLCJPYmplY3QiLCJrZXlzIiwiaGFuZGxlUGF5bWVudExpbmtTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsInNlbGVjdGVkRGV0YWlscyIsInBheWxvYWRzIiwicGF5bWVudF9ncm91cF90aWNrZXRzIiwicmVzdWx0cyIsInBheWxvYWQiLCJwb3N0IiwicHVzaCIsInN1Y2Nlc3MiLCJzdWNjZXNzQ291bnQiLCJyIiwiZmFpbHVyZUNvdW50IiwiY29sdW1ucyIsImhlYWRlciIsInJlbmRlciIsInJvdyIsInNlbGVjdGVkbmV3R3JvdXAiLCJmaW5kIiwiZyIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJ0b1N0cmluZyIsInRvTG93ZXJDYXNlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQnVsa0NoaXRQYXltZW50TGluay5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlUmVmIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgeyBTZWxlY3QsIERyb3Bkb3duLCBub3RpZmljYXRpb24sIEFsZXJ0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCBkYXlqcyBmcm9tIFwiZGF5anNcIjtcclxuaW1wb3J0IEJyZWFkY3J1bWIgZnJvbSBcIi4uL2hlbHBlcnMvQnJlYWRjcnVtYlwiO1xyXG5cclxuY29uc3QgQnVsa0NoaXRQYXltZW50TGluayA9ICgpID0+IHtcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtUYWJsZUVucm9sbHMsIHNldFRhYmxlRW5yb2xsc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkVXNlcnMsIHNldEZpbHRlcmVkVXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEdyb3VwLCBzZXRTZWxlY3RlZEdyb3VwXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNEYXRhVGFibGVMb2FkaW5nLCBzZXRJc0RhdGFUYWJsZUxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEVucm9sbG1lbnRzLCBzZXRTZWxlY3RlZEVucm9sbG1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0QWxsLCBzZXRTZWxlY3RBbGxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93UGF5bWVudExpbmtNb2RhbCwgc2V0U2hvd1BheW1lbnRMaW5rTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtwYXltZW50TGlua0Zvcm0sIHNldFBheW1lbnRMaW5rRm9ybV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICBleHBpcnk6IGRheWpzKCkuYWRkKDEsIFwiZGF5XCIpLmZvcm1hdChcIllZWVktTU0tRERcIiksXHJcbiAgICBzZW5kX3NtczogdHJ1ZSxcclxuICAgIHNlbmRfZW1haWw6IHRydWUsXHJcbiAgfSk7XHJcbiAgY29uc3QgW3BheW1lbnRMaW5rRXJyb3JzLCBzZXRQYXltZW50TGlua0Vycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2FsZXJ0LCBzZXRBbGVydF0gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmxlOiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuXHJcbiAgIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgICB9KTtcclxuXHJcbiAgY29uc3QgW2FkbWluLCBzZXRBZG1pbl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBkYXRlID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcclxuICBjb25zdCBbYWxsRW5yb2xsVXJsLCBzZXRBbGxFbnJvbGxVcmxdID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW2xlYWRzLCBzZXRMZWFkc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBzZWxlY3RBbGxDaGVja2JveFJlZiA9IHVzZVJlZihudWxsKTtcclxuXHJcbiAgY29uc3QgR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFNlYXJjaFRleHQodmFsdWUpO1xyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB1c2VyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgY29uc3QgdXNlck9iaiA9IEpTT04ucGFyc2UodXNlcik7XHJcbiAgICBjb25zdCBhZG1pbklkID0gdXNlck9iaj8uX2lkO1xyXG4gICAgaWYgKGFkbWluSWQpIHtcclxuICAgICAgc2V0QWRtaW4odXNlck9iaj8uX2lkKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEFkbWluKFwiXCIpO1xyXG4gICAgfVxyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgICAgc2V0R3JvdXBzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hHcm91cHMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBhc3luYyBmdW5jdGlvbiBmZXRjaEFsbEVucm9sbG1lbnREYXRhKCkge1xyXG4gICAgICBzZXRBbGxFbnJvbGxVcmwodHJ1ZSk7XHJcbiAgICAgIGxldCB1cmwgPSBgL2Vucm9sbC1yZXBvcnQvZ2V0LWVucm9sbC1yZXBvcnQ/ZnJvbV9kYXRlPSR7ZGF0ZX0mdG9fZGF0ZT0ke2RhdGV9YDtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRUYWJsZUVucm9sbHMoW10pO1xyXG4gICAgICAgIHNldElzRGF0YVRhYmxlTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQodXJsKTtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgIHNldEZpbHRlcmVkVXNlcnMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2UuZGF0YS5tYXAoKGdyb3VwLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoIWdyb3VwPy5ncm91cF9pZCB8fCAhZ3JvdXA/LnVzZXJfaWQpIHJldHVybiB7fTtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICBzZWxlY3Q6IChcclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICBjaGVja2VkPXtzZWxlY3RlZEVucm9sbG1lbnRzLmluY2x1ZGVzKGdyb3VwLl9pZCl9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRW5yb2xsbWVudFNlbGVjdChncm91cC5faWQsIGUpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWNoZWNrYm94IGgtNCB3LTQgdGV4dC12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICBfaWQ6IGdyb3VwPy5faWQsXHJcbiAgICAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgICBuYW1lOiBncm91cD8udXNlcl9pZD8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgICAgIHBob25lX251bWJlcjogZ3JvdXA/LnVzZXJfaWQ/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgICBncm91cF9uYW1lOiBncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgICAgcGF5bWVudF90eXBlOiBncm91cD8ucGF5bWVudF90eXBlLFxyXG4gICAgICAgICAgICAgIGVucm9sbG1lbnRfZGF0ZTogZ3JvdXA/LmNyZWF0ZWRBdFxyXG4gICAgICAgICAgICAgICAgPyBncm91cD8uY3JlYXRlZEF0Py5zcGxpdChcIlRcIilbMF1cclxuICAgICAgICAgICAgICAgIDogXCJcIixcclxuICAgICAgICAgICAgICBjaGl0X2Fza2luZ19tb250aDogZ3JvdXA/LmNoaXRfYXNraW5nX21vbnRoLFxyXG4gICAgICAgICAgICAgIHJlZmVycmVkX3R5cGU6IGdyb3VwPy5yZWZlcnJlZF90eXBlLFxyXG4gICAgICAgICAgICAgIHJlZmVycmVkX2J5OlxyXG4gICAgICAgICAgICAgICAgZ3JvdXA/LmFnZW50Py5uYW1lICYmIGdyb3VwPy5hZ2VudD8ucGhvbmVfbnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgID8gYCR7Z3JvdXAuYWdlbnQubmFtZX0gfCAke2dyb3VwLmFnZW50LnBob25lX251bWJlcn1gXHJcbiAgICAgICAgICAgICAgICAgIDogZ3JvdXA/LnJlZmVycmVkX2N1c3RvbWVyPy5mdWxsX25hbWUgJiZcclxuICAgICAgICAgICAgICAgICAgICBncm91cD8ucmVmZXJyZWRfY3VzdG9tZXI/LnBob25lX251bWJlclxyXG4gICAgICAgICAgICAgICAgICA/IGAke2dyb3VwLnJlZmVycmVkX2N1c3RvbWVyLmZ1bGxfbmFtZX0gfCAke2dyb3VwPy5yZWZlcnJlZF9jdXN0b21lcj8ucGhvbmVfbnVtYmVyfWBcclxuICAgICAgICAgICAgICAgICAgOiBncm91cD8ucmVmZXJyZWRfbGVhZD8ubGVhZF9uYW1lICYmXHJcbiAgICAgICAgICAgICAgICAgICAgZ3JvdXA/LnJlZmVycmVkX2xlYWQ/LmFnZW50X251bWJlclxyXG4gICAgICAgICAgICAgICAgICA/IGAke2dyb3VwLnJlZmVycmVkX2xlYWQubGVhZF9uYW1lfSB8ICR7Z3JvdXAucmVmZXJyZWRfbGVhZC5hZ2VudF9udW1iZXJ9YFxyXG4gICAgICAgICAgICAgICAgICA6IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgdGlja2V0OiBncm91cC50aWNrZXRzLFxyXG4gICAgICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVZpZXdEZXRhaWxzKGdyb3VwLl9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZpZXcgRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgc2V0VGFibGVFbnJvbGxzKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVucm9sbG1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldEZpbHRlcmVkVXNlcnMoW10pO1xyXG4gICAgICAgIHNldFRhYmxlRW5yb2xscyhbXSk7XHJcbiAgICAgICAgc2V0QWxlcnQoe1xyXG4gICAgICAgICAgdmlzaWJsZTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGxvYWQgZW5yb2xsbWVudCBkYXRhXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNEYXRhVGFibGVMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgZmV0Y2hBbGxFbnJvbGxtZW50RGF0YSgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoVXNlcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgICAgc2V0VXNlcnMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHVzZXIgXCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoVXNlcnMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEFnZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYWdlbnQvZ2V0LWFnZW50XCIpO1xyXG4gICAgICAgIHNldEFnZW50cyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBBZ2VudHNcIiwgZXJyKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoQWdlbnRzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hMZWFkcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvbGVhZC9nZXQtbGVhZFwiKTtcclxuICAgICAgICBzZXRMZWFkcyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBMZWFkc1wiLCBlcnIpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hMZWFkcygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8gU3luYyBzZWxlY3RBbGwgd2hlbiBUYWJsZUVucm9sbHMgb3Igc2VsZWN0ZWRFbnJvbGxtZW50cyBjaGFuZ2VcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKFRhYmxlRW5yb2xscy5sZW5ndGggPT09IDApIHtcclxuICAgICAgc2V0U2VsZWN0QWxsKGZhbHNlKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgY29uc3QgYWxsVmlzaWJsZVNlbGVjdGVkID0gVGFibGVFbnJvbGxzLmV2ZXJ5KChlbnJvbGwpID0+XHJcbiAgICAgIHNlbGVjdGVkRW5yb2xsbWVudHMuaW5jbHVkZXMoZW5yb2xsLl9pZClcclxuICAgICk7XHJcbiAgICBzZXRTZWxlY3RBbGwoYWxsVmlzaWJsZVNlbGVjdGVkKTtcclxuICB9LCBbVGFibGVFbnJvbGxzLCBzZWxlY3RlZEVucm9sbG1lbnRzXSk7XHJcblxyXG4gIC8vIEFwcGx5IGluZGV0ZXJtaW5hdGUgc3RhdGUgdG8gdGhlIFwiU2VsZWN0IEFsbFwiIGNoZWNrYm94XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChzZWxlY3RBbGxDaGVja2JveFJlZi5jdXJyZW50KSB7XHJcbiAgICAgIGNvbnN0IHRvdGFsVmlzaWJsZSA9IFRhYmxlRW5yb2xscy5sZW5ndGg7XHJcbiAgICAgIGNvbnN0IHNlbGVjdGVkQ291bnQgPSBzZWxlY3RlZEVucm9sbG1lbnRzLmZpbHRlcigoaWQpID0+XHJcbiAgICAgICAgVGFibGVFbnJvbGxzLnNvbWUoKGVucm9sbCkgPT4gZW5yb2xsLl9pZCA9PT0gaWQpXHJcbiAgICAgICkubGVuZ3RoO1xyXG5cclxuICAgICAgc2VsZWN0QWxsQ2hlY2tib3hSZWYuY3VycmVudC5pbmRldGVybWluYXRlID1cclxuICAgICAgICBzZWxlY3RlZENvdW50ID4gMCAmJiBzZWxlY3RlZENvdW50IDwgdG90YWxWaXNpYmxlO1xyXG4gICAgfVxyXG4gIH0sIFtzZWxlY3RlZEVucm9sbG1lbnRzLCBUYWJsZUVucm9sbHNdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3JvdXBDaGFuZ2UgPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRHcm91cChncm91cElkKTtcclxuICAgIGlmIChncm91cElkKSB7XHJcbiAgICAgIGxldCB1cmw7XHJcbiAgICAgIGlmIChncm91cElkID09PSBcInRvZGF5XCIpIHtcclxuICAgICAgICB1cmwgPSBgL2Vucm9sbC1yZXBvcnQvZ2V0LWVucm9sbC1yZXBvcnQ/ZnJvbV9kYXRlPSR7ZGF0ZX0mdG9fZGF0ZT0ke2RhdGV9YDtcclxuICAgICAgICBzZXRBbGxFbnJvbGxVcmwodHJ1ZSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdXJsID0gYC9lbnJvbGwvZ2V0LWdyb3VwLWVucm9sbC8ke2dyb3VwSWR9YDtcclxuICAgICAgICBzZXRBbGxFbnJvbGxVcmwoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0VGFibGVFbnJvbGxzKFtdKTtcclxuICAgICAgICBzZXRJc0RhdGFUYWJsZUxvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KHVybCk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlLmRhdGEubWFwKChncm91cCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgaWYgKCFncm91cD8uZ3JvdXBfaWQgfHwgIWdyb3VwPy51c2VyX2lkKSByZXR1cm4ge307XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgc2VsZWN0OiAoXHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0ZWRFbnJvbGxtZW50cy5pbmNsdWRlcyhncm91cC5faWQpfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUVucm9sbG1lbnRTZWxlY3QoZ3JvdXAuX2lkLCBlKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jaGVja2JveCBoLTQgdy00IHRleHQtdmlvbGV0LTYwMFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgX2lkOiBncm91cD8uX2lkLFxyXG4gICAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgbmFtZTogZ3JvdXA/LnVzZXJfaWQ/LmZ1bGxfbmFtZSxcclxuICAgICAgICAgICAgICBwaG9uZV9udW1iZXI6IGdyb3VwPy51c2VyX2lkPy5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgICAgZ3JvdXBfbmFtZTogZ3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9uYW1lLFxyXG4gICAgICAgICAgICAgIHBheW1lbnRfdHlwZTogZ3JvdXA/LnBheW1lbnRfdHlwZSxcclxuICAgICAgICAgICAgICBlbnJvbGxtZW50X2RhdGU6IGdyb3VwPy5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICAgICAgICBjaGl0X2Fza2luZ19tb250aDogZ3JvdXA/LmNoaXRfYXNraW5nX21vbnRoLFxyXG4gICAgICAgICAgICAgIHJlZmVycmVkX3R5cGU6IGdyb3VwPy5yZWZlcnJlZF90eXBlLFxyXG4gICAgICAgICAgICAgIHJlZmVycmVkX2J5OlxyXG4gICAgICAgICAgICAgICAgZ3JvdXA/LmFnZW50Py5uYW1lICYmIGdyb3VwPy5hZ2VudD8ucGhvbmVfbnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgID8gYCR7Z3JvdXAuYWdlbnQubmFtZX0gfCAke2dyb3VwLmFnZW50LnBob25lX251bWJlcn1gXHJcbiAgICAgICAgICAgICAgICAgIDogZ3JvdXA/LnJlZmVycmVkX2N1c3RvbWVyPy5mdWxsX25hbWUgJiZcclxuICAgICAgICAgICAgICAgICAgICBncm91cD8ucmVmZXJyZWRfY3VzdG9tZXI/LnBob25lX251bWJlclxyXG4gICAgICAgICAgICAgICAgICA/IGAke2dyb3VwLnJlZmVycmVkX2N1c3RvbWVyLmZ1bGxfbmFtZX0gfCAke2dyb3VwPy5yZWZlcnJlZF9jdXN0b21lcj8ucGhvbmVfbnVtYmVyfWBcclxuICAgICAgICAgICAgICAgICAgOiBncm91cD8ucmVmZXJyZWRfbGVhZD8ubGVhZF9uYW1lICYmXHJcbiAgICAgICAgICAgICAgICAgICAgZ3JvdXA/LnJlZmVycmVkX2xlYWQ/LmFnZW50X251bWJlclxyXG4gICAgICAgICAgICAgICAgICA/IGAke2dyb3VwLnJlZmVycmVkX2xlYWQubGVhZF9uYW1lfSB8ICR7Z3JvdXAucmVmZXJyZWRfbGVhZC5hZ2VudF9udW1iZXJ9YFxyXG4gICAgICAgICAgICAgICAgICA6IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgdGlja2V0OiBncm91cC50aWNrZXRzLFxyXG4gICAgICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVZpZXdEZXRhaWxzKGdyb3VwLl9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZpZXcgRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgc2V0VGFibGVFbnJvbGxzKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKFtdKTtcclxuICAgICAgICAgIHNldFRhYmxlRW5yb2xscyhbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbnJvbGxtZW50IFwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRVc2VycyhbXSk7XHJcbiAgICAgICAgc2V0VGFibGVFbnJvbGxzKFtdKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0RhdGFUYWJsZUxvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRGaWx0ZXJlZFVzZXJzKFtdKTtcclxuICAgICAgc2V0VGFibGVFbnJvbGxzKFtdKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuIFxyXG5cclxuY29uc3QgaGFuZGxlU2VsZWN0QWxsID0gKGUpID0+IHtcclxuICBpZiAoZS50YXJnZXQuY2hlY2tlZCkge1xyXG4gICAgY29uc3QgYWxsSWRzID0gVGFibGVFbnJvbGxzLm1hcCgoZW5yb2xsKSA9PiBlbnJvbGwuX2lkKTtcclxuICAgIHNldFNlbGVjdGVkRW5yb2xsbWVudHMoYWxsSWRzKTtcclxuICB9IGVsc2Uge1xyXG4gICAgc2V0U2VsZWN0ZWRFbnJvbGxtZW50cyhbXSk7XHJcbiAgfVxyXG59O1xyXG5cclxuY29uc3QgaGFuZGxlRW5yb2xsbWVudFNlbGVjdCA9IChpZCkgPT4ge1xyXG4gIHNldFNlbGVjdGVkRW5yb2xsbWVudHMoKHByZXYpID0+XHJcbiAgICBwcmV2LmluY2x1ZGVzKGlkKVxyXG4gICAgICA/IHByZXYuZmlsdGVyKChlbikgPT4gZW4gIT09IGlkKVxyXG4gICAgICA6IFsuLi5wcmV2LCBpZF1cclxuICApO1xyXG59O1xyXG5cclxuICBjb25zdCBoYW5kbGVWaWV3RGV0YWlscyA9IGFzeW5jIChlbnJvbGxtZW50SWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL2Vucm9sbC9nZXQtZW5yb2xsLWJ5LWlkLyR7ZW5yb2xsbWVudElkfWApO1xyXG4gICAgICBjb25zdCBlbnJvbGxtZW50ID0gcmVzcG9uc2UuZGF0YTtcclxuXHJcbiAgICAgIG5vdGlmaWNhdGlvbi5pbmZvKHtcclxuICAgICAgICBtZXNzYWdlOiAnRW5yb2xsbWVudCBEZXRhaWxzJyxcclxuICAgICAgICBkZXNjcmlwdGlvbjogKFxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPHA+PHN0cm9uZz5DdXN0b21lcjo8L3N0cm9uZz4ge2Vucm9sbG1lbnQudXNlcl9pZD8uZnVsbF9uYW1lfTwvcD5cclxuICAgICAgICAgICAgPHA+PHN0cm9uZz5QaG9uZTo8L3N0cm9uZz4ge2Vucm9sbG1lbnQudXNlcl9pZD8ucGhvbmVfbnVtYmVyfTwvcD5cclxuICAgICAgICAgICAgPHA+PHN0cm9uZz5Hcm91cDo8L3N0cm9uZz4ge2Vucm9sbG1lbnQuZ3JvdXBfaWQ/Lmdyb3VwX25hbWV9PC9wPlxyXG4gICAgICAgICAgICA8cD48c3Ryb25nPlRpY2tldDo8L3N0cm9uZz4ge2Vucm9sbG1lbnQudGlja2V0c308L3A+XHJcbiAgICAgICAgICAgIDxwPjxzdHJvbmc+UGF5bWVudCBUeXBlOjwvc3Ryb25nPiB7ZW5yb2xsbWVudC5wYXltZW50X3R5cGV9PC9wPlxyXG4gICAgICAgICAgICA8cD48c3Ryb25nPkVucm9sbG1lbnQgRGF0ZTo8L3N0cm9uZz4ge25ldyBEYXRlKGVucm9sbG1lbnQuY3JlYXRlZEF0KS50b0xvY2FsZURhdGVTdHJpbmcoKX08L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApLFxyXG4gICAgICAgIGR1cmF0aW9uOiA1XHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVucm9sbG1lbnQgZGV0YWlsczpcIiwgZXJyb3IpO1xyXG4gICAgICBub3RpZmljYXRpb24uZXJyb3Ioe1xyXG4gICAgICAgIG1lc3NhZ2U6ICdFcnJvcicsXHJcbiAgICAgICAgZGVzY3JpcHRpb246ICdGYWlsZWQgdG8gZmV0Y2ggZW5yb2xsbWVudCBkZXRhaWxzJ1xyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVPcGVuUGF5bWVudExpbmtNb2RhbCA9ICgpID0+IHtcclxuICAgIGlmIChzZWxlY3RlZEVucm9sbG1lbnRzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICBub3RpZmljYXRpb24ud2FybmluZyh7XHJcbiAgICAgICAgbWVzc2FnZTogJ05vIFNlbGVjdGlvbicsXHJcbiAgICAgICAgZGVzY3JpcHRpb246ICdQbGVhc2Ugc2VsZWN0IGF0IGxlYXN0IG9uZSBlbnJvbGxtZW50IHRvIGNyZWF0ZSBwYXltZW50IGxpbmtzJ1xyXG4gICAgICB9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgc2V0U2hvd1BheW1lbnRMaW5rTW9kYWwodHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUGF5bWVudExpbmtDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSwgdHlwZSwgY2hlY2tlZCB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRQYXltZW50TGlua0Zvcm0oKHByZXYpID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIFtuYW1lXTogdHlwZSA9PT0gJ2NoZWNrYm94JyA/IGNoZWNrZWQgOiB2YWx1ZVxyXG4gICAgfSkpO1xyXG4gICAgc2V0UGF5bWVudExpbmtFcnJvcnMoKHByZXYpID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIFtuYW1lXTogXCJcIlxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHZhbGlkYXRlUGF5bWVudExpbmtGb3JtID0gKCkgPT4ge1xyXG4gICAgY29uc3QgZXJyb3JzID0ge307XHJcbiAgICBjb25zdCBhbW91bnQgPSBwYXJzZUZsb2F0KHBheW1lbnRMaW5rRm9ybS5hbW91bnQpO1xyXG5cclxuICAgIGlmICghcGF5bWVudExpbmtGb3JtLmFtb3VudCB8fCBpc05hTihhbW91bnQpIHx8IGFtb3VudCA8PSAwKSB7XHJcbiAgICAgIGVycm9ycy5hbW91bnQgPSBcIlBsZWFzZSBlbnRlciBhIHZhbGlkIHBvc2l0aXZlIGFtb3VudFwiO1xyXG4gICAgfVxyXG5cclxuICAgIHNldFBheW1lbnRMaW5rRXJyb3JzKGVycm9ycyk7XHJcbiAgICByZXR1cm4gT2JqZWN0LmtleXMoZXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUGF5bWVudExpbmtTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cclxuICAgIGlmICghdmFsaWRhdGVQYXltZW50TGlua0Zvcm0oKSkge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgIGNvbnN0IHNlbGVjdGVkRGV0YWlscyA9IFRhYmxlRW5yb2xscy5maWx0ZXIoKGVucm9sbCkgPT5cclxuICAgICAgICBzZWxlY3RlZEVucm9sbG1lbnRzLmluY2x1ZGVzKGVucm9sbC5faWQpXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBjb25zdCBwYXlsb2FkcyA9IHNlbGVjdGVkRGV0YWlscy5tYXAoKGVucm9sbG1lbnQpID0+ICh7XHJcbiAgICAgICAgdXNlcl9pZDogZW5yb2xsbWVudC51c2VyX2lkLFxyXG4gICAgICAgIGdyb3VwX2lkOiBlbnJvbGxtZW50Lmdyb3VwX2lkPy5faWQsXHJcbiAgICAgICAgdGlja2V0OiBlbnJvbGxtZW50LnRpY2tldCxcclxuICAgICAgICBhbW91bnQ6IHBhcnNlRmxvYXQocGF5bWVudExpbmtGb3JtLmFtb3VudCksXHJcbiAgICAgICAgZXhwaXJ5OiBwYXltZW50TGlua0Zvcm0uZXhwaXJ5LFxyXG4gICAgICAgIHNlbmRfc21zOiBwYXltZW50TGlua0Zvcm0uc2VuZF9zbXMsXHJcbiAgICAgICAgc2VuZF9lbWFpbDogcGF5bWVudExpbmtGb3JtLnNlbmRfZW1haWwsXHJcbiAgICAgICAgcGF5bWVudF9ncm91cF90aWNrZXRzOiBbXHJcbiAgICAgICAgICBgY2hpdC0ke2Vucm9sbG1lbnQuZ3JvdXBfaWQ/Ll9pZH18JHtlbnJvbGxtZW50LnRpY2tldH1gXHJcbiAgICAgICAgXVxyXG4gICAgICB9KSk7XHJcblxyXG4gICAgICBjb25zdCByZXN1bHRzID0gW107XHJcbiAgICAgIGZvciAoY29uc3QgcGF5bG9hZCBvZiBwYXlsb2Fkcykge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KFwiL3BheW1lbnRhcGkvcGF5bWVudC1saW5rXCIsIHBheWxvYWQpO1xyXG4gICAgICAgICAgcmVzdWx0cy5wdXNoKHsgc3VjY2VzczogdHJ1ZSwgZW5yb2xsbWVudDogcGF5bG9hZCwgcmVzcG9uc2UgfSk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgIHJlc3VsdHMucHVzaCh7IHN1Y2Nlc3M6IGZhbHNlLCBlbnJvbGxtZW50OiBwYXlsb2FkLCBlcnJvciB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IHN1Y2Nlc3NDb3VudCA9IHJlc3VsdHMuZmlsdGVyKHIgPT4gci5zdWNjZXNzKS5sZW5ndGg7XHJcbiAgICAgIGNvbnN0IGZhaWx1cmVDb3VudCA9IHJlc3VsdHMubGVuZ3RoIC0gc3VjY2Vzc0NvdW50O1xyXG5cclxuICAgICAgaWYgKHN1Y2Nlc3NDb3VudCA+IDApIHtcclxuICAgICAgICBzZXRBbGVydCh7XHJcbiAgICAgICAgICB2aXNpYmxlOiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogYFN1Y2Nlc3NmdWxseSBjcmVhdGVkICR7c3VjY2Vzc0NvdW50fSBwYXltZW50IGxpbmske3N1Y2Nlc3NDb3VudCA+IDEgPyAncycgOiAnJ31gLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCJcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgc2V0U2VsZWN0QWxsKGZhbHNlKTtcclxuICAgICAgICBzZXRTZWxlY3RlZEVucm9sbG1lbnRzKFtdKTtcclxuICAgICAgICBzZXRTaG93UGF5bWVudExpbmtNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgc2V0UGF5bWVudExpbmtGb3JtKHtcclxuICAgICAgICAgIGFtb3VudDogXCJcIixcclxuICAgICAgICAgIGV4cGlyeTogZGF5anMoKS5hZGQoMSwgXCJkYXlcIikuZm9ybWF0KFwiWVlZWS1NTS1ERFwiKSxcclxuICAgICAgICAgIHNlbmRfc21zOiB0cnVlLFxyXG4gICAgICAgICAgc2VuZF9lbWFpbDogdHJ1ZVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAoZmFpbHVyZUNvdW50ID4gMCkge1xyXG4gICAgICAgIG5vdGlmaWNhdGlvbi5lcnJvcih7XHJcbiAgICAgICAgICBtZXNzYWdlOiAnUGF5bWVudCBMaW5rIENyZWF0aW9uJyxcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBgRmFpbGVkIHRvIGNyZWF0ZSAke2ZhaWx1cmVDb3VudH0gcGF5bWVudCBsaW5rJHtmYWlsdXJlQ291bnQgPiAxID8gJ3MnIDogJyd9YFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgY3JlYXRpbmcgcGF5bWVudCBsaW5rczpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydCh7XHJcbiAgICAgICAgdmlzaWJsZTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkVycm9yIGNyZWF0aW5nIHBheW1lbnQgbGlua3NcIixcclxuICAgICAgICB0eXBlOiBcImVycm9yXCJcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBDb2x1bW5zIGNvbmZpZ3VyYXRpb25cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAge1xyXG4gIGtleTogXCJzZWxlY3RcIixcclxuICBoZWFkZXI6IChcclxuICAgIDxpbnB1dFxyXG4gICAgICByZWY9e3NlbGVjdEFsbENoZWNrYm94UmVmfVxyXG4gICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICBjaGVja2VkPXtzZWxlY3RlZEVucm9sbG1lbnRzLmxlbmd0aCA9PT0gVGFibGVFbnJvbGxzLmxlbmd0aCAmJiBUYWJsZUVucm9sbHMubGVuZ3RoID4gMH1cclxuICAgICAgb25DaGFuZ2U9e2hhbmRsZVNlbGVjdEFsbH1cclxuICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jaGVja2JveCBoLTQgdy00IHRleHQtdmlvbGV0LTYwMFwiXHJcbiAgICAvPlxyXG4gICksXHJcbiAgcmVuZGVyOiAocm93KSA9PiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17c2VsZWN0ZWRFbnJvbGxtZW50cy5pbmNsdWRlcyhyb3cuX2lkKSA/IFwiYmctdmlvbGV0LTEwMFwiIDogXCJcIn0+XHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgY2hlY2tlZD17c2VsZWN0ZWRFbnJvbGxtZW50cy5pbmNsdWRlcyhyb3cuX2lkKX1cclxuICAgICAgICBvbkNoYW5nZT17KCkgPT4gaGFuZGxlRW5yb2xsbWVudFNlbGVjdChyb3cuX2lkKX1cclxuICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWNoZWNrYm94IGgtNCB3LTQgdGV4dC12aW9sZXQtNjAwXCJcclxuICAgICAgLz5cclxuICAgIDwvZGl2PlxyXG4gICksXHJcbn0sXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJDdXN0b21lciBQaG9uZSBOdW1iZXJcIiB9LFxyXG4gIF07XHJcblxyXG4gIGlmIChhbGxFbnJvbGxVcmwpIHtcclxuICAgIGNvbHVtbnMucHVzaCh7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJFbnJvbGxlZCBHcm91cFwiIH0pO1xyXG4gIH1cclxuXHJcbiAgY29sdW1ucy5wdXNoKFxyXG4gICAgeyBrZXk6IFwidGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXQgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcInJlZmVycmVkX3R5cGVcIiwgaGVhZGVyOiBcIlJlZmVycmVkIFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5bWVudF90eXBlXCIsIGhlYWRlcjogXCJQYXltZW50IFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZW5yb2xsbWVudF9kYXRlXCIsIGhlYWRlcjogXCJFbnJvbGxtZW50IERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY2hpdF9hc2tpbmdfbW9udGhcIiwgaGVhZGVyOiBcIkNoaXQgQXNraW5nIE1vbnRoXCIgfSxcclxuICAgIHsga2V5OiBcInJlZmVycmVkX2J5XCIsIGhlYWRlcjogXCJSZWZlcnJlZCBCeVwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH1cclxuICApO1xyXG5cclxuICBjb25zdCBzZWxlY3RlZG5ld0dyb3VwID0gZ3JvdXBzLmZpbmQoKGcpID0+IGcuX2lkID09PSBzZWxlY3RlZEdyb3VwKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgIFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiID5cclxuICAgICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17R2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn1cclxuICAgICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICB7YWxlcnQudmlzaWJsZSAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgdG9wLTQgcmlnaHQtNCB6LTUwIHctOTZcIj5cclxuICAgICAgICAgICAgICA8QWxlcnRcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Lm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICB0eXBlPXthbGVydC50eXBlfVxyXG4gICAgICAgICAgICAgICAgc2hvd0ljb25cclxuICAgICAgICAgICAgICAgIGNsb3NhYmxlXHJcbiAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRBbGVydCh7IC4uLmFsZXJ0LCB2aXNpYmxlOiBmYWxzZSB9KX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+QnVsayBQYXltZW50IExpbms8L2gxPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsPlNlYXJjaCBvciBTZWxlY3QgR3JvdXA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHctZnVsbCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkR3JvdXAgfHwgXCJ0b2RheVwifVxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbj8udG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgPy50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQ/LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggb3IgU2VsZWN0IEdyb3VwXCJcclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUdyb3VwQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgaC0xNCAgIHctZnVsbCBtYXgtdy1tZFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT1cInRvZGF5XCIgdmFsdWU9XCJ0b2RheVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFRvZGF5J3MgRW5yb2xsbWVudFxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIHtncm91cHMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cC5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRFbnJvbGxtZW50cy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVPcGVuUGF5bWVudExpbmtNb2RhbH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXZpb2xldC02MDAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZCBob3ZlcjpiZy12aW9sZXQtNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBBZGQgUGF5bWVudCBMaW5rICh7c2VsZWN0ZWRFbnJvbGxtZW50cy5sZW5ndGh9KVxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHtUYWJsZUVucm9sbHM/Lmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbihUYWJsZUVucm9sbHMsIHNlYXJjaFRleHQpfVxyXG4gICAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgRW5yb2xsbWVudHMtJHtcclxuICAgICAgICAgICAgICAgICAgICBUYWJsZUVucm9sbHMubGVuZ3RoID4gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBUYWJsZUVucm9sbHNbMF0ubmFtZSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiIHRvIFwiICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgVGFibGVFbnJvbGxzW1RhYmxlRW5yb2xscy5sZW5ndGggLSAxXS5uYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiZW1wdHlcIlxyXG4gICAgICAgICAgICAgICAgICB9LmNzdmB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0RhdGFUYWJsZUxvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgIGZhaWx1cmU9e1RhYmxlRW5yb2xscz8ubGVuZ3RoIDw9IDAgJiYgc2VsZWN0ZWRHcm91cH1cclxuICAgICAgICAgICAgICAgICAgZGF0YT17XCJFbnJvbGxtZW50IERhdGFcIn1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dQYXltZW50TGlua01vZGFsfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRTaG93UGF5bWVudExpbmtNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldFBheW1lbnRMaW5rRXJyb3JzKHt9KTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTYgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBib3JkZXItYiBwYi0yXCI+XHJcbiAgICAgICAgICAgICAgQ3JlYXRlIFBheW1lbnQgTGlua3NcclxuICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBwLTMgYmctdmlvbGV0LTUwIHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdmlvbGV0LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgQ3JlYXRpbmcgcGF5bWVudCBsaW5rcyBmb3Ige3NlbGVjdGVkRW5yb2xsbWVudHMubGVuZ3RofSBzZWxlY3RlZCBlbnJvbGxtZW50e3NlbGVjdGVkRW5yb2xsbWVudHMubGVuZ3RoID4gMSA/ICdzJyA6ICcnfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgbWF4LWgtNDAgb3ZlcmZsb3cteS1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICB7VGFibGVFbnJvbGxzLmZpbHRlcihlbnJvbGwgPT4gc2VsZWN0ZWRFbnJvbGxtZW50cy5pbmNsdWRlcyhlbnJvbGwuX2lkKSkubWFwKChlbnJvbGxtZW50LCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aW5kZXh9IGNsYXNzTmFtZT1cInRleHQtc20gcHktMSBib3JkZXItYiBib3JkZXItdmlvbGV0LTEwMCBsYXN0OmJvcmRlci0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vucm9sbG1lbnQubmFtZX0gfCB7ZW5yb2xsbWVudC5waG9uZV9udW1iZXJ9IHwge2Vucm9sbG1lbnQuZ3JvdXBfbmFtZX0gfCBUaWNrZXQge2Vucm9sbG1lbnQudGlja2V0fVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNVwiIG9uU3VibWl0PXtoYW5kbGVQYXltZW50TGlua1N1Ym1pdH0+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgQW1vdW50IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3BheW1lbnRMaW5rRm9ybS5hbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQYXltZW50TGlua0NoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgIG1pbj1cIjAuMDFcIlxyXG4gICAgICAgICAgICAgICAgICBzdGVwPVwiMC4wMVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAge3BheW1lbnRMaW5rRXJyb3JzLmFtb3VudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXJlZC01MDBcIj57cGF5bWVudExpbmtFcnJvcnMuYW1vdW50fTwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEV4cGlyeSBEYXRlXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cImV4cGlyeVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXltZW50TGlua0Zvcm0uZXhwaXJ5fVxyXG4gICAgICAgICAgICAgICAgICBtaW49e2RheWpzKCkuZm9ybWF0KFwiWVlZWS1NTS1ERFwiKX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVBheW1lbnRMaW5rQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJzZW5kX3Ntc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwic2VuZF9zbXNcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3BheW1lbnRMaW5rRm9ybS5zZW5kX3Ntc31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlUGF5bWVudExpbmtDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LXZpb2xldC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInNlbmRfc21zXCIgY2xhc3NOYW1lPVwibWwtMiB0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBTZW5kIFNNU1xyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICBpZD1cInNlbmRfZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInNlbmRfZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3BheW1lbnRMaW5rRm9ybS5zZW5kX2VtYWlsfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQYXltZW50TGlua0NoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtdmlvbGV0LTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwic2VuZF9lbWFpbFwiIGNsYXNzTmFtZT1cIm1sLTIgdGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgU2VuZCBFbWFpbFxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBwdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNSBweS0yLjUgcm91bmRlZC1sZyBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWNvbG9ycyAke1xyXG4gICAgICAgICAgICAgICAgICAgIGxvYWRpbmcgPyBcImJnLWdyYXktNDAwIGN1cnNvci1ub3QtYWxsb3dlZFwiIDogXCJiZy12aW9sZXQtOTUwIHRleHQtd2hpdGUgaG92ZXI6YmctdmlvbGV0LTgwMFwiXHJcbiAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7bG9hZGluZyA/IFwiQ3JlYXRpbmcuLi5cIiA6IFwiQ3JlYXRlIFBheW1lbnQgTGlua3NcIn1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBCdWxrQ2hpdFBheW1lbnRMaW5rOyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9CdWxrQ2hpdFBheW1lbnRMaW5rLmpzeCJ9