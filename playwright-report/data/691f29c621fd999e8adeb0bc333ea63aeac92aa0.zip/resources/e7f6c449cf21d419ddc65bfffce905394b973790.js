import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/TransferMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import {
  ArrowLeft,
  Loader2,
  CheckCircle,
  XCircle,
  AlertCircle,
  RefreshCw,
  Calendar,
  FileText,
  TrendingUp,
  Users,
  CreditCard,
  Send,
  Info,
  Search,
  User,
  Tag,
  Package,
  X,
  Zap,
  Eye,
  DollarSign,
  Receipt,
  Clock,
  ArrowRight
} from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
const TransferMenu = () => {
  _s();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(null);
  const [error, setError] = useState(null);
  const [transferResult, setTransferResult] = useState(null);
  const [showPreview, setShowPreview] = useState(false);
  const [previewData, setPreviewData] = useState(null);
  const [isLoadingPreview, setIsLoadingPreview] = useState(false);
  const [allEnrollments, setAllEnrollments] = useState([]);
  const [isLoadingEnrollments, setIsLoadingEnrollments] = useState(false);
  const [fromSearch, setFromSearch] = useState("");
  const [toSearch, setToSearch] = useState("");
  const [fromResults, setFromResults] = useState([]);
  const [toResults, setToResults] = useState([]);
  const [showFromDropdown, setShowFromDropdown] = useState(false);
  const [showToDropdown, setShowToDropdown] = useState(false);
  const [formData, setFormData] = useState({
    fromEnrollId: "",
    toEnrollId: "",
    fromDisplay: "",
    toDisplay: "",
    fromEnrollDetails: null,
    toEnrollDetails: null
  });
  const fromRef = useRef();
  const toRef = useRef();
  useEffect(() => {
    if (allEnrollments.length === 0) return;
    const params = new URLSearchParams(location.search);
    const sourceId = params.get("sourceEnrollmentId");
    const destId = params.get("destEnrollmentId");
    if (sourceId && !formData.fromEnrollId) {
      const source = allEnrollments.find((e) => e._id === sourceId);
      if (source) handleSelectEnrollment(source, "from");
    }
    if (destId && !formData.toEnrollId) {
      const dest = allEnrollments.find((e) => e._id === destId);
      if (dest) handleSelectEnrollment(dest, "to");
    }
  }, [allEnrollments, location.search, formData.fromEnrollId, formData.toEnrollId]);
  useEffect(() => {
    if (allEnrollments.length === 0) return;
    const params = new URLSearchParams(location.search);
    const sourceId = params.get("sourceEnrollmentId");
    const destId = params.get("destEnrollmentId");
    if (sourceId && !formData.fromEnrollId) {
      const source = allEnrollments.find((e) => e._id === sourceId);
      if (source) handleSelectEnrollment(source, "from");
    }
    if (destId && !formData.toEnrollId) {
      const dest = allEnrollments.find((e) => e._id === destId);
      if (dest) handleSelectEnrollment(dest, "to");
    }
  }, [allEnrollments, location.search, formData.fromEnrollId, formData.toEnrollId]);
  useEffect(() => {
    fetchAllEnrollments();
  }, []);
  const fetchAllEnrollments = async () => {
    setIsLoadingEnrollments(true);
    try {
      const response = await api.get("/v1/admin/enrolls/get-all-enrolls");
      if (response.data.statusCode === 200 || response.data.status === true) {
        const enrollments = response.data.data || response.data.enrolls || [];
        setAllEnrollments(enrollments);
      } else {
        console.error("Unexpected response structure:", response.data);
      }
    } catch (err) {
      console.error("Error fetching enrollments:", err);
      setError("Failed to load enrollments. Please refresh the page.");
    } finally {
      setIsLoadingEnrollments(false);
    }
  };
  const fetchPaymentBalance = async (enrollId, ticket) => {
    try {
      const response = await api.get(`/v1/admin/enrolls/${enrollId}/payments/totalamount`);
      return response.data?.data?.total_amount || 0;
    } catch (err) {
      console.error("Error fetching balance:", err);
      return 0;
    }
  };
  const fetchPaymentPreview = async () => {
    if (!formData.fromEnrollId || !formData.toEnrollId) {
      setError("Please select both source and destination enrollments first");
      return;
    }
    setIsLoadingPreview(true);
    setError(null);
    try {
      const sourceEnroll = allEnrollments.find((e) => e._id === formData.fromEnrollId);
      const destEnroll = allEnrollments.find((e) => e._id === formData.toEnrollId);
      const sourceBalance = await fetchPaymentBalance(formData.fromEnrollId, sourceEnroll?.tickets || sourceEnroll?.ticket);
      const destBalance = await fetchPaymentBalance(formData.toEnrollId, destEnroll?.tickets || destEnroll?.ticket);
      const afterSourceBalance = 0;
      const afterDestBalance = destBalance + sourceBalance;
      setPreviewData({
        sourceEnroll,
        destEnroll,
        sourceTicket: sourceEnroll?.tickets || sourceEnroll?.ticket || "N/A",
        destTicket: destEnroll?.tickets || destEnroll?.ticket || "N/A",
        sourceCustomer: sourceEnroll?.user_id?.full_name || "Unknown",
        destCustomer: destEnroll?.user_id?.full_name || "Unknown",
        sourceGroup: sourceEnroll?.group_id?.group_name || "Unknown",
        destGroup: destEnroll?.group_id?.group_name || "Unknown",
        sourceCurrentBalance: sourceBalance,
        destCurrentBalance: destBalance,
        transferAmount: sourceBalance,
        afterSourceBalance,
        afterDestBalance
      });
      setShowPreview(true);
    } catch (err) {
      console.error("Error fetching preview:", err);
      setError("Failed to fetch payment preview. Please try again.");
    } finally {
      setIsLoadingPreview(false);
    }
  };
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      minimumFractionDigits: 2
    }).format(amount || 0);
  };
  const formatDate = (date) => {
    if (!date) return "N/A";
    return new Date(date).toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric"
    });
  };
  const searchEnrollments = (searchTerm, type) => {
    if (!searchTerm.trim()) {
      if (type === "from") setFromResults([]);
      if (type === "to") setToResults([]);
      return;
    }
    const searchLower = searchTerm.toLowerCase();
    const filtered = allEnrollments.filter((enrolls) => {
      const customerName = enrolls.user_id?.full_name || "";
      const groupName = enrolls.group_id?.group_name || "";
      const ticket = String(enrolls.tickets || enrolls.ticket || "");
      const customerEmail = enrolls.user_id?.email || "";
      const customerPhone = enrolls.user_id?.phone_number || "";
      return customerName.toLowerCase().includes(searchLower) || groupName.toLowerCase().includes(searchLower) || ticket.toLowerCase().includes(searchLower) || customerEmail.toLowerCase().includes(searchLower) || customerPhone.includes(searchTerm);
    });
    if (type === "from") {
      setFromResults(filtered.slice(0, 10));
      setShowFromDropdown(true);
    } else {
      setToResults(filtered.slice(0, 10));
      setShowToDropdown(true);
    }
  };
  const handleSelectEnrollment = (enrolls, type) => {
    const customerName = enrolls.user_id?.full_name || "Unknown Customer";
    const groupName = enrolls.group_id?.group_name || "Unknown Group";
    const ticket = enrolls.tickets || enrolls.ticket || "N/A";
    const displayText = `${customerName} | ${groupName} | ${ticket}`;
    if (type === "from") {
      setFormData((prev) => ({
        ...prev,
        fromEnrollId: enrolls._id,
        fromDisplay: displayText,
        fromEnrollDetails: enrolls
      }));
      setFromSearch("");
      setShowFromDropdown(false);
    } else {
      setFormData((prev) => ({
        ...prev,
        toEnrollId: enrolls._id,
        toDisplay: displayText,
        toEnrollDetails: enrolls
      }));
      setToSearch("");
      setShowToDropdown(false);
    }
    setSuccess(null);
    setError(null);
    setTransferResult(null);
    setShowPreview(false);
    setPreviewData(null);
  };
  const handleClearSelection = (type) => {
    if (type === "from") {
      setFormData((prev) => ({
        ...prev,
        fromEnrollId: "",
        fromDisplay: "",
        fromEnrollDetails: null
      }));
      setFromSearch("");
    } else {
      setFormData((prev) => ({
        ...prev,
        toEnrollId: "",
        toDisplay: "",
        toEnrollDetails: null
      }));
      setToSearch("");
    }
    setShowPreview(false);
    setPreviewData(null);
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.fromEnrollId || !formData.toEnrollId) {
      setError("Please select both source and destination enrollments");
      return;
    }
    if (formData.fromEnrollId === formData.toEnrollId) {
      setError("Source and destination enrollments cannot be the same");
      return;
    }
    setLoading(true);
    setError(null);
    setSuccess(null);
    setTransferResult(null);
    setShowPreview(false);
    try {
      const response = await api.post(
        `/v1/admin/enrolls/${formData.fromEnrollId}/${formData.toEnrollId}/payments/change`
      );
      if (response.data.status) {
        setSuccess(response.data.message);
        setTransferResult(response.data);
      } else {
        setError(response.data.message || "Transfer failed");
      }
    } catch (err) {
      setError(err.response?.data?.message || "An error occurred during transfer");
    } finally {
      setLoading(false);
    }
  };
  const handleReset = () => {
    setFormData({
      fromEnrollId: "",
      toEnrollId: "",
      fromDisplay: "",
      toDisplay: "",
      fromEnrollDetails: null,
      toEnrollDetails: null
    });
    setFromSearch("");
    setToSearch("");
    setSuccess(null);
    setError(null);
    setTransferResult(null);
    setShowPreview(false);
    setPreviewData(null);
  };
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (fromRef.current && !fromRef.current.contains(event.target)) {
        setShowFromDropdown(false);
      }
      if (toRef.current && !toRef.current.contains(event.target)) {
        setShowToDropdown(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen w-full bg-gradient-to-br from-gray-50 to-gray-100", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
      lineNumber: 474,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
        lineNumber: 476,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-6 lg:p-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => navigate(-1),
              className: "flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4 transition-colors group",
              children: [
                /* @__PURE__ */ jsxDEV(ArrowLeft, { className: "w-4 h-4 group-hover:-translate-x-1 transition-transform" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 485,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium", children: "Back" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 486,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
              lineNumber: 481,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between flex-wrap gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold text-gray-900 flex items-center gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl", children: /* @__PURE__ */ jsxDEV(TrendingUp, { className: "w-6 h-6 text-white" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 493,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 492,
                  columnNumber: 21
                }, this),
                "Group Change & Payment Transfer"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 491,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mt-2", children: "Transfer all payments from one enrollment to another" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 497,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
              lineNumber: 490,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 px-4 py-2 bg-blue-50 rounded-lg border border-blue-100", children: [
              /* @__PURE__ */ jsxDEV(Info, { className: "w-4 h-4 text-blue-600" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 503,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-blue-700", children: "Admin Action Required" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 504,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
              lineNumber: 502,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
            lineNumber: 489,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
          lineNumber: 480,
          columnNumber: 13
        }, this),
        isLoadingEnrollments ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center h-64", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
          lineNumber: 511,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
          lineNumber: 510,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-3 gap-8", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "lg:col-span-2", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "p-6 border-b border-gray-200 bg-gradient-to-r from-gray-50 to-white", children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-900 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(CreditCard, { className: "w-5 h-5 text-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 520,
                  columnNumber: 25
                }, this),
                "Transfer Details"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 519,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: "Search and select enrollments to transfer payments" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 523,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
              lineNumber: 518,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "p-6 space-y-6", children: [
              /* @__PURE__ */ jsxDEV("div", { ref: fromRef, children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(Users, { className: "w-4 h-4 text-red-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 533,
                    columnNumber: 29
                  }, this),
                  "Source Enrollment"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 532,
                  columnNumber: 27
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 531,
                  columnNumber: 25
                }, this),
                formData.fromDisplay ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-900", children: formData.fromDisplay }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 541,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: [
                      "ID: ",
                      formData.fromEnrollId
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 542,
                      columnNumber: 31
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 540,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleClearSelection("from"),
                      className: "p-1 hover:bg-red-200 rounded-lg transition-colors",
                      children: /* @__PURE__ */ jsxDEV(X, { className: "w-4 h-4 text-red-600" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                        lineNumber: 549,
                        columnNumber: 31
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 544,
                      columnNumber: 29
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 539,
                  columnNumber: 23
                }, this) : /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                    /* @__PURE__ */ jsxDEV(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 555,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        value: fromSearch,
                        onChange: (e) => {
                          setFromSearch(e.target.value);
                          searchEnrollments(e.target.value, "from");
                        },
                        onFocus: () => fromResults.length > 0 && setShowFromDropdown(true),
                        placeholder: "Search by customer name, group name, or ticket...",
                        className: "w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 transition-all outline-none",
                        disabled: loading
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                        lineNumber: 556,
                        columnNumber: 31
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 554,
                    columnNumber: 29
                  }, this),
                  showFromDropdown && fromResults.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-80 overflow-y-auto", children: fromResults.map(
                    (enroll) => /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleSelectEnrollment(enroll, "from"),
                        className: "w-full text-left p-3 hover:bg-gray-50 border-b border-gray-100 last:border-0 transition-colors",
                        children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-2", children: [
                          /* @__PURE__ */ jsxDEV(User, { className: "w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                            lineNumber: 580,
                            columnNumber: 39
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-900", children: enroll.user_id?.full_name || "Unknown Customer" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                              lineNumber: 582,
                              columnNumber: 41
                            }, this),
                            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2 mt-1", children: [
                              /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1 text-xs text-gray-500", children: [
                                /* @__PURE__ */ jsxDEV(Package, { className: "w-3 h-3" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                                  lineNumber: 587,
                                  columnNumber: 45
                                }, this),
                                enroll.group_id?.group_name || "No Group"
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                                lineNumber: 586,
                                columnNumber: 43
                              }, this),
                              /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1 text-xs text-gray-500", children: [
                                /* @__PURE__ */ jsxDEV(Tag, { className: "w-3 h-3" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                                  lineNumber: 591,
                                  columnNumber: 45
                                }, this),
                                "Ticket: ",
                                enroll.tickets || enroll.ticket || "N/A"
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                                lineNumber: 590,
                                columnNumber: 43
                              }, this)
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                              lineNumber: 585,
                              columnNumber: 41
                            }, this),
                            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-400 mt-1", children: [
                              "ID: ",
                              enroll._id
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                              lineNumber: 595,
                              columnNumber: 41
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                            lineNumber: 581,
                            columnNumber: 39
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                          lineNumber: 579,
                          columnNumber: 37
                        }, this)
                      },
                      enroll._id,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                        lineNumber: 573,
                        columnNumber: 27
                      },
                      this
                    )
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 571,
                    columnNumber: 25
                  }, this),
                  showFromDropdown && fromSearch && fromResults.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg p-4 text-center", children: /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "No enrollments found" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 607,
                    columnNumber: 33
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 606,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 553,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: "Payments will be transferred FROM this enrollment" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 613,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 530,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-2", children: /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center shadow-lg", children: /* @__PURE__ */ jsxDEV(Send, { className: "w-5 h-5 text-white" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 622,
                  columnNumber: 29
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 621,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full animate-ping" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 624,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 620,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 619,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { ref: toRef, children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(Users, { className: "w-4 h-4 text-green-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 632,
                    columnNumber: 29
                  }, this),
                  "Destination Enrollment"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 631,
                  columnNumber: 27
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 630,
                  columnNumber: 25
                }, this),
                formData.toDisplay ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 p-3 bg-green-50 border border-green-200 rounded-lg", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-900", children: formData.toDisplay }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 640,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: [
                      "ID: ",
                      formData.toEnrollId
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 641,
                      columnNumber: 31
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 639,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => handleClearSelection("to"),
                      className: "p-1 hover:bg-green-200 rounded-lg transition-colors",
                      children: /* @__PURE__ */ jsxDEV(X, { className: "w-4 h-4 text-green-600" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                        lineNumber: 648,
                        columnNumber: 31
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 643,
                      columnNumber: 29
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 638,
                  columnNumber: 23
                }, this) : /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                    /* @__PURE__ */ jsxDEV(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 654,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        value: toSearch,
                        onChange: (e) => {
                          setToSearch(e.target.value);
                          searchEnrollments(e.target.value, "to");
                        },
                        onFocus: () => toResults.length > 0 && setShowToDropdown(true),
                        placeholder: "Search by customer name, group name, or ticket...",
                        className: "w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all outline-none",
                        disabled: loading
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                        lineNumber: 655,
                        columnNumber: 31
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 653,
                    columnNumber: 29
                  }, this),
                  showToDropdown && toResults.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-80 overflow-y-auto", children: toResults.map(
                    (enroll) => /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "button",
                        onClick: () => handleSelectEnrollment(enroll, "to"),
                        className: "w-full text-left p-3 hover:bg-gray-50 border-b border-gray-100 last:border-0 transition-colors",
                        children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-2", children: [
                          /* @__PURE__ */ jsxDEV(User, { className: "w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                            lineNumber: 679,
                            columnNumber: 39
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-900", children: enroll.user_id?.full_name || "Unknown Customer" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                              lineNumber: 681,
                              columnNumber: 41
                            }, this),
                            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2 mt-1", children: [
                              /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1 text-xs text-gray-500", children: [
                                /* @__PURE__ */ jsxDEV(Package, { className: "w-3 h-3" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                                  lineNumber: 686,
                                  columnNumber: 45
                                }, this),
                                enroll.group_id?.group_name || "No Group"
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                                lineNumber: 685,
                                columnNumber: 43
                              }, this),
                              /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-1 text-xs text-gray-500", children: [
                                /* @__PURE__ */ jsxDEV(Tag, { className: "w-3 h-3" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                                  lineNumber: 690,
                                  columnNumber: 45
                                }, this),
                                "Ticket: ",
                                enroll.tickets || enroll.ticket || "N/A"
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                                lineNumber: 689,
                                columnNumber: 43
                              }, this)
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                              lineNumber: 684,
                              columnNumber: 41
                            }, this),
                            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-400 mt-1", children: [
                              "ID: ",
                              enroll._id
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                              lineNumber: 694,
                              columnNumber: 41
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                            lineNumber: 680,
                            columnNumber: 39
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                          lineNumber: 678,
                          columnNumber: 37
                        }, this)
                      },
                      enroll._id,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                        lineNumber: 672,
                        columnNumber: 27
                      },
                      this
                    )
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 670,
                    columnNumber: 25
                  }, this),
                  showToDropdown && toSearch && toResults.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg p-4 text-center", children: /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "No enrollments found" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 706,
                    columnNumber: 33
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 705,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 652,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: "All payments will be moved TO this enrollment" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 712,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 629,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3 pt-4", children: [
                formData.fromEnrollId && formData.toEnrollId && /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: fetchPaymentPreview,
                    disabled: loading || isLoadingPreview,
                    className: "bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed shadow-sm hover:shadow-md flex items-center justify-center gap-2",
                    children: isLoadingPreview ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                      /* @__PURE__ */ jsxDEV(Loader2, { className: "w-5 h-5 animate-spin" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                        lineNumber: 728,
                        columnNumber: 33
                      }, this),
                      "Loading Preview..."
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 727,
                      columnNumber: 25
                    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
                      /* @__PURE__ */ jsxDEV(Eye, { className: "w-5 h-5" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                        lineNumber: 733,
                        columnNumber: 33
                      }, this),
                      "Preview Transfer"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 732,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 720,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    disabled: loading || !formData.fromEnrollId || !formData.toEnrollId,
                    className: "flex-1 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed shadow-sm hover:shadow-md flex items-center justify-center gap-2",
                    children: loading ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                      /* @__PURE__ */ jsxDEV(Loader2, { className: "w-5 h-5 animate-spin" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                        lineNumber: 747,
                        columnNumber: 31
                      }, this),
                      "Processing Transfer..."
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 746,
                      columnNumber: 25
                    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
                      /* @__PURE__ */ jsxDEV(RefreshCw, { className: "w-5 h-5" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                        lineNumber: 752,
                        columnNumber: 31
                      }, this),
                      "Transfer Payments"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 751,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 740,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: handleReset,
                    disabled: loading,
                    className: "px-6 py-3 border border-gray-300 text-gray-700 font-semibold rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50",
                    children: "Reset"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 758,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 718,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
              lineNumber: 528,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
            lineNumber: 517,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
            lineNumber: 516,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-amber-50 rounded-2xl p-6 border border-amber-200", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
              /* @__PURE__ */ jsxDEV(AlertCircle, { className: "w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 776,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-amber-900 mb-1", children: "Important Notice" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 778,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-amber-800", children: "This action will permanently transfer all payments from the source enrollment to the destination enrollment. The source enrollment will be marked as transferred." }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 779,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 777,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
              lineNumber: 775,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
              lineNumber: 774,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl p-6 border border-gray-200", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-gray-900 mb-4 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(FileText, { className: "w-4 h-4 text-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 789,
                  columnNumber: 23
                }, this),
                "What gets transferred?"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 788,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("ul", { className: "space-y-3", children: [
                /* @__PURE__ */ jsxDEV("li", { className: "flex items-start gap-2 text-sm text-gray-600", children: [
                  /* @__PURE__ */ jsxDEV(CheckCircle, { className: "w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 794,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: "All payment records" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 795,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 793,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("li", { className: "flex items-start gap-2 text-sm text-gray-600", children: [
                  /* @__PURE__ */ jsxDEV(CheckCircle, { className: "w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 798,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: "Group and user associations" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 799,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 797,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("li", { className: "flex items-start gap-2 text-sm text-gray-600", children: [
                  /* @__PURE__ */ jsxDEV(CheckCircle, { className: "w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 802,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: "Ticket information" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 803,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 801,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("li", { className: "flex items-start gap-2 text-sm text-gray-600", children: [
                  /* @__PURE__ */ jsxDEV(Calendar, { className: "w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 806,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: "Creation timestamp from source" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 807,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 805,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 792,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
              lineNumber: 787,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-6 border border-blue-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
              /* @__PURE__ */ jsxDEV(Zap, { className: "w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 815,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-gray-900 mb-1", children: "Quick Tips" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 817,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-700", children: "Search by customer name, group name, or ticket number to find enrollments quickly." }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 818,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 816,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
              lineNumber: 814,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
              lineNumber: 813,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
            lineNumber: 772,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
          lineNumber: 514,
          columnNumber: 13
        }, this),
        showPreview && previewData && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-2xl max-w-5xl w-full max-h-[90vh] overflow-hidden", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "p-6 border-b border-gray-200 bg-gradient-to-r from-purple-50 to-white", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-purple-100 rounded-lg", children: /* @__PURE__ */ jsxDEV(Eye, { className: "w-6 h-6 text-purple-600" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 837,
                columnNumber: 27
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 836,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-gray-900", children: "Transfer Preview" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 840,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Review balance changes before proceeding" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 841,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 839,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
              lineNumber: 835,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setShowPreview(false),
                className: "p-2 hover:bg-gray-100 rounded-lg transition-colors",
                children: /* @__PURE__ */ jsxDEV(X, { className: "w-5 h-5 text-gray-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 848,
                  columnNumber: 25
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 844,
                columnNumber: 23
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
            lineNumber: 834,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
            lineNumber: 833,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-6 overflow-y-auto", style: { maxHeight: "calc(90vh - 180px)" }, children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-6 mb-6 text-white", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm opacity-90 mb-1", children: "Transfer Amount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 859,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold", children: formatCurrency(previewData.transferAmount) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 860,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 858,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm opacity-90 mb-1", children: "From Ticket" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 863,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-mono font-bold", children: [
                  "#",
                  previewData.sourceTicket
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 864,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 862,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(ArrowRight, { className: "w-8 h-8 opacity-75" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 866,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm opacity-90 mb-1", children: "To Ticket" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 868,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-mono font-bold", children: [
                  "#",
                  previewData.destTicket
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 869,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 867,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
              lineNumber: 857,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
              lineNumber: 856,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6 mb-6", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-red-50 rounded-xl p-5 border-2 border-red-200", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-red-900", children: "Source Ticket" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 880,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-red-700", children: [
                      "Ticket #",
                      previewData.sourceTicket
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 881,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 879,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs px-2 py-1 bg-red-200 text-red-800 rounded-full", children: "Before Transfer" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 883,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 878,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pb-2 border-b border-red-200", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-red-700", children: "Customer:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 888,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-red-900", children: previewData.sourceCustomer }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 889,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 887,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pb-2 border-b border-red-200", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-red-700", children: "Group:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 892,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-red-900", children: previewData.sourceGroup }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 893,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 891,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-red-800", children: "Current Balance:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 896,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-red-900", children: formatCurrency(previewData.sourceCurrentBalance) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 897,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 895,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 886,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 877,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-xl p-5 border-2 border-gray-300", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-gray-700", children: "Source Ticket" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 906,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-600", children: [
                      "Ticket #",
                      previewData.sourceTicket
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 907,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 905,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs px-2 py-1 bg-gray-300 text-gray-700 rounded-full", children: "After Transfer" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 909,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 904,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pb-2 border-b border-gray-200", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600", children: "Customer:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 914,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-500", children: previewData.sourceCustomer }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 915,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 913,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pb-2 border-b border-gray-200", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600", children: "Group:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 918,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-500", children: previewData.sourceGroup }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 919,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 917,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-700", children: "New Balance:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 922,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-gray-500", children: formatCurrency(0) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 923,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 921,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 912,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 903,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
              lineNumber: 875,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6 mb-6", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-yellow-50 rounded-xl p-5 border-2 border-yellow-200", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-yellow-900", children: "Destination Ticket" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 935,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-yellow-700", children: [
                      "Ticket #",
                      previewData.destTicket
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 936,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 934,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs px-2 py-1 bg-yellow-200 text-yellow-800 rounded-full", children: "Before Transfer" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 938,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 933,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pb-2 border-b border-yellow-200", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-yellow-700", children: "Customer:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 943,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-yellow-900", children: previewData.destCustomer }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 944,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 942,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pb-2 border-b border-yellow-200", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-yellow-700", children: "Group:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 947,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-yellow-900", children: previewData.destGroup }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 948,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 946,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-yellow-800", children: "Current Balance:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 951,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-yellow-900", children: formatCurrency(previewData.destCurrentBalance) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 952,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 950,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 941,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 932,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-green-50 rounded-xl p-5 border-2 border-green-200", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-green-900", children: "Destination Ticket" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 961,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-green-700", children: [
                      "Ticket #",
                      previewData.destTicket
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 962,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 960,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs px-2 py-1 bg-green-200 text-green-800 rounded-full", children: "After Transfer" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 964,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 959,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pb-2 border-b border-green-200", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-green-700", children: "Customer:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 969,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-green-900", children: previewData.destCustomer }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 970,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 968,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pb-2 border-b border-green-200", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-green-700", children: "Group:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 973,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-green-900", children: previewData.destGroup }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 974,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 972,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-green-800", children: "New Balance:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 977,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-green-900", children: [
                      "+ ",
                      formatCurrency(previewData.afterDestBalance)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                      lineNumber: 978,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 976,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 967,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 958,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
              lineNumber: 930,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-5 border border-blue-200", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-gray-900 mb-3 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(TrendingUp, { className: "w-5 h-5 text-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 987,
                  columnNumber: 25
                }, this),
                "Balance Change Summary"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 986,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center p-2 bg-white rounded-lg", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-700", children: [
                    "Source Ticket #",
                    previewData.sourceTicket
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 992,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-red-600", children: [
                    formatCurrency(previewData.sourceCurrentBalance),
                    " → ",
                    formatCurrency(0)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 993,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 991,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center p-2 bg-white rounded-lg", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-700", children: [
                    "Destination Ticket #",
                    previewData.destTicket
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 998,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-green-600", children: [
                    formatCurrency(previewData.destCurrentBalance),
                    " → ",
                    formatCurrency(previewData.afterDestBalance)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 999,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 997,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center p-2 bg-blue-100 rounded-lg mt-2", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-blue-800", children: "Total Amount Transferred" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 1004,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-bold text-blue-900", children: formatCurrency(previewData.transferAmount) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 1005,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 1003,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 990,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
              lineNumber: 985,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
            lineNumber: 854,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-6 border-t border-gray-200 bg-gray-50", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setShowPreview(false),
                className: "px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-100 transition-colors",
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 1014,
                columnNumber: 23
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setShowPreview(false);
                  handleSubmit(new Event("submit"));
                },
                className: "px-6 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-200 flex items-center gap-2 shadow-md",
                children: [
                  /* @__PURE__ */ jsxDEV(RefreshCw, { className: "w-4 h-4" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 1027,
                    columnNumber: 25
                  }, this),
                  "Confirm & Transfer ",
                  formatCurrency(previewData.transferAmount)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 1020,
                columnNumber: 23
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
            lineNumber: 1013,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
            lineNumber: 1012,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
          lineNumber: 831,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
          lineNumber: 830,
          columnNumber: 13
        }, this),
        (success || error || transferResult) && /* @__PURE__ */ jsxDEV("div", { className: "mt-8 animate-fadeIn", children: [
          success && /* @__PURE__ */ jsxDEV("div", { className: "bg-green-50 border border-green-200 rounded-2xl p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
            /* @__PURE__ */ jsxDEV(CheckCircle, { className: "w-6 h-6 text-green-600 flex-shrink-0" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
              lineNumber: 1042,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-green-900 mb-2", children: "Transfer Successful!" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 1044,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-green-800 mb-4", children: success }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 1045,
                columnNumber: 25
              }, this),
              transferResult && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 mt-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg p-4 border border-green-200", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mb-1", children: "Matched Payments" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 1050,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-900", children: transferResult.matchedPayments || 0 }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 1051,
                    columnNumber: 31
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 1049,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg p-4 border border-green-200", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mb-1", children: "Modified Payments" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 1054,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-900", children: transferResult.modifiedPayments || 0 }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 1055,
                    columnNumber: 31
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 1053,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg p-4 border border-green-200", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mb-1", children: "Ticket Transfer" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 1058,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-900", children: [
                    transferResult.fromTicket,
                    " → ",
                    transferResult.toTicket
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                    lineNumber: 1059,
                    columnNumber: 31
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                  lineNumber: 1057,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 1048,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
              lineNumber: 1043,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
            lineNumber: 1041,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
            lineNumber: 1040,
            columnNumber: 15
          }, this),
          error && /* @__PURE__ */ jsxDEV("div", { className: "bg-red-50 border border-red-200 rounded-2xl p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
            /* @__PURE__ */ jsxDEV(XCircle, { className: "w-6 h-6 text-red-600 flex-shrink-0" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
              lineNumber: 1073,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-red-900 mb-1", children: "Transfer Failed" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 1075,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-red-800", children: error }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
                lineNumber: 1076,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
              lineNumber: 1074,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
            lineNumber: 1072,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
            lineNumber: 1071,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
          lineNumber: 1038,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
        lineNumber: 478,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
      lineNumber: 475,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
    lineNumber: 473,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx",
    lineNumber: 472,
    columnNumber: 5
  }, this);
};
_s(TransferMenu, "t49y7/94OHVCsgLNxDnvyOLKNNk=", false, function() {
  return [useNavigate];
});
_c = TransferMenu;
export default TransferMenu;
var _c;
$RefreshReg$(_c, "TransferMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransferMenu.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeWRRLFNBNlBzQixVQTdQdEI7MkJBemRSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBaUhBLE9BQU9BLFNBQVNDLFVBQVVDLFdBQVdDLGNBQWM7QUFDbkQsU0FBU0MsbUJBQW1CO0FBQzVCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxvQkFBb0I7QUFDM0I7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsT0FBT0MsU0FBUztBQUVoQixNQUFNQyxlQUFlQSxNQUFNO0FBQUFDLEtBQUE7QUFDekIsUUFBTUMsV0FBVy9CLFlBQVk7QUFDN0IsUUFBTSxDQUFDZ0MsU0FBU0MsVUFBVSxJQUFJcEMsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ3FDLFNBQVNDLFVBQVUsSUFBSXRDLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUN1QyxPQUFPQyxRQUFRLElBQUl4QyxTQUFTLElBQUk7QUFDdkMsUUFBTSxDQUFDeUMsZ0JBQWdCQyxpQkFBaUIsSUFBSTFDLFNBQVMsSUFBSTtBQUd6RCxRQUFNLENBQUMyQyxhQUFhQyxjQUFjLElBQUk1QyxTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDNkMsYUFBYUMsY0FBYyxJQUFJOUMsU0FBUyxJQUFJO0FBQ25ELFFBQU0sQ0FBQytDLGtCQUFrQkMsbUJBQW1CLElBQUloRCxTQUFTLEtBQUs7QUFFOUQsUUFBTSxDQUFDaUQsZ0JBQWdCQyxpQkFBaUIsSUFBSWxELFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNtRCxzQkFBc0JDLHVCQUF1QixJQUFJcEQsU0FBUyxLQUFLO0FBRXRFLFFBQU0sQ0FBQ3FELFlBQVlDLGFBQWEsSUFBSXRELFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUN1RCxVQUFVQyxXQUFXLElBQUl4RCxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDeUQsYUFBYUMsY0FBYyxJQUFJMUQsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQzJELFdBQVdDLFlBQVksSUFBSTVELFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUM2RCxrQkFBa0JDLG1CQUFtQixJQUFJOUQsU0FBUyxLQUFLO0FBQzlELFFBQU0sQ0FBQytELGdCQUFnQkMsaUJBQWlCLElBQUloRSxTQUFTLEtBQUs7QUFFMUQsUUFBTSxDQUFDaUUsVUFBVUMsV0FBVyxJQUFJbEUsU0FBUztBQUFBLElBQ3ZDbUUsY0FBYztBQUFBLElBQ2RDLFlBQVk7QUFBQSxJQUNaQyxhQUFhO0FBQUEsSUFDYkMsV0FBVztBQUFBLElBQ1hDLG1CQUFtQjtBQUFBLElBQ25CQyxpQkFBaUI7QUFBQSxFQUNuQixDQUFDO0FBRUQsUUFBTUMsVUFBVXZFLE9BQU87QUFDdkIsUUFBTXdFLFFBQVF4RSxPQUFPO0FBR3JCRCxZQUFVLE1BQU07QUFDZCxRQUFJZ0QsZUFBZTBCLFdBQVcsRUFBRztBQUVqQyxVQUFNQyxTQUFTLElBQUlDLGdCQUFnQkMsU0FBU0MsTUFBTTtBQUNsRCxVQUFNQyxXQUFXSixPQUFPSyxJQUFJLG9CQUFvQjtBQUNoRCxVQUFNQyxTQUFTTixPQUFPSyxJQUFJLGtCQUFrQjtBQUU1QyxRQUFJRCxZQUFZLENBQUNmLFNBQVNFLGNBQWM7QUFDdEMsWUFBTWdCLFNBQVNsQyxlQUFlbUMsS0FBSyxDQUFBQyxNQUFLQSxFQUFFQyxRQUFRTixRQUFRO0FBQzFELFVBQUlHLE9BQVFJLHdCQUF1QkosUUFBUSxNQUFNO0FBQUEsSUFDbkQ7QUFDQSxRQUFJRCxVQUFVLENBQUNqQixTQUFTRyxZQUFZO0FBQ2xDLFlBQU1vQixPQUFPdkMsZUFBZW1DLEtBQUssQ0FBQUMsTUFBS0EsRUFBRUMsUUFBUUosTUFBTTtBQUN0RCxVQUFJTSxLQUFNRCx3QkFBdUJDLE1BQU0sSUFBSTtBQUFBLElBQzdDO0FBQUEsRUFDRixHQUFHLENBQUN2QyxnQkFBZ0I2QixTQUFTQyxRQUFRZCxTQUFTRSxjQUFjRixTQUFTRyxVQUFVLENBQUM7QUFHaEZuRSxZQUFVLE1BQU07QUFDZCxRQUFJZ0QsZUFBZTBCLFdBQVcsRUFBRztBQUVqQyxVQUFNQyxTQUFTLElBQUlDLGdCQUFnQkMsU0FBU0MsTUFBTTtBQUNsRCxVQUFNQyxXQUFXSixPQUFPSyxJQUFJLG9CQUFvQjtBQUNoRCxVQUFNQyxTQUFTTixPQUFPSyxJQUFJLGtCQUFrQjtBQUU1QyxRQUFJRCxZQUFZLENBQUNmLFNBQVNFLGNBQWM7QUFDdEMsWUFBTWdCLFNBQVNsQyxlQUFlbUMsS0FBSyxDQUFBQyxNQUFLQSxFQUFFQyxRQUFRTixRQUFRO0FBQzFELFVBQUlHLE9BQVFJLHdCQUF1QkosUUFBUSxNQUFNO0FBQUEsSUFDbkQ7QUFDQSxRQUFJRCxVQUFVLENBQUNqQixTQUFTRyxZQUFZO0FBQ2xDLFlBQU1vQixPQUFPdkMsZUFBZW1DLEtBQUssQ0FBQUMsTUFBS0EsRUFBRUMsUUFBUUosTUFBTTtBQUN0RCxVQUFJTSxLQUFNRCx3QkFBdUJDLE1BQU0sSUFBSTtBQUFBLElBQzdDO0FBQUEsRUFDRixHQUFHLENBQUN2QyxnQkFBZ0I2QixTQUFTQyxRQUFRZCxTQUFTRSxjQUFjRixTQUFTRyxVQUFVLENBQUM7QUFFaEZuRSxZQUFVLE1BQU07QUFDZHdGLHdCQUFvQjtBQUFBLEVBQ3RCLEdBQUcsRUFBRTtBQUVMLFFBQU1BLHNCQUFzQixZQUFZO0FBQ3RDckMsNEJBQXdCLElBQUk7QUFDNUIsUUFBSTtBQUNGLFlBQU1zQyxXQUFXLE1BQU0zRCxJQUFJa0QsSUFBSSxtQ0FBbUM7QUFFbEUsVUFBSVMsU0FBU0MsS0FBS0MsZUFBZSxPQUFPRixTQUFTQyxLQUFLRSxXQUFXLE1BQU07QUFDckUsY0FBTUMsY0FBY0osU0FBU0MsS0FBS0EsUUFBUUQsU0FBU0MsS0FBS0ksV0FBVztBQUNuRTdDLDBCQUFrQjRDLFdBQVc7QUFBQSxNQUMvQixPQUFPO0FBQ0xFLGdCQUFRekQsTUFBTSxrQ0FBa0NtRCxTQUFTQyxJQUFJO0FBQUEsTUFDL0Q7QUFBQSxJQUNGLFNBQVNNLEtBQUs7QUFDWkQsY0FBUXpELE1BQU0sK0JBQStCMEQsR0FBRztBQUNoRHpELGVBQVMsc0RBQXNEO0FBQUEsSUFDakUsVUFBQztBQUNDWSw4QkFBd0IsS0FBSztBQUFBLElBQy9CO0FBQUEsRUFDRjtBQUdBLFFBQU04QyxzQkFBc0IsT0FBT0MsVUFBVUMsV0FBVztBQUN0RCxRQUFJO0FBQ0YsWUFBTVYsV0FBVyxNQUFNM0QsSUFBSWtELElBQUkscUJBQXFCa0IsUUFBUSx1QkFBdUI7QUFDbkYsYUFBT1QsU0FBU0MsTUFBTUEsTUFBTVUsZ0JBQWdCO0FBQUEsSUFDOUMsU0FBU0osS0FBSztBQUNaRCxjQUFRekQsTUFBTSwyQkFBMkIwRCxHQUFHO0FBQzVDLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUdBLFFBQU1LLHNCQUFzQixZQUFZO0FBQ3RDLFFBQUksQ0FBQ3JDLFNBQVNFLGdCQUFnQixDQUFDRixTQUFTRyxZQUFZO0FBQ2xENUIsZUFBUyw2REFBNkQ7QUFDdEU7QUFBQSxJQUNGO0FBRUFRLHdCQUFvQixJQUFJO0FBQ3hCUixhQUFTLElBQUk7QUFFYixRQUFJO0FBRUYsWUFBTStELGVBQWV0RCxlQUFlbUMsS0FBSyxDQUFBQyxNQUFLQSxFQUFFQyxRQUFRckIsU0FBU0UsWUFBWTtBQUM3RSxZQUFNcUMsYUFBYXZELGVBQWVtQyxLQUFLLENBQUFDLE1BQUtBLEVBQUVDLFFBQVFyQixTQUFTRyxVQUFVO0FBR3pFLFlBQU1xQyxnQkFBZ0IsTUFBTVAsb0JBQW9CakMsU0FBU0UsY0FBY29DLGNBQWNHLFdBQVdILGNBQWNILE1BQU07QUFDcEgsWUFBTU8sY0FBYyxNQUFNVCxvQkFBb0JqQyxTQUFTRyxZQUFZb0MsWUFBWUUsV0FBV0YsWUFBWUosTUFBTTtBQUc1RyxZQUFNUSxxQkFBcUI7QUFDM0IsWUFBTUMsbUJBQW1CRixjQUFjRjtBQUV2QzNELHFCQUFlO0FBQUEsUUFDYnlEO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FNLGNBQWNQLGNBQWNHLFdBQVdILGNBQWNILFVBQVU7QUFBQSxRQUMvRFcsWUFBWVAsWUFBWUUsV0FBV0YsWUFBWUosVUFBVTtBQUFBLFFBQ3pEWSxnQkFBZ0JULGNBQWNVLFNBQVNDLGFBQWE7QUFBQSxRQUNwREMsY0FBY1gsWUFBWVMsU0FBU0MsYUFBYTtBQUFBLFFBQ2hERSxhQUFhYixjQUFjYyxVQUFVQyxjQUFjO0FBQUEsUUFDbkRDLFdBQVdmLFlBQVlhLFVBQVVDLGNBQWM7QUFBQSxRQUMvQ0Usc0JBQXNCZjtBQUFBQSxRQUN0QmdCLG9CQUFvQmQ7QUFBQUEsUUFDcEJlLGdCQUFnQmpCO0FBQUFBLFFBQ2hCRztBQUFBQSxRQUNBQztBQUFBQSxNQUNGLENBQUM7QUFDRGpFLHFCQUFlLElBQUk7QUFBQSxJQUNyQixTQUFTcUQsS0FBSztBQUNaRCxjQUFRekQsTUFBTSwyQkFBMkIwRCxHQUFHO0FBQzVDekQsZUFBUyxvREFBb0Q7QUFBQSxJQUMvRCxVQUFDO0FBQ0NRLDBCQUFvQixLQUFLO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBRUEsUUFBTTJFLGlCQUFpQkEsQ0FBQ0MsV0FBVztBQUNqQyxXQUFPLElBQUlDLEtBQUtDLGFBQWEsU0FBUztBQUFBLE1BQ3BDQyxPQUFPO0FBQUEsTUFDUEMsVUFBVTtBQUFBLE1BQ1ZDLHVCQUF1QjtBQUFBLElBQ3pCLENBQUMsRUFBRUMsT0FBT04sVUFBVSxDQUFDO0FBQUEsRUFDdkI7QUFFQSxRQUFNTyxhQUFhQSxDQUFDQyxTQUFTO0FBQzNCLFFBQUksQ0FBQ0EsS0FBTSxRQUFPO0FBQ2xCLFdBQU8sSUFBSUMsS0FBS0QsSUFBSSxFQUFFRSxtQkFBbUIsU0FBUztBQUFBLE1BQ2hEQyxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLE1BQU07QUFBQSxJQUNSLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTUMsb0JBQW9CQSxDQUFDQyxZQUFZQyxTQUFTO0FBQzlDLFFBQUksQ0FBQ0QsV0FBV0UsS0FBSyxHQUFHO0FBQ3RCLFVBQUlELFNBQVMsT0FBUWxGLGdCQUFlLEVBQUU7QUFDdEMsVUFBSWtGLFNBQVMsS0FBTWhGLGNBQWEsRUFBRTtBQUNsQztBQUFBLElBQ0Y7QUFFQSxVQUFNa0YsY0FBY0gsV0FBV0ksWUFBWTtBQUMzQyxVQUFNQyxXQUFXL0YsZUFBZWdHLE9BQU8sQ0FBQWxELFlBQVc7QUFDaEQsWUFBTW1ELGVBQWVuRCxRQUFRa0IsU0FBU0MsYUFBYTtBQUNuRCxZQUFNaUMsWUFBWXBELFFBQVFzQixVQUFVQyxjQUFjO0FBQ2xELFlBQU1sQixTQUFTZ0QsT0FBT3JELFFBQVFXLFdBQVdYLFFBQVFLLFVBQVUsRUFBRTtBQUM3RCxZQUFNaUQsZ0JBQWdCdEQsUUFBUWtCLFNBQVNxQyxTQUFTO0FBQ2hELFlBQU1DLGdCQUFnQnhELFFBQVFrQixTQUFTdUMsZ0JBQWdCO0FBRXZELGFBQ0VOLGFBQWFILFlBQVksRUFBRVUsU0FBU1gsV0FBVyxLQUMvQ0ssVUFBVUosWUFBWSxFQUFFVSxTQUFTWCxXQUFXLEtBQzVDMUMsT0FBTzJDLFlBQVksRUFBRVUsU0FBU1gsV0FBVyxLQUN6Q08sY0FBY04sWUFBWSxFQUFFVSxTQUFTWCxXQUFXLEtBQ2hEUyxjQUFjRSxTQUFTZCxVQUFVO0FBQUEsSUFFckMsQ0FBQztBQUVELFFBQUlDLFNBQVMsUUFBUTtBQUNuQmxGLHFCQUFlc0YsU0FBU1UsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNwQzVGLDBCQUFvQixJQUFJO0FBQUEsSUFDMUIsT0FBTztBQUNMRixtQkFBYW9GLFNBQVNVLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDbEMxRix3QkFBa0IsSUFBSTtBQUFBLElBQ3hCO0FBQUEsRUFDRjtBQUVBLFFBQU11Qix5QkFBeUJBLENBQUNRLFNBQVM2QyxTQUFTO0FBQ2hELFVBQU1NLGVBQWVuRCxRQUFRa0IsU0FBU0MsYUFBYTtBQUNuRCxVQUFNaUMsWUFBWXBELFFBQVFzQixVQUFVQyxjQUFjO0FBQ2xELFVBQU1sQixTQUFTTCxRQUFRVyxXQUFXWCxRQUFRSyxVQUFVO0FBQ3BELFVBQU11RCxjQUFjLEdBQUdULFlBQVksTUFBTUMsU0FBUyxNQUFNL0MsTUFBTTtBQUU5RCxRQUFJd0MsU0FBUyxRQUFRO0FBQ25CMUUsa0JBQVksQ0FBQTBGLFVBQVM7QUFBQSxRQUNuQixHQUFHQTtBQUFBQSxRQUNIekYsY0FBYzRCLFFBQVFUO0FBQUFBLFFBQ3RCakIsYUFBYXNGO0FBQUFBLFFBQ2JwRixtQkFBbUJ3QjtBQUFBQSxNQUNyQixFQUFFO0FBQ0Z6QyxvQkFBYyxFQUFFO0FBQ2hCUSwwQkFBb0IsS0FBSztBQUFBLElBQzNCLE9BQU87QUFDTEksa0JBQVksQ0FBQTBGLFVBQVM7QUFBQSxRQUNuQixHQUFHQTtBQUFBQSxRQUNIeEYsWUFBWTJCLFFBQVFUO0FBQUFBLFFBQ3BCaEIsV0FBV3FGO0FBQUFBLFFBQ1huRixpQkFBaUJ1QjtBQUFBQSxNQUNuQixFQUFFO0FBQ0Z2QyxrQkFBWSxFQUFFO0FBQ2RRLHdCQUFrQixLQUFLO0FBQUEsSUFDekI7QUFFQTFCLGVBQVcsSUFBSTtBQUNmRSxhQUFTLElBQUk7QUFDYkUsc0JBQWtCLElBQUk7QUFDdEJFLG1CQUFlLEtBQUs7QUFDcEJFLG1CQUFlLElBQUk7QUFBQSxFQUNyQjtBQUVBLFFBQU0rRyx1QkFBdUJBLENBQUNqQixTQUFTO0FBQ3JDLFFBQUlBLFNBQVMsUUFBUTtBQUNuQjFFLGtCQUFZLENBQUEwRixVQUFTO0FBQUEsUUFDbkIsR0FBR0E7QUFBQUEsUUFDSHpGLGNBQWM7QUFBQSxRQUNkRSxhQUFhO0FBQUEsUUFDYkUsbUJBQW1CO0FBQUEsTUFDckIsRUFBRTtBQUNGakIsb0JBQWMsRUFBRTtBQUFBLElBQ2xCLE9BQU87QUFDTFksa0JBQVksQ0FBQTBGLFVBQVM7QUFBQSxRQUNuQixHQUFHQTtBQUFBQSxRQUNIeEYsWUFBWTtBQUFBLFFBQ1pFLFdBQVc7QUFBQSxRQUNYRSxpQkFBaUI7QUFBQSxNQUNuQixFQUFFO0FBQ0ZoQixrQkFBWSxFQUFFO0FBQUEsSUFDaEI7QUFDQVosbUJBQWUsS0FBSztBQUNwQkUsbUJBQWUsSUFBSTtBQUFBLEVBQ3JCO0FBRUEsUUFBTWdILGVBQWUsT0FBT3pFLE1BQU07QUFDaENBLE1BQUUwRSxlQUFlO0FBRWpCLFFBQUksQ0FBQzlGLFNBQVNFLGdCQUFnQixDQUFDRixTQUFTRyxZQUFZO0FBQ2xENUIsZUFBUyx1REFBdUQ7QUFDaEU7QUFBQSxJQUNGO0FBRUEsUUFBSXlCLFNBQVNFLGlCQUFpQkYsU0FBU0csWUFBWTtBQUNqRDVCLGVBQVMsdURBQXVEO0FBQ2hFO0FBQUEsSUFDRjtBQUVBSixlQUFXLElBQUk7QUFDZkksYUFBUyxJQUFJO0FBQ2JGLGVBQVcsSUFBSTtBQUNmSSxzQkFBa0IsSUFBSTtBQUN0QkUsbUJBQWUsS0FBSztBQUVwQixRQUFJO0FBQ0YsWUFBTThDLFdBQVcsTUFBTTNELElBQUlpSTtBQUFBQSxRQUN6QixxQkFBcUIvRixTQUFTRSxZQUFZLElBQUlGLFNBQVNHLFVBQVU7QUFBQSxNQUNuRTtBQUVBLFVBQUlzQixTQUFTQyxLQUFLRSxRQUFRO0FBQ3hCdkQsbUJBQVdvRCxTQUFTQyxLQUFLc0UsT0FBTztBQUNoQ3ZILDBCQUFrQmdELFNBQVNDLElBQUk7QUFBQSxNQUNqQyxPQUFPO0FBQ0xuRCxpQkFBU2tELFNBQVNDLEtBQUtzRSxXQUFXLGlCQUFpQjtBQUFBLE1BQ3JEO0FBQUEsSUFDRixTQUFTaEUsS0FBSztBQUNaekQsZUFBU3lELElBQUlQLFVBQVVDLE1BQU1zRSxXQUFXLG1DQUFtQztBQUFBLElBQzdFLFVBQUM7QUFDQzdILGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNOEgsY0FBY0EsTUFBTTtBQUN4QmhHLGdCQUFZO0FBQUEsTUFDVkMsY0FBYztBQUFBLE1BQ2RDLFlBQVk7QUFBQSxNQUNaQyxhQUFhO0FBQUEsTUFDYkMsV0FBVztBQUFBLE1BQ1hDLG1CQUFtQjtBQUFBLE1BQ25CQyxpQkFBaUI7QUFBQSxJQUNuQixDQUFDO0FBQ0RsQixrQkFBYyxFQUFFO0FBQ2hCRSxnQkFBWSxFQUFFO0FBQ2RsQixlQUFXLElBQUk7QUFDZkUsYUFBUyxJQUFJO0FBQ2JFLHNCQUFrQixJQUFJO0FBQ3RCRSxtQkFBZSxLQUFLO0FBQ3BCRSxtQkFBZSxJQUFJO0FBQUEsRUFDckI7QUFFQTdDLFlBQVUsTUFBTTtBQUNkLFVBQU1rSyxxQkFBcUJBLENBQUNDLFVBQVU7QUFDcEMsVUFBSTNGLFFBQVE0RixXQUFXLENBQUM1RixRQUFRNEYsUUFBUUMsU0FBU0YsTUFBTUcsTUFBTSxHQUFHO0FBQzlEekcsNEJBQW9CLEtBQUs7QUFBQSxNQUMzQjtBQUNBLFVBQUlZLE1BQU0yRixXQUFXLENBQUMzRixNQUFNMkYsUUFBUUMsU0FBU0YsTUFBTUcsTUFBTSxHQUFHO0FBQzFEdkcsMEJBQWtCLEtBQUs7QUFBQSxNQUN6QjtBQUFBLElBQ0Y7QUFDQXdHLGFBQVNDLGlCQUFpQixhQUFhTixrQkFBa0I7QUFDekQsV0FBTyxNQUFNSyxTQUFTRSxvQkFBb0IsYUFBYVAsa0JBQWtCO0FBQUEsRUFDM0UsR0FBRyxFQUFFO0FBRUwsU0FDRSx1QkFBQyxTQUFJLFdBQVUsY0FDYixpQ0FBQyxTQUFJLFdBQVUsdUVBQ2I7QUFBQSwyQkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUTtBQUFBLElBQ1IsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSw2QkFBQyxVQUFPLFlBQVksUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QjtBQUFBLE1BRXpCLHVCQUFDLFNBQUksV0FBVSxjQUViO0FBQUEsK0JBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNakksU0FBUyxFQUFFO0FBQUEsY0FDMUIsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxhQUFVLFdBQVUsNkRBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThFO0FBQUEsZ0JBQzlFLHVCQUFDLFVBQUssV0FBVSx1QkFBc0Isb0JBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBDO0FBQUE7QUFBQTtBQUFBLFlBTDVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUscURBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsUUFBRyxXQUFVLDREQUNaO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDhEQUNiLGlDQUFDLGNBQVcsV0FBVSx3QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEMsS0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUFNO0FBQUEsbUJBSFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsT0FBRSxXQUFVLHNCQUFxQixvRUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxrRkFDYjtBQUFBLHFDQUFDLFFBQUssV0FBVSwyQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUM7QUFBQSxjQUN2Qyx1QkFBQyxVQUFLLFdBQVUseUJBQXdCLHFDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RDtBQUFBLGlCQUYvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQkE7QUFBQSxhQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkJBO0FBQUEsUUFFQ2lCLHVCQUNDLHVCQUFDLFNBQUksV0FBVSx5Q0FDYixpQ0FBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWUsS0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHlDQUViO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlCQUNiLGlDQUFDLFNBQUksV0FBVSx5RUFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSx1RUFDYjtBQUFBLHFDQUFDLFFBQUcsV0FBVSwrREFDWjtBQUFBLHVDQUFDLGNBQVcsV0FBVSwyQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkM7QUFBQSxnQkFBRztBQUFBLG1CQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLGtFQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBRUEsdUJBQUMsVUFBSyxVQUFVMkcsY0FBYyxXQUFVLGlCQUV0QztBQUFBLHFDQUFDLFNBQUksS0FBS3JGLFNBQ1I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQ2YsaUNBQUMsVUFBSyxXQUFVLDJCQUNkO0FBQUEseUNBQUMsU0FBTSxXQUFVLDBCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1QztBQUFBLGtCQUFHO0FBQUEscUJBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBRUNSLFNBQVNJLGNBQ1IsdUJBQUMsU0FBSSxXQUFVLDBFQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSwyQ0FBQyxPQUFFLFdBQVUscUNBQXFDSixtQkFBU0ksZUFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUU7QUFBQSxvQkFDdkUsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QjtBQUFBO0FBQUEsc0JBQUtKLFNBQVNFO0FBQUFBLHlCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFxRTtBQUFBLHVCQUZ2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVMsTUFBTTBGLHFCQUFxQixNQUFNO0FBQUEsc0JBQzFDLFdBQVU7QUFBQSxzQkFFVixpQ0FBQyxLQUFFLFdBQVUsMEJBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBbUM7QUFBQTtBQUFBLG9CQUxyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTUE7QUFBQSxxQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVlBLElBRUEsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLDJDQUFDLFVBQU8sV0FBVSxvRUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBa0Y7QUFBQSxvQkFDbEY7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE9BQU94RztBQUFBQSx3QkFDUCxVQUFVLENBQUNnQyxNQUFNO0FBQ2YvQix3Q0FBYytCLEVBQUVrRixPQUFPSSxLQUFLO0FBQzVCakMsNENBQWtCckQsRUFBRWtGLE9BQU9JLE9BQU8sTUFBTTtBQUFBLHdCQUMxQztBQUFBLHdCQUNBLFNBQVMsTUFBTWxILFlBQVlrQixTQUFTLEtBQUtiLG9CQUFvQixJQUFJO0FBQUEsd0JBQ2pFLGFBQVk7QUFBQSx3QkFDWixXQUFVO0FBQUEsd0JBQ1YsVUFBVTNCO0FBQUFBO0FBQUFBLHNCQVZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFVb0I7QUFBQSx1QkFadEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFjQTtBQUFBLGtCQUVDMEIsb0JBQW9CSixZQUFZa0IsU0FBUyxLQUN4Qyx1QkFBQyxTQUFJLFdBQVUsMkdBQ1psQixzQkFBWW1IO0FBQUFBLG9CQUFJLENBQUNDLFdBQ2hCO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUVDLE1BQUs7QUFBQSx3QkFDTCxTQUFTLE1BQU10Rix1QkFBdUJzRixRQUFRLE1BQU07QUFBQSx3QkFDcEQsV0FBVTtBQUFBLHdCQUVWLGlDQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLGlEQUFDLFFBQUssV0FBVSxnREFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBNEQ7QUFBQSwwQkFDNUQsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSxtREFBQyxPQUFFLFdBQVUscUNBQ1ZBLGlCQUFPNUQsU0FBU0MsYUFBYSxzQkFEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FFQTtBQUFBLDRCQUNBLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLHFEQUFDLFVBQUssV0FBVSx3REFDZDtBQUFBLHVEQUFDLFdBQVEsV0FBVSxhQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUE0QjtBQUFBLGdDQUMzQjJELE9BQU94RCxVQUFVQyxjQUFjO0FBQUEsbUNBRmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBR0E7QUFBQSw4QkFDQSx1QkFBQyxVQUFLLFdBQVUsd0RBQ2Q7QUFBQSx1REFBQyxPQUFJLFdBQVUsYUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUF3QjtBQUFBLGdDQUFHO0FBQUEsZ0NBQ2xCdUQsT0FBT25FLFdBQVdtRSxPQUFPekUsVUFBVTtBQUFBLG1DQUY5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUdBO0FBQUEsaUNBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FTQTtBQUFBLDRCQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkI7QUFBQTtBQUFBLDhCQUNuQ3lFLE9BQU92RjtBQUFBQSxpQ0FEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUVBO0FBQUEsK0JBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBaUJBO0FBQUEsNkJBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBb0JBO0FBQUE7QUFBQSxzQkF6Qkt1RixPQUFPdkY7QUFBQUEsc0JBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkEyQkE7QUFBQSxrQkFDRCxLQTlCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQStCQTtBQUFBLGtCQUdEekIsb0JBQW9CUixjQUFjSSxZQUFZa0IsV0FBVyxLQUN4RCx1QkFBQyxTQUFJLFdBQVUsa0dBQ2IsaUNBQUMsT0FBRSxXQUFVLHlCQUF3QixvQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUQsS0FEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQXZESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXlEQTtBQUFBLGdCQUdGLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsaUVBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFyRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFzRkE7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSw0QkFDYixpQ0FBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxpSEFDYixpQ0FBQyxRQUFLLFdBQVUsd0JBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9DLEtBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsNkVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUY7QUFBQSxtQkFKM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxjQUdBLHVCQUFDLFNBQUksS0FBS0QsT0FDUjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFDZixpQ0FBQyxVQUFLLFdBQVUsMkJBQ2Q7QUFBQSx5Q0FBQyxTQUFNLFdBQVUsNEJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlDO0FBQUEsa0JBQUc7QUFBQSxxQkFEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxnQkFFQ1QsU0FBU0ssWUFDUix1QkFBQyxTQUFJLFdBQVUsOEVBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDJDQUFDLE9BQUUsV0FBVSxxQ0FBcUNMLG1CQUFTSyxhQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFxRTtBQUFBLG9CQUNyRSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCO0FBQUE7QUFBQSxzQkFBS0wsU0FBU0c7QUFBQUEseUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW1FO0FBQUEsdUJBRnJFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsU0FBUyxNQUFNeUYscUJBQXFCLElBQUk7QUFBQSxzQkFDeEMsV0FBVTtBQUFBLHNCQUVWLGlDQUFDLEtBQUUsV0FBVSw0QkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFxQztBQUFBO0FBQUEsb0JBTHZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNQTtBQUFBLHFCQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBWUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsMkNBQUMsVUFBTyxXQUFVLG9FQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFrRjtBQUFBLG9CQUNsRjtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsT0FBT3RHO0FBQUFBLHdCQUNQLFVBQVUsQ0FBQzhCLE1BQU07QUFDZjdCLHNDQUFZNkIsRUFBRWtGLE9BQU9JLEtBQUs7QUFDMUJqQyw0Q0FBa0JyRCxFQUFFa0YsT0FBT0ksT0FBTyxJQUFJO0FBQUEsd0JBQ3hDO0FBQUEsd0JBQ0EsU0FBUyxNQUFNaEgsVUFBVWdCLFNBQVMsS0FBS1gsa0JBQWtCLElBQUk7QUFBQSx3QkFDN0QsYUFBWTtBQUFBLHdCQUNaLFdBQVU7QUFBQSx3QkFDVixVQUFVN0I7QUFBQUE7QUFBQUEsc0JBVlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVVvQjtBQUFBLHVCQVp0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWNBO0FBQUEsa0JBRUM0QixrQkFBa0JKLFVBQVVnQixTQUFTLEtBQ3BDLHVCQUFDLFNBQUksV0FBVSwyR0FDWmhCLG9CQUFVaUg7QUFBQUEsb0JBQUksQ0FBQ0MsV0FDZDtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFFQyxNQUFLO0FBQUEsd0JBQ0wsU0FBUyxNQUFNdEYsdUJBQXVCc0YsUUFBUSxJQUFJO0FBQUEsd0JBQ2xELFdBQVU7QUFBQSx3QkFFVixpQ0FBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxpREFBQyxRQUFLLFdBQVUsZ0RBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQTREO0FBQUEsMEJBQzVELHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsbURBQUMsT0FBRSxXQUFVLHFDQUNWQSxpQkFBTzVELFNBQVNDLGFBQWEsc0JBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQSw0QkFDQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxxREFBQyxVQUFLLFdBQVUsd0RBQ2Q7QUFBQSx1REFBQyxXQUFRLFdBQVUsYUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FBNEI7QUFBQSxnQ0FDM0IyRCxPQUFPeEQsVUFBVUMsY0FBYztBQUFBLG1DQUZsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUdBO0FBQUEsOEJBQ0EsdUJBQUMsVUFBSyxXQUFVLHdEQUNkO0FBQUEsdURBQUMsT0FBSSxXQUFVLGFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FBd0I7QUFBQSxnQ0FBRztBQUFBLGdDQUNsQnVELE9BQU9uRSxXQUFXbUUsT0FBT3pFLFVBQVU7QUFBQSxtQ0FGOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FHQTtBQUFBLGlDQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBU0E7QUFBQSw0QkFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCO0FBQUE7QUFBQSw4QkFDbkN5RSxPQUFPdkY7QUFBQUEsaUNBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FFQTtBQUFBLCtCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQWlCQTtBQUFBLDZCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQW9CQTtBQUFBO0FBQUEsc0JBekJLdUYsT0FBT3ZGO0FBQUFBLHNCQURkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBMkJBO0FBQUEsa0JBQ0QsS0E5Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkErQkE7QUFBQSxrQkFHRHZCLGtCQUFrQlIsWUFBWUksVUFBVWdCLFdBQVcsS0FDbEQsdUJBQUMsU0FBSSxXQUFVLGtHQUNiLGlDQUFDLE9BQUUsV0FBVSx5QkFBd0Isb0NBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlELEtBRDNEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkF2REo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF5REE7QUFBQSxnQkFHRix1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLDZEQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBckZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0ZBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ1pWO0FBQUFBLHlCQUFTRSxnQkFBZ0JGLFNBQVNHLGNBQ2pDO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTa0M7QUFBQUEsb0JBQ1QsVUFBVW5FLFdBQVdZO0FBQUFBLG9CQUNyQixXQUFVO0FBQUEsb0JBRVRBLDZCQUNDLG1DQUNFO0FBQUEsNkNBQUMsV0FBUSxXQUFVLDBCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5QztBQUFBLHNCQUFHO0FBQUEseUJBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0EsSUFFQSxtQ0FDRTtBQUFBLDZDQUFDLE9BQUksV0FBVSxhQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXdCO0FBQUEsc0JBQUc7QUFBQSx5QkFEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBO0FBQUEsa0JBZko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWlCQTtBQUFBLGdCQUdGO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxVQUFVWixXQUFXLENBQUM4QixTQUFTRSxnQkFBZ0IsQ0FBQ0YsU0FBU0c7QUFBQUEsb0JBQ3pELFdBQVU7QUFBQSxvQkFFVGpDLG9CQUNDLG1DQUNFO0FBQUEsNkNBQUMsV0FBUSxXQUFVLDBCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5QztBQUFBLHNCQUFHO0FBQUEseUJBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0EsSUFFQSxtQ0FDRTtBQUFBLDZDQUFDLGFBQVUsV0FBVSxhQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE4QjtBQUFBLHNCQUFHO0FBQUEseUJBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQTtBQUFBLGtCQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFnQkE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBUytIO0FBQUFBLG9CQUNULFVBQVUvSDtBQUFBQSxvQkFDVixXQUFVO0FBQUEsb0JBQWdJO0FBQUE7QUFBQSxrQkFKNUk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BO0FBQUEsbUJBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0RBO0FBQUEsaUJBOU9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK09BO0FBQUEsZUExUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyUEEsS0E1UEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2UEE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxhQUViO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHVEQUNiLGlDQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLHFDQUFDLGVBQVksV0FBVSxpREFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0U7QUFBQSxjQUNwRSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsUUFBRyxXQUFVLHFDQUFvQyxnQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0U7QUFBQSxnQkFDbEUsdUJBQUMsT0FBRSxXQUFVLDBCQUF5QixpTEFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLG1EQUNiO0FBQUEscUNBQUMsUUFBRyxXQUFVLDREQUNaO0FBQUEsdUNBQUMsWUFBUyxXQUFVLDJCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyQztBQUFBLGdCQUFHO0FBQUEsbUJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNBLHVCQUFDLFFBQUcsV0FBVSxhQUNaO0FBQUEsdUNBQUMsUUFBRyxXQUFVLGdEQUNaO0FBQUEseUNBQUMsZUFBWSxXQUFVLGlEQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvRTtBQUFBLGtCQUNwRSx1QkFBQyxVQUFLLG1DQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlCO0FBQUEscUJBRjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLFdBQVUsZ0RBQ1o7QUFBQSx5Q0FBQyxlQUFZLFdBQVUsaURBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9FO0FBQUEsa0JBQ3BFLHVCQUFDLFVBQUssMkNBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQSxxQkFGbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBLHVCQUFDLFFBQUcsV0FBVSxnREFDWjtBQUFBLHlDQUFDLGVBQVksV0FBVSxpREFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0U7QUFBQSxrQkFDcEUsdUJBQUMsVUFBSyxrQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3QjtBQUFBLHFCQUYxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxXQUFVLGdEQUNaO0FBQUEseUNBQUMsWUFBUyxXQUFVLGdEQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnRTtBQUFBLGtCQUNoRSx1QkFBQyxVQUFLLDhDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9DO0FBQUEscUJBRnRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxtQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxpQkF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1QkE7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSxzRkFDYixpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHFDQUFDLE9BQUksV0FBVSxnREFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyRDtBQUFBLGNBQzNELHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsb0NBQW1DLDBCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyRDtBQUFBLGdCQUMzRCx1QkFBQyxPQUFFLFdBQVUseUJBQXdCLGtHQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGlCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsZUFuREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvREE7QUFBQSxhQXRURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdVRBO0FBQUEsUUFJRFEsZUFBZUUsZUFDZCx1QkFBQyxTQUFJLFdBQVUsa0ZBQ2IsaUNBQUMsU0FBSSxXQUFVLGlGQUViO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHlFQUNiLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxnQ0FDYixpQ0FBQyxPQUFJLFdBQVUsNkJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0MsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFFBQUcsV0FBVSxtQ0FBa0MsZ0NBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdFO0FBQUEsZ0JBQ2hFLHVCQUFDLE9BQUUsV0FBVSx5QkFBd0Isd0RBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZFO0FBQUEsbUJBRi9FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTUQsZUFBZSxLQUFLO0FBQUEsZ0JBQ25DLFdBQVU7QUFBQSxnQkFFVixpQ0FBQyxLQUFFLFdBQVUsMkJBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0M7QUFBQTtBQUFBLGNBSnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsZUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQSxLQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLHVCQUFzQixPQUFPLEVBQUVrSSxXQUFXLHFCQUFxQixHQUU1RTtBQUFBLG1DQUFDLFNBQUksV0FBVSwrRUFDYixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxxQ0FBQyxTQUNDO0FBQUEsdUNBQUMsT0FBRSxXQUFVLDJCQUEwQiwrQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0Q7QUFBQSxnQkFDdEQsdUJBQUMsT0FBRSxXQUFVLHNCQUFzQm5ELHlCQUFlOUUsWUFBWTZFLGNBQWMsS0FBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEU7QUFBQSxtQkFGaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSx1Q0FBQyxPQUFFLFdBQVUsMkJBQTBCLDJCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRDtBQUFBLGdCQUNsRCx1QkFBQyxPQUFFLFdBQVUsK0JBQThCO0FBQUE7QUFBQSxrQkFBRTdFLFlBQVlpRTtBQUFBQSxxQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0U7QUFBQSxtQkFGeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsY0FBVyxXQUFVLHdCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQztBQUFBLGNBQzFDLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsdUNBQUMsT0FBRSxXQUFVLDJCQUEwQix5QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0Q7QUFBQSxnQkFDaEQsdUJBQUMsT0FBRSxXQUFVLCtCQUE4QjtBQUFBO0FBQUEsa0JBQUVqRSxZQUFZa0U7QUFBQUEscUJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9FO0FBQUEsbUJBRnRFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSw4Q0FFYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxvREFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHlDQUFDLFNBQ0M7QUFBQSwyQ0FBQyxRQUFHLFdBQVUsOEJBQTZCLDZCQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF3RDtBQUFBLG9CQUN4RCx1QkFBQyxPQUFFLFdBQVUsd0JBQXVCO0FBQUE7QUFBQSxzQkFBU2xFLFlBQVlpRTtBQUFBQSx5QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBc0U7QUFBQSx1QkFGeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUNBLHVCQUFDLFVBQUssV0FBVSwwREFBeUQsK0JBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdGO0FBQUEscUJBTDFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTUE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxrRUFDYjtBQUFBLDJDQUFDLFVBQUssV0FBVSx3QkFBdUIseUJBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdEO0FBQUEsb0JBQ2hELHVCQUFDLFVBQUssV0FBVSxvQ0FBb0NqRSxzQkFBWW1FLGtCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErRTtBQUFBLHVCQUZqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGtFQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHdCQUF1QixzQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkM7QUFBQSxvQkFDN0MsdUJBQUMsVUFBSyxXQUFVLG9DQUFvQ25FLHNCQUFZdUUsZUFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNEU7QUFBQSx1QkFGOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLDJDQUFDLFVBQUssV0FBVSxzQ0FBcUMsZ0NBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXFFO0FBQUEsb0JBQ3JFLHVCQUFDLFVBQUssV0FBVSxrQ0FBa0NPLHlCQUFlOUUsWUFBWTJFLG9CQUFvQixLQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtRztBQUFBLHVCQUZyRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEscUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFhQTtBQUFBLG1CQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXVCQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLHNEQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEseUNBQUMsU0FDQztBQUFBLDJDQUFDLFFBQUcsV0FBVSwrQkFBOEIsNkJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXlEO0FBQUEsb0JBQ3pELHVCQUFDLE9BQUUsV0FBVSx5QkFBd0I7QUFBQTtBQUFBLHNCQUFTM0UsWUFBWWlFO0FBQUFBLHlCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF1RTtBQUFBLHVCQUZ6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0EsdUJBQUMsVUFBSyxXQUFVLDREQUEyRCw4QkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUY7QUFBQSxxQkFMM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFNQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLG1FQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHlCQUF3Qix5QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUQ7QUFBQSxvQkFDakQsdUJBQUMsVUFBSyxXQUFVLHFDQUFxQ2pFLHNCQUFZbUUsa0JBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdGO0FBQUEsdUJBRmxGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsbUVBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUseUJBQXdCLHNCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE4QztBQUFBLG9CQUM5Qyx1QkFBQyxVQUFLLFdBQVUscUNBQXFDbkUsc0JBQVl1RSxlQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2RTtBQUFBLHVCQUYvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHVDQUFzQyw0QkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBa0U7QUFBQSxvQkFDbEUsdUJBQUMsVUFBSyxXQUFVLG1DQUFtQ08seUJBQWUsQ0FBQyxLQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFxRTtBQUFBLHVCQUZ2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEscUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFhQTtBQUFBLG1CQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXVCQTtBQUFBLGlCQW5ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9EQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLDhDQUViO0FBQUEscUNBQUMsU0FBSSxXQUFVLDBEQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEseUNBQUMsU0FDQztBQUFBLDJDQUFDLFFBQUcsV0FBVSxpQ0FBZ0Msa0NBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdFO0FBQUEsb0JBQ2hFLHVCQUFDLE9BQUUsV0FBVSwyQkFBMEI7QUFBQTtBQUFBLHNCQUFTOUUsWUFBWWtFO0FBQUFBLHlCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF1RTtBQUFBLHVCQUZ6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0EsdUJBQUMsVUFBSyxXQUFVLGdFQUErRCwrQkFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEY7QUFBQSxxQkFMaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFNQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLHFFQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLDJCQUEwQix5QkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBbUQ7QUFBQSxvQkFDbkQsdUJBQUMsVUFBSyxXQUFVLHVDQUF1Q2xFLHNCQUFZc0UsZ0JBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdGO0FBQUEsdUJBRmxGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUscUVBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsMkJBQTBCLHNCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnRDtBQUFBLG9CQUNoRCx1QkFBQyxVQUFLLFdBQVUsdUNBQXVDdEUsc0JBQVkwRSxhQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2RTtBQUFBLHVCQUYvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHlDQUF3QyxnQ0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBd0U7QUFBQSxvQkFDeEUsdUJBQUMsVUFBSyxXQUFVLHFDQUFxQ0kseUJBQWU5RSxZQUFZNEUsa0JBQWtCLEtBQWxHO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9HO0FBQUEsdUJBRnRHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxxQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWFBO0FBQUEsbUJBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdUJBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSx5Q0FBQyxTQUNDO0FBQUEsMkNBQUMsUUFBRyxXQUFVLGdDQUErQixrQ0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0Q7QUFBQSxvQkFDL0QsdUJBQUMsT0FBRSxXQUFVLDBCQUF5QjtBQUFBO0FBQUEsc0JBQVM1RSxZQUFZa0U7QUFBQUEseUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXNFO0FBQUEsdUJBRnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxVQUFLLFdBQVUsOERBQTZELDhCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyRjtBQUFBLHFCQUw3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU1BO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsb0VBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsMEJBQXlCLHlCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFrRDtBQUFBLG9CQUNsRCx1QkFBQyxVQUFLLFdBQVUsc0NBQXNDbEUsc0JBQVlzRSxnQkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0U7QUFBQSx1QkFGakY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxvRUFDYjtBQUFBLDJDQUFDLFVBQUssV0FBVSwwQkFBeUIsc0JBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQStDO0FBQUEsb0JBQy9DLHVCQUFDLFVBQUssV0FBVSxzQ0FBc0N0RSxzQkFBWTBFLGFBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTRFO0FBQUEsdUJBRjlFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsd0NBQXVDLDRCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtRTtBQUFBLG9CQUNuRSx1QkFBQyxVQUFLLFdBQVUsb0NBQW1DO0FBQUE7QUFBQSxzQkFBR0ksZUFBZTlFLFlBQVlnRSxnQkFBZ0I7QUFBQSx5QkFBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBbUc7QUFBQSx1QkFGckc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLHFCQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBYUE7QUFBQSxtQkF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF1QkE7QUFBQSxpQkFuREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvREE7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSxxRkFDYjtBQUFBLHFDQUFDLFFBQUcsV0FBVSw0REFDWjtBQUFBLHVDQUFDLGNBQVcsV0FBVSwyQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkM7QUFBQSxnQkFBRztBQUFBLG1CQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLHlDQUFDLFVBQUssV0FBVSx5QkFBd0I7QUFBQTtBQUFBLG9CQUFnQmhFLFlBQVlpRTtBQUFBQSx1QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUY7QUFBQSxrQkFDakYsdUJBQUMsVUFBSyxXQUFVLHNDQUNiYTtBQUFBQSxtQ0FBZTlFLFlBQVkyRSxvQkFBb0I7QUFBQSxvQkFBRTtBQUFBLG9CQUFJRyxlQUFlLENBQUM7QUFBQSx1QkFEeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSx5Q0FBQyxVQUFLLFdBQVUseUJBQXdCO0FBQUE7QUFBQSxvQkFBcUI5RSxZQUFZa0U7QUFBQUEsdUJBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9GO0FBQUEsa0JBQ3BGLHVCQUFDLFVBQUssV0FBVSx3Q0FDYlk7QUFBQUEsbUNBQWU5RSxZQUFZNEUsa0JBQWtCO0FBQUEsb0JBQUU7QUFBQSxvQkFBSUUsZUFBZTlFLFlBQVlnRSxnQkFBZ0I7QUFBQSx1QkFEakc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUscUVBQ2I7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsdUNBQXNDLHdDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE4RTtBQUFBLGtCQUM5RSx1QkFBQyxVQUFLLFdBQVUsbUNBQW1DYyx5QkFBZTlFLFlBQVk2RSxjQUFjLEtBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThGO0FBQUEscUJBRmhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxtQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxpQkF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1QkE7QUFBQSxlQTFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTJKQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiLGlDQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNOUUsZUFBZSxLQUFLO0FBQUEsZ0JBQ25DLFdBQVU7QUFBQSxnQkFBK0Y7QUFBQTtBQUFBLGNBRjNHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTTtBQUNiQSxpQ0FBZSxLQUFLO0FBQ3BCa0gsK0JBQWEsSUFBSWlCLE1BQU0sUUFBUSxDQUFDO0FBQUEsZ0JBQ2xDO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsYUFBVSxXQUFVLGFBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThCO0FBQUEsa0JBQUc7QUFBQSxrQkFDYnBELGVBQWU5RSxZQUFZNkUsY0FBYztBQUFBO0FBQUE7QUFBQSxjQVIvRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFTQTtBQUFBLGVBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBLEtBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUF4TUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlNQSxLQTFNRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMk1BO0FBQUEsU0FJQXJGLFdBQVdFLFNBQVNFLG1CQUNwQix1QkFBQyxTQUFJLFdBQVUsdUJBQ1pKO0FBQUFBLHFCQUNDLHVCQUFDLFNBQUksV0FBVSx1REFDYixpQ0FBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxtQ0FBQyxlQUFZLFdBQVUsMENBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZEO0FBQUEsWUFDN0QsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUscUNBQW9DLG9DQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRTtBQUFBLGNBQ3RFLHVCQUFDLE9BQUUsV0FBVSx1QkFBdUJBLHFCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0QztBQUFBLGNBRTNDSSxrQkFDQyx1QkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsbURBQ2I7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsOEJBQTZCLGdDQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwRDtBQUFBLGtCQUMxRCx1QkFBQyxPQUFFLFdBQVUsb0NBQW9DQSx5QkFBZXVJLG1CQUFtQixLQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxRjtBQUFBLHFCQUZ2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLG1EQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLDhCQUE2QixpQ0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkQ7QUFBQSxrQkFDM0QsdUJBQUMsT0FBRSxXQUFVLG9DQUFvQ3ZJLHlCQUFld0ksb0JBQW9CLEtBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNGO0FBQUEscUJBRnhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsbURBQ2I7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsOEJBQTZCLCtCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RDtBQUFBLGtCQUN6RCx1QkFBQyxPQUFFLFdBQVUscUNBQ1Z4STtBQUFBQSxtQ0FBZXlJO0FBQUFBLG9CQUFXO0FBQUEsb0JBQUl6SSxlQUFlMEk7QUFBQUEsdUJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsbUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBLGlCQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXNCQTtBQUFBLGVBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUJBLEtBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMkJBO0FBQUEsVUFHRDVJLFNBQ0MsdUJBQUMsU0FBSSxXQUFVLG1EQUNiLGlDQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLG1DQUFDLFdBQVEsV0FBVSx3Q0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUQ7QUFBQSxZQUN2RCx1QkFBQyxTQUNDO0FBQUEscUNBQUMsUUFBRyxXQUFVLG1DQUFrQywrQkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0Q7QUFBQSxjQUMvRCx1QkFBQyxPQUFFLFdBQVUsZ0JBQWdCQSxtQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUM7QUFBQSxpQkFGckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxhQXpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkNBO0FBQUEsV0EzbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2bEJBO0FBQUEsU0FobUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpbUJBO0FBQUEsT0FubUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvbUJBLEtBcm1CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc21CQTtBQUVKO0FBQUVOLEdBNzZCSUQsY0FBWTtBQUFBLFVBQ0M3QixXQUFXO0FBQUE7QUFBQWlMLEtBRHhCcEo7QUErNkJOLGVBQWVBO0FBQWEsSUFBQW9KO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUmVmIiwidXNlTmF2aWdhdGUiLCJOYXZiYXIiLCJTaWRlYmFyIiwiQ2lyY3VsYXJMb2FkZXIiLCJBcnJvd0xlZnQiLCJMb2FkZXIyIiwiQ2hlY2tDaXJjbGUiLCJYQ2lyY2xlIiwiQWxlcnRDaXJjbGUiLCJSZWZyZXNoQ3ciLCJDYWxlbmRhciIsIkZpbGVUZXh0IiwiVHJlbmRpbmdVcCIsIlVzZXJzIiwiQ3JlZGl0Q2FyZCIsIlNlbmQiLCJJbmZvIiwiU2VhcmNoIiwiVXNlciIsIlRhZyIsIlBhY2thZ2UiLCJYIiwiWmFwIiwiRXllIiwiRG9sbGFyU2lnbiIsIlJlY2VpcHQiLCJDbG9jayIsIkFycm93UmlnaHQiLCJhcGkiLCJUcmFuc2Zlck1lbnUiLCJfcyIsIm5hdmlnYXRlIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzdWNjZXNzIiwic2V0U3VjY2VzcyIsImVycm9yIiwic2V0RXJyb3IiLCJ0cmFuc2ZlclJlc3VsdCIsInNldFRyYW5zZmVyUmVzdWx0Iiwic2hvd1ByZXZpZXciLCJzZXRTaG93UHJldmlldyIsInByZXZpZXdEYXRhIiwic2V0UHJldmlld0RhdGEiLCJpc0xvYWRpbmdQcmV2aWV3Iiwic2V0SXNMb2FkaW5nUHJldmlldyIsImFsbEVucm9sbG1lbnRzIiwic2V0QWxsRW5yb2xsbWVudHMiLCJpc0xvYWRpbmdFbnJvbGxtZW50cyIsInNldElzTG9hZGluZ0Vucm9sbG1lbnRzIiwiZnJvbVNlYXJjaCIsInNldEZyb21TZWFyY2giLCJ0b1NlYXJjaCIsInNldFRvU2VhcmNoIiwiZnJvbVJlc3VsdHMiLCJzZXRGcm9tUmVzdWx0cyIsInRvUmVzdWx0cyIsInNldFRvUmVzdWx0cyIsInNob3dGcm9tRHJvcGRvd24iLCJzZXRTaG93RnJvbURyb3Bkb3duIiwic2hvd1RvRHJvcGRvd24iLCJzZXRTaG93VG9Ecm9wZG93biIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJmcm9tRW5yb2xsSWQiLCJ0b0Vucm9sbElkIiwiZnJvbURpc3BsYXkiLCJ0b0Rpc3BsYXkiLCJmcm9tRW5yb2xsRGV0YWlscyIsInRvRW5yb2xsRGV0YWlscyIsImZyb21SZWYiLCJ0b1JlZiIsImxlbmd0aCIsInBhcmFtcyIsIlVSTFNlYXJjaFBhcmFtcyIsImxvY2F0aW9uIiwic2VhcmNoIiwic291cmNlSWQiLCJnZXQiLCJkZXN0SWQiLCJzb3VyY2UiLCJmaW5kIiwiZSIsIl9pZCIsImhhbmRsZVNlbGVjdEVucm9sbG1lbnQiLCJkZXN0IiwiZmV0Y2hBbGxFbnJvbGxtZW50cyIsInJlc3BvbnNlIiwiZGF0YSIsInN0YXR1c0NvZGUiLCJzdGF0dXMiLCJlbnJvbGxtZW50cyIsImVucm9sbHMiLCJjb25zb2xlIiwiZXJyIiwiZmV0Y2hQYXltZW50QmFsYW5jZSIsImVucm9sbElkIiwidGlja2V0IiwidG90YWxfYW1vdW50IiwiZmV0Y2hQYXltZW50UHJldmlldyIsInNvdXJjZUVucm9sbCIsImRlc3RFbnJvbGwiLCJzb3VyY2VCYWxhbmNlIiwidGlja2V0cyIsImRlc3RCYWxhbmNlIiwiYWZ0ZXJTb3VyY2VCYWxhbmNlIiwiYWZ0ZXJEZXN0QmFsYW5jZSIsInNvdXJjZVRpY2tldCIsImRlc3RUaWNrZXQiLCJzb3VyY2VDdXN0b21lciIsInVzZXJfaWQiLCJmdWxsX25hbWUiLCJkZXN0Q3VzdG9tZXIiLCJzb3VyY2VHcm91cCIsImdyb3VwX2lkIiwiZ3JvdXBfbmFtZSIsImRlc3RHcm91cCIsInNvdXJjZUN1cnJlbnRCYWxhbmNlIiwiZGVzdEN1cnJlbnRCYWxhbmNlIiwidHJhbnNmZXJBbW91bnQiLCJmb3JtYXRDdXJyZW5jeSIsImFtb3VudCIsIkludGwiLCJOdW1iZXJGb3JtYXQiLCJzdHlsZSIsImN1cnJlbmN5IiwibWluaW11bUZyYWN0aW9uRGlnaXRzIiwiZm9ybWF0IiwiZm9ybWF0RGF0ZSIsImRhdGUiLCJEYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiZGF5IiwibW9udGgiLCJ5ZWFyIiwic2VhcmNoRW5yb2xsbWVudHMiLCJzZWFyY2hUZXJtIiwidHlwZSIsInRyaW0iLCJzZWFyY2hMb3dlciIsInRvTG93ZXJDYXNlIiwiZmlsdGVyZWQiLCJmaWx0ZXIiLCJjdXN0b21lck5hbWUiLCJncm91cE5hbWUiLCJTdHJpbmciLCJjdXN0b21lckVtYWlsIiwiZW1haWwiLCJjdXN0b21lclBob25lIiwicGhvbmVfbnVtYmVyIiwiaW5jbHVkZXMiLCJzbGljZSIsImRpc3BsYXlUZXh0IiwicHJldiIsImhhbmRsZUNsZWFyU2VsZWN0aW9uIiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJwb3N0IiwibWVzc2FnZSIsImhhbmRsZVJlc2V0IiwiaGFuZGxlQ2xpY2tPdXRzaWRlIiwiZXZlbnQiLCJjdXJyZW50IiwiY29udGFpbnMiLCJ0YXJnZXQiLCJkb2N1bWVudCIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwidmFsdWUiLCJtYXAiLCJlbnJvbGwiLCJtYXhIZWlnaHQiLCJFdmVudCIsIm1hdGNoZWRQYXltZW50cyIsIm1vZGlmaWVkUGF5bWVudHMiLCJmcm9tVGlja2V0IiwidG9UaWNrZXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUcmFuc2Zlck1lbnUuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIGltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG4vLyBpbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbi8vIGltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG4vLyBpbXBvcnQgeyBVc2VycywgQnJpZWZjYXNlLCBDaGV2cm9uUmlnaHQsWmFwICB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuLy8gaW1wb3J0IHsgR3JVc2VyU2V0dGluZ3MgfSBmcm9tIFwicmVhY3QtaWNvbnMvZ3JcIjtcclxuXHJcbi8vIGNvbnN0IFRyYW5zZmVyTWVudSA9ICgpID0+IHtcclxuLy8gICBjb25zdCB0cmFuc2ZlckNhdGVnb3JpZXMgPSBbXHJcbi8vICAgICB7XHJcbi8vICAgICAgIGlkOiAxLFxyXG4vLyAgICAgICB0aXRsZTogXCJTb2Z0IFRyYW5zZmVyXCIsXHJcbi8vICAgICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBTb2Z0IFRyYW5mZXIgcmVjb3Jkc1wiLFxyXG4vLyAgICAgICBpY29uOiA8R3JVc2VyU2V0dGluZ3MgY2xhc3NOYW1lPVwidy04IGgtOFwiIC8+LFxyXG4vLyAgICAgICBjb2xvcjogXCJmcm9tLWJsdWUtNjAwIHRvLWJsdWUtNzAwXCIsXHJcbi8vICAgICAgIGxpZ2h0Q29sb3I6IFwiYmctYmx1ZS01MFwiLFxyXG4vLyAgICAgICBib3JkZXJDb2xvcjogXCJib3JkZXItYmx1ZS0yMDBcIixcclxuLy8gICAgICAgaHJlZjogXCIvdHJhbnNmZXItbWVudS9zb2Z0LXRyYW5zZmVyXCIsXHJcbi8vICAgICAgIHN0YXRzOiBcIkFjdGl2ZSBTb2Z0IFRyYW5zZmVyXCIsXHJcbi8vICAgICB9LFxyXG4vLyAgICAge1xyXG4vLyAgICAgICBpZDogMixcclxuLy8gICAgICAgdGl0bGU6IFwiSGFyZCBUcmFuc2ZlclwiLFxyXG4vLyAgICAgICBkZXNjcmlwdGlvbjogXCJNYW5hZ2UgSGFyZCByZWNvcmRzXCIsXHJcbi8vICAgICAgIGljb246IDxHclVzZXJTZXR0aW5ncyBjbGFzc05hbWU9XCJ3LTggaC04XCIgLz4sXHJcbi8vICAgICAgIGNvbG9yOiBcImZyb20tYW1iZXItNjAwIHRvLWFtYmVyLTcwMFwiLFxyXG4vLyAgICAgICBsaWdodENvbG9yOiBcImJnLWFtYmVyLTUwXCIsXHJcbi8vICAgICAgIGJvcmRlckNvbG9yOiBcImJvcmRlci1hbWJlci0yMDBcIixcclxuLy8gICAgICAgaHJlZjogXCIvdHJhbnNmZXItbWVudS9oYXJkLXRyYW5zZmVyXCIsXHJcbi8vICAgICAgIHN0YXRzOiBcIkFjdGl2ZSBIYXJkIFRyYW5zZmVyXCIsXHJcbi8vICAgICB9LFxyXG4vLyAgIF07XHJcblxyXG4vLyAgIHJldHVybiAoXHJcbi8vICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLXNjcmVlbiB3LWZ1bGwgYmctZ3JheS01MFwiPlxyXG4vLyAgICAgICAgIDxTaWRlYmFyIC8+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuLy8gICAgICAgICAgIDxOYXZiYXIgdmlzaWJpbGl0eT17dHJ1ZX0gLz5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04XCI+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4vLyAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgVHJhbnNmZXIgTWFuYWdlbWVudFxyXG4vLyAgICAgICAgICAgICAgIDwvaDI+XHJcbi8vICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBtdC0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICBNYW5hZ2UgYW5kIG9yZ2FuaXplIHlvdXIgdGVhbSBtZW1iZXJzXHJcbi8vICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMiBnYXAtNlwiPlxyXG4vLyAgICAgICAgICAgICAgIHt0cmFuc2ZlckNhdGVnb3JpZXMubWFwKChjYXRlZ29yeSkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgPExpbmsga2V5PXtjYXRlZ29yeS5pZH0gdG89e2NhdGVnb3J5LmhyZWZ9IGNsYXNzTmFtZT1cImdyb3VwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2ByZWxhdGl2ZSBoLWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQteGwgYmctd2hpdGUgYm9yZGVyICR7Y2F0ZWdvcnkuYm9yZGVyQ29sb3J9IHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwYH1cclxuLy8gICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGFic29sdXRlIHRvcC0wIHJpZ2h0LTAgdy0zMiBoLTMyIGJnLWdyYWRpZW50LXRvLWJyICR7Y2F0ZWdvcnkuY29sb3J9IG9wYWNpdHktNSBncm91cC1ob3ZlcjpvcGFjaXR5LTEwIHJvdW5kZWQtZnVsbCAtbXItMTYgLW10LTE2IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBibHVyLXhsYH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHAtN1wiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdy0xNCBoLTE0ICR7Y2F0ZWdvcnkubGlnaHRDb2xvcn0gcm91bmRlZC1sZyBtYi01IGdyb3VwLWhvdmVyOnNjYWxlLTEwNSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDBgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PntjYXRlZ29yeS5pY29ufTwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi01XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIG1iLTIgZ3JvdXAtaG92ZXI6dGV4dC1ncmF5LTk1MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeS50aXRsZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeS5kZXNjcmlwdGlvbn1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZ3JvdXAtaG92ZXI6Ym9yZGVyLWdyYXktMjAwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBncm91cC1ob3Zlcjp0ZXh0LWdyYXktNzAwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAge2NhdGVnb3J5LnN0YXRzfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTEuNSByb3VuZGVkLWxnIGJnLWdyYWRpZW50LXRvLWJyICR7Y2F0ZWdvcnkuY29sb3J9IG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2Zvcm0gdHJhbnNsYXRlLXgtMSBncm91cC1ob3Zlcjp0cmFuc2xhdGUteC0wIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMGB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC13aGl0ZVwiIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGFic29sdXRlIHRvcC0wIGxlZnQtMCByaWdodC0wIGgtMC41IGJnLWdyYWRpZW50LXRvLXIgJHtjYXRlZ29yeS5jb2xvcn0gb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eSBkdXJhdGlvbi0zMDBgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4vLyAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTE2IHAtOCBiZy1ncmFkaWVudC10by1iciBmcm9tLWJsdWUtNTAgdG8taW5kaWdvLTUwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItYmx1ZS0xMDBcIj5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00XCI+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8WmFwIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1ibHVlLTYwMCBtdC0xXCIgLz5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMCBtYi0yXCI+UXVpY2sgVGlwczwvaDM+XHJcbi8vICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTcwMFwiPlVzZSB0aGUgdHJhbnNmZXIgZGlyZWN0b3J5IHRvIG1hbmFnZSBoYXJkLCBzb2Z0IHRyYW5zZmVyLCB1cGRhdGUgdHJhbnNmZXIgaW5mb3JtYXRpb24uPC9wPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgIDwvZGl2PlxyXG4vLyAgICAgPC9kaXY+XHJcbi8vICAgKTtcclxuLy8gfTtcclxuXHJcbi8vIGV4cG9ydCBkZWZhdWx0IFRyYW5zZmVyTWVudTtcclxuXHJcbmltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQge1xyXG4gIEFycm93TGVmdCxcclxuICBMb2FkZXIyLFxyXG4gIENoZWNrQ2lyY2xlLFxyXG4gIFhDaXJjbGUsXHJcbiAgQWxlcnRDaXJjbGUsXHJcbiAgUmVmcmVzaEN3LFxyXG4gIENhbGVuZGFyLFxyXG4gIEZpbGVUZXh0LFxyXG4gIFRyZW5kaW5nVXAsXHJcbiAgVXNlcnMsXHJcbiAgQ3JlZGl0Q2FyZCxcclxuICBTZW5kLFxyXG4gIEluZm8sXHJcbiAgU2VhcmNoLFxyXG4gIFVzZXIsXHJcbiAgVGFnLFxyXG4gIFBhY2thZ2UsXHJcbiAgWCxcclxuICBaYXAsXHJcbiAgRXllLFxyXG4gIERvbGxhclNpZ24sXHJcbiAgUmVjZWlwdCxcclxuICBDbG9jayxcclxuICBBcnJvd1JpZ2h0LFxyXG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5cclxuY29uc3QgVHJhbnNmZXJNZW51ID0gKCkgPT4ge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3N1Y2Nlc3MsIHNldFN1Y2Nlc3NdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbdHJhbnNmZXJSZXN1bHQsIHNldFRyYW5zZmVyUmVzdWx0XSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIFxyXG4gIC8vIFByZXZpZXcgc3RhdGVzXHJcbiAgY29uc3QgW3Nob3dQcmV2aWV3LCBzZXRTaG93UHJldmlld10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3ByZXZpZXdEYXRhLCBzZXRQcmV2aWV3RGF0YV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbaXNMb2FkaW5nUHJldmlldywgc2V0SXNMb2FkaW5nUHJldmlld10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgXHJcbiAgY29uc3QgW2FsbEVucm9sbG1lbnRzLCBzZXRBbGxFbnJvbGxtZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZ0Vucm9sbG1lbnRzLCBzZXRJc0xvYWRpbmdFbnJvbGxtZW50c10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgXHJcbiAgY29uc3QgW2Zyb21TZWFyY2gsIHNldEZyb21TZWFyY2hdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3RvU2VhcmNoLCBzZXRUb1NlYXJjaF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZnJvbVJlc3VsdHMsIHNldEZyb21SZXN1bHRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdG9SZXN1bHRzLCBzZXRUb1Jlc3VsdHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzaG93RnJvbURyb3Bkb3duLCBzZXRTaG93RnJvbURyb3Bkb3duXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd1RvRHJvcGRvd24sIHNldFNob3dUb0Ryb3Bkb3duXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBcclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGZyb21FbnJvbGxJZDogXCJcIixcclxuICAgIHRvRW5yb2xsSWQ6IFwiXCIsXHJcbiAgICBmcm9tRGlzcGxheTogXCJcIixcclxuICAgIHRvRGlzcGxheTogXCJcIixcclxuICAgIGZyb21FbnJvbGxEZXRhaWxzOiBudWxsLFxyXG4gICAgdG9FbnJvbGxEZXRhaWxzOiBudWxsLFxyXG4gIH0pO1xyXG4gIFxyXG4gIGNvbnN0IGZyb21SZWYgPSB1c2VSZWYoKTtcclxuICBjb25zdCB0b1JlZiA9IHVzZVJlZigpO1xyXG5cclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChhbGxFbnJvbGxtZW50cy5sZW5ndGggPT09IDApIHJldHVybjtcclxuXHJcbiAgICBjb25zdCBwYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKGxvY2F0aW9uLnNlYXJjaCk7XHJcbiAgICBjb25zdCBzb3VyY2VJZCA9IHBhcmFtcy5nZXQoXCJzb3VyY2VFbnJvbGxtZW50SWRcIik7XHJcbiAgICBjb25zdCBkZXN0SWQgPSBwYXJhbXMuZ2V0KFwiZGVzdEVucm9sbG1lbnRJZFwiKTtcclxuXHJcbiAgICBpZiAoc291cmNlSWQgJiYgIWZvcm1EYXRhLmZyb21FbnJvbGxJZCkge1xyXG4gICAgICBjb25zdCBzb3VyY2UgPSBhbGxFbnJvbGxtZW50cy5maW5kKGUgPT4gZS5faWQgPT09IHNvdXJjZUlkKTtcclxuICAgICAgaWYgKHNvdXJjZSkgaGFuZGxlU2VsZWN0RW5yb2xsbWVudChzb3VyY2UsIFwiZnJvbVwiKTtcclxuICAgIH1cclxuICAgIGlmIChkZXN0SWQgJiYgIWZvcm1EYXRhLnRvRW5yb2xsSWQpIHtcclxuICAgICAgY29uc3QgZGVzdCA9IGFsbEVucm9sbG1lbnRzLmZpbmQoZSA9PiBlLl9pZCA9PT0gZGVzdElkKTtcclxuICAgICAgaWYgKGRlc3QpIGhhbmRsZVNlbGVjdEVucm9sbG1lbnQoZGVzdCwgXCJ0b1wiKTtcclxuICAgIH1cclxuICB9LCBbYWxsRW5yb2xsbWVudHMsIGxvY2F0aW9uLnNlYXJjaCwgZm9ybURhdGEuZnJvbUVucm9sbElkLCBmb3JtRGF0YS50b0Vucm9sbElkXSk7XHJcblxyXG4gIFxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoYWxsRW5yb2xsbWVudHMubGVuZ3RoID09PSAwKSByZXR1cm47XHJcblxyXG4gICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhsb2NhdGlvbi5zZWFyY2gpO1xyXG4gICAgY29uc3Qgc291cmNlSWQgPSBwYXJhbXMuZ2V0KFwic291cmNlRW5yb2xsbWVudElkXCIpO1xyXG4gICAgY29uc3QgZGVzdElkID0gcGFyYW1zLmdldChcImRlc3RFbnJvbGxtZW50SWRcIik7XHJcblxyXG4gICAgaWYgKHNvdXJjZUlkICYmICFmb3JtRGF0YS5mcm9tRW5yb2xsSWQpIHtcclxuICAgICAgY29uc3Qgc291cmNlID0gYWxsRW5yb2xsbWVudHMuZmluZChlID0+IGUuX2lkID09PSBzb3VyY2VJZCk7XHJcbiAgICAgIGlmIChzb3VyY2UpIGhhbmRsZVNlbGVjdEVucm9sbG1lbnQoc291cmNlLCBcImZyb21cIik7XHJcbiAgICB9XHJcbiAgICBpZiAoZGVzdElkICYmICFmb3JtRGF0YS50b0Vucm9sbElkKSB7XHJcbiAgICAgIGNvbnN0IGRlc3QgPSBhbGxFbnJvbGxtZW50cy5maW5kKGUgPT4gZS5faWQgPT09IGRlc3RJZCk7XHJcbiAgICAgIGlmIChkZXN0KSBoYW5kbGVTZWxlY3RFbnJvbGxtZW50KGRlc3QsIFwidG9cIik7XHJcbiAgICB9XHJcbiAgfSwgW2FsbEVucm9sbG1lbnRzLCBsb2NhdGlvbi5zZWFyY2gsIGZvcm1EYXRhLmZyb21FbnJvbGxJZCwgZm9ybURhdGEudG9FbnJvbGxJZF0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hBbGxFbnJvbGxtZW50cygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hBbGxFbnJvbGxtZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgIHNldElzTG9hZGluZ0Vucm9sbG1lbnRzKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3YxL2FkbWluL2Vucm9sbHMvZ2V0LWFsbC1lbnJvbGxzXCIpO1xyXG4gICAgICBcclxuICAgICAgaWYgKHJlc3BvbnNlLmRhdGEuc3RhdHVzQ29kZSA9PT0gMjAwIHx8IHJlc3BvbnNlLmRhdGEuc3RhdHVzID09PSB0cnVlKSB7XHJcbiAgICAgICAgY29uc3QgZW5yb2xsbWVudHMgPSByZXNwb25zZS5kYXRhLmRhdGEgfHwgcmVzcG9uc2UuZGF0YS5lbnJvbGxzIHx8IFtdO1xyXG4gICAgICAgIHNldEFsbEVucm9sbG1lbnRzKGVucm9sbG1lbnRzKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiVW5leHBlY3RlZCByZXNwb25zZSBzdHJ1Y3R1cmU6XCIsIHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVucm9sbG1lbnRzOlwiLCBlcnIpO1xyXG4gICAgICBzZXRFcnJvcihcIkZhaWxlZCB0byBsb2FkIGVucm9sbG1lbnRzLiBQbGVhc2UgcmVmcmVzaCB0aGUgcGFnZS5cIik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmdFbnJvbGxtZW50cyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gRmV0Y2ggcGF5bWVudCBiYWxhbmNlIGZvciBhIHNwZWNpZmljIHRpY2tldC9lbnJvbGxtZW50XHJcbiAgY29uc3QgZmV0Y2hQYXltZW50QmFsYW5jZSA9IGFzeW5jIChlbnJvbGxJZCwgdGlja2V0KSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC92MS9hZG1pbi9lbnJvbGxzLyR7ZW5yb2xsSWR9L3BheW1lbnRzL3RvdGFsYW1vdW50YCk7XHJcbiAgICAgIHJldHVybiByZXNwb25zZS5kYXRhPy5kYXRhPy50b3RhbF9hbW91bnQgfHwgMDtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYmFsYW5jZTpcIiwgZXJyKTtcclxuICAgICAgcmV0dXJuIDA7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gRmV0Y2ggcHJldmlldyB3aXRoIGJhbGFuY2UgaW5mb3JtYXRpb25cclxuICBjb25zdCBmZXRjaFBheW1lbnRQcmV2aWV3ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFmb3JtRGF0YS5mcm9tRW5yb2xsSWQgfHwgIWZvcm1EYXRhLnRvRW5yb2xsSWQpIHtcclxuICAgICAgc2V0RXJyb3IoXCJQbGVhc2Ugc2VsZWN0IGJvdGggc291cmNlIGFuZCBkZXN0aW5hdGlvbiBlbnJvbGxtZW50cyBmaXJzdFwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldElzTG9hZGluZ1ByZXZpZXcodHJ1ZSk7XHJcbiAgICBzZXRFcnJvcihudWxsKTtcclxuICAgIFxyXG4gICAgdHJ5IHtcclxuICAgICAgLy8gR2V0IHRoZSBlbnJvbGxtZW50IGRldGFpbHNcclxuICAgICAgY29uc3Qgc291cmNlRW5yb2xsID0gYWxsRW5yb2xsbWVudHMuZmluZChlID0+IGUuX2lkID09PSBmb3JtRGF0YS5mcm9tRW5yb2xsSWQpO1xyXG4gICAgICBjb25zdCBkZXN0RW5yb2xsID0gYWxsRW5yb2xsbWVudHMuZmluZChlID0+IGUuX2lkID09PSBmb3JtRGF0YS50b0Vucm9sbElkKTtcclxuICAgICAgXHJcbiAgICAgIC8vIEZldGNoIGN1cnJlbnQgYmFsYW5jZXNcclxuICAgICAgY29uc3Qgc291cmNlQmFsYW5jZSA9IGF3YWl0IGZldGNoUGF5bWVudEJhbGFuY2UoZm9ybURhdGEuZnJvbUVucm9sbElkLCBzb3VyY2VFbnJvbGw/LnRpY2tldHMgfHwgc291cmNlRW5yb2xsPy50aWNrZXQpO1xyXG4gICAgICBjb25zdCBkZXN0QmFsYW5jZSA9IGF3YWl0IGZldGNoUGF5bWVudEJhbGFuY2UoZm9ybURhdGEudG9FbnJvbGxJZCwgZGVzdEVucm9sbD8udGlja2V0cyB8fCBkZXN0RW5yb2xsPy50aWNrZXQpO1xyXG4gICAgICBcclxuICAgICAgLy8gQ2FsY3VsYXRlIGFmdGVyIHRyYW5zZmVyIGJhbGFuY2VzXHJcbiAgICAgIGNvbnN0IGFmdGVyU291cmNlQmFsYW5jZSA9IDA7IC8vIFNvdXJjZSBiZWNvbWVzIHplcm8gYWZ0ZXIgdHJhbnNmZXJcclxuICAgICAgY29uc3QgYWZ0ZXJEZXN0QmFsYW5jZSA9IGRlc3RCYWxhbmNlICsgc291cmNlQmFsYW5jZTsgLy8gRGVzdGluYXRpb24gZ2V0cyBzb3VyY2UgYmFsYW5jZSBhZGRlZFxyXG4gICAgICBcclxuICAgICAgc2V0UHJldmlld0RhdGEoe1xyXG4gICAgICAgIHNvdXJjZUVucm9sbCxcclxuICAgICAgICBkZXN0RW5yb2xsLFxyXG4gICAgICAgIHNvdXJjZVRpY2tldDogc291cmNlRW5yb2xsPy50aWNrZXRzIHx8IHNvdXJjZUVucm9sbD8udGlja2V0IHx8IFwiTi9BXCIsXHJcbiAgICAgICAgZGVzdFRpY2tldDogZGVzdEVucm9sbD8udGlja2V0cyB8fCBkZXN0RW5yb2xsPy50aWNrZXQgfHwgXCJOL0FcIixcclxuICAgICAgICBzb3VyY2VDdXN0b21lcjogc291cmNlRW5yb2xsPy51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCJVbmtub3duXCIsXHJcbiAgICAgICAgZGVzdEN1c3RvbWVyOiBkZXN0RW5yb2xsPy51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCJVbmtub3duXCIsXHJcbiAgICAgICAgc291cmNlR3JvdXA6IHNvdXJjZUVucm9sbD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCJVbmtub3duXCIsXHJcbiAgICAgICAgZGVzdEdyb3VwOiBkZXN0RW5yb2xsPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIlVua25vd25cIixcclxuICAgICAgICBzb3VyY2VDdXJyZW50QmFsYW5jZTogc291cmNlQmFsYW5jZSxcclxuICAgICAgICBkZXN0Q3VycmVudEJhbGFuY2U6IGRlc3RCYWxhbmNlLFxyXG4gICAgICAgIHRyYW5zZmVyQW1vdW50OiBzb3VyY2VCYWxhbmNlLFxyXG4gICAgICAgIGFmdGVyU291cmNlQmFsYW5jZTogYWZ0ZXJTb3VyY2VCYWxhbmNlLFxyXG4gICAgICAgIGFmdGVyRGVzdEJhbGFuY2U6IGFmdGVyRGVzdEJhbGFuY2UsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRTaG93UHJldmlldyh0cnVlKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcHJldmlldzpcIiwgZXJyKTtcclxuICAgICAgc2V0RXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggcGF5bWVudCBwcmV2aWV3LiBQbGVhc2UgdHJ5IGFnYWluLlwiKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZ1ByZXZpZXcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZvcm1hdEN1cnJlbmN5ID0gKGFtb3VudCkgPT4ge1xyXG4gICAgcmV0dXJuIG5ldyBJbnRsLk51bWJlckZvcm1hdChcImVuLUlOXCIsIHtcclxuICAgICAgc3R5bGU6IFwiY3VycmVuY3lcIixcclxuICAgICAgY3VycmVuY3k6IFwiSU5SXCIsXHJcbiAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgIH0pLmZvcm1hdChhbW91bnQgfHwgMCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlKSA9PiB7XHJcbiAgICBpZiAoIWRhdGUpIHJldHVybiBcIk4vQVwiO1xyXG4gICAgcmV0dXJuIG5ldyBEYXRlKGRhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgZGF5OiBcIjItZGlnaXRcIixcclxuICAgICAgbW9udGg6IFwiMi1kaWdpdFwiLFxyXG4gICAgICB5ZWFyOiBcIm51bWVyaWNcIixcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHNlYXJjaEVucm9sbG1lbnRzID0gKHNlYXJjaFRlcm0sIHR5cGUpID0+IHtcclxuICAgIGlmICghc2VhcmNoVGVybS50cmltKCkpIHtcclxuICAgICAgaWYgKHR5cGUgPT09IFwiZnJvbVwiKSBzZXRGcm9tUmVzdWx0cyhbXSk7XHJcbiAgICAgIGlmICh0eXBlID09PSBcInRvXCIpIHNldFRvUmVzdWx0cyhbXSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBzZWFyY2hMb3dlciA9IHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKTtcclxuICAgIGNvbnN0IGZpbHRlcmVkID0gYWxsRW5yb2xsbWVudHMuZmlsdGVyKGVucm9sbHMgPT4ge1xyXG4gICAgICBjb25zdCBjdXN0b21lck5hbWUgPSBlbnJvbGxzLnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIlwiO1xyXG4gICAgICBjb25zdCBncm91cE5hbWUgPSBlbnJvbGxzLmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IFwiXCI7XHJcbiAgICAgIGNvbnN0IHRpY2tldCA9IFN0cmluZyhlbnJvbGxzLnRpY2tldHMgfHwgZW5yb2xscy50aWNrZXQgfHwgXCJcIik7XHJcbiAgICAgIGNvbnN0IGN1c3RvbWVyRW1haWwgPSBlbnJvbGxzLnVzZXJfaWQ/LmVtYWlsIHx8IFwiXCI7XHJcbiAgICAgIGNvbnN0IGN1c3RvbWVyUGhvbmUgPSBlbnJvbGxzLnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIlwiO1xyXG5cclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICBjdXN0b21lck5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hMb3dlcikgfHxcclxuICAgICAgICBncm91cE5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hMb3dlcikgfHxcclxuICAgICAgICB0aWNrZXQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hMb3dlcikgfHxcclxuICAgICAgICBjdXN0b21lckVtYWlsLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoTG93ZXIpIHx8XHJcbiAgICAgICAgY3VzdG9tZXJQaG9uZS5pbmNsdWRlcyhzZWFyY2hUZXJtKVxyXG4gICAgICApO1xyXG4gICAgfSk7XHJcblxyXG4gICAgaWYgKHR5cGUgPT09IFwiZnJvbVwiKSB7XHJcbiAgICAgIHNldEZyb21SZXN1bHRzKGZpbHRlcmVkLnNsaWNlKDAsIDEwKSk7IFxyXG4gICAgICBzZXRTaG93RnJvbURyb3Bkb3duKHRydWUpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0VG9SZXN1bHRzKGZpbHRlcmVkLnNsaWNlKDAsIDEwKSk7XHJcbiAgICAgIHNldFNob3dUb0Ryb3Bkb3duKHRydWUpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNlbGVjdEVucm9sbG1lbnQgPSAoZW5yb2xscywgdHlwZSkgPT4ge1xyXG4gICAgY29uc3QgY3VzdG9tZXJOYW1lID0gZW5yb2xscy51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCJVbmtub3duIEN1c3RvbWVyXCI7XHJcbiAgICBjb25zdCBncm91cE5hbWUgPSBlbnJvbGxzLmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IFwiVW5rbm93biBHcm91cFwiO1xyXG4gICAgY29uc3QgdGlja2V0ID0gZW5yb2xscy50aWNrZXRzIHx8IGVucm9sbHMudGlja2V0IHx8IFwiTi9BXCI7XHJcbiAgICBjb25zdCBkaXNwbGF5VGV4dCA9IGAke2N1c3RvbWVyTmFtZX0gfCAke2dyb3VwTmFtZX0gfCAke3RpY2tldH1gO1xyXG4gICAgXHJcbiAgICBpZiAodHlwZSA9PT0gXCJmcm9tXCIpIHtcclxuICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgZnJvbUVucm9sbElkOiBlbnJvbGxzLl9pZCxcclxuICAgICAgICBmcm9tRGlzcGxheTogZGlzcGxheVRleHQsXHJcbiAgICAgICAgZnJvbUVucm9sbERldGFpbHM6IGVucm9sbHMsXHJcbiAgICAgIH0pKTtcclxuICAgICAgc2V0RnJvbVNlYXJjaChcIlwiKTtcclxuICAgICAgc2V0U2hvd0Zyb21Ecm9wZG93bihmYWxzZSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7XHJcbiAgICAgICAgLi4ucHJldixcclxuICAgICAgICB0b0Vucm9sbElkOiBlbnJvbGxzLl9pZCxcclxuICAgICAgICB0b0Rpc3BsYXk6IGRpc3BsYXlUZXh0LFxyXG4gICAgICAgIHRvRW5yb2xsRGV0YWlsczogZW5yb2xscyxcclxuICAgICAgfSkpO1xyXG4gICAgICBzZXRUb1NlYXJjaChcIlwiKTtcclxuICAgICAgc2V0U2hvd1RvRHJvcGRvd24oZmFsc2UpO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICBzZXRTdWNjZXNzKG51bGwpO1xyXG4gICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICBzZXRUcmFuc2ZlclJlc3VsdChudWxsKTtcclxuICAgIHNldFNob3dQcmV2aWV3KGZhbHNlKTtcclxuICAgIHNldFByZXZpZXdEYXRhKG51bGwpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNsZWFyU2VsZWN0aW9uID0gKHR5cGUpID0+IHtcclxuICAgIGlmICh0eXBlID09PSBcImZyb21cIikge1xyXG4gICAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7XHJcbiAgICAgICAgLi4ucHJldixcclxuICAgICAgICBmcm9tRW5yb2xsSWQ6IFwiXCIsXHJcbiAgICAgICAgZnJvbURpc3BsYXk6IFwiXCIsXHJcbiAgICAgICAgZnJvbUVucm9sbERldGFpbHM6IG51bGwsXHJcbiAgICAgIH0pKTtcclxuICAgICAgc2V0RnJvbVNlYXJjaChcIlwiKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIHRvRW5yb2xsSWQ6IFwiXCIsXHJcbiAgICAgICAgdG9EaXNwbGF5OiBcIlwiLFxyXG4gICAgICAgIHRvRW5yb2xsRGV0YWlsczogbnVsbCxcclxuICAgICAgfSkpO1xyXG4gICAgICBzZXRUb1NlYXJjaChcIlwiKTtcclxuICAgIH1cclxuICAgIHNldFNob3dQcmV2aWV3KGZhbHNlKTtcclxuICAgIHNldFByZXZpZXdEYXRhKG51bGwpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBcclxuICAgIGlmICghZm9ybURhdGEuZnJvbUVucm9sbElkIHx8ICFmb3JtRGF0YS50b0Vucm9sbElkKSB7XHJcbiAgICAgIHNldEVycm9yKFwiUGxlYXNlIHNlbGVjdCBib3RoIHNvdXJjZSBhbmQgZGVzdGluYXRpb24gZW5yb2xsbWVudHNcIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoZm9ybURhdGEuZnJvbUVucm9sbElkID09PSBmb3JtRGF0YS50b0Vucm9sbElkKSB7XHJcbiAgICAgIHNldEVycm9yKFwiU291cmNlIGFuZCBkZXN0aW5hdGlvbiBlbnJvbGxtZW50cyBjYW5ub3QgYmUgdGhlIHNhbWVcIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICBzZXRTdWNjZXNzKG51bGwpO1xyXG4gICAgc2V0VHJhbnNmZXJSZXN1bHQobnVsbCk7XHJcbiAgICBzZXRTaG93UHJldmlldyhmYWxzZSk7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChcclxuICAgICAgICBgL3YxL2FkbWluL2Vucm9sbHMvJHtmb3JtRGF0YS5mcm9tRW5yb2xsSWR9LyR7Zm9ybURhdGEudG9FbnJvbGxJZH0vcGF5bWVudHMvY2hhbmdlYFxyXG4gICAgICApO1xyXG4gICAgICBcclxuICAgICAgaWYgKHJlc3BvbnNlLmRhdGEuc3RhdHVzKSB7XHJcbiAgICAgICAgc2V0U3VjY2VzcyhyZXNwb25zZS5kYXRhLm1lc3NhZ2UpO1xyXG4gICAgICAgIHNldFRyYW5zZmVyUmVzdWx0KHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEVycm9yKHJlc3BvbnNlLmRhdGEubWVzc2FnZSB8fCBcIlRyYW5zZmVyIGZhaWxlZFwiKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIHNldEVycm9yKGVyci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkFuIGVycm9yIG9jY3VycmVkIGR1cmluZyB0cmFuc2ZlclwiKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVJlc2V0ID0gKCkgPT4ge1xyXG4gICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICBmcm9tRW5yb2xsSWQ6IFwiXCIsXHJcbiAgICAgIHRvRW5yb2xsSWQ6IFwiXCIsXHJcbiAgICAgIGZyb21EaXNwbGF5OiBcIlwiLFxyXG4gICAgICB0b0Rpc3BsYXk6IFwiXCIsXHJcbiAgICAgIGZyb21FbnJvbGxEZXRhaWxzOiBudWxsLFxyXG4gICAgICB0b0Vucm9sbERldGFpbHM6IG51bGwsXHJcbiAgICB9KTtcclxuICAgIHNldEZyb21TZWFyY2goXCJcIik7XHJcbiAgICBzZXRUb1NlYXJjaChcIlwiKTtcclxuICAgIHNldFN1Y2Nlc3MobnVsbCk7XHJcbiAgICBzZXRFcnJvcihudWxsKTtcclxuICAgIHNldFRyYW5zZmVyUmVzdWx0KG51bGwpO1xyXG4gICAgc2V0U2hvd1ByZXZpZXcoZmFsc2UpO1xyXG4gICAgc2V0UHJldmlld0RhdGEobnVsbCk7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGhhbmRsZUNsaWNrT3V0c2lkZSA9IChldmVudCkgPT4ge1xyXG4gICAgICBpZiAoZnJvbVJlZi5jdXJyZW50ICYmICFmcm9tUmVmLmN1cnJlbnQuY29udGFpbnMoZXZlbnQudGFyZ2V0KSkge1xyXG4gICAgICAgIHNldFNob3dGcm9tRHJvcGRvd24oZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICAgIGlmICh0b1JlZi5jdXJyZW50ICYmICF0b1JlZi5jdXJyZW50LmNvbnRhaW5zKGV2ZW50LnRhcmdldCkpIHtcclxuICAgICAgICBzZXRTaG93VG9Ecm9wZG93bihmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwibW91c2Vkb3duXCIsIGhhbmRsZUNsaWNrT3V0c2lkZSk7XHJcbiAgICByZXR1cm4gKCkgPT4gZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIm1vdXNlZG93blwiLCBoYW5kbGVDbGlja091dHNpZGUpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtc2NyZWVuIHctZnVsbCBiZy1ncmFkaWVudC10by1iciBmcm9tLWdyYXktNTAgdG8tZ3JheS0xMDBcIj5cclxuICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICA8TmF2YmFyIHZpc2liaWxpdHk9e3RydWV9IC8+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IGxnOnAtOFwiPlxyXG4gICAgICAgICAgICB7LyogSGVhZGVyIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKC0xKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtZ3JheS02MDAgaG92ZXI6dGV4dC1ncmF5LTkwMCBtYi00IHRyYW5zaXRpb24tY29sb3JzIGdyb3VwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8QXJyb3dMZWZ0IGNsYXNzTmFtZT1cInctNCBoLTQgZ3JvdXAtaG92ZXI6LXRyYW5zbGF0ZS14LTEgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIiAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPkJhY2s8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZmxleC13cmFwIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1ncmFkaWVudC10by1iciBmcm9tLWJsdWUtNTAwIHRvLWJsdWUtNjAwIHJvdW5kZWQteGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxUcmVuZGluZ1VwIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC13aGl0ZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgR3JvdXAgQ2hhbmdlICYgUGF5bWVudCBUcmFuc2ZlclxyXG4gICAgICAgICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICBUcmFuc2ZlciBhbGwgcGF5bWVudHMgZnJvbSBvbmUgZW5yb2xsbWVudCB0byBhbm90aGVyXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMiBiZy1ibHVlLTUwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ibHVlLTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5mbyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYmx1ZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtYmx1ZS03MDBcIj5BZG1pbiBBY3Rpb24gUmVxdWlyZWQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7aXNMb2FkaW5nRW5yb2xsbWVudHMgPyAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBoLTY0XCI+XHJcbiAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbGc6Z3JpZC1jb2xzLTMgZ2FwLThcIj5cclxuICAgICAgICAgICAgICAgIHsvKiBNYWluIEZvcm0gLSBMZWZ0IFNpZGUgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBib3JkZXItYiBib3JkZXItZ3JheS0yMDAgYmctZ3JhZGllbnQtdG8tciBmcm9tLWdyYXktNTAgdG8td2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q3JlZGl0Q2FyZCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtYmx1ZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUcmFuc2ZlciBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgU2VhcmNoIGFuZCBzZWxlY3QgZW5yb2xsbWVudHMgdG8gdHJhbnNmZXIgcGF5bWVudHNcclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gY2xhc3NOYW1lPVwicC02IHNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIFNvdXJjZSBFbnJvbGxtZW50ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiByZWY9e2Zyb21SZWZ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFVzZXJzIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1yZWQtNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNvdXJjZSBFbnJvbGxtZW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmZyb21EaXNwbGF5ID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcC0zIGJnLXJlZC01MCBib3JkZXIgYm9yZGVyLXJlZC0yMDAgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+e2Zvcm1EYXRhLmZyb21EaXNwbGF5fTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTFcIj5JRDoge2Zvcm1EYXRhLmZyb21FbnJvbGxJZH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUNsZWFyU2VsZWN0aW9uKFwiZnJvbVwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIGhvdmVyOmJnLXJlZC0yMDAgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1yZWQtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTMgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHctNCBoLTQgdGV4dC1ncmF5LTQwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZnJvbVNlYXJjaH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZyb21TZWFyY2goZS50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VhcmNoRW5yb2xsbWVudHMoZS50YXJnZXQudmFsdWUsIFwiZnJvbVwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uRm9jdXM9eygpID0+IGZyb21SZXN1bHRzLmxlbmd0aCA+IDAgJiYgc2V0U2hvd0Zyb21Ecm9wZG93bih0cnVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBieSBjdXN0b21lciBuYW1lLCBncm91cCBuYW1lLCBvciB0aWNrZXQuLi5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwbC0xMCBwci00IHB5LTMgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXJlZC01MDAgZm9jdXM6Ym9yZGVyLXJlZC01MDAgdHJhbnNpdGlvbi1hbGwgb3V0bGluZS1ub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2hvd0Zyb21Ecm9wZG93biAmJiBmcm9tUmVzdWx0cy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB6LTEwIHctZnVsbCBtdC0xIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBzaGFkb3ctbGcgbWF4LWgtODAgb3ZlcmZsb3cteS1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zyb21SZXN1bHRzLm1hcCgoZW5yb2xsKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17ZW5yb2xsLl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNlbGVjdEVucm9sbG1lbnQoZW5yb2xsLCBcImZyb21cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgcC0zIGhvdmVyOmJnLWdyYXktNTAgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIGxhc3Q6Ym9yZGVyLTAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VXNlciBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS00MDAgbXQtMC41IGZsZXgtc2hyaW5rLTBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vucm9sbC51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCJVbmtub3duIEN1c3RvbWVyXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQYWNrYWdlIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlbnJvbGwuZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCJObyBHcm91cFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGFnIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRpY2tldDoge2Vucm9sbC50aWNrZXRzIHx8IGVucm9sbC50aWNrZXQgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS00MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBJRDoge2Vucm9sbC5faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Nob3dGcm9tRHJvcGRvd24gJiYgZnJvbVNlYXJjaCAmJiBmcm9tUmVzdWx0cy5sZW5ndGggPT09IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHotMTAgdy1mdWxsIG10LTEgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIHNoYWRvdy1sZyBwLTQgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5ObyBlbnJvbGxtZW50cyBmb3VuZDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50cyB3aWxsIGJlIHRyYW5zZmVycmVkIEZST00gdGhpcyBlbnJvbGxtZW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBUcmFuc2ZlciBBcnJvdyBBbmltYXRpb24gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ibHVlLTUwMCB0by1ibHVlLTYwMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hhZG93LWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VuZCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtd2hpdGVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXRvcC0xIC1yaWdodC0xIHctMyBoLTMgYmctZ3JlZW4tNTAwIHJvdW5kZWQtZnVsbCBhbmltYXRlLXBpbmdcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogRGVzdGluYXRpb24gRW5yb2xsbWVudCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgcmVmPXt0b1JlZn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VXNlcnMgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyZWVuLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBEZXN0aW5hdGlvbiBFbnJvbGxtZW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLnRvRGlzcGxheSA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHAtMyBiZy1ncmVlbi01MCBib3JkZXIgYm9yZGVyLWdyZWVuLTIwMCByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj57Zm9ybURhdGEudG9EaXNwbGF5fTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTFcIj5JRDoge2Zvcm1EYXRhLnRvRW5yb2xsSWR9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDbGVhclNlbGVjdGlvbihcInRvXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgaG92ZXI6YmctZ3JlZW4tMjAwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JlZW4tNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlYXJjaCBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTMgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHctNCBoLTQgdGV4dC1ncmF5LTQwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dG9TZWFyY2h9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRUb1NlYXJjaChlLnRhcmdldC52YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWFyY2hFbnJvbGxtZW50cyhlLnRhcmdldC52YWx1ZSwgXCJ0b1wiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uRm9jdXM9eygpID0+IHRvUmVzdWx0cy5sZW5ndGggPiAwICYmIHNldFNob3dUb0Ryb3Bkb3duKHRydWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGJ5IGN1c3RvbWVyIG5hbWUsIGdyb3VwIG5hbWUsIG9yIHRpY2tldC4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTEwIHByLTQgcHktMyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZ3JlZW4tNTAwIGZvY3VzOmJvcmRlci1ncmVlbi01MDAgdHJhbnNpdGlvbi1hbGwgb3V0bGluZS1ub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2hvd1RvRHJvcGRvd24gJiYgdG9SZXN1bHRzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHotMTAgdy1mdWxsIG10LTEgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIHNoYWRvdy1sZyBtYXgtaC04MCBvdmVyZmxvdy15LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dG9SZXN1bHRzLm1hcCgoZW5yb2xsKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17ZW5yb2xsLl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNlbGVjdEVucm9sbG1lbnQoZW5yb2xsLCBcInRvXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1sZWZ0IHAtMyBob3ZlcjpiZy1ncmF5LTUwIGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBsYXN0OmJvcmRlci0wIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFVzZXIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNDAwIG10LTAuNSBmbGV4LXNocmluay0wXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlbnJvbGwudXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiVW5rbm93biBDdXN0b21lclwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMiBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UGFja2FnZSBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZW5yb2xsLmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IFwiTm8gR3JvdXBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRhZyBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUaWNrZXQ6IHtlbnJvbGwudGlja2V0cyB8fCBlbnJvbGwudGlja2V0IHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSUQ6IHtlbnJvbGwuX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93VG9Ecm9wZG93biAmJiB0b1NlYXJjaCAmJiB0b1Jlc3VsdHMubGVuZ3RoID09PSAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB6LTEwIHctZnVsbCBtdC0xIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBzaGFkb3ctbGcgcC00IHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+Tm8gZW5yb2xsbWVudHMgZm91bmQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQWxsIHBheW1lbnRzIHdpbGwgYmUgbW92ZWQgVE8gdGhpcyBlbnJvbGxtZW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBBY3Rpb24gQnV0dG9ucyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMyBwdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5mcm9tRW5yb2xsSWQgJiYgZm9ybURhdGEudG9FbnJvbGxJZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtmZXRjaFBheW1lbnRQcmV2aWV3fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmcgfHwgaXNMb2FkaW5nUHJldmlld31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1wdXJwbGUtNjAwIHRvLXB1cnBsZS03MDAgaG92ZXI6ZnJvbS1wdXJwbGUtNzAwIGhvdmVyOnRvLXB1cnBsZS04MDAgdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHB5LTMgcHgtNiByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBzaGFkb3ctc20gaG92ZXI6c2hhZG93LW1kIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNMb2FkaW5nUHJldmlldyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9XCJ3LTUgaC01IGFuaW1hdGUtc3BpblwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTG9hZGluZyBQcmV2aWV3Li4uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RXllIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByZXZpZXcgVHJhbnNmZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nIHx8ICFmb3JtRGF0YS5mcm9tRW5yb2xsSWQgfHwgIWZvcm1EYXRhLnRvRW5yb2xsSWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB0by1ibHVlLTcwMCBob3Zlcjpmcm9tLWJsdWUtNzAwIGhvdmVyOnRvLWJsdWUtODAwIHRleHQtd2hpdGUgZm9udC1zZW1pYm9sZCBweS0zIHB4LTYgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1tZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7bG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMb2FkZXIyIGNsYXNzTmFtZT1cInctNSBoLTUgYW5pbWF0ZS1zcGluXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUHJvY2Vzc2luZyBUcmFuc2Zlci4uLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSZWZyZXNoQ3cgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRyYW5zZmVyIFBheW1lbnRzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVSZXNldH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC02IHB5LTMgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktNzAwIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1sZyBob3ZlcjpiZy1ncmF5LTUwIHRyYW5zaXRpb24tY29sb3JzIGRpc2FibGVkOm9wYWNpdHktNTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUmVzZXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIEluZm8gQ2FyZHMgLSBSaWdodCBTaWRlICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgICAgICAgICAgICAgey8qIFdhcm5pbmcgQ2FyZCAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1hbWJlci01MCByb3VuZGVkLTJ4bCBwLTYgYm9yZGVyIGJvcmRlci1hbWJlci0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxBbGVydENpcmNsZSBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtYW1iZXItNjAwIGZsZXgtc2hyaW5rLTAgbXQtMC41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtYW1iZXItOTAwIG1iLTFcIj5JbXBvcnRhbnQgTm90aWNlPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWFtYmVyLTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFRoaXMgYWN0aW9uIHdpbGwgcGVybWFuZW50bHkgdHJhbnNmZXIgYWxsIHBheW1lbnRzIGZyb20gdGhlIHNvdXJjZSBlbnJvbGxtZW50IHRvIHRoZSBkZXN0aW5hdGlvbiBlbnJvbGxtZW50LiBUaGUgc291cmNlIGVucm9sbG1lbnQgd2lsbCBiZSBtYXJrZWQgYXMgdHJhbnNmZXJyZWQuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBXaGF0IEdldHMgVHJhbnNmZXJyZWQgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgcC02IGJvcmRlciBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIG1iLTQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxGaWxlVGV4dCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYmx1ZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgV2hhdCBnZXRzIHRyYW5zZmVycmVkP1xyXG4gICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTIgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JlZW4tNTAwIGZsZXgtc2hyaW5rLTAgbXQtMC41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+QWxsIHBheW1lbnQgcmVjb3Jkczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMiB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmVlbi01MDAgZmxleC1zaHJpbmstMCBtdC0wLjVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Hcm91cCBhbmQgdXNlciBhc3NvY2lhdGlvbnM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTIgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JlZW4tNTAwIGZsZXgtc2hyaW5rLTAgbXQtMC41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+VGlja2V0IGluZm9ybWF0aW9uPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2FsZW5kYXIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWJsdWUtNTAwIGZsZXgtc2hyaW5rLTAgbXQtMC41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+Q3JlYXRpb24gdGltZXN0YW1wIGZyb20gc291cmNlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBRdWljayBUaXBzICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tYmx1ZS01MCB0by1pbmRpZ28tNTAgcm91bmRlZC0yeGwgcC02IGJvcmRlciBib3JkZXItYmx1ZS0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWJsdWUtNjAwIGZsZXgtc2hyaW5rLTAgbXQtMC41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgbWItMVwiPlF1aWNrIFRpcHM8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBTZWFyY2ggYnkgY3VzdG9tZXIgbmFtZSwgZ3JvdXAgbmFtZSwgb3IgdGlja2V0IG51bWJlciB0byBmaW5kIGVucm9sbG1lbnRzIHF1aWNrbHkuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgey8qIFByZXZpZXcgTW9kYWwgKi99XHJcbiAgICAgICAgICAgIHtzaG93UHJldmlldyAmJiBwcmV2aWV3RGF0YSAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGJnLWJsYWNrIGJnLW9wYWNpdHktNTBcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBtYXgtdy01eGwgdy1mdWxsIG1heC1oLVs5MHZoXSBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgICAgICAgey8qIE1vZGFsIEhlYWRlciAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1wdXJwbGUtNTAgdG8td2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1wdXJwbGUtMTAwIHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8RXllIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC1wdXJwbGUtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5UcmFuc2ZlciBQcmV2aWV3PC9oMj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5SZXZpZXcgYmFsYW5jZSBjaGFuZ2VzIGJlZm9yZSBwcm9jZWVkaW5nPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UHJldmlldyhmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiBob3ZlcjpiZy1ncmF5LTEwMCByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWdyYXktNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBNb2RhbCBDb250ZW50ICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBvdmVyZmxvdy15LWF1dG9cIiBzdHlsZT17eyBtYXhIZWlnaHQ6IFwiY2FsYyg5MHZoIC0gMTgwcHgpXCIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIFRyYW5zZmVyIEFtb3VudCBIaWdobGlnaHQgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS02MDAgdG8tcHVycGxlLTYwMCByb3VuZGVkLXhsIHAtNiBtYi02IHRleHQtd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBvcGFjaXR5LTkwIG1iLTFcIj5UcmFuc2ZlciBBbW91bnQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkXCI+e2Zvcm1hdEN1cnJlbmN5KHByZXZpZXdEYXRhLnRyYW5zZmVyQW1vdW50KX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIG9wYWNpdHktOTAgbWItMVwiPkZyb20gVGlja2V0PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tb25vIGZvbnQtYm9sZFwiPiN7cHJldmlld0RhdGEuc291cmNlVGlja2V0fTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxBcnJvd1JpZ2h0IGNsYXNzTmFtZT1cInctOCBoLTggb3BhY2l0eS03NVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gb3BhY2l0eS05MCBtYi0xXCI+VG8gVGlja2V0PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tb25vIGZvbnQtYm9sZFwiPiN7cHJldmlld0RhdGEuZGVzdFRpY2tldH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBCYWxhbmNlIENvbXBhcmlzb24gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBTb3VyY2UgVGlja2V0IC0gQmVmb3JlIFRyYW5zZmVyICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1yZWQtNTAgcm91bmRlZC14bCBwLTUgYm9yZGVyLTIgYm9yZGVyLXJlZC0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXJlZC05MDBcIj5Tb3VyY2UgVGlja2V0PC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1yZWQtNzAwXCI+VGlja2V0ICN7cHJldmlld0RhdGEuc291cmNlVGlja2V0fTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHB4LTIgcHktMSBiZy1yZWQtMjAwIHRleHQtcmVkLTgwMCByb3VuZGVkLWZ1bGxcIj5CZWZvcmUgVHJhbnNmZXI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwYi0yIGJvcmRlci1iIGJvcmRlci1yZWQtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtcmVkLTcwMFwiPkN1c3RvbWVyOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1yZWQtOTAwXCI+e3ByZXZpZXdEYXRhLnNvdXJjZUN1c3RvbWVyfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwYi0yIGJvcmRlci1iIGJvcmRlci1yZWQtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtcmVkLTcwMFwiPkdyb3VwOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1yZWQtOTAwXCI+e3ByZXZpZXdEYXRhLnNvdXJjZUdyb3VwfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1yZWQtODAwXCI+Q3VycmVudCBCYWxhbmNlOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtcmVkLTkwMFwiPntmb3JtYXRDdXJyZW5jeShwcmV2aWV3RGF0YS5zb3VyY2VDdXJyZW50QmFsYW5jZSl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBTb3VyY2UgVGlja2V0IC0gQWZ0ZXIgVHJhbnNmZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcm91bmRlZC14bCBwLTUgYm9yZGVyLTIgYm9yZGVyLWdyYXktMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlNvdXJjZSBUaWNrZXQ8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNjAwXCI+VGlja2V0ICN7cHJldmlld0RhdGEuc291cmNlVGlja2V0fTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHB4LTIgcHktMSBiZy1ncmF5LTMwMCB0ZXh0LWdyYXktNzAwIHJvdW5kZWQtZnVsbFwiPkFmdGVyIFRyYW5zZmVyPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcGItMiBib3JkZXItYiBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPkN1c3RvbWVyOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMFwiPntwcmV2aWV3RGF0YS5zb3VyY2VDdXN0b21lcn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcGItMiBib3JkZXItYiBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPkdyb3VwOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMFwiPntwcmV2aWV3RGF0YS5zb3VyY2VHcm91cH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcHQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5OZXcgQmFsYW5jZTo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktNTAwXCI+e2Zvcm1hdEN1cnJlbmN5KDApfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIERlc3RpbmF0aW9uIFRpY2tldCBCYWxhbmNlIENvbXBhcmlzb24gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBEZXN0aW5hdGlvbiBUaWNrZXQgLSBCZWZvcmUgVHJhbnNmZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXllbGxvdy01MCByb3VuZGVkLXhsIHAtNSBib3JkZXItMiBib3JkZXIteWVsbG93LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQteWVsbG93LTkwMFwiPkRlc3RpbmF0aW9uIFRpY2tldDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQteWVsbG93LTcwMFwiPlRpY2tldCAje3ByZXZpZXdEYXRhLmRlc3RUaWNrZXR9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgcHgtMiBweS0xIGJnLXllbGxvdy0yMDAgdGV4dC15ZWxsb3ctODAwIHJvdW5kZWQtZnVsbFwiPkJlZm9yZSBUcmFuc2Zlcjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHBiLTIgYm9yZGVyLWIgYm9yZGVyLXllbGxvdy0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC15ZWxsb3ctNzAwXCI+Q3VzdG9tZXI6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXllbGxvdy05MDBcIj57cHJldmlld0RhdGEuZGVzdEN1c3RvbWVyfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwYi0yIGJvcmRlci1iIGJvcmRlci15ZWxsb3ctMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQteWVsbG93LTcwMFwiPkdyb3VwOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC15ZWxsb3ctOTAwXCI+e3ByZXZpZXdEYXRhLmRlc3RHcm91cH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcHQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQteWVsbG93LTgwMFwiPkN1cnJlbnQgQmFsYW5jZTo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXllbGxvdy05MDBcIj57Zm9ybWF0Q3VycmVuY3kocHJldmlld0RhdGEuZGVzdEN1cnJlbnRCYWxhbmNlKX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIERlc3RpbmF0aW9uIFRpY2tldCAtIEFmdGVyIFRyYW5zZmVyICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmVlbi01MCByb3VuZGVkLXhsIHAtNSBib3JkZXItMiBib3JkZXItZ3JlZW4tMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmVlbi05MDBcIj5EZXN0aW5hdGlvbiBUaWNrZXQ8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyZWVuLTcwMFwiPlRpY2tldCAje3ByZXZpZXdEYXRhLmRlc3RUaWNrZXR9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgcHgtMiBweS0xIGJnLWdyZWVuLTIwMCB0ZXh0LWdyZWVuLTgwMCByb3VuZGVkLWZ1bGxcIj5BZnRlciBUcmFuc2Zlcjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHBiLTIgYm9yZGVyLWIgYm9yZGVyLWdyZWVuLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyZWVuLTcwMFwiPkN1c3RvbWVyOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmVlbi05MDBcIj57cHJldmlld0RhdGEuZGVzdEN1c3RvbWVyfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwYi0yIGJvcmRlci1iIGJvcmRlci1ncmVlbi0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmVlbi03MDBcIj5Hcm91cDo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JlZW4tOTAwXCI+e3ByZXZpZXdEYXRhLmRlc3RHcm91cH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcHQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JlZW4tODAwXCI+TmV3IEJhbGFuY2U6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmVlbi05MDBcIj4rIHtmb3JtYXRDdXJyZW5jeShwcmV2aWV3RGF0YS5hZnRlckRlc3RCYWxhbmNlKX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBCYWxhbmNlIENoYW5nZSBTdW1tYXJ5ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ibHVlLTUwIHRvLWluZGlnby01MCByb3VuZGVkLXhsIHAtNSBib3JkZXIgYm9yZGVyLWJsdWUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIG1iLTMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRyZW5kaW5nVXAgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWJsdWUtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQmFsYW5jZSBDaGFuZ2UgU3VtbWFyeVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHAtMiBiZy13aGl0ZSByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+U291cmNlIFRpY2tldCAje3ByZXZpZXdEYXRhLnNvdXJjZVRpY2tldH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEN1cnJlbmN5KHByZXZpZXdEYXRhLnNvdXJjZUN1cnJlbnRCYWxhbmNlKX0g4oaSIHtmb3JtYXRDdXJyZW5jeSgwKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwLTIgYmctd2hpdGUgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTcwMFwiPkRlc3RpbmF0aW9uIFRpY2tldCAje3ByZXZpZXdEYXRhLmRlc3RUaWNrZXR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyZWVuLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEN1cnJlbmN5KHByZXZpZXdEYXRhLmRlc3RDdXJyZW50QmFsYW5jZSl9IOKGkiB7Zm9ybWF0Q3VycmVuY3kocHJldmlld0RhdGEuYWZ0ZXJEZXN0QmFsYW5jZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcC0yIGJnLWJsdWUtMTAwIHJvdW5kZWQtbGcgbXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWJsdWUtODAwXCI+VG90YWwgQW1vdW50IFRyYW5zZmVycmVkPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtYmx1ZS05MDBcIj57Zm9ybWF0Q3VycmVuY3kocHJldmlld0RhdGEudHJhbnNmZXJBbW91bnQpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogTW9kYWwgRm9vdGVyICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBib3JkZXItdCBib3JkZXItZ3JheS0yMDAgYmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UHJldmlldyhmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS03MDAgcm91bmRlZC1sZyBob3ZlcjpiZy1ncmF5LTEwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93UHJldmlldyhmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlU3VibWl0KG5ldyBFdmVudChcInN1Ym1pdFwiKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTYgcHktMiBiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS02MDAgdG8tcHVycGxlLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgaG92ZXI6ZnJvbS1ibHVlLTcwMCBob3Zlcjp0by1wdXJwbGUtNzAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBzaGFkb3ctbWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8UmVmcmVzaEN3IGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDb25maXJtICYgVHJhbnNmZXIge2Zvcm1hdEN1cnJlbmN5KHByZXZpZXdEYXRhLnRyYW5zZmVyQW1vdW50KX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgey8qIFJlc3VsdHMgU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgeyhzdWNjZXNzIHx8IGVycm9yIHx8IHRyYW5zZmVyUmVzdWx0KSAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IGFuaW1hdGUtZmFkZUluXCI+XHJcbiAgICAgICAgICAgICAgICB7c3VjY2VzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JlZW4tNTAgYm9yZGVyIGJvcmRlci1ncmVlbi0yMDAgcm91bmRlZC0yeGwgcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LWdyZWVuLTYwMCBmbGV4LXNocmluay0wXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JlZW4tOTAwIG1iLTJcIj5UcmFuc2ZlciBTdWNjZXNzZnVsITwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tODAwIG1iLTRcIj57c3VjY2Vzc308L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dHJhbnNmZXJSZXN1bHQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNCBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgcC00IGJvcmRlciBib3JkZXItZ3JlZW4tMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBtYi0xXCI+TWF0Y2hlZCBQYXltZW50czwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj57dHJhbnNmZXJSZXN1bHQubWF0Y2hlZFBheW1lbnRzIHx8IDB9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgcC00IGJvcmRlciBib3JkZXItZ3JlZW4tMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBtYi0xXCI+TW9kaWZpZWQgUGF5bWVudHM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+e3RyYW5zZmVyUmVzdWx0Lm1vZGlmaWVkUGF5bWVudHMgfHwgMH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBwLTQgYm9yZGVyIGJvcmRlci1ncmVlbi0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG1iLTFcIj5UaWNrZXQgVHJhbnNmZXI8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0cmFuc2ZlclJlc3VsdC5mcm9tVGlja2V0fSDihpIge3RyYW5zZmVyUmVzdWx0LnRvVGlja2V0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAge2Vycm9yICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1yZWQtNTAgYm9yZGVyIGJvcmRlci1yZWQtMjAwIHJvdW5kZWQtMnhsIHAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFhDaXJjbGUgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LXJlZC02MDAgZmxleC1zaHJpbmstMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXJlZC05MDAgbWItMVwiPlRyYW5zZmVyIEZhaWxlZDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTgwMFwiPntlcnJvcn08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFRyYW5zZmVyTWVudTsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvVHJhbnNmZXJNZW51LmpzeCJ9