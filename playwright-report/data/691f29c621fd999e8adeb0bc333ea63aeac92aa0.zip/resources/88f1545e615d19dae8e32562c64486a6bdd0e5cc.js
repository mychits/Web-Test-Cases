import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/RegistrationFeeReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import { MdDelete } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { CiEdit } from "/node_modules/.vite/deps/react-icons_ci.js?v=819e0a34";
import Modal from "/src/components/modals/Modal.jsx";
import { BsEye } from "/node_modules/.vite/deps/react-icons_bs.js?v=819e0a34";
import UploadModal from "/src/components/modals/UploadModal.jsx";
import axios from "/node_modules/.vite/deps/axios.js?v=819e0a34";
import url from "/src/data/Url.js";
import { Select, Dropdown } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import EndlessCircularLoader from "/src/components/loaders/EndlessCircularLoader.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { fieldSize } from "/src/data/fieldSize.js";
const RegistrationFeeReport = () => {
  _s();
  const [groups, setGroups] = useState([]);
  const [TableDaybook, setTableDaybook] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState("");
  const [selectedAuctionGroup, setSelectedAuctionGroup] = useState("");
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [selectedAuctionGroupId, setSelectedAuctionGroupId] = useState("");
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [filteredAuction, setFilteredAuction] = useState([]);
  const [groupInfo, setGroupInfo] = useState({});
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [currentGroup, setCurrentGroup] = useState(null);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentUpdateGroup, setCurrentUpdateGroup] = useState(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [receiptNo, setReceiptNo] = useState("");
  const [paymentMode, setPaymentMode] = useState("cash");
  const [searchText, setSearchText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showFilterField, setShowFilterField] = useState(false);
  const [selectedLabel, setSelectedLabel] = useState("Today");
  const now = /* @__PURE__ */ new Date();
  const onGlobalSearchChangeHandler = (e) => {
    setSearchText(e.target.value);
  };
  const todayString = now.toISOString().split("T")[0];
  const [selectedFromDate, setSelectedFromDate] = useState(todayString);
  const [selectedDate, setSelectedDate] = useState(todayString);
  const [selectedPaymentMode, setSelectedPaymentMode] = useState("");
  const [hideAccountType, setHideAccountType] = useState("");
  const [selectedAccountType, setSelectedAccountType] = useState("");
  const [selectedCustomers, setSelectedCustomers] = useState("");
  const [payments, setPayments] = useState("");
  const [showAllPaymentModes, setShowAllPaymentModes] = useState(false);
  const [formData, setFormData] = useState({
    group_id: "",
    user_id: "",
    ticket: "",
    receipt_no: "",
    pay_date: "",
    amount: "",
    pay_type: "cash",
    transaction_id: ""
  });
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const handleModalClose = () => setShowUploadModal(false);
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    if (userObj && userObj.admin_access_right_id?.access_permissions?.edit_payment) {
      const showPaymentsModes = userObj.admin_access_right_id?.access_permissions?.edit_payment === "true" ? true : false;
      setShowAllPaymentModes(showPaymentsModes);
    }
  }, []);
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    if (userObj && userObj.admin_access_right_id?.access_permissions?.edit_payment) {
      const isModify = userObj.admin_access_right_id?.access_permissions?.edit_payment === "true" ? true : false;
      setHideAccountType(isModify);
    }
  }, []);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/user/get-user");
        setFilteredUsers(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  useEffect(() => {
    if (receiptNo) {
      setFormData((prevData) => ({
        ...prevData,
        receipt_no: receiptNo.receipt_no
      }));
    }
  }, [receiptNo]);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  const handleChangeUser = (e) => {
    const { name, value } = e.target;
    const [user_id, ticket] = value.split("-");
    setFormData((prevData) => ({
      ...prevData,
      user_id,
      ticket
    }));
  };
  const handleGroup = async (event) => {
    const groupId = event.target.value;
    setSelectedGroupId(groupId);
    setFormData((prevFormData) => ({
      ...prevFormData,
      group_id: groupId
    }));
    handleGroupChange(groupId);
    if (groupId) {
      try {
        const response = await api.get(`/group/get-by-id-group/${groupId}`);
        setGroupInfo(response.data || {});
      } catch (error) {
        console.error("Error fetching group data:", error);
        setGroupInfo({});
      }
    } else {
      setGroupInfo({});
    }
  };
  const groupOptions = [
    { value: "Today", label: "Today" },
    { value: "Yesterday", label: "Yesterday" },
    { value: "ThisMonth", label: "This Month" },
    { value: "LastMonth", label: "Last Month" },
    { value: "ThisYear", label: "This Year" },
    { value: "Custom", label: "Custom" }
  ];
  const handleGroupPayment = async (groupId) => {
    setSelectedAuctionGroupId(groupId);
  };
  const handleSelectFilter = (value) => {
    setSelectedLabel(value);
    setShowFilterField(false);
    const today = /* @__PURE__ */ new Date();
    const formatDate = (date) => date.toLocaleDateString("en-CA");
    if (value === "Today") {
      const formatted = formatDate(today);
      setSelectedFromDate(formatted);
      setSelectedDate(formatted);
    } else if (value === "Yesterday") {
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      const formatted = formatDate(yesterday);
      setSelectedFromDate(formatted);
      setSelectedDate(formatted);
    } else if (value === "ThisMonth") {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      setSelectedFromDate(formatDate(start));
      setSelectedDate(formatDate(end));
    } else if (value === "LastMonth") {
      const start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      const end = new Date(today.getFullYear(), today.getMonth(), 0);
      setSelectedFromDate(formatDate(start));
      setSelectedDate(formatDate(end));
    } else if (value === "ThisYear") {
      const start = new Date(today.getFullYear(), 0, 1);
      const end = new Date(today.getFullYear(), 11, 31);
      setSelectedFromDate(formatDate(start));
      setSelectedDate(formatDate(end));
    } else if (value === "Custom") {
      setShowFilterField(true);
    }
  };
  const formatPayDate = (dateString) => {
    const date = new Date(dateString);
    const options = { day: "numeric", month: "long", year: "numeric" };
    return date.toLocaleDateString("en-US", options).replace(",", "");
  };
  useEffect(
    () => {
      const abortController = new AbortController();
      const fetchPayments = async () => {
        try {
          setIsLoading(true);
          const response = await api.get(`/registration-fee/dates`, {
            params: {
              from_date: selectedFromDate,
              to_date: selectedDate,
              groupId: selectedAuctionGroupId,
              userId: selectedCustomers,
              pay_type: selectedPaymentMode,
              account_type: selectedAccountType
            },
            signal: abortController.signal
          });
          console.info(response.data, "testing account type");
          if (response.data && response.data.length > 0) {
            const validPayments = response.data.filter(
              (payment) => payment.group_id !== null
            );
            setFilteredAuction(validPayments);
            const totalAmount = validPayments.reduce(
              (sum, payment) => sum + Number(payment.amount || 0),
              0
            );
            console.info(totalAmount, "check amount");
            setPayments(totalAmount);
            const formattedData = validPayments.map((group, index) => ({
              _id: group?._id,
              id: index + 1,
              date: group?.pay_date,
              group: group?.group_id?.group_name || group.pay_for,
              name: group?.user_id?.full_name,
              category: group?.pay_for || "Chit",
              phone_number: group?.user_id?.phone_number,
              receipt_no: group?.receipt_no,
              old_receipt_no: group?.old_receipt_no,
              ticket: group?.ticket,
              amount: group?.amount,
              transaction_date: group?.createdAt?.split("T")?.[0],
              mode: group?.pay_type,
              account_type: group?.account_type,
              collected_by: group?.collected_by?.name || group?.admin_type?.admin_name || "Super Admin",
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  trigger: ["click"],
                  menu: {
                    items: [
                      {
                        key: "1",
                        label: /* @__PURE__ */ jsxDEV(
                          Link,
                          {
                            target: "_blank",
                            to: `/print/${group._id}`,
                            className: "text-violet-600 ",
                            children: "Print"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                            lineNumber: 300,
                            columnNumber: 21
                          },
                          this
                        )
                      }
                    ]
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 313,
                    columnNumber: 19
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                  lineNumber: 293,
                  columnNumber: 17
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 292,
                columnNumber: 13
              }, this)
            }));
            setTableDaybook(formattedData);
          } else {
            setFilteredAuction([]);
          }
        } catch (error) {
          console.error("Error fetching payment data:", error);
          setFilteredAuction([]);
          setPayments(0);
        } finally {
          setIsLoading(false);
        }
      };
      fetchPayments();
      return () => {
        abortController.abort();
      };
    },
    [
      selectedAuctionGroupId,
      selectedDate,
      selectedPaymentMode,
      selectedCustomers,
      selectedFromDate,
      selectedAccountType
    ]
  );
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Paid Date" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "group", header: "Group Name" },
    { key: "name", header: "Customer Name" },
    { key: "category", header: "Category" },
    { key: "phone_number", header: "Customer Phone Number" },
    { key: "receipt_no", header: "Receipt Number" },
    { key: "old_receipt_no", header: "Old Receipt" },
    { key: "ticket", header: "Ticket" },
    { key: "amount", header: "Amount" },
    { key: "mode", header: "Payment Mode" },
    ...hideAccountType ? [{ key: "account_type", header: "Account Type" }] : [],
    { key: "collected_by", header: "Collected By" },
    { key: "action", header: "Action" }
  ];
  useEffect(() => {
    if (groupInfo && formData.bid_amount) {
      const commission = groupInfo.group_value * 5 / 100 || 0;
      const win_amount = (groupInfo.group_value || 0) - (formData.bid_amount || 0);
      const divident = (formData.bid_amount || 0) - commission;
      const divident_head = groupInfo.group_members ? divident / groupInfo.group_members : 0;
      const payable = (groupInfo.group_install || 0) - divident_head;
      setFormData((prevData) => ({
        ...prevData,
        group_id: groupInfo._id,
        commission,
        win_amount,
        divident,
        divident_head,
        payable
      }));
    }
  }, [groupInfo, formData.bid_amount]);
  const handlePaymentModeChange = (e) => {
    const selectedMode = e.target.value;
    setPaymentMode(selectedMode);
    setFormData((prevData) => ({
      ...prevData,
      pay_type: selectedMode,
      transaction_id: selectedMode === "online" ? prevData.transaction_id : ""
    }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await api.post("/payment/add-payment", formData);
      if (response.status === 201) {
        alert("Payment Added Successfully");
        setShowModal(false);
      }
    } catch (error) {
      console.error("Error submitting payment data:", error);
    }
  };
  const handleDeleteModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/payment/get-payment-by-id/${groupId}`);
      setCurrentGroup(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching enroll:", error);
    }
  };
  const handleDeleteAuction = async () => {
    if (currentGroup) {
      try {
        await api.delete(`/payment/delete-payment/${currentGroup._id}`);
        alert("Payment deleted successfully");
        setShowModalDelete(false);
        setCurrentGroup(null);
        window.location.reload();
      } catch (error) {
        console.error("Error deleting auction:", error);
      }
    }
  };
  const handleUpdateModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/auction/get-auction-by-id/${groupId}`);
      setCurrentUpdateGroup(response.data);
      setShowModalUpdate(true);
    } catch (error) {
      console.error("Error fetching auction:", error);
    }
  };
  const handleFileSubmit = async (e) => {
    e.preventDefault();
    const formDatas = new FormData();
    const fileInput = e.target.file;
    if (fileInput && fileInput.files[0]) {
      formDatas.append("file", fileInput.files[0]);
      try {
        const response = await api.post(`/payment/payment-excel`, formDatas, {
          headers: { "Content-Type": "multipart/form-data" }
        });
        if (response.status === 200) {
          alert("File uploaded successfully!");
          window.location.reload();
          setShowUploadModal(false);
        }
      } catch (error) {
        console.error("Error uploading file:", error);
        alert("Failed to upload file.");
      }
    } else {
      alert("Please select a file to upload.");
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 mt-30", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
        lineNumber: 475,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlert,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
        lineNumber: 479,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold", children: "Registration Receipt Report" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
        lineNumber: 485,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-start items-center w-full gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Filter Option" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 490,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                popupMatchSelectWidth: false,
                onChange: handleSelectFilter,
                value: selectedLabel,
                placeholder: "Search Or Select Filter",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-full max-w-xs h-11",
                children: groupOptions.map(
                  (time) => /* @__PURE__ */ jsxDEV(Select.Option, { value: time.value, children: time.label }, time.value, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 507,
                    columnNumber: 23
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 492,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
            lineNumber: 489,
            columnNumber: 19
          }, this),
          showFilterField && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "From Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 516,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: selectedFromDate,
                  onChange: (e) => setSelectedFromDate(e.target.value),
                  className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full max-w-xs"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                  lineNumber: 517,
                  columnNumber: 25
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 515,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "To Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 525,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: selectedDate,
                  onChange: (e) => setSelectedDate(e.target.value),
                  className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full max-w-xs"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                  lineNumber: 526,
                  columnNumber: 25
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 524,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
            lineNumber: 514,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Group" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 536,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                popupMatchSelectWidth: false,
                value: selectedAuctionGroupId,
                onChange: handleGroupPayment,
                placeholder: "Search Or Select Group",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-full max-w-xs h-11",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 563,
                    columnNumber: 23
                  }, this),
                  groups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                      lineNumber: 565,
                      columnNumber: 23
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 549,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
            lineNumber: 535,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Customer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 572,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                popupMatchSelectWidth: false,
                value: selectedCustomers,
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                placeholder: "Search Or Select Customer",
                onChange: (groupId) => setSelectedCustomers(groupId),
                className: "w-full max-w-xs h-11",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 600,
                    columnNumber: 23
                  }, this),
                  filteredUsers.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group?._id, children: [
                      group?.full_name,
                      " - ",
                      group.phone_number
                    ] }, group?._id, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                      lineNumber: 602,
                      columnNumber: 23
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 585,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
            lineNumber: 571,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Payment Mode" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 609,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: selectedPaymentMode,
                showSearch: true,
                placeholder: "Search Or Select Payment",
                popupMatchSelectWidth: false,
                onChange: (groupId) => setSelectedPaymentMode(groupId),
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-full max-w-xs h-11",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 634,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "cash", children: "Cash" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 635,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "Payment Link", children: "Online | Payment Link" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 636,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "online", children: "Online" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 637,
                    columnNumber: 23
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 619,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
            lineNumber: 608,
            columnNumber: 19
          }, this),
          showAllPaymentModes && /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Account Type" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 643,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: selectedAccountType,
                showSearch: true,
                placeholder: "Search Or Select Account Type",
                popupMatchSelectWidth: false,
                onChange: (groupId) => setSelectedAccountType(groupId),
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-full max-w-xs h-11",
                children: /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Account Type" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 669,
                    columnNumber: 26
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "suspense", children: "Suspense" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 670,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "credit", children: "Credit" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 671,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "adjustment", children: "Adjustment" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 672,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "others", children: "Others" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 673,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                  lineNumber: 668,
                  columnNumber: 25
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 653,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
            lineNumber: 642,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("h1", { className: "text-md mt-6", children: [
            "Total Amount:",
            " ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-xl", children: [
              "₹",
              payments || 0
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 682,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
            lineNumber: 680,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
            lineNumber: 679,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
          lineNumber: 488,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
          lineNumber: 487,
          columnNumber: 15
        }, this),
        filteredAuction && filteredAuction.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: [
          /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: filterOption(TableDaybook, searchText),
              columns,
              exportedPdfName: `Registration Receipt Report`,
              exportedFileName: `Registration Receipt.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 689,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mt-4 pr-4", children: /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: [
            "Total Amount: ₹",
            payments
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
            lineNumber: 697,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
            lineNumber: 696,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
          lineNumber: 688,
          columnNumber: 15
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10 text-center text-gray-500", children: /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: filteredAuction.length <= 0,
            data: "Receipt Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
            lineNumber: 704,
            columnNumber: 19
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
          lineNumber: 703,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
        lineNumber: 486,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
      lineNumber: 484,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Payment" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
        lineNumber: 715,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "category",
              children: "Group"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 720,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              value: selectedGroupId,
              onChange: handleGroup,
              className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5",
              children: [
                /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Group" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                  lineNumber: 731,
                  columnNumber: 21
                }, this),
                groups.map(
                  (group) => /* @__PURE__ */ jsxDEV("option", { value: group._id, children: group.group_name }, group._id, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 733,
                    columnNumber: 21
                  }, this)
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 726,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
          lineNumber: 719,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "category",
              children: "Customers"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 740,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "select",
            {
              name: "user_id",
              value: `${formData.user_id}-${formData.ticket}`,
              onChange: handleChangeUser,
              required: true,
              className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5",
              children: [
                /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Customer" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                  lineNumber: 753,
                  columnNumber: 21
                }, this),
                filteredUsers.map(
                  (user) => /* @__PURE__ */ jsxDEV(
                    "option",
                    {
                      value: `${user?.user_id?._id}-${user.tickets}`,
                      children: [
                        user?.user_id?.full_name,
                        " | ",
                        user.tickets
                      ]
                    },
                    `${user?.user_id?._id}-${user.tickets}`,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                      lineNumber: 755,
                      columnNumber: 21
                    },
                    this
                  )
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 746,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
          lineNumber: 739,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "group_value",
                children: "Receipt No."
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 766,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                name: "receipt_no",
                value: formData.receipt_no,
                id: "receipt_no",
                placeholder: "Receipt No.",
                readOnly: true,
                className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 772,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
            lineNumber: 765,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "group_install",
                children: "Payment Date"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 783,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                name: "pay_date",
                value: formData.pay_date,
                id: "pay_date",
                onChange: handleChange,
                placeholder: "",
                className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 789,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
            lineNumber: 782,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
          lineNumber: 764,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "group_value",
                children: "Amount"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 802,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                name: "amount",
                value: formData.amount,
                id: "amount",
                onChange: handleChange,
                placeholder: "Enter Amount",
                className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 808,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
            lineNumber: 801,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "pay_mode",
                children: "Payment Mode"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 819,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                name: "pay_mode",
                id: "pay_mode",
                className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5",
                onChange: handlePaymentModeChange,
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "cash", children: "Cash" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 831,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "online", children: "Online" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 832,
                    columnNumber: 23
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 825,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
            lineNumber: 818,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
          lineNumber: 800,
          columnNumber: 17
        }, this),
        paymentMode === "online" && /* @__PURE__ */ jsxDEV("div", { className: "w-full mt-4", children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "transaction_id",
              children: "Transaction ID"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 838,
              columnNumber: 21
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              name: "transaction_id",
              id: "transaction_id",
              value: formData.transaction_id,
              onChange: handleChange,
              placeholder: "Enter Transaction ID",
              className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 844,
              columnNumber: 21
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
          lineNumber: 837,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "w-full text-white bg-violet-700 hover:bg-violet-800\r\n                              focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
            children: "Add"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
            lineNumber: 855,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
        lineNumber: 718,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
      lineNumber: 714,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
      lineNumber: 713,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "View Auction" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
            lineNumber: 870,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: () => {
          }, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: "Group"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                  lineNumber: 875,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  name: "group_id",
                  value: currentUpdateGroup?.group_id?.group_name,
                  onChange: () => {
                  },
                  id: "name",
                  placeholder: "Enter the Group Name",
                  readOnly: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                  lineNumber: 881,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 874,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "group_value",
                    children: "Group Value"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 894,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "group_value",
                    value: currentUpdateGroup?.group_id?.group_value,
                    id: "group_value",
                    placeholder: "select group to check",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 900,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 893,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "group_install",
                    children: "Group Installment"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 911,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "group_install",
                    value: currentUpdateGroup?.group_id?.group_install,
                    id: "group_install",
                    placeholder: "select group to check",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 917,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 910,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 892,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: "User"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                  lineNumber: 929,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  name: "group_id",
                  value: `${currentUpdateGroup?.user_id?.full_name} | ${currentUpdateGroup?.ticket}`,
                  onChange: () => {
                  },
                  id: "name",
                  placeholder: "Enter the User Name",
                  readOnly: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                  lineNumber: 935,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 928,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: "Bid Amount"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                  lineNumber: 948,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "number",
                  name: "bid_amount",
                  value: currentUpdateGroup?.group_id?.group_value - currentUpdateGroup?.win_amount,
                  onChange: () => {
                  },
                  id: "name",
                  placeholder: "Enter the Bid Amount",
                  readOnly: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                  lineNumber: 954,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 947,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "group_value",
                    children: "Commission"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 970,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "commission",
                    value: currentUpdateGroup?.commission,
                    id: "commission",
                    placeholder: "",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 976,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 969,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "group_install",
                    children: "Winning Amount"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 987,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "win_amount",
                    value: currentUpdateGroup?.win_amount,
                    id: "win_amount",
                    placeholder: "",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 993,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 986,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 968,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "group_value",
                    children: "Divident"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 1006,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "divident",
                    value: currentUpdateGroup?.divident,
                    id: "divident",
                    placeholder: "",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 1012,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 1005,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "group_install",
                    children: "Divident per Head"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 1023,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "divident_head",
                    value: currentUpdateGroup?.divident_head,
                    id: "divident_head",
                    placeholder: "",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 1029,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 1022,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "group_install",
                    children: "Next Payable"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 1040,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "payable",
                    value: currentUpdateGroup?.payable,
                    id: "payable",
                    placeholder: "",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 1046,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 1039,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 1004,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: "Auction Date"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 1059,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    name: "auction_date",
                    value: currentUpdateGroup?.auction_date,
                    onChange: () => {
                    },
                    id: "date",
                    placeholder: "Enter the Date",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 1065,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 1058,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: "Next Date"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 1077,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    name: "next_date",
                    value: currentUpdateGroup?.next_date,
                    onChange: () => {
                    },
                    id: "date",
                    placeholder: "Enter the Date",
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                    lineNumber: 1083,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                lineNumber: 1076,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 1057,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
            lineNumber: 873,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
          lineNumber: 869,
          columnNumber: 13
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
        lineNumber: 865,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentGroup(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Sure want to delete this Payment ?" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
            lineNumber: 1106,
            columnNumber: 15
          }, this),
          currentGroup && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteAuction();
              },
              className: "space-y-6",
              children: /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "submit",
                  className: "w-full text-white bg-red-700 hover:bg-red-800\r\n                    focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                  children: "Delete"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
                  lineNumber: 1117,
                  columnNumber: 19
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
              lineNumber: 1110,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
          lineNumber: 1105,
          columnNumber: 13
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
        lineNumber: 1098,
        columnNumber: 11
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
    lineNumber: 474,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
    lineNumber: 473,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx",
    lineNumber: 472,
    columnNumber: 5
  }, this);
};
_s(RegistrationFeeReport, "xhigApewiqjzvpUSYtl2Dduc9TA=");
_c = RegistrationFeeReport;
export default RegistrationFeeReport;
var _c;
$RefreshReg$(_c, "RegistrationFeeReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/RegistrationFeeReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMlMwQixTQWdYRixVQWhYRTsyQkEzUzFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsU0FBUztBQUNoQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsY0FBYztBQUN2QixPQUFPQyxXQUFXO0FBQ2xCLFNBQVNDLGFBQWE7QUFDdEIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsU0FBUztBQUNoQixTQUFTQyxRQUFRQyxnQkFBZ0I7QUFDakMsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MsMkJBQTJCO0FBQ2xDLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGtCQUFrQjtBQUN6QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxpQkFBaUI7QUFFMUIsTUFBTUMsd0JBQXdCQSxNQUFNO0FBQUFDLEtBQUE7QUFDbEMsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUl4QixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDeUIsY0FBY0MsZUFBZSxJQUFJMUIsU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQzJCLGVBQWVDLGdCQUFnQixJQUFJNUIsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzZCLHNCQUFzQkMsdUJBQXVCLElBQUk5QixTQUFTLEVBQUU7QUFDbkUsUUFBTSxDQUFDK0IsaUJBQWlCQyxrQkFBa0IsSUFBSWhDLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUNpQyx3QkFBd0JDLHlCQUF5QixJQUFJbEMsU0FBUyxFQUFFO0FBQ3ZFLFFBQU0sQ0FBQ21DLGVBQWVDLGdCQUFnQixJQUFJcEMsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ3FDLGlCQUFpQkMsa0JBQWtCLElBQUl0QyxTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDdUMsV0FBV0MsWUFBWSxJQUFJeEMsU0FBUyxDQUFDLENBQUM7QUFDN0MsUUFBTSxDQUFDeUMsV0FBV0MsWUFBWSxJQUFJMUMsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzJDLGlCQUFpQkMsa0JBQWtCLElBQUk1QyxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDNkMsY0FBY0MsZUFBZSxJQUFJOUMsU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQytDLGlCQUFpQkMsa0JBQWtCLElBQUloRCxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDaUQsb0JBQW9CQyxxQkFBcUIsSUFBSWxELFNBQVMsSUFBSTtBQUNqRSxRQUFNLENBQUNtRCxpQkFBaUJDLGtCQUFrQixJQUFJcEQsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ3FELFdBQVdDLFlBQVksSUFBSXRELFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUN1RCxhQUFhQyxjQUFjLElBQUl4RCxTQUFTLE1BQU07QUFDckQsUUFBTSxDQUFDeUQsWUFBWUMsYUFBYSxJQUFJMUQsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQzJELFdBQVdDLFlBQVksSUFBSTVELFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUM2RCxpQkFBaUJDLGtCQUFrQixJQUFJOUQsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQytELGVBQWVDLGdCQUFnQixJQUFJaEUsU0FBUyxPQUFPO0FBRTFELFFBQU1pRSxNQUFNLG9CQUFJQyxLQUFLO0FBQ3JCLFFBQU1DLDhCQUE4QkEsQ0FBQ0MsTUFBTTtBQUN6Q1Ysa0JBQWNVLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxFQUM5QjtBQUNBLFFBQU1DLGNBQWNOLElBQUlPLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNsRCxRQUFNLENBQUNDLGtCQUFrQkMsbUJBQW1CLElBQUkzRSxTQUFTdUUsV0FBVztBQUNwRSxRQUFNLENBQUNLLGNBQWNDLGVBQWUsSUFBSTdFLFNBQVN1RSxXQUFXO0FBQzVELFFBQU0sQ0FBQ08scUJBQXFCQyxzQkFBc0IsSUFBSS9FLFNBQVMsRUFBRTtBQUNqRSxRQUFNLENBQUNnRixpQkFBaUJDLGtCQUFrQixJQUFJakYsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ2tGLHFCQUFxQkMsc0JBQXNCLElBQUluRixTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDb0YsbUJBQW1CQyxvQkFBb0IsSUFBSXJGLFNBQVMsRUFBRTtBQUM3RCxRQUFNLENBQUNzRixVQUFVQyxXQUFXLElBQUl2RixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDd0YscUJBQXFCQyxzQkFBc0IsSUFBSXpGLFNBQVMsS0FBSztBQUNwRSxRQUFNLENBQUMwRixVQUFVQyxXQUFXLElBQUkzRixTQUFTO0FBQUEsSUFDdkM0RixVQUFVO0FBQUEsSUFDVkMsU0FBUztBQUFBLElBQ1RDLFFBQVE7QUFBQSxJQUNSQyxZQUFZO0FBQUEsSUFDWkMsVUFBVTtBQUFBLElBQ1ZDLFFBQVE7QUFBQSxJQUNSQyxVQUFVO0FBQUEsSUFDVkMsZ0JBQWdCO0FBQUEsRUFDbEIsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJckcsU0FBUztBQUFBLElBQzdDc0csWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBQ0QsUUFBTUMsbUJBQW1CQSxNQUFNckQsbUJBQW1CLEtBQUs7QUFDdkRyRCxZQUFVLE1BQU07QUFDZCxVQUFNMkcsT0FBT0MsYUFBYUMsUUFBUSxNQUFNO0FBQ3hDLFVBQU1DLFVBQVVDLEtBQUtDLE1BQU1MLElBQUk7QUFFL0IsUUFDRUcsV0FDQUEsUUFBUUcsdUJBQXVCQyxvQkFBb0JDLGNBQ25EO0FBQ0EsWUFBTUMsb0JBQ0pOLFFBQVFHLHVCQUF1QkMsb0JBQW9CQyxpQkFDbkQsU0FDSSxPQUNBO0FBQ056Qiw2QkFBdUIwQixpQkFBaUI7QUFBQSxJQUMxQztBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBQ0xwSCxZQUFVLE1BQU07QUFDWixVQUFNMkcsT0FBT0MsYUFBYUMsUUFBUSxNQUFNO0FBQ3hDLFVBQU1DLFVBQVVDLEtBQUtDLE1BQU1MLElBQUk7QUFFL0IsUUFDRUcsV0FDQUEsUUFBUUcsdUJBQXVCQyxvQkFBb0JDLGNBQ25EO0FBQ0EsWUFBTUUsV0FDSlAsUUFBUUcsdUJBQXVCQyxvQkFBb0JDLGlCQUNuRCxTQUNJLE9BQ0E7QUFDTmpDLHlCQUFtQm1DLFFBQVE7QUFBQSxJQUM3QjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBQ1BySCxZQUFVLE1BQU07QUFDZCxVQUFNc0gsY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRixjQUFNQyxXQUFXLE1BQU1wSCxJQUFJcUgsSUFBSSx3QkFBd0I7QUFDdkQvRixrQkFBVThGLFNBQVNFLElBQUk7QUFBQSxNQUN6QixTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDhCQUE4QkEsS0FBSztBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUNBSixnQkFBWTtBQUFBLEVBQ2QsR0FBRyxFQUFFO0FBSUx0SCxZQUFVLE1BQU07QUFDZCxVQUFNc0gsY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRixjQUFNQyxXQUFXLE1BQU1wSCxJQUFJcUgsSUFBSSxnQkFBZ0I7QUFDL0NuRix5QkFBaUJrRixTQUFTRSxJQUFJO0FBQUEsTUFDaEMsU0FBU0MsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxNQUNuRDtBQUFBLElBQ0Y7QUFDQUosZ0JBQVk7QUFBQSxFQUNkLEdBQUcsRUFBRTtBQUVMdEgsWUFBVSxNQUFNO0FBQ2QsUUFBSXNELFdBQVc7QUFDYnNDLGtCQUFZLENBQUNnQyxjQUFjO0FBQUEsUUFDekIsR0FBR0E7QUFBQUEsUUFDSDVCLFlBQVkxQyxVQUFVMEM7QUFBQUEsTUFDeEIsRUFBRTtBQUFBLElBQ0o7QUFBQSxFQUNGLEdBQUcsQ0FBQzFDLFNBQVMsQ0FBQztBQUVkLFFBQU11RSxlQUFlQSxDQUFDeEQsTUFBTTtBQUMxQixVQUFNLEVBQUV5RCxNQUFNdkQsTUFBTSxJQUFJRixFQUFFQztBQUMxQnNCLGdCQUFZLENBQUNnQyxjQUFjO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRSxJQUFJLEdBQUd2RDtBQUFBQSxJQUNWLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTXdELG1CQUFtQkEsQ0FBQzFELE1BQU07QUFDOUIsVUFBTSxFQUFFeUQsTUFBTXZELE1BQU0sSUFBSUYsRUFBRUM7QUFDMUIsVUFBTSxDQUFDd0IsU0FBU0MsTUFBTSxJQUFJeEIsTUFBTUcsTUFBTSxHQUFHO0FBQ3pDa0IsZ0JBQVksQ0FBQ2dDLGNBQWM7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNIOUI7QUFBQUEsTUFDQUM7QUFBQUEsSUFDRixFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU1pQyxjQUFjLE9BQU9DLFVBQVU7QUFDbkMsVUFBTUMsVUFBVUQsTUFBTTNELE9BQU9DO0FBQzdCdEMsdUJBQW1CaUcsT0FBTztBQUMxQnRDLGdCQUFZLENBQUN1QyxrQkFBa0I7QUFBQSxNQUM3QixHQUFHQTtBQUFBQSxNQUNIdEMsVUFBVXFDO0FBQUFBLElBQ1osRUFBRTtBQUVGRSxzQkFBa0JGLE9BQU87QUFFekIsUUFBSUEsU0FBUztBQUNYLFVBQUk7QUFDRixjQUFNWCxXQUFXLE1BQU1wSCxJQUFJcUgsSUFBSSwwQkFBMEJVLE9BQU8sRUFBRTtBQUNsRXpGLHFCQUFhOEUsU0FBU0UsUUFBUSxDQUFDLENBQUM7QUFBQSxNQUNsQyxTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDhCQUE4QkEsS0FBSztBQUNqRGpGLHFCQUFhLENBQUMsQ0FBQztBQUFBLE1BQ2pCO0FBQUEsSUFDRixPQUFPO0FBQ0xBLG1CQUFhLENBQUMsQ0FBQztBQUFBLElBQ2pCO0FBQUEsRUFDRjtBQUVBLFFBQU00RixlQUFlO0FBQUEsSUFDbkIsRUFBRTlELE9BQU8sU0FBUytELE9BQU8sUUFBUTtBQUFBLElBQ2pDLEVBQUUvRCxPQUFPLGFBQWErRCxPQUFPLFlBQVk7QUFBQSxJQUN6QyxFQUFFL0QsT0FBTyxhQUFhK0QsT0FBTyxhQUFhO0FBQUEsSUFDMUMsRUFBRS9ELE9BQU8sYUFBYStELE9BQU8sYUFBYTtBQUFBLElBQzFDLEVBQUUvRCxPQUFPLFlBQVkrRCxPQUFPLFlBQVk7QUFBQSxJQUN4QyxFQUFFL0QsT0FBTyxVQUFVK0QsT0FBTyxTQUFTO0FBQUEsRUFBQztBQUd0QyxRQUFNQyxxQkFBcUIsT0FBT0wsWUFBWTtBQUU1Qy9GLDhCQUEwQitGLE9BQU87QUFBQSxFQUNuQztBQUVBLFFBQU1NLHFCQUFxQkEsQ0FBQ2pFLFVBQVU7QUFDcENOLHFCQUFpQk0sS0FBSztBQUV0QlIsdUJBQW1CLEtBQUs7QUFFeEIsVUFBTTBFLFFBQVEsb0JBQUl0RSxLQUFLO0FBQ3ZCLFVBQU11RSxhQUFhQSxDQUFDQyxTQUFTQSxLQUFLQyxtQkFBbUIsT0FBTztBQUU1RCxRQUFJckUsVUFBVSxTQUFTO0FBQ3JCLFlBQU1zRSxZQUFZSCxXQUFXRCxLQUFLO0FBQ2xDN0QsMEJBQW9CaUUsU0FBUztBQUM3Qi9ELHNCQUFnQitELFNBQVM7QUFBQSxJQUMzQixXQUFXdEUsVUFBVSxhQUFhO0FBQ2hDLFlBQU11RSxZQUFZLElBQUkzRSxLQUFLc0UsS0FBSztBQUNoQ0ssZ0JBQVVDLFFBQVFELFVBQVVFLFFBQVEsSUFBSSxDQUFDO0FBQ3pDLFlBQU1ILFlBQVlILFdBQVdJLFNBQVM7QUFDdENsRSwwQkFBb0JpRSxTQUFTO0FBQzdCL0Qsc0JBQWdCK0QsU0FBUztBQUFBLElBQzNCLFdBQVd0RSxVQUFVLGFBQWE7QUFDaEMsWUFBTTBFLFFBQVEsSUFBSTlFLEtBQUtzRSxNQUFNUyxZQUFZLEdBQUdULE1BQU1VLFNBQVMsR0FBRyxDQUFDO0FBQy9ELFlBQU1DLE1BQU0sSUFBSWpGLEtBQUtzRSxNQUFNUyxZQUFZLEdBQUdULE1BQU1VLFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDakV2RSwwQkFBb0I4RCxXQUFXTyxLQUFLLENBQUM7QUFDckNuRSxzQkFBZ0I0RCxXQUFXVSxHQUFHLENBQUM7QUFBQSxJQUNqQyxXQUFXN0UsVUFBVSxhQUFhO0FBQ2hDLFlBQU0wRSxRQUFRLElBQUk5RSxLQUFLc0UsTUFBTVMsWUFBWSxHQUFHVCxNQUFNVSxTQUFTLElBQUksR0FBRyxDQUFDO0FBQ25FLFlBQU1DLE1BQU0sSUFBSWpGLEtBQUtzRSxNQUFNUyxZQUFZLEdBQUdULE1BQU1VLFNBQVMsR0FBRyxDQUFDO0FBQzdEdkUsMEJBQW9COEQsV0FBV08sS0FBSyxDQUFDO0FBQ3JDbkUsc0JBQWdCNEQsV0FBV1UsR0FBRyxDQUFDO0FBQUEsSUFDakMsV0FBVzdFLFVBQVUsWUFBWTtBQUMvQixZQUFNMEUsUUFBUSxJQUFJOUUsS0FBS3NFLE1BQU1TLFlBQVksR0FBRyxHQUFHLENBQUM7QUFDaEQsWUFBTUUsTUFBTSxJQUFJakYsS0FBS3NFLE1BQU1TLFlBQVksR0FBRyxJQUFJLEVBQUU7QUFDaER0RSwwQkFBb0I4RCxXQUFXTyxLQUFLLENBQUM7QUFDckNuRSxzQkFBZ0I0RCxXQUFXVSxHQUFHLENBQUM7QUFBQSxJQUNqQyxXQUFXN0UsVUFBVSxVQUFVO0FBQzdCUix5QkFBbUIsSUFBSTtBQUFBLElBQ3pCO0FBQUEsRUFDRjtBQUNBLFFBQU1zRixnQkFBZ0JBLENBQUNDLGVBQWU7QUFDcEMsVUFBTVgsT0FBTyxJQUFJeEUsS0FBS21GLFVBQVU7QUFDaEMsVUFBTUMsVUFBVSxFQUFFQyxLQUFLLFdBQVdDLE9BQU8sUUFBUUMsTUFBTSxVQUFVO0FBQ2pFLFdBQU9mLEtBQUtDLG1CQUFtQixTQUFTVyxPQUFPLEVBQUVJLFFBQVEsS0FBSyxFQUFFO0FBQUEsRUFDbEU7QUFFQTNKO0FBQUFBLElBQVUsTUFBTTtBQUNkLFlBQU00SixrQkFBa0IsSUFBSUMsZ0JBQWdCO0FBQzVDLFlBQU1DLGdCQUFnQixZQUFZO0FBQ2hDLFlBQUk7QUFDRmpHLHVCQUFhLElBQUk7QUFDakIsZ0JBQU0wRCxXQUFXLE1BQU1wSCxJQUFJcUgsSUFBSSwyQkFBMkI7QUFBQSxZQUN4RHVDLFFBQVE7QUFBQSxjQUNOQyxXQUFXckY7QUFBQUEsY0FDWHNGLFNBQVNwRjtBQUFBQSxjQUNUcUQsU0FBU2hHO0FBQUFBLGNBQ1RnSSxRQUFRN0U7QUFBQUEsY0FDUmMsVUFBVXBCO0FBQUFBLGNBQ1ZvRixjQUFjaEY7QUFBQUEsWUFFaEI7QUFBQSxZQUNBaUYsUUFBT1IsZ0JBQWdCUTtBQUFBQSxVQUN6QixDQUFDO0FBQ0R6QyxrQkFBUTBDLEtBQUs5QyxTQUFTRSxNQUFNLHNCQUFzQjtBQUNsRCxjQUFJRixTQUFTRSxRQUFRRixTQUFTRSxLQUFLNkMsU0FBUyxHQUFHO0FBQzdDLGtCQUFNQyxnQkFBZ0JoRCxTQUFTRSxLQUFLK0M7QUFBQUEsY0FDbEMsQ0FBQ0MsWUFBWUEsUUFBUTVFLGFBQWE7QUFBQSxZQUNwQztBQUVBdEQsK0JBQW1CZ0ksYUFBYTtBQUVoQyxrQkFBTUcsY0FBY0gsY0FBY0k7QUFBQUEsY0FDaEMsQ0FBQ0MsS0FBS0gsWUFBWUcsTUFBTUMsT0FBT0osUUFBUXZFLFVBQVUsQ0FBQztBQUFBLGNBQ2xEO0FBQUEsWUFDRjtBQUNBeUIsb0JBQVEwQyxLQUFLSyxhQUFZLGNBQWM7QUFDdkNsRix3QkFBWWtGLFdBQVc7QUFFdkIsa0JBQU1JLGdCQUFnQlAsY0FBY1EsSUFBSSxDQUFDQyxPQUFPQyxXQUFXO0FBQUEsY0FDekRDLEtBQUtGLE9BQU9FO0FBQUFBLGNBQ1pDLElBQUlGLFFBQVE7QUFBQSxjQUNadEMsTUFBTXFDLE9BQU8vRTtBQUFBQSxjQUNiK0UsT0FBT0EsT0FBT25GLFVBQVV1RixjQUFjSixNQUFNSztBQUFBQSxjQUM1Q3ZELE1BQU1rRCxPQUFPbEYsU0FBU3dGO0FBQUFBLGNBQ3RCQyxVQUFVUCxPQUFPSyxXQUFXO0FBQUEsY0FDNUJHLGNBQWNSLE9BQU9sRixTQUFTMEY7QUFBQUEsY0FDOUJ4RixZQUFZZ0YsT0FBT2hGO0FBQUFBLGNBQ25CeUYsZ0JBQWdCVCxPQUFPUztBQUFBQSxjQUN2QjFGLFFBQVFpRixPQUFPakY7QUFBQUEsY0FDZkcsUUFBUThFLE9BQU85RTtBQUFBQSxjQUNmd0Ysa0JBQWtCVixPQUFPVyxXQUFXakgsTUFBTSxHQUFHLElBQUksQ0FBQztBQUFBLGNBQ2xEa0gsTUFBTVosT0FBTzdFO0FBQUFBLGNBQ2JnRSxjQUFjYSxPQUFPYjtBQUFBQSxjQUNyQjBCLGNBQ0ViLE9BQU9hLGNBQWMvRCxRQUNyQmtELE9BQU9jLFlBQVlDLGNBQ25CO0FBQUEsY0FDRkMsUUFDRSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUyxDQUFDLE9BQU87QUFBQSxrQkFDakIsTUFBTTtBQUFBLG9CQUNKQyxPQUFPO0FBQUEsc0JBQ0w7QUFBQSx3QkFDRUMsS0FBSztBQUFBLHdCQUNMNUQsT0FDRTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxRQUFPO0FBQUEsNEJBQ1AsSUFBSSxVQUFVMEMsTUFBTUUsR0FBRztBQUFBLDRCQUN2QixXQUFVO0FBQUEsNEJBQWtCO0FBQUE7QUFBQSwwQkFIOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQU1BO0FBQUEsc0JBRUo7QUFBQSxvQkFBQztBQUFBLGtCQUVMO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUVWLGlDQUFDLFlBQVMsV0FBVSxlQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQjtBQUFBO0FBQUEsZ0JBcEJqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FxQkEsS0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF1QkE7QUFBQSxZQUVKLEVBQUU7QUFFRnZKLDRCQUFnQm1KLGFBQWE7QUFBQSxVQUMvQixPQUFPO0FBQ0x2SSwrQkFBbUIsRUFBRTtBQUFBLFVBQ3ZCO0FBQUEsUUFDRixTQUFTbUYsT0FBTztBQUNkQyxrQkFBUUQsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFDbkRuRiw2QkFBbUIsRUFBRTtBQUNyQmlELHNCQUFZLENBQUM7QUFBQSxRQUNmLFVBQUM7QUFDQzNCLHVCQUFhLEtBQUs7QUFBQSxRQUNwQjtBQUFBLE1BQ0Y7QUFFQWlHLG9CQUFjO0FBQ2IsYUFBTyxNQUFJO0FBQ1JGLHdCQUFnQnVDLE1BQU07QUFBQSxNQUN4QjtBQUFBLElBQ0o7QUFBQSxJQUFHO0FBQUEsTUFDRGpLO0FBQUFBLE1BQ0EyQztBQUFBQSxNQUNBRTtBQUFBQSxNQUNBTTtBQUFBQSxNQUNBVjtBQUFBQSxNQUNBUTtBQUFBQSxJQUFtQjtBQUFBLEVBQ3BCO0FBRUQsUUFBTWlILFVBQVU7QUFBQSxJQUNkLEVBQUVGLEtBQUssTUFBTUcsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUgsS0FBSyxRQUFRRyxRQUFRLFlBQVk7QUFBQSxJQUNuQyxFQUFFSCxLQUFLLG9CQUFvQkcsUUFBUSxtQkFBbUI7QUFBQSxJQUN0RCxFQUFFSCxLQUFLLFNBQVNHLFFBQVEsYUFBYTtBQUFBLElBQ3JDLEVBQUVILEtBQUssUUFBUUcsUUFBUSxnQkFBZ0I7QUFBQSxJQUN2QyxFQUFFSCxLQUFLLFlBQVlHLFFBQVEsV0FBVztBQUFBLElBQ3RDLEVBQUVILEtBQUssZ0JBQWdCRyxRQUFRLHdCQUF3QjtBQUFBLElBQ3ZELEVBQUVILEtBQUssY0FBY0csUUFBUSxpQkFBaUI7QUFBQSxJQUM5QyxFQUFFSCxLQUFLLGtCQUFrQkcsUUFBUSxjQUFjO0FBQUEsSUFDL0MsRUFBRUgsS0FBSyxVQUFVRyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFSCxLQUFLLFVBQVVHLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVILEtBQUssUUFBUUcsUUFBUSxlQUFlO0FBQUEsSUFDdEMsR0FBSXBILGtCQUNGLENBQUMsRUFBRWlILEtBQUssZ0JBQWdCRyxRQUFRLGVBQWUsQ0FBQyxJQUFHO0FBQUEsSUFDckQsRUFBRUgsS0FBSyxnQkFBZ0JHLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVILEtBQUssVUFBVUcsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQ3JNLFlBQVUsTUFBTTtBQUNkLFFBQUl3QyxhQUFhbUQsU0FBUzJHLFlBQVk7QUFDcEMsWUFBTUMsYUFBYy9KLFVBQVVnSyxjQUFjLElBQUssT0FBTztBQUN4RCxZQUFNQyxjQUNIakssVUFBVWdLLGVBQWUsTUFBTTdHLFNBQVMyRyxjQUFjO0FBQ3pELFlBQU1JLFlBQVkvRyxTQUFTMkcsY0FBYyxLQUFLQztBQUM5QyxZQUFNSSxnQkFBZ0JuSyxVQUFVb0ssZ0JBQzVCRixXQUFXbEssVUFBVW9LLGdCQUNyQjtBQUNKLFlBQU1DLFdBQVdySyxVQUFVc0ssaUJBQWlCLEtBQUtIO0FBRWpEL0csa0JBQVksQ0FBQ2dDLGNBQWM7QUFBQSxRQUN6QixHQUFHQTtBQUFBQSxRQUNIL0IsVUFBVXJELFVBQVUwSTtBQUFBQSxRQUNwQnFCO0FBQUFBLFFBQ0FFO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FFO0FBQUFBLE1BQ0YsRUFBRTtBQUFBLElBQ0o7QUFBQSxFQUNGLEdBQUcsQ0FBQ3JLLFdBQVdtRCxTQUFTMkcsVUFBVSxDQUFDO0FBRW5DLFFBQU1TLDBCQUEwQkEsQ0FBQzFJLE1BQU07QUFDckMsVUFBTTJJLGVBQWUzSSxFQUFFQyxPQUFPQztBQUM5QmQsbUJBQWV1SixZQUFZO0FBQzNCcEgsZ0JBQVksQ0FBQ2dDLGNBQWM7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNIekIsVUFBVTZHO0FBQUFBLE1BQ1Y1RyxnQkFBZ0I0RyxpQkFBaUIsV0FBV3BGLFNBQVN4QixpQkFBaUI7QUFBQSxJQUN4RSxFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU02RyxlQUFlLE9BQU81SSxNQUFNO0FBQ2hDQSxNQUFFNkksZUFBZTtBQUNqQixRQUFJO0FBQ0YsWUFBTTNGLFdBQVcsTUFBTXBILElBQUlnTixLQUFLLHdCQUF3QnhILFFBQVE7QUFDaEUsVUFBSTRCLFNBQVM2RixXQUFXLEtBQUs7QUFDM0JDLGNBQU0sNEJBQTRCO0FBQ2xDMUsscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRixTQUFTK0UsT0FBTztBQUNkQyxjQUFRRCxNQUFNLGtDQUFrQ0EsS0FBSztBQUFBLElBQ3ZEO0FBQUEsRUFDRjtBQUVBLFFBQU00Rix3QkFBd0IsT0FBT3BGLFlBQVk7QUFDL0MsUUFBSTtBQUNGLFlBQU1YLFdBQVcsTUFBTXBILElBQUlxSCxJQUFJLDhCQUE4QlUsT0FBTyxFQUFFO0FBQ3RFbkYsc0JBQWdCd0UsU0FBU0UsSUFBSTtBQUM3QjVFLHlCQUFtQixJQUFJO0FBQUEsSUFDekIsU0FBUzZFLE9BQU87QUFDZEMsY0FBUUQsTUFBTSwwQkFBMEJBLEtBQUs7QUFBQSxJQUMvQztBQUFBLEVBQ0Y7QUFFQSxRQUFNNkYsc0JBQXNCLFlBQVk7QUFDdEMsUUFBSXpLLGNBQWM7QUFDaEIsVUFBSTtBQUNGLGNBQU0zQyxJQUFJcU4sT0FBTywyQkFBMkIxSyxhQUFhb0ksR0FBRyxFQUFFO0FBQzlEbUMsY0FBTSw4QkFBOEI7QUFDcEN4SywyQkFBbUIsS0FBSztBQUN4QkUsd0JBQWdCLElBQUk7QUFDcEIwSyxlQUFPQyxTQUFTQyxPQUFPO0FBQUEsTUFDekIsU0FBU2pHLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sMkJBQTJCQSxLQUFLO0FBQUEsTUFDaEQ7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU1rRyx3QkFBd0IsT0FBTzFGLFlBQVk7QUFDL0MsUUFBSTtBQUNGLFlBQU1YLFdBQVcsTUFBTXBILElBQUlxSCxJQUFJLDhCQUE4QlUsT0FBTyxFQUFFO0FBQ3RFL0UsNEJBQXNCb0UsU0FBU0UsSUFBSTtBQUNuQ3hFLHlCQUFtQixJQUFJO0FBQUEsSUFDekIsU0FBU3lFLE9BQU87QUFDZEMsY0FBUUQsTUFBTSwyQkFBMkJBLEtBQUs7QUFBQSxJQUNoRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNbUcsbUJBQW1CLE9BQU94SixNQUFNO0FBQ3BDQSxNQUFFNkksZUFBZTtBQUVqQixVQUFNWSxZQUFZLElBQUlDLFNBQVM7QUFDL0IsVUFBTUMsWUFBWTNKLEVBQUVDLE9BQU8ySjtBQUMzQixRQUFJRCxhQUFhQSxVQUFVRSxNQUFNLENBQUMsR0FBRztBQUNuQ0osZ0JBQVVLLE9BQU8sUUFBUUgsVUFBVUUsTUFBTSxDQUFDLENBQUM7QUFFM0MsVUFBSTtBQUNGLGNBQU0zRyxXQUFXLE1BQU1wSCxJQUFJZ04sS0FBSywwQkFBMEJXLFdBQVc7QUFBQSxVQUNuRU0sU0FBUyxFQUFFLGdCQUFnQixzQkFBc0I7QUFBQSxRQUNuRCxDQUFDO0FBRUQsWUFBSTdHLFNBQVM2RixXQUFXLEtBQUs7QUFDM0JDLGdCQUFNLDZCQUE2QjtBQUNuQ0ksaUJBQU9DLFNBQVNDLE9BQU87QUFDdkJ0Syw2QkFBbUIsS0FBSztBQUFBLFFBQzFCO0FBQUEsTUFDRixTQUFTcUUsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSx5QkFBeUJBLEtBQUs7QUFDNUMyRixjQUFNLHdCQUF3QjtBQUFBLE1BQ2hDO0FBQUEsSUFDRixPQUFPO0FBQ0xBLFlBQU0saUNBQWlDO0FBQUEsSUFDekM7QUFBQSxFQUNGO0FBRUEsU0FDRSxtQ0FDSSxpQ0FBQyxTQUFJLFdBQVUsVUFDZixpQ0FBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLFlBQVk7QUFBQTtBQUFBLE1BRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRW1CO0FBQUEsSUFFbkI7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU1oSCxZQUFZSTtBQUFBQSxRQUNsQixXQUFXSixZQUFZRTtBQUFBQSxRQUN2QixTQUFTRixZQUFZRztBQUFBQTtBQUFBQSxNQUh2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHK0I7QUFBQSxJQUUvQix1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsc0JBQXFCLDJDQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThEO0FBQUEsTUFDOUQsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLG1DQUFDLFdBQU0sNkJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0I7QUFBQSxZQUVwQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDO0FBQUEsZ0JBQ0EsdUJBQXVCO0FBQUEsZ0JBQ3ZCLFVBQVVnQztBQUFBQSxnQkFDVixPQUFPeEU7QUFBQUEsZ0JBQ1AsYUFBWTtBQUFBLGdCQUNaLGNBQWMsQ0FBQ3FLLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1RDLFlBQVksRUFDWkMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsZ0JBRWpDLFdBQVU7QUFBQSxnQkFFVHBHLHVCQUFhMEM7QUFBQUEsa0JBQUksQ0FBQzRELFNBQ2pCLHVCQUFDLE9BQU8sUUFBUCxFQUErQixPQUFPQSxLQUFLcEssT0FDekNvSyxlQUFLckcsU0FEWXFHLEtBQUtwSyxPQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBLGNBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQW1CQTtBQUFBLGVBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdUJBO0FBQUEsVUFDQ1QsbUJBQ0MsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHFDQUFDLFdBQU0seUJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0I7QUFBQSxjQUNoQjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT2E7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDTixNQUFNTyxvQkFBb0JQLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxrQkFDbkQsV0FBVTtBQUFBO0FBQUEsZ0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSTZGO0FBQUEsaUJBTi9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEscUNBQUMsV0FBTSx1QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFjO0FBQUEsY0FDZDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT007QUFBQUEsa0JBQ1AsVUFBVSxDQUFDUixNQUFNUyxnQkFBZ0JULEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxrQkFDL0MsV0FBVTtBQUFBO0FBQUEsZ0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSTZGO0FBQUEsaUJBTi9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLFVBRUYsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxtQ0FBQyxXQUFNLHFCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVk7QUFBQSxZQWFaO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQSx1QkFBdUI7QUFBQSxnQkFDdkIsT0FBT3JDO0FBQUFBLGdCQUNQLFVBQVVxRztBQUFBQSxnQkFDVixhQUFZO0FBQUEsZ0JBQ1osY0FBYyxDQUFDOEYsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pDLFNBQVMsRUFDVEMsWUFBWSxFQUNaQyxTQUFTTCxNQUFNSSxZQUFZLENBQUM7QUFBQSxnQkFFakMsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTyxJQUFJLG1CQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QjtBQUFBLGtCQUM1QmpOLE9BQU91SjtBQUFBQSxvQkFBSSxDQUFDQyxVQUNYLHVCQUFDLE9BQU8sUUFBUCxFQUE4QixPQUFPQSxNQUFNRSxLQUN6Q0YsZ0JBQU1JLGNBRFdKLE1BQU1FLEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUE7QUFBQSxjQW5CSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFvQkE7QUFBQSxlQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1DQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxtQ0FBQyxXQUFNLHdCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWU7QUFBQSxZQWFmO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQSx1QkFBdUI7QUFBQSxnQkFDdkIsT0FBTzdGO0FBQUFBLGdCQUNQLGNBQWMsQ0FBQ2dKLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1RDLFlBQVksRUFDWkMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsZ0JBRWpDLGFBQVk7QUFBQSxnQkFDWixVQUFVLENBQUN2RyxZQUFZNUMscUJBQXFCNEMsT0FBTztBQUFBLGdCQUNuRCxXQUFVO0FBQUEsZ0JBR1Y7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsbUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJCO0FBQUEsa0JBQzFCOUYsY0FBYzJJO0FBQUFBLG9CQUFJLENBQUNDLFVBQ2xCLHVCQUFDLE9BQU8sUUFBUCxFQUErQixPQUFPQSxPQUFPRSxLQUMzQ0Y7QUFBQUEsNkJBQU9NO0FBQUFBLHNCQUFVO0FBQUEsc0JBQUlOLE1BQU1RO0FBQUFBLHlCQURWUixPQUFPRSxLQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBO0FBQUEsY0FwQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBcUJBO0FBQUEsZUFuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQ0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsbUNBQUMsV0FBTSw0QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQjtBQUFBLFlBVW5CO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBT25HO0FBQUFBLGdCQUNQO0FBQUEsZ0JBQ0EsYUFBWTtBQUFBLGdCQUNaLHVCQUF1QjtBQUFBLGdCQUN2QixVQUFVLENBQUNtRCxZQUFZbEQsdUJBQXVCa0QsT0FBTztBQUFBLGdCQUNyRCxjQUFjLENBQUNtRyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUQyxZQUFZLEVBQ1pDLFNBQVNMLE1BQU1JLFlBQVksQ0FBQztBQUFBLGdCQUVqQyxXQUFVO0FBQUEsZ0JBR1Y7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsbUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJCO0FBQUEsa0JBQzNCLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sUUFBTyxvQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxrQkFDaEMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxnQkFBZSxxQ0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUQ7QUFBQSxrQkFDekQsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxVQUFTLHNCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvQztBQUFBO0FBQUE7QUFBQSxjQWxCdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBb0JBO0FBQUEsZUEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQ0E7QUFBQSxVQUNDaEosdUJBQ0QsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxtQ0FBQyxXQUFNLDRCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1CO0FBQUEsWUFVbkI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPTjtBQUFBQSxnQkFDUDtBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWix1QkFBdUI7QUFBQSxnQkFDdkIsVUFBVSxDQUFDK0MsWUFBWTlDLHVCQUF1QjhDLE9BQU87QUFBQSxnQkFDckQsY0FBYyxDQUFDbUcsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pDLFNBQVMsRUFDVEMsWUFBWSxFQUNaQyxTQUFTTCxNQUFNSSxZQUFZLENBQUM7QUFBQSxnQkFFakMsV0FBVTtBQUFBLGdCQUdSLDZDQUNDO0FBQUEseUNBQUMsWUFBTyxPQUFNLElBQUcsbUNBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9DO0FBQUEsa0JBQ25DLHVCQUFDLFlBQU8sT0FBTSxZQUFXLHdCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQztBQUFBLGtCQUNqQyx1QkFBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkI7QUFBQSxrQkFDN0IsdUJBQUMsWUFBTyxPQUFNLGNBQWEsMEJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFDO0FBQUEsa0JBQ3JDLHVCQUFDLFlBQU8sT0FBTSxVQUFTLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QjtBQUFBLHFCQUwvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU1BO0FBQUE7QUFBQSxjQXJCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF1QkE7QUFBQSxlQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1DQTtBQUFBLFVBRUEsdUJBQUMsU0FDQyxpQ0FBQyxRQUFHLFdBQVUsZ0JBQWU7QUFBQTtBQUFBLFlBQ2I7QUFBQSxZQUNkLHVCQUFDLFVBQUssV0FBVSxXQUFVO0FBQUE7QUFBQSxjQUFFbEosWUFBWTtBQUFBLGlCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwQztBQUFBLGVBRjVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFwTUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFNQSxLQXRNRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdU1BO0FBQUEsUUFDQ2pELG1CQUFtQkEsZ0JBQWdCZ0ksU0FBUyxLQUFLLENBQUMxRyxZQUNqRCx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNMUMsYUFBYVEsY0FBY2dDLFVBQVU7QUFBQSxjQUMzQztBQUFBLGNBQ0EsaUJBQWlCO0FBQUEsY0FFakIsa0JBQWtCO0FBQUE7QUFBQSxZQUxwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLK0M7QUFBQSxVQUUvQyx1QkFBQyxTQUFJLFdBQVUsOEJBQ2IsaUNBQUMsVUFBSyxXQUFVLHlCQUF3QjtBQUFBO0FBQUEsWUFDdEI2QjtBQUFBQSxlQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLGFBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLG1DQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0EsU0FBU2pELGdCQUFnQmdJLFVBQVU7QUFBQSxZQUNuQyxNQUFLO0FBQUE7QUFBQSxVQUhQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUdxQixLQUp2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxXQS9OSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaU9BO0FBQUEsU0FuT0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9PQTtBQUFBLElBQ0EsdUJBQUMsU0FBTSxXQUFXNUgsV0FBVyxTQUFTLE1BQU1DLGFBQWEsS0FBSyxHQUM1RCxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsd0NBQXVDLDJCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVVzSyxjQUNwQztBQUFBLCtCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLFNBQVE7QUFBQSxjQUFVO0FBQUE7QUFBQSxZQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU9qTDtBQUFBQSxjQUNQLFVBQVVnRztBQUFBQSxjQUNWLFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsWUFBTyxPQUFNLElBQUcsNEJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZCO0FBQUEsZ0JBQzVCeEcsT0FBT3VKO0FBQUFBLGtCQUFJLENBQUNDLFVBQ1gsdUJBQUMsWUFBdUIsT0FBT0EsTUFBTUUsS0FDbENGLGdCQUFNSSxjQURJSixNQUFNRSxLQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBO0FBQUEsWUFWSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFXQTtBQUFBLGFBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQkE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLFNBQVE7QUFBQSxjQUFVO0FBQUE7QUFBQSxZQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE9BQU8sR0FBR3ZGLFNBQVNHLE9BQU8sSUFBSUgsU0FBU0ksTUFBTTtBQUFBLGNBQzdDLFVBQVVnQztBQUFBQSxjQUNWO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFlBQU8sT0FBTSxJQUFHLCtCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLGdCQUMvQjNGLGNBQWMySTtBQUFBQSxrQkFBSSxDQUFDcEUsU0FDbEI7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBRUMsT0FBTyxHQUFHQSxNQUFNYixTQUFTb0YsR0FBRyxJQUFJdkUsS0FBS2lJLE9BQU87QUFBQSxzQkFFM0NqSTtBQUFBQSw4QkFBTWIsU0FBU3dGO0FBQUFBLHdCQUFVO0FBQUEsd0JBQUkzRSxLQUFLaUk7QUFBQUE7QUFBQUE7QUFBQUEsb0JBSDlCLEdBQUdqSSxNQUFNYixTQUFTb0YsR0FBRyxJQUFJdkUsS0FBS2lJLE9BQU87QUFBQSxvQkFENUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLQTtBQUFBLGdCQUNEO0FBQUE7QUFBQTtBQUFBLFlBZkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBZ0JBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFRO0FBQUEsZ0JBQWE7QUFBQTtBQUFBLGNBRnZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsT0FBT2pKLFNBQVNLO0FBQUFBLGdCQUNoQixJQUFHO0FBQUEsZ0JBQ0gsYUFBWTtBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBO0FBQUEsY0FQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPMkk7QUFBQSxlQWQ3STtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFRO0FBQUEsZ0JBQWU7QUFBQTtBQUFBLGNBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsT0FBT0wsU0FBU007QUFBQUEsZ0JBQ2hCLElBQUc7QUFBQSxnQkFDSCxVQUFVNEI7QUFBQUEsZ0JBQ1YsYUFBWTtBQUFBLGdCQUNaLFdBQVU7QUFBQTtBQUFBLGNBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTzJJO0FBQUEsZUFkN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxhQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUNBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBYTtBQUFBO0FBQUEsY0FGdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPbEMsU0FBU087QUFBQUEsZ0JBQ2hCLElBQUc7QUFBQSxnQkFDSCxVQUFVMkI7QUFBQUEsZ0JBQ1YsYUFBWTtBQUFBLGdCQUNaLFdBQVU7QUFBQTtBQUFBLGNBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTzJJO0FBQUEsZUFkN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsU0FBUTtBQUFBLGdCQUFVO0FBQUE7QUFBQSxjQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsSUFBRztBQUFBLGdCQUNILFdBQVU7QUFBQSxnQkFDVixVQUFVa0Y7QUFBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxZQUFPLE9BQU0sUUFBTyxvQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUI7QUFBQSxrQkFDekIsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZCO0FBQUE7QUFBQTtBQUFBLGNBUC9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFBO0FBQUEsZUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLGFBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQ0E7QUFBQSxRQUNDdkosZ0JBQWdCLFlBQ2YsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBUTtBQUFBLGNBQWdCO0FBQUE7QUFBQSxZQUYxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLElBQUc7QUFBQSxjQUNILE9BQU9tQyxTQUFTUztBQUFBQSxjQUNoQixVQUFVeUI7QUFBQUEsY0FDVixhQUFZO0FBQUEsY0FDWixXQUFVO0FBQUE7QUFBQSxZQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU8ySTtBQUFBLGFBZDdJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxRQUVGO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxXQUFVO0FBQUEsWUFDK0c7QUFBQTtBQUFBLFVBSDNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsV0EvSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdKQTtBQUFBLFNBcEpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxSkEsS0F0SkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVKQTtBQUFBLElBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVc3RTtBQUFBQSxRQUNYLFNBQVMsTUFBTUMsbUJBQW1CLEtBQUs7QUFBQSxRQUV2QyxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLDRCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVUsYUFBWSxVQUFVLE1BQU07QUFBQSxVQUFDLEdBQzNDO0FBQUEsbUNBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQU87QUFBQTtBQUFBLGdCQUZqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPQyxvQkFBb0IyQyxVQUFVdUY7QUFBQUEsa0JBQ3JDLFVBQVUsTUFBTTtBQUFBLGtCQUFDO0FBQUEsa0JBQ2pCLElBQUc7QUFBQSxrQkFDSCxhQUFZO0FBQUEsa0JBQ1o7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRMkk7QUFBQSxpQkFmN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBYTtBQUFBO0FBQUEsa0JBRnZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT2xJLG9CQUFvQjJDLFVBQVUyRztBQUFBQSxvQkFDckMsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPMkk7QUFBQSxtQkFkN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBZTtBQUFBO0FBQUEsa0JBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT3RKLG9CQUFvQjJDLFVBQVVpSDtBQUFBQSxvQkFDckMsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPMkk7QUFBQSxtQkFkN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQkE7QUFBQSxpQkFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtQ0E7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFPO0FBQUE7QUFBQSxnQkFGakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsT0FBTyxHQUFHNUosb0JBQW9CNEMsU0FBU3dGLFNBQVMsTUFBTXBJLG9CQUFvQjZDLE1BQU07QUFBQSxrQkFDaEYsVUFBVSxNQUFNO0FBQUEsa0JBQUM7QUFBQSxrQkFDakIsSUFBRztBQUFBLGtCQUNILGFBQVk7QUFBQSxrQkFDWjtBQUFBLGtCQUNBLFdBQVU7QUFBQTtBQUFBLGdCQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVEySTtBQUFBLGlCQWY3STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLFlBRUEsdUJBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQU87QUFBQTtBQUFBLGdCQUZqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUNFN0Msb0JBQW9CMkMsVUFBVTJHLGNBQzlCdEosb0JBQW9CdUo7QUFBQUEsa0JBRXRCLFVBQVUsTUFBTTtBQUFBLGtCQUFDO0FBQUEsa0JBQ2pCLElBQUc7QUFBQSxrQkFDSCxhQUFZO0FBQUEsa0JBQ1o7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFYWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FXMkk7QUFBQSxpQkFsQjdJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQWE7QUFBQTtBQUFBLGtCQUZ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU92SixvQkFBb0JxSjtBQUFBQSxvQkFDM0IsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPMkk7QUFBQSxtQkFkN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBZTtBQUFBO0FBQUEsa0JBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT3JKLG9CQUFvQnVKO0FBQUFBLG9CQUMzQixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU8ySTtBQUFBLG1CQWQ3STtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWdCQTtBQUFBLGlCQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1DQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFhO0FBQUE7QUFBQSxrQkFGdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPdkosb0JBQW9Cd0o7QUFBQUEsb0JBQzNCLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFVO0FBQUE7QUFBQSxrQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTzJJO0FBQUEsbUJBZDdJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0JBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQWU7QUFBQTtBQUFBLGtCQUZ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU94SixvQkFBb0J5SjtBQUFBQSxvQkFDM0IsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPMkk7QUFBQSxtQkFkN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBZTtBQUFBO0FBQUEsa0JBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT3pKLG9CQUFvQjJKO0FBQUFBLG9CQUMzQixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU8ySTtBQUFBLG1CQWQ3STtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWdCQTtBQUFBLGlCQW5ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9EQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxrQkFGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPM0osb0JBQW9CMkw7QUFBQUEsb0JBQzNCLFVBQVUsTUFBTTtBQUFBLG9CQUFDO0FBQUEsb0JBQ2pCLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFVO0FBQUE7QUFBQSxrQkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUTJJO0FBQUEsbUJBZjdJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUJBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLGtCQUZoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU8zTCxvQkFBb0I0TDtBQUFBQSxvQkFDM0IsVUFBVSxNQUFNO0FBQUEsb0JBQUM7QUFBQSxvQkFDakIsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRMkk7QUFBQSxtQkFmN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxpQkFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQ0E7QUFBQSxlQTdORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQThOQTtBQUFBLGFBbE9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtT0E7QUFBQTtBQUFBLE1Bdk9GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXdPQTtBQUFBLElBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVdsTTtBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiQyw2QkFBbUIsS0FBSztBQUN4QkUsMEJBQWdCLElBQUk7QUFBQSxRQUN0QjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QyxrREFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0NELGdCQUNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxVQUFVLENBQUN1QixNQUFNO0FBQ2ZBLGtCQUFFNkksZUFBZTtBQUNqQkssb0NBQW9CO0FBQUEsY0FDdEI7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUVWO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ21HO0FBQUE7QUFBQSxnQkFIL0c7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUE7QUFBQTtBQUFBLFlBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBY0E7QUFBQSxhQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUJBO0FBQUE7QUFBQSxNQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUE2QkE7QUFBQSxPQTdvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThvQkEsS0Evb0JBO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FncEJGLEtBanBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa3BCQTtBQUVKO0FBQUVoTSxHQXJsQ0lELHVCQUFxQjtBQUFBeU4sS0FBckJ6TjtBQXVsQ04sZUFBZUE7QUFBc0IsSUFBQXlOO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJhcGkiLCJNZERlbGV0ZSIsIkNpRWRpdCIsIk1vZGFsIiwiQnNFeWUiLCJVcGxvYWRNb2RhbCIsImF4aW9zIiwidXJsIiwiU2VsZWN0IiwiRHJvcGRvd24iLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydCIsIkVuZGxlc3NDaXJjdWxhckxvYWRlciIsIkNpcmN1bGFyTG9hZGVyIiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwiSW9NZE1vcmUiLCJMaW5rIiwiZmllbGRTaXplIiwiUmVnaXN0cmF0aW9uRmVlUmVwb3J0IiwiX3MiLCJncm91cHMiLCJzZXRHcm91cHMiLCJUYWJsZURheWJvb2siLCJzZXRUYWJsZURheWJvb2siLCJzZWxlY3RlZEdyb3VwIiwic2V0U2VsZWN0ZWRHcm91cCIsInNlbGVjdGVkQXVjdGlvbkdyb3VwIiwic2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXAiLCJzZWxlY3RlZEdyb3VwSWQiLCJzZXRTZWxlY3RlZEdyb3VwSWQiLCJzZWxlY3RlZEF1Y3Rpb25Hcm91cElkIiwic2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCIsImZpbHRlcmVkVXNlcnMiLCJzZXRGaWx0ZXJlZFVzZXJzIiwiZmlsdGVyZWRBdWN0aW9uIiwic2V0RmlsdGVyZWRBdWN0aW9uIiwiZ3JvdXBJbmZvIiwic2V0R3JvdXBJbmZvIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwic2hvd01vZGFsRGVsZXRlIiwic2V0U2hvd01vZGFsRGVsZXRlIiwiY3VycmVudEdyb3VwIiwic2V0Q3VycmVudEdyb3VwIiwic2hvd01vZGFsVXBkYXRlIiwic2V0U2hvd01vZGFsVXBkYXRlIiwiY3VycmVudFVwZGF0ZUdyb3VwIiwic2V0Q3VycmVudFVwZGF0ZUdyb3VwIiwic2hvd1VwbG9hZE1vZGFsIiwic2V0U2hvd1VwbG9hZE1vZGFsIiwicmVjZWlwdE5vIiwic2V0UmVjZWlwdE5vIiwicGF5bWVudE1vZGUiLCJzZXRQYXltZW50TW9kZSIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwic2hvd0ZpbHRlckZpZWxkIiwic2V0U2hvd0ZpbHRlckZpZWxkIiwic2VsZWN0ZWRMYWJlbCIsInNldFNlbGVjdGVkTGFiZWwiLCJub3ciLCJEYXRlIiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInRhcmdldCIsInZhbHVlIiwidG9kYXlTdHJpbmciLCJ0b0lTT1N0cmluZyIsInNwbGl0Iiwic2VsZWN0ZWRGcm9tRGF0ZSIsInNldFNlbGVjdGVkRnJvbURhdGUiLCJzZWxlY3RlZERhdGUiLCJzZXRTZWxlY3RlZERhdGUiLCJzZWxlY3RlZFBheW1lbnRNb2RlIiwic2V0U2VsZWN0ZWRQYXltZW50TW9kZSIsImhpZGVBY2NvdW50VHlwZSIsInNldEhpZGVBY2NvdW50VHlwZSIsInNlbGVjdGVkQWNjb3VudFR5cGUiLCJzZXRTZWxlY3RlZEFjY291bnRUeXBlIiwic2VsZWN0ZWRDdXN0b21lcnMiLCJzZXRTZWxlY3RlZEN1c3RvbWVycyIsInBheW1lbnRzIiwic2V0UGF5bWVudHMiLCJzaG93QWxsUGF5bWVudE1vZGVzIiwic2V0U2hvd0FsbFBheW1lbnRNb2RlcyIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJncm91cF9pZCIsInVzZXJfaWQiLCJ0aWNrZXQiLCJyZWNlaXB0X25vIiwicGF5X2RhdGUiLCJhbW91bnQiLCJwYXlfdHlwZSIsInRyYW5zYWN0aW9uX2lkIiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwidHlwZSIsImhhbmRsZU1vZGFsQ2xvc2UiLCJ1c2VyIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInVzZXJPYmoiLCJKU09OIiwicGFyc2UiLCJhZG1pbl9hY2Nlc3NfcmlnaHRfaWQiLCJhY2Nlc3NfcGVybWlzc2lvbnMiLCJlZGl0X3BheW1lbnQiLCJzaG93UGF5bWVudHNNb2RlcyIsImlzTW9kaWZ5IiwiZmV0Y2hHcm91cHMiLCJyZXNwb25zZSIsImdldCIsImRhdGEiLCJlcnJvciIsImNvbnNvbGUiLCJwcmV2RGF0YSIsImhhbmRsZUNoYW5nZSIsIm5hbWUiLCJoYW5kbGVDaGFuZ2VVc2VyIiwiaGFuZGxlR3JvdXAiLCJldmVudCIsImdyb3VwSWQiLCJwcmV2Rm9ybURhdGEiLCJoYW5kbGVHcm91cENoYW5nZSIsImdyb3VwT3B0aW9ucyIsImxhYmVsIiwiaGFuZGxlR3JvdXBQYXltZW50IiwiaGFuZGxlU2VsZWN0RmlsdGVyIiwidG9kYXkiLCJmb3JtYXREYXRlIiwiZGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImZvcm1hdHRlZCIsInllc3RlcmRheSIsInNldERhdGUiLCJnZXREYXRlIiwic3RhcnQiLCJnZXRGdWxsWWVhciIsImdldE1vbnRoIiwiZW5kIiwiZm9ybWF0UGF5RGF0ZSIsImRhdGVTdHJpbmciLCJvcHRpb25zIiwiZGF5IiwibW9udGgiLCJ5ZWFyIiwicmVwbGFjZSIsImFib3J0Q29udHJvbGxlciIsIkFib3J0Q29udHJvbGxlciIsImZldGNoUGF5bWVudHMiLCJwYXJhbXMiLCJmcm9tX2RhdGUiLCJ0b19kYXRlIiwidXNlcklkIiwiYWNjb3VudF90eXBlIiwic2lnbmFsIiwiaW5mbyIsImxlbmd0aCIsInZhbGlkUGF5bWVudHMiLCJmaWx0ZXIiLCJwYXltZW50IiwidG90YWxBbW91bnQiLCJyZWR1Y2UiLCJzdW0iLCJOdW1iZXIiLCJmb3JtYXR0ZWREYXRhIiwibWFwIiwiZ3JvdXAiLCJpbmRleCIsIl9pZCIsImlkIiwiZ3JvdXBfbmFtZSIsInBheV9mb3IiLCJmdWxsX25hbWUiLCJjYXRlZ29yeSIsInBob25lX251bWJlciIsIm9sZF9yZWNlaXB0X25vIiwidHJhbnNhY3Rpb25fZGF0ZSIsImNyZWF0ZWRBdCIsIm1vZGUiLCJjb2xsZWN0ZWRfYnkiLCJhZG1pbl90eXBlIiwiYWRtaW5fbmFtZSIsImFjdGlvbiIsIml0ZW1zIiwia2V5IiwiYWJvcnQiLCJjb2x1bW5zIiwiaGVhZGVyIiwiYmlkX2Ftb3VudCIsImNvbW1pc3Npb24iLCJncm91cF92YWx1ZSIsIndpbl9hbW91bnQiLCJkaXZpZGVudCIsImRpdmlkZW50X2hlYWQiLCJncm91cF9tZW1iZXJzIiwicGF5YWJsZSIsImdyb3VwX2luc3RhbGwiLCJoYW5kbGVQYXltZW50TW9kZUNoYW5nZSIsInNlbGVjdGVkTW9kZSIsImhhbmRsZVN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwicG9zdCIsInN0YXR1cyIsImFsZXJ0IiwiaGFuZGxlRGVsZXRlTW9kYWxPcGVuIiwiaGFuZGxlRGVsZXRlQXVjdGlvbiIsImRlbGV0ZSIsIndpbmRvdyIsImxvY2F0aW9uIiwicmVsb2FkIiwiaGFuZGxlVXBkYXRlTW9kYWxPcGVuIiwiaGFuZGxlRmlsZVN1Ym1pdCIsImZvcm1EYXRhcyIsIkZvcm1EYXRhIiwiZmlsZUlucHV0IiwiZmlsZSIsImZpbGVzIiwiYXBwZW5kIiwiaGVhZGVycyIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJ0b1N0cmluZyIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJ0aW1lIiwidGlja2V0cyIsImF1Y3Rpb25fZGF0ZSIsIm5leHRfZGF0ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlJlZ2lzdHJhdGlvbkZlZVJlcG9ydC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgeyBNZERlbGV0ZSB9IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5pbXBvcnQgeyBDaUVkaXQgfSBmcm9tIFwicmVhY3QtaWNvbnMvY2lcIjtcclxuaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgeyBCc0V5ZSB9IGZyb20gXCJyZWFjdC1pY29ucy9ic1wiO1xyXG5pbXBvcnQgVXBsb2FkTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL1VwbG9hZE1vZGFsXCI7XHJcbmltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IHVybCBmcm9tIFwiLi4vZGF0YS9VcmxcIjtcclxuaW1wb3J0IHsgU2VsZWN0LCBEcm9wZG93biB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0IGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydFwiO1xyXG5pbXBvcnQgRW5kbGVzc0NpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvRW5kbGVzc0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IGZpZWxkU2l6ZSB9IGZyb20gXCIuLi9kYXRhL2ZpZWxkU2l6ZVwiO1xyXG5cclxuY29uc3QgUmVnaXN0cmF0aW9uRmVlUmVwb3J0ID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtncm91cHMsIHNldEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW1RhYmxlRGF5Ym9vaywgc2V0VGFibGVEYXlib29rXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0ZWRHcm91cCwgc2V0U2VsZWN0ZWRHcm91cF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRBdWN0aW9uR3JvdXAsIHNldFNlbGVjdGVkQXVjdGlvbkdyb3VwXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEdyb3VwSWQsIHNldFNlbGVjdGVkR3JvdXBJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCwgc2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZmlsdGVyZWRVc2Vycywgc2V0RmlsdGVyZWRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkQXVjdGlvbiwgc2V0RmlsdGVyZWRBdWN0aW9uXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZ3JvdXBJbmZvLCBzZXRHcm91cEluZm9dID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbERlbGV0ZSwgc2V0U2hvd01vZGFsRGVsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudEdyb3VwLCBzZXRDdXJyZW50R3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbFVwZGF0ZSwgc2V0U2hvd01vZGFsVXBkYXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudFVwZGF0ZUdyb3VwLCBzZXRDdXJyZW50VXBkYXRlR3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3Nob3dVcGxvYWRNb2RhbCwgc2V0U2hvd1VwbG9hZE1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcmVjZWlwdE5vLCBzZXRSZWNlaXB0Tm9dID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3BheW1lbnRNb2RlLCBzZXRQYXltZW50TW9kZV0gPSB1c2VTdGF0ZShcImNhc2hcIik7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd0ZpbHRlckZpZWxkLCBzZXRTaG93RmlsdGVyRmllbGRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZExhYmVsLCBzZXRTZWxlY3RlZExhYmVsXSA9IHVzZVN0YXRlKFwiVG9kYXlcIik7XHJcblxyXG4gIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCk7XHJcbiAgY29uc3Qgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgIHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpO1xyXG4gIH07XHJcbiAgY29uc3QgdG9kYXlTdHJpbmcgPSBub3cudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcbiAgY29uc3QgW3NlbGVjdGVkRnJvbURhdGUsIHNldFNlbGVjdGVkRnJvbURhdGVdID0gdXNlU3RhdGUodG9kYXlTdHJpbmcpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZERhdGUsIHNldFNlbGVjdGVkRGF0ZV0gPSB1c2VTdGF0ZSh0b2RheVN0cmluZyk7XHJcbiAgY29uc3QgW3NlbGVjdGVkUGF5bWVudE1vZGUsIHNldFNlbGVjdGVkUGF5bWVudE1vZGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2hpZGVBY2NvdW50VHlwZSwgc2V0SGlkZUFjY291bnRUeXBlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEFjY291bnRUeXBlLCBzZXRTZWxlY3RlZEFjY291bnRUeXBlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEN1c3RvbWVycywgc2V0U2VsZWN0ZWRDdXN0b21lcnNdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3BheW1lbnRzLCBzZXRQYXltZW50c10gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2hvd0FsbFBheW1lbnRNb2Rlcywgc2V0U2hvd0FsbFBheW1lbnRNb2Rlc10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBncm91cF9pZDogXCJcIixcclxuICAgIHVzZXJfaWQ6IFwiXCIsXHJcbiAgICB0aWNrZXQ6IFwiXCIsXHJcbiAgICByZWNlaXB0X25vOiBcIlwiLFxyXG4gICAgcGF5X2RhdGU6IFwiXCIsXHJcbiAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICBwYXlfdHlwZTogXCJjYXNoXCIsXHJcbiAgICB0cmFuc2FjdGlvbl9pZDogXCJcIixcclxuICB9KTtcclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IGhhbmRsZU1vZGFsQ2xvc2UgPSAoKSA9PiBzZXRTaG93VXBsb2FkTW9kYWwoZmFsc2UpO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB1c2VyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgY29uc3QgdXNlck9iaiA9IEpTT04ucGFyc2UodXNlcik7XHJcblxyXG4gICAgaWYgKFxyXG4gICAgICB1c2VyT2JqICYmXHJcbiAgICAgIHVzZXJPYmouYWRtaW5fYWNjZXNzX3JpZ2h0X2lkPy5hY2Nlc3NfcGVybWlzc2lvbnM/LmVkaXRfcGF5bWVudFxyXG4gICAgKSB7XHJcbiAgICAgIGNvbnN0IHNob3dQYXltZW50c01vZGVzID1cclxuICAgICAgICB1c2VyT2JqLmFkbWluX2FjY2Vzc19yaWdodF9pZD8uYWNjZXNzX3Blcm1pc3Npb25zPy5lZGl0X3BheW1lbnQgPT09XHJcbiAgICAgICAgXCJ0cnVlXCJcclxuICAgICAgICAgID8gdHJ1ZVxyXG4gICAgICAgICAgOiBmYWxzZTtcclxuICAgICAgc2V0U2hvd0FsbFBheW1lbnRNb2RlcyhzaG93UGF5bWVudHNNb2Rlcyk7XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgIGNvbnN0IHVzZXIgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICAgIGNvbnN0IHVzZXJPYmogPSBKU09OLnBhcnNlKHVzZXIpO1xyXG4gIFxyXG4gICAgICBpZiAoXHJcbiAgICAgICAgdXNlck9iaiAmJlxyXG4gICAgICAgIHVzZXJPYmouYWRtaW5fYWNjZXNzX3JpZ2h0X2lkPy5hY2Nlc3NfcGVybWlzc2lvbnM/LmVkaXRfcGF5bWVudFxyXG4gICAgICApIHtcclxuICAgICAgICBjb25zdCBpc01vZGlmeSA9XHJcbiAgICAgICAgICB1c2VyT2JqLmFkbWluX2FjY2Vzc19yaWdodF9pZD8uYWNjZXNzX3Blcm1pc3Npb25zPy5lZGl0X3BheW1lbnQgPT09XHJcbiAgICAgICAgICBcInRydWVcIlxyXG4gICAgICAgICAgICA/IHRydWVcclxuICAgICAgICAgICAgOiBmYWxzZTtcclxuICAgICAgICBzZXRIaWRlQWNjb3VudFR5cGUoaXNNb2RpZnkpO1xyXG4gICAgICB9XHJcbiAgICB9LCBbXSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgICAgc2V0R3JvdXBzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFtdKTtcclxuXHJcblxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hHcm91cHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRVc2VycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hHcm91cHMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAocmVjZWlwdE5vKSB7XHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgICByZWNlaXB0X25vOiByZWNlaXB0Tm8ucmVjZWlwdF9ubyxcclxuICAgICAgfSkpO1xyXG4gICAgfVxyXG4gIH0sIFtyZWNlaXB0Tm9dKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2VVc2VyID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgY29uc3QgW3VzZXJfaWQsIHRpY2tldF0gPSB2YWx1ZS5zcGxpdChcIi1cIik7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICB1c2VyX2lkLFxyXG4gICAgICB0aWNrZXQsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3JvdXAgPSBhc3luYyAoZXZlbnQpID0+IHtcclxuICAgIGNvbnN0IGdyb3VwSWQgPSBldmVudC50YXJnZXQudmFsdWU7XHJcbiAgICBzZXRTZWxlY3RlZEdyb3VwSWQoZ3JvdXBJZCk7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkZvcm1EYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2Rm9ybURhdGEsXHJcbiAgICAgIGdyb3VwX2lkOiBncm91cElkLFxyXG4gICAgfSkpO1xyXG5cclxuICAgIGhhbmRsZUdyb3VwQ2hhbmdlKGdyb3VwSWQpO1xyXG5cclxuICAgIGlmIChncm91cElkKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvZ3JvdXAvZ2V0LWJ5LWlkLWdyb3VwLyR7Z3JvdXBJZH1gKTtcclxuICAgICAgICBzZXRHcm91cEluZm8ocmVzcG9uc2UuZGF0YSB8fCB7fSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGdyb3VwIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRHcm91cEluZm8oe30pO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRHcm91cEluZm8oe30pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdyb3VwT3B0aW9ucyA9IFtcclxuICAgIHsgdmFsdWU6IFwiVG9kYXlcIiwgbGFiZWw6IFwiVG9kYXlcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJZZXN0ZXJkYXlcIiwgbGFiZWw6IFwiWWVzdGVyZGF5XCIgfSxcclxuICAgIHsgdmFsdWU6IFwiVGhpc01vbnRoXCIsIGxhYmVsOiBcIlRoaXMgTW9udGhcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJMYXN0TW9udGhcIiwgbGFiZWw6IFwiTGFzdCBNb250aFwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIlRoaXNZZWFyXCIsIGxhYmVsOiBcIlRoaXMgWWVhclwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIkN1c3RvbVwiLCBsYWJlbDogXCJDdXN0b21cIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUdyb3VwUGF5bWVudCA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICAvLyBjb25zdCBncm91cElkID0gZXZlbnQudGFyZ2V0LnZhbHVlO1xyXG4gICAgc2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBJZChncm91cElkKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTZWxlY3RGaWx0ZXIgPSAodmFsdWUpID0+IHtcclxuICAgIHNldFNlbGVjdGVkTGFiZWwodmFsdWUpO1xyXG4gICAgLy9jb25zdCB7IHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFNob3dGaWx0ZXJGaWVsZChmYWxzZSk7XHJcblxyXG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlKSA9PiBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUNBXCIpO1xyXG5cclxuICAgIGlmICh2YWx1ZSA9PT0gXCJUb2RheVwiKSB7XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdERhdGUodG9kYXkpO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdHRlZCk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXR0ZWQpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJZZXN0ZXJkYXlcIikge1xyXG4gICAgICBjb25zdCB5ZXN0ZXJkYXkgPSBuZXcgRGF0ZSh0b2RheSk7XHJcbiAgICAgIHllc3RlcmRheS5zZXREYXRlKHllc3RlcmRheS5nZXREYXRlKCkgLSAxKTtcclxuICAgICAgY29uc3QgZm9ybWF0dGVkID0gZm9ybWF0RGF0ZSh5ZXN0ZXJkYXkpO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdHRlZCk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXR0ZWQpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzTW9udGhcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpICsgMSwgMCk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiTGFzdE1vbnRoXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpIC0gMSwgMSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDApO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNZZWFyXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAwLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMTEsIDMxKTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJDdXN0b21cIikge1xyXG4gICAgICBzZXRTaG93RmlsdGVyRmllbGQodHJ1ZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuICBjb25zdCBmb3JtYXRQYXlEYXRlID0gKGRhdGVTdHJpbmcpID0+IHtcclxuICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZShkYXRlU3RyaW5nKTtcclxuICAgIGNvbnN0IG9wdGlvbnMgPSB7IGRheTogXCJudW1lcmljXCIsIG1vbnRoOiBcImxvbmdcIiwgeWVhcjogXCJudW1lcmljXCIgfTtcclxuICAgIHJldHVybiBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLVVTXCIsIG9wdGlvbnMpLnJlcGxhY2UoXCIsXCIsIFwiXCIpO1xyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBhYm9ydENvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XHJcbiAgICBjb25zdCBmZXRjaFBheW1lbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9yZWdpc3RyYXRpb24tZmVlL2RhdGVzYCwge1xyXG4gICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgIGZyb21fZGF0ZTogc2VsZWN0ZWRGcm9tRGF0ZSxcclxuICAgICAgICAgICAgdG9fZGF0ZTogc2VsZWN0ZWREYXRlLFxyXG4gICAgICAgICAgICBncm91cElkOiBzZWxlY3RlZEF1Y3Rpb25Hcm91cElkLFxyXG4gICAgICAgICAgICB1c2VySWQ6IHNlbGVjdGVkQ3VzdG9tZXJzLFxyXG4gICAgICAgICAgICBwYXlfdHlwZTogc2VsZWN0ZWRQYXltZW50TW9kZSxcclxuICAgICAgICAgICAgYWNjb3VudF90eXBlOiBzZWxlY3RlZEFjY291bnRUeXBlLFxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBzaWduYWw6YWJvcnRDb250cm9sbGVyLnNpZ25hbFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGNvbnNvbGUuaW5mbyhyZXNwb25zZS5kYXRhLCBcInRlc3RpbmcgYWNjb3VudCB0eXBlXCIpXHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBjb25zdCB2YWxpZFBheW1lbnRzID0gcmVzcG9uc2UuZGF0YS5maWx0ZXIoXHJcbiAgICAgICAgICAgIChwYXltZW50KSA9PiBwYXltZW50Lmdyb3VwX2lkICE9PSBudWxsXHJcbiAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbih2YWxpZFBheW1lbnRzKTtcclxuXHJcbiAgICAgICAgICBjb25zdCB0b3RhbEFtb3VudCA9IHZhbGlkUGF5bWVudHMucmVkdWNlKFxyXG4gICAgICAgICAgICAoc3VtLCBwYXltZW50KSA9PiBzdW0gKyBOdW1iZXIocGF5bWVudC5hbW91bnQgfHwgMCksXHJcbiAgICAgICAgICAgIDBcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgICBjb25zb2xlLmluZm8odG90YWxBbW91bnQsXCJjaGVjayBhbW91bnRcIik7XHJcbiAgICAgICAgICBzZXRQYXltZW50cyh0b3RhbEFtb3VudCk7XHJcblxyXG4gICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHZhbGlkUGF5bWVudHMubWFwKChncm91cCwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICAgIF9pZDogZ3JvdXA/Ll9pZCxcclxuICAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgZGF0ZTogZ3JvdXA/LnBheV9kYXRlLFxyXG4gICAgICAgICAgICBncm91cDogZ3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IGdyb3VwLnBheV9mb3IsXHJcbiAgICAgICAgICAgIG5hbWU6IGdyb3VwPy51c2VyX2lkPy5mdWxsX25hbWUsXHJcbiAgICAgICAgICAgIGNhdGVnb3J5OiBncm91cD8ucGF5X2ZvciB8fCBcIkNoaXRcIixcclxuICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBncm91cD8udXNlcl9pZD8ucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgICAgICByZWNlaXB0X25vOiBncm91cD8ucmVjZWlwdF9ubyxcclxuICAgICAgICAgICAgb2xkX3JlY2VpcHRfbm86IGdyb3VwPy5vbGRfcmVjZWlwdF9ubyxcclxuICAgICAgICAgICAgdGlja2V0OiBncm91cD8udGlja2V0LFxyXG4gICAgICAgICAgICBhbW91bnQ6IGdyb3VwPy5hbW91bnQsXHJcbiAgICAgICAgICAgIHRyYW5zYWN0aW9uX2RhdGU6IGdyb3VwPy5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKT8uWzBdLFxyXG4gICAgICAgICAgICBtb2RlOiBncm91cD8ucGF5X3R5cGUsXHJcbiAgICAgICAgICAgIGFjY291bnRfdHlwZTogZ3JvdXA/LmFjY291bnRfdHlwZSxcclxuICAgICAgICAgICAgY29sbGVjdGVkX2J5OlxyXG4gICAgICAgICAgICAgIGdyb3VwPy5jb2xsZWN0ZWRfYnk/Lm5hbWUgfHxcclxuICAgICAgICAgICAgICBncm91cD8uYWRtaW5fdHlwZT8uYWRtaW5fbmFtZSB8fFxyXG4gICAgICAgICAgICAgIFwiU3VwZXIgQWRtaW5cIixcclxuICAgICAgICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgICAgdHJpZ2dlcj17W1wiY2xpY2tcIl19XHJcbiAgICAgICAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e2AvcHJpbnQvJHtncm91cC5faWR9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTYwMCBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByaW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApLFxyXG4gICAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICAgIHNldFRhYmxlRGF5Ym9vayhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHBheW1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICAgICAgc2V0UGF5bWVudHMoMCk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaFBheW1lbnRzKCk7XHJcbiAgICAgcmV0dXJuICgpPT57XHJcbiAgICAgICAgYWJvcnRDb250cm9sbGVyLmFib3J0KCk7XHJcbiAgICAgIH1cclxuICB9LCBbXHJcbiAgICBzZWxlY3RlZEF1Y3Rpb25Hcm91cElkLFxyXG4gICAgc2VsZWN0ZWREYXRlLFxyXG4gICAgc2VsZWN0ZWRQYXltZW50TW9kZSxcclxuICAgIHNlbGVjdGVkQ3VzdG9tZXJzLFxyXG4gICAgc2VsZWN0ZWRGcm9tRGF0ZSxcclxuICAgIHNlbGVjdGVkQWNjb3VudFR5cGUsXHJcbiAgXSk7XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImRhdGVcIiwgaGVhZGVyOiBcIlBhaWQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0cmFuc2FjdGlvbl9kYXRlXCIsIGhlYWRlcjogXCJUcmFuc2FjdGlvbiBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY2F0ZWdvcnlcIiwgaGVhZGVyOiBcIkNhdGVnb3J5XCIgfSxcclxuICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcInJlY2VpcHRfbm9cIiwgaGVhZGVyOiBcIlJlY2VpcHQgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcIm9sZF9yZWNlaXB0X25vXCIsIGhlYWRlcjogXCJPbGQgUmVjZWlwdFwiIH0sXHJcbiAgICB7IGtleTogXCJ0aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwiIH0sXHJcbiAgICB7IGtleTogXCJhbW91bnRcIiwgaGVhZGVyOiBcIkFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJtb2RlXCIsIGhlYWRlcjogXCJQYXltZW50IE1vZGVcIiB9LFxyXG4gICAgLi4uKGhpZGVBY2NvdW50VHlwZVxyXG4gICAgPyBbeyBrZXk6IFwiYWNjb3VudF90eXBlXCIsIGhlYWRlcjogXCJBY2NvdW50IFR5cGVcIiB9XTogW10pLFxyXG4gICAgeyBrZXk6IFwiY29sbGVjdGVkX2J5XCIsIGhlYWRlcjogXCJDb2xsZWN0ZWQgQnlcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoZ3JvdXBJbmZvICYmIGZvcm1EYXRhLmJpZF9hbW91bnQpIHtcclxuICAgICAgY29uc3QgY29tbWlzc2lvbiA9IChncm91cEluZm8uZ3JvdXBfdmFsdWUgKiA1KSAvIDEwMCB8fCAwO1xyXG4gICAgICBjb25zdCB3aW5fYW1vdW50ID1cclxuICAgICAgICAoZ3JvdXBJbmZvLmdyb3VwX3ZhbHVlIHx8IDApIC0gKGZvcm1EYXRhLmJpZF9hbW91bnQgfHwgMCk7XHJcbiAgICAgIGNvbnN0IGRpdmlkZW50ID0gKGZvcm1EYXRhLmJpZF9hbW91bnQgfHwgMCkgLSBjb21taXNzaW9uO1xyXG4gICAgICBjb25zdCBkaXZpZGVudF9oZWFkID0gZ3JvdXBJbmZvLmdyb3VwX21lbWJlcnNcclxuICAgICAgICA/IGRpdmlkZW50IC8gZ3JvdXBJbmZvLmdyb3VwX21lbWJlcnNcclxuICAgICAgICA6IDA7XHJcbiAgICAgIGNvbnN0IHBheWFibGUgPSAoZ3JvdXBJbmZvLmdyb3VwX2luc3RhbGwgfHwgMCkgLSBkaXZpZGVudF9oZWFkO1xyXG5cclxuICAgICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICAgIGdyb3VwX2lkOiBncm91cEluZm8uX2lkLFxyXG4gICAgICAgIGNvbW1pc3Npb24sXHJcbiAgICAgICAgd2luX2Ftb3VudCxcclxuICAgICAgICBkaXZpZGVudCxcclxuICAgICAgICBkaXZpZGVudF9oZWFkLFxyXG4gICAgICAgIHBheWFibGUsXHJcbiAgICAgIH0pKTtcclxuICAgIH1cclxuICB9LCBbZ3JvdXBJbmZvLCBmb3JtRGF0YS5iaWRfYW1vdW50XSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVBheW1lbnRNb2RlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHNlbGVjdGVkTW9kZSA9IGUudGFyZ2V0LnZhbHVlO1xyXG4gICAgc2V0UGF5bWVudE1vZGUoc2VsZWN0ZWRNb2RlKTtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIHBheV90eXBlOiBzZWxlY3RlZE1vZGUsXHJcbiAgICAgIHRyYW5zYWN0aW9uX2lkOiBzZWxlY3RlZE1vZGUgPT09IFwib25saW5lXCIgPyBwcmV2RGF0YS50cmFuc2FjdGlvbl9pZCA6IFwiXCIsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoXCIvcGF5bWVudC9hZGQtcGF5bWVudFwiLCBmb3JtRGF0YSk7XHJcbiAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDIwMSkge1xyXG4gICAgICAgIGFsZXJ0KFwiUGF5bWVudCBBZGRlZCBTdWNjZXNzZnVsbHlcIik7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHN1Ym1pdHRpbmcgcGF5bWVudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlTW9kYWxPcGVuID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3BheW1lbnQvZ2V0LXBheW1lbnQtYnktaWQvJHtncm91cElkfWApO1xyXG4gICAgICBzZXRDdXJyZW50R3JvdXAocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFNob3dNb2RhbERlbGV0ZSh0cnVlKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbnJvbGw6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVBdWN0aW9uID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKGN1cnJlbnRHcm91cCkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGF3YWl0IGFwaS5kZWxldGUoYC9wYXltZW50L2RlbGV0ZS1wYXltZW50LyR7Y3VycmVudEdyb3VwLl9pZH1gKTtcclxuICAgICAgICBhbGVydChcIlBheW1lbnQgZGVsZXRlZCBzdWNjZXNzZnVsbHlcIik7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICBzZXRDdXJyZW50R3JvdXAobnVsbCk7XHJcbiAgICAgICAgd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBkZWxldGluZyBhdWN0aW9uOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGVNb2RhbE9wZW4gPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvYXVjdGlvbi9nZXQtYXVjdGlvbi1ieS1pZC8ke2dyb3VwSWR9YCk7XHJcbiAgICAgIHNldEN1cnJlbnRVcGRhdGVHcm91cChyZXNwb25zZS5kYXRhKTtcclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGF1Y3Rpb246XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVGaWxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgICBjb25zdCBmb3JtRGF0YXMgPSBuZXcgRm9ybURhdGEoKTtcclxuICAgIGNvbnN0IGZpbGVJbnB1dCA9IGUudGFyZ2V0LmZpbGU7XHJcbiAgICBpZiAoZmlsZUlucHV0ICYmIGZpbGVJbnB1dC5maWxlc1swXSkge1xyXG4gICAgICBmb3JtRGF0YXMuYXBwZW5kKFwiZmlsZVwiLCBmaWxlSW5wdXQuZmlsZXNbMF0pO1xyXG5cclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KGAvcGF5bWVudC9wYXltZW50LWV4Y2VsYCwgZm9ybURhdGFzLCB7XHJcbiAgICAgICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwibXVsdGlwYXJ0L2Zvcm0tZGF0YVwiIH0sXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDIwMCkge1xyXG4gICAgICAgICAgYWxlcnQoXCJGaWxlIHVwbG9hZGVkIHN1Y2Nlc3NmdWxseSFcIik7XHJcbiAgICAgICAgICB3aW5kb3cubG9jYXRpb24ucmVsb2FkKCk7XHJcbiAgICAgICAgICBzZXRTaG93VXBsb2FkTW9kYWwoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBsb2FkaW5nIGZpbGU6XCIsIGVycm9yKTtcclxuICAgICAgICBhbGVydChcIkZhaWxlZCB0byB1cGxvYWQgZmlsZS5cIik7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGFsZXJ0KFwiUGxlYXNlIHNlbGVjdCBhIGZpbGUgdG8gdXBsb2FkLlwiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG10LTMwXCI+XHJcbiAgICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxDdXN0b21BbGVydFxyXG4gICAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbiAgICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGRcIj5SZWdpc3RyYXRpb24gUmVjZWlwdCBSZXBvcnQ8L2gxPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktc3RhcnQgaXRlbXMtY2VudGVyIHctZnVsbCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWw+RmlsdGVyIE9wdGlvbjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVNlbGVjdEZpbHRlcn1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZExhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggT3IgU2VsZWN0IEZpbHRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXcteHMgaC0xMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2dyb3VwT3B0aW9ucy5tYXAoKHRpbWUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt0aW1lLnZhbHVlfSB2YWx1ZT17dGltZS52YWx1ZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3RpbWUubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAge3Nob3dGaWx0ZXJGaWVsZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPkZyb20gRGF0ZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRGcm9tRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkRnJvbURhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC00IHB5LTIgc2hhZG93LXNtIG91dGxpbmUtbm9uZSB3LWZ1bGwgbWF4LXcteHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPlRvIERhdGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTQgcHktMiBzaGFkb3ctc20gb3V0bGluZS1ub25lIHctZnVsbCBtYXgtdy14c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsPkdyb3VwPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICB7LyogPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQXVjdGlvbkdyb3VwSWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlR3JvdXBQYXltZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTYgcHktMiBzaGFkb3ctc20gb3V0bGluZS1ub25lIHctZnVsbCBtYXgtdy1tZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPkFsbCA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cHMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEF1Y3Rpb25Hcm91cElkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUdyb3VwUGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIE9yIFNlbGVjdCBHcm91cFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXcteHMgaC0xMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9e1wiXCJ9PkFsbDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cHMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsPkN1c3RvbWVyPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICB7LyogPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQ3VzdG9tZXJzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZEN1c3RvbWVycyhlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNiBweS0yIHNoYWRvdy1zbSBvdXRsaW5lLW5vbmUgdy1mdWxsIG1heC13LW1kXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+QWxsPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRVc2Vycy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtncm91cD8uX2lkfSB2YWx1ZT17Z3JvdXA/Ll9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwPy5mdWxsX25hbWV9IC0ge2dyb3VwLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEN1c3RvbWVyc31cclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIE9yIFNlbGVjdCBDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGdyb3VwSWQpID0+IHNldFNlbGVjdGVkQ3VzdG9tZXJzKGdyb3VwSWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LXhzIGgtMTFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTYgcHktMiBzaGFkb3ctc20gb3V0bGluZS1ub25lIHctZnVsbCBtYXgtdy1tZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGw8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRVc2Vycy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXA/Ll9pZH0gdmFsdWU9e2dyb3VwPy5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cD8uZnVsbF9uYW1lfSAtIHtncm91cC5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsPlBheW1lbnQgTW9kZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFBheW1lbnRNb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZFBheW1lbnRNb2RlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC02IHB5LTIgc2hhZG93LXNtIG91dGxpbmUtbm9uZSB3LWZ1bGwgbWF4LXctbWRcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5BbGw8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjYXNoXCI+Q2FzaDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm9ubGluZVwiPk9ubGluZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PiAqL31cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRQYXltZW50TW9kZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIE9yIFNlbGVjdCBQYXltZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGdyb3VwSWQpID0+IHNldFNlbGVjdGVkUGF5bWVudE1vZGUoZ3JvdXBJZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXcteHMgaC0xMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvLyBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNiBweS0yIHNoYWRvdy1zbSBvdXRsaW5lLW5vbmUgdy1mdWxsIG1heC13LW1kXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPkFsbDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiY2FzaFwiPkNhc2g8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlBheW1lbnQgTGlua1wiPk9ubGluZSB8IFBheW1lbnQgTGluazwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwib25saW5lXCI+T25saW5lPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAge3Nob3dBbGxQYXltZW50TW9kZXMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWw+QWNjb3VudCBUeXBlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICB7LyogPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkUGF5bWVudE1vZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkUGF5bWVudE1vZGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTYgcHktMiBzaGFkb3ctc20gb3V0bGluZS1ub25lIHctZnVsbCBtYXgtdy1tZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPkFsbDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNhc2hcIj5DYXNoPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwib25saW5lXCI+T25saW5lPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEFjY291bnRUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggT3IgU2VsZWN0IEFjY291bnQgVHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhncm91cElkKSA9PiBzZXRTZWxlY3RlZEFjY291bnRUeXBlKGdyb3VwSWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LXhzIGgtMTFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTYgcHktMiBzaGFkb3ctc20gb3V0bGluZS1ub25lIHctZnVsbCBtYXgtdy1tZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBBY2NvdW50IFR5cGU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwic3VzcGVuc2VcIj5TdXNwZW5zZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjcmVkaXRcIj5DcmVkaXQ8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWRqdXN0bWVudFwiPkFkanVzdG1lbnQ8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwib3RoZXJzXCI+T3RoZXJzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LW1kIG10LTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIEFtb3VudDp7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsXCI+4oK5e3BheW1lbnRzIHx8IDB9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAge2ZpbHRlcmVkQXVjdGlvbiAmJiBmaWx0ZXJlZEF1Y3Rpb24ubGVuZ3RoID4gMCAmJiAhaXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKFRhYmxlRGF5Ym9vaywgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9e2BSZWdpc3RyYXRpb24gUmVjZWlwdCBSZXBvcnRgfVxyXG4gICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BSZWdpc3RyYXRpb24gUmVjZWlwdC5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgbXQtNCBwci00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBBbW91bnQ6IOKCuXtwYXltZW50c31cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTAgdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICBmYWlsdXJlPXtmaWx0ZXJlZEF1Y3Rpb24ubGVuZ3RoIDw9IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YT1cIlJlY2VpcHQgRGF0YVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPE1vZGFsIGlzVmlzaWJsZT17c2hvd01vZGFsfSBvbkNsb3NlPXsoKSA9PiBzZXRTaG93TW9kYWwoZmFsc2UpfT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICBBZGQgUGF5bWVudFxyXG4gICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEdyb3VwXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRHcm91cElkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVHcm91cH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IEdyb3VwPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAge2dyb3Vwcy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXJzXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwidXNlcl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Ake2Zvcm1EYXRhLnVzZXJfaWR9LSR7Zm9ybURhdGEudGlja2V0fWB9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZVVzZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IEN1c3RvbWVyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkVXNlcnMubWFwKCh1c2VyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17YCR7dXNlcj8udXNlcl9pZD8uX2lkfS0ke3VzZXIudGlja2V0c31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YCR7dXNlcj8udXNlcl9pZD8uX2lkfS0ke3VzZXIudGlja2V0c31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dXNlcj8udXNlcl9pZD8uZnVsbF9uYW1lfSB8IHt1c2VyLnRpY2tldHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cF92YWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUmVjZWlwdCBOby5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInJlY2VpcHRfbm9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnJlY2VpcHRfbm99XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInJlY2VpcHRfbm9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJSZWNlaXB0IE5vLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZ3JvdXBfaW5zdGFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXlfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGF5X2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInBheV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cF92YWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJwYXlfbW9kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBNb2RlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGF5X21vZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJwYXlfbW9kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlUGF5bWVudE1vZGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNhc2hcIj5DYXNoPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwib25saW5lXCI+T25saW5lPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICB7cGF5bWVudE1vZGUgPT09IFwib25saW5lXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwidHJhbnNhY3Rpb25faWRcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFRyYW5zYWN0aW9uIElEXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0cmFuc2FjdGlvbl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInRyYW5zYWN0aW9uX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS50cmFuc2FjdGlvbl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFRyYW5zYWN0aW9uIElEXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC13aGl0ZSBiZy12aW9sZXQtNzAwIGhvdmVyOmJnLXZpb2xldC04MDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLXZpb2xldC0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQWRkXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbFVwZGF0ZX1cclxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICBWaWV3IEF1Y3Rpb25cclxuICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXsoKSA9PiB7fX0+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEdyb3VwXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3JvdXBfaWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50VXBkYXRlR3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiB7fX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEdyb3VwIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZ3JvdXBfdmFsdWVcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIEdyb3VwIFZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF92YWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudFVwZGF0ZUdyb3VwPy5ncm91cF9pZD8uZ3JvdXBfdmFsdWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImdyb3VwX3ZhbHVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwic2VsZWN0IGdyb3VwIHRvIGNoZWNrXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cF9pbnN0YWxsXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBHcm91cCBJbnN0YWxsbWVudFxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3JvdXBfaW5zdGFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudFVwZGF0ZUdyb3VwPy5ncm91cF9pZD8uZ3JvdXBfaW5zdGFsbH1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZ3JvdXBfaW5zdGFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cInNlbGVjdCBncm91cCB0byBjaGVja1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFVzZXJcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Ake2N1cnJlbnRVcGRhdGVHcm91cD8udXNlcl9pZD8uZnVsbF9uYW1lfSB8ICR7Y3VycmVudFVwZGF0ZUdyb3VwPy50aWNrZXR9YH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4ge319XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBVc2VyIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBCaWQgQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJiaWRfYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50VXBkYXRlR3JvdXA/Lmdyb3VwX2lkPy5ncm91cF92YWx1ZSAtXHJcbiAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50VXBkYXRlR3JvdXA/Lndpbl9hbW91bnRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHt9fVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgQmlkIEFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cF92YWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ29tbWlzc2lvblxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29tbWlzc2lvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudFVwZGF0ZUdyb3VwPy5jb21taXNzaW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjb21taXNzaW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cF9pbnN0YWxsXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBXaW5uaW5nIEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwid2luX2Ftb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudFVwZGF0ZUdyb3VwPy53aW5fYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJ3aW5fYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cF92YWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRGl2aWRlbnRcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImRpdmlkZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50VXBkYXRlR3JvdXA/LmRpdmlkZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJkaXZpZGVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZ3JvdXBfaW5zdGFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRGl2aWRlbnQgcGVyIEhlYWRcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImRpdmlkZW50X2hlYWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRVcGRhdGVHcm91cD8uZGl2aWRlbnRfaGVhZH1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZGl2aWRlbnRfaGVhZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZ3JvdXBfaW5zdGFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgTmV4dCBQYXlhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXlhYmxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50VXBkYXRlR3JvdXA/LnBheWFibGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cInBheWFibGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIEF1Y3Rpb24gRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYXVjdGlvbl9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50VXBkYXRlR3JvdXA/LmF1Y3Rpb25fZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiB7fX1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBEYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBOZXh0IERhdGVcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm5leHRfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudFVwZGF0ZUdyb3VwPy5uZXh0X2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4ge319XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgICA8TW9kYWxcclxuICAgICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxEZWxldGV9XHJcbiAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgICBzZXRTaG93TW9kYWxEZWxldGUoZmFsc2UpO1xyXG4gICAgICAgICAgICAgIHNldEN1cnJlbnRHcm91cChudWxsKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICBTdXJlIHdhbnQgdG8gZGVsZXRlIHRoaXMgUGF5bWVudCA/XHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICB7Y3VycmVudEdyb3VwICYmIChcclxuICAgICAgICAgICAgICAgIDxmb3JtXHJcbiAgICAgICAgICAgICAgICAgIG9uU3VibWl0PXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICAgICAgICBoYW5kbGVEZWxldGVBdWN0aW9uKCk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC13aGl0ZSBiZy1yZWQtNzAwIGhvdmVyOmJnLXJlZC04MDBcclxuICAgICAgICAgICAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctdmlvbGV0LTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUmVnaXN0cmF0aW9uRmVlUmVwb3J0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvUmVnaXN0cmF0aW9uRmVlUmVwb3J0LmpzeCJ9