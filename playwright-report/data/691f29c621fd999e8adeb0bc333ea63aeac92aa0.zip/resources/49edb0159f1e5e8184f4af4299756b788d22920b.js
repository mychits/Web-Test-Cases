import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/printFormats/CustomerAcknowledgementPrint.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerAcknowledgementPrint.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import mychitsLogo from "/src/assets/images/mychits.png?import";
const CustomerAcknowledgementPrint = ({ item }) => {
  const handlePrintAcknowledgement = () => {
    const printWindow = window.open("", "_blank", "width=900,height=700");
    if (!printWindow) {
      alert("Please allow pop-ups to print the acknowledgement.");
      return;
    }
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Customer Acknowledgement - ${item.transaction_id}</title>

          <style>
            body {
              font-family: Arial, sans-serif;
              padding: 30px;
              color: #222;
              margin: 0;
            }

            .header {
              display: flex;
              align-items: center;
              justify-content: center;
              gap: 15px;
              border-bottom: 2px solid #222;
              padding-bottom: 15px;
              margin-bottom: 20px;
            }

            .logo {
              width: 50px;
              height: auto;
              object-fit: contain;
            }

            .header-title {
              font-size: 24px;
              font-weight: bold;
            }

            .header p {
              margin: 5px 0 0;
              font-size: 13px;
              color: #666;
            }

            .title {
              text-align: center;
              margin: 10px 0;
              font-size: 20px;
              font-weight: bold;
            }

            .section {
              margin-top: 20px;
            }

            .section-title {
              background: #f3f4f6;
              padding: 10px;
              font-weight: bold;
              border: 1px solid #ddd;
            }

            table {
              width: 100%;
              border-collapse: collapse;
            }

            td {
              border: 1px solid #ddd;
              padding: 10px;
              font-size: 13px;
            }

            td:first-child {
              width: 35%;
              font-weight: bold;
              background: #fafafa;
            }

            .amount {
              font-size: 18px;
              font-weight: bold;
            }

            .footer {
              margin-top: 50px;
              display: flex;
              justify-content: space-between;
              font-size: 13px;
            }

            .company-footer {
              margin-top: 30px;
              background-color: #00267C;
              color: #fff;
              padding: 10px 0;
              text-align: center;
              font-size: 8px;
              line-height: 1.6;
              margin-left: -30px;
              margin-right: -30px;
              margin-bottom: -30px;
              border-bottom-left-radius: 8px;
              border-bottom-right-radius: 8px;
            }

            .company-footer .company-name {
              font-weight: bold;
              font-size: 9px;
              color: #d4af37;
            }

            @media print {
              body {
                padding: 15px;
              }

              .company-footer {
                margin-left: -15px;
                margin-right: -15px;
                margin-bottom: -15px;
              }
            }
          </style>
        </head>

        <body>
          <div class="header">
            <img
              src="${mychitsLogo}"
              alt="Company Logo"
              class="logo"
            />
            <span class="header-title">Customer Acknowledgement</span>
          </div>

          <div class="title">
            Transaction Details
          </div>

          <div class="section">
            <div class="section-title">
              Customer Details
            </div>

            <table>
              <tr>
                <td>Customer Name</td>
                <td>${item.full_name}</td>
              </tr>

              <tr>
                <td>Phone Number</td>
                <td>${item.phone_number}</td>
              </tr>

              <tr>
                <td>Transaction ID</td>
                <td>${item.transaction_id}</td>
              </tr>

              <tr>
                <td>Transaction Date</td>
                <td>${item.transaction_date}</td>
              </tr>
            </table>
          </div>

          <div class="section">
            <div class="section-title">
              Transaction Information
            </div>

            <table>
              <tr>
                <td>Transaction Type</td>
                <td>${item.transaction_type}</td>
              </tr>

              <tr>
                <td>Reason</td>
                <td>${item.reason}</td>
              </tr>

              <tr>
                <td>Gross Amount</td>
                <td class="amount">₹${item.gross_amount}</td>
              </tr>

              <tr>
                <td>Amount</td>
                <td>₹${item.amount}</td>
              </tr>

              <tr>
                <td>Interest Amount</td>
                <td>₹${item.interest_amount}</td>
              </tr>

              <tr>
                <td>Service Charge</td>
                <td>₹${item.service_charge}</td>
              </tr>

              <tr>
                <td>GST Amount</td>
                <td>₹${item.gst_amount}</td>
              </tr>

              <tr>
                <td>Remarks</td>
                <td>${item.remarks}</td>
              </tr>
            </table>
          </div>

          ${item.group_name !== "-" ? `
                <div class="section">
                  <div class="section-title">
                    Chit Details
                  </div>

                  <table>
                    <tr>
                      <td>Group Name</td>
                      <td>${item.group_name}</td>
                    </tr>

                    <tr>
                      <td>Enrollment Code</td>
                      <td>${item.enroll_code}</td>
                    </tr>

                    <tr>
                      <td>Tickets</td>
                      <td>${item.tickets}</td>
                    </tr>

                    <tr>
                      <td>Payment Type</td>
                      <td>${item.payment_type}</td>
                    </tr>
                  </table>
                </div>
              ` : ""}

          ${item.pigme_id !== "-" ? `
                <div class="section">
                  <div class="section-title">
                    Pigmy Details
                  </div>

                  <table>
                    <tr>
                      <td>Pigmy ID</td>
                      <td>${item.pigme_id}</td>
                    </tr>

                    <tr>
                      <td>Request Status</td>
                      <td>${item.request_status}</td>
                    </tr>

                    <tr>
                      <td>Closure Type</td>
                      <td>${item.closure_type}</td>
                    </tr>
                  </table>
                </div>
              ` : ""}

          <div class="footer">
            <div>
              Prepared By: ${item.admin_name}
            </div>

            <div>
              Customer Signature: ____________________
            </div>
          </div>

          <div class="company-footer">
            <div class="company-name">
              VIJAYA VINAYAK CHIT FUNDS PRIVATE LIMITED
            </div>

            <div>
              #11/36-25, 3rd Floor, 2nd Main, Kathriguppe Main Road,
              Banashankari 3rd Stage, Bengaluru-560085
            </div>

            <div>
              Mob: 9483900777 | Ph: 080-4979 8763 |
              Email: info.mychits@gmail.com | www.mychits.co.in
            </div>
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.onload = () => {
      printWindow.focus();
      printWindow.print();
      printWindow.close();
    };
  };
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: "text-blue-600 font-medium cursor-pointer",
      onClick: handlePrintAcknowledgement,
      children: "Print"
    },
    void 0,
    false,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerAcknowledgementPrint.jsx",
      lineNumber: 328,
      columnNumber: 5
    },
    this
  );
};
_c = CustomerAcknowledgementPrint;
export default CustomerAcknowledgementPrint;
var _c;
$RefreshReg$(_c, "CustomerAcknowledgementPrint");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerAcknowledgementPrint.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerAcknowledgementPrint.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdVVJO0FBdlVKLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixPQUFPQyxpQkFBaUI7QUFFeEIsTUFBTUMsK0JBQStCQSxDQUFDLEVBQUVDLEtBQUssTUFBTTtBQUNqRCxRQUFNQyw2QkFBNkJBLE1BQU07QUFDdkMsVUFBTUMsY0FBY0MsT0FBT0MsS0FBSyxJQUFJLFVBQVUsc0JBQXNCO0FBRXBFLFFBQUksQ0FBQ0YsYUFBYTtBQUNoQkcsWUFBTSxvREFBb0Q7QUFDMUQ7QUFBQSxJQUNGO0FBRUFILGdCQUFZSSxTQUFTQyxNQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUEsOENBSWVQLEtBQUtRLGNBQWM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTBINUNWLFdBQVc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFtQlZFLEtBQUtTLFNBQVM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUtkVCxLQUFLVSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFLakJWLEtBQUtRLGNBQWM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUtuQlIsS0FBS1csZ0JBQWdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBYXJCWCxLQUFLWSxnQkFBZ0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUtyQlosS0FBS2EsTUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0NBS0tiLEtBQUtjLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtoQ2QsS0FBS2UsTUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS1hmLEtBQUtnQixlQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLcEJoQixLQUFLaUIsY0FBYztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS25CakIsS0FBS2tCLFVBQVU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUtoQmxCLEtBQUttQixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU10Qm5CLEtBQUtvQixlQUFlLE1BQ2hCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQVNZcEIsS0FBS29CLFVBQVU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQUtmcEIsS0FBS3FCLFdBQVc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQUtoQnJCLEtBQUtzQixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFLWnRCLEtBQUt1QixZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSzdCLEVBQUU7QUFBQTtBQUFBLFlBSU52QixLQUFLd0IsYUFBYSxNQUNkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQVNZeEIsS0FBS3dCLFFBQVE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQUtieEIsS0FBS3lCLGNBQWM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQUtuQnpCLEtBQUswQixZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSzdCLEVBQUU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFLVzFCLEtBQUsyQixVQUFVO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0F5QnZDO0FBRUR6QixnQkFBWUksU0FBU3NCLE1BQU07QUFFM0IxQixnQkFBWTJCLFNBQVMsTUFBTTtBQUN6QjNCLGtCQUFZNEIsTUFBTTtBQUNsQjVCLGtCQUFZNkIsTUFBTTtBQUNsQjdCLGtCQUFZMEIsTUFBTTtBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFdBQVU7QUFBQSxNQUNWLFNBQVMzQjtBQUFBQSxNQUEyQjtBQUFBO0FBQUEsSUFGdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBS0E7QUFFSjtBQUFFK0IsS0EzVUlqQztBQTZVTixlQUFlQTtBQUE2QixJQUFBaUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwibXljaGl0c0xvZ28iLCJDdXN0b21lckFja25vd2xlZGdlbWVudFByaW50IiwiaXRlbSIsImhhbmRsZVByaW50QWNrbm93bGVkZ2VtZW50IiwicHJpbnRXaW5kb3ciLCJ3aW5kb3ciLCJvcGVuIiwiYWxlcnQiLCJkb2N1bWVudCIsIndyaXRlIiwidHJhbnNhY3Rpb25faWQiLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJ0cmFuc2FjdGlvbl9kYXRlIiwidHJhbnNhY3Rpb25fdHlwZSIsInJlYXNvbiIsImdyb3NzX2Ftb3VudCIsImFtb3VudCIsImludGVyZXN0X2Ftb3VudCIsInNlcnZpY2VfY2hhcmdlIiwiZ3N0X2Ftb3VudCIsInJlbWFya3MiLCJncm91cF9uYW1lIiwiZW5yb2xsX2NvZGUiLCJ0aWNrZXRzIiwicGF5bWVudF90eXBlIiwicGlnbWVfaWQiLCJyZXF1ZXN0X3N0YXR1cyIsImNsb3N1cmVfdHlwZSIsImFkbWluX25hbWUiLCJjbG9zZSIsIm9ubG9hZCIsImZvY3VzIiwicHJpbnQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDdXN0b21lckFja25vd2xlZGdlbWVudFByaW50LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBteWNoaXRzTG9nbyBmcm9tIFwiLi4vLi4vYXNzZXRzL2ltYWdlcy9teWNoaXRzLnBuZ1wiO1xyXG5cclxuY29uc3QgQ3VzdG9tZXJBY2tub3dsZWRnZW1lbnRQcmludCA9ICh7IGl0ZW0gfSkgPT4ge1xyXG4gIGNvbnN0IGhhbmRsZVByaW50QWNrbm93bGVkZ2VtZW50ID0gKCkgPT4ge1xyXG4gICAgY29uc3QgcHJpbnRXaW5kb3cgPSB3aW5kb3cub3BlbihcIlwiLCBcIl9ibGFua1wiLCBcIndpZHRoPTkwMCxoZWlnaHQ9NzAwXCIpO1xyXG5cclxuICAgIGlmICghcHJpbnRXaW5kb3cpIHtcclxuICAgICAgYWxlcnQoXCJQbGVhc2UgYWxsb3cgcG9wLXVwcyB0byBwcmludCB0aGUgYWNrbm93bGVkZ2VtZW50LlwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHByaW50V2luZG93LmRvY3VtZW50LndyaXRlKGBcclxuICAgICAgPCFET0NUWVBFIGh0bWw+XHJcbiAgICAgIDxodG1sPlxyXG4gICAgICAgIDxoZWFkPlxyXG4gICAgICAgICAgPHRpdGxlPkN1c3RvbWVyIEFja25vd2xlZGdlbWVudCAtICR7aXRlbS50cmFuc2FjdGlvbl9pZH08L3RpdGxlPlxyXG5cclxuICAgICAgICAgIDxzdHlsZT5cclxuICAgICAgICAgICAgYm9keSB7XHJcbiAgICAgICAgICAgICAgZm9udC1mYW1pbHk6IEFyaWFsLCBzYW5zLXNlcmlmO1xyXG4gICAgICAgICAgICAgIHBhZGRpbmc6IDMwcHg7XHJcbiAgICAgICAgICAgICAgY29sb3I6ICMyMjI7XHJcbiAgICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAuaGVhZGVyIHtcclxuICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgZ2FwOiAxNXB4O1xyXG4gICAgICAgICAgICAgIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCAjMjIyO1xyXG4gICAgICAgICAgICAgIHBhZGRpbmctYm90dG9tOiAxNXB4O1xyXG4gICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5sb2dvIHtcclxuICAgICAgICAgICAgICB3aWR0aDogNTBweDtcclxuICAgICAgICAgICAgICBoZWlnaHQ6IGF1dG87XHJcbiAgICAgICAgICAgICAgb2JqZWN0LWZpdDogY29udGFpbjtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLmhlYWRlci10aXRsZSB7XHJcbiAgICAgICAgICAgICAgZm9udC1zaXplOiAyNHB4O1xyXG4gICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAuaGVhZGVyIHAge1xyXG4gICAgICAgICAgICAgIG1hcmdpbjogNXB4IDAgMDtcclxuICAgICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgICAgICAgY29sb3I6ICM2NjY7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC50aXRsZSB7XHJcbiAgICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICAgIG1hcmdpbjogMTBweCAwO1xyXG4gICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgICAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLnNlY3Rpb24ge1xyXG4gICAgICAgICAgICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5zZWN0aW9uLXRpdGxlIHtcclxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZjNmNGY2O1xyXG4gICAgICAgICAgICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2RkZDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgdGFibGUge1xyXG4gICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICAgIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHRkIHtcclxuICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjZGRkO1xyXG4gICAgICAgICAgICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB0ZDpmaXJzdC1jaGlsZCB7XHJcbiAgICAgICAgICAgICAgd2lkdGg6IDM1JTtcclxuICAgICAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZmFmYWZhO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAuYW1vdW50IHtcclxuICAgICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5mb290ZXIge1xyXG4gICAgICAgICAgICAgIG1hcmdpbi10b3A6IDUwcHg7XHJcbiAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAuY29tcGFueS1mb290ZXIge1xyXG4gICAgICAgICAgICAgIG1hcmdpbi10b3A6IDMwcHg7XHJcbiAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzAwMjY3QztcclxuICAgICAgICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICAgICAgICBwYWRkaW5nOiAxMHB4IDA7XHJcbiAgICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICAgIGZvbnQtc2l6ZTogOHB4O1xyXG4gICAgICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxLjY7XHJcbiAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IC0zMHB4O1xyXG4gICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogLTMwcHg7XHJcbiAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogLTMwcHg7XHJcbiAgICAgICAgICAgICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogOHB4O1xyXG4gICAgICAgICAgICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA4cHg7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5jb21wYW55LWZvb3RlciAuY29tcGFueS1uYW1lIHtcclxuICAgICAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICAgICAgICBmb250LXNpemU6IDlweDtcclxuICAgICAgICAgICAgICBjb2xvcjogI2Q0YWYzNztcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgQG1lZGlhIHByaW50IHtcclxuICAgICAgICAgICAgICBib2R5IHtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDE1cHg7XHJcbiAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAuY29tcGFueS1mb290ZXIge1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IC0xNXB4O1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAtMTVweDtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IC0xNXB4O1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgPC9zdHlsZT5cclxuICAgICAgICA8L2hlYWQ+XHJcblxyXG4gICAgICAgIDxib2R5PlxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImhlYWRlclwiPlxyXG4gICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgc3JjPVwiJHtteWNoaXRzTG9nb31cIlxyXG4gICAgICAgICAgICAgIGFsdD1cIkNvbXBhbnkgTG9nb1wiXHJcbiAgICAgICAgICAgICAgY2xhc3M9XCJsb2dvXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJoZWFkZXItdGl0bGVcIj5DdXN0b21lciBBY2tub3dsZWRnZW1lbnQ8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwidGl0bGVcIj5cclxuICAgICAgICAgICAgVHJhbnNhY3Rpb24gRGV0YWlsc1xyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cInNlY3Rpb25cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNlY3Rpb24tdGl0bGVcIj5cclxuICAgICAgICAgICAgICBDdXN0b21lciBEZXRhaWxzXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPHRhYmxlPlxyXG4gICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgIDx0ZD5DdXN0b21lciBOYW1lPC90ZD5cclxuICAgICAgICAgICAgICAgIDx0ZD4ke2l0ZW0uZnVsbF9uYW1lfTwvdGQ+XHJcbiAgICAgICAgICAgICAgPC90cj5cclxuXHJcbiAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgPHRkPlBob25lIE51bWJlcjwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8dGQ+JHtpdGVtLnBob25lX251bWJlcn08L3RkPlxyXG4gICAgICAgICAgICAgIDwvdHI+XHJcblxyXG4gICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgIDx0ZD5UcmFuc2FjdGlvbiBJRDwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8dGQ+JHtpdGVtLnRyYW5zYWN0aW9uX2lkfTwvdGQ+XHJcbiAgICAgICAgICAgICAgPC90cj5cclxuXHJcbiAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgPHRkPlRyYW5zYWN0aW9uIERhdGU8L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkPiR7aXRlbS50cmFuc2FjdGlvbl9kYXRlfTwvdGQ+XHJcbiAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJzZWN0aW9uXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzZWN0aW9uLXRpdGxlXCI+XHJcbiAgICAgICAgICAgICAgVHJhbnNhY3Rpb24gSW5mb3JtYXRpb25cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8dGFibGU+XHJcbiAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgPHRkPlRyYW5zYWN0aW9uIFR5cGU8L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkPiR7aXRlbS50cmFuc2FjdGlvbl90eXBlfTwvdGQ+XHJcbiAgICAgICAgICAgICAgPC90cj5cclxuXHJcbiAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgPHRkPlJlYXNvbjwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8dGQ+JHtpdGVtLnJlYXNvbn08L3RkPlxyXG4gICAgICAgICAgICAgIDwvdHI+XHJcblxyXG4gICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgIDx0ZD5Hcm9zcyBBbW91bnQ8L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzPVwiYW1vdW50XCI+4oK5JHtpdGVtLmdyb3NzX2Ftb3VudH08L3RkPlxyXG4gICAgICAgICAgICAgIDwvdHI+XHJcblxyXG4gICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgIDx0ZD5BbW91bnQ8L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkPuKCuSR7aXRlbS5hbW91bnR9PC90ZD5cclxuICAgICAgICAgICAgICA8L3RyPlxyXG5cclxuICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICA8dGQ+SW50ZXJlc3QgQW1vdW50PC90ZD5cclxuICAgICAgICAgICAgICAgIDx0ZD7igrkke2l0ZW0uaW50ZXJlc3RfYW1vdW50fTwvdGQ+XHJcbiAgICAgICAgICAgICAgPC90cj5cclxuXHJcbiAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgPHRkPlNlcnZpY2UgQ2hhcmdlPC90ZD5cclxuICAgICAgICAgICAgICAgIDx0ZD7igrkke2l0ZW0uc2VydmljZV9jaGFyZ2V9PC90ZD5cclxuICAgICAgICAgICAgICA8L3RyPlxyXG5cclxuICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICA8dGQ+R1NUIEFtb3VudDwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8dGQ+4oK5JHtpdGVtLmdzdF9hbW91bnR9PC90ZD5cclxuICAgICAgICAgICAgICA8L3RyPlxyXG5cclxuICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICA8dGQ+UmVtYXJrczwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8dGQ+JHtpdGVtLnJlbWFya3N9PC90ZD5cclxuICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgJHtcclxuICAgICAgICAgICAgaXRlbS5ncm91cF9uYW1lICE9PSBcIi1cIlxyXG4gICAgICAgICAgICAgID8gYFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNlY3Rpb25cIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cInNlY3Rpb24tdGl0bGVcIj5cclxuICAgICAgICAgICAgICAgICAgICBDaGl0IERldGFpbHNcclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8dGFibGU+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkPkdyb3VwIE5hbWU8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkPiR7aXRlbS5ncm91cF9uYW1lfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkPkVucm9sbG1lbnQgQ29kZTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQ+JHtpdGVtLmVucm9sbF9jb2RlfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkPlRpY2tldHM8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkPiR7aXRlbS50aWNrZXRzfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkPlBheW1lbnQgVHlwZTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQ+JHtpdGVtLnBheW1lbnRfdHlwZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICBgXHJcbiAgICAgICAgICAgICAgOiBcIlwiXHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgJHtcclxuICAgICAgICAgICAgaXRlbS5waWdtZV9pZCAhPT0gXCItXCJcclxuICAgICAgICAgICAgICA/IGBcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzZWN0aW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzZWN0aW9uLXRpdGxlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUGlnbXkgRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDx0YWJsZT5cclxuICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQ+UGlnbXkgSUQ8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkPiR7aXRlbS5waWdtZV9pZH08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0ZD5SZXF1ZXN0IFN0YXR1czwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQ+JHtpdGVtLnJlcXVlc3Rfc3RhdHVzfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRkPkNsb3N1cmUgVHlwZTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGQ+JHtpdGVtLmNsb3N1cmVfdHlwZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICBgXHJcbiAgICAgICAgICAgICAgOiBcIlwiXHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImZvb3RlclwiPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIFByZXBhcmVkIEJ5OiAke2l0ZW0uYWRtaW5fbmFtZX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIEN1c3RvbWVyIFNpZ25hdHVyZTogX19fX19fX19fX19fX19fX19fX19cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiY29tcGFueS1mb290ZXJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cImNvbXBhbnktbmFtZVwiPlxyXG4gICAgICAgICAgICAgIFZJSkFZQSBWSU5BWUFLIENISVQgRlVORFMgUFJJVkFURSBMSU1JVEVEXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAjMTEvMzYtMjUsIDNyZCBGbG9vciwgMm5kIE1haW4sIEthdGhyaWd1cHBlIE1haW4gUm9hZCxcclxuICAgICAgICAgICAgICBCYW5hc2hhbmthcmkgM3JkIFN0YWdlLCBCZW5nYWx1cnUtNTYwMDg1XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICBNb2I6IDk0ODM5MDA3NzcgfCBQaDogMDgwLTQ5NzkgODc2MyB8XHJcbiAgICAgICAgICAgICAgRW1haWw6IGluZm8ubXljaGl0c0BnbWFpbC5jb20gfCB3d3cubXljaGl0cy5jby5pblxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvYm9keT5cclxuICAgICAgPC9odG1sPlxyXG4gICAgYCk7XHJcblxyXG4gICAgcHJpbnRXaW5kb3cuZG9jdW1lbnQuY2xvc2UoKTtcclxuXHJcbiAgICBwcmludFdpbmRvdy5vbmxvYWQgPSAoKSA9PiB7XHJcbiAgICAgIHByaW50V2luZG93LmZvY3VzKCk7XHJcbiAgICAgIHByaW50V2luZG93LnByaW50KCk7XHJcbiAgICAgIHByaW50V2luZG93LmNsb3NlKCk7XHJcbiAgICB9O1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2XHJcbiAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgZm9udC1tZWRpdW0gY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICBvbkNsaWNrPXtoYW5kbGVQcmludEFja25vd2xlZGdlbWVudH1cclxuICAgID5cclxuICAgICAgUHJpbnRcclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDdXN0b21lckFja25vd2xlZGdlbWVudFByaW50OyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9jb21wb25lbnRzL3ByaW50Rm9ybWF0cy9DdXN0b21lckFja25vd2xlZGdlbWVudFByaW50LmpzeCJ9