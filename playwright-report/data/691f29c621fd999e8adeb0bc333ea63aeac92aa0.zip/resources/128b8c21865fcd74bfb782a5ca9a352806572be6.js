import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Home.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const createElement = __vite__cjsImport1_react["createElement"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import {
  BadgeCheck,
  BriefcaseBusiness,
  Building2,
  CalendarDays,
  ClipboardList,
  GitBranch,
  IndianRupee,
  Layers3,
  MessageSquareText,
  Percent,
  UserRoundCheck,
  UsersRound,
  Wallet
} from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import __vite__cjsImport6_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport6_react["useEffect"]; const useState = __vite__cjsImport6_react["useState"]; const useCallback = __vite__cjsImport6_react["useCallback"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { BsGrid3X3GapFill, BsListUl } from "/node_modules/.vite/deps/react-icons_bs.js?v=819e0a34";
import Receipt from "/src/components/receipts/CustomReceiptOne.jsx";
import { formatDateYYYYMMDD } from "/src/helpers/DateConvertion.jsx";
import ClosingGroupsModal from "/src/components/modals/ClosingGroupsModal.jsx";
import __vite__cjsImport14_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport14_dayjs.__esModule ? __vite__cjsImport14_dayjs.default : __vite__cjsImport14_dayjs;
import { Dropdown, Tag } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import {
  ClockCircleOutlined,
  CheckCircleOutlined,
  CloseCircleOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { ChevronDown, ChevronUp } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { FaCopy, FaShareAlt, FaExternalLinkAlt } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { message, Tooltip } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import CustomerAcknowledgementPrint from "/src/components/printFormats/CustomerAcknowledgementPrint.jsx";
import { DashboardAnalyticsContent } from "/src/pages/Analytics.jsx";
const Home = () => {
  _s();
  const [groups, setGroups] = useState([]);
  const [users, setUsers] = useState([]);
  const [agents, setAgents] = useState([]);
  const [staffs, setStaffs] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [paymentsValue, setPaymentsValue] = useState(0);
  const [paymentsPerMonthValue, setPaymentsPerMonthValue] = useState(0);
  const [searchValue, setSearchValue] = useState("");
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [hidePayment, setHidePayment] = useState(false);
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);
  const [enrollmentsCount, setEnrollmentsCount] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [viewMode, setViewMode] = useState("list");
  const [mobileAppLoading, setMobileAppLoading] = useState(false);
  const [acknowledmentsLoading, setAcknowledmentsLoading] = useState(false);
  const [openSection, setOpenSection] = useState({
    transactions: false,
    enrollments: false,
    unverifiedCustomers: false,
    payouts: false,
    mobileApplogs: false,
    installations: false,
    closingGroups: false,
    acknowledments: false
  });
  const [tableData, setTableData] = useState({
    tableTransactions: [],
    yesterdayEnrollments: [],
    recentPayouts: [],
    recentMobileAppLogs: [],
    unverifiedCustomers: []
  });
  const [mobileAppSummary, setMobileAppSummary] = useState({});
  const [mobileAppData, setMobileAppData] = useState([]);
  const [acknowledmentData, setacknowledmentData] = useState([]);
  const [closingGroupsData, setclosingGroupsData] = useState([]);
  const [activeMobileTab, setActiveMobileTab] = useState("installation");
  const [targetValue, setTargetValue] = useState(0);
  const [secondaryTargetValue, setSecondaryTargetValue] = useState(0);
  const [transactionsLoading, setTransactionsLoading] = useState(false);
  const [tableTransactions, setTableTransactions] = useState([]);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const navigate = useNavigate();
  const [showPasswordPrompt, setShowPasswordPrompt] = useState(false);
  const [selectedRedirect, setSelectedRedirect] = useState("");
  const [passwordInput, setPasswordInput] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [isLoadingVerify, setIsLoadingVerify] = useState(false);
  const [showRevenue, setShowRevenue] = useState(false);
  const [enrollmentsLoading, setEnrollmentsLoading] = useState(false);
  const [payoutsLoading, setPayoutsLoading] = useState(false);
  const [mobileAppLogsLoading, setMobileAppLogsLoading] = useState(false);
  const [closingGroupsLoading, setclosingGroupsLoading] = useState(false);
  const GlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchValue(value);
  };
  const handleViewDetailsClick = (redirect) => {
    setSelectedRedirect(redirect);
    setShowPasswordPrompt(true);
    setErrorMsg("");
  };
  const enrollmentColumns = [
    { key: "id", header: "SL. NO" },
    { key: "enrollment_date", header: "Enrollment Date" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "group_name", header: "Group Name" },
    { key: "ticket", header: "Ticket" },
    { key: "group_value", header: "Group Value" },
    { key: "payment_type", header: "payment Type" },
    { key: "chit_asking_month", header: "Chit Asking Month" },
    { key: "referred_type", header: "Referred Type" },
    // { key: "referred_agent", header: "Referred Agent" },
    // { key: "referred_customer", header: "Referred Customer" },
    //{ key: "referred_lead", header: "Referred Lead" },
    { key: "referred_by", header: "Referred By" }
  ];
  const unverifiedCustomersColumns = [
    { key: "id", header: "SL. NO" },
    { key: "createdAt", header: "Date" },
    { key: "name", header: "Customer Name" },
    { key: "customer_id", header: "Customer ID" },
    { key: "phone_number", header: "Phone Number" },
    { key: "status", header: "Status" }
    // { key: "address", header: "Address" },
    // { key: "pincode", header: "Pincode" },
    // { key: "chit_asking_month", header: "Chit Asking Month" },
    // { key: "referred_type", header: "Referred Type" },
    // // { key: "referred_agent", header: "Referred Agent" },
    // // { key: "referred_customer", header: "Referred Customer" },
    // //{ key: "referred_lead", header: "Referred Lead" },
    // { key: "referred_by", header: "Referred By" },
  ];
  const payOutColumns = [
    { key: "id", header: "SL. NO" },
    { key: "pay_date", header: "Payment Date" },
    { key: "name", header: "Customer Name" },
    { key: "amount", header: "Amount" },
    { key: "pay_type", header: "Payment type" },
    { key: "transaction_id", header: "Transaction Id" },
    { key: "pay_for", header: "Payment for" },
    { key: "disbursement_type", header: "Disbursement type" },
    { key: "category", header: "category" },
    { key: "receipt_no", header: "Receipt no" },
    { key: "note", header: "Note" },
    { key: "admin_type", header: "Created by" },
    { key: "createdAt", header: "created At" }
  ];
  const mobileAppLogsColumns = [
    { key: "id", header: "SL. NO" },
    { key: "createdAt", header: "created At" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "action", header: "Action" },
    { key: "reason", header: "Reason" },
    { key: "status", header: "Status" }
  ];
  const acknowledgementColumns = [
    { key: "id", header: "SL. NO" },
    { key: "transaction_id", header: "Acknowledgement ID" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "full_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    // { key: "transaction_type", header: "Transaction Type" },
    { key: "group_name", header: "Group/Pigmy/Loan" },
    { key: "tickets", header: "Tickets/Pigmy-Id/Loan-Id" },
    { key: "reason", header: "Reason" },
    // { key: "closure_type", header: "Closure Type" },
    { key: "gross_amount", header: "Gross Amount" },
    { key: "service_charge", header: "Service Charge" },
    { key: "gst_amount", header: "GST Amount" },
    { key: "interest_amount", header: "Interest Amount" },
    { key: "amount", header: "Net Amount" },
    // { key: "enroll_code", header: "Enrollment Code" },
    // { key: "payment_type", header: "Payment Type" },
    // { key: "pigme_id", header: "Pigmy ID" },
    // { key: "request_status", header: "Request Status" },
    { key: "admin_name", header: "Processed By" },
    // { key: "remarks", header: "Remarks" },
    { key: "action", header: "Action" }
  ];
  const fetchTotalBranchTarget = useCallback(async () => {
    try {
      const response = await api.get("/payment/branch/target");
      setTargetValue(response?.data?.data?.[0].branchTarget || 0);
    } catch (error) {
      console.error("Error fetching branch target amount:", error);
      setTargetValue(0);
    }
  }, []);
  const fetchTotalSecondaryBranchTarget = useCallback(async () => {
    try {
      const response = await api.get("/payment/secondary-branch/target");
      setSecondaryTargetValue(response?.data?.data?.[0].branchTarget || 0);
    } catch (error) {
      console.error("Error fetching branch target amount:", error);
      setSecondaryTargetValue(0);
    }
  }, []);
  const verifyPasswordAndRedirect = async () => {
    setIsLoadingVerify(true);
    setErrorMsg("");
    try {
      const admin = JSON.parse(localStorage.getItem("user"));
      if (!admin?.password) {
        setErrorMsg("No admin contact found. Please login again.");
        setIsLoadingVerify(false);
        return;
      }
      const response = await api.post("/admin/login", {
        phoneNumber: admin.phoneNumber,
        password: passwordInput
      });
      if (response.data?.token) {
        setShowPasswordPrompt(false);
        setPasswordInput("");
        setErrorMsg("");
        if (selectedRedirect === "/total-revenue" || selectedRedirect === "/monthly-revenue") {
          setShowRevenue(true);
          setTimeout(() => setShowRevenue(false), 3e4);
        }
        navigate(selectedRedirect);
      }
    } catch (err) {
      setErrorMsg(
        err.response?.data?.message || "Password verification failed"
      );
    } finally {
      setIsLoadingVerify(false);
    }
  };
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    if (userObj && userObj.admin_access_right_id?.access_permissions?.edit_payment) {
      const isModify = userObj.admin_access_right_id?.access_permissions?.edit_payment === "true";
      setHidePayment(isModify);
    }
  }, []);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, [reloadTrigger]);
  useEffect(() => {
    fetchTotalBranchTarget();
  }, [fetchTotalBranchTarget, reloadTrigger]);
  useEffect(() => {
    fetchTotalSecondaryBranchTarget();
  }, [fetchTotalSecondaryBranchTarget, reloadTrigger]);
  useEffect(() => {
    const fetchEnrollments = async () => {
      try {
        const response = await api.get("/enroll/get-enroll");
        setEnrollmentsCount(
          Array.isArray(response.data) ? response.data.length : 0
        );
      } catch (error) {
        console.error("Error fetching enrollments:", error);
        setEnrollmentsCount(0);
      }
    };
    fetchEnrollments();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await api.get("/user/get-user");
        setUsers(response.data);
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };
    fetchUsers();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchAgents = async () => {
      try {
        const response = await api.get("/agent/get");
        const verifiedAgent = (response.data.agent || []).filter(
          (agent) => agent.isVerified === true
        );
        setAgents(verifiedAgent || []);
      } catch (error) {
        console.error("Error fetching agents:", error);
      }
    };
    fetchAgents();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchStaffs = async () => {
      try {
        const response = await api.get("/agent/get-agent");
        const verifiedStaff = (response.data || []).filter(
          (staff) => staff.isVerified === true
        );
        setStaffs(verifiedStaff || []);
      } catch (error) {
        console.error("Error fetching staffs:", error);
      }
    };
    fetchStaffs();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const response = await api.get("/agent/get-employee");
        const verifiedEmployee = (response.data?.employee || []).filter(
          (employee) => employee.isVerified === true
        );
        setEmployees(verifiedEmployee || []);
      } catch (error) {
        console.error("Error fetching employees:", error);
      }
    };
    fetchEmployees();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchTotalPayments = async () => {
      try {
        const response = await api.get("/payment/get-total-payment-amount");
        setPaymentsValue(response?.data?.totalAmount || 0);
      } catch (error) {
        console.error("Error fetching total payment amount:", error);
      }
    };
    fetchTotalPayments();
  }, [reloadTrigger]);
  const getMaskedValue = (value) => {
    if (showRevenue) {
      return value.toLocaleString();
    }
    return "•••••";
  };
  const handleCopyTransaction = async (item, customer, group) => {
    const copyText = `
Transaction ID: ${item.transaction_id ? item.transaction_id.replace("MCF-TRN-", "MCF-ACK-") : "-"}
Customer Name: ${customer?.full_name || "-"}
Phone Number: ${customer?.phone_number || "-"}
Transaction Type: ${item.transaction_type || "-"}
Reason: ${item.reason || "-"}${item.pigme_id?.closure_type ? ` (${item.pigme_id.closure_type})` : ""}
Gross Amount: ${item.gross_amount ?? 0}
Amount: ${item.amount ?? 0}
Interest Amount: ${item.interest_amount ?? 0}
Service Charge: ${item.service_charge ?? 0}
GST Amount: ${item.gst_amount ?? 0}
Remarks: ${item.remarks || "-"}
Transaction Date: ${item.transaction_date ? new Date(item.transaction_date).toLocaleDateString("en-IN") : "-"}
Group Name: ${group?.group_name ? group.group_name : item.pigme_id ? "Pigmy" : item.loan_id ? "Loan" : "-"}
Tickets: ${item.enroll_id?.tickets || item.pigme_id?.pigme_id || item.loan_id?.loan_id || "-"}
Enroll Code: ${item.enroll_id?.enroll_code || "-"}
Payment Type: ${item.enroll_id?.payment_type || "-"}
Request Status: ${item.pigme_id?.request_status || "-"}
Admin Name: ${item.admin_id?.name || item.admin_id?.admin_name || "-"}
`.trim();
    try {
      await navigator.clipboard.writeText(copyText);
      message.success("Transaction details copied!");
    } catch (error) {
      console.error("Failed to copy:", error);
      message.error("Failed to copy transaction details");
    }
  };
  const fetchclosingGroupsData = async () => {
    try {
      setclosingGroupsLoading(true);
      const res = await api.get("/v1/admin/groups/closing");
      setclosingGroupsData(res?.data?.data || []);
    } catch (error) {
      console.error("Error fetching mobile app installations:", error);
      setclosingGroupsData([]);
    } finally {
      setclosingGroupsLoading(false);
    }
  };
  const fetchMobileAppInstalls = async () => {
    try {
      setMobileAppLoading(true);
      const res = await api.get("/v1/admin/users/mobile-app-installs");
      setMobileAppData(res?.data?.data || []);
    } catch (error) {
      console.error("Error fetching mobile app installations:", error);
      setMobileAppData([]);
    } finally {
      setMobileAppLoading(false);
    }
  };
  const fetchacknowledmentData = async (limit) => {
    try {
      setAcknowledmentsLoading(true);
      const url = limit ? `/v1/admin/transaction-history?limit=${limit}` : "/v1/admin/transaction-history";
      const res = await api.get(url);
      setacknowledmentData(res?.data?.data || []);
    } catch (error) {
      console.error("Error fetching mobile app installations:", error);
      setacknowledmentData([]);
    } finally {
      setAcknowledmentsLoading(false);
    }
  };
  const acknowledmentsTableData = acknowledmentData?.map((item, index) => {
    const customer = item.pigme_id?.customer || item.enroll_id?.user_id || {};
    const group = item.enroll_id?.group_id || {};
    return {
      id: index + 1,
      transaction_id: item.transaction_id ? item.transaction_id.replace("MCF-TRN-", "MCF-ACK-") : "-",
      full_name: customer.full_name || "-",
      phone_number: customer.phone_number || "-",
      transaction_type: item.transaction_type || "-",
      reason: /* @__PURE__ */ jsxDEV("span", { className: "text-blue-800 font-semibold ml-1", children: [
        item.reason || "-",
        item.pigme_id?.closure_type && /* @__PURE__ */ jsxDEV("span", { children: [
          "(",
          item.pigme_id.closure_type,
          ")"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
          lineNumber: 540,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
        lineNumber: 537,
        columnNumber: 7
      }, this),
      gross_amount: item.gross_amount ?? 0,
      amount: /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-semibold", children: item.amount ?? 0 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
        lineNumber: 547,
        columnNumber: 15
      }, this),
      interest_amount: item.interest_amount?.toFixed(1) ?? 0,
      service_charge: item.service_charge ?? 0,
      gst_amount: item.gst_amount ?? 0,
      remarks: item.remarks || "-",
      transaction_date: item.transaction_date ? new Date(item.transaction_date).toLocaleDateString("en-IN") : "-",
      group_name: group.group_name ? group.group_name : item.pigme_id ? "Pigmy" : item.loan_id ? "Loan" : "-",
      tickets: item.enroll_id?.tickets || item.pigme_id?.pigme_id || item.loan_id?.loan_id || "-",
      enroll_code: item.enroll_id?.enroll_code || "-",
      payment_type: item.enroll_id?.payment_type || "-",
      // pigme_id: item.pigme_id?.pigme_id || "-",
      request_status: item.pigme_id?.request_status || "-",
      // closure_type: item.pigme_id?.closure_type || "-",
      admin_name: item.admin_id?.name || item.admin_id?.admin_name || "-",
      diff_group_value: item.enroll_id?.diff_group_value || "-",
      action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center gap-2", children: /* @__PURE__ */ jsxDEV(
        Dropdown,
        {
          menu: {
            items: [
              {
                key: "1",
                label: /* @__PURE__ */ jsxDEV("div", { className: "text-blue-600 cursor-pointer", children: /* @__PURE__ */ jsxDEV(
                  CustomerAcknowledgementPrint,
                  {
                    item: {
                      transaction_id: item.transaction_id || "-",
                      full_name: customer.full_name || "-",
                      phone_number: customer.phone_number || "-",
                      transaction_type: item.transaction_type || "-",
                      reason: item.reason || "",
                      gross_amount: item.gross_amount ?? 0,
                      amount: item.amount ?? 0,
                      interest_amount: item.interest_amount ?? 0,
                      service_charge: item.service_charge ?? 0,
                      gst_amount: item.gst_amount ?? 0,
                      remarks: item.remarks || "-",
                      transaction_date: item.transaction_date ? new Date(item.transaction_date).toLocaleDateString("en-IN") : "-",
                      group_name: group.group_name || "-",
                      tickets: item.enroll_id?.tickets ?? "-",
                      enroll_code: item.enroll_id?.enroll_code || "-",
                      payment_type: item.enroll_id?.payment_type || "-",
                      pigme_id: item.pigme_id?.pigme_id || "-",
                      request_status: item.pigme_id?.request_status || "-",
                      closure_type: item.pigme_id?.closure_type || "-",
                      admin_name: item.admin_id?.name || item.admin_id?.admin_name || "-"
                    }
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 578,
                    columnNumber: 23
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 577,
                  columnNumber: 15
                }, this)
              },
              {
                key: "2",
                label: /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "text-gray-700 cursor-pointer",
                    onClick: () => handleCopyTransaction(item, customer, group),
                    children: "Copy Transaction"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 613,
                    columnNumber: 15
                  },
                  this
                )
              }
            ]
          },
          children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-xl cursor-pointer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 626,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
          lineNumber: 571,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
        lineNumber: 570,
        columnNumber: 7
      }, this)
    };
  });
  const installationTableData = mobileAppData.map((item, index) => ({
    id: index + 1,
    customer_id: item.customer_id || "-",
    full_name: item.full_name || "-",
    phone_number: item.phone_number || "-",
    status: item.verdict ? "Installed" : "Not Installed",
    last_login: item.last_successful_login_at ? new Date(item.last_successful_login_at).toLocaleString() : " "
  }));
  useEffect(() => {
    const fetchEnrollments = async () => {
      try {
        setEnrollmentsLoading(true);
        const today = /* @__PURE__ */ new Date();
        const lastWeek = /* @__PURE__ */ new Date();
        lastWeek.setDate(today.getDate() - 7);
        const formatDateYYYYMMDD2 = (date) => {
          const year = date.getFullYear();
          const month = String(date.getMonth() + 1).padStart(2, "0");
          const day = String(date.getDate()).padStart(2, "0");
          return `${year}-${month}-${day}`;
        };
        const fromDate = formatDateYYYYMMDD2(lastWeek);
        const toDate = formatDateYYYYMMDD2(today);
        const [enrollResponse, enrollReportResponse] = await Promise.all(
          [
            api.get("/enroll/get-enroll"),
            api.get(
              `/enroll-report/get-dashboard-enrollment?from_date=${fromDate}&to_date=${toDate}`
            )
          ]
        );
        const formattedData = enrollReportResponse?.data.map((group, index) => {
          if (!group.group_id || !group.user_id) return {};
          return {
            _id: group?._id,
            id: index + 1,
            name: group?.user_id?.full_name,
            phone_number: group?.user_id?.phone_number,
            group_name: group?.group_id?.group_name,
            group_value: group?.group_id?.group_value,
            payment_type: group?.payment_type,
            enrollment_date: group?.createdAt?.split("T")[0].split("-").reverse().join("-"),
            chit_asking_month: group?.chit_asking_month,
            ticket: group.tickets,
            referred_type: group?.user_id?.referral_type,
            // referred_agent: group?.agent?.name,
            // referred_customer: group?.referred_customer?.full_name,
            // referred_lead: group?.referred_lead?.lead_name,
            referred_by: group?.user_id?.referral_type === "Self Joining" ? "Self Joining" : group?.user_id?.referred_employee?.name && group?.user_id?.referred_employee?.phone_number ? `${group.user_id.referred_employee.name} | ${group.user_id.referred_employee.phone_number}` : group?.user_id?.referred_agent?.name && group?.user_id?.referred_agent?.phone_number ? `${group.user_id.referred_agent.name} | ${group.user_id.referred_agent.phone_number}` : group?.user_id?.referred_customer?.full_name && group?.user_id?.referred_customer?.phone_number ? `${group.user_id.referred_customer.full_name} | ${group.user_id.referred_customer.phone_number}` : "N/A"
          };
        });
        setEnrollmentsCount(
          Array.isArray(enrollResponse.data) ? enrollResponse.data.length : 0
        );
        setTableData((prev) => ({
          ...prev,
          // keep existing properties
          yesterdayEnrollments: Array.isArray(formattedData) ? formattedData : []
        }));
      } catch (error) {
        console.error("Error fetching enrollments:", error);
        setEnrollmentsCount(0);
        setTableData({ tableTransactions: [], yesterdayEnrollments: [] });
      } finally {
        setEnrollmentsLoading(false);
      }
    };
    fetchEnrollments();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchPayouts = async () => {
      try {
        setPayoutsLoading(true);
        setMobileAppLogsLoading(true);
        const [payoutResponse, mobAppLogsRes, unverifiedCustomersRes] = await Promise.all(
          [
            api.get("/payment-out/latest-payout"),
            api.get("/user-event-logger/dashboard-app-user-events"),
            api.get("/user/approval-status/false")
          ]
        );
        const formattedData = payoutResponse?.data?.data?.map(
          (group, index) => {
            if (!group._id || !group.user_id) return {};
            return {
              _id: group?._id,
              id: index + 1,
              name: group?.user_id?.full_name,
              phone_number: group?.user_id?.phone_number,
              pay_date: group?.pay_date?.split("T")[0].split("-").reverse().join("-"),
              amount: group?.amount,
              pay_type: group?.pay_type,
              transaction_id: group?.pay_type === "cheque" ? ` Chq No: ${group?.cheque_number || "-"} | 
                  Chq Date: ${group?.cheque_date ? group.cheque_date.split("T")[0].split("-").reverse().join("-") : "-"}` : group?.transaction_id,
              pay_for: group?.pay_for,
              disbursement_type: group?.disbursement_type,
              category: group?.category,
              note: group?.note,
              admin_type: group?.admin_type?.name,
              createdAt: group?.createdAt?.split("T")[0].split("-").reverse().join("-"),
              receipt_no: group?.receipt_no
            };
          }
        );
        setMobileAppSummary(mobAppLogsRes?.data?.summary || {});
        const formattedDataMobileData = mobAppLogsRes?.data?.data?.map(
          (group, index) => {
            if (!group._id) return null;
            return {
              _id: group?._id,
              id: index + 1,
              name: group?.user_id?.full_name,
              phone_number: group?.user_id?.phone_number || group?.phone,
              reason: group?.reason,
              status: group?.status,
              createdAt: group?.createdAt?.split("T")[0].split("-").reverse().join("-")
            };
          }
        );
        const formattedUnverifiedCustomers = unverifiedCustomersRes?.data?.filter(
          (customer) => customer?.status === "Not Contacted"
        )?.map((customer, index) => ({
          id: index + 1,
          name: customer?.full_name,
          phone_number: customer?.phone_number,
          createdAt: customer?.createdAt?.split("T")[0],
          address: customer?.address,
          // pincode: customer?.pincode,
          status: customer?.status,
          customer_id: customer?.customer_id
        })) || [];
        setTableData((prev) => ({
          ...prev,
          recentPayouts: Array.isArray(formattedData) ? formattedData : [],
          recentMobileAppLogs: Array.isArray(formattedDataMobileData) ? formattedDataMobileData : [],
          unverifiedCustomers: formattedUnverifiedCustomers
        }));
      } catch (error) {
        console.error("Error fetching enrollments:", error);
        setTableData({
          tableTransactions: [],
          yesterdayEnrollments: [],
          recentPayouts: [],
          recentMobileAppLogs: [],
          unverifiedCustomers: []
        });
      } finally {
        setPayoutsLoading(false);
        setMobileAppLogsLoading(false);
      }
    };
    fetchPayouts();
  }, [reloadTrigger]);
  async function getTransactions() {
    try {
      setTransactionsLoading(true);
      const response = await api.get("/cashfree-pg-orders/10");
      const transactionsData = response.data?.data;
      const filteredData = transactionsData.map((order, index) => {
        const status = order?.status;
        const color = status === "ACTIVE" ? "blue" : status === "PAID" ? "green" : "red";
        const icon = status === "ACTIVE" ? /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
          lineNumber: 841,
          columnNumber: 9
        }, this) : status === "PAID" ? /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
          lineNumber: 843,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV(CloseCircleOutlined, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
          lineNumber: 845,
          columnNumber: 9
        }, this);
        const groups2 = order?.groups;
        const pigmys = order.pigmys;
        const loans = order?.loans;
        const groupsString = (groups2?.map(
          (group) => `${group?.group_id?.group_name} | ${group?.ticket}`
        ) || []).join(" | ");
        const pigmysString = (pigmys?.map(
          (pigmy) => `${pigmy?.payable_amount} | ${pigmy?.pigme_id}`
        ) || []).join(" | ");
        const loansString = (loans?.map((loan) => `${loan?.loan_amount} | ${loan?.loan_id}`) || []).join(" | ");
        return {
          id: index + 1,
          orderType: order?.order_type,
          user_name: order?.user_id?.full_name,
          phone_number: order?.user_id?.phone_number,
          groups: (groups2?.map(
            (group) => `${group?.group_id?.group_name} | ${group?.ticket}`
          ) || []).join(" | "),
          pigmys: (pigmys?.map(
            (pigmy) => `${pigmy?.payable_amount} | ${pigmy?.pigme_id}`
          ) || []).join(" | "),
          loans: (loans?.map((loan) => `${loan?.loan_amount} | ${loan?.loan_id}`) || []).join(" | "),
          others: groupsString + pigmysString + loansString,
          status: /* @__PURE__ */ jsxDEV(Tag, { color, icon, variant: "filled", children: status }, "success", false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 884,
            columnNumber: 11
          }, this),
          amount: order?.amount,
          purpose: order?.purpose,
          link_url: order?.link_url,
          statusRaw: status,
          collectedBy: order?.collected_by,
          createdAt: order?.createdAt?.split("T")[0].split("-").reverse().join("-")
        };
      });
      setTableData((prev) => ({
        ...prev,
        tableTransactions: filteredData,
        yesterdayEnrollments: prev.yesterdayEnrollments
      }));
    } catch (error) {
      setTableData((prev) => ({ ...prev, tableTransactions: [] }));
    } finally {
      setTransactionsLoading(false);
    }
  }
  useEffect(() => {
    getTransactions();
  }, []);
  const cardData = [
    {
      // --- Added Branch Target Card ---
      icon: Building2,
      title: "Primary Branch Target",
      value: `₹ ${(targetValue ?? 0).toLocaleString("en-IN")}`,
      subtitle: "Current branch target goal",
      color: "from-gray-500 to-gray-600",
      iconBg: "bg-gray-100",
      iconColor: "text-gray-600",
      borderColor: "border-gray-600",
      ringColor: "ring-gray-500/20",
      redirect: "/staff-menu/employee-menu",
      key: "0"
    },
    {
      // --- Added Branch Target Card ---
      icon: GitBranch,
      title: "Secondary Target",
      value: `₹ ${(secondaryTargetValue ?? 0).toLocaleString("en-IN")}`,
      subtitle: "Secondary branch target goal",
      color: "from-gray-500 to-gray-600",
      iconBg: "bg-gray-100",
      iconColor: "text-gray-600",
      borderColor: "border-gray-600",
      ringColor: "ring-gray-500/20",
      redirect: "/staff-menu/employee-menu",
      key: "0"
    },
    {
      icon: Layers3,
      title: "Chit Groups",
      value: groups.length,
      subtitle: "Active business units",
      color: "from-indigo-500 to-indigo-600",
      iconBg: "bg-indigo-100",
      iconColor: "text-indigo-600",
      borderColor: "border-indigo-600",
      ringColor: "ring-indigo-500/20",
      redirect: "/group",
      key: "1"
    },
    {
      icon: UsersRound,
      title: "Customers",
      value: users.length,
      subtitle: "Total registered users",
      color: "from-amber-500 to-amber-600",
      iconBg: "bg-amber-100",
      iconColor: "text-amber-600",
      borderColor: "border-amber-600",
      ringColor: "ring-amber-500/20",
      redirect: "/user",
      key: "2"
    },
    {
      icon: ClipboardList,
      title: "Total Enrollments",
      value: enrollmentsCount.toLocaleString(),
      subtitle: "Active enrollments this period",
      color: "from-teal-500 to-teal-600",
      iconBg: "bg-teal-100",
      iconColor: "text-teal-600",
      borderColor: "border-teal-600",
      ringColor: "ring-teal-500/20",
      redirect: "/enrollment",
      key: "8"
    },
    {
      icon: UserRoundCheck,
      title: "Agents",
      value: agents.length,
      subtitle: "Field representatives",
      color: "from-purple-500 to-purple-600",
      iconBg: "bg-purple-100",
      iconColor: "text-purple-600",
      borderColor: "border-purple-600",
      ringColor: "ring-purple-500/20",
      redirect: "/staff-menu/agent-menu",
      key: "3"
    },
    {
      icon: BadgeCheck,
      title: "Staff",
      value: staffs.length,
      subtitle: "Verified collection staff",
      iconBg: "bg-violet-50",
      iconColor: "text-violet-700"
    },
    {
      icon: BriefcaseBusiness,
      title: "Employees",
      value: employees.length,
      subtitle: "Organization workforce",
      color: "from-orange-500 to-orange-600",
      iconBg: "bg-orange-100",
      iconColor: "text-orange-600",
      borderColor: "border-orange-600",
      ringColor: "ring-orange-500/20",
      redirect: "/staff-menu/employee-menu",
      key: "5"
    },
    {
      icon: Wallet,
      title: "Total Revenue",
      value: `${getMaskedValue(paymentsValue)}`,
      subtitle: "All-time earnings",
      color: "from-emerald-500 to-emerald-600",
      iconBg: "bg-emerald-100",
      iconColor: "text-emerald-600",
      borderColor: "border-emerald-600",
      ringColor: "ring-emerald-500/20",
      redirect: "/total-revenue",
      key: "6"
    },
    {
      icon: CalendarDays,
      title: "Monthly Revenue",
      value: `${getMaskedValue(paymentsPerMonthValue)}`,
      subtitle: "Current billing cycle",
      color: "from-sky-500 to-sky-600",
      iconBg: "bg-sky-100",
      iconColor: "text-sky-600",
      borderColor: "border-sky-600",
      ringColor: "ring-sky-500/20",
      redirect: "/monthly-revenue",
      key: "7"
    }
  ].filter(
    (card) => card.title.toLowerCase().includes(searchValue.toLowerCase()) || card.subtitle.toLowerCase().includes(searchValue.toLowerCase())
  );
  const newsItems = [
    {
      text: "New chit fund scheme launched with 10% higher returns! New chit fund scheme launched with 10% higher returns! New chit fund scheme launched with 10% higher returns!",
      icon: Percent,
      iconClass: "text-amber-600"
    },
    {
      text: "Banglore branch opens for Chit Plans enrollment.",
      icon: Building2,
      iconClass: "text-blue-600"
    },
    {
      text: "Monthly chit collection due date reminder for subscribers.",
      icon: IndianRupee,
      iconClass: "text-emerald-600"
    },
    {
      text: "Customer feedback requested for better chit management.",
      icon: UsersRound,
      iconClass: "text-violet-600"
    },
    {
      text: "Special bonus chit draw happening this weekend!",
      icon: MessageSquareText,
      iconClass: "text-pink-600"
    }
  ];
  const handleCopyLink = (url) => {
    if (!url) {
      message.warning("No payment link found for this transaction");
      return;
    }
    navigator.clipboard.writeText(url);
    message.success("Payment link copied to clipboard!");
  };
  const GRID_LAYOUT = "grid-cols-[50px_110px_1.5fr_2fr_100px_120px_100px]";
  return /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("div", { className: "flex pt-[68px] bg-slate-50 text-slate-900", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
      lineNumber: 1093,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(ClosingGroupsModal, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
      lineNumber: 1094,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
        lineNumber: 1095,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("main", { className: "w-full overflow-hidden px-3 py-4 sm:px-5 lg:px-7", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-5 flex flex-col gap-3 rounded-3xl border border-slate-200/70 bg-white/80 px-5 py-4 shadow-sm shadow-slate-900/[0.03] backdrop-blur-xl sm:flex-row sm:items-center sm:justify-between", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold tracking-tight text-slate-950 sm:text-3xl", children: "Intelligence Dashboard" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 1107,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-slate-500", children: "A live overview of branch targets, customers, enrollments, revenue, and team activity." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 1110,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
          lineNumber: 1106,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative group", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "flex h-8 w-8 cursor-pointer items-center justify-center rounded-full border border-slate-200/80 bg-white/70 text-xs font-bold text-[#0071e3] shadow-sm shadow-slate-900/[0.03] transition-all duration-200 hover:bg-white hover:text-slate-950", children: "i" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 1115,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "absolute top-full mt-3 left-1/2 -translate-x-1/2 mb-3 w-72 p-3 bg-gray-900 text-white text-xs leading-relaxed rounded-lg shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 pointer-events-none z-[9999]", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "font-semibold text-sm mb-1", children: "Dashboard overview" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1121,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-gray-300", children: "Real-time analytics and performance metrics for your organization. Monitor key business indicators and make data-driven decisions." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1125,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "absolute top-full left-1/2 -translate-x-1/2 border-l-4 border-r-4 border-t-4 border-l-transparent border-r-transparent border-t-gray-900" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1131,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 1120,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
          lineNumber: 1114,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
        lineNumber: 1105,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mb-5 h-9 overflow-hidden rounded-2xl border border-slate-200/70 bg-white/70 shadow-sm shadow-slate-900/[0.03] backdrop-blur-xl", children: /* @__PURE__ */ jsxDEV("div", { className: "dashboard-news-marquee flex h-full w-max items-center whitespace-nowrap", children: newsItems.concat(newsItems).map((item, idx) => {
        const Icon = item.icon;
        return /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "flex h-full items-center gap-2 px-4 text-sm font-medium text-slate-600 transition duration-200 hover:bg-white/80",
            children: [
              /* @__PURE__ */ jsxDEV(Icon, { className: `h-4 w-4 shrink-0 ${item.iconClass}`, strokeWidth: 1.8 }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1146,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: item.text }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1147,
                columnNumber: 21
              }, this)
            ]
          },
          `${item.text}-${idx}`,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 1142,
            columnNumber: 19
          },
          this
        );
      }) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
        lineNumber: 1137,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
        lineNumber: 1136,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("style", { children: `
            @keyframes dashboard-news-scroll {
              0% {
                transform: translateX(0);
              }
              100% {
                transform: translateX(-50%);
              }
            }

            .dashboard-news-marquee {
              animation: dashboard-news-scroll 30s linear infinite;
            }
          ` }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
        lineNumber: 1154,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "pb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4", children: cardData.map((card) => {
          const CardElement = card.redirect ? "button" : "div";
          return /* @__PURE__ */ createElement(
            CardElement,
            {
              ...card.redirect ? {
                type: "button",
                onClick: () => handleViewDetailsClick(card.redirect),
                "aria-label": `${card.title}: ${card.value}. ${card.subtitle}`
              } : {},
              key: card.title,
              className: `group flex min-h-[112px] w-full min-w-0 items-center gap-3 rounded-2xl border border-slate-200/70 bg-white/80 p-3 text-left shadow-sm shadow-slate-900/[0.03] backdrop-blur-xl sm:p-4 ${card.redirect ? "cursor-pointer transition duration-200 hover:-translate-y-0.5 hover:bg-white hover:shadow-md hover:shadow-slate-900/10 focus:outline-none focus:ring-2 focus:ring-[#0071e3]/25" : ""}`
            },
            /* @__PURE__ */ jsxDEV("span", { className: `grid h-11 w-11 shrink-0 place-items-center rounded-xl border ${card.iconBg} ${card.iconColor} border-current/10`, children: /* @__PURE__ */ jsxDEV(card.icon, { className: "h-5 w-5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1184,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1183,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "min-w-0 flex-1", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "block whitespace-normal text-sm font-medium leading-snug text-slate-600", children: card.title }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1187,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "mt-1 block break-words text-xl font-semibold tabular-nums tracking-tight text-slate-950", children: card.value }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1188,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "mt-1 block whitespace-normal text-xs leading-snug text-slate-500", children: card.subtitle }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1189,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1186,
              columnNumber: 19
            }, this)
          );
        }) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
          lineNumber: 1170,
          columnNumber: 13
        }, this),
        cardData.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "col-span-full flex flex-col items-center justify-center py-12 px-6 rounded-2xl bg-white shadow-lg mx-4 md:mx-0", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-gray-400 mb-4", children: /* @__PURE__ */ jsxDEV(
            "svg",
            {
              className: "w-16 h-16 mx-auto",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: "1.5",
                  d: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1204,
                  columnNumber: 21
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1198,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 1197,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-semibold text-gray-700 mb-2 text-center", children: "No results found" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 1212,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 max-w-md text-center", children: [
            "We couldn't find any matching results for",
            " ",
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: [
              '"',
              searchValue,
              '"'
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1217,
              columnNumber: 19
            }, this),
            ". Try adjusting your search terms."
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 1215,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
          lineNumber: 1196,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("section", { id: "dashboard-analytics", className: "mt-7 rounded-3xl border border-slate-200/70 bg-white/60 p-4 shadow-sm shadow-slate-900/[0.03] backdrop-blur-xl sm:p-5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-5 border-b border-slate-200/70 pb-4", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-[0.16em] text-slate-500", children: "Performance detail" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1225,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-slate-600", children: "Trends and operational breakdowns" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1226,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 1224,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(DashboardAnalyticsContent, { embedded: true }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 1228,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
          lineNumber: 1223,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-8 cursor-pointer border border-orange-300 bg-gradient-to-r from-orange-50 to-red-50 rounded-xl shadow-lg p-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between mb-2 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-orange-900", children: "Closing Groups Needing Attention" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1319,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 rounded-full bg-red-100 text-red-700 text-xs font-semibold animate-pulse", children: "Admin Action Required" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1323,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1318,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-orange-800", children: [
                "Some chit groups are ",
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-red-700", children: "approaching their closing date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1329,
                  columnNumber: 42
                }, this),
                ". Please review them and take the necessary actions before the groups are closed."
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1328,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1317,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  const isOpening = !openSection.closingGroups;
                  setOpenSection((prev) => ({
                    ...prev,
                    closingGroups: isOpening
                  }));
                  if (isOpening && closingGroupsData.length === 0) {
                    fetchclosingGroupsData();
                  }
                },
                className: "p-2 rounded-full hover:bg-orange-100 transition",
                children: /* @__PURE__ */ jsxDEV("span", { className: "text-orange-600 text-3xl font-bold", children: openSection.closingGroups ? "−" : "+" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1349,
                  columnNumber: 21
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1335,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1334,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 1316,
            columnNumber: 15
          }, this),
          closingGroupsLoading ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [...Array(5)].map(
            (_, i) => /* @__PURE__ */ jsxDEV("div", { className: "h-16 bg-gray-100 animate-pulse rounded-xl" }, i, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1358,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 1356,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `transition-all duration-300 ease-in-out overflow-hidden ${openSection.closingGroups ? "max-h-[2000px] opacity-100" : "max-h-0 opacity-0"}`,
              children: /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full border-collapse", children: [
                /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "bg-gray-100", children: [
                  /* @__PURE__ */ jsxDEV("th", { className: "p-3 text-left", children: "SL" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 1370,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "p-3 text-left", children: "Group Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 1371,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "p-3 text-left", children: "End Date" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 1372,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "p-3 text-left", children: "Days Remaining" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 1373,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "p-3 text-left", children: "Months Remaining" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 1374,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1369,
                  columnNumber: 25
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1368,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("tbody", { children: closingGroupsData.length > 0 ? closingGroupsData.map(
                  (item, index) => /* @__PURE__ */ jsxDEV("tr", { className: "border-b hover:bg-gray-50", children: [
                    /* @__PURE__ */ jsxDEV("td", { className: "p-3", children: index + 1 }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1381,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "p-3 font-medium", children: item.group_name }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1382,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "p-3", children: new Date(item.end_date).toLocaleDateString("en-IN", {
                      day: "2-digit",
                      month: "short",
                      year: "numeric"
                    }) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1383,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "p-3", children: /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-1 rounded bg-red-100 text-red-700 text-xs font-semibold", children: [
                      item.days_remaining,
                      " days"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1391,
                      columnNumber: 33
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1390,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "p-3", children: [
                      item.months_remaining,
                      " month(s)"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1395,
                      columnNumber: 31
                    }, this)
                  ] }, item._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 1380,
                    columnNumber: 23
                  }, this)
                ) : /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { colSpan: "5", className: "text-center p-6 text-gray-500", children: "No closing groups found" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1400,
                  columnNumber: 29
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1399,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1377,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1367,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1366,
                columnNumber: 19
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1362,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
          lineNumber: 1315,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between border border-gray-200 rounded-lg shadow-md p-4 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-gray-800 dark:text-gray-300", children: [
                "Recent Transactions",
                /* @__PURE__ */ jsxDEV(
                  Link,
                  {
                    to: "/payment-link-transactions",
                    className: "text-sm font-medium text-blue-500 hover:text-blue-700 hover:underline ml-4",
                    children: "View All"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 1419,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1416,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Showing the latest activities" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1427,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1415,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex bg-gray-200 p-1 rounded-lg", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setViewMode("grid"),
                    className: `p-2 rounded-md transition-all ${viewMode === "grid" ? "bg-white shadow-sm text-blue-600" : "text-gray-500"}`,
                    children: /* @__PURE__ */ jsxDEV(BsGrid3X3GapFill, { size: 18 }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1443,
                      columnNumber: 23
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 1436,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setViewMode("list"),
                    className: `p-2 rounded-md transition-all ${viewMode === "list" ? "bg-white shadow-sm text-blue-600" : "text-gray-500"}`,
                    children: /* @__PURE__ */ jsxDEV(BsListUl, { size: 18 }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1453,
                      columnNumber: 23
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 1446,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1435,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: getTransactions,
                  className: "bg-white border px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-50 dark:text-gray-500",
                  children: "Refresh"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1458,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setOpenSection((prev) => ({
                    ...prev,
                    transactions: !prev.transactions
                  })),
                  className: "p-2",
                  children: /* @__PURE__ */ jsxDEV(
                    ChevronUp,
                    {
                      className: `text-orange-500 text-3xl transition-transform duration-300 ${openSection.transactions ? "rotate-180" : ""}`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1475,
                      columnNumber: 21
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1466,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1433,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 1413,
            columnNumber: 15
          }, this),
          transactionsLoading ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "h-20 bg-gray-200 animate-pulse rounded-md" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1485,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "h-20 bg-gray-200 animate-pulse rounded-md" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1486,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 1484,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `transition-all duration-300 ease-in-out overflow-hidden mt-2 ${openSection.transactions ? "max-h-[2000px] opacity-100" : "max-h-0 opacity-0"}`,
              children: /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: viewMode === "grid" ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6" : "flex flex-col border border-gray-200 rounded-lg overflow-hidden bg-white shadow-sm",
                  children: [
                    viewMode === "list" && /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: `grid ${GRID_LAYOUT} items-center bg-gray-50 px-6 py-4 border-b border-gray-200 font-bold text-[11px] text-gray-400 uppercase tracking-widest gap-4`,
                        children: [
                          /* @__PURE__ */ jsxDEV("div", { children: "SL" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                            lineNumber: 1508,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { children: "Date" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                            lineNumber: 1509,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { children: "Customer" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                            lineNumber: 1510,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { children: "Purpose & Details" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                            lineNumber: 1511,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { children: "Amount" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                            lineNumber: 1512,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { children: "Status" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                            lineNumber: 1513,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: "Actions" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                            lineNumber: 1514,
                            columnNumber: 27
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                        lineNumber: 1505,
                        columnNumber: 21
                      },
                      this
                    ),
                    tableData?.tableTransactions.length > 0 ? tableData?.tableTransactions?.map(
                      (item, index) => viewMode === "list" ? /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: `grid ${GRID_LAYOUT} items-center px-6 py-4 border-b border-gray-50 hover:bg-gray-50/80 transition-colors gap-4 text-sm`,
                          children: [
                            /* @__PURE__ */ jsxDEV("div", { className: "text-gray-400 font-mono", children: (index + 1).toString().padStart(2, "0") }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                              lineNumber: 1526,
                              columnNumber: 31
                            }, this),
                            /* @__PURE__ */ jsxDEV("div", { className: "text-gray-600 font-medium whitespace-nowrap", children: item.createdAt }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                              lineNumber: 1530,
                              columnNumber: 31
                            }, this),
                            /* @__PURE__ */ jsxDEV("div", { className: "overflow-hidden", children: [
                              /* @__PURE__ */ jsxDEV("div", { className: "font-bold text-gray-800 truncate", children: item.user_name }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                                lineNumber: 1535,
                                columnNumber: 33
                              }, this),
                              /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-400", children: item.phone_number }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                                lineNumber: 1538,
                                columnNumber: 33
                              }, this)
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                              lineNumber: 1534,
                              columnNumber: 31
                            }, this),
                            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col overflow-hidden", children: [
                              /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-blue-700 text-[10px] px-2 py-0.5 bg-blue-50 rounded-md w-fit mb-1 uppercase", children: item.purpose || "N/A" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                                lineNumber: 1545,
                                columnNumber: 33
                              }, this),
                              /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-500 line-clamp-1 italic", children: item.others || "No extra data" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                                lineNumber: 1548,
                                columnNumber: 33
                              }, this)
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                              lineNumber: 1544,
                              columnNumber: 31
                            }, this),
                            /* @__PURE__ */ jsxDEV("div", { className: "font-bold text-gray-900", children: [
                              "₹",
                              item.amount?.toLocaleString("en-IN")
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                              lineNumber: 1553,
                              columnNumber: 31
                            }, this),
                            /* @__PURE__ */ jsxDEV("div", { children: item.status }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                              lineNumber: 1557,
                              columnNumber: 31
                            }, this),
                            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-2", children: [
                              /* @__PURE__ */ jsxDEV(
                                Tooltip,
                                {
                                  title: item?.link_url ? "Copy Payment Link" : "No link available",
                                  children: /* @__PURE__ */ jsxDEV(
                                    "button",
                                    {
                                      onClick: () => handleCopyLink(item?.link_url),
                                      className: `p-2 rounded-lg transition-all ${item?.link_url ? "text-blue-600 hover:bg-blue-100" : "text-gray-300"}`,
                                      children: /* @__PURE__ */ jsxDEV(FaCopy, { size: 14 }, void 0, false, {
                                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                                        lineNumber: 1574,
                                        columnNumber: 37
                                      }, this)
                                    },
                                    void 0,
                                    false,
                                    {
                                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                                      lineNumber: 1568,
                                      columnNumber: 35
                                    },
                                    this
                                  )
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                                  lineNumber: 1561,
                                  columnNumber: 33
                                },
                                this
                              ),
                              /* @__PURE__ */ jsxDEV(
                                Tooltip,
                                {
                                  title: item.link_url ? "Open Link" : "Link not found",
                                  children: /* @__PURE__ */ jsxDEV(
                                    "button",
                                    {
                                      onClick: () => {
                                        if (item.link_url)
                                          window.open(item.link_url, "_blank");
                                        else
                                          message.info(
                                            "External link is not available for this entry"
                                          );
                                      },
                                      className: `p-2 rounded-lg transition-all ${item.link_url ? "text-gray-500 hover:bg-gray-100" : "text-gray-300"}`,
                                      children: /* @__PURE__ */ jsxDEV(FaExternalLinkAlt, { size: 13 }, void 0, false, {
                                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                                        lineNumber: 1596,
                                        columnNumber: 37
                                      }, this)
                                    },
                                    void 0,
                                    false,
                                    {
                                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                                      lineNumber: 1585,
                                      columnNumber: 35
                                    },
                                    this
                                  )
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                                  lineNumber: 1578,
                                  columnNumber: 33
                                },
                                this
                              )
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                              lineNumber: 1560,
                              columnNumber: 31
                            }, this)
                          ]
                        },
                        item.id,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                          lineNumber: 1522,
                          columnNumber: 21
                        },
                        this
                      ) : /* @__PURE__ */ jsxDEV(
                        Receipt,
                        {
                          ...item,
                          status: item.statusRaw,
                          viewMode: "grid"
                        },
                        item.id,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                          lineNumber: 1602,
                          columnNumber: 21
                        },
                        this
                      )
                    ) : /* @__PURE__ */ jsxDEV("div", { className: "p-20 text-center text-gray-400 italic bg-white", children: "No transactions found." }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1611,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1496,
                  columnNumber: 21
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1490,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 1489,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: `flex-1 border rounded-lg shadow-md p-1 mt-5 transition-all duration-300 ${tableData?.unverifiedCustomers?.length > 0 ? "border-orange-300 shadow-orange-100 ring-1 ring-orange-100" : "border-gray-200"}`, children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center p-4 cursor-pointer", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
                tableData?.unverifiedCustomers?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "relative mt-1", children: /* @__PURE__ */ jsxDEV("span", { className: "flex h-3 w-3", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "absolute inline-flex h-full w-full animate-ping rounded-full bg-orange-400 opacity-75" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 1631,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "relative inline-flex h-3 w-3 rounded-full bg-orange-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 1632,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1630,
                  columnNumber: 25
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1629,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-gray-800 dark:text-gray-300", children: "Unverified Customers" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1639,
                      columnNumber: 25
                    }, this),
                    tableData?.unverifiedCustomers?.length > 0 && /* @__PURE__ */ jsxDEV("span", { className: "px-2.5 py-1 text-xs font-semibold text-orange-700 bg-orange-100 border border-orange-200 rounded-full animate-pulse", children: [
                      tableData.unverifiedCustomers.length,
                      " Pending"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1644,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Link,
                      {
                        to: "/approval-menu/un-approved-customer",
                        className: "text-sm font-medium text-blue-500 hover:text-blue-700 hover:underline transition",
                        children: "View All"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                        lineNumber: 1649,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 1638,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: tableData?.unverifiedCustomers?.length > 0 ? "New customer verification requests require your attention" : "Showing the latest unverified customers" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 1657,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1637,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1627,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: `text-3xl mr-2 font-bold transition-colors duration-300 ${tableData?.unverifiedCustomers?.length > 0 ? "text-orange-500" : "text-gray-400"}`,
                  onClick: () => setOpenSection((prev) => ({
                    ...prev,
                    unverifiedCustomers: !prev.unverifiedCustomers
                  })),
                  children: openSection.unverifiedCustomers ? "−" : "+"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1666,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1626,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `transition-all duration-300 ease-in-out overflow-hidden ${openSection.unverifiedCustomers ? "max-h-[1000px] opacity-100" : "max-h-0 opacity-0"}`,
                children: /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "flex flex-col rounded-lg overflow-hidden bg-white shadow-sm",
                    onClick: (e) => e.stopPropagation(),
                    children: enrollmentsLoading ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 p-4", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "h-20 bg-gray-200 animate-pulse rounded-md" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                        lineNumber: 1695,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "h-20 bg-gray-200 animate-pulse rounded-md" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                        lineNumber: 1696,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1694,
                      columnNumber: 21
                    }, this) : tableData?.unverifiedCustomers?.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "p-2", children: /* @__PURE__ */ jsxDEV(
                      DataTable,
                      {
                        data: tableData?.unverifiedCustomers,
                        columns: unverifiedCustomersColumns
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                        lineNumber: 1700,
                        columnNumber: 25
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1699,
                      columnNumber: 21
                    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p-20 text-center text-gray-400 italic", children: "No unverified Customers found" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1706,
                      columnNumber: 21
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 1689,
                    columnNumber: 19
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1683,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 1619,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 border border-gray-200 rounded-lg shadow-md p-1 mt-5", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center p-4 cursor-pointer", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-gray-800 dark:text-gray-300", children: [
                  "Recent Enrollments",
                  /* @__PURE__ */ jsxDEV(
                    Link,
                    {
                      to: "/reports/enrollment-report",
                      className: "text-sm font-medium text-blue-500 hover:text-blue-700 hover:underline transition ml-3",
                      children: "View All"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1723,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1720,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Showing the latest activities" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1730,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1719,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: "text-orange-500 text-3xl mr-2 font-bold",
                  onClick: () => setOpenSection((prev) => ({
                    ...prev,
                    enrollments: !prev.enrollments
                  })),
                  children: openSection.enrollments ? "−" : "+"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1736,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1718,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `transition-all duration-300 ease-in-out overflow-hidden ${openSection.enrollments ? "max-h-[1000px] opacity-100" : "max-h-0 opacity-0"}`,
                children: /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "flex flex-col  rounded-lg overflow-hidden bg-white shadow-sm",
                    onClick: (e) => e.stopPropagation(),
                    children: enrollmentsLoading ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 p-4", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "h-20 bg-gray-200 animate-pulse rounded-md" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                        lineNumber: 1763,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "h-20 bg-gray-200 animate-pulse rounded-md" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                        lineNumber: 1764,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1762,
                      columnNumber: 21
                    }, this) : tableData?.yesterdayEnrollments?.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "p-2", children: /* @__PURE__ */ jsxDEV(
                      DataTable,
                      {
                        data: tableData?.yesterdayEnrollments,
                        columns: enrollmentColumns
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                        lineNumber: 1768,
                        columnNumber: 25
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1767,
                      columnNumber: 21
                    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p-20 text-center text-gray-400 italic", children: "No enrollments found" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1775,
                      columnNumber: 21
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 1757,
                    columnNumber: 19
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1750,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 1714,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 border border-gray-200 rounded-lg shadow-md p-1 mt-5", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center p-4 cursor-pointer", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-gray-800 dark:text-gray-300", children: [
                  "Recent Payouts",
                  /* @__PURE__ */ jsxDEV(
                    Link,
                    {
                      to: "/reports/payout-report",
                      className: "text-sm font-medium text-blue-500 hover:text-blue-700 hover:underline ml-4",
                      children: "View All"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1791,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1789,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Showing the latest activities" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1799,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1788,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: "text-orange-500 text-3xl mr-2 font-bold",
                  onClick: () => setOpenSection((prev) => ({
                    ...prev,
                    payouts: !prev.payouts
                  })),
                  children: openSection.payouts ? "−" : "+"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1805,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1787,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `transition-all duration-300 ease-in-out overflow-hidden ${openSection.payouts ? "max-h-[1000px] opacity-100" : "max-h-0 opacity-0"}`,
                children: /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "flex flex-col rounded-lg overflow-hidden bg-white shadow-sm",
                    onClick: (e) => e.stopPropagation(),
                    children: payoutsLoading ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 p-4", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "h-20 bg-gray-200 animate-pulse rounded-md" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                        lineNumber: 1832,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "h-20 bg-gray-200 animate-pulse rounded-md" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                        lineNumber: 1833,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1831,
                      columnNumber: 21
                    }, this) : tableData?.recentPayouts?.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "p-2", children: /* @__PURE__ */ jsxDEV(
                      DataTable,
                      {
                        data: tableData.recentPayouts,
                        columns: payOutColumns
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                        lineNumber: 1837,
                        columnNumber: 25
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1836,
                      columnNumber: 21
                    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p-20 text-center text-gray-400 italic", children: "No Payouts found" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1844,
                      columnNumber: 21
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 1826,
                    columnNumber: 19
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1819,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 1783,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-8 cursor-pointer border border-gray-200 rounded-lg shadow-md p-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between mb-2 gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-gray-800", children: "Customer App Installation Details" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 1858,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Link,
                    {
                      to: "/reports/mobile-app-installs",
                      className: "text-sm font-medium text-blue-500 hover:text-blue-700 hover:underline transition ml-3 mt-3",
                      children: "View All"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1862,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1857,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Real-time mobile app installation status" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1870,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1856,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => {
                    const isOpening = !openSection.installations;
                    setOpenSection((prev) => ({
                      ...prev,
                      installations: isOpening
                    }));
                    if (isOpening && mobileAppData.length === 0) {
                      fetchMobileAppInstalls();
                    }
                  },
                  className: "p-2",
                  children: /* @__PURE__ */ jsxDEV("span", { className: "text-orange-500 text-3xl mr-2 font-bold", children: openSection.installations ? "−" : "+" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 1891,
                    columnNumber: 23
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 1876,
                  columnNumber: 21
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1875,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 1855,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `transition-all duration-300 ease-in-out overflow-hidden ${openSection.installations ? "max-h-[3000px] opacity-100" : "max-h-0 opacity-0"}`,
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 border border-gray-200 rounded-lg p-2 mb-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        onClick: (e) => {
                          e.stopPropagation();
                          setActiveMobileTab("installation");
                        },
                        className: `px-5 py-2.5 rounded-lg text-sm font-semibold transition-all duration-200 ${activeMobileTab === "installation" ? "bg-blue-600 text-white shadow-md" : "text-gray-600 hover:bg-gray-100"}`,
                        children: "App Installation"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                        lineNumber: 1910,
                        columnNumber: 23
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        onClick: (e) => {
                          e.stopPropagation();
                          setActiveMobileTab("logs");
                        },
                        className: `px-5 py-2.5 rounded-lg text-sm font-semibold transition-all duration-200 ${activeMobileTab === "logs" ? "bg-blue-600 text-white shadow-md" : "text-gray-600 hover:bg-gray-100"}`,
                        children: "Mobile Activity Logs"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                        lineNumber: 1923,
                        columnNumber: 23
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 1909,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 1908,
                    columnNumber: 19
                  }, this),
                  activeMobileTab === "installation" && /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "overflow-x-auto",
                      onClick: (e) => e.stopPropagation(),
                      children: mobileAppLoading ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [...Array(5)].map(
                        (_, i) => /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "h-16 bg-gray-100 animate-pulse rounded-xl"
                          },
                          i,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                            lineNumber: 1948,
                            columnNumber: 23
                          },
                          this
                        )
                      ) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                        lineNumber: 1946,
                        columnNumber: 21
                      }, this) : /* @__PURE__ */ jsxDEV("table", { className: "w-full border-collapse", children: [
                        /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "bg-gray-100", children: [
                          /* @__PURE__ */ jsxDEV("th", { className: "p-3 text-left", children: "SL" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                            lineNumber: 1958,
                            columnNumber: 31
                          }, this),
                          /* @__PURE__ */ jsxDEV("th", { className: "p-3 text-left", children: "Customer ID" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                            lineNumber: 1959,
                            columnNumber: 31
                          }, this),
                          /* @__PURE__ */ jsxDEV("th", { className: "p-3 text-left", children: "Customer Name" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                            lineNumber: 1960,
                            columnNumber: 31
                          }, this),
                          /* @__PURE__ */ jsxDEV("th", { className: "p-3 text-left", children: "Phone" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                            lineNumber: 1961,
                            columnNumber: 31
                          }, this),
                          /* @__PURE__ */ jsxDEV("th", { className: "p-3 text-left", children: "Status" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                            lineNumber: 1962,
                            columnNumber: 31
                          }, this),
                          /* @__PURE__ */ jsxDEV("th", { className: "p-3 text-left", children: "Last Login" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                            lineNumber: 1963,
                            columnNumber: 31
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                          lineNumber: 1957,
                          columnNumber: 29
                        }, this) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                          lineNumber: 1956,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV("tbody", { children: installationTableData.length > 0 ? installationTableData.map(
                          (item) => /* @__PURE__ */ jsxDEV(
                            "tr",
                            {
                              className: "border-b hover:bg-gray-50",
                              children: [
                                /* @__PURE__ */ jsxDEV("td", { className: "p-3", children: item.id }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                                  lineNumber: 1974,
                                  columnNumber: 35
                                }, this),
                                /* @__PURE__ */ jsxDEV("td", { className: "p-3", children: item.customer_id }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                                  lineNumber: 1975,
                                  columnNumber: 35
                                }, this),
                                /* @__PURE__ */ jsxDEV("td", { className: "p-3", children: item.full_name }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                                  lineNumber: 1976,
                                  columnNumber: 35
                                }, this),
                                /* @__PURE__ */ jsxDEV("td", { className: "p-3", children: item.phone_number }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                                  lineNumber: 1977,
                                  columnNumber: 35
                                }, this),
                                /* @__PURE__ */ jsxDEV("td", { className: "p-3", children: /* @__PURE__ */ jsxDEV(
                                  "span",
                                  {
                                    className: `px-2 py-1 rounded text-xs font-semibold ${item.status === "Installed" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`,
                                    children: item.status
                                  },
                                  void 0,
                                  false,
                                  {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                                    lineNumber: 1980,
                                    columnNumber: 37
                                  },
                                  this
                                ) }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                                  lineNumber: 1979,
                                  columnNumber: 35
                                }, this),
                                /* @__PURE__ */ jsxDEV("td", { className: "p-3", children: item.last_login && !isNaN(new Date(item.last_login)) ? new Date(item.last_login).toLocaleString(
                                  "en-IN"
                                ) : "-" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                                  lineNumber: 1990,
                                  columnNumber: 35
                                }, this)
                              ]
                            },
                            item.id,
                            true,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                              lineNumber: 1970,
                              columnNumber: 25
                            },
                            this
                          )
                        ) : /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV(
                          "td",
                          {
                            colSpan: "6",
                            className: "text-center p-6 text-gray-500",
                            children: "No installation records found"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                            lineNumber: 2002,
                            columnNumber: 33
                          },
                          this
                        ) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                          lineNumber: 2001,
                          columnNumber: 25
                        }, this) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                          lineNumber: 1967,
                          columnNumber: 27
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                        lineNumber: 1955,
                        columnNumber: 21
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 1941,
                      columnNumber: 19
                    },
                    this
                  ),
                  activeMobileTab === "logs" && /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "flex flex-col rounded-lg overflow-hidden bg-white shadow-sm",
                      onClick: (e) => e.stopPropagation(),
                      children: mobileAppLogsLoading ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 p-4", children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "h-20 bg-gray-200 animate-pulse rounded-md" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                          lineNumber: 2025,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "h-20 bg-gray-200 animate-pulse rounded-md" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                          lineNumber: 2026,
                          columnNumber: 27
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                        lineNumber: 2024,
                        columnNumber: 21
                      }, this) : tableData?.recentMobileAppLogs?.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "p-2", children: /* @__PURE__ */ jsxDEV(
                        DataTable,
                        {
                          data: tableData?.recentMobileAppLogs,
                          columns: mobileAppLogsColumns
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                          lineNumber: 2030,
                          columnNumber: 27
                        },
                        this
                      ) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                        lineNumber: 2029,
                        columnNumber: 21
                      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p-20 text-center text-gray-400 italic", children: "No Mobile Activity Logs found" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                        lineNumber: 2036,
                        columnNumber: 21
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                      lineNumber: 2019,
                      columnNumber: 19
                    },
                    this
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 1900,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 1854,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
          lineNumber: 1412,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-8 cursor-pointer border border-gray-200 rounded-lg shadow-md p-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between mb-2 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-gray-800", children: "Customer Acknowledgement Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 2188,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Link,
                  {
                    to: "/reports/transaction-history",
                    className: "text-sm font-medium text-blue-500 hover:text-blue-700 hover:underline transition ml-3 mt-3",
                    children: "View All"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 2192,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 2187,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Real-time Customer Acknowledgement status" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 2200,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 2186,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  const isOpening = !openSection.acknowledments;
                  setOpenSection((prev) => ({
                    ...prev,
                    acknowledments: isOpening
                  }));
                  if (isOpening && acknowledmentData.length === 0) {
                    fetchacknowledmentData(10);
                  }
                },
                className: "p-2",
                children: /* @__PURE__ */ jsxDEV("span", { className: "text-orange-500 text-3xl mr-2 font-bold", children: openSection.acknowledments ? "−" : "+" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 2220,
                  columnNumber: 21
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 2205,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 2204,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 2185,
            columnNumber: 15
          }, this),
          acknowledmentsLoading ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [...Array(5)].map(
            (_, i) => /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "h-16 bg-gray-100 animate-pulse rounded-xl"
              },
              i,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 2230,
                columnNumber: 17
              },
              this
            )
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 2228,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `transition-all duration-300 ease-in-out overflow-hidden ${openSection.acknowledments ? "max-h-[2000px] opacity-100" : "max-h-0 opacity-0"}`,
              children: acknowledmentsLoading ? /* @__PURE__ */ jsxDEV("div", { className: "py-8", children: /* @__PURE__ */ jsxDEV(
                CircularLoader,
                {
                  isLoading: acknowledmentsLoading,
                  failure: acknowledmentData.length === 0,
                  data: "installation records"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 2245,
                  columnNumber: 23
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 2244,
                columnNumber: 17
              }, this) : /* @__PURE__ */ jsxDEV(
                DataTable,
                {
                  data: acknowledmentsTableData,
                  columns: acknowledgementColumns
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 2252,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 2237,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
          lineNumber: 2184,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
        lineNumber: 1169,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
      lineNumber: 1104,
      columnNumber: 9
    }, this),
    showPasswordPrompt && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 p-4 animate-fade-in", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-2xl w-full max-w-md p-8 transform transition-all duration-300 scale-100 hover:scale-[1.01]", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-6", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-gray-800", children: [
          " ",
          "Secure Access Required"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
          lineNumber: 2270,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setShowPasswordPrompt(false),
            className: "text-gray-400 hover:text-gray-600 transition-colors",
            children: /* @__PURE__ */ jsxDEV(
              "svg",
              {
                className: "w-6 h-6",
                fill: "none",
                stroke: "currentColor",
                viewBox: "0 0 24 24",
                children: /* @__PURE__ */ jsxDEV(
                  "path",
                  {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: "2",
                    d: "M6 18L18 6M6 6l12 12"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                    lineNumber: 2284,
                    columnNumber: 21
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                lineNumber: 2278,
                columnNumber: 19
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 2274,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
        lineNumber: 2269,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 text-sm mb-6", children: [
        "Please enter your admin password to proceed to",
        " ",
        /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-violet-600", children: [
          selectedRedirect,
          " page"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
          lineNumber: 2296,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
        lineNumber: 2294,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
        /* @__PURE__ */ jsxDEV(
          "label",
          {
            htmlFor: "password",
            className: "block text-sm font-medium text-gray-700 mb-2",
            children: "Password"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 2302,
            columnNumber: 17
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            id: "password",
            type: "password",
            value: passwordInput,
            onChange: (e) => setPasswordInput(e.target.value),
            placeholder: "••••••••",
            autoFocus: true,
            className: "w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-4 focus:ring-violet-200 focus:border-violet-500 outline-none transition-all duration-200 text-gray-800 placeholder-gray-400"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 2308,
            columnNumber: 17
          },
          this
        ),
        errorMsg && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-500 font-medium flex items-center", children: [
          /* @__PURE__ */ jsxDEV(
            "svg",
            {
              className: "w-4 h-4 mr-1",
              fill: "currentColor",
              viewBox: "0 0 20 20",
              children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  fillRule: "evenodd",
                  d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z",
                  clipRule: "evenodd"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 2324,
                  columnNumber: 23
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 2319,
              columnNumber: 21
            },
            this
          ),
          errorMsg
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
          lineNumber: 2318,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
        lineNumber: 2301,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setShowPasswordPrompt(false),
            className: "flex-1 py-3 px-4 bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium rounded-xl transition-colors duration-200",
            disabled: isLoadingVerify,
            children: "Cancel"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 2336,
            columnNumber: 17
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: verifyPasswordAndRedirect,
            disabled: isLoadingVerify,
            className: `flex-1 py-3 px-4 font-medium rounded-xl shadow-md transition-all duration-200 flex items-center justify-center
                  ${isLoadingVerify ? "bg-violet-400 cursor-not-allowed opacity-80" : "bg-gradient-to-r from-violet-500 to-violet-600 hover:from-violet-600 hover:to-violet-700 text-white hover:shadow-lg"}`,
            children: isLoadingVerify ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV(
                "svg",
                {
                  className: "animate-spin -ml-1 mr-2 h-5 w-5 text-white",
                  xmlns: "http://www.w3.org/2000/svg",
                  fill: "none",
                  viewBox: "0 0 24 24",
                  children: [
                    /* @__PURE__ */ jsxDEV(
                      "circle",
                      {
                        className: "opacity-25",
                        cx: "12",
                        cy: "12",
                        r: "10",
                        stroke: "currentColor",
                        strokeWidth: "4"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                        lineNumber: 2360,
                        columnNumber: 25
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "path",
                      {
                        className: "opacity-75",
                        fill: "currentColor",
                        d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                        lineNumber: 2368,
                        columnNumber: 25
                      },
                      this
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
                  lineNumber: 2354,
                  columnNumber: 23
                },
                this
              ),
              "Verifying..."
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
              lineNumber: 2353,
              columnNumber: 17
            }, this) : "Verify & Proceed"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
            lineNumber: 2343,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
        lineNumber: 2335,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
      lineNumber: 2268,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
      lineNumber: 2267,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
    lineNumber: 1092,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx",
    lineNumber: 1091,
    columnNumber: 5
  }, this);
};
_s(Home, "4j70HBP8PyfB5rtWVxRxAqOw2PA=", false, function() {
  return [useNavigate];
});
_c = Home;
export default Home;
var _c;
$RefreshReg$(_c, "Home");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Home.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMmhCWSxTQXE3QkksVUFyN0JKO0FBMG5CSTsyQkFycENoQjtBQUFvQixpREFBK0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDbkQ7QUFBQSxFQUNFQTtBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0MsV0FBV0MsVUFBVUMsbUJBQW1CO0FBQ2pELFNBQVNDLG1CQUFtQjtBQUM1QixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLHVCQUF1QjtBQUM5QixTQUFTQyxrQkFBa0JDLGdCQUFnQjtBQUMzQyxPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLDBCQUEwQjtBQUNuQyxPQUFPQyx3QkFBd0I7QUFDL0IsT0FBT0MsV0FBVztBQUNsQixTQUFTQyxVQUFVQyxXQUFXO0FBQzlCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLFlBQVk7QUFDckIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGFBQWFDLGlCQUFpQjtBQUN2QyxPQUFPQyxlQUFlO0FBQ3RCLFNBQVNDLFFBQVFDLFlBQVlDLHlCQUF5QjtBQUN0RCxTQUFTQyxTQUFTQyxlQUFlO0FBQ2pDLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxrQ0FBa0M7QUFDekMsU0FBU0MsaUNBQWlDO0FBRTFDLE1BQU1DLE9BQU9BLE1BQU07QUFBQUMsS0FBQTtBQUNqQixRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSWhDLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNpQyxPQUFPQyxRQUFRLElBQUlsQyxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDbUMsUUFBUUMsU0FBUyxJQUFJcEMsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ3FDLFFBQVFDLFNBQVMsSUFBSXRDLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUN1QyxXQUFXQyxZQUFZLElBQUl4QyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDeUMsZUFBZUMsZ0JBQWdCLElBQUkxQyxTQUFTLENBQUM7QUFDcEQsUUFBTSxDQUFDMkMsdUJBQXVCQyx3QkFBd0IsSUFBSTVDLFNBQVMsQ0FBQztBQUNwRSxRQUFNLENBQUM2QyxhQUFhQyxjQUFjLElBQUk5QyxTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDK0MsZUFBZUMsZ0JBQWdCLElBQUloRCxTQUFTLENBQUM7QUFDcEQsUUFBTSxDQUFDaUQsYUFBYUMsY0FBYyxJQUFJbEQsU0FBUyxLQUFLO0FBQ3BELFFBQU0sQ0FBQ21ELG1CQUFtQkMsb0JBQW9CLElBQUlwRCxTQUFTLEtBQUs7QUFDaEUsUUFBTSxDQUFDcUQsa0JBQWtCQyxtQkFBbUIsSUFBSXRELFNBQVMsQ0FBQztBQUMxRCxRQUFNLENBQUN1RCxXQUFXQyxZQUFZLElBQUl4RCxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDeUQsVUFBVUMsV0FBVyxJQUFJMUQsU0FBUyxNQUFNO0FBQy9DLFFBQU0sQ0FBQzJELGtCQUFrQkMsbUJBQW1CLElBQUk1RCxTQUFTLEtBQUs7QUFDOUQsUUFBTSxDQUFDNkQsdUJBQXVCQyx3QkFBd0IsSUFBSTlELFNBQVMsS0FBSztBQUN4RSxRQUFNLENBQUMrRCxhQUFhQyxjQUFjLElBQUloRSxTQUFTO0FBQUEsSUFDN0NpRSxjQUFjO0FBQUEsSUFDZEMsYUFBYTtBQUFBLElBQ2JDLHFCQUFxQjtBQUFBLElBQ3JCQyxTQUFTO0FBQUEsSUFDVEMsZUFBZTtBQUFBLElBQ2ZDLGVBQWU7QUFBQSxJQUNmQyxlQUFlO0FBQUEsSUFDZkMsZ0JBQWdCO0FBQUEsRUFDbEIsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJMUUsU0FBUztBQUFBLElBQ3pDMkUsbUJBQW1CO0FBQUEsSUFDbkJDLHNCQUFzQjtBQUFBLElBQ3RCQyxlQUFlO0FBQUEsSUFDZkMscUJBQXFCO0FBQUEsSUFDckJYLHFCQUFxQjtBQUFBLEVBQ3ZCLENBQUM7QUFDRCxRQUFNLENBQUNZLGtCQUFrQkMsbUJBQW1CLElBQUloRixTQUFTLENBQUMsQ0FBQztBQUMzRCxRQUFNLENBQUNpRixlQUFlQyxnQkFBZ0IsSUFBSWxGLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNtRixtQkFBbUJDLG9CQUFvQixJQUFJcEYsU0FBUyxFQUFFO0FBQzdELFFBQU0sQ0FBQ3FGLG1CQUFtQkMsb0JBQW9CLElBQUl0RixTQUFTLEVBQUU7QUFDN0QsUUFBTSxDQUFDdUYsaUJBQWlCQyxrQkFBa0IsSUFBSXhGLFNBQVMsY0FBYztBQUVyRSxRQUFNLENBQUN5RixhQUFhQyxjQUFjLElBQUkxRixTQUFTLENBQUM7QUFDaEQsUUFBTSxDQUFDMkYsc0JBQXNCQyx1QkFBdUIsSUFBSTVGLFNBQVMsQ0FBQztBQUVsRSxRQUFNLENBQUM2RixxQkFBcUJDLHNCQUFzQixJQUFJOUYsU0FBUyxLQUFLO0FBQ3BFLFFBQU0sQ0FBQzJFLG1CQUFtQm9CLG9CQUFvQixJQUFJL0YsU0FBUyxFQUFFO0FBRTdELFFBQU0sQ0FBQ2dHLGFBQWFDLGNBQWMsSUFBSWpHLFNBQVM7QUFBQSxJQUM3Q2tHLFlBQVk7QUFBQSxJQUNaMUUsU0FBUztBQUFBLElBQ1QyRSxNQUFNO0FBQUEsRUFDUixDQUFDO0FBRUQsUUFBTUMsV0FBV2xHLFlBQVk7QUFFN0IsUUFBTSxDQUFDbUcsb0JBQW9CQyxxQkFBcUIsSUFBSXRHLFNBQVMsS0FBSztBQUNsRSxRQUFNLENBQUN1RyxrQkFBa0JDLG1CQUFtQixJQUFJeEcsU0FBUyxFQUFFO0FBQzNELFFBQU0sQ0FBQ3lHLGVBQWVDLGdCQUFnQixJQUFJMUcsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzJHLFVBQVVDLFdBQVcsSUFBSTVHLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUM2RyxpQkFBaUJDLGtCQUFrQixJQUFJOUcsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQytHLGFBQWFDLGNBQWMsSUFBSWhILFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUNpSCxvQkFBb0JDLHFCQUFxQixJQUFJbEgsU0FBUyxLQUFLO0FBQ2xFLFFBQU0sQ0FBQ21ILGdCQUFnQkMsaUJBQWlCLElBQUlwSCxTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDcUgsc0JBQXNCQyx1QkFBdUIsSUFBSXRILFNBQVMsS0FBSztBQUN0RSxRQUFNLENBQUN1SCxzQkFBc0JDLHVCQUF1QixJQUFJeEgsU0FBUyxLQUFLO0FBRXRFLFFBQU15SCw0QkFBNEJBLENBQUNDLE1BQU07QUFDdkMsVUFBTSxFQUFFQyxNQUFNLElBQUlELEVBQUVFO0FBQ3BCOUUsbUJBQWU2RSxLQUFLO0FBQUEsRUFDdEI7QUFFQSxRQUFNRSx5QkFBeUJBLENBQUNDLGFBQWE7QUFDM0N0Qix3QkFBb0JzQixRQUFRO0FBQzVCeEIsMEJBQXNCLElBQUk7QUFDMUJNLGdCQUFZLEVBQUU7QUFBQSxFQUNoQjtBQUNBLFFBQU1tQixvQkFBb0I7QUFBQSxJQUN4QixFQUFFQyxLQUFLLE1BQU1DLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVELEtBQUssbUJBQW1CQyxRQUFRLGtCQUFrQjtBQUFBLElBQ3BELEVBQUVELEtBQUssUUFBUUMsUUFBUSxnQkFBZ0I7QUFBQSxJQUN2QyxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVELEtBQUssZUFBZUMsUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVELEtBQUsscUJBQXFCQyxRQUFRLG9CQUFvQjtBQUFBLElBQ3hELEVBQUVELEtBQUssaUJBQWlCQyxRQUFRLGdCQUFnQjtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSWhELEVBQUVELEtBQUssZUFBZUMsUUFBUSxjQUFjO0FBQUEsRUFBQztBQUUvQyxRQUFNQyw2QkFBNkI7QUFBQSxJQUNqQyxFQUFFRixLQUFLLE1BQU1DLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVELEtBQUssYUFBYUMsUUFBUSxPQUFPO0FBQUEsSUFDbkMsRUFBRUQsS0FBSyxRQUFRQyxRQUFRLGdCQUFnQjtBQUFBLElBQ3ZDLEVBQUVELEtBQUssZUFBZUMsUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUWxDO0FBRUYsUUFBTUUsZ0JBQWdCO0FBQUEsSUFDcEIsRUFBRUgsS0FBSyxNQUFNQyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFRCxLQUFLLFlBQVlDLFFBQVEsZUFBZTtBQUFBLElBQzFDLEVBQUVELEtBQUssUUFBUUMsUUFBUSxnQkFBZ0I7QUFBQSxJQUN2QyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVELEtBQUssWUFBWUMsUUFBUSxlQUFlO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxrQkFBa0JDLFFBQVEsaUJBQWlCO0FBQUEsSUFDbEQsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLGNBQWM7QUFBQSxJQUN4QyxFQUFFRCxLQUFLLHFCQUFxQkMsUUFBUSxvQkFBb0I7QUFBQSxJQUN4RCxFQUFFRCxLQUFLLFlBQVlDLFFBQVEsV0FBVztBQUFBLElBQ3RDLEVBQUVELEtBQUssY0FBY0MsUUFBUSxhQUFhO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxRQUFRQyxRQUFRLE9BQU87QUFBQSxJQUM5QixFQUFFRCxLQUFLLGNBQWNDLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVELEtBQUssYUFBYUMsUUFBUSxhQUFhO0FBQUEsRUFBQztBQUc1QyxRQUFNRyx1QkFBdUI7QUFBQSxJQUMzQixFQUFFSixLQUFLLE1BQU1DLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVELEtBQUssYUFBYUMsUUFBUSxhQUFhO0FBQUEsSUFDekMsRUFBRUQsS0FBSyxRQUFRQyxRQUFRLGdCQUFnQjtBQUFBLElBQ3ZDLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFFBQU1JLHlCQUF5QjtBQUFBLElBQzdCLEVBQUVMLEtBQUssTUFBTUMsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxrQkFBa0JDLFFBQVEscUJBQXFCO0FBQUEsSUFDdEQsRUFBRUQsS0FBSyxvQkFBb0JDLFFBQVEsbUJBQW1CO0FBQUEsSUFDdEQsRUFBRUQsS0FBSyxhQUFhQyxRQUFRLGdCQUFnQjtBQUFBLElBQzVDLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGVBQWU7QUFBQTtBQUFBLElBRTlDLEVBQUVELEtBQUssY0FBY0MsUUFBUSxtQkFBbUI7QUFBQSxJQUNoRCxFQUFFRCxLQUFLLFdBQVdDLFFBQVEsMkJBQTJCO0FBQUEsSUFDckQsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQTtBQUFBLElBRWxDLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFRCxLQUFLLGtCQUFrQkMsUUFBUSxpQkFBaUI7QUFBQSxJQUNsRCxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVELEtBQUssbUJBQW1CQyxRQUFRLGtCQUFrQjtBQUFBLElBQ3BELEVBQUVELEtBQUssVUFBVUMsUUFBUSxhQUFhO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUt0QyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsZUFBZTtBQUFBO0FBQUEsSUFFNUMsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBSXJDLFFBQU1LLHlCQUF5QnJJLFlBQVksWUFBWTtBQUNyRCxRQUFJO0FBQ0YsWUFBTXNJLFdBQVcsTUFBTXBJLElBQUlxSSxJQUFJLHdCQUF3QjtBQUN2RDlDLHFCQUFlNkMsVUFBVUUsTUFBTUEsT0FBTyxDQUFDLEVBQUVDLGdCQUFnQixDQUFDO0FBQUEsSUFDNUQsU0FBU0MsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHdDQUF3Q0EsS0FBSztBQUMzRGpELHFCQUFlLENBQUM7QUFBQSxJQUNsQjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTW1ELGtDQUFrQzVJLFlBQVksWUFBWTtBQUM5RCxRQUFJO0FBQ0YsWUFBTXNJLFdBQVcsTUFBTXBJLElBQUlxSSxJQUFJLGtDQUFrQztBQUNqRTVDLDhCQUF3QjJDLFVBQVVFLE1BQU1BLE9BQU8sQ0FBQyxFQUFFQyxnQkFBZ0IsQ0FBQztBQUFBLElBQ3JFLFNBQVNDLE9BQU87QUFDZEMsY0FBUUQsTUFBTSx3Q0FBd0NBLEtBQUs7QUFDM0QvQyw4QkFBd0IsQ0FBQztBQUFBLElBQzNCO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxRQUFNa0QsNEJBQTRCLFlBQVk7QUFDNUNoQyx1QkFBbUIsSUFBSTtBQUN2QkYsZ0JBQVksRUFBRTtBQUNkLFFBQUk7QUFDRixZQUFNbUMsUUFBUUMsS0FBS0MsTUFBTUMsYUFBYUMsUUFBUSxNQUFNLENBQUM7QUFDckQsVUFBSSxDQUFDSixPQUFPSyxVQUFVO0FBQ3BCeEMsb0JBQVksNkNBQTZDO0FBQ3pERSwyQkFBbUIsS0FBSztBQUN4QjtBQUFBLE1BQ0Y7QUFFQSxZQUFNeUIsV0FBVyxNQUFNcEksSUFBSWtKLEtBQUssZ0JBQWdCO0FBQUEsUUFDOUNDLGFBQWFQLE1BQU1PO0FBQUFBLFFBQ25CRixVQUFVM0M7QUFBQUEsTUFDWixDQUFDO0FBRUQsVUFBSThCLFNBQVNFLE1BQU1jLE9BQU87QUFDeEJqRCw4QkFBc0IsS0FBSztBQUMzQkkseUJBQWlCLEVBQUU7QUFDbkJFLG9CQUFZLEVBQUU7QUFHZCxZQUNFTCxxQkFBcUIsb0JBQ3JCQSxxQkFBcUIsb0JBQ3JCO0FBQ0FTLHlCQUFlLElBQUk7QUFDbkJ3QyxxQkFBVyxNQUFNeEMsZUFBZSxLQUFLLEdBQUcsR0FBSztBQUFBLFFBQy9DO0FBRUFaLGlCQUFTRyxnQkFBZ0I7QUFBQSxNQUMzQjtBQUFBLElBQ0YsU0FBU2tELEtBQUs7QUFDWjdDO0FBQUFBLFFBQ0U2QyxJQUFJbEIsVUFBVUUsTUFBTWpILFdBQVc7QUFBQSxNQUNqQztBQUFBLElBQ0YsVUFBQztBQUNDc0YseUJBQW1CLEtBQUs7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFFQS9HLFlBQVUsTUFBTTtBQUNkLFVBQU0ySixPQUFPUixhQUFhQyxRQUFRLE1BQU07QUFDeEMsVUFBTVEsVUFBVVgsS0FBS0MsTUFBTVMsSUFBSTtBQUMvQixRQUNFQyxXQUNBQSxRQUFRQyx1QkFBdUJDLG9CQUFvQkMsY0FDbkQ7QUFDQSxZQUFNQyxXQUNKSixRQUFRQyx1QkFBdUJDLG9CQUFvQkMsaUJBQ25EO0FBQ0Y1RyxxQkFBZTZHLFFBQVE7QUFBQSxJQUN6QjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUxoSyxZQUFVLE1BQU07QUFDZCxVQUFNaUssY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRixjQUFNekIsV0FBVyxNQUFNcEksSUFBSXFJLElBQUksd0JBQXdCO0FBQ3ZEeEcsa0JBQVV1RyxTQUFTRSxJQUFJO0FBQUEsTUFDekIsU0FBU0UsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxNQUNuRDtBQUFBLElBQ0Y7QUFDQXFCLGdCQUFZO0FBQUEsRUFDZCxHQUFHLENBQUNqSCxhQUFhLENBQUM7QUFHbEJoRCxZQUFVLE1BQU07QUFDZHVJLDJCQUF1QjtBQUFBLEVBQ3pCLEdBQUcsQ0FBQ0Esd0JBQXdCdkYsYUFBYSxDQUFDO0FBRTFDaEQsWUFBVSxNQUFNO0FBQ2Q4SSxvQ0FBZ0M7QUFBQSxFQUNsQyxHQUFHLENBQUNBLGlDQUFpQzlGLGFBQWEsQ0FBQztBQUVuRGhELFlBQVUsTUFBTTtBQUNkLFVBQU1rSyxtQkFBbUIsWUFBWTtBQUNuQyxVQUFJO0FBQ0YsY0FBTTFCLFdBQVcsTUFBTXBJLElBQUlxSSxJQUFJLG9CQUFvQjtBQUNuRGxGO0FBQUFBLFVBQ0U0RyxNQUFNQyxRQUFRNUIsU0FBU0UsSUFBSSxJQUFJRixTQUFTRSxLQUFLMkIsU0FBUztBQUFBLFFBQ3hEO0FBQUEsTUFDRixTQUFTekIsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSwrQkFBK0JBLEtBQUs7QUFDbERyRiw0QkFBb0IsQ0FBQztBQUFBLE1BQ3ZCO0FBQUEsSUFDRjtBQUNBMkcscUJBQWlCO0FBQUEsRUFDbkIsR0FBRyxDQUFDbEgsYUFBYSxDQUFDO0FBRWxCaEQsWUFBVSxNQUFNO0FBQ2QsVUFBTXNLLGFBQWEsWUFBWTtBQUM3QixVQUFJO0FBQ0YsY0FBTTlCLFdBQVcsTUFBTXBJLElBQUlxSSxJQUFJLGdCQUFnQjtBQUMvQ3RHLGlCQUFTcUcsU0FBU0UsSUFBSTtBQUFBLE1BQ3hCLFNBQVNFLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sNkJBQTZCQSxLQUFLO0FBQUEsTUFDbEQ7QUFBQSxJQUNGO0FBQ0EwQixlQUFXO0FBQUEsRUFDYixHQUFHLENBQUN0SCxhQUFhLENBQUM7QUFFbEJoRCxZQUFVLE1BQU07QUFDZCxVQUFNdUssY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRixjQUFNL0IsV0FBVyxNQUFNcEksSUFBSXFJLElBQUksWUFBWTtBQUMzQyxjQUFNK0IsaUJBQWlCaEMsU0FBU0UsS0FBSytCLFNBQVMsSUFBSUM7QUFBQUEsVUFDaEQsQ0FBQ0QsVUFBVUEsTUFBTUUsZUFBZTtBQUFBLFFBQ2xDO0FBQ0F0SSxrQkFBVW1JLGlCQUFpQixFQUFFO0FBQUEsTUFDL0IsU0FBUzVCLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sMEJBQTBCQSxLQUFLO0FBQUEsTUFDL0M7QUFBQSxJQUNGO0FBQ0EyQixnQkFBWTtBQUFBLEVBQ2QsR0FBRyxDQUFDdkgsYUFBYSxDQUFDO0FBRWxCaEQsWUFBVSxNQUFNO0FBQ2QsVUFBTTRLLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTXBDLFdBQVcsTUFBTXBJLElBQUlxSSxJQUFJLGtCQUFrQjtBQUNqRCxjQUFNb0MsaUJBQWlCckMsU0FBU0UsUUFBUSxJQUFJZ0M7QUFBQUEsVUFDMUMsQ0FBQ0ksVUFBVUEsTUFBTUgsZUFBZTtBQUFBLFFBQ2xDO0FBQ0FwSSxrQkFBVXNJLGlCQUFpQixFQUFFO0FBQUEsTUFDL0IsU0FBU2pDLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sMEJBQTBCQSxLQUFLO0FBQUEsTUFDL0M7QUFBQSxJQUNGO0FBQ0FnQyxnQkFBWTtBQUFBLEVBQ2QsR0FBRyxDQUFDNUgsYUFBYSxDQUFDO0FBRWxCaEQsWUFBVSxNQUFNO0FBQ2QsVUFBTStLLGlCQUFpQixZQUFZO0FBQ2pDLFVBQUk7QUFDRixjQUFNdkMsV0FBVyxNQUFNcEksSUFBSXFJLElBQUkscUJBQXFCO0FBQ3BELGNBQU11QyxvQkFBb0J4QyxTQUFTRSxNQUFNdUMsWUFBWSxJQUFJUDtBQUFBQSxVQUN2RCxDQUFDTyxhQUFhQSxTQUFTTixlQUFlO0FBQUEsUUFDeEM7QUFDQWxJLHFCQUFhdUksb0JBQW9CLEVBQUU7QUFBQSxNQUNyQyxTQUFTcEMsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw2QkFBNkJBLEtBQUs7QUFBQSxNQUNsRDtBQUFBLElBQ0Y7QUFDQW1DLG1CQUFlO0FBQUEsRUFDakIsR0FBRyxDQUFDL0gsYUFBYSxDQUFDO0FBRWxCaEQsWUFBVSxNQUFNO0FBQ2QsVUFBTWtMLHFCQUFxQixZQUFZO0FBQ3JDLFVBQUk7QUFDRixjQUFNMUMsV0FBVyxNQUFNcEksSUFBSXFJLElBQUksbUNBQW1DO0FBQ2xFOUYseUJBQWlCNkYsVUFBVUUsTUFBTXlDLGVBQWUsQ0FBQztBQUFBLE1BQ25ELFNBQVN2QyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLHdDQUF3Q0EsS0FBSztBQUFBLE1BQzdEO0FBQUEsSUFDRjtBQUNBc0MsdUJBQW1CO0FBQUEsRUFDckIsR0FBRyxDQUFDbEksYUFBYSxDQUFDO0FBK0JsQixRQUFNb0ksaUJBQWlCQSxDQUFDeEQsVUFBVTtBQUNoQyxRQUFJWixhQUFhO0FBQ2YsYUFBT1ksTUFBTXlELGVBQWU7QUFBQSxJQUM5QjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBRUEsUUFBTUMsd0JBQXdCLE9BQU9DLE1BQU1DLFVBQVVDLFVBQVU7QUFDN0QsVUFBTUMsV0FBVztBQUFBLGtCQUNISCxLQUFLSSxpQkFDYkosS0FBS0ksZUFBZUMsUUFBUSxZQUFZLFVBQVUsSUFDbEQsR0FBRztBQUFBLGlCQUVJSixVQUFVSyxhQUFhLEdBQUc7QUFBQSxnQkFDM0JMLFVBQVVNLGdCQUFnQixHQUFHO0FBQUEsb0JBQ3pCUCxLQUFLUSxvQkFBb0IsR0FBRztBQUFBLFVBQ3RDUixLQUFLUyxVQUFVLEdBQUcsR0FBR1QsS0FBS1UsVUFBVUMsZUFDcEMsS0FBS1gsS0FBS1UsU0FBU0MsWUFBWSxNQUMvQixFQUFFO0FBQUEsZ0JBRUlYLEtBQUtZLGdCQUFnQixDQUFDO0FBQUEsVUFDNUJaLEtBQUthLFVBQVUsQ0FBQztBQUFBLG1CQUNQYixLQUFLYyxtQkFBbUIsQ0FBQztBQUFBLGtCQUMxQmQsS0FBS2Usa0JBQWtCLENBQUM7QUFBQSxjQUM1QmYsS0FBS2dCLGNBQWMsQ0FBQztBQUFBLFdBQ3ZCaEIsS0FBS2lCLFdBQVcsR0FBRztBQUFBLG9CQUNWakIsS0FBS2tCLG1CQUNmLElBQUlDLEtBQUtuQixLQUFLa0IsZ0JBQWdCLEVBQUVFLG1CQUFtQixPQUFPLElBQzFELEdBQUc7QUFBQSxjQUVDbEIsT0FBT21CLGFBQ1huQixNQUFNbUIsYUFDTnJCLEtBQUtVLFdBQ0gsVUFDQVYsS0FBS3NCLFVBQ0gsU0FDQSxHQUFHO0FBQUEsV0FFTnRCLEtBQUt1QixXQUFXQyxXQUNyQnhCLEtBQUtVLFVBQVVBLFlBQ2ZWLEtBQUtzQixTQUFTQSxXQUNkLEdBQUc7QUFBQSxlQUVNdEIsS0FBS3VCLFdBQVdFLGVBQWUsR0FBRztBQUFBLGdCQUNqQ3pCLEtBQUt1QixXQUFXRyxnQkFBZ0IsR0FBRztBQUFBLGtCQUNqQzFCLEtBQUtVLFVBQVVpQixrQkFBa0IsR0FBRztBQUFBLGNBQ3hDM0IsS0FBSzRCLFVBQVVDLFFBQ3ZCN0IsS0FBSzRCLFVBQVVFLGNBQ2YsR0FBRztBQUFBLEVBRVBDLEtBQUs7QUFFSCxRQUFJO0FBQ0YsWUFBTUMsVUFBVUMsVUFBVUMsVUFBVS9CLFFBQVE7QUFDNUNqSyxjQUFRaU0sUUFBUSw2QkFBNkI7QUFBQSxJQUMvQyxTQUFTOUUsT0FBTztBQUNkQyxjQUFRRCxNQUFNLG1CQUFtQkEsS0FBSztBQUN0Q25ILGNBQVFtSCxNQUFNLG9DQUFvQztBQUFBLElBQ3BEO0FBQUEsRUFDRjtBQUVBLFFBQU0rRSx5QkFBeUIsWUFBWTtBQUN6QyxRQUFJO0FBQ0ZsRyw4QkFBd0IsSUFBSTtBQUU1QixZQUFNbUcsTUFBTSxNQUFNeE4sSUFBSXFJLElBQUksMEJBQTBCO0FBRXBEbEQsMkJBQXFCcUksS0FBS2xGLE1BQU1BLFFBQVEsRUFBRTtBQUFBLElBQzVDLFNBQVNFLE9BQU87QUFDZEMsY0FBUUQsTUFBTSw0Q0FBNENBLEtBQUs7QUFDL0RyRCwyQkFBcUIsRUFBRTtBQUFBLElBQ3pCLFVBQUM7QUFDQ2tDLDhCQUF3QixLQUFLO0FBQUEsSUFDL0I7QUFBQSxFQUNGO0FBRUEsUUFBTW9HLHlCQUF5QixZQUFZO0FBQ3pDLFFBQUk7QUFDRmhLLDBCQUFvQixJQUFJO0FBRXhCLFlBQU0rSixNQUFNLE1BQU14TixJQUFJcUksSUFBSSxxQ0FBcUM7QUFFL0R0RCx1QkFBaUJ5SSxLQUFLbEYsTUFBTUEsUUFBUSxFQUFFO0FBQUEsSUFDeEMsU0FBU0UsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDRDQUE0Q0EsS0FBSztBQUMvRHpELHVCQUFpQixFQUFFO0FBQUEsSUFDckIsVUFBQztBQUNDdEIsMEJBQW9CLEtBQUs7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNaUsseUJBQXlCLE9BQU9DLFVBQVU7QUFDOUMsUUFBSTtBQUNGaEssK0JBQXlCLElBQUk7QUFFN0IsWUFBTWlLLE1BQU1ELFFBQ1IsdUNBQXVDQSxLQUFLLEtBQzVDO0FBRUosWUFBTUgsTUFBTSxNQUFNeE4sSUFBSXFJLElBQUl1RixHQUFHO0FBRTdCM0ksMkJBQXFCdUksS0FBS2xGLE1BQU1BLFFBQVEsRUFBRTtBQUFBLElBQzVDLFNBQVNFLE9BQU87QUFDZEMsY0FBUUQsTUFBTSw0Q0FBNENBLEtBQUs7QUFDL0R2RCwyQkFBcUIsRUFBRTtBQUFBLElBQ3pCLFVBQUM7QUFDQ3RCLCtCQUF5QixLQUFLO0FBQUEsSUFDaEM7QUFBQSxFQUNGO0FBRUEsUUFBTWtLLDBCQUEwQjdJLG1CQUFtQjhJLElBQUksQ0FBQzNDLE1BQU00QyxVQUFVO0FBQ3RFLFVBQU0zQyxXQUNKRCxLQUFLVSxVQUFVVCxZQUNmRCxLQUFLdUIsV0FBV3NCLFdBQ2hCLENBQUM7QUFFSCxVQUFNM0MsUUFBUUYsS0FBS3VCLFdBQVd1QixZQUFZLENBQUM7QUFFM0MsV0FBTztBQUFBLE1BQ0xDLElBQUlILFFBQVE7QUFBQSxNQUNaeEMsZ0JBQWdCSixLQUFLSSxpQkFDakJKLEtBQUtJLGVBQWVDLFFBQVEsWUFBWSxVQUFVLElBQ2xEO0FBQUEsTUFDSkMsV0FBV0wsU0FBU0ssYUFBYTtBQUFBLE1BQ2pDQyxjQUFjTixTQUFTTSxnQkFBZ0I7QUFBQSxNQUN2Q0Msa0JBQWtCUixLQUFLUSxvQkFBb0I7QUFBQSxNQUMzQ0MsUUFDRSx1QkFBQyxVQUFLLFdBQVUsb0NBQ2JUO0FBQUFBLGFBQUtTLFVBQVU7QUFBQSxRQUNmVCxLQUFLVSxVQUFVQyxnQkFDZCx1QkFBQyxVQUFNO0FBQUE7QUFBQSxVQUNIWCxLQUFLVSxTQUFTQztBQUFBQSxVQUFhO0FBQUEsYUFEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUVGQyxjQUFjWixLQUFLWSxnQkFBZ0I7QUFBQSxNQUNuQ0MsUUFBUSx1QkFBQyxVQUFLLFdBQVUsK0JBQ3JCYixlQUFLYSxVQUFVLEtBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVSO0FBQUEsTUFDQUMsaUJBQWlCZCxLQUFLYyxpQkFBaUJrQyxRQUFRLENBQUMsS0FBSztBQUFBLE1BQ3JEakMsZ0JBQWdCZixLQUFLZSxrQkFBa0I7QUFBQSxNQUN2Q0MsWUFBWWhCLEtBQUtnQixjQUFjO0FBQUEsTUFDL0JDLFNBQVNqQixLQUFLaUIsV0FBVztBQUFBLE1BQ3pCQyxrQkFBa0JsQixLQUFLa0IsbUJBQ25CLElBQUlDLEtBQUtuQixLQUFLa0IsZ0JBQWdCLEVBQUVFLG1CQUFtQixPQUFPLElBQzFEO0FBQUEsTUFDSkMsWUFBWW5CLE1BQU1tQixhQUFhbkIsTUFBTW1CLGFBQWFyQixLQUFLVSxXQUFXLFVBQVVWLEtBQUtzQixVQUFVLFNBQVM7QUFBQSxNQUNwR0UsU0FBU3hCLEtBQUt1QixXQUFXQyxXQUFXeEIsS0FBS1UsVUFBVUEsWUFBWVYsS0FBS3NCLFNBQVNBLFdBQVc7QUFBQSxNQUN4RkcsYUFBYXpCLEtBQUt1QixXQUFXRSxlQUFlO0FBQUEsTUFDNUNDLGNBQWMxQixLQUFLdUIsV0FBV0csZ0JBQWdCO0FBQUE7QUFBQSxNQUU5Q0MsZ0JBQWdCM0IsS0FBS1UsVUFBVWlCLGtCQUFrQjtBQUFBO0FBQUEsTUFFakRHLFlBQ0U5QixLQUFLNEIsVUFBVUMsUUFDZjdCLEtBQUs0QixVQUFVRSxjQUNmO0FBQUEsTUFDRm1CLGtCQUFrQmpELEtBQUt1QixXQUFXMEIsb0JBQW9CO0FBQUEsTUFDdERDLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFNO0FBQUEsWUFDSkMsT0FBTztBQUFBLGNBQ0w7QUFBQSxnQkFDRXpHLEtBQUs7QUFBQSxnQkFDTDBHLE9BQ0UsdUJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQU07QUFBQSxzQkFDSmhELGdCQUFnQkosS0FBS0ksa0JBQWtCO0FBQUEsc0JBQ3ZDRSxXQUFXTCxTQUFTSyxhQUFhO0FBQUEsc0JBQ2pDQyxjQUFjTixTQUFTTSxnQkFBZ0I7QUFBQSxzQkFDdkNDLGtCQUFrQlIsS0FBS1Esb0JBQW9CO0FBQUEsc0JBQzNDQyxRQUFRVCxLQUFLUyxVQUFVO0FBQUEsc0JBQ3ZCRyxjQUFjWixLQUFLWSxnQkFBZ0I7QUFBQSxzQkFDbkNDLFFBQVFiLEtBQUthLFVBQVU7QUFBQSxzQkFDdkJDLGlCQUFpQmQsS0FBS2MsbUJBQW1CO0FBQUEsc0JBQ3pDQyxnQkFBZ0JmLEtBQUtlLGtCQUFrQjtBQUFBLHNCQUN2Q0MsWUFBWWhCLEtBQUtnQixjQUFjO0FBQUEsc0JBQy9CQyxTQUFTakIsS0FBS2lCLFdBQVc7QUFBQSxzQkFDekJDLGtCQUFrQmxCLEtBQUtrQixtQkFDbkIsSUFBSUMsS0FBS25CLEtBQUtrQixnQkFBZ0IsRUFBRUUsbUJBQW1CLE9BQU8sSUFDMUQ7QUFBQSxzQkFDSkMsWUFBWW5CLE1BQU1tQixjQUFjO0FBQUEsc0JBQ2hDRyxTQUFTeEIsS0FBS3VCLFdBQVdDLFdBQVc7QUFBQSxzQkFDcENDLGFBQWF6QixLQUFLdUIsV0FBV0UsZUFBZTtBQUFBLHNCQUM1Q0MsY0FBYzFCLEtBQUt1QixXQUFXRyxnQkFBZ0I7QUFBQSxzQkFDOUNoQixVQUFVVixLQUFLVSxVQUFVQSxZQUFZO0FBQUEsc0JBQ3JDaUIsZ0JBQWdCM0IsS0FBS1UsVUFBVWlCLGtCQUFrQjtBQUFBLHNCQUNqRGhCLGNBQWNYLEtBQUtVLFVBQVVDLGdCQUFnQjtBQUFBLHNCQUM3Q21CLFlBQ0U5QixLQUFLNEIsVUFBVUMsUUFDZjdCLEtBQUs0QixVQUFVRSxjQUNmO0FBQUEsb0JBQ0o7QUFBQTtBQUFBLGtCQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBMkJJLEtBNUJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBOEJBO0FBQUEsY0FFSjtBQUFBLGNBQ0E7QUFBQSxnQkFDRXBGLEtBQUs7QUFBQSxnQkFDTDBHLE9BQ0U7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVMsTUFDUHJELHNCQUFzQkMsTUFBTUMsVUFBVUMsS0FBSztBQUFBLG9CQUM1QztBQUFBO0FBQUEsa0JBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BO0FBQUEsY0FFSjtBQUFBLFlBQUM7QUFBQSxVQUVMO0FBQUEsVUFFQSxpQ0FBQyxZQUFTLFdBQVUsNEJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRDO0FBQUE7QUFBQSxRQXZEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1Bd0RBLEtBekRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwREE7QUFBQSxJQUVKO0FBQUEsRUFDRixDQUFDO0FBQ0QsUUFBTW1ELHdCQUF3QjFKLGNBQWNnSixJQUFJLENBQUMzQyxNQUFNNEMsV0FBVztBQUFBLElBQ2hFRyxJQUFJSCxRQUFRO0FBQUEsSUFDWlUsYUFBYXRELEtBQUtzRCxlQUFlO0FBQUEsSUFDakNoRCxXQUFXTixLQUFLTSxhQUFhO0FBQUEsSUFDN0JDLGNBQWNQLEtBQUtPLGdCQUFnQjtBQUFBLElBQ25DZ0QsUUFBUXZELEtBQUt3RCxVQUFVLGNBQWM7QUFBQSxJQUNyQ0MsWUFBWXpELEtBQUswRCwyQkFBMkIsSUFBSXZDLEtBQUtuQixLQUFLMEQsd0JBQXdCLEVBQUU1RCxlQUFlLElBQUk7QUFBQSxFQUN6RyxFQUFFO0FBRUZyTCxZQUFVLE1BQU07QUFDZCxVQUFNa0ssbUJBQW1CLFlBQVk7QUFDbkMsVUFBSTtBQUNGL0MsOEJBQXNCLElBQUk7QUFFMUIsY0FBTStILFFBQVEsb0JBQUl4QyxLQUFLO0FBQ3ZCLGNBQU15QyxXQUFXLG9CQUFJekMsS0FBSztBQUMxQnlDLGlCQUFTQyxRQUFRRixNQUFNRyxRQUFRLElBQUksQ0FBQztBQUdwQyxjQUFNNU8sc0JBQXFCQSxDQUFDNk8sU0FBUztBQUNuQyxnQkFBTUMsT0FBT0QsS0FBS0UsWUFBWTtBQUM5QixnQkFBTUMsUUFBUUMsT0FBT0osS0FBS0ssU0FBUyxJQUFJLENBQUMsRUFBRUMsU0FBUyxHQUFHLEdBQUc7QUFDekQsZ0JBQU1DLE1BQU1ILE9BQU9KLEtBQUtELFFBQVEsQ0FBQyxFQUFFTyxTQUFTLEdBQUcsR0FBRztBQUNsRCxpQkFBTyxHQUFHTCxJQUFJLElBQUlFLEtBQUssSUFBSUksR0FBRztBQUFBLFFBQ2hDO0FBRUEsY0FBTUMsV0FBV3JQLG9CQUFtQjBPLFFBQVE7QUFDNUMsY0FBTVksU0FBU3RQLG9CQUFtQnlPLEtBQUs7QUFFdkMsY0FBTSxDQUFDYyxnQkFBZ0JDLG9CQUFvQixJQUFJLE1BQU1DLFFBQVFDO0FBQUFBLFVBQUk7QUFBQSxZQUMvRC9QLElBQUlxSSxJQUFJLG9CQUFvQjtBQUFBLFlBQzVCckksSUFBSXFJO0FBQUFBLGNBQ0YscURBQXFEcUgsUUFBUSxZQUFZQyxNQUFNO0FBQUEsWUFDakY7QUFBQSxVQUFDO0FBQUEsUUFDRjtBQUVELGNBQU1LLGdCQUFnQkgsc0JBQXNCdkgsS0FBS3dGLElBQUksQ0FBQ3pDLE9BQU8wQyxVQUFVO0FBQ3JFLGNBQUksQ0FBQzFDLE1BQU00QyxZQUFZLENBQUM1QyxNQUFNMkMsUUFBUyxRQUFPLENBQUM7QUFDL0MsaUJBQU87QUFBQSxZQUNMaUMsS0FBSzVFLE9BQU80RTtBQUFBQSxZQUNaL0IsSUFBSUgsUUFBUTtBQUFBLFlBQ1pmLE1BQU0zQixPQUFPMkMsU0FBU3ZDO0FBQUFBLFlBQ3RCQyxjQUFjTCxPQUFPMkMsU0FBU3RDO0FBQUFBLFlBQzlCYyxZQUFZbkIsT0FBTzRDLFVBQVV6QjtBQUFBQSxZQUM3QjBELGFBQWE3RSxPQUFPNEMsVUFBVWlDO0FBQUFBLFlBQzlCckQsY0FBY3hCLE9BQU93QjtBQUFBQSxZQUNyQnNELGlCQUFpQjlFLE9BQU8rRSxXQUNwQkMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxFQUNiQSxNQUFNLEdBQUcsRUFDVEMsUUFBUSxFQUNSQyxLQUFLLEdBQUc7QUFBQSxZQUNYQyxtQkFBbUJuRixPQUFPbUY7QUFBQUEsWUFDMUJDLFFBQVFwRixNQUFNc0I7QUFBQUEsWUFDZCtELGVBQWVyRixPQUFPMkMsU0FBUzJDO0FBQUFBO0FBQUFBO0FBQUFBO0FBQUFBLFlBSS9CQyxhQUNFdkYsT0FBTzJDLFNBQVMyQyxrQkFBa0IsaUJBQzlCLGlCQUNBdEYsT0FBTzJDLFNBQVM2QyxtQkFBbUI3RCxRQUNuQzNCLE9BQU8yQyxTQUFTNkMsbUJBQW1CbkYsZUFDakMsR0FBR0wsTUFBTTJDLFFBQVE2QyxrQkFBa0I3RCxJQUFJLE1BQU0zQixNQUFNMkMsUUFBUTZDLGtCQUFrQm5GLFlBQVksS0FDekZMLE9BQU8yQyxTQUFTOEMsZ0JBQWdCOUQsUUFDaEMzQixPQUFPMkMsU0FBUzhDLGdCQUFnQnBGLGVBQzlCLEdBQUdMLE1BQU0yQyxRQUFROEMsZUFBZTlELElBQUksTUFBTTNCLE1BQU0yQyxRQUFROEMsZUFBZXBGLFlBQVksS0FDbkZMLE9BQU8yQyxTQUFTK0MsbUJBQW1CdEYsYUFDbkNKLE9BQU8yQyxTQUFTK0MsbUJBQW1CckYsZUFDakMsR0FBR0wsTUFBTTJDLFFBQVErQyxrQkFBa0J0RixTQUFTLE1BQU1KLE1BQU0yQyxRQUFRK0Msa0JBQWtCckYsWUFBWSxLQUM5RjtBQUFBLFVBQ2Q7QUFBQSxRQUNGLENBQUM7QUFDRHZJO0FBQUFBLFVBQ0U0RyxNQUFNQyxRQUFRNEYsZUFBZXRILElBQUksSUFBSXNILGVBQWV0SCxLQUFLMkIsU0FBUztBQUFBLFFBQ3BFO0FBQ0ExRixxQkFBYSxDQUFDeU0sVUFBVTtBQUFBLFVBQ3RCLEdBQUdBO0FBQUFBO0FBQUFBLFVBQ0h2TSxzQkFBc0JzRixNQUFNQyxRQUFRZ0csYUFBYSxJQUM3Q0EsZ0JBQ0E7QUFBQSxRQUNOLEVBQUU7QUFBQSxNQUNKLFNBQVN4SCxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLCtCQUErQkEsS0FBSztBQUNsRHJGLDRCQUFvQixDQUFDO0FBQ3JCb0IscUJBQWEsRUFBRUMsbUJBQW1CLElBQUlDLHNCQUFzQixHQUFHLENBQUM7QUFBQSxNQUNsRSxVQUFDO0FBQ0NzQyw4QkFBc0IsS0FBSztBQUFBLE1BQzdCO0FBQUEsSUFDRjtBQUNBK0MscUJBQWlCO0FBQUEsRUFDbkIsR0FBRyxDQUFDbEgsYUFBYSxDQUFDO0FBRWxCaEQsWUFBVSxNQUFNO0FBQ2QsVUFBTXFSLGVBQWUsWUFBWTtBQUMvQixVQUFJO0FBQ0ZoSywwQkFBa0IsSUFBSTtBQUN0QkUsZ0NBQXdCLElBQUk7QUFFNUIsY0FBTSxDQUFDK0osZ0JBQWdCQyxlQUFlQyxzQkFBc0IsSUFBSSxNQUFNdEIsUUFBUUM7QUFBQUEsVUFBSTtBQUFBLFlBQ2hGL1AsSUFBSXFJLElBQUksNEJBQTRCO0FBQUEsWUFDcENySSxJQUFJcUksSUFBSSw4Q0FBOEM7QUFBQSxZQUN0RHJJLElBQUlxSSxJQUFJLDZCQUE2QjtBQUFBLFVBQUM7QUFBQSxRQUN2QztBQUVELGNBQU0ySCxnQkFBZ0JrQixnQkFBZ0I1SSxNQUFNQSxNQUFNd0Y7QUFBQUEsVUFDaEQsQ0FBQ3pDLE9BQU8wQyxVQUFVO0FBQ2hCLGdCQUFJLENBQUMxQyxNQUFNNEUsT0FBTyxDQUFDNUUsTUFBTTJDLFFBQVMsUUFBTyxDQUFDO0FBQzFDLG1CQUFPO0FBQUEsY0FDTGlDLEtBQUs1RSxPQUFPNEU7QUFBQUEsY0FDWi9CLElBQUlILFFBQVE7QUFBQSxjQUNaZixNQUFNM0IsT0FBTzJDLFNBQVN2QztBQUFBQSxjQUN0QkMsY0FBY0wsT0FBTzJDLFNBQVN0QztBQUFBQSxjQUM5QjJGLFVBQVVoRyxPQUFPZ0csVUFDYmhCLE1BQU0sR0FBRyxFQUFFLENBQUMsRUFDYkEsTUFBTSxHQUFHLEVBQ1RDLFFBQVEsRUFDUkMsS0FBSyxHQUFHO0FBQUEsY0FDWHZFLFFBQVFYLE9BQU9XO0FBQUFBLGNBQ2ZzRixVQUFVakcsT0FBT2lHO0FBQUFBLGNBQ2pCL0YsZ0JBQWdCRixPQUFPaUcsYUFBYSxXQUNoQyxZQUFZakcsT0FBT2tHLGlCQUFpQixHQUFHO0FBQUEsOEJBQzNCbEcsT0FBT21HLGNBQWNuRyxNQUFNbUcsWUFBWW5CLE1BQU0sR0FBRyxFQUFFLENBQUMsRUFBRUEsTUFBTSxHQUFHLEVBQUVDLFFBQVEsRUFBRUMsS0FBSyxHQUFHLElBQUksR0FBRyxLQUFLbEYsT0FBT0U7QUFBQUEsY0FDckhrRyxTQUFTcEcsT0FBT29HO0FBQUFBLGNBQ2hCQyxtQkFBbUJyRyxPQUFPcUc7QUFBQUEsY0FDMUJDLFVBQVV0RyxPQUFPc0c7QUFBQUEsY0FDakJDLE1BQU12RyxPQUFPdUc7QUFBQUEsY0FDYkMsWUFBWXhHLE9BQU93RyxZQUFZN0U7QUFBQUEsY0FDL0JvRCxXQUFXL0UsT0FBTytFLFdBQ2RDLE1BQU0sR0FBRyxFQUFFLENBQUMsRUFDYkEsTUFBTSxHQUFHLEVBQ1RDLFFBQVEsRUFDUkMsS0FBSyxHQUFHO0FBQUEsY0FDWHVCLFlBQVl6RyxPQUFPeUc7QUFBQUEsWUFDckI7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUNBak4sNEJBQW9Cc00sZUFBZTdJLE1BQU15SixXQUFXLENBQUMsQ0FBQztBQUV0RCxjQUFNQywwQkFBMEJiLGVBQWU3SSxNQUFNQSxNQUFNd0Y7QUFBQUEsVUFDekQsQ0FBQ3pDLE9BQU8wQyxVQUFVO0FBRWhCLGdCQUFJLENBQUMxQyxNQUFNNEUsSUFBSyxRQUFPO0FBQ3ZCLG1CQUFPO0FBQUEsY0FDTEEsS0FBSzVFLE9BQU80RTtBQUFBQSxjQUNaL0IsSUFBSUgsUUFBUTtBQUFBLGNBQ1pmLE1BQU0zQixPQUFPMkMsU0FBU3ZDO0FBQUFBLGNBQ3RCQyxjQUFjTCxPQUFPMkMsU0FBU3RDLGdCQUFnQkwsT0FBTzRHO0FBQUFBLGNBQ3JEckcsUUFBUVAsT0FBT087QUFBQUEsY0FDZjhDLFFBQVFyRCxPQUFPcUQ7QUFBQUEsY0FDZjBCLFdBQVcvRSxPQUFPK0UsV0FDZEMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxFQUNiQSxNQUFNLEdBQUcsRUFDVEMsUUFBUSxFQUNSQyxLQUFLLEdBQUc7QUFBQSxZQUNiO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFDQSxjQUFNMkIsK0JBQ0pkLHdCQUF3QjlJLE1BQ3BCZ0M7QUFBQUEsVUFDQSxDQUFDYyxhQUFhQSxVQUFVc0QsV0FBVztBQUFBLFFBQ3JDLEdBQ0VaLElBQUksQ0FBQzFDLFVBQVUyQyxXQUFXO0FBQUEsVUFDMUJHLElBQUlILFFBQVE7QUFBQSxVQUNaZixNQUFNNUIsVUFBVUs7QUFBQUEsVUFDaEJDLGNBQWNOLFVBQVVNO0FBQUFBLFVBQ3hCMEUsV0FBV2hGLFVBQVVnRixXQUFXQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsVUFDNUM4QixTQUFTL0csVUFBVStHO0FBQUFBO0FBQUFBLFVBRW5CekQsUUFBUXRELFVBQVVzRDtBQUFBQSxVQUNsQkQsYUFBYXJELFVBQVVxRDtBQUFBQSxRQUN6QixFQUFFLEtBQUs7QUFFWGxLLHFCQUFhLENBQUN5TSxVQUFVO0FBQUEsVUFDdEIsR0FBR0E7QUFBQUEsVUFDSHRNLGVBQWVxRixNQUFNQyxRQUFRZ0csYUFBYSxJQUFJQSxnQkFBZ0I7QUFBQSxVQUM5RHJMLHFCQUFxQm9GLE1BQU1DLFFBQVFnSSx1QkFBdUIsSUFDdERBLDBCQUNBO0FBQUEsVUFDSmhPLHFCQUFxQmtPO0FBQUFBLFFBQ3ZCLEVBQUU7QUFBQSxNQUNKLFNBQVMxSixPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLCtCQUErQkEsS0FBSztBQUNsRGpFLHFCQUFhO0FBQUEsVUFDWEMsbUJBQW1CO0FBQUEsVUFDbkJDLHNCQUFzQjtBQUFBLFVBQ3RCQyxlQUFlO0FBQUEsVUFDZkMscUJBQXFCO0FBQUEsVUFDckJYLHFCQUFxQjtBQUFBLFFBQ3ZCLENBQUM7QUFBQSxNQUNILFVBQUM7QUFDQ2lELDBCQUFrQixLQUFLO0FBQ3ZCRSxnQ0FBd0IsS0FBSztBQUFBLE1BQy9CO0FBQUEsSUFDRjtBQUNBOEosaUJBQWE7QUFBQSxFQUNmLEdBQUcsQ0FBQ3JPLGFBQWEsQ0FBQztBQUVsQixpQkFBZXdQLGtCQUFrQjtBQUMvQixRQUFJO0FBQ0Z6TSw2QkFBdUIsSUFBSTtBQUMzQixZQUFNeUMsV0FBVyxNQUFNcEksSUFBSXFJLElBQUksd0JBQXdCO0FBQ3ZELFlBQU1nSyxtQkFBbUJqSyxTQUFTRSxNQUFNQTtBQUN4QyxZQUFNZ0ssZUFBZUQsaUJBQWlCdkUsSUFBSSxDQUFDeUUsT0FBT3hFLFVBQVU7QUFDMUQsY0FBTVcsU0FBUzZELE9BQU83RDtBQUN0QixjQUFNOEQsUUFDSjlELFdBQVcsV0FBVyxTQUFTQSxXQUFXLFNBQVMsVUFBVTtBQUMvRCxjQUFNK0QsT0FDSi9ELFdBQVcsV0FDVCx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9CLElBQ2xCQSxXQUFXLFNBQ2IsdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQixJQUVwQix1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9CO0FBRXhCLGNBQU05TSxVQUFTMlEsT0FBTzNRO0FBQ3RCLGNBQU04USxTQUFTSCxNQUFNRztBQUNyQixjQUFNQyxRQUFRSixPQUFPSTtBQUNyQixjQUFNQyxnQkFDSmhSLFNBQVFrTTtBQUFBQSxVQUNOLENBQUN6QyxVQUFVLEdBQUdBLE9BQU80QyxVQUFVekIsVUFBVSxNQUFNbkIsT0FBT29GLE1BQU07QUFBQSxRQUM5RCxLQUFLLElBQ0xGLEtBQUssS0FBSztBQUNaLGNBQU1zQyxnQkFDSkgsUUFBUTVFO0FBQUFBLFVBQ04sQ0FBQ2dGLFVBQVUsR0FBR0EsT0FBT0MsY0FBYyxNQUFNRCxPQUFPakgsUUFBUTtBQUFBLFFBQzFELEtBQUssSUFDTDBFLEtBQUssS0FBSztBQUNaLGNBQU15QyxlQUNKTCxPQUFPN0UsSUFBSSxDQUFDbUYsU0FBUyxHQUFHQSxNQUFNQyxXQUFXLE1BQU1ELE1BQU14RyxPQUFPLEVBQUUsS0FBSyxJQUNuRThELEtBQUssS0FBSztBQUNaLGVBQU87QUFBQSxVQUNMckMsSUFBSUgsUUFBUTtBQUFBLFVBQ1pvRixXQUFXWixPQUFPYTtBQUFBQSxVQUNsQkMsV0FBV2QsT0FBT3ZFLFNBQVN2QztBQUFBQSxVQUMzQkMsY0FBYzZHLE9BQU92RSxTQUFTdEM7QUFBQUEsVUFDOUI5SixTQUNFQSxTQUFRa007QUFBQUEsWUFDTixDQUFDekMsVUFBVSxHQUFHQSxPQUFPNEMsVUFBVXpCLFVBQVUsTUFBTW5CLE9BQU9vRixNQUFNO0FBQUEsVUFDOUQsS0FBSyxJQUNMRixLQUFLLEtBQUs7QUFBQSxVQUNabUMsU0FDRUEsUUFBUTVFO0FBQUFBLFlBQ04sQ0FBQ2dGLFVBQVUsR0FBR0EsT0FBT0MsY0FBYyxNQUFNRCxPQUFPakgsUUFBUTtBQUFBLFVBQzFELEtBQUssSUFDTDBFLEtBQUssS0FBSztBQUFBLFVBQ1pvQyxRQUNFQSxPQUFPN0UsSUFBSSxDQUFDbUYsU0FBUyxHQUFHQSxNQUFNQyxXQUFXLE1BQU1ELE1BQU14RyxPQUFPLEVBQUUsS0FDOUQsSUFDQThELEtBQUssS0FBSztBQUFBLFVBQ1orQyxRQUFRVixlQUFlQyxlQUFlRztBQUFBQSxVQUN0Q3RFLFFBQ0UsdUJBQUMsT0FBb0IsT0FBYyxNQUFZLFNBQVMsVUFDckRBLG9CQURPLFdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUYxQyxRQUFRdUcsT0FBT3ZHO0FBQUFBLFVBQ2Z1SCxTQUFTaEIsT0FBT2dCO0FBQUFBLFVBQ2hCQyxVQUFVakIsT0FBT2lCO0FBQUFBLFVBQ2pCQyxXQUFXL0U7QUFBQUEsVUFDWGdGLGFBQWFuQixPQUFPb0I7QUFBQUEsVUFDcEJ2RCxXQUFXbUMsT0FBT25DLFdBQ2RDLE1BQU0sR0FBRyxFQUFFLENBQUMsRUFDYkEsTUFBTSxHQUFHLEVBQ1RDLFFBQVEsRUFDUkMsS0FBSyxHQUFHO0FBQUEsUUFDYjtBQUFBLE1BQ0YsQ0FBQztBQUVEaE0sbUJBQWEsQ0FBQ3lNLFVBQVU7QUFBQSxRQUN0QixHQUFHQTtBQUFBQSxRQUNIeE0sbUJBQW1COE47QUFBQUEsUUFDbkI3TixzQkFBc0J1TSxLQUFLdk07QUFBQUEsTUFDN0IsRUFBRTtBQUFBLElBQ0osU0FBUytELE9BQU87QUFFZGpFLG1CQUFhLENBQUN5TSxVQUFVLEVBQUUsR0FBR0EsTUFBTXhNLG1CQUFtQixHQUFHLEVBQUU7QUFBQSxJQUM3RCxVQUFDO0FBQ0NtQiw2QkFBdUIsS0FBSztBQUFBLElBQzlCO0FBQUEsRUFDRjtBQUVBL0YsWUFBVSxNQUFNO0FBQ2R3UyxvQkFBZ0I7QUFBQSxFQUNsQixHQUFHLEVBQUU7QUFFTCxRQUFNd0IsV0FBVztBQUFBLElBQ2Y7QUFBQTtBQUFBLE1BRUVuQixNQUFNeFQ7QUFBQUEsTUFDTjRVLE9BQU87QUFBQSxNQUNQck0sT0FBTyxNQUFNbEMsZUFBZSxHQUFHMkYsZUFBZSxPQUFPLENBQUM7QUFBQSxNQUN0RDZJLFVBQVU7QUFBQSxNQUNWdEIsT0FBTztBQUFBLE1BQ1B1QixRQUFRO0FBQUEsTUFDUkMsV0FBVztBQUFBLE1BQ1hDLGFBQWE7QUFBQSxNQUNiQyxXQUFXO0FBQUEsTUFDWHZNLFVBQVU7QUFBQSxNQUNWRSxLQUFLO0FBQUEsSUFDUDtBQUFBLElBQ0E7QUFBQTtBQUFBLE1BRUU0SyxNQUFNclQ7QUFBQUEsTUFDTnlVLE9BQU87QUFBQSxNQUNQck0sT0FBTyxNQUFNaEMsd0JBQXdCLEdBQUd5RixlQUFlLE9BQU8sQ0FBQztBQUFBLE1BQy9ENkksVUFBVTtBQUFBLE1BQ1Z0QixPQUFPO0FBQUEsTUFDUHVCLFFBQVE7QUFBQSxNQUNSQyxXQUFXO0FBQUEsTUFDWEMsYUFBYTtBQUFBLE1BQ2JDLFdBQVc7QUFBQSxNQUNYdk0sVUFBVTtBQUFBLE1BQ1ZFLEtBQUs7QUFBQSxJQUNQO0FBQUEsSUFDQTtBQUFBLE1BQ0U0SyxNQUFNblQ7QUFBQUEsTUFDTnVVLE9BQU87QUFBQSxNQUNQck0sT0FBTzVGLE9BQU9xSTtBQUFBQSxNQUNkNkosVUFBVTtBQUFBLE1BQ1Z0QixPQUFPO0FBQUEsTUFDUHVCLFFBQVE7QUFBQSxNQUNSQyxXQUFXO0FBQUEsTUFDWEMsYUFBYTtBQUFBLE1BQ2JDLFdBQVc7QUFBQSxNQUNYdk0sVUFBVTtBQUFBLE1BQ1ZFLEtBQUs7QUFBQSxJQUNQO0FBQUEsSUFDQTtBQUFBLE1BQ0U0SyxNQUFNL1M7QUFBQUEsTUFDTm1VLE9BQU87QUFBQSxNQUNQck0sT0FBTzFGLE1BQU1tSTtBQUFBQSxNQUNiNkosVUFBVTtBQUFBLE1BQ1Z0QixPQUFPO0FBQUEsTUFDUHVCLFFBQVE7QUFBQSxNQUNSQyxXQUFXO0FBQUEsTUFDWEMsYUFBYTtBQUFBLE1BQ2JDLFdBQVc7QUFBQSxNQUNYdk0sVUFBVTtBQUFBLE1BQ1ZFLEtBQUs7QUFBQSxJQUNQO0FBQUEsSUFDQTtBQUFBLE1BQ0U0SyxNQUFNdFQ7QUFBQUEsTUFDTjBVLE9BQU87QUFBQSxNQUNQck0sT0FBT3RFLGlCQUFpQitILGVBQWU7QUFBQSxNQUN2QzZJLFVBQVU7QUFBQSxNQUNWdEIsT0FBTztBQUFBLE1BQ1B1QixRQUFRO0FBQUEsTUFDUkMsV0FBVztBQUFBLE1BQ1hDLGFBQWE7QUFBQSxNQUNiQyxXQUFXO0FBQUEsTUFDWHZNLFVBQVU7QUFBQSxNQUNWRSxLQUFLO0FBQUEsSUFDUDtBQUFBLElBQ0E7QUFBQSxNQUNFNEssTUFBTWhUO0FBQUFBLE1BQ05vVSxPQUFPO0FBQUEsTUFDUHJNLE9BQU94RixPQUFPaUk7QUFBQUEsTUFDZDZKLFVBQVU7QUFBQSxNQUNWdEIsT0FBTztBQUFBLE1BQ1B1QixRQUFRO0FBQUEsTUFDUkMsV0FBVztBQUFBLE1BQ1hDLGFBQWE7QUFBQSxNQUNiQyxXQUFXO0FBQUEsTUFDWHZNLFVBQVU7QUFBQSxNQUNWRSxLQUFLO0FBQUEsSUFDUDtBQUFBLElBQ0E7QUFBQSxNQUNFNEssTUFBTTFUO0FBQUFBLE1BQ044VSxPQUFPO0FBQUEsTUFDUHJNLE9BQU90RixPQUFPK0g7QUFBQUEsTUFDZDZKLFVBQVU7QUFBQSxNQUNWQyxRQUFRO0FBQUEsTUFDUkMsV0FBVztBQUFBLElBQ2I7QUFBQSxJQUNBO0FBQUEsTUFDRXZCLE1BQU16VDtBQUFBQSxNQUNONlUsT0FBTztBQUFBLE1BQ1ByTSxPQUFPcEYsVUFBVTZIO0FBQUFBLE1BQ2pCNkosVUFBVTtBQUFBLE1BQ1Z0QixPQUFPO0FBQUEsTUFDUHVCLFFBQVE7QUFBQSxNQUNSQyxXQUFXO0FBQUEsTUFDWEMsYUFBYTtBQUFBLE1BQ2JDLFdBQVc7QUFBQSxNQUNYdk0sVUFBVTtBQUFBLE1BQ1ZFLEtBQUs7QUFBQSxJQUNQO0FBQUEsSUFDQTtBQUFBLE1BQ0U0SyxNQUFNOVM7QUFBQUEsTUFDTmtVLE9BQU87QUFBQSxNQUNQck0sT0FBTyxHQUFHd0QsZUFBZTFJLGFBQWEsQ0FBQztBQUFBLE1BQ3ZDd1IsVUFBVTtBQUFBLE1BQ1Z0QixPQUFPO0FBQUEsTUFDUHVCLFFBQVE7QUFBQSxNQUNSQyxXQUFXO0FBQUEsTUFDWEMsYUFBYTtBQUFBLE1BQ2JDLFdBQVc7QUFBQSxNQUNYdk0sVUFBVTtBQUFBLE1BQ1ZFLEtBQUs7QUFBQSxJQUNQO0FBQUEsSUFDQTtBQUFBLE1BQ0U0SyxNQUFNdlQ7QUFBQUEsTUFDTjJVLE9BQU87QUFBQSxNQUNQck0sT0FBTyxHQUFHd0QsZUFBZXhJLHFCQUFxQixDQUFDO0FBQUEsTUFDL0NzUixVQUFVO0FBQUEsTUFDVnRCLE9BQU87QUFBQSxNQUNQdUIsUUFBUTtBQUFBLE1BQ1JDLFdBQVc7QUFBQSxNQUNYQyxhQUFhO0FBQUEsTUFDYkMsV0FBVztBQUFBLE1BQ1h2TSxVQUFVO0FBQUEsTUFDVkUsS0FBSztBQUFBLElBQ1A7QUFBQSxFQUFDLEVBQ0R5QztBQUFBQSxJQUNBLENBQUM2SixTQUNDQSxLQUFLTixNQUFNTyxZQUFZLEVBQUVDLFNBQVMzUixZQUFZMFIsWUFBWSxDQUFDLEtBQzNERCxLQUFLTCxTQUFTTSxZQUFZLEVBQUVDLFNBQVMzUixZQUFZMFIsWUFBWSxDQUFDO0FBQUEsRUFDbEU7QUFFQSxRQUFNRSxZQUFZO0FBQUEsSUFDaEI7QUFBQSxNQUNFQyxNQUFNO0FBQUEsTUFDTjlCLE1BQU1qVDtBQUFBQSxNQUNOZ1YsV0FBVztBQUFBLElBQ2I7QUFBQSxJQUNBO0FBQUEsTUFDRUQsTUFBTTtBQUFBLE1BQ045QixNQUFNeFQ7QUFBQUEsTUFDTnVWLFdBQVc7QUFBQSxJQUNiO0FBQUEsSUFDQTtBQUFBLE1BQ0VELE1BQU07QUFBQSxNQUNOOUIsTUFBTXBUO0FBQUFBLE1BQ05tVixXQUFXO0FBQUEsSUFDYjtBQUFBLElBQ0E7QUFBQSxNQUNFRCxNQUFNO0FBQUEsTUFDTjlCLE1BQU0vUztBQUFBQSxNQUNOOFUsV0FBVztBQUFBLElBQ2I7QUFBQSxJQUNBO0FBQUEsTUFDRUQsTUFBTTtBQUFBLE1BQ045QixNQUFNbFQ7QUFBQUEsTUFDTmlWLFdBQVc7QUFBQSxJQUNiO0FBQUEsRUFBQztBQUdILFFBQU1DLGlCQUFpQkEsQ0FBQzdHLFFBQVE7QUFDOUIsUUFBSSxDQUFDQSxLQUFLO0FBQ1J2TSxjQUFRcVQsUUFBUSw0Q0FBNEM7QUFDNUQ7QUFBQSxJQUNGO0FBQ0F2SCxjQUFVQyxVQUFVQyxVQUFVTyxHQUFHO0FBQ2pDdk0sWUFBUWlNLFFBQVEsbUNBQW1DO0FBQUEsRUFDckQ7QUFDQSxRQUFNcUgsY0FBYztBQUVwQixTQUNFLHVCQUFDLFNBQ0MsaUNBQUMsU0FBSSxXQUFVLDZDQUNiO0FBQUEsMkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVE7QUFBQSxJQUNSLHVCQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUI7QUFBQSxJQUNuQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTTlPLFlBQVlHO0FBQUFBLFFBQ2xCLFdBQVdILFlBQVlFO0FBQUFBLFFBQ3ZCLFNBQVNGLFlBQVl4RTtBQUFBQSxRQUNyQixTQUFTLE1BQ1B5RSxlQUFlLENBQUNrTCxVQUFVLEVBQUUsR0FBR0EsTUFBTWpMLFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxNQUw3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNRztBQUFBLElBR0gsdUJBQUMsVUFBSyxXQUFVLG9EQUNkO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDJMQUNiO0FBQUEsK0JBQUMsU0FDQztBQUFBLGlDQUFDLFFBQUcsV0FBVSxvRUFBbUUsc0NBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSwrQkFBOEIsc0dBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlJO0FBQUEsYUFKbkk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsa1BBQWlQLGlCQUFqUTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsK1BBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsOEJBQTZCLGtDQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQWdCLGtKQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsOElBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUo7QUFBQSxlQVgzSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsYUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFdBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2QkE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxrSUFDYixpQ0FBQyxTQUFJLFdBQVUsMkVBQ1p1TyxvQkFBVU0sT0FBT04sU0FBUyxFQUFFeEcsSUFBSSxDQUFDM0MsTUFBTTBKLFFBQVE7QUFDOUMsY0FBTUMsT0FBTzNKLEtBQUtzSDtBQUVsQixlQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLFFBQUssV0FBVyxvQkFBb0J0SCxLQUFLcUosU0FBUyxJQUFJLGFBQWEsT0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0U7QUFBQSxjQUN4RSx1QkFBQyxVQUFNckosZUFBS29KLFFBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUI7QUFBQTtBQUFBO0FBQUEsVUFKWixHQUFHcEosS0FBS29KLElBQUksSUFBSU0sR0FBRztBQUFBLFVBRDFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLE1BRUosQ0FBQyxLQWJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQSxLQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQkE7QUFBQSxNQUVBLHVCQUFDLFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhRTtBQUFBLE1BRUYsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsd0RBQ1pqQixtQkFBUzlGLElBQUksQ0FBQ3FHLFNBQVM7QUFDdEIsZ0JBQU1ZLGNBQWNaLEtBQUt4TSxXQUFXLFdBQVc7QUFDL0MsaUJBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLEdBQUt3TSxLQUFLeE0sV0FBVztBQUFBLGdCQUNuQjNCLE1BQU07QUFBQSxnQkFDTmdQLFNBQVNBLE1BQU10Tix1QkFBdUJ5TSxLQUFLeE0sUUFBUTtBQUFBLGdCQUNuRCxjQUFjLEdBQUd3TSxLQUFLTixLQUFLLEtBQUtNLEtBQUszTSxLQUFLLEtBQUsyTSxLQUFLTCxRQUFRO0FBQUEsY0FDOUQsSUFBSSxDQUFDO0FBQUEsY0FDTCxLQUFLSyxLQUFLTjtBQUFBQSxjQUNWLFdBQVcseUxBQXlMTSxLQUFLeE0sV0FBVyxtTEFBbUwsRUFBRTtBQUFBO0FBQUEsWUFFelksdUJBQUMsVUFBSyxXQUFXLGdFQUFnRXdNLEtBQUtKLE1BQU0sSUFBSUksS0FBS0gsU0FBUyxzQkFDNUcsaUNBQUMsS0FBSyxNQUFMLEVBQVUsV0FBVSxhQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QixLQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLFdBQVUsa0JBQ2Q7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsMkVBQTJFRyxlQUFLTixTQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRztBQUFBLGNBQ3RHLHVCQUFDLFVBQUssV0FBVSwyRkFBMkZNLGVBQUszTSxTQUFoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzSDtBQUFBLGNBQ3RILHVCQUFDLFVBQUssV0FBVSxvRUFBb0UyTSxlQUFLTCxZQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRztBQUFBLGlCQUhwRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsVUFDRjtBQUFBLFFBRUYsQ0FBQyxLQXZCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFDQ0YsU0FBUzNKLFdBQVcsS0FDbkIsdUJBQUMsU0FBSSxXQUFVLGtIQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHNCQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixNQUFLO0FBQUEsY0FDTCxRQUFPO0FBQUEsY0FDUCxTQUFRO0FBQUEsY0FFUjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxlQUFjO0FBQUEsa0JBQ2QsZ0JBQWU7QUFBQSxrQkFDZixhQUFZO0FBQUEsa0JBQ1osR0FBRTtBQUFBO0FBQUEsZ0JBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSWlEO0FBQUE7QUFBQSxZQVZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxVQUNBLHVCQUFDLFFBQUcsV0FBVSx5REFBd0QsZ0NBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxzQ0FBcUM7QUFBQTtBQUFBLFlBQ0Q7QUFBQSxZQUMvQyx1QkFBQyxVQUFLLFdBQVUsZUFBYztBQUFBO0FBQUEsY0FBT3ZIO0FBQUFBLGNBQVk7QUFBQSxpQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUQ7QUFBQSxZQUFPO0FBQUEsZUFGaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLGFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxRQUdGLHVCQUFDLGFBQVEsSUFBRyx1QkFBc0IsV0FBVSx5SEFDMUM7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsb0VBQW1FLGtDQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrRztBQUFBLFlBQ2xHLHVCQUFDLE9BQUUsV0FBVSwrQkFBOEIsaURBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRFO0FBQUEsZUFGOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsNkJBQTBCLFVBQVEsUUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUM7QUFBQSxhQUxyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxRQXNGQSx1QkFBQyxTQUFJLFdBQVUsbUhBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsd0VBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLHFDQUFvQyxnREFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVBLHVCQUFDLFVBQUssV0FBVSxzRkFBcUYscUNBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsY0FFQSx1QkFBQyxPQUFFLFdBQVUsZ0NBQStCO0FBQUE7QUFBQSxnQkFDckIsdUJBQUMsVUFBSyxXQUFVLDhCQUE2Qiw4Q0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkU7QUFBQSxnQkFBTztBQUFBLG1CQUR6RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFlQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNO0FBQ2Isd0JBQU11UyxZQUFZLENBQUNyUixZQUFZUTtBQUMvQlAsaUNBQWUsQ0FBQ21OLFVBQVU7QUFBQSxvQkFDeEIsR0FBR0E7QUFBQUEsb0JBQ0g1TSxlQUFlNlE7QUFBQUEsa0JBQ2pCLEVBQUU7QUFFRixzQkFBSUEsYUFBYS9QLGtCQUFrQitFLFdBQVcsR0FBRztBQUMvQ3NELDJDQUF1QjtBQUFBLGtCQUN6QjtBQUFBLGdCQUNGO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUVWLGlDQUFDLFVBQUssV0FBVSxzQ0FDYjNKLHNCQUFZUSxnQkFBZ0IsTUFBTSxPQURyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUE7QUFBQSxjQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtQkE7QUFBQSxlQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNDQTtBQUFBLFVBQ0NnRCx1QkFDQyx1QkFBQyxTQUFJLFdBQVUsYUFDWixXQUFDLEdBQUcyQyxNQUFNLENBQUMsQ0FBQyxFQUFFK0Q7QUFBQUEsWUFBSSxDQUFDb0gsR0FBR0MsTUFDckIsdUJBQUMsU0FBWSxXQUFVLCtDQUFiQSxHQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtFO0FBQUEsVUFDbkUsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBLElBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVcsMkRBQTJEdlIsWUFBWVEsZ0JBQWdCLCtCQUErQixtQkFBbUI7QUFBQSxjQUdwSixpQ0FBQyxTQUFJLFdBQVUsbUJBQ2IsaUNBQUMsV0FBTSxXQUFVLDBCQUNmO0FBQUEsdUNBQUMsV0FDQyxpQ0FBQyxRQUFHLFdBQVUsZUFDWjtBQUFBLHlDQUFDLFFBQUcsV0FBVSxpQkFBZ0Isa0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEsa0JBQ2hDLHVCQUFDLFFBQUcsV0FBVSxpQkFBZ0IsMEJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdDO0FBQUEsa0JBQ3hDLHVCQUFDLFFBQUcsV0FBVSxpQkFBZ0Isd0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNDO0FBQUEsa0JBQ3RDLHVCQUFDLFFBQUcsV0FBVSxpQkFBZ0IsOEJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTRDO0FBQUEsa0JBQzVDLHVCQUFDLFFBQUcsV0FBVSxpQkFBZ0IsZ0NBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThDO0FBQUEscUJBTGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVFBO0FBQUEsZ0JBQ0EsdUJBQUMsV0FDRWMsNEJBQWtCK0UsU0FBUyxJQUMxQi9FLGtCQUFrQjRJO0FBQUFBLGtCQUFJLENBQUMzQyxNQUFNNEMsVUFDM0IsdUJBQUMsUUFBa0IsV0FBVSw2QkFDM0I7QUFBQSwyQ0FBQyxRQUFHLFdBQVUsT0FBT0Esa0JBQVEsS0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0I7QUFBQSxvQkFDL0IsdUJBQUMsUUFBRyxXQUFVLG1CQUFtQjVDLGVBQUtxQixjQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpRDtBQUFBLG9CQUNqRCx1QkFBQyxRQUFHLFdBQVUsT0FDWCxjQUFJRixLQUFLbkIsS0FBS2lLLFFBQVEsRUFBRTdJLG1CQUFtQixTQUFTO0FBQUEsc0JBQ25Ea0QsS0FBSztBQUFBLHNCQUNMSixPQUFPO0FBQUEsc0JBQ1BGLE1BQU07QUFBQSxvQkFDUixDQUFDLEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFNQTtBQUFBLG9CQUNBLHVCQUFDLFFBQUcsV0FBVSxPQUNaLGlDQUFDLFVBQUssV0FBVSxtRUFDYmhFO0FBQUFBLDJCQUFLa0s7QUFBQUEsc0JBQWU7QUFBQSx5QkFEdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsT0FBT2xLO0FBQUFBLDJCQUFLbUs7QUFBQUEsc0JBQWlCO0FBQUEseUJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9EO0FBQUEsdUJBZjdDbkssS0FBSzhFLEtBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFnQkE7QUFBQSxnQkFDRCxJQUVELHVCQUFDLFFBQ0MsaUNBQUMsUUFBRyxTQUFRLEtBQUksV0FBVSxpQ0FBZ0MsdUNBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBLEtBMUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBNEJBO0FBQUEsbUJBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdUNBLEtBeENGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeUNBO0FBQUE7QUFBQSxZQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUE4Q0E7QUFBQSxhQTdGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0ZBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxtSEFFYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsc0RBQXFEO0FBQUE7QUFBQSxnQkFHakU7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsSUFBRztBQUFBLG9CQUNILFdBQVU7QUFBQSxvQkFBNEU7QUFBQTtBQUFBLGtCQUZ4RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxtQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVNBO0FBQUEsY0FFQSx1QkFBQyxPQUFFLFdBQVUseUJBQXdCLDZDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFlQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLDJCQUViO0FBQUEscUNBQUMsU0FBSSxXQUFVLG1DQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsU0FBUyxNQUFNMU0sWUFBWSxNQUFNO0FBQUEsb0JBQ2pDLFdBQVcsaUNBQWlDRCxhQUFhLFNBQ3JELHFDQUNBLGVBQWU7QUFBQSxvQkFHbkIsaUNBQUMsb0JBQWlCLE1BQU0sTUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkI7QUFBQTtBQUFBLGtCQVA3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUUE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU1DLFlBQVksTUFBTTtBQUFBLG9CQUNqQyxXQUFXLGlDQUFpQ0QsYUFBYSxTQUNyRCxxQ0FDQSxlQUFlO0FBQUEsb0JBR25CLGlDQUFDLFlBQVMsTUFBTSxNQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtQjtBQUFBO0FBQUEsa0JBUHJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRQTtBQUFBLG1CQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW9CQTtBQUFBLGNBR0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUzhPO0FBQUFBLGtCQUNULFdBQVU7QUFBQSxrQkFBOEY7QUFBQTtBQUFBLGdCQUYxRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBR0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUyxNQUNQdk8sZUFBZSxDQUFDbU4sVUFBVTtBQUFBLG9CQUN4QixHQUFHQTtBQUFBQSxvQkFDSGxOLGNBQWMsQ0FBQ2tOLEtBQUtsTjtBQUFBQSxrQkFDdEIsRUFBRTtBQUFBLGtCQUVKLFdBQVU7QUFBQSxrQkFFVjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFXLDhEQUE4REYsWUFBWUUsZUFBZSxlQUFlLEVBQUU7QUFBQTtBQUFBLG9CQUR2SDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRU87QUFBQTtBQUFBLGdCQVhUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWFBO0FBQUEsaUJBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0NBO0FBQUEsZUFuRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvRUE7QUFBQSxVQUVDNEIsc0JBQ0MsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsK0NBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxZQUMxRCx1QkFBQyxTQUFJLFdBQVUsK0NBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxlQUY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBLElBRUEsbUNBQ0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVcsZ0VBQWdFOUIsWUFBWUUsZUFDbkYsK0JBQ0EsbUJBQW1CO0FBQUEsY0FHdkI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FDRVIsYUFBYSxTQUNULHdFQUNBO0FBQUEsa0JBSUxBO0FBQUFBLGlDQUFhLFVBQ1o7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVyxRQUFRcVIsV0FBVztBQUFBLHdCQUU5QjtBQUFBLGlEQUFDLFNBQUksa0JBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBTztBQUFBLDBCQUNQLHVCQUFDLFNBQUksb0JBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBUztBQUFBLDBCQUNULHVCQUFDLFNBQUksd0JBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBYTtBQUFBLDBCQUNiLHVCQUFDLFNBQUksaUNBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBc0I7QUFBQSwwQkFDdEIsdUJBQUMsU0FBSSxzQkFBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFXO0FBQUEsMEJBQ1gsdUJBQUMsU0FBSSxzQkFBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFXO0FBQUEsMEJBQ1gsdUJBQUMsU0FBSSxXQUFVLGVBQWMsdUJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQW9DO0FBQUE7QUFBQTtBQUFBLHNCQVR0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBVUE7QUFBQSxvQkFJRHJRLFdBQVdFLGtCQUFrQnlGLFNBQVMsSUFDckMzRixXQUFXRSxtQkFBbUJzSjtBQUFBQSxzQkFBSSxDQUFDM0MsTUFBTTRDLFVBQ3ZDekssYUFBYSxTQUNYO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUVDLFdBQVcsUUFBUXFSLFdBQVc7QUFBQSwwQkFFOUI7QUFBQSxtREFBQyxTQUFJLFdBQVUsMkJBQ1g1RyxtQkFBUSxHQUFHd0gsU0FBUyxFQUFFL0YsU0FBUyxHQUFHLEdBQUcsS0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FFQTtBQUFBLDRCQUVBLHVCQUFDLFNBQUksV0FBVSwrQ0FDWnJFLGVBQUtpRixhQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQSw0QkFFQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSxxREFBQyxTQUFJLFdBQVUsb0NBQ1pqRixlQUFLa0ksYUFEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUVBO0FBQUEsOEJBQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNabEksZUFBS08sZ0JBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FFQTtBQUFBLGlDQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBT0E7QUFBQSw0QkFHQSx1QkFBQyxTQUFJLFdBQVUsaUNBQ2I7QUFBQSxxREFBQyxVQUFLLFdBQVUsZ0dBQ2JQLGVBQUtvSSxXQUFXLFNBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBRUE7QUFBQSw4QkFDQSx1QkFBQyxVQUFLLFdBQVUsaURBQ2JwSSxlQUFLbUksVUFBVSxtQkFEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FFQTtBQUFBLGlDQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBT0E7QUFBQSw0QkFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQTBCO0FBQUE7QUFBQSw4QkFDckNuSSxLQUFLYSxRQUFRZixlQUFlLE9BQU87QUFBQSxpQ0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FFQTtBQUFBLDRCQUVBLHVCQUFDLFNBQUtFLGVBQUt1RCxVQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQWtCO0FBQUEsNEJBR2xCLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBO0FBQUEsZ0NBQUM7QUFBQTtBQUFBLGtDQUNDLE9BQ0V2RCxNQUFNcUksV0FDRixzQkFDQTtBQUFBLGtDQUdOO0FBQUEsb0NBQUM7QUFBQTtBQUFBLHNDQUNDLFNBQVMsTUFDUGlCLGVBQWV0SixNQUFNcUksUUFBUTtBQUFBLHNDQUUvQixXQUFXLGlDQUFpQ3JJLE1BQU1xSSxXQUFXLG9DQUFvQyxlQUFlO0FBQUEsc0NBRWhILGlDQUFDLFVBQU8sTUFBTSxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkNBQWlCO0FBQUE7QUFBQSxvQ0FObkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtDQU9BO0FBQUE7QUFBQSxnQ0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBZUE7QUFBQSw4QkFFQTtBQUFBLGdDQUFDO0FBQUE7QUFBQSxrQ0FDQyxPQUNFckksS0FBS3FJLFdBQ0QsY0FDQTtBQUFBLGtDQUdOO0FBQUEsb0NBQUM7QUFBQTtBQUFBLHNDQUNDLFNBQVMsTUFBTTtBQUNiLDRDQUFJckksS0FBS3FJO0FBQ1BnQyxpREFBT0MsS0FBS3RLLEtBQUtxSSxVQUFVLFFBQVE7QUFBQTtBQUVuQ25TLGtEQUFRcVU7QUFBQUEsNENBQ047QUFBQSwwQ0FDRjtBQUFBLHNDQUNKO0FBQUEsc0NBQ0EsV0FBVyxpQ0FBaUN2SyxLQUFLcUksV0FBVyxvQ0FBb0MsZUFBZTtBQUFBLHNDQUUvRyxpQ0FBQyxxQkFBa0IsTUFBTSxNQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZDQUE0QjtBQUFBO0FBQUEsb0NBWDlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQ0FZQTtBQUFBO0FBQUEsZ0NBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFvQkE7QUFBQSxpQ0F0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0F1Q0E7QUFBQTtBQUFBO0FBQUEsd0JBNUVLckksS0FBSytDO0FBQUFBLHdCQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBOEVBLElBRUE7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBRUMsR0FBSS9DO0FBQUFBLDBCQUNKLFFBQVFBLEtBQUtzSTtBQUFBQSwwQkFDYixVQUFTO0FBQUE7QUFBQSx3QkFISnRJLEtBQUsrQztBQUFBQSx3QkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUlpQjtBQUFBLG9CQUdyQixJQUVBLHVCQUFDLFNBQUksV0FBVSxrREFBaUQsc0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQTtBQUFBO0FBQUEsZ0JBckhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXVIQTtBQUFBO0FBQUEsWUE3SEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBOEhBLEtBL0hGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0lBO0FBQUEsVUFFRix1QkFBQyxTQUFJLFdBQVcsMkVBQTJFNUosV0FBV04scUJBQXFCaUcsU0FBUyxJQUNoSSwrREFDQSxpQkFBaUIsSUFLbkI7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsMEJBQ1ozRjtBQUFBQSwyQkFBV04scUJBQXFCaUcsU0FBUyxLQUN4Qyx1QkFBQyxTQUFJLFdBQVUsaUJBQ2IsaUNBQUMsVUFBSyxXQUFVLGdCQUNkO0FBQUEseUNBQUMsVUFBSyxXQUFVLDJGQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3RztBQUFBLGtCQUN4Ryx1QkFBQyxVQUFLLFdBQVUsNkRBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBFO0FBQUEscUJBRjVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBR0YsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDJDQUFDLFFBQUcsV0FBVSxzREFBcUQsb0NBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFQzNGLFdBQVdOLHFCQUFxQmlHLFNBQVMsS0FDeEMsdUJBQUMsVUFBSyxXQUFVLHVIQUNiM0Y7QUFBQUEsZ0NBQVVOLG9CQUFvQmlHO0FBQUFBLHNCQUFPO0FBQUEseUJBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFHRjtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxJQUFHO0FBQUEsd0JBQ0gsV0FBVTtBQUFBLHdCQUFrRjtBQUFBO0FBQUEsc0JBRjlGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLHVCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWlCQTtBQUFBLGtCQUVBLHVCQUFDLE9BQUUsV0FBVSw4QkFDVjNGLHFCQUFXTixxQkFBcUJpRyxTQUFTLElBQ3RDLDhEQUNBLDZDQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxxQkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF5QkE7QUFBQSxtQkFuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFvQ0E7QUFBQSxjQUdBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVcsMERBQTBEM0YsV0FBV04scUJBQXFCaUcsU0FBUyxJQUMxRyxvQkFDQSxlQUFlO0FBQUEsa0JBRW5CLFNBQVMsTUFDUHBHLGVBQWUsQ0FBQ21OLFVBQVU7QUFBQSxvQkFDeEIsR0FBR0E7QUFBQUEsb0JBQ0hoTixxQkFBcUIsQ0FBQ2dOLEtBQUtoTjtBQUFBQSxrQkFDN0IsRUFBRTtBQUFBLGtCQUdISixzQkFBWUksc0JBQXNCLE1BQU07QUFBQTtBQUFBLGdCQVozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FhQTtBQUFBLGlCQXJERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXNEQTtBQUFBLFlBR0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXLDJEQUEyREosWUFBWUksc0JBQzlFLCtCQUNBLG1CQUFtQjtBQUFBLGdCQUd2QjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUyxDQUFDdUQsTUFBTUEsRUFBRW9PLGdCQUFnQjtBQUFBLG9CQUVqQzdPLCtCQUNDLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLDZDQUFDLFNBQUksV0FBVSwrQ0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEwRDtBQUFBLHNCQUMxRCx1QkFBQyxTQUFJLFdBQVUsK0NBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBMEQ7QUFBQSx5QkFGNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQSxJQUNFeEMsV0FBV04scUJBQXFCaUcsU0FBUyxJQUMzQyx1QkFBQyxTQUFJLFdBQVUsT0FDYjtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFNM0YsV0FBV047QUFBQUEsd0JBQ2pCLFNBQVMrRDtBQUFBQTtBQUFBQSxzQkFGWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBRXNDLEtBSHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBS0EsSUFFQSx1QkFBQyxTQUFJLFdBQVUseUNBQXdDLDZDQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUE7QUFBQSxrQkFuQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQXFCQTtBQUFBO0FBQUEsY0EzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBNEJBO0FBQUEsZUE1RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2RkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSwrREFJYjtBQUFBLG1DQUFDLFNBQUksV0FBVSx3REFDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsc0RBQXFEO0FBQUE7QUFBQSxrQkFHakU7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsSUFBRztBQUFBLHNCQUNILFdBQVU7QUFBQSxzQkFBdUY7QUFBQTtBQUFBLG9CQUZuRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxxQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVNBO0FBQUEsZ0JBQ0EsdUJBQUMsT0FBRSxXQUFVLHlCQUF3Qiw2Q0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxjQUdBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFTLE1BQ1BsRSxlQUFlLENBQUNtTixVQUFVO0FBQUEsb0JBQ3hCLEdBQUdBO0FBQUFBLG9CQUNIak4sYUFBYSxDQUFDaU4sS0FBS2pOO0FBQUFBLGtCQUNyQixFQUFFO0FBQUEsa0JBR0hILHNCQUFZRyxjQUFjLE1BQU07QUFBQTtBQUFBLGdCQVRuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FVQTtBQUFBLGlCQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZCQTtBQUFBLFlBR0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXLDJEQUEyREgsWUFBWUcsY0FDOUUsK0JBQ0EsbUJBQW1CO0FBQUEsZ0JBSXZCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFTLENBQUN3RCxNQUFNQSxFQUFFb08sZ0JBQWdCO0FBQUEsb0JBRWpDN08sK0JBQ0MsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsNkNBQUMsU0FBSSxXQUFVLCtDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTBEO0FBQUEsc0JBQzFELHVCQUFDLFNBQUksV0FBVSwrQ0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEwRDtBQUFBLHlCQUY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBLElBQ0V4QyxXQUFXRyxzQkFBc0J3RixTQUFTLElBQzVDLHVCQUFDLFNBQUksV0FBVSxPQUNiO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUVDLE1BQU0zRixXQUFXRztBQUFBQSx3QkFDakIsU0FBU21EO0FBQUFBO0FBQUFBLHNCQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFHNkIsS0FKL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFNQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FBd0Msb0NBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQTtBQUFBLGtCQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBc0JBO0FBQUE7QUFBQSxjQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUE4QkE7QUFBQSxlQWxFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1FQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLCtEQUliO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFFBQUcsV0FBVSxzREFBcUQ7QUFBQTtBQUFBLGtCQUVqRTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxJQUFHO0FBQUEsc0JBQ0gsV0FBVTtBQUFBLHNCQUE0RTtBQUFBO0FBQUEsb0JBRnhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLQTtBQUFBLHFCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUUE7QUFBQSxnQkFFQSx1QkFBQyxPQUFFLFdBQVUseUJBQXdCLDZDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFjQTtBQUFBLGNBR0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVMsTUFDUC9ELGVBQWUsQ0FBQ21OLFVBQVU7QUFBQSxvQkFDeEIsR0FBR0E7QUFBQUEsb0JBQ0gvTSxTQUFTLENBQUMrTSxLQUFLL007QUFBQUEsa0JBQ2pCLEVBQUU7QUFBQSxrQkFHSEwsc0JBQVlLLFVBQVUsTUFBTTtBQUFBO0FBQUEsZ0JBVC9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVVBO0FBQUEsaUJBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkJBO0FBQUEsWUFHQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVcsMkRBQTJETCxZQUFZSyxVQUM5RSwrQkFDQSxtQkFBbUI7QUFBQSxnQkFJdkI7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVMsQ0FBQ3NELE1BQU1BLEVBQUVvTyxnQkFBZ0I7QUFBQSxvQkFFakMzTywyQkFDQyx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSw2Q0FBQyxTQUFJLFdBQVUsK0NBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBMEQ7QUFBQSxzQkFDMUQsdUJBQUMsU0FBSSxXQUFVLCtDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTBEO0FBQUEseUJBRjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0EsSUFDRTFDLFdBQVdJLGVBQWV1RixTQUFTLElBQ3JDLHVCQUFDLFNBQUksV0FBVSxPQUNiO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUVDLE1BQU0zRixVQUFVSTtBQUFBQSx3QkFDaEIsU0FBU3NEO0FBQUFBO0FBQUFBLHNCQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFHeUIsS0FKM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFNQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FBd0MsZ0NBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQTtBQUFBLGtCQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBc0JBO0FBQUE7QUFBQSxjQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUE4QkE7QUFBQSxlQWxFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1FQTtBQUFBLFVBSUEsdUJBQUMsU0FBSSxXQUFVLHVFQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHdFQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHlDQUFDLFFBQUcsV0FBVSxtQ0FBa0MsaURBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFFQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxJQUFHO0FBQUEsc0JBQ0gsV0FBVTtBQUFBLHNCQUE0RjtBQUFBO0FBQUEsb0JBRnhHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLQTtBQUFBLHFCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBV0E7QUFBQSxnQkFFQSx1QkFBQyxPQUFFLFdBQVUseUJBQXdCLHdEQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUJBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUyxNQUFNO0FBQ2IsMEJBQU1pTixZQUFZLENBQUNyUixZQUFZTztBQUUvQk4sbUNBQWUsQ0FBQ21OLFVBQVU7QUFBQSxzQkFDeEIsR0FBR0E7QUFBQUEsc0JBQ0g3TSxlQUFlOFE7QUFBQUEsb0JBQ2pCLEVBQUU7QUFFRix3QkFBSUEsYUFBYW5RLGNBQWNtRixXQUFXLEdBQUc7QUFDM0N3RCw2Q0FBdUI7QUFBQSxvQkFDekI7QUFBQSxrQkFDRjtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFFVixpQ0FBQyxVQUFLLFdBQVUsMkNBQ2I3SixzQkFBWU8sZ0JBQWdCLE1BQU0sT0FEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBO0FBQUEsZ0JBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWtCQSxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW9CQTtBQUFBLGlCQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlDQTtBQUFBLFlBSUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXLDJEQUEyRFAsWUFBWU8sZ0JBQzlFLCtCQUNBLG1CQUFtQjtBQUFBLGdCQUt2QjtBQUFBLHlDQUFDLFNBQUksV0FBVSx5REFDYixpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxTQUFTLENBQUNvRCxNQUFNO0FBQ2RBLDRCQUFFb08sZ0JBQWdCO0FBQ2xCdFEsNkNBQW1CLGNBQWM7QUFBQSx3QkFDbkM7QUFBQSx3QkFDQSxXQUFXLDRFQUE0RUQsb0JBQW9CLGlCQUN2RyxxQ0FDQSxpQ0FBaUM7QUFBQSx3QkFDaEM7QUFBQTtBQUFBLHNCQVJQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFXQTtBQUFBLG9CQUVBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFNBQVMsQ0FBQ21DLE1BQU07QUFDZEEsNEJBQUVvTyxnQkFBZ0I7QUFDbEJ0USw2Q0FBbUIsTUFBTTtBQUFBLHdCQUMzQjtBQUFBLHdCQUNBLFdBQVcsNEVBQTRFRCxvQkFBb0IsU0FDdkcscUNBQ0EsaUNBQWlDO0FBQUEsd0JBQ2hDO0FBQUE7QUFBQSxzQkFSUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBV0E7QUFBQSx1QkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkEwQkEsS0EzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkE0QkE7QUFBQSxrQkFJQ0Esb0JBQW9CLGtCQUNuQjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUyxDQUFDbUMsTUFBTUEsRUFBRW9PLGdCQUFnQjtBQUFBLHNCQUVqQ25TLDZCQUNDLHVCQUFDLFNBQUksV0FBVSxhQUNaLFdBQUMsR0FBR3VHLE1BQU0sQ0FBQyxDQUFDLEVBQUUrRDtBQUFBQSx3QkFBSSxDQUFDb0gsR0FBR0MsTUFDckI7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBRUMsV0FBVTtBQUFBO0FBQUEsMEJBRExBO0FBQUFBLDBCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBRXVEO0FBQUEsc0JBRXhELEtBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFPQSxJQUVBLHVCQUFDLFdBQU0sV0FBVSwwQkFDZjtBQUFBLCtDQUFDLFdBQ0MsaUNBQUMsUUFBRyxXQUFVLGVBQ1o7QUFBQSxpREFBQyxRQUFHLFdBQVUsaUJBQWdCLGtCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFnQztBQUFBLDBCQUNoQyx1QkFBQyxRQUFHLFdBQVUsaUJBQWdCLDJCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUF5QztBQUFBLDBCQUN6Qyx1QkFBQyxRQUFHLFdBQVUsaUJBQWdCLDZCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUEyQztBQUFBLDBCQUMzQyx1QkFBQyxRQUFHLFdBQVUsaUJBQWdCLHFCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFtQztBQUFBLDBCQUNuQyx1QkFBQyxRQUFHLFdBQVUsaUJBQWdCLHNCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFvQztBQUFBLDBCQUNwQyx1QkFBQyxRQUFHLFdBQVUsaUJBQWdCLDBCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUF3QztBQUFBLDZCQU4xQztBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFTQTtBQUFBLHdCQUVBLHVCQUFDLFdBQ0UzRyxnQ0FBc0J2RSxTQUFTLElBQzlCdUUsc0JBQXNCVjtBQUFBQSwwQkFBSSxDQUFDM0MsU0FDekI7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBRUMsV0FBVTtBQUFBLDhCQUVWO0FBQUEsdURBQUMsUUFBRyxXQUFVLE9BQU9BLGVBQUsrQyxNQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUE2QjtBQUFBLGdDQUM3Qix1QkFBQyxRQUFHLFdBQVUsT0FBTy9DLGVBQUtzRCxlQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUFzQztBQUFBLGdDQUN0Qyx1QkFBQyxRQUFHLFdBQVUsT0FBT3RELGVBQUtNLGFBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBQW9DO0FBQUEsZ0NBQ3BDLHVCQUFDLFFBQUcsV0FBVSxPQUFPTixlQUFLTyxnQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FBdUM7QUFBQSxnQ0FFdkMsdUJBQUMsUUFBRyxXQUFVLE9BQ1o7QUFBQSxrQ0FBQztBQUFBO0FBQUEsb0NBQ0MsV0FBVywyQ0FBMkNQLEtBQUt1RCxXQUFXLGNBQ2xFLGdDQUNBLHlCQUF5QjtBQUFBLG9DQUc1QnZELGVBQUt1RDtBQUFBQTtBQUFBQSxrQ0FOUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQVNBO0FBQUEsZ0NBRUEsdUJBQUMsUUFBRyxXQUFVLE9BQ1h2RCxlQUFLeUQsY0FDSixDQUFDZ0gsTUFBTSxJQUFJdEosS0FBS25CLEtBQUt5RCxVQUFVLENBQUMsSUFDOUIsSUFBSXRDLEtBQUtuQixLQUFLeUQsVUFBVSxFQUFFM0Q7QUFBQUEsa0NBQzFCO0FBQUEsZ0NBQ0YsSUFDRSxPQU5OO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBT0E7QUFBQTtBQUFBO0FBQUEsNEJBMUJLRSxLQUFLK0M7QUFBQUEsNEJBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkE0QkE7QUFBQSx3QkFDRCxJQUVELHVCQUFDLFFBQ0M7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsU0FBUTtBQUFBLDRCQUNSLFdBQVU7QUFBQSw0QkFBK0I7QUFBQTtBQUFBLDBCQUYzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQU9BLEtBekNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBMkNBO0FBQUEsMkJBdkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBd0RBO0FBQUE7QUFBQSxvQkF0RUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQXdFQTtBQUFBLGtCQUtEOUksb0JBQW9CLFVBQ25CO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixTQUFTLENBQUNtQyxNQUFNQSxFQUFFb08sZ0JBQWdCO0FBQUEsc0JBRWpDek8saUNBQ0MsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0NBQUMsU0FBSSxXQUFVLCtDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTBEO0FBQUEsd0JBQzFELHVCQUFDLFNBQUksV0FBVSwrQ0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUEwRDtBQUFBLDJCQUY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBLElBQ0U1QyxXQUFXSyxxQkFBcUJzRixTQUFTLElBQzNDLHVCQUFDLFNBQUksV0FBVSxPQUNiO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQU0zRixXQUFXSztBQUFBQSwwQkFDakIsU0FBU3NEO0FBQUFBO0FBQUFBLHdCQUZYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFFZ0MsS0FIbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFLQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FBd0MsNkNBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQTtBQUFBLG9CQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBcUJBO0FBQUE7QUFBQTtBQUFBLGNBNUlKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQThJQTtBQUFBLGVBNUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNkxBO0FBQUEsYUF2bkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3bkJBO0FBQUEsUUE0SUEsdUJBQUMsU0FBSSxXQUFVLHVFQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHdFQUNiO0FBQUEsbUNBQUMsU0FDQztBQUFBLHFDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSxtQ0FBa0MsZ0RBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxJQUFHO0FBQUEsb0JBQ0gsV0FBVTtBQUFBLG9CQUE0RjtBQUFBO0FBQUEsa0JBRnhHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLG1CQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxjQUVBLHVCQUFDLE9BQUUsV0FBVSx5QkFBd0IseURBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTTtBQUNiLHdCQUFNZ04sWUFBWSxDQUFDclIsWUFBWVM7QUFFL0JSLGlDQUFlLENBQUNtTixVQUFVO0FBQUEsb0JBQ3hCLEdBQUdBO0FBQUFBLG9CQUNIM00sZ0JBQWdCNFE7QUFBQUEsa0JBQ2xCLEVBQUU7QUFFRixzQkFBSUEsYUFBYWpRLGtCQUFrQmlGLFdBQVcsR0FBRztBQUMvQ3lELDJDQUF1QixFQUFFO0FBQUEsa0JBQzNCO0FBQUEsZ0JBQ0Y7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBRVYsaUNBQUMsVUFBSyxXQUFVLDJDQUNiOUosc0JBQVlTLGlCQUFpQixNQUFNLE9BRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQTtBQUFBLGNBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWtCQSxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9CQTtBQUFBLGVBdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0NBO0FBQUEsVUFFQ1gsd0JBQ0MsdUJBQUMsU0FBSSxXQUFVLGFBQ1osV0FBQyxHQUFHcUcsTUFBTSxDQUFDLENBQUMsRUFBRStEO0FBQUFBLFlBQUksQ0FBQ29ILEdBQUdDLE1BQ3JCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsV0FBVTtBQUFBO0FBQUEsY0FETEE7QUFBQUEsY0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRXVEO0FBQUEsVUFFeEQsS0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BLElBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVcsMkRBQTJEdlIsWUFBWVMsaUJBQzlFLCtCQUNBLG1CQUFtQjtBQUFBLGNBR3RCWCxrQ0FDQyx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXQTtBQUFBQSxrQkFDWCxTQUFTc0Isa0JBQWtCaUYsV0FBVztBQUFBLGtCQUN0QyxNQUFLO0FBQUE7QUFBQSxnQkFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FHNkIsS0FKL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFNQSxJQUVBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQU00RDtBQUFBQSxrQkFDTixTQUFTM0Y7QUFBQUE7QUFBQUEsZ0JBRlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRWtDO0FBQUE7QUFBQSxZQWpCdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBb0JBO0FBQUEsYUF6RUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRFQTtBQUFBLFdBbmtDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc2tDQTtBQUFBLFNBdm9DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd29DQTtBQUFBLElBRUNoQyxzQkFDQyx1QkFBQyxTQUFJLFdBQVUsa0dBQ2IsaUNBQUMsU0FBSSxXQUFVLDBIQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLG1DQUNYO0FBQUE7QUFBQSxVQUFJO0FBQUEsYUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1DLHNCQUFzQixLQUFLO0FBQUEsWUFDMUMsV0FBVTtBQUFBLFlBRVY7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsTUFBSztBQUFBLGdCQUNMLFFBQU87QUFBQSxnQkFDUCxTQUFRO0FBQUEsZ0JBRVI7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsZUFBYztBQUFBLG9CQUNkLGdCQUFlO0FBQUEsb0JBQ2YsYUFBWTtBQUFBLG9CQUNaLEdBQUU7QUFBQTtBQUFBLGtCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJMEI7QUFBQTtBQUFBLGNBVjVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVlBO0FBQUE7QUFBQSxVQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFpQkE7QUFBQSxXQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUJBO0FBQUEsTUFFQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCO0FBQUE7QUFBQSxRQUNPO0FBQUEsUUFDL0MsdUJBQUMsVUFBSyxXQUFVLCtCQUNiQztBQUFBQTtBQUFBQSxVQUFpQjtBQUFBLGFBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixXQUFVO0FBQUEsWUFBOEM7QUFBQTtBQUFBLFVBRjFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsSUFBRztBQUFBLFlBQ0gsTUFBSztBQUFBLFlBQ0wsT0FBT0U7QUFBQUEsWUFDUCxVQUFVLENBQUNpQixNQUFNaEIsaUJBQWlCZ0IsRUFBRUUsT0FBT0QsS0FBSztBQUFBLFlBQ2hELGFBQVk7QUFBQSxZQUNaO0FBQUEsWUFDQSxXQUFVO0FBQUE7QUFBQSxVQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU91TTtBQUFBLFFBRXRNaEIsWUFDQyx1QkFBQyxPQUFFLFdBQVUsMkRBQ1g7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsTUFBSztBQUFBLGNBQ0wsU0FBUTtBQUFBLGNBRVI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsVUFBUztBQUFBLGtCQUNULEdBQUU7QUFBQSxrQkFDRixVQUFTO0FBQUE7QUFBQSxnQkFIWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FHb0I7QUFBQTtBQUFBLFlBUnRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBO0FBQUEsVUFDQ0E7QUFBQUEsYUFaSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxXQTlCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0NBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1MLHNCQUFzQixLQUFLO0FBQUEsWUFDMUMsV0FBVTtBQUFBLFlBQ1YsVUFBVU87QUFBQUEsWUFBZ0I7QUFBQTtBQUFBLFVBSDVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBU2lDO0FBQUFBLFlBQ1QsVUFBVWpDO0FBQUFBLFlBQ1YsV0FBVztBQUFBLG9CQUNUQSxrQkFDSSxnREFDQSxxSEFBcUg7QUFBQSxZQUcxSEEsNEJBQ0MsbUNBQ0U7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsT0FBTTtBQUFBLGtCQUNOLE1BQUs7QUFBQSxrQkFDTCxTQUFRO0FBQUEsa0JBRVI7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsSUFBRztBQUFBLHdCQUNILElBQUc7QUFBQSx3QkFDSCxHQUFFO0FBQUEsd0JBQ0YsUUFBTztBQUFBLHdCQUNQLGFBQVk7QUFBQTtBQUFBLHNCQU5kO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPQztBQUFBLG9CQUNEO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixNQUFLO0FBQUEsd0JBQ0wsR0FBRTtBQUFBO0FBQUEsc0JBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUlDO0FBQUE7QUFBQTtBQUFBLGdCQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FtQkE7QUFBQSxjQUFNO0FBQUEsaUJBcEJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBLElBRUE7QUFBQTtBQUFBLFVBbENKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQW9DQTtBQUFBLFdBNUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2Q0E7QUFBQSxTQWhIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUhBLEtBbEhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FtSEE7QUFBQSxPQTF3Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTR3Q0EsS0E3d0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4d0NBO0FBRUo7QUFBRS9FLEdBenlFSUQsTUFBSTtBQUFBLFVBb0RTM0IsV0FBVztBQUFBO0FBQUE4VixLQXBEeEJuVTtBQTJ5RU4sZUFBZUE7QUFBSyxJQUFBbVU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkJhZGdlQ2hlY2siLCJCcmllZmNhc2VCdXNpbmVzcyIsIkJ1aWxkaW5nMiIsIkNhbGVuZGFyRGF5cyIsIkNsaXBib2FyZExpc3QiLCJHaXRCcmFuY2giLCJJbmRpYW5SdXBlZSIsIkxheWVyczMiLCJNZXNzYWdlU3F1YXJlVGV4dCIsIlBlcmNlbnQiLCJVc2VyUm91bmRDaGVjayIsIlVzZXJzUm91bmQiLCJXYWxsZXQiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInVzZUNhbGxiYWNrIiwidXNlTmF2aWdhdGUiLCJhcGkiLCJDdXN0b21BbGVydERpYWxvZyIsIkJzR3JpZDNYM0dhcEZpbGwiLCJCc0xpc3RVbCIsIlJlY2VpcHQiLCJmb3JtYXREYXRlWVlZWU1NREQiLCJDbG9zaW5nR3JvdXBzTW9kYWwiLCJkYXlqcyIsIkRyb3Bkb3duIiwiVGFnIiwiQ2xvY2tDaXJjbGVPdXRsaW5lZCIsIkNoZWNrQ2lyY2xlT3V0bGluZWQiLCJDbG9zZUNpcmNsZU91dGxpbmVkIiwiTGluayIsIklvTWRNb3JlIiwiQ2hldnJvbkRvd24iLCJDaGV2cm9uVXAiLCJEYXRhVGFibGUiLCJGYUNvcHkiLCJGYVNoYXJlQWx0IiwiRmFFeHRlcm5hbExpbmtBbHQiLCJtZXNzYWdlIiwiVG9vbHRpcCIsIkNpcmN1bGFyTG9hZGVyIiwiQ3VzdG9tZXJBY2tub3dsZWRnZW1lbnRQcmludCIsIkRhc2hib2FyZEFuYWx5dGljc0NvbnRlbnQiLCJIb21lIiwiX3MiLCJncm91cHMiLCJzZXRHcm91cHMiLCJ1c2VycyIsInNldFVzZXJzIiwiYWdlbnRzIiwic2V0QWdlbnRzIiwic3RhZmZzIiwic2V0U3RhZmZzIiwiZW1wbG95ZWVzIiwic2V0RW1wbG95ZWVzIiwicGF5bWVudHNWYWx1ZSIsInNldFBheW1lbnRzVmFsdWUiLCJwYXltZW50c1Blck1vbnRoVmFsdWUiLCJzZXRQYXltZW50c1Blck1vbnRoVmFsdWUiLCJzZWFyY2hWYWx1ZSIsInNldFNlYXJjaFZhbHVlIiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJoaWRlUGF5bWVudCIsInNldEhpZGVQYXltZW50Iiwic2hvd01vYmlsZVNpZGViYXIiLCJzZXRTaG93TW9iaWxlU2lkZWJhciIsImVucm9sbG1lbnRzQ291bnQiLCJzZXRFbnJvbGxtZW50c0NvdW50IiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwidmlld01vZGUiLCJzZXRWaWV3TW9kZSIsIm1vYmlsZUFwcExvYWRpbmciLCJzZXRNb2JpbGVBcHBMb2FkaW5nIiwiYWNrbm93bGVkbWVudHNMb2FkaW5nIiwic2V0QWNrbm93bGVkbWVudHNMb2FkaW5nIiwib3BlblNlY3Rpb24iLCJzZXRPcGVuU2VjdGlvbiIsInRyYW5zYWN0aW9ucyIsImVucm9sbG1lbnRzIiwidW52ZXJpZmllZEN1c3RvbWVycyIsInBheW91dHMiLCJtb2JpbGVBcHBsb2dzIiwiaW5zdGFsbGF0aW9ucyIsImNsb3NpbmdHcm91cHMiLCJhY2tub3dsZWRtZW50cyIsInRhYmxlRGF0YSIsInNldFRhYmxlRGF0YSIsInRhYmxlVHJhbnNhY3Rpb25zIiwieWVzdGVyZGF5RW5yb2xsbWVudHMiLCJyZWNlbnRQYXlvdXRzIiwicmVjZW50TW9iaWxlQXBwTG9ncyIsIm1vYmlsZUFwcFN1bW1hcnkiLCJzZXRNb2JpbGVBcHBTdW1tYXJ5IiwibW9iaWxlQXBwRGF0YSIsInNldE1vYmlsZUFwcERhdGEiLCJhY2tub3dsZWRtZW50RGF0YSIsInNldGFja25vd2xlZG1lbnREYXRhIiwiY2xvc2luZ0dyb3Vwc0RhdGEiLCJzZXRjbG9zaW5nR3JvdXBzRGF0YSIsImFjdGl2ZU1vYmlsZVRhYiIsInNldEFjdGl2ZU1vYmlsZVRhYiIsInRhcmdldFZhbHVlIiwic2V0VGFyZ2V0VmFsdWUiLCJzZWNvbmRhcnlUYXJnZXRWYWx1ZSIsInNldFNlY29uZGFyeVRhcmdldFZhbHVlIiwidHJhbnNhY3Rpb25zTG9hZGluZyIsInNldFRyYW5zYWN0aW9uc0xvYWRpbmciLCJzZXRUYWJsZVRyYW5zYWN0aW9ucyIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwidHlwZSIsIm5hdmlnYXRlIiwic2hvd1Bhc3N3b3JkUHJvbXB0Iiwic2V0U2hvd1Bhc3N3b3JkUHJvbXB0Iiwic2VsZWN0ZWRSZWRpcmVjdCIsInNldFNlbGVjdGVkUmVkaXJlY3QiLCJwYXNzd29yZElucHV0Iiwic2V0UGFzc3dvcmRJbnB1dCIsImVycm9yTXNnIiwic2V0RXJyb3JNc2ciLCJpc0xvYWRpbmdWZXJpZnkiLCJzZXRJc0xvYWRpbmdWZXJpZnkiLCJzaG93UmV2ZW51ZSIsInNldFNob3dSZXZlbnVlIiwiZW5yb2xsbWVudHNMb2FkaW5nIiwic2V0RW5yb2xsbWVudHNMb2FkaW5nIiwicGF5b3V0c0xvYWRpbmciLCJzZXRQYXlvdXRzTG9hZGluZyIsIm1vYmlsZUFwcExvZ3NMb2FkaW5nIiwic2V0TW9iaWxlQXBwTG9nc0xvYWRpbmciLCJjbG9zaW5nR3JvdXBzTG9hZGluZyIsInNldGNsb3NpbmdHcm91cHNMb2FkaW5nIiwiR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciIsImUiLCJ2YWx1ZSIsInRhcmdldCIsImhhbmRsZVZpZXdEZXRhaWxzQ2xpY2siLCJyZWRpcmVjdCIsImVucm9sbG1lbnRDb2x1bW5zIiwia2V5IiwiaGVhZGVyIiwidW52ZXJpZmllZEN1c3RvbWVyc0NvbHVtbnMiLCJwYXlPdXRDb2x1bW5zIiwibW9iaWxlQXBwTG9nc0NvbHVtbnMiLCJhY2tub3dsZWRnZW1lbnRDb2x1bW5zIiwiZmV0Y2hUb3RhbEJyYW5jaFRhcmdldCIsInJlc3BvbnNlIiwiZ2V0IiwiZGF0YSIsImJyYW5jaFRhcmdldCIsImVycm9yIiwiY29uc29sZSIsImZldGNoVG90YWxTZWNvbmRhcnlCcmFuY2hUYXJnZXQiLCJ2ZXJpZnlQYXNzd29yZEFuZFJlZGlyZWN0IiwiYWRtaW4iLCJKU09OIiwicGFyc2UiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwicGFzc3dvcmQiLCJwb3N0IiwicGhvbmVOdW1iZXIiLCJ0b2tlbiIsInNldFRpbWVvdXQiLCJlcnIiLCJ1c2VyIiwidXNlck9iaiIsImFkbWluX2FjY2Vzc19yaWdodF9pZCIsImFjY2Vzc19wZXJtaXNzaW9ucyIsImVkaXRfcGF5bWVudCIsImlzTW9kaWZ5IiwiZmV0Y2hHcm91cHMiLCJmZXRjaEVucm9sbG1lbnRzIiwiQXJyYXkiLCJpc0FycmF5IiwibGVuZ3RoIiwiZmV0Y2hVc2VycyIsImZldGNoQWdlbnRzIiwidmVyaWZpZWRBZ2VudCIsImFnZW50IiwiZmlsdGVyIiwiaXNWZXJpZmllZCIsImZldGNoU3RhZmZzIiwidmVyaWZpZWRTdGFmZiIsInN0YWZmIiwiZmV0Y2hFbXBsb3llZXMiLCJ2ZXJpZmllZEVtcGxveWVlIiwiZW1wbG95ZWUiLCJmZXRjaFRvdGFsUGF5bWVudHMiLCJ0b3RhbEFtb3VudCIsImdldE1hc2tlZFZhbHVlIiwidG9Mb2NhbGVTdHJpbmciLCJoYW5kbGVDb3B5VHJhbnNhY3Rpb24iLCJpdGVtIiwiY3VzdG9tZXIiLCJncm91cCIsImNvcHlUZXh0IiwidHJhbnNhY3Rpb25faWQiLCJyZXBsYWNlIiwiZnVsbF9uYW1lIiwicGhvbmVfbnVtYmVyIiwidHJhbnNhY3Rpb25fdHlwZSIsInJlYXNvbiIsInBpZ21lX2lkIiwiY2xvc3VyZV90eXBlIiwiZ3Jvc3NfYW1vdW50IiwiYW1vdW50IiwiaW50ZXJlc3RfYW1vdW50Iiwic2VydmljZV9jaGFyZ2UiLCJnc3RfYW1vdW50IiwicmVtYXJrcyIsInRyYW5zYWN0aW9uX2RhdGUiLCJEYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiZ3JvdXBfbmFtZSIsImxvYW5faWQiLCJlbnJvbGxfaWQiLCJ0aWNrZXRzIiwiZW5yb2xsX2NvZGUiLCJwYXltZW50X3R5cGUiLCJyZXF1ZXN0X3N0YXR1cyIsImFkbWluX2lkIiwibmFtZSIsImFkbWluX25hbWUiLCJ0cmltIiwibmF2aWdhdG9yIiwiY2xpcGJvYXJkIiwid3JpdGVUZXh0Iiwic3VjY2VzcyIsImZldGNoY2xvc2luZ0dyb3Vwc0RhdGEiLCJyZXMiLCJmZXRjaE1vYmlsZUFwcEluc3RhbGxzIiwiZmV0Y2hhY2tub3dsZWRtZW50RGF0YSIsImxpbWl0IiwidXJsIiwiYWNrbm93bGVkbWVudHNUYWJsZURhdGEiLCJtYXAiLCJpbmRleCIsInVzZXJfaWQiLCJncm91cF9pZCIsImlkIiwidG9GaXhlZCIsImRpZmZfZ3JvdXBfdmFsdWUiLCJhY3Rpb24iLCJpdGVtcyIsImxhYmVsIiwiaW5zdGFsbGF0aW9uVGFibGVEYXRhIiwiY3VzdG9tZXJfaWQiLCJzdGF0dXMiLCJ2ZXJkaWN0IiwibGFzdF9sb2dpbiIsImxhc3Rfc3VjY2Vzc2Z1bF9sb2dpbl9hdCIsInRvZGF5IiwibGFzdFdlZWsiLCJzZXREYXRlIiwiZ2V0RGF0ZSIsImRhdGUiLCJ5ZWFyIiwiZ2V0RnVsbFllYXIiLCJtb250aCIsIlN0cmluZyIsImdldE1vbnRoIiwicGFkU3RhcnQiLCJkYXkiLCJmcm9tRGF0ZSIsInRvRGF0ZSIsImVucm9sbFJlc3BvbnNlIiwiZW5yb2xsUmVwb3J0UmVzcG9uc2UiLCJQcm9taXNlIiwiYWxsIiwiZm9ybWF0dGVkRGF0YSIsIl9pZCIsImdyb3VwX3ZhbHVlIiwiZW5yb2xsbWVudF9kYXRlIiwiY3JlYXRlZEF0Iiwic3BsaXQiLCJyZXZlcnNlIiwiam9pbiIsImNoaXRfYXNraW5nX21vbnRoIiwidGlja2V0IiwicmVmZXJyZWRfdHlwZSIsInJlZmVycmFsX3R5cGUiLCJyZWZlcnJlZF9ieSIsInJlZmVycmVkX2VtcGxveWVlIiwicmVmZXJyZWRfYWdlbnQiLCJyZWZlcnJlZF9jdXN0b21lciIsInByZXYiLCJmZXRjaFBheW91dHMiLCJwYXlvdXRSZXNwb25zZSIsIm1vYkFwcExvZ3NSZXMiLCJ1bnZlcmlmaWVkQ3VzdG9tZXJzUmVzIiwicGF5X2RhdGUiLCJwYXlfdHlwZSIsImNoZXF1ZV9udW1iZXIiLCJjaGVxdWVfZGF0ZSIsInBheV9mb3IiLCJkaXNidXJzZW1lbnRfdHlwZSIsImNhdGVnb3J5Iiwibm90ZSIsImFkbWluX3R5cGUiLCJyZWNlaXB0X25vIiwic3VtbWFyeSIsImZvcm1hdHRlZERhdGFNb2JpbGVEYXRhIiwicGhvbmUiLCJmb3JtYXR0ZWRVbnZlcmlmaWVkQ3VzdG9tZXJzIiwiYWRkcmVzcyIsImdldFRyYW5zYWN0aW9ucyIsInRyYW5zYWN0aW9uc0RhdGEiLCJmaWx0ZXJlZERhdGEiLCJvcmRlciIsImNvbG9yIiwiaWNvbiIsInBpZ215cyIsImxvYW5zIiwiZ3JvdXBzU3RyaW5nIiwicGlnbXlzU3RyaW5nIiwicGlnbXkiLCJwYXlhYmxlX2Ftb3VudCIsImxvYW5zU3RyaW5nIiwibG9hbiIsImxvYW5fYW1vdW50Iiwib3JkZXJUeXBlIiwib3JkZXJfdHlwZSIsInVzZXJfbmFtZSIsIm90aGVycyIsInB1cnBvc2UiLCJsaW5rX3VybCIsInN0YXR1c1JhdyIsImNvbGxlY3RlZEJ5IiwiY29sbGVjdGVkX2J5IiwiY2FyZERhdGEiLCJ0aXRsZSIsInN1YnRpdGxlIiwiaWNvbkJnIiwiaWNvbkNvbG9yIiwiYm9yZGVyQ29sb3IiLCJyaW5nQ29sb3IiLCJjYXJkIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsIm5ld3NJdGVtcyIsInRleHQiLCJpY29uQ2xhc3MiLCJoYW5kbGVDb3B5TGluayIsIndhcm5pbmciLCJHUklEX0xBWU9VVCIsImNvbmNhdCIsImlkeCIsIkljb24iLCJDYXJkRWxlbWVudCIsIm9uQ2xpY2siLCJpc09wZW5pbmciLCJfIiwiaSIsImVuZF9kYXRlIiwiZGF5c19yZW1haW5pbmciLCJtb250aHNfcmVtYWluaW5nIiwidG9TdHJpbmciLCJ3aW5kb3ciLCJvcGVuIiwiaW5mbyIsInN0b3BQcm9wYWdhdGlvbiIsImlzTmFOIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSG9tZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCB7XHJcbiAgQmFkZ2VDaGVjayxcclxuICBCcmllZmNhc2VCdXNpbmVzcyxcclxuICBCdWlsZGluZzIsXHJcbiAgQ2FsZW5kYXJEYXlzLFxyXG4gIENsaXBib2FyZExpc3QsXHJcbiAgR2l0QnJhbmNoLFxyXG4gIEluZGlhblJ1cGVlLFxyXG4gIExheWVyczMsXHJcbiAgTWVzc2FnZVNxdWFyZVRleHQsXHJcbiAgUGVyY2VudCxcclxuICBVc2VyUm91bmRDaGVjayxcclxuICBVc2Vyc1JvdW5kLFxyXG4gIFdhbGxldCxcclxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZUNhbGxiYWNrIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCB7IEJzR3JpZDNYM0dhcEZpbGwsIEJzTGlzdFVsIH0gZnJvbSBcInJlYWN0LWljb25zL2JzXCI7XHJcbmltcG9ydCBSZWNlaXB0IGZyb20gXCIuLi9jb21wb25lbnRzL3JlY2VpcHRzL0N1c3RvbVJlY2VpcHRPbmVcIjtcclxuaW1wb3J0IHsgZm9ybWF0RGF0ZVlZWVlNTUREIH0gZnJvbSBcIi4uL2hlbHBlcnMvZGF0ZUNvbnZlcnRpb25cIjtcclxuaW1wb3J0IENsb3NpbmdHcm91cHNNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvQ2xvc2luZ0dyb3Vwc01vZGFsXCI7XHJcbmltcG9ydCBkYXlqcyBmcm9tIFwiZGF5anNcIjtcclxuaW1wb3J0IHsgRHJvcGRvd24sIFRhZyB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7XHJcbiAgQ2xvY2tDaXJjbGVPdXRsaW5lZCxcclxuICBDaGVja0NpcmNsZU91dGxpbmVkLFxyXG4gIENsb3NlQ2lyY2xlT3V0bGluZWQsXHJcbn0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgeyBDaGV2cm9uRG93biwgQ2hldnJvblVwIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCB7IEZhQ29weSwgRmFTaGFyZUFsdCwgRmFFeHRlcm5hbExpbmtBbHQgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IHsgbWVzc2FnZSwgVG9vbHRpcCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBDdXN0b21lckFja25vd2xlZGdlbWVudFByaW50IGZyb20gXCIuLi9jb21wb25lbnRzL3ByaW50Rm9ybWF0cy9DdXN0b21lckFja25vd2xlZGdlbWVudFByaW50XCI7XHJcbmltcG9ydCB7IERhc2hib2FyZEFuYWx5dGljc0NvbnRlbnQgfSBmcm9tIFwiLi9BbmFseXRpY3NcIjtcclxuXHJcbmNvbnN0IEhvbWUgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2dyb3Vwcywgc2V0R3JvdXBzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYWdlbnRzLCBzZXRBZ2VudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzdGFmZnMsIHNldFN0YWZmc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2VtcGxveWVlcywgc2V0RW1wbG95ZWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbcGF5bWVudHNWYWx1ZSwgc2V0UGF5bWVudHNWYWx1ZV0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbcGF5bWVudHNQZXJNb250aFZhbHVlLCBzZXRQYXltZW50c1Blck1vbnRoVmFsdWVdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW3NlYXJjaFZhbHVlLCBzZXRTZWFyY2hWYWx1ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbcmVsb2FkVHJpZ2dlciwgc2V0UmVsb2FkVHJpZ2dlcl0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbaGlkZVBheW1lbnQsIHNldEhpZGVQYXltZW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd01vYmlsZVNpZGViYXIsIHNldFNob3dNb2JpbGVTaWRlYmFyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZW5yb2xsbWVudHNDb3VudCwgc2V0RW5yb2xsbWVudHNDb3VudF0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFt2aWV3TW9kZSwgc2V0Vmlld01vZGVdID0gdXNlU3RhdGUoXCJsaXN0XCIpO1xyXG4gIGNvbnN0IFttb2JpbGVBcHBMb2FkaW5nLCBzZXRNb2JpbGVBcHBMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbYWNrbm93bGVkbWVudHNMb2FkaW5nLCBzZXRBY2tub3dsZWRtZW50c0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtvcGVuU2VjdGlvbiwgc2V0T3BlblNlY3Rpb25dID0gdXNlU3RhdGUoe1xyXG4gICAgdHJhbnNhY3Rpb25zOiBmYWxzZSxcclxuICAgIGVucm9sbG1lbnRzOiBmYWxzZSxcclxuICAgIHVudmVyaWZpZWRDdXN0b21lcnM6IGZhbHNlLFxyXG4gICAgcGF5b3V0czogZmFsc2UsXHJcbiAgICBtb2JpbGVBcHBsb2dzOiBmYWxzZSxcclxuICAgIGluc3RhbGxhdGlvbnM6IGZhbHNlLFxyXG4gICAgY2xvc2luZ0dyb3VwczogZmFsc2UsXHJcbiAgICBhY2tub3dsZWRtZW50czogZmFsc2UsXHJcbiAgfSk7XHJcbiAgY29uc3QgW3RhYmxlRGF0YSwgc2V0VGFibGVEYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIHRhYmxlVHJhbnNhY3Rpb25zOiBbXSxcclxuICAgIHllc3RlcmRheUVucm9sbG1lbnRzOiBbXSxcclxuICAgIHJlY2VudFBheW91dHM6IFtdLFxyXG4gICAgcmVjZW50TW9iaWxlQXBwTG9nczogW10sXHJcbiAgICB1bnZlcmlmaWVkQ3VzdG9tZXJzOiBbXSxcclxuICB9KTtcclxuICBjb25zdCBbbW9iaWxlQXBwU3VtbWFyeSwgc2V0TW9iaWxlQXBwU3VtbWFyeV0gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW21vYmlsZUFwcERhdGEsIHNldE1vYmlsZUFwcERhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthY2tub3dsZWRtZW50RGF0YSwgc2V0YWNrbm93bGVkbWVudERhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtjbG9zaW5nR3JvdXBzRGF0YSwgc2V0Y2xvc2luZ0dyb3Vwc0RhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthY3RpdmVNb2JpbGVUYWIsIHNldEFjdGl2ZU1vYmlsZVRhYl0gPSB1c2VTdGF0ZShcImluc3RhbGxhdGlvblwiKTtcclxuICAvLyBCcmFuY2ggVGFyZ2V0IFN0YXRlXHJcbiAgY29uc3QgW3RhcmdldFZhbHVlLCBzZXRUYXJnZXRWYWx1ZV0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbc2Vjb25kYXJ5VGFyZ2V0VmFsdWUsIHNldFNlY29uZGFyeVRhcmdldFZhbHVlXSA9IHVzZVN0YXRlKDApO1xyXG5cclxuICBjb25zdCBbdHJhbnNhY3Rpb25zTG9hZGluZywgc2V0VHJhbnNhY3Rpb25zTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3RhYmxlVHJhbnNhY3Rpb25zLCBzZXRUYWJsZVRyYW5zYWN0aW9uc10gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuXHJcbiAgY29uc3QgW3Nob3dQYXNzd29yZFByb21wdCwgc2V0U2hvd1Bhc3N3b3JkUHJvbXB0XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VsZWN0ZWRSZWRpcmVjdCwgc2V0U2VsZWN0ZWRSZWRpcmVjdF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbcGFzc3dvcmRJbnB1dCwgc2V0UGFzc3dvcmRJbnB1dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZXJyb3JNc2csIHNldEVycm9yTXNnXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmdWZXJpZnksIHNldElzTG9hZGluZ1ZlcmlmeV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dSZXZlbnVlLCBzZXRTaG93UmV2ZW51ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Vucm9sbG1lbnRzTG9hZGluZywgc2V0RW5yb2xsbWVudHNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcGF5b3V0c0xvYWRpbmcsIHNldFBheW91dHNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbW9iaWxlQXBwTG9nc0xvYWRpbmcsIHNldE1vYmlsZUFwcExvZ3NMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY2xvc2luZ0dyb3Vwc0xvYWRpbmcsIHNldGNsb3NpbmdHcm91cHNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFNlYXJjaFZhbHVlKHZhbHVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVWaWV3RGV0YWlsc0NsaWNrID0gKHJlZGlyZWN0KSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZFJlZGlyZWN0KHJlZGlyZWN0KTtcclxuICAgIHNldFNob3dQYXNzd29yZFByb21wdCh0cnVlKTtcclxuICAgIHNldEVycm9yTXNnKFwiXCIpO1xyXG4gIH07XHJcbiAgY29uc3QgZW5yb2xsbWVudENvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImVucm9sbG1lbnRfZGF0ZVwiLCBoZWFkZXI6IFwiRW5yb2xsbWVudCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBfbmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF92YWx1ZVwiLCBoZWFkZXI6IFwiR3JvdXAgVmFsdWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5bWVudF90eXBlXCIsIGhlYWRlcjogXCJwYXltZW50IFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY2hpdF9hc2tpbmdfbW9udGhcIiwgaGVhZGVyOiBcIkNoaXQgQXNraW5nIE1vbnRoXCIgfSxcclxuICAgIHsga2V5OiBcInJlZmVycmVkX3R5cGVcIiwgaGVhZGVyOiBcIlJlZmVycmVkIFR5cGVcIiB9LFxyXG4gICAgLy8geyBrZXk6IFwicmVmZXJyZWRfYWdlbnRcIiwgaGVhZGVyOiBcIlJlZmVycmVkIEFnZW50XCIgfSxcclxuICAgIC8vIHsga2V5OiBcInJlZmVycmVkX2N1c3RvbWVyXCIsIGhlYWRlcjogXCJSZWZlcnJlZCBDdXN0b21lclwiIH0sXHJcbiAgICAvL3sga2V5OiBcInJlZmVycmVkX2xlYWRcIiwgaGVhZGVyOiBcIlJlZmVycmVkIExlYWRcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVmZXJyZWRfYnlcIiwgaGVhZGVyOiBcIlJlZmVycmVkIEJ5XCIgfSxcclxuICBdO1xyXG4gIGNvbnN0IHVudmVyaWZpZWRDdXN0b21lcnNDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJjcmVhdGVkQXRcIiwgaGVhZGVyOiBcIkRhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcl9pZFwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgSURcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gICAgLy8geyBrZXk6IFwiYWRkcmVzc1wiLCBoZWFkZXI6IFwiQWRkcmVzc1wiIH0sXHJcbiAgICAvLyB7IGtleTogXCJwaW5jb2RlXCIsIGhlYWRlcjogXCJQaW5jb2RlXCIgfSxcclxuICAgIC8vIHsga2V5OiBcImNoaXRfYXNraW5nX21vbnRoXCIsIGhlYWRlcjogXCJDaGl0IEFza2luZyBNb250aFwiIH0sXHJcbiAgICAvLyB7IGtleTogXCJyZWZlcnJlZF90eXBlXCIsIGhlYWRlcjogXCJSZWZlcnJlZCBUeXBlXCIgfSxcclxuICAgIC8vIC8vIHsga2V5OiBcInJlZmVycmVkX2FnZW50XCIsIGhlYWRlcjogXCJSZWZlcnJlZCBBZ2VudFwiIH0sXHJcbiAgICAvLyAvLyB7IGtleTogXCJyZWZlcnJlZF9jdXN0b21lclwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgQ3VzdG9tZXJcIiB9LFxyXG4gICAgLy8gLy97IGtleTogXCJyZWZlcnJlZF9sZWFkXCIsIGhlYWRlcjogXCJSZWZlcnJlZCBMZWFkXCIgfSxcclxuICAgIC8vIHsga2V5OiBcInJlZmVycmVkX2J5XCIsIGhlYWRlcjogXCJSZWZlcnJlZCBCeVwiIH0sXHJcbiAgXTtcclxuICBjb25zdCBwYXlPdXRDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJwYXlfZGF0ZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50XCIsIGhlYWRlcjogXCJBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5X3R5cGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgdHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0cmFuc2FjdGlvbl9pZFwiLCBoZWFkZXI6IFwiVHJhbnNhY3Rpb24gSWRcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5X2ZvclwiLCBoZWFkZXI6IFwiUGF5bWVudCBmb3JcIiB9LFxyXG4gICAgeyBrZXk6IFwiZGlzYnVyc2VtZW50X3R5cGVcIiwgaGVhZGVyOiBcIkRpc2J1cnNlbWVudCB0eXBlXCIgfSxcclxuICAgIHsga2V5OiBcImNhdGVnb3J5XCIsIGhlYWRlcjogXCJjYXRlZ29yeVwiIH0sXHJcbiAgICB7IGtleTogXCJyZWNlaXB0X25vXCIsIGhlYWRlcjogXCJSZWNlaXB0IG5vXCIgfSxcclxuICAgIHsga2V5OiBcIm5vdGVcIiwgaGVhZGVyOiBcIk5vdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWRtaW5fdHlwZVwiLCBoZWFkZXI6IFwiQ3JlYXRlZCBieVwiIH0sXHJcbiAgICB7IGtleTogXCJjcmVhdGVkQXRcIiwgaGVhZGVyOiBcImNyZWF0ZWQgQXRcIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IG1vYmlsZUFwcExvZ3NDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJjcmVhdGVkQXRcIiwgaGVhZGVyOiBcImNyZWF0ZWQgQXRcIiB9LFxyXG4gICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgICB7IGtleTogXCJyZWFzb25cIiwgaGVhZGVyOiBcIlJlYXNvblwiIH0sXHJcbiAgICB7IGtleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgYWNrbm93bGVkZ2VtZW50Q29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwidHJhbnNhY3Rpb25faWRcIiwgaGVhZGVyOiBcIkFja25vd2xlZGdlbWVudCBJRFwiIH0sXHJcbiAgICB7IGtleTogXCJ0cmFuc2FjdGlvbl9kYXRlXCIsIGhlYWRlcjogXCJUcmFuc2FjdGlvbiBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImZ1bGxfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICAvLyB7IGtleTogXCJ0cmFuc2FjdGlvbl90eXBlXCIsIGhlYWRlcjogXCJUcmFuc2FjdGlvbiBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX25hbWVcIiwgaGVhZGVyOiBcIkdyb3VwL1BpZ215L0xvYW5cIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0c1wiLCBoZWFkZXI6IFwiVGlja2V0cy9QaWdteS1JZC9Mb2FuLUlkXCIgfSxcclxuICAgIHsga2V5OiBcInJlYXNvblwiLCBoZWFkZXI6IFwiUmVhc29uXCIgfSxcclxuICAgIC8vIHsga2V5OiBcImNsb3N1cmVfdHlwZVwiLCBoZWFkZXI6IFwiQ2xvc3VyZSBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3NzX2Ftb3VudFwiLCBoZWFkZXI6IFwiR3Jvc3MgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcInNlcnZpY2VfY2hhcmdlXCIsIGhlYWRlcjogXCJTZXJ2aWNlIENoYXJnZVwiIH0sXHJcbiAgICB7IGtleTogXCJnc3RfYW1vdW50XCIsIGhlYWRlcjogXCJHU1QgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcImludGVyZXN0X2Ftb3VudFwiLCBoZWFkZXI6IFwiSW50ZXJlc3QgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudFwiLCBoZWFkZXI6IFwiTmV0IEFtb3VudFwiIH0sXHJcbiAgICAvLyB7IGtleTogXCJlbnJvbGxfY29kZVwiLCBoZWFkZXI6IFwiRW5yb2xsbWVudCBDb2RlXCIgfSxcclxuICAgIC8vIHsga2V5OiBcInBheW1lbnRfdHlwZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBUeXBlXCIgfSxcclxuICAgIC8vIHsga2V5OiBcInBpZ21lX2lkXCIsIGhlYWRlcjogXCJQaWdteSBJRFwiIH0sXHJcbiAgICAvLyB7IGtleTogXCJyZXF1ZXN0X3N0YXR1c1wiLCBoZWFkZXI6IFwiUmVxdWVzdCBTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWRtaW5fbmFtZVwiLCBoZWFkZXI6IFwiUHJvY2Vzc2VkIEJ5XCIgfSxcclxuICAgIC8vIHsga2V5OiBcInJlbWFya3NcIiwgaGVhZGVyOiBcIlJlbWFya3NcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIC8vIC0tLSBBZGRlZCBCcmFuY2ggVGFyZ2V0IEZldGNoIExvZ2ljIC0tLVxyXG4gIGNvbnN0IGZldGNoVG90YWxCcmFuY2hUYXJnZXQgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvcGF5bWVudC9icmFuY2gvdGFyZ2V0XCIpO1xyXG4gICAgICBzZXRUYXJnZXRWYWx1ZShyZXNwb25zZT8uZGF0YT8uZGF0YT8uWzBdLmJyYW5jaFRhcmdldCB8fCAwKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBicmFuY2ggdGFyZ2V0IGFtb3VudDpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRUYXJnZXRWYWx1ZSgwKTtcclxuICAgIH1cclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IGZldGNoVG90YWxTZWNvbmRhcnlCcmFuY2hUYXJnZXQgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvcGF5bWVudC9zZWNvbmRhcnktYnJhbmNoL3RhcmdldFwiKTtcclxuICAgICAgc2V0U2Vjb25kYXJ5VGFyZ2V0VmFsdWUocmVzcG9uc2U/LmRhdGE/LmRhdGE/LlswXS5icmFuY2hUYXJnZXQgfHwgMCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYnJhbmNoIHRhcmdldCBhbW91bnQ6XCIsIGVycm9yKTtcclxuICAgICAgc2V0U2Vjb25kYXJ5VGFyZ2V0VmFsdWUoMCk7XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCB2ZXJpZnlQYXNzd29yZEFuZFJlZGlyZWN0ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgc2V0SXNMb2FkaW5nVmVyaWZ5KHRydWUpO1xyXG4gICAgc2V0RXJyb3JNc2coXCJcIik7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBhZG1pbiA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpKTtcclxuICAgICAgaWYgKCFhZG1pbj8ucGFzc3dvcmQpIHtcclxuICAgICAgICBzZXRFcnJvck1zZyhcIk5vIGFkbWluIGNvbnRhY3QgZm91bmQuIFBsZWFzZSBsb2dpbiBhZ2Fpbi5cIik7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nVmVyaWZ5KGZhbHNlKTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoXCIvYWRtaW4vbG9naW5cIiwge1xyXG4gICAgICAgIHBob25lTnVtYmVyOiBhZG1pbi5waG9uZU51bWJlcixcclxuICAgICAgICBwYXNzd29yZDogcGFzc3dvcmRJbnB1dCxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBpZiAocmVzcG9uc2UuZGF0YT8udG9rZW4pIHtcclxuICAgICAgICBzZXRTaG93UGFzc3dvcmRQcm9tcHQoZmFsc2UpO1xyXG4gICAgICAgIHNldFBhc3N3b3JkSW5wdXQoXCJcIik7XHJcbiAgICAgICAgc2V0RXJyb3JNc2coXCJcIik7XHJcblxyXG4gICAgICAgIC8vIFNwZWNpYWwgaGFuZGxpbmcgZm9yIHJldmVudWUgcGFnZXNcclxuICAgICAgICBpZiAoXHJcbiAgICAgICAgICBzZWxlY3RlZFJlZGlyZWN0ID09PSBcIi90b3RhbC1yZXZlbnVlXCIgfHxcclxuICAgICAgICAgIHNlbGVjdGVkUmVkaXJlY3QgPT09IFwiL21vbnRobHktcmV2ZW51ZVwiXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICBzZXRTaG93UmV2ZW51ZSh0cnVlKTtcclxuICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0U2hvd1JldmVudWUoZmFsc2UpLCAzMDAwMCk7IC8vIEhpZGUgYWZ0ZXIgMzAgc2Vjb25kc1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbmF2aWdhdGUoc2VsZWN0ZWRSZWRpcmVjdCk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBzZXRFcnJvck1zZyhcclxuICAgICAgICBlcnIucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJQYXNzd29yZCB2ZXJpZmljYXRpb24gZmFpbGVkXCIsXHJcbiAgICAgICk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmdWZXJpZnkoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB1c2VyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgY29uc3QgdXNlck9iaiA9IEpTT04ucGFyc2UodXNlcik7XHJcbiAgICBpZiAoXHJcbiAgICAgIHVzZXJPYmogJiZcclxuICAgICAgdXNlck9iai5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQ/LmFjY2Vzc19wZXJtaXNzaW9ucz8uZWRpdF9wYXltZW50XHJcbiAgICApIHtcclxuICAgICAgY29uc3QgaXNNb2RpZnkgPVxyXG4gICAgICAgIHVzZXJPYmouYWRtaW5fYWNjZXNzX3JpZ2h0X2lkPy5hY2Nlc3NfcGVybWlzc2lvbnM/LmVkaXRfcGF5bWVudCA9PT1cclxuICAgICAgICBcInRydWVcIjtcclxuICAgICAgc2V0SGlkZVBheW1lbnQoaXNNb2RpZnkpO1xyXG4gICAgfVxyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgICAgc2V0R3JvdXBzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIC8vIC0tLSBBZGRlZCBCcmFuY2ggVGFyZ2V0IEVmZmVjdCAtLS1cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hUb3RhbEJyYW5jaFRhcmdldCgpO1xyXG4gIH0sIFtmZXRjaFRvdGFsQnJhbmNoVGFyZ2V0LCByZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaFRvdGFsU2Vjb25kYXJ5QnJhbmNoVGFyZ2V0KCk7XHJcbiAgfSwgW2ZldGNoVG90YWxTZWNvbmRhcnlCcmFuY2hUYXJnZXQsIHJlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoRW5yb2xsbWVudHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2Vucm9sbC9nZXQtZW5yb2xsXCIpO1xyXG4gICAgICAgIHNldEVucm9sbG1lbnRzQ291bnQoXHJcbiAgICAgICAgICBBcnJheS5pc0FycmF5KHJlc3BvbnNlLmRhdGEpID8gcmVzcG9uc2UuZGF0YS5sZW5ndGggOiAwLFxyXG4gICAgICAgICk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVucm9sbG1lbnRzOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0RW5yb2xsbWVudHNDb3VudCgwKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoRW5yb2xsbWVudHMoKTtcclxuICB9LCBbcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hVc2VycyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuICAgICAgICBzZXRVc2VycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlciBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaFVzZXJzKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQWdlbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9hZ2VudC9nZXRcIik7XHJcbiAgICAgICAgY29uc3QgdmVyaWZpZWRBZ2VudCA9IChyZXNwb25zZS5kYXRhLmFnZW50IHx8IFtdKS5maWx0ZXIoXHJcbiAgICAgICAgICAoYWdlbnQpID0+IGFnZW50LmlzVmVyaWZpZWQgPT09IHRydWUsXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXRBZ2VudHModmVyaWZpZWRBZ2VudCB8fCBbXSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGFnZW50czpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hBZ2VudHMoKTtcclxuICB9LCBbcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hTdGFmZnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2FnZW50L2dldC1hZ2VudFwiKTtcclxuICAgICAgICBjb25zdCB2ZXJpZmllZFN0YWZmID0gKHJlc3BvbnNlLmRhdGEgfHwgW10pLmZpbHRlcihcclxuICAgICAgICAgIChzdGFmZikgPT4gc3RhZmYuaXNWZXJpZmllZCA9PT0gdHJ1ZSxcclxuICAgICAgICApO1xyXG4gICAgICAgIHNldFN0YWZmcyh2ZXJpZmllZFN0YWZmIHx8IFtdKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgc3RhZmZzOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaFN0YWZmcygpO1xyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEVtcGxveWVlcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYWdlbnQvZ2V0LWVtcGxveWVlXCIpO1xyXG4gICAgICAgIGNvbnN0IHZlcmlmaWVkRW1wbG95ZWUgPSAocmVzcG9uc2UuZGF0YT8uZW1wbG95ZWUgfHwgW10pLmZpbHRlcihcclxuICAgICAgICAgIChlbXBsb3llZSkgPT4gZW1wbG95ZWUuaXNWZXJpZmllZCA9PT0gdHJ1ZSxcclxuICAgICAgICApO1xyXG4gICAgICAgIHNldEVtcGxveWVlcyh2ZXJpZmllZEVtcGxveWVlIHx8IFtdKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW1wbG95ZWVzOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEVtcGxveWVlcygpO1xyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFRvdGFsUGF5bWVudHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3BheW1lbnQvZ2V0LXRvdGFsLXBheW1lbnQtYW1vdW50XCIpO1xyXG4gICAgICAgIHNldFBheW1lbnRzVmFsdWUocmVzcG9uc2U/LmRhdGE/LnRvdGFsQW1vdW50IHx8IDApO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB0b3RhbCBwYXltZW50IGFtb3VudDpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hUb3RhbFBheW1lbnRzKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgLy8gdXNlRWZmZWN0KCgpID0+IHtcclxuICAvLyAgIGNvbnN0IGZldGNoTW9udGhseVBheW1lbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gIC8vICAgICB0cnkge1xyXG4gIC8vICAgICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICAvLyAgICAgICBjb25zdCBjdXJyZW50TW9udGggPSB0b2RheS5nZXRNb250aCgpO1xyXG4gIC8vICAgICAgIGNvbnN0IGN1cnJlbnRZZWFyID0gdG9kYXkuZ2V0RnVsbFllYXIoKTtcclxuICAvLyAgICAgICBjb25zdCBmaXJzdERheSA9IGAke2N1cnJlbnRZZWFyfS0ke1N0cmluZyhjdXJyZW50TW9udGggKyAxKS5wYWRTdGFydChcclxuICAvLyAgICAgICAgIDIsXHJcbiAgLy8gICAgICAgICBcIjBcIlxyXG4gIC8vICAgICAgICl9LTAxYDtcclxuICAvLyAgICAgICBjb25zdCBsYXN0RGF5ID0gbmV3IERhdGUoY3VycmVudFllYXIsIGN1cnJlbnRNb250aCArIDEsIDApO1xyXG4gIC8vICAgICAgIGNvbnN0IGxhc3REYXlGb3JtYXR0ZWQgPSBsYXN0RGF5LnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdO1xyXG5cclxuICAvLyAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvcGF5bWVudC9nZXQtY3VycmVudC1tb250aC1wYXltZW50XCIsIHtcclxuICAvLyAgICAgICAgIHBhcmFtczoge1xyXG4gIC8vICAgICAgICAgICBmcm9tX2RhdGU6IGZpcnN0RGF5LFxyXG4gIC8vICAgICAgICAgICB0b19kYXRlOiBsYXN0RGF5Rm9ybWF0dGVkLFxyXG4gIC8vICAgICAgICAgfSxcclxuICAvLyAgICAgICB9KTtcclxuXHJcbiAgLy8gICAgICAgc2V0UGF5bWVudHNQZXJNb250aFZhbHVlKHJlc3BvbnNlPy5kYXRhPy5tb250aGx5UGF5bWVudCB8fCAwKTtcclxuICAvLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAvLyAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgbW9udGhseSBwYXltZW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAvLyAgICAgfVxyXG4gIC8vICAgfTtcclxuICAvLyAgIGZldGNoTW9udGhseVBheW1lbnRzKCk7XHJcbiAgLy8gfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgLy8gRnVuY3Rpb24gdG8gbWFzayByZXZlbnVlIHZhbHVlc1xyXG4gIGNvbnN0IGdldE1hc2tlZFZhbHVlID0gKHZhbHVlKSA9PiB7XHJcbiAgICBpZiAoc2hvd1JldmVudWUpIHtcclxuICAgICAgcmV0dXJuIHZhbHVlLnRvTG9jYWxlU3RyaW5nKCk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gXCLigKLigKLigKLigKLigKJcIjtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDb3B5VHJhbnNhY3Rpb24gPSBhc3luYyAoaXRlbSwgY3VzdG9tZXIsIGdyb3VwKSA9PiB7XHJcbiAgICBjb25zdCBjb3B5VGV4dCA9IGBcclxuVHJhbnNhY3Rpb24gSUQ6ICR7aXRlbS50cmFuc2FjdGlvbl9pZFxyXG4gICAgICAgID8gaXRlbS50cmFuc2FjdGlvbl9pZC5yZXBsYWNlKFwiTUNGLVRSTi1cIiwgXCJNQ0YtQUNLLVwiKVxyXG4gICAgICAgIDogXCItXCJcclxuICAgICAgfVxyXG5DdXN0b21lciBOYW1lOiAke2N1c3RvbWVyPy5mdWxsX25hbWUgfHwgXCItXCJ9XHJcblBob25lIE51bWJlcjogJHtjdXN0b21lcj8ucGhvbmVfbnVtYmVyIHx8IFwiLVwifVxyXG5UcmFuc2FjdGlvbiBUeXBlOiAke2l0ZW0udHJhbnNhY3Rpb25fdHlwZSB8fCBcIi1cIn1cclxuUmVhc29uOiAke2l0ZW0ucmVhc29uIHx8IFwiLVwifSR7aXRlbS5waWdtZV9pZD8uY2xvc3VyZV90eXBlXHJcbiAgICAgICAgPyBgICgke2l0ZW0ucGlnbWVfaWQuY2xvc3VyZV90eXBlfSlgXHJcbiAgICAgICAgOiBcIlwiXHJcbiAgICAgIH1cclxuR3Jvc3MgQW1vdW50OiAke2l0ZW0uZ3Jvc3NfYW1vdW50ID8/IDB9XHJcbkFtb3VudDogJHtpdGVtLmFtb3VudCA/PyAwfVxyXG5JbnRlcmVzdCBBbW91bnQ6ICR7aXRlbS5pbnRlcmVzdF9hbW91bnQgPz8gMH1cclxuU2VydmljZSBDaGFyZ2U6ICR7aXRlbS5zZXJ2aWNlX2NoYXJnZSA/PyAwfVxyXG5HU1QgQW1vdW50OiAke2l0ZW0uZ3N0X2Ftb3VudCA/PyAwfVxyXG5SZW1hcmtzOiAke2l0ZW0ucmVtYXJrcyB8fCBcIi1cIn1cclxuVHJhbnNhY3Rpb24gRGF0ZTogJHtpdGVtLnRyYW5zYWN0aW9uX2RhdGVcclxuICAgICAgICA/IG5ldyBEYXRlKGl0ZW0udHJhbnNhY3Rpb25fZGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tSU5cIilcclxuICAgICAgICA6IFwiLVwiXHJcbiAgICAgIH1cclxuR3JvdXAgTmFtZTogJHtncm91cD8uZ3JvdXBfbmFtZVxyXG4gICAgICAgID8gZ3JvdXAuZ3JvdXBfbmFtZVxyXG4gICAgICAgIDogaXRlbS5waWdtZV9pZFxyXG4gICAgICAgICAgPyBcIlBpZ215XCJcclxuICAgICAgICAgIDogaXRlbS5sb2FuX2lkXHJcbiAgICAgICAgICAgID8gXCJMb2FuXCJcclxuICAgICAgICAgICAgOiBcIi1cIlxyXG4gICAgICB9XHJcblRpY2tldHM6ICR7aXRlbS5lbnJvbGxfaWQ/LnRpY2tldHMgfHxcclxuICAgICAgaXRlbS5waWdtZV9pZD8ucGlnbWVfaWQgfHxcclxuICAgICAgaXRlbS5sb2FuX2lkPy5sb2FuX2lkIHx8XHJcbiAgICAgIFwiLVwiXHJcbiAgICAgIH1cclxuRW5yb2xsIENvZGU6ICR7aXRlbS5lbnJvbGxfaWQ/LmVucm9sbF9jb2RlIHx8IFwiLVwifVxyXG5QYXltZW50IFR5cGU6ICR7aXRlbS5lbnJvbGxfaWQ/LnBheW1lbnRfdHlwZSB8fCBcIi1cIn1cclxuUmVxdWVzdCBTdGF0dXM6ICR7aXRlbS5waWdtZV9pZD8ucmVxdWVzdF9zdGF0dXMgfHwgXCItXCJ9XHJcbkFkbWluIE5hbWU6ICR7aXRlbS5hZG1pbl9pZD8ubmFtZSB8fFxyXG4gICAgICBpdGVtLmFkbWluX2lkPy5hZG1pbl9uYW1lIHx8XHJcbiAgICAgIFwiLVwiXHJcbiAgICAgIH1cclxuYC50cmltKCk7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQoY29weVRleHQpO1xyXG4gICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJUcmFuc2FjdGlvbiBkZXRhaWxzIGNvcGllZCFcIik7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGNvcHk6XCIsIGVycm9yKTtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBjb3B5IHRyYW5zYWN0aW9uIGRldGFpbHNcIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hjbG9zaW5nR3JvdXBzRGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldGNsb3NpbmdHcm91cHNMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi92MS9hZG1pbi9ncm91cHMvY2xvc2luZ1wiKTtcclxuXHJcbiAgICAgIHNldGNsb3NpbmdHcm91cHNEYXRhKHJlcz8uZGF0YT8uZGF0YSB8fCBbXSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgbW9iaWxlIGFwcCBpbnN0YWxsYXRpb25zOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldGNsb3NpbmdHcm91cHNEYXRhKFtdKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldGNsb3NpbmdHcm91cHNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaE1vYmlsZUFwcEluc3RhbGxzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0TW9iaWxlQXBwTG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvdjEvYWRtaW4vdXNlcnMvbW9iaWxlLWFwcC1pbnN0YWxsc1wiKTtcclxuXHJcbiAgICAgIHNldE1vYmlsZUFwcERhdGEocmVzPy5kYXRhPy5kYXRhIHx8IFtdKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBtb2JpbGUgYXBwIGluc3RhbGxhdGlvbnM6XCIsIGVycm9yKTtcclxuICAgICAgc2V0TW9iaWxlQXBwRGF0YShbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRNb2JpbGVBcHBMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaGFja25vd2xlZG1lbnREYXRhID0gYXN5bmMgKGxpbWl0KSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRBY2tub3dsZWRtZW50c0xvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgICBjb25zdCB1cmwgPSBsaW1pdFxyXG4gICAgICAgID8gYC92MS9hZG1pbi90cmFuc2FjdGlvbi1oaXN0b3J5P2xpbWl0PSR7bGltaXR9YFxyXG4gICAgICAgIDogXCIvdjEvYWRtaW4vdHJhbnNhY3Rpb24taGlzdG9yeVwiO1xyXG5cclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldCh1cmwpO1xyXG5cclxuICAgICAgc2V0YWNrbm93bGVkbWVudERhdGEocmVzPy5kYXRhPy5kYXRhIHx8IFtdKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBtb2JpbGUgYXBwIGluc3RhbGxhdGlvbnM6XCIsIGVycm9yKTtcclxuICAgICAgc2V0YWNrbm93bGVkbWVudERhdGEoW10pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0QWNrbm93bGVkbWVudHNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBhY2tub3dsZWRtZW50c1RhYmxlRGF0YSA9IGFja25vd2xlZG1lbnREYXRhPy5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XHJcbiAgICBjb25zdCBjdXN0b21lciA9XHJcbiAgICAgIGl0ZW0ucGlnbWVfaWQ/LmN1c3RvbWVyIHx8XHJcbiAgICAgIGl0ZW0uZW5yb2xsX2lkPy51c2VyX2lkIHx8XHJcbiAgICAgIHt9O1xyXG5cclxuICAgIGNvbnN0IGdyb3VwID0gaXRlbS5lbnJvbGxfaWQ/Lmdyb3VwX2lkIHx8IHt9O1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgIHRyYW5zYWN0aW9uX2lkOiBpdGVtLnRyYW5zYWN0aW9uX2lkXHJcbiAgICAgICAgPyBpdGVtLnRyYW5zYWN0aW9uX2lkLnJlcGxhY2UoXCJNQ0YtVFJOLVwiLCBcIk1DRi1BQ0stXCIpXHJcbiAgICAgICAgOiBcIi1cIixcclxuICAgICAgZnVsbF9uYW1lOiBjdXN0b21lci5mdWxsX25hbWUgfHwgXCItXCIsXHJcbiAgICAgIHBob25lX251bWJlcjogY3VzdG9tZXIucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgICB0cmFuc2FjdGlvbl90eXBlOiBpdGVtLnRyYW5zYWN0aW9uX3R5cGUgfHwgXCItXCIsXHJcbiAgICAgIHJlYXNvbjogKFxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmx1ZS04MDAgZm9udC1zZW1pYm9sZCBtbC0xXCI+XHJcbiAgICAgICAgICB7aXRlbS5yZWFzb24gfHwgXCItXCJ9XHJcbiAgICAgICAgICB7aXRlbS5waWdtZV9pZD8uY2xvc3VyZV90eXBlICYmIChcclxuICAgICAgICAgICAgPHNwYW4gPlxyXG4gICAgICAgICAgICAgICh7aXRlbS5waWdtZV9pZC5jbG9zdXJlX3R5cGV9KVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgKSxcclxuICAgICAgZ3Jvc3NfYW1vdW50OiBpdGVtLmdyb3NzX2Ftb3VudCA/PyAwLFxyXG4gICAgICBhbW91bnQ6IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDAgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgIHtpdGVtLmFtb3VudCA/PyAwfVxyXG4gICAgICA8L3NwYW4+LFxyXG4gICAgICBpbnRlcmVzdF9hbW91bnQ6IGl0ZW0uaW50ZXJlc3RfYW1vdW50Py50b0ZpeGVkKDEpID8/IDAsXHJcbiAgICAgIHNlcnZpY2VfY2hhcmdlOiBpdGVtLnNlcnZpY2VfY2hhcmdlID8/IDAsXHJcbiAgICAgIGdzdF9hbW91bnQ6IGl0ZW0uZ3N0X2Ftb3VudCA/PyAwLFxyXG4gICAgICByZW1hcmtzOiBpdGVtLnJlbWFya3MgfHwgXCItXCIsXHJcbiAgICAgIHRyYW5zYWN0aW9uX2RhdGU6IGl0ZW0udHJhbnNhY3Rpb25fZGF0ZVxyXG4gICAgICAgID8gbmV3IERhdGUoaXRlbS50cmFuc2FjdGlvbl9kYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1JTlwiKVxyXG4gICAgICAgIDogXCItXCIsXHJcbiAgICAgIGdyb3VwX25hbWU6IGdyb3VwLmdyb3VwX25hbWUgPyBncm91cC5ncm91cF9uYW1lIDogaXRlbS5waWdtZV9pZCA/IFwiUGlnbXlcIiA6IGl0ZW0ubG9hbl9pZCA/IFwiTG9hblwiIDogXCItXCIsXHJcbiAgICAgIHRpY2tldHM6IGl0ZW0uZW5yb2xsX2lkPy50aWNrZXRzIHx8IGl0ZW0ucGlnbWVfaWQ/LnBpZ21lX2lkIHx8IGl0ZW0ubG9hbl9pZD8ubG9hbl9pZCB8fCBcIi1cIixcclxuICAgICAgZW5yb2xsX2NvZGU6IGl0ZW0uZW5yb2xsX2lkPy5lbnJvbGxfY29kZSB8fCBcIi1cIixcclxuICAgICAgcGF5bWVudF90eXBlOiBpdGVtLmVucm9sbF9pZD8ucGF5bWVudF90eXBlIHx8IFwiLVwiLFxyXG4gICAgICAvLyBwaWdtZV9pZDogaXRlbS5waWdtZV9pZD8ucGlnbWVfaWQgfHwgXCItXCIsXHJcbiAgICAgIHJlcXVlc3Rfc3RhdHVzOiBpdGVtLnBpZ21lX2lkPy5yZXF1ZXN0X3N0YXR1cyB8fCBcIi1cIixcclxuICAgICAgLy8gY2xvc3VyZV90eXBlOiBpdGVtLnBpZ21lX2lkPy5jbG9zdXJlX3R5cGUgfHwgXCItXCIsXHJcbiAgICAgIGFkbWluX25hbWU6XHJcbiAgICAgICAgaXRlbS5hZG1pbl9pZD8ubmFtZSB8fFxyXG4gICAgICAgIGl0ZW0uYWRtaW5faWQ/LmFkbWluX25hbWUgfHxcclxuICAgICAgICBcIi1cIixcclxuICAgICAgZGlmZl9ncm91cF92YWx1ZTogaXRlbS5lbnJvbGxfaWQ/LmRpZmZfZ3JvdXBfdmFsdWUgfHwgXCItXCIsXHJcbiAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDdXN0b21lckFja25vd2xlZGdlbWVudFByaW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW09e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvbl9pZDogaXRlbS50cmFuc2FjdGlvbl9pZCB8fCBcIi1cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmdWxsX25hbWU6IGN1c3RvbWVyLmZ1bGxfbmFtZSB8fCBcIi1cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwaG9uZV9udW1iZXI6IGN1c3RvbWVyLnBob25lX251bWJlciB8fCBcIi1cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvbl90eXBlOiBpdGVtLnRyYW5zYWN0aW9uX3R5cGUgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhc29uOiBpdGVtLnJlYXNvbiB8fCBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3NzX2Ftb3VudDogaXRlbS5ncm9zc19hbW91bnQgPz8gMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IGl0ZW0uYW1vdW50ID8/IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaW50ZXJlc3RfYW1vdW50OiBpdGVtLmludGVyZXN0X2Ftb3VudCA/PyAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNlcnZpY2VfY2hhcmdlOiBpdGVtLnNlcnZpY2VfY2hhcmdlID8/IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZ3N0X2Ftb3VudDogaXRlbS5nc3RfYW1vdW50ID8/IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVtYXJrczogaXRlbS5yZW1hcmtzIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zYWN0aW9uX2RhdGU6IGl0ZW0udHJhbnNhY3Rpb25fZGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBuZXcgRGF0ZShpdGVtLnRyYW5zYWN0aW9uX2RhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUlOXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwX25hbWU6IGdyb3VwLmdyb3VwX25hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGlja2V0czogaXRlbS5lbnJvbGxfaWQ/LnRpY2tldHMgPz8gXCItXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZW5yb2xsX2NvZGU6IGl0ZW0uZW5yb2xsX2lkPy5lbnJvbGxfY29kZSB8fCBcIi1cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwYXltZW50X3R5cGU6IGl0ZW0uZW5yb2xsX2lkPy5wYXltZW50X3R5cGUgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGlnbWVfaWQ6IGl0ZW0ucGlnbWVfaWQ/LnBpZ21lX2lkIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVlc3Rfc3RhdHVzOiBpdGVtLnBpZ21lX2lkPy5yZXF1ZXN0X3N0YXR1cyB8fCBcIi1cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbG9zdXJlX3R5cGU6IGl0ZW0ucGlnbWVfaWQ/LmNsb3N1cmVfdHlwZSB8fCBcIi1cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhZG1pbl9uYW1lOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5hZG1pbl9pZD8ubmFtZSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5hZG1pbl9pZD8uYWRtaW5fbmFtZSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCItXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNzAwIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUNvcHlUcmFuc2FjdGlvbihpdGVtLCBjdXN0b21lciwgZ3JvdXApXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ29weSBUcmFuc2FjdGlvblxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC14bCBjdXJzb3ItcG9pbnRlclwiIC8+XHJcbiAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApLFxyXG4gICAgfTtcclxuICB9KTtcclxuICBjb25zdCBpbnN0YWxsYXRpb25UYWJsZURhdGEgPSBtb2JpbGVBcHBEYXRhLm1hcCgoaXRlbSwgaW5kZXgpID0+ICh7XHJcbiAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgY3VzdG9tZXJfaWQ6IGl0ZW0uY3VzdG9tZXJfaWQgfHwgXCItXCIsXHJcbiAgICBmdWxsX25hbWU6IGl0ZW0uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4gICAgcGhvbmVfbnVtYmVyOiBpdGVtLnBob25lX251bWJlciB8fCBcIi1cIixcclxuICAgIHN0YXR1czogaXRlbS52ZXJkaWN0ID8gXCJJbnN0YWxsZWRcIiA6IFwiTm90IEluc3RhbGxlZFwiLFxyXG4gICAgbGFzdF9sb2dpbjogaXRlbS5sYXN0X3N1Y2Nlc3NmdWxfbG9naW5fYXQgPyBuZXcgRGF0ZShpdGVtLmxhc3Rfc3VjY2Vzc2Z1bF9sb2dpbl9hdCkudG9Mb2NhbGVTdHJpbmcoKSA6IFwiIFwiIHx8IFwiLVwiLFxyXG4gIH0pKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoRW5yb2xsbWVudHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0RW5yb2xsbWVudHNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIC8vIENhbGN1bGF0ZSBkYXRlc1xyXG4gICAgICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICAgICAgICBjb25zdCBsYXN0V2VlayA9IG5ldyBEYXRlKCk7XHJcbiAgICAgICAgbGFzdFdlZWsuc2V0RGF0ZSh0b2RheS5nZXREYXRlKCkgLSA3KTtcclxuXHJcbiAgICAgICAgLy8gRm9ybWF0IGFzIFlZWVktTU0tRERcclxuICAgICAgICBjb25zdCBmb3JtYXREYXRlWVlZWU1NREQgPSAoZGF0ZSkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgeWVhciA9IGRhdGUuZ2V0RnVsbFllYXIoKTtcclxuICAgICAgICAgIGNvbnN0IG1vbnRoID0gU3RyaW5nKGRhdGUuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsIFwiMFwiKTtcclxuICAgICAgICAgIGNvbnN0IGRheSA9IFN0cmluZyhkYXRlLmdldERhdGUoKSkucGFkU3RhcnQoMiwgXCIwXCIpO1xyXG4gICAgICAgICAgcmV0dXJuIGAke3llYXJ9LSR7bW9udGh9LSR7ZGF5fWA7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgY29uc3QgZnJvbURhdGUgPSBmb3JtYXREYXRlWVlZWU1NREQobGFzdFdlZWspO1xyXG4gICAgICAgIGNvbnN0IHRvRGF0ZSA9IGZvcm1hdERhdGVZWVlZTU1ERCh0b2RheSk7XHJcbiAgICAgICAgLy8gUnVuIGJvdGggQVBJIGNhbGxzIGluIHBhcmFsbGVsXHJcbiAgICAgICAgY29uc3QgW2Vucm9sbFJlc3BvbnNlLCBlbnJvbGxSZXBvcnRSZXNwb25zZV0gPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgICBhcGkuZ2V0KFwiL2Vucm9sbC9nZXQtZW5yb2xsXCIpLFxyXG4gICAgICAgICAgYXBpLmdldChcclxuICAgICAgICAgICAgYC9lbnJvbGwtcmVwb3J0L2dldC1kYXNoYm9hcmQtZW5yb2xsbWVudD9mcm9tX2RhdGU9JHtmcm9tRGF0ZX0mdG9fZGF0ZT0ke3RvRGF0ZX1gLFxyXG4gICAgICAgICAgKSxcclxuICAgICAgICBdKTtcclxuXHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IGVucm9sbFJlcG9ydFJlc3BvbnNlPy5kYXRhLm1hcCgoZ3JvdXAsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICBpZiAoIWdyb3VwLmdyb3VwX2lkIHx8ICFncm91cC51c2VyX2lkKSByZXR1cm4ge307XHJcbiAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBfaWQ6IGdyb3VwPy5faWQsXHJcbiAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgIG5hbWU6IGdyb3VwPy51c2VyX2lkPy5mdWxsX25hbWUsXHJcbiAgICAgICAgICAgIHBob25lX251bWJlcjogZ3JvdXA/LnVzZXJfaWQ/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgZ3JvdXBfbmFtZTogZ3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9uYW1lLFxyXG4gICAgICAgICAgICBncm91cF92YWx1ZTogZ3JvdXA/Lmdyb3VwX2lkPy5ncm91cF92YWx1ZSxcclxuICAgICAgICAgICAgcGF5bWVudF90eXBlOiBncm91cD8ucGF5bWVudF90eXBlLFxyXG4gICAgICAgICAgICBlbnJvbGxtZW50X2RhdGU6IGdyb3VwPy5jcmVhdGVkQXRcclxuICAgICAgICAgICAgICA/LnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgICAgICAgIC5zcGxpdChcIi1cIilcclxuICAgICAgICAgICAgICAucmV2ZXJzZSgpXHJcbiAgICAgICAgICAgICAgLmpvaW4oXCItXCIpLFxyXG4gICAgICAgICAgICBjaGl0X2Fza2luZ19tb250aDogZ3JvdXA/LmNoaXRfYXNraW5nX21vbnRoLFxyXG4gICAgICAgICAgICB0aWNrZXQ6IGdyb3VwLnRpY2tldHMsXHJcbiAgICAgICAgICAgIHJlZmVycmVkX3R5cGU6IGdyb3VwPy51c2VyX2lkPy5yZWZlcnJhbF90eXBlLFxyXG4gICAgICAgICAgICAvLyByZWZlcnJlZF9hZ2VudDogZ3JvdXA/LmFnZW50Py5uYW1lLFxyXG4gICAgICAgICAgICAvLyByZWZlcnJlZF9jdXN0b21lcjogZ3JvdXA/LnJlZmVycmVkX2N1c3RvbWVyPy5mdWxsX25hbWUsXHJcbiAgICAgICAgICAgIC8vIHJlZmVycmVkX2xlYWQ6IGdyb3VwPy5yZWZlcnJlZF9sZWFkPy5sZWFkX25hbWUsXHJcbiAgICAgICAgICAgIHJlZmVycmVkX2J5OlxyXG4gICAgICAgICAgICAgIGdyb3VwPy51c2VyX2lkPy5yZWZlcnJhbF90eXBlID09PSBcIlNlbGYgSm9pbmluZ1wiXHJcbiAgICAgICAgICAgICAgICA/IFwiU2VsZiBKb2luaW5nXCJcclxuICAgICAgICAgICAgICAgIDogZ3JvdXA/LnVzZXJfaWQ/LnJlZmVycmVkX2VtcGxveWVlPy5uYW1lICYmXHJcbiAgICAgICAgICAgICAgICAgIGdyb3VwPy51c2VyX2lkPy5yZWZlcnJlZF9lbXBsb3llZT8ucGhvbmVfbnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgID8gYCR7Z3JvdXAudXNlcl9pZC5yZWZlcnJlZF9lbXBsb3llZS5uYW1lfSB8ICR7Z3JvdXAudXNlcl9pZC5yZWZlcnJlZF9lbXBsb3llZS5waG9uZV9udW1iZXJ9YFxyXG4gICAgICAgICAgICAgICAgICA6IGdyb3VwPy51c2VyX2lkPy5yZWZlcnJlZF9hZ2VudD8ubmFtZSAmJlxyXG4gICAgICAgICAgICAgICAgICAgIGdyb3VwPy51c2VyX2lkPy5yZWZlcnJlZF9hZ2VudD8ucGhvbmVfbnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgPyBgJHtncm91cC51c2VyX2lkLnJlZmVycmVkX2FnZW50Lm5hbWV9IHwgJHtncm91cC51c2VyX2lkLnJlZmVycmVkX2FnZW50LnBob25lX251bWJlcn1gXHJcbiAgICAgICAgICAgICAgICAgICAgOiBncm91cD8udXNlcl9pZD8ucmVmZXJyZWRfY3VzdG9tZXI/LmZ1bGxfbmFtZSAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgZ3JvdXA/LnVzZXJfaWQ/LnJlZmVycmVkX2N1c3RvbWVyPy5waG9uZV9udW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgID8gYCR7Z3JvdXAudXNlcl9pZC5yZWZlcnJlZF9jdXN0b21lci5mdWxsX25hbWV9IHwgJHtncm91cC51c2VyX2lkLnJlZmVycmVkX2N1c3RvbWVyLnBob25lX251bWJlcn1gXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTi9BXCIsXHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldEVucm9sbG1lbnRzQ291bnQoXHJcbiAgICAgICAgICBBcnJheS5pc0FycmF5KGVucm9sbFJlc3BvbnNlLmRhdGEpID8gZW5yb2xsUmVzcG9uc2UuZGF0YS5sZW5ndGggOiAwLFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgc2V0VGFibGVEYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgLi4ucHJldiwgLy8ga2VlcCBleGlzdGluZyBwcm9wZXJ0aWVzXHJcbiAgICAgICAgICB5ZXN0ZXJkYXlFbnJvbGxtZW50czogQXJyYXkuaXNBcnJheShmb3JtYXR0ZWREYXRhKVxyXG4gICAgICAgICAgICA/IGZvcm1hdHRlZERhdGFcclxuICAgICAgICAgICAgOiBbXSxcclxuICAgICAgICB9KSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVucm9sbG1lbnRzOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0RW5yb2xsbWVudHNDb3VudCgwKTtcclxuICAgICAgICBzZXRUYWJsZURhdGEoeyB0YWJsZVRyYW5zYWN0aW9uczogW10sIHllc3RlcmRheUVucm9sbG1lbnRzOiBbXSB9KTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRFbnJvbGxtZW50c0xvYWRpbmcoZmFsc2UpOyAvLyBhbHdheXMgc3RvcCBsb2FkZXJcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoRW5yb2xsbWVudHMoKTtcclxuICB9LCBbcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hQYXlvdXRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldFBheW91dHNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIHNldE1vYmlsZUFwcExvZ3NMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIC8vIFJ1biBib3RoIEFQSSBjYWxscyBpbiBwYXJhbGxlbFxyXG4gICAgICAgIGNvbnN0IFtwYXlvdXRSZXNwb25zZSwgbW9iQXBwTG9nc1JlcywgdW52ZXJpZmllZEN1c3RvbWVyc1Jlc10gPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgICBhcGkuZ2V0KFwiL3BheW1lbnQtb3V0L2xhdGVzdC1wYXlvdXRcIiksXHJcbiAgICAgICAgICBhcGkuZ2V0KFwiL3VzZXItZXZlbnQtbG9nZ2VyL2Rhc2hib2FyZC1hcHAtdXNlci1ldmVudHNcIiksXHJcbiAgICAgICAgICBhcGkuZ2V0KFwiL3VzZXIvYXBwcm92YWwtc3RhdHVzL2ZhbHNlXCIpLFxyXG4gICAgICAgIF0pO1xyXG5cclxuICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcGF5b3V0UmVzcG9uc2U/LmRhdGE/LmRhdGE/Lm1hcChcclxuICAgICAgICAgIChncm91cCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgaWYgKCFncm91cC5faWQgfHwgIWdyb3VwLnVzZXJfaWQpIHJldHVybiB7fTtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICBfaWQ6IGdyb3VwPy5faWQsXHJcbiAgICAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgICBuYW1lOiBncm91cD8udXNlcl9pZD8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgICAgIHBob25lX251bWJlcjogZ3JvdXA/LnVzZXJfaWQ/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgICBwYXlfZGF0ZTogZ3JvdXA/LnBheV9kYXRlXHJcbiAgICAgICAgICAgICAgICA/LnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgICAgICAgICAgLnNwbGl0KFwiLVwiKVxyXG4gICAgICAgICAgICAgICAgLnJldmVyc2UoKVxyXG4gICAgICAgICAgICAgICAgLmpvaW4oXCItXCIpLFxyXG4gICAgICAgICAgICAgIGFtb3VudDogZ3JvdXA/LmFtb3VudCxcclxuICAgICAgICAgICAgICBwYXlfdHlwZTogZ3JvdXA/LnBheV90eXBlLFxyXG4gICAgICAgICAgICAgIHRyYW5zYWN0aW9uX2lkOiBncm91cD8ucGF5X3R5cGUgPT09IFwiY2hlcXVlXCJcclxuICAgICAgICAgICAgICAgID8gYCBDaHEgTm86ICR7Z3JvdXA/LmNoZXF1ZV9udW1iZXIgfHwgXCItXCJ9IHwgXHJcbiAgICAgICAgICAgICAgICAgIENocSBEYXRlOiAke2dyb3VwPy5jaGVxdWVfZGF0ZSA/IGdyb3VwLmNoZXF1ZV9kYXRlLnNwbGl0KFwiVFwiKVswXS5zcGxpdChcIi1cIikucmV2ZXJzZSgpLmpvaW4oXCItXCIpIDogJy0nfWAgOiBncm91cD8udHJhbnNhY3Rpb25faWQsXHJcbiAgICAgICAgICAgICAgcGF5X2ZvcjogZ3JvdXA/LnBheV9mb3IsXHJcbiAgICAgICAgICAgICAgZGlzYnVyc2VtZW50X3R5cGU6IGdyb3VwPy5kaXNidXJzZW1lbnRfdHlwZSxcclxuICAgICAgICAgICAgICBjYXRlZ29yeTogZ3JvdXA/LmNhdGVnb3J5LFxyXG4gICAgICAgICAgICAgIG5vdGU6IGdyb3VwPy5ub3RlLFxyXG4gICAgICAgICAgICAgIGFkbWluX3R5cGU6IGdyb3VwPy5hZG1pbl90eXBlPy5uYW1lLFxyXG4gICAgICAgICAgICAgIGNyZWF0ZWRBdDogZ3JvdXA/LmNyZWF0ZWRBdFxyXG4gICAgICAgICAgICAgICAgPy5zcGxpdChcIlRcIilbMF1cclxuICAgICAgICAgICAgICAgIC5zcGxpdChcIi1cIilcclxuICAgICAgICAgICAgICAgIC5yZXZlcnNlKClcclxuICAgICAgICAgICAgICAgIC5qb2luKFwiLVwiKSxcclxuICAgICAgICAgICAgICByZWNlaXB0X25vOiBncm91cD8ucmVjZWlwdF9ubyxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXRNb2JpbGVBcHBTdW1tYXJ5KG1vYkFwcExvZ3NSZXM/LmRhdGE/LnN1bW1hcnkgfHwge30pO1xyXG5cclxuICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhTW9iaWxlRGF0YSA9IG1vYkFwcExvZ3NSZXM/LmRhdGE/LmRhdGE/Lm1hcChcclxuICAgICAgICAgIChncm91cCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgLy8gaWYgKCFncm91cC5faWQgfHwgIWdyb3VwLnVzZXJfaWQpIHJldHVybiB7fTtcclxuICAgICAgICAgICAgaWYgKCFncm91cC5faWQpIHJldHVybiBudWxsO1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgIF9pZDogZ3JvdXA/Ll9pZCxcclxuICAgICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICAgIG5hbWU6IGdyb3VwPy51c2VyX2lkPy5mdWxsX25hbWUsXHJcbiAgICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBncm91cD8udXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IGdyb3VwPy5waG9uZSxcclxuICAgICAgICAgICAgICByZWFzb246IGdyb3VwPy5yZWFzb24sXHJcbiAgICAgICAgICAgICAgc3RhdHVzOiBncm91cD8uc3RhdHVzLFxyXG4gICAgICAgICAgICAgIGNyZWF0ZWRBdDogZ3JvdXA/LmNyZWF0ZWRBdFxyXG4gICAgICAgICAgICAgICAgPy5zcGxpdChcIlRcIilbMF1cclxuICAgICAgICAgICAgICAgIC5zcGxpdChcIi1cIilcclxuICAgICAgICAgICAgICAgIC5yZXZlcnNlKClcclxuICAgICAgICAgICAgICAgIC5qb2luKFwiLVwiKSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgKTtcclxuICAgICAgICBjb25zdCBmb3JtYXR0ZWRVbnZlcmlmaWVkQ3VzdG9tZXJzID1cclxuICAgICAgICAgIHVudmVyaWZpZWRDdXN0b21lcnNSZXM/LmRhdGFcclxuICAgICAgICAgICAgPy5maWx0ZXIoXHJcbiAgICAgICAgICAgICAgKGN1c3RvbWVyKSA9PiBjdXN0b21lcj8uc3RhdHVzID09PSBcIk5vdCBDb250YWN0ZWRcIlxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgICAgID8ubWFwKChjdXN0b21lciwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgICBuYW1lOiBjdXN0b21lcj8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgICAgIHBob25lX251bWJlcjogY3VzdG9tZXI/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgICBjcmVhdGVkQXQ6IGN1c3RvbWVyPy5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICAgICAgICBhZGRyZXNzOiBjdXN0b21lcj8uYWRkcmVzcyxcclxuICAgICAgICAgICAgICAvLyBwaW5jb2RlOiBjdXN0b21lcj8ucGluY29kZSxcclxuICAgICAgICAgICAgICBzdGF0dXM6IGN1c3RvbWVyPy5zdGF0dXMsXHJcbiAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IGN1c3RvbWVyPy5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgfSkpIHx8IFtdO1xyXG5cclxuICAgICAgICBzZXRUYWJsZURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgcmVjZW50UGF5b3V0czogQXJyYXkuaXNBcnJheShmb3JtYXR0ZWREYXRhKSA/IGZvcm1hdHRlZERhdGEgOiBbXSxcclxuICAgICAgICAgIHJlY2VudE1vYmlsZUFwcExvZ3M6IEFycmF5LmlzQXJyYXkoZm9ybWF0dGVkRGF0YU1vYmlsZURhdGEpXHJcbiAgICAgICAgICAgID8gZm9ybWF0dGVkRGF0YU1vYmlsZURhdGFcclxuICAgICAgICAgICAgOiBbXSxcclxuICAgICAgICAgIHVudmVyaWZpZWRDdXN0b21lcnM6IGZvcm1hdHRlZFVudmVyaWZpZWRDdXN0b21lcnMsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbnJvbGxtZW50czpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldFRhYmxlRGF0YSh7XHJcbiAgICAgICAgICB0YWJsZVRyYW5zYWN0aW9uczogW10sXHJcbiAgICAgICAgICB5ZXN0ZXJkYXlFbnJvbGxtZW50czogW10sXHJcbiAgICAgICAgICByZWNlbnRQYXlvdXRzOiBbXSxcclxuICAgICAgICAgIHJlY2VudE1vYmlsZUFwcExvZ3M6IFtdLFxyXG4gICAgICAgICAgdW52ZXJpZmllZEN1c3RvbWVyczogW10sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0UGF5b3V0c0xvYWRpbmcoZmFsc2UpOyAvLyBhbHdheXMgc3RvcCBsb2FkZXJcclxuICAgICAgICBzZXRNb2JpbGVBcHBMb2dzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaFBheW91dHMoKTtcclxuICB9LCBbcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICBhc3luYyBmdW5jdGlvbiBnZXRUcmFuc2FjdGlvbnMoKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRUcmFuc2FjdGlvbnNMb2FkaW5nKHRydWUpO1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvY2FzaGZyZWUtcGctb3JkZXJzLzEwXCIpO1xyXG4gICAgICBjb25zdCB0cmFuc2FjdGlvbnNEYXRhID0gcmVzcG9uc2UuZGF0YT8uZGF0YTtcclxuICAgICAgY29uc3QgZmlsdGVyZWREYXRhID0gdHJhbnNhY3Rpb25zRGF0YS5tYXAoKG9yZGVyLCBpbmRleCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHN0YXR1cyA9IG9yZGVyPy5zdGF0dXM7XHJcbiAgICAgICAgY29uc3QgY29sb3IgPVxyXG4gICAgICAgICAgc3RhdHVzID09PSBcIkFDVElWRVwiID8gXCJibHVlXCIgOiBzdGF0dXMgPT09IFwiUEFJRFwiID8gXCJncmVlblwiIDogXCJyZWRcIjtcclxuICAgICAgICBjb25zdCBpY29uID1cclxuICAgICAgICAgIHN0YXR1cyA9PT0gXCJBQ1RJVkVcIiA/IChcclxuICAgICAgICAgICAgPENsb2NrQ2lyY2xlT3V0bGluZWQgLz5cclxuICAgICAgICAgICkgOiBzdGF0dXMgPT09IFwiUEFJRFwiID8gKFxyXG4gICAgICAgICAgICA8Q2hlY2tDaXJjbGVPdXRsaW5lZCAvPlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPENsb3NlQ2lyY2xlT3V0bGluZWQgLz5cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgY29uc3QgZ3JvdXBzID0gb3JkZXI/Lmdyb3VwcztcclxuICAgICAgICBjb25zdCBwaWdteXMgPSBvcmRlci5waWdteXM7XHJcbiAgICAgICAgY29uc3QgbG9hbnMgPSBvcmRlcj8ubG9hbnM7XHJcbiAgICAgICAgY29uc3QgZ3JvdXBzU3RyaW5nID0gKFxyXG4gICAgICAgICAgZ3JvdXBzPy5tYXAoXHJcbiAgICAgICAgICAgIChncm91cCkgPT4gYCR7Z3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9uYW1lfSB8ICR7Z3JvdXA/LnRpY2tldH1gLFxyXG4gICAgICAgICAgKSB8fCBbXVxyXG4gICAgICAgICkuam9pbihcIiB8IFwiKTtcclxuICAgICAgICBjb25zdCBwaWdteXNTdHJpbmcgPSAoXHJcbiAgICAgICAgICBwaWdteXM/Lm1hcChcclxuICAgICAgICAgICAgKHBpZ215KSA9PiBgJHtwaWdteT8ucGF5YWJsZV9hbW91bnR9IHwgJHtwaWdteT8ucGlnbWVfaWR9YCxcclxuICAgICAgICAgICkgfHwgW11cclxuICAgICAgICApLmpvaW4oXCIgfCBcIik7XHJcbiAgICAgICAgY29uc3QgbG9hbnNTdHJpbmcgPSAoXHJcbiAgICAgICAgICBsb2Fucz8ubWFwKChsb2FuKSA9PiBgJHtsb2FuPy5sb2FuX2Ftb3VudH0gfCAke2xvYW4/LmxvYW5faWR9YCkgfHwgW11cclxuICAgICAgICApLmpvaW4oXCIgfCBcIik7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICBvcmRlclR5cGU6IG9yZGVyPy5vcmRlcl90eXBlLFxyXG4gICAgICAgICAgdXNlcl9uYW1lOiBvcmRlcj8udXNlcl9pZD8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgcGhvbmVfbnVtYmVyOiBvcmRlcj8udXNlcl9pZD8ucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgICAgZ3JvdXBzOiAoXHJcbiAgICAgICAgICAgIGdyb3Vwcz8ubWFwKFxyXG4gICAgICAgICAgICAgIChncm91cCkgPT4gYCR7Z3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9uYW1lfSB8ICR7Z3JvdXA/LnRpY2tldH1gLFxyXG4gICAgICAgICAgICApIHx8IFtdXHJcbiAgICAgICAgICApLmpvaW4oXCIgfCBcIiksXHJcbiAgICAgICAgICBwaWdteXM6IChcclxuICAgICAgICAgICAgcGlnbXlzPy5tYXAoXHJcbiAgICAgICAgICAgICAgKHBpZ215KSA9PiBgJHtwaWdteT8ucGF5YWJsZV9hbW91bnR9IHwgJHtwaWdteT8ucGlnbWVfaWR9YCxcclxuICAgICAgICAgICAgKSB8fCBbXVxyXG4gICAgICAgICAgKS5qb2luKFwiIHwgXCIpLFxyXG4gICAgICAgICAgbG9hbnM6IChcclxuICAgICAgICAgICAgbG9hbnM/Lm1hcCgobG9hbikgPT4gYCR7bG9hbj8ubG9hbl9hbW91bnR9IHwgJHtsb2FuPy5sb2FuX2lkfWApIHx8XHJcbiAgICAgICAgICAgIFtdXHJcbiAgICAgICAgICApLmpvaW4oXCIgfCBcIiksXHJcbiAgICAgICAgICBvdGhlcnM6IGdyb3Vwc1N0cmluZyArIHBpZ215c1N0cmluZyArIGxvYW5zU3RyaW5nLFxyXG4gICAgICAgICAgc3RhdHVzOiAoXHJcbiAgICAgICAgICAgIDxUYWcga2V5PXtcInN1Y2Nlc3NcIn0gY29sb3I9e2NvbG9yfSBpY29uPXtpY29ufSB2YXJpYW50PXtcImZpbGxlZFwifT5cclxuICAgICAgICAgICAgICB7c3RhdHVzfVxyXG4gICAgICAgICAgICA8L1RhZz5cclxuICAgICAgICAgICksXHJcbiAgICAgICAgICBhbW91bnQ6IG9yZGVyPy5hbW91bnQsXHJcbiAgICAgICAgICBwdXJwb3NlOiBvcmRlcj8ucHVycG9zZSxcclxuICAgICAgICAgIGxpbmtfdXJsOiBvcmRlcj8ubGlua191cmwsXHJcbiAgICAgICAgICBzdGF0dXNSYXc6IHN0YXR1cyxcclxuICAgICAgICAgIGNvbGxlY3RlZEJ5OiBvcmRlcj8uY29sbGVjdGVkX2J5LFxyXG4gICAgICAgICAgY3JlYXRlZEF0OiBvcmRlcj8uY3JlYXRlZEF0XHJcbiAgICAgICAgICAgID8uc3BsaXQoXCJUXCIpWzBdXHJcbiAgICAgICAgICAgIC5zcGxpdChcIi1cIilcclxuICAgICAgICAgICAgLnJldmVyc2UoKVxyXG4gICAgICAgICAgICAuam9pbihcIi1cIiksXHJcbiAgICAgICAgfTtcclxuICAgICAgfSk7XHJcbiAgICAgIC8vIHNldFRhYmxlVHJhbnNhY3Rpb25zKGZpbHRlcmVkRGF0YSk7XHJcbiAgICAgIHNldFRhYmxlRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIHRhYmxlVHJhbnNhY3Rpb25zOiBmaWx0ZXJlZERhdGEsXHJcbiAgICAgICAgeWVzdGVyZGF5RW5yb2xsbWVudHM6IHByZXYueWVzdGVyZGF5RW5yb2xsbWVudHMsXHJcbiAgICAgIH0pKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIC8vIHNldFRhYmxlVHJhbnNhY3Rpb25zKFtdKTtcclxuICAgICAgc2V0VGFibGVEYXRhKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB0YWJsZVRyYW5zYWN0aW9uczogW10gfSkpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0VHJhbnNhY3Rpb25zTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZ2V0VHJhbnNhY3Rpb25zKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBjYXJkRGF0YSA9IFtcclxuICAgIHtcclxuICAgICAgLy8gLS0tIEFkZGVkIEJyYW5jaCBUYXJnZXQgQ2FyZCAtLS1cclxuICAgICAgaWNvbjogQnVpbGRpbmcyLFxyXG4gICAgICB0aXRsZTogXCJQcmltYXJ5IEJyYW5jaCBUYXJnZXRcIixcclxuICAgICAgdmFsdWU6IGDigrkgJHsodGFyZ2V0VmFsdWUgPz8gMCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gLFxyXG4gICAgICBzdWJ0aXRsZTogXCJDdXJyZW50IGJyYW5jaCB0YXJnZXQgZ29hbFwiLFxyXG4gICAgICBjb2xvcjogXCJmcm9tLWdyYXktNTAwIHRvLWdyYXktNjAwXCIsXHJcbiAgICAgIGljb25CZzogXCJiZy1ncmF5LTEwMFwiLFxyXG4gICAgICBpY29uQ29sb3I6IFwidGV4dC1ncmF5LTYwMFwiLFxyXG4gICAgICBib3JkZXJDb2xvcjogXCJib3JkZXItZ3JheS02MDBcIixcclxuICAgICAgcmluZ0NvbG9yOiBcInJpbmctZ3JheS01MDAvMjBcIixcclxuICAgICAgcmVkaXJlY3Q6IFwiL3N0YWZmLW1lbnUvZW1wbG95ZWUtbWVudVwiLFxyXG4gICAgICBrZXk6IFwiMFwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgLy8gLS0tIEFkZGVkIEJyYW5jaCBUYXJnZXQgQ2FyZCAtLS1cclxuICAgICAgaWNvbjogR2l0QnJhbmNoLFxyXG4gICAgICB0aXRsZTogXCJTZWNvbmRhcnkgVGFyZ2V0XCIsXHJcbiAgICAgIHZhbHVlOiBg4oK5ICR7KHNlY29uZGFyeVRhcmdldFZhbHVlID8/IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgICAgc3VidGl0bGU6IFwiU2Vjb25kYXJ5IGJyYW5jaCB0YXJnZXQgZ29hbFwiLFxyXG4gICAgICBjb2xvcjogXCJmcm9tLWdyYXktNTAwIHRvLWdyYXktNjAwXCIsXHJcbiAgICAgIGljb25CZzogXCJiZy1ncmF5LTEwMFwiLFxyXG4gICAgICBpY29uQ29sb3I6IFwidGV4dC1ncmF5LTYwMFwiLFxyXG4gICAgICBib3JkZXJDb2xvcjogXCJib3JkZXItZ3JheS02MDBcIixcclxuICAgICAgcmluZ0NvbG9yOiBcInJpbmctZ3JheS01MDAvMjBcIixcclxuICAgICAgcmVkaXJlY3Q6IFwiL3N0YWZmLW1lbnUvZW1wbG95ZWUtbWVudVwiLFxyXG4gICAgICBrZXk6IFwiMFwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWNvbjogTGF5ZXJzMyxcclxuICAgICAgdGl0bGU6IFwiQ2hpdCBHcm91cHNcIixcclxuICAgICAgdmFsdWU6IGdyb3Vwcy5sZW5ndGgsXHJcbiAgICAgIHN1YnRpdGxlOiBcIkFjdGl2ZSBidXNpbmVzcyB1bml0c1wiLFxyXG4gICAgICBjb2xvcjogXCJmcm9tLWluZGlnby01MDAgdG8taW5kaWdvLTYwMFwiLFxyXG4gICAgICBpY29uQmc6IFwiYmctaW5kaWdvLTEwMFwiLFxyXG4gICAgICBpY29uQ29sb3I6IFwidGV4dC1pbmRpZ28tNjAwXCIsXHJcbiAgICAgIGJvcmRlckNvbG9yOiBcImJvcmRlci1pbmRpZ28tNjAwXCIsXHJcbiAgICAgIHJpbmdDb2xvcjogXCJyaW5nLWluZGlnby01MDAvMjBcIixcclxuICAgICAgcmVkaXJlY3Q6IFwiL2dyb3VwXCIsXHJcbiAgICAgIGtleTogXCIxXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpY29uOiBVc2Vyc1JvdW5kLFxyXG4gICAgICB0aXRsZTogXCJDdXN0b21lcnNcIixcclxuICAgICAgdmFsdWU6IHVzZXJzLmxlbmd0aCxcclxuICAgICAgc3VidGl0bGU6IFwiVG90YWwgcmVnaXN0ZXJlZCB1c2Vyc1wiLFxyXG4gICAgICBjb2xvcjogXCJmcm9tLWFtYmVyLTUwMCB0by1hbWJlci02MDBcIixcclxuICAgICAgaWNvbkJnOiBcImJnLWFtYmVyLTEwMFwiLFxyXG4gICAgICBpY29uQ29sb3I6IFwidGV4dC1hbWJlci02MDBcIixcclxuICAgICAgYm9yZGVyQ29sb3I6IFwiYm9yZGVyLWFtYmVyLTYwMFwiLFxyXG4gICAgICByaW5nQ29sb3I6IFwicmluZy1hbWJlci01MDAvMjBcIixcclxuICAgICAgcmVkaXJlY3Q6IFwiL3VzZXJcIixcclxuICAgICAga2V5OiBcIjJcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGljb246IENsaXBib2FyZExpc3QsXHJcbiAgICAgIHRpdGxlOiBcIlRvdGFsIEVucm9sbG1lbnRzXCIsXHJcbiAgICAgIHZhbHVlOiBlbnJvbGxtZW50c0NvdW50LnRvTG9jYWxlU3RyaW5nKCksXHJcbiAgICAgIHN1YnRpdGxlOiBcIkFjdGl2ZSBlbnJvbGxtZW50cyB0aGlzIHBlcmlvZFwiLFxyXG4gICAgICBjb2xvcjogXCJmcm9tLXRlYWwtNTAwIHRvLXRlYWwtNjAwXCIsXHJcbiAgICAgIGljb25CZzogXCJiZy10ZWFsLTEwMFwiLFxyXG4gICAgICBpY29uQ29sb3I6IFwidGV4dC10ZWFsLTYwMFwiLFxyXG4gICAgICBib3JkZXJDb2xvcjogXCJib3JkZXItdGVhbC02MDBcIixcclxuICAgICAgcmluZ0NvbG9yOiBcInJpbmctdGVhbC01MDAvMjBcIixcclxuICAgICAgcmVkaXJlY3Q6IFwiL2Vucm9sbG1lbnRcIixcclxuICAgICAga2V5OiBcIjhcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGljb246IFVzZXJSb3VuZENoZWNrLFxyXG4gICAgICB0aXRsZTogXCJBZ2VudHNcIixcclxuICAgICAgdmFsdWU6IGFnZW50cy5sZW5ndGgsXHJcbiAgICAgIHN1YnRpdGxlOiBcIkZpZWxkIHJlcHJlc2VudGF0aXZlc1wiLFxyXG4gICAgICBjb2xvcjogXCJmcm9tLXB1cnBsZS01MDAgdG8tcHVycGxlLTYwMFwiLFxyXG4gICAgICBpY29uQmc6IFwiYmctcHVycGxlLTEwMFwiLFxyXG4gICAgICBpY29uQ29sb3I6IFwidGV4dC1wdXJwbGUtNjAwXCIsXHJcbiAgICAgIGJvcmRlckNvbG9yOiBcImJvcmRlci1wdXJwbGUtNjAwXCIsXHJcbiAgICAgIHJpbmdDb2xvcjogXCJyaW5nLXB1cnBsZS01MDAvMjBcIixcclxuICAgICAgcmVkaXJlY3Q6IFwiL3N0YWZmLW1lbnUvYWdlbnQtbWVudVwiLFxyXG4gICAgICBrZXk6IFwiM1wiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWNvbjogQmFkZ2VDaGVjayxcclxuICAgICAgdGl0bGU6IFwiU3RhZmZcIixcclxuICAgICAgdmFsdWU6IHN0YWZmcy5sZW5ndGgsXHJcbiAgICAgIHN1YnRpdGxlOiBcIlZlcmlmaWVkIGNvbGxlY3Rpb24gc3RhZmZcIixcclxuICAgICAgaWNvbkJnOiBcImJnLXZpb2xldC01MFwiLFxyXG4gICAgICBpY29uQ29sb3I6IFwidGV4dC12aW9sZXQtNzAwXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpY29uOiBCcmllZmNhc2VCdXNpbmVzcyxcclxuICAgICAgdGl0bGU6IFwiRW1wbG95ZWVzXCIsXHJcbiAgICAgIHZhbHVlOiBlbXBsb3llZXMubGVuZ3RoLFxyXG4gICAgICBzdWJ0aXRsZTogXCJPcmdhbml6YXRpb24gd29ya2ZvcmNlXCIsXHJcbiAgICAgIGNvbG9yOiBcImZyb20tb3JhbmdlLTUwMCB0by1vcmFuZ2UtNjAwXCIsXHJcbiAgICAgIGljb25CZzogXCJiZy1vcmFuZ2UtMTAwXCIsXHJcbiAgICAgIGljb25Db2xvcjogXCJ0ZXh0LW9yYW5nZS02MDBcIixcclxuICAgICAgYm9yZGVyQ29sb3I6IFwiYm9yZGVyLW9yYW5nZS02MDBcIixcclxuICAgICAgcmluZ0NvbG9yOiBcInJpbmctb3JhbmdlLTUwMC8yMFwiLFxyXG4gICAgICByZWRpcmVjdDogXCIvc3RhZmYtbWVudS9lbXBsb3llZS1tZW51XCIsXHJcbiAgICAgIGtleTogXCI1XCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpY29uOiBXYWxsZXQsXHJcbiAgICAgIHRpdGxlOiBcIlRvdGFsIFJldmVudWVcIixcclxuICAgICAgdmFsdWU6IGAke2dldE1hc2tlZFZhbHVlKHBheW1lbnRzVmFsdWUpfWAsXHJcbiAgICAgIHN1YnRpdGxlOiBcIkFsbC10aW1lIGVhcm5pbmdzXCIsXHJcbiAgICAgIGNvbG9yOiBcImZyb20tZW1lcmFsZC01MDAgdG8tZW1lcmFsZC02MDBcIixcclxuICAgICAgaWNvbkJnOiBcImJnLWVtZXJhbGQtMTAwXCIsXHJcbiAgICAgIGljb25Db2xvcjogXCJ0ZXh0LWVtZXJhbGQtNjAwXCIsXHJcbiAgICAgIGJvcmRlckNvbG9yOiBcImJvcmRlci1lbWVyYWxkLTYwMFwiLFxyXG4gICAgICByaW5nQ29sb3I6IFwicmluZy1lbWVyYWxkLTUwMC8yMFwiLFxyXG4gICAgICByZWRpcmVjdDogXCIvdG90YWwtcmV2ZW51ZVwiLFxyXG4gICAgICBrZXk6IFwiNlwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWNvbjogQ2FsZW5kYXJEYXlzLFxyXG4gICAgICB0aXRsZTogXCJNb250aGx5IFJldmVudWVcIixcclxuICAgICAgdmFsdWU6IGAke2dldE1hc2tlZFZhbHVlKHBheW1lbnRzUGVyTW9udGhWYWx1ZSl9YCxcclxuICAgICAgc3VidGl0bGU6IFwiQ3VycmVudCBiaWxsaW5nIGN5Y2xlXCIsXHJcbiAgICAgIGNvbG9yOiBcImZyb20tc2t5LTUwMCB0by1za3ktNjAwXCIsXHJcbiAgICAgIGljb25CZzogXCJiZy1za3ktMTAwXCIsXHJcbiAgICAgIGljb25Db2xvcjogXCJ0ZXh0LXNreS02MDBcIixcclxuICAgICAgYm9yZGVyQ29sb3I6IFwiYm9yZGVyLXNreS02MDBcIixcclxuICAgICAgcmluZ0NvbG9yOiBcInJpbmctc2t5LTUwMC8yMFwiLFxyXG4gICAgICByZWRpcmVjdDogXCIvbW9udGhseS1yZXZlbnVlXCIsXHJcbiAgICAgIGtleTogXCI3XCIsXHJcbiAgICB9LFxyXG4gIF0uZmlsdGVyKFxyXG4gICAgKGNhcmQpID0+XHJcbiAgICAgIGNhcmQudGl0bGUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hWYWx1ZS50b0xvd2VyQ2FzZSgpKSB8fFxyXG4gICAgICBjYXJkLnN1YnRpdGxlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVmFsdWUudG9Mb3dlckNhc2UoKSksXHJcbiAgKTtcclxuXHJcbiAgY29uc3QgbmV3c0l0ZW1zID0gW1xyXG4gICAge1xyXG4gICAgICB0ZXh0OiBcIk5ldyBjaGl0IGZ1bmQgc2NoZW1lIGxhdW5jaGVkIHdpdGggMTAlIGhpZ2hlciByZXR1cm5zISBOZXcgY2hpdCBmdW5kIHNjaGVtZSBsYXVuY2hlZCB3aXRoIDEwJSBoaWdoZXIgcmV0dXJucyEgTmV3IGNoaXQgZnVuZCBzY2hlbWUgbGF1bmNoZWQgd2l0aCAxMCUgaGlnaGVyIHJldHVybnMhXCIsXHJcbiAgICAgIGljb246IFBlcmNlbnQsXHJcbiAgICAgIGljb25DbGFzczogXCJ0ZXh0LWFtYmVyLTYwMFwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdGV4dDogXCJCYW5nbG9yZSBicmFuY2ggb3BlbnMgZm9yIENoaXQgUGxhbnMgZW5yb2xsbWVudC5cIixcclxuICAgICAgaWNvbjogQnVpbGRpbmcyLFxyXG4gICAgICBpY29uQ2xhc3M6IFwidGV4dC1ibHVlLTYwMFwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdGV4dDogXCJNb250aGx5IGNoaXQgY29sbGVjdGlvbiBkdWUgZGF0ZSByZW1pbmRlciBmb3Igc3Vic2NyaWJlcnMuXCIsXHJcbiAgICAgIGljb246IEluZGlhblJ1cGVlLFxyXG4gICAgICBpY29uQ2xhc3M6IFwidGV4dC1lbWVyYWxkLTYwMFwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdGV4dDogXCJDdXN0b21lciBmZWVkYmFjayByZXF1ZXN0ZWQgZm9yIGJldHRlciBjaGl0IG1hbmFnZW1lbnQuXCIsXHJcbiAgICAgIGljb246IFVzZXJzUm91bmQsXHJcbiAgICAgIGljb25DbGFzczogXCJ0ZXh0LXZpb2xldC02MDBcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRleHQ6IFwiU3BlY2lhbCBib251cyBjaGl0IGRyYXcgaGFwcGVuaW5nIHRoaXMgd2Vla2VuZCFcIixcclxuICAgICAgaWNvbjogTWVzc2FnZVNxdWFyZVRleHQsXHJcbiAgICAgIGljb25DbGFzczogXCJ0ZXh0LXBpbmstNjAwXCIsXHJcbiAgICB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNvcHlMaW5rID0gKHVybCkgPT4ge1xyXG4gICAgaWYgKCF1cmwpIHtcclxuICAgICAgbWVzc2FnZS53YXJuaW5nKFwiTm8gcGF5bWVudCBsaW5rIGZvdW5kIGZvciB0aGlzIHRyYW5zYWN0aW9uXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dCh1cmwpO1xyXG4gICAgbWVzc2FnZS5zdWNjZXNzKFwiUGF5bWVudCBsaW5rIGNvcGllZCB0byBjbGlwYm9hcmQhXCIpO1xyXG4gIH07XHJcbiAgY29uc3QgR1JJRF9MQVlPVVQgPSBcImdyaWQtY29scy1bNTBweF8xMTBweF8xLjVmcl8yZnJfMTAwcHhfMTIwcHhfMTAwcHhdXCI7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggcHQtWzY4cHhdIGJnLXNsYXRlLTUwIHRleHQtc2xhdGUtOTAwXCI+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICA8Q2xvc2luZ0dyb3Vwc01vZGFsIC8+XHJcbiAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbiAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+XHJcbiAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuICAgICAgICAgIH1cclxuICAgICAgICAvPlxyXG5cclxuICAgICAgICA8bWFpbiBjbGFzc05hbWU9XCJ3LWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIHB4LTMgcHktNCBzbTpweC01IGxnOnB4LTdcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNSBmbGV4IGZsZXgtY29sIGdhcC0zIHJvdW5kZWQtM3hsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzcwIGJnLXdoaXRlLzgwIHB4LTUgcHktNCBzaGFkb3ctc20gc2hhZG93LXNsYXRlLTkwMC9bMC4wM10gYmFja2Ryb3AtYmx1ci14bCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIgc206anVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1zbGF0ZS05NTAgc206dGV4dC0zeGxcIj5cclxuICAgICAgICAgICAgICAgIEludGVsbGlnZW5jZSBEYXNoYm9hcmRcclxuICAgICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXNsYXRlLTUwMFwiPkEgbGl2ZSBvdmVydmlldyBvZiBicmFuY2ggdGFyZ2V0cywgY3VzdG9tZXJzLCBlbnJvbGxtZW50cywgcmV2ZW51ZSwgYW5kIHRlYW0gYWN0aXZpdHkuPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBJbmZvIEljb24gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZ3JvdXBcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGgtOCB3LTggY3Vyc29yLXBvaW50ZXIgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBiZy13aGl0ZS83MCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LVsjMDA3MWUzXSBzaGFkb3ctc20gc2hhZG93LXNsYXRlLTkwMC9bMC4wM10gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIGhvdmVyOmJnLXdoaXRlIGhvdmVyOnRleHQtc2xhdGUtOTUwXCI+XHJcbiAgICAgICAgICAgICAgICBpXHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICB7LyogVG9vbHRpcCAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC1mdWxsIG10LTMgbGVmdC0xLzIgLXRyYW5zbGF0ZS14LTEvMiBtYi0zIHctNzIgcC0zIGJnLWdyYXktOTAwIHRleHQtd2hpdGUgdGV4dC14cyBsZWFkaW5nLXJlbGF4ZWQgcm91bmRlZC1sZyBzaGFkb3cteGwgb3BhY2l0eS0wIGludmlzaWJsZSBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCBncm91cC1ob3Zlcjp2aXNpYmxlIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBwb2ludGVyLWV2ZW50cy1ub25lIHotWzk5OTldXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIERhc2hib2FyZCBvdmVydmlld1xyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFJlYWwtdGltZSBhbmFseXRpY3MgYW5kIHBlcmZvcm1hbmNlIG1ldHJpY3MgZm9yIHlvdXIgb3JnYW5pemF0aW9uLlxyXG4gICAgICAgICAgICAgICAgICBNb25pdG9yIGtleSBidXNpbmVzcyBpbmRpY2F0b3JzIGFuZCBtYWtlIGRhdGEtZHJpdmVuIGRlY2lzaW9ucy5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBUb29sdGlwIEFycm93ICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtZnVsbCBsZWZ0LTEvMiAtdHJhbnNsYXRlLXgtMS8yIGJvcmRlci1sLTQgYm9yZGVyLXItNCBib3JkZXItdC00IGJvcmRlci1sLXRyYW5zcGFyZW50IGJvcmRlci1yLXRyYW5zcGFyZW50IGJvcmRlci10LWdyYXktOTAwXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTUgaC05IG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC83MCBiZy13aGl0ZS83MCBzaGFkb3ctc20gc2hhZG93LXNsYXRlLTkwMC9bMC4wM10gYmFja2Ryb3AtYmx1ci14bFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRhc2hib2FyZC1uZXdzLW1hcnF1ZWUgZmxleCBoLWZ1bGwgdy1tYXggaXRlbXMtY2VudGVyIHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcbiAgICAgICAgICAgICAge25ld3NJdGVtcy5jb25jYXQobmV3c0l0ZW1zKS5tYXAoKGl0ZW0sIGlkeCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgSWNvbiA9IGl0ZW0uaWNvbjtcclxuXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAga2V5PXtgJHtpdGVtLnRleHR9LSR7aWR4fWB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBoLWZ1bGwgaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTYwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCBob3ZlcjpiZy13aGl0ZS84MFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9e2BoLTQgdy00IHNocmluay0wICR7aXRlbS5pY29uQ2xhc3N9YH0gc3Ryb2tlV2lkdGg9ezEuOH0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57aXRlbS50ZXh0fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxzdHlsZT57YFxyXG4gICAgICAgICAgICBAa2V5ZnJhbWVzIGRhc2hib2FyZC1uZXdzLXNjcm9sbCB7XHJcbiAgICAgICAgICAgICAgMCUge1xyXG4gICAgICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKDApO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAxMDAlIHtcclxuICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5kYXNoYm9hcmQtbmV3cy1tYXJxdWVlIHtcclxuICAgICAgICAgICAgICBhbmltYXRpb246IGRhc2hib2FyZC1uZXdzLXNjcm9sbCAzMHMgbGluZWFyIGluZmluaXRlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICBgfTwvc3R5bGU+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYi04XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAtMyBzbTpncmlkLWNvbHMtMiB4bDpncmlkLWNvbHMtNFwiPlxyXG4gICAgICAgICAgICAgIHtjYXJkRGF0YS5tYXAoKGNhcmQpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IENhcmRFbGVtZW50ID0gY2FyZC5yZWRpcmVjdCA/IFwiYnV0dG9uXCIgOiBcImRpdlwiO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgIDxDYXJkRWxlbWVudFxyXG4gICAgICAgICAgICAgICAgICB7Li4uKGNhcmQucmVkaXJlY3QgPyB7XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJidXR0b25cIixcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrOiAoKSA9PiBoYW5kbGVWaWV3RGV0YWlsc0NsaWNrKGNhcmQucmVkaXJlY3QpLFxyXG4gICAgICAgICAgICAgICAgICAgIFwiYXJpYS1sYWJlbFwiOiBgJHtjYXJkLnRpdGxlfTogJHtjYXJkLnZhbHVlfS4gJHtjYXJkLnN1YnRpdGxlfWAsXHJcbiAgICAgICAgICAgICAgICAgIH0gOiB7fSl9XHJcbiAgICAgICAgICAgICAgICAgIGtleT17Y2FyZC50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZ3JvdXAgZmxleCBtaW4taC1bMTEycHhdIHctZnVsbCBtaW4tdy0wIGl0ZW1zLWNlbnRlciBnYXAtMyByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC83MCBiZy13aGl0ZS84MCBwLTMgdGV4dC1sZWZ0IHNoYWRvdy1zbSBzaGFkb3ctc2xhdGUtOTAwL1swLjAzXSBiYWNrZHJvcC1ibHVyLXhsIHNtOnAtNCAke2NhcmQucmVkaXJlY3QgPyBcImN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwIGhvdmVyOi10cmFuc2xhdGUteS0wLjUgaG92ZXI6Ymctd2hpdGUgaG92ZXI6c2hhZG93LW1kIGhvdmVyOnNoYWRvdy1zbGF0ZS05MDAvMTAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLVsjMDA3MWUzXS8yNVwiIDogXCJcIn1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BncmlkIGgtMTEgdy0xMSBzaHJpbmstMCBwbGFjZS1pdGVtcy1jZW50ZXIgcm91bmRlZC14bCBib3JkZXIgJHtjYXJkLmljb25CZ30gJHtjYXJkLmljb25Db2xvcn0gYm9yZGVyLWN1cnJlbnQvMTBgfT5cclxuICAgICAgICAgICAgICAgICAgICA8Y2FyZC5pY29uIGNsYXNzTmFtZT1cImgtNSB3LTVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgd2hpdGVzcGFjZS1ub3JtYWwgdGV4dC1zbSBmb250LW1lZGl1bSBsZWFkaW5nLXNudWcgdGV4dC1zbGF0ZS02MDBcIj57Y2FyZC50aXRsZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibXQtMSBibG9jayBicmVhay13b3JkcyB0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGFidWxhci1udW1zIHRyYWNraW5nLXRpZ2h0IHRleHQtc2xhdGUtOTUwXCI+e2NhcmQudmFsdWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm10LTEgYmxvY2sgd2hpdGVzcGFjZS1ub3JtYWwgdGV4dC14cyBsZWFkaW5nLXNudWcgdGV4dC1zbGF0ZS01MDBcIj57Y2FyZC5zdWJ0aXRsZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvQ2FyZEVsZW1lbnQ+XHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAge2NhcmREYXRhLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi1mdWxsIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB5LTEyIHB4LTYgcm91bmRlZC0yeGwgYmctd2hpdGUgc2hhZG93LWxnIG14LTQgbWQ6bXgtMFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTYgaC0xNiBteC1hdXRvXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjEuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBkPVwiTTIxIDIxbC02LTZtMi01YTcgNyAwIDExLTE0IDAgNyA3IDAgMDExNCAwelwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMiB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICBObyByZXN1bHRzIGZvdW5kXHJcbiAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCBtYXgtdy1tZCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICBXZSBjb3VsZG4mYXBvczt0IGZpbmQgYW55IG1hdGNoaW5nIHJlc3VsdHMgZm9ye1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPiZxdW90O3tzZWFyY2hWYWx1ZX0mcXVvdDs8L3NwYW4+LiBUcnlcclxuICAgICAgICAgICAgICAgICAgYWRqdXN0aW5nIHlvdXIgc2VhcmNoIHRlcm1zLlxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgPHNlY3Rpb24gaWQ9XCJkYXNoYm9hcmQtYW5hbHl0aWNzXCIgY2xhc3NOYW1lPVwibXQtNyByb3VuZGVkLTN4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC83MCBiZy13aGl0ZS82MCBwLTQgc2hhZG93LXNtIHNoYWRvdy1zbGF0ZS05MDAvWzAuMDNdIGJhY2tkcm9wLWJsdXIteGwgc206cC01XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi01IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAvNzAgcGItNFwiPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy1bMC4xNmVtXSB0ZXh0LXNsYXRlLTUwMFwiPlBlcmZvcm1hbmNlIGRldGFpbDwvcD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXNsYXRlLTYwMFwiPlRyZW5kcyBhbmQgb3BlcmF0aW9uYWwgYnJlYWtkb3duczwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8RGFzaGJvYXJkQW5hbHl0aWNzQ29udGVudCBlbWJlZGRlZCAvPlxyXG4gICAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgICAgIHsvKiBSRUNFTlQgVFJBTlNBQ1RJT05TIFNFQ1RJT04gKi99XHJcbiAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cIm10LTE2XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItOCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUmVjZW50IFRyYW5zYWN0aW9uc1xyXG4gICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5TaG93aW5nIHRoZSBsYXRlc3QgYWN0aXZpdGllczwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGJnLWdyYXktMjAwIHAtMSByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Vmlld01vZGUoXCJncmlkXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQtbWQgdHJhbnNpdGlvbi1hbGwgJHt2aWV3TW9kZSA9PT0gXCJncmlkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctd2hpdGUgc2hhZG93LXNtIHRleHQtdmlvbGV0LTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtZ3JheS01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8QnNHcmlkM1gzR2FwRmlsbCBzaXplPXsxOH0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3TW9kZShcImxpc3RcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTIgcm91bmRlZC1tZCB0cmFuc2l0aW9uLWFsbCAke3ZpZXdNb2RlID09PSBcImxpc3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy13aGl0ZSBzaGFkb3ctc20gdGV4dC12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1ncmF5LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxCc0xpc3RVbCBzaXplPXsxOH0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17Z2V0VHJhbnNhY3Rpb25zfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBweC00IHB5LTIgcm91bmRlZC1sZyB0ZXh0LXNtIGZvbnQtbWVkaXVtIGhvdmVyOmJnLWdyYXktNTBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUmVmcmVzaFxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7dHJhbnNhY3Rpb25zTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0yMCBiZy1ncmF5LTIwMCBhbmltYXRlLXB1bHNlIHJvdW5kZWQtbWRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMjAgYmctZ3JheS0yMDAgYW5pbWF0ZS1wdWxzZSByb3VuZGVkLW1kXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICAgICAgICAgICAgdmlld01vZGUgPT09IFwiZ3JpZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyB4bDpncmlkLWNvbHMtNCBnYXAtNlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiZmxleCBmbGV4LWNvbCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgb3ZlcmZsb3ctaGlkZGVuIGJnLXdoaXRlIHNoYWRvdy1zbVwiXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge3ZpZXdNb2RlID09PSBcImxpc3RcIiAmJiB0YWJsZVRyYW5zYWN0aW9ucy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLVs2MHB4XzE0MHB4XzFmcl8xLjVmcl8xMDBweF8xMDBweF8xMjBweF0gaXRlbXMtY2VudGVyIGJnLWdyYXktMTAwIHAtNCBib3JkZXItYiBib3JkZXItZ3JheS0yMDAgZm9udC1ib2xkIHRleHQtWzEwcHhdIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PklEPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtbGVmdFwiPlRyYW5zYWN0aW9uIERhdGU8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+Q3VzdG9tZXI8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+RGV0YWlsczwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5UeXBlPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlN0YXR1czwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+QWdlbnQ8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIHt0YWJsZVRyYW5zYWN0aW9ucy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIHRhYmxlVHJhbnNhY3Rpb25zLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFJlY2VpcHRcclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtPy5pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgey4uLml0ZW19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1cz17aXRlbT8uc3RhdHVzUmF3fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2aWV3TW9kZT17dmlld01vZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICkpXHJcbiAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIwIHRleHQtY2VudGVyIHRleHQtZ3JheS00MDAgaXRhbGljXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBObyB0cmFuc2FjdGlvbnMgZm91bmRcclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PiAqL31cclxuXHJcbiAgICAgICAgICAgIHsvKiBDbG9zaW5nIEdyb3VwcyBOZWVkaW5nIEF0dGVudGlvbiAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IGN1cnNvci1wb2ludGVyIGJvcmRlciBib3JkZXItb3JhbmdlLTMwMCBiZy1ncmFkaWVudC10by1yIGZyb20tb3JhbmdlLTUwIHRvLXJlZC01MCByb3VuZGVkLXhsIHNoYWRvdy1sZyBwLTNcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LW9yYW5nZS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIENsb3NpbmcgR3JvdXBzIE5lZWRpbmcgQXR0ZW50aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMyBweS0xIHJvdW5kZWQtZnVsbCBiZy1yZWQtMTAwIHRleHQtcmVkLTcwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgYW5pbWF0ZS1wdWxzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQWRtaW4gQWN0aW9uIFJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LW9yYW5nZS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBTb21lIGNoaXQgZ3JvdXBzIGFyZSA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtcmVkLTcwMFwiPmFwcHJvYWNoaW5nIHRoZWlyIGNsb3NpbmcgZGF0ZTwvc3Bhbj4uXHJcbiAgICAgICAgICAgICAgICAgICAgUGxlYXNlIHJldmlldyB0aGVtIGFuZCB0YWtlIHRoZSBuZWNlc3NhcnkgYWN0aW9ucyBiZWZvcmUgdGhlIGdyb3VwcyBhcmUgY2xvc2VkLlxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc09wZW5pbmcgPSAhb3BlblNlY3Rpb24uY2xvc2luZ0dyb3VwcztcclxuICAgICAgICAgICAgICAgICAgICAgIHNldE9wZW5TZWN0aW9uKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbG9zaW5nR3JvdXBzOiBpc09wZW5pbmcsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGlzT3BlbmluZyAmJiBjbG9zaW5nR3JvdXBzRGF0YS5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZmV0Y2hjbG9zaW5nR3JvdXBzRGF0YSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQtZnVsbCBob3ZlcjpiZy1vcmFuZ2UtMTAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1vcmFuZ2UtNjAwIHRleHQtM3hsIGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge29wZW5TZWN0aW9uLmNsb3NpbmdHcm91cHMgPyBcIuKIklwiIDogXCIrXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIHtjbG9zaW5nR3JvdXBzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtbLi4uQXJyYXkoNSldLm1hcCgoXywgaSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJoLTE2IGJnLWdyYXktMTAwIGFuaW1hdGUtcHVsc2Ugcm91bmRlZC14bFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGVhc2UtaW4tb3V0IG92ZXJmbG93LWhpZGRlbiAke29wZW5TZWN0aW9uLmNsb3NpbmdHcm91cHMgPyBcIm1heC1oLVsyMDAwcHhdIG9wYWNpdHktMTAwXCIgOiBcIm1heC1oLTAgb3BhY2l0eS0wXCJcclxuICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlci1jb2xsYXBzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctZ3JheS0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0zIHRleHQtbGVmdFwiPlNMPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0zIHRleHQtbGVmdFwiPkdyb3VwIE5hbWU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTMgdGV4dC1sZWZ0XCI+RW5kIERhdGU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTMgdGV4dC1sZWZ0XCI+RGF5cyBSZW1haW5pbmc8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTMgdGV4dC1sZWZ0XCI+TW9udGhzIFJlbWFpbmluZzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Y2xvc2luZ0dyb3Vwc0RhdGEubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbG9zaW5nR3JvdXBzRGF0YS5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtpdGVtLl9pZH0gY2xhc3NOYW1lPVwiYm9yZGVyLWIgaG92ZXI6YmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zXCI+e2luZGV4ICsgMX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIGZvbnQtbWVkaXVtXCI+e2l0ZW0uZ3JvdXBfbmFtZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKGl0ZW0uZW5kX2RhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRheTogXCIyLWRpZ2l0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb250aDogXCJzaG9ydFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeWVhcjogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTEgcm91bmRlZCBiZy1yZWQtMTAwIHRleHQtcmVkLTcwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmRheXNfcmVtYWluaW5nfSBkYXlzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zXCI+e2l0ZW0ubW9udGhzX3JlbWFpbmluZ30gbW9udGgocyk8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPVwiNVwiIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHAtNiB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vIGNsb3NpbmcgZ3JvdXBzIGZvdW5kXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTZcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgc2hhZG93LW1kIHAtNCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgey8qIExFRlQgU0lERSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwIGRhcms6dGV4dC1ncmF5LTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFJlY2VudCBUcmFuc2FjdGlvbnNcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgIHRvPVwiL3BheW1lbnQtbGluay10cmFuc2FjdGlvbnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWJsdWUtNTAwIGhvdmVyOnRleHQtYmx1ZS03MDAgaG92ZXI6dW5kZXJsaW5lIG1sLTRcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFZpZXcgQWxsXHJcbiAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgU2hvd2luZyB0aGUgbGF0ZXN0IGFjdGl2aXRpZXNcclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFJJR0hUIFNJREUgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiBHcmlkIC8gTGlzdCBUb2dnbGUgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBiZy1ncmF5LTIwMCBwLTEgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdNb2RlKFwiZ3JpZFwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMiByb3VuZGVkLW1kIHRyYW5zaXRpb24tYWxsICR7dmlld01vZGUgPT09IFwiZ3JpZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy13aGl0ZSBzaGFkb3ctc20gdGV4dC1ibHVlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LWdyYXktNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEJzR3JpZDNYM0dhcEZpbGwgc2l6ZT17MTh9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdNb2RlKFwibGlzdFwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMiByb3VuZGVkLW1kIHRyYW5zaXRpb24tYWxsICR7dmlld01vZGUgPT09IFwibGlzdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy13aGl0ZSBzaGFkb3ctc20gdGV4dC1ibHVlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LWdyYXktNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEJzTGlzdFVsIHNpemU9ezE4fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBSZWZyZXNoICovfVxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17Z2V0VHJhbnNhY3Rpb25zfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBweC00IHB5LTIgcm91bmRlZC1sZyB0ZXh0LXNtIGZvbnQtbWVkaXVtIGhvdmVyOmJnLWdyYXktNTAgZGFyazp0ZXh0LWdyYXktNTAwXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFJlZnJlc2hcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogQ29sbGFwc2UgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0T3BlblNlY3Rpb24oKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zYWN0aW9uczogIXByZXYudHJhbnNhY3Rpb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMlwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblVwXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LW9yYW5nZS01MDAgdGV4dC0zeGwgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwICR7b3BlblNlY3Rpb24udHJhbnNhY3Rpb25zID8gXCJyb3RhdGUtMTgwXCIgOiBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHt0cmFuc2FjdGlvbnNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTIwIGJnLWdyYXktMjAwIGFuaW1hdGUtcHVsc2Ugcm91bmRlZC1tZFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0yMCBiZy1ncmF5LTIwMCBhbmltYXRlLXB1bHNlIHJvdW5kZWQtbWRcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZWFzZS1pbi1vdXQgb3ZlcmZsb3ctaGlkZGVuIG10LTIgJHtvcGVuU2VjdGlvbi50cmFuc2FjdGlvbnNcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJtYXgtaC1bMjAwMHB4XSBvcGFjaXR5LTEwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwibWF4LWgtMCBvcGFjaXR5LTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2aWV3TW9kZSA9PT0gXCJncmlkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyB4bDpncmlkLWNvbHMtNCBnYXAtNlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImZsZXggZmxleC1jb2wgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIG92ZXJmbG93LWhpZGRlbiBiZy13aGl0ZSBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBIRUFERVIgU0VDVElPTiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIHt2aWV3TW9kZSA9PT0gXCJsaXN0XCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZ3JpZCAke0dSSURfTEFZT1VUfSBpdGVtcy1jZW50ZXIgYmctZ3JheS01MCBweC02IHB5LTQgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwIGZvbnQtYm9sZCB0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgZ2FwLTRgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5TTDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+RGF0ZTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+Q3VzdG9tZXI8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlB1cnBvc2UgJiBEZXRhaWxzPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5BbW91bnQ8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlN0YXR1czwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5BY3Rpb25zPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogQk9EWSBTRUNUSU9OICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAge3RhYmxlRGF0YT8udGFibGVUcmFuc2FjdGlvbnMubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGFibGVEYXRhPy50YWJsZVRyYW5zYWN0aW9ucz8ubWFwKChpdGVtLCBpbmRleCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3TW9kZSA9PT0gXCJsaXN0XCIgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZ3JpZCAke0dSSURfTEFZT1VUfSBpdGVtcy1jZW50ZXIgcHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1ncmF5LTUwIGhvdmVyOmJnLWdyYXktNTAvODAgdHJhbnNpdGlvbi1jb2xvcnMgZ2FwLTQgdGV4dC1zbWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCBmb250LW1vbm9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KGluZGV4ICsgMSkudG9TdHJpbmcoKS5wYWRTdGFydCgyLCBcIjBcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIGZvbnQtbWVkaXVtIHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uY3JlYXRlZEF0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ncmF5LTgwMCB0cnVuY2F0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udXNlcl9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFBVUlBPU0UgJiBERVRBSUxTICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ibHVlLTcwMCB0ZXh0LVsxMHB4XSBweC0yIHB5LTAuNSBiZy1ibHVlLTUwIHJvdW5kZWQtbWQgdy1maXQgbWItMSB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnB1cnBvc2UgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTUwMCBsaW5lLWNsYW1wLTEgaXRhbGljXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5vdGhlcnMgfHwgXCJObyBleHRyYSBkYXRhXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7aXRlbS5hbW91bnQ/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj57aXRlbS5zdGF0dXN9PC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQUNUSU9OUzogSWNvbnMgc3RheSB2aXNpYmxlIGV2ZW4gaWYgbGluayBpcyBtaXNzaW5nICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRvb2x0aXBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbT8ubGlua191cmxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiQ29weSBQYXltZW50IExpbmtcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJObyBsaW5rIGF2YWlsYWJsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUNvcHlMaW5rKGl0ZW0/LmxpbmtfdXJsKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMiByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsICR7aXRlbT8ubGlua191cmwgPyBcInRleHQtYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS0xMDBcIiA6IFwidGV4dC1ncmF5LTMwMFwifWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYUNvcHkgc2l6ZT17MTR9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1Rvb2x0aXA+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUb29sdGlwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ubGlua191cmxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiT3BlbiBMaW5rXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiTGluayBub3QgZm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpdGVtLmxpbmtfdXJsKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd2luZG93Lm9wZW4oaXRlbS5saW5rX3VybCwgXCJfYmxhbmtcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5pbmZvKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIkV4dGVybmFsIGxpbmsgaXMgbm90IGF2YWlsYWJsZSBmb3IgdGhpcyBlbnRyeVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgJHtpdGVtLmxpbmtfdXJsID8gXCJ0ZXh0LWdyYXktNTAwIGhvdmVyOmJnLWdyYXktMTAwXCIgOiBcInRleHQtZ3JheS0zMDBcIn1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFFeHRlcm5hbExpbmtBbHQgc2l6ZT17MTN9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1Rvb2x0aXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSZWNlaXB0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey4uLml0ZW19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1cz17aXRlbS5zdGF0dXNSYXd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdNb2RlPVwiZ3JpZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yMCB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNDAwIGl0YWxpYyBiZy13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIE5vIHRyYW5zYWN0aW9ucyBmb3VuZC5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BmbGV4LTEgYm9yZGVyIHJvdW5kZWQtbGcgc2hhZG93LW1kIHAtMSBtdC01IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCAke3RhYmxlRGF0YT8udW52ZXJpZmllZEN1c3RvbWVycz8ubGVuZ3RoID4gMFxyXG4gICAgICAgICAgICAgICAgPyBcImJvcmRlci1vcmFuZ2UtMzAwIHNoYWRvdy1vcmFuZ2UtMTAwIHJpbmctMSByaW5nLW9yYW5nZS0xMDBcIlxyXG4gICAgICAgICAgICAgICAgOiBcImJvcmRlci1ncmF5LTIwMFwiXHJcbiAgICAgICAgICAgICAgICB9YH0+XHJcbiAgICAgICAgICAgICAgICB7LyogTUFJTiBDQVJEICovfVxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBIRUFERVIgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwLTQgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3RhYmxlRGF0YT8udW52ZXJpZmllZEN1c3RvbWVycz8ubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBoLTMgdy0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5saW5lLWZsZXggaC1mdWxsIHctZnVsbCBhbmltYXRlLXBpbmcgcm91bmRlZC1mdWxsIGJnLW9yYW5nZS00MDAgb3BhY2l0eS03NVwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBpbmxpbmUtZmxleCBoLTMgdy0zIHJvdW5kZWQtZnVsbCBiZy1vcmFuZ2UtNTAwXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBVbnZlcmlmaWVkIEN1c3RvbWVyc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3RhYmxlRGF0YT8udW52ZXJpZmllZEN1c3RvbWVycz8ubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMi41IHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtb3JhbmdlLTcwMCBiZy1vcmFuZ2UtMTAwIGJvcmRlciBib3JkZXItb3JhbmdlLTIwMCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1wdWxzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3RhYmxlRGF0YS51bnZlcmlmaWVkQ3VzdG9tZXJzLmxlbmd0aH0gUGVuZGluZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdG89XCIvYXBwcm92YWwtbWVudS91bi1hcHByb3ZlZC1jdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWJsdWUtNTAwIGhvdmVyOnRleHQtYmx1ZS03MDAgaG92ZXI6dW5kZXJsaW5lIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgVmlldyBBbGxcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3RhYmxlRGF0YT8udW52ZXJpZmllZEN1c3RvbWVycz8ubGVuZ3RoID4gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJOZXcgY3VzdG9tZXIgdmVyaWZpY2F0aW9uIHJlcXVlc3RzIHJlcXVpcmUgeW91ciBhdHRlbnRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJTaG93aW5nIHRoZSBsYXRlc3QgdW52ZXJpZmllZCBjdXN0b21lcnNcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogVE9HR0xFIElDT04gKi99XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC0zeGwgbXItMiBmb250LWJvbGQgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMzAwICR7dGFibGVEYXRhPy51bnZlcmlmaWVkQ3VzdG9tZXJzPy5sZW5ndGggPiAwXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwidGV4dC1vcmFuZ2UtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LWdyYXktNDAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRPcGVuU2VjdGlvbigocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgICAgdW52ZXJpZmllZEN1c3RvbWVyczogIXByZXYudW52ZXJpZmllZEN1c3RvbWVycyxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtvcGVuU2VjdGlvbi51bnZlcmlmaWVkQ3VzdG9tZXJzID8gXCLiiJJcIiA6IFwiK1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogQ09MTEFQU0lCTEUgQ09OVEVOVCAqL31cclxuICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGVhc2UtaW4tb3V0IG92ZXJmbG93LWhpZGRlbiAke29wZW5TZWN0aW9uLnVudmVyaWZpZWRDdXN0b21lcnNcclxuICAgICAgICAgICAgICAgICAgICA/IFwibWF4LWgtWzEwMDBweF0gb3BhY2l0eS0xMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIDogXCJtYXgtaC0wIG9wYWNpdHktMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHJvdW5kZWQtbGcgb3ZlcmZsb3ctaGlkZGVuIGJnLXdoaXRlIHNoYWRvdy1zbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7ZW5yb2xsbWVudHNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTQgcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0yMCBiZy1ncmF5LTIwMCBhbmltYXRlLXB1bHNlIHJvdW5kZWQtbWRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMjAgYmctZ3JheS0yMDAgYW5pbWF0ZS1wdWxzZSByb3VuZGVkLW1kXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkgOiB0YWJsZURhdGE/LnVudmVyaWZpZWRDdXN0b21lcnM/Lmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT17dGFibGVEYXRhPy51bnZlcmlmaWVkQ3VzdG9tZXJzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e3VudmVyaWZpZWRDdXN0b21lcnNDb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yMCB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNDAwIGl0YWxpY1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBObyB1bnZlcmlmaWVkIEN1c3RvbWVycyBmb3VuZFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIHNoYWRvdy1tZCBwLTEgbXQtNVwiPlxyXG4gICAgICAgICAgICAgICAgey8qIE1BSU4gQ0FSRCAqL31cclxuXHJcbiAgICAgICAgICAgICAgICB7Lyog4pyFIEhFQURFUiAoT05MWSBDTElDS0FCTEUgQVJFQSkgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwLTQgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBkYXJrOnRleHQtZ3JheS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFJlY2VudCBFbnJvbGxtZW50c1xyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIFZJRVcgQUxMIEFTIEFOQ0hPUiBMSU5LICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdG89XCIvcmVwb3J0cy9lbnJvbGxtZW50LXJlcG9ydFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ibHVlLTUwMCBob3Zlcjp0ZXh0LWJsdWUtNzAwIGhvdmVyOnVuZGVybGluZSB0cmFuc2l0aW9uIG1sLTNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBWaWV3IEFsbFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTaG93aW5nIHRoZSBsYXRlc3QgYWN0aXZpdGllc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogVE9HR0xFIElDT04gKi99XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1vcmFuZ2UtNTAwIHRleHQtM3hsIG1yLTIgZm9udC1ib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0T3BlblNlY3Rpb24oKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVucm9sbG1lbnRzOiAhcHJldi5lbnJvbGxtZW50cyxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtvcGVuU2VjdGlvbi5lbnJvbGxtZW50cyA/IFwi4oiSXCIgOiBcIitcIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIOKchSBDT0xMQVBTSUJMRSBDT05URU5UIChBTFdBWVMgTU9VTlRFRCkgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBlYXNlLWluLW91dCBvdmVyZmxvdy1oaWRkZW4gJHtvcGVuU2VjdGlvbi5lbnJvbGxtZW50c1xyXG4gICAgICAgICAgICAgICAgICAgID8gXCJtYXgtaC1bMTAwMHB4XSBvcGFjaXR5LTEwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcIm1heC1oLTAgb3BhY2l0eS0wXCJcclxuICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgey8qIOKchSBTVE9QIENMSUNLIFBST1BBR0FUSU9OIElOU0lERSAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgIHJvdW5kZWQtbGcgb3ZlcmZsb3ctaGlkZGVuIGJnLXdoaXRlIHNoYWRvdy1zbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7ZW5yb2xsbWVudHNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTQgcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0yMCBiZy1ncmF5LTIwMCBhbmltYXRlLXB1bHNlIHJvdW5kZWQtbWRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMjAgYmctZ3JheS0yMDAgYW5pbWF0ZS1wdWxzZSByb3VuZGVkLW1kXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkgOiB0YWJsZURhdGE/Lnllc3RlcmRheUVucm9sbG1lbnRzPy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGlzRXhwb3J0RW5hYmxlZD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT17dGFibGVEYXRhPy55ZXN0ZXJkYXlFbnJvbGxtZW50c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtlbnJvbGxtZW50Q29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMjAgdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTQwMCBpdGFsaWNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTm8gZW5yb2xsbWVudHMgZm91bmRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBzaGFkb3ctbWQgcC0xIG10LTVcIj5cclxuICAgICAgICAgICAgICAgIHsvKiBNQUlOIENBUkQgKi99XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIOKchSBIRUFERVIgKE9OTFkgQ0xJQ0tBQkxFIEFSRUEpICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcC00IGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDAgZGFyazp0ZXh0LWdyYXktMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBSZWNlbnQgUGF5b3V0c1xyXG4gICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdG89XCIvcmVwb3J0cy9wYXlvdXQtcmVwb3J0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWJsdWUtNTAwIGhvdmVyOnRleHQtYmx1ZS03MDAgaG92ZXI6dW5kZXJsaW5lIG1sLTRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBWaWV3IEFsbFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2hvd2luZyB0aGUgbGF0ZXN0IGFjdGl2aXRpZXNcclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIFRPR0dMRSBJQ09OICovfVxyXG4gICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtb3JhbmdlLTUwMCB0ZXh0LTN4bCBtci0yIGZvbnQtYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldE9wZW5TZWN0aW9uKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXlvdXRzOiAhcHJldi5wYXlvdXRzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge29wZW5TZWN0aW9uLnBheW91dHMgPyBcIuKIklwiIDogXCIrXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiDinIUgQ09MTEFQU0lCTEUgQ09OVEVOVCAoQUxXQVlTIE1PVU5URUQpICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZWFzZS1pbi1vdXQgb3ZlcmZsb3ctaGlkZGVuICR7b3BlblNlY3Rpb24ucGF5b3V0c1xyXG4gICAgICAgICAgICAgICAgICAgID8gXCJtYXgtaC1bMTAwMHB4XSBvcGFjaXR5LTEwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcIm1heC1oLTAgb3BhY2l0eS0wXCJcclxuICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgey8qIOKchSBTVE9QIENMSUNLIFBST1BBR0FUSU9OIElOU0lERSAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgcm91bmRlZC1sZyBvdmVyZmxvdy1oaWRkZW4gYmctd2hpdGUgc2hhZG93LXNtXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtwYXlvdXRzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00IHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMjAgYmctZ3JheS0yMDAgYW5pbWF0ZS1wdWxzZSByb3VuZGVkLW1kXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTIwIGJnLWdyYXktMjAwIGFuaW1hdGUtcHVsc2Ugcm91bmRlZC1tZFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApIDogdGFibGVEYXRhPy5yZWNlbnRQYXlvdXRzPy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGlzRXhwb3J0RW5hYmxlZD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT17dGFibGVEYXRhLnJlY2VudFBheW91dHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17cGF5T3V0Q29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMjAgdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTQwMCBpdGFsaWNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTm8gUGF5b3V0cyBmb3VuZFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIEN1c3RvbWVyIEFwcCBJbnN0YWxsYXRpb24gRGV0YWlscyAqL31cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IGN1cnNvci1wb2ludGVyIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBzaGFkb3ctbWQgcC0zXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXIgQXBwIEluc3RhbGxhdGlvbiBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvPVwiL3JlcG9ydHMvbW9iaWxlLWFwcC1pbnN0YWxsc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ibHVlLTUwMCBob3Zlcjp0ZXh0LWJsdWUtNzAwIGhvdmVyOnVuZGVybGluZSB0cmFuc2l0aW9uIG1sLTMgbXQtM1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFZpZXcgQWxsXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUmVhbC10aW1lIG1vYmlsZSBhcHAgaW5zdGFsbGF0aW9uIHN0YXR1c1xyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc09wZW5pbmcgPSAhb3BlblNlY3Rpb24uaW5zdGFsbGF0aW9ucztcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldE9wZW5TZWN0aW9uKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaW5zdGFsbGF0aW9uczogaXNPcGVuaW5nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNPcGVuaW5nICYmIG1vYmlsZUFwcERhdGEubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZmV0Y2hNb2JpbGVBcHBJbnN0YWxscygpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LW9yYW5nZS01MDAgdGV4dC0zeGwgbXItMiBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge29wZW5TZWN0aW9uLmluc3RhbGxhdGlvbnMgPyBcIuKIklwiIDogXCIrXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIENPTExBUFNJQkxFIENPTlRFTlQgKi99XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZWFzZS1pbi1vdXQgb3ZlcmZsb3ctaGlkZGVuICR7b3BlblNlY3Rpb24uaW5zdGFsbGF0aW9uc1xyXG4gICAgICAgICAgICAgICAgICAgID8gXCJtYXgtaC1bMzAwMHB4XSBvcGFjaXR5LTEwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcIm1heC1oLTAgb3BhY2l0eS0wXCJcclxuICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgey8qIFRBQlMgSU5TSURFIENVU1RPTUVSIEFQUCBJTlNUQUxMQVRJT04gREVUQUlMUyAqL31cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgcC0yIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVNb2JpbGVUYWIoXCJpbnN0YWxsYXRpb25cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTUgcHktMi41IHJvdW5kZWQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCAke2FjdGl2ZU1vYmlsZVRhYiA9PT0gXCJpbnN0YWxsYXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtZ3JheS02MDAgaG92ZXI6YmctZ3JheS0xMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBcHAgSW5zdGFsbGF0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVNb2JpbGVUYWIoXCJsb2dzXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC01IHB5LTIuNSByb3VuZGVkLWxnIHRleHQtc20gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgJHthY3RpdmVNb2JpbGVUYWIgPT09IFwibG9nc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWJsdWUtNjAwIHRleHQtd2hpdGUgc2hhZG93LW1kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTEwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE1vYmlsZSBBY3Rpdml0eSBMb2dzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogVEFCIDEgLSBBUFAgSU5TVEFMTEFUSU9OICovfVxyXG5cclxuICAgICAgICAgICAgICAgICAge2FjdGl2ZU1vYmlsZVRhYiA9PT0gXCJpbnN0YWxsYXRpb25cIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHttb2JpbGVBcHBMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtbLi4uQXJyYXkoNSldLm1hcCgoXywgaSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTYgYmctZ3JheS0xMDAgYW5pbWF0ZS1wdWxzZSByb3VuZGVkLXhsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXItY29sbGFwc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctZ3JheS0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMyB0ZXh0LWxlZnRcIj5TTDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTMgdGV4dC1sZWZ0XCI+Q3VzdG9tZXIgSUQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0zIHRleHQtbGVmdFwiPkN1c3RvbWVyIE5hbWU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0zIHRleHQtbGVmdFwiPlBob25lPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMyB0ZXh0LWxlZnRcIj5TdGF0dXM8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0zIHRleHQtbGVmdFwiPkxhc3QgTG9naW48L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aW5zdGFsbGF0aW9uVGFibGVEYXRhLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluc3RhbGxhdGlvblRhYmxlRGF0YS5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlci1iIGhvdmVyOmJnLWdyYXktNTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTNcIj57aXRlbS5pZH08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtM1wiPntpdGVtLmN1c3RvbWVyX2lkfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zXCI+e2l0ZW0uZnVsbF9uYW1lfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zXCI+e2l0ZW0ucGhvbmVfbnVtYmVyfTwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTIgcHktMSByb3VuZGVkIHRleHQteHMgZm9udC1zZW1pYm9sZCAke2l0ZW0uc3RhdHVzID09PSBcIkluc3RhbGxlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1yZWQtMTAwIHRleHQtcmVkLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnN0YXR1c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmxhc3RfbG9naW4gJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAhaXNOYU4obmV3IERhdGUoaXRlbS5sYXN0X2xvZ2luKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKGl0ZW0ubGFzdF9sb2dpbikudG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImVuLUlOXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbFNwYW49XCI2XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHAtNiB0ZXh0LWdyYXktNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBObyBpbnN0YWxsYXRpb24gcmVjb3JkcyBmb3VuZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIFRBQiAyIC0gTU9CSUxFIEFDVElWSVRZIExPR1MgKi99XHJcblxyXG4gICAgICAgICAgICAgICAgICB7YWN0aXZlTW9iaWxlVGFiID09PSBcImxvZ3NcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCByb3VuZGVkLWxnIG92ZXJmbG93LWhpZGRlbiBiZy13aGl0ZSBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge21vYmlsZUFwcExvZ3NMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCBwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMjAgYmctZ3JheS0yMDAgYW5pbWF0ZS1wdWxzZSByb3VuZGVkLW1kXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMjAgYmctZ3JheS0yMDAgYW5pbWF0ZS1wdWxzZSByb3VuZGVkLW1kXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApIDogdGFibGVEYXRhPy5yZWNlbnRNb2JpbGVBcHBMb2dzPy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE9e3RhYmxlRGF0YT8ucmVjZW50TW9iaWxlQXBwTG9nc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e21vYmlsZUFwcExvZ3NDb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIwIHRleHQtY2VudGVyIHRleHQtZ3JheS00MDAgaXRhbGljXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTm8gTW9iaWxlIEFjdGl2aXR5IExvZ3MgZm91bmRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7LyogRU5EIFJFQ0VOVCBQQVlPVVRTIFNFQ1RJT04gKi99XHJcblxyXG5cclxuXHJcbiAgICAgICAgICAgIHsvKiAgQ3VzdG9tZXIgQXBwIEluc3RhbGxhdGlvbiBEZXRhaWxzICovfVxyXG5cclxuICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwibXQtOCBjdXJzb3ItcG9pbnRlciBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgc2hhZG93LW1kIHAtM1wiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXIgQXBwIEluc3RhbGxhdGlvbiBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgIHRvPVwiL3JlcG9ydHMvbW9iaWxlLWFwcC1pbnN0YWxsc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtYmx1ZS01MDAgaG92ZXI6dGV4dC1ibHVlLTcwMCBob3Zlcjp1bmRlcmxpbmUgdHJhbnNpdGlvbiBtbC0zIG10LTNcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFZpZXcgQWxsXHJcbiAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFJlYWwtdGltZSBtb2JpbGUgYXBwIGluc3RhbGxhdGlvbiBzdGF0dXNcclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc09wZW5pbmcgPSAhb3BlblNlY3Rpb24uaW5zdGFsbGF0aW9ucztcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRPcGVuU2VjdGlvbigocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgICAgaW5zdGFsbGF0aW9uczogaXNPcGVuaW5nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIGlmIChpc09wZW5pbmcgJiYgbW9iaWxlQXBwRGF0YS5sZW5ndGggPT09IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZmV0Y2hNb2JpbGVBcHBJbnN0YWxscygpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtb3JhbmdlLTUwMCB0ZXh0LTN4bCBtci0yIGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge29wZW5TZWN0aW9uLmluc3RhbGxhdGlvbnMgPyBcIuKIklwiIDogXCIrXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7bW9iaWxlQXBwTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtbLi4uQXJyYXkoNSldLm1hcCgoXywgaSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgIGtleT17aX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTYgYmctZ3JheS0xMDAgYW5pbWF0ZS1wdWxzZSByb3VuZGVkLXhsXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBlYXNlLWluLW91dCBvdmVyZmxvdy1oaWRkZW4gJHtvcGVuU2VjdGlvbi5pbnN0YWxsYXRpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgPyBcIm1heC1oLVsyMDAwcHhdIG9wYWNpdHktMTAwXCJcclxuICAgICAgICAgICAgICAgICAgICA6IFwibWF4LWgtMCBvcGFjaXR5LTBcIlxyXG4gICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7bW9iaWxlQXBwTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LThcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e21vYmlsZUFwcExvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZhaWx1cmU9e2luc3RhbGxhdGlvblRhYmxlRGF0YS5sZW5ndGggPT09IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE9XCJpbnN0YWxsYXRpb24gcmVjb3Jkc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlci1jb2xsYXBzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJnLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0zIHRleHQtbGVmdFwiPlNMPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTMgdGV4dC1sZWZ0XCI+Q3VzdG9tZXIgSUQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMyB0ZXh0LWxlZnRcIj5DdXN0b21lciBOYW1lPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTMgdGV4dC1sZWZ0XCI+UGhvbmU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMyB0ZXh0LWxlZnRcIj5TdGF0dXM8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMyB0ZXh0LWxlZnRcIj5MYXN0IExvZ2luPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpbnN0YWxsYXRpb25UYWJsZURhdGEubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluc3RhbGxhdGlvblRhYmxlRGF0YT8ubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0clxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItYiBob3ZlcjpiZy1ncmF5LTUwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTNcIj57aXRlbS5pZH08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTNcIj57aXRlbS5jdXN0b21lcl9pZH08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTNcIj57aXRlbS5mdWxsX25hbWV9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zXCI+e2l0ZW0ucGhvbmVfbnVtYmVyfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMiBweS0xIHJvdW5kZWQgdGV4dC14cyBmb250LXNlbWlib2xkICR7aXRlbS5zdGF0dXMgPT09IFwiSW5zdGFsbGVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctcmVkLTEwMCB0ZXh0LXJlZC03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5zdGF0dXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5sYXN0X2xvZ2luICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICFpc05hTihuZXcgRGF0ZShpdGVtLmxhc3RfbG9naW4pKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKGl0ZW0ubGFzdF9sb2dpbikudG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbi1JTlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sU3Bhbj1cIjZcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHAtNiB0ZXh0LWdyYXktNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vIGluc3RhbGxhdGlvbiByZWNvcmRzIGZvdW5kXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAvLyA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj4gKi99XHJcblxyXG4gICAgICAgICAgICB7LyogQ3VzdG9tZXIgQWNrbm93bGVkbWVudCBEZXRhaWxzICovfVxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IGN1cnNvci1wb2ludGVyIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBzaGFkb3ctbWQgcC0zXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lciBBY2tub3dsZWRnZW1lbnQgRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICB0bz1cIi9yZXBvcnRzL3RyYW5zYWN0aW9uLWhpc3RvcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWJsdWUtNTAwIGhvdmVyOnRleHQtYmx1ZS03MDAgaG92ZXI6dW5kZXJsaW5lIHRyYW5zaXRpb24gbWwtMyBtdC0zXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBWaWV3IEFsbFxyXG4gICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBSZWFsLXRpbWUgQ3VzdG9tZXIgQWNrbm93bGVkZ2VtZW50IHN0YXR1c1xyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzT3BlbmluZyA9ICFvcGVuU2VjdGlvbi5hY2tub3dsZWRtZW50cztcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRPcGVuU2VjdGlvbigocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNrbm93bGVkbWVudHM6IGlzT3BlbmluZyxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNPcGVuaW5nICYmIGFja25vd2xlZG1lbnREYXRhLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmZXRjaGFja25vd2xlZG1lbnREYXRhKDEwKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMlwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LW9yYW5nZS01MDAgdGV4dC0zeGwgbXItMiBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtvcGVuU2VjdGlvbi5hY2tub3dsZWRtZW50cyA/IFwi4oiSXCIgOiBcIitcIn1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHthY2tub3dsZWRtZW50c0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgICAgICB7Wy4uLkFycmF5KDUpXS5tYXAoKF8sIGkpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTE2IGJnLWdyYXktMTAwIGFuaW1hdGUtcHVsc2Ugcm91bmRlZC14bFwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZWFzZS1pbi1vdXQgb3ZlcmZsb3ctaGlkZGVuICR7b3BlblNlY3Rpb24uYWNrbm93bGVkbWVudHNcclxuICAgICAgICAgICAgICAgICAgICA/IFwibWF4LWgtWzIwMDBweF0gb3BhY2l0eS0xMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIDogXCJtYXgtaC0wIG9wYWNpdHktMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHthY2tub3dsZWRtZW50c0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS04XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaXNMb2FkaW5nPXthY2tub3dsZWRtZW50c0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZhaWx1cmU9e2Fja25vd2xlZG1lbnREYXRhLmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT1cImluc3RhbGxhdGlvbiByZWNvcmRzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgZGF0YT17YWNrbm93bGVkbWVudHNUYWJsZURhdGF9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXthY2tub3dsZWRnZW1lbnRDb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIC8vIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L21haW4+XHJcblxyXG4gICAgICAgIHtzaG93UGFzc3dvcmRQcm9tcHQgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWJsYWNrIGJnLW9wYWNpdHktNTAgei01MCBwLTQgYW5pbWF0ZS1mYWRlLWluXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCB3LWZ1bGwgbWF4LXctbWQgcC04IHRyYW5zZm9ybSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgc2NhbGUtMTAwIGhvdmVyOnNjYWxlLVsxLjAxXVwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgU2VjdXJlIEFjY2VzcyBSZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1Bhc3N3b3JkUHJvbXB0KGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCBob3Zlcjp0ZXh0LWdyYXktNjAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNiBoLTZcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBkPVwiTTYgMThMMTggNk02IDZsMTIgMTJcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgdGV4dC1zbSBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICBQbGVhc2UgZW50ZXIgeW91ciBhZG1pbiBwYXNzd29yZCB0byBwcm9jZWVkIHRve1wiIFwifVxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC12aW9sZXQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFJlZGlyZWN0fSBwYWdlXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFBhc3N3b3JkXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmRJbnB1dH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQYXNzd29yZElucHV0KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLigKLigKLigKLigKLigKLigKLigKLigKJcIlxyXG4gICAgICAgICAgICAgICAgICBhdXRvRm9jdXNcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQteGwgZm9jdXM6cmluZy00IGZvY3VzOnJpbmctdmlvbGV0LTIwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCBvdXRsaW5lLW5vbmUgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIHRleHQtZ3JheS04MDAgcGxhY2Vob2xkZXItZ3JheS00MDBcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIHtlcnJvck1zZyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC01MDAgZm9udC1tZWRpdW0gZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IG1yLTFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsbD1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDIwIDIwXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWxsUnVsZT1cImV2ZW5vZGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkPVwiTTE4IDEwYTggOCAwIDExLTE2IDAgOCA4IDAgMDExNiAwem0tNyA0YTEgMSAwIDExLTIgMCAxIDEgMCAwMTIgMHptLTEtOWExIDEgMCAwMC0xIDF2NGExIDEgMCAxMDIgMFY2YTEgMSAwIDAwLTEtMXpcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGlwUnVsZT1cImV2ZW5vZGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JNc2d9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UGFzc3dvcmRQcm9tcHQoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHktMyBweC00IGJnLWdyYXktMTAwIGhvdmVyOmJnLWdyYXktMjAwIHRleHQtZ3JheS03MDAgZm9udC1tZWRpdW0gcm91bmRlZC14bCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNMb2FkaW5nVmVyaWZ5fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXt2ZXJpZnlQYXNzd29yZEFuZFJlZGlyZWN0fVxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNMb2FkaW5nVmVyaWZ5fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4LTEgcHktMyBweC00IGZvbnQtbWVkaXVtIHJvdW5kZWQteGwgc2hhZG93LW1kIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclxyXG4gICAgICAgICAgICAgICAgICAke2lzTG9hZGluZ1ZlcmlmeVxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXZpb2xldC00MDAgY3Vyc29yLW5vdC1hbGxvd2VkIG9wYWNpdHktODBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWdyYWRpZW50LXRvLXIgZnJvbS12aW9sZXQtNTAwIHRvLXZpb2xldC02MDAgaG92ZXI6ZnJvbS12aW9sZXQtNjAwIGhvdmVyOnRvLXZpb2xldC03MDAgdGV4dC13aGl0ZSBob3ZlcjpzaGFkb3ctbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7aXNMb2FkaW5nVmVyaWZ5ID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiAtbWwtMSBtci0yIGgtNSB3LTUgdGV4dC13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Y2lyY2xlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwib3BhY2l0eS0yNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY3g9XCIxMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY3k9XCIxMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcj1cIjEwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID48L2NpcmNsZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJvcGFjaXR5LTc1XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkPVwiTTQgMTJhOCA4IDAgMDE4LThWMEM1LjM3MyAwIDAgNS4zNzMgMCAxMmg0em0yIDUuMjkxQTcuOTYyIDcuOTYyIDAgMDE0IDEySDBjMCAzLjA0MiAxLjEzNSA1LjgyNCAzIDcuOTM4bDMtMi42NDd6XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPjwvcGF0aD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgVmVyaWZ5aW5nLi4uXHJcbiAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgXCJWZXJpZnkgJiBQcm9jZWVkXCJcclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEhvbWU7XHJcblxyXG5cclxuXHJcblxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvSG9tZS5qc3gifQ==