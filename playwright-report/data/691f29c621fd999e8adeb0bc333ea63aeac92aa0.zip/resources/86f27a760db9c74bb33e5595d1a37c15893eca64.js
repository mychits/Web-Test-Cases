import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/SuspensePayments.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import API from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import {
  DatePicker,
  Select,
  Dropdown,
  Drawer,
  Empty,
  Spin,
  Modal,
  Form,
  Input,
  Button,
  message,
  Typography,
  Card
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
const { RangePicker } = DatePicker;
const { Title, Text } = Typography;
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { Link, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import {
  LoadingOutlined,
  ExclamationCircleOutlined,
  CalendarOutlined,
  DollarOutlined,
  CreditCardOutlined,
  BankOutlined,
  SafetyOutlined,
  FileTextOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import { RiMoneyRupeeCircleFill } from "/node_modules/.vite/deps/react-icons_ri.js?v=819e0a34";
import __vite__cjsImport13_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport13_dayjs.__esModule ? __vite__cjsImport13_dayjs.default : __vite__cjsImport13_dayjs;
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const SuspensePayments = () => {
  _s();
  const [paymentsData, setPaymentsData] = useState([]);
  const [groups, setGroups] = useState([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [searchParams, setSearchParams] = useSearchParams();
  const [startDate, setStartDate] = useState(
    searchParams.get("start_date") || ""
  );
  const [endDate, setEndDate] = useState(searchParams.get("end_date") || "");
  const [group, setGroup] = useState(searchParams.get("group_id"));
  const [updateModalVisible, setUpdateModalVisible] = useState(false);
  const [currentPaymentId, setCurrentPaymentId] = useState(null);
  const [updateForm] = Form.useForm();
  const [updateLoading, setUpdateLoading] = useState(false);
  const [deleteModalVisible, setDeleteModalVisible] = useState(false);
  const [paymentIdToDelete, setPaymentIdToDelete] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "",
    type: "info"
  });
  const payType = Form.useWatch("pay_type", updateForm);
  const handleViewModalOpen = () => {
    setOpen(true);
  };
  const onGlobalSearchChangeHandler = (e) => {
    setSearchText(e.target.value);
    setCurrentPage(1);
    setCurrentPageRelated(1);
  };
  const handleUpdateModalOpen = async (paymentId) => {
    setCurrentPaymentId(paymentId);
    setUpdateModalVisible(true);
    try {
      setUpdateLoading(true);
      const response = await API.get(`/payment/${paymentId}`);
      const payment = response.data.data;
      updateForm.setFieldsValue({
        pay_date: payment.pay_date ? dayjs(payment.pay_date) : null,
        amount: payment.amount,
        pay_type: payment.pay_type,
        account_type: payment.account_type,
        transaction_id: payment.transaction_id,
        pay_for: payment.pay_for,
        cheque_number: payment.cheque_number,
        cheque_date: payment.cheque_date ? dayjs(payment.cheque_date) : null,
        cheque_bank_name: payment.cheque_bank_name,
        cheque_bank_branch: payment.cheque_bank_branch
      });
    } catch (error) {
      message.error("Failed to fetch payment details");
    } finally {
      setUpdateLoading(false);
    }
  };
  const handleUpdatePayment = async (values) => {
    try {
      setUpdateLoading(true);
      let formattedValues = {
        ...values,
        pay_date: values.pay_date ? values.pay_date.format("YYYY-MM-DD") : null,
        cheque_date: values.cheque_date ? values.cheque_date.format("YYYY-MM-DD") : null
      };
      if (formattedValues.pay_type === "cash") {
        formattedValues.transaction_id = null;
        formattedValues.cheque_number = null;
        formattedValues.cheque_date = null;
        formattedValues.cheque_bank_name = null;
        formattedValues.cheque_bank_branch = null;
      } else if (formattedValues.pay_type === "online") {
        formattedValues.cheque_number = null;
        formattedValues.cheque_date = null;
        formattedValues.cheque_bank_name = null;
        formattedValues.cheque_bank_branch = null;
      } else if (formattedValues.pay_type === "cheque") {
        formattedValues.transaction_id = null;
      }
      await API.put(`/payment/${currentPaymentId}`, formattedValues);
      message.success("Payment updated successfully");
      setUpdateModalVisible(false);
      updateForm.resetFields();
      getPayments();
    } catch (error) {
      message.error("Failed to update payment");
    } finally {
      setUpdateLoading(false);
    }
  };
  const handleUpdateModalCancel = () => {
    setUpdateModalVisible(false);
    updateForm.resetFields();
  };
  const handleDeleteModalOpen = (paymentId) => {
    setPaymentIdToDelete(paymentId);
    setDeleteModalVisible(true);
  };
  const handleConfirmDelete = async () => {
    try {
      setDeleteLoading(true);
      await API.delete(`/delete/${paymentIdToDelete}`);
      message.success("Payment deleted successfully!");
      setDeleteModalVisible(false);
      setPaymentIdToDelete(null);
      getPayments();
    } catch (error) {
      message.error("Failed to delete payment");
    } finally {
      setDeleteLoading(false);
    }
  };
  const handleFormValuesChange = (changedValues) => {
    if (changedValues.pay_type) {
      const newPayType = changedValues.pay_type;
      let fieldsToClear = {};
      if (newPayType === "cash") {
        fieldsToClear = {
          transaction_id: null,
          cheque_number: null,
          cheque_date: null,
          cheque_bank_name: null,
          cheque_bank_branch: null
        };
      } else if (newPayType === "online") {
        fieldsToClear = {
          cheque_number: null,
          cheque_date: null,
          cheque_bank_name: null,
          cheque_bank_branch: null
        };
      } else if (newPayType === "cheque") {
        fieldsToClear = {
          transaction_id: null
        };
      }
      updateForm.setFieldsValue(fieldsToClear);
    }
  };
  const dropDownItems = (paymentID) => {
    const dropDownItemList = [
      {
        key: "1",
        label: /* @__PURE__ */ jsxDEV(Link, { to: `/print/${paymentID}`, className: "text-violet-600", children: "Print" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
          lineNumber: 208,
          columnNumber: 7
        }, this)
      },
      {
        key: "2",
        label: /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "text-green-600",
            onClick: () => handleUpdateModalOpen(paymentID),
            children: "Update"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
            lineNumber: 216,
            columnNumber: 7
          },
          this
        )
      },
      {
        key: "3",
        label: /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "text-red-600",
            onClick: () => handleDeleteModalOpen(paymentID),
            children: "Delete"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
            lineNumber: 227,
            columnNumber: 7
          },
          this
        )
      }
    ];
    return dropDownItemList;
  };
  async function getPayments() {
    try {
      setLoading(true);
      const payments = await API.get(
        `/payment/suspense?group_id=${group}&start_date=${startDate}&end_date=${endDate}`
      );
      const responseData = payments?.data?.data.map((payment, index) => ({
        key: payment?._id,
        payment_id: payment._id,
        slNo: index + 1,
        customerName: payment?.user_id?.full_name,
        customerId: payment?.user_id?.customer_id,
        customerPhone: payment?.user_id?.phone_number,
        adminType: payment?.admin_type?.admin_name,
        groupName: payment?.group_id?.group_name,
        ticket: payment?.ticket,
        receiptNo: payment.receipt_no,
        amount: payment.amount,
        payType: payment.pay_type,
        payDate: payment.pay_date,
        transactionDate: payment.createdAt.split("T")[0],
        action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
          Dropdown,
          {
            trigger: ["click"],
            menu: { items: dropDownItems(payment?._id) },
            placement: "bottomLeft",
            children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold cursor-pointer text-xl hover:text-gray-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
              lineNumber: 269,
              columnNumber: 15
            }, this)
          },
          payment?._id,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
            lineNumber: 263,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
          lineNumber: 262,
          columnNumber: 9
        }, this)
      }));
      setPaymentsData(responseData);
    } catch (error) {
      setPaymentsData([]);
    } finally {
      setLoading(false);
    }
  }
  async function getGroups() {
    try {
      const response = await API.get("/group/get-group-admin");
      const filteredGroups = response?.data?.map((group2) => ({
        value: group2?._id,
        label: group2?.group_name
      }));
      setGroups(filteredGroups);
    } catch (error) {
      setGroups([]);
    }
  }
  useEffect(() => {
    getPayments();
  }, [group, startDate, endDate]);
  useEffect(() => {
    getGroups();
  }, []);
  const handleRangeChange = (dates, dateStrings) => {
    if (dates) {
      setStartDate(dateStrings[0]);
      setEndDate(dateStrings[1]);
      setSearchParams({
        ...Object.fromEntries(searchParams),
        start_date: dateStrings[0],
        end_date: dateStrings[1]
      });
    } else {
      setStartDate(null);
      setEndDate(null);
    }
  };
  const columns = [
    { key: "slNo", header: "Sl No" },
    { key: "transactionDate", header: "Transaction Date" },
    { key: "payDate", header: "Pay Date" },
    { key: "customerName", header: "Customer Name" },
    { key: "customerId", header: "Customer Id" },
    { key: "customerPhone", header: "Customer Phone" },
    { key: "groupName", header: "Group Name" },
    { key: "ticket", header: "Ticket" },
    { key: "amount", header: "Amount" },
    { key: "payType", header: "Pay Type" },
    { key: "receiptNo", header: "Receipt No" },
    { key: "adminType", header: "Admin Type" },
    { key: "action", header: "Actions" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gray-50 overflow-x-hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "flex", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
      lineNumber: 337,
      columnNumber: 8
    }, this),
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
        lineNumber: 338,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
        lineNumber: 342,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("main", { className: "flex-1 p-6 mt-20  min-w-0  overflow-x-auto", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
          lineNumber: 350,
          columnNumber: 26
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold text-gray-800 mb-2", children: "Suspense Payments" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
          lineNumber: 351,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600", children: "Manage and track suspense payment records" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
          lineNumber: 354,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
        lineNumber: 349,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-700 mb-4", children: "Filters" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
          lineNumber: 361,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium text-gray-700 mb-2", children: "Date Range" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
              lineNumber: 364,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              RangePicker,
              {
                onChange: handleRangeChange,
                className: "w-64",
                size: "large",
                placeholder: ["Start Date", "End Date"]
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                lineNumber: 367,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
            lineNumber: 363,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium text-gray-700 mb-2", children: "Group" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
              lineNumber: 375,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                size: "large",
                style: { width: 240 },
                placeholder: "Select a group",
                optionFilterProp: "label",
                filterSort: (optionA, optionB) => (optionA?.label ?? "").toLowerCase().localeCompare((optionB?.label ?? "").toLowerCase()),
                value: group,
                options: groups,
                onChange: (value) => {
                  setSearchParams({
                    ...Object.fromEntries(searchParams),
                    group_id: value
                  });
                  setGroup(value);
                },
                allowClear: true
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                lineNumber: 378,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
            lineNumber: 374,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
          lineNumber: 362,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
        lineNumber: 360,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border border-gray-200 p-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-700", children: "Payment Records" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
            lineNumber: 406,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600", children: [
            "Total Records:",
            " ",
            /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: paymentsData.length }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
              lineNumber: 411,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
            lineNumber: 409,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
          lineNumber: 405,
          columnNumber: 11
        }, this),
        loading ? /* @__PURE__ */ jsxDEV("div", { className: "w-full h-64 flex justify-center items-center", children: /* @__PURE__ */ jsxDEV(Spin, { indicator: /* @__PURE__ */ jsxDEV(LoadingOutlined, { spin: true }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
          lineNumber: 417,
          columnNumber: 32
        }, this), size: "large" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
          lineNumber: 417,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
          lineNumber: 416,
          columnNumber: 13
        }, this) : paymentsData.length > 0 ? /* @__PURE__ */ jsxDEV(DataTable, { columns, data: paymentsData, exportedFileName: "Suspense Payment.csv", exportedPdfName: "Suspense Payment" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
          lineNumber: 420,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV(Empty, { description: "No Payment Records Found" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
          lineNumber: 423,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
        lineNumber: 404,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
      lineNumber: 348,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        title: "Payment Details",
        placement: "right",
        onClose: () => setOpen(false),
        open,
        width: 500,
        children: /* @__PURE__ */ jsxDEV("p", { children: "Some contents for viewing payment details..." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
          lineNumber: 436,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
        lineNumber: 429,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        open: updateModalVisible,
        onCancel: handleUpdateModalCancel,
        footer: null,
        width: 900,
        destroyOnClose: true,
        centered: true,
        className: "professional-modal",
        styles: {
          body: { padding: 0 },
          header: { display: "none" }
        },
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-violet-50 via-white to-purple-50 p-8", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-2", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 bg-gradient-to-br from-violet-500 to-violet-600 rounded-xl flex items-center justify-center shadow-lg", children: /* @__PURE__ */ jsxDEV(CreditCardOutlined, { className: "text-white text-2xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                lineNumber: 458,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                lineNumber: 457,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV(Title, { level: 3, className: "!mb-0 !text-gray-800", children: "Update Payment Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                  lineNumber: 461,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Text, { className: "text-gray-500 text-sm", children: "Modify payment information and transaction details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                  lineNumber: 464,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                lineNumber: 460,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
              lineNumber: 456,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
              lineNumber: 455,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(Spin, { spinning: updateLoading, size: "large", children: /* @__PURE__ */ jsxDEV(
              Form,
              {
                form: updateForm,
                layout: "vertical",
                onFinish: handleUpdatePayment,
                className: "space-y-6",
                onValuesChange: handleFormValuesChange,
                children: [
                  /* @__PURE__ */ jsxDEV(
                    Card,
                    {
                      className: "shadow-sm border-0",
                      styles: { body: { padding: "24px" } },
                      children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-6", children: /* @__PURE__ */ jsxDEV(Title, { level: 5, className: "!mb-0 !text-gray-700", children: "Payment Information" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                          lineNumber: 485,
                          columnNumber: 19
                        }, this) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                          lineNumber: 484,
                          columnNumber: 17
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
                          /* @__PURE__ */ jsxDEV(
                            Form.Item,
                            {
                              label: /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-700 flex items-center gap-2", children: [
                                /* @__PURE__ */ jsxDEV(CalendarOutlined, { className: "text-gray-400" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                  lineNumber: 494,
                                  columnNumber: 25
                                }, this),
                                "Payment Date"
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                lineNumber: 493,
                                columnNumber: 23
                              }, this),
                              name: "pay_date",
                              rules: [
                                { required: true, message: "Please select the payment date" }
                              ],
                              children: /* @__PURE__ */ jsxDEV(
                                DatePicker,
                                {
                                  style: { width: "100%", height: "46px" },
                                  format: "YYYY-MM-DD",
                                  placeholder: "Select payment date",
                                  className: "rounded-lg hover:border-violet-400 focus:border-violet-500"
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                  lineNumber: 503,
                                  columnNumber: 21
                                },
                                this
                              )
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                              lineNumber: 491,
                              columnNumber: 19
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV(
                            Form.Item,
                            {
                              label: /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-700 flex items-center gap-2", children: [
                                /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { className: "text-gray-400" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                  lineNumber: 514,
                                  columnNumber: 25
                                }, this),
                                "Amount"
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                lineNumber: 513,
                                columnNumber: 23
                              }, this),
                              name: "amount",
                              rules: [
                                { required: true, message: "Please input the amount" },
                                {
                                  pattern: /^\d+(\.\d{1,2})?$/,
                                  message: "Please enter a valid amount"
                                }
                              ],
                              children: /* @__PURE__ */ jsxDEV(
                                Input,
                                {
                                  type: "number",
                                  prefix: "₹",
                                  placeholder: "0.00",
                                  className: "rounded-lg h-[46px] hover:border-violet-400 focus:border-violet-500",
                                  style: { fontSize: "15px" }
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                  lineNumber: 527,
                                  columnNumber: 21
                                },
                                this
                              )
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                              lineNumber: 511,
                              columnNumber: 19
                            },
                            this
                          )
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                          lineNumber: 490,
                          columnNumber: 17
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                      lineNumber: 480,
                      columnNumber: 15
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Card,
                    {
                      className: "shadow-sm border-0",
                      styles: { body: { padding: "24px" } },
                      children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-6", children: /* @__PURE__ */ jsxDEV(Title, { level: 5, className: "!mb-0 !text-gray-700", children: "Payment Method" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                          lineNumber: 544,
                          columnNumber: 19
                        }, this) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                          lineNumber: 543,
                          columnNumber: 17
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
                          /* @__PURE__ */ jsxDEV(
                            Form.Item,
                            {
                              label: /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-700 flex items-center gap-2", children: [
                                /* @__PURE__ */ jsxDEV(CreditCardOutlined, { className: "text-gray-400" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                  lineNumber: 553,
                                  columnNumber: 25
                                }, this),
                                "Payment Type"
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                lineNumber: 552,
                                columnNumber: 23
                              }, this),
                              name: "pay_type",
                              rules: [
                                { required: true, message: "Please select a payment type" }
                              ],
                              children: /* @__PURE__ */ jsxDEV(
                                Select,
                                {
                                  placeholder: "Select payment method",
                                  size: "large",
                                  className: "professional-select",
                                  suffixIcon: /* @__PURE__ */ jsxDEV(CreditCardOutlined, { className: "text-gray-400" }, void 0, false, {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                    lineNumber: 566,
                                    columnNumber: 37
                                  }, this),
                                  children: [
                                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "cash", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                                      /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { className: "text-green-600" }, void 0, false, {
                                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                        lineNumber: 570,
                                        columnNumber: 27
                                      }, this),
                                      /* @__PURE__ */ jsxDEV("span", { children: "Cash Payment" }, void 0, false, {
                                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                        lineNumber: 571,
                                        columnNumber: 27
                                      }, this)
                                    ] }, void 0, true, {
                                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                      lineNumber: 569,
                                      columnNumber: 25
                                    }, this) }, void 0, false, {
                                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                      lineNumber: 568,
                                      columnNumber: 23
                                    }, this),
                                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "cheque", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                                      /* @__PURE__ */ jsxDEV(FileTextOutlined, { className: "text-violet-600" }, void 0, false, {
                                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                        lineNumber: 576,
                                        columnNumber: 27
                                      }, this),
                                      /* @__PURE__ */ jsxDEV("span", { children: "Cheque Payment" }, void 0, false, {
                                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                        lineNumber: 577,
                                        columnNumber: 27
                                      }, this)
                                    ] }, void 0, true, {
                                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                      lineNumber: 575,
                                      columnNumber: 25
                                    }, this) }, void 0, false, {
                                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                      lineNumber: 574,
                                      columnNumber: 23
                                    }, this),
                                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "online", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                                      /* @__PURE__ */ jsxDEV(BankOutlined, { className: "text-purple-600" }, void 0, false, {
                                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                        lineNumber: 582,
                                        columnNumber: 27
                                      }, this),
                                      /* @__PURE__ */ jsxDEV("span", { children: "Online Transfer" }, void 0, false, {
                                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                        lineNumber: 583,
                                        columnNumber: 27
                                      }, this)
                                    ] }, void 0, true, {
                                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                      lineNumber: 581,
                                      columnNumber: 25
                                    }, this) }, void 0, false, {
                                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                      lineNumber: 580,
                                      columnNumber: 23
                                    }, this)
                                  ]
                                },
                                void 0,
                                true,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                  lineNumber: 562,
                                  columnNumber: 21
                                },
                                this
                              )
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                              lineNumber: 550,
                              columnNumber: 19
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV(
                            Form.Item,
                            {
                              label: /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-700 flex items-center gap-2", children: [
                                /* @__PURE__ */ jsxDEV(BankOutlined, { className: "text-gray-400" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                  lineNumber: 592,
                                  columnNumber: 25
                                }, this),
                                "Account Type"
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                lineNumber: 591,
                                columnNumber: 23
                              }, this),
                              name: "account_type",
                              rules: [
                                { required: true, message: "Please select an account type" }
                              ],
                              children: /* @__PURE__ */ jsxDEV(
                                Select,
                                {
                                  placeholder: "Select account type",
                                  size: "large",
                                  className: "professional-select",
                                  suffixIcon: /* @__PURE__ */ jsxDEV(BankOutlined, { className: "text-gray-400" }, void 0, false, {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                    lineNumber: 605,
                                    columnNumber: 37
                                  }, this),
                                  children: [
                                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "Suspense", children: "Suspense" }, void 0, false, {
                                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                      lineNumber: 607,
                                      columnNumber: 23
                                    }, this),
                                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "Other", children: "Other" }, void 0, false, {
                                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                      lineNumber: 608,
                                      columnNumber: 23
                                    }, this)
                                  ]
                                },
                                void 0,
                                true,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                  lineNumber: 601,
                                  columnNumber: 21
                                },
                                this
                              )
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                              lineNumber: 589,
                              columnNumber: 19
                            },
                            this
                          )
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                          lineNumber: 549,
                          columnNumber: 17
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                      lineNumber: 539,
                      columnNumber: 15
                    },
                    this
                  ),
                  payType === "online" && /* @__PURE__ */ jsxDEV(
                    Card,
                    {
                      className: "shadow-sm border-0 bg-gradient-to-br from-purple-50 to-violet-50",
                      styles: { body: { padding: "24px" } },
                      children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-6", children: /* @__PURE__ */ jsxDEV(Title, { level: 5, className: "!mb-0 !text-gray-700", children: "Online Transaction Details" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                          lineNumber: 621,
                          columnNumber: 21
                        }, this) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                          lineNumber: 620,
                          columnNumber: 19
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          Form.Item,
                          {
                            label: /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-700 flex items-center gap-2", children: "Transaction ID" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                              lineNumber: 628,
                              columnNumber: 21
                            }, this),
                            name: "transaction_id",
                            rules: [
                              { required: true, message: "Please input the transaction ID" }
                            ],
                            children: /* @__PURE__ */ jsxDEV(
                              Input,
                              {
                                placeholder: "Enter transaction reference number",
                                className: "rounded-lg h-[46px] hover:border-purple-400 focus:border-purple-500",
                                prefix: /* @__PURE__ */ jsxDEV(SafetyOutlined, { className: "text-gray-400" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                  lineNumber: 640,
                                  columnNumber: 31
                                }, this)
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                lineNumber: 637,
                                columnNumber: 21
                              },
                              this
                            )
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                            lineNumber: 626,
                            columnNumber: 19
                          },
                          this
                        )
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                      lineNumber: 616,
                      columnNumber: 17
                    },
                    this
                  ),
                  payType === "cheque" && /* @__PURE__ */ jsxDEV(
                    Card,
                    {
                      className: "shadow-sm border-0 bg-gradient-to-br from-violet-50 to-indigo-50",
                      styles: { body: { padding: "24px" } },
                      children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-6", children: /* @__PURE__ */ jsxDEV(Title, { level: 5, className: "!mb-0 !text-gray-700", children: "Cheque Details" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                          lineNumber: 652,
                          columnNumber: 21
                        }, this) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                          lineNumber: 651,
                          columnNumber: 19
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
                          /* @__PURE__ */ jsxDEV(
                            Form.Item,
                            {
                              label: /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-700 flex items-center gap-2", children: [
                                /* @__PURE__ */ jsxDEV(FileTextOutlined, { className: "text-gray-400" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                  lineNumber: 661,
                                  columnNumber: 27
                                }, this),
                                "Cheque Number"
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                lineNumber: 660,
                                columnNumber: 23
                              }, this),
                              name: "cheque_number",
                              rules: [
                                { required: true, message: "Please input the cheque number" }
                              ],
                              children: /* @__PURE__ */ jsxDEV(
                                Input,
                                {
                                  placeholder: "Enter cheque number",
                                  className: "rounded-lg h-[46px] hover:border-violet-400 focus:border-violet-500",
                                  prefix: /* @__PURE__ */ jsxDEV(FileTextOutlined, { className: "text-gray-400" }, void 0, false, {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                    lineNumber: 673,
                                    columnNumber: 33
                                  }, this)
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                  lineNumber: 670,
                                  columnNumber: 23
                                },
                                this
                              )
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                              lineNumber: 658,
                              columnNumber: 21
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV(
                            Form.Item,
                            {
                              label: /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-700 flex items-center gap-2", children: [
                                /* @__PURE__ */ jsxDEV(CalendarOutlined, { className: "text-gray-400" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                  lineNumber: 680,
                                  columnNumber: 27
                                }, this),
                                "Cheque Date"
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                lineNumber: 679,
                                columnNumber: 23
                              }, this),
                              name: "cheque_date",
                              rules: [
                                { required: true, message: "Please select the cheque date" }
                              ],
                              children: /* @__PURE__ */ jsxDEV(
                                DatePicker,
                                {
                                  style: { width: "100%", height: "46px" },
                                  format: "YYYY-MM-DD",
                                  placeholder: "Select cheque date",
                                  className: "rounded-lg hover:border-violet-400 focus:border-violet-500"
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                  lineNumber: 689,
                                  columnNumber: 23
                                },
                                this
                              )
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                              lineNumber: 677,
                              columnNumber: 21
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV(
                            Form.Item,
                            {
                              label: /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-700 flex items-center gap-2", children: [
                                /* @__PURE__ */ jsxDEV(BankOutlined, { className: "text-gray-400" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                  lineNumber: 700,
                                  columnNumber: 27
                                }, this),
                                "Bank Name"
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                lineNumber: 699,
                                columnNumber: 23
                              }, this),
                              name: "cheque_bank_name",
                              rules: [
                                { required: true, message: "Please input the bank name" }
                              ],
                              children: /* @__PURE__ */ jsxDEV(
                                Input,
                                {
                                  placeholder: "Enter bank name",
                                  className: "rounded-lg h-[46px] hover:border-violet-400 focus:border-violet-500",
                                  prefix: /* @__PURE__ */ jsxDEV(BankOutlined, { className: "text-gray-400" }, void 0, false, {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                    lineNumber: 712,
                                    columnNumber: 33
                                  }, this)
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                  lineNumber: 709,
                                  columnNumber: 23
                                },
                                this
                              )
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                              lineNumber: 697,
                              columnNumber: 21
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV(
                            Form.Item,
                            {
                              label: /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-700 flex items-center gap-2", children: [
                                /* @__PURE__ */ jsxDEV(BankOutlined, { className: "text-gray-400" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                  lineNumber: 719,
                                  columnNumber: 27
                                }, this),
                                "Bank Branch"
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                lineNumber: 718,
                                columnNumber: 23
                              }, this),
                              name: "cheque_bank_branch",
                              rules: [
                                { required: true, message: "Please input the bank branch" }
                              ],
                              children: /* @__PURE__ */ jsxDEV(
                                Input,
                                {
                                  placeholder: "Enter branch name",
                                  className: "rounded-lg h-[46px] hover:border-violet-400 focus:border-violet-500",
                                  prefix: /* @__PURE__ */ jsxDEV(BankOutlined, { className: "text-gray-400" }, void 0, false, {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                    lineNumber: 731,
                                    columnNumber: 33
                                  }, this)
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                                  lineNumber: 728,
                                  columnNumber: 23
                                },
                                this
                              )
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                              lineNumber: 716,
                              columnNumber: 21
                            },
                            this
                          )
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                          lineNumber: 657,
                          columnNumber: 19
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                      lineNumber: 647,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3 mt-8 pt-6 border-t", children: [
                    /* @__PURE__ */ jsxDEV(
                      Button,
                      {
                        onClick: handleUpdateModalCancel,
                        size: "large",
                        className: "h-11 px-8 rounded-lg font-medium hover:bg-gray-100",
                        children: "Cancel"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                        lineNumber: 740,
                        columnNumber: 17
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Button,
                      {
                        type: "primary",
                        htmlType: "submit",
                        loading: updateLoading,
                        size: "large",
                        className: "h-11 px-8 rounded-lg font-medium bg-gradient-to-r from-violet-600 to-violet-700 hover:from-violet-700 hover:to-violet-800 border-0 shadow-lg",
                        icon: /* @__PURE__ */ jsxDEV(SafetyOutlined, {}, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                          lineNumber: 753,
                          columnNumber: 27
                        }, this),
                        children: "Update Payment"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                        lineNumber: 747,
                        columnNumber: 17
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                    lineNumber: 739,
                    columnNumber: 15
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
                lineNumber: 472,
                columnNumber: 13
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
              lineNumber: 471,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
            lineNumber: 453,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("style", { jsx: true, global: true, children: `
          .professional-modal .ant-modal-content {
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
          }

          .professional-select .ant-select-selector {
            height: 46px !important;
            padding: 8px 16px !important;
            border-radius: 8px !important;
            display: flex !important;
            align-items: center !important;
          }

          .professional-select .ant-select-selection-placeholder,
          .professional-select .ant-select-selection-item {
            line-height: 30px !important;
          }

          .ant-input-affix-wrapper {
            border-radius: 8px;
          }

          .ant-picker {
            border-radius: 8px;
          }

          .ant-card {
            border-radius: 12px;
          }
        ` }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
            lineNumber: 762,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
        lineNumber: 440,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 bg-red-100 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, { className: "text-red-600 text-xl" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
            lineNumber: 801,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
            lineNumber: 800,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: "Confirm Deletion" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
            lineNumber: 803,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
          lineNumber: 799,
          columnNumber: 11
        }, this),
        open: deleteModalVisible,
        onOk: handleConfirmDelete,
        onCancel: () => setDeleteModalVisible(false),
        okText: "Delete Payment",
        cancelText: "Cancel",
        okButtonProps: {
          danger: true,
          size: "large",
          className: "h-10 rounded-lg font-medium"
        },
        cancelButtonProps: {
          size: "large",
          className: "h-10 rounded-lg font-medium"
        },
        confirmLoading: deleteLoading,
        centered: true,
        width: 480,
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-4", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 text-base mb-3", children: "Are you sure you want to delete this payment record?" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
            lineNumber: 825,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-red-50 border border-red-200 rounded-lg p-4", children: /* @__PURE__ */ jsxDEV("p", { className: "text-red-700 text-sm font-medium flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
              lineNumber: 830,
              columnNumber: 15
            }, this),
            "This action cannot be undone."
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
            lineNumber: 829,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
            lineNumber: 828,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
          lineNumber: 824,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
        lineNumber: 797,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
    lineNumber: 336,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx",
    lineNumber: 335,
    columnNumber: 5
  }, this);
};
_s(SuspensePayments, "/P+REhgxfC36qwNhKbn4hCpSOrM=", false, function() {
  return [useSearchParams, Form.useForm, Form.useWatch];
});
_c = SuspensePayments;
export default SuspensePayments;
var _c;
$RefreshReg$(_c, "SuspensePayments");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/SuspensePayments.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK01VOzJCQS9NVjtBQUFnQkEsTUFBV0MsY0FBUSxPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2xELE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsTUFBTSxFQUFFQyxZQUFZLElBQUliO0FBQ3hCLE1BQU0sRUFBRWMsT0FBT0MsS0FBSyxJQUFJSjtBQUN4QixTQUFTSyxnQkFBZ0I7QUFDekIsU0FBU0MsTUFBTUMsdUJBQXVCO0FBQ3RDO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLDhCQUE4QjtBQUN2QyxPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLHVCQUF1QjtBQUM5QixPQUFPQyxnQkFBZ0I7QUFFdkIsTUFBTUMsbUJBQW1CQSxNQUFNO0FBQUFDLEtBQUE7QUFDN0IsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUl2QyxTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDd0MsUUFBUUMsU0FBUyxJQUFJekMsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQzBDLE1BQU1DLE9BQU8sSUFBSTNDLFNBQVMsS0FBSztBQUN0QyxRQUFNLENBQUM0QyxTQUFTQyxVQUFVLElBQUk3QyxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDOEMsY0FBY0MsZUFBZSxJQUFJeEIsZ0JBQWdCO0FBQ3hELFFBQU0sQ0FBQ3lCLFdBQVdDLFlBQVksSUFBSWpEO0FBQUFBLElBQ2hDOEMsYUFBYUksSUFBSSxZQUFZLEtBQUs7QUFBQSxFQUNwQztBQUNBLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJcEQsU0FBUzhDLGFBQWFJLElBQUksVUFBVSxLQUFLLEVBQUU7QUFDekUsUUFBTSxDQUFDRyxPQUFPQyxRQUFRLElBQUl0RCxTQUFTOEMsYUFBYUksSUFBSSxVQUFVLENBQUM7QUFHL0QsUUFBTSxDQUFDSyxvQkFBb0JDLHFCQUFxQixJQUFJeEQsU0FBUyxLQUFLO0FBQ2xFLFFBQU0sQ0FBQ3lELGtCQUFrQkMsbUJBQW1CLElBQUkxRCxTQUFTLElBQUk7QUFDN0QsUUFBTSxDQUFDMkQsVUFBVSxJQUFJL0MsS0FBS2dELFFBQVE7QUFDbEMsUUFBTSxDQUFDQyxlQUFlQyxnQkFBZ0IsSUFBSTlELFNBQVMsS0FBSztBQUd4RCxRQUFNLENBQUMrRCxvQkFBb0JDLHFCQUFxQixJQUFJaEUsU0FBUyxLQUFLO0FBQ2xFLFFBQU0sQ0FBQ2lFLG1CQUFtQkMsb0JBQW9CLElBQUlsRSxTQUFTLElBQUk7QUFDL0QsUUFBTSxDQUFDbUUsZUFBZUMsZ0JBQWdCLElBQUlwRSxTQUFTLEtBQUs7QUFDekQsUUFBTSxDQUFDcUUsYUFBYUMsY0FBYyxJQUFJdEUsU0FBUztBQUFBLElBQzVDdUUsWUFBWTtBQUFBLElBQ1p4RCxTQUFTO0FBQUEsSUFDVHlELE1BQU07QUFBQSxFQUNSLENBQUM7QUFFRCxRQUFNQyxVQUFVN0QsS0FBSzhELFNBQVMsWUFBWWYsVUFBVTtBQUVwRCxRQUFNZ0Isc0JBQXNCQSxNQUFNO0FBQ2hDaEMsWUFBUSxJQUFJO0FBQUEsRUFDZDtBQUNBLFFBQU1pQyw4QkFBOEJBLENBQUNDLE1BQU07QUFDekNDLGtCQUFjRCxFQUFFRSxPQUFPQyxLQUFLO0FBQzVCQyxtQkFBZSxDQUFDO0FBQ2hCQywwQkFBc0IsQ0FBQztBQUFBLEVBQ3pCO0FBQ0EsUUFBTUMsd0JBQXdCLE9BQU9DLGNBQWM7QUFDakQxQix3QkFBb0IwQixTQUFTO0FBQzdCNUIsMEJBQXNCLElBQUk7QUFDMUIsUUFBSTtBQUNGTSx1QkFBaUIsSUFBSTtBQUNyQixZQUFNdUIsV0FBVyxNQUFNbEYsSUFBSStDLElBQUksWUFBWWtDLFNBQVMsRUFBRTtBQUN0RCxZQUFNRSxVQUFVRCxTQUFTRSxLQUFLQTtBQUU5QjVCLGlCQUFXNkIsZUFBZTtBQUFBLFFBQ3hCQyxVQUFVSCxRQUFRRyxXQUFXeEQsTUFBTXFELFFBQVFHLFFBQVEsSUFBSTtBQUFBLFFBQ3ZEQyxRQUFRSixRQUFRSTtBQUFBQSxRQUNoQkMsVUFBVUwsUUFBUUs7QUFBQUEsUUFDbEJDLGNBQWNOLFFBQVFNO0FBQUFBLFFBQ3RCQyxnQkFBZ0JQLFFBQVFPO0FBQUFBLFFBQ3hCQyxTQUFTUixRQUFRUTtBQUFBQSxRQUNqQkMsZUFBZVQsUUFBUVM7QUFBQUEsUUFDdkJDLGFBQWFWLFFBQVFVLGNBQWMvRCxNQUFNcUQsUUFBUVUsV0FBVyxJQUFJO0FBQUEsUUFDaEVDLGtCQUFrQlgsUUFBUVc7QUFBQUEsUUFDMUJDLG9CQUFvQlosUUFBUVk7QUFBQUEsTUFDOUIsQ0FBQztBQUFBLElBQ0gsU0FBU0MsT0FBTztBQUNkcEYsY0FBUW9GLE1BQU0saUNBQWlDO0FBQUEsSUFDakQsVUFBQztBQUNDckMsdUJBQWlCLEtBQUs7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNc0Msc0JBQXNCLE9BQU9DLFdBQVc7QUFDNUMsUUFBSTtBQUNGdkMsdUJBQWlCLElBQUk7QUFDckIsVUFBSXdDLGtCQUFrQjtBQUFBLFFBQ3BCLEdBQUdEO0FBQUFBLFFBQ0haLFVBQVVZLE9BQU9aLFdBQVdZLE9BQU9aLFNBQVNjLE9BQU8sWUFBWSxJQUFJO0FBQUEsUUFDbkVQLGFBQWFLLE9BQU9MLGNBQWNLLE9BQU9MLFlBQVlPLE9BQU8sWUFBWSxJQUFJO0FBQUEsTUFDOUU7QUFHQSxVQUFJRCxnQkFBZ0JYLGFBQWEsUUFBUTtBQUN2Q1csd0JBQWdCVCxpQkFBaUI7QUFDakNTLHdCQUFnQlAsZ0JBQWdCO0FBQ2hDTyx3QkFBZ0JOLGNBQWM7QUFDOUJNLHdCQUFnQkwsbUJBQW1CO0FBQ25DSyx3QkFBZ0JKLHFCQUFxQjtBQUFBLE1BQ3ZDLFdBQVdJLGdCQUFnQlgsYUFBYSxVQUFVO0FBQ2hEVyx3QkFBZ0JQLGdCQUFnQjtBQUNoQ08sd0JBQWdCTixjQUFjO0FBQzlCTSx3QkFBZ0JMLG1CQUFtQjtBQUNuQ0ssd0JBQWdCSixxQkFBcUI7QUFBQSxNQUN2QyxXQUFXSSxnQkFBZ0JYLGFBQWEsVUFBVTtBQUNoRFcsd0JBQWdCVCxpQkFBaUI7QUFBQSxNQUNuQztBQUVBLFlBQU0xRixJQUFJcUcsSUFBSSxZQUFZL0MsZ0JBQWdCLElBQUk2QyxlQUFlO0FBQzdEdkYsY0FBUTBGLFFBQVEsOEJBQThCO0FBQzlDakQsNEJBQXNCLEtBQUs7QUFDM0JHLGlCQUFXK0MsWUFBWTtBQUN2QkMsa0JBQVk7QUFBQSxJQUNkLFNBQVNSLE9BQU87QUFDZHBGLGNBQVFvRixNQUFNLDBCQUEwQjtBQUFBLElBQzFDLFVBQUM7QUFDQ3JDLHVCQUFpQixLQUFLO0FBQUEsSUFDeEI7QUFBQSxFQUNGO0FBRUEsUUFBTThDLDBCQUEwQkEsTUFBTTtBQUNwQ3BELDBCQUFzQixLQUFLO0FBQzNCRyxlQUFXK0MsWUFBWTtBQUFBLEVBQ3pCO0FBR0EsUUFBTUcsd0JBQXdCQSxDQUFDekIsY0FBYztBQUMzQ2xCLHlCQUFxQmtCLFNBQVM7QUFDOUJwQiwwQkFBc0IsSUFBSTtBQUFBLEVBQzVCO0FBR0EsUUFBTThDLHNCQUFzQixZQUFZO0FBQ3RDLFFBQUk7QUFDRjFDLHVCQUFpQixJQUFJO0FBQ3JCLFlBQU1qRSxJQUFJNEcsT0FBTyxXQUFXOUMsaUJBQWlCLEVBQUU7QUFDL0NsRCxjQUFRMEYsUUFBUSwrQkFBK0I7QUFDL0N6Qyw0QkFBc0IsS0FBSztBQUMzQkUsMkJBQXFCLElBQUk7QUFDekJ5QyxrQkFBWTtBQUFBLElBQ2QsU0FBU1IsT0FBTztBQUNkcEYsY0FBUW9GLE1BQU0sMEJBQTBCO0FBQUEsSUFDMUMsVUFBQztBQUNDL0IsdUJBQWlCLEtBQUs7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFHQSxRQUFNNEMseUJBQXlCQSxDQUFDQyxrQkFBa0I7QUFFaEQsUUFBSUEsY0FBY3RCLFVBQVU7QUFDMUIsWUFBTXVCLGFBQWFELGNBQWN0QjtBQUNqQyxVQUFJd0IsZ0JBQWdCLENBQUM7QUFHckIsVUFBSUQsZUFBZSxRQUFRO0FBQ3pCQyx3QkFBZ0I7QUFBQSxVQUNkdEIsZ0JBQWdCO0FBQUEsVUFDaEJFLGVBQWU7QUFBQSxVQUNmQyxhQUFhO0FBQUEsVUFDYkMsa0JBQWtCO0FBQUEsVUFDbEJDLG9CQUFvQjtBQUFBLFFBQ3RCO0FBQUEsTUFDRixXQUFXZ0IsZUFBZSxVQUFVO0FBQ2xDQyx3QkFBZ0I7QUFBQSxVQUNkcEIsZUFBZTtBQUFBLFVBQ2ZDLGFBQWE7QUFBQSxVQUNiQyxrQkFBa0I7QUFBQSxVQUNsQkMsb0JBQW9CO0FBQUEsUUFDdEI7QUFBQSxNQUNGLFdBQVdnQixlQUFlLFVBQVU7QUFDbENDLHdCQUFnQjtBQUFBLFVBQ2R0QixnQkFBZ0I7QUFBQSxRQUNsQjtBQUFBLE1BQ0Y7QUFHQWxDLGlCQUFXNkIsZUFBZTJCLGFBQWE7QUFBQSxJQUN6QztBQUFBLEVBQ0Y7QUFFQSxRQUFNQyxnQkFBZ0JBLENBQUNDLGNBQWM7QUFDbkMsVUFBTUMsbUJBQW1CO0FBQUEsTUFDdkI7QUFBQSxRQUNFQyxLQUFLO0FBQUEsUUFDTEMsT0FDRSx1QkFBQyxRQUFLLElBQUksVUFBVUgsU0FBUyxJQUFJLFdBQVUsbUJBQWtCLHFCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxNQUVKO0FBQUEsTUFDQTtBQUFBLFFBQ0VFLEtBQUs7QUFBQSxRQUNMQyxPQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixTQUFTLE1BQU1yQyxzQkFBc0JrQyxTQUFTO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFGbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxNQUVKO0FBQUEsTUFDQTtBQUFBLFFBQ0VFLEtBQUs7QUFBQSxRQUNMQyxPQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixTQUFTLE1BQU1YLHNCQUFzQlEsU0FBUztBQUFBLFlBQUU7QUFBQTtBQUFBLFVBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsTUFFSjtBQUFBLElBQUM7QUFHSCxXQUFPQztBQUFBQSxFQUNUO0FBRUEsaUJBQWVYLGNBQWM7QUFDM0IsUUFBSTtBQUNGOUQsaUJBQVcsSUFBSTtBQUNmLFlBQU00RSxXQUFXLE1BQU10SCxJQUFJK0M7QUFBQUEsUUFDekIsOEJBQThCRyxLQUFLLGVBQWVMLFNBQVMsYUFBYUcsT0FBTztBQUFBLE1BQ2pGO0FBQ0EsWUFBTXVFLGVBQWVELFVBQVVsQyxNQUFNQSxLQUFLb0MsSUFBSSxDQUFDckMsU0FBU3NDLFdBQVc7QUFBQSxRQUNqRUwsS0FBS2pDLFNBQVN1QztBQUFBQSxRQUNkQyxZQUFZeEMsUUFBUXVDO0FBQUFBLFFBQ3BCRSxNQUFNSCxRQUFRO0FBQUEsUUFDZEksY0FBYzFDLFNBQVMyQyxTQUFTQztBQUFBQSxRQUNoQ0MsWUFBWTdDLFNBQVMyQyxTQUFTRztBQUFBQSxRQUM5QkMsZUFBZS9DLFNBQVMyQyxTQUFTSztBQUFBQSxRQUNqQ0MsV0FBV2pELFNBQVNrRCxZQUFZQztBQUFBQSxRQUNoQ0MsV0FBV3BELFNBQVNxRCxVQUFVQztBQUFBQSxRQUM5QkMsUUFBUXZELFNBQVN1RDtBQUFBQSxRQUNqQkMsV0FBV3hELFFBQVF5RDtBQUFBQSxRQUNuQnJELFFBQVFKLFFBQVFJO0FBQUFBLFFBQ2hCakIsU0FBU2EsUUFBUUs7QUFBQUEsUUFDakJxRCxTQUFTMUQsUUFBUUc7QUFBQUEsUUFDakJ3RCxpQkFBaUIzRCxRQUFRNEQsVUFBVUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLFFBQy9DQyxRQUNFLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUMsU0FBUyxDQUFDLE9BQU87QUFBQSxZQUNqQixNQUFNLEVBQUVDLE9BQU9qQyxjQUFjOUIsU0FBU3VDLEdBQUcsRUFBRTtBQUFBLFlBQzNDLFdBQVU7QUFBQSxZQUVWLGlDQUFDLFlBQVMsV0FBVSwwREFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEU7QUFBQTtBQUFBLFVBTHJFdkMsU0FBU3VDO0FBQUFBLFVBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLE1BRUosRUFBRTtBQUNGdEYsc0JBQWdCbUYsWUFBWTtBQUFBLElBQzlCLFNBQVN2QixPQUFPO0FBQ2Q1RCxzQkFBZ0IsRUFBRTtBQUFBLElBQ3BCLFVBQUM7QUFDQ00saUJBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUVBLGlCQUFleUcsWUFBWTtBQUN6QixRQUFJO0FBQ0YsWUFBTWpFLFdBQVcsTUFBTWxGLElBQUkrQyxJQUFJLHdCQUF3QjtBQUN2RCxZQUFNcUcsaUJBQWlCbEUsVUFBVUUsTUFBTW9DLElBQUksQ0FBQ3RFLFlBQVc7QUFBQSxRQUNyRDJCLE9BQU8zQixRQUFPd0U7QUFBQUEsUUFDZEwsT0FBT25FLFFBQU91RjtBQUFBQSxNQUNoQixFQUFFO0FBQ0ZuRyxnQkFBVThHLGNBQWM7QUFBQSxJQUMxQixTQUFTcEQsT0FBTztBQUNkMUQsZ0JBQVUsRUFBRTtBQUFBLElBQ2Q7QUFBQSxFQUNGO0FBRUExQyxZQUFVLE1BQU07QUFDZDRHLGdCQUFZO0FBQUEsRUFDZCxHQUFHLENBQUN0RCxPQUFPTCxXQUFXRyxPQUFPLENBQUM7QUFFOUJwRCxZQUFVLE1BQU07QUFDZHVKLGNBQVU7QUFBQSxFQUNaLEdBQUcsRUFBRTtBQUVMLFFBQU1FLG9CQUFvQkEsQ0FBQ0MsT0FBT0MsZ0JBQWdCO0FBQ2hELFFBQUlELE9BQU87QUFDVHhHLG1CQUFheUcsWUFBWSxDQUFDLENBQUM7QUFDM0J0RyxpQkFBV3NHLFlBQVksQ0FBQyxDQUFDO0FBQ3pCM0csc0JBQWdCO0FBQUEsUUFDZCxHQUFHNEcsT0FBT0MsWUFBWTlHLFlBQVk7QUFBQSxRQUNsQytHLFlBQVlILFlBQVksQ0FBQztBQUFBLFFBQ3pCSSxVQUFVSixZQUFZLENBQUM7QUFBQSxNQUN6QixDQUFDO0FBQUEsSUFDSCxPQUFPO0FBQ0x6RyxtQkFBYSxJQUFJO0FBQ2pCRyxpQkFBVyxJQUFJO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBRUEsUUFBTTJHLFVBQVU7QUFBQSxJQUNkLEVBQUV4QyxLQUFLLFFBQVF5QyxRQUFRLFFBQVE7QUFBQSxJQUMvQixFQUFFekMsS0FBSyxtQkFBbUJ5QyxRQUFRLG1CQUFtQjtBQUFBLElBQ3JELEVBQUV6QyxLQUFLLFdBQVd5QyxRQUFRLFdBQVc7QUFBQSxJQUNyQyxFQUFFekMsS0FBSyxnQkFBZ0J5QyxRQUFRLGdCQUFnQjtBQUFBLElBQy9DLEVBQUV6QyxLQUFLLGNBQWN5QyxRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFekMsS0FBSyxpQkFBaUJ5QyxRQUFRLGlCQUFpQjtBQUFBLElBQ2pELEVBQUV6QyxLQUFLLGFBQWF5QyxRQUFRLGFBQWE7QUFBQSxJQUN6QyxFQUFFekMsS0FBSyxVQUFVeUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRXpDLEtBQUssVUFBVXlDLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUV6QyxLQUFLLFdBQVd5QyxRQUFRLFdBQVc7QUFBQSxJQUNyQyxFQUFFekMsS0FBSyxhQUFheUMsUUFBUSxhQUFhO0FBQUEsSUFDekMsRUFBRXpDLEtBQUssYUFBYXlDLFFBQVEsYUFBYTtBQUFBLElBQ3pDLEVBQUV6QyxLQUFLLFVBQVV5QyxRQUFRLFVBQVU7QUFBQSxFQUFDO0FBR3RDLFNBQ0EsdUJBQUMsU0FBSSxXQUFVLDZDQUNULGlDQUFDLFNBQUksV0FBVSxRQUNoQjtBQUFBLDJCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFRO0FBQUEsSUFDUDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLFlBQVk7QUFBQTtBQUFBLE1BRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRW1CO0FBQUEsSUFFbkI7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU0zRixZQUFZRztBQUFBQSxRQUNsQixXQUFXSCxZQUFZRTtBQUFBQSxRQUN2QixTQUFTRixZQUFZdEQ7QUFBQUEsUUFDckIsU0FBUyxNQUFNdUQsZUFBZSxDQUFDMkYsVUFBVSxFQUFFLEdBQUdBLE1BQU0xRixZQUFZLE1BQU0sRUFBRTtBQUFBO0FBQUEsTUFKMUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSTRFO0FBQUEsSUFFOUUsdUJBQUMsVUFBSyxXQUFVLDhDQUNkO0FBQUEsNkJBQUMsU0FBSSxXQUFVLFFBQ0U7QUFBQSwrQkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVc7QUFBQSxRQUMxQix1QkFBQyxRQUFHLFdBQVUseUNBQXdDLGlDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSxpQkFBZ0IseURBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsaUVBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsNENBQTJDLHVCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdFO0FBQUEsUUFDaEUsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDBDQUF5QywwQkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxVQUFVaUY7QUFBQUEsZ0JBQ1YsV0FBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQSxnQkFDTCxhQUFhLENBQUMsY0FBYyxVQUFVO0FBQUE7QUFBQSxjQUp4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJMEM7QUFBQSxlQVI1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsMENBQXlDLHFCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDO0FBQUEsZ0JBQ0EsTUFBSztBQUFBLGdCQUNMLE9BQU8sRUFBRVUsT0FBTyxJQUFJO0FBQUEsZ0JBQ3BCLGFBQVk7QUFBQSxnQkFDWixrQkFBaUI7QUFBQSxnQkFDakIsWUFBWSxDQUFDQyxTQUFTQyxhQUNuQkQsU0FBUzNDLFNBQVMsSUFDaEI2QyxZQUFZLEVBQ1pDLGVBQWVGLFNBQVM1QyxTQUFTLElBQUk2QyxZQUFZLENBQUM7QUFBQSxnQkFFdkQsT0FBT2hIO0FBQUFBLGdCQUNQLFNBQVNiO0FBQUFBLGdCQUNULFVBQVUsQ0FBQ3dDLFVBQVU7QUFDbkJqQyxrQ0FBZ0I7QUFBQSxvQkFDZCxHQUFHNEcsT0FBT0MsWUFBWTlHLFlBQVk7QUFBQSxvQkFDbEM2RixVQUFVM0Q7QUFBQUEsa0JBQ1osQ0FBQztBQUNEMUIsMkJBQVMwQixLQUFLO0FBQUEsZ0JBQ2hCO0FBQUEsZ0JBQ0EsWUFBVTtBQUFBO0FBQUEsY0FwQlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBb0JZO0FBQUEsZUF4QmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwQkE7QUFBQSxhQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUNBO0FBQUEsV0F6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBDQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDREQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHVDQUFzQywrQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUF3QjtBQUFBO0FBQUEsWUFDdEI7QUFBQSxZQUNmLHVCQUFDLFVBQUssV0FBVSxpQkFBaUIxQyx1QkFBYWlJLFVBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFEO0FBQUEsZUFGdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFFQzNILFVBQ0MsdUJBQUMsU0FBSSxXQUFVLGdEQUNiLGlDQUFDLFFBQUssV0FBVyx1QkFBQyxtQkFBZ0IsTUFBSSxRQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFCLEdBQUssTUFBSyxXQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVELEtBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUNFTixhQUFhaUksU0FBUyxJQUNkLHVCQUFDLGFBQVUsU0FBa0IsTUFBTWpJLGNBQWMsa0JBQWlCLHdCQUF1QixpQkFBZ0Isc0JBQXpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkgsSUFHckksdUJBQUMsU0FBTSxhQUFZLDhCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDO0FBQUEsV0FuQmpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxTQTdFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEVBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTTtBQUFBLFFBQ04sV0FBVTtBQUFBLFFBQ1YsU0FBUyxNQUFNSyxRQUFRLEtBQUs7QUFBQSxRQUM1QjtBQUFBLFFBQ0EsT0FBTztBQUFBLFFBRVAsaUNBQUMsT0FBRSw0REFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStDO0FBQUE7QUFBQSxNQVBqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFRQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU1ZO0FBQUFBLFFBQ04sVUFBVXFEO0FBQUFBLFFBQ1YsUUFBUTtBQUFBLFFBQ1IsT0FBTztBQUFBLFFBQ1A7QUFBQSxRQUNBO0FBQUEsUUFDQSxXQUFVO0FBQUEsUUFDVixRQUFRO0FBQUEsVUFDTjRELE1BQU0sRUFBRUMsU0FBUyxFQUFFO0FBQUEsVUFDbkJULFFBQVEsRUFBRVUsU0FBUyxPQUFPO0FBQUEsUUFDNUI7QUFBQSxRQUVBO0FBQUEsaUNBQUMsU0FBSSxXQUFVLCtEQUViO0FBQUEsbUNBQUMsU0FBSSxXQUFVLFFBQ2IsaUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLG1IQUNiLGlDQUFDLHNCQUFtQixXQUFVLHlCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRCxLQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsU0FBTSxPQUFPLEdBQUcsV0FBVSx3QkFBdUIsc0NBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxRQUFLLFdBQVUseUJBQXdCLGtFQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGlCQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWUEsS0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWNBO0FBQUEsWUFFQSx1QkFBQyxRQUFLLFVBQVU3RyxlQUFlLE1BQUssU0FDbEM7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFNRjtBQUFBQSxnQkFDTixRQUFPO0FBQUEsZ0JBQ1AsVUFBVXlDO0FBQUFBLGdCQUNWLFdBQVU7QUFBQSxnQkFDVixnQkFBZ0JZO0FBQUFBLGdCQUdoQjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixRQUFRLEVBQUV3RCxNQUFNLEVBQUVDLFNBQVMsT0FBTyxFQUFFO0FBQUEsc0JBRXBDO0FBQUEsK0NBQUMsU0FBSSxXQUFVLGdDQUNiLGlDQUFDLFNBQU0sT0FBTyxHQUFHLFdBQVUsd0JBQXVCLG1DQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFJQTtBQUFBLHdCQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBO0FBQUEsNEJBQUMsS0FBSztBQUFBLDRCQUFMO0FBQUEsOEJBQ0MsT0FDRSx1QkFBQyxVQUFLLFdBQVUsK0RBQ2Q7QUFBQSx1REFBQyxvQkFBaUIsV0FBVSxtQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FBMkM7QUFBQSxnQ0FBRztBQUFBLG1DQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUdBO0FBQUEsOEJBRUYsTUFBSztBQUFBLDhCQUNMLE9BQU87QUFBQSxnQ0FDTCxFQUFFRSxVQUFVLE1BQU01SixTQUFTLGlDQUFpQztBQUFBLDhCQUFDO0FBQUEsOEJBRy9EO0FBQUEsZ0NBQUM7QUFBQTtBQUFBLGtDQUNDLE9BQU8sRUFBRW1KLE9BQU8sUUFBUVUsUUFBUSxPQUFPO0FBQUEsa0NBQ3ZDLFFBQU87QUFBQSxrQ0FDUCxhQUFZO0FBQUEsa0NBQ1osV0FBVTtBQUFBO0FBQUEsZ0NBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQUl3RTtBQUFBO0FBQUEsNEJBaEIxRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBa0JBO0FBQUEsMEJBRUE7QUFBQSw0QkFBQyxLQUFLO0FBQUEsNEJBQUw7QUFBQSw4QkFDQyxPQUNFLHVCQUFDLFVBQUssV0FBVSwrREFDZDtBQUFBLHVEQUFDLDBCQUF1QixXQUFVLG1CQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUFpRDtBQUFBLGdDQUFHO0FBQUEsbUNBRHREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBR0E7QUFBQSw4QkFFRixNQUFLO0FBQUEsOEJBQ0wsT0FBTztBQUFBLGdDQUNMLEVBQUVELFVBQVUsTUFBTTVKLFNBQVMsMEJBQTBCO0FBQUEsZ0NBQ3JEO0FBQUEsa0NBQ0U4SixTQUFTO0FBQUEsa0NBQ1Q5SixTQUFTO0FBQUEsZ0NBQ1g7QUFBQSw4QkFBQztBQUFBLDhCQUdIO0FBQUEsZ0NBQUM7QUFBQTtBQUFBLGtDQUNDLE1BQUs7QUFBQSxrQ0FDTCxRQUFPO0FBQUEsa0NBQ1AsYUFBWTtBQUFBLGtDQUNaLFdBQVU7QUFBQSxrQ0FDVixPQUFPLEVBQUUrSixVQUFVLE9BQU87QUFBQTtBQUFBLGdDQUw1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBSzhCO0FBQUE7QUFBQSw0QkFyQmhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkF1QkE7QUFBQSw2QkE1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkE2Q0E7QUFBQTtBQUFBO0FBQUEsb0JBdkRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkF3REE7QUFBQSxrQkFHQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsUUFBUSxFQUFFTixNQUFNLEVBQUVDLFNBQVMsT0FBTyxFQUFFO0FBQUEsc0JBRXBDO0FBQUEsK0NBQUMsU0FBSSxXQUFVLGdDQUNiLGlDQUFDLFNBQU0sT0FBTyxHQUFHLFdBQVUsd0JBQXVCLDhCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFJQTtBQUFBLHdCQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBO0FBQUEsNEJBQUMsS0FBSztBQUFBLDRCQUFMO0FBQUEsOEJBQ0MsT0FDRSx1QkFBQyxVQUFLLFdBQVUsK0RBQ2Q7QUFBQSx1REFBQyxzQkFBbUIsV0FBVSxtQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FBNkM7QUFBQSxnQ0FBRztBQUFBLG1DQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUdBO0FBQUEsOEJBRUYsTUFBSztBQUFBLDhCQUNMLE9BQU87QUFBQSxnQ0FDTCxFQUFFRSxVQUFVLE1BQU01SixTQUFTLCtCQUErQjtBQUFBLDhCQUFDO0FBQUEsOEJBRzdEO0FBQUEsZ0NBQUM7QUFBQTtBQUFBLGtDQUNDLGFBQVk7QUFBQSxrQ0FDWixNQUFLO0FBQUEsa0NBQ0wsV0FBVTtBQUFBLGtDQUNWLFlBQVksdUJBQUMsc0JBQW1CLFdBQVUsbUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUNBQTZDO0FBQUEsa0NBRXpEO0FBQUEsMkRBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxRQUNuQixpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSw2REFBQywwQkFBdUIsV0FBVSxvQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2Q0FBa0Q7QUFBQSxzQ0FDbEQsdUJBQUMsVUFBSyw0QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZDQUFrQjtBQUFBLHlDQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJDQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQ0FLQTtBQUFBLG9DQUNBLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sVUFDbkIsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsNkRBQUMsb0JBQWlCLFdBQVUscUJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkNBQTZDO0FBQUEsc0NBQzdDLHVCQUFDLFVBQUssOEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSw2Q0FBb0I7QUFBQSx5Q0FGdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQ0FHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkNBS0E7QUFBQSxvQ0FDQSx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFVBQ25CLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDZEQUFDLGdCQUFhLFdBQVUscUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkNBQXlDO0FBQUEsc0NBQ3pDLHVCQUFDLFVBQUssK0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSw2Q0FBcUI7QUFBQSx5Q0FGdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQ0FHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkNBS0E7QUFBQTtBQUFBO0FBQUEsZ0NBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkF3QkE7QUFBQTtBQUFBLDRCQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBcUNBO0FBQUEsMEJBRUE7QUFBQSw0QkFBQyxLQUFLO0FBQUEsNEJBQUw7QUFBQSw4QkFDQyxPQUNFLHVCQUFDLFVBQUssV0FBVSwrREFDZDtBQUFBLHVEQUFDLGdCQUFhLFdBQVUsbUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBQXVDO0FBQUEsZ0NBQUc7QUFBQSxtQ0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FHQTtBQUFBLDhCQUVGLE1BQUs7QUFBQSw4QkFDTCxPQUFPO0FBQUEsZ0NBQ0wsRUFBRTRKLFVBQVUsTUFBTTVKLFNBQVMsZ0NBQWdDO0FBQUEsOEJBQUM7QUFBQSw4QkFHOUQ7QUFBQSxnQ0FBQztBQUFBO0FBQUEsa0NBQ0MsYUFBWTtBQUFBLGtDQUNaLE1BQUs7QUFBQSxrQ0FDTCxXQUFVO0FBQUEsa0NBQ1YsWUFBWSx1QkFBQyxnQkFBYSxXQUFVLG1CQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQUF1QztBQUFBLGtDQUVuRDtBQUFBLDJEQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sWUFBVyx3QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQ0FBd0M7QUFBQSxvQ0FDeEMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxTQUFRLHFCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJDQUFrQztBQUFBO0FBQUE7QUFBQSxnQ0FQcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQVFBO0FBQUE7QUFBQSw0QkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQXFCQTtBQUFBLDZCQTdERjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQThEQTtBQUFBO0FBQUE7QUFBQSxvQkF4RUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQXlFQTtBQUFBLGtCQUdDMEQsWUFBWSxZQUNYO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixRQUFRLEVBQUUrRixNQUFNLEVBQUVDLFNBQVMsT0FBTyxFQUFFO0FBQUEsc0JBRXBDO0FBQUEsK0NBQUMsU0FBSSxXQUFVLGdDQUNiLGlDQUFDLFNBQU0sT0FBTyxHQUFHLFdBQVUsd0JBQXVCLDBDQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFJQTtBQUFBLHdCQUVBO0FBQUEsMEJBQUMsS0FBSztBQUFBLDBCQUFMO0FBQUEsNEJBQ0MsT0FDRSx1QkFBQyxVQUFLLFdBQVUsK0RBQThELDhCQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUVBO0FBQUEsNEJBRUYsTUFBSztBQUFBLDRCQUNMLE9BQU87QUFBQSw4QkFDTCxFQUFFRSxVQUFVLE1BQU01SixTQUFTLGtDQUFrQztBQUFBLDRCQUFDO0FBQUEsNEJBR2hFO0FBQUEsOEJBQUM7QUFBQTtBQUFBLGdDQUNDLGFBQVk7QUFBQSxnQ0FDWixXQUFVO0FBQUEsZ0NBQ1YsUUFBUSx1QkFBQyxrQkFBZSxXQUFVLG1CQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUF5QztBQUFBO0FBQUEsOEJBSG5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFHdUQ7QUFBQTtBQUFBLDBCQWR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBZ0JBO0FBQUE7QUFBQTtBQUFBLG9CQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBMkJBO0FBQUEsa0JBR0QwRCxZQUFZLFlBQ1g7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFFBQVEsRUFBRStGLE1BQU0sRUFBRUMsU0FBUyxPQUFPLEVBQUU7QUFBQSxzQkFFcEM7QUFBQSwrQ0FBQyxTQUFJLFdBQVUsZ0NBQ2IsaUNBQUMsU0FBTSxPQUFPLEdBQUcsV0FBVSx3QkFBdUIsOEJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUlBO0FBQUEsd0JBRUEsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUE7QUFBQSw0QkFBQyxLQUFLO0FBQUEsNEJBQUw7QUFBQSw4QkFDQyxPQUNFLHVCQUFDLFVBQUssV0FBVSwrREFDZDtBQUFBLHVEQUFDLG9CQUFpQixXQUFVLG1CQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUEyQztBQUFBLGdDQUFHO0FBQUEsbUNBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBR0E7QUFBQSw4QkFFRixNQUFLO0FBQUEsOEJBQ0wsT0FBTztBQUFBLGdDQUNMLEVBQUVFLFVBQVUsTUFBTTVKLFNBQVMsaUNBQWlDO0FBQUEsOEJBQUM7QUFBQSw4QkFHL0Q7QUFBQSxnQ0FBQztBQUFBO0FBQUEsa0NBQ0MsYUFBWTtBQUFBLGtDQUNaLFdBQVU7QUFBQSxrQ0FDVixRQUFRLHVCQUFDLG9CQUFpQixXQUFVLG1CQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQUEyQztBQUFBO0FBQUEsZ0NBSHJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFHeUQ7QUFBQTtBQUFBLDRCQWYzRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBaUJBO0FBQUEsMEJBRUE7QUFBQSw0QkFBQyxLQUFLO0FBQUEsNEJBQUw7QUFBQSw4QkFDQyxPQUNFLHVCQUFDLFVBQUssV0FBVSwrREFDZDtBQUFBLHVEQUFDLG9CQUFpQixXQUFVLG1CQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUEyQztBQUFBLGdDQUFHO0FBQUEsbUNBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBR0E7QUFBQSw4QkFFRixNQUFLO0FBQUEsOEJBQ0wsT0FBTztBQUFBLGdDQUNMLEVBQUU0SixVQUFVLE1BQU01SixTQUFTLGdDQUFnQztBQUFBLDhCQUFDO0FBQUEsOEJBRzlEO0FBQUEsZ0NBQUM7QUFBQTtBQUFBLGtDQUNDLE9BQU8sRUFBRW1KLE9BQU8sUUFBUVUsUUFBUSxPQUFPO0FBQUEsa0NBQ3ZDLFFBQU87QUFBQSxrQ0FDUCxhQUFZO0FBQUEsa0NBQ1osV0FBVTtBQUFBO0FBQUEsZ0NBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQUl3RTtBQUFBO0FBQUEsNEJBaEIxRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBa0JBO0FBQUEsMEJBRUE7QUFBQSw0QkFBQyxLQUFLO0FBQUEsNEJBQUw7QUFBQSw4QkFDQyxPQUNFLHVCQUFDLFVBQUssV0FBVSwrREFDZDtBQUFBLHVEQUFDLGdCQUFhLFdBQVUsbUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBQXVDO0FBQUEsZ0NBQUc7QUFBQSxtQ0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FHQTtBQUFBLDhCQUVGLE1BQUs7QUFBQSw4QkFDTCxPQUFPO0FBQUEsZ0NBQ0wsRUFBRUQsVUFBVSxNQUFNNUosU0FBUyw2QkFBNkI7QUFBQSw4QkFBQztBQUFBLDhCQUczRDtBQUFBLGdDQUFDO0FBQUE7QUFBQSxrQ0FDQyxhQUFZO0FBQUEsa0NBQ1osV0FBVTtBQUFBLGtDQUNWLFFBQVEsdUJBQUMsZ0JBQWEsV0FBVSxtQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5Q0FBdUM7QUFBQTtBQUFBLGdDQUhqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBR3FEO0FBQUE7QUFBQSw0QkFmdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQWlCQTtBQUFBLDBCQUVBO0FBQUEsNEJBQUMsS0FBSztBQUFBLDRCQUFMO0FBQUEsOEJBQ0MsT0FDRSx1QkFBQyxVQUFLLFdBQVUsK0RBQ2Q7QUFBQSx1REFBQyxnQkFBYSxXQUFVLG1CQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUF1QztBQUFBLGdDQUFHO0FBQUEsbUNBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBR0E7QUFBQSw4QkFFRixNQUFLO0FBQUEsOEJBQ0wsT0FBTztBQUFBLGdDQUNMLEVBQUU0SixVQUFVLE1BQU01SixTQUFTLCtCQUErQjtBQUFBLDhCQUFDO0FBQUEsOEJBRzdEO0FBQUEsZ0NBQUM7QUFBQTtBQUFBLGtDQUNDLGFBQVk7QUFBQSxrQ0FDWixXQUFVO0FBQUEsa0NBQ1YsUUFBUSx1QkFBQyxnQkFBYSxXQUFVLG1CQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlDQUF1QztBQUFBO0FBQUEsZ0NBSGpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFHcUQ7QUFBQTtBQUFBLDRCQWZ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBaUJBO0FBQUEsNkJBNUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBNkVBO0FBQUE7QUFBQTtBQUFBLG9CQXZGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBd0ZBO0FBQUEsa0JBSUYsdUJBQUMsU0FBSSxXQUFVLDZDQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsU0FBUzZGO0FBQUFBLHdCQUNULE1BQUs7QUFBQSx3QkFDTCxXQUFVO0FBQUEsd0JBQW9EO0FBQUE7QUFBQSxzQkFIaEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1BO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLFVBQVM7QUFBQSx3QkFDVCxTQUFTL0M7QUFBQUEsd0JBQ1QsTUFBSztBQUFBLHdCQUNMLFdBQVU7QUFBQSx3QkFDVixNQUFNLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWU7QUFBQSx3QkFBSTtBQUFBO0FBQUEsc0JBTjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFTQTtBQUFBLHVCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWtCQTtBQUFBO0FBQUE7QUFBQSxjQTdSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUE4UkEsS0EvUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnU0E7QUFBQSxlQWxURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1UQTtBQUFBLFVBRUEsdUJBQUMsV0FBTSxLQUFHLE1BQUMsUUFBTSxNQUFFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkErQkU7QUFBQTtBQUFBO0FBQUEsTUFqV0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBa1dBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FDRSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsc0VBQ2IsaUNBQUMsNkJBQTBCLFdBQVUsMEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJELEtBRDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSx5QkFBd0IsZ0NBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdEO0FBQUEsYUFKMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFFRixNQUFNRTtBQUFBQSxRQUNOLE1BQU0rQztBQUFBQSxRQUNOLFVBQVUsTUFBTTlDLHNCQUFzQixLQUFLO0FBQUEsUUFDM0MsUUFBTztBQUFBLFFBQ1AsWUFBVztBQUFBLFFBQ1gsZUFBZTtBQUFBLFVBQ2IrRyxRQUFRO0FBQUEsVUFDUkMsTUFBTTtBQUFBLFVBQ05DLFdBQVc7QUFBQSxRQUNiO0FBQUEsUUFDQSxtQkFBbUI7QUFBQSxVQUNqQkQsTUFBTTtBQUFBLFVBQ05DLFdBQVc7QUFBQSxRQUNiO0FBQUEsUUFDQSxnQkFBZ0I5RztBQUFBQSxRQUNoQjtBQUFBLFFBQ0EsT0FBTztBQUFBLFFBRVAsaUNBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsZ0NBQStCLG9FQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsa0RBQ2IsaUNBQUMsT0FBRSxXQUFVLDREQUNYO0FBQUEsbUNBQUMsK0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEI7QUFBQSxZQUFHO0FBQUEsZUFEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxhQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBO0FBQUEsTUFyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBc0NBO0FBQUEsT0FuZkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9mSixLQXJmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc2ZFO0FBRUo7QUFBRTlCLEdBL3hCSUQsa0JBQWdCO0FBQUEsVUFLb0JiLGlCQVVuQlgsS0FBS2dELFNBYVZoRCxLQUFLOEQsUUFBUTtBQUFBO0FBQUF3RyxLQTVCekI5STtBQWl5Qk4sZUFBZUE7QUFBaUIsSUFBQThJO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIk5hdmJhciIsIlNpZGViYXIiLCJBUEkiLCJEYXRhVGFibGUiLCJEYXRlUGlja2VyIiwiU2VsZWN0IiwiRHJvcGRvd24iLCJEcmF3ZXIiLCJFbXB0eSIsIlNwaW4iLCJNb2RhbCIsIkZvcm0iLCJJbnB1dCIsIkJ1dHRvbiIsIm1lc3NhZ2UiLCJUeXBvZ3JhcGh5IiwiQ2FyZCIsIlJhbmdlUGlja2VyIiwiVGl0bGUiLCJUZXh0IiwiSW9NZE1vcmUiLCJMaW5rIiwidXNlU2VhcmNoUGFyYW1zIiwiTG9hZGluZ091dGxpbmVkIiwiRXhjbGFtYXRpb25DaXJjbGVPdXRsaW5lZCIsIkNhbGVuZGFyT3V0bGluZWQiLCJEb2xsYXJPdXRsaW5lZCIsIkNyZWRpdENhcmRPdXRsaW5lZCIsIkJhbmtPdXRsaW5lZCIsIlNhZmV0eU91dGxpbmVkIiwiRmlsZVRleHRPdXRsaW5lZCIsIlJpTW9uZXlSdXBlZUNpcmNsZUZpbGwiLCJkYXlqcyIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwiQnJlYWRjcnVtYiIsIlN1c3BlbnNlUGF5bWVudHMiLCJfcyIsInBheW1lbnRzRGF0YSIsInNldFBheW1lbnRzRGF0YSIsImdyb3VwcyIsInNldEdyb3VwcyIsIm9wZW4iLCJzZXRPcGVuIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzZWFyY2hQYXJhbXMiLCJzZXRTZWFyY2hQYXJhbXMiLCJzdGFydERhdGUiLCJzZXRTdGFydERhdGUiLCJnZXQiLCJlbmREYXRlIiwic2V0RW5kRGF0ZSIsImdyb3VwIiwic2V0R3JvdXAiLCJ1cGRhdGVNb2RhbFZpc2libGUiLCJzZXRVcGRhdGVNb2RhbFZpc2libGUiLCJjdXJyZW50UGF5bWVudElkIiwic2V0Q3VycmVudFBheW1lbnRJZCIsInVwZGF0ZUZvcm0iLCJ1c2VGb3JtIiwidXBkYXRlTG9hZGluZyIsInNldFVwZGF0ZUxvYWRpbmciLCJkZWxldGVNb2RhbFZpc2libGUiLCJzZXREZWxldGVNb2RhbFZpc2libGUiLCJwYXltZW50SWRUb0RlbGV0ZSIsInNldFBheW1lbnRJZFRvRGVsZXRlIiwiZGVsZXRlTG9hZGluZyIsInNldERlbGV0ZUxvYWRpbmciLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsInR5cGUiLCJwYXlUeXBlIiwidXNlV2F0Y2giLCJoYW5kbGVWaWV3TW9kYWxPcGVuIiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInNldFNlYXJjaFRleHQiLCJ0YXJnZXQiLCJ2YWx1ZSIsInNldEN1cnJlbnRQYWdlIiwic2V0Q3VycmVudFBhZ2VSZWxhdGVkIiwiaGFuZGxlVXBkYXRlTW9kYWxPcGVuIiwicGF5bWVudElkIiwicmVzcG9uc2UiLCJwYXltZW50IiwiZGF0YSIsInNldEZpZWxkc1ZhbHVlIiwicGF5X2RhdGUiLCJhbW91bnQiLCJwYXlfdHlwZSIsImFjY291bnRfdHlwZSIsInRyYW5zYWN0aW9uX2lkIiwicGF5X2ZvciIsImNoZXF1ZV9udW1iZXIiLCJjaGVxdWVfZGF0ZSIsImNoZXF1ZV9iYW5rX25hbWUiLCJjaGVxdWVfYmFua19icmFuY2giLCJlcnJvciIsImhhbmRsZVVwZGF0ZVBheW1lbnQiLCJ2YWx1ZXMiLCJmb3JtYXR0ZWRWYWx1ZXMiLCJmb3JtYXQiLCJwdXQiLCJzdWNjZXNzIiwicmVzZXRGaWVsZHMiLCJnZXRQYXltZW50cyIsImhhbmRsZVVwZGF0ZU1vZGFsQ2FuY2VsIiwiaGFuZGxlRGVsZXRlTW9kYWxPcGVuIiwiaGFuZGxlQ29uZmlybURlbGV0ZSIsImRlbGV0ZSIsImhhbmRsZUZvcm1WYWx1ZXNDaGFuZ2UiLCJjaGFuZ2VkVmFsdWVzIiwibmV3UGF5VHlwZSIsImZpZWxkc1RvQ2xlYXIiLCJkcm9wRG93bkl0ZW1zIiwicGF5bWVudElEIiwiZHJvcERvd25JdGVtTGlzdCIsImtleSIsImxhYmVsIiwicGF5bWVudHMiLCJyZXNwb25zZURhdGEiLCJtYXAiLCJpbmRleCIsIl9pZCIsInBheW1lbnRfaWQiLCJzbE5vIiwiY3VzdG9tZXJOYW1lIiwidXNlcl9pZCIsImZ1bGxfbmFtZSIsImN1c3RvbWVySWQiLCJjdXN0b21lcl9pZCIsImN1c3RvbWVyUGhvbmUiLCJwaG9uZV9udW1iZXIiLCJhZG1pblR5cGUiLCJhZG1pbl90eXBlIiwiYWRtaW5fbmFtZSIsImdyb3VwTmFtZSIsImdyb3VwX2lkIiwiZ3JvdXBfbmFtZSIsInRpY2tldCIsInJlY2VpcHRObyIsInJlY2VpcHRfbm8iLCJwYXlEYXRlIiwidHJhbnNhY3Rpb25EYXRlIiwiY3JlYXRlZEF0Iiwic3BsaXQiLCJhY3Rpb24iLCJpdGVtcyIsImdldEdyb3VwcyIsImZpbHRlcmVkR3JvdXBzIiwiaGFuZGxlUmFuZ2VDaGFuZ2UiLCJkYXRlcyIsImRhdGVTdHJpbmdzIiwiT2JqZWN0IiwiZnJvbUVudHJpZXMiLCJzdGFydF9kYXRlIiwiZW5kX2RhdGUiLCJjb2x1bW5zIiwiaGVhZGVyIiwicHJldiIsIndpZHRoIiwib3B0aW9uQSIsIm9wdGlvbkIiLCJ0b0xvd2VyQ2FzZSIsImxvY2FsZUNvbXBhcmUiLCJsZW5ndGgiLCJib2R5IiwicGFkZGluZyIsImRpc3BsYXkiLCJyZXF1aXJlZCIsImhlaWdodCIsInBhdHRlcm4iLCJmb250U2l6ZSIsImRhbmdlciIsInNpemUiLCJjbGFzc05hbWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTdXNwZW5zZVBheW1lbnRzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgQVBJIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IHtcclxuICBEYXRlUGlja2VyLFxyXG4gIFNlbGVjdCxcclxuICBEcm9wZG93bixcclxuICBEcmF3ZXIsXHJcbiAgRW1wdHksXHJcbiAgU3BpbixcclxuICBNb2RhbCxcclxuICBGb3JtLFxyXG4gIElucHV0LFxyXG4gIEJ1dHRvbixcclxuICBtZXNzYWdlLFxyXG4gIFR5cG9ncmFwaHksXHJcbiAgQ2FyZCxcclxufSBmcm9tIFwiYW50ZFwiO1xyXG5jb25zdCB7IFJhbmdlUGlja2VyIH0gPSBEYXRlUGlja2VyO1xyXG5jb25zdCB7IFRpdGxlLCBUZXh0IH0gPSBUeXBvZ3JhcGh5O1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VTZWFyY2hQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQge1xyXG4gIExvYWRpbmdPdXRsaW5lZCxcclxuICBFeGNsYW1hdGlvbkNpcmNsZU91dGxpbmVkLFxyXG4gIENhbGVuZGFyT3V0bGluZWQsXHJcbiAgRG9sbGFyT3V0bGluZWQsXHJcbiAgQ3JlZGl0Q2FyZE91dGxpbmVkLFxyXG4gIEJhbmtPdXRsaW5lZCxcclxuICBTYWZldHlPdXRsaW5lZCxcclxuICBGaWxlVGV4dE91dGxpbmVkLFxyXG59IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5pbXBvcnQgeyBSaU1vbmV5UnVwZWVDaXJjbGVGaWxsIH0gZnJvbSBcInJlYWN0LWljb25zL3JpXCI7XHJcbmltcG9ydCBkYXlqcyBmcm9tIFwiZGF5anNcIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0RGlhbG9nIGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydERpYWxvZ1wiO1xyXG5pbXBvcnQgQnJlYWRjcnVtYiBmcm9tIFwiLi4vaGVscGVycy9CcmVhZGNydW1iXCI7XHJcblxyXG5jb25zdCBTdXNwZW5zZVBheW1lbnRzID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtwYXltZW50c0RhdGEsIHNldFBheW1lbnRzRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2dyb3Vwcywgc2V0R3JvdXBzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWFyY2hQYXJhbXMsIHNldFNlYXJjaFBhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKTtcclxuICBjb25zdCBbc3RhcnREYXRlLCBzZXRTdGFydERhdGVdID0gdXNlU3RhdGUoXHJcbiAgICBzZWFyY2hQYXJhbXMuZ2V0KFwic3RhcnRfZGF0ZVwiKSB8fCBcIlwiXHJcbiAgKTtcclxuICBjb25zdCBbZW5kRGF0ZSwgc2V0RW5kRGF0ZV0gPSB1c2VTdGF0ZShzZWFyY2hQYXJhbXMuZ2V0KFwiZW5kX2RhdGVcIikgfHwgXCJcIik7XHJcbiAgY29uc3QgW2dyb3VwLCBzZXRHcm91cF0gPSB1c2VTdGF0ZShzZWFyY2hQYXJhbXMuZ2V0KFwiZ3JvdXBfaWRcIikpO1xyXG5cclxuICAvLyBTdGF0ZXMgZm9yIHVwZGF0ZSBtb2RhbFxyXG4gIGNvbnN0IFt1cGRhdGVNb2RhbFZpc2libGUsIHNldFVwZGF0ZU1vZGFsVmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2N1cnJlbnRQYXltZW50SWQsIHNldEN1cnJlbnRQYXltZW50SWRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3VwZGF0ZUZvcm1dID0gRm9ybS51c2VGb3JtKCk7XHJcbiAgY29uc3QgW3VwZGF0ZUxvYWRpbmcsIHNldFVwZGF0ZUxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAvLyBTdGF0ZXMgZm9yIGRlbGV0ZSBtb2RhbFxyXG4gIGNvbnN0IFtkZWxldGVNb2RhbFZpc2libGUsIHNldERlbGV0ZU1vZGFsVmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3BheW1lbnRJZFRvRGVsZXRlLCBzZXRQYXltZW50SWRUb0RlbGV0ZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZGVsZXRlTG9hZGluZywgc2V0RGVsZXRlTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJcIixcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG4gIC8vIFdhdGNoIHRoZSBwYXlfdHlwZSB2YWx1ZSB0byBjb25kaXRpb25hbGx5IHJlbmRlciBmaWVsZHNcclxuICBjb25zdCBwYXlUeXBlID0gRm9ybS51c2VXYXRjaChcInBheV90eXBlXCIsIHVwZGF0ZUZvcm0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVWaWV3TW9kYWxPcGVuID0gKCkgPT4ge1xyXG4gICAgc2V0T3Blbih0cnVlKTtcclxuICB9O1xyXG4gIGNvbnN0IG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbiAgICBzZXRTZWFyY2hUZXh0KGUudGFyZ2V0LnZhbHVlKTtcclxuICAgIHNldEN1cnJlbnRQYWdlKDEpO1xyXG4gICAgc2V0Q3VycmVudFBhZ2VSZWxhdGVkKDEpO1xyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxPcGVuID0gYXN5bmMgKHBheW1lbnRJZCkgPT4ge1xyXG4gICAgc2V0Q3VycmVudFBheW1lbnRJZChwYXltZW50SWQpO1xyXG4gICAgc2V0VXBkYXRlTW9kYWxWaXNpYmxlKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0VXBkYXRlTG9hZGluZyh0cnVlKTtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBUEkuZ2V0KGAvcGF5bWVudC8ke3BheW1lbnRJZH1gKTtcclxuICAgICAgY29uc3QgcGF5bWVudCA9IHJlc3BvbnNlLmRhdGEuZGF0YTtcclxuXHJcbiAgICAgIHVwZGF0ZUZvcm0uc2V0RmllbGRzVmFsdWUoe1xyXG4gICAgICAgIHBheV9kYXRlOiBwYXltZW50LnBheV9kYXRlID8gZGF5anMocGF5bWVudC5wYXlfZGF0ZSkgOiBudWxsLFxyXG4gICAgICAgIGFtb3VudDogcGF5bWVudC5hbW91bnQsXHJcbiAgICAgICAgcGF5X3R5cGU6IHBheW1lbnQucGF5X3R5cGUsXHJcbiAgICAgICAgYWNjb3VudF90eXBlOiBwYXltZW50LmFjY291bnRfdHlwZSxcclxuICAgICAgICB0cmFuc2FjdGlvbl9pZDogcGF5bWVudC50cmFuc2FjdGlvbl9pZCxcclxuICAgICAgICBwYXlfZm9yOiBwYXltZW50LnBheV9mb3IsXHJcbiAgICAgICAgY2hlcXVlX251bWJlcjogcGF5bWVudC5jaGVxdWVfbnVtYmVyLFxyXG4gICAgICAgIGNoZXF1ZV9kYXRlOiBwYXltZW50LmNoZXF1ZV9kYXRlID8gZGF5anMocGF5bWVudC5jaGVxdWVfZGF0ZSkgOiBudWxsLFxyXG4gICAgICAgIGNoZXF1ZV9iYW5rX25hbWU6IHBheW1lbnQuY2hlcXVlX2JhbmtfbmFtZSxcclxuICAgICAgICBjaGVxdWVfYmFua19icmFuY2g6IHBheW1lbnQuY2hlcXVlX2JhbmtfYnJhbmNoLFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggcGF5bWVudCBkZXRhaWxzXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0VXBkYXRlTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlUGF5bWVudCA9IGFzeW5jICh2YWx1ZXMpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldFVwZGF0ZUxvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGxldCBmb3JtYXR0ZWRWYWx1ZXMgPSB7XHJcbiAgICAgICAgLi4udmFsdWVzLFxyXG4gICAgICAgIHBheV9kYXRlOiB2YWx1ZXMucGF5X2RhdGUgPyB2YWx1ZXMucGF5X2RhdGUuZm9ybWF0KFwiWVlZWS1NTS1ERFwiKSA6IG51bGwsXHJcbiAgICAgICAgY2hlcXVlX2RhdGU6IHZhbHVlcy5jaGVxdWVfZGF0ZSA/IHZhbHVlcy5jaGVxdWVfZGF0ZS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpIDogbnVsbCxcclxuICAgICAgfTtcclxuXHJcbiAgICAgIC8vIEV4cGxpY2l0bHkgc2V0IGZpZWxkcyB0byBudWxsIGJhc2VkIG9uIHBheW1lbnQgdHlwZSBiZWZvcmUgc2VuZGluZyB0byBiYWNrZW5kXHJcbiAgICAgIGlmIChmb3JtYXR0ZWRWYWx1ZXMucGF5X3R5cGUgPT09IFwiY2FzaFwiKSB7XHJcbiAgICAgICAgZm9ybWF0dGVkVmFsdWVzLnRyYW5zYWN0aW9uX2lkID0gbnVsbDtcclxuICAgICAgICBmb3JtYXR0ZWRWYWx1ZXMuY2hlcXVlX251bWJlciA9IG51bGw7XHJcbiAgICAgICAgZm9ybWF0dGVkVmFsdWVzLmNoZXF1ZV9kYXRlID0gbnVsbDtcclxuICAgICAgICBmb3JtYXR0ZWRWYWx1ZXMuY2hlcXVlX2JhbmtfbmFtZSA9IG51bGw7XHJcbiAgICAgICAgZm9ybWF0dGVkVmFsdWVzLmNoZXF1ZV9iYW5rX2JyYW5jaCA9IG51bGw7XHJcbiAgICAgIH0gZWxzZSBpZiAoZm9ybWF0dGVkVmFsdWVzLnBheV90eXBlID09PSBcIm9ubGluZVwiKSB7XHJcbiAgICAgICAgZm9ybWF0dGVkVmFsdWVzLmNoZXF1ZV9udW1iZXIgPSBudWxsO1xyXG4gICAgICAgIGZvcm1hdHRlZFZhbHVlcy5jaGVxdWVfZGF0ZSA9IG51bGw7XHJcbiAgICAgICAgZm9ybWF0dGVkVmFsdWVzLmNoZXF1ZV9iYW5rX25hbWUgPSBudWxsO1xyXG4gICAgICAgIGZvcm1hdHRlZFZhbHVlcy5jaGVxdWVfYmFua19icmFuY2ggPSBudWxsO1xyXG4gICAgICB9IGVsc2UgaWYgKGZvcm1hdHRlZFZhbHVlcy5wYXlfdHlwZSA9PT0gXCJjaGVxdWVcIikge1xyXG4gICAgICAgIGZvcm1hdHRlZFZhbHVlcy50cmFuc2FjdGlvbl9pZCA9IG51bGw7XHJcbiAgICAgIH1cclxuICAgICAgXHJcbiAgICAgIGF3YWl0IEFQSS5wdXQoYC9wYXltZW50LyR7Y3VycmVudFBheW1lbnRJZH1gLCBmb3JtYXR0ZWRWYWx1ZXMpO1xyXG4gICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJQYXltZW50IHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5XCIpO1xyXG4gICAgICBzZXRVcGRhdGVNb2RhbFZpc2libGUoZmFsc2UpO1xyXG4gICAgICB1cGRhdGVGb3JtLnJlc2V0RmllbGRzKCk7XHJcbiAgICAgIGdldFBheW1lbnRzKCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIHVwZGF0ZSBwYXltZW50XCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0VXBkYXRlTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxDYW5jZWwgPSAoKSA9PiB7XHJcbiAgICBzZXRVcGRhdGVNb2RhbFZpc2libGUoZmFsc2UpO1xyXG4gICAgdXBkYXRlRm9ybS5yZXNldEZpZWxkcygpO1xyXG4gIH07XHJcblxyXG4gIC8vIEZ1bmN0aW9uIHRvIHNob3cgZGVsZXRlIGNvbmZpcm1hdGlvbiBtb2RhbFxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZU1vZGFsT3BlbiA9IChwYXltZW50SWQpID0+IHtcclxuICAgIHNldFBheW1lbnRJZFRvRGVsZXRlKHBheW1lbnRJZCk7XHJcbiAgICBzZXREZWxldGVNb2RhbFZpc2libGUodHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gRnVuY3Rpb24gdG8gaGFuZGxlIHRoZSBhY3R1YWwgZGVsZXRpb25cclxuICBjb25zdCBoYW5kbGVDb25maXJtRGVsZXRlID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0RGVsZXRlTG9hZGluZyh0cnVlKTtcclxuICAgICAgYXdhaXQgQVBJLmRlbGV0ZShgL2RlbGV0ZS8ke3BheW1lbnRJZFRvRGVsZXRlfWApO1xyXG4gICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJQYXltZW50IGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5IVwiKTtcclxuICAgICAgc2V0RGVsZXRlTW9kYWxWaXNpYmxlKGZhbHNlKTtcclxuICAgICAgc2V0UGF5bWVudElkVG9EZWxldGUobnVsbCk7XHJcbiAgICAgIGdldFBheW1lbnRzKCk7IC8vIFJlZnJlc2ggdGhlIGxpc3RcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gZGVsZXRlIHBheW1lbnRcIik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXREZWxldGVMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBUaGlzIGZ1bmN0aW9uIHdpbGwgYmUgY2FsbGVkIHdoZW5ldmVyIGFueSBmb3JtIHZhbHVlIGNoYW5nZXNcclxuICBjb25zdCBoYW5kbGVGb3JtVmFsdWVzQ2hhbmdlID0gKGNoYW5nZWRWYWx1ZXMpID0+IHtcclxuICAgIC8vIENoZWNrIGlmIHRoZSBwYXlfdHlwZSBmaWVsZCB3YXMgY2hhbmdlZFxyXG4gICAgaWYgKGNoYW5nZWRWYWx1ZXMucGF5X3R5cGUpIHtcclxuICAgICAgY29uc3QgbmV3UGF5VHlwZSA9IGNoYW5nZWRWYWx1ZXMucGF5X3R5cGU7XHJcbiAgICAgIGxldCBmaWVsZHNUb0NsZWFyID0ge307XHJcblxyXG4gICAgICAvLyBDbGVhciBmaWVsZHMgYmFzZWQgb24gdGhlIG5ldyBwYXltZW50IHR5cGVcclxuICAgICAgaWYgKG5ld1BheVR5cGUgPT09IFwiY2FzaFwiKSB7XHJcbiAgICAgICAgZmllbGRzVG9DbGVhciA9IHtcclxuICAgICAgICAgIHRyYW5zYWN0aW9uX2lkOiBudWxsLFxyXG4gICAgICAgICAgY2hlcXVlX251bWJlcjogbnVsbCxcclxuICAgICAgICAgIGNoZXF1ZV9kYXRlOiBudWxsLFxyXG4gICAgICAgICAgY2hlcXVlX2JhbmtfbmFtZTogbnVsbCxcclxuICAgICAgICAgIGNoZXF1ZV9iYW5rX2JyYW5jaDogbnVsbCxcclxuICAgICAgICB9O1xyXG4gICAgICB9IGVsc2UgaWYgKG5ld1BheVR5cGUgPT09IFwib25saW5lXCIpIHtcclxuICAgICAgICBmaWVsZHNUb0NsZWFyID0ge1xyXG4gICAgICAgICAgY2hlcXVlX251bWJlcjogbnVsbCxcclxuICAgICAgICAgIGNoZXF1ZV9kYXRlOiBudWxsLFxyXG4gICAgICAgICAgY2hlcXVlX2JhbmtfbmFtZTogbnVsbCxcclxuICAgICAgICAgIGNoZXF1ZV9iYW5rX2JyYW5jaDogbnVsbCxcclxuICAgICAgICB9O1xyXG4gICAgICB9IGVsc2UgaWYgKG5ld1BheVR5cGUgPT09IFwiY2hlcXVlXCIpIHtcclxuICAgICAgICBmaWVsZHNUb0NsZWFyID0ge1xyXG4gICAgICAgICAgdHJhbnNhY3Rpb25faWQ6IG51bGwsXHJcbiAgICAgICAgfTtcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gVXBkYXRlIHRoZSBmb3JtIHdpdGggdGhlIGNsZWFyZWQgZmllbGRzXHJcbiAgICAgIHVwZGF0ZUZvcm0uc2V0RmllbGRzVmFsdWUoZmllbGRzVG9DbGVhcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZHJvcERvd25JdGVtcyA9IChwYXltZW50SUQpID0+IHtcclxuICAgIGNvbnN0IGRyb3BEb3duSXRlbUxpc3QgPSBbXHJcbiAgICAgIHtcclxuICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICA8TGluayB0bz17YC9wcmludC8ke3BheW1lbnRJRH1gfSBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDBcIj5cclxuICAgICAgICAgICAgUHJpbnRcclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICApLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVVwZGF0ZU1vZGFsT3BlbihwYXltZW50SUQpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBVcGRhdGVcclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICksXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBrZXk6IFwiM1wiLFxyXG4gICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZU1vZGFsT3BlbihwYXltZW50SUQpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICksXHJcbiAgICAgIH0sXHJcbiAgICBdO1xyXG5cclxuICAgIHJldHVybiBkcm9wRG93bkl0ZW1MaXN0O1xyXG4gIH07XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGdldFBheW1lbnRzKCkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgICAgY29uc3QgcGF5bWVudHMgPSBhd2FpdCBBUEkuZ2V0KFxyXG4gICAgICAgIGAvcGF5bWVudC9zdXNwZW5zZT9ncm91cF9pZD0ke2dyb3VwfSZzdGFydF9kYXRlPSR7c3RhcnREYXRlfSZlbmRfZGF0ZT0ke2VuZERhdGV9YFxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCByZXNwb25zZURhdGEgPSBwYXltZW50cz8uZGF0YT8uZGF0YS5tYXAoKHBheW1lbnQsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgIGtleTogcGF5bWVudD8uX2lkLFxyXG4gICAgICAgIHBheW1lbnRfaWQ6IHBheW1lbnQuX2lkLFxyXG4gICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuICAgICAgICBjdXN0b21lck5hbWU6IHBheW1lbnQ/LnVzZXJfaWQ/LmZ1bGxfbmFtZSxcclxuICAgICAgICBjdXN0b21lcklkOiBwYXltZW50Py51c2VyX2lkPy5jdXN0b21lcl9pZCxcclxuICAgICAgICBjdXN0b21lclBob25lOiBwYXltZW50Py51c2VyX2lkPy5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgYWRtaW5UeXBlOiBwYXltZW50Py5hZG1pbl90eXBlPy5hZG1pbl9uYW1lLFxyXG4gICAgICAgIGdyb3VwTmFtZTogcGF5bWVudD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgdGlja2V0OiBwYXltZW50Py50aWNrZXQsXHJcbiAgICAgICAgcmVjZWlwdE5vOiBwYXltZW50LnJlY2VpcHRfbm8sXHJcbiAgICAgICAgYW1vdW50OiBwYXltZW50LmFtb3VudCxcclxuICAgICAgICBwYXlUeXBlOiBwYXltZW50LnBheV90eXBlLFxyXG4gICAgICAgIHBheURhdGU6IHBheW1lbnQucGF5X2RhdGUsXHJcbiAgICAgICAgdHJhbnNhY3Rpb25EYXRlOiBwYXltZW50LmNyZWF0ZWRBdC5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgICAga2V5PXtwYXltZW50Py5faWR9XHJcbiAgICAgICAgICAgICAgdHJpZ2dlcj17W1wiY2xpY2tcIl19XHJcbiAgICAgICAgICAgICAgbWVudT17eyBpdGVtczogZHJvcERvd25JdGVtcyhwYXltZW50Py5faWQpIH19XHJcbiAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkIGN1cnNvci1wb2ludGVyIHRleHQteGwgaG92ZXI6dGV4dC1ncmF5LTYwMFwiIC8+XHJcbiAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApLFxyXG4gICAgICB9KSk7XHJcbiAgICAgIHNldFBheW1lbnRzRGF0YShyZXNwb25zZURhdGEpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgc2V0UGF5bWVudHNEYXRhKFtdKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gZ2V0R3JvdXBzKCkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBUEkuZ2V0KFwiL2dyb3VwL2dldC1ncm91cC1hZG1pblwiKTtcclxuICAgICAgY29uc3QgZmlsdGVyZWRHcm91cHMgPSByZXNwb25zZT8uZGF0YT8ubWFwKChncm91cCkgPT4gKHtcclxuICAgICAgICB2YWx1ZTogZ3JvdXA/Ll9pZCxcclxuICAgICAgICBsYWJlbDogZ3JvdXA/Lmdyb3VwX25hbWUsXHJcbiAgICAgIH0pKTtcclxuICAgICAgc2V0R3JvdXBzKGZpbHRlcmVkR3JvdXBzKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNldEdyb3VwcyhbXSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZ2V0UGF5bWVudHMoKTtcclxuICB9LCBbZ3JvdXAsIHN0YXJ0RGF0ZSwgZW5kRGF0ZV0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZ2V0R3JvdXBzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVSYW5nZUNoYW5nZSA9IChkYXRlcywgZGF0ZVN0cmluZ3MpID0+IHtcclxuICAgIGlmIChkYXRlcykge1xyXG4gICAgICBzZXRTdGFydERhdGUoZGF0ZVN0cmluZ3NbMF0pO1xyXG4gICAgICBzZXRFbmREYXRlKGRhdGVTdHJpbmdzWzFdKTtcclxuICAgICAgc2V0U2VhcmNoUGFyYW1zKHtcclxuICAgICAgICAuLi5PYmplY3QuZnJvbUVudHJpZXMoc2VhcmNoUGFyYW1zKSxcclxuICAgICAgICBzdGFydF9kYXRlOiBkYXRlU3RyaW5nc1swXSxcclxuICAgICAgICBlbmRfZGF0ZTogZGF0ZVN0cmluZ3NbMV0sXHJcbiAgICAgIH0pO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0U3RhcnREYXRlKG51bGwpO1xyXG4gICAgICBzZXRFbmREYXRlKG51bGwpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJzbE5vXCIsIGhlYWRlcjogXCJTbCBOb1wiIH0sXHJcbiAgICB7IGtleTogXCJ0cmFuc2FjdGlvbkRhdGVcIiwgaGVhZGVyOiBcIlRyYW5zYWN0aW9uIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5RGF0ZVwiLCBoZWFkZXI6IFwiUGF5IERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJOYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImN1c3RvbWVySWRcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIElkXCIgfSxcclxuICAgIHsga2V5OiBcImN1c3RvbWVyUGhvbmVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIFBob25lXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwTmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwiIH0sXHJcbiAgICB7IGtleTogXCJhbW91bnRcIiwgaGVhZGVyOiBcIkFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJwYXlUeXBlXCIsIGhlYWRlcjogXCJQYXkgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJyZWNlaXB0Tm9cIiwgaGVhZGVyOiBcIlJlY2VpcHQgTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwiYWRtaW5UeXBlXCIsIGhlYWRlcjogXCJBZG1pbiBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uc1wiIH0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1ncmF5LTUwIG92ZXJmbG93LXgtaGlkZGVuXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4XCI+XHJcbiAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxDdXN0b21BbGVydERpYWxvZ1xyXG4gICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMSBwLTYgbXQtMjAgIG1pbi13LTAgIG92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgIFN1c3BlbnNlIFBheW1lbnRzXHJcbiAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICBNYW5hZ2UgYW5kIHRyYWNrIHN1c3BlbnNlIHBheW1lbnQgcmVjb3Jkc1xyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogRmlsdGVycyBTZWN0aW9uICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBwLTYgbWItNlwiPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTRcIj5GaWx0ZXJzPC9oMj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgRGF0ZSBSYW5nZVxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFJhbmdlUGlja2VyXHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlUmFuZ2VDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTY0XCJcclxuICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17W1wiU3RhcnQgRGF0ZVwiLCBcIkVuZCBEYXRlXCJdfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIEdyb3VwXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDI0MCB9fVxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgYSBncm91cFwiXHJcbiAgICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwibGFiZWxcIlxyXG4gICAgICAgICAgICAgICAgZmlsdGVyU29ydD17KG9wdGlvbkEsIG9wdGlvbkIpID0+XHJcbiAgICAgICAgICAgICAgICAgIChvcHRpb25BPy5sYWJlbCA/PyBcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgLmxvY2FsZUNvbXBhcmUoKG9wdGlvbkI/LmxhYmVsID8/IFwiXCIpLnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXB9XHJcbiAgICAgICAgICAgICAgICBvcHRpb25zPXtncm91cHN9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIHNldFNlYXJjaFBhcmFtcyh7XHJcbiAgICAgICAgICAgICAgICAgICAgLi4uT2JqZWN0LmZyb21FbnRyaWVzKHNlYXJjaFBhcmFtcyksXHJcbiAgICAgICAgICAgICAgICAgICAgZ3JvdXBfaWQ6IHZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgc2V0R3JvdXAodmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcC02XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi00XCI+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgIFBheW1lbnQgUmVjb3Jkc1xyXG4gICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgIFRvdGFsIFJlY29yZHM6e1wiIFwifVxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj57cGF5bWVudHNEYXRhLmxlbmd0aH08L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGgtNjQgZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8U3BpbiBpbmRpY2F0b3I9ezxMb2FkaW5nT3V0bGluZWQgc3BpbiAvPn0gc2l6ZT1cImxhcmdlXCIgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApIDogcGF5bWVudHNEYXRhLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlIGNvbHVtbnM9e2NvbHVtbnN9IGRhdGE9e3BheW1lbnRzRGF0YX0gZXhwb3J0ZWRGaWxlTmFtZT1cIlN1c3BlbnNlIFBheW1lbnQuY3N2XCIgZXhwb3J0ZWRQZGZOYW1lPVwiU3VzcGVuc2UgUGF5bWVudFwiIC8+XHJcblxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPEVtcHR5IGRlc2NyaXB0aW9uPVwiTm8gUGF5bWVudCBSZWNvcmRzIEZvdW5kXCIgLz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvbWFpbj5cclxuXHJcbiAgICAgIHsvKiBWaWV3IERyYXdlciAocGxhY2Vob2xkZXIpICovfVxyXG4gICAgICA8RHJhd2VyXHJcbiAgICAgICAgdGl0bGU9XCJQYXltZW50IERldGFpbHNcIlxyXG4gICAgICAgIHBsYWNlbWVudD1cInJpZ2h0XCJcclxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRPcGVuKGZhbHNlKX1cclxuICAgICAgICBvcGVuPXtvcGVufVxyXG4gICAgICAgIHdpZHRoPXs1MDB9XHJcbiAgICAgID5cclxuICAgICAgICA8cD5Tb21lIGNvbnRlbnRzIGZvciB2aWV3aW5nIHBheW1lbnQgZGV0YWlscy4uLjwvcD5cclxuICAgICAgPC9EcmF3ZXI+XHJcblxyXG4gICAgICB7LyogRW5oYW5jZWQgUHJvZmVzc2lvbmFsIFVwZGF0ZSBNb2RhbCAqL31cclxuICAgICAgPE1vZGFsXHJcbiAgICAgICAgb3Blbj17dXBkYXRlTW9kYWxWaXNpYmxlfVxyXG4gICAgICAgIG9uQ2FuY2VsPXtoYW5kbGVVcGRhdGVNb2RhbENhbmNlbH1cclxuICAgICAgICBmb290ZXI9e251bGx9XHJcbiAgICAgICAgd2lkdGg9ezkwMH1cclxuICAgICAgICBkZXN0cm95T25DbG9zZVxyXG4gICAgICAgIGNlbnRlcmVkXHJcbiAgICAgICAgY2xhc3NOYW1lPVwicHJvZmVzc2lvbmFsLW1vZGFsXCJcclxuICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgIGJvZHk6IHsgcGFkZGluZzogMCB9LFxyXG4gICAgICAgICAgaGVhZGVyOiB7IGRpc3BsYXk6IFwibm9uZVwiIH0sXHJcbiAgICAgICAgfX1cclxuICAgICAgPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS12aW9sZXQtNTAgdmlhLXdoaXRlIHRvLXB1cnBsZS01MCBwLThcIj5cclxuICAgICAgICAgIHsvKiBNb2RhbCBIZWFkZXIgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLThcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS12aW9sZXQtNTAwIHRvLXZpb2xldC02MDAgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaGFkb3ctbGdcIj5cclxuICAgICAgICAgICAgICAgIDxDcmVkaXRDYXJkT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSB0ZXh0LTJ4bFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxUaXRsZSBsZXZlbD17M30gY2xhc3NOYW1lPVwiIW1iLTAgIXRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVXBkYXRlIFBheW1lbnQgRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgPC9UaXRsZT5cclxuICAgICAgICAgICAgICAgIDxUZXh0IGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICBNb2RpZnkgcGF5bWVudCBpbmZvcm1hdGlvbiBhbmQgdHJhbnNhY3Rpb24gZGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxTcGluIHNwaW5uaW5nPXt1cGRhdGVMb2FkaW5nfSBzaXplPVwibGFyZ2VcIj5cclxuICAgICAgICAgICAgPEZvcm1cclxuICAgICAgICAgICAgICBmb3JtPXt1cGRhdGVGb3JtfVxyXG4gICAgICAgICAgICAgIGxheW91dD1cInZlcnRpY2FsXCJcclxuICAgICAgICAgICAgICBvbkZpbmlzaD17aGFuZGxlVXBkYXRlUGF5bWVudH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzcGFjZS15LTZcIlxyXG4gICAgICAgICAgICAgIG9uVmFsdWVzQ2hhbmdlPXtoYW5kbGVGb3JtVmFsdWVzQ2hhbmdlfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgey8qIFBheW1lbnQgSW5mb3JtYXRpb24gU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgICA8Q2FyZFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2hhZG93LXNtIGJvcmRlci0wXCJcclxuICAgICAgICAgICAgICAgIHN0eWxlcz17eyBib2R5OiB7IHBhZGRpbmc6IFwiMjRweFwiIH0gfX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPFRpdGxlIGxldmVsPXs1fSBjbGFzc05hbWU9XCIhbWItMCAhdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFBheW1lbnQgSW5mb3JtYXRpb25cclxuICAgICAgICAgICAgICAgICAgPC9UaXRsZT5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPENhbGVuZGFyT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFBheW1lbnQgRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGF5X2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICB7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIlBsZWFzZSBzZWxlY3QgdGhlIHBheW1lbnQgZGF0ZVwiIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxEYXRlUGlja2VyXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIsIGhlaWdodDogXCI0NnB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIGZvcm1hdD1cIllZWVktTU0tRERcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgcGF5bWVudCBkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgaG92ZXI6Ym9yZGVyLXZpb2xldC00MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsPXtcclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxSaU1vbmV5UnVwZWVDaXJjbGVGaWxsIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBbW91bnRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcnVsZXM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgIHsgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiUGxlYXNlIGlucHV0IHRoZSBhbW91bnRcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXR0ZXJuOiAvXlxcZCsoXFwuXFxkezEsMn0pPyQvLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBlbnRlciBhIHZhbGlkIGFtb3VudFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHByZWZpeD1cIuKCuVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjAuMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBoLVs0NnB4XSBob3Zlcjpib3JkZXItdmlvbGV0LTQwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBmb250U2l6ZTogXCIxNXB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvQ2FyZD5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFBheW1lbnQgTWV0aG9kIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgPENhcmRcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNoYWRvdy1zbSBib3JkZXItMFwiXHJcbiAgICAgICAgICAgICAgICBzdHlsZXM9e3sgYm9keTogeyBwYWRkaW5nOiBcIjI0cHhcIiB9IH19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxUaXRsZSBsZXZlbD17NX0gY2xhc3NOYW1lPVwiIW1iLTAgIXRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBQYXltZW50IE1ldGhvZFxyXG4gICAgICAgICAgICAgICAgICA8L1RpdGxlPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgICBsYWJlbD17XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q3JlZGl0Q2FyZE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IFR5cGVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBheV90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICBydWxlcz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJQbGVhc2Ugc2VsZWN0IGEgcGF5bWVudCB0eXBlXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgcGF5bWVudCBtZXRob2RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInByb2Zlc3Npb25hbC1zZWxlY3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3VmZml4SWNvbj17PENyZWRpdENhcmRPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwXCIgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJjYXNoXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8UmlNb25leVJ1cGVlQ2lyY2xlRmlsbCBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+Q2FzaCBQYXltZW50PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiY2hlcXVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlsZVRleHRPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkNoZXF1ZSBQYXltZW50PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwib25saW5lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8QmFua091dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+T25saW5lIFRyYW5zZmVyPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJhbmtPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWNjb3VudCBUeXBlXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhY2NvdW50X3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICB7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIlBsZWFzZSBzZWxlY3QgYW4gYWNjb3VudCB0eXBlXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgYWNjb3VudCB0eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwcm9mZXNzaW9uYWwtc2VsZWN0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN1ZmZpeEljb249ezxCYW5rT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiU3VzcGVuc2VcIj5TdXNwZW5zZTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiT3RoZXJcIj5PdGhlcjwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L0NhcmQ+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBDb25kaXRpb25hbCBQYXltZW50IERldGFpbHMgKi99XHJcbiAgICAgICAgICAgICAge3BheVR5cGUgPT09IFwib25saW5lXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPENhcmRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2hhZG93LXNtIGJvcmRlci0wIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tcHVycGxlLTUwIHRvLXZpb2xldC01MFwiXHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlcz17eyBib2R5OiB7IHBhZGRpbmc6IFwiMjRweFwiIH0gfX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRpdGxlIGxldmVsPXs1fSBjbGFzc05hbWU9XCIhbWItMCAhdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgT25saW5lIFRyYW5zYWN0aW9uIERldGFpbHNcclxuICAgICAgICAgICAgICAgICAgICA8L1RpdGxlPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgICBsYWJlbD17XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUcmFuc2FjdGlvbiBJRFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwidHJhbnNhY3Rpb25faWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICB7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIlBsZWFzZSBpbnB1dCB0aGUgdHJhbnNhY3Rpb24gSURcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdHJhbnNhY3Rpb24gcmVmZXJlbmNlIG51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGgtWzQ2cHhdIGhvdmVyOmJvcmRlci1wdXJwbGUtNDAwIGZvY3VzOmJvcmRlci1wdXJwbGUtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHByZWZpeD17PFNhZmV0eU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIiAvPn1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICB7cGF5VHlwZSA9PT0gXCJjaGVxdWVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8Q2FyZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzaGFkb3ctc20gYm9yZGVyLTAgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS12aW9sZXQtNTAgdG8taW5kaWdvLTUwXCJcclxuICAgICAgICAgICAgICAgICAgc3R5bGVzPXt7IGJvZHk6IHsgcGFkZGluZzogXCIyNHB4XCIgfSB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8VGl0bGUgbGV2ZWw9ezV9IGNsYXNzTmFtZT1cIiFtYi0wICF0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBDaGVxdWUgRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvVGl0bGU+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxGaWxlVGV4dE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIENoZXF1ZSBOdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNoZXF1ZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcnVsZXM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJQbGVhc2UgaW5wdXQgdGhlIGNoZXF1ZSBudW1iZXJcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBjaGVxdWUgbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBoLVs0NnB4XSBob3Zlcjpib3JkZXItdmlvbGV0LTQwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHByZWZpeD17PEZpbGVUZXh0T3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDYWxlbmRhck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIENoZXF1ZSBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjaGVxdWVfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBydWxlcz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIlBsZWFzZSBzZWxlY3QgdGhlIGNoZXF1ZSBkYXRlXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPERhdGVQaWNrZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiLCBoZWlnaHQ6IFwiNDZweFwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1hdD1cIllZWVktTU0tRERcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBjaGVxdWUgZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgaG92ZXI6Ym9yZGVyLXZpb2xldC00MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxCYW5rT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQmFuayBOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjaGVxdWVfYmFua19uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiUGxlYXNlIGlucHV0IHRoZSBiYW5rIG5hbWVcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBiYW5rIG5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGgtWzQ2cHhdIGhvdmVyOmJvcmRlci12aW9sZXQtNDAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcHJlZml4PXs8QmFua091dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIiAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8QmFua091dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEJhbmsgQnJhbmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjaGVxdWVfYmFua19icmFuY2hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcnVsZXM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJQbGVhc2UgaW5wdXQgdGhlIGJhbmsgYnJhbmNoXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgYnJhbmNoIG5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGgtWzQ2cHhdIGhvdmVyOmJvcmRlci12aW9sZXQtNDAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcHJlZml4PXs8QmFua091dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIiAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBBY3Rpb24gQnV0dG9ucyAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTMgbXQtOCBwdC02IGJvcmRlci10XCI+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVVwZGF0ZU1vZGFsQ2FuY2VsfVxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTExIHB4LTggcm91bmRlZC1sZyBmb250LW1lZGl1bSBob3ZlcjpiZy1ncmF5LTEwMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgaHRtbFR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBsb2FkaW5nPXt1cGRhdGVMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTExIHB4LTggcm91bmRlZC1sZyBmb250LW1lZGl1bSBiZy1ncmFkaWVudC10by1yIGZyb20tdmlvbGV0LTYwMCB0by12aW9sZXQtNzAwIGhvdmVyOmZyb20tdmlvbGV0LTcwMCBob3Zlcjp0by12aW9sZXQtODAwIGJvcmRlci0wIHNoYWRvdy1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgIGljb249ezxTYWZldHlPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgVXBkYXRlIFBheW1lbnRcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L0Zvcm0+XHJcbiAgICAgICAgICA8L1NwaW4+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxzdHlsZSBqc3ggZ2xvYmFsPntgXHJcbiAgICAgICAgICAucHJvZmVzc2lvbmFsLW1vZGFsIC5hbnQtbW9kYWwtY29udGVudCB7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDE2cHg7XHJcbiAgICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICAgICAgICAgIGJveC1zaGFkb3c6IDAgMjBweCA2MHB4IHJnYmEoMCwgMCwgMCwgMC4xNSk7XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgLnByb2Zlc3Npb25hbC1zZWxlY3QgLmFudC1zZWxlY3Qtc2VsZWN0b3Ige1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDQ2cHggIWltcG9ydGFudDtcclxuICAgICAgICAgICAgcGFkZGluZzogOHB4IDE2cHggIWltcG9ydGFudDtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogOHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcclxuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlciAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIC5wcm9mZXNzaW9uYWwtc2VsZWN0IC5hbnQtc2VsZWN0LXNlbGVjdGlvbi1wbGFjZWhvbGRlcixcclxuICAgICAgICAgIC5wcm9mZXNzaW9uYWwtc2VsZWN0IC5hbnQtc2VsZWN0LXNlbGVjdGlvbi1pdGVtIHtcclxuICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDMwcHggIWltcG9ydGFudDtcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAuYW50LWlucHV0LWFmZml4LXdyYXBwZXIge1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgLmFudC1waWNrZXIge1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgLmFudC1jYXJkIHtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTJweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICBgfTwvc3R5bGU+XHJcbiAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICB7LyogRGVsZXRlIENvbmZpcm1hdGlvbiBNb2RhbCAqL31cclxuICAgICAgPE1vZGFsXHJcbiAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCBiZy1yZWQtMTAwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxFeGNsYW1hdGlvbkNpcmNsZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMCB0ZXh0LXhsXCIgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZFwiPkNvbmZpcm0gRGVsZXRpb248L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICB9XHJcbiAgICAgICAgb3Blbj17ZGVsZXRlTW9kYWxWaXNpYmxlfVxyXG4gICAgICAgIG9uT2s9e2hhbmRsZUNvbmZpcm1EZWxldGV9XHJcbiAgICAgICAgb25DYW5jZWw9eygpID0+IHNldERlbGV0ZU1vZGFsVmlzaWJsZShmYWxzZSl9XHJcbiAgICAgICAgb2tUZXh0PVwiRGVsZXRlIFBheW1lbnRcIlxyXG4gICAgICAgIGNhbmNlbFRleHQ9XCJDYW5jZWxcIlxyXG4gICAgICAgIG9rQnV0dG9uUHJvcHM9e3tcclxuICAgICAgICAgIGRhbmdlcjogdHJ1ZSxcclxuICAgICAgICAgIHNpemU6IFwibGFyZ2VcIixcclxuICAgICAgICAgIGNsYXNzTmFtZTogXCJoLTEwIHJvdW5kZWQtbGcgZm9udC1tZWRpdW1cIixcclxuICAgICAgICB9fVxyXG4gICAgICAgIGNhbmNlbEJ1dHRvblByb3BzPXt7XHJcbiAgICAgICAgICBzaXplOiBcImxhcmdlXCIsXHJcbiAgICAgICAgICBjbGFzc05hbWU6IFwiaC0xMCByb3VuZGVkLWxnIGZvbnQtbWVkaXVtXCIsXHJcbiAgICAgICAgfX1cclxuICAgICAgICBjb25maXJtTG9hZGluZz17ZGVsZXRlTG9hZGluZ31cclxuICAgICAgICBjZW50ZXJlZFxyXG4gICAgICAgIHdpZHRoPXs0ODB9XHJcbiAgICAgID5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTRcIj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgdGV4dC1iYXNlIG1iLTNcIj5cclxuICAgICAgICAgICAgQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSB0aGlzIHBheW1lbnQgcmVjb3JkP1xyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1yZWQtNTAgYm9yZGVyIGJvcmRlci1yZWQtMjAwIHJvdW5kZWQtbGcgcC00XCI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTcwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPEV4Y2xhbWF0aW9uQ2lyY2xlT3V0bGluZWQgLz5cclxuICAgICAgICAgICAgICBUaGlzIGFjdGlvbiBjYW5ub3QgYmUgdW5kb25lLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9Nb2RhbD5cclxuICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFN1c3BlbnNlUGF5bWVudHM7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1N1c3BlbnNlUGF5bWVudHMuanN4In0=