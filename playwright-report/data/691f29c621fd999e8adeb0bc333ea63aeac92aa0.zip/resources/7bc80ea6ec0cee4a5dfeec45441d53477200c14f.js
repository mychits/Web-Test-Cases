import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/TargetPayoutSalary.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import API from "/src/instance/TokenInstance.js";
import Modal from "/src/components/modals/Modal.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Tooltip, notification } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import SettingSidebar from "/src/components/layouts/SettingSidebar.jsx";
const TargetPayOutSalary = () => {
  _s();
  const paymentFor = "salary";
  const [api, contextHolder] = notification.useNotification();
  const [showSalaryModal, setShowSalaryModal] = useState(false);
  const [modifyPayment, setModifyPayment] = useState(false);
  const [adminId, setAdminId] = useState("");
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    noReload: false,
    type: "info"
  });
  const [targetData, setTargetData] = useState({
    target: 0,
    achieved: 0,
    remaining: 0,
    difference: 0,
    incentiveAmount: "₹0.00",
    incentivePercent: "0%"
  });
  const [agents, setAgents] = useState([]);
  const [salaryPayments, setSalaryPayments] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [adminName, setAdminName] = useState("");
  const [errors, setErrors] = useState({});
  const [reRender, setReRender] = useState(0);
  const today = /* @__PURE__ */ new Date();
  const [salaryForm, setSalaryForm] = useState({
    agent_id: "",
    pay_date: today.toISOString().split("T")[0],
    from_date: "",
    to_date: "",
    amount: "",
    pay_type: "cash",
    transaction_id: "",
    note: "",
    pay_for: paymentFor,
    admin_type: ""
  });
  const [employeeDetails, setEmployeeDetails] = useState({
    joining_date: "",
    salary: ""
  });
  const [totalWithIncentive, setTotalWithIncentive] = useState("0.00");
  const [calculatedSalary, setCalculatedSalary] = useState("");
  const [alreadyPaid, setAlreadyPaid] = useState("0.00");
  const [remainingSalary, setRemainingSalary] = useState("0.00");
  const formatDate = (date) => {
    if (!date) return "";
    if (typeof date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return date;
    }
    const d = new Date(date);
    if (isNaN(d)) return "";
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };
  const calculateProRatedSalary = async (fromDateStr, toDateStr, monthlySalary, empId) => {
    if (!fromDateStr || !toDateStr || !monthlySalary || !empId) {
      setCalculatedSalary("");
      setAlreadyPaid("0.00");
      setRemainingSalary("0.00");
      return;
    }
    const fromDate = new Date(formatDate(fromDateStr));
    const toDate = new Date(formatDate(toDateStr));
    const salary = parseFloat(monthlySalary);
    if (toDate < fromDate || isNaN(salary)) {
      setCalculatedSalary("");
      setAlreadyPaid("0.00");
      setRemainingSalary("0.00");
      return;
    }
    let current = new Date(fromDate);
    let totalSalary = 0;
    while (current <= toDate) {
      const year = current.getFullYear();
      const month = current.getMonth();
      const daysInMonth = new Date(year, month + 1, 0).getDate();
      const fromDay = current.getFullYear() === fromDate.getFullYear() && current.getMonth() === fromDate.getMonth() ? fromDate.getDate() : 1;
      const toDay = current.getFullYear() === toDate.getFullYear() && current.getMonth() === toDate.getMonth() ? toDate.getDate() : daysInMonth;
      const daysWorked = toDay - fromDay + 1;
      const dailySalary = salary / daysInMonth;
      totalSalary += daysWorked * dailySalary;
      current = new Date(year, month + 1, 1);
    }
    const proRatedSalary = totalSalary;
    const totalPayableWithIncentive = proRatedSalary;
    setCalculatedSalary(totalPayableWithIncentive.toFixed(2));
    setTotalWithIncentive(totalPayableWithIncentive.toFixed(2));
    try {
      const res = await API.get("/payment-out/get-salary-payments");
      const paidToAgent = res?.data?.filter((p) => {
        const pAgentId = p.agent_id?._id ? String(p.agent_id._id) : String(p.agent_id);
        const matchesAgent = pAgentId === String(empId);
        const payDate = new Date(formatDate(p.pay_date));
        return matchesAgent && payDate >= fromDate && payDate <= toDate;
      });
      const totalPaid = paidToAgent.reduce(
        (sum, p) => sum + parseFloat(p.amount || 0),
        0
      );
      const remaining = totalPayableWithIncentive - totalPaid;
      setAlreadyPaid(totalPaid.toFixed(2));
      setRemainingSalary(remaining.toFixed(2));
    } catch (error) {
      console.error("Error calculating already paid and remaining", error);
      setAlreadyPaid("0.00");
      setRemainingSalary(totalPayableWithIncentive.toFixed(2));
    }
  };
  const fetchEmployeeDetails = async (empId) => {
    try {
      const res = await API.get(
        `/agent/get-additional-employee-info-by-id/${empId}`
      );
      const emp = res?.data?.employee;
      if (emp) {
        const joining = emp.joining_date?.split("T")[0] || "";
        const baseSalary = emp.salary || "";
        setEmployeeDetails({ joining_date: joining, salary: baseSalary });
        if (salaryForm.from_date && salaryForm.to_date) {
          const fd = formatDate(salaryForm.from_date);
          const td = formatDate(salaryForm.to_date);
          fetchTargetDetails(empId, fd, td);
          calculateProRatedSalary(fd, td, baseSalary, empId);
        }
      }
    } catch (err) {
      console.error("Error fetching employee info", err);
      setEmployeeDetails({ joining_date: "", salary: "" });
      setCalculatedSalary("");
    }
  };
  const fetchAgents = async () => {
    try {
      const response = await API.get("/employee");
      setAgents(response.data?.employee || []);
    } catch (error) {
      console.error("Failed to fetch Agents");
    }
  };
  const fetchSalaryPayments = async () => {
    setIsLoading(true);
    try {
      const response = await API.get("/payment-out/get-salary-payments");
      const responseData = response.data.map((payment, index) => ({
        id: index + 1,
        _id: payment._id,
        agent_id: payment.agent_id,
        agent_name: payment.agent_id?.name,
        pay_date: payment.pay_date,
        amount: payment.amount,
        pay_type: payment.pay_type,
        transaction_id: payment.transaction_id,
        note: payment.note,
        pay_for: payment.pay_for,
        disbursed_by: payment.admin_type?.name,
        receipt_no: payment.receipt_no
      }));
      setSalaryPayments(responseData);
    } catch (error) {
      console.error("Failed to fetch Salary payments", error);
      setSalaryPayments([]);
    } finally {
      setIsLoading(false);
    }
  };
  const fetchTargetDetails = async (agentId, fromDate, toDate) => {
    if (!agentId || !fromDate || !toDate) {
      resetTargetData();
      return;
    }
    try {
      const res = await API.get(`/target/employee/${agentId}`, {
        params: { from_date: fromDate, to_date: toDate }
      });
      if (res.data?.success && res.data?.summary) {
        const empSummary = res.data.summary;
        setTargetData({
          target: empSummary.agent?.target?.value || "Not Set",
          achieved: empSummary.metrics?.actual_business || "₹0.00",
          difference: empSummary.metrics?.target_difference || "₹0.00",
          remaining: empSummary.metrics?.target_remaining || "₹0.00",
          incentiveAmount: empSummary.metrics?.total_estimated || "₹0.00",
          incentivePercent: (empSummary.agent?.target?.achievement_percent || "0") + "%"
        });
        return;
      }
      resetTargetData();
    } catch (error) {
      console.error("Error fetching target details", error);
      resetTargetData();
    }
  };
  const resetTargetData = () => {
    setTargetData({
      target: 0,
      achieved: 0,
      difference: 0,
      remaining: 0,
      incentiveAmount: "₹0.00",
      incentivePercent: "0%"
    });
  };
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    setAdminId(userObj._id);
    setAdminName(userObj.name || "");
    if (userObj?.admin_access_right_id?.access_permissions?.edit_payment) {
      setModifyPayment(
        userObj.admin_access_right_id.access_permissions.edit_payment === "true"
      );
    }
  }, []);
  useEffect(() => {
    fetchAgents();
    fetchSalaryPayments();
  }, [reRender]);
  const handleSalaryChange = (e) => {
    const { name, value } = e.target;
    setSalaryForm((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };
  const validateForm = () => {
    const newErrors = {};
    if (!salaryForm.agent_id) newErrors.agent_id = "Please select an agent";
    if (!salaryForm.amount || isNaN(salaryForm.amount))
      newErrors.amount = "Please enter a valid amount";
    if (salaryForm.pay_type === "online" && !salaryForm.transaction_id)
      newErrors.pay_type = "Transaction ID is required for online payments";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSalarySubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    if (isValid) {
      try {
        setIsLoading(true);
        const payload = {
          ...salaryForm,
          admin_type: adminId
        };
        await API.post("/payment-out/add-salary-payment", payload);
        api.open({
          message: "Salary Payout Successful",
          description: "The salary payment has been successfully processed.",
          className: "bg-green-500 rounded-lg font-semibold text-white",
          showProgress: true,
          pauseOnHover: false
        });
        setShowSalaryModal(false);
        resetForm();
        setReRender((val) => val + 1);
        fetchSalaryPayments();
      } catch (error) {
        const message = error.message || "Something went wrong";
        api.open({
          message: "Salary Payout Failed",
          description: message,
          showProgress: true,
          pauseOnHover: false,
          className: "bg-red-500 rounded-lg font-semibold text-white"
        });
      } finally {
        setIsLoading(false);
      }
    }
  };
  const resetForm = () => {
    setSalaryForm({
      agent_id: "",
      pay_date: today.toISOString().split("T")[0],
      from_date: "",
      to_date: "",
      amount: "",
      pay_type: "cash",
      transaction_id: "",
      note: "",
      pay_for: paymentFor,
      admin_type: adminId
    });
    setEmployeeDetails({ joining_date: "", salary: "" });
    setCalculatedSalary("");
    setAlreadyPaid("0.00");
    setRemainingSalary("0.00");
    resetTargetData();
  };
  const salaryColumns = [
    { key: "id", header: "SL. NO" },
    { key: "pay_date", header: "Pay Date" },
    { key: "agent_name", header: "Agent" },
    { key: "amount", header: "Amount (₹)" },
    { key: "pay_type", header: "Payment Mode" },
    { key: "receipt_no", header: "Receipt No" },
    { key: "note", header: "Note" },
    { key: "disbursed_by", header: "Disbursed by" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    contextHolder,
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
        lineNumber: 381,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
        lineNumber: 382,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        CustomAlert,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          noReload: alertConfig.noReload
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
          lineNumber: 383,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-2xl text-red-500 font-bold", children: paymentFor?.toUpperCase() }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
              lineNumber: 392,
              columnNumber: 17
            }, this),
            " ",
            "Payments Out"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
            lineNumber: 391,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Tooltip, { title: "Add Salary Payment", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowSalaryModal(true);
                resetForm();
              },
              className: "ml-4 bg-violet-900 text-white px-4 py-2 rounded shadow-md hover:bg-violet-600 transition duration-200 flex items-center",
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "mr-2", children: "+" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                  lineNumber: 405,
                  columnNumber: 19
                }, this),
                " Salary Payment"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
              lineNumber: 398,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
            lineNumber: 397,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
          lineNumber: 390,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-8 bg-white p-6 rounded-lg shadow-md", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold mb-4 text-violet-800 border-b pb-2", children: "Salary Payments" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
            lineNumber: 411,
            columnNumber: 15
          }, this),
          salaryPayments.length > 0 ? /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: salaryPayments,
              columns: salaryColumns,
              exportedPdfName: "PayOut Salary",
              exportedFileName: `PayOut Salary.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
              lineNumber: 416,
              columnNumber: 15
            },
            this
          ) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10 text-center text-gray-500", children: /* @__PURE__ */ jsxDEV(
            CircularLoader,
            {
              isLoading,
              data: "Salary Payments",
              failure: salaryPayments.length === 0
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
              lineNumber: 424,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
            lineNumber: 423,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
          lineNumber: 410,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
        lineNumber: 389,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Modal,
        {
          isVisible: showSalaryModal,
          onClose: () => {
            setShowSalaryModal(false);
            resetForm();
          },
          children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900 border-b pb-2", children: "Add Salary Payment" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
              lineNumber: 442,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("form", { className: "space-y-4", onSubmit: handleSalarySubmit, children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Employee ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 448,
                    columnNumber: 30
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                  lineNumber: 447,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: "w-full h-12",
                    placeholder: "Select Agent",
                    showSearch: true,
                    optionFilterProp: "children",
                    filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                    value: salaryForm.agent_id || void 0,
                    onChange: (value) => {
                      setErrors((prev) => ({ ...prev, agent_id: "" }));
                      setSalaryForm((prev) => ({
                        ...prev,
                        agent_id: value,
                        from_date: "",
                        to_date: "",
                        amount: ""
                      }));
                      setEmployeeDetails({ joining_date: "", salary: "" });
                      setCalculatedSalary("");
                      setAlreadyPaid("0.00");
                      setRemainingSalary("0.00");
                      resetTargetData();
                      fetchEmployeeDetails(value);
                    },
                    children: agents.map(
                      (agent) => /* @__PURE__ */ jsxDEV(Select.Option, { value: agent._id, children: `${agent.name} | ${agent.phone_number}` }, agent._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                        lineNumber: 479,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 450,
                    columnNumber: 19
                  },
                  this
                ),
                errors.agent_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.agent_id }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                  lineNumber: 485,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                lineNumber: 446,
                columnNumber: 17
              }, this),
              employeeDetails.joining_date && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Joining Date" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 494,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      value: employeeDetails.joining_date,
                      readOnly: true,
                      className: "bg-gray-100 border border-gray-300 text-gray-700 text-sm rounded-lg w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                      lineNumber: 497,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                  lineNumber: 493,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "From Date ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                        lineNumber: 508,
                        columnNumber: 37
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                      lineNumber: 507,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "date",
                        name: "from_date",
                        value: salaryForm.from_date,
                        onChange: handleSalaryChange,
                        className: "w-full p-3 border border-gray-300 rounded-lg"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                        lineNumber: 510,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 506,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "To Date ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                        lineNumber: 521,
                        columnNumber: 35
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                      lineNumber: 520,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "date",
                        name: "to_date",
                        value: salaryForm.to_date,
                        onChange: handleSalaryChange,
                        className: "w-full p-3 border border-gray-300 rounded-lg"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                        lineNumber: 523,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 519,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "col-span-2", children: /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      className: "mt-2 bg-violet-600 hover:bg-violet-700 text-white px-4 py-2 rounded",
                      onClick: () => {
                        if (salaryForm.agent_id && salaryForm.from_date && salaryForm.to_date && employeeDetails.salary) {
                          const fd = formatDate(salaryForm.from_date);
                          const td = formatDate(salaryForm.to_date);
                          fetchTargetDetails(salaryForm.agent_id, fd, td);
                          calculateProRatedSalary(
                            fd,
                            td,
                            employeeDetails.salary,
                            salaryForm.agent_id
                          );
                        }
                      },
                      children: "Calculate"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                      lineNumber: 533,
                      columnNumber: 25
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 532,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                  lineNumber: 505,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4 mt-6 p-3 rounded-lg bg-gray-50", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium", children: "Target" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                      lineNumber: 563,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        value: `${targetData.target?.toLocaleString(
                          "en-IN"
                        )}`,
                        readOnly: true,
                        className: "w-full border rounded px-3 py-2 bg-white font-semibold"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                        lineNumber: 566,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 562,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium", children: "Achieved" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                      lineNumber: 575,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        value: `${targetData.achieved?.toLocaleString(
                          "en-IN"
                        )}`,
                        readOnly: true,
                        className: "w-full border rounded px-3 py-2 bg-white font-semibold"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                        lineNumber: 578,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 574,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium", children: "Difference" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                      lineNumber: 587,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        value: `${targetData.difference?.toLocaleString(
                          "en-IN"
                        )}`,
                        readOnly: true,
                        className: "w-full border rounded px-3 py-2 bg-white font-semibold"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                        lineNumber: 590,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 586,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                  lineNumber: 561,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Monthly Salary (₹)" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 601,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      value: employeeDetails.salary,
                      readOnly: true,
                      className: "bg-gray-100 border border-gray-300 text-gray-700 text-sm rounded-lg w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                      lineNumber: 604,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                  lineNumber: 600,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Total Payable Salary (₹)" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 613,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      value: calculatedSalary,
                      readOnly: true,
                      className: "border border-gray-300 font-semibold text-sm rounded-lg w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                      lineNumber: 616,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                  lineNumber: 612,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                lineNumber: 492,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Payment Date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                  lineNumber: 627,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    name: "pay_date",
                    value: salaryForm.pay_date,
                    onChange: handleSalaryChange,
                    className: "w-full p-3 border border-gray-300 rounded-lg",
                    disabled: !modifyPayment
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 630,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                lineNumber: 626,
                columnNumber: 17
              }, this),
              calculatedSalary && /* @__PURE__ */ jsxDEV("div", { className: "mt-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Enter Payable Amount (₹)",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 644,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                  lineNumber: 642,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "amount",
                    min: 1,
                    value: salaryForm.amount,
                    onChange: (e) => {
                      const val = parseFloat(e.target.value || 0);
                      const rem = parseFloat(remainingSalary);
                      if (val > rem) {
                        setErrors((prev) => ({
                          ...prev,
                          amount: `Cannot pay more than ₹${rem.toFixed(2)}`
                        }));
                      } else {
                        setSalaryForm((prev) => ({
                          ...prev,
                          amount: e.target.value
                        }));
                        setErrors((prev) => ({ ...prev, amount: "" }));
                      }
                    },
                    className: "w-full p-3 border border-gray-300 rounded-lg",
                    placeholder: "Enter amount to pay"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 646,
                    columnNumber: 21
                  },
                  this
                ),
                errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.amount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                  lineNumber: 671,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4 mt-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm font-medium text-gray-900", children: "Already Paid (₹)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                      lineNumber: 678,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        value: alreadyPaid,
                        readOnly: true,
                        className: "bg-green-50 border border-green-300 text-green-700 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                        lineNumber: 681,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 677,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm font-medium text-gray-900", children: "Remaining Salary (₹)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                      lineNumber: 690,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        value: remainingSalary,
                        readOnly: true,
                        className: "bg-red-50 border border-red-300 text-red-700 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                        lineNumber: 693,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 689,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                  lineNumber: 676,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                lineNumber: 641,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Payment Mode" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                  lineNumber: 705,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    name: "pay_type",
                    value: salaryForm.pay_type,
                    onChange: handleSalaryChange,
                    className: "w-full p-3 border border-gray-300 rounded-lg",
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "cash", children: "Cash" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                        lineNumber: 714,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "online", children: "Online" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                        lineNumber: 715,
                        columnNumber: 21
                      }, this),
                      modifyPayment && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "cheque", children: "Cheque" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                          lineNumber: 718,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "bank_transfer", children: "Bank Transfer" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                          lineNumber: 719,
                          columnNumber: 25
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                        lineNumber: 717,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 708,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                lineNumber: 704,
                columnNumber: 17
              }, this),
              salaryForm.pay_type === "online" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Transaction ID ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 728,
                    columnNumber: 38
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                  lineNumber: 727,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "transaction_id",
                    value: salaryForm.transaction_id,
                    onChange: handleSalaryChange,
                    className: "w-full p-3 border border-gray-300 rounded-lg"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 730,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                lineNumber: 726,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Note" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                  lineNumber: 741,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "textarea",
                  {
                    name: "note",
                    value: salaryForm.note,
                    onChange: handleSalaryChange,
                    className: "w-full p-3 border border-gray-300 rounded-lg",
                    rows: "2"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 744,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                lineNumber: 740,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full bg-violet-50 p-3 rounded-lg", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm font-medium text-gray-900", children: "Disbursed By" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                  lineNumber: 754,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "font-semibold", children: adminName }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                  lineNumber: 757,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                lineNumber: 753,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end space-x-3 pt-4", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => setShowSalaryModal(false),
                    className: "px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100",
                    children: "Cancel"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 761,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    disabled: isLoading,
                    className: "px-4 py-2 bg-violet-700 text-white rounded-lg hover:bg-violet-600 disabled:opacity-50",
                    children: isLoading ? "Processing..." : "Save Payment"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                    lineNumber: 768,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
                lineNumber: 760,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
              lineNumber: 445,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
            lineNumber: 441,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
          lineNumber: 434,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
      lineNumber: 380,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
    lineNumber: 378,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx",
    lineNumber: 377,
    columnNumber: 5
  }, this);
};
_s(TargetPayOutSalary, "Ol8PNaVfvo+WYThl7o9ZEYu4C+8=", false, function() {
  return [notification.useNotification];
});
_c = TargetPayOutSalary;
export default TargetPayOutSalary;
var _c;
$RefreshReg$(_c, "TargetPayOutSalary");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetPayoutSalary.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNFhVLFNBK0dRLFVBL0dSOzJCQTVYVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLFNBQVNBLFdBQVdDLGdCQUFnQjtBQUNwQyxPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsWUFBWTtBQUNuQixTQUFTQyxRQUFRQyxTQUFTQyxvQkFBb0I7QUFDOUMsT0FBT0Msb0JBQW9CO0FBRTNCLE1BQU1DLHFCQUFxQkEsTUFBTTtBQUFBQyxLQUFBO0FBQy9CLFFBQU1DLGFBQWE7QUFDbkIsUUFBTSxDQUFDQyxLQUFLQyxhQUFhLElBQUlOLGFBQWFPLGdCQUFnQjtBQUMxRCxRQUFNLENBQUNDLGlCQUFpQkMsa0JBQWtCLElBQUluQixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDb0IsZUFBZUMsZ0JBQWdCLElBQUlyQixTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDc0IsU0FBU0MsVUFBVSxJQUFJdkIsU0FBUyxFQUFFO0FBQ3pDLFFBQU0sQ0FBQ3dCLGFBQWFDLGNBQWMsSUFBSXpCLFNBQVM7QUFBQSxJQUM3QzBCLFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsVUFBVTtBQUFBLElBQ1ZDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFFRCxRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSS9CLFNBQVM7QUFBQSxJQUMzQ2dDLFFBQVE7QUFBQSxJQUNSQyxVQUFVO0FBQUEsSUFDVkMsV0FBVztBQUFBLElBQ1hDLFlBQVk7QUFBQSxJQUNaQyxpQkFBaUI7QUFBQSxJQUNqQkMsa0JBQWtCO0FBQUEsRUFDcEIsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJdkMsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ3dDLGdCQUFnQkMsaUJBQWlCLElBQUl6QyxTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDMEMsV0FBV0MsWUFBWSxJQUFJM0MsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzRDLFdBQVdDLFlBQVksSUFBSTdDLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUM4QyxRQUFRQyxTQUFTLElBQUkvQyxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUNnRCxVQUFVQyxXQUFXLElBQUlqRCxTQUFTLENBQUM7QUFFMUMsUUFBTWtELFFBQVEsb0JBQUlDLEtBQUs7QUFFdkIsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUlyRCxTQUFTO0FBQUEsSUFDM0NzRCxVQUFVO0FBQUEsSUFDVkMsVUFBVUwsTUFBTU0sWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsSUFDMUNDLFdBQVc7QUFBQSxJQUNYQyxTQUFTO0FBQUEsSUFDVEMsUUFBUTtBQUFBLElBQ1JDLFVBQVU7QUFBQSxJQUNWQyxnQkFBZ0I7QUFBQSxJQUNoQkMsTUFBTTtBQUFBLElBQ05DLFNBQVNsRDtBQUFBQSxJQUNUbUQsWUFBWTtBQUFBLEVBQ2QsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsaUJBQWlCQyxrQkFBa0IsSUFBSW5FLFNBQVM7QUFBQSxJQUNyRG9FLGNBQWM7QUFBQSxJQUNkQyxRQUFRO0FBQUEsRUFDVixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxvQkFBb0JDLHFCQUFxQixJQUFJdkUsU0FBUyxNQUFNO0FBRW5FLFFBQU0sQ0FBQ3dFLGtCQUFrQkMsbUJBQW1CLElBQUl6RSxTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDMEUsYUFBYUMsY0FBYyxJQUFJM0UsU0FBUyxNQUFNO0FBQ3JELFFBQU0sQ0FBQzRFLGlCQUFpQkMsa0JBQWtCLElBQUk3RSxTQUFTLE1BQU07QUFFN0QsUUFBTThFLGFBQWFBLENBQUNDLFNBQVM7QUFDM0IsUUFBSSxDQUFDQSxLQUFNLFFBQU87QUFDbEIsUUFBSSxPQUFPQSxTQUFTLFlBQVksc0JBQXNCQyxLQUFLRCxJQUFJLEdBQUc7QUFDaEUsYUFBT0E7QUFBQUEsSUFDVDtBQUNBLFVBQU1FLElBQUksSUFBSTlCLEtBQUs0QixJQUFJO0FBQ3ZCLFFBQUlHLE1BQU1ELENBQUMsRUFBRyxRQUFPO0FBQ3JCLFVBQU1FLE9BQU9GLEVBQUVHLFlBQVk7QUFDM0IsVUFBTUMsUUFBUUMsT0FBT0wsRUFBRU0sU0FBUyxJQUFJLENBQUMsRUFBRUMsU0FBUyxHQUFHLEdBQUc7QUFDdEQsVUFBTUMsTUFBTUgsT0FBT0wsRUFBRVMsUUFBUSxDQUFDLEVBQUVGLFNBQVMsR0FBRyxHQUFHO0FBQy9DLFdBQU8sR0FBR0wsSUFBSSxJQUFJRSxLQUFLLElBQUlJLEdBQUc7QUFBQSxFQUNoQztBQUVBLFFBQU1FLDBCQUEwQixPQUM5QkMsYUFDQUMsV0FDQUMsZUFDQUMsVUFDRztBQUNILFFBQUksQ0FBQ0gsZUFBZSxDQUFDQyxhQUFhLENBQUNDLGlCQUFpQixDQUFDQyxPQUFPO0FBQzFEdEIsMEJBQW9CLEVBQUU7QUFDdEJFLHFCQUFlLE1BQU07QUFDckJFLHlCQUFtQixNQUFNO0FBQ3pCO0FBQUEsSUFDRjtBQUVBLFVBQU1tQixXQUFXLElBQUk3QyxLQUFLMkIsV0FBV2MsV0FBVyxDQUFDO0FBQ2pELFVBQU1LLFNBQVMsSUFBSTlDLEtBQUsyQixXQUFXZSxTQUFTLENBQUM7QUFDN0MsVUFBTXhCLFNBQVM2QixXQUFXSixhQUFhO0FBRXZDLFFBQUlHLFNBQVNELFlBQVlkLE1BQU1iLE1BQU0sR0FBRztBQUN0Q0ksMEJBQW9CLEVBQUU7QUFDdEJFLHFCQUFlLE1BQU07QUFDckJFLHlCQUFtQixNQUFNO0FBQ3pCO0FBQUEsSUFDRjtBQUVBLFFBQUlzQixVQUFVLElBQUloRCxLQUFLNkMsUUFBUTtBQUMvQixRQUFJSSxjQUFjO0FBRWxCLFdBQU9ELFdBQVdGLFFBQVE7QUFDeEIsWUFBTWQsT0FBT2dCLFFBQVFmLFlBQVk7QUFDakMsWUFBTUMsUUFBUWMsUUFBUVosU0FBUztBQUMvQixZQUFNYyxjQUFjLElBQUlsRCxLQUFLZ0MsTUFBTUUsUUFBUSxHQUFHLENBQUMsRUFBRUssUUFBUTtBQUV6RCxZQUFNWSxVQUNKSCxRQUFRZixZQUFZLE1BQU1ZLFNBQVNaLFlBQVksS0FDL0NlLFFBQVFaLFNBQVMsTUFBTVMsU0FBU1QsU0FBUyxJQUNyQ1MsU0FBU04sUUFBUSxJQUNqQjtBQUVOLFlBQU1hLFFBQ0pKLFFBQVFmLFlBQVksTUFBTWEsT0FBT2IsWUFBWSxLQUM3Q2UsUUFBUVosU0FBUyxNQUFNVSxPQUFPVixTQUFTLElBQ25DVSxPQUFPUCxRQUFRLElBQ2ZXO0FBRU4sWUFBTUcsYUFBYUQsUUFBUUQsVUFBVTtBQUNyQyxZQUFNRyxjQUFjcEMsU0FBU2dDO0FBRTdCRCxxQkFBZUksYUFBYUM7QUFDNUJOLGdCQUFVLElBQUloRCxLQUFLZ0MsTUFBTUUsUUFBUSxHQUFHLENBQUM7QUFBQSxJQUN2QztBQUVBLFVBQU1xQixpQkFBaUJOO0FBQ3ZCLFVBQU1PLDRCQUE0QkQ7QUFFbENqQyx3QkFBb0JrQywwQkFBMEJDLFFBQVEsQ0FBQyxDQUFDO0FBQ3hEckMsMEJBQXNCb0MsMEJBQTBCQyxRQUFRLENBQUMsQ0FBQztBQUUxRCxRQUFJO0FBQ0YsWUFBTUMsTUFBTSxNQUFNM0csSUFBSTRHLElBQUksa0NBQWtDO0FBQzVELFlBQU1DLGNBQWNGLEtBQUtHLE1BQU1DLE9BQU8sQ0FBQ0MsTUFBTTtBQUMzQyxjQUFNQyxXQUFXRCxFQUFFNUQsVUFBVThELE1BQ3pCOUIsT0FBTzRCLEVBQUU1RCxTQUFTOEQsR0FBRyxJQUNyQjlCLE9BQU80QixFQUFFNUQsUUFBUTtBQUNyQixjQUFNK0QsZUFBZUYsYUFBYTdCLE9BQU9TLEtBQUs7QUFDOUMsY0FBTXVCLFVBQVUsSUFBSW5FLEtBQUsyQixXQUFXb0MsRUFBRTNELFFBQVEsQ0FBQztBQUMvQyxlQUFPOEQsZ0JBQWdCQyxXQUFXdEIsWUFBWXNCLFdBQVdyQjtBQUFBQSxNQUMzRCxDQUFDO0FBRUQsWUFBTXNCLFlBQVlSLFlBQVlTO0FBQUFBLFFBQzVCLENBQUNDLEtBQUtQLE1BQU1PLE1BQU12QixXQUFXZ0IsRUFBRXRELFVBQVUsQ0FBQztBQUFBLFFBQzFDO0FBQUEsTUFDRjtBQUVBLFlBQU0xQixZQUFZeUUsNEJBQTRCWTtBQUU5QzVDLHFCQUFlNEMsVUFBVVgsUUFBUSxDQUFDLENBQUM7QUFDbkMvQix5QkFBbUIzQyxVQUFVMEUsUUFBUSxDQUFDLENBQUM7QUFBQSxJQUN6QyxTQUFTYyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sZ0RBQWdEQSxLQUFLO0FBQ25FL0MscUJBQWUsTUFBTTtBQUNyQkUseUJBQW1COEIsMEJBQTBCQyxRQUFRLENBQUMsQ0FBQztBQUFBLElBQ3pEO0FBQUEsRUFDRjtBQUVBLFFBQU1nQix1QkFBdUIsT0FBTzdCLFVBQVU7QUFDNUMsUUFBSTtBQUNGLFlBQU1jLE1BQU0sTUFBTTNHLElBQUk0RztBQUFBQSxRQUNwQiw2Q0FBNkNmLEtBQUs7QUFBQSxNQUNwRDtBQUNBLFlBQU04QixNQUFNaEIsS0FBS0csTUFBTWM7QUFDdkIsVUFBSUQsS0FBSztBQUNQLGNBQU1FLFVBQVVGLElBQUl6RCxjQUFjWCxNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUs7QUFDbkQsY0FBTXVFLGFBQWFILElBQUl4RCxVQUFVO0FBQ2pDRiwyQkFBbUIsRUFBRUMsY0FBYzJELFNBQVMxRCxRQUFRMkQsV0FBVyxDQUFDO0FBRWhFLFlBQUk1RSxXQUFXTSxhQUFhTixXQUFXTyxTQUFTO0FBQzlDLGdCQUFNc0UsS0FBS25ELFdBQVcxQixXQUFXTSxTQUFTO0FBQzFDLGdCQUFNd0UsS0FBS3BELFdBQVcxQixXQUFXTyxPQUFPO0FBQ3hDd0UsNkJBQW1CcEMsT0FBT2tDLElBQUlDLEVBQUU7QUFDaEN2QyxrQ0FBd0JzQyxJQUFJQyxJQUFJRixZQUFZakMsS0FBSztBQUFBLFFBQ25EO0FBQUEsTUFDRjtBQUFBLElBQ0YsU0FBU3FDLEtBQUs7QUFDWlQsY0FBUUQsTUFBTSxnQ0FBZ0NVLEdBQUc7QUFDakRqRSx5QkFBbUIsRUFBRUMsY0FBYyxJQUFJQyxRQUFRLEdBQUcsQ0FBQztBQUNuREksMEJBQW9CLEVBQUU7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNEQsY0FBYyxZQUFZO0FBQzlCLFFBQUk7QUFDRixZQUFNQyxXQUFXLE1BQU1wSSxJQUFJNEcsSUFBSSxXQUFXO0FBQzFDdkUsZ0JBQVUrRixTQUFTdEIsTUFBTWMsWUFBWSxFQUFFO0FBQUEsSUFDekMsU0FBU0osT0FBTztBQUNkQyxjQUFRRCxNQUFNLHdCQUF3QjtBQUFBLElBQ3hDO0FBQUEsRUFDRjtBQUVBLFFBQU1hLHNCQUFzQixZQUFZO0FBQ3RDNUYsaUJBQWEsSUFBSTtBQUNqQixRQUFJO0FBQ0YsWUFBTTJGLFdBQVcsTUFBTXBJLElBQUk0RyxJQUFJLGtDQUFrQztBQUNqRSxZQUFNMEIsZUFBZUYsU0FBU3RCLEtBQUt5QixJQUFJLENBQUNDLFNBQVNDLFdBQVc7QUFBQSxRQUMxREMsSUFBSUQsUUFBUTtBQUFBLFFBQ1p2QixLQUFLc0IsUUFBUXRCO0FBQUFBLFFBQ2I5RCxVQUFVb0YsUUFBUXBGO0FBQUFBLFFBQ2xCdUYsWUFBWUgsUUFBUXBGLFVBQVV3RjtBQUFBQSxRQUM5QnZGLFVBQVVtRixRQUFRbkY7QUFBQUEsUUFDbEJLLFFBQVE4RSxRQUFROUU7QUFBQUEsUUFDaEJDLFVBQVU2RSxRQUFRN0U7QUFBQUEsUUFDbEJDLGdCQUFnQjRFLFFBQVE1RTtBQUFBQSxRQUN4QkMsTUFBTTJFLFFBQVEzRTtBQUFBQSxRQUNkQyxTQUFTMEUsUUFBUTFFO0FBQUFBLFFBQ2pCK0UsY0FBY0wsUUFBUXpFLFlBQVk2RTtBQUFBQSxRQUNsQ0UsWUFBWU4sUUFBUU07QUFBQUEsTUFDdEIsRUFBRTtBQUNGdkcsd0JBQWtCK0YsWUFBWTtBQUFBLElBQ2hDLFNBQVNkLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxtQ0FBbUNBLEtBQUs7QUFDdERqRix3QkFBa0IsRUFBRTtBQUFBLElBQ3RCLFVBQUM7QUFDQ0UsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBLFFBQU13RixxQkFBcUIsT0FBT2MsU0FBU2pELFVBQVVDLFdBQVc7QUFDOUQsUUFBSSxDQUFDZ0QsV0FBVyxDQUFDakQsWUFBWSxDQUFDQyxRQUFRO0FBQ3BDaUQsc0JBQWdCO0FBQ2hCO0FBQUEsSUFDRjtBQUVBLFFBQUk7QUFDRixZQUFNckMsTUFBTSxNQUFNM0csSUFBSTRHLElBQUksb0JBQW9CbUMsT0FBTyxJQUFJO0FBQUEsUUFDdkRFLFFBQVEsRUFBRXpGLFdBQVdzQyxVQUFVckMsU0FBU3NDLE9BQU87QUFBQSxNQUNqRCxDQUFDO0FBRUQsVUFBSVksSUFBSUcsTUFBTW9DLFdBQVd2QyxJQUFJRyxNQUFNcUMsU0FBUztBQUMxQyxjQUFNQyxhQUFhekMsSUFBSUcsS0FBS3FDO0FBRTVCdEgsc0JBQWM7QUFBQSxVQUNaQyxRQUFRc0gsV0FBV0MsT0FBT3ZILFFBQVF3SCxTQUFTO0FBQUEsVUFDM0N2SCxVQUFVcUgsV0FBV0csU0FBU0MsbUJBQW1CO0FBQUEsVUFDakR2SCxZQUFZbUgsV0FBV0csU0FBU0UscUJBQXFCO0FBQUEsVUFDckR6SCxXQUFXb0gsV0FBV0csU0FBU0csb0JBQW9CO0FBQUEsVUFDbkR4SCxpQkFBaUJrSCxXQUFXRyxTQUFTSSxtQkFBbUI7QUFBQSxVQUN4RHhILG1CQUNHaUgsV0FBV0MsT0FBT3ZILFFBQVE4SCx1QkFBdUIsT0FBTztBQUFBLFFBQzdELENBQUM7QUFDRDtBQUFBLE1BQ0Y7QUFFQVosc0JBQWdCO0FBQUEsSUFDbEIsU0FBU3hCLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxpQ0FBaUNBLEtBQUs7QUFDcER3QixzQkFBZ0I7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNQSxrQkFBa0JBLE1BQU07QUFDNUJuSCxrQkFBYztBQUFBLE1BQ1pDLFFBQVE7QUFBQSxNQUNSQyxVQUFVO0FBQUEsTUFDVkUsWUFBWTtBQUFBLE1BQ1pELFdBQVc7QUFBQSxNQUNYRSxpQkFBaUI7QUFBQSxNQUNqQkMsa0JBQWtCO0FBQUEsSUFDcEIsQ0FBQztBQUFBLEVBQ0g7QUFHQXRDLFlBQVUsTUFBTTtBQUNkLFVBQU1nSyxPQUFPQyxhQUFhQyxRQUFRLE1BQU07QUFDeEMsVUFBTUMsVUFBVUMsS0FBS0MsTUFBTUwsSUFBSTtBQUMvQnhJLGVBQVcySSxRQUFROUMsR0FBRztBQUN0QnZFLGlCQUFhcUgsUUFBUXBCLFFBQVEsRUFBRTtBQUUvQixRQUFJb0IsU0FBU0csdUJBQXVCQyxvQkFBb0JDLGNBQWM7QUFDcEVsSjtBQUFBQSxRQUNFNkksUUFBUUcsc0JBQXNCQyxtQkFBbUJDLGlCQUFpQjtBQUFBLE1BQ3BFO0FBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBR0x4SyxZQUFVLE1BQU07QUFDZHNJLGdCQUFZO0FBQ1pFLHdCQUFvQjtBQUFBLEVBQ3RCLEdBQUcsQ0FBQ3ZGLFFBQVEsQ0FBQztBQUViLFFBQU13SCxxQkFBcUJBLENBQUNDLE1BQU07QUFDaEMsVUFBTSxFQUFFM0IsTUFBTVUsTUFBTSxJQUFJaUIsRUFBRXpJO0FBQzFCcUIsa0JBQWMsQ0FBQ3FILFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUM1QixJQUFJLEdBQUdVLE1BQU0sRUFBRTtBQUNwRHpHLGNBQVUsQ0FBQzJILFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUM1QixJQUFJLEdBQUcsR0FBRyxFQUFFO0FBQUEsRUFDL0M7QUFFQSxRQUFNNkIsZUFBZUEsTUFBTTtBQUN6QixVQUFNQyxZQUFZLENBQUM7QUFFbkIsUUFBSSxDQUFDeEgsV0FBV0UsU0FBVXNILFdBQVV0SCxXQUFXO0FBQy9DLFFBQUksQ0FBQ0YsV0FBV1EsVUFBVXNCLE1BQU05QixXQUFXUSxNQUFNO0FBQy9DZ0gsZ0JBQVVoSCxTQUFTO0FBQ3JCLFFBQUlSLFdBQVdTLGFBQWEsWUFBWSxDQUFDVCxXQUFXVTtBQUNsRDhHLGdCQUFVL0csV0FBVztBQUV2QmQsY0FBVTZILFNBQVM7QUFDbkIsV0FBT0MsT0FBT0MsS0FBS0YsU0FBUyxFQUFFRyxXQUFXO0FBQUEsRUFDM0M7QUFFQSxRQUFNQyxxQkFBcUIsT0FBT1AsTUFBTTtBQUN0Q0EsTUFBRVEsZUFBZTtBQUNqQixVQUFNQyxVQUFVUCxhQUFhO0FBQzdCLFFBQUlPLFNBQVM7QUFDWCxVQUFJO0FBQ0Z2SSxxQkFBYSxJQUFJO0FBQ2pCLGNBQU13SSxVQUFVO0FBQUEsVUFDZCxHQUFHL0g7QUFBQUEsVUFDSGEsWUFBWTNDO0FBQUFBLFFBQ2Q7QUFDQSxjQUFNcEIsSUFBSWtMLEtBQUssbUNBQW1DRCxPQUFPO0FBQ3pEcEssWUFBSXNLLEtBQUs7QUFBQSxVQUNQMUosU0FBUztBQUFBLFVBQ1QySixhQUFhO0FBQUEsVUFDYkMsV0FBVztBQUFBLFVBQ1hDLGNBQWM7QUFBQSxVQUNkQyxjQUFjO0FBQUEsUUFDaEIsQ0FBQztBQUNEdEssMkJBQW1CLEtBQUs7QUFDeEJ1SyxrQkFBVTtBQUNWekksb0JBQVksQ0FBQzBJLFFBQVFBLE1BQU0sQ0FBQztBQUM1QnBELDRCQUFvQjtBQUFBLE1BQ3RCLFNBQVNiLE9BQU87QUFDZCxjQUFNL0YsVUFBVStGLE1BQU0vRixXQUFXO0FBQ2pDWixZQUFJc0ssS0FBSztBQUFBLFVBQ1AxSixTQUFTO0FBQUEsVUFDVDJKLGFBQWEzSjtBQUFBQSxVQUNiNkosY0FBYztBQUFBLFVBQ2RDLGNBQWM7QUFBQSxVQUNkRixXQUFXO0FBQUEsUUFDYixDQUFDO0FBQUEsTUFDSCxVQUFDO0FBQ0M1SSxxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU0rSSxZQUFZQSxNQUFNO0FBQ3RCckksa0JBQWM7QUFBQSxNQUNaQyxVQUFVO0FBQUEsTUFDVkMsVUFBVUwsTUFBTU0sWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDMUNDLFdBQVc7QUFBQSxNQUNYQyxTQUFTO0FBQUEsTUFDVEMsUUFBUTtBQUFBLE1BQ1JDLFVBQVU7QUFBQSxNQUNWQyxnQkFBZ0I7QUFBQSxNQUNoQkMsTUFBTTtBQUFBLE1BQ05DLFNBQVNsRDtBQUFBQSxNQUNUbUQsWUFBWTNDO0FBQUFBLElBQ2QsQ0FBQztBQUNENkMsdUJBQW1CLEVBQUVDLGNBQWMsSUFBSUMsUUFBUSxHQUFHLENBQUM7QUFDbkRJLHdCQUFvQixFQUFFO0FBQ3RCRSxtQkFBZSxNQUFNO0FBQ3JCRSx1QkFBbUIsTUFBTTtBQUN6QnFFLG9CQUFnQjtBQUFBLEVBQ2xCO0FBRUEsUUFBTTBDLGdCQUFnQjtBQUFBLElBQ3BCLEVBQUVDLEtBQUssTUFBTUMsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxZQUFZQyxRQUFRLFdBQVc7QUFBQSxJQUN0QyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsUUFBUTtBQUFBLElBQ3JDLEVBQUVELEtBQUssVUFBVUMsUUFBUSxhQUFhO0FBQUEsSUFDdEMsRUFBRUQsS0FBSyxZQUFZQyxRQUFRLGVBQWU7QUFBQSxJQUMxQyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVELEtBQUssUUFBUUMsUUFBUSxPQUFPO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZUFBZTtBQUFBLEVBQUM7QUFHakQsU0FDRSxtQ0FDRSxpQ0FBQyxTQUNFOUs7QUFBQUE7QUFBQUEsSUFDRCx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDZCQUFDLFVBQU8sWUFBWSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFDekIsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUNSO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFNUSxZQUFZSztBQUFBQSxVQUNsQixXQUFXTCxZQUFZRTtBQUFBQSxVQUN2QixTQUFTRixZQUFZRztBQUFBQSxVQUNyQixVQUFVSCxZQUFZSTtBQUFBQTtBQUFBQSxRQUp4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJaUM7QUFBQSxNQUVqQyx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMEJBQ1o7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsbUNBQ2JkLHNCQUFZaUwsWUFBWSxLQUQzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFBUTtBQUFBLFlBQUk7QUFBQSxlQUhkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBLHVCQUFDLFdBQVEsT0FBTSxzQkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNO0FBQ2I1SyxtQ0FBbUIsSUFBSTtBQUN2QnVLLDBCQUFVO0FBQUEsY0FDWjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsUUFBTyxpQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0I7QUFBQSxnQkFBTztBQUFBO0FBQUE7QUFBQSxZQVBqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxhQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsNERBQTJELCtCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQ2xKLGVBQWV1SSxTQUFTLElBQ3ZCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNdkk7QUFBQUEsY0FDTixTQUFTb0o7QUFBQUEsY0FDVCxpQkFBZ0I7QUFBQSxjQUNoQixrQkFBa0I7QUFBQTtBQUFBLFlBSnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUl3QyxJQUd4Qyx1QkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDO0FBQUEsY0FDQSxNQUFLO0FBQUEsY0FDTCxTQUFTcEosZUFBZXVJLFdBQVc7QUFBQTtBQUFBLFlBSHJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUd1QyxLQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsYUFuQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFCQTtBQUFBLFdBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQ0E7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFXN0o7QUFBQUEsVUFDWCxTQUFTLE1BQU07QUFDYkMsK0JBQW1CLEtBQUs7QUFDeEJ1SyxzQkFBVTtBQUFBLFVBQ1o7QUFBQSxVQUVBLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSxzREFBcUQsa0NBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVVWLG9CQUNwQztBQUFBLHFDQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsa0JBQ3JELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxxQkFEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxrQkFBaUI7QUFBQSxvQkFDakIsY0FBYyxDQUFDZ0IsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pDLFlBQVksRUFDWkMsU0FBU0osTUFBTUcsWUFBWSxDQUFDO0FBQUEsb0JBRWpDLE9BQU8vSSxXQUFXRSxZQUFZK0k7QUFBQUEsb0JBQzlCLFVBQVUsQ0FBQzdDLFVBQVU7QUFDbkJ6RyxnQ0FBVSxDQUFDMkgsVUFBVSxFQUFFLEdBQUdBLE1BQU1wSCxVQUFVLEdBQUcsRUFBRTtBQUMvQ0Qsb0NBQWMsQ0FBQ3FILFVBQVU7QUFBQSx3QkFDdkIsR0FBR0E7QUFBQUEsd0JBQ0hwSCxVQUFVa0c7QUFBQUEsd0JBQ1Y5RixXQUFXO0FBQUEsd0JBQ1hDLFNBQVM7QUFBQSx3QkFDVEMsUUFBUTtBQUFBLHNCQUNWLEVBQUU7QUFDRk8seUNBQW1CLEVBQUVDLGNBQWMsSUFBSUMsUUFBUSxHQUFHLENBQUM7QUFDbkRJLDBDQUFvQixFQUFFO0FBQ3RCRSxxQ0FBZSxNQUFNO0FBQ3JCRSx5Q0FBbUIsTUFBTTtBQUN6QnFFLHNDQUFnQjtBQUNoQnRCLDJDQUFxQjRCLEtBQUs7QUFBQSxvQkFDNUI7QUFBQSxvQkFFQ2xILGlCQUFPbUc7QUFBQUEsc0JBQUksQ0FBQ2MsVUFDWCx1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsTUFBTW5DLEtBQ3pDLGFBQUdtQyxNQUFNVCxJQUFJLE1BQU1TLE1BQU0rQyxZQUFZLE1BRHBCL0MsTUFBTW5DLEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxvQkFDRDtBQUFBO0FBQUEsa0JBaENIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFpQ0E7QUFBQSxnQkFDQ3RFLE9BQU9RLFlBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWUixpQkFBT1EsWUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBekNKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMkNBO0FBQUEsY0FFQ1ksZ0JBQWdCRSxnQkFDZixtQ0FDRTtBQUFBLHVDQUFDLFNBQ0M7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE9BQU9GLGdCQUFnQkU7QUFBQUEsc0JBQ3ZCO0FBQUEsc0JBQ0EsV0FBVTtBQUFBO0FBQUEsb0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUk4RjtBQUFBLHFCQVJoRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVVBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEseUNBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLHNCQUNwRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUEseUJBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9oQixXQUFXTTtBQUFBQSx3QkFDbEIsVUFBVThHO0FBQUFBLHdCQUNWLFdBQVU7QUFBQTtBQUFBLHNCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLMEQ7QUFBQSx1QkFUNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFXQTtBQUFBLGtCQUVBLHVCQUFDLFNBQ0M7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxzQkFDdEQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnQztBQUFBLHlCQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPcEgsV0FBV087QUFBQUEsd0JBQ2xCLFVBQVU2RztBQUFBQSx3QkFDVixXQUFVO0FBQUE7QUFBQSxzQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBSzBEO0FBQUEsdUJBVDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBV0E7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsV0FBVTtBQUFBLHNCQUNWLFNBQVMsTUFBTTtBQUNiLDRCQUNFcEgsV0FBV0UsWUFDWEYsV0FBV00sYUFDWE4sV0FBV08sV0FDWE8sZ0JBQWdCRyxRQUNoQjtBQUNBLGdDQUFNNEQsS0FBS25ELFdBQVcxQixXQUFXTSxTQUFTO0FBQzFDLGdDQUFNd0UsS0FBS3BELFdBQVcxQixXQUFXTyxPQUFPO0FBQ3hDd0UsNkNBQW1CL0UsV0FBV0UsVUFBVTJFLElBQUlDLEVBQUU7QUFDOUN2QztBQUFBQSw0QkFDRXNDO0FBQUFBLDRCQUNBQztBQUFBQSw0QkFDQWhFLGdCQUFnQkc7QUFBQUEsNEJBQ2hCakIsV0FBV0U7QUFBQUEsMEJBQ2I7QUFBQSx3QkFDRjtBQUFBLHNCQUNGO0FBQUEsc0JBQUU7QUFBQTtBQUFBLG9CQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBdUJBLEtBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBeUJBO0FBQUEscUJBcERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBcURBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLHlEQUNiO0FBQUEseUNBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSw2QkFBNEIsc0JBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUFPLEdBQUd4QixXQUFXRSxRQUFRdUs7QUFBQUEsMEJBQzNCO0FBQUEsd0JBQ0YsQ0FBQztBQUFBLHdCQUNEO0FBQUEsd0JBQ0EsV0FBVTtBQUFBO0FBQUEsc0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtvRTtBQUFBLHVCQVR0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVdBO0FBQUEsa0JBQ0EsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSw2QkFBNEIsd0JBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUFPLEdBQUd6SyxXQUFXRyxVQUFVc0s7QUFBQUEsMEJBQzdCO0FBQUEsd0JBQ0YsQ0FBQztBQUFBLHdCQUNEO0FBQUEsd0JBQ0EsV0FBVTtBQUFBO0FBQUEsc0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtvRTtBQUFBLHVCQVR0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVdBO0FBQUEsa0JBQ0EsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSw2QkFBNEIsMEJBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUFPLEdBQUd6SyxXQUFXSyxZQUFZb0s7QUFBQUEsMEJBQy9CO0FBQUEsd0JBQ0YsQ0FBQztBQUFBLHdCQUNEO0FBQUEsd0JBQ0EsV0FBVTtBQUFBO0FBQUEsc0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtvRTtBQUFBLHVCQVR0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVdBO0FBQUEscUJBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBcUNBO0FBQUEsZ0JBRUEsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFdBQU0sV0FBVSxnREFBK0Msa0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsT0FBT3JJLGdCQUFnQkc7QUFBQUEsc0JBQ3ZCO0FBQUEsc0JBQ0EsV0FBVTtBQUFBO0FBQUEsb0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUk4RjtBQUFBLHFCQVJoRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVVBO0FBQUEsZ0JBRUEsdUJBQUMsU0FDQztBQUFBLHlDQUFDLFdBQU0sV0FBVSxnREFBK0Msd0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsT0FBT0c7QUFBQUEsc0JBQ1A7QUFBQSxzQkFDQSxXQUFVO0FBQUE7QUFBQSxvQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSWtGO0FBQUEscUJBUnBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQSxtQkFsSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFtSUE7QUFBQSxjQUdGLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT3BCLFdBQVdHO0FBQUFBLG9CQUNsQixVQUFVaUg7QUFBQUEsb0JBQ1YsV0FBVTtBQUFBLG9CQUNWLFVBQVUsQ0FBQ3BKO0FBQUFBO0FBQUFBLGtCQU5iO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNMkI7QUFBQSxtQkFWN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQTtBQUFBLGNBRUNvRCxvQkFDQyx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGtCQUNyQztBQUFBLGtCQUN6Qix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEscUJBRmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLEtBQUs7QUFBQSxvQkFDTCxPQUFPcEIsV0FBV1E7QUFBQUEsb0JBQ2xCLFVBQVUsQ0FBQzZHLE1BQU07QUFDZiw0QkFBTWtCLE1BQU16RixXQUFXdUUsRUFBRXpJLE9BQU93SCxTQUFTLENBQUM7QUFDMUMsNEJBQU1nRCxNQUFNdEcsV0FBV3RCLGVBQWU7QUFDdEMsMEJBQUkrRyxNQUFNYSxLQUFLO0FBQ2J6SixrQ0FBVSxDQUFDMkgsVUFBVTtBQUFBLDBCQUNuQixHQUFHQTtBQUFBQSwwQkFDSDlHLFFBQVEseUJBQXlCNEksSUFBSTVGLFFBQVEsQ0FBQyxDQUFDO0FBQUEsd0JBQ2pELEVBQUU7QUFBQSxzQkFDSixPQUFPO0FBQ0x2RCxzQ0FBYyxDQUFDcUgsVUFBVTtBQUFBLDBCQUN2QixHQUFHQTtBQUFBQSwwQkFDSDlHLFFBQVE2RyxFQUFFekksT0FBT3dIO0FBQUFBLHdCQUNuQixFQUFFO0FBQ0Z6RyxrQ0FBVSxDQUFDMkgsVUFBVSxFQUFFLEdBQUdBLE1BQU05RyxRQUFRLEdBQUcsRUFBRTtBQUFBLHNCQUMvQztBQUFBLG9CQUNGO0FBQUEsb0JBQ0EsV0FBVTtBQUFBLG9CQUNWLGFBQVk7QUFBQTtBQUFBLGtCQXRCZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBc0JtQztBQUFBLGdCQUVsQ2QsT0FBT2MsVUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZkLGlCQUFPYyxVQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFHRix1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSx5Q0FBQyxTQUNDO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyxnQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxPQUFPYztBQUFBQSx3QkFDUDtBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFJZ0c7QUFBQSx1QkFSbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFVQTtBQUFBLGtCQUVBLHVCQUFDLFNBQ0M7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLG9DQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE9BQU9FO0FBQUFBLHdCQUNQO0FBQUEsd0JBQ0EsV0FBVTtBQUFBO0FBQUEsc0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUkwRjtBQUFBLHVCQVI1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVVBO0FBQUEscUJBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBd0JBO0FBQUEsbUJBM0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNERBO0FBQUEsY0FHRix1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0MsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsT0FBT3hCLFdBQVdTO0FBQUFBLG9CQUNsQixVQUFVMkc7QUFBQUEsb0JBQ1YsV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsWUFBTyxPQUFNLFFBQU8sb0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXlCO0FBQUEsc0JBQ3pCLHVCQUFDLFlBQU8sT0FBTSxVQUFTLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE2QjtBQUFBLHNCQUM1QnBKLGlCQUNDLG1DQUNFO0FBQUEsK0NBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTZCO0FBQUEsd0JBQzdCLHVCQUFDLFlBQU8sT0FBTSxpQkFBZ0IsNkJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTJDO0FBQUEsMkJBRjdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBR0E7QUFBQTtBQUFBO0FBQUEsa0JBWko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWNBO0FBQUEsbUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbUJBO0FBQUEsY0FFQ2dDLFdBQVdTLGFBQWEsWUFDdkIsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxrQkFDL0MsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBLHFCQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPVCxXQUFXVTtBQUFBQSxvQkFDbEIsVUFBVTBHO0FBQUFBLG9CQUNWLFdBQVU7QUFBQTtBQUFBLGtCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLMEQ7QUFBQSxtQkFUNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFXQTtBQUFBLGNBR0YsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLG9CQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE9BQU9wSCxXQUFXVztBQUFBQSxvQkFDbEIsVUFBVXlHO0FBQUFBLG9CQUNWLFdBQVU7QUFBQSxvQkFDVixNQUFLO0FBQUE7QUFBQSxrQkFMUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS1U7QUFBQSxtQkFUWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVdBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsc0NBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUFpQjVILHVCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwQztBQUFBLG1CQUo1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBUyxNQUFNekIsbUJBQW1CLEtBQUs7QUFBQSxvQkFDdkMsV0FBVTtBQUFBLG9CQUE2RTtBQUFBO0FBQUEsa0JBSHpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxVQUFVdUI7QUFBQUEsb0JBQ1YsV0FBVTtBQUFBLG9CQUVUQSxzQkFBWSxrQkFBa0I7QUFBQTtBQUFBLGtCQUxqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxtQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWVBO0FBQUEsaUJBMVVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMlVBO0FBQUEsZUEvVUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnVkE7QUFBQTtBQUFBLFFBdlZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXdWQTtBQUFBLFNBOVlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErWUE7QUFBQSxPQWpaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa1pBLEtBblpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvWkE7QUFFSjtBQUFFN0IsR0Fsd0JJRCxvQkFBa0I7QUFBQSxVQUVPRixhQUFhTyxlQUFlO0FBQUE7QUFBQXdMLEtBRnJEN0w7QUFvd0JOLGVBQWVBO0FBQW1CLElBQUE2TDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJTaWRlYmFyIiwiQVBJIiwiTW9kYWwiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydCIsIkNpcmN1bGFyTG9hZGVyIiwiTmF2YmFyIiwiU2VsZWN0IiwiVG9vbHRpcCIsIm5vdGlmaWNhdGlvbiIsIlNldHRpbmdTaWRlYmFyIiwiVGFyZ2V0UGF5T3V0U2FsYXJ5IiwiX3MiLCJwYXltZW50Rm9yIiwiYXBpIiwiY29udGV4dEhvbGRlciIsInVzZU5vdGlmaWNhdGlvbiIsInNob3dTYWxhcnlNb2RhbCIsInNldFNob3dTYWxhcnlNb2RhbCIsIm1vZGlmeVBheW1lbnQiLCJzZXRNb2RpZnlQYXltZW50IiwiYWRtaW5JZCIsInNldEFkbWluSWQiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJub1JlbG9hZCIsInR5cGUiLCJ0YXJnZXREYXRhIiwic2V0VGFyZ2V0RGF0YSIsInRhcmdldCIsImFjaGlldmVkIiwicmVtYWluaW5nIiwiZGlmZmVyZW5jZSIsImluY2VudGl2ZUFtb3VudCIsImluY2VudGl2ZVBlcmNlbnQiLCJhZ2VudHMiLCJzZXRBZ2VudHMiLCJzYWxhcnlQYXltZW50cyIsInNldFNhbGFyeVBheW1lbnRzIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwiYWRtaW5OYW1lIiwic2V0QWRtaW5OYW1lIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwicmVSZW5kZXIiLCJzZXRSZVJlbmRlciIsInRvZGF5IiwiRGF0ZSIsInNhbGFyeUZvcm0iLCJzZXRTYWxhcnlGb3JtIiwiYWdlbnRfaWQiLCJwYXlfZGF0ZSIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJmcm9tX2RhdGUiLCJ0b19kYXRlIiwiYW1vdW50IiwicGF5X3R5cGUiLCJ0cmFuc2FjdGlvbl9pZCIsIm5vdGUiLCJwYXlfZm9yIiwiYWRtaW5fdHlwZSIsImVtcGxveWVlRGV0YWlscyIsInNldEVtcGxveWVlRGV0YWlscyIsImpvaW5pbmdfZGF0ZSIsInNhbGFyeSIsInRvdGFsV2l0aEluY2VudGl2ZSIsInNldFRvdGFsV2l0aEluY2VudGl2ZSIsImNhbGN1bGF0ZWRTYWxhcnkiLCJzZXRDYWxjdWxhdGVkU2FsYXJ5IiwiYWxyZWFkeVBhaWQiLCJzZXRBbHJlYWR5UGFpZCIsInJlbWFpbmluZ1NhbGFyeSIsInNldFJlbWFpbmluZ1NhbGFyeSIsImZvcm1hdERhdGUiLCJkYXRlIiwidGVzdCIsImQiLCJpc05hTiIsInllYXIiLCJnZXRGdWxsWWVhciIsIm1vbnRoIiwiU3RyaW5nIiwiZ2V0TW9udGgiLCJwYWRTdGFydCIsImRheSIsImdldERhdGUiLCJjYWxjdWxhdGVQcm9SYXRlZFNhbGFyeSIsImZyb21EYXRlU3RyIiwidG9EYXRlU3RyIiwibW9udGhseVNhbGFyeSIsImVtcElkIiwiZnJvbURhdGUiLCJ0b0RhdGUiLCJwYXJzZUZsb2F0IiwiY3VycmVudCIsInRvdGFsU2FsYXJ5IiwiZGF5c0luTW9udGgiLCJmcm9tRGF5IiwidG9EYXkiLCJkYXlzV29ya2VkIiwiZGFpbHlTYWxhcnkiLCJwcm9SYXRlZFNhbGFyeSIsInRvdGFsUGF5YWJsZVdpdGhJbmNlbnRpdmUiLCJ0b0ZpeGVkIiwicmVzIiwiZ2V0IiwicGFpZFRvQWdlbnQiLCJkYXRhIiwiZmlsdGVyIiwicCIsInBBZ2VudElkIiwiX2lkIiwibWF0Y2hlc0FnZW50IiwicGF5RGF0ZSIsInRvdGFsUGFpZCIsInJlZHVjZSIsInN1bSIsImVycm9yIiwiY29uc29sZSIsImZldGNoRW1wbG95ZWVEZXRhaWxzIiwiZW1wIiwiZW1wbG95ZWUiLCJqb2luaW5nIiwiYmFzZVNhbGFyeSIsImZkIiwidGQiLCJmZXRjaFRhcmdldERldGFpbHMiLCJlcnIiLCJmZXRjaEFnZW50cyIsInJlc3BvbnNlIiwiZmV0Y2hTYWxhcnlQYXltZW50cyIsInJlc3BvbnNlRGF0YSIsIm1hcCIsInBheW1lbnQiLCJpbmRleCIsImlkIiwiYWdlbnRfbmFtZSIsIm5hbWUiLCJkaXNidXJzZWRfYnkiLCJyZWNlaXB0X25vIiwiYWdlbnRJZCIsInJlc2V0VGFyZ2V0RGF0YSIsInBhcmFtcyIsInN1Y2Nlc3MiLCJzdW1tYXJ5IiwiZW1wU3VtbWFyeSIsImFnZW50IiwidmFsdWUiLCJtZXRyaWNzIiwiYWN0dWFsX2J1c2luZXNzIiwidGFyZ2V0X2RpZmZlcmVuY2UiLCJ0YXJnZXRfcmVtYWluaW5nIiwidG90YWxfZXN0aW1hdGVkIiwiYWNoaWV2ZW1lbnRfcGVyY2VudCIsInVzZXIiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwidXNlck9iaiIsIkpTT04iLCJwYXJzZSIsImFkbWluX2FjY2Vzc19yaWdodF9pZCIsImFjY2Vzc19wZXJtaXNzaW9ucyIsImVkaXRfcGF5bWVudCIsImhhbmRsZVNhbGFyeUNoYW5nZSIsImUiLCJwcmV2IiwidmFsaWRhdGVGb3JtIiwibmV3RXJyb3JzIiwiT2JqZWN0Iiwia2V5cyIsImxlbmd0aCIsImhhbmRsZVNhbGFyeVN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwiaXNWYWxpZCIsInBheWxvYWQiLCJwb3N0Iiwib3BlbiIsImRlc2NyaXB0aW9uIiwiY2xhc3NOYW1lIiwic2hvd1Byb2dyZXNzIiwicGF1c2VPbkhvdmVyIiwicmVzZXRGb3JtIiwidmFsIiwic2FsYXJ5Q29sdW1ucyIsImtleSIsImhlYWRlciIsInRvVXBwZXJDYXNlIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJ1bmRlZmluZWQiLCJwaG9uZV9udW1iZXIiLCJ0b0xvY2FsZVN0cmluZyIsInJlbSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlRhcmdldFBheW91dFNhbGFyeS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IEFQSSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0IGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydFwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgVG9vbHRpcCwgbm90aWZpY2F0aW9uIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IFNldHRpbmdTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2V0dGluZ1NpZGViYXJcIjtcclxuXHJcbmNvbnN0IFRhcmdldFBheU91dFNhbGFyeSA9ICgpID0+IHtcclxuICBjb25zdCBwYXltZW50Rm9yID0gXCJzYWxhcnlcIjtcclxuICBjb25zdCBbYXBpLCBjb250ZXh0SG9sZGVyXSA9IG5vdGlmaWNhdGlvbi51c2VOb3RpZmljYXRpb24oKTtcclxuICBjb25zdCBbc2hvd1NhbGFyeU1vZGFsLCBzZXRTaG93U2FsYXJ5TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFttb2RpZnlQYXltZW50LCBzZXRNb2RpZnlQYXltZW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbYWRtaW5JZCwgc2V0QWRtaW5JZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgIG5vUmVsb2FkOiBmYWxzZSxcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbdGFyZ2V0RGF0YSwgc2V0VGFyZ2V0RGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICB0YXJnZXQ6IDAsXHJcbiAgICBhY2hpZXZlZDogMCxcclxuICAgIHJlbWFpbmluZzogMCxcclxuICAgIGRpZmZlcmVuY2U6IDAsXHJcbiAgICBpbmNlbnRpdmVBbW91bnQ6IFwi4oK5MC4wMFwiLFxyXG4gICAgaW5jZW50aXZlUGVyY2VudDogXCIwJVwiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbYWdlbnRzLCBzZXRBZ2VudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzYWxhcnlQYXltZW50cywgc2V0U2FsYXJ5UGF5bWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FkbWluTmFtZSwgc2V0QWRtaW5OYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW3JlUmVuZGVyLCBzZXRSZVJlbmRlcl0gPSB1c2VTdGF0ZSgwKTtcclxuXHJcbiAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG5cclxuICBjb25zdCBbc2FsYXJ5Rm9ybSwgc2V0U2FsYXJ5Rm9ybV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBhZ2VudF9pZDogXCJcIixcclxuICAgIHBheV9kYXRlOiB0b2RheS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXSxcclxuICAgIGZyb21fZGF0ZTogXCJcIixcclxuICAgIHRvX2RhdGU6IFwiXCIsXHJcbiAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICBwYXlfdHlwZTogXCJjYXNoXCIsXHJcbiAgICB0cmFuc2FjdGlvbl9pZDogXCJcIixcclxuICAgIG5vdGU6IFwiXCIsXHJcbiAgICBwYXlfZm9yOiBwYXltZW50Rm9yLFxyXG4gICAgYWRtaW5fdHlwZTogXCJcIixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW2VtcGxveWVlRGV0YWlscywgc2V0RW1wbG95ZWVEZXRhaWxzXSA9IHVzZVN0YXRlKHtcclxuICAgIGpvaW5pbmdfZGF0ZTogXCJcIixcclxuICAgIHNhbGFyeTogXCJcIixcclxuICB9KTtcclxuICBjb25zdCBbdG90YWxXaXRoSW5jZW50aXZlLCBzZXRUb3RhbFdpdGhJbmNlbnRpdmVdID0gdXNlU3RhdGUoXCIwLjAwXCIpO1xyXG5cclxuICBjb25zdCBbY2FsY3VsYXRlZFNhbGFyeSwgc2V0Q2FsY3VsYXRlZFNhbGFyeV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWxyZWFkeVBhaWQsIHNldEFscmVhZHlQYWlkXSA9IHVzZVN0YXRlKFwiMC4wMFwiKTtcclxuICBjb25zdCBbcmVtYWluaW5nU2FsYXJ5LCBzZXRSZW1haW5pbmdTYWxhcnldID0gdXNlU3RhdGUoXCIwLjAwXCIpO1xyXG5cclxuICBjb25zdCBmb3JtYXREYXRlID0gKGRhdGUpID0+IHtcclxuICAgIGlmICghZGF0ZSkgcmV0dXJuIFwiXCI7XHJcbiAgICBpZiAodHlwZW9mIGRhdGUgPT09IFwic3RyaW5nXCIgJiYgL15cXGR7NH0tXFxkezJ9LVxcZHsyfSQvLnRlc3QoZGF0ZSkpIHtcclxuICAgICAgcmV0dXJuIGRhdGU7XHJcbiAgICB9XHJcbiAgICBjb25zdCBkID0gbmV3IERhdGUoZGF0ZSk7XHJcbiAgICBpZiAoaXNOYU4oZCkpIHJldHVybiBcIlwiO1xyXG4gICAgY29uc3QgeWVhciA9IGQuZ2V0RnVsbFllYXIoKTtcclxuICAgIGNvbnN0IG1vbnRoID0gU3RyaW5nKGQuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsIFwiMFwiKTtcclxuICAgIGNvbnN0IGRheSA9IFN0cmluZyhkLmdldERhdGUoKSkucGFkU3RhcnQoMiwgXCIwXCIpO1xyXG4gICAgcmV0dXJuIGAke3llYXJ9LSR7bW9udGh9LSR7ZGF5fWA7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY2FsY3VsYXRlUHJvUmF0ZWRTYWxhcnkgPSBhc3luYyAoXHJcbiAgICBmcm9tRGF0ZVN0cixcclxuICAgIHRvRGF0ZVN0cixcclxuICAgIG1vbnRobHlTYWxhcnksXHJcbiAgICBlbXBJZFxyXG4gICkgPT4ge1xyXG4gICAgaWYgKCFmcm9tRGF0ZVN0ciB8fCAhdG9EYXRlU3RyIHx8ICFtb250aGx5U2FsYXJ5IHx8ICFlbXBJZCkge1xyXG4gICAgICBzZXRDYWxjdWxhdGVkU2FsYXJ5KFwiXCIpO1xyXG4gICAgICBzZXRBbHJlYWR5UGFpZChcIjAuMDBcIik7XHJcbiAgICAgIHNldFJlbWFpbmluZ1NhbGFyeShcIjAuMDBcIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBmcm9tRGF0ZSA9IG5ldyBEYXRlKGZvcm1hdERhdGUoZnJvbURhdGVTdHIpKTtcclxuICAgIGNvbnN0IHRvRGF0ZSA9IG5ldyBEYXRlKGZvcm1hdERhdGUodG9EYXRlU3RyKSk7XHJcbiAgICBjb25zdCBzYWxhcnkgPSBwYXJzZUZsb2F0KG1vbnRobHlTYWxhcnkpO1xyXG5cclxuICAgIGlmICh0b0RhdGUgPCBmcm9tRGF0ZSB8fCBpc05hTihzYWxhcnkpKSB7XHJcbiAgICAgIHNldENhbGN1bGF0ZWRTYWxhcnkoXCJcIik7XHJcbiAgICAgIHNldEFscmVhZHlQYWlkKFwiMC4wMFwiKTtcclxuICAgICAgc2V0UmVtYWluaW5nU2FsYXJ5KFwiMC4wMFwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGxldCBjdXJyZW50ID0gbmV3IERhdGUoZnJvbURhdGUpO1xyXG4gICAgbGV0IHRvdGFsU2FsYXJ5ID0gMDtcclxuXHJcbiAgICB3aGlsZSAoY3VycmVudCA8PSB0b0RhdGUpIHtcclxuICAgICAgY29uc3QgeWVhciA9IGN1cnJlbnQuZ2V0RnVsbFllYXIoKTtcclxuICAgICAgY29uc3QgbW9udGggPSBjdXJyZW50LmdldE1vbnRoKCk7XHJcbiAgICAgIGNvbnN0IGRheXNJbk1vbnRoID0gbmV3IERhdGUoeWVhciwgbW9udGggKyAxLCAwKS5nZXREYXRlKCk7XHJcblxyXG4gICAgICBjb25zdCBmcm9tRGF5ID1cclxuICAgICAgICBjdXJyZW50LmdldEZ1bGxZZWFyKCkgPT09IGZyb21EYXRlLmdldEZ1bGxZZWFyKCkgJiZcclxuICAgICAgICBjdXJyZW50LmdldE1vbnRoKCkgPT09IGZyb21EYXRlLmdldE1vbnRoKClcclxuICAgICAgICAgID8gZnJvbURhdGUuZ2V0RGF0ZSgpXHJcbiAgICAgICAgICA6IDE7XHJcblxyXG4gICAgICBjb25zdCB0b0RheSA9XHJcbiAgICAgICAgY3VycmVudC5nZXRGdWxsWWVhcigpID09PSB0b0RhdGUuZ2V0RnVsbFllYXIoKSAmJlxyXG4gICAgICAgIGN1cnJlbnQuZ2V0TW9udGgoKSA9PT0gdG9EYXRlLmdldE1vbnRoKClcclxuICAgICAgICAgID8gdG9EYXRlLmdldERhdGUoKVxyXG4gICAgICAgICAgOiBkYXlzSW5Nb250aDtcclxuXHJcbiAgICAgIGNvbnN0IGRheXNXb3JrZWQgPSB0b0RheSAtIGZyb21EYXkgKyAxO1xyXG4gICAgICBjb25zdCBkYWlseVNhbGFyeSA9IHNhbGFyeSAvIGRheXNJbk1vbnRoO1xyXG5cclxuICAgICAgdG90YWxTYWxhcnkgKz0gZGF5c1dvcmtlZCAqIGRhaWx5U2FsYXJ5O1xyXG4gICAgICBjdXJyZW50ID0gbmV3IERhdGUoeWVhciwgbW9udGggKyAxLCAxKTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBwcm9SYXRlZFNhbGFyeSA9IHRvdGFsU2FsYXJ5O1xyXG4gICAgY29uc3QgdG90YWxQYXlhYmxlV2l0aEluY2VudGl2ZSA9IHByb1JhdGVkU2FsYXJ5O1xyXG5cclxuICAgIHNldENhbGN1bGF0ZWRTYWxhcnkodG90YWxQYXlhYmxlV2l0aEluY2VudGl2ZS50b0ZpeGVkKDIpKTtcclxuICAgIHNldFRvdGFsV2l0aEluY2VudGl2ZSh0b3RhbFBheWFibGVXaXRoSW5jZW50aXZlLnRvRml4ZWQoMikpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IEFQSS5nZXQoXCIvcGF5bWVudC1vdXQvZ2V0LXNhbGFyeS1wYXltZW50c1wiKTtcclxuICAgICAgY29uc3QgcGFpZFRvQWdlbnQgPSByZXM/LmRhdGE/LmZpbHRlcigocCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHBBZ2VudElkID0gcC5hZ2VudF9pZD8uX2lkXHJcbiAgICAgICAgICA/IFN0cmluZyhwLmFnZW50X2lkLl9pZClcclxuICAgICAgICAgIDogU3RyaW5nKHAuYWdlbnRfaWQpO1xyXG4gICAgICAgIGNvbnN0IG1hdGNoZXNBZ2VudCA9IHBBZ2VudElkID09PSBTdHJpbmcoZW1wSWQpO1xyXG4gICAgICAgIGNvbnN0IHBheURhdGUgPSBuZXcgRGF0ZShmb3JtYXREYXRlKHAucGF5X2RhdGUpKTtcclxuICAgICAgICByZXR1cm4gbWF0Y2hlc0FnZW50ICYmIHBheURhdGUgPj0gZnJvbURhdGUgJiYgcGF5RGF0ZSA8PSB0b0RhdGU7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgdG90YWxQYWlkID0gcGFpZFRvQWdlbnQucmVkdWNlKFxyXG4gICAgICAgIChzdW0sIHApID0+IHN1bSArIHBhcnNlRmxvYXQocC5hbW91bnQgfHwgMCksXHJcbiAgICAgICAgMFxyXG4gICAgICApO1xyXG5cclxuICAgICAgY29uc3QgcmVtYWluaW5nID0gdG90YWxQYXlhYmxlV2l0aEluY2VudGl2ZSAtIHRvdGFsUGFpZDtcclxuXHJcbiAgICAgIHNldEFscmVhZHlQYWlkKHRvdGFsUGFpZC50b0ZpeGVkKDIpKTtcclxuICAgICAgc2V0UmVtYWluaW5nU2FsYXJ5KHJlbWFpbmluZy50b0ZpeGVkKDIpKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBjYWxjdWxhdGluZyBhbHJlYWR5IHBhaWQgYW5kIHJlbWFpbmluZ1wiLCBlcnJvcik7XHJcbiAgICAgIHNldEFscmVhZHlQYWlkKFwiMC4wMFwiKTtcclxuICAgICAgc2V0UmVtYWluaW5nU2FsYXJ5KHRvdGFsUGF5YWJsZVdpdGhJbmNlbnRpdmUudG9GaXhlZCgyKSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hFbXBsb3llZURldGFpbHMgPSBhc3luYyAoZW1wSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IEFQSS5nZXQoXHJcbiAgICAgICAgYC9hZ2VudC9nZXQtYWRkaXRpb25hbC1lbXBsb3llZS1pbmZvLWJ5LWlkLyR7ZW1wSWR9YFxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCBlbXAgPSByZXM/LmRhdGE/LmVtcGxveWVlO1xyXG4gICAgICBpZiAoZW1wKSB7XHJcbiAgICAgICAgY29uc3Qgam9pbmluZyA9IGVtcC5qb2luaW5nX2RhdGU/LnNwbGl0KFwiVFwiKVswXSB8fCBcIlwiO1xyXG4gICAgICAgIGNvbnN0IGJhc2VTYWxhcnkgPSBlbXAuc2FsYXJ5IHx8IFwiXCI7XHJcbiAgICAgICAgc2V0RW1wbG95ZWVEZXRhaWxzKHsgam9pbmluZ19kYXRlOiBqb2luaW5nLCBzYWxhcnk6IGJhc2VTYWxhcnkgfSk7XHJcblxyXG4gICAgICAgIGlmIChzYWxhcnlGb3JtLmZyb21fZGF0ZSAmJiBzYWxhcnlGb3JtLnRvX2RhdGUpIHtcclxuICAgICAgICAgIGNvbnN0IGZkID0gZm9ybWF0RGF0ZShzYWxhcnlGb3JtLmZyb21fZGF0ZSk7XHJcbiAgICAgICAgICBjb25zdCB0ZCA9IGZvcm1hdERhdGUoc2FsYXJ5Rm9ybS50b19kYXRlKTtcclxuICAgICAgICAgIGZldGNoVGFyZ2V0RGV0YWlscyhlbXBJZCwgZmQsIHRkKTtcclxuICAgICAgICAgIGNhbGN1bGF0ZVByb1JhdGVkU2FsYXJ5KGZkLCB0ZCwgYmFzZVNhbGFyeSwgZW1wSWQpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbXBsb3llZSBpbmZvXCIsIGVycik7XHJcbiAgICAgIHNldEVtcGxveWVlRGV0YWlscyh7IGpvaW5pbmdfZGF0ZTogXCJcIiwgc2FsYXJ5OiBcIlwiIH0pO1xyXG4gICAgICBzZXRDYWxjdWxhdGVkU2FsYXJ5KFwiXCIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoQWdlbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBUEkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4gICAgICBzZXRBZ2VudHMocmVzcG9uc2UuZGF0YT8uZW1wbG95ZWUgfHwgW10pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBBZ2VudHNcIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hTYWxhcnlQYXltZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldChcIi9wYXltZW50LW91dC9nZXQtc2FsYXJ5LXBheW1lbnRzXCIpO1xyXG4gICAgICBjb25zdCByZXNwb25zZURhdGEgPSByZXNwb25zZS5kYXRhLm1hcCgocGF5bWVudCwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICBfaWQ6IHBheW1lbnQuX2lkLFxyXG4gICAgICAgIGFnZW50X2lkOiBwYXltZW50LmFnZW50X2lkLFxyXG4gICAgICAgIGFnZW50X25hbWU6IHBheW1lbnQuYWdlbnRfaWQ/Lm5hbWUsXHJcbiAgICAgICAgcGF5X2RhdGU6IHBheW1lbnQucGF5X2RhdGUsXHJcbiAgICAgICAgYW1vdW50OiBwYXltZW50LmFtb3VudCxcclxuICAgICAgICBwYXlfdHlwZTogcGF5bWVudC5wYXlfdHlwZSxcclxuICAgICAgICB0cmFuc2FjdGlvbl9pZDogcGF5bWVudC50cmFuc2FjdGlvbl9pZCxcclxuICAgICAgICBub3RlOiBwYXltZW50Lm5vdGUsXHJcbiAgICAgICAgcGF5X2ZvcjogcGF5bWVudC5wYXlfZm9yLFxyXG4gICAgICAgIGRpc2J1cnNlZF9ieTogcGF5bWVudC5hZG1pbl90eXBlPy5uYW1lLFxyXG4gICAgICAgIHJlY2VpcHRfbm86IHBheW1lbnQucmVjZWlwdF9ubyxcclxuICAgICAgfSkpO1xyXG4gICAgICBzZXRTYWxhcnlQYXltZW50cyhyZXNwb25zZURhdGEpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBTYWxhcnkgcGF5bWVudHNcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRTYWxhcnlQYXltZW50cyhbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoVGFyZ2V0RGV0YWlscyA9IGFzeW5jIChhZ2VudElkLCBmcm9tRGF0ZSwgdG9EYXRlKSA9PiB7XHJcbiAgICBpZiAoIWFnZW50SWQgfHwgIWZyb21EYXRlIHx8ICF0b0RhdGUpIHtcclxuICAgICAgcmVzZXRUYXJnZXREYXRhKCk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBBUEkuZ2V0KGAvdGFyZ2V0L2VtcGxveWVlLyR7YWdlbnRJZH1gLCB7XHJcbiAgICAgICAgcGFyYW1zOiB7IGZyb21fZGF0ZTogZnJvbURhdGUsIHRvX2RhdGU6IHRvRGF0ZSB9LFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGlmIChyZXMuZGF0YT8uc3VjY2VzcyAmJiByZXMuZGF0YT8uc3VtbWFyeSkge1xyXG4gICAgICAgIGNvbnN0IGVtcFN1bW1hcnkgPSByZXMuZGF0YS5zdW1tYXJ5O1xyXG5cclxuICAgICAgICBzZXRUYXJnZXREYXRhKHtcclxuICAgICAgICAgIHRhcmdldDogZW1wU3VtbWFyeS5hZ2VudD8udGFyZ2V0Py52YWx1ZSB8fCBcIk5vdCBTZXRcIixcclxuICAgICAgICAgIGFjaGlldmVkOiBlbXBTdW1tYXJ5Lm1ldHJpY3M/LmFjdHVhbF9idXNpbmVzcyB8fCBcIuKCuTAuMDBcIixcclxuICAgICAgICAgIGRpZmZlcmVuY2U6IGVtcFN1bW1hcnkubWV0cmljcz8udGFyZ2V0X2RpZmZlcmVuY2UgfHwgXCLigrkwLjAwXCIsXHJcbiAgICAgICAgICByZW1haW5pbmc6IGVtcFN1bW1hcnkubWV0cmljcz8udGFyZ2V0X3JlbWFpbmluZyB8fCBcIuKCuTAuMDBcIixcclxuICAgICAgICAgIGluY2VudGl2ZUFtb3VudDogZW1wU3VtbWFyeS5tZXRyaWNzPy50b3RhbF9lc3RpbWF0ZWQgfHwgXCLigrkwLjAwXCIsXHJcbiAgICAgICAgICBpbmNlbnRpdmVQZXJjZW50OlxyXG4gICAgICAgICAgICAoZW1wU3VtbWFyeS5hZ2VudD8udGFyZ2V0Py5hY2hpZXZlbWVudF9wZXJjZW50IHx8IFwiMFwiKSArIFwiJVwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG5cclxuICAgICAgcmVzZXRUYXJnZXREYXRhKCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdGFyZ2V0IGRldGFpbHNcIiwgZXJyb3IpO1xyXG4gICAgICByZXNldFRhcmdldERhdGEoKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCByZXNldFRhcmdldERhdGEgPSAoKSA9PiB7XHJcbiAgICBzZXRUYXJnZXREYXRhKHtcclxuICAgICAgdGFyZ2V0OiAwLFxyXG4gICAgICBhY2hpZXZlZDogMCxcclxuICAgICAgZGlmZmVyZW5jZTogMCxcclxuICAgICAgcmVtYWluaW5nOiAwLFxyXG4gICAgICBpbmNlbnRpdmVBbW91bnQ6IFwi4oK5MC4wMFwiLFxyXG4gICAgICBpbmNlbnRpdmVQZXJjZW50OiBcIjAlXCIsXHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICAvLyBMb2FkIHVzZXIgaW5mbyBvbiBtb3VudFxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB1c2VyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgY29uc3QgdXNlck9iaiA9IEpTT04ucGFyc2UodXNlcik7XHJcbiAgICBzZXRBZG1pbklkKHVzZXJPYmouX2lkKTtcclxuICAgIHNldEFkbWluTmFtZSh1c2VyT2JqLm5hbWUgfHwgXCJcIik7XHJcblxyXG4gICAgaWYgKHVzZXJPYmo/LmFkbWluX2FjY2Vzc19yaWdodF9pZD8uYWNjZXNzX3Blcm1pc3Npb25zPy5lZGl0X3BheW1lbnQpIHtcclxuICAgICAgc2V0TW9kaWZ5UGF5bWVudChcclxuICAgICAgICB1c2VyT2JqLmFkbWluX2FjY2Vzc19yaWdodF9pZC5hY2Nlc3NfcGVybWlzc2lvbnMuZWRpdF9wYXltZW50ID09PSBcInRydWVcIlxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8gSW5pdGlhbCBkYXRhIGxvYWRcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hBZ2VudHMoKTtcclxuICAgIGZldGNoU2FsYXJ5UGF5bWVudHMoKTtcclxuICB9LCBbcmVSZW5kZXJdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU2FsYXJ5Q2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0U2FsYXJ5Rm9ybSgocHJldikgPT4gKHsgLi4ucHJldiwgW25hbWVdOiB2YWx1ZSB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIFtuYW1lXTogXCJcIiB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKCkgPT4ge1xyXG4gICAgY29uc3QgbmV3RXJyb3JzID0ge307XHJcblxyXG4gICAgaWYgKCFzYWxhcnlGb3JtLmFnZW50X2lkKSBuZXdFcnJvcnMuYWdlbnRfaWQgPSBcIlBsZWFzZSBzZWxlY3QgYW4gYWdlbnRcIjtcclxuICAgIGlmICghc2FsYXJ5Rm9ybS5hbW91bnQgfHwgaXNOYU4oc2FsYXJ5Rm9ybS5hbW91bnQpKVxyXG4gICAgICBuZXdFcnJvcnMuYW1vdW50ID0gXCJQbGVhc2UgZW50ZXIgYSB2YWxpZCBhbW91bnRcIjtcclxuICAgIGlmIChzYWxhcnlGb3JtLnBheV90eXBlID09PSBcIm9ubGluZVwiICYmICFzYWxhcnlGb3JtLnRyYW5zYWN0aW9uX2lkKVxyXG4gICAgICBuZXdFcnJvcnMucGF5X3R5cGUgPSBcIlRyYW5zYWN0aW9uIElEIGlzIHJlcXVpcmVkIGZvciBvbmxpbmUgcGF5bWVudHNcIjtcclxuXHJcbiAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTYWxhcnlTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgaXNWYWxpZCA9IHZhbGlkYXRlRm9ybSgpO1xyXG4gICAgaWYgKGlzVmFsaWQpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcGF5bG9hZCA9IHtcclxuICAgICAgICAgIC4uLnNhbGFyeUZvcm0sXHJcbiAgICAgICAgICBhZG1pbl90eXBlOiBhZG1pbklkLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgYXdhaXQgQVBJLnBvc3QoXCIvcGF5bWVudC1vdXQvYWRkLXNhbGFyeS1wYXltZW50XCIsIHBheWxvYWQpO1xyXG4gICAgICAgIGFwaS5vcGVuKHtcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiU2FsYXJ5IFBheW91dCBTdWNjZXNzZnVsXCIsXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbjogXCJUaGUgc2FsYXJ5IHBheW1lbnQgaGFzIGJlZW4gc3VjY2Vzc2Z1bGx5IHByb2Nlc3NlZC5cIixcclxuICAgICAgICAgIGNsYXNzTmFtZTogXCJiZy1ncmVlbi01MDAgcm91bmRlZC1sZyBmb250LXNlbWlib2xkIHRleHQtd2hpdGVcIixcclxuICAgICAgICAgIHNob3dQcm9ncmVzczogdHJ1ZSxcclxuICAgICAgICAgIHBhdXNlT25Ib3ZlcjogZmFsc2UsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2V0U2hvd1NhbGFyeU1vZGFsKGZhbHNlKTtcclxuICAgICAgICByZXNldEZvcm0oKTtcclxuICAgICAgICBzZXRSZVJlbmRlcigodmFsKSA9PiB2YWwgKyAxKTtcclxuICAgICAgICBmZXRjaFNhbGFyeVBheW1lbnRzKCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IGVycm9yLm1lc3NhZ2UgfHwgXCJTb21ldGhpbmcgd2VudCB3cm9uZ1wiO1xyXG4gICAgICAgIGFwaS5vcGVuKHtcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiU2FsYXJ5IFBheW91dCBGYWlsZWRcIixcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBtZXNzYWdlLFxyXG4gICAgICAgICAgc2hvd1Byb2dyZXNzOiB0cnVlLFxyXG4gICAgICAgICAgcGF1c2VPbkhvdmVyOiBmYWxzZSxcclxuICAgICAgICAgIGNsYXNzTmFtZTogXCJiZy1yZWQtNTAwIHJvdW5kZWQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHJlc2V0Rm9ybSA9ICgpID0+IHtcclxuICAgIHNldFNhbGFyeUZvcm0oe1xyXG4gICAgICBhZ2VudF9pZDogXCJcIixcclxuICAgICAgcGF5X2RhdGU6IHRvZGF5LnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICBmcm9tX2RhdGU6IFwiXCIsXHJcbiAgICAgIHRvX2RhdGU6IFwiXCIsXHJcbiAgICAgIGFtb3VudDogXCJcIixcclxuICAgICAgcGF5X3R5cGU6IFwiY2FzaFwiLFxyXG4gICAgICB0cmFuc2FjdGlvbl9pZDogXCJcIixcclxuICAgICAgbm90ZTogXCJcIixcclxuICAgICAgcGF5X2ZvcjogcGF5bWVudEZvcixcclxuICAgICAgYWRtaW5fdHlwZTogYWRtaW5JZCxcclxuICAgIH0pO1xyXG4gICAgc2V0RW1wbG95ZWVEZXRhaWxzKHsgam9pbmluZ19kYXRlOiBcIlwiLCBzYWxhcnk6IFwiXCIgfSk7XHJcbiAgICBzZXRDYWxjdWxhdGVkU2FsYXJ5KFwiXCIpO1xyXG4gICAgc2V0QWxyZWFkeVBhaWQoXCIwLjAwXCIpO1xyXG4gICAgc2V0UmVtYWluaW5nU2FsYXJ5KFwiMC4wMFwiKTtcclxuICAgIHJlc2V0VGFyZ2V0RGF0YSgpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHNhbGFyeUNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcInBheV9kYXRlXCIsIGhlYWRlcjogXCJQYXkgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJhZ2VudF9uYW1lXCIsIGhlYWRlcjogXCJBZ2VudFwiIH0sXHJcbiAgICB7IGtleTogXCJhbW91bnRcIiwgaGVhZGVyOiBcIkFtb3VudCAo4oK5KVwiIH0sXHJcbiAgICB7IGtleTogXCJwYXlfdHlwZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBNb2RlXCIgfSxcclxuICAgIHsga2V5OiBcInJlY2VpcHRfbm9cIiwgaGVhZGVyOiBcIlJlY2VpcHQgTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwibm90ZVwiLCBoZWFkZXI6IFwiTm90ZVwiIH0sXHJcbiAgICB7IGtleTogXCJkaXNidXJzZWRfYnlcIiwgaGVhZGVyOiBcIkRpc2J1cnNlZCBieVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAge2NvbnRleHRIb2xkZXJ9XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgICA8TmF2YmFyIHZpc2liaWxpdHk9e3RydWV9IC8+XHJcbiAgICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgICAgPEN1c3RvbUFsZXJ0XHJcbiAgICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgICAgbm9SZWxvYWQ9e2FsZXJ0Q29uZmlnLm5vUmVsb2FkfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCB0ZXh0LXJlZC01MDAgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtwYXltZW50Rm9yPy50b1VwcGVyQ2FzZSgpfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICAgIFBheW1lbnRzIE91dFxyXG4gICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgICAgPFRvb2x0aXAgdGl0bGU9XCJBZGQgU2FsYXJ5IFBheW1lbnRcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFNob3dTYWxhcnlNb2RhbCh0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgICByZXNldEZvcm0oKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtNCBiZy12aW9sZXQtOTAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLXZpb2xldC02MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDAgZmxleCBpdGVtcy1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtci0yXCI+Kzwvc3Bhbj4gU2FsYXJ5IFBheW1lbnRcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvVG9vbHRpcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTggYmctd2hpdGUgcC02IHJvdW5kZWQtbGcgc2hhZG93LW1kXCI+XHJcbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCBtYi00IHRleHQtdmlvbGV0LTgwMCBib3JkZXItYiBwYi0yXCI+XHJcbiAgICAgICAgICAgICAgICBTYWxhcnkgUGF5bWVudHNcclxuICAgICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgICB7c2FsYXJ5UGF5bWVudHMubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgZGF0YT17c2FsYXJ5UGF5bWVudHN9XHJcbiAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e3NhbGFyeUNvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIlBheU91dCBTYWxhcnlcIlxyXG4gICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgUGF5T3V0IFNhbGFyeS5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMCB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgICAgICAgIGlzTG9hZGluZz17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGE9XCJTYWxhcnkgUGF5bWVudHNcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZhaWx1cmU9e3NhbGFyeVBheW1lbnRzLmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICAgIGlzVmlzaWJsZT17c2hvd1NhbGFyeU1vZGFsfVxyXG4gICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0U2hvd1NhbGFyeU1vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgICByZXNldEZvcm0oKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGJvcmRlci1iIHBiLTJcIj5cclxuICAgICAgICAgICAgICAgIEFkZCBTYWxhcnkgUGF5bWVudFxyXG4gICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS00XCIgb25TdWJtaXQ9e2hhbmRsZVNhbGFyeVN1Ym1pdH0+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBFbXBsb3llZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEFnZW50XCJcclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2FsYXJ5Rm9ybS5hZ2VudF9pZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBhZ2VudF9pZDogXCJcIiB9KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRTYWxhcnlGb3JtKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhZ2VudF9pZDogdmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZyb21fZGF0ZTogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgdG9fZGF0ZTogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgYW1vdW50OiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0RW1wbG95ZWVEZXRhaWxzKHsgam9pbmluZ19kYXRlOiBcIlwiLCBzYWxhcnk6IFwiXCIgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRDYWxjdWxhdGVkU2FsYXJ5KFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0QWxyZWFkeVBhaWQoXCIwLjAwXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0UmVtYWluaW5nU2FsYXJ5KFwiMC4wMFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgIHJlc2V0VGFyZ2V0RGF0YSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgZmV0Y2hFbXBsb3llZURldGFpbHModmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7YWdlbnRzLm1hcCgoYWdlbnQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17YWdlbnQuX2lkfSB2YWx1ZT17YWdlbnQuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Ake2FnZW50Lm5hbWV9IHwgJHthZ2VudC5waG9uZV9udW1iZXJ9YH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYWdlbnRfaWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYWdlbnRfaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAge2VtcGxveWVlRGV0YWlscy5qb2luaW5nX2RhdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgSm9pbmluZyBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VtcGxveWVlRGV0YWlscy5qb2luaW5nX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktMTAwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTcwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRnJvbSBEYXRlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZnJvbV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2FsYXJ5Rm9ybS5mcm9tX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVNhbGFyeUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBUbyBEYXRlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwidG9fZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NhbGFyeUZvcm0udG9fZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU2FsYXJ5Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTMgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMiBiZy12aW9sZXQtNjAwIGhvdmVyOmJnLXZpb2xldC03MDAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzYWxhcnlGb3JtLmFnZW50X2lkICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNhbGFyeUZvcm0uZnJvbV9kYXRlICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNhbGFyeUZvcm0udG9fZGF0ZSAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbXBsb3llZURldGFpbHMuc2FsYXJ5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZmQgPSBmb3JtYXREYXRlKHNhbGFyeUZvcm0uZnJvbV9kYXRlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdGQgPSBmb3JtYXREYXRlKHNhbGFyeUZvcm0udG9fZGF0ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZldGNoVGFyZ2V0RGV0YWlscyhzYWxhcnlGb3JtLmFnZW50X2lkLCBmZCwgdGQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYWxjdWxhdGVQcm9SYXRlZFNhbGFyeShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbXBsb3llZURldGFpbHMuc2FsYXJ5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNhbGFyeUZvcm0uYWdlbnRfaWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQ2FsY3VsYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiDinIUgVEFSR0VUIERBVEEgRElTUExBWSAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTQgbXQtNiBwLTMgcm91bmRlZC1sZyBiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFRhcmdldFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YCR7dGFyZ2V0RGF0YS50YXJnZXQ/LnRvTG9jYWxlU3RyaW5nKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbi1JTlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciByb3VuZGVkIHB4LTMgcHktMiBiZy13aGl0ZSBmb250LXNlbWlib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBBY2hpZXZlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YCR7dGFyZ2V0RGF0YS5hY2hpZXZlZD8udG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImVuLUlOXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIHJvdW5kZWQgcHgtMyBweS0yIGJnLXdoaXRlIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIERpZmZlcmVuY2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Ake3RhcmdldERhdGEuZGlmZmVyZW5jZT8udG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImVuLUlOXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIHJvdW5kZWQgcHgtMyBweS0yIGJnLXdoaXRlIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTW9udGhseSBTYWxhcnkgKOKCuSlcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW1wbG95ZWVEZXRhaWxzLnNhbGFyeX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS0xMDAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktNzAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBQYXlhYmxlIFNhbGFyeSAo4oK5KVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjYWxjdWxhdGVkU2FsYXJ5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIGZvbnQtc2VtaWJvbGQgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBEYXRlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGF5X2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzYWxhcnlGb3JtLnBheV9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVTYWxhcnlDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshbW9kaWZ5UGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHtjYWxjdWxhdGVkU2FsYXJ5ICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBFbnRlciBQYXlhYmxlIEFtb3VudCAo4oK5KXtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBtaW49ezF9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2FsYXJ5Rm9ybS5hbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsID0gcGFyc2VGbG9hdChlLnRhcmdldC52YWx1ZSB8fCAwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVtID0gcGFyc2VGbG9hdChyZW1haW5pbmdTYWxhcnkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsID4gcmVtKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFtb3VudDogYENhbm5vdCBwYXkgbW9yZSB0aGFuIOKCuSR7cmVtLnRvRml4ZWQoMil9YCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2FsYXJ5Rm9ybSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbW91bnQ6IGUudGFyZ2V0LnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRFcnJvcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIGFtb3VudDogXCJcIiB9KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIGFtb3VudCB0byBwYXlcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5hbW91bnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTQgbXQtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTEgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQWxyZWFkeSBQYWlkICjigrkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YWxyZWFkeVBhaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmVlbi01MCBib3JkZXIgYm9yZGVyLWdyZWVuLTMwMCB0ZXh0LWdyZWVuLTcwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFJlbWFpbmluZyBTYWxhcnkgKOKCuSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtyZW1haW5pbmdTYWxhcnl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1yZWQtNTAgYm9yZGVyIGJvcmRlci1yZWQtMzAwIHRleHQtcmVkLTcwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBNb2RlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGF5X3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzYWxhcnlGb3JtLnBheV90eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVTYWxhcnlDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNhc2hcIj5DYXNoPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm9ubGluZVwiPk9ubGluZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIHttb2RpZnlQYXltZW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjaGVxdWVcIj5DaGVxdWU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImJhbmtfdHJhbnNmZXJcIj5CYW5rIFRyYW5zZmVyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHtzYWxhcnlGb3JtLnBheV90eXBlID09PSBcIm9ubGluZVwiICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFRyYW5zYWN0aW9uIElEIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0cmFuc2FjdGlvbl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2FsYXJ5Rm9ybS50cmFuc2FjdGlvbl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVTYWxhcnlDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIE5vdGVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPHRleHRhcmVhXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm5vdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzYWxhcnlGb3JtLm5vdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVNhbGFyeUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgcm93cz1cIjJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctdmlvbGV0LTUwIHAtMyByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIERpc2J1cnNlZCBCeVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj57YWRtaW5OYW1lfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIHNwYWNlLXgtMyBwdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93U2FsYXJ5TW9kYWwoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgdGV4dC1ncmF5LTcwMCBob3ZlcjpiZy1ncmF5LTEwMFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy12aW9sZXQtNzAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBob3ZlcjpiZy12aW9sZXQtNjAwIGRpc2FibGVkOm9wYWNpdHktNTBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2lzTG9hZGluZyA/IFwiUHJvY2Vzc2luZy4uLlwiIDogXCJTYXZlIFBheW1lbnRcIn1cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVGFyZ2V0UGF5T3V0U2FsYXJ5O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvVGFyZ2V0UGF5b3V0U2FsYXJ5LmpzeCJ9