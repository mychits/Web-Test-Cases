import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LoanCompletionReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { Search, FileText, Users, Calendar, IndianRupee, TrendingUp } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import { DatePicker } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import __vite__cjsImport6_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport6_dayjs.__esModule ? __vite__cjsImport6_dayjs.default : __vite__cjsImport6_dayjs;
import { Collapse } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { FileTextOutlined, DollarOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import { FaMoneyBill } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
const { RangePicker } = DatePicker;
const LoanCompletionReport = () => {
  _s();
  const [loanReportTable, setLoanReportTable] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedLoanId, setSelectedLoanId] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState("");
  const [selectedReferredBy, setSelectedReferredBy] = useState("");
  const [dateRange, setDateRange] = useState(null);
  useEffect(() => {
    const fetchLoanReport = async () => {
      try {
        const response = await api.get(`/payment/customers/loan-report`);
        const formattedData = response.data.loanReports.filter((loan) => loan?.status === "Completed").map((loan, index) => ({
          id: loan?._id,
          slNo: index + 1,
          loanIds: loan?.loan_id || "N/A",
          loanAmountValue: loan?.loan_amount || 0,
          customerId: loan?.borrower?.customer_id || "N/A",
          customerName: loan?.borrower?.full_name || "N/A",
          customerPhone: loan?.borrower?.phone_number || "N/A",
          daily_payment_amount: loan?.daily_payment_amount || "N/A",
          loanStartDate: loan?.start_date ? new Date(loan.start_date).toLocaleDateString("en-GB") : "N/A",
          loanStartDateObj: loan?.start_date ? new Date(loan.start_date) : null,
          // payableLoanDays: loan?.days_count && `${loan?.days_count || 0} Days`,
          payableLoanDays: loan?.days_count,
          loanServiceCharges: loan?.service_charges ?? 0,
          loanAmount: loan?.double_loan_amount ?? 0,
          payableAmount: loan?.amount_payable ?? 0,
          totalLoanAmount: loan?.total_paid_amount ?? 0,
          loanBalance: loan?.balance ?? 0,
          status: loan.status,
          // always "Completed" now
          referredBy: loan?.referredBy || "N/A"
        }));
        setLoanReportTable(formattedData);
      } catch (error) {
        console.error("Error fetching loan report:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchLoanReport();
  }, []);
  const uniqueLoanCombos = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    loanReportTable.forEach((loan) => {
      const key = loan.loanIds;
      if (!map.has(key)) {
        map.set(key, { id: key, label: `${key} | ₹${loan.loanAmountValue}` });
      }
    });
    return Array.from(map.values());
  }, [loanReportTable]);
  const uniqueCustomers = useMemo(
    () => loanReportTable.map((loan) => ({
      id: loan.id,
      name: loan.customerName,
      phone: loan.customerPhone,
      custid: loan.customerId
    })),
    [loanReportTable]
  );
  const uniqueReferredBy = useMemo(() => {
    const set = /* @__PURE__ */ new Set();
    loanReportTable.forEach((loan) => {
      if (loan.referredBy && loan.referredBy !== "N/A") {
        set.add(loan.referredBy);
      }
    });
    return Array.from(set);
  }, [loanReportTable]);
  const filteredLoanReport = useMemo(() => {
    return loanReportTable.filter((loan) => {
      const matchLoanId = selectedLoanId ? loan.loanIds === selectedLoanId : true;
      const matchCustomer = selectedCustomer ? loan.id === selectedCustomer : true;
      const matchReferredBy = selectedReferredBy ? loan.referredBy === selectedReferredBy : true;
      let matchDateRange = true;
      if (dateRange && dateRange.length === 2 && loan.loanStartDateObj) {
        const startDate = dayjs(dateRange[0]).startOf("day");
        const endDate = dayjs(dateRange[1]).endOf("day");
        const loanDate = dayjs(loan.loanStartDateObj);
        matchDateRange = loanDate.isAfter(startDate) && loanDate.isBefore(endDate);
      }
      return matchLoanId && matchCustomer && matchReferredBy && matchDateRange;
    });
  }, [loanReportTable, selectedLoanId, selectedCustomer, selectedReferredBy, dateRange]);
  const summaryStats = useMemo(() => {
    const filtered = filteredLoanReport;
    return {
      totalLoans: filtered.length,
      totalAmount: filtered.reduce((sum, loan) => sum + loan.loanAmount, 0),
      totalPaid: filtered.reduce((sum, loan) => sum + loan.totalLoanAmount, 0),
      totalBalance: filtered.reduce((sum, loan) => sum + loan.loanBalance, 0)
    };
  }, [filteredLoanReport]);
  const loanReportColumns = [
    { key: "slNo", header: "Sl No" },
    { key: "loanIds", header: "Loan ID" },
    { key: "customerName", header: "Customer Name" },
    { key: "customerPhone", header: "Phone Number" },
    { key: "loanStartDate", header: "Loan Start Date" },
    { key: "loanServiceCharges", header: "Service Charges" },
    { key: "daily_payment_amount", header: "Daily Payment" },
    { key: "loanAmount", header: "Loan Amount" },
    { key: "payableLoanDays", header: "Loan Age (in Days)" },
    { key: "payableAmount", header: "Loan Payable" },
    { key: "totalLoanAmount", header: "Total Paid" },
    { key: "status", header: "Status" },
    { key: "referredBy", header: "Referred By" },
    { key: "loanBalance", header: "Balance" }
  ];
  const StatCard = ({ icon: Icon, label, value, color }) => /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm border p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-600 mb-1", children: label }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
        lineNumber: 181,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-900", children: value }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
        lineNumber: 182,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
      lineNumber: 180,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: `p-3 rounded-lg ${color}`, children: /* @__PURE__ */ jsxDEV(Icon, { className: "w-6 h-6 text-white" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
      lineNumber: 185,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
      lineNumber: 184,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
    lineNumber: 179,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
    lineNumber: 178,
    columnNumber: 3
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "max-w-screen", children: /* @__PURE__ */ jsxDEV("div", { className: " mx-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(FileText, { className: "w-7 h-7 text-violet-600" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
          lineNumber: 197,
          columnNumber: 13
        }, this),
        " Loan Completion Report"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
        lineNumber: 196,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 ml-10", children: "Overview of customer completion loans, payments & referral details" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
        lineNumber: 199,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
      lineNumber: 195,
      columnNumber: 9
    }, this),
    loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center h-96", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
      lineNumber: 206,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
      lineNumber: 205,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "my-6", children: /* @__PURE__ */ jsxDEV(
        Collapse,
        {
          items: [
            {
              key: "1",
              label: /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 text-base", children: "Shortcut Keys" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
                lineNumber: 216,
                columnNumber: 17
              }, this),
              children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-5 gap-4", children: [
                /* @__PURE__ */ jsxDEV(
                  Link,
                  {
                    to: "/other-service-menu/loan",
                    className: "flex text-base items-center gap-2 border  border-gray-200 rounded-lg px-4 py-2 text-gray-700 hover:border-violet-500 hover:text-violet-600 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(FaMoneyBill, { className: "text-violet-500", size: 30 }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
                        lineNumber: 226,
                        columnNumber: 27
                      }, this),
                      "Add Loan"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
                    lineNumber: 222,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Link,
                  {
                    to: "/reports/customer-loan-report",
                    className: "flex text-base items-center gap-2 border  border-gray-200 rounded-lg px-4 py-2 text-gray-700 hover:border-violet-500 hover:text-violet-600 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(
                        FileTextOutlined,
                        {
                          className: "text-violet-500",
                          size: 30
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
                          lineNumber: 233,
                          columnNumber: 27
                        },
                        this
                      ),
                      "Loan Summary Report"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
                    lineNumber: 229,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Link,
                  {
                    to: "/reports/loan-due-report",
                    className: "flex text-base items-center gap-2 border  border-gray-200 rounded-lg px-4 py-2 text-gray-700 hover:border-violet-500 hover:text-violet-600 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(
                        DollarOutlined,
                        {
                          className: "text-violet-500",
                          size: 30
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
                          lineNumber: 243,
                          columnNumber: 27
                        },
                        this
                      ),
                      "OutStanding Loan Report"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
                    lineNumber: 239,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
                lineNumber: 221,
                columnNumber: 17
              }, this)
            }
          ],
          defaultActiveKey: ["1"],
          className: "rounded-lg border border-gray-200 bg-white shadow-sm"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
          lineNumber: 211,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
        lineNumber: 210,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              icon: FileText,
              label: "Total Loans",
              value: summaryStats.totalLoans,
              color: "bg-violet-600"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
              lineNumber: 267,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700 mt-2 break-words pl-3", children: numberToIndianWords(summaryStats.totalLoans || 0) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
            lineNumber: 273,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
          lineNumber: 266,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              icon: IndianRupee,
              label: "Total Loan Amount",
              value: `₹${summaryStats.totalAmount}`,
              color: "bg-purple-600"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
              lineNumber: 279,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700 mt-2 break-words pl-3", children: numberToIndianWords(summaryStats.totalAmount || 0) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
            lineNumber: 285,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
          lineNumber: 278,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              icon: TrendingUp,
              label: "Total Paid",
              value: `₹${summaryStats.totalPaid}`,
              color: "bg-green-600"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
              lineNumber: 291,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700 mt-2 break-words pl-3", children: numberToIndianWords(summaryStats.totalPaid || 0) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
            lineNumber: 297,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
          lineNumber: 290,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              icon: Calendar,
              label: "Total Balance",
              value: `₹${summaryStats.totalBalance}`,
              color: "bg-orange-600"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
              lineNumber: 303,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-mono text-green-700 mt-2 break-words pl-3", children: numberToIndianWords(summaryStats.totalBalance || 0) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
            lineNumber: 309,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
          lineNumber: 302,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
        lineNumber: 264,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm border p-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold flex items-center gap-2 mb-4", children: [
          /* @__PURE__ */ jsxDEV(Search, { className: "w-5 h-5" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
            lineNumber: 320,
            columnNumber: 17
          }, this),
          " Filter Options"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
          lineNumber: 319,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Loan ID & Amount" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
              lineNumber: 326,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                placeholder: "Select loan",
                value: selectedLoanId,
                onChange: setSelectedLoanId,
                allowClear: true,
                className: "w-full",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Loans" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
                    lineNumber: 335,
                    columnNumber: 21
                  }, this),
                  uniqueLoanCombos.map(
                    (loan) => /* @__PURE__ */ jsxDEV(Select.Option, { value: loan.id, children: loan.label }, loan.id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
                      lineNumber: 337,
                      columnNumber: 19
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
                lineNumber: 327,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
            lineNumber: 325,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Customer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
              lineNumber: 346,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                placeholder: "Select customer",
                value: selectedCustomer,
                onChange: setSelectedCustomer,
                allowClear: true,
                className: "w-full",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Customers" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
                    lineNumber: 355,
                    columnNumber: 21
                  }, this),
                  uniqueCustomers.map(
                    (cust) => /* @__PURE__ */ jsxDEV(
                      Select.Option,
                      {
                        value: cust.id,
                        children: [
                          cust.custid,
                          " | ",
                          cust.name,
                          " | ",
                          cust.phone
                        ]
                      },
                      cust.id,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
                        lineNumber: 357,
                        columnNumber: 19
                      },
                      this
                    )
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
                lineNumber: 347,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
            lineNumber: 345,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Referred By" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
              lineNumber: 369,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                placeholder: "Select referrer",
                value: selectedReferredBy,
                onChange: setSelectedReferredBy,
                allowClear: true,
                className: "w-full",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Referred By" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
                    lineNumber: 378,
                    columnNumber: 21
                  }, this),
                  uniqueReferredBy.map(
                    (ref) => /* @__PURE__ */ jsxDEV(Select.Option, { value: ref, children: ref }, ref, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
                      lineNumber: 380,
                      columnNumber: 19
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
                lineNumber: 370,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
            lineNumber: 368,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Start Date Range" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
              lineNumber: 389,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              RangePicker,
              {
                value: dateRange,
                onChange: setDateRange,
                className: "w-full",
                format: "DD/MM/YYYY"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
                lineNumber: 390,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
            lineNumber: 388,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
          lineNumber: 323,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
        lineNumber: 318,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "max-w-screen", children: /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          columns: loanReportColumns,
          data: filteredLoanReport,
          exportedFileName: "Customer Completion Loan Report.csv",
          exportedPdfName: "Customer Completion Loan Report"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
          lineNumber: 402,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
        lineNumber: 401,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
      lineNumber: 209,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
    lineNumber: 193,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx",
    lineNumber: 192,
    columnNumber: 5
  }, this);
};
_s(LoanCompletionReport, "dENn+Yil8LNzO5ED7UbXhI9EW3s=");
_c = LoanCompletionReport;
export default LoanCompletionReport;
var _c;
$RefreshReg$(_c, "LoanCompletionReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanCompletionReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0xVLFNBNEJBLFVBNUJBOzJCQXBMVjtBQUFvQkEsb0JBQWlCLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDcEQsU0FBU0MsUUFBUUMsVUFBVUMsT0FBT0MsVUFBVUMsYUFBYUMsa0JBQWtCO0FBQzNFLFNBQVNDLGtCQUFrQjtBQUMzQixPQUFPQyxXQUFXO0FBQ2xCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLGtCQUFrQkMsc0JBQXNCO0FBQ2pELFNBQVNDLG1CQUFtQjtBQUM1QixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsU0FBU0MsY0FBYztBQUN2QixPQUFPQyxvQkFBb0I7QUFFM0IsU0FBU0MsMkJBQTJCO0FBRXBDLE1BQU0sRUFBRUMsWUFBWSxJQUFJWjtBQUV4QixNQUFNYSx1QkFBdUJBLE1BQU07QUFBQUMsS0FBQTtBQUNqQyxRQUFNLENBQUNDLGlCQUFpQkMsa0JBQWtCLElBQUl2QixTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDd0IsU0FBU0MsVUFBVSxJQUFJekIsU0FBUyxJQUFJO0FBRTNDLFFBQU0sQ0FBQzBCLGdCQUFnQkMsaUJBQWlCLElBQUkzQixTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDNEIsa0JBQWtCQyxtQkFBbUIsSUFBSTdCLFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUM4QixvQkFBb0JDLHFCQUFxQixJQUFJL0IsU0FBUyxFQUFFO0FBQy9ELFFBQU0sQ0FBQ2dDLFdBQVdDLFlBQVksSUFBSWpDLFNBQVMsSUFBSTtBQUUvQ2tDLFlBQVUsTUFBTTtBQUNkLFVBQU1DLGtCQUFrQixZQUFZO0FBQ2xDLFVBQUk7QUFDRixjQUFNQyxXQUFXLE1BQU10QixJQUFJdUIsSUFBSSxnQ0FBZ0M7QUEyQi9ELGNBQU1DLGdCQUFnQkYsU0FBU0csS0FBS0MsWUFDakNDLE9BQU8sQ0FBQUMsU0FBUUEsTUFBTUMsV0FBVyxXQUFXLEVBQzNDQyxJQUFJLENBQUNGLE1BQU1HLFdBQVc7QUFBQSxVQUNyQkMsSUFBSUosTUFBTUs7QUFBQUEsVUFDVkMsTUFBTUgsUUFBUTtBQUFBLFVBQ2RJLFNBQVNQLE1BQU1RLFdBQVc7QUFBQSxVQUMxQkMsaUJBQWlCVCxNQUFNVSxlQUFlO0FBQUEsVUFFdENDLFlBQVlYLE1BQU1ZLFVBQVVDLGVBQWU7QUFBQSxVQUMzQ0MsY0FBY2QsTUFBTVksVUFBVUcsYUFBYTtBQUFBLFVBQzNDQyxlQUFlaEIsTUFBTVksVUFBVUssZ0JBQWdCO0FBQUEsVUFDL0NDLHNCQUFzQmxCLE1BQU1rQix3QkFBd0I7QUFBQSxVQUVwREMsZUFBZW5CLE1BQU1vQixhQUNqQixJQUFJQyxLQUFLckIsS0FBS29CLFVBQVUsRUFBRUUsbUJBQW1CLE9BQU8sSUFDcEQ7QUFBQSxVQUNKQyxrQkFBa0J2QixNQUFNb0IsYUFBYSxJQUFJQyxLQUFLckIsS0FBS29CLFVBQVUsSUFBSTtBQUFBO0FBQUEsVUFFakVJLGlCQUFpQnhCLE1BQU15QjtBQUFBQSxVQUV2QkMsb0JBQW9CMUIsTUFBTTJCLG1CQUFtQjtBQUFBLFVBQzdDQyxZQUFZNUIsTUFBTTZCLHNCQUFzQjtBQUFBLFVBQ3hDQyxlQUFlOUIsTUFBTStCLGtCQUFrQjtBQUFBLFVBQ3ZDQyxpQkFBaUJoQyxNQUFNaUMscUJBQXFCO0FBQUEsVUFDNUNDLGFBQWFsQyxNQUFNbUMsV0FBVztBQUFBLFVBRTlCbEMsUUFBUUQsS0FBS0M7QUFBQUE7QUFBQUEsVUFDYm1DLFlBQVlwQyxNQUFNb0MsY0FBYztBQUFBLFFBQ2xDLEVBQUU7QUFFSnZELDJCQUFtQmUsYUFBYTtBQUFBLE1BQ2xDLFNBQVN5QyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLCtCQUErQkEsS0FBSztBQUFBLE1BQ3BELFVBQUM7QUFDQ3RELG1CQUFXLEtBQUs7QUFBQSxNQUNsQjtBQUFBLElBQ0Y7QUFFQVUsb0JBQWdCO0FBQUEsRUFDbEIsR0FBRyxFQUFFO0FBRUwsUUFBTThDLG1CQUFtQkMsUUFBUSxNQUFNO0FBQ3JDLFVBQU10QyxNQUFNLG9CQUFJdUMsSUFBSTtBQUNwQjdELG9CQUFnQjhELFFBQVEsQ0FBQzFDLFNBQVM7QUFDaEMsWUFBTTJDLE1BQU0zQyxLQUFLTztBQUNqQixVQUFJLENBQUNMLElBQUkwQyxJQUFJRCxHQUFHLEdBQUc7QUFDakJ6QyxZQUFJMkMsSUFBSUYsS0FBSyxFQUFFdkMsSUFBSXVDLEtBQUtHLE9BQU8sR0FBR0gsR0FBRyxPQUFPM0MsS0FBS1MsZUFBZSxHQUFHLENBQUM7QUFBQSxNQUN0RTtBQUFBLElBQ0YsQ0FBQztBQUNELFdBQU9zQyxNQUFNQyxLQUFLOUMsSUFBSStDLE9BQU8sQ0FBQztBQUFBLEVBQ2hDLEdBQUcsQ0FBQ3JFLGVBQWUsQ0FBQztBQUVwQixRQUFNc0Usa0JBQWtCVjtBQUFBQSxJQUN0QixNQUNFNUQsZ0JBQWdCc0IsSUFBSSxDQUFDRixVQUFVO0FBQUEsTUFDN0JJLElBQUlKLEtBQUtJO0FBQUFBLE1BQ1QrQyxNQUFNbkQsS0FBS2M7QUFBQUEsTUFDWHNDLE9BQU9wRCxLQUFLZ0I7QUFBQUEsTUFDWnFDLFFBQVFyRCxLQUFLVztBQUFBQSxJQUNmLEVBQUU7QUFBQSxJQUNKLENBQUMvQixlQUFlO0FBQUEsRUFDbEI7QUFFQSxRQUFNMEUsbUJBQW1CZCxRQUFRLE1BQU07QUFDckMsVUFBTUssTUFBTSxvQkFBSVUsSUFBSTtBQUNwQjNFLG9CQUFnQjhELFFBQVEsQ0FBQzFDLFNBQVM7QUFDaEMsVUFBSUEsS0FBS29DLGNBQWNwQyxLQUFLb0MsZUFBZSxPQUFPO0FBQ2hEUyxZQUFJVyxJQUFJeEQsS0FBS29DLFVBQVU7QUFBQSxNQUN6QjtBQUFBLElBQ0YsQ0FBQztBQUNELFdBQU9XLE1BQU1DLEtBQUtILEdBQUc7QUFBQSxFQUN2QixHQUFHLENBQUNqRSxlQUFlLENBQUM7QUFFcEIsUUFBTTZFLHFCQUFxQmpCLFFBQVEsTUFBTTtBQUN2QyxXQUFPNUQsZ0JBQWdCbUIsT0FBTyxDQUFDQyxTQUFTO0FBQ3RDLFlBQU0wRCxjQUFjMUUsaUJBQWlCZ0IsS0FBS08sWUFBWXZCLGlCQUFpQjtBQUN2RSxZQUFNMkUsZ0JBQWdCekUsbUJBQW1CYyxLQUFLSSxPQUFPbEIsbUJBQW1CO0FBQ3hFLFlBQU0wRSxrQkFBa0J4RSxxQkFBcUJZLEtBQUtvQyxlQUFlaEQscUJBQXFCO0FBR3RGLFVBQUl5RSxpQkFBaUI7QUFDckIsVUFBSXZFLGFBQWFBLFVBQVV3RSxXQUFXLEtBQUs5RCxLQUFLdUIsa0JBQWtCO0FBQ2hFLGNBQU13QyxZQUFZakcsTUFBTXdCLFVBQVUsQ0FBQyxDQUFDLEVBQUUwRSxRQUFRLEtBQUs7QUFDbkQsY0FBTUMsVUFBVW5HLE1BQU13QixVQUFVLENBQUMsQ0FBQyxFQUFFNEUsTUFBTSxLQUFLO0FBQy9DLGNBQU1DLFdBQVdyRyxNQUFNa0MsS0FBS3VCLGdCQUFnQjtBQUM1Q3NDLHlCQUFpQk0sU0FBU0MsUUFBUUwsU0FBUyxLQUFLSSxTQUFTRSxTQUFTSixPQUFPO0FBQUEsTUFDM0U7QUFFQSxhQUFPUCxlQUFlQyxpQkFBaUJDLG1CQUFtQkM7QUFBQUEsSUFDNUQsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDakYsaUJBQWlCSSxnQkFBZ0JFLGtCQUFrQkUsb0JBQW9CRSxTQUFTLENBQUM7QUFFckYsUUFBTWdGLGVBQWU5QixRQUFRLE1BQU07QUFDakMsVUFBTStCLFdBQVdkO0FBQ2pCLFdBQU87QUFBQSxNQUNMZSxZQUFZRCxTQUFTVDtBQUFBQSxNQUNyQlcsYUFBYUYsU0FBU0csT0FBTyxDQUFDQyxLQUFLM0UsU0FBUzJFLE1BQU0zRSxLQUFLNEIsWUFBWSxDQUFDO0FBQUEsTUFDcEVnRCxXQUFXTCxTQUFTRyxPQUFPLENBQUNDLEtBQUszRSxTQUFTMkUsTUFBTTNFLEtBQUtnQyxpQkFBaUIsQ0FBQztBQUFBLE1BQ3ZFNkMsY0FBY04sU0FBU0csT0FBTyxDQUFDQyxLQUFLM0UsU0FBUzJFLE1BQU0zRSxLQUFLa0MsYUFBYSxDQUFDO0FBQUEsSUFDeEU7QUFBQSxFQUNGLEdBQUcsQ0FBQ3VCLGtCQUFrQixDQUFDO0FBRXZCLFFBQU1xQixvQkFBb0I7QUFBQSxJQUN4QixFQUFFbkMsS0FBSyxRQUFRb0MsUUFBUSxRQUFRO0FBQUEsSUFDL0IsRUFBRXBDLEtBQUssV0FBV29DLFFBQVEsVUFBVTtBQUFBLElBQ3BDLEVBQUVwQyxLQUFLLGdCQUFnQm9DLFFBQVEsZ0JBQWdCO0FBQUEsSUFDL0MsRUFBRXBDLEtBQUssaUJBQWlCb0MsUUFBUSxlQUFlO0FBQUEsSUFDL0MsRUFBRXBDLEtBQUssaUJBQWlCb0MsUUFBUSxrQkFBa0I7QUFBQSxJQUNsRCxFQUFFcEMsS0FBSyxzQkFBc0JvQyxRQUFRLGtCQUFrQjtBQUFBLElBQ3ZELEVBQUVwQyxLQUFLLHdCQUF3Qm9DLFFBQVEsZ0JBQWdCO0FBQUEsSUFDdkQsRUFBRXBDLEtBQUssY0FBY29DLFFBQVEsY0FBYztBQUFBLElBQzNDLEVBQUVwQyxLQUFLLG1CQUFtQm9DLFFBQVEscUJBQXFCO0FBQUEsSUFDdkQsRUFBRXBDLEtBQUssaUJBQWlCb0MsUUFBUSxlQUFlO0FBQUEsSUFDL0MsRUFBRXBDLEtBQUssbUJBQW1Cb0MsUUFBUSxhQUFhO0FBQUEsSUFDL0MsRUFBRXBDLEtBQUssVUFBVW9DLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVwQyxLQUFLLGNBQWNvQyxRQUFRLGNBQWM7QUFBQSxJQUUzQyxFQUFFcEMsS0FBSyxlQUFlb0MsUUFBUSxVQUFVO0FBQUEsRUFBQztBQUczQyxRQUFNQyxXQUFXQSxDQUFDLEVBQUVDLE1BQU1DLE1BQU1wQyxPQUFPcUMsT0FBT0MsTUFBTSxNQUNsRCx1QkFBQyxTQUFJLFdBQVUsNENBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsMkJBQUMsU0FDQztBQUFBLDZCQUFDLE9BQUUsV0FBVSwwQ0FBMEN0QyxtQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RDtBQUFBLE1BQzdELHVCQUFDLE9BQUUsV0FBVSxvQ0FBb0NxQyxtQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RDtBQUFBLFNBRnpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFXLGtCQUFrQkMsS0FBSyxJQUNyQyxpQ0FBQyxRQUFLLFdBQVUsd0JBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0MsS0FEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBVUE7QUFHRixTQUNFLHVCQUFDLFNBQUksV0FBVSxnQkFDYixpQ0FBQyxTQUFJLFdBQVUsWUFFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLDhDQUNaO0FBQUEsK0JBQUMsWUFBUyxXQUFVLDZCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDO0FBQUEsUUFBRztBQUFBLFdBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxXQUFVLHVCQUFzQixrRkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUVDdEcsVUFDQyx1QkFBQyxTQUFJLFdBQVUseUNBQ2IsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxJQUVBLG1DQUNFO0FBQUEsNkJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU87QUFBQSxZQUNMO0FBQUEsY0FDRTZELEtBQUs7QUFBQSxjQUNMRyxPQUNFLHVCQUFDLFVBQUssV0FBVSx5Q0FBd0MsNkJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVGdUMsVUFDRSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxJQUFHO0FBQUEsb0JBQ0gsV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsZUFBWSxXQUFVLG1CQUFrQixNQUFNLE1BQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWtEO0FBQUEsc0JBQUc7QUFBQTtBQUFBO0FBQUEsa0JBSnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLElBQUc7QUFBQSxvQkFDSCxXQUFVO0FBQUEsb0JBRVY7QUFBQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFVO0FBQUEsMEJBQ1YsTUFBTTtBQUFBO0FBQUEsd0JBRlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUVXO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVNBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsSUFBRztBQUFBLG9CQUNILFdBQVU7QUFBQSxvQkFFVjtBQUFBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFdBQVU7QUFBQSwwQkFDVixNQUFNO0FBQUE7QUFBQSx3QkFGUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBRVc7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFOYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBU0E7QUFBQSxtQkEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFrQ0E7QUFBQSxZQUVKO0FBQUEsVUFBQztBQUFBLFVBRUgsa0JBQWtCLENBQUMsR0FBRztBQUFBLFVBQ3RCLFdBQVU7QUFBQTtBQUFBLFFBakRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWlEa0UsS0FsRHBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvREE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSw2REFFYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNN0g7QUFBQUEsY0FDTixPQUFNO0FBQUEsY0FDTixPQUFPOEcsYUFBYUU7QUFBQUEsY0FDcEIsT0FBTTtBQUFBO0FBQUEsWUFKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJdUI7QUFBQSxVQUV2Qix1QkFBQyxVQUFLLFdBQVUsMERBQ2JoRyw4QkFBb0I4RixhQUFhRSxjQUFjLENBQUMsS0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTTdHO0FBQUFBLGNBQ04sT0FBTTtBQUFBLGNBQ04sT0FBTyxJQUFJMkcsYUFBYUcsV0FBVztBQUFBLGNBQ25DLE9BQU07QUFBQTtBQUFBLFlBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSXVCO0FBQUEsVUFFdkIsdUJBQUMsVUFBSyxXQUFVLDBEQUNiakcsOEJBQW9COEYsYUFBYUcsZUFBZSxDQUFDLEtBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU03RztBQUFBQSxjQUNOLE9BQU07QUFBQSxjQUNOLE9BQU8sSUFBSTBHLGFBQWFNLFNBQVM7QUFBQSxjQUNqQyxPQUFNO0FBQUE7QUFBQSxZQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlzQjtBQUFBLFVBRXRCLHVCQUFDLFVBQUssV0FBVSwwREFDYnBHLDhCQUFvQjhGLGFBQWFNLGFBQWEsQ0FBQyxLQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNbEg7QUFBQUEsY0FDTixPQUFNO0FBQUEsY0FDTixPQUFPLElBQUk0RyxhQUFhTyxZQUFZO0FBQUEsY0FDcEMsT0FBTTtBQUFBO0FBQUEsWUFKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJdUI7QUFBQSxVQUV2Qix1QkFBQyxVQUFLLFdBQVUsMERBQ2JyRyw4QkFBb0I4RixhQUFhTyxnQkFBZ0IsQ0FBQyxLQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxXQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0RBO0FBQUEsTUFJQSx1QkFBQyxTQUFJLFdBQVUsaURBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsc0RBQ1o7QUFBQSxpQ0FBQyxVQUFPLFdBQVUsYUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkI7QUFBQSxVQUFHO0FBQUEsYUFEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsd0RBRWI7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtDQUFpQyxnQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0U7QUFBQSxZQUNsRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDO0FBQUEsZ0JBQ0EsYUFBWTtBQUFBLGdCQUNaLE9BQU83RjtBQUFBQSxnQkFDUCxVQUFVQztBQUFBQSxnQkFDVjtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFFVjtBQUFBLHlDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyx5QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQSxrQkFDaENzRCxpQkFBaUJyQztBQUFBQSxvQkFBSSxDQUFDRixTQUNyQix1QkFBQyxPQUFPLFFBQVAsRUFBNEIsT0FBT0EsS0FBS0ksSUFDdENKLGVBQUs4QyxTQURZOUMsS0FBS0ksSUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQTtBQUFBLGNBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBY0E7QUFBQSxlQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQTtBQUFBLFVBR0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxrQ0FBaUMsd0JBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUEsWUFDMUQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWixPQUFPbEI7QUFBQUEsZ0JBQ1AsVUFBVUM7QUFBQUEsZ0JBQ1Y7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsNkJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFDO0FBQUEsa0JBQ3BDK0QsZ0JBQWdCaEQ7QUFBQUEsb0JBQUksQ0FBQ29GLFNBQ3BCO0FBQUEsc0JBQUMsT0FBTztBQUFBLHNCQUFQO0FBQUEsd0JBRUMsT0FBT0EsS0FBS2xGO0FBQUFBLHdCQUVYa0Y7QUFBQUEsK0JBQUtqQztBQUFBQSwwQkFBTztBQUFBLDBCQUFJaUMsS0FBS25DO0FBQUFBLDBCQUFLO0FBQUEsMEJBQUltQyxLQUFLbEM7QUFBQUE7QUFBQUE7QUFBQUEsc0JBSC9Ca0MsS0FBS2xGO0FBQUFBLHNCQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxrQkFDRDtBQUFBO0FBQUE7QUFBQSxjQWhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFpQkE7QUFBQSxlQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CQTtBQUFBLFVBR0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxrQ0FBaUMsMkJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZEO0FBQUEsWUFDN0Q7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWixPQUFPaEI7QUFBQUEsZ0JBQ1AsVUFBVUM7QUFBQUEsZ0JBQ1Y7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsK0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVDO0FBQUEsa0JBQ3RDaUUsaUJBQWlCcEQ7QUFBQUEsb0JBQUksQ0FBQ3FGLFFBQ3JCLHVCQUFDLE9BQU8sUUFBUCxFQUF3QixPQUFPQSxLQUM3QkEsaUJBRGlCQSxLQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBO0FBQUEsY0FiSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFjQTtBQUFBLGVBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsVUFHQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtDQUFpQyxnQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0U7QUFBQSxZQUNsRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU9qRztBQUFBQSxnQkFDUCxVQUFVQztBQUFBQSxnQkFDVixXQUFVO0FBQUEsZ0JBQ1YsUUFBTztBQUFBO0FBQUEsY0FKVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJcUI7QUFBQSxlQU52QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsYUF6RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBFQTtBQUFBLFdBL0VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnRkE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBU3VGO0FBQUFBLFVBQ1QsTUFBTXJCO0FBQUFBLFVBQ0wsa0JBQWlCO0FBQUEsVUFDbEIsaUJBQWdCO0FBQUE7QUFBQSxRQUpsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJbUQsS0FMckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsU0F2TUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdNQTtBQUFBLE9BeE5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwTkEsS0EzTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTROQTtBQUVKO0FBQUU5RSxHQTVZSUQsc0JBQW9CO0FBQUE4RyxLQUFwQjlHO0FBOFlOLGVBQWVBO0FBQXFCLElBQUE4RztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJTZWFyY2giLCJGaWxlVGV4dCIsIlVzZXJzIiwiQ2FsZW5kYXIiLCJJbmRpYW5SdXBlZSIsIlRyZW5kaW5nVXAiLCJEYXRlUGlja2VyIiwiZGF5anMiLCJDb2xsYXBzZSIsIkxpbmsiLCJGaWxlVGV4dE91dGxpbmVkIiwiRG9sbGFyT3V0bGluZWQiLCJGYU1vbmV5QmlsbCIsImFwaSIsIkRhdGFUYWJsZSIsIlNlbGVjdCIsIkNpcmN1bGFyTG9hZGVyIiwibnVtYmVyVG9JbmRpYW5Xb3JkcyIsIlJhbmdlUGlja2VyIiwiTG9hbkNvbXBsZXRpb25SZXBvcnQiLCJfcyIsImxvYW5SZXBvcnRUYWJsZSIsInNldExvYW5SZXBvcnRUYWJsZSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwic2VsZWN0ZWRMb2FuSWQiLCJzZXRTZWxlY3RlZExvYW5JZCIsInNlbGVjdGVkQ3VzdG9tZXIiLCJzZXRTZWxlY3RlZEN1c3RvbWVyIiwic2VsZWN0ZWRSZWZlcnJlZEJ5Iiwic2V0U2VsZWN0ZWRSZWZlcnJlZEJ5IiwiZGF0ZVJhbmdlIiwic2V0RGF0ZVJhbmdlIiwidXNlRWZmZWN0IiwiZmV0Y2hMb2FuUmVwb3J0IiwicmVzcG9uc2UiLCJnZXQiLCJmb3JtYXR0ZWREYXRhIiwiZGF0YSIsImxvYW5SZXBvcnRzIiwiZmlsdGVyIiwibG9hbiIsInN0YXR1cyIsIm1hcCIsImluZGV4IiwiaWQiLCJfaWQiLCJzbE5vIiwibG9hbklkcyIsImxvYW5faWQiLCJsb2FuQW1vdW50VmFsdWUiLCJsb2FuX2Ftb3VudCIsImN1c3RvbWVySWQiLCJib3Jyb3dlciIsImN1c3RvbWVyX2lkIiwiY3VzdG9tZXJOYW1lIiwiZnVsbF9uYW1lIiwiY3VzdG9tZXJQaG9uZSIsInBob25lX251bWJlciIsImRhaWx5X3BheW1lbnRfYW1vdW50IiwibG9hblN0YXJ0RGF0ZSIsInN0YXJ0X2RhdGUiLCJEYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwibG9hblN0YXJ0RGF0ZU9iaiIsInBheWFibGVMb2FuRGF5cyIsImRheXNfY291bnQiLCJsb2FuU2VydmljZUNoYXJnZXMiLCJzZXJ2aWNlX2NoYXJnZXMiLCJsb2FuQW1vdW50IiwiZG91YmxlX2xvYW5fYW1vdW50IiwicGF5YWJsZUFtb3VudCIsImFtb3VudF9wYXlhYmxlIiwidG90YWxMb2FuQW1vdW50IiwidG90YWxfcGFpZF9hbW91bnQiLCJsb2FuQmFsYW5jZSIsImJhbGFuY2UiLCJyZWZlcnJlZEJ5IiwiZXJyb3IiLCJjb25zb2xlIiwidW5pcXVlTG9hbkNvbWJvcyIsInVzZU1lbW8iLCJNYXAiLCJmb3JFYWNoIiwia2V5IiwiaGFzIiwic2V0IiwibGFiZWwiLCJBcnJheSIsImZyb20iLCJ2YWx1ZXMiLCJ1bmlxdWVDdXN0b21lcnMiLCJuYW1lIiwicGhvbmUiLCJjdXN0aWQiLCJ1bmlxdWVSZWZlcnJlZEJ5IiwiU2V0IiwiYWRkIiwiZmlsdGVyZWRMb2FuUmVwb3J0IiwibWF0Y2hMb2FuSWQiLCJtYXRjaEN1c3RvbWVyIiwibWF0Y2hSZWZlcnJlZEJ5IiwibWF0Y2hEYXRlUmFuZ2UiLCJsZW5ndGgiLCJzdGFydERhdGUiLCJzdGFydE9mIiwiZW5kRGF0ZSIsImVuZE9mIiwibG9hbkRhdGUiLCJpc0FmdGVyIiwiaXNCZWZvcmUiLCJzdW1tYXJ5U3RhdHMiLCJmaWx0ZXJlZCIsInRvdGFsTG9hbnMiLCJ0b3RhbEFtb3VudCIsInJlZHVjZSIsInN1bSIsInRvdGFsUGFpZCIsInRvdGFsQmFsYW5jZSIsImxvYW5SZXBvcnRDb2x1bW5zIiwiaGVhZGVyIiwiU3RhdENhcmQiLCJpY29uIiwiSWNvbiIsInZhbHVlIiwiY29sb3IiLCJjaGlsZHJlbiIsImN1c3QiLCJyZWYiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJMb2FuQ29tcGxldGlvblJlcG9ydC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlTWVtbyB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBTZWFyY2gsIEZpbGVUZXh0LCBVc2VycywgQ2FsZW5kYXIsIEluZGlhblJ1cGVlLCBUcmVuZGluZ1VwIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgeyBEYXRlUGlja2VyIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IGRheWpzIGZyb20gXCJkYXlqc1wiO1xyXG5pbXBvcnQgeyBDb2xsYXBzZSB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBGaWxlVGV4dE91dGxpbmVkLCBEb2xsYXJPdXRsaW5lZCB9IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5pbXBvcnQgeyBGYU1vbmV5QmlsbCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IHsgU2VsZWN0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuXHJcbmltcG9ydCB7IG51bWJlclRvSW5kaWFuV29yZHMgfSBmcm9tIFwiLi4vaGVscGVycy9udW1iZXJUb0luZGlhbldvcmRzXCJcclxuXHJcbmNvbnN0IHsgUmFuZ2VQaWNrZXIgfSA9IERhdGVQaWNrZXI7XHJcblxyXG5jb25zdCBMb2FuQ29tcGxldGlvblJlcG9ydCA9ICgpID0+IHtcclxuICBjb25zdCBbbG9hblJlcG9ydFRhYmxlLCBzZXRMb2FuUmVwb3J0VGFibGVdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG5cclxuICBjb25zdCBbc2VsZWN0ZWRMb2FuSWQsIHNldFNlbGVjdGVkTG9hbklkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEN1c3RvbWVyLCBzZXRTZWxlY3RlZEN1c3RvbWVyXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFJlZmVycmVkQnksIHNldFNlbGVjdGVkUmVmZXJyZWRCeV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZGF0ZVJhbmdlLCBzZXREYXRlUmFuZ2VdID0gdXNlU3RhdGUobnVsbCk7IC8vIE5FVyBTVEFURSBmb3IgZGF0ZSByYW5nZVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hMb2FuUmVwb3J0ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3BheW1lbnQvY3VzdG9tZXJzL2xvYW4tcmVwb3J0YCk7XHJcbiAgICAgICBcclxuXHJcbiAgICAgICAgLy8gY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlLmRhdGEubG9hblJlcG9ydHMubWFwKChsb2FuLCBpbmRleCkgPT4gKHtcclxuICAgICAgICAvLyAgIGlkOiBsb2FuPy5faWQsXHJcbiAgICAgICAgLy8gICBzbE5vOiBpbmRleCArIDEsXHJcbiAgICAgICAgLy8gICBsb2FuSWRzOiBsb2FuPy5sb2FuX2lkIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgLy8gICBsb2FuQW1vdW50VmFsdWU6IGxvYW4/LmxvYW5fYW1vdW50IHx8IDAsXHJcblxyXG4gICAgICAgIC8vICAgY3VzdG9tZXJJZDogbG9hbj8uYm9ycm93ZXI/LmN1c3RvbWVyX2lkIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgLy8gICBjdXN0b21lck5hbWU6IGxvYW4/LmJvcnJvd2VyPy5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAvLyAgIGN1c3RvbWVyUGhvbmU6IGxvYW4/LmJvcnJvd2VyPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICAvLyAgIGRhaWx5X3BheW1lbnRfYW1vdW50OiBsb2FuPy5kYWlseV9wYXltZW50X2Ftb3VudCB8fCBcIk4vQVwiLFxyXG4gICAgICAgIC8vICAgbG9hblN0YXJ0RGF0ZTogbG9hbj8uc3RhcnRfZGF0ZVxyXG4gICAgICAgIC8vICAgICA/IG5ldyBEYXRlKGxvYW4uc3RhcnRfZGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tR0JcIilcclxuICAgICAgICAvLyAgICAgOiBcIk4vQVwiLFxyXG4gICAgICAgIC8vICAgLy8gU3RvcmUgdGhlIG9yaWdpbmFsIGRhdGUgZm9yIGZpbHRlcmluZ1xyXG4gICAgICAgIC8vICAgbG9hblN0YXJ0RGF0ZU9iajogbG9hbj8uc3RhcnRfZGF0ZSA/IG5ldyBEYXRlKGxvYW4uc3RhcnRfZGF0ZSkgOiBudWxsLFxyXG5cclxuICAgICAgICAvLyAgIGxvYW5TZXJ2aWNlQ2hhcmdlczogbG9hbj8uc2VydmljZV9jaGFyZ2VzID8/IDAsXHJcbiAgICAgICAgLy8gICBsb2FuQW1vdW50OiBsb2FuPy5kb3VibGVfbG9hbl9hbW91bnQgPz8gMCxcclxuICAgICAgICAvLyAgIHBheWFibGVBbW91bnQ6IGxvYW4/LmFtb3VudF9wYXlhYmxlID8/IDAsXHJcbiAgICAgICAgLy8gICB0b3RhbExvYW5BbW91bnQ6IGxvYW4/LnRvdGFsX3BhaWRfYW1vdW50ID8/IDAsXHJcbiAgICAgICAgLy8gICBsb2FuQmFsYW5jZTogbG9hbj8uYmFsYW5jZSA/PyAwLFxyXG4gICAgICAgIC8vICAgc3RhdHVzOiBsb2FuPy5zdGF0dXMgPT09IFwiQ29tcGxldGVkXCIgPyBsb2FuLnN0YXR1cyA6IG51bGwsXHJcbiAgICAgICAgLy8gICByZWZlcnJlZEJ5OiBsb2FuPy5yZWZlcnJlZEJ5IHx8IFwiTi9BXCIsXHJcbiAgICAgICAgLy8gfSkpO1xyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLmxvYW5SZXBvcnRzXHJcbiAgICAgICAgICAuZmlsdGVyKGxvYW4gPT4gbG9hbj8uc3RhdHVzID09PSBcIkNvbXBsZXRlZFwiKVxyXG4gICAgICAgICAgLm1hcCgobG9hbiwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICAgIGlkOiBsb2FuPy5faWQsXHJcbiAgICAgICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgbG9hbklkczogbG9hbj8ubG9hbl9pZCB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICBsb2FuQW1vdW50VmFsdWU6IGxvYW4/LmxvYW5fYW1vdW50IHx8IDAsXHJcblxyXG4gICAgICAgICAgICBjdXN0b21lcklkOiBsb2FuPy5ib3Jyb3dlcj8uY3VzdG9tZXJfaWQgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgY3VzdG9tZXJOYW1lOiBsb2FuPy5ib3Jyb3dlcj8uZnVsbF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIGN1c3RvbWVyUGhvbmU6IGxvYW4/LmJvcnJvd2VyPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgZGFpbHlfcGF5bWVudF9hbW91bnQ6IGxvYW4/LmRhaWx5X3BheW1lbnRfYW1vdW50IHx8IFwiTi9BXCIsXHJcblxyXG4gICAgICAgICAgICBsb2FuU3RhcnREYXRlOiBsb2FuPy5zdGFydF9kYXRlXHJcbiAgICAgICAgICAgICAgPyBuZXcgRGF0ZShsb2FuLnN0YXJ0X2RhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUdCXCIpXHJcbiAgICAgICAgICAgICAgOiBcIk4vQVwiLFxyXG4gICAgICAgICAgICBsb2FuU3RhcnREYXRlT2JqOiBsb2FuPy5zdGFydF9kYXRlID8gbmV3IERhdGUobG9hbi5zdGFydF9kYXRlKSA6IG51bGwsXHJcbiAgICAgICAgICAgIC8vIHBheWFibGVMb2FuRGF5czogbG9hbj8uZGF5c19jb3VudCAmJiBgJHtsb2FuPy5kYXlzX2NvdW50IHx8IDB9IERheXNgLFxyXG4gICAgICAgICAgICBwYXlhYmxlTG9hbkRheXM6IGxvYW4/LmRheXNfY291bnQsXHJcblxyXG4gICAgICAgICAgICBsb2FuU2VydmljZUNoYXJnZXM6IGxvYW4/LnNlcnZpY2VfY2hhcmdlcyA/PyAwLFxyXG4gICAgICAgICAgICBsb2FuQW1vdW50OiBsb2FuPy5kb3VibGVfbG9hbl9hbW91bnQgPz8gMCxcclxuICAgICAgICAgICAgcGF5YWJsZUFtb3VudDogbG9hbj8uYW1vdW50X3BheWFibGUgPz8gMCxcclxuICAgICAgICAgICAgdG90YWxMb2FuQW1vdW50OiBsb2FuPy50b3RhbF9wYWlkX2Ftb3VudCA/PyAwLFxyXG4gICAgICAgICAgICBsb2FuQmFsYW5jZTogbG9hbj8uYmFsYW5jZSA/PyAwLFxyXG5cclxuICAgICAgICAgICAgc3RhdHVzOiBsb2FuLnN0YXR1cywgLy8gYWx3YXlzIFwiQ29tcGxldGVkXCIgbm93XHJcbiAgICAgICAgICAgIHJlZmVycmVkQnk6IGxvYW4/LnJlZmVycmVkQnkgfHwgXCJOL0FcIixcclxuICAgICAgICAgIH0pKTtcclxuXHJcbiAgICAgICAgc2V0TG9hblJlcG9ydFRhYmxlKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBsb2FuIHJlcG9ydDpcIiwgZXJyb3IpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoTG9hblJlcG9ydCgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgdW5pcXVlTG9hbkNvbWJvcyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgbWFwID0gbmV3IE1hcCgpO1xyXG4gICAgbG9hblJlcG9ydFRhYmxlLmZvckVhY2goKGxvYW4pID0+IHtcclxuICAgICAgY29uc3Qga2V5ID0gbG9hbi5sb2FuSWRzO1xyXG4gICAgICBpZiAoIW1hcC5oYXMoa2V5KSkge1xyXG4gICAgICAgIG1hcC5zZXQoa2V5LCB7IGlkOiBrZXksIGxhYmVsOiBgJHtrZXl9IHwg4oK5JHtsb2FuLmxvYW5BbW91bnRWYWx1ZX1gIH0pO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIHJldHVybiBBcnJheS5mcm9tKG1hcC52YWx1ZXMoKSk7XHJcbiAgfSwgW2xvYW5SZXBvcnRUYWJsZV0pO1xyXG5cclxuICBjb25zdCB1bmlxdWVDdXN0b21lcnMgPSB1c2VNZW1vKFxyXG4gICAgKCkgPT5cclxuICAgICAgbG9hblJlcG9ydFRhYmxlLm1hcCgobG9hbikgPT4gKHtcclxuICAgICAgICBpZDogbG9hbi5pZCxcclxuICAgICAgICBuYW1lOiBsb2FuLmN1c3RvbWVyTmFtZSxcclxuICAgICAgICBwaG9uZTogbG9hbi5jdXN0b21lclBob25lLFxyXG4gICAgICAgIGN1c3RpZDogbG9hbi5jdXN0b21lcklkLFxyXG4gICAgICB9KSksXHJcbiAgICBbbG9hblJlcG9ydFRhYmxlXVxyXG4gICk7XHJcblxyXG4gIGNvbnN0IHVuaXF1ZVJlZmVycmVkQnkgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IHNldCA9IG5ldyBTZXQoKTtcclxuICAgIGxvYW5SZXBvcnRUYWJsZS5mb3JFYWNoKChsb2FuKSA9PiB7XHJcbiAgICAgIGlmIChsb2FuLnJlZmVycmVkQnkgJiYgbG9hbi5yZWZlcnJlZEJ5ICE9PSBcIk4vQVwiKSB7XHJcbiAgICAgICAgc2V0LmFkZChsb2FuLnJlZmVycmVkQnkpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIHJldHVybiBBcnJheS5mcm9tKHNldCk7XHJcbiAgfSwgW2xvYW5SZXBvcnRUYWJsZV0pO1xyXG5cclxuICBjb25zdCBmaWx0ZXJlZExvYW5SZXBvcnQgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiBsb2FuUmVwb3J0VGFibGUuZmlsdGVyKChsb2FuKSA9PiB7XHJcbiAgICAgIGNvbnN0IG1hdGNoTG9hbklkID0gc2VsZWN0ZWRMb2FuSWQgPyBsb2FuLmxvYW5JZHMgPT09IHNlbGVjdGVkTG9hbklkIDogdHJ1ZTtcclxuICAgICAgY29uc3QgbWF0Y2hDdXN0b21lciA9IHNlbGVjdGVkQ3VzdG9tZXIgPyBsb2FuLmlkID09PSBzZWxlY3RlZEN1c3RvbWVyIDogdHJ1ZTtcclxuICAgICAgY29uc3QgbWF0Y2hSZWZlcnJlZEJ5ID0gc2VsZWN0ZWRSZWZlcnJlZEJ5ID8gbG9hbi5yZWZlcnJlZEJ5ID09PSBzZWxlY3RlZFJlZmVycmVkQnkgOiB0cnVlO1xyXG5cclxuICAgICAgLy8gTkVXOiBEYXRlIHJhbmdlIGZpbHRlcmluZ1xyXG4gICAgICBsZXQgbWF0Y2hEYXRlUmFuZ2UgPSB0cnVlO1xyXG4gICAgICBpZiAoZGF0ZVJhbmdlICYmIGRhdGVSYW5nZS5sZW5ndGggPT09IDIgJiYgbG9hbi5sb2FuU3RhcnREYXRlT2JqKSB7XHJcbiAgICAgICAgY29uc3Qgc3RhcnREYXRlID0gZGF5anMoZGF0ZVJhbmdlWzBdKS5zdGFydE9mKCdkYXknKTtcclxuICAgICAgICBjb25zdCBlbmREYXRlID0gZGF5anMoZGF0ZVJhbmdlWzFdKS5lbmRPZignZGF5Jyk7XHJcbiAgICAgICAgY29uc3QgbG9hbkRhdGUgPSBkYXlqcyhsb2FuLmxvYW5TdGFydERhdGVPYmopO1xyXG4gICAgICAgIG1hdGNoRGF0ZVJhbmdlID0gbG9hbkRhdGUuaXNBZnRlcihzdGFydERhdGUpICYmIGxvYW5EYXRlLmlzQmVmb3JlKGVuZERhdGUpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4gbWF0Y2hMb2FuSWQgJiYgbWF0Y2hDdXN0b21lciAmJiBtYXRjaFJlZmVycmVkQnkgJiYgbWF0Y2hEYXRlUmFuZ2U7XHJcbiAgICB9KTtcclxuICB9LCBbbG9hblJlcG9ydFRhYmxlLCBzZWxlY3RlZExvYW5JZCwgc2VsZWN0ZWRDdXN0b21lciwgc2VsZWN0ZWRSZWZlcnJlZEJ5LCBkYXRlUmFuZ2VdKTtcclxuXHJcbiAgY29uc3Qgc3VtbWFyeVN0YXRzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBmaWx0ZXJlZCA9IGZpbHRlcmVkTG9hblJlcG9ydDtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHRvdGFsTG9hbnM6IGZpbHRlcmVkLmxlbmd0aCxcclxuICAgICAgdG90YWxBbW91bnQ6IGZpbHRlcmVkLnJlZHVjZSgoc3VtLCBsb2FuKSA9PiBzdW0gKyBsb2FuLmxvYW5BbW91bnQsIDApLFxyXG4gICAgICB0b3RhbFBhaWQ6IGZpbHRlcmVkLnJlZHVjZSgoc3VtLCBsb2FuKSA9PiBzdW0gKyBsb2FuLnRvdGFsTG9hbkFtb3VudCwgMCksXHJcbiAgICAgIHRvdGFsQmFsYW5jZTogZmlsdGVyZWQucmVkdWNlKChzdW0sIGxvYW4pID0+IHN1bSArIGxvYW4ubG9hbkJhbGFuY2UsIDApLFxyXG4gICAgfTtcclxuICB9LCBbZmlsdGVyZWRMb2FuUmVwb3J0XSk7XHJcblxyXG4gIGNvbnN0IGxvYW5SZXBvcnRDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwic2xOb1wiLCBoZWFkZXI6IFwiU2wgTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwibG9hbklkc1wiLCBoZWFkZXI6IFwiTG9hbiBJRFwiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lck5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJQaG9uZVwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImxvYW5TdGFydERhdGVcIiwgaGVhZGVyOiBcIkxvYW4gU3RhcnQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJsb2FuU2VydmljZUNoYXJnZXNcIiwgaGVhZGVyOiBcIlNlcnZpY2UgQ2hhcmdlc1wiIH0sXHJcbiAgICB7IGtleTogXCJkYWlseV9wYXltZW50X2Ftb3VudFwiLCBoZWFkZXI6IFwiRGFpbHkgUGF5bWVudFwiIH0sXHJcbiAgICB7IGtleTogXCJsb2FuQW1vdW50XCIsIGhlYWRlcjogXCJMb2FuIEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJwYXlhYmxlTG9hbkRheXNcIiwgaGVhZGVyOiBcIkxvYW4gQWdlIChpbiBEYXlzKVwiIH0sXHJcbiAgICB7IGtleTogXCJwYXlhYmxlQW1vdW50XCIsIGhlYWRlcjogXCJMb2FuIFBheWFibGVcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxMb2FuQW1vdW50XCIsIGhlYWRlcjogXCJUb3RhbCBQYWlkXCIgfSxcclxuICAgIHsga2V5OiBcInN0YXR1c1wiLCBoZWFkZXI6IFwiU3RhdHVzXCIgfSxcclxuICAgIHsga2V5OiBcInJlZmVycmVkQnlcIiwgaGVhZGVyOiBcIlJlZmVycmVkIEJ5XCIgfSxcclxuXHJcbiAgICB7IGtleTogXCJsb2FuQmFsYW5jZVwiLCBoZWFkZXI6IFwiQmFsYW5jZVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgU3RhdENhcmQgPSAoeyBpY29uOiBJY29uLCBsYWJlbCwgdmFsdWUsIGNvbG9yIH0pID0+IChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctc20gYm9yZGVyIHAtNlwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgbWItMVwiPntsYWJlbH08L3A+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPnt2YWx1ZX08L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BwLTMgcm91bmRlZC1sZyAke2NvbG9yfWB9PlxyXG4gICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LXdoaXRlXCIgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy1zY3JlZW5cIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCIgbXgtYXV0b1wiPlxyXG4gICAgICAgIHsvKiBIZWFkZXIgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XHJcbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxGaWxlVGV4dCBjbGFzc05hbWU9XCJ3LTcgaC03IHRleHQtdmlvbGV0LTYwMFwiIC8+IExvYW4gQ29tcGxldGlvbiBSZXBvcnRcclxuICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIG1sLTEwXCI+XHJcbiAgICAgICAgICAgIE92ZXJ2aWV3IG9mIGN1c3RvbWVyIGNvbXBsZXRpb24gbG9hbnMsIHBheW1lbnRzICYgcmVmZXJyYWwgZGV0YWlsc1xyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7bG9hZGluZyA/IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgaC05NlwiPlxyXG4gICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm15LTZcIj5cclxuICAgICAgICAgICAgICA8Q29sbGFwc2VcclxuICAgICAgICAgICAgICAgIGl0ZW1zPXtbXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1iYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFNob3J0Y3V0IEtleXNcclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIGNoaWxkcmVuOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgbWQ6Z3JpZC1jb2xzLTUgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0bz1cIi9vdGhlci1zZXJ2aWNlLW1lbnUvbG9hblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCB0ZXh0LWJhc2UgaXRlbXMtY2VudGVyIGdhcC0yIGJvcmRlciAgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgcHgtNCBweS0yIHRleHQtZ3JheS03MDAgaG92ZXI6Ym9yZGVyLXZpb2xldC01MDAgaG92ZXI6dGV4dC12aW9sZXQtNjAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxGYU1vbmV5QmlsbCBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC01MDBcIiBzaXplPXszMH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBBZGQgTG9hblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdG89XCIvcmVwb3J0cy9jdXN0b21lci1sb2FuLXJlcG9ydFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCB0ZXh0LWJhc2UgaXRlbXMtY2VudGVyIGdhcC0yIGJvcmRlciAgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgcHgtNCBweS0yIHRleHQtZ3JheS03MDAgaG92ZXI6Ym9yZGVyLXZpb2xldC01MDAgaG92ZXI6dGV4dC12aW9sZXQtNjAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxGaWxlVGV4dE91dGxpbmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT17MzB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBMb2FuIFN1bW1hcnkgUmVwb3J0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0bz1cIi9yZXBvcnRzL2xvYW4tZHVlLXJlcG9ydFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCB0ZXh0LWJhc2UgaXRlbXMtY2VudGVyIGdhcC0yIGJvcmRlciAgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgcHgtNCBweS0yIHRleHQtZ3JheS03MDAgaG92ZXI6Ym9yZGVyLXZpb2xldC01MDAgaG92ZXI6dGV4dC12aW9sZXQtNjAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxEb2xsYXJPdXRsaW5lZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9ezMwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgT3V0U3RhbmRpbmcgTG9hbiBSZXBvcnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0QWN0aXZlS2V5PXtbXCIxXCJdfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHNoYWRvdy1zbVwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHsvKiBTdW1tYXJ5IENhcmRzICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTYgbWItOFwiPlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgIDxTdGF0Q2FyZFxyXG4gICAgICAgICAgICAgICAgICBpY29uPXtGaWxlVGV4dH1cclxuICAgICAgICAgICAgICAgICAgbGFiZWw9XCJUb3RhbCBMb2Fuc1wiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdW1tYXJ5U3RhdHMudG90YWxMb2Fuc31cclxuICAgICAgICAgICAgICAgICAgY29sb3I9XCJiZy12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMCBtdC0yIGJyZWFrLXdvcmRzIHBsLTNcIj5cclxuICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoc3VtbWFyeVN0YXRzLnRvdGFsTG9hbnMgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgPFN0YXRDYXJkXHJcbiAgICAgICAgICAgICAgICAgIGljb249e0luZGlhblJ1cGVlfVxyXG4gICAgICAgICAgICAgICAgICBsYWJlbD1cIlRvdGFsIExvYW4gQW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Digrkke3N1bW1hcnlTdGF0cy50b3RhbEFtb3VudH1gfVxyXG4gICAgICAgICAgICAgICAgICBjb2xvcj1cImJnLXB1cnBsZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tb25vIHRleHQtZ3JlZW4tNzAwIG10LTIgYnJlYWstd29yZHMgcGwtM1wiPlxyXG4gICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhzdW1tYXJ5U3RhdHMudG90YWxBbW91bnQgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgPFN0YXRDYXJkXHJcbiAgICAgICAgICAgICAgICAgIGljb249e1RyZW5kaW5nVXB9XHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPVwiVG90YWwgUGFpZFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtg4oK5JHtzdW1tYXJ5U3RhdHMudG90YWxQYWlkfWB9XHJcbiAgICAgICAgICAgICAgICAgIGNvbG9yPVwiYmctZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMCBtdC0yIGJyZWFrLXdvcmRzIHBsLTNcIj5cclxuICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoc3VtbWFyeVN0YXRzLnRvdGFsUGFpZCB8fCAwKX1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICA8U3RhdENhcmRcclxuICAgICAgICAgICAgICAgICAgaWNvbj17Q2FsZW5kYXJ9XHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPVwiVG90YWwgQmFsYW5jZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtg4oK5JHtzdW1tYXJ5U3RhdHMudG90YWxCYWxhbmNlfWB9XHJcbiAgICAgICAgICAgICAgICAgIGNvbG9yPVwiYmctb3JhbmdlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1vbm8gdGV4dC1ncmVlbi03MDAgbXQtMiBicmVhay13b3JkcyBwbC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKHN1bW1hcnlTdGF0cy50b3RhbEJhbGFuY2UgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcblxyXG4gICAgICAgICAgICB7LyogRklMVEVSUyAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1zbSBib3JkZXIgcC02IG1iLThcIj5cclxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+IEZpbHRlciBPcHRpb25zXHJcbiAgICAgICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC02XCI+XHJcbiAgICAgICAgICAgICAgICB7LyogTG9hbiBGaWx0ZXIgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+TG9hbiBJRCAmIEFtb3VudDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgbG9hblwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkTG9hbklkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXRTZWxlY3RlZExvYW5JZH1cclxuICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiXCI+QWxsIExvYW5zPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1bmlxdWVMb2FuQ29tYm9zLm1hcCgobG9hbikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtsb2FuLmlkfSB2YWx1ZT17bG9hbi5pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtsb2FuLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBDdXN0b21lciBGaWx0ZXIgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+Q3VzdG9tZXI8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IGN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRDdXN0b21lcn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRDdXN0b21lcn1cclxuICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiXCI+QWxsIEN1c3RvbWVyczwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICB7dW5pcXVlQ3VzdG9tZXJzLm1hcCgoY3VzdCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtjdXN0LmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VzdC5pZH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2N1c3QuY3VzdGlkfSB8IHtjdXN0Lm5hbWV9IHwge2N1c3QucGhvbmV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFJlZmVycmVkIEJ5IEZpbHRlciAqL31cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5SZWZlcnJlZCBCeTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgcmVmZXJyZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFJlZmVycmVkQnl9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFNlbGVjdGVkUmVmZXJyZWRCeX1cclxuICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiXCI+QWxsIFJlZmVycmVkIEJ5PC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1bmlxdWVSZWZlcnJlZEJ5Lm1hcCgocmVmKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3JlZn0gdmFsdWU9e3JlZn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtyZWZ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIE5FVzogRGF0ZSBSYW5nZSBGaWx0ZXIgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+U3RhcnQgRGF0ZSBSYW5nZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxSYW5nZVBpY2tlclxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkYXRlUmFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldERhdGVSYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZvcm1hdD1cIkREL01NL1lZWVlcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFRBQkxFICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LXNjcmVlblwiPlxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgIGNvbHVtbnM9e2xvYW5SZXBvcnRDb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyZWRMb2FuUmVwb3J0fVxyXG4gICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJDdXN0b21lciBDb21wbGV0aW9uIExvYW4gUmVwb3J0LmNzdlwiXHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJDdXN0b21lciBDb21wbGV0aW9uIExvYW4gUmVwb3J0XCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IExvYW5Db21wbGV0aW9uUmVwb3J0OyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9Mb2FuQ29tcGxldGlvblJlcG9ydC5qc3gifQ==