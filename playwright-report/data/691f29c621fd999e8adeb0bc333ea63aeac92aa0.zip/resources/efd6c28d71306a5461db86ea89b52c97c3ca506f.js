import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/TargetCommission.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Select, Radio, Tabs } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import { GiPartyPopper } from "/node_modules/.vite/deps/react-icons_gi.js?v=819e0a34";
import { FileTextOutlined, DollarOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import { FaMoneyBill } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { MdPayments } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { FiTarget } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
const { TabPane } = Tabs;
const TargetCommission = () => {
  _s();
  const [employees, setEmployees] = useState([]);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState(null);
  const [selectedMonth, setSelectedMonth] = useState(null);
  const [dateSelectionMode, setDateSelectionMode] = useState("month");
  const [agentLoading, setAgentLoading] = useState(false);
  const [selectedEmployeeDetails, setSelectedEmployeeDetails] = useState(null);
  const [employeeCustomerData, setEmployeeCustomerData] = useState([]);
  const [commissionTotalDetails, setCommissionTotalDetails] = useState({});
  const [loading, setLoading] = useState(false);
  const [showCommissionModal, setShowCommissionModal] = useState(false);
  const [commissionForm, setCommissionForm] = useState({
    agent_id: "",
    pay_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
    amount: "",
    pay_type: "cash",
    transaction_id: "",
    note: "",
    pay_for: "commission",
    admin_type: ""
  });
  const [errors, setErrors] = useState({});
  const [adminId, setAdminId] = useState("");
  const [adminName, setAdminName] = useState("");
  const [targetData, setTargetData] = useState({
    target: 0,
    achieved: 0,
    remaining: 0,
    startDate: "",
    endDate: "",
    targetCommission: 0
  });
  const [tempSelectedMonth, setTempSelectedMonth] = useState(null);
  const [tempFromDate, setTempFromDate] = useState(null);
  const [tempToDate, setTempToDate] = useState(null);
  const [isFilterApplied, setIsFilterApplied] = useState(false);
  const [activeTab, setActiveTab] = useState("commission");
  const [grossCommissionData, setGrossCommissionData] = useState([]);
  const [grossCommissionSummary, setGrossCommissionSummary] = useState({
    total_gross_incentive_value: 0,
    total_gross_group_value: 0,
    total_gross_enrollments: 0
  });
  const parseAmount = (val) => parseFloat(val?.toString().replace(/[^0-9.-]+/g, "")) || 0;
  useEffect(() => {
    const today2 = /* @__PURE__ */ new Date();
    const currentMonth2 = `${today2.getFullYear()}-${String(
      today2.getMonth() + 1
    ).padStart(2, "0")}`;
    setTempSelectedMonth(currentMonth2);
    const year = today2.getFullYear();
    const month = today2.getMonth() + 1;
    const firstDay = `${year}-${String(month).padStart(2, "0")}-01`;
    const lastday1 = new Date(year, month, 0).getDate();
    const lastDay = `${year}-${month}-${String(lastday1).padStart(2, "0")}`;
    setTempFromDate(firstDay);
    setTempToDate(lastDay);
  }, []);
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (user) {
      setAdminId(user._id);
      setAdminName(user.name || "");
    }
  }, []);
  const fetchEmployees = async () => {
    try {
      const res = await api.get("/agent/get");
      setEmployees(res?.data?.agent);
    } catch (err) {
      console.error("Error fetching employees:", err);
    }
  };
  const fetchCommissionReport = async (employeeId, startDate, endDate) => {
    if (!employeeId || !startDate || !endDate) return;
    const abortController = new AbortController();
    setLoading(true);
    try {
      const params = {
        start_date: startDate,
        end_date: endDate
      };
      const res = await api.get(`/enroll/agent/${employeeId}/commission`, {
        params,
        signal: abortController.signal
      });
      setEmployeeCustomerData(res.data?.commissionData);
      setCommissionTotalDetails({
        actual_business: res.data?.commissionSummary?.total_group_value,
        total_actual: res.data?.commissionSummary?.total_commission_value,
        total_customers: res.data?.commissionSummary?.total_enrollments,
        total_groups: res.data?.commissionSummary?.total_enrollments,
        expected_business: res.data?.commissionSummary?.total_group_value,
        total_estimated: res.data?.commissionSummary?.total_commission_value
      });
    } catch (err) {
      if (err.name !== "AbortController") {
        console.error("Error fetching employee report:", err);
        setEmployeeCustomerData([]);
        setCommissionTotalDetails({});
      }
    } finally {
      if (!abortController.signal.aborted) {
        setLoading(false);
      }
    }
  };
  const fetchGrossIncentiveReport = async (employeeId, startDate, endDate) => {
    if (!employeeId || !startDate || !endDate) return;
    setLoading(true);
    try {
      let params = {
        start_date: startDate,
        end_date: endDate
      };
      const res = await api.get(
        `/enroll/agent/${employeeId}/gross-commission`,
        {
          params
        }
      );
      const commissionData = res.data?.grossCommissionInfo?.map((enrollment) => ({
        user_name: enrollment?.user_id?.full_name || "N/A",
        phone_number: enrollment?.user_id?.phone_number || "N/A",
        group_name: enrollment?.group_id?.group_name || "N/A",
        group_value: enrollment?.group_id?.group_value || "N/A",
        group_commission: enrollment?.group_id?.commission || "N/A",
        group_ticket: enrollment?.tickets || "N/A",
        enrollment_date: enrollment?.createdAt?.split("T")?.[0],
        total_paid_amount: enrollment?.total_paid_amount || "0",
        group_monthly_installment: enrollment?.group_id?.monthly_installment || "N/A"
      }));
      setGrossCommissionData(commissionData || []);
      setGrossCommissionSummary(res.data.grossCommissionSummary || {
        total_gross_commission_value: 0,
        total_gross_group_value: 0,
        total_gross_enrollments: 0
      });
    } catch (err) {
      console.error("Error fetching gross incentive report:", err);
      setGrossCommissionData([]);
      setGrossCommissionSummary({
        total_gross_commission_value: 0,
        total_gross_group_value: 0,
        total_gross_enrollments: 0
      });
    } finally {
      setLoading(false);
    }
  };
  const calculateTargetCommission = (achievedBusiness, targetAmount) => {
    const achievedNum = typeof achievedBusiness === "string" ? Number(achievedBusiness.replace(/[^0-9.-]+/g, "")) : achievedBusiness;
    const targetNum = typeof targetAmount === "string" ? Number(targetAmount.replace(/[^0-9.-]+/g, "")) : targetAmount;
    if (achievedNum <= targetNum) {
      return achievedNum * 5e-3;
    } else {
      const upToTarget = targetNum * 5e-3;
      const beyondTarget = (achievedNum - targetNum) * 0.01;
      return upToTarget + beyondTarget;
    }
  };
  const fetchTargetData = async (employeeId, startDate, endDate) => {
    if (!employeeId || !startDate || !endDate) return;
    try {
      const abortController = new AbortController();
      const targetRes = await api.get(`/target/agents/${employeeId}`, {
        params: { start_date: startDate, end_date: endDate },
        signal: abortController.signal
      });
      const targetForMonth = targetRes.data?.total_target || 0;
      const { data: comm } = await api.get(
        `/enroll/agent/${employeeId}/commission`,
        {
          params: { start_date: startDate, end_date: endDate },
          signal: abortController.signal
        }
      );
      let achieved = comm?.commissionSummary?.total_group_value || 0;
      if (typeof achieved === "string") {
        achieved = Number(achieved.replace(/[^0-9.-]+/g, ""));
      }
      const remaining = Math.max(targetForMonth - achieved, 0);
      const difference = targetForMonth - achieved;
      const targetCommission = calculateTargetCommission(
        achieved,
        targetForMonth
      );
      setTargetData({
        target: Math.round(targetForMonth),
        achieved,
        remaining,
        difference,
        startDate,
        endDate,
        targetCommission
      });
    } catch (err) {
      if (err.name !== "AbortError") {
        console.error("Error fetching target data:", err);
        setTargetData({
          target: 0,
          achieved: 0,
          remaining: 0,
          difference: 0,
          startDate: "",
          endDate: "",
          targetCommission: 0
        });
      }
    }
  };
  const fetchAllCommissionReport = async (startDate, endDate) => {
    if (!startDate || !endDate) return;
    const abortController = new AbortController();
    setLoading(true);
    try {
      const params = {
        start_date: startDate,
        end_date: endDate
      };
      const res = await api.get("/enroll/commission", {
        params,
        signal: abortController.signal
      });
      setEmployeeCustomerData(res.data?.commissionData);
      setCommissionTotalDetails({
        actual_business: res.data?.commissionSummary?.total_group_value,
        total_actual: res.data?.commissionSummary?.total_commission_value,
        total_customers: res.data?.commissionSummary?.total_enrollments,
        total_groups: res.data?.commissionSummary?.total_enrollments,
        expected_business: res.data?.commissionSummary?.total_group_value,
        total_estimated: res.data?.commissionSummary?.total_commission_value
      });
    } catch (err) {
      if (err.name !== "AbortError") {
        console.error("Error fetching all commission report:", err);
        setEmployeeCustomerData([]);
        setCommissionTotalDetails({});
      }
    } finally {
      if (!abortController.signal.aborted) {
        setLoading(false);
      }
    }
  };
  const fetchAllGrossIncentiveReport = async (startDate, endDate) => {
    if (!startDate || !endDate) return;
    setLoading(true);
    try {
      let params = {
        start_date: startDate,
        end_date: endDate
      };
      const res = await api.get("/enroll/gross-incentive", {
        params
      });
      setGrossCommissionData(res.data.grossIncentiveInfo || []);
      setGrossCommissionSummary(res.data.grossCommissionSummary || {
        total_gross_incentive_value: 0,
        total_gross_group_value: 0,
        total_gross_enrollments: 0
      });
    } catch (err) {
      console.error("Error fetching all gross incentive report:", err);
      setGrossCommissionData([]);
      setGrossCommissionSummary({
        total_gross_incentive_value: 0,
        total_gross_group_value: 0,
        total_gross_enrollments: 0
      });
    } finally {
      setLoading(false);
    }
  };
  const handleEmployeeChange = (value) => {
    setSelectedEmployeeId(value);
    setSelectedEmployeeDetails(null);
    setEmployeeCustomerData([]);
    setCommissionTotalDetails({});
    setTargetData({
      target: 0,
      achieved: 0,
      remaining: 0,
      startDate: "",
      endDate: "",
      targetCommission: 0
    });
    setGrossCommissionData([]);
    setGrossCommissionSummary({
      total_gross_incentive_value: 0,
      total_gross_group_value: 0,
      total_gross_enrollments: 0
    });
    setIsFilterApplied(false);
  };
  const handleTempMonthChange = (e) => {
    const selectedMonth2 = e.target.value;
    setTempSelectedMonth(selectedMonth2);
    if (selectedMonth2) {
      const [year, month] = selectedMonth2.split("-");
      const firstDay = `${year}-${month}-01`;
      const lastday1 = new Date(year, month, 0).getDate();
      const lastDay = `${year}-${month}-${String(lastDay).padStart(2, "0")}`;
      setTempFromDate(firstDay);
      setTempToDate(lastDay);
    }
  };
  const applyFilter = async () => {
    if (!selectedEmployeeId) {
      alert("Please select an agent.");
      return;
    }
    if (dateSelectionMode === "month" && !tempSelectedMonth) {
      alert("Please select a month.");
      return;
    }
    if (dateSelectionMode === "date-range" && (!tempFromDate || !tempToDate)) {
      alert("Please select both From and To dates.");
      return;
    }
    let startDate, endDate;
    if (dateSelectionMode === "month") {
      setSelectedMonth(tempSelectedMonth);
      const [year, month] = tempSelectedMonth.split("-");
      startDate = `${year}-${month}-01`;
      const lastDay = new Date(year, month, 0).getDate();
      endDate = `${year}-${month}-${String(lastDay).padStart(2, "0")}`;
    } else {
      startDate = tempFromDate;
      endDate = tempToDate;
    }
    setAgentLoading(true);
    setLoading(true);
    setIsFilterApplied(true);
    try {
      if (selectedEmployeeId === "ALL") {
        setSelectedEmployeeDetails(null);
        setTargetData({
          target: 0,
          achieved: 0,
          remaining: 0,
          startDate: "",
          endDate: "",
          targetCommission: 0
        });
        await fetchAllCommissionReport(startDate, endDate);
        await fetchAllGrossIncentiveReport(startDate, endDate);
      } else {
        const emp = employees.find((e) => e._id === selectedEmployeeId);
        setSelectedEmployeeDetails(emp || null);
        await fetchCommissionReport(selectedEmployeeId, startDate, endDate);
        await fetchTargetData(selectedEmployeeId, startDate, endDate);
        await fetchGrossIncentiveReport(selectedEmployeeId, startDate, endDate);
      }
    } finally {
      setAgentLoading(false);
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchEmployees();
  }, []);
  const handleCommissionChange = (e) => {
    const { name, value } = e.target;
    setCommissionForm((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };
  const validateForm = () => {
    const newErrors = {};
    if (!commissionForm.agent_id)
      newErrors.agent_id = "Please select an agent";
    if (!commissionForm.amount || isNaN(commissionForm.amount))
      newErrors.amount = "Please enter a valid amount";
    if (commissionForm.pay_type === "online" && !commissionForm.transaction_id)
      newErrors.transaction_id = "Transaction ID is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleCommissionSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    try {
      const payload = { ...commissionForm, admin_type: adminId };
      await api.post("/payment-out/add-commission-payment", payload);
      alert("Commission Paid Successfully!");
      setShowCommissionModal(false);
    } catch (err) {
      alert("Failed to add payment.");
    }
  };
  const processedTableData = employeeCustomerData.map((item, index) => ({
    ...item,
    group_value_digits: item.group_id?.group_value || 0,
    estimated_commission_digits: item.estimated_commission || 0,
    actual_commission_digits: item.commission_value || 0,
    total_paid_digits: item.total_paid_amount || 0,
    required_installment_digits: item.group_id?.monthly_installment || 0,
    group_ticket: item?.ticket || 0,
    net_commission_percentage: item?.group_id?.commission || 0,
    commission_released: item.commission_released ? "Yes" : "No",
    user_name: item.user_id?.full_name || "N/A",
    phone_number: item.user_id?.phone_number || "N/A",
    group_name: item.group_id?.group_name || "N/A",
    enollment_date: item.createdAt?.split("T")?.[0] || "N/A"
  }));
  const columns = [
    { key: "user_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "group_name", header: "Group Name" },
    { key: "group_ticket", header: "Ticket No" },
    { key: "group_value_digits", header: "Group Value" },
    { key: "enollment_date", header: "Enrollment Date" },
    { key: "net_commission_percentage", header: "Net Commission Percentage" },
    { key: "actual_commission_digits", header: "Net Commission" },
    { key: "total_paid_digits", header: "Total Paid" },
    { key: "required_installment_digits", header: "Required Installment" },
    { key: "commission_released", header: "Commission Released" }
  ];
  const grossCommissionColumns = [
    { key: "user_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "group_name", header: "Group Name" },
    { key: "group_value", header: "Group Value" },
    { key: "group_ticket", header: "Ticket No" },
    { key: "enrollment_date", header: "Enrollment Date" },
    { key: "group_monthly_installment", header: "First Installment Amount" },
    { key: "group_commission", header: "Commission Percentage" },
    { key: "total_paid_amount", header: "Total Paid" }
  ];
  const today = /* @__PURE__ */ new Date();
  const currentMonth = `${today.getFullYear()}-${String(
    today.getMonth() + 1
  ).padStart(2, "0")}`;
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-h-screen bg-gray-50", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
    /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
      lineNumber: 1455,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-4xl font-bold text-gray-900", children: "Commission Reports" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
          lineNumber: 1459,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mt-2", children: "Track and manage agent commissions and performance" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
          lineNumber: 1462,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
        lineNumber: 1458,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border border-gray-200 p-8 mb-8", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-800 mb-6", children: "Report Filters" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
          lineNumber: 1469,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-3", children: "Select Agent" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 1475,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                value: selectedEmployeeId || void 0,
                onChange: handleEmployeeChange,
                showSearch: true,
                popupMatchSelectWidth: false,
                placeholder: "Search by name or phone",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                style: { height: "44px" },
                className: "rounded",
                children: employees.map(
                  (emp) => /* @__PURE__ */ jsxDEV(Select.Option, { value: emp._id, children: [
                    emp.name,
                    " - ",
                    emp.phone_number
                  ] }, emp._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1494,
                    columnNumber: 19
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                lineNumber: 1478,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
            lineNumber: 1474,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-3", children: "Date Selection" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 1503,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 p-3 bg-gray-50 rounded-lg h-11", children: /* @__PURE__ */ jsxDEV(
              Radio.Group,
              {
                value: dateSelectionMode,
                onChange: (e) => setDateSelectionMode(e.target.value),
                children: [
                  /* @__PURE__ */ jsxDEV(Radio, { value: "month", className: "text-sm", children: "Month" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1511,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Radio, { value: "date-range", className: "text-sm", children: "Range" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1514,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                lineNumber: 1507,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 1506,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
            lineNumber: 1502,
            columnNumber: 15
          }, this),
          dateSelectionMode === "month" ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-3", children: "Select Month" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 1524,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "month",
                value: tempSelectedMonth || "",
                max: currentMonth,
                onChange: handleTempMonthChange,
                className: "border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-violet-500 h-11"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                lineNumber: 1527,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
            lineNumber: 1523,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-3", children: "From Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                lineNumber: 1538,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: tempFromDate || "",
                  max: tempToDate || currentMonth,
                  onChange: (e) => setTempFromDate(e.target.value),
                  className: "border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-violet-500 h-11"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1541,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 1537,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-3", children: "To Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                lineNumber: 1550,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  value: tempToDate || "",
                  min: tempFromDate || "",
                  max: currentMonth,
                  onChange: (e) => setTempToDate(e.target.value),
                  className: "border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-violet-500 h-11"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1553,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 1549,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
            lineNumber: 1536,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
          lineNumber: 1472,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: applyFilter,
            className: "px-8 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-semibold shadow-sm",
            children: "Continue"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
            lineNumber: 1568,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
          lineNumber: 1567,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
        lineNumber: 1468,
        columnNumber: 11
      }, this),
      agentLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
        lineNumber: 1579,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
        lineNumber: 1578,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4", children: [
          /* @__PURE__ */ jsxDEV(
            Link,
            {
              to: "/target-menu/target",
              className: "flex items-center gap-3 p-4 border border-gray-200 rounded-lg hover:border-violet-500 hover:bg-violet-50 transition-all group",
              children: [
                /* @__PURE__ */ jsxDEV(FiTarget, { className: "text-violet-600 group-hover:scale-110 transition-transform", size: 24 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1590,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700 group-hover:text-violet-600", children: "Set Target" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1591,
                  columnNumber: 21
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 1586,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Link,
            {
              to: "/reports/target-incentive",
              className: "flex items-center gap-3 p-4 border border-gray-200 rounded-lg hover:border-violet-500 hover:bg-violet-50 transition-all group",
              children: [
                /* @__PURE__ */ jsxDEV(FileTextOutlined, { className: "text-violet-600 group-hover:scale-110 transition-transform text-lg" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1599,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700 group-hover:text-violet-600", children: "Incentive Report" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1600,
                  columnNumber: 21
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 1595,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Link,
            {
              to: "/payment-menu/payment-in-out-menu/pay-out-menu/salary-payment",
              className: "flex items-center gap-3 p-4 border border-gray-200 rounded-lg hover:border-violet-500 hover:bg-violet-50 transition-all group",
              children: [
                /* @__PURE__ */ jsxDEV(FaMoneyBill, { className: "text-violet-600 group-hover:scale-110 transition-transform", size: 24 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1608,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700 group-hover:text-violet-600", children: "Salary Payout" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1609,
                  columnNumber: 21
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 1604,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
          lineNumber: 1585,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
          lineNumber: 1584,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(Tabs, { activeKey: activeTab, onChange: setActiveTab, children: [
          /* @__PURE__ */ jsxDEV(TabPane, { tab: "Net Commission Report", children: [
            isFilterApplied && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8", children: [
              selectedEmployeeId !== "ALL" && selectedEmployeeDetails && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800 mb-4", children: "Agent Information" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1626,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 mb-6", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Name" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 1631,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        value: selectedEmployeeDetails.name || "-",
                        readOnly: true,
                        className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 bg-gray-50 text-gray-900 font-medium mt-1"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                        lineNumber: 1634,
                        columnNumber: 33
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1630,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Email" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 1641,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        value: selectedEmployeeDetails.email || "-",
                        readOnly: true,
                        className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 bg-gray-50 text-gray-900 font-medium mt-1"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                        lineNumber: 1644,
                        columnNumber: 33
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1640,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Phone" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 1651,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        value: selectedEmployeeDetails.phone_number || "-",
                        readOnly: true,
                        className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 bg-gray-50 text-gray-900 font-medium mt-1"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                        lineNumber: 1654,
                        columnNumber: 33
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1650,
                    columnNumber: 31
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1629,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 mb-6", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Adhaar" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 1665,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        value: selectedEmployeeDetails.adhaar_no || "-",
                        readOnly: true,
                        className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 bg-gray-50 text-gray-900 font-medium mt-1"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                        lineNumber: 1668,
                        columnNumber: 33
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1664,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "PAN" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 1677,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        value: selectedEmployeeDetails.pan_no || "-",
                        readOnly: true,
                        className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 bg-gray-50 text-gray-900 font-medium mt-1"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                        lineNumber: 1680,
                        columnNumber: 33
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1676,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Pincode" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 1687,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        value: selectedEmployeeDetails.pincode || "-",
                        readOnly: true,
                        className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 bg-gray-50 text-gray-900 font-medium mt-1"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                        lineNumber: 1690,
                        columnNumber: 33
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1686,
                    columnNumber: 31
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1663,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 mb-6", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Address" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 1701,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        value: selectedEmployeeDetails?.address || "-",
                        readOnly: true,
                        className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 bg-gray-50 text-gray-900 font-medium mt-1"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                        lineNumber: 1704,
                        columnNumber: 33
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1700,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Joining Date" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 1711,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        value: selectedEmployeeDetails?.joining_date ? selectedEmployeeDetails.joining_date.split(
                          "T"
                        )[0] : "-",
                        readOnly: true,
                        className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 bg-gray-50 text-gray-900 font-medium mt-1"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                        lineNumber: 1714,
                        columnNumber: 33
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1710,
                    columnNumber: 31
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1699,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("hr", { className: "my-6" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1727,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                lineNumber: 1625,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800 mb-4", children: "Commission Summary" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                lineNumber: 1732,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-lg p-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Net Business" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1737,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      value: commissionTotalDetails?.actual_business || "-",
                      readOnly: true,
                      className: "w-full bg-transparent text-2xl font-bold text-green-700 mt-2 border-0"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 1740,
                      columnNumber: 27
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-green-700 mt-1 block", children: numberToIndianWords(
                    parseAmount(commissionTotalDetails?.actual_business)
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1747,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1736,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-violet-50 to-violet-100 border border-violet-200 rounded-lg p-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Net Commission (1% each)" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1754,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      value: commissionTotalDetails?.total_actual || "-",
                      readOnly: true,
                      className: "w-full bg-transparent text-2xl font-bold text-violet-700 mt-2 border-0"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 1757,
                      columnNumber: 27
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-violet-700 mt-1 block", children: numberToIndianWords(
                    parseAmount(commissionTotalDetails?.total_actual)
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1762,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1753,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-purple-50 to-purple-100 border border-purple-200 rounded-lg p-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Net Customers" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1769,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      value: commissionTotalDetails?.total_customers || "-",
                      readOnly: true,
                      className: "w-full bg-transparent text-2xl font-bold text-purple-700 mt-2 border-0"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 1772,
                      columnNumber: 27
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1768,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                lineNumber: 1735,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 1622,
              columnNumber: 17
            }, this),
            isFilterApplied && selectedEmployeeId && selectedEmployeeId !== "ALL" && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-6", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800", children: "Target Performance" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1790,
                  columnNumber: 27
                }, this),
                targetData.achieved >= targetData.target && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 px-4 py-2 rounded-lg bg-green-100 border border-green-300", children: [
                  /* @__PURE__ */ jsxDEV(
                    GiPartyPopper,
                    {
                      size: 24,
                      className: "text-green-600"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 1795,
                      columnNumber: 31
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-green-700 font-semibold", children: "Target Achieved" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1799,
                    columnNumber: 31
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1794,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                lineNumber: 1789,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4 mb-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-violet-50 to-violet-100 border border-violet-200 rounded-lg p-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Target Set" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1807,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-violet-700 mt-2", children: `${targetData.target?.toLocaleString("en-IN")}` }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1810,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-violet-700 mt-1 block", children: numberToIndianWords(targetData.target || 0) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1813,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1806,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-lg p-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Achieved" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1818,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-green-700 mt-2", children: `${targetData.achieved?.toLocaleString("en-IN")}` }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1821,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-green-700 mt-1 block", children: numberToIndianWords(targetData.achieved || 0) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1824,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1817,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-amber-50 to-amber-100 border border-amber-200 rounded-lg p-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Difference" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1829,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-amber-700 mt-2", children: `${(targetData.difference ?? "0")?.toLocaleString("en-IN")}` }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1832,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-amber-700 mt-1 block", children: numberToIndianWords(
                    Math.abs(targetData.difference || 0)
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1837,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1828,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-emerald-50 to-emerald-100 border border-emerald-200 rounded-lg p-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Total Payable Commission" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1844,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-emerald-700 mt-2", children: `${targetData.targetCommission.toLocaleString(
                    "en-IN",
                    {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    }
                  )}` }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1847,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-emerald-700 mt-1 block", children: numberToIndianWords(
                    targetData.targetCommission || 0
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1856,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1843,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                lineNumber: 1805,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-50 border border-violet-200 rounded-lg p-5", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-violet-800 mb-3", children: "Commission Breakdown" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1864,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsxDEV("li", { className: "text-sm text-gray-700 flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "w-2 h-2 bg-violet-600 rounded-full" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 1869,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: [
                      "Up to target (0.5%):",
                      " ",
                      (Math.min(
                        targetData.achieved,
                        targetData.target
                      ) * 5e-3).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 1870,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-violet-700 ml-2", children: [
                      "(",
                      numberToIndianWords(
                        Math.min(
                          targetData.achieved,
                          targetData.target
                        ) * 5e-3
                      ),
                      ")"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 1882,
                      columnNumber: 31
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1868,
                    columnNumber: 29
                  }, this),
                  targetData.achieved > targetData.target && /* @__PURE__ */ jsxDEV("li", { className: "text-sm text-gray-700 flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "w-2 h-2 bg-green-600 rounded-full" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 1895,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: [
                      "Beyond target (1%):",
                      " ",
                      ((targetData.achieved - targetData.target) * 0.01).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 1896,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-green-700 ml-2", children: [
                      "(",
                      numberToIndianWords(
                        (targetData.achieved - targetData.target) * 0.01
                      ),
                      ")"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 1906,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 1894,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 1867,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                lineNumber: 1863,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 1788,
              columnNumber: 17
            }, this),
            loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 1924,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 1923,
              columnNumber: 17
            }, this) : employeeCustomerData.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden", children: /* @__PURE__ */ jsxDEV(
              DataTable,
              {
                data: processedTableData,
                columns,
                exportedPdfName: `Commission Report`,
                printHeaderKeys: [
                  "Name",
                  "Phone Number",
                  "Month",
                  "Target Set",
                  "Achieved",
                  "Remaining",
                  "Total Payable Commission",
                  "Actual Business",
                  "Actual Commission",
                  "Gross Business",
                  "Gross Commission",
                  "Total Customers",
                  "Total Groups"
                ],
                printHeaderValues: [
                  selectedEmployeeId === "ALL" ? "All Employees" : selectedEmployeeDetails?.name || "-",
                  selectedEmployeeId === "ALL" ? "-" : selectedEmployeeDetails?.phone_number || "-",
                  isFilterApplied ? dateSelectionMode === "month" ? (/* @__PURE__ */ new Date(`${selectedMonth}-01`)).toLocaleString(
                    "default",
                    {
                      month: "long",
                      year: "numeric"
                    }
                  ) : `${new Date(
                    tempFromDate
                  ).toLocaleDateString()} - ${new Date(
                    tempToDate
                  ).toLocaleDateString()}` : "-",
                  `₹${targetData?.target?.toLocaleString("en-IN") || "0"} (${numberToIndianWords(
                    targetData?.target || 0
                  )})`,
                  `₹${targetData?.achieved?.toLocaleString("en-IN") || "0"} (${numberToIndianWords(
                    targetData?.achieved || 0
                  )})`,
                  `₹${targetData?.remaining?.toLocaleString("en-IN") || "0"} (${numberToIndianWords(
                    targetData?.remaining || 0
                  )})`,
                  `₹${targetData?.targetCommission?.toLocaleString(
                    "en-IN",
                    {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    }
                  ) || "0.00"} (${numberToIndianWords(
                    targetData?.targetCommission || 0
                  )})`,
                  `₹${commissionTotalDetails?.actual_business?.toLocaleString(
                    "en-IN"
                  ) || "0"} (${numberToIndianWords(
                    parseAmount(commissionTotalDetails?.actual_business)
                  )})`,
                  `₹${commissionTotalDetails?.total_actual?.toLocaleString(
                    "en-IN"
                  ) || "0"} (${numberToIndianWords(
                    parseAmount(commissionTotalDetails?.total_actual)
                  )})`,
                  `₹${commissionTotalDetails?.expected_business?.toLocaleString(
                    "en-IN"
                  ) || "0"} (${numberToIndianWords(
                    parseAmount(commissionTotalDetails?.expected_business)
                  )})`,
                  `₹${commissionTotalDetails?.total_estimated?.toLocaleString(
                    "en-IN"
                  ) || "0"} (${numberToIndianWords(
                    parseAmount(commissionTotalDetails?.total_estimated)
                  )})`,
                  commissionTotalDetails?.total_customers || "0",
                  commissionTotalDetails?.total_groups || "0"
                ],
                exportedFileName: `CommissionReport-${selectedEmployeeDetails?.name || "all"}-${isFilterApplied ? dateSelectionMode === "month" ? selectedMonth : `${tempFromDate}_to_${tempToDate}` : "unfiltered"}.csv`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                lineNumber: 1928,
                columnNumber: 23
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 1927,
              columnNumber: 17
            }, this) : isFilterApplied && selectedEmployeeDetails?.name && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-lg font-medium", children: "No commission data found for the selected period." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 2025,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 2024,
              columnNumber: 17
            }, this)
          ] }, "commission", true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
            lineNumber: 1619,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(TabPane, { tab: "Gross Commission Report", children: [
            isFilterApplied && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800 mb-4", children: "Gross Incentive Summary" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                lineNumber: 2038,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-lg p-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Gross Group Value" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 2043,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      value: grossCommissionSummary.total_gross_group_value?.toLocaleString(
                        "en-IN"
                      ) || "-",
                      readOnly: true,
                      className: "w-full bg-transparent text-2xl font-bold text-green-700 mt-2 border-0"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 2046,
                      columnNumber: 27
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-green-700 mt-1 block", children: numberToIndianWords(
                    grossCommissionSummary.total_gross_group_value || 0
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 2055,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 2042,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-violet-50 to-violet-100 border border-violet-200 rounded-lg p-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Gross Commission Value" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 2063,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      value: grossCommissionSummary.total_gross_commission_value?.toLocaleString(
                        "en-IN"
                      ) || "-",
                      readOnly: true,
                      className: "w-full bg-transparent text-2xl font-bold text-violet-700 mt-2 border-0"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 2066,
                      columnNumber: 27
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-violet-700 mt-1 block", children: numberToIndianWords(
                    grossCommissionSummary.total_gross_commission_value || 0
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 2075,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 2062,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-purple-50 to-purple-100 border border-purple-200 rounded-lg p-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600 uppercase", children: "Gross Enrollments" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                    lineNumber: 2083,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      value: grossCommissionSummary.total_gross_enrollments || "-",
                      readOnly: true,
                      className: "w-full bg-transparent text-2xl font-bold text-purple-700 mt-2 border-0"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                      lineNumber: 2086,
                      columnNumber: 27
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                  lineNumber: 2082,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                lineNumber: 2041,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 2037,
              columnNumber: 17
            }, this),
            loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 2102,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 2101,
              columnNumber: 17
            }, this) : grossCommissionData.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden", children: /* @__PURE__ */ jsxDEV(
              DataTable,
              {
                data: grossCommissionData,
                columns: grossCommissionColumns,
                exportedPdfName: `Gross Incentive Report`,
                printHeaderKeys: [
                  "Name",
                  "Phone Number",
                  "Period",
                  "Total Group Value",
                  "Total Incentive Value",
                  "Total Enrollments"
                ],
                printHeaderValues: [
                  selectedEmployeeId === "ALL" ? "All Employees" : selectedEmployeeDetails?.name || "-",
                  selectedEmployeeId === "ALL" ? "-" : selectedEmployeeDetails?.phone_number || "-",
                  isFilterApplied ? dateSelectionMode === "month" ? (/* @__PURE__ */ new Date(`${selectedMonth}-01`)).toLocaleString(
                    "default",
                    {
                      month: "long",
                      year: "numeric"
                    }
                  ) : `${new Date(
                    tempFromDate
                  ).toLocaleDateString()} - ${new Date(
                    tempToDate
                  ).toLocaleDateString()}` : "-",
                  `₹${grossCommissionSummary.total_gross_group_value?.toLocaleString(
                    "en-IN"
                  ) || "0"} (${numberToIndianWords(
                    grossCommissionSummary.total_gross_group_value || 0
                  )})`,
                  `₹${grossCommissionSummary.total_gross_incentive_value?.toLocaleString(
                    "en-IN"
                  ) || "0"} (${numberToIndianWords(
                    grossCommissionSummary.total_gross_incentive_value || 0
                  )})`,
                  `${grossCommissionSummary.total_gross_enrollments || "0"}`
                ],
                exportedFileName: `GrossIncentiveReport-${selectedEmployeeDetails?.name || "all"}-${isFilterApplied ? dateSelectionMode === "month" ? selectedMonth : `${tempFromDate}_to_${tempToDate}` : "unfiltered"}.csv`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
                lineNumber: 2106,
                columnNumber: 23
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 2105,
              columnNumber: 17
            }, this) : isFilterApplied && selectedEmployeeDetails?.name && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-lg font-medium", children: "No gross incentive data found for the selected period." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 2168,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
              lineNumber: 2167,
              columnNumber: 17
            }, this)
          ] }, "gross-incentive", true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
            lineNumber: 2034,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
          lineNumber: 1617,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
        lineNumber: 1582,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
      lineNumber: 1456,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
    lineNumber: 1454,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx",
    lineNumber: 1453,
    columnNumber: 5
  }, this);
};
_s(TargetCommission, "irwA6JaOKGTRMEFIkudRUkxjvro=");
_c = TargetCommission;
export default TargetCommission;
var _c;
$RefreshReg$(_c, "TargetCommission");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TargetCommission.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBODZDUSxTQWlGUSxVQWpGUjsyQkE5NkNSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBdThCQSxPQUFPQSxTQUFTQyxXQUFXQyxnQkFBZ0I7QUFDM0MsU0FBU0MsUUFBUUMsT0FBT0MsWUFBWTtBQUNwQyxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsV0FBVztBQUNsQixTQUFTQyxxQkFBcUI7QUFDOUIsU0FBU0Msa0JBQWtCQyxzQkFBc0I7QUFDakQsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQywyQkFBMkI7QUFFcEMsTUFBTSxFQUFFQyxRQUFRLElBQUlkO0FBRXBCLE1BQU1lLG1CQUFtQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzdCLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJckIsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ3NCLG9CQUFvQkMscUJBQXFCLElBQUl2QixTQUFTLElBQUk7QUFDakUsUUFBTSxDQUFDd0IsZUFBZUMsZ0JBQWdCLElBQUl6QixTQUFTLElBQUk7QUFDdkQsUUFBTSxDQUFDMEIsbUJBQW1CQyxvQkFBb0IsSUFBSTNCLFNBQVMsT0FBTztBQUNsRSxRQUFNLENBQUM0QixjQUFjQyxlQUFlLElBQUk3QixTQUFTLEtBQUs7QUFDdEQsUUFBTSxDQUFDOEIseUJBQXlCQywwQkFBMEIsSUFBSS9CLFNBQVMsSUFBSTtBQUMzRSxRQUFNLENBQUNnQyxzQkFBc0JDLHVCQUF1QixJQUFJakMsU0FBUyxFQUFFO0FBQ25FLFFBQU0sQ0FBQ2tDLHdCQUF3QkMseUJBQXlCLElBQUluQyxTQUFTLENBQUMsQ0FBQztBQUN2RSxRQUFNLENBQUNvQyxTQUFTQyxVQUFVLElBQUlyQyxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDc0MscUJBQXFCQyxzQkFBc0IsSUFBSXZDLFNBQVMsS0FBSztBQUNwRSxRQUFNLENBQUN3QyxnQkFBZ0JDLGlCQUFpQixJQUFJekMsU0FBUztBQUFBLElBQ25EMEMsVUFBVTtBQUFBLElBQ1ZDLFdBQVUsb0JBQUlDLEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsSUFDL0NDLFFBQVE7QUFBQSxJQUNSQyxVQUFVO0FBQUEsSUFDVkMsZ0JBQWdCO0FBQUEsSUFDaEJDLE1BQU07QUFBQSxJQUNOQyxTQUFTO0FBQUEsSUFDVEMsWUFBWTtBQUFBLEVBQ2QsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJdEQsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDdUQsU0FBU0MsVUFBVSxJQUFJeEQsU0FBUyxFQUFFO0FBQ3pDLFFBQU0sQ0FBQ3lELFdBQVdDLFlBQVksSUFBSTFELFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUMyRCxZQUFZQyxhQUFhLElBQUk1RCxTQUFTO0FBQUEsSUFDM0M2RCxRQUFRO0FBQUEsSUFDUkMsVUFBVTtBQUFBLElBQ1ZDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsSUFDWEMsU0FBUztBQUFBLElBQ1RDLGtCQUFrQjtBQUFBLEVBQ3BCLENBQUM7QUFDRCxRQUFNLENBQUNDLG1CQUFtQkMsb0JBQW9CLElBQUlwRSxTQUFTLElBQUk7QUFDL0QsUUFBTSxDQUFDcUUsY0FBY0MsZUFBZSxJQUFJdEUsU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQ3VFLFlBQVlDLGFBQWEsSUFBSXhFLFNBQVMsSUFBSTtBQUNqRCxRQUFNLENBQUN5RSxpQkFBaUJDLGtCQUFrQixJQUFJMUUsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQzJFLFdBQVdDLFlBQVksSUFBSTVFLFNBQVMsWUFBWTtBQUN2RCxRQUFNLENBQUM2RSxxQkFBcUJDLHNCQUFzQixJQUFJOUUsU0FBUyxFQUFFO0FBQ2pFLFFBQU0sQ0FBQytFLHdCQUF3QkMseUJBQXlCLElBQUloRixTQUFTO0FBQUEsSUFDbkVpRiw2QkFBNkI7QUFBQSxJQUM3QkMseUJBQXlCO0FBQUEsSUFDekJDLHlCQUF5QjtBQUFBLEVBQzNCLENBQUM7QUFHRCxRQUFNQyxjQUFjQSxDQUFDQyxRQUNuQkMsV0FBV0QsS0FBS0UsU0FBUyxFQUFFQyxRQUFRLGNBQWMsRUFBRSxDQUFDLEtBQUs7QUFFM0R6RixZQUFVLE1BQU07QUFDZCxVQUFNMEYsU0FBUSxvQkFBSTdDLEtBQUs7QUFDdkIsVUFBTThDLGdCQUFlLEdBQUdELE9BQU1FLFlBQVksQ0FBQyxJQUFJQztBQUFBQSxNQUM3Q0gsT0FBTUksU0FBUyxJQUFJO0FBQUEsSUFDckIsRUFBRUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUNsQjFCLHlCQUFxQnNCLGFBQVk7QUFDakMsVUFBTUssT0FBT04sT0FBTUUsWUFBWTtBQUMvQixVQUFNSyxRQUFRUCxPQUFNSSxTQUFTLElBQUk7QUFDakMsVUFBTUksV0FBVyxHQUFHRixJQUFJLElBQUlILE9BQU9JLEtBQUssRUFBRUYsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUMxRCxVQUFNSSxXQUFXLElBQUl0RCxLQUFLbUQsTUFBTUMsT0FBTyxDQUFDLEVBQUVHLFFBQVE7QUFDbEQsVUFBTUMsVUFBVSxHQUFHTCxJQUFJLElBQUlDLEtBQUssSUFBSUosT0FBT00sUUFBUSxFQUFFSixTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQ3JFeEIsb0JBQWdCMkIsUUFBUTtBQUN4QnpCLGtCQUFjNEIsT0FBTztBQUFBLEVBQ3ZCLEdBQUcsRUFBRTtBQUVMckcsWUFBVSxNQUFNO0FBQ2QsVUFBTXNHLE9BQU9DLEtBQUtDLE1BQU1DLGFBQWFDLFFBQVEsTUFBTSxDQUFDO0FBQ3BELFFBQUlKLE1BQU07QUFDUjdDLGlCQUFXNkMsS0FBS0ssR0FBRztBQUNuQmhELG1CQUFhMkMsS0FBS00sUUFBUSxFQUFFO0FBQUEsSUFDOUI7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFFBQU1DLGlCQUFpQixZQUFZO0FBQ2pDLFFBQUk7QUFDRixZQUFNQyxNQUFNLE1BQU16RyxJQUFJMEcsSUFBSSxZQUFZO0FBQ3RDekYsbUJBQWF3RixLQUFLRSxNQUFNQyxLQUFLO0FBQUEsSUFDL0IsU0FBU0MsS0FBSztBQUNaQyxjQUFRQyxNQUFNLDZCQUE2QkYsR0FBRztBQUFBLElBQ2hEO0FBQUEsRUFDRjtBQUVBLFFBQU1HLHdCQUF3QixPQUFPQyxZQUFZckQsV0FBV0MsWUFBWTtBQUN0RSxRQUFJLENBQUNvRCxjQUFjLENBQUNyRCxhQUFhLENBQUNDLFFBQVM7QUFDM0MsVUFBTXFELGtCQUFrQixJQUFJQyxnQkFBZ0I7QUFDNUNsRixlQUFXLElBQUk7QUFDZixRQUFJO0FBQ0YsWUFBTW1GLFNBQVM7QUFBQSxRQUNiQyxZQUFZekQ7QUFBQUEsUUFDWjBELFVBQVV6RDtBQUFBQSxNQUNaO0FBQ0EsWUFBTTRDLE1BQU0sTUFBTXpHLElBQUkwRyxJQUFJLGlCQUFpQk8sVUFBVSxlQUFlO0FBQUEsUUFDbEVHO0FBQUFBLFFBQ0FHLFFBQVFMLGdCQUFnQks7QUFBQUEsTUFDMUIsQ0FBQztBQUNEMUYsOEJBQXdCNEUsSUFBSUUsTUFBTWEsY0FBYztBQUNoRHpGLGdDQUEwQjtBQUFBLFFBQ3hCMEYsaUJBQWlCaEIsSUFBSUUsTUFBTWUsbUJBQW1CQztBQUFBQSxRQUM5Q0MsY0FBY25CLElBQUlFLE1BQU1lLG1CQUFtQkc7QUFBQUEsUUFDM0NDLGlCQUFpQnJCLElBQUlFLE1BQU1lLG1CQUFtQks7QUFBQUEsUUFDOUNDLGNBQWN2QixJQUFJRSxNQUFNZSxtQkFBbUJLO0FBQUFBLFFBQzNDRSxtQkFBbUJ4QixJQUFJRSxNQUFNZSxtQkFBbUJDO0FBQUFBLFFBQ2hETyxpQkFBaUJ6QixJQUFJRSxNQUFNZSxtQkFBbUJHO0FBQUFBLE1BQ2hELENBQUM7QUFBQSxJQUNILFNBQVNoQixLQUFLO0FBQ1osVUFBSUEsSUFBSU4sU0FBUyxtQkFBbUI7QUFDbENPLGdCQUFRQyxNQUFNLG1DQUFtQ0YsR0FBRztBQUNwRGhGLGdDQUF3QixFQUFFO0FBQzFCRSxrQ0FBMEIsQ0FBQyxDQUFDO0FBQUEsTUFDOUI7QUFBQSxJQUNGLFVBQUM7QUFDQyxVQUFJLENBQUNtRixnQkFBZ0JLLE9BQU9ZLFNBQVM7QUFDbkNsRyxtQkFBVyxLQUFLO0FBQUEsTUFDbEI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU1tRyw0QkFBNEIsT0FBT25CLFlBQVlyRCxXQUFXQyxZQUFZO0FBQzFFLFFBQUksQ0FBQ29ELGNBQWMsQ0FBQ3JELGFBQWEsQ0FBQ0MsUUFBUztBQUMzQzVCLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDRixVQUFJbUYsU0FBUztBQUFBLFFBQ1hDLFlBQVl6RDtBQUFBQSxRQUNaMEQsVUFBVXpEO0FBQUFBLE1BQ1o7QUFDQSxZQUFNNEMsTUFBTSxNQUFNekcsSUFBSTBHO0FBQUFBLFFBQ3BCLGlCQUFpQk8sVUFBVTtBQUFBLFFBQzNCO0FBQUEsVUFDRUc7QUFBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxZQUFNSSxpQkFBaUJmLElBQUlFLE1BQU0wQixxQkFBcUJDLElBQUksQ0FBQ0MsZ0JBQWdCO0FBQUEsUUFDekVDLFdBQVdELFlBQVlFLFNBQVNDLGFBQWE7QUFBQSxRQUM3Q0MsY0FBY0osWUFBWUUsU0FBU0UsZ0JBQWdCO0FBQUEsUUFDbkRDLFlBQVlMLFlBQVlNLFVBQVVELGNBQWM7QUFBQSxRQUNoREUsYUFBYVAsWUFBWU0sVUFBVUMsZUFBZTtBQUFBLFFBQ2xEQyxrQkFBa0JSLFlBQVlNLFVBQVVHLGNBQWM7QUFBQSxRQUN0REMsY0FBY1YsWUFBWVcsV0FBVztBQUFBLFFBQ3JDQyxpQkFBaUJaLFlBQVlhLFdBQVcxRyxNQUFNLEdBQUcsSUFBSSxDQUFDO0FBQUEsUUFDdEQyRyxtQkFBbUJkLFlBQVljLHFCQUFxQjtBQUFBLFFBQ3BEQywyQkFDRWYsWUFBWU0sVUFBVVUsdUJBQXVCO0FBQUEsTUFDakQsRUFBRTtBQUNGN0UsNkJBQXVCOEMsa0JBQWtCLEVBQUU7QUFDM0M1QyxnQ0FBMEI2QixJQUFJRSxLQUFLaEMsMEJBQTBCO0FBQUEsUUFDM0Q2RSw4QkFBOEI7QUFBQSxRQUM5QjFFLHlCQUF5QjtBQUFBLFFBQ3pCQyx5QkFBeUI7QUFBQSxNQUMzQixDQUFDO0FBQUEsSUFDSCxTQUFTOEIsS0FBSztBQUNaQyxjQUFRQyxNQUFNLDBDQUEwQ0YsR0FBRztBQUMzRG5DLDZCQUF1QixFQUFFO0FBQ3pCRSxnQ0FBMEI7QUFBQSxRQUN4QjRFLDhCQUE4QjtBQUFBLFFBQzlCMUUseUJBQXlCO0FBQUEsUUFDekJDLHlCQUF5QjtBQUFBLE1BQzNCLENBQUM7QUFBQSxJQUNILFVBQUM7QUFDQzlDLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNd0gsNEJBQTRCQSxDQUFDQyxrQkFBa0JDLGlCQUFpQjtBQUNwRSxVQUFNQyxjQUNKLE9BQU9GLHFCQUFxQixXQUN4QkcsT0FBT0gsaUJBQWlCdEUsUUFBUSxjQUFjLEVBQUUsQ0FBQyxJQUNqRHNFO0FBQ04sVUFBTUksWUFDSixPQUFPSCxpQkFBaUIsV0FDcEJFLE9BQU9GLGFBQWF2RSxRQUFRLGNBQWMsRUFBRSxDQUFDLElBQzdDdUU7QUFDTixRQUFJQyxlQUFlRSxXQUFXO0FBQzVCLGFBQU9GLGNBQWM7QUFBQSxJQUN2QixPQUFPO0FBQ0wsWUFBTUcsYUFBYUQsWUFBWTtBQUMvQixZQUFNRSxnQkFBZ0JKLGNBQWNFLGFBQWE7QUFDakQsYUFBT0MsYUFBYUM7QUFBQUEsSUFDdEI7QUFBQSxFQUNGO0FBRUEsUUFBTUMsa0JBQWtCLE9BQU9oRCxZQUFZckQsV0FBV0MsWUFBWTtBQUNoRSxRQUFJLENBQUNvRCxjQUFjLENBQUNyRCxhQUFhLENBQUNDLFFBQVM7QUFDM0MsUUFBSTtBQUNGLFlBQU1xRCxrQkFBa0IsSUFBSUMsZ0JBQWdCO0FBQzVDLFlBQU0rQyxZQUFZLE1BQU1sSyxJQUFJMEcsSUFBSSxrQkFBa0JPLFVBQVUsSUFBSTtBQUFBLFFBQzlERyxRQUFRLEVBQUVDLFlBQVl6RCxXQUFXMEQsVUFBVXpELFFBQVE7QUFBQSxRQUNuRDBELFFBQVFMLGdCQUFnQks7QUFBQUEsTUFDMUIsQ0FBQztBQUNELFlBQU00QyxpQkFBaUJELFVBQVV2RCxNQUFNeUQsZ0JBQWdCO0FBQ3ZELFlBQU0sRUFBRXpELE1BQU0wRCxLQUFLLElBQUksTUFBTXJLLElBQUkwRztBQUFBQSxRQUMvQixpQkFBaUJPLFVBQVU7QUFBQSxRQUMzQjtBQUFBLFVBQ0VHLFFBQVEsRUFBRUMsWUFBWXpELFdBQVcwRCxVQUFVekQsUUFBUTtBQUFBLFVBQ25EMEQsUUFBUUwsZ0JBQWdCSztBQUFBQSxRQUMxQjtBQUFBLE1BQ0Y7QUFDQSxVQUFJN0QsV0FBVzJHLE1BQU0zQyxtQkFBbUJDLHFCQUFxQjtBQUM3RCxVQUFJLE9BQU9qRSxhQUFhLFVBQVU7QUFDaENBLG1CQUFXbUcsT0FBT25HLFNBQVMwQixRQUFRLGNBQWMsRUFBRSxDQUFDO0FBQUEsTUFDdEQ7QUFDQSxZQUFNekIsWUFBWTJHLEtBQUtDLElBQUlKLGlCQUFpQnpHLFVBQVUsQ0FBQztBQUN2RCxZQUFNOEcsYUFBYUwsaUJBQWlCekc7QUFDcEMsWUFBTUksbUJBQW1CMkY7QUFBQUEsUUFDdkIvRjtBQUFBQSxRQUNBeUc7QUFBQUEsTUFDRjtBQUNBM0csb0JBQWM7QUFBQSxRQUNaQyxRQUFRNkcsS0FBS0csTUFBTU4sY0FBYztBQUFBLFFBQ2pDekc7QUFBQUEsUUFDQUM7QUFBQUEsUUFDQTZHO0FBQUFBLFFBQ0E1RztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxNQUNGLENBQUM7QUFBQSxJQUNILFNBQVMrQyxLQUFLO0FBQ1osVUFBSUEsSUFBSU4sU0FBUyxjQUFjO0FBQzdCTyxnQkFBUUMsTUFBTSwrQkFBK0JGLEdBQUc7QUFDaERyRCxzQkFBYztBQUFBLFVBQ1pDLFFBQVE7QUFBQSxVQUNSQyxVQUFVO0FBQUEsVUFDVkMsV0FBVztBQUFBLFVBQ1g2RyxZQUFZO0FBQUEsVUFDWjVHLFdBQVc7QUFBQSxVQUNYQyxTQUFTO0FBQUEsVUFDVEMsa0JBQWtCO0FBQUEsUUFDcEIsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU00RywyQkFBMkIsT0FBTzlHLFdBQVdDLFlBQVk7QUFDN0QsUUFBSSxDQUFDRCxhQUFhLENBQUNDLFFBQVM7QUFDNUIsVUFBTXFELGtCQUFrQixJQUFJQyxnQkFBZ0I7QUFDNUNsRixlQUFXLElBQUk7QUFDZixRQUFJO0FBQ0YsWUFBTW1GLFNBQVM7QUFBQSxRQUNiQyxZQUFZekQ7QUFBQUEsUUFDWjBELFVBQVV6RDtBQUFBQSxNQUNaO0FBQ0EsWUFBTTRDLE1BQU0sTUFBTXpHLElBQUkwRyxJQUFJLHNCQUFzQjtBQUFBLFFBQzlDVTtBQUFBQSxRQUNBRyxRQUFRTCxnQkFBZ0JLO0FBQUFBLE1BQzFCLENBQUM7QUFDRDFGLDhCQUF3QjRFLElBQUlFLE1BQU1hLGNBQWM7QUFDaER6RixnQ0FBMEI7QUFBQSxRQUN4QjBGLGlCQUFpQmhCLElBQUlFLE1BQU1lLG1CQUFtQkM7QUFBQUEsUUFDOUNDLGNBQWNuQixJQUFJRSxNQUFNZSxtQkFBbUJHO0FBQUFBLFFBQzNDQyxpQkFBaUJyQixJQUFJRSxNQUFNZSxtQkFBbUJLO0FBQUFBLFFBQzlDQyxjQUFjdkIsSUFBSUUsTUFBTWUsbUJBQW1CSztBQUFBQSxRQUMzQ0UsbUJBQW1CeEIsSUFBSUUsTUFBTWUsbUJBQW1CQztBQUFBQSxRQUNoRE8saUJBQWlCekIsSUFBSUUsTUFBTWUsbUJBQW1CRztBQUFBQSxNQUNoRCxDQUFDO0FBQUEsSUFDSCxTQUFTaEIsS0FBSztBQUNaLFVBQUlBLElBQUlOLFNBQVMsY0FBYztBQUM3Qk8sZ0JBQVFDLE1BQU0seUNBQXlDRixHQUFHO0FBQzFEaEYsZ0NBQXdCLEVBQUU7QUFDMUJFLGtDQUEwQixDQUFDLENBQUM7QUFBQSxNQUM5QjtBQUFBLElBQ0YsVUFBQztBQUNDLFVBQUksQ0FBQ21GLGdCQUFnQkssT0FBT1ksU0FBUztBQUNuQ2xHLG1CQUFXLEtBQUs7QUFBQSxNQUNsQjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTTBJLCtCQUErQixPQUFPL0csV0FBV0MsWUFBWTtBQUNqRSxRQUFJLENBQUNELGFBQWEsQ0FBQ0MsUUFBUztBQUM1QjVCLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDRixVQUFJbUYsU0FBUztBQUFBLFFBQ1hDLFlBQVl6RDtBQUFBQSxRQUNaMEQsVUFBVXpEO0FBQUFBLE1BQ1o7QUFDQSxZQUFNNEMsTUFBTSxNQUFNekcsSUFBSTBHLElBQUksMkJBQTJCO0FBQUEsUUFDbkRVO0FBQUFBLE1BQ0YsQ0FBQztBQUNEMUMsNkJBQXVCK0IsSUFBSUUsS0FBS2lFLHNCQUFzQixFQUFFO0FBQ3hEaEcsZ0NBQTBCNkIsSUFBSUUsS0FBS2hDLDBCQUEwQjtBQUFBLFFBQzNERSw2QkFBNkI7QUFBQSxRQUM3QkMseUJBQXlCO0FBQUEsUUFDekJDLHlCQUF5QjtBQUFBLE1BQzNCLENBQUM7QUFBQSxJQUNILFNBQVM4QixLQUFLO0FBQ1pDLGNBQVFDLE1BQU0sOENBQThDRixHQUFHO0FBQy9EbkMsNkJBQXVCLEVBQUU7QUFDekJFLGdDQUEwQjtBQUFBLFFBQ3hCQyw2QkFBNkI7QUFBQSxRQUM3QkMseUJBQXlCO0FBQUEsUUFDekJDLHlCQUF5QjtBQUFBLE1BQzNCLENBQUM7QUFBQSxJQUNILFVBQUM7QUFDQzlDLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNEksdUJBQXVCQSxDQUFDQyxVQUFVO0FBQ3RDM0osMEJBQXNCMkosS0FBSztBQUMzQm5KLCtCQUEyQixJQUFJO0FBQy9CRSw0QkFBd0IsRUFBRTtBQUMxQkUsOEJBQTBCLENBQUMsQ0FBQztBQUM1QnlCLGtCQUFjO0FBQUEsTUFDWkMsUUFBUTtBQUFBLE1BQ1JDLFVBQVU7QUFBQSxNQUNWQyxXQUFXO0FBQUEsTUFDWEMsV0FBVztBQUFBLE1BQ1hDLFNBQVM7QUFBQSxNQUNUQyxrQkFBa0I7QUFBQSxJQUNwQixDQUFDO0FBQ0RZLDJCQUF1QixFQUFFO0FBQ3pCRSw4QkFBMEI7QUFBQSxNQUN4QkMsNkJBQTZCO0FBQUEsTUFDN0JDLHlCQUF5QjtBQUFBLE1BQ3pCQyx5QkFBeUI7QUFBQSxJQUMzQixDQUFDO0FBQ0RULHVCQUFtQixLQUFLO0FBQUEsRUFDMUI7QUFFQSxRQUFNeUcsd0JBQXdCQSxDQUFDQyxNQUFNO0FBQ25DLFVBQU01SixpQkFBZ0I0SixFQUFFdkgsT0FBT3FIO0FBQy9COUcseUJBQXFCNUMsY0FBYTtBQUNsQyxRQUFJQSxnQkFBZTtBQUNqQixZQUFNLENBQUN1RSxNQUFNQyxLQUFLLElBQUl4RSxlQUFjc0IsTUFBTSxHQUFHO0FBQzdDLFlBQU1tRCxXQUFXLEdBQUdGLElBQUksSUFBSUMsS0FBSztBQUNqQyxZQUFNRSxXQUFXLElBQUl0RCxLQUFLbUQsTUFBTUMsT0FBTyxDQUFDLEVBQUVHLFFBQVE7QUFDbEQsWUFBTUMsVUFBVSxHQUFHTCxJQUFJLElBQUlDLEtBQUssSUFBSUosT0FBT1EsT0FBTyxFQUFFTixTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQ3BFeEIsc0JBQWdCMkIsUUFBUTtBQUN4QnpCLG9CQUFjNEIsT0FBTztBQUFBLElBQ3ZCO0FBQUEsRUFDRjtBQUVBLFFBQU1pRixjQUFjLFlBQVk7QUFDOUIsUUFBSSxDQUFDL0osb0JBQW9CO0FBQ3ZCZ0ssWUFBTSx5QkFBeUI7QUFDL0I7QUFBQSxJQUNGO0FBQ0EsUUFBSTVKLHNCQUFzQixXQUFXLENBQUN5QyxtQkFBbUI7QUFDdkRtSCxZQUFNLHdCQUF3QjtBQUM5QjtBQUFBLElBQ0Y7QUFDQSxRQUFJNUosc0JBQXNCLGlCQUFpQixDQUFDMkMsZ0JBQWdCLENBQUNFLGFBQWE7QUFDeEUrRyxZQUFNLHVDQUF1QztBQUM3QztBQUFBLElBQ0Y7QUFDQSxRQUFJdEgsV0FBV0M7QUFDZixRQUFJdkMsc0JBQXNCLFNBQVM7QUFDakNELHVCQUFpQjBDLGlCQUFpQjtBQUNsQyxZQUFNLENBQUM0QixNQUFNQyxLQUFLLElBQUk3QixrQkFBa0JyQixNQUFNLEdBQUc7QUFDakRrQixrQkFBWSxHQUFHK0IsSUFBSSxJQUFJQyxLQUFLO0FBQzVCLFlBQU1JLFVBQVUsSUFBSXhELEtBQUttRCxNQUFNQyxPQUFPLENBQUMsRUFBRUcsUUFBUTtBQUNqRGxDLGdCQUFVLEdBQUc4QixJQUFJLElBQUlDLEtBQUssSUFBSUosT0FBT1EsT0FBTyxFQUFFTixTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQUEsSUFDaEUsT0FBTztBQUNMOUIsa0JBQVlLO0FBQ1pKLGdCQUFVTTtBQUFBQSxJQUNaO0FBQ0ExQyxvQkFBZ0IsSUFBSTtBQUNwQlEsZUFBVyxJQUFJO0FBQ2ZxQyx1QkFBbUIsSUFBSTtBQUN2QixRQUFJO0FBQ0YsVUFBSXBELHVCQUF1QixPQUFPO0FBQ2hDUyxtQ0FBMkIsSUFBSTtBQUMvQjZCLHNCQUFjO0FBQUEsVUFDWkMsUUFBUTtBQUFBLFVBQ1JDLFVBQVU7QUFBQSxVQUNWQyxXQUFXO0FBQUEsVUFDWEMsV0FBVztBQUFBLFVBQ1hDLFNBQVM7QUFBQSxVQUNUQyxrQkFBa0I7QUFBQSxRQUNwQixDQUFDO0FBQ0QsY0FBTTRHLHlCQUF5QjlHLFdBQVdDLE9BQU87QUFDakQsY0FBTThHLDZCQUE2Qi9HLFdBQVdDLE9BQU87QUFBQSxNQUN2RCxPQUFPO0FBQ0wsY0FBTXNILE1BQU1uSyxVQUFVb0ssS0FBSyxDQUFDSixNQUFNQSxFQUFFMUUsUUFBUXBGLGtCQUFrQjtBQUM5RFMsbUNBQTJCd0osT0FBTyxJQUFJO0FBQ3RDLGNBQU1uRSxzQkFBc0I5RixvQkFBb0IwQyxXQUFXQyxPQUFPO0FBQ2xFLGNBQU1vRyxnQkFBZ0IvSSxvQkFBb0IwQyxXQUFXQyxPQUFPO0FBQzVELGNBQU11RSwwQkFBMEJsSCxvQkFBb0IwQyxXQUFXQyxPQUFPO0FBQUEsTUFDeEU7QUFBQSxJQUNGLFVBQUM7QUFDQ3BDLHNCQUFnQixLQUFLO0FBQ3JCUSxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUF0QyxZQUFVLE1BQU07QUFDZDZHLG1CQUFlO0FBQUEsRUFDakIsR0FBRyxFQUFFO0FBRUwsUUFBTTZFLHlCQUF5QkEsQ0FBQ0wsTUFBTTtBQUNwQyxVQUFNLEVBQUV6RSxNQUFNdUUsTUFBTSxJQUFJRSxFQUFFdkg7QUFDMUJwQixzQkFBa0IsQ0FBQ2lKLFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUMvRSxJQUFJLEdBQUd1RSxNQUFNLEVBQUU7QUFDeEQ1SCxjQUFVLENBQUNvSSxVQUFVLEVBQUUsR0FBR0EsTUFBTSxDQUFDL0UsSUFBSSxHQUFHLEdBQUcsRUFBRTtBQUFBLEVBQy9DO0FBRUEsUUFBTWdGLGVBQWVBLE1BQU07QUFDekIsVUFBTUMsWUFBWSxDQUFDO0FBQ25CLFFBQUksQ0FBQ3BKLGVBQWVFO0FBQ2xCa0osZ0JBQVVsSixXQUFXO0FBQ3ZCLFFBQUksQ0FBQ0YsZUFBZU8sVUFBVThJLE1BQU1ySixlQUFlTyxNQUFNO0FBQ3ZENkksZ0JBQVU3SSxTQUFTO0FBQ3JCLFFBQ0VQLGVBQWVRLGFBQWEsWUFDNUIsQ0FBQ1IsZUFBZVM7QUFFaEIySSxnQkFBVTNJLGlCQUFpQjtBQUM3QkssY0FBVXNJLFNBQVM7QUFDbkIsV0FBT0UsT0FBT0MsS0FBS0gsU0FBUyxFQUFFSSxXQUFXO0FBQUEsRUFDM0M7QUFFQSxRQUFNQyx5QkFBeUIsT0FBT2IsTUFBTTtBQUMxQ0EsTUFBRWMsZUFBZTtBQUNqQixRQUFJLENBQUNQLGFBQWEsRUFBRztBQUNyQixRQUFJO0FBQ0YsWUFBTVEsVUFBVSxFQUFFLEdBQUczSixnQkFBZ0JZLFlBQVlHLFFBQVE7QUFDekQsWUFBTW5ELElBQUlnTSxLQUFLLHVDQUF1Q0QsT0FBTztBQUM3RGIsWUFBTSwrQkFBK0I7QUFDckMvSSw2QkFBdUIsS0FBSztBQUFBLElBQzlCLFNBQVMwRSxLQUFLO0FBQ1pxRSxZQUFNLHdCQUF3QjtBQUFBLElBQ2hDO0FBQUEsRUFDRjtBQUVBLFFBQU1lLHFCQUFxQnJLLHFCQUFxQjBHLElBQUksQ0FBQzRELE1BQU1DLFdBQVc7QUFBQSxJQUNwRSxHQUFHRDtBQUFBQSxJQUNIRSxvQkFBb0JGLEtBQUtyRCxVQUFVQyxlQUFlO0FBQUEsSUFDbER1RCw2QkFBNkJILEtBQUtJLHdCQUF3QjtBQUFBLElBQzFEQywwQkFBMEJMLEtBQUtNLG9CQUFvQjtBQUFBLElBQ25EQyxtQkFBbUJQLEtBQUs3QyxxQkFBcUI7QUFBQSxJQUM3Q3FELDZCQUE2QlIsS0FBS3JELFVBQVVVLHVCQUF1QjtBQUFBLElBQ25FTixjQUFjaUQsTUFBTVMsVUFBVTtBQUFBLElBQzlCQywyQkFBMkJWLE1BQU1yRCxVQUFVRyxjQUFjO0FBQUEsSUFDekQ2RCxxQkFBcUJYLEtBQUtXLHNCQUFzQixRQUFRO0FBQUEsSUFDeERyRSxXQUFXMEQsS0FBS3pELFNBQVNDLGFBQWE7QUFBQSxJQUN0Q0MsY0FBY3VELEtBQUt6RCxTQUFTRSxnQkFBZ0I7QUFBQSxJQUM1Q0MsWUFBWXNELEtBQUtyRCxVQUFVRCxjQUFjO0FBQUEsSUFDekNrRSxnQkFBZ0JaLEtBQUs5QyxXQUFXMUcsTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLO0FBQUEsRUFDckQsRUFBRTtBQUVGLFFBQU1xSyxVQUFVO0FBQUEsSUFDZCxFQUFFQyxLQUFLLGFBQWFDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDNUMsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVELEtBQUssY0FBY0MsUUFBUSxhQUFhO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsWUFBWTtBQUFBLElBQzNDLEVBQUVELEtBQUssc0JBQXNCQyxRQUFRLGNBQWM7QUFBQSxJQUNuRCxFQUFFRCxLQUFLLGtCQUFrQkMsUUFBUSxrQkFBa0I7QUFBQSxJQUNuRCxFQUFFRCxLQUFLLDZCQUE2QkMsUUFBUSw0QkFBNEI7QUFBQSxJQUN4RSxFQUFFRCxLQUFLLDRCQUE0QkMsUUFBUSxpQkFBaUI7QUFBQSxJQUM1RCxFQUFFRCxLQUFLLHFCQUFxQkMsUUFBUSxhQUFhO0FBQUEsSUFDakQsRUFBRUQsS0FBSywrQkFBK0JDLFFBQVEsdUJBQXVCO0FBQUEsSUFDckUsRUFBRUQsS0FBSyx1QkFBdUJDLFFBQVEsc0JBQXNCO0FBQUEsRUFBQztBQUcvRCxRQUFNQyx5QkFBeUI7QUFBQSxJQUM3QixFQUFFRixLQUFLLGFBQWFDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDNUMsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVELEtBQUssY0FBY0MsUUFBUSxhQUFhO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxlQUFlQyxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxZQUFZO0FBQUEsSUFDM0MsRUFBRUQsS0FBSyxtQkFBbUJDLFFBQVEsa0JBQWtCO0FBQUEsSUFDcEQsRUFBRUQsS0FBSyw2QkFBNkJDLFFBQVEsMkJBQTJCO0FBQUEsSUFDdkUsRUFBRUQsS0FBSyxvQkFBb0JDLFFBQVEsd0JBQXdCO0FBQUEsSUFDM0QsRUFBRUQsS0FBSyxxQkFBcUJDLFFBQVEsYUFBYTtBQUFBLEVBQUM7QUFHcEQsUUFBTTVILFFBQVEsb0JBQUk3QyxLQUFLO0FBQ3ZCLFFBQU04QyxlQUFlLEdBQUdELE1BQU1FLFlBQVksQ0FBQyxJQUFJQztBQUFBQSxJQUM3Q0gsTUFBTUksU0FBUyxJQUFJO0FBQUEsRUFDckIsRUFBRUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUVsQixTQUNFLHVCQUFDLFNBQUksV0FBVSxrQ0FDYixpQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDJCQUFDLFVBQU8sWUFBWSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlCO0FBQUEsSUFDekIsdUJBQUMsU0FBSSxXQUFVLGlCQUViO0FBQUEsNkJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsb0NBQW1DLGtDQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSxzQkFBcUIsa0VBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsaUVBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsNENBQTJDLDhCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSw2REFFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxrREFBaUQsNEJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBT3hFLHNCQUFzQmlNO0FBQUFBLGdCQUM3QixVQUFVdEM7QUFBQUEsZ0JBQ1Y7QUFBQSxnQkFDQSx1QkFBdUI7QUFBQSxnQkFDdkIsYUFBWTtBQUFBLGdCQUNaLGNBQWMsQ0FBQ3VDLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKbkksU0FBUyxFQUNUb0ksWUFBWSxFQUNaQyxTQUFTSixNQUFNRyxZQUFZLENBQUM7QUFBQSxnQkFFakMsT0FBTyxFQUFFRSxRQUFRLE9BQU87QUFBQSxnQkFDeEIsV0FBVTtBQUFBLGdCQUVUek0sb0JBQVVzSDtBQUFBQSxrQkFBSSxDQUFDNkMsUUFDZCx1QkFBQyxPQUFPLFFBQVAsRUFBNEIsT0FBT0EsSUFBSTdFLEtBQ3JDNkU7QUFBQUEsd0JBQUk1RTtBQUFBQSxvQkFBSztBQUFBLG9CQUFJNEUsSUFBSXhDO0FBQUFBLHVCQURBd0MsSUFBSTdFLEtBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDRDtBQUFBO0FBQUEsY0FuQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBb0JBO0FBQUEsZUF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5QkE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxrREFBaUQsOEJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwwREFDYjtBQUFBLGNBQUMsTUFBTTtBQUFBLGNBQU47QUFBQSxnQkFDQyxPQUFPaEY7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDMEosTUFBTXpKLHFCQUFxQnlKLEVBQUV2SCxPQUFPcUgsS0FBSztBQUFBLGdCQUVwRDtBQUFBLHlDQUFDLFNBQU0sT0FBTSxTQUFRLFdBQVUsV0FBVSxxQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFNBQU0sT0FBTSxjQUFhLFdBQVUsV0FBVSxxQkFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBO0FBQUE7QUFBQSxjQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLGVBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsVUFHQ3hKLHNCQUFzQixVQUNyQix1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsa0RBQWlELDRCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPeUMscUJBQXFCO0FBQUEsZ0JBQzVCLEtBQUt1QjtBQUFBQSxnQkFDTCxVQUFVeUY7QUFBQUEsZ0JBQ1YsV0FBVTtBQUFBO0FBQUEsY0FMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLb0g7QUFBQSxlQVR0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBLElBRUEsbUNBQ0U7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsa0RBQWlELHlCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBTzlHLGdCQUFnQjtBQUFBLGtCQUN2QixLQUFLRSxjQUFjbUI7QUFBQUEsa0JBQ25CLFVBQVUsQ0FBQzBGLE1BQU05RyxnQkFBZ0I4RyxFQUFFdkgsT0FBT3FILEtBQUs7QUFBQSxrQkFDL0MsV0FBVTtBQUFBO0FBQUEsZ0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS29IO0FBQUEsaUJBVHRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxrREFBaUQsdUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFPM0csY0FBYztBQUFBLGtCQUNyQixLQUFLRixnQkFBZ0I7QUFBQSxrQkFDckIsS0FBS3FCO0FBQUFBLGtCQUNMLFVBQVUsQ0FBQzBGLE1BQU01RyxjQUFjNEcsRUFBRXZILE9BQU9xSCxLQUFLO0FBQUEsa0JBQzdDLFdBQVU7QUFBQTtBQUFBLGdCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1vSDtBQUFBLGlCQVZ0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUEsZUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwQkE7QUFBQSxhQTFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNEZBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVNHO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBQTZHO0FBQUE7QUFBQSxVQUZ6SDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBMUdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyR0E7QUFBQSxNQUVDekosZUFDQyx1QkFBQyxTQUFJLFdBQVUsNkJBQ2IsaUNBQUMsa0JBQWUsV0FBVyxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdDLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxJQUVBLG1DQUVFO0FBQUEsK0JBQUMsU0FBSSxXQUFVLFFBQ2IsaUNBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLElBQUc7QUFBQSxjQUNILFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsWUFBUyxXQUFVLDhEQUE2RCxNQUFNLE1BQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBGO0FBQUEsZ0JBQzFGLHVCQUFDLFVBQUssV0FBVSx5REFBd0QsMEJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQTtBQUFBO0FBQUEsWUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLElBQUc7QUFBQSxjQUNILFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsb0JBQWlCLFdBQVUsd0VBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdHO0FBQUEsZ0JBQ2hHLHVCQUFDLFVBQUssV0FBVSx5REFBd0QsZ0NBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQTtBQUFBO0FBQUEsWUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLElBQUc7QUFBQSxjQUNILFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsZUFBWSxXQUFVLDhEQUE2RCxNQUFNLE1BQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZGO0FBQUEsZ0JBQzdGLHVCQUFDLFVBQUssV0FBVSx5REFBd0QsNkJBQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQTtBQUFBO0FBQUEsWUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLGFBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0QkEsS0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThCQTtBQUFBLFFBR0EsdUJBQUMsUUFBSyxXQUFXK0MsV0FBVyxVQUFVQyxjQUVwQztBQUFBLGlDQUFDLFdBQVEsS0FBSSx5QkFFVkg7QUFBQUEsK0JBQ0MsdUJBQUMsU0FBSSxXQUFVLGlFQUNabkQ7QUFBQUEscUNBQXVCLFNBQ3RCUSwyQkFDRSxtQ0FDRTtBQUFBLHVDQUFDLFFBQUcsV0FBVSw0Q0FBMkMsaUNBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSx5Q0FBQyxTQUNDO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGlEQUFnRCxvQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE9BQU9BLHdCQUF3QjZFLFFBQVE7QUFBQSx3QkFDdkM7QUFBQSx3QkFDQSxXQUFVO0FBQUE7QUFBQSxzQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBRzRHO0FBQUEsdUJBUDlHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBU0E7QUFBQSxrQkFDQSx1QkFBQyxTQUNDO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGlEQUFnRCxxQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE9BQU83RSx3QkFBd0JnTSxTQUFTO0FBQUEsd0JBQ3hDO0FBQUEsd0JBQ0EsV0FBVTtBQUFBO0FBQUEsc0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUc0RztBQUFBLHVCQVA5RztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVNBO0FBQUEsa0JBQ0EsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSxpREFBZ0QscUJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUNFaE0sd0JBQXdCaUgsZ0JBQWdCO0FBQUEsd0JBRTFDO0FBQUEsd0JBQ0EsV0FBVTtBQUFBO0FBQUEsc0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUs0RztBQUFBLHVCQVQ5RztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVdBO0FBQUEscUJBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaUNBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEseUNBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSxpREFBZ0Qsc0JBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUNFakgsd0JBQXdCaU0sYUFBYTtBQUFBLHdCQUV2QztBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLNEc7QUFBQSx1QkFUOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFXQTtBQUFBLGtCQUNBLHVCQUFDLFNBQ0M7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsaURBQWdELG1CQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsT0FBT2pNLHdCQUF3QmtNLFVBQVU7QUFBQSx3QkFDekM7QUFBQSx3QkFDQSxXQUFVO0FBQUE7QUFBQSxzQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBRzRHO0FBQUEsdUJBUDlHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBU0E7QUFBQSxrQkFDQSx1QkFBQyxTQUNDO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGlEQUFnRCx1QkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE9BQ0VsTSx3QkFBd0JtTSxXQUFXO0FBQUEsd0JBRXJDO0FBQUEsd0JBQ0EsV0FBVTtBQUFBO0FBQUEsc0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUs0RztBQUFBLHVCQVQ5RztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVdBO0FBQUEscUJBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBbUNBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEseUNBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSxpREFBZ0QsdUJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUFPbk0seUJBQXlCb00sV0FBVztBQUFBLHdCQUMzQztBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFHNEc7QUFBQSx1QkFQOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFTQTtBQUFBLGtCQUNBLHVCQUFDLFNBQ0M7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsaURBQWdELDRCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsT0FDRXBNLHlCQUF5QnFNLGVBQ3JCck0sd0JBQXdCcU0sYUFBYXJMO0FBQUFBLDBCQUNuQztBQUFBLHdCQUNGLEVBQUUsQ0FBQyxJQUNIO0FBQUEsd0JBRU47QUFBQSx3QkFDQSxXQUFVO0FBQUE7QUFBQSxzQkFUWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBUzRHO0FBQUEsdUJBYjlHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBZUE7QUFBQSxxQkExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkEyQkE7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLFdBQVUsVUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvQjtBQUFBLG1CQXRHdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF1R0E7QUFBQSxjQUlKLHVCQUFDLFFBQUcsV0FBVSw0Q0FBMkMsa0NBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSx1RkFDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxpREFBZ0QsNEJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUNFWix3QkFBd0IyRixtQkFBbUI7QUFBQSxzQkFFN0M7QUFBQSxzQkFDQSxXQUFVO0FBQUE7QUFBQSxvQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS21GO0FBQUEsa0JBRW5GLHVCQUFDLFVBQUssV0FBVSwrQ0FDYjdHO0FBQUFBLG9CQUNDb0UsWUFBWWxELHdCQUF3QjJGLGVBQWU7QUFBQSxrQkFDckQsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUlBO0FBQUEscUJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFnQkE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsMEZBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsaURBQWdELHdDQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FBTzNGLHdCQUF3QjhGLGdCQUFnQjtBQUFBLHNCQUMvQztBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFHb0Y7QUFBQSxrQkFFcEYsdUJBQUMsVUFBSyxXQUFVLGdEQUNiaEg7QUFBQUEsb0JBQ0NvRSxZQUFZbEQsd0JBQXdCOEYsWUFBWTtBQUFBLGtCQUNsRCxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxxQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWNBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDBGQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGlEQUFnRCw2QkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQ0U5Rix3QkFBd0JnRyxtQkFBbUI7QUFBQSxzQkFFN0M7QUFBQSxzQkFDQSxXQUFVO0FBQUE7QUFBQSxvQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS29GO0FBQUEscUJBVHRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBV0E7QUFBQSxtQkE1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE2Q0E7QUFBQSxpQkE5SkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkErSkE7QUFBQSxZQUlEekQsbUJBQ0NuRCxzQkFDQUEsdUJBQXVCLFNBQ3JCLHVCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSx1Q0FBc0Msa0NBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQ3FDLFdBQVdHLFlBQVlILFdBQVdFLFVBQ2pDLHVCQUFDLFNBQUksV0FBVSxxRkFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQU07QUFBQSxzQkFDTixXQUFVO0FBQUE7QUFBQSxvQkFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRTRCO0FBQUEsa0JBRTVCLHVCQUFDLFVBQUssV0FBVSxnQ0FBK0IsK0JBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVFBO0FBQUEsbUJBYko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDBGQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGlEQUFnRCwwQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLE9BQUUsV0FBVSwyQ0FDVixhQUFHRixXQUFXRSxRQUFRdUssZUFBZSxPQUFPLENBQUMsTUFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFVBQUssV0FBVSxnREFDYnBOLDhCQUFvQjJDLFdBQVdFLFVBQVUsQ0FBQyxLQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSx1RkFDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxpREFBZ0Qsd0JBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsMENBQ1YsYUFBR0YsV0FBV0csVUFBVXNLLGVBQWUsT0FBTyxDQUFDLE1BRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxVQUFLLFdBQVUsK0NBQ2JwTiw4QkFBb0IyQyxXQUFXRyxZQUFZLENBQUMsS0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsdUZBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsaURBQWdELDBCQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRSxXQUFVLDBDQUNWLGNBQ0NILFdBQVdpSCxjQUFjLE1BQ3hCd0QsZUFBZSxPQUFPLENBQUMsTUFINUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQTtBQUFBLGtCQUNBLHVCQUFDLFVBQUssV0FBVSwrQ0FDYnBOO0FBQUFBLG9CQUNDMEosS0FBSzJELElBQUkxSyxXQUFXaUgsY0FBYyxDQUFDO0FBQUEsa0JBQ3JDLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQTtBQUFBLHFCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBY0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsNkZBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsaURBQWdELHdDQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRSxXQUFVLDRDQUNWLGFBQUdqSCxXQUFXTyxpQkFBaUJrSztBQUFBQSxvQkFDOUI7QUFBQSxvQkFDQTtBQUFBLHNCQUNFRSx1QkFBdUI7QUFBQSxzQkFDdkJDLHVCQUF1QjtBQUFBLG9CQUN6QjtBQUFBLGtCQUNGLENBQUMsTUFQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVFBO0FBQUEsa0JBQ0EsdUJBQUMsVUFBSyxXQUFVLGlEQUNidk47QUFBQUEsb0JBQ0MyQyxXQUFXTyxvQkFBb0I7QUFBQSxrQkFDakMsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUlBO0FBQUEscUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0JBO0FBQUEsbUJBeERGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeURBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSx1Q0FBQyxPQUFFLFdBQVUsOENBQTZDLG9DQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxXQUFVLGFBQ1o7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsaURBQ1o7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsd0NBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXFEO0FBQUEsb0JBQ3JELHVCQUFDLFVBQUs7QUFBQTtBQUFBLHNCQUNpQjtBQUFBLHVCQUVuQndHLEtBQUs4RDtBQUFBQSx3QkFDSDdLLFdBQVdHO0FBQUFBLHdCQUNYSCxXQUFXRTtBQUFBQSxzQkFDYixJQUFJLE1BQ0p1SyxlQUFlLFNBQVM7QUFBQSx3QkFDeEJFLHVCQUF1QjtBQUFBLHdCQUN2QkMsdUJBQXVCO0FBQUEsc0JBQ3pCLENBQUM7QUFBQSx5QkFWSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVdBO0FBQUEsb0JBQ0EsdUJBQUMsVUFBSyxXQUFVLDBDQUF5QztBQUFBO0FBQUEsc0JBRXREdk47QUFBQUEsd0JBQ0MwSixLQUFLOEQ7QUFBQUEsMEJBQ0g3SyxXQUFXRztBQUFBQSwwQkFDWEgsV0FBV0U7QUFBQUEsd0JBQ2IsSUFBSTtBQUFBLHNCQUNOO0FBQUEsc0JBQUU7QUFBQSx5QkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVNBO0FBQUEsdUJBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBd0JBO0FBQUEsa0JBQ0NGLFdBQVdHLFdBQVdILFdBQVdFLFVBQ2hDLHVCQUFDLFFBQUcsV0FBVSxpREFDWjtBQUFBLDJDQUFDLFVBQUssV0FBVSx1Q0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0Q7QUFBQSxvQkFDcEQsdUJBQUMsVUFBSztBQUFBO0FBQUEsc0JBQ2dCO0FBQUEsd0JBRWpCRixXQUFXRyxXQUFXSCxXQUFXRSxVQUNsQyxNQUNBdUssZUFBZSxTQUFTO0FBQUEsd0JBQ3hCRSx1QkFBdUI7QUFBQSx3QkFDdkJDLHVCQUF1QjtBQUFBLHNCQUN6QixDQUFDO0FBQUEseUJBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFTQTtBQUFBLG9CQUNBLHVCQUFDLFVBQUssV0FBVSx5Q0FBd0M7QUFBQTtBQUFBLHNCQUVyRHZOO0FBQUFBLHlCQUNFMkMsV0FBV0csV0FBV0gsV0FBV0UsVUFDaEM7QUFBQSxzQkFDSjtBQUFBLHNCQUFFO0FBQUEseUJBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFPQTtBQUFBLHVCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQW9CQTtBQUFBLHFCQS9DSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlEQTtBQUFBLG1CQXJERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNEQTtBQUFBLGlCQWpJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtJQTtBQUFBLFlBSUh6QixVQUNDLHVCQUFDLFNBQUksV0FBVSw2QkFDYixpQ0FBQyxrQkFBZSxXQUFXLFFBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsSUFDRUoscUJBQXFCZ0ssU0FBUyxJQUNoQyx1QkFBQyxTQUFJLFdBQVUsd0VBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFNSztBQUFBQSxnQkFDTjtBQUFBLGdCQUNBLGlCQUFpQjtBQUFBLGdCQUNqQixpQkFBaUI7QUFBQSxrQkFDZjtBQUFBLGtCQUNBO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQTtBQUFBLGtCQUNBO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQTtBQUFBLGtCQUNBO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQTtBQUFBLGtCQUNBO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQTtBQUFBLGdCQUFjO0FBQUEsZ0JBRWhCLG1CQUFtQjtBQUFBLGtCQUNqQi9LLHVCQUF1QixRQUNuQixrQkFDQVEseUJBQXlCNkUsUUFBUTtBQUFBLGtCQUNyQ3JGLHVCQUF1QixRQUNuQixNQUNBUSx5QkFBeUJpSCxnQkFBZ0I7QUFBQSxrQkFDN0N0RSxrQkFDSS9DLHNCQUFzQixXQUNwQixvQkFBSWtCLEtBQUssR0FBR3BCLGFBQWEsS0FBSyxHQUFFNE07QUFBQUEsb0JBQzlCO0FBQUEsb0JBQ0E7QUFBQSxzQkFDRXBJLE9BQU87QUFBQSxzQkFDUEQsTUFBTTtBQUFBLG9CQUNSO0FBQUEsa0JBQ0YsSUFDQSxHQUFHLElBQUluRDtBQUFBQSxvQkFDTHlCO0FBQUFBLGtCQUNGLEVBQUVvSyxtQkFBbUIsQ0FBQyxNQUFNLElBQUk3TDtBQUFBQSxvQkFDOUIyQjtBQUFBQSxrQkFDRixFQUFFa0ssbUJBQW1CLENBQUMsS0FDeEI7QUFBQSxrQkFDSixJQUFJOUssWUFBWUUsUUFBUXVLLGVBQWUsT0FBTyxLQUFLLEdBQUcsS0FBS3BOO0FBQUFBLG9CQUN6RDJDLFlBQVlFLFVBQVU7QUFBQSxrQkFDeEIsQ0FBQztBQUFBLGtCQUNELElBQUlGLFlBQVlHLFVBQVVzSyxlQUFlLE9BQU8sS0FBSyxHQUFHLEtBQUtwTjtBQUFBQSxvQkFDM0QyQyxZQUFZRyxZQUFZO0FBQUEsa0JBQzFCLENBQUM7QUFBQSxrQkFDRCxJQUFJSCxZQUFZSSxXQUFXcUssZUFBZSxPQUFPLEtBQUssR0FBRyxLQUFLcE47QUFBQUEsb0JBQzVEMkMsWUFBWUksYUFBYTtBQUFBLGtCQUMzQixDQUFDO0FBQUEsa0JBQ0QsSUFBSUosWUFBWU8sa0JBQWtCa0s7QUFBQUEsb0JBQ2hDO0FBQUEsb0JBQ0E7QUFBQSxzQkFDRUUsdUJBQXVCO0FBQUEsc0JBQ3ZCQyx1QkFBdUI7QUFBQSxvQkFDekI7QUFBQSxrQkFDRixLQUFLLE1BQU0sS0FBS3ZOO0FBQUFBLG9CQUNkMkMsWUFBWU8sb0JBQW9CO0FBQUEsa0JBQ2xDLENBQUM7QUFBQSxrQkFDRCxJQUFJaEMsd0JBQXdCMkYsaUJBQWlCdUc7QUFBQUEsb0JBQzNDO0FBQUEsa0JBQ0YsS0FBSyxHQUFHLEtBQUtwTjtBQUFBQSxvQkFDWG9FLFlBQVlsRCx3QkFBd0IyRixlQUFlO0FBQUEsa0JBQ3JELENBQUM7QUFBQSxrQkFDRCxJQUFJM0Ysd0JBQXdCOEYsY0FBY29HO0FBQUFBLG9CQUN4QztBQUFBLGtCQUNGLEtBQUssR0FBRyxLQUFLcE47QUFBQUEsb0JBQ1hvRSxZQUFZbEQsd0JBQXdCOEYsWUFBWTtBQUFBLGtCQUNsRCxDQUFDO0FBQUEsa0JBQ0QsSUFBSTlGLHdCQUF3Qm1HLG1CQUFtQitGO0FBQUFBLG9CQUM3QztBQUFBLGtCQUNGLEtBQUssR0FBRyxLQUFLcE47QUFBQUEsb0JBQ1hvRSxZQUFZbEQsd0JBQXdCbUcsaUJBQWlCO0FBQUEsa0JBQ3ZELENBQUM7QUFBQSxrQkFDRCxJQUFJbkcsd0JBQXdCb0csaUJBQWlCOEY7QUFBQUEsb0JBQzNDO0FBQUEsa0JBQ0YsS0FBSyxHQUFHLEtBQUtwTjtBQUFBQSxvQkFDWG9FLFlBQVlsRCx3QkFBd0JvRyxlQUFlO0FBQUEsa0JBQ3JELENBQUM7QUFBQSxrQkFDRHBHLHdCQUF3QmdHLG1CQUFtQjtBQUFBLGtCQUMzQ2hHLHdCQUF3QmtHLGdCQUFnQjtBQUFBLGdCQUFHO0FBQUEsZ0JBRTdDLGtCQUFrQixvQkFDaEJ0Ryx5QkFBeUI2RSxRQUFRLEtBQUssSUFFdENsQyxrQkFDSS9DLHNCQUFzQixVQUNwQkYsZ0JBQ0EsR0FBRzZDLFlBQVksT0FBT0UsVUFBVSxLQUNsQyxZQUFZO0FBQUE7QUFBQSxjQXpGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBMEZTLEtBM0ZYO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkZBLElBRUFFLG1CQUNBM0MseUJBQXlCNkUsUUFDdkIsdUJBQUMsU0FBSSxXQUFVLHlFQUNiLGlDQUFDLE9BQUUsV0FBVSxxQ0FBb0MsaUVBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsZUF6Wm1DLGNBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNFpBO0FBQUEsVUFHQSx1QkFBQyxXQUFRLEtBQUksMkJBRVZsQztBQUFBQSwrQkFDQyx1QkFBQyxTQUFJLFdBQVUsaUVBQ2I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsNENBQTJDLHVDQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsdUZBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsaURBQWdELGlDQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FDRU0sdUJBQXVCRyx5QkFBeUJrSjtBQUFBQSx3QkFDOUM7QUFBQSxzQkFDRixLQUFLO0FBQUEsc0JBRVA7QUFBQSxzQkFDQSxXQUFVO0FBQUE7QUFBQSxvQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBT21GO0FBQUEsa0JBRW5GLHVCQUFDLFVBQUssV0FBVSwrQ0FDYnBOO0FBQUFBLG9CQUNDK0QsdUJBQXVCRywyQkFDckI7QUFBQSxrQkFDSixLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxxQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFtQkE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsMEZBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsaURBQWdELHNDQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FDRUgsdUJBQXVCNkUsOEJBQThCd0U7QUFBQUEsd0JBQ25EO0FBQUEsc0JBQ0YsS0FBSztBQUFBLHNCQUVQO0FBQUEsc0JBQ0EsV0FBVTtBQUFBO0FBQUEsb0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU9vRjtBQUFBLGtCQUVwRix1QkFBQyxVQUFLLFdBQVUsZ0RBQ2JwTjtBQUFBQSxvQkFDQytELHVCQUF1QjZFLGdDQUNyQjtBQUFBLGtCQUNKLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLHFCQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW1CQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwwRkFDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxpREFBZ0QsaUNBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUNFN0UsdUJBQXVCSSwyQkFDdkI7QUFBQSxzQkFFRjtBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNb0Y7QUFBQSxxQkFWdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFZQTtBQUFBLG1CQXJERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNEQTtBQUFBLGlCQTFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJEQTtBQUFBLFlBSUQvQyxVQUNDLHVCQUFDLFNBQUksV0FBVSw2QkFDYixpQ0FBQyxrQkFBZSxXQUFXLFFBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsSUFDRXlDLG9CQUFvQm1ILFNBQVMsSUFDL0IsdUJBQUMsU0FBSSxXQUFVLHdFQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBTW5IO0FBQUFBLGdCQUNOLFNBQVN5STtBQUFBQSxnQkFDVCxpQkFBaUI7QUFBQSxnQkFDakIsaUJBQWlCO0FBQUEsa0JBQ2Y7QUFBQSxrQkFDQTtBQUFBLGtCQUNBO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQTtBQUFBLGtCQUNBO0FBQUEsZ0JBQW1CO0FBQUEsZ0JBRXJCLG1CQUFtQjtBQUFBLGtCQUNqQmhNLHVCQUF1QixRQUNuQixrQkFDQVEseUJBQXlCNkUsUUFBUTtBQUFBLGtCQUNyQ3JGLHVCQUF1QixRQUNuQixNQUNBUSx5QkFBeUJpSCxnQkFBZ0I7QUFBQSxrQkFDN0N0RSxrQkFDSS9DLHNCQUFzQixXQUNwQixvQkFBSWtCLEtBQUssR0FBR3BCLGFBQWEsS0FBSyxHQUFFNE07QUFBQUEsb0JBQzlCO0FBQUEsb0JBQ0E7QUFBQSxzQkFDRXBJLE9BQU87QUFBQSxzQkFDUEQsTUFBTTtBQUFBLG9CQUNSO0FBQUEsa0JBQ0YsSUFDQSxHQUFHLElBQUluRDtBQUFBQSxvQkFDTHlCO0FBQUFBLGtCQUNGLEVBQUVvSyxtQkFBbUIsQ0FBQyxNQUFNLElBQUk3TDtBQUFBQSxvQkFDOUIyQjtBQUFBQSxrQkFDRixFQUFFa0ssbUJBQW1CLENBQUMsS0FDeEI7QUFBQSxrQkFDSixJQUFJMUosdUJBQXVCRyx5QkFBeUJrSjtBQUFBQSxvQkFDbEQ7QUFBQSxrQkFDRixLQUFLLEdBQUcsS0FBS3BOO0FBQUFBLG9CQUNYK0QsdUJBQXVCRywyQkFBMkI7QUFBQSxrQkFDcEQsQ0FBQztBQUFBLGtCQUNELElBQUlILHVCQUF1QkUsNkJBQTZCbUo7QUFBQUEsb0JBQ3REO0FBQUEsa0JBQ0YsS0FBSyxHQUFHLEtBQUtwTjtBQUFBQSxvQkFDWCtELHVCQUF1QkUsK0JBQ3JCO0FBQUEsa0JBQ0osQ0FBQztBQUFBLGtCQUNELEdBQUdGLHVCQUF1QkksMkJBQTJCLEdBQUc7QUFBQSxnQkFBRTtBQUFBLGdCQUU1RCxrQkFBa0Isd0JBQ2hCckQseUJBQXlCNkUsUUFBUSxLQUFLLElBRXRDbEMsa0JBQ0kvQyxzQkFBc0IsVUFDcEJGLGdCQUNBLEdBQUc2QyxZQUFZLE9BQU9FLFVBQVUsS0FDbEMsWUFBWTtBQUFBO0FBQUEsY0F0RHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXVEUyxLQXhEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBEQSxJQUVBRSxtQkFDQTNDLHlCQUF5QjZFLFFBQ3ZCLHVCQUFDLFNBQUksV0FBVSx5RUFDYixpQ0FBQyxPQUFFLFdBQVUscUNBQW9DLHNFQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBeklxQyxtQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0SUE7QUFBQSxhQTdpQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThpQkE7QUFBQSxXQWpsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtsQkE7QUFBQSxTQWh0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWt0QkE7QUFBQSxPQXB0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXF0QkEsS0F0dEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1dEJBO0FBRUo7QUFBRXhGLEdBN3FDSUQsa0JBQWdCO0FBQUF3TixLQUFoQnhOO0FBK3FDTixlQUFlQTtBQUFpQixJQUFBd047QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJTZWxlY3QiLCJSYWRpbyIsIlRhYnMiLCJhcGkiLCJEYXRhVGFibGUiLCJDaXJjdWxhckxvYWRlciIsIk5hdmJhciIsIk1vZGFsIiwiR2lQYXJ0eVBvcHBlciIsIkZpbGVUZXh0T3V0bGluZWQiLCJEb2xsYXJPdXRsaW5lZCIsIkZhTW9uZXlCaWxsIiwiTWRQYXltZW50cyIsIkxpbmsiLCJGaVRhcmdldCIsIm51bWJlclRvSW5kaWFuV29yZHMiLCJUYWJQYW5lIiwiVGFyZ2V0Q29tbWlzc2lvbiIsIl9zIiwiZW1wbG95ZWVzIiwic2V0RW1wbG95ZWVzIiwic2VsZWN0ZWRFbXBsb3llZUlkIiwic2V0U2VsZWN0ZWRFbXBsb3llZUlkIiwic2VsZWN0ZWRNb250aCIsInNldFNlbGVjdGVkTW9udGgiLCJkYXRlU2VsZWN0aW9uTW9kZSIsInNldERhdGVTZWxlY3Rpb25Nb2RlIiwiYWdlbnRMb2FkaW5nIiwic2V0QWdlbnRMb2FkaW5nIiwic2VsZWN0ZWRFbXBsb3llZURldGFpbHMiLCJzZXRTZWxlY3RlZEVtcGxveWVlRGV0YWlscyIsImVtcGxveWVlQ3VzdG9tZXJEYXRhIiwic2V0RW1wbG95ZWVDdXN0b21lckRhdGEiLCJjb21taXNzaW9uVG90YWxEZXRhaWxzIiwic2V0Q29tbWlzc2lvblRvdGFsRGV0YWlscyIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwic2hvd0NvbW1pc3Npb25Nb2RhbCIsInNldFNob3dDb21taXNzaW9uTW9kYWwiLCJjb21taXNzaW9uRm9ybSIsInNldENvbW1pc3Npb25Gb3JtIiwiYWdlbnRfaWQiLCJwYXlfZGF0ZSIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNwbGl0IiwiYW1vdW50IiwicGF5X3R5cGUiLCJ0cmFuc2FjdGlvbl9pZCIsIm5vdGUiLCJwYXlfZm9yIiwiYWRtaW5fdHlwZSIsImVycm9ycyIsInNldEVycm9ycyIsImFkbWluSWQiLCJzZXRBZG1pbklkIiwiYWRtaW5OYW1lIiwic2V0QWRtaW5OYW1lIiwidGFyZ2V0RGF0YSIsInNldFRhcmdldERhdGEiLCJ0YXJnZXQiLCJhY2hpZXZlZCIsInJlbWFpbmluZyIsInN0YXJ0RGF0ZSIsImVuZERhdGUiLCJ0YXJnZXRDb21taXNzaW9uIiwidGVtcFNlbGVjdGVkTW9udGgiLCJzZXRUZW1wU2VsZWN0ZWRNb250aCIsInRlbXBGcm9tRGF0ZSIsInNldFRlbXBGcm9tRGF0ZSIsInRlbXBUb0RhdGUiLCJzZXRUZW1wVG9EYXRlIiwiaXNGaWx0ZXJBcHBsaWVkIiwic2V0SXNGaWx0ZXJBcHBsaWVkIiwiYWN0aXZlVGFiIiwic2V0QWN0aXZlVGFiIiwiZ3Jvc3NDb21taXNzaW9uRGF0YSIsInNldEdyb3NzQ29tbWlzc2lvbkRhdGEiLCJncm9zc0NvbW1pc3Npb25TdW1tYXJ5Iiwic2V0R3Jvc3NDb21taXNzaW9uU3VtbWFyeSIsInRvdGFsX2dyb3NzX2luY2VudGl2ZV92YWx1ZSIsInRvdGFsX2dyb3NzX2dyb3VwX3ZhbHVlIiwidG90YWxfZ3Jvc3NfZW5yb2xsbWVudHMiLCJwYXJzZUFtb3VudCIsInZhbCIsInBhcnNlRmxvYXQiLCJ0b1N0cmluZyIsInJlcGxhY2UiLCJ0b2RheSIsImN1cnJlbnRNb250aCIsImdldEZ1bGxZZWFyIiwiU3RyaW5nIiwiZ2V0TW9udGgiLCJwYWRTdGFydCIsInllYXIiLCJtb250aCIsImZpcnN0RGF5IiwibGFzdGRheTEiLCJnZXREYXRlIiwibGFzdERheSIsInVzZXIiLCJKU09OIiwicGFyc2UiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiX2lkIiwibmFtZSIsImZldGNoRW1wbG95ZWVzIiwicmVzIiwiZ2V0IiwiZGF0YSIsImFnZW50IiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwiZmV0Y2hDb21taXNzaW9uUmVwb3J0IiwiZW1wbG95ZWVJZCIsImFib3J0Q29udHJvbGxlciIsIkFib3J0Q29udHJvbGxlciIsInBhcmFtcyIsInN0YXJ0X2RhdGUiLCJlbmRfZGF0ZSIsInNpZ25hbCIsImNvbW1pc3Npb25EYXRhIiwiYWN0dWFsX2J1c2luZXNzIiwiY29tbWlzc2lvblN1bW1hcnkiLCJ0b3RhbF9ncm91cF92YWx1ZSIsInRvdGFsX2FjdHVhbCIsInRvdGFsX2NvbW1pc3Npb25fdmFsdWUiLCJ0b3RhbF9jdXN0b21lcnMiLCJ0b3RhbF9lbnJvbGxtZW50cyIsInRvdGFsX2dyb3VwcyIsImV4cGVjdGVkX2J1c2luZXNzIiwidG90YWxfZXN0aW1hdGVkIiwiYWJvcnRlZCIsImZldGNoR3Jvc3NJbmNlbnRpdmVSZXBvcnQiLCJncm9zc0NvbW1pc3Npb25JbmZvIiwibWFwIiwiZW5yb2xsbWVudCIsInVzZXJfbmFtZSIsInVzZXJfaWQiLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJncm91cF9uYW1lIiwiZ3JvdXBfaWQiLCJncm91cF92YWx1ZSIsImdyb3VwX2NvbW1pc3Npb24iLCJjb21taXNzaW9uIiwiZ3JvdXBfdGlja2V0IiwidGlja2V0cyIsImVucm9sbG1lbnRfZGF0ZSIsImNyZWF0ZWRBdCIsInRvdGFsX3BhaWRfYW1vdW50IiwiZ3JvdXBfbW9udGhseV9pbnN0YWxsbWVudCIsIm1vbnRobHlfaW5zdGFsbG1lbnQiLCJ0b3RhbF9ncm9zc19jb21taXNzaW9uX3ZhbHVlIiwiY2FsY3VsYXRlVGFyZ2V0Q29tbWlzc2lvbiIsImFjaGlldmVkQnVzaW5lc3MiLCJ0YXJnZXRBbW91bnQiLCJhY2hpZXZlZE51bSIsIk51bWJlciIsInRhcmdldE51bSIsInVwVG9UYXJnZXQiLCJiZXlvbmRUYXJnZXQiLCJmZXRjaFRhcmdldERhdGEiLCJ0YXJnZXRSZXMiLCJ0YXJnZXRGb3JNb250aCIsInRvdGFsX3RhcmdldCIsImNvbW0iLCJNYXRoIiwibWF4IiwiZGlmZmVyZW5jZSIsInJvdW5kIiwiZmV0Y2hBbGxDb21taXNzaW9uUmVwb3J0IiwiZmV0Y2hBbGxHcm9zc0luY2VudGl2ZVJlcG9ydCIsImdyb3NzSW5jZW50aXZlSW5mbyIsImhhbmRsZUVtcGxveWVlQ2hhbmdlIiwidmFsdWUiLCJoYW5kbGVUZW1wTW9udGhDaGFuZ2UiLCJlIiwiYXBwbHlGaWx0ZXIiLCJhbGVydCIsImVtcCIsImZpbmQiLCJoYW5kbGVDb21taXNzaW9uQ2hhbmdlIiwicHJldiIsInZhbGlkYXRlRm9ybSIsIm5ld0Vycm9ycyIsImlzTmFOIiwiT2JqZWN0Iiwia2V5cyIsImxlbmd0aCIsImhhbmRsZUNvbW1pc3Npb25TdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsInBheWxvYWQiLCJwb3N0IiwicHJvY2Vzc2VkVGFibGVEYXRhIiwiaXRlbSIsImluZGV4IiwiZ3JvdXBfdmFsdWVfZGlnaXRzIiwiZXN0aW1hdGVkX2NvbW1pc3Npb25fZGlnaXRzIiwiZXN0aW1hdGVkX2NvbW1pc3Npb24iLCJhY3R1YWxfY29tbWlzc2lvbl9kaWdpdHMiLCJjb21taXNzaW9uX3ZhbHVlIiwidG90YWxfcGFpZF9kaWdpdHMiLCJyZXF1aXJlZF9pbnN0YWxsbWVudF9kaWdpdHMiLCJ0aWNrZXQiLCJuZXRfY29tbWlzc2lvbl9wZXJjZW50YWdlIiwiY29tbWlzc2lvbl9yZWxlYXNlZCIsImVub2xsbWVudF9kYXRlIiwiY29sdW1ucyIsImtleSIsImhlYWRlciIsImdyb3NzQ29tbWlzc2lvbkNvbHVtbnMiLCJ1bmRlZmluZWQiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsImhlaWdodCIsImVtYWlsIiwiYWRoYWFyX25vIiwicGFuX25vIiwicGluY29kZSIsImFkZHJlc3MiLCJqb2luaW5nX2RhdGUiLCJ0b0xvY2FsZVN0cmluZyIsImFicyIsIm1pbmltdW1GcmFjdGlvbkRpZ2l0cyIsIm1heGltdW1GcmFjdGlvbkRpZ2l0cyIsIm1pbiIsInRvTG9jYWxlRGF0ZVN0cmluZyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlRhcmdldENvbW1pc3Npb24uanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIGltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbi8vIGltcG9ydCB7IFNlbGVjdCwgUmFkaW8gfSBmcm9tIFwiYW50ZFwiO1xyXG4vLyBpbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbi8vIGltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuLy8gaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuLy8gaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG4vLyBpbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbi8vIGltcG9ydCB7IEdpUGFydHlQb3BwZXIgfSBmcm9tIFwicmVhY3QtaWNvbnMvZ2lcIjtcclxuLy8gaW1wb3J0IHsgRmlsZVRleHRPdXRsaW5lZCwgRG9sbGFyT3V0bGluZWQgfSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuLy8gaW1wb3J0IHsgQ29sbGFwc2UgfSBmcm9tIFwiYW50ZFwiO1xyXG4vLyBpbXBvcnQgeyBGYU1vbmV5QmlsbCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG4vLyBpbXBvcnQgeyBNZFBheW1lbnRzIH0gZnJvbSBcInJlYWN0LWljb25zL21kXCI7XHJcbi8vIGltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG4vLyBpbXBvcnQgeyBGaVRhcmdldCB9IGZyb20gXCJyZWFjdC1pY29ucy9maVwiO1xyXG5cclxuLy8gY29uc3QgVGFyZ2V0Q29tbWlzc2lvbiA9ICgpID0+IHtcclxuLy8gICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtzZWxlY3RlZEVtcGxveWVlSWQsIHNldFNlbGVjdGVkRW1wbG95ZWVJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuLy8gICBjb25zdCBbc2VsZWN0ZWRNb250aCwgc2V0U2VsZWN0ZWRNb250aF0gPSB1c2VTdGF0ZShudWxsKTtcclxuLy8gICBjb25zdCBbZGF0ZVNlbGVjdGlvbk1vZGUsIHNldERhdGVTZWxlY3Rpb25Nb2RlXSA9IHVzZVN0YXRlKFwibW9udGhcIik7XHJcbi8vICAgY29uc3QgW2FnZW50TG9hZGluZywgc2V0QWdlbnRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbc2VsZWN0ZWRFbXBsb3llZURldGFpbHMsIHNldFNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4vLyAgIGNvbnN0IFtlbXBsb3llZUN1c3RvbWVyRGF0YSwgc2V0RW1wbG95ZWVDdXN0b21lckRhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtjb21taXNzaW9uVG90YWxEZXRhaWxzLCBzZXRDb21taXNzaW9uVG90YWxEZXRhaWxzXSA9IHVzZVN0YXRlKHt9KTtcclxuLy8gICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW3Nob3dDb21taXNzaW9uTW9kYWwsIHNldFNob3dDb21taXNzaW9uTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFtjb21taXNzaW9uRm9ybSwgc2V0Q29tbWlzc2lvbkZvcm1dID0gdXNlU3RhdGUoe1xyXG4vLyAgICAgYWdlbnRfaWQ6IFwiXCIsXHJcbi8vICAgICBwYXlfZGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXSxcclxuLy8gICAgIGFtb3VudDogXCJcIixcclxuLy8gICAgIHBheV90eXBlOiBcImNhc2hcIixcclxuLy8gICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4vLyAgICAgbm90ZTogXCJcIixcclxuLy8gICAgIHBheV9mb3I6IFwiY29tbWlzc2lvblwiLFxyXG4vLyAgICAgYWRtaW5fdHlwZTogXCJcIixcclxuLy8gICB9KTtcclxuLy8gICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4vLyAgIGNvbnN0IFthZG1pbklkLCBzZXRBZG1pbklkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFthZG1pbk5hbWUsIHNldEFkbWluTmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbdGFyZ2V0RGF0YSwgc2V0VGFyZ2V0RGF0YV0gPSB1c2VTdGF0ZSh7XHJcbi8vICAgICB0YXJnZXQ6IDAsXHJcbi8vICAgICBhY2hpZXZlZDogMCxcclxuLy8gICAgIHJlbWFpbmluZzogMCxcclxuLy8gICAgIHN0YXJ0RGF0ZTogXCJcIixcclxuLy8gICAgIGVuZERhdGU6IFwiXCIsXHJcbi8vICAgICB0YXJnZXRDb21taXNzaW9uOiAwLFxyXG4vLyAgIH0pO1xyXG5cclxuLy8gICBjb25zdCBbdGVtcFNlbGVjdGVkTW9udGgsIHNldFRlbXBTZWxlY3RlZE1vbnRoXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4vLyAgIGNvbnN0IFt0ZW1wRnJvbURhdGUsIHNldFRlbXBGcm9tRGF0ZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuLy8gICBjb25zdCBbdGVtcFRvRGF0ZSwgc2V0VGVtcFRvRGF0ZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuLy8gICBjb25zdCBbaXNGaWx0ZXJBcHBsaWVkLCBzZXRJc0ZpbHRlckFwcGxpZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4vLyAgICAgY29uc3QgY3VycmVudE1vbnRoID0gYCR7dG9kYXkuZ2V0RnVsbFllYXIoKX0tJHtTdHJpbmcoXHJcbi8vICAgICAgIHRvZGF5LmdldE1vbnRoKCkgKyAxXHJcbi8vICAgICApLnBhZFN0YXJ0KDIsIFwiMFwiKX1gO1xyXG4vLyAgICAgc2V0VGVtcFNlbGVjdGVkTW9udGgoY3VycmVudE1vbnRoKTtcclxuXHJcbi8vICAgICBjb25zdCB5ZWFyID0gdG9kYXkuZ2V0RnVsbFllYXIoKTtcclxuLy8gICAgIGNvbnN0IG1vbnRoID0gdG9kYXkuZ2V0TW9udGgoKSArIDE7XHJcbi8vICAgICBjb25zdCBmaXJzdERheSA9IGAke3llYXJ9LSR7U3RyaW5nKG1vbnRoKS5wYWRTdGFydCgyLCBcIjBcIil9LTAxYDtcclxuLy8gICAgIGNvbnN0IGxhc3REYXkgPSBuZXcgRGF0ZSh5ZWFyLCBtb250aCwgMCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcbi8vICAgICBzZXRUZW1wRnJvbURhdGUoZmlyc3REYXkpO1xyXG4vLyAgICAgc2V0VGVtcFRvRGF0ZShsYXN0RGF5KTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBjb25zdCB1c2VyID0gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIikpO1xyXG4vLyAgICAgaWYgKHVzZXIpIHtcclxuLy8gICAgICAgc2V0QWRtaW5JZCh1c2VyLl9pZCk7XHJcbi8vICAgICAgIHNldEFkbWluTmFtZSh1c2VyLm5hbWUgfHwgXCJcIik7XHJcbi8vICAgICB9XHJcbi8vICAgfSwgW10pO1xyXG5cclxuLy8gICBjb25zdCBmZXRjaEVtcGxveWVlcyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvYWdlbnQvZ2V0XCIpO1xyXG4vLyAgICAgICBzZXRFbXBsb3llZXMocmVzPy5kYXRhPy5hZ2VudCk7XHJcbi8vICAgICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVtcGxveWVlczpcIiwgZXJyKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBmZXRjaENvbW1pc3Npb25SZXBvcnQgPSBhc3luYyAoZW1wbG95ZWVJZCwgc3RhcnREYXRlLCBlbmREYXRlKSA9PiB7XHJcbi8vICAgICBpZiAoIWVtcGxveWVlSWQgfHwgIXN0YXJ0RGF0ZSB8fCAhZW5kRGF0ZSkgcmV0dXJuO1xyXG4vLyAgICAgY29uc3QgYWJvcnRDb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xyXG4vLyAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGNvbnN0IHBhcmFtcyA9IHtcclxuLy8gICAgICAgICBzdGFydF9kYXRlOiBzdGFydERhdGUsXHJcbi8vICAgICAgICAgZW5kX2RhdGU6IGVuZERhdGUsXHJcbi8vICAgICAgIH07XHJcblxyXG4vLyAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KGAvZW5yb2xsL2FnZW50LyR7ZW1wbG95ZWVJZH0vY29tbWlzc2lvbmAsIHtcclxuLy8gICAgICAgICBwYXJhbXMsXHJcbi8vICAgICAgICAgc2lnbmFsOiBhYm9ydENvbnRyb2xsZXIuc2lnbmFsLFxyXG4vLyAgICAgICB9KTtcclxuXHJcbi8vICAgICAgIHNldEVtcGxveWVlQ3VzdG9tZXJEYXRhKHJlcy5kYXRhPy5jb21taXNzaW9uRGF0YSk7XHJcbi8vICAgICAgIHNldENvbW1pc3Npb25Ub3RhbERldGFpbHMoe1xyXG4vLyAgICAgICAgIGFjdHVhbF9idXNpbmVzczogcmVzLmRhdGE/LmNvbW1pc3Npb25TdW1tYXJ5Py50b3RhbF9ncm91cF92YWx1ZSxcclxuLy8gICAgICAgICB0b3RhbF9hY3R1YWw6IHJlcy5kYXRhPy5jb21taXNzaW9uU3VtbWFyeT8udG90YWxfY29tbWlzc2lvbl92YWx1ZSxcclxuLy8gICAgICAgICB0b3RhbF9jdXN0b21lcnM6IHJlcy5kYXRhPy5jb21taXNzaW9uU3VtbWFyeT8udG90YWxfZW5yb2xsbWVudHMsXHJcbi8vICAgICAgICAgdG90YWxfZ3JvdXBzOiByZXMuZGF0YT8uY29tbWlzc2lvblN1bW1hcnk/LnRvdGFsX2Vucm9sbG1lbnRzLFxyXG4vLyAgICAgICAgIGV4cGVjdGVkX2J1c2luZXNzOiByZXMuZGF0YT8uY29tbWlzc2lvblN1bW1hcnk/LnRvdGFsX2dyb3VwX3ZhbHVlLFxyXG4vLyAgICAgICAgIHRvdGFsX2VzdGltYXRlZDogcmVzLmRhdGE/LmNvbW1pc3Npb25TdW1tYXJ5Py50b3RhbF9jb21taXNzaW9uX3ZhbHVlLFxyXG4vLyAgICAgICB9KTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycikge1xyXG4vLyAgICAgICBpZiAoZXJyLm5hbWUgIT09IFwiQWJvcnRDb250cm9sbGVyXCIpIHtcclxuLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW1wbG95ZWUgcmVwb3J0OlwiLCBlcnIpO1xyXG4vLyAgICAgICAgIHNldEVtcGxveWVlQ3VzdG9tZXJEYXRhKFtdKTtcclxuLy8gICAgICAgICBzZXRDb21taXNzaW9uVG90YWxEZXRhaWxzKHt9KTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfSBmaW5hbGx5IHtcclxuLy8gICAgICAgaWYgKCFhYm9ydENvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHtcclxuLy8gICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGNhbGN1bGF0ZVRhcmdldENvbW1pc3Npb24gPSAoYWNoaWV2ZWRCdXNpbmVzcywgdGFyZ2V0QW1vdW50KSA9PiB7XHJcbi8vICAgICBjb25zdCBhY2hpZXZlZE51bSA9XHJcbi8vICAgICAgIHR5cGVvZiBhY2hpZXZlZEJ1c2luZXNzID09PSBcInN0cmluZ1wiXHJcbi8vICAgICAgICAgPyBOdW1iZXIoYWNoaWV2ZWRCdXNpbmVzcy5yZXBsYWNlKC9bXjAtOS4tXSsvZywgXCJcIikpXHJcbi8vICAgICAgICAgOiBhY2hpZXZlZEJ1c2luZXNzO1xyXG4vLyAgICAgY29uc3QgdGFyZ2V0TnVtID1cclxuLy8gICAgICAgdHlwZW9mIHRhcmdldEFtb3VudCA9PT0gXCJzdHJpbmdcIlxyXG4vLyAgICAgICAgID8gTnVtYmVyKHRhcmdldEFtb3VudC5yZXBsYWNlKC9bXjAtOS4tXSsvZywgXCJcIikpXHJcbi8vICAgICAgICAgOiB0YXJnZXRBbW91bnQ7XHJcblxyXG4vLyAgICAgaWYgKGFjaGlldmVkTnVtIDw9IHRhcmdldE51bSkge1xyXG4vLyAgICAgICByZXR1cm4gYWNoaWV2ZWROdW0gKiAwLjAwNTtcclxuLy8gICAgIH0gZWxzZSB7XHJcbi8vICAgICAgIGNvbnN0IHVwVG9UYXJnZXQgPSB0YXJnZXROdW0gKiAwLjAwNTtcclxuLy8gICAgICAgY29uc3QgYmV5b25kVGFyZ2V0ID0gKGFjaGlldmVkTnVtIC0gdGFyZ2V0TnVtKSAqIDAuMDE7XHJcbi8vICAgICAgIHJldHVybiB1cFRvVGFyZ2V0ICsgYmV5b25kVGFyZ2V0O1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGZldGNoVGFyZ2V0RGF0YSA9IGFzeW5jIChlbXBsb3llZUlkLCBzdGFydERhdGUsIGVuZERhdGUpID0+IHtcclxuLy8gICAgIGlmICghZW1wbG95ZWVJZCB8fCAhc3RhcnREYXRlIHx8ICFlbmREYXRlKSByZXR1cm47XHJcblxyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgY29uc3QgYWJvcnRDb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xyXG5cclxuLy8gICAgICAgY29uc3QgdGFyZ2V0UmVzID0gYXdhaXQgYXBpLmdldChgL3RhcmdldC9hZ2VudHMvJHtlbXBsb3llZUlkfWAsIHtcclxuLy8gICAgICAgICBwYXJhbXM6IHsgc3RhcnRfZGF0ZTogc3RhcnREYXRlLCBlbmRfZGF0ZTogZW5kRGF0ZSB9LFxyXG4vLyAgICAgICAgIHNpZ25hbDogYWJvcnRDb250cm9sbGVyLnNpZ25hbCxcclxuLy8gICAgICAgfSk7XHJcblxyXG4vLyAgICAgICBjb25zdCB0YXJnZXRGb3JNb250aCA9IHRhcmdldFJlcy5kYXRhPy50b3RhbF90YXJnZXQgfHwgMDtcclxuXHJcbi8vICAgICAgIGNvbnN0IHsgZGF0YTogY29tbSB9ID0gYXdhaXQgYXBpLmdldChcclxuLy8gICAgICAgICBgL2Vucm9sbC9hZ2VudC8ke2VtcGxveWVlSWR9L2NvbW1pc3Npb25gLFxyXG4vLyAgICAgICAgIHtcclxuLy8gICAgICAgICAgIHBhcmFtczogeyBzdGFydF9kYXRlOiBzdGFydERhdGUsIGVuZF9kYXRlOiBlbmREYXRlIH0sXHJcbi8vICAgICAgICAgICBzaWduYWw6IGFib3J0Q29udHJvbGxlci5zaWduYWwsXHJcbi8vICAgICAgICAgfVxyXG4vLyAgICAgICApO1xyXG5cclxuLy8gICAgICAgbGV0IGFjaGlldmVkID0gY29tbT8uY29tbWlzc2lvblN1bW1hcnk/LnRvdGFsX2dyb3VwX3ZhbHVlIHx8IDA7XHJcbi8vICAgICAgIGlmICh0eXBlb2YgYWNoaWV2ZWQgPT09IFwic3RyaW5nXCIpIHtcclxuLy8gICAgICAgICBhY2hpZXZlZCA9IE51bWJlcihhY2hpZXZlZC5yZXBsYWNlKC9bXjAtOS4tXSsvZywgXCJcIikpO1xyXG4vLyAgICAgICB9XHJcblxyXG4vLyAgICAgICBjb25zdCByZW1haW5pbmcgPSBNYXRoLm1heCh0YXJnZXRGb3JNb250aCAtIGFjaGlldmVkLCAwKTtcclxuLy8gICAgICAgY29uc3QgZGlmZmVyZW5jZSA9IHRhcmdldEZvck1vbnRoIC0gYWNoaWV2ZWQ7XHJcbi8vICAgICAgIGNvbnN0IHRhcmdldENvbW1pc3Npb24gPSBjYWxjdWxhdGVUYXJnZXRDb21taXNzaW9uKFxyXG4vLyAgICAgICAgIGFjaGlldmVkLFxyXG4vLyAgICAgICAgIHRhcmdldEZvck1vbnRoXHJcbi8vICAgICAgICk7XHJcblxyXG4vLyAgICAgICBzZXRUYXJnZXREYXRhKHtcclxuLy8gICAgICAgICB0YXJnZXQ6IE1hdGgucm91bmQodGFyZ2V0Rm9yTW9udGgpLFxyXG4vLyAgICAgICAgIGFjaGlldmVkLFxyXG4vLyAgICAgICAgIHJlbWFpbmluZyxcclxuLy8gICAgICAgICBkaWZmZXJlbmNlLFxyXG4vLyAgICAgICAgIHN0YXJ0RGF0ZTogc3RhcnREYXRlLFxyXG4vLyAgICAgICAgIGVuZERhdGU6IGVuZERhdGUsXHJcbi8vICAgICAgICAgdGFyZ2V0Q29tbWlzc2lvbixcclxuLy8gICAgICAgfSk7XHJcbi8vICAgICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAgICAgaWYgKGVyci5uYW1lICE9PSBcIkFib3J0RXJyb3JcIikge1xyXG4vLyAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB0YXJnZXQgZGF0YTpcIiwgZXJyKTtcclxuLy8gICAgICAgICBzZXRUYXJnZXREYXRhKHtcclxuLy8gICAgICAgICAgIHRhcmdldDogMCxcclxuLy8gICAgICAgICAgIGFjaGlldmVkOiAwLFxyXG4vLyAgICAgICAgICAgcmVtYWluaW5nOiAwLFxyXG4vLyAgICAgICAgICAgZGlmZmVyZW5jZTogMCxcclxuLy8gICAgICAgICAgIHN0YXJ0RGF0ZTogXCJcIixcclxuLy8gICAgICAgICAgIGVuZERhdGU6IFwiXCIsXHJcbi8vICAgICAgICAgICB0YXJnZXRDb21taXNzaW9uOiAwLFxyXG4vLyAgICAgICAgIH0pO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgZmV0Y2hBbGxDb21taXNzaW9uUmVwb3J0ID0gYXN5bmMgKHN0YXJ0RGF0ZSwgZW5kRGF0ZSkgPT4ge1xyXG4vLyAgICAgaWYgKCFzdGFydERhdGUgfHwgIWVuZERhdGUpIHJldHVybjtcclxuXHJcbi8vICAgICBjb25zdCBhYm9ydENvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XHJcbi8vICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgY29uc3QgcGFyYW1zID0ge1xyXG4vLyAgICAgICAgIHN0YXJ0X2RhdGU6IHN0YXJ0RGF0ZSxcclxuLy8gICAgICAgICBlbmRfZGF0ZTogZW5kRGF0ZSxcclxuLy8gICAgICAgfTtcclxuXHJcbi8vICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvZW5yb2xsL2NvbW1pc3Npb25cIiwge1xyXG4vLyAgICAgICAgIHBhcmFtcyxcclxuLy8gICAgICAgICBzaWduYWw6IGFib3J0Q29udHJvbGxlci5zaWduYWwsXHJcbi8vICAgICAgIH0pO1xyXG5cclxuLy8gICAgICAgc2V0RW1wbG95ZWVDdXN0b21lckRhdGEocmVzLmRhdGE/LmNvbW1pc3Npb25EYXRhKTtcclxuLy8gICAgICAgc2V0Q29tbWlzc2lvblRvdGFsRGV0YWlscyh7XHJcbi8vICAgICAgICAgYWN0dWFsX2J1c2luZXNzOiByZXMuZGF0YT8uY29tbWlzc2lvblN1bW1hcnk/LnRvdGFsX2dyb3VwX3ZhbHVlLFxyXG4vLyAgICAgICAgIHRvdGFsX2FjdHVhbDogcmVzLmRhdGE/LmNvbW1pc3Npb25TdW1tYXJ5Py50b3RhbF9jb21taXNzaW9uX3ZhbHVlLFxyXG4vLyAgICAgICAgIHRvdGFsX2N1c3RvbWVyczogcmVzLmRhdGE/LmNvbW1pc3Npb25TdW1tYXJ5Py50b3RhbF9lbnJvbGxtZW50cyxcclxuLy8gICAgICAgICB0b3RhbF9ncm91cHM6IHJlcy5kYXRhPy5jb21taXNzaW9uU3VtbWFyeT8udG90YWxfZW5yb2xsbWVudHMsXHJcbi8vICAgICAgICAgZXhwZWN0ZWRfYnVzaW5lc3M6IHJlcy5kYXRhPy5jb21taXNzaW9uU3VtbWFyeT8udG90YWxfZ3JvdXBfdmFsdWUsXHJcbi8vICAgICAgICAgdG90YWxfZXN0aW1hdGVkOiByZXMuZGF0YT8uY29tbWlzc2lvblN1bW1hcnk/LnRvdGFsX2NvbW1pc3Npb25fdmFsdWUsXHJcbi8vICAgICAgIH0pO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbi8vICAgICAgIGlmIChlcnIubmFtZSAhPT0gXCJBYm9ydEVycm9yXCIpIHtcclxuLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYWxsIGNvbW1pc3Npb24gcmVwb3J0OlwiLCBlcnIpO1xyXG4vLyAgICAgICAgIHNldEVtcGxveWVlQ3VzdG9tZXJEYXRhKFtdKTtcclxuLy8gICAgICAgICBzZXRDb21taXNzaW9uVG90YWxEZXRhaWxzKHt9KTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfSBmaW5hbGx5IHtcclxuLy8gICAgICAgaWYgKCFhYm9ydENvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHtcclxuLy8gICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZUVtcGxveWVlQ2hhbmdlID0gKHZhbHVlKSA9PiB7XHJcbi8vICAgICBzZXRTZWxlY3RlZEVtcGxveWVlSWQodmFsdWUpO1xyXG4vLyAgICAgc2V0U2VsZWN0ZWRFbXBsb3llZURldGFpbHMobnVsbCk7XHJcbi8vICAgICBzZXRFbXBsb3llZUN1c3RvbWVyRGF0YShbXSk7XHJcbi8vICAgICBzZXRDb21taXNzaW9uVG90YWxEZXRhaWxzKHt9KTtcclxuLy8gICAgIHNldFRhcmdldERhdGEoe1xyXG4vLyAgICAgICB0YXJnZXQ6IDAsXHJcbi8vICAgICAgIGFjaGlldmVkOiAwLFxyXG4vLyAgICAgICByZW1haW5pbmc6IDAsXHJcbi8vICAgICAgIHN0YXJ0RGF0ZTogXCJcIixcclxuLy8gICAgICAgZW5kRGF0ZTogXCJcIixcclxuLy8gICAgICAgdGFyZ2V0Q29tbWlzc2lvbjogMCxcclxuLy8gICAgIH0pO1xyXG4vLyAgICAgc2V0SXNGaWx0ZXJBcHBsaWVkKGZhbHNlKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVUZW1wTW9udGhDaGFuZ2UgPSAoZSkgPT4ge1xyXG4vLyAgICAgY29uc3Qgc2VsZWN0ZWRNb250aCA9IGUudGFyZ2V0LnZhbHVlO1xyXG4vLyAgICAgc2V0VGVtcFNlbGVjdGVkTW9udGgoc2VsZWN0ZWRNb250aCk7XHJcbi8vICAgICBpZiAoc2VsZWN0ZWRNb250aCkge1xyXG4vLyAgICAgICBjb25zdCBbeWVhciwgbW9udGhdID0gc2VsZWN0ZWRNb250aC5zcGxpdChcIi1cIik7XHJcbi8vICAgICAgIGNvbnN0IGZpcnN0RGF5ID0gYCR7eWVhcn0tJHttb250aH0tMDFgO1xyXG4vLyAgICAgICBjb25zdCBsYXN0RGF5ID0gbmV3IERhdGUoeWVhciwgbW9udGgsIDApLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdO1xyXG4vLyAgICAgICBzZXRUZW1wRnJvbURhdGUoZmlyc3REYXkpO1xyXG4vLyAgICAgICBzZXRUZW1wVG9EYXRlKGxhc3REYXkpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGFwcGx5RmlsdGVyID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgaWYgKCFzZWxlY3RlZEVtcGxveWVlSWQpIHtcclxuLy8gICAgICAgYWxlcnQoXCJQbGVhc2Ugc2VsZWN0IGFuIGFnZW50LlwiKTtcclxuLy8gICAgICAgcmV0dXJuO1xyXG4vLyAgICAgfVxyXG5cclxuLy8gICAgIGlmIChkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiICYmICF0ZW1wU2VsZWN0ZWRNb250aCkge1xyXG4vLyAgICAgICBhbGVydChcIlBsZWFzZSBzZWxlY3QgYSBtb250aC5cIik7XHJcbi8vICAgICAgIHJldHVybjtcclxuLy8gICAgIH1cclxuXHJcbi8vICAgICBpZiAoZGF0ZVNlbGVjdGlvbk1vZGUgPT09IFwiZGF0ZS1yYW5nZVwiICYmICghdGVtcEZyb21EYXRlIHx8ICF0ZW1wVG9EYXRlKSkge1xyXG4vLyAgICAgICBhbGVydChcIlBsZWFzZSBzZWxlY3QgYm90aCBGcm9tIGFuZCBUbyBkYXRlcy5cIik7XHJcbi8vICAgICAgIHJldHVybjtcclxuLy8gICAgIH1cclxuXHJcbi8vICAgICBsZXQgc3RhcnREYXRlLCBlbmREYXRlO1xyXG5cclxuLy8gICAgIGlmIChkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiKSB7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkTW9udGgodGVtcFNlbGVjdGVkTW9udGgpO1xyXG4vLyAgICAgICBjb25zdCBbeWVhciwgbW9udGhdID0gdGVtcFNlbGVjdGVkTW9udGguc3BsaXQoXCItXCIpO1xyXG4vLyAgICAgICBzdGFydERhdGUgPSBgJHt5ZWFyfS0ke21vbnRofS0wMWA7XHJcbi8vICAgICAgIGVuZERhdGUgPSBuZXcgRGF0ZSh5ZWFyLCBtb250aCwgMCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcbi8vICAgICB9IGVsc2Uge1xyXG4vLyAgICAgICBzdGFydERhdGUgPSB0ZW1wRnJvbURhdGU7XHJcbi8vICAgICAgIGVuZERhdGUgPSB0ZW1wVG9EYXRlO1xyXG4vLyAgICAgfVxyXG5cclxuLy8gICAgIHNldEFnZW50TG9hZGluZyh0cnVlKTtcclxuLy8gICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcblxyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgc2V0SXNGaWx0ZXJBcHBsaWVkKHRydWUpO1xyXG5cclxuLy8gICAgICAgaWYgKHNlbGVjdGVkRW1wbG95ZWVJZCA9PT0gXCJBTExcIikge1xyXG4vLyAgICAgICAgIHNldFNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzKG51bGwpO1xyXG4vLyAgICAgICAgIHNldFRhcmdldERhdGEoe1xyXG4vLyAgICAgICAgICAgdGFyZ2V0OiAwLFxyXG4vLyAgICAgICAgICAgYWNoaWV2ZWQ6IDAsXHJcbi8vICAgICAgICAgICByZW1haW5pbmc6IDAsXHJcbi8vICAgICAgICAgICBzdGFydERhdGU6IFwiXCIsXHJcbi8vICAgICAgICAgICBlbmREYXRlOiBcIlwiLFxyXG4vLyAgICAgICAgICAgdGFyZ2V0Q29tbWlzc2lvbjogMCxcclxuLy8gICAgICAgICB9KTtcclxuLy8gICAgICAgICBhd2FpdCBmZXRjaEFsbENvbW1pc3Npb25SZXBvcnQoc3RhcnREYXRlLCBlbmREYXRlKTtcclxuLy8gICAgICAgfSBlbHNlIHtcclxuLy8gICAgICAgICBjb25zdCBlbXAgPSBlbXBsb3llZXMuZmluZCgoZSkgPT4gZS5faWQgPT09IHNlbGVjdGVkRW1wbG95ZWVJZCk7XHJcbi8vICAgICAgICAgc2V0U2VsZWN0ZWRFbXBsb3llZURldGFpbHMoZW1wIHx8IG51bGwpO1xyXG4vLyAgICAgICAgIGF3YWl0IGZldGNoQ29tbWlzc2lvblJlcG9ydChzZWxlY3RlZEVtcGxveWVlSWQsIHN0YXJ0RGF0ZSwgZW5kRGF0ZSk7XHJcbi8vICAgICAgICAgYXdhaXQgZmV0Y2hUYXJnZXREYXRhKHNlbGVjdGVkRW1wbG95ZWVJZCwgc3RhcnREYXRlLCBlbmREYXRlKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfSBmaW5hbGx5IHtcclxuLy8gICAgICAgc2V0QWdlbnRMb2FkaW5nKGZhbHNlKTtcclxuLy8gICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGZldGNoRW1wbG95ZWVzKCk7XHJcbi8vICAgfSwgW10pO1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVDb21taXNzaW9uQ2hhbmdlID0gKGUpID0+IHtcclxuLy8gICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4vLyAgICAgc2V0Q29tbWlzc2lvbkZvcm0oKHByZXYpID0+ICh7IC4uLnByZXYsIFtuYW1lXTogdmFsdWUgfSkpO1xyXG4vLyAgICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbbmFtZV06IFwiXCIgfSkpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IHZhbGlkYXRlRm9ybSA9ICgpID0+IHtcclxuLy8gICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG4vLyAgICAgaWYgKCFjb21taXNzaW9uRm9ybS5hZ2VudF9pZCkgbmV3RXJyb3JzLmFnZW50X2lkID0gXCJQbGVhc2Ugc2VsZWN0IGFuIGFnZW50XCI7XHJcbi8vICAgICBpZiAoIWNvbW1pc3Npb25Gb3JtLmFtb3VudCB8fCBpc05hTihjb21taXNzaW9uRm9ybS5hbW91bnQpKVxyXG4vLyAgICAgICBuZXdFcnJvcnMuYW1vdW50ID0gXCJQbGVhc2UgZW50ZXIgYSB2YWxpZCBhbW91bnRcIjtcclxuLy8gICAgIGlmIChjb21taXNzaW9uRm9ybS5wYXlfdHlwZSA9PT0gXCJvbmxpbmVcIiAmJiAhY29tbWlzc2lvbkZvcm0udHJhbnNhY3Rpb25faWQpXHJcbi8vICAgICAgIG5ld0Vycm9ycy50cmFuc2FjdGlvbl9pZCA9IFwiVHJhbnNhY3Rpb24gSUQgaXMgcmVxdWlyZWRcIjtcclxuLy8gICAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG4vLyAgICAgcmV0dXJuIE9iamVjdC5rZXlzKG5ld0Vycm9ycykubGVuZ3RoID09PSAwO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZUNvbW1pc3Npb25TdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4vLyAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4vLyAgICAgaWYgKCF2YWxpZGF0ZUZvcm0oKSkgcmV0dXJuO1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgY29uc3QgcGF5bG9hZCA9IHsgLi4uY29tbWlzc2lvbkZvcm0sIGFkbWluX3R5cGU6IGFkbWluSWQgfTtcclxuLy8gICAgICAgYXdhaXQgYXBpLnBvc3QoXCIvcGF5bWVudC1vdXQvYWRkLWNvbW1pc3Npb24tcGF5bWVudFwiLCBwYXlsb2FkKTtcclxuLy8gICAgICAgYWxlcnQoXCJDb21taXNzaW9uIFBhaWQgU3VjY2Vzc2Z1bGx5IVwiKTtcclxuLy8gICAgICAgc2V0U2hvd0NvbW1pc3Npb25Nb2RhbChmYWxzZSk7XHJcbi8vICAgICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAgICAgYWxlcnQoXCJGYWlsZWQgdG8gYWRkIHBheW1lbnQuXCIpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IHByb2Nlc3NlZFRhYmxlRGF0YSA9IGVtcGxveWVlQ3VzdG9tZXJEYXRhLm1hcCgoaXRlbSwgaW5kZXgpID0+ICh7XHJcbi8vICAgICAuLi5pdGVtLFxyXG4vLyAgICAgZ3JvdXBfdmFsdWVfZGlnaXRzOiBpdGVtLmdyb3VwX2lkPy5ncm91cF92YWx1ZSB8fCAwLFxyXG4vLyAgICAgZXN0aW1hdGVkX2NvbW1pc3Npb25fZGlnaXRzOiBpdGVtLmVzdGltYXRlZF9jb21taXNzaW9uIHx8IDAsXHJcbi8vICAgICBhY3R1YWxfY29tbWlzc2lvbl9kaWdpdHM6IGl0ZW0uY29tbWlzc2lvbl92YWx1ZSB8fCAwLFxyXG4vLyAgICAgdG90YWxfcGFpZF9kaWdpdHM6IGl0ZW0udG90YWxfcGFpZF9hbW91bnQgfHwgMCxcclxuLy8gICAgIHJlcXVpcmVkX2luc3RhbGxtZW50X2RpZ2l0czogaXRlbS5ncm91cF9pZD8ubW9udGhseV9pbnN0YWxsbWVudCB8fCAwLFxyXG4vLyAgICAgZ3JvdXBfdGlja2V0OiBpdGVtPy50aWNrZXQgfHwgMCxcclxuLy8gICAgIG5ldF9jb21taXNzaW9uX3BlcmNlbnRhZ2U6IGl0ZW0/Lmdyb3VwX2lkPy5jb21taXNzaW9uIHx8IDAsXHJcbi8vICAgICBjb21taXNzaW9uX3JlbGVhc2VkOiBpdGVtLmNvbW1pc3Npb25fcmVsZWFzZWQgPyBcIlllc1wiIDogXCJOb1wiLFxyXG4vLyAgICAgdXNlcl9uYW1lOiBpdGVtLnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIk4vQVwiLFxyXG4vLyAgICAgcGhvbmVfbnVtYmVyOiBpdGVtLnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIk4vQVwiLFxyXG4vLyAgICAgZ3JvdXBfbmFtZTogaXRlbS5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIk4vQVwiLFxyXG4vLyAgICAgc3RhcnRfZGF0ZTogaXRlbS5ncm91cF9pZD8uc3RhcnRfZGF0ZVxyXG4vLyAgICAgICA/IG5ldyBEYXRlKGl0ZW0uZ3JvdXBfaWQuc3RhcnRfZGF0ZSk/LnRvSVNPU3RyaW5nKCk/LnNwbGl0KFwiVFwiKT8uWzBdXHJcbi8vICAgICAgIDogXCJOL0FcIixcclxuLy8gICB9KSk7XHJcblxyXG4vLyAgIGNvbnN0IGNvbHVtbnMgPSBbXHJcbi8vICAgICB7IGtleTogXCJ1c2VyX25hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiZ3JvdXBfbmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJncm91cF90aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldCBOb1wiIH0sXHJcbi8vICAgICB7IGtleTogXCJncm91cF92YWx1ZV9kaWdpdHNcIiwgaGVhZGVyOiBcIkdyb3VwIFZhbHVlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInN0YXJ0X2RhdGVcIiwgaGVhZGVyOiBcIlN0YXJ0IERhdGVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwibmV0X2NvbW1pc3Npb25fcGVyY2VudGFnZVwiLCBoZWFkZXI6IFwiTmV0IENvbW1pc3Npb24gUGVyY2VudGFnZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJhY3R1YWxfY29tbWlzc2lvbl9kaWdpdHNcIiwgaGVhZGVyOiBcIk5ldCBDb21taXNzaW9uXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInRvdGFsX3BhaWRfZGlnaXRzXCIsIGhlYWRlcjogXCJUb3RhbCBQYWlkXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInJlcXVpcmVkX2luc3RhbGxtZW50X2RpZ2l0c1wiLCBoZWFkZXI6IFwiUmVxdWlyZWQgSW5zdGFsbG1lbnRcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwiY29tbWlzc2lvbl9yZWxlYXNlZFwiLCBoZWFkZXI6IFwiQ29tbWlzc2lvbiBSZWxlYXNlZFwiIH0sXHJcbi8vICAgXTtcclxuXHJcbi8vICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4vLyAgIGNvbnN0IGN1cnJlbnRNb250aCA9IGAke3RvZGF5LmdldEZ1bGxZZWFyKCl9LSR7U3RyaW5nKFxyXG4vLyAgICAgdG9kYXkuZ2V0TW9udGgoKSArIDFcclxuLy8gICApLnBhZFN0YXJ0KDIsIFwiMFwiKX1gO1xyXG5cclxuLy8gICByZXR1cm4gKFxyXG4vLyAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LXNjcmVlbiBtaW4taC1zY3JlZW4gYmctZ3JheS01MFwiPlxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXhcIj5cclxuLy8gICAgICAgICA8TmF2YmFyIHZpc2liaWxpdHk9e3RydWV9IC8+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC04XCI+XHJcbi8vICAgICAgICAgICB7LyogSGVhZGVyIFNlY3Rpb24gKi99XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLThcIj5cclxuLy8gICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtNHhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbi8vICAgICAgICAgICAgICAgQ29tbWlzc2lvbiBSZXBvcnRzXHJcbi8vICAgICAgICAgICAgIDwvaDE+XHJcbi8vICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgbXQtMlwiPlRyYWNrIGFuZCBtYW5hZ2UgYWdlbnQgY29tbWlzc2lvbnMgYW5kIHBlcmZvcm1hbmNlPC9wPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgey8qIEZpbHRlciBDYXJkICovfVxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHAtOCBtYi04XCI+XHJcbi8vICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi02XCI+UmVwb3J0IEZpbHRlcnM8L2gyPlxyXG5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC02IG1iLTZcIj5cclxuLy8gICAgICAgICAgICAgICB7LyogQWdlbnQgU2VsZWN0ICovfVxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTNcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgU2VsZWN0IEFnZW50XHJcbi8vICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRFbXBsb3llZUlkIHx8IHVuZGVmaW5lZH1cclxuLy8gICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUVtcGxveWVlQ2hhbmdlfVxyXG4vLyAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbi8vICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbi8vICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGJ5IG5hbWUgb3IgcGhvbmVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuLy8gICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBoZWlnaHQ6IFwiNDRweFwiIH19XHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICB7ZW1wbG95ZWVzLm1hcCgoZW1wKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtlbXAuX2lkfSB2YWx1ZT17ZW1wLl9pZH0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7ZW1wLm5hbWV9IC0ge2VtcC5waG9uZV9udW1iZXJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICB7LyogRGF0ZSBTZWxlY3Rpb24gTW9kZSAqL31cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0zXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIERhdGUgU2VsZWN0aW9uXHJcbi8vICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBwLTMgYmctZ3JheS01MCByb3VuZGVkLWxnIGgtMTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPFJhZGlvLkdyb3VwXHJcbi8vICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2RhdGVTZWxlY3Rpb25Nb2RlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RGF0ZVNlbGVjdGlvbk1vZGUoZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPFJhZGlvIHZhbHVlPVwibW9udGhcIiBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+TW9udGg8L1JhZGlvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxSYWRpbyB2YWx1ZT1cImRhdGUtcmFuZ2VcIiBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+UmFuZ2U8L1JhZGlvPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L1JhZGlvLkdyb3VwPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgIHsvKiBEYXRlIFBpY2tlciBGaWVsZHMgKi99XHJcbi8vICAgICAgICAgICAgICAge2RhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCIgPyAoXHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTNcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICBTZWxlY3QgTW9udGhcclxuLy8gICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm1vbnRoXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dGVtcFNlbGVjdGVkTW9udGggfHwgXCJcIn1cclxuLy8gICAgICAgICAgICAgICAgICAgICBtYXg9e2N1cnJlbnRNb250aH1cclxuLy8gICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlVGVtcE1vbnRoQ2hhbmdlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXZpb2xldC01MDAgaC0xMVwiXHJcbi8vICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgICAgPD5cclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTNcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIEZyb20gRGF0ZVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dGVtcEZyb21EYXRlIHx8IFwiXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBtYXg9e3RlbXBUb0RhdGUgfHwgY3VycmVudE1vbnRofVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUZW1wRnJvbURhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHB4LTQgcHktMiBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBoLTExXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTNcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIFRvIERhdGVcclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RlbXBUb0RhdGUgfHwgXCJcIn1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG1pbj17dGVtcEZyb21EYXRlIHx8IFwiXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBtYXg9e2N1cnJlbnRNb250aH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGVtcFRvRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy12aW9sZXQtNTAwIGgtMTFcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPC8+XHJcbi8vICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICB7LyogRmlsdGVyIEJ1dHRvbiAqL31cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kXCI+XHJcbi8vICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgb25DbGljaz17YXBwbHlGaWx0ZXJ9XHJcbi8vICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC04IHB5LTIuNSBiZy12aW9sZXQtNjAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBob3ZlcjpiZy12aW9sZXQtNzAwIHRyYW5zaXRpb24tY29sb3JzIGZvbnQtc2VtaWJvbGQgc2hhZG93LXNtXCJcclxuLy8gICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICBHZW5lcmF0ZSBSZXBvcnRcclxuLy8gICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICB7YWdlbnRMb2FkaW5nID8gKFxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgcHktMjBcIj5cclxuLy8gICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXt0cnVlfSAvPlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICAgIDw+XHJcbi8vICAgICAgICAgICAgICAgey8qIFF1aWNrIExpbmtzICovfVxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPENvbGxhcHNlXHJcbi8vICAgICAgICAgICAgICAgICAgIGl0ZW1zPXtbXHJcbi8vICAgICAgICAgICAgICAgICAgICAge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIFF1aWNrIExpbmtzXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICksXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjaGlsZHJlbjogKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89XCIvdGFyZ2V0LW1lbnUvdGFyZ2V0XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHAtNCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgaG92ZXI6Ym9yZGVyLXZpb2xldC01MDAgaG92ZXI6YmctdmlvbGV0LTUwIHRyYW5zaXRpb24tYWxsIGdyb3VwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlUYXJnZXQgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwIGdyb3VwLWhvdmVyOnNjYWxlLTExMCB0cmFuc2l0aW9uLXRyYW5zZm9ybVwiIHNpemU9ezI0fSAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBncm91cC1ob3Zlcjp0ZXh0LXZpb2xldC02MDBcIj5TZXQgVGFyZ2V0PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89XCIvcmVwb3J0cy90YXJnZXQtaW5jZW50aXZlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHAtNCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgaG92ZXI6Ym9yZGVyLXZpb2xldC01MDAgaG92ZXI6YmctdmlvbGV0LTUwIHRyYW5zaXRpb24tYWxsIGdyb3VwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlsZVRleHRPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDAgZ3JvdXAtaG92ZXI6c2NhbGUtMTEwIHRyYW5zaXRpb24tdHJhbnNmb3JtIHRleHQtbGdcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBncm91cC1ob3Zlcjp0ZXh0LXZpb2xldC02MDBcIj5JbmNlbnRpdmUgUmVwb3J0PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89XCIvdGFyZ2V0LWNvbW1pc3Npb24taW5jZW50aXZlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHAtNCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgaG92ZXI6Ym9yZGVyLXZpb2xldC01MDAgaG92ZXI6YmctdmlvbGV0LTUwIHRyYW5zaXRpb24tYWxsIGdyb3VwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWRQYXltZW50cyBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDAgZ3JvdXAtaG92ZXI6c2NhbGUtMTEwIHRyYW5zaXRpb24tdHJhbnNmb3JtXCIgc2l6ZT17MjR9IC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGdyb3VwLWhvdmVyOnRleHQtdmlvbGV0LTYwMFwiPlBheW91dDwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuLy8gICAgICAgICAgICAgICAgICAgICB9LFxyXG4vLyAgICAgICAgICAgICAgICAgICBdfVxyXG4vLyAgICAgICAgICAgICAgICAgICBkZWZhdWx0QWN0aXZlS2V5PXtbXCIxXCJdfVxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHJvdW5kZWQtbGdcIlxyXG4vLyAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgey8qIEVtcGxveWVlIERldGFpbHMgKi99XHJcbi8vICAgICAgICAgICAgICAge2lzRmlsdGVyQXBwbGllZCAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcC02IG1iLThcIj5cclxuLy8gICAgICAgICAgICAgICAgICAge3NlbGVjdGVkRW1wbG95ZWVJZCAhPT0gXCJBTExcIiAmJiBzZWxlY3RlZEVtcGxveWVlRGV0YWlscyAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi00XCI+QWdlbnQgSW5mb3JtYXRpb248L2gzPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC00IG1iLTZcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlXCI+TmFtZTwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRFbXBsb3llZURldGFpbHMubmFtZSB8fCBcIi1cIn1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHB4LTQgcHktMi41IGJnLWdyYXktNTAgdGV4dC1ncmF5LTkwMCBmb250LW1lZGl1bSBtdC0xXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlXCI+RW1haWw8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzLmVtYWlsIHx8IFwiLVwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yLjUgYmctZ3JheS01MCB0ZXh0LWdyYXktOTAwIGZvbnQtbWVkaXVtIG10LTFcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5QaG9uZTwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRFbXBsb3llZURldGFpbHMucGhvbmVfbnVtYmVyIHx8IFwiLVwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yLjUgYmctZ3JheS01MCB0ZXh0LWdyYXktOTAwIGZvbnQtbWVkaXVtIG10LTFcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTQgbWItNlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5BZGhhYXI8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzLmFkaGFhcl9ubyB8fCBcIi1cIn1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHB4LTQgcHktMi41IGJnLWdyYXktNTAgdGV4dC1ncmF5LTkwMCBmb250LW1lZGl1bSBtdC0xXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlXCI+UEFOPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEVtcGxveWVlRGV0YWlscy5wYW5fbm8gfHwgXCItXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSBiZy1ncmF5LTUwIHRleHQtZ3JheS05MDAgZm9udC1tZWRpdW0gbXQtMVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlBpbmNvZGU8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzLnBpbmNvZGUgfHwgXCItXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSBiZy1ncmF5LTUwIHRleHQtZ3JheS05MDAgZm9udC1tZWRpdW0gbXQtMVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5BZGRyZXNzPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzLmFkZHJlc3MgfHwgXCItXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHB4LTQgcHktMi41IGJnLWdyYXktNTAgdGV4dC1ncmF5LTkwMCBmb250LW1lZGl1bSBtdC0xXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPGhyIGNsYXNzTmFtZT1cIm15LTZcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4vLyAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgey8qIFN1bW1hcnkgU2VjdGlvbiAqL31cclxuLy8gICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG1iLTRcIj5Db21taXNzaW9uIFN1bW1hcnk8L2gzPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tZ3JlZW4tNTAgdG8tZ3JlZW4tMTAwIGJvcmRlciBib3JkZXItZ3JlZW4tMjAwIHJvdW5kZWQtbGcgcC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlXCI+TmV0IEJ1c2luZXNzPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y29tbWlzc2lvblRvdGFsRGV0YWlscz8uYWN0dWFsX2J1c2luZXNzIHx8IFwiLVwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctdHJhbnNwYXJlbnQgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JlZW4tNzAwIG10LTIgYm9yZGVyLTBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tdmlvbGV0LTUwIHRvLXZpb2xldC0xMDAgYm9yZGVyIGJvcmRlci12aW9sZXQtMjAwIHJvdW5kZWQtbGcgcC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlXCI+TmV0IENvbW1pc3Npb24gKDElIGVhY2gpPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y29tbWlzc2lvblRvdGFsRGV0YWlscz8udG90YWxfYWN0dWFsIHx8IFwiLVwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctdHJhbnNwYXJlbnQgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtdmlvbGV0LTcwMCBtdC0yIGJvcmRlci0wXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLXB1cnBsZS01MCB0by1wdXJwbGUtMTAwIGJvcmRlciBib3JkZXItcHVycGxlLTIwMCByb3VuZGVkLWxnIHAtNFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPk5ldCBDdXN0b21lcnM8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb21taXNzaW9uVG90YWxEZXRhaWxzPy50b3RhbF9jdXN0b21lcnMgfHwgXCItXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy10cmFuc3BhcmVudCB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1wdXJwbGUtNzAwIG10LTIgYm9yZGVyLTBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tb3JhbmdlLTUwIHRvLW9yYW5nZS0xMDAgYm9yZGVyIGJvcmRlci1vcmFuZ2UtMjAwIHJvdW5kZWQtbGcgcC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlXCI+TmV0IEdyb3VwczwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvbW1pc3Npb25Ub3RhbERldGFpbHM/LnRvdGFsX2dyb3VwcyB8fCBcIi1cIn1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXRyYW5zcGFyZW50IHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LW9yYW5nZS03MDAgbXQtMiBib3JkZXItMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICl9XHJcblxyXG4vLyAgICAgICAgICAgICAgIHsvKiBUYXJnZXQgRGV0YWlscyAqL31cclxuLy8gICAgICAgICAgICAgICB7aXNGaWx0ZXJBcHBsaWVkICYmXHJcbi8vICAgICAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlSWQgJiZcclxuLy8gICAgICAgICAgICAgICAgIHNlbGVjdGVkRW1wbG95ZWVJZCAhPT0gXCJBTExcIiAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBwLTYgbWItOFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTZcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlRhcmdldCBQZXJmb3JtYW5jZTwvaDM+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7dGFyZ2V0RGF0YS5hY2hpZXZlZCA+PSB0YXJnZXREYXRhLnRhcmdldCAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNCBweS0yIHJvdW5kZWQtbGcgYmctZ3JlZW4tMTAwIGJvcmRlciBib3JkZXItZ3JlZW4tMzAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPEdpUGFydHlQb3BwZXIgc2l6ZT17MjR9IGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTcwMCBmb250LXNlbWlib2xkXCI+VGFyZ2V0IEFjaGlldmVkPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBtZDpncmlkLWNvbHMtNCBnYXAtNCBtYi02XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tdmlvbGV0LTUwIHRvLXZpb2xldC0xMDAgYm9yZGVyIGJvcmRlci12aW9sZXQtMjAwIHJvdW5kZWQtbGcgcC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5UYXJnZXQgU2V0PC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtdmlvbGV0LTcwMCBtdC0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAge2Ake3RhcmdldERhdGEudGFyZ2V0Py50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWdyZWVuLTUwIHRvLWdyZWVuLTEwMCBib3JkZXIgYm9yZGVyLWdyZWVuLTIwMCByb3VuZGVkLWxnIHAtNFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlXCI+QWNoaWV2ZWQ8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmVlbi03MDAgbXQtMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHtgJHt0YXJnZXREYXRhLmFjaGlldmVkPy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWFtYmVyLTUwIHRvLWFtYmVyLTEwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCByb3VuZGVkLWxnIHAtNFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlXCI+RGlmZmVyZW5jZTwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTcwMCBtdC0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAge2Akeyh0YXJnZXREYXRhLmRpZmZlcmVuY2U/PyBcIjBcIik/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tZW1lcmFsZC01MCB0by1lbWVyYWxkLTEwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwIHJvdW5kZWQtbGcgcC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5Ub3RhbCBQYXlhYmxlIENvbW1pc3Npb248L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTcwMCBtdC0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAge2Ake3RhcmdldERhdGEudGFyZ2V0Q29tbWlzc2lvbi50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1gfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy12aW9sZXQtNTAgYm9yZGVyIGJvcmRlci12aW9sZXQtMjAwIHJvdW5kZWQtbGcgcC01XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC12aW9sZXQtODAwIG1iLTNcIj5Db21taXNzaW9uIEJyZWFrZG93bjwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgYmctdmlvbGV0LTYwMCByb3VuZGVkLWZ1bGxcIj48L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+VXAgdG8gdGFyZ2V0ICgwLjUlKTogeyhNYXRoLm1pbih0YXJnZXREYXRhLmFjaGlldmVkLCB0YXJnZXREYXRhLnRhcmdldCkgKiAwLjAwNSkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5pbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB7dGFyZ2V0RGF0YS5hY2hpZXZlZCA+IHRhcmdldERhdGEudGFyZ2V0ICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTIgaC0yIGJnLWdyZWVuLTYwMCByb3VuZGVkLWZ1bGxcIj48L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5CZXlvbmQgdGFyZ2V0ICgxJSk6IHsoKHRhcmdldERhdGEuYWNoaWV2ZWQgLSB0YXJnZXREYXRhLnRhcmdldCkgKiAwLjAxKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX08L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvdWw+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgKX1cclxuXHJcbi8vICAgICAgICAgICAgICAgey8qIERhdGEgVGFibGUgKi99XHJcbi8vICAgICAgICAgICAgICAge2xvYWRpbmcgPyAoXHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgcHktMjBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGlzTG9hZGluZz17dHJ1ZX0gLz5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICkgOiBlbXBsb3llZUN1c3RvbWVyRGF0YS5sZW5ndGggPiAwID8gKFxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIG92ZXJmbG93LWhpZGRlblwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbi8vICAgICAgICAgICAgICAgICAgICAgZGF0YT17cHJvY2Vzc2VkVGFibGVEYXRhfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPXtgQ29tbWlzc2lvbiBSZXBvcnRgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgXCJOYW1lXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBcIlBob25lIE51bWJlclwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgXCJNb250aFwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgXCJUYXJnZXQgU2V0XCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBcIkFjaGlldmVkXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBcIlJlbWFpbmluZ1wiLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgXCJUb3RhbCBQYXlhYmxlIENvbW1pc3Npb25cIixcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIFwiQWN0dWFsIEJ1c2luZXNzXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBcIkFjdHVhbCBDb21taXNzaW9uXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBcIkdyb3NzIEJ1c2luZXNzXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBcIkdyb3NzIENvbW1pc3Npb25cIixcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIFwiVG90YWwgQ3VzdG9tZXJzXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBcIlRvdGFsIEdyb3Vwc1wiLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIF19XHJcbi8vICAgICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJWYWx1ZXM9e1tcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkRW1wbG95ZWVJZCA9PT0gXCJBTExcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiQWxsIEVtcGxveWVlc1wiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDogc2VsZWN0ZWRFbXBsb3llZURldGFpbHM/Lm5hbWUgfHwgXCItXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlSWQgPT09IFwiQUxMXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPyBcIi1cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA6IHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzPy5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBpc0ZpbHRlckFwcGxpZWRcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPyBkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBuZXcgRGF0ZShgJHtzZWxlY3RlZE1vbnRofS0wMWApLnRvTG9jYWxlU3RyaW5nKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImRlZmF1bHRcIixcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vbnRoOiBcImxvbmdcIixcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB5ZWFyOiBcIm51bWVyaWNcIixcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDogYCR7bmV3IERhdGUoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBGcm9tRGF0ZVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZURhdGVTdHJpbmcoKX0gLSAke25ldyBEYXRlKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wVG9EYXRlXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICApLnRvTG9jYWxlRGF0ZVN0cmluZygpfWBcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgOiBcIi1cIixcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGAke3RhcmdldERhdGE/LnRhcmdldD8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKSB8fCBcIjBcIn1gLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgYCR7dGFyZ2V0RGF0YT8uYWNoaWV2ZWQ/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIikgfHwgXCIwXCJ9YCxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGAke1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXREYXRhPy5yZW1haW5pbmc/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIikgfHwgXCIwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIH1gLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgYCR7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldERhdGE/LnRhcmdldENvbW1pc3Npb24/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIiwge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhpbXVtRnJhY3Rpb25EaWdpdHM6IDIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIH0pIHx8IFwiMC4wMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB9YCxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGAke1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBjb21taXNzaW9uVG90YWxEZXRhaWxzPy5hY3R1YWxfYnVzaW5lc3M/LnRvTG9jYWxlU3RyaW5nKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZW4tSU5cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICApIHx8IFwiMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB9YCxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGAke1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBjb21taXNzaW9uVG90YWxEZXRhaWxzPy50b3RhbF9hY3R1YWw/LnRvTG9jYWxlU3RyaW5nKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZW4tSU5cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICApIHx8IFwiMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB9YCxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGAke1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBjb21taXNzaW9uVG90YWxEZXRhaWxzPy5leHBlY3RlZF9idXNpbmVzcz8udG9Mb2NhbGVTdHJpbmcoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbi1JTlwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICkgfHwgXCIwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIH1gLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgYCR7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGNvbW1pc3Npb25Ub3RhbERldGFpbHM/LnRvdGFsX2VzdGltYXRlZD8udG9Mb2NhbGVTdHJpbmcoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbi1JTlwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICkgfHwgXCIwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIH1gLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgY29tbWlzc2lvblRvdGFsRGV0YWlscz8udG90YWxfY3VzdG9tZXJzIHx8IFwiMFwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgY29tbWlzc2lvblRvdGFsRGV0YWlscz8udG90YWxfZ3JvdXBzIHx8IFwiMFwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIF19XHJcbi8vICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YENvbW1pc3Npb25SZXBvcnQtJHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzPy5uYW1lIHx8IFwiYWxsXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICB9LSR7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBpc0ZpbHRlckFwcGxpZWRcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPyBkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBzZWxlY3RlZE1vbnRoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBgJHt0ZW1wRnJvbURhdGV9X3RvXyR7dGVtcFRvRGF0ZX1gXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJ1bmZpbHRlcmVkXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICB9LmNzdmB9XHJcbi8vICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgICAgaXNGaWx0ZXJBcHBsaWVkICYmXHJcbi8vICAgICAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ubmFtZSAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBwLTEyIHRleHQtY2VudGVyXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LWxnIGZvbnQtbWVkaXVtXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBObyBjb21taXNzaW9uIGRhdGEgZm91bmQgZm9yIHRoZSBzZWxlY3RlZCBwZXJpb2QuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIClcclxuLy8gICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICA8Lz5cclxuLy8gICAgICAgICAgICl9XHJcblxyXG4vLyAgICAgICAgICAgey8qIENvbW1pc3Npb24gTW9kYWwgKi99XHJcbi8vICAgICAgICAgICA8TW9kYWxcclxuLy8gICAgICAgICAgICAgaXNWaXNpYmxlPXtzaG93Q29tbWlzc2lvbk1vZGFsfVxyXG4vLyAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTaG93Q29tbWlzc2lvbk1vZGFsKGZhbHNlKX1cclxuLy8gICAgICAgICAgICAgd2lkdGg9XCJtYXgtdy1tZFwiXHJcbi8vICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02XCI+XHJcbi8vICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgYm9yZGVyLWIgcGItNCBtYi02XCI+XHJcbi8vICAgICAgICAgICAgICAgICBBZGQgQ29tbWlzc2lvbiBQYXltZW50XHJcbi8vICAgICAgICAgICAgICAgPC9oMz5cclxuLy8gICAgICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTVcIiBvblN1Ym1pdD17aGFuZGxlQ29tbWlzc2lvblN1Ym1pdH0+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIEFnZW50IE5hbWVcclxuLy8gICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbi8vICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgZW1wbG95ZWVzLmZpbmQoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIChlbXApID0+IGVtcC5faWQgPT09IGNvbW1pc3Npb25Gb3JtLmFnZW50X2lkXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICApPy5uYW1lIHx8IFwiXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSBiZy1ncmF5LTUwIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBEYXRlXHJcbi8vICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGF5X2RhdGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb21taXNzaW9uRm9ybS5wYXlfZGF0ZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ29tbWlzc2lvbkNoYW5nZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHB4LTQgcHktMi41IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy12aW9sZXQtNTAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICBUb3RhbCBQYXlhYmxlIENvbW1pc3Npb25cclxuLy8gICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbi8vICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Ake2NvbW1pc3Npb25Gb3JtLmFtb3VudCB8fCBcIjAuMDBcIn1gfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yLjUgYmctZ3JheS01MCB0ZXh0LWdyZWVuLTcwMCBmb250LWJvbGRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIFBheW1lbnQgTW9kZVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBheV90eXBlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y29tbWlzc2lvbkZvcm0ucGF5X3R5cGV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNvbW1pc3Npb25DaGFuZ2V9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdmlvbGV0LTUwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY2FzaFwiPkNhc2g8L29wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwib25saW5lXCI+T25saW5lPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNoZXF1ZVwiPkNoZXF1ZTwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJiYW5rX3RyYW5zZmVyXCI+QmFuayBUcmFuc2Zlcjwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAge2NvbW1pc3Npb25Gb3JtLnBheV90eXBlID09PSBcIm9ubGluZVwiICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgVHJhbnNhY3Rpb24gSURcclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInRyYW5zYWN0aW9uX2lkXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb21taXNzaW9uRm9ybS50cmFuc2FjdGlvbl9pZH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDb21taXNzaW9uQ2hhbmdlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdmlvbGV0LTUwMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnRyYW5zYWN0aW9uX2lkICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy50cmFuc2FjdGlvbl9pZH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuLy8gICAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIE5vdGVcclxuLy8gICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgPHRleHRhcmVhXHJcbi8vICAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm5vdGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb21taXNzaW9uRm9ybS5ub3RlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDb21taXNzaW9uQ2hhbmdlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yLjUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXZpb2xldC01MDAgcmVzaXplLW5vbmVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHJvd3M9XCIzXCJcclxuLy8gICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zIHB0LTQgYm9yZGVyLXRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dDb21taXNzaW9uTW9kYWwoZmFsc2UpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTYgcHktMi41IGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyB0ZXh0LWdyYXktNzAwIGZvbnQtc2VtaWJvbGQgaG92ZXI6YmctZ3JheS01MCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbi8vICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICBDYW5jZWxcclxuLy8gICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC02IHB5LTIuNSBiZy12aW9sZXQtNjAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBmb250LXNlbWlib2xkIGhvdmVyOmJnLXZpb2xldC03MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgU2F2ZSBQYXltZW50XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDwvTW9kYWw+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgIDwvZGl2PlxyXG4vLyAgICAgPC9kaXY+XHJcbi8vICAgKTtcclxuLy8gfTtcclxuXHJcbi8vIGV4cG9ydCBkZWZhdWx0IFRhcmdldENvbW1pc3Npb247XHJcblxyXG5cclxuaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgU2VsZWN0LCBSYWRpbywgVGFicyB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IHsgR2lQYXJ0eVBvcHBlciB9IGZyb20gXCJyZWFjdC1pY29ucy9naVwiO1xyXG5pbXBvcnQgeyBGaWxlVGV4dE91dGxpbmVkLCBEb2xsYXJPdXRsaW5lZCB9IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5pbXBvcnQgeyBGYU1vbmV5QmlsbCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyBNZFBheW1lbnRzIH0gZnJvbSBcInJlYWN0LWljb25zL21kXCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBGaVRhcmdldCB9IGZyb20gXCJyZWFjdC1pY29ucy9maVwiO1xyXG5pbXBvcnQgeyBudW1iZXJUb0luZGlhbldvcmRzIH0gZnJvbSBcIi4uL2hlbHBlcnMvbnVtYmVyVG9JbmRpYW5Xb3Jkc1wiO1xyXG5cclxuY29uc3QgeyBUYWJQYW5lIH0gPSBUYWJzO1xyXG5cclxuY29uc3QgVGFyZ2V0Q29tbWlzc2lvbiA9ICgpID0+IHtcclxuICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEVtcGxveWVlSWQsIHNldFNlbGVjdGVkRW1wbG95ZWVJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc2VsZWN0ZWRNb250aCwgc2V0U2VsZWN0ZWRNb250aF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZGF0ZVNlbGVjdGlvbk1vZGUsIHNldERhdGVTZWxlY3Rpb25Nb2RlXSA9IHVzZVN0YXRlKFwibW9udGhcIik7XHJcbiAgY29uc3QgW2FnZW50TG9hZGluZywgc2V0QWdlbnRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VsZWN0ZWRFbXBsb3llZURldGFpbHMsIHNldFNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtlbXBsb3llZUN1c3RvbWVyRGF0YSwgc2V0RW1wbG95ZWVDdXN0b21lckRhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtjb21taXNzaW9uVG90YWxEZXRhaWxzLCBzZXRDb21taXNzaW9uVG90YWxEZXRhaWxzXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dDb21taXNzaW9uTW9kYWwsIHNldFNob3dDb21taXNzaW9uTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjb21taXNzaW9uRm9ybSwgc2V0Q29tbWlzc2lvbkZvcm1dID0gdXNlU3RhdGUoe1xyXG4gICAgYWdlbnRfaWQ6IFwiXCIsXHJcbiAgICBwYXlfZGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXSxcclxuICAgIGFtb3VudDogXCJcIixcclxuICAgIHBheV90eXBlOiBcImNhc2hcIixcclxuICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgbm90ZTogXCJcIixcclxuICAgIHBheV9mb3I6IFwiY29tbWlzc2lvblwiLFxyXG4gICAgYWRtaW5fdHlwZTogXCJcIixcclxuICB9KTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFthZG1pbklkLCBzZXRBZG1pbklkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFthZG1pbk5hbWUsIHNldEFkbWluTmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbdGFyZ2V0RGF0YSwgc2V0VGFyZ2V0RGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICB0YXJnZXQ6IDAsXHJcbiAgICBhY2hpZXZlZDogMCxcclxuICAgIHJlbWFpbmluZzogMCxcclxuICAgIHN0YXJ0RGF0ZTogXCJcIixcclxuICAgIGVuZERhdGU6IFwiXCIsXHJcbiAgICB0YXJnZXRDb21taXNzaW9uOiAwLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFt0ZW1wU2VsZWN0ZWRNb250aCwgc2V0VGVtcFNlbGVjdGVkTW9udGhdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3RlbXBGcm9tRGF0ZSwgc2V0VGVtcEZyb21EYXRlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFt0ZW1wVG9EYXRlLCBzZXRUZW1wVG9EYXRlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtpc0ZpbHRlckFwcGxpZWQsIHNldElzRmlsdGVyQXBwbGllZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKFwiY29tbWlzc2lvblwiKTtcclxuICBjb25zdCBbZ3Jvc3NDb21taXNzaW9uRGF0YSwgc2V0R3Jvc3NDb21taXNzaW9uRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2dyb3NzQ29tbWlzc2lvblN1bW1hcnksIHNldEdyb3NzQ29tbWlzc2lvblN1bW1hcnldID0gdXNlU3RhdGUoe1xyXG4gICAgdG90YWxfZ3Jvc3NfaW5jZW50aXZlX3ZhbHVlOiAwLFxyXG4gICAgdG90YWxfZ3Jvc3NfZ3JvdXBfdmFsdWU6IDAsXHJcbiAgICB0b3RhbF9ncm9zc19lbnJvbGxtZW50czogMCxcclxuICB9KTtcclxuXHJcbiAgLy8g4pyFIEhlbHBlciB0byBzYW5pdGl6ZSBzdHJpbmcgYW1vdW50cyB0byBudW1iZXJzIGZvciB3b3JkIGNvbnZlcnNpb25cclxuICBjb25zdCBwYXJzZUFtb3VudCA9ICh2YWwpID0+XHJcbiAgICBwYXJzZUZsb2F0KHZhbD8udG9TdHJpbmcoKS5yZXBsYWNlKC9bXjAtOS4tXSsvZywgXCJcIikpIHx8IDA7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgICBjb25zdCBjdXJyZW50TW9udGggPSBgJHt0b2RheS5nZXRGdWxsWWVhcigpfS0ke1N0cmluZyhcclxuICAgICAgdG9kYXkuZ2V0TW9udGgoKSArIDFcclxuICAgICkucGFkU3RhcnQoMiwgXCIwXCIpfWA7XHJcbiAgICBzZXRUZW1wU2VsZWN0ZWRNb250aChjdXJyZW50TW9udGgpO1xyXG4gICAgY29uc3QgeWVhciA9IHRvZGF5LmdldEZ1bGxZZWFyKCk7XHJcbiAgICBjb25zdCBtb250aCA9IHRvZGF5LmdldE1vbnRoKCkgKyAxO1xyXG4gICAgY29uc3QgZmlyc3REYXkgPSBgJHt5ZWFyfS0ke1N0cmluZyhtb250aCkucGFkU3RhcnQoMiwgXCIwXCIpfS0wMWA7XHJcbiAgICBjb25zdCBsYXN0ZGF5MSA9IG5ldyBEYXRlKHllYXIsIG1vbnRoLCAwKS5nZXREYXRlKCk7XHJcbiAgICBjb25zdCBsYXN0RGF5ID0gYCR7eWVhcn0tJHttb250aH0tJHtTdHJpbmcobGFzdGRheTEpLnBhZFN0YXJ0KDIsIFwiMFwiKX1gO1xyXG4gICAgc2V0VGVtcEZyb21EYXRlKGZpcnN0RGF5KTtcclxuICAgIHNldFRlbXBUb0RhdGUobGFzdERheSk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpKTtcclxuICAgIGlmICh1c2VyKSB7XHJcbiAgICAgIHNldEFkbWluSWQodXNlci5faWQpO1xyXG4gICAgICBzZXRBZG1pbk5hbWUodXNlci5uYW1lIHx8IFwiXCIpO1xyXG4gICAgfVxyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2FnZW50L2dldFwiKTtcclxuICAgICAgc2V0RW1wbG95ZWVzKHJlcz8uZGF0YT8uYWdlbnQpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbXBsb3llZXM6XCIsIGVycik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hDb21taXNzaW9uUmVwb3J0ID0gYXN5bmMgKGVtcGxveWVlSWQsIHN0YXJ0RGF0ZSwgZW5kRGF0ZSkgPT4ge1xyXG4gICAgaWYgKCFlbXBsb3llZUlkIHx8ICFzdGFydERhdGUgfHwgIWVuZERhdGUpIHJldHVybjtcclxuICAgIGNvbnN0IGFib3J0Q29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcclxuICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBwYXJhbXMgPSB7XHJcbiAgICAgICAgc3RhcnRfZGF0ZTogc3RhcnREYXRlLFxyXG4gICAgICAgIGVuZF9kYXRlOiBlbmREYXRlLFxyXG4gICAgICB9O1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KGAvZW5yb2xsL2FnZW50LyR7ZW1wbG95ZWVJZH0vY29tbWlzc2lvbmAsIHtcclxuICAgICAgICBwYXJhbXMsXHJcbiAgICAgICAgc2lnbmFsOiBhYm9ydENvbnRyb2xsZXIuc2lnbmFsLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0RW1wbG95ZWVDdXN0b21lckRhdGEocmVzLmRhdGE/LmNvbW1pc3Npb25EYXRhKTtcclxuICAgICAgc2V0Q29tbWlzc2lvblRvdGFsRGV0YWlscyh7XHJcbiAgICAgICAgYWN0dWFsX2J1c2luZXNzOiByZXMuZGF0YT8uY29tbWlzc2lvblN1bW1hcnk/LnRvdGFsX2dyb3VwX3ZhbHVlLFxyXG4gICAgICAgIHRvdGFsX2FjdHVhbDogcmVzLmRhdGE/LmNvbW1pc3Npb25TdW1tYXJ5Py50b3RhbF9jb21taXNzaW9uX3ZhbHVlLFxyXG4gICAgICAgIHRvdGFsX2N1c3RvbWVyczogcmVzLmRhdGE/LmNvbW1pc3Npb25TdW1tYXJ5Py50b3RhbF9lbnJvbGxtZW50cyxcclxuICAgICAgICB0b3RhbF9ncm91cHM6IHJlcy5kYXRhPy5jb21taXNzaW9uU3VtbWFyeT8udG90YWxfZW5yb2xsbWVudHMsXHJcbiAgICAgICAgZXhwZWN0ZWRfYnVzaW5lc3M6IHJlcy5kYXRhPy5jb21taXNzaW9uU3VtbWFyeT8udG90YWxfZ3JvdXBfdmFsdWUsXHJcbiAgICAgICAgdG90YWxfZXN0aW1hdGVkOiByZXMuZGF0YT8uY29tbWlzc2lvblN1bW1hcnk/LnRvdGFsX2NvbW1pc3Npb25fdmFsdWUsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGlmIChlcnIubmFtZSAhPT0gXCJBYm9ydENvbnRyb2xsZXJcIikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbXBsb3llZSByZXBvcnQ6XCIsIGVycik7XHJcbiAgICAgICAgc2V0RW1wbG95ZWVDdXN0b21lckRhdGEoW10pO1xyXG4gICAgICAgIHNldENvbW1pc3Npb25Ub3RhbERldGFpbHMoe30pO1xyXG4gICAgICB9XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBpZiAoIWFib3J0Q29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkge1xyXG4gICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hHcm9zc0luY2VudGl2ZVJlcG9ydCA9IGFzeW5jIChlbXBsb3llZUlkLCBzdGFydERhdGUsIGVuZERhdGUpID0+IHtcclxuICAgIGlmICghZW1wbG95ZWVJZCB8fCAhc3RhcnREYXRlIHx8ICFlbmREYXRlKSByZXR1cm47XHJcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgbGV0IHBhcmFtcyA9IHtcclxuICAgICAgICBzdGFydF9kYXRlOiBzdGFydERhdGUsXHJcbiAgICAgICAgZW5kX2RhdGU6IGVuZERhdGUsXHJcbiAgICAgIH07XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgYC9lbnJvbGwvYWdlbnQvJHtlbXBsb3llZUlkfS9ncm9zcy1jb21taXNzaW9uYCxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBwYXJhbXMsXHJcbiAgICAgICAgfVxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCBjb21taXNzaW9uRGF0YSA9IHJlcy5kYXRhPy5ncm9zc0NvbW1pc3Npb25JbmZvPy5tYXAoKGVucm9sbG1lbnQpID0+ICh7XHJcbiAgICAgICAgdXNlcl9uYW1lOiBlbnJvbGxtZW50Py51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICBwaG9uZV9udW1iZXI6IGVucm9sbG1lbnQ/LnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIk4vQVwiLFxyXG4gICAgICAgIGdyb3VwX25hbWU6IGVucm9sbG1lbnQ/Lmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgZ3JvdXBfdmFsdWU6IGVucm9sbG1lbnQ/Lmdyb3VwX2lkPy5ncm91cF92YWx1ZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgIGdyb3VwX2NvbW1pc3Npb246IGVucm9sbG1lbnQ/Lmdyb3VwX2lkPy5jb21taXNzaW9uIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgZ3JvdXBfdGlja2V0OiBlbnJvbGxtZW50Py50aWNrZXRzIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgZW5yb2xsbWVudF9kYXRlOiBlbnJvbGxtZW50Py5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKT8uWzBdLFxyXG4gICAgICAgIHRvdGFsX3BhaWRfYW1vdW50OiBlbnJvbGxtZW50Py50b3RhbF9wYWlkX2Ftb3VudCB8fCBcIjBcIixcclxuICAgICAgICBncm91cF9tb250aGx5X2luc3RhbGxtZW50OlxyXG4gICAgICAgICAgZW5yb2xsbWVudD8uZ3JvdXBfaWQ/Lm1vbnRobHlfaW5zdGFsbG1lbnQgfHwgXCJOL0FcIixcclxuICAgICAgfSkpO1xyXG4gICAgICBzZXRHcm9zc0NvbW1pc3Npb25EYXRhKGNvbW1pc3Npb25EYXRhIHx8IFtdKTtcclxuICAgICAgc2V0R3Jvc3NDb21taXNzaW9uU3VtbWFyeShyZXMuZGF0YS5ncm9zc0NvbW1pc3Npb25TdW1tYXJ5IHx8IHtcclxuICAgICAgICB0b3RhbF9ncm9zc19jb21taXNzaW9uX3ZhbHVlOiAwLFxyXG4gICAgICAgIHRvdGFsX2dyb3NzX2dyb3VwX3ZhbHVlOiAwLFxyXG4gICAgICAgIHRvdGFsX2dyb3NzX2Vucm9sbG1lbnRzOiAwLFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3Jvc3MgaW5jZW50aXZlIHJlcG9ydDpcIiwgZXJyKTtcclxuICAgICAgc2V0R3Jvc3NDb21taXNzaW9uRGF0YShbXSk7XHJcbiAgICAgIHNldEdyb3NzQ29tbWlzc2lvblN1bW1hcnkoe1xyXG4gICAgICAgIHRvdGFsX2dyb3NzX2NvbW1pc3Npb25fdmFsdWU6IDAsXHJcbiAgICAgICAgdG90YWxfZ3Jvc3NfZ3JvdXBfdmFsdWU6IDAsXHJcbiAgICAgICAgdG90YWxfZ3Jvc3NfZW5yb2xsbWVudHM6IDAsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY2FsY3VsYXRlVGFyZ2V0Q29tbWlzc2lvbiA9IChhY2hpZXZlZEJ1c2luZXNzLCB0YXJnZXRBbW91bnQpID0+IHtcclxuICAgIGNvbnN0IGFjaGlldmVkTnVtID1cclxuICAgICAgdHlwZW9mIGFjaGlldmVkQnVzaW5lc3MgPT09IFwic3RyaW5nXCJcclxuICAgICAgICA/IE51bWJlcihhY2hpZXZlZEJ1c2luZXNzLnJlcGxhY2UoL1teMC05Li1dKy9nLCBcIlwiKSlcclxuICAgICAgICA6IGFjaGlldmVkQnVzaW5lc3M7XHJcbiAgICBjb25zdCB0YXJnZXROdW0gPVxyXG4gICAgICB0eXBlb2YgdGFyZ2V0QW1vdW50ID09PSBcInN0cmluZ1wiXHJcbiAgICAgICAgPyBOdW1iZXIodGFyZ2V0QW1vdW50LnJlcGxhY2UoL1teMC05Li1dKy9nLCBcIlwiKSlcclxuICAgICAgICA6IHRhcmdldEFtb3VudDtcclxuICAgIGlmIChhY2hpZXZlZE51bSA8PSB0YXJnZXROdW0pIHtcclxuICAgICAgcmV0dXJuIGFjaGlldmVkTnVtICogMC4wMDU7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCB1cFRvVGFyZ2V0ID0gdGFyZ2V0TnVtICogMC4wMDU7XHJcbiAgICAgIGNvbnN0IGJleW9uZFRhcmdldCA9IChhY2hpZXZlZE51bSAtIHRhcmdldE51bSkgKiAwLjAxO1xyXG4gICAgICByZXR1cm4gdXBUb1RhcmdldCArIGJleW9uZFRhcmdldDtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaFRhcmdldERhdGEgPSBhc3luYyAoZW1wbG95ZWVJZCwgc3RhcnREYXRlLCBlbmREYXRlKSA9PiB7XHJcbiAgICBpZiAoIWVtcGxveWVlSWQgfHwgIXN0YXJ0RGF0ZSB8fCAhZW5kRGF0ZSkgcmV0dXJuO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgYWJvcnRDb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xyXG4gICAgICBjb25zdCB0YXJnZXRSZXMgPSBhd2FpdCBhcGkuZ2V0KGAvdGFyZ2V0L2FnZW50cy8ke2VtcGxveWVlSWR9YCwge1xyXG4gICAgICAgIHBhcmFtczogeyBzdGFydF9kYXRlOiBzdGFydERhdGUsIGVuZF9kYXRlOiBlbmREYXRlIH0sXHJcbiAgICAgICAgc2lnbmFsOiBhYm9ydENvbnRyb2xsZXIuc2lnbmFsLFxyXG4gICAgICB9KTtcclxuICAgICAgY29uc3QgdGFyZ2V0Rm9yTW9udGggPSB0YXJnZXRSZXMuZGF0YT8udG90YWxfdGFyZ2V0IHx8IDA7XHJcbiAgICAgIGNvbnN0IHsgZGF0YTogY29tbSB9ID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL2Vucm9sbC9hZ2VudC8ke2VtcGxveWVlSWR9L2NvbW1pc3Npb25gLFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIHBhcmFtczogeyBzdGFydF9kYXRlOiBzdGFydERhdGUsIGVuZF9kYXRlOiBlbmREYXRlIH0sXHJcbiAgICAgICAgICBzaWduYWw6IGFib3J0Q29udHJvbGxlci5zaWduYWwsXHJcbiAgICAgICAgfVxyXG4gICAgICApO1xyXG4gICAgICBsZXQgYWNoaWV2ZWQgPSBjb21tPy5jb21taXNzaW9uU3VtbWFyeT8udG90YWxfZ3JvdXBfdmFsdWUgfHwgMDtcclxuICAgICAgaWYgKHR5cGVvZiBhY2hpZXZlZCA9PT0gXCJzdHJpbmdcIikge1xyXG4gICAgICAgIGFjaGlldmVkID0gTnVtYmVyKGFjaGlldmVkLnJlcGxhY2UoL1teMC05Li1dKy9nLCBcIlwiKSk7XHJcbiAgICAgIH1cclxuICAgICAgY29uc3QgcmVtYWluaW5nID0gTWF0aC5tYXgodGFyZ2V0Rm9yTW9udGggLSBhY2hpZXZlZCwgMCk7XHJcbiAgICAgIGNvbnN0IGRpZmZlcmVuY2UgPSB0YXJnZXRGb3JNb250aCAtIGFjaGlldmVkO1xyXG4gICAgICBjb25zdCB0YXJnZXRDb21taXNzaW9uID0gY2FsY3VsYXRlVGFyZ2V0Q29tbWlzc2lvbihcclxuICAgICAgICBhY2hpZXZlZCxcclxuICAgICAgICB0YXJnZXRGb3JNb250aFxyXG4gICAgICApO1xyXG4gICAgICBzZXRUYXJnZXREYXRhKHtcclxuICAgICAgICB0YXJnZXQ6IE1hdGgucm91bmQodGFyZ2V0Rm9yTW9udGgpLFxyXG4gICAgICAgIGFjaGlldmVkLFxyXG4gICAgICAgIHJlbWFpbmluZyxcclxuICAgICAgICBkaWZmZXJlbmNlLFxyXG4gICAgICAgIHN0YXJ0RGF0ZTogc3RhcnREYXRlLFxyXG4gICAgICAgIGVuZERhdGU6IGVuZERhdGUsXHJcbiAgICAgICAgdGFyZ2V0Q29tbWlzc2lvbixcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgaWYgKGVyci5uYW1lICE9PSBcIkFib3J0RXJyb3JcIikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB0YXJnZXQgZGF0YTpcIiwgZXJyKTtcclxuICAgICAgICBzZXRUYXJnZXREYXRhKHtcclxuICAgICAgICAgIHRhcmdldDogMCxcclxuICAgICAgICAgIGFjaGlldmVkOiAwLFxyXG4gICAgICAgICAgcmVtYWluaW5nOiAwLFxyXG4gICAgICAgICAgZGlmZmVyZW5jZTogMCxcclxuICAgICAgICAgIHN0YXJ0RGF0ZTogXCJcIixcclxuICAgICAgICAgIGVuZERhdGU6IFwiXCIsXHJcbiAgICAgICAgICB0YXJnZXRDb21taXNzaW9uOiAwLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hBbGxDb21taXNzaW9uUmVwb3J0ID0gYXN5bmMgKHN0YXJ0RGF0ZSwgZW5kRGF0ZSkgPT4ge1xyXG4gICAgaWYgKCFzdGFydERhdGUgfHwgIWVuZERhdGUpIHJldHVybjtcclxuICAgIGNvbnN0IGFib3J0Q29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcclxuICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBwYXJhbXMgPSB7XHJcbiAgICAgICAgc3RhcnRfZGF0ZTogc3RhcnREYXRlLFxyXG4gICAgICAgIGVuZF9kYXRlOiBlbmREYXRlLFxyXG4gICAgICB9O1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2Vucm9sbC9jb21taXNzaW9uXCIsIHtcclxuICAgICAgICBwYXJhbXMsXHJcbiAgICAgICAgc2lnbmFsOiBhYm9ydENvbnRyb2xsZXIuc2lnbmFsLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0RW1wbG95ZWVDdXN0b21lckRhdGEocmVzLmRhdGE/LmNvbW1pc3Npb25EYXRhKTtcclxuICAgICAgc2V0Q29tbWlzc2lvblRvdGFsRGV0YWlscyh7XHJcbiAgICAgICAgYWN0dWFsX2J1c2luZXNzOiByZXMuZGF0YT8uY29tbWlzc2lvblN1bW1hcnk/LnRvdGFsX2dyb3VwX3ZhbHVlLFxyXG4gICAgICAgIHRvdGFsX2FjdHVhbDogcmVzLmRhdGE/LmNvbW1pc3Npb25TdW1tYXJ5Py50b3RhbF9jb21taXNzaW9uX3ZhbHVlLFxyXG4gICAgICAgIHRvdGFsX2N1c3RvbWVyczogcmVzLmRhdGE/LmNvbW1pc3Npb25TdW1tYXJ5Py50b3RhbF9lbnJvbGxtZW50cyxcclxuICAgICAgICB0b3RhbF9ncm91cHM6IHJlcy5kYXRhPy5jb21taXNzaW9uU3VtbWFyeT8udG90YWxfZW5yb2xsbWVudHMsXHJcbiAgICAgICAgZXhwZWN0ZWRfYnVzaW5lc3M6IHJlcy5kYXRhPy5jb21taXNzaW9uU3VtbWFyeT8udG90YWxfZ3JvdXBfdmFsdWUsXHJcbiAgICAgICAgdG90YWxfZXN0aW1hdGVkOiByZXMuZGF0YT8uY29tbWlzc2lvblN1bW1hcnk/LnRvdGFsX2NvbW1pc3Npb25fdmFsdWUsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGlmIChlcnIubmFtZSAhPT0gXCJBYm9ydEVycm9yXCIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYWxsIGNvbW1pc3Npb24gcmVwb3J0OlwiLCBlcnIpO1xyXG4gICAgICAgIHNldEVtcGxveWVlQ3VzdG9tZXJEYXRhKFtdKTtcclxuICAgICAgICBzZXRDb21taXNzaW9uVG90YWxEZXRhaWxzKHt9KTtcclxuICAgICAgfVxyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgaWYgKCFhYm9ydENvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHtcclxuICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoQWxsR3Jvc3NJbmNlbnRpdmVSZXBvcnQgPSBhc3luYyAoc3RhcnREYXRlLCBlbmREYXRlKSA9PiB7XHJcbiAgICBpZiAoIXN0YXJ0RGF0ZSB8fCAhZW5kRGF0ZSkgcmV0dXJuO1xyXG4gICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGxldCBwYXJhbXMgPSB7XHJcbiAgICAgICAgc3RhcnRfZGF0ZTogc3RhcnREYXRlLFxyXG4gICAgICAgIGVuZF9kYXRlOiBlbmREYXRlLFxyXG4gICAgICB9O1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2Vucm9sbC9ncm9zcy1pbmNlbnRpdmVcIiwge1xyXG4gICAgICAgIHBhcmFtcyxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldEdyb3NzQ29tbWlzc2lvbkRhdGEocmVzLmRhdGEuZ3Jvc3NJbmNlbnRpdmVJbmZvIHx8IFtdKTtcclxuICAgICAgc2V0R3Jvc3NDb21taXNzaW9uU3VtbWFyeShyZXMuZGF0YS5ncm9zc0NvbW1pc3Npb25TdW1tYXJ5IHx8IHtcclxuICAgICAgICB0b3RhbF9ncm9zc19pbmNlbnRpdmVfdmFsdWU6IDAsXHJcbiAgICAgICAgdG90YWxfZ3Jvc3NfZ3JvdXBfdmFsdWU6IDAsXHJcbiAgICAgICAgdG90YWxfZ3Jvc3NfZW5yb2xsbWVudHM6IDAsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBhbGwgZ3Jvc3MgaW5jZW50aXZlIHJlcG9ydDpcIiwgZXJyKTtcclxuICAgICAgc2V0R3Jvc3NDb21taXNzaW9uRGF0YShbXSk7XHJcbiAgICAgIHNldEdyb3NzQ29tbWlzc2lvblN1bW1hcnkoe1xyXG4gICAgICAgIHRvdGFsX2dyb3NzX2luY2VudGl2ZV92YWx1ZTogMCxcclxuICAgICAgICB0b3RhbF9ncm9zc19ncm91cF92YWx1ZTogMCxcclxuICAgICAgICB0b3RhbF9ncm9zc19lbnJvbGxtZW50czogMCxcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVFbXBsb3llZUNoYW5nZSA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRFbXBsb3llZUlkKHZhbHVlKTtcclxuICAgIHNldFNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzKG51bGwpO1xyXG4gICAgc2V0RW1wbG95ZWVDdXN0b21lckRhdGEoW10pO1xyXG4gICAgc2V0Q29tbWlzc2lvblRvdGFsRGV0YWlscyh7fSk7XHJcbiAgICBzZXRUYXJnZXREYXRhKHtcclxuICAgICAgdGFyZ2V0OiAwLFxyXG4gICAgICBhY2hpZXZlZDogMCxcclxuICAgICAgcmVtYWluaW5nOiAwLFxyXG4gICAgICBzdGFydERhdGU6IFwiXCIsXHJcbiAgICAgIGVuZERhdGU6IFwiXCIsXHJcbiAgICAgIHRhcmdldENvbW1pc3Npb246IDAsXHJcbiAgICB9KTtcclxuICAgIHNldEdyb3NzQ29tbWlzc2lvbkRhdGEoW10pO1xyXG4gICAgc2V0R3Jvc3NDb21taXNzaW9uU3VtbWFyeSh7XHJcbiAgICAgIHRvdGFsX2dyb3NzX2luY2VudGl2ZV92YWx1ZTogMCxcclxuICAgICAgdG90YWxfZ3Jvc3NfZ3JvdXBfdmFsdWU6IDAsXHJcbiAgICAgIHRvdGFsX2dyb3NzX2Vucm9sbG1lbnRzOiAwLFxyXG4gICAgfSk7XHJcbiAgICBzZXRJc0ZpbHRlckFwcGxpZWQoZmFsc2UpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVRlbXBNb250aENoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCBzZWxlY3RlZE1vbnRoID0gZS50YXJnZXQudmFsdWU7XHJcbiAgICBzZXRUZW1wU2VsZWN0ZWRNb250aChzZWxlY3RlZE1vbnRoKTtcclxuICAgIGlmIChzZWxlY3RlZE1vbnRoKSB7XHJcbiAgICAgIGNvbnN0IFt5ZWFyLCBtb250aF0gPSBzZWxlY3RlZE1vbnRoLnNwbGl0KFwiLVwiKTtcclxuICAgICAgY29uc3QgZmlyc3REYXkgPSBgJHt5ZWFyfS0ke21vbnRofS0wMWA7XHJcbiAgICAgIGNvbnN0IGxhc3RkYXkxID0gbmV3IERhdGUoeWVhciwgbW9udGgsIDApLmdldERhdGUoKTtcclxuICAgICAgY29uc3QgbGFzdERheSA9IGAke3llYXJ9LSR7bW9udGh9LSR7U3RyaW5nKGxhc3REYXkpLnBhZFN0YXJ0KDIsIFwiMFwiKX1gO1xyXG4gICAgICBzZXRUZW1wRnJvbURhdGUoZmlyc3REYXkpO1xyXG4gICAgICBzZXRUZW1wVG9EYXRlKGxhc3REYXkpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGFwcGx5RmlsdGVyID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFzZWxlY3RlZEVtcGxveWVlSWQpIHtcclxuICAgICAgYWxlcnQoXCJQbGVhc2Ugc2VsZWN0IGFuIGFnZW50LlwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgaWYgKGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCIgJiYgIXRlbXBTZWxlY3RlZE1vbnRoKSB7XHJcbiAgICAgIGFsZXJ0KFwiUGxlYXNlIHNlbGVjdCBhIG1vbnRoLlwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgaWYgKGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcImRhdGUtcmFuZ2VcIiAmJiAoIXRlbXBGcm9tRGF0ZSB8fCAhdGVtcFRvRGF0ZSkpIHtcclxuICAgICAgYWxlcnQoXCJQbGVhc2Ugc2VsZWN0IGJvdGggRnJvbSBhbmQgVG8gZGF0ZXMuXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBsZXQgc3RhcnREYXRlLCBlbmREYXRlO1xyXG4gICAgaWYgKGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCIpIHtcclxuICAgICAgc2V0U2VsZWN0ZWRNb250aCh0ZW1wU2VsZWN0ZWRNb250aCk7XHJcbiAgICAgIGNvbnN0IFt5ZWFyLCBtb250aF0gPSB0ZW1wU2VsZWN0ZWRNb250aC5zcGxpdChcIi1cIik7XHJcbiAgICAgIHN0YXJ0RGF0ZSA9IGAke3llYXJ9LSR7bW9udGh9LTAxYDtcclxuICAgICAgY29uc3QgbGFzdERheSA9IG5ldyBEYXRlKHllYXIsIG1vbnRoLCAwKS5nZXREYXRlKCk7XHJcbiAgICAgIGVuZERhdGUgPSBgJHt5ZWFyfS0ke21vbnRofS0ke1N0cmluZyhsYXN0RGF5KS5wYWRTdGFydCgyLCBcIjBcIil9YDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHN0YXJ0RGF0ZSA9IHRlbXBGcm9tRGF0ZTtcclxuICAgICAgZW5kRGF0ZSA9IHRlbXBUb0RhdGU7XHJcbiAgICB9XHJcbiAgICBzZXRBZ2VudExvYWRpbmcodHJ1ZSk7XHJcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgc2V0SXNGaWx0ZXJBcHBsaWVkKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgaWYgKHNlbGVjdGVkRW1wbG95ZWVJZCA9PT0gXCJBTExcIikge1xyXG4gICAgICAgIHNldFNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzKG51bGwpO1xyXG4gICAgICAgIHNldFRhcmdldERhdGEoe1xyXG4gICAgICAgICAgdGFyZ2V0OiAwLFxyXG4gICAgICAgICAgYWNoaWV2ZWQ6IDAsXHJcbiAgICAgICAgICByZW1haW5pbmc6IDAsXHJcbiAgICAgICAgICBzdGFydERhdGU6IFwiXCIsXHJcbiAgICAgICAgICBlbmREYXRlOiBcIlwiLFxyXG4gICAgICAgICAgdGFyZ2V0Q29tbWlzc2lvbjogMCxcclxuICAgICAgICB9KTtcclxuICAgICAgICBhd2FpdCBmZXRjaEFsbENvbW1pc3Npb25SZXBvcnQoc3RhcnREYXRlLCBlbmREYXRlKTtcclxuICAgICAgICBhd2FpdCBmZXRjaEFsbEdyb3NzSW5jZW50aXZlUmVwb3J0KHN0YXJ0RGF0ZSwgZW5kRGF0ZSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgY29uc3QgZW1wID0gZW1wbG95ZWVzLmZpbmQoKGUpID0+IGUuX2lkID09PSBzZWxlY3RlZEVtcGxveWVlSWQpO1xyXG4gICAgICAgIHNldFNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzKGVtcCB8fCBudWxsKTtcclxuICAgICAgICBhd2FpdCBmZXRjaENvbW1pc3Npb25SZXBvcnQoc2VsZWN0ZWRFbXBsb3llZUlkLCBzdGFydERhdGUsIGVuZERhdGUpO1xyXG4gICAgICAgIGF3YWl0IGZldGNoVGFyZ2V0RGF0YShzZWxlY3RlZEVtcGxveWVlSWQsIHN0YXJ0RGF0ZSwgZW5kRGF0ZSk7XHJcbiAgICAgICAgYXdhaXQgZmV0Y2hHcm9zc0luY2VudGl2ZVJlcG9ydChzZWxlY3RlZEVtcGxveWVlSWQsIHN0YXJ0RGF0ZSwgZW5kRGF0ZSk7XHJcbiAgICAgIH1cclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldEFnZW50TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaEVtcGxveWVlcygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ29tbWlzc2lvbkNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldENvbW1pc3Npb25Gb3JtKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbbmFtZV06IHZhbHVlIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgW25hbWVdOiBcIlwiIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCB2YWxpZGF0ZUZvcm0gPSAoKSA9PiB7XHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuICAgIGlmICghY29tbWlzc2lvbkZvcm0uYWdlbnRfaWQpXHJcbiAgICAgIG5ld0Vycm9ycy5hZ2VudF9pZCA9IFwiUGxlYXNlIHNlbGVjdCBhbiBhZ2VudFwiO1xyXG4gICAgaWYgKCFjb21taXNzaW9uRm9ybS5hbW91bnQgfHwgaXNOYU4oY29tbWlzc2lvbkZvcm0uYW1vdW50KSlcclxuICAgICAgbmV3RXJyb3JzLmFtb3VudCA9IFwiUGxlYXNlIGVudGVyIGEgdmFsaWQgYW1vdW50XCI7XHJcbiAgICBpZiAoXHJcbiAgICAgIGNvbW1pc3Npb25Gb3JtLnBheV90eXBlID09PSBcIm9ubGluZVwiICYmXHJcbiAgICAgICFjb21taXNzaW9uRm9ybS50cmFuc2FjdGlvbl9pZFxyXG4gICAgKVxyXG4gICAgICBuZXdFcnJvcnMudHJhbnNhY3Rpb25faWQgPSBcIlRyYW5zYWN0aW9uIElEIGlzIHJlcXVpcmVkXCI7XHJcbiAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDb21taXNzaW9uU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGlmICghdmFsaWRhdGVGb3JtKCkpIHJldHVybjtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHBheWxvYWQgPSB7IC4uLmNvbW1pc3Npb25Gb3JtLCBhZG1pbl90eXBlOiBhZG1pbklkIH07XHJcbiAgICAgIGF3YWl0IGFwaS5wb3N0KFwiL3BheW1lbnQtb3V0L2FkZC1jb21taXNzaW9uLXBheW1lbnRcIiwgcGF5bG9hZCk7XHJcbiAgICAgIGFsZXJ0KFwiQ29tbWlzc2lvbiBQYWlkIFN1Y2Nlc3NmdWxseSFcIik7XHJcbiAgICAgIHNldFNob3dDb21taXNzaW9uTW9kYWwoZmFsc2UpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGFsZXJ0KFwiRmFpbGVkIHRvIGFkZCBwYXltZW50LlwiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBwcm9jZXNzZWRUYWJsZURhdGEgPSBlbXBsb3llZUN1c3RvbWVyRGF0YS5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoe1xyXG4gICAgLi4uaXRlbSxcclxuICAgIGdyb3VwX3ZhbHVlX2RpZ2l0czogaXRlbS5ncm91cF9pZD8uZ3JvdXBfdmFsdWUgfHwgMCxcclxuICAgIGVzdGltYXRlZF9jb21taXNzaW9uX2RpZ2l0czogaXRlbS5lc3RpbWF0ZWRfY29tbWlzc2lvbiB8fCAwLFxyXG4gICAgYWN0dWFsX2NvbW1pc3Npb25fZGlnaXRzOiBpdGVtLmNvbW1pc3Npb25fdmFsdWUgfHwgMCxcclxuICAgIHRvdGFsX3BhaWRfZGlnaXRzOiBpdGVtLnRvdGFsX3BhaWRfYW1vdW50IHx8IDAsXHJcbiAgICByZXF1aXJlZF9pbnN0YWxsbWVudF9kaWdpdHM6IGl0ZW0uZ3JvdXBfaWQ/Lm1vbnRobHlfaW5zdGFsbG1lbnQgfHwgMCxcclxuICAgIGdyb3VwX3RpY2tldDogaXRlbT8udGlja2V0IHx8IDAsXHJcbiAgICBuZXRfY29tbWlzc2lvbl9wZXJjZW50YWdlOiBpdGVtPy5ncm91cF9pZD8uY29tbWlzc2lvbiB8fCAwLFxyXG4gICAgY29tbWlzc2lvbl9yZWxlYXNlZDogaXRlbS5jb21taXNzaW9uX3JlbGVhc2VkID8gXCJZZXNcIiA6IFwiTm9cIixcclxuICAgIHVzZXJfbmFtZTogaXRlbS51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuICAgIHBob25lX251bWJlcjogaXRlbS51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgIGdyb3VwX25hbWU6IGl0ZW0uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCJOL0FcIixcclxuICAgIGVub2xsbWVudF9kYXRlOiBpdGVtLmNyZWF0ZWRBdD8uc3BsaXQoXCJUXCIpPy5bMF0gfHwgXCJOL0FcIixcclxuICB9KSk7XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJ1c2VyX25hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBfbmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF90aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldCBOb1wiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF92YWx1ZV9kaWdpdHNcIiwgaGVhZGVyOiBcIkdyb3VwIFZhbHVlXCIgfSxcclxuICAgIHsga2V5OiBcImVub2xsbWVudF9kYXRlXCIsIGhlYWRlcjogXCJFbnJvbGxtZW50IERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwibmV0X2NvbW1pc3Npb25fcGVyY2VudGFnZVwiLCBoZWFkZXI6IFwiTmV0IENvbW1pc3Npb24gUGVyY2VudGFnZVwiIH0sXHJcbiAgICB7IGtleTogXCJhY3R1YWxfY29tbWlzc2lvbl9kaWdpdHNcIiwgaGVhZGVyOiBcIk5ldCBDb21taXNzaW9uXCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsX3BhaWRfZGlnaXRzXCIsIGhlYWRlcjogXCJUb3RhbCBQYWlkXCIgfSxcclxuICAgIHsga2V5OiBcInJlcXVpcmVkX2luc3RhbGxtZW50X2RpZ2l0c1wiLCBoZWFkZXI6IFwiUmVxdWlyZWQgSW5zdGFsbG1lbnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiY29tbWlzc2lvbl9yZWxlYXNlZFwiLCBoZWFkZXI6IFwiQ29tbWlzc2lvbiBSZWxlYXNlZFwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgZ3Jvc3NDb21taXNzaW9uQ29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcInVzZXJfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX3ZhbHVlXCIsIGhlYWRlcjogXCJHcm91cCBWYWx1ZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF90aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldCBOb1wiIH0sXHJcbiAgICB7IGtleTogXCJlbnJvbGxtZW50X2RhdGVcIiwgaGVhZGVyOiBcIkVucm9sbG1lbnQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9tb250aGx5X2luc3RhbGxtZW50XCIsIGhlYWRlcjogXCJGaXJzdCBJbnN0YWxsbWVudCBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBfY29tbWlzc2lvblwiLCBoZWFkZXI6IFwiQ29tbWlzc2lvbiBQZXJjZW50YWdlXCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsX3BhaWRfYW1vdW50XCIsIGhlYWRlcjogXCJUb3RhbCBQYWlkXCIgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgY29uc3QgY3VycmVudE1vbnRoID0gYCR7dG9kYXkuZ2V0RnVsbFllYXIoKX0tJHtTdHJpbmcoXHJcbiAgICB0b2RheS5nZXRNb250aCgpICsgMVxyXG4gICkucGFkU3RhcnQoMiwgXCIwXCIpfWA7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4taC1zY3JlZW4gYmctZ3JheS01MFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgIDxOYXZiYXIgdmlzaWJpbGl0eT17dHJ1ZX0gLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLThcIj5cclxuICAgICAgICAgIHsvKiBIZWFkZXIgU2VjdGlvbiAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC00eGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBDb21taXNzaW9uIFJlcG9ydHNcclxuICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgVHJhY2sgYW5kIG1hbmFnZSBhZ2VudCBjb21taXNzaW9ucyBhbmQgcGVyZm9ybWFuY2VcclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIEZpbHRlciBDYXJkICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHAtOCBtYi04XCI+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgUmVwb3J0IEZpbHRlcnNcclxuICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC02IG1iLTZcIj5cclxuICAgICAgICAgICAgICB7LyogQWdlbnQgU2VsZWN0ICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgU2VsZWN0IEFnZW50XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRFbXBsb3llZUlkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUVtcGxveWVlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGJ5IG5hbWUgb3IgcGhvbmVcIlxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBoZWlnaHQ6IFwiNDRweFwiIH19XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWRcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7ZW1wbG95ZWVzLm1hcCgoZW1wKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtlbXAuX2lkfSB2YWx1ZT17ZW1wLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZW1wLm5hbWV9IC0ge2VtcC5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogRGF0ZSBTZWxlY3Rpb24gTW9kZSAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIERhdGUgU2VsZWN0aW9uXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBwLTMgYmctZ3JheS01MCByb3VuZGVkLWxnIGgtMTFcIj5cclxuICAgICAgICAgICAgICAgICAgPFJhZGlvLkdyb3VwXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2RhdGVTZWxlY3Rpb25Nb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RGF0ZVNlbGVjdGlvbk1vZGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJhZGlvIHZhbHVlPVwibW9udGhcIiBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBNb250aFxyXG4gICAgICAgICAgICAgICAgICAgIDwvUmFkaW8+XHJcbiAgICAgICAgICAgICAgICAgICAgPFJhZGlvIHZhbHVlPVwiZGF0ZS1yYW5nZVwiIGNsYXNzTmFtZT1cInRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFJhbmdlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9SYWRpbz5cclxuICAgICAgICAgICAgICAgICAgPC9SYWRpby5Hcm91cD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogRGF0ZSBQaWNrZXIgRmllbGRzICovfVxyXG4gICAgICAgICAgICAgIHtkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiID8gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgU2VsZWN0IE1vbnRoXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJtb250aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RlbXBTZWxlY3RlZE1vbnRoIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgbWF4PXtjdXJyZW50TW9udGh9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVRlbXBNb250aENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy12aW9sZXQtNTAwIGgtMTFcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBGcm9tIERhdGVcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RlbXBGcm9tRGF0ZSB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgbWF4PXt0ZW1wVG9EYXRlIHx8IGN1cnJlbnRNb250aH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGVtcEZyb21EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXZpb2xldC01MDAgaC0xMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBUbyBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0ZW1wVG9EYXRlIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBtaW49e3RlbXBGcm9tRGF0ZSB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgbWF4PXtjdXJyZW50TW9udGh9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRlbXBUb0RhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHB4LTQgcHktMiBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBoLTExXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIEZpbHRlciBCdXR0b24gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2FwcGx5RmlsdGVyfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtOCBweS0yLjUgYmctZ3JlZW4tNjAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBob3ZlcjpiZy1ncmVlbi03MDAgdHJhbnNpdGlvbi1jb2xvcnMgZm9udC1zZW1pYm9sZCBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIENvbnRpbnVlXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAge2FnZW50TG9hZGluZyA/IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIHB5LTIwXCI+XHJcbiAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGlzTG9hZGluZz17dHJ1ZX0gLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgIHsvKiBRdWljayBMaW5rcyAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLThcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgIHRvPVwiL3RhcmdldC1tZW51L3RhcmdldFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcC00IGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBob3Zlcjpib3JkZXItdmlvbGV0LTUwMCBob3ZlcjpiZy12aW9sZXQtNTAgdHJhbnNpdGlvbi1hbGwgZ3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZpVGFyZ2V0IGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTYwMCBncm91cC1ob3ZlcjpzY2FsZS0xMTAgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIiBzaXplPXsyNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGdyb3VwLWhvdmVyOnRleHQtdmlvbGV0LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2V0IFRhcmdldFxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgIHRvPVwiL3JlcG9ydHMvdGFyZ2V0LWluY2VudGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcC00IGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBob3Zlcjpib3JkZXItdmlvbGV0LTUwMCBob3ZlcjpiZy12aW9sZXQtNTAgdHJhbnNpdGlvbi1hbGwgZ3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZpbGVUZXh0T3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwIGdyb3VwLWhvdmVyOnNjYWxlLTExMCB0cmFuc2l0aW9uLXRyYW5zZm9ybSB0ZXh0LWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGdyb3VwLWhvdmVyOnRleHQtdmlvbGV0LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgSW5jZW50aXZlIFJlcG9ydFxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgIHRvPVwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9zYWxhcnktcGF5bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcC00IGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBob3Zlcjpib3JkZXItdmlvbGV0LTUwMCBob3ZlcjpiZy12aW9sZXQtNTAgdHJhbnNpdGlvbi1hbGwgZ3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZhTW9uZXlCaWxsIGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTYwMCBncm91cC1ob3ZlcjpzY2FsZS0xMTAgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIiBzaXplPXsyNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGdyb3VwLWhvdmVyOnRleHQtdmlvbGV0LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2FsYXJ5IFBheW91dFxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBUYWJiZWQgVmlldyBmb3IgUmVwb3J0cyAqL31cclxuICAgICAgICAgICAgICA8VGFicyBhY3RpdmVLZXk9e2FjdGl2ZVRhYn0gb25DaGFuZ2U9e3NldEFjdGl2ZVRhYn0+XHJcbiAgICAgICAgICAgICAgICB7LyogQ29tbWlzc2lvbiBSZXBvcnQgVGFiICovfVxyXG4gICAgICAgICAgICAgICAgPFRhYlBhbmUgdGFiPVwiTmV0IENvbW1pc3Npb24gUmVwb3J0XCIga2V5PVwiY29tbWlzc2lvblwiPlxyXG4gICAgICAgICAgICAgICAgICB7LyogRW1wbG95ZWUgRGV0YWlscyAqL31cclxuICAgICAgICAgICAgICAgICAge2lzRmlsdGVyQXBwbGllZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHAtNiBtYi04XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRFbXBsb3llZUlkICE9PSBcIkFMTFwiICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWdlbnQgSW5mb3JtYXRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTQgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzLm5hbWUgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSBiZy1ncmF5LTUwIHRleHQtZ3JheS05MDAgZm9udC1tZWRpdW0gbXQtMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRW1haWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzLmVtYWlsIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yLjUgYmctZ3JheS01MCB0ZXh0LWdyYXktOTAwIGZvbnQtbWVkaXVtIG10LTFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBob25lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRFbXBsb3llZURldGFpbHMucGhvbmVfbnVtYmVyIHx8IFwiLVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSBiZy1ncmF5LTUwIHRleHQtZ3JheS05MDAgZm9udC1tZWRpdW0gbXQtMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWRoYWFyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRFbXBsb3llZURldGFpbHMuYWRoYWFyX25vIHx8IFwiLVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSBiZy1ncmF5LTUwIHRleHQtZ3JheS05MDAgZm9udC1tZWRpdW0gbXQtMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUEFOXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEVtcGxveWVlRGV0YWlscy5wYW5fbm8gfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSBiZy1ncmF5LTUwIHRleHQtZ3JheS05MDAgZm9udC1tZWRpdW0gbXQtMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGluY29kZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzLnBpbmNvZGUgfHwgXCItXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHB4LTQgcHktMi41IGJnLWdyYXktNTAgdGV4dC1ncmF5LTkwMCBmb250LW1lZGl1bSBtdC0xXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBZGRyZXNzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8uYWRkcmVzcyB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHB4LTQgcHktMi41IGJnLWdyYXktNTAgdGV4dC1ncmF5LTkwMCBmb250LW1lZGl1bSBtdC0xXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBKb2luaW5nIERhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8uam9pbmluZ19kYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBzZWxlY3RlZEVtcGxveWVlRGV0YWlscy5qb2luaW5nX2RhdGUuc3BsaXQoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiVFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApWzBdXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIi1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yLjUgYmctZ3JheS01MCB0ZXh0LWdyYXktOTAwIGZvbnQtbWVkaXVtIG10LTFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aHIgY2xhc3NOYW1lPVwibXktNlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIFN1bW1hcnkgU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENvbW1pc3Npb24gU3VtbWFyeVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tZ3JlZW4tNTAgdG8tZ3JlZW4tMTAwIGJvcmRlciBib3JkZXItZ3JlZW4tMjAwIHJvdW5kZWQtbGcgcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgTmV0IEJ1c2luZXNzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29tbWlzc2lvblRvdGFsRGV0YWlscz8uYWN0dWFsX2J1c2luZXNzIHx8IFwiLVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXRyYW5zcGFyZW50IHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMCBtdC0yIGJvcmRlci0wXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIHRleHQtZ3JlZW4tNzAwIG10LTEgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJzZUFtb3VudChjb21taXNzaW9uVG90YWxEZXRhaWxzPy5hY3R1YWxfYnVzaW5lc3MpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS12aW9sZXQtNTAgdG8tdmlvbGV0LTEwMCBib3JkZXIgYm9yZGVyLXZpb2xldC0yMDAgcm91bmRlZC1sZyBwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBOZXQgQ29tbWlzc2lvbiAoMSUgZWFjaClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvbW1pc3Npb25Ub3RhbERldGFpbHM/LnRvdGFsX2FjdHVhbCB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctdHJhbnNwYXJlbnQgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtdmlvbGV0LTcwMCBtdC0yIGJvcmRlci0wXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIHRleHQtdmlvbGV0LTcwMCBtdC0xIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VBbW91bnQoY29tbWlzc2lvblRvdGFsRGV0YWlscz8udG90YWxfYWN0dWFsKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tcHVycGxlLTUwIHRvLXB1cnBsZS0xMDAgYm9yZGVyIGJvcmRlci1wdXJwbGUtMjAwIHJvdW5kZWQtbGcgcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgTmV0IEN1c3RvbWVyc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbW1pc3Npb25Ub3RhbERldGFpbHM/LnRvdGFsX2N1c3RvbWVycyB8fCBcIi1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy10cmFuc3BhcmVudCB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1wdXJwbGUtNzAwIG10LTIgYm9yZGVyLTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogVGFyZ2V0IERldGFpbHMgKi99XHJcbiAgICAgICAgICAgICAgICAgIHtpc0ZpbHRlckFwcGxpZWQgJiZcclxuICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlSWQgJiZcclxuICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlSWQgIT09IFwiQUxMXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHAtNiBtYi04XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRhcmdldCBQZXJmb3JtYW5jZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3RhcmdldERhdGEuYWNoaWV2ZWQgPj0gdGFyZ2V0RGF0YS50YXJnZXQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC00IHB5LTIgcm91bmRlZC1sZyBiZy1ncmVlbi0xMDAgYm9yZGVyIGJvcmRlci1ncmVlbi0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEdpUGFydHlQb3BwZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPXsyNH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNzAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUYXJnZXQgQWNoaWV2ZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBtZDpncmlkLWNvbHMtNCBnYXAtNCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLXZpb2xldC01MCB0by12aW9sZXQtMTAwIGJvcmRlciBib3JkZXItdmlvbGV0LTIwMCByb3VuZGVkLWxnIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUYXJnZXQgU2V0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtdmlvbGV0LTcwMCBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtgJHt0YXJnZXREYXRhLnRhcmdldD8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdGV4dC12aW9sZXQtNzAwIG10LTEgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHModGFyZ2V0RGF0YS50YXJnZXQgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWdyZWVuLTUwIHRvLWdyZWVuLTEwMCBib3JkZXIgYm9yZGVyLWdyZWVuLTIwMCByb3VuZGVkLWxnIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBY2hpZXZlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMCBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtgJHt0YXJnZXREYXRhLmFjaGlldmVkPy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMCBtdC0xIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKHRhcmdldERhdGEuYWNoaWV2ZWQgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWFtYmVyLTUwIHRvLWFtYmVyLTEwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCByb3VuZGVkLWxnIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEaWZmZXJlbmNlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtYW1iZXItNzAwIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2AkeyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXREYXRhLmRpZmZlcmVuY2UgPz8gXCIwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKT8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdGV4dC1hbWJlci03MDAgbXQtMSBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBNYXRoLmFicyh0YXJnZXREYXRhLmRpZmZlcmVuY2UgfHwgMClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tZW1lcmFsZC01MCB0by1lbWVyYWxkLTEwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwIHJvdW5kZWQtbGcgcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIFBheWFibGUgQ29tbWlzc2lvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNzAwIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Ake3RhcmdldERhdGEudGFyZ2V0Q29tbWlzc2lvbi50b0xvY2FsZVN0cmluZyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImVuLUlOXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gdGV4dC1lbWVyYWxkLTcwMCBtdC0xIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldERhdGEudGFyZ2V0Q29tbWlzc2lvbiB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXZpb2xldC01MCBib3JkZXIgYm9yZGVyLXZpb2xldC0yMDAgcm91bmRlZC1sZyBwLTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC12aW9sZXQtODAwIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIENvbW1pc3Npb24gQnJlYWtkb3duXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS03MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiBiZy12aW9sZXQtNjAwIHJvdW5kZWQtZnVsbFwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVXAgdG8gdGFyZ2V0ICgwLjUlKTp7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE1hdGgubWluKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXREYXRhLmFjaGlldmVkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXREYXRhLnRhcmdldFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSAqIDAuMDA1XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LXZpb2xldC03MDAgbWwtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE1hdGgubWluKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXREYXRhLmFjaGlldmVkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXREYXRhLnRhcmdldFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSAqIDAuMDA1XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGFyZ2V0RGF0YS5hY2hpZXZlZCA+IHRhcmdldERhdGEudGFyZ2V0ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgYmctZ3JlZW4tNjAwIHJvdW5kZWQtZnVsbFwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJleW9uZCB0YXJnZXQgKDElKTp7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAodGFyZ2V0RGF0YS5hY2hpZXZlZCAtIHRhcmdldERhdGEudGFyZ2V0KSAqXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDAuMDFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIHRleHQtZ3JlZW4tNzAwIG1sLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAodGFyZ2V0RGF0YS5hY2hpZXZlZCAtIHRhcmdldERhdGEudGFyZ2V0KSAqXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgMC4wMVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBEYXRhIFRhYmxlICovfVxyXG4gICAgICAgICAgICAgICAgICB7bG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgcHktMjBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e3RydWV9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICkgOiBlbXBsb3llZUN1c3RvbWVyRGF0YS5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT17cHJvY2Vzc2VkVGFibGVEYXRhfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9e2BDb21taXNzaW9uIFJlcG9ydGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiTmFtZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiUGhvbmUgTnVtYmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJNb250aFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiVGFyZ2V0IFNldFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiQWNoaWV2ZWRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBcIlJlbWFpbmluZ1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiVG90YWwgUGF5YWJsZSBDb21taXNzaW9uXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJBY3R1YWwgQnVzaW5lc3NcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBcIkFjdHVhbCBDb21taXNzaW9uXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJHcm9zcyBCdXNpbmVzc1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiR3Jvc3MgQ29tbWlzc2lvblwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiVG90YWwgQ3VzdG9tZXJzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJUb3RhbCBHcm91cHNcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJWYWx1ZXM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlSWQgPT09IFwiQUxMXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJBbGwgRW1wbG95ZWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogc2VsZWN0ZWRFbXBsb3llZURldGFpbHM/Lm5hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRFbXBsb3llZUlkID09PSBcIkFMTFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiLVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzPy5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaXNGaWx0ZXJBcHBsaWVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBuZXcgRGF0ZShgJHtzZWxlY3RlZE1vbnRofS0wMWApLnRvTG9jYWxlU3RyaW5nKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJkZWZhdWx0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vbnRoOiBcImxvbmdcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeWVhcjogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGAke25ldyBEYXRlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcEZyb21EYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZURhdGVTdHJpbmcoKX0gLSAke25ldyBEYXRlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcFRvRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVEYXRlU3RyaW5nKCl9YFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIi1cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBg4oK5JHt0YXJnZXREYXRhPy50YXJnZXQ/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIikgfHwgXCIwXCJ9ICgke251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXREYXRhPy50YXJnZXQgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9KWAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYOKCuSR7dGFyZ2V0RGF0YT8uYWNoaWV2ZWQ/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIikgfHwgXCIwXCJ9ICgke251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXREYXRhPy5hY2hpZXZlZCB8fCAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX0pYCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBg4oK5JHt0YXJnZXREYXRhPy5yZW1haW5pbmc/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIikgfHwgXCIwXCJ9ICgke251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXREYXRhPy5yZW1haW5pbmcgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9KWAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYOKCuSR7dGFyZ2V0RGF0YT8udGFyZ2V0Q29tbWlzc2lvbj8udG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImVuLUlOXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogMixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4aW11bUZyYWN0aW9uRGlnaXRzOiAyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkgfHwgXCIwLjAwXCJ9ICgke251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXREYXRhPy50YXJnZXRDb21taXNzaW9uIHx8IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfSlgLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGDigrkke2NvbW1pc3Npb25Ub3RhbERldGFpbHM/LmFjdHVhbF9idXNpbmVzcz8udG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImVuLUlOXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApIHx8IFwiMFwifSAoJHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VBbW91bnQoY29tbWlzc2lvblRvdGFsRGV0YWlscz8uYWN0dWFsX2J1c2luZXNzKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9KWAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYOKCuSR7Y29tbWlzc2lvblRvdGFsRGV0YWlscz8udG90YWxfYWN0dWFsPy50b0xvY2FsZVN0cmluZyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZW4tSU5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkgfHwgXCIwXCJ9ICgke251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJzZUFtb3VudChjb21taXNzaW9uVG90YWxEZXRhaWxzPy50b3RhbF9hY3R1YWwpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX0pYCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBg4oK5JHtjb21taXNzaW9uVG90YWxEZXRhaWxzPy5leHBlY3RlZF9idXNpbmVzcz8udG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImVuLUlOXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApIHx8IFwiMFwifSAoJHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VBbW91bnQoY29tbWlzc2lvblRvdGFsRGV0YWlscz8uZXhwZWN0ZWRfYnVzaW5lc3MpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX0pYCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBg4oK5JHtjb21taXNzaW9uVG90YWxEZXRhaWxzPy50b3RhbF9lc3RpbWF0ZWQ/LnRvTG9jYWxlU3RyaW5nKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbi1JTlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSB8fCBcIjBcIn0gKCR7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlQW1vdW50KGNvbW1pc3Npb25Ub3RhbERldGFpbHM/LnRvdGFsX2VzdGltYXRlZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfSlgLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbW1pc3Npb25Ub3RhbERldGFpbHM/LnRvdGFsX2N1c3RvbWVycyB8fCBcIjBcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb21taXNzaW9uVG90YWxEZXRhaWxzPy50b3RhbF9ncm91cHMgfHwgXCIwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BDb21taXNzaW9uUmVwb3J0LSR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRFbXBsb3llZURldGFpbHM/Lm5hbWUgfHwgXCJhbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LSR7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaXNGaWx0ZXJBcHBsaWVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBzZWxlY3RlZE1vbnRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogYCR7dGVtcEZyb21EYXRlfV90b18ke3RlbXBUb0RhdGV9YFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcInVuZmlsdGVyZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LmNzdmB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIGlzRmlsdGVyQXBwbGllZCAmJlxyXG4gICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzPy5uYW1lICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBwLTEyIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1sZyBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIE5vIGNvbW1pc3Npb24gZGF0YSBmb3VuZCBmb3IgdGhlIHNlbGVjdGVkIHBlcmlvZC5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9UYWJQYW5lPlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBHcm9zcyBJbmNlbnRpdmUgUmVwb3J0IFRhYiAqL31cclxuICAgICAgICAgICAgICAgIDxUYWJQYW5lIHRhYj1cIkdyb3NzIENvbW1pc3Npb24gUmVwb3J0XCIga2V5PVwiZ3Jvc3MtaW5jZW50aXZlXCI+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiBHcm9zcyBJbmNlbnRpdmUgU3VtbWFyeSBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICB7aXNGaWx0ZXJBcHBsaWVkICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcC02IG1iLThcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEdyb3NzIEluY2VudGl2ZSBTdW1tYXJ5XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ncmVlbi01MCB0by1ncmVlbi0xMDAgYm9yZGVyIGJvcmRlci1ncmVlbi0yMDAgcm91bmRlZC1sZyBwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBHcm9zcyBHcm91cCBWYWx1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3NzQ29tbWlzc2lvblN1bW1hcnkudG90YWxfZ3Jvc3NfZ3JvdXBfdmFsdWU/LnRvTG9jYWxlU3RyaW5nKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZW4tSU5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHx8IFwiLVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXRyYW5zcGFyZW50IHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMCBtdC0yIGJvcmRlci0wXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIHRleHQtZ3JlZW4tNzAwIG10LTEgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm9zc0NvbW1pc3Npb25TdW1tYXJ5LnRvdGFsX2dyb3NzX2dyb3VwX3ZhbHVlIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tdmlvbGV0LTUwIHRvLXZpb2xldC0xMDAgYm9yZGVyIGJvcmRlci12aW9sZXQtMjAwIHJvdW5kZWQtbGcgcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgR3Jvc3MgQ29tbWlzc2lvbiBWYWx1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3NzQ29tbWlzc2lvblN1bW1hcnkudG90YWxfZ3Jvc3NfY29tbWlzc2lvbl92YWx1ZT8udG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbi1JTlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgfHwgXCItXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctdHJhbnNwYXJlbnQgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtdmlvbGV0LTcwMCBtdC0yIGJvcmRlci0wXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIHRleHQtdmlvbGV0LTcwMCBtdC0xIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3Jvc3NDb21taXNzaW9uU3VtbWFyeS50b3RhbF9ncm9zc19jb21taXNzaW9uX3ZhbHVlIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tcHVycGxlLTUwIHRvLXB1cnBsZS0xMDAgYm9yZGVyIGJvcmRlci1wdXJwbGUtMjAwIHJvdW5kZWQtbGcgcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgR3Jvc3MgRW5yb2xsbWVudHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm9zc0NvbW1pc3Npb25TdW1tYXJ5LnRvdGFsX2dyb3NzX2Vucm9sbG1lbnRzIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiLVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXRyYW5zcGFyZW50IHRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXB1cnBsZS03MDAgbXQtMiBib3JkZXItMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBEYXRhIFRhYmxlICovfVxyXG4gICAgICAgICAgICAgICAgICB7bG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgcHktMjBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e3RydWV9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICkgOiBncm9zc0NvbW1pc3Npb25EYXRhLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhPXtncm9zc0NvbW1pc3Npb25EYXRhfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtncm9zc0NvbW1pc3Npb25Db2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9e2BHcm9zcyBJbmNlbnRpdmUgUmVwb3J0YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJOYW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJQaG9uZSBOdW1iZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBcIlBlcmlvZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiVG90YWwgR3JvdXAgVmFsdWVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBcIlRvdGFsIEluY2VudGl2ZSBWYWx1ZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiVG90YWwgRW5yb2xsbWVudHNcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJWYWx1ZXM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlSWQgPT09IFwiQUxMXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJBbGwgRW1wbG95ZWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogc2VsZWN0ZWRFbXBsb3llZURldGFpbHM/Lm5hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRFbXBsb3llZUlkID09PSBcIkFMTFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiLVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzPy5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaXNGaWx0ZXJBcHBsaWVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGRhdGVTZWxlY3Rpb25Nb2RlID09PSBcIm1vbnRoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBuZXcgRGF0ZShgJHtzZWxlY3RlZE1vbnRofS0wMWApLnRvTG9jYWxlU3RyaW5nKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJkZWZhdWx0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vbnRoOiBcImxvbmdcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeWVhcjogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGAke25ldyBEYXRlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcEZyb21EYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZURhdGVTdHJpbmcoKX0gLSAke25ldyBEYXRlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcFRvRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVEYXRlU3RyaW5nKCl9YFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIi1cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBg4oK5JHtncm9zc0NvbW1pc3Npb25TdW1tYXJ5LnRvdGFsX2dyb3NzX2dyb3VwX3ZhbHVlPy50b0xvY2FsZVN0cmluZyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZW4tSU5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkgfHwgXCIwXCJ9ICgke251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm9zc0NvbW1pc3Npb25TdW1tYXJ5LnRvdGFsX2dyb3NzX2dyb3VwX3ZhbHVlIHx8IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfSlgLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGDigrkke2dyb3NzQ29tbWlzc2lvblN1bW1hcnkudG90YWxfZ3Jvc3NfaW5jZW50aXZlX3ZhbHVlPy50b0xvY2FsZVN0cmluZyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZW4tSU5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkgfHwgXCIwXCJ9ICgke251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm9zc0NvbW1pc3Npb25TdW1tYXJ5LnRvdGFsX2dyb3NzX2luY2VudGl2ZV92YWx1ZSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX0pYCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBgJHtncm9zc0NvbW1pc3Npb25TdW1tYXJ5LnRvdGFsX2dyb3NzX2Vucm9sbG1lbnRzIHx8IFwiMFwifWAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BHcm9zc0luY2VudGl2ZVJlcG9ydC0ke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzPy5uYW1lIHx8IFwiYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfS0ke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzRmlsdGVyQXBwbGllZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBkYXRlU2VsZWN0aW9uTW9kZSA9PT0gXCJtb250aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gc2VsZWN0ZWRNb250aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGAke3RlbXBGcm9tRGF0ZX1fdG9fJHt0ZW1wVG9EYXRlfWBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJ1bmZpbHRlcmVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgfS5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICBpc0ZpbHRlckFwcGxpZWQgJiZcclxuICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ubmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcC0xMiB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQtbGcgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBObyBncm9zcyBpbmNlbnRpdmUgZGF0YSBmb3VuZCBmb3IgdGhlIHNlbGVjdGVkIHBlcmlvZC5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9UYWJQYW5lPlxyXG4gICAgICAgICAgICAgIDwvVGFicz5cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBUYXJnZXRDb21taXNzaW9uOyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9UYXJnZXRDb21taXNzaW9uLmpzeCJ9