import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AuctionInformation.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { notification } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { Ticket } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { FaUsers, FaCheckCircle } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const AuctionInformation = () => {
  _s();
  const [searchText, setSearchText] = useState("");
  const [usersData, setUsersData] = useState([]);
  const [groupFilter, setGroupFilter] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [activeUserData, setActiveUserData] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [totalUsers, setTotalUsers] = useState(0);
  const [notifier, contextHolder] = notification.useNotification();
  const [selectAll, setSelectAll] = useState(false);
  const [auctionData, setAuctionData] = useState([]);
  const groupOptions = [
    ...new Set(
      usersData.filter(
        (u) => u.groupName !== void 0 && u.groupName !== "" && u.groupName !== "   "
      ).map((u) => u.groupName)
    )
  ];
  const filteredUsers = useMemo(() => {
    const filtered = filterOption(
      usersData.filter((u) => {
        const matchGroup = groupFilter ? u.groupName === groupFilter : true;
        const enrollmentDate = new Date(u.enrollmentDate);
        const matchFromDate = fromDate ? enrollmentDate >= new Date(fromDate) : true;
        const matchToDate = toDate ? enrollmentDate <= new Date(toDate) : true;
        return matchGroup && matchFromDate && matchToDate;
      }),
      searchText
    );
    return filtered.map((user, index) => {
      const isSelected = !!activeUserData[user._id]?.info?.status;
      return {
        ...user,
        sl_no: index + 1,
        checkBoxs: /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "checkbox",
            checked: isSelected,
            onChange: (e) => {
              setActiveUserData((prev) => ({
                ...prev,
                [user._id]: {
                  info: {
                    status: e.target.checked,
                    userPhone: user.userPhone,
                    groupName: user.groupName,
                    groupMembers: user.groupMembers,
                    userName: user.userName,
                    //  ticket: user.ticket,
                    winAmount: user.winAmount,
                    bidPercent: user.bidPercent,
                    bidAmount: user.bidAmount,
                    groupId: user.groupId?._id
                    // userId: user.userId,
                  }
                }
              }));
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
            lineNumber: 63,
            columnNumber: 9
          },
          this
        ),
        isSelected
      };
    });
  }, [usersData, groupFilter, fromDate, toDate, searchText, activeUserData]);
  const visibleSelectedCount = useMemo(() => {
    return filteredUsers.filter((user) => user.isSelected).length;
  }, [filteredUsers]);
  const sendWhatsapp = async () => {
    const key = "updatable";
    try {
      notifier.open({
        key,
        message: "Sending Messages Via Whatsapp..",
        description: "Processing...",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
      const visibleActiveUsers = {};
      filteredUsers.forEach((user) => {
        if (user.isSelected && activeUserData[user._id]) {
          visibleActiveUsers[user._id] = activeUserData[user._id];
        }
      });
      await api.post("/whatsapp/auction-winner-document-list", {
        receivers: visibleActiveUsers
      });
      const newActiveUserData = { ...activeUserData };
      filteredUsers.forEach((user) => {
        if (user.isSelected) {
          delete newActiveUserData[user._id];
        }
      });
      setActiveUserData(newActiveUserData);
      notifier.open({
        key,
        message: "Whatsapp Messages Has Been Sent Successfully",
        description: "Success",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
    } catch (err) {
      notifier.open({
        key,
        message: "Failed to Send Whatsapp",
        description: err.message || "Something went wrong",
        className: "bg-red-300 rounded-lg font-bold",
        duration: 2
      });
    }
  };
  useEffect(() => {
    const allChecked = filteredUsers.length > 0 && filteredUsers.every((user) => activeUserData[user._id]?.info?.status);
    setSelectAll(allChecked);
  }, [filteredUsers, activeUserData]);
  const fetchData = async () => {
    try {
      setIsLoading(true);
      const reportResponse = await api.get("/auction/get-auction");
      console.info(reportResponse.data, "ghsjgsjg");
      const usersList = [];
      const tempActive = {};
      const auctionData2 = reportResponse.data?.auction?.map(
        (auction, index) => {
          const id = auction._id;
          const userName = auction.user_id?.full_name;
          const groupId = auction.group_id;
          const userPhone = auction.user_id?.phone_number;
          const groupName = auction.group_id?.group_name;
          const groupMembers = auction.group_id?.group_members;
          const winAmount = auction?.win_amount;
          const bidAmount = Number(auction?.group_id?.group_value) - Number(auction?.win_amount);
          const bidPercentage = Number(bidAmount) * 100 / Number(auction?.group_id?.group_value);
          const ticket = auction.ticket;
          tempActive[id] = {
            info: { status: false }
          };
          const tempUser = {
            _id: id,
            userName,
            userPhone,
            groupName,
            ticket,
            winAmount,
            groupMembers,
            enrollmentDate: auction.group_id?.createdAt,
            bidAmount,
            groupId,
            bidPercentage
            //  installmentNumber,
          };
          usersList.push(tempUser);
          return {
            slNo: index + 1,
            groupName,
            userPhone,
            userName,
            ticket,
            winAmount,
            bidAmount,
            bidPercentage,
            groupMembers,
            groupId
            // installmentNumber: index + 1,
          };
        }
      );
      setAuctionData(auctionData2);
      console.log(usersList, "userslist");
      setUsersData(usersList);
      setTotalUsers(usersList.length);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);
  const Auctioncolumns = [
    { key: "sl_no", header: "SL. NO" },
    { key: "checkBoxs", header: "Select User" },
    { key: "userName", header: "Customer Name" },
    { key: "userPhone", header: "Phone Number" },
    // { key: "customerId", header: "Customer Id" },
    { key: "groupName", header: "Group Name" },
    { key: "ticket", header: "Ticket" },
    { key: "winAmount", header: "win Amount" },
    { key: "bidAmount", header: "Bid Amount" },
    { key: "bidPercentage", header: "Bid Percentage" }
    //  {key: "installmentNumber", header: "installment Number"}
    //  {key: "paymentsTicket", header: "Ticket"},
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
        lineNumber: 243,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
      lineNumber: 247,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
        lineNumber: 250,
        columnNumber: 16
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-center mt-2", children: "Auction Information" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
        lineNumber: 251,
        columnNumber: 13
      }, this),
      contextHolder,
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-start border-b border-gray-300 mb-4" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
          lineNumber: 260,
          columnNumber: 15
        }, this),
        isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-green-600" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
          lineNumber: 263,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
          lineNumber: 262,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-6 mt-8 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Total Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
                  lineNumber: 271,
                  columnNumber: 7
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-violet-700", children: filteredUsers.length }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
                  lineNumber: 272,
                  columnNumber: 7
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
                lineNumber: 270,
                columnNumber: 5
              }, this),
              /* @__PURE__ */ jsxDEV(FaUsers, { className: "text-violet-600 text-4xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
                lineNumber: 276,
                columnNumber: 5
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
              lineNumber: 269,
              columnNumber: 3
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Selected Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
                  lineNumber: 281,
                  columnNumber: 7
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-green-700", children: visibleSelectedCount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
                  lineNumber: 282,
                  columnNumber: 7
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
                lineNumber: 280,
                columnNumber: 5
              }, this),
              /* @__PURE__ */ jsxDEV(FaCheckCircle, { className: "text-green-600 text-4xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
                lineNumber: 286,
                columnNumber: 5
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
              lineNumber: 279,
              columnNumber: 3
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
            lineNumber: 268,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-4 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Select Group" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
                lineNumber: 291,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  style: { width: 200 },
                  allowClear: true,
                  placeholder: "--All groups--",
                  onChange: (value) => setGroupFilter(value),
                  value: groupFilter || void 0,
                  className: "w-full max-w-xs h-11 ",
                  children: groupOptions.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group, children: group }, group, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
                      lineNumber: 303,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
                  lineNumber: 294,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
              lineNumber: 290,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-5", children: "Select All" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
                lineNumber: 311,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  className: "ml-4 w-4 h-4 mb-3",
                  checked: selectAll,
                  onChange: (e) => {
                    const checked = e.target.checked;
                    setSelectAll(checked);
                    const updatedData = { ...activeUserData };
                    filteredUsers.forEach((user) => {
                      updatedData[user._id] = {
                        info: {
                          status: checked,
                          userPhone: user.userPhone,
                          groupName: user.groupName,
                          groupMembers: user.groupMembers,
                          userName: user.userName,
                          //  ticket: user.ticket,
                          winAmount: user.winAmount,
                          bidPercent: user.bidPercent,
                          bidAmount: user.bidAmount,
                          groupId: user.groupId?._id
                          // userId: user.userId,
                        }
                      };
                    });
                    setActiveUserData(updatedData);
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
                  lineNumber: 314,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
              lineNumber: 310,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
            lineNumber: 289,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mb-4", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: sendWhatsapp,
              className: "relative bg-green-600 text-white px-4 py-2 rounded shadow-md hover:bg-green-700 transition duration-200 flex items-center",
              children: [
                visibleSelectedCount > 0 && /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "min-w-6 h-6 absolute -right-3 -top-2 shadow-lg hover:bg-red-600 bg-red-400 rounded-full text-white flex items-center justify-center text-xs",
                    title: `Message will be sent to total ${visibleSelectedCount} customers`,
                    children: /* @__PURE__ */ jsxDEV("span", { children: visibleSelectedCount }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
                      lineNumber: 358,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
                    lineNumber: 354,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "mr-2", size: 20 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
                  lineNumber: 361,
                  columnNumber: 21
                }, this),
                "WhatsApp"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
              lineNumber: 349,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
            lineNumber: 348,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: filteredUsers,
              columns: Auctioncolumns,
              catcher: "_id",
              exportedPdfName: "Auction Information",
              printHeaderKeys: ["Group Name"],
              printHeaderValues: [groupFilter],
              exportedFileName: `Auction Information.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
              lineNumber: 365,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
          lineNumber: 266,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
        lineNumber: 259,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
      lineNumber: 249,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
    lineNumber: 242,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx",
    lineNumber: 241,
    columnNumber: 5
  }, this);
};
_s(AuctionInformation, "dnqT5GpkUh6a2lVfloJw0nfr/G0=", false, function() {
  return [notification.useNotification];
});
_c = AuctionInformation;
export default AuctionInformation;
var _c;
$RefreshReg$(_c, "AuctionInformation");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionInformation.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOERVOzJCQTlEVjtBQUFnQkEsTUFBV0MsY0FBVUMsT0FBTyxzQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzRCxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLGNBQWM7QUFDdkIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxjQUFjO0FBQ3ZCLE9BQU9DLGFBQWE7QUFDcEIsU0FBU0MsU0FBU0MscUJBQXFCO0FBQ3ZDLE9BQU9DLGdCQUFnQjtBQUd2QixNQUFNQyxxQkFBcUJBLE1BQU07QUFBQUMsS0FBQTtBQUMvQixRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSWxCLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNtQixXQUFXQyxZQUFZLElBQUlwQixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDcUIsYUFBYUMsY0FBYyxJQUFJdEIsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ3VCLFVBQVVDLFdBQVcsSUFBSXhCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUN5QixRQUFRQyxTQUFTLElBQUkxQixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDMkIsZ0JBQWdCQyxpQkFBaUIsSUFBSTVCLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZELFFBQU0sQ0FBQzZCLFdBQVdDLFlBQVksSUFBSTlCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMrQixZQUFZQyxhQUFhLElBQUloQyxTQUFTLENBQUM7QUFDOUMsUUFBTSxDQUFDaUMsVUFBVUMsYUFBYSxJQUFJekIsYUFBYTBCLGdCQUFnQjtBQUMvRCxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSXJDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNzQyxhQUFhQyxjQUFjLElBQUl2QyxTQUFTLEVBQUU7QUFHakQsUUFBTXdDLGVBQWU7QUFBQSxJQUNuQixHQUFHLElBQUlDO0FBQUFBLE1BQ0x0QixVQUNHdUI7QUFBQUEsUUFDQyxDQUFDQyxNQUNDQSxFQUFFQyxjQUFjQyxVQUNoQkYsRUFBRUMsY0FBYyxNQUNoQkQsRUFBRUMsY0FBYztBQUFBLE1BQ3BCLEVBQ0NFLElBQUksQ0FBQ0gsTUFBTUEsRUFBRUMsU0FBUztBQUFBLElBQzNCO0FBQUEsRUFBQztBQUVILFFBQU1HLGdCQUFnQjlDLFFBQVEsTUFBTTtBQUNsQyxVQUFNK0MsV0FBV3pDO0FBQUFBLE1BQ2ZZLFVBQVV1QixPQUFPLENBQUNDLE1BQU07QUFDdEIsY0FBTU0sYUFBYTVCLGNBQWNzQixFQUFFQyxjQUFjdkIsY0FBYztBQUMvRCxjQUFNNkIsaUJBQWlCLElBQUlDLEtBQUtSLEVBQUVPLGNBQWM7QUFDaEQsY0FBTUUsZ0JBQWdCN0IsV0FDbEIyQixrQkFBa0IsSUFBSUMsS0FBSzVCLFFBQVEsSUFDbkM7QUFDSixjQUFNOEIsY0FBYzVCLFNBQVN5QixrQkFBa0IsSUFBSUMsS0FBSzFCLE1BQU0sSUFBSTtBQUNsRSxlQUFPd0IsY0FBY0csaUJBQWlCQztBQUFBQSxNQUN4QyxDQUFDO0FBQUEsTUFDRHBDO0FBQUFBLElBQ0Y7QUFFQSxXQUFPK0IsU0FBU0YsSUFBSSxDQUFDUSxNQUFNQyxVQUFVO0FBQ25DLFlBQU1DLGFBQWEsQ0FBQyxDQUFDN0IsZUFBZTJCLEtBQUtHLEdBQUcsR0FBR0MsTUFBTUM7QUFFckQsYUFBTztBQUFBLFFBQ0wsR0FBR0w7QUFBQUEsUUFDSE0sT0FBT0wsUUFBUTtBQUFBLFFBQ2ZNLFdBQ0U7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVNMO0FBQUFBLFlBQ1QsVUFBVSxDQUFDTSxNQUFNO0FBQ2ZsQyxnQ0FBa0IsQ0FBQ21DLFVBQVU7QUFBQSxnQkFDM0IsR0FBR0E7QUFBQUEsZ0JBQ0gsQ0FBQ1QsS0FBS0csR0FBRyxHQUFHO0FBQUEsa0JBQ1ZDLE1BQU07QUFBQSxvQkFDSkMsUUFBUUcsRUFBRUUsT0FBT0M7QUFBQUEsb0JBQ2pCQyxXQUFXWixLQUFLWTtBQUFBQSxvQkFDaEJ0QixXQUFXVSxLQUFLVjtBQUFBQSxvQkFDaEJ1QixjQUFjYixLQUFLYTtBQUFBQSxvQkFDbkJDLFVBQVVkLEtBQUtjO0FBQUFBO0FBQUFBLG9CQUVmQyxXQUFXZixLQUFLZTtBQUFBQSxvQkFDaEJDLFlBQVloQixLQUFLZ0I7QUFBQUEsb0JBQ2pCQyxXQUFXakIsS0FBS2lCO0FBQUFBLG9CQUNoQkMsU0FBU2xCLEtBQUtrQixTQUFTZjtBQUFBQTtBQUFBQSxrQkFFekI7QUFBQSxnQkFDRjtBQUFBLGNBQ0YsRUFBRTtBQUFBLFlBQ0o7QUFBQTtBQUFBLFVBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXNCSTtBQUFBLFFBR05EO0FBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILEdBQUcsQ0FBQ3JDLFdBQVdFLGFBQWFFLFVBQVVFLFFBQVFSLFlBQVlVLGNBQWMsQ0FBQztBQUV6RSxRQUFNOEMsdUJBQXVCeEUsUUFBUSxNQUFNO0FBQ3pDLFdBQU84QyxjQUFjTCxPQUFPLENBQUNZLFNBQVNBLEtBQUtFLFVBQVUsRUFBRWtCO0FBQUFBLEVBQ3pELEdBQUcsQ0FBQzNCLGFBQWEsQ0FBQztBQUVsQixRQUFNNEIsZUFBZSxZQUFZO0FBQy9CLFVBQU1DLE1BQU07QUFDWixRQUFJO0FBQ0YzQyxlQUFTNEMsS0FBSztBQUFBLFFBQ1pEO0FBQUFBLFFBQ0FFLFNBQVM7QUFBQSxRQUNUQyxhQUFhO0FBQUEsUUFDYkMsV0FBVztBQUFBLFFBQ1hDLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFFRCxZQUFNQyxxQkFBcUIsQ0FBQztBQUM1Qm5DLG9CQUFjb0MsUUFBUSxDQUFDN0IsU0FBUztBQUM5QixZQUFJQSxLQUFLRSxjQUFjN0IsZUFBZTJCLEtBQUtHLEdBQUcsR0FBRztBQUMvQ3lCLDZCQUFtQjVCLEtBQUtHLEdBQUcsSUFBSTlCLGVBQWUyQixLQUFLRyxHQUFHO0FBQUEsUUFDeEQ7QUFBQSxNQUNGLENBQUM7QUFFRCxZQUFNdkQsSUFBSWtGLEtBQUssMENBQTBDO0FBQUEsUUFDdkRDLFdBQVdIO0FBQUFBLE1BQ2IsQ0FBQztBQUVELFlBQU1JLG9CQUFvQixFQUFFLEdBQUczRCxlQUFlO0FBQzlDb0Isb0JBQWNvQyxRQUFRLENBQUM3QixTQUFTO0FBQzlCLFlBQUlBLEtBQUtFLFlBQVk7QUFDbkIsaUJBQU84QixrQkFBa0JoQyxLQUFLRyxHQUFHO0FBQUEsUUFDbkM7QUFBQSxNQUNGLENBQUM7QUFDRDdCLHdCQUFrQjBELGlCQUFpQjtBQUVuQ3JELGVBQVM0QyxLQUFLO0FBQUEsUUFDWkQ7QUFBQUEsUUFDQUUsU0FBUztBQUFBLFFBQ1RDLGFBQWE7QUFBQSxRQUNiQyxXQUFXO0FBQUEsUUFDWEMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0gsU0FBU00sS0FBSztBQUNadEQsZUFBUzRDLEtBQUs7QUFBQSxRQUNaRDtBQUFBQSxRQUNBRSxTQUFTO0FBQUEsUUFDVEMsYUFBYVEsSUFBSVQsV0FBVztBQUFBLFFBQzVCRSxXQUFXO0FBQUEsUUFDWEMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBQ0FsRixZQUFVLE1BQU07QUFFZCxVQUFNeUYsYUFDSnpDLGNBQWMyQixTQUFTLEtBQ3ZCM0IsY0FBYzBDLE1BQU0sQ0FBQ25DLFNBQVMzQixlQUFlMkIsS0FBS0csR0FBRyxHQUFHQyxNQUFNQyxNQUFNO0FBQ3RFdEIsaUJBQWFtRCxVQUFVO0FBQUEsRUFDekIsR0FBRyxDQUFDekMsZUFBZXBCLGNBQWMsQ0FBQztBQUNsQyxRQUFNK0QsWUFBWSxZQUFZO0FBQzVCLFFBQUk7QUFDRjVELG1CQUFhLElBQUk7QUFDakIsWUFBTTZELGlCQUFpQixNQUFNekYsSUFBSTBGLElBQUksc0JBQXNCO0FBQzNEQyxjQUFRbkMsS0FBS2lDLGVBQWVHLE1BQU0sVUFBVTtBQUM1QyxZQUFNQyxZQUFZO0FBQ2xCLFlBQU1DLGFBQWEsQ0FBQztBQUVwQixZQUFNMUQsZUFBY3FELGVBQWVHLE1BQU1HLFNBQVNuRDtBQUFBQSxRQUNoRCxDQUFDbUQsU0FBUzFDLFVBQVU7QUFDbEIsZ0JBQU0yQyxLQUFLRCxRQUFReEM7QUFDbkIsZ0JBQU1XLFdBQVc2QixRQUFRRSxTQUFTQztBQUNsQyxnQkFBTTVCLFVBQVV5QixRQUFRSTtBQUN4QixnQkFBTW5DLFlBQVkrQixRQUFRRSxTQUFTRztBQUNuQyxnQkFBTTFELFlBQVlxRCxRQUFRSSxVQUFVRTtBQUNwQyxnQkFBTXBDLGVBQWU4QixRQUFRSSxVQUFVRztBQUN2QyxnQkFBTW5DLFlBQVk0QixTQUFTUTtBQUMzQixnQkFBTWxDLFlBQ0ptQyxPQUFPVCxTQUFTSSxVQUFVTSxXQUFXLElBQ3JDRCxPQUFPVCxTQUFTUSxVQUFVO0FBQzVCLGdCQUFNRyxnQkFDSEYsT0FBT25DLFNBQVMsSUFBSSxNQUFPbUMsT0FBT1QsU0FBU0ksVUFBVU0sV0FBVztBQUNuRSxnQkFBTUUsU0FBU1osUUFBUVk7QUFHdkJiLHFCQUFXRSxFQUFFLElBQUk7QUFBQSxZQUNmeEMsTUFBTSxFQUFFQyxRQUFRLE1BQU07QUFBQSxVQUN4QjtBQUNBLGdCQUFNbUQsV0FBVztBQUFBLFlBQ2ZyRCxLQUFLeUM7QUFBQUEsWUFDTDlCO0FBQUFBLFlBQ0FGO0FBQUFBLFlBQ0F0QjtBQUFBQSxZQUNBaUU7QUFBQUEsWUFDQXhDO0FBQUFBLFlBQ0FGO0FBQUFBLFlBQ0FqQixnQkFBZ0IrQyxRQUFRSSxVQUFVVTtBQUFBQSxZQUNsQ3hDO0FBQUFBLFlBQ0FDO0FBQUFBLFlBQ0FvQztBQUFBQTtBQUFBQSxVQUVGO0FBQ0FiLG9CQUFVaUIsS0FBS0YsUUFBUTtBQUV2QixpQkFBTztBQUFBLFlBQ0xHLE1BQU0xRCxRQUFRO0FBQUEsWUFDZFg7QUFBQUEsWUFDQXNCO0FBQUFBLFlBQ0FFO0FBQUFBLFlBQ0F5QztBQUFBQSxZQUNBeEM7QUFBQUEsWUFDQUU7QUFBQUEsWUFDQXFDO0FBQUFBLFlBQ0F6QztBQUFBQSxZQUNBSztBQUFBQTtBQUFBQSxVQUVGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQWpDLHFCQUFlRCxZQUFXO0FBQzFCdUQsY0FBUXFCLElBQUluQixXQUFXLFdBQVc7QUFDbEMzRSxtQkFBYTJFLFNBQVM7QUFDdEIvRCxvQkFBYytELFVBQVVyQixNQUFNO0FBQUEsSUFDaEMsU0FBU3lDLE9BQU87QUFDZHRCLGNBQVFzQixNQUFNLHdCQUF3QkEsS0FBSztBQUFBLElBQzdDLFVBQUM7QUFDQ3JGLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQS9CLFlBQVUsTUFBTTtBQUNkMkYsY0FBVTtBQUFBLEVBQ1osR0FBRyxFQUFFO0FBRUwsUUFBTTBCLGlCQUFpQjtBQUFBLElBQ3JCLEVBQUV4QyxLQUFLLFNBQVN5QyxRQUFRLFNBQVM7QUFBQSxJQUNqQyxFQUFFekMsS0FBSyxhQUFheUMsUUFBUSxjQUFjO0FBQUEsSUFDMUMsRUFBRXpDLEtBQUssWUFBWXlDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDM0MsRUFBRXpDLEtBQUssYUFBYXlDLFFBQVEsZUFBZTtBQUFBO0FBQUEsSUFFM0MsRUFBRXpDLEtBQUssYUFBYXlDLFFBQVEsYUFBYTtBQUFBLElBQ3pDLEVBQUV6QyxLQUFLLFVBQVV5QyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFekMsS0FBSyxhQUFheUMsUUFBUSxhQUFhO0FBQUEsSUFDekMsRUFBRXpDLEtBQUssYUFBYXlDLFFBQVEsYUFBYTtBQUFBLElBQ3pDLEVBQUV6QyxLQUFLLGlCQUFpQnlDLFFBQVEsaUJBQWlCO0FBQUE7QUFBQTtBQUFBLEVBRWpEO0FBR0YsU0FDRSx1QkFBQyxTQUFJLFdBQVUsVUFDYixpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyw2QkFBNkIsQ0FBQ3ZELE1BQU01QyxjQUFjNEMsRUFBRUUsT0FBT3NELEtBQUs7QUFBQSxRQUNoRSxZQUFZO0FBQUE7QUFBQSxNQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUVtQjtBQUFBLElBRW5CLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFRO0FBQUEsSUFFTix1QkFBQyxTQUFJLFdBQVUsaUJBQ1Y7QUFBQSw2QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVc7QUFBQSxNQUNkLHVCQUFDLFFBQUcsV0FBVSx1Q0FBc0MsbUNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BS0NwRjtBQUFBQSxNQUNELHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHNEQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0U7QUFBQSxRQUNoRUwsWUFDTix1QkFBQyxTQUFJLFdBQVUsVUFDYixpQ0FBQyxrQkFBZSxPQUFNLG9CQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNDLEtBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUVJLHVCQUFDLFNBQUksV0FBVSxTQUU3QjtBQUFBLGlDQUFDLFNBQUksV0FBVSxtREFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSx5RUFDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxPQUFFLFdBQVUseUJBQXdCLCtCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRDtBQUFBLGdCQUNwRCx1QkFBQyxPQUFFLFdBQVUsc0NBQ1ZrQix3QkFBYzJCLFVBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxXQUFRLFdBQVUsOEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZDO0FBQUEsaUJBUC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSx3RUFDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxPQUFFLFdBQVUseUJBQXdCLGtDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RDtBQUFBLGdCQUN2RCx1QkFBQyxPQUFFLFdBQVUscUNBQ1ZELGtDQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxpQkFBYyxXQUFVLDZCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRDtBQUFBLGlCQVBwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxVQUNnQix1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTyxFQUFFOEMsT0FBTyxJQUFJO0FBQUEsa0JBQ3BCO0FBQUEsa0JBQ0EsYUFBWTtBQUFBLGtCQUNaLFVBQVUsQ0FBQ0QsVUFBVWhHLGVBQWVnRyxLQUFLO0FBQUEsa0JBQ3pDLE9BQU9qRyxlQUFld0I7QUFBQUEsa0JBQ3RCLFdBQVU7QUFBQSxrQkFFVEwsdUJBQWFNO0FBQUFBLG9CQUFJLENBQUMwRSxVQUNqQix1QkFBQyxPQUFPLFFBQVAsRUFBMEIsT0FBT0EsT0FDL0JBLG1CQURpQkEsT0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFaSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FhQTtBQUFBLGlCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtCQTtBQUFBLFlBRUEsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0MsMEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsU0FBU3BGO0FBQUFBLGtCQUNULFVBQVUsQ0FBQzBCLE1BQU07QUFDZiwwQkFBTUcsVUFBVUgsRUFBRUUsT0FBT0M7QUFDekI1QixpQ0FBYTRCLE9BQU87QUFFcEIsMEJBQU13RCxjQUFjLEVBQUUsR0FBRzlGLGVBQWU7QUFHeENvQixrQ0FBY29DLFFBQVEsQ0FBQzdCLFNBQVM7QUFDOUJtRSxrQ0FBWW5FLEtBQUtHLEdBQUcsSUFBSTtBQUFBLHdCQUN0QkMsTUFBTTtBQUFBLDBCQUNKQyxRQUFRTTtBQUFBQSwwQkFDUkMsV0FBV1osS0FBS1k7QUFBQUEsMEJBQ2hCdEIsV0FBV1UsS0FBS1Y7QUFBQUEsMEJBQ2hCdUIsY0FBY2IsS0FBS2E7QUFBQUEsMEJBQ25CQyxVQUFVZCxLQUFLYztBQUFBQTtBQUFBQSwwQkFFZkMsV0FBV2YsS0FBS2U7QUFBQUEsMEJBQ2hCQyxZQUFZaEIsS0FBS2dCO0FBQUFBLDBCQUNqQkMsV0FBV2pCLEtBQUtpQjtBQUFBQSwwQkFDaEJDLFNBQVNsQixLQUFLa0IsU0FBU2Y7QUFBQUE7QUFBQUEsd0JBRXpCO0FBQUEsc0JBQ0Y7QUFBQSxvQkFDRixDQUFDO0FBRUQ3QixzQ0FBa0I2RixXQUFXO0FBQUEsa0JBQy9CO0FBQUE7QUFBQSxnQkE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBOEJJO0FBQUEsaUJBbENOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0NBO0FBQUEsZUF6REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwREE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUzlDO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBRVRGO0FBQUFBLHVDQUF1QixLQUN0QjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsT0FBTyxpQ0FBaUNBLG9CQUFvQjtBQUFBLG9CQUU1RCxpQ0FBQyxVQUFNQSxrQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE0QjtBQUFBO0FBQUEsa0JBSjlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUVGLHVCQUFDLGNBQVcsV0FBVSxRQUFPLE1BQU0sTUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0M7QUFBQSxnQkFBRztBQUFBO0FBQUE7QUFBQSxZQVozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFjQSxLQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTTFCO0FBQUFBLGNBQ04sU0FBU3FFO0FBQUFBLGNBQ1QsU0FBUTtBQUFBLGNBQ1IsaUJBQWdCO0FBQUEsY0FDaEIsaUJBQWlCLENBQUMsWUFBWTtBQUFBLGNBQzlCLG1CQUFtQixDQUFDL0YsV0FBVztBQUFBLGNBQy9CLGtCQUFrQjtBQUFBO0FBQUEsWUFQcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTzhDO0FBQUEsYUExR2hEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0R0E7QUFBQSxXQW5IRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUhBO0FBQUEsU0EvSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdJQTtBQUFBLE9BdklKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5SUEsS0ExSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJJQTtBQUVKO0FBQUVMLEdBOVdJRCxvQkFBa0I7QUFBQSxVQVNZTixhQUFhMEIsZUFBZTtBQUFBO0FBQUF1RixLQVQxRDNHO0FBZ1hOLGVBQWVBO0FBQW1CLElBQUEyRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VNZW1vIiwiYXBpIiwiRGF0YVRhYmxlIiwiQ2lyY3VsYXJMb2FkZXIiLCJTZWxlY3QiLCJOYXZiYXIiLCJmaWx0ZXJPcHRpb24iLCJGYVdoYXRzYXBwIiwibm90aWZpY2F0aW9uIiwiVGlja2V0IiwiU2lkZWJhciIsIkZhVXNlcnMiLCJGYUNoZWNrQ2lyY2xlIiwiQnJlYWRjcnVtYiIsIkF1Y3Rpb25JbmZvcm1hdGlvbiIsIl9zIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJ1c2Vyc0RhdGEiLCJzZXRVc2Vyc0RhdGEiLCJncm91cEZpbHRlciIsInNldEdyb3VwRmlsdGVyIiwiZnJvbURhdGUiLCJzZXRGcm9tRGF0ZSIsInRvRGF0ZSIsInNldFRvRGF0ZSIsImFjdGl2ZVVzZXJEYXRhIiwic2V0QWN0aXZlVXNlckRhdGEiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJ0b3RhbFVzZXJzIiwic2V0VG90YWxVc2VycyIsIm5vdGlmaWVyIiwiY29udGV4dEhvbGRlciIsInVzZU5vdGlmaWNhdGlvbiIsInNlbGVjdEFsbCIsInNldFNlbGVjdEFsbCIsImF1Y3Rpb25EYXRhIiwic2V0QXVjdGlvbkRhdGEiLCJncm91cE9wdGlvbnMiLCJTZXQiLCJmaWx0ZXIiLCJ1IiwiZ3JvdXBOYW1lIiwidW5kZWZpbmVkIiwibWFwIiwiZmlsdGVyZWRVc2VycyIsImZpbHRlcmVkIiwibWF0Y2hHcm91cCIsImVucm9sbG1lbnREYXRlIiwiRGF0ZSIsIm1hdGNoRnJvbURhdGUiLCJtYXRjaFRvRGF0ZSIsInVzZXIiLCJpbmRleCIsImlzU2VsZWN0ZWQiLCJfaWQiLCJpbmZvIiwic3RhdHVzIiwic2xfbm8iLCJjaGVja0JveHMiLCJlIiwicHJldiIsInRhcmdldCIsImNoZWNrZWQiLCJ1c2VyUGhvbmUiLCJncm91cE1lbWJlcnMiLCJ1c2VyTmFtZSIsIndpbkFtb3VudCIsImJpZFBlcmNlbnQiLCJiaWRBbW91bnQiLCJncm91cElkIiwidmlzaWJsZVNlbGVjdGVkQ291bnQiLCJsZW5ndGgiLCJzZW5kV2hhdHNhcHAiLCJrZXkiLCJvcGVuIiwibWVzc2FnZSIsImRlc2NyaXB0aW9uIiwiY2xhc3NOYW1lIiwiZHVyYXRpb24iLCJ2aXNpYmxlQWN0aXZlVXNlcnMiLCJmb3JFYWNoIiwicG9zdCIsInJlY2VpdmVycyIsIm5ld0FjdGl2ZVVzZXJEYXRhIiwiZXJyIiwiYWxsQ2hlY2tlZCIsImV2ZXJ5IiwiZmV0Y2hEYXRhIiwicmVwb3J0UmVzcG9uc2UiLCJnZXQiLCJjb25zb2xlIiwiZGF0YSIsInVzZXJzTGlzdCIsInRlbXBBY3RpdmUiLCJhdWN0aW9uIiwiaWQiLCJ1c2VyX2lkIiwiZnVsbF9uYW1lIiwiZ3JvdXBfaWQiLCJwaG9uZV9udW1iZXIiLCJncm91cF9uYW1lIiwiZ3JvdXBfbWVtYmVycyIsIndpbl9hbW91bnQiLCJOdW1iZXIiLCJncm91cF92YWx1ZSIsImJpZFBlcmNlbnRhZ2UiLCJ0aWNrZXQiLCJ0ZW1wVXNlciIsImNyZWF0ZWRBdCIsInB1c2giLCJzbE5vIiwibG9nIiwiZXJyb3IiLCJBdWN0aW9uY29sdW1ucyIsImhlYWRlciIsInZhbHVlIiwid2lkdGgiLCJncm91cCIsInVwZGF0ZWREYXRhIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXVjdGlvbkluZm9ybWF0aW9uLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlTWVtbyB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgU2VsZWN0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgeyBGYVdoYXRzYXBwIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IG5vdGlmaWNhdGlvbiB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IFRpY2tldCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCB7IEZhVXNlcnMsIEZhQ2hlY2tDaXJjbGUgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IEJyZWFkY3J1bWIgZnJvbSBcIi4uL2hlbHBlcnMvQnJlYWRjcnVtYlwiO1xyXG5cclxuXHJcbmNvbnN0IEF1Y3Rpb25JbmZvcm1hdGlvbiA9ICgpID0+IHtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbdXNlcnNEYXRhLCBzZXRVc2Vyc0RhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtncm91cEZpbHRlciwgc2V0R3JvdXBGaWx0ZXJdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2Zyb21EYXRlLCBzZXRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbdG9EYXRlLCBzZXRUb0RhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FjdGl2ZVVzZXJEYXRhLCBzZXRBY3RpdmVVc2VyRGF0YV0gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdG90YWxVc2Vycywgc2V0VG90YWxVc2Vyc10gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbbm90aWZpZXIsIGNvbnRleHRIb2xkZXJdID0gbm90aWZpY2F0aW9uLnVzZU5vdGlmaWNhdGlvbigpO1xyXG4gIGNvbnN0IFtzZWxlY3RBbGwsIHNldFNlbGVjdEFsbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2F1Y3Rpb25EYXRhLCBzZXRBdWN0aW9uRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4gIC8vY29uc3QgZ3JvdXBPcHRpb25zID0gWy4uLm5ldyBTZXQodXNlcnNEYXRhLm1hcCgodSkgPT4gdS5ncm91cE5hbWUpKV07XHJcbiAgY29uc3QgZ3JvdXBPcHRpb25zID0gW1xyXG4gICAgLi4ubmV3IFNldChcclxuICAgICAgdXNlcnNEYXRhXHJcbiAgICAgICAgLmZpbHRlcihcclxuICAgICAgICAgICh1KSA9PlxyXG4gICAgICAgICAgICB1Lmdyb3VwTmFtZSAhPT0gdW5kZWZpbmVkICYmXHJcbiAgICAgICAgICAgIHUuZ3JvdXBOYW1lICE9PSBcIlwiICYmXHJcbiAgICAgICAgICAgIHUuZ3JvdXBOYW1lICE9PSBcIiAgIFwiXHJcbiAgICAgICAgKSAvLyBGaWx0ZXIgb3V0IHVuZGVmaW5lZCwgZW1wdHksIGFuZCB3aGl0ZXNwYWNlLW9ubHkgdmFsdWVzXHJcbiAgICAgICAgLm1hcCgodSkgPT4gdS5ncm91cE5hbWUpXHJcbiAgICApLFxyXG4gIF07XHJcbiAgY29uc3QgZmlsdGVyZWRVc2VycyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgZmlsdGVyZWQgPSBmaWx0ZXJPcHRpb24oXHJcbiAgICAgIHVzZXJzRGF0YS5maWx0ZXIoKHUpID0+IHtcclxuICAgICAgICBjb25zdCBtYXRjaEdyb3VwID0gZ3JvdXBGaWx0ZXIgPyB1Lmdyb3VwTmFtZSA9PT0gZ3JvdXBGaWx0ZXIgOiB0cnVlO1xyXG4gICAgICAgIGNvbnN0IGVucm9sbG1lbnREYXRlID0gbmV3IERhdGUodS5lbnJvbGxtZW50RGF0ZSk7XHJcbiAgICAgICAgY29uc3QgbWF0Y2hGcm9tRGF0ZSA9IGZyb21EYXRlXHJcbiAgICAgICAgICA/IGVucm9sbG1lbnREYXRlID49IG5ldyBEYXRlKGZyb21EYXRlKVxyXG4gICAgICAgICAgOiB0cnVlO1xyXG4gICAgICAgIGNvbnN0IG1hdGNoVG9EYXRlID0gdG9EYXRlID8gZW5yb2xsbWVudERhdGUgPD0gbmV3IERhdGUodG9EYXRlKSA6IHRydWU7XHJcbiAgICAgICAgcmV0dXJuIG1hdGNoR3JvdXAgJiYgbWF0Y2hGcm9tRGF0ZSAmJiBtYXRjaFRvRGF0ZTtcclxuICAgICAgfSksXHJcbiAgICAgIHNlYXJjaFRleHRcclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGZpbHRlcmVkLm1hcCgodXNlciwgaW5kZXgpID0+IHtcclxuICAgICAgY29uc3QgaXNTZWxlY3RlZCA9ICEhYWN0aXZlVXNlckRhdGFbdXNlci5faWRdPy5pbmZvPy5zdGF0dXM7XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLnVzZXIsXHJcbiAgICAgICAgc2xfbm86IGluZGV4ICsgMSxcclxuICAgICAgICBjaGVja0JveHM6IChcclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICBjaGVja2VkPXtpc1NlbGVjdGVkfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICBzZXRBY3RpdmVVc2VyRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICBbdXNlci5faWRdOiB7XHJcbiAgICAgICAgICAgICAgICAgIGluZm86IHtcclxuICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlclBob25lOiB1c2VyLnVzZXJQaG9uZSxcclxuICAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIGdyb3VwTWVtYmVyczogdXNlci5ncm91cE1lbWJlcnMsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlck5hbWU6IHVzZXIudXNlck5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gIHRpY2tldDogdXNlci50aWNrZXQsXHJcbiAgICAgICAgICAgICAgICAgICAgd2luQW1vdW50OiB1c2VyLndpbkFtb3VudCxcclxuICAgICAgICAgICAgICAgICAgICBiaWRQZXJjZW50OiB1c2VyLmJpZFBlcmNlbnQsXHJcbiAgICAgICAgICAgICAgICAgICAgYmlkQW1vdW50OiB1c2VyLmJpZEFtb3VudCxcclxuICAgICAgICAgICAgICAgICAgICBncm91cElkOiB1c2VyLmdyb3VwSWQ/Ll9pZCxcclxuICAgICAgICAgICAgICAgICAgICAvLyB1c2VySWQ6IHVzZXIudXNlcklkLFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICksXHJcbiAgICAgICAgaXNTZWxlY3RlZCxcclxuICAgICAgfTtcclxuICAgIH0pO1xyXG4gIH0sIFt1c2Vyc0RhdGEsIGdyb3VwRmlsdGVyLCBmcm9tRGF0ZSwgdG9EYXRlLCBzZWFyY2hUZXh0LCBhY3RpdmVVc2VyRGF0YV0pO1xyXG5cclxuICBjb25zdCB2aXNpYmxlU2VsZWN0ZWRDb3VudCA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGZpbHRlcmVkVXNlcnMuZmlsdGVyKCh1c2VyKSA9PiB1c2VyLmlzU2VsZWN0ZWQpLmxlbmd0aDtcclxuICB9LCBbZmlsdGVyZWRVc2Vyc10pO1xyXG5cclxuICBjb25zdCBzZW5kV2hhdHNhcHAgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCBrZXkgPSBcInVwZGF0YWJsZVwiO1xyXG4gICAgdHJ5IHtcclxuICAgICAgbm90aWZpZXIub3Blbih7XHJcbiAgICAgICAga2V5LFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiU2VuZGluZyBNZXNzYWdlcyBWaWEgV2hhdHNhcHAuLlwiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlByb2Nlc3NpbmcuLi5cIixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYmctZ3JlZW4tMzAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbiAgICAgICAgZHVyYXRpb246IDIsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgdmlzaWJsZUFjdGl2ZVVzZXJzID0ge307XHJcbiAgICAgIGZpbHRlcmVkVXNlcnMuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4gICAgICAgIGlmICh1c2VyLmlzU2VsZWN0ZWQgJiYgYWN0aXZlVXNlckRhdGFbdXNlci5faWRdKSB7XHJcbiAgICAgICAgICB2aXNpYmxlQWN0aXZlVXNlcnNbdXNlci5faWRdID0gYWN0aXZlVXNlckRhdGFbdXNlci5faWRdO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcblxyXG4gICAgICBhd2FpdCBhcGkucG9zdChcIi93aGF0c2FwcC9hdWN0aW9uLXdpbm5lci1kb2N1bWVudC1saXN0XCIsIHtcclxuICAgICAgICByZWNlaXZlcnM6IHZpc2libGVBY3RpdmVVc2VycyxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCBuZXdBY3RpdmVVc2VyRGF0YSA9IHsgLi4uYWN0aXZlVXNlckRhdGEgfTtcclxuICAgICAgZmlsdGVyZWRVc2Vycy5mb3JFYWNoKCh1c2VyKSA9PiB7XHJcbiAgICAgICAgaWYgKHVzZXIuaXNTZWxlY3RlZCkge1xyXG4gICAgICAgICAgZGVsZXRlIG5ld0FjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRBY3RpdmVVc2VyRGF0YShuZXdBY3RpdmVVc2VyRGF0YSk7XHJcblxyXG4gICAgICBub3RpZmllci5vcGVuKHtcclxuICAgICAgICBrZXksXHJcbiAgICAgICAgbWVzc2FnZTogXCJXaGF0c2FwcCBNZXNzYWdlcyBIYXMgQmVlbiBTZW50IFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlN1Y2Nlc3NcIixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYmctZ3JlZW4tMzAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbiAgICAgICAgZHVyYXRpb246IDIsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIG5vdGlmaWVyLm9wZW4oe1xyXG4gICAgICAgIGtleSxcclxuICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBTZW5kIFdoYXRzYXBwXCIsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IGVyci5tZXNzYWdlIHx8IFwiU29tZXRoaW5nIHdlbnQgd3JvbmdcIixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYmctcmVkLTMwMCByb3VuZGVkLWxnIGZvbnQtYm9sZFwiLFxyXG4gICAgICAgIGR1cmF0aW9uOiAyLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAvLyBBdXRvbWF0aWNhbGx5IHVwZGF0ZSBzZWxlY3RBbGwgYmFzZWQgb24gZmlsdGVyZWRVc2Vyc1xyXG4gICAgY29uc3QgYWxsQ2hlY2tlZCA9XHJcbiAgICAgIGZpbHRlcmVkVXNlcnMubGVuZ3RoID4gMCAmJlxyXG4gICAgICBmaWx0ZXJlZFVzZXJzLmV2ZXJ5KCh1c2VyKSA9PiBhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF0/LmluZm8/LnN0YXR1cyk7XHJcbiAgICBzZXRTZWxlY3RBbGwoYWxsQ2hlY2tlZCk7XHJcbiAgfSwgW2ZpbHRlcmVkVXNlcnMsIGFjdGl2ZVVzZXJEYXRhXSk7XHJcbiAgY29uc3QgZmV0Y2hEYXRhID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICBjb25zdCByZXBvcnRSZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYXVjdGlvbi9nZXQtYXVjdGlvblwiKTtcclxuICAgICAgY29uc29sZS5pbmZvKHJlcG9ydFJlc3BvbnNlLmRhdGEsIFwiZ2hzamdzamdcIik7XHJcbiAgICAgIGNvbnN0IHVzZXJzTGlzdCA9IFtdO1xyXG4gICAgICBjb25zdCB0ZW1wQWN0aXZlID0ge307XHJcblxyXG4gICAgICBjb25zdCBhdWN0aW9uRGF0YSA9IHJlcG9ydFJlc3BvbnNlLmRhdGE/LmF1Y3Rpb24/Lm1hcChcclxuICAgICAgICAoYXVjdGlvbiwgaW5kZXgpID0+IHtcclxuICAgICAgICAgIGNvbnN0IGlkID0gYXVjdGlvbi5faWQ7XHJcbiAgICAgICAgICBjb25zdCB1c2VyTmFtZSA9IGF1Y3Rpb24udXNlcl9pZD8uZnVsbF9uYW1lO1xyXG4gICAgICAgICAgY29uc3QgZ3JvdXBJZCA9IGF1Y3Rpb24uZ3JvdXBfaWQ7XHJcbiAgICAgICAgICBjb25zdCB1c2VyUGhvbmUgPSBhdWN0aW9uLnVzZXJfaWQ/LnBob25lX251bWJlcjtcclxuICAgICAgICAgIGNvbnN0IGdyb3VwTmFtZSA9IGF1Y3Rpb24uZ3JvdXBfaWQ/Lmdyb3VwX25hbWU7XHJcbiAgICAgICAgICBjb25zdCBncm91cE1lbWJlcnMgPSBhdWN0aW9uLmdyb3VwX2lkPy5ncm91cF9tZW1iZXJzO1xyXG4gICAgICAgICAgY29uc3Qgd2luQW1vdW50ID0gYXVjdGlvbj8ud2luX2Ftb3VudDtcclxuICAgICAgICAgIGNvbnN0IGJpZEFtb3VudCA9XHJcbiAgICAgICAgICAgIE51bWJlcihhdWN0aW9uPy5ncm91cF9pZD8uZ3JvdXBfdmFsdWUpIC1cclxuICAgICAgICAgICAgTnVtYmVyKGF1Y3Rpb24/Lndpbl9hbW91bnQpO1xyXG4gICAgICAgICAgY29uc3QgYmlkUGVyY2VudGFnZSA9XHJcbiAgICAgICAgICAgIChOdW1iZXIoYmlkQW1vdW50KSAqIDEwMCkgLyBOdW1iZXIoYXVjdGlvbj8uZ3JvdXBfaWQ/Lmdyb3VwX3ZhbHVlKTtcclxuICAgICAgICAgIGNvbnN0IHRpY2tldCA9IGF1Y3Rpb24udGlja2V0O1xyXG4gICAgICAgICAgLy8gIGNvbnN0IGluc3RhbGxtZW50TnVtYmVyID0gaW5kZXggKyAxO1xyXG5cclxuICAgICAgICAgIHRlbXBBY3RpdmVbaWRdID0ge1xyXG4gICAgICAgICAgICBpbmZvOiB7IHN0YXR1czogZmFsc2UgfSxcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgICBjb25zdCB0ZW1wVXNlciA9IHtcclxuICAgICAgICAgICAgX2lkOiBpZCxcclxuICAgICAgICAgICAgdXNlck5hbWUsXHJcbiAgICAgICAgICAgIHVzZXJQaG9uZSxcclxuICAgICAgICAgICAgZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgICB0aWNrZXQsXHJcbiAgICAgICAgICAgIHdpbkFtb3VudCxcclxuICAgICAgICAgICAgZ3JvdXBNZW1iZXJzLFxyXG4gICAgICAgICAgICBlbnJvbGxtZW50RGF0ZTogYXVjdGlvbi5ncm91cF9pZD8uY3JlYXRlZEF0LFxyXG4gICAgICAgICAgICBiaWRBbW91bnQsXHJcbiAgICAgICAgICAgIGdyb3VwSWQsXHJcbiAgICAgICAgICAgIGJpZFBlcmNlbnRhZ2UsXHJcbiAgICAgICAgICAgIC8vICBpbnN0YWxsbWVudE51bWJlcixcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgICB1c2Vyc0xpc3QucHVzaCh0ZW1wVXNlcik7XHJcblxyXG4gICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgc2xObzogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICBncm91cE5hbWUsXHJcbiAgICAgICAgICAgIHVzZXJQaG9uZSxcclxuICAgICAgICAgICAgdXNlck5hbWUsXHJcbiAgICAgICAgICAgIHRpY2tldCxcclxuICAgICAgICAgICAgd2luQW1vdW50LFxyXG4gICAgICAgICAgICBiaWRBbW91bnQsXHJcbiAgICAgICAgICAgIGJpZFBlcmNlbnRhZ2UsXHJcbiAgICAgICAgICAgIGdyb3VwTWVtYmVycyxcclxuICAgICAgICAgICAgZ3JvdXBJZCxcclxuICAgICAgICAgICAgLy8gaW5zdGFsbG1lbnROdW1iZXI6IGluZGV4ICsgMSxcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICApO1xyXG4gICAgICBzZXRBdWN0aW9uRGF0YShhdWN0aW9uRGF0YSk7XHJcbiAgICAgIGNvbnNvbGUubG9nKHVzZXJzTGlzdCwgXCJ1c2Vyc2xpc3RcIik7XHJcbiAgICAgIHNldFVzZXJzRGF0YSh1c2Vyc0xpc3QpO1xyXG4gICAgICBzZXRUb3RhbFVzZXJzKHVzZXJzTGlzdC5sZW5ndGgpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGRhdGE6XCIsIGVycm9yKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoRGF0YSgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgQXVjdGlvbmNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJzbF9ub1wiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImNoZWNrQm94c1wiLCBoZWFkZXI6IFwiU2VsZWN0IFVzZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlck5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlclBob25lXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgLy8geyBrZXk6IFwiY3VzdG9tZXJJZFwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgSWRcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBOYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInRpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0XCIgfSxcclxuICAgIHsga2V5OiBcIndpbkFtb3VudFwiLCBoZWFkZXI6IFwid2luIEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJiaWRBbW91bnRcIiwgaGVhZGVyOiBcIkJpZCBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmlkUGVyY2VudGFnZVwiLCBoZWFkZXI6IFwiQmlkIFBlcmNlbnRhZ2VcIiB9LFxyXG4gICAgLy8gIHtrZXk6IFwiaW5zdGFsbG1lbnROdW1iZXJcIiwgaGVhZGVyOiBcImluc3RhbGxtZW50IE51bWJlclwifVxyXG4gICAgLy8gIHtrZXk6IFwicGF5bWVudHNUaWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwifSxcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXsoZSkgPT4gc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPFNpZGViYXIvPlxyXG4gICAgICAgXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWNlbnRlciBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgQXVjdGlvbiBJbmZvcm1hdGlvblxyXG4gICAgICAgICAgICA8L2gxPlxyXG5cclxuXHJcblxyXG5cclxuICAgICAgICAgICAge2NvbnRleHRIb2xkZXJ9XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi04XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktc3RhcnQgYm9yZGVyLWIgYm9yZGVyLWdyYXktMzAwIG1iLTRcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBjb2xvcj1cInRleHQtZ3JlZW4tNjAwXCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMFwiPlxyXG4gICAgICAgICAgICAgICAgey8qID09PT09IFNVTU1BUlkgU0VDVElPTiA9PT09PSAqL31cclxuPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC02IG10LTggbWItNlwiPlxyXG4gIDxkaXYgY2xhc3NOYW1lPVwiYmctdmlvbGV0LTEwMCByb3VuZGVkLXhsIHAtNiBzaGFkb3cgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICA8ZGl2PlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5Ub3RhbCBDdXN0b21lcnM8L3A+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LXZpb2xldC03MDBcIj5cclxuICAgICAgICB7ZmlsdGVyZWRVc2Vycy5sZW5ndGh9XHJcbiAgICAgIDwvcD5cclxuICAgIDwvZGl2PlxyXG4gICAgPEZhVXNlcnMgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwIHRleHQtNHhsXCIgLz5cclxuICA8L2Rpdj5cclxuXHJcbiAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmVlbi0xMDAgcm91bmRlZC14bCBwLTYgc2hhZG93IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgPGRpdj5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+U2VsZWN0ZWQgQ3VzdG9tZXJzPC9wPlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmVlbi03MDBcIj5cclxuICAgICAgICB7dmlzaWJsZVNlbGVjdGVkQ291bnR9XHJcbiAgICAgIDwvcD5cclxuICAgIDwvZGl2PlxyXG4gICAgPEZhQ2hlY2tDaXJjbGUgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDAgdGV4dC00eGxcIiAvPlxyXG4gIDwvZGl2PlxyXG48L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBHcm91cFxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDIwMCB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCItLUFsbCBncm91cHMtLVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBzZXRHcm91cEZpbHRlcih2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXBGaWx0ZXIgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LXhzIGgtMTEgXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXBPcHRpb25zLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtncm91cH0gdmFsdWU9e2dyb3VwfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgQWxsXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC00IHctNCBoLTQgbWItM1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtzZWxlY3RBbGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY2hlY2tlZCA9IGUudGFyZ2V0LmNoZWNrZWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdEFsbChjaGVja2VkKTsgLy8gU2V0IGdsb2JhbCBjaGVja2JveCBzdGF0ZVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdXBkYXRlZERhdGEgPSB7IC4uLmFjdGl2ZVVzZXJEYXRhIH07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBMb29wIHRocm91Z2ggYWxsIGZpbHRlcmVkIHVzZXJzIGFuZCBhcHBseSB0aGUgc2VsZWN0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcmVkVXNlcnMuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWREYXRhW3VzZXIuX2lkXSA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZm86IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBjaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyUGhvbmU6IHVzZXIudXNlclBob25lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cE1lbWJlcnM6IHVzZXIuZ3JvdXBNZW1iZXJzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyTmFtZTogdXNlci51c2VyTmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gIHRpY2tldDogdXNlci50aWNrZXQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpbkFtb3VudDogdXNlci53aW5BbW91bnQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJpZFBlcmNlbnQ6IHVzZXIuYmlkUGVyY2VudCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmlkQW1vdW50OiB1c2VyLmJpZEFtb3VudCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXBJZDogdXNlci5ncm91cElkPy5faWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHVzZXJJZDogdXNlci51c2VySWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlVXNlckRhdGEodXBkYXRlZERhdGEpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3NlbmRXaGF0c2FwcH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSBiZy1ncmVlbi02MDAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZCBzaGFkb3ctbWQgaG92ZXI6YmctZ3JlZW4tNzAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwIGZsZXggaXRlbXMtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHt2aXNpYmxlU2VsZWN0ZWRDb3VudCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtaW4tdy02IGgtNiBhYnNvbHV0ZSAtcmlnaHQtMyAtdG9wLTIgc2hhZG93LWxnIGhvdmVyOmJnLXJlZC02MDAgYmctcmVkLTQwMCByb3VuZGVkLWZ1bGwgdGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXhzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e2BNZXNzYWdlIHdpbGwgYmUgc2VudCB0byB0b3RhbCAke3Zpc2libGVTZWxlY3RlZENvdW50fSBjdXN0b21lcnNgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57dmlzaWJsZVNlbGVjdGVkQ291bnR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8RmFXaGF0c2FwcCBjbGFzc05hbWU9XCJtci0yXCIgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgV2hhdHNBcHBcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyZWRVc2Vyc31cclxuICAgICAgICAgICAgICAgICAgY29sdW1ucz17QXVjdGlvbmNvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgIGNhdGNoZXI9XCJfaWRcIlxyXG4gICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJBdWN0aW9uIEluZm9ybWF0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtbXCJHcm91cCBOYW1lXCJdfVxyXG4gICAgICAgICAgICAgICAgICBwcmludEhlYWRlclZhbHVlcz17W2dyb3VwRmlsdGVyXX1cclxuICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YEF1Y3Rpb24gSW5mb3JtYXRpb24uY3N2YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICBcclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQXVjdGlvbkluZm9ybWF0aW9uO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvQXVjdGlvbkluZm9ybWF0aW9uLmpzeCJ9