import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PigmyPayoutReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import DataTable from "/src/components/layouts/Datatable.jsx";
import api from "/src/instance/TokenInstance.js";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { Select, Dropdown } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
const PigmyPayoutReport = () => {
  _s();
  const [dataTable, setDataTable] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedFromDate, setSelectedFromDate] = useState("");
  const [selectedToDate, setSelectedToDate] = useState("");
  const [showFilterField, setShowFilterField] = useState(false);
  const [summary, setSummary] = useState({
    totalAmount: 0,
    totalCount: 0,
    totalUsers: 0
  });
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [formData, setFormData] = useState({
    user: "",
    filterType: "Today"
  });
  const handleAntDSelect = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };
  const formatDate = (date) => date.toLocaleDateString("en-CA");
  const handleSelectFilter = (value) => {
    setShowFilterField(false);
    const today = /* @__PURE__ */ new Date();
    let from = "";
    let to = "";
    if (value === "Today") {
      from = to = formatDate(today);
    } else if (value === "Yesterday") {
      const y = new Date(today);
      y.setDate(today.getDate() - 1);
      from = to = formatDate(y);
    } else if (value === "ThisMonth") {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      from = formatDate(start);
      to = formatDate(end);
    } else if (value === "Custom") {
      setShowFilterField(true);
      return;
    }
    setSelectedFromDate(from);
    setSelectedToDate(to);
  };
  useEffect(() => {
    handleSelectFilter(formData.filterType);
  }, [formData.filterType]);
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await api.get("/user/get-user");
        setUsers(res.data || []);
      } catch (err) {
        console.error("Error fetching users:", err);
      }
    };
    fetchUsers();
  }, []);
  const fetchPigmyPayouts = async () => {
    try {
      setLoading(true);
      let url = `v1/admin/payments-out/pigme-payout`;
      const params = new URLSearchParams();
      if (formData.user) params.append("user_id", formData.user);
      if (selectedFromDate) params.append("from_date", selectedFromDate);
      if (selectedToDate) params.append("to_date", selectedToDate);
      if (params.toString()) url += `?${params.toString()}`;
      const res = await api.get(url);
      const data = res?.data?.data || [];
      const totalAmount = data.reduce(
        (sum, item) => sum + Number(item?.amount || 0),
        0
      );
      const uniqueUsers = new Set(data.map((d) => d?.user_id?._id).filter(Boolean));
      setSummary({
        totalAmount,
        totalCount: data.length,
        totalUsers: uniqueUsers.size
      });
      const formatted = data.map((item, index) => {
        const pigme = item?.pigme || {};
        const user = item?.user_id || {};
        let referred_by = "N/A";
        const refType = pigme?.referred_type;
        if (refType === "Employee") {
          const emp = pigme?.referred_employee;
          if (emp) {
            referred_by = `${emp.name} | ${emp.phone_number || emp.employeeCode || ""}`;
          }
        } else if (refType === "Agent") {
          const agent = pigme?.referred_agent;
          if (agent) {
            referred_by = `${agent.name} | ${agent.phone_number || ""}`;
          }
        } else if (refType === "Customer") {
          const cust = pigme?.referred_customer;
          if (cust) {
            referred_by = `${cust.full_name} | ${cust.phone_number || ""}`;
          }
        }
        let statusBadge = null;
        const reqStatus = pigme?.request_status;
        if (reqStatus === "REQUESTED") {
          statusBadge = /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800", children: "Requested" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
            lineNumber: 149,
            columnNumber: 11
          }, this);
        } else if (reqStatus === "APPROVED") {
          statusBadge = /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800", children: "Approved" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
            lineNumber: 155,
            columnNumber: 11
          }, this);
        } else if (reqStatus === "CLOSED" || reqStatus === "DONE") {
          statusBadge = /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-800", children: reqStatus === "DONE" ? "Closed (Done)" : "Closed" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
            lineNumber: 161,
            columnNumber: 11
          }, this);
        } else {
          statusBadge = /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: "-" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
            lineNumber: 166,
            columnNumber: 25
          }, this);
        }
        return {
          id: item?._id,
          slNo: index + 1,
          // Basic customer info
          name: user?.full_name || "-",
          phone: user?.phone_number || "-",
          start_date: pigme?.start_date?.split("T")[0].split("-").reverse().join("-") || "-",
          // Pigmy details
          pigmyId: pigme?.pigme_id || "-",
          maturityPeriod: pigme?.maturity_period || "-",
          payableAmount: pigme?.payable_amount || "-",
          payment_details: `${pigme?.maturity_period || ""} – ₹${pigme?.payable_amount || "0"}`,
          duration: pigme?.duration ? `${pigme.duration} Months` : "-",
          maturity_amount: pigme?.maturity_amount,
          // Financials
          total_paid: Number(pigme?.total_paid || 0),
          payType: item?.pay_type || "-",
          transactionId: item?.transaction_id || "-",
          receipt: item?.receipt_no || "-",
          date: item?.pay_date?.split("T")[0].split("-").reverse().join("-") || "-",
          // -------- NEW FIELDS (from borrower code) --------
          referred_type: pigme?.referred_type || "N/A",
          referred_by,
          // computed above
          status: statusBadge,
          // JSX badge
          closure_type: pigme?.closure_type || "-",
          is_prized: pigme?.is_prized ? "Yes" : "No",
          // Action dropdown (keep as is)
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              trigger: ["click"],
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-purple-600",
                        onClick: () => handlePrint(item._id),
                        children: "Print"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
                        lineNumber: 214,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
                lineNumber: 226,
                columnNumber: 33
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
              lineNumber: 207,
              columnNumber: 29
            },
            this
          ) }, item._id, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
            lineNumber: 206,
            columnNumber: 11
          }, this)
        };
      });
      setDataTable(formatted);
    } catch (err) {
      console.error("❌ Pigmy Payout Fetch Error:", err);
      setAlertConfig({
        visibility: true,
        message: "Failed to fetch pigmy payout data",
        type: "error"
      });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    if (selectedFromDate && selectedToDate) {
      fetchPigmyPayouts();
    }
  }, [selectedFromDate, selectedToDate, formData.user]);
  const handlePrint = async (payoutId) => {
    try {
      window.open(`/print/pigmy-payout/${payoutId}`, "_blank");
    } catch (error) {
      console.error("Print error:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to generate print",
        type: "error"
      });
    }
  };
  const columns = [
    { key: "slNo", header: "Sl No" },
    { key: "pigmyId", header: "Pigmy ID" },
    { key: "date", header: "Pay Date" },
    { key: "name", header: "Customer Name" },
    { key: "phone", header: "Phone" },
    { key: "start_date", header: "Start Date" },
    { key: "duration", header: "Duration (Months)" },
    { key: "closure_type", header: "Closure Type" },
    { key: "receipt", header: "Receipt No" },
    // { key: "payableAmount", header: "Payable Amount" },
    { key: "payment_details", header: "Payment Details" },
    { key: "payType", header: "Pay Type" },
    { key: "transactionId", header: "Transaction ID" },
    { key: "total_paid", header: "Paid Amount" },
    { key: "maturity_amount", header: "Maturity Amount" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-10", children: [
    /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
      lineNumber: 290,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
        lineNumber: 291,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 overflow-x-hidden", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold mb-6", children: "Pigmy Payment Out Report" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
        lineNumber: 301,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-end gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-1/4", children: /* @__PURE__ */ jsxDEV(
          Select,
          {
            className: "w-full h-[42px]",
            placeholder: "All Users",
            popupMatchSelectWidth: false,
            showSearch: true,
            filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
            value: formData.user || void 0,
            onChange: (val) => handleAntDSelect("user", val),
            children: [
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
                lineNumber: 318,
                columnNumber: 29
              }, this),
              users.map(
                (u) => /* @__PURE__ */ jsxDEV(Select.Option, { value: u._id, children: u.full_name }, u._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
                  lineNumber: 320,
                  columnNumber: 15
                }, this)
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
            lineNumber: 307,
            columnNumber: 25
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
          lineNumber: 306,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-1/4", children: /* @__PURE__ */ jsxDEV(
          Select,
          {
            className: "w-full h-[42px]",
            value: formData.filterType,
            onChange: (val) => handleAntDSelect("filterType", val),
            children: [
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "Today", children: "Today" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
                lineNumber: 334,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "Yesterday", children: "Yesterday" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
                lineNumber: 335,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "ThisMonth", children: "This Month" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
                lineNumber: 336,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "Custom", children: "Custom" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
                lineNumber: 337,
                columnNumber: 29
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
            lineNumber: 329,
            columnNumber: 25
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
          lineNumber: 328,
          columnNumber: 21
        }, this),
        showFilterField && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-1/5", children: /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "date",
              className: "w-full h-[42px] px-3 border border-gray-300 rounded-lg",
              value: selectedFromDate,
              onChange: (e) => setSelectedFromDate(e.target.value)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
              lineNumber: 345,
              columnNumber: 33
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
            lineNumber: 344,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-1/5", children: /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "date",
              className: "w-full h-[42px] px-3 border border-gray-300 rounded-lg",
              value: selectedToDate,
              onChange: (e) => setSelectedToDate(e.target.value)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
              lineNumber: 354,
              columnNumber: 33
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
            lineNumber: 353,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
          lineNumber: 343,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
        lineNumber: 304,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-4 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-100 p-4 rounded", children: [
          /* @__PURE__ */ jsxDEV("p", { children: "Total Amount" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
            lineNumber: 368,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { children: [
            "₹",
            summary.totalAmount.toLocaleString()
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
            lineNumber: 369,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
          lineNumber: 367,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 p-4 rounded", children: [
          /* @__PURE__ */ jsxDEV("p", { children: "Total Transactions" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
            lineNumber: 373,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { children: summary.totalCount }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
            lineNumber: 374,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
          lineNumber: 372,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-yellow-100 p-4 rounded", children: [
          /* @__PURE__ */ jsxDEV("p", { children: "Total Customers" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
            lineNumber: 378,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { children: summary.totalUsers }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
            lineNumber: 379,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
          lineNumber: 377,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
        lineNumber: 366,
        columnNumber: 17
      }, this),
      dataTable.length > 0 && !loading ? /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          columns,
          data: dataTable,
          exportedFileName: "Pigmy_Payout_Report"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
          lineNumber: 385,
          columnNumber: 9
        },
        this
      ) : /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: loading }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
        lineNumber: 391,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
      lineNumber: 300,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx",
    lineNumber: 289,
    columnNumber: 5
  }, this);
};
_s(PigmyPayoutReport, "dTdIN1VLV2MwGCkBoz608z+Vu6M=");
_c = PigmyPayoutReport;
export default PigmyPayoutReport;
var _c;
$RefreshReg$(_c, "PigmyPayoutReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PigmyPayoutReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0p3QixTQWtNQSxVQWxNQTsyQkFwSnhCO0FBQW1CQSxvQkFBaUIsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzQyxPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLFFBQVFDLGdCQUFnQjtBQUNqQyxPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLHVCQUF1QjtBQUU5QixNQUFNQyxvQkFBb0JBLE1BQU07QUFBQUMsS0FBQTtBQUM1QixRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSUMsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJRixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDRyxTQUFTQyxVQUFVLElBQUlKLFNBQVMsS0FBSztBQUU1QyxRQUFNLENBQUNLLGtCQUFrQkMsbUJBQW1CLElBQUlOLFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUNPLGdCQUFnQkMsaUJBQWlCLElBQUlSLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNTLGlCQUFpQkMsa0JBQWtCLElBQUlWLFNBQVMsS0FBSztBQUU1RCxRQUFNLENBQUNXLFNBQVNDLFVBQVUsSUFBSVosU0FBUztBQUFBLElBQ25DYSxhQUFhO0FBQUEsSUFDYkMsWUFBWTtBQUFBLElBQ1pDLFlBQVk7QUFBQSxFQUNoQixDQUFDO0FBRUQsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUlqQixTQUFTO0FBQUEsSUFDM0NrQixZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNWLENBQUM7QUFFRCxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSXRCLFNBQVM7QUFBQSxJQUNyQ3VCLE1BQU07QUFBQSxJQUNOQyxZQUFZO0FBQUEsRUFDaEIsQ0FBQztBQUdELFFBQU1DLG1CQUFtQkEsQ0FBQ0MsT0FBT0MsVUFBVTtBQUN2Q0wsZ0JBQVksQ0FBQ00sVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0YsS0FBSyxHQUFHQyxNQUFNLEVBQUU7QUFBQSxFQUN2RDtBQUVBLFFBQU1FLGFBQWFBLENBQUNDLFNBQVNBLEtBQUtDLG1CQUFtQixPQUFPO0FBRzVELFFBQU1DLHFCQUFxQkEsQ0FBQ0wsVUFBVTtBQUNsQ2pCLHVCQUFtQixLQUFLO0FBRXhCLFVBQU11QixRQUFRLG9CQUFJQyxLQUFLO0FBQ3ZCLFFBQUlDLE9BQU87QUFDWCxRQUFJQyxLQUFLO0FBRVQsUUFBSVQsVUFBVSxTQUFTO0FBQ25CUSxhQUFPQyxLQUFLUCxXQUFXSSxLQUFLO0FBQUEsSUFDaEMsV0FBV04sVUFBVSxhQUFhO0FBQzlCLFlBQU1VLElBQUksSUFBSUgsS0FBS0QsS0FBSztBQUN4QkksUUFBRUMsUUFBUUwsTUFBTU0sUUFBUSxJQUFJLENBQUM7QUFDN0JKLGFBQU9DLEtBQUtQLFdBQVdRLENBQUM7QUFBQSxJQUM1QixXQUFXVixVQUFVLGFBQWE7QUFDOUIsWUFBTWEsUUFBUSxJQUFJTixLQUFLRCxNQUFNUSxZQUFZLEdBQUdSLE1BQU1TLFNBQVMsR0FBRyxDQUFDO0FBQy9ELFlBQU1DLE1BQU0sSUFBSVQsS0FBS0QsTUFBTVEsWUFBWSxHQUFHUixNQUFNUyxTQUFTLElBQUksR0FBRyxDQUFDO0FBQ2pFUCxhQUFPTixXQUFXVyxLQUFLO0FBQ3ZCSixXQUFLUCxXQUFXYyxHQUFHO0FBQUEsSUFDdkIsV0FBV2hCLFVBQVUsVUFBVTtBQUMzQmpCLHlCQUFtQixJQUFJO0FBQ3ZCO0FBQUEsSUFDSjtBQUVBSix3QkFBb0I2QixJQUFJO0FBQ3hCM0Isc0JBQWtCNEIsRUFBRTtBQUFBLEVBQ3hCO0FBRUFsRCxZQUFVLE1BQU07QUFDWjhDLHVCQUFtQlgsU0FBU0csVUFBVTtBQUFBLEVBQzFDLEdBQUcsQ0FBQ0gsU0FBU0csVUFBVSxDQUFDO0FBR3hCdEMsWUFBVSxNQUFNO0FBQ1osVUFBTTBELGFBQWEsWUFBWTtBQUMzQixVQUFJO0FBQ0EsY0FBTUMsTUFBTSxNQUFNekQsSUFBSTBELElBQUksZ0JBQWdCO0FBQzFDNUMsaUJBQVMyQyxJQUFJRSxRQUFRLEVBQUU7QUFBQSxNQUMzQixTQUFTQyxLQUFLO0FBQ1ZDLGdCQUFRQyxNQUFNLHlCQUF5QkYsR0FBRztBQUFBLE1BQzlDO0FBQUEsSUFDSjtBQUNBSixlQUFXO0FBQUEsRUFDZixHQUFHLEVBQUU7QUFHTCxRQUFNTyxvQkFBb0IsWUFBWTtBQUNsQyxRQUFJO0FBQ0EvQyxpQkFBVyxJQUFJO0FBRWYsVUFBSWdELE1BQU07QUFDVixZQUFNQyxTQUFTLElBQUlDLGdCQUFnQjtBQUVuQyxVQUFJakMsU0FBU0UsS0FBTThCLFFBQU9FLE9BQU8sV0FBV2xDLFNBQVNFLElBQUk7QUFDekQsVUFBSWxCLGlCQUFrQmdELFFBQU9FLE9BQU8sYUFBYWxELGdCQUFnQjtBQUNqRSxVQUFJRSxlQUFnQjhDLFFBQU9FLE9BQU8sV0FBV2hELGNBQWM7QUFFM0QsVUFBSThDLE9BQU9HLFNBQVMsRUFBR0osUUFBTyxJQUFJQyxPQUFPRyxTQUFTLENBQUM7QUFFbkQsWUFBTVgsTUFBTSxNQUFNekQsSUFBSTBELElBQUlNLEdBQUc7QUFDN0IsWUFBTUwsT0FBT0YsS0FBS0UsTUFBTUEsUUFBUTtBQUdoQyxZQUFNbEMsY0FBY2tDLEtBQUtVO0FBQUFBLFFBQ3JCLENBQUNDLEtBQUtDLFNBQVNELE1BQU1FLE9BQU9ELE1BQU1FLFVBQVUsQ0FBQztBQUFBLFFBQzdDO0FBQUEsTUFDSjtBQUNBLFlBQU1DLGNBQWMsSUFBSUMsSUFBSWhCLEtBQUtpQixJQUFJLENBQUNDLE1BQU1BLEdBQUdDLFNBQVNDLEdBQUcsRUFBRUMsT0FBT0MsT0FBTyxDQUFDO0FBRTVFekQsaUJBQVc7QUFBQSxRQUNQQztBQUFBQSxRQUNBQyxZQUFZaUMsS0FBS3VCO0FBQUFBLFFBQ2pCdkQsWUFBWStDLFlBQVlTO0FBQUFBLE1BQzVCLENBQUM7QUFHRCxZQUFNQyxZQUFZekIsS0FBS2lCLElBQUksQ0FBQ0wsTUFBTWMsVUFBVTtBQUN4QyxjQUFNQyxRQUFRZixNQUFNZSxTQUFTLENBQUM7QUFDOUIsY0FBTW5ELE9BQU9vQyxNQUFNTyxXQUFXLENBQUM7QUFHL0IsWUFBSVMsY0FBYztBQUNsQixjQUFNQyxVQUFVRixPQUFPRztBQUN2QixZQUFJRCxZQUFZLFlBQVk7QUFDeEIsZ0JBQU1FLE1BQU1KLE9BQU9LO0FBQ25CLGNBQUlELEtBQUs7QUFDTEgsMEJBQWMsR0FBR0csSUFBSUUsSUFBSSxNQUFNRixJQUFJRyxnQkFBZ0JILElBQUlJLGdCQUFnQixFQUFFO0FBQUEsVUFDN0U7QUFBQSxRQUNKLFdBQVdOLFlBQVksU0FBUztBQUM1QixnQkFBTU8sUUFBUVQsT0FBT1U7QUFDckIsY0FBSUQsT0FBTztBQUNQUiwwQkFBYyxHQUFHUSxNQUFNSCxJQUFJLE1BQU1HLE1BQU1GLGdCQUFnQixFQUFFO0FBQUEsVUFDN0Q7QUFBQSxRQUNKLFdBQVdMLFlBQVksWUFBWTtBQUMvQixnQkFBTVMsT0FBT1gsT0FBT1k7QUFDcEIsY0FBSUQsTUFBTTtBQUNOViwwQkFBYyxHQUFHVSxLQUFLRSxTQUFTLE1BQU1GLEtBQUtKLGdCQUFnQixFQUFFO0FBQUEsVUFDaEU7QUFBQSxRQUNKO0FBR0EsWUFBSU8sY0FBYztBQUNsQixjQUFNQyxZQUFZZixPQUFPZ0I7QUFDekIsWUFBSUQsY0FBYyxhQUFhO0FBQzNCRCx3QkFDSSx1QkFBQyxVQUFLLFdBQVUsOEVBQTZFLHlCQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsUUFFUixXQUFXQyxjQUFjLFlBQVk7QUFDakNELHdCQUNJLHVCQUFDLFVBQUssV0FBVSw0RUFBMkUsd0JBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxRQUVSLFdBQVdDLGNBQWMsWUFBWUEsY0FBYyxRQUFRO0FBQ3ZERCx3QkFDSSx1QkFBQyxVQUFLLFdBQVUsMEVBQ1hDLHdCQUFjLFNBQVMsa0JBQWtCLFlBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxRQUVSLE9BQU87QUFDSEQsd0JBQWMsdUJBQUMsVUFBSyxXQUFVLFdBQVUsaUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJCO0FBQUEsUUFDN0M7QUFFQSxlQUFPO0FBQUEsVUFDSEcsSUFBSWhDLE1BQU1RO0FBQUFBLFVBQ1Z5QixNQUFNbkIsUUFBUTtBQUFBO0FBQUEsVUFHZE8sTUFBTXpELE1BQU1nRSxhQUFhO0FBQUEsVUFDekJNLE9BQU90RSxNQUFNMEQsZ0JBQWdCO0FBQUEsVUFDN0JhLFlBQVlwQixPQUFPb0IsWUFBWUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxFQUN0Q0EsTUFBTSxHQUFHLEVBQ1RDLFFBQVEsRUFDUkMsS0FBSyxHQUFHLEtBQUs7QUFBQTtBQUFBLFVBRWxCQyxTQUFTeEIsT0FBT3lCLFlBQVk7QUFBQSxVQUM1QkMsZ0JBQWdCMUIsT0FBTzJCLG1CQUFtQjtBQUFBLFVBQzFDQyxlQUFlNUIsT0FBTzZCLGtCQUFrQjtBQUFBLFVBQ3hDQyxpQkFBaUIsR0FBRzlCLE9BQU8yQixtQkFBbUIsRUFBRSxPQUFPM0IsT0FBTzZCLGtCQUFrQixHQUFHO0FBQUEsVUFDbkZFLFVBQVUvQixPQUFPK0IsV0FBVyxHQUFHL0IsTUFBTStCLFFBQVEsWUFBWTtBQUFBLFVBQ3pEQyxpQkFBaUJoQyxPQUFPZ0M7QUFBQUE7QUFBQUEsVUFFeEJDLFlBQVkvQyxPQUFPYyxPQUFPaUMsY0FBYyxDQUFDO0FBQUEsVUFDekNDLFNBQVNqRCxNQUFNa0QsWUFBWTtBQUFBLFVBQzNCQyxlQUFlbkQsTUFBTW9ELGtCQUFrQjtBQUFBLFVBQ3ZDQyxTQUFTckQsTUFBTXNELGNBQWM7QUFBQSxVQUM3Qm5GLE1BQU02QixNQUFNdUQsVUFBVW5CLE1BQU0sR0FBRyxFQUFFLENBQUMsRUFDN0JBLE1BQU0sR0FBRyxFQUNUQyxRQUFRLEVBQ1JDLEtBQUssR0FBRyxLQUFLO0FBQUE7QUFBQSxVQUdsQnBCLGVBQWVILE9BQU9HLGlCQUFpQjtBQUFBLFVBQ3ZDRjtBQUFBQTtBQUFBQSxVQUNBd0MsUUFBUTNCO0FBQUFBO0FBQUFBLFVBQ1I0QixjQUFjMUMsT0FBTzBDLGdCQUFnQjtBQUFBLFVBQ3JDQyxXQUFXM0MsT0FBTzJDLFlBQVksUUFBUTtBQUFBO0FBQUEsVUFHdENDLFFBQ0ksdUJBQUMsU0FBSSxXQUFVLDZCQUNYO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxTQUFTLENBQUMsT0FBTztBQUFBLGNBQ2pCLE1BQU07QUFBQSxnQkFDRkMsT0FBTztBQUFBLGtCQUNIO0FBQUEsb0JBQ0lDLEtBQUs7QUFBQSxvQkFDTEMsT0FDSTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDRyxXQUFVO0FBQUEsd0JBQ1YsU0FBUyxNQUFNQyxZQUFZL0QsS0FBS1EsR0FBRztBQUFBLHdCQUFFO0FBQUE7QUFBQSxzQkFGekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsa0JBRVI7QUFBQSxnQkFBQztBQUFBLGNBRVQ7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUVWLGlDQUFDLFlBQVMsV0FBVSxlQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBO0FBQUEsWUFuQm5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQW9CQSxLQXJCNENSLEtBQUtRLEtBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0JBO0FBQUEsUUFFUjtBQUFBLE1BQ0osQ0FBQztBQUVEcEUsbUJBQWF5RSxTQUFTO0FBQUEsSUFDMUIsU0FBU3hCLEtBQUs7QUFDVkMsY0FBUUMsTUFBTSwrQkFBK0JGLEdBQUc7QUFDaEQvQixxQkFBZTtBQUFBLFFBQ1hDLFlBQVk7QUFBQSxRQUNaQyxTQUFTO0FBQUEsUUFDVEMsTUFBTTtBQUFBLE1BQ1YsQ0FBQztBQUFBLElBQ0wsVUFBQztBQUNHaEIsaUJBQVcsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDSjtBQUdBbEIsWUFBVSxNQUFNO0FBQ1osUUFBSW1CLG9CQUFvQkUsZ0JBQWdCO0FBQ3BDNEMsd0JBQWtCO0FBQUEsSUFDdEI7QUFBQSxFQUNKLEdBQUcsQ0FBQzlDLGtCQUFrQkUsZ0JBQWdCYyxTQUFTRSxJQUFJLENBQUM7QUFHcEQsUUFBTW1HLGNBQWMsT0FBT0MsYUFBYTtBQUNwQyxRQUFJO0FBRUFDLGFBQU9DLEtBQUssdUJBQXVCRixRQUFRLElBQUksUUFBUTtBQUFBLElBQzNELFNBQVN6RSxPQUFPO0FBQ1pELGNBQVFDLE1BQU0sZ0JBQWdCQSxLQUFLO0FBQ25DakMscUJBQWU7QUFBQSxRQUNYQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxNQUNWLENBQUM7QUFBQSxJQUNMO0FBQUEsRUFDSjtBQUdBLFFBQU0wRyxVQUFVO0FBQUEsSUFDWixFQUFFTixLQUFLLFFBQVFPLFFBQVEsUUFBUTtBQUFBLElBQy9CLEVBQUVQLEtBQUssV0FBV08sUUFBUSxXQUFXO0FBQUEsSUFDckMsRUFBRVAsS0FBSyxRQUFRTyxRQUFRLFdBQVc7QUFBQSxJQUNsQyxFQUFFUCxLQUFLLFFBQVFPLFFBQVEsZ0JBQWdCO0FBQUEsSUFDdkMsRUFBRVAsS0FBSyxTQUFTTyxRQUFRLFFBQVE7QUFBQSxJQUNoQyxFQUFFUCxLQUFLLGNBQWNPLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVQLEtBQUssWUFBWU8sUUFBUSxvQkFBb0I7QUFBQSxJQUMvQyxFQUFFUCxLQUFLLGdCQUFnQk8sUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRVAsS0FBSyxXQUFXTyxRQUFRLGFBQWE7QUFBQTtBQUFBLElBRXZDLEVBQUVQLEtBQUssbUJBQW1CTyxRQUFRLGtCQUFrQjtBQUFBLElBQ3BELEVBQUVQLEtBQUssV0FBV08sUUFBUSxXQUFXO0FBQUEsSUFDckMsRUFBRVAsS0FBSyxpQkFBaUJPLFFBQVEsaUJBQWlCO0FBQUEsSUFDakQsRUFBRVAsS0FBSyxjQUFjTyxRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFUCxLQUFLLG1CQUFtQk8sUUFBUSxrQkFBa0I7QUFBQSxJQUNwRCxFQUFFUCxLQUFLLFVBQVVPLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHdkMsU0FDSSx1QkFBQyxTQUFJLFdBQVUsY0FDWDtBQUFBLDJCQUFDLFVBQU8sWUFBWSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlCO0FBQUEsSUFDekI7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNHLE1BQU0vRyxZQUFZSTtBQUFBQSxRQUNsQixXQUFXSixZQUFZRTtBQUFBQSxRQUN2QixTQUFTRixZQUFZRztBQUFBQSxRQUNyQixTQUFTLE1BQ0xGLGVBQWUsQ0FBQ1csVUFBVSxFQUFFLEdBQUdBLE1BQU1WLFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxNQUxqRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNSztBQUFBLElBR0wsdUJBQUMsU0FBSSxXQUFVLG1DQUNYO0FBQUEsNkJBQUMsUUFBRyxXQUFVLCtCQUE4Qix3Q0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvRTtBQUFBLE1BR3BFLHVCQUFDLFNBQUksV0FBVSx1Q0FFWDtBQUFBLCtCQUFDLFNBQUksV0FBVSxtQkFDWDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csV0FBVTtBQUFBLFlBQ1YsYUFBWTtBQUFBLFlBQ1osdUJBQXVCO0FBQUEsWUFDdkI7QUFBQSxZQUNBLGNBQWMsQ0FBQzhHLE9BQU9DLFdBQ2xCQSxPQUFPQyxTQUFTQyxZQUFZLEVBQUVDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLFlBRTlELE9BQU85RyxTQUFTRSxRQUFROEc7QUFBQUEsWUFDeEIsVUFBVSxDQUFDQyxRQUFRN0csaUJBQWlCLFFBQVE2RyxHQUFHO0FBQUEsWUFFL0M7QUFBQSxxQ0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsbUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJCO0FBQUEsY0FDMUJySSxNQUFNK0Q7QUFBQUEsZ0JBQUksQ0FBQ3VFLE1BQ1IsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU9BLEVBQUVwRSxLQUMvQm9FLFlBQUVoRCxhQURhZ0QsRUFBRXBFLEtBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNIO0FBQUE7QUFBQTtBQUFBLFVBaEJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWlCQSxLQWxCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUJBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ1g7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLFdBQVU7QUFBQSxZQUNWLE9BQU85QyxTQUFTRztBQUFBQSxZQUNoQixVQUFVLENBQUM4RyxRQUFRN0csaUJBQWlCLGNBQWM2RyxHQUFHO0FBQUEsWUFFckQ7QUFBQSxxQ0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFNBQVEscUJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtDO0FBQUEsY0FDbEMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxhQUFZLHlCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQztBQUFBLGNBQzFDLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sYUFBWSwwQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkM7QUFBQSxjQUMzQyx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFVBQVMsc0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9DO0FBQUE7QUFBQTtBQUFBLFVBUnhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBLEtBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFHQzdILG1CQUNHLG1DQUNJO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG1CQUNYO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixPQUFPSjtBQUFBQSxjQUNQLFVBQVUsQ0FBQ21JLE1BQU1sSSxvQkFBb0JrSSxFQUFFQyxPQUFPOUcsS0FBSztBQUFBO0FBQUEsWUFKdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSXlELEtBTDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxtQkFDWDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsT0FBT3BCO0FBQUFBLGNBQ1AsVUFBVSxDQUFDaUksTUFBTWhJLGtCQUFrQmdJLEVBQUVDLE9BQU85RyxLQUFLO0FBQUE7QUFBQSxZQUpyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJdUQsS0FMM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxXQXpEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkRBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsK0JBQ1g7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMkJBQ1g7QUFBQSxpQ0FBQyxPQUFFLDRCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWU7QUFBQSxVQUNmLHVCQUFDLFFBQUc7QUFBQTtBQUFBLFlBQUVoQixRQUFRRSxZQUFZNkgsZUFBZTtBQUFBLGVBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJDO0FBQUEsYUFGL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsNEJBQ1g7QUFBQSxpQ0FBQyxPQUFFLGtDQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFCO0FBQUEsVUFDckIsdUJBQUMsUUFBSS9ILGtCQUFRRyxjQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdCO0FBQUEsYUFGNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ1g7QUFBQSxpQ0FBQyxPQUFFLCtCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtCO0FBQUEsVUFDbEIsdUJBQUMsUUFBSUgsa0JBQVFJLGNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0I7QUFBQSxhQUY1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLE1BR0NqQixVQUFVd0UsU0FBUyxLQUFLLENBQUNuRSxVQUN0QjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0c7QUFBQSxVQUNBLE1BQU1MO0FBQUFBLFVBQ04sa0JBQWlCO0FBQUE7QUFBQSxRQUhyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHMEMsSUFHMUMsdUJBQUMsa0JBQWUsV0FBV0ssV0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtQztBQUFBLFNBM0YzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkZBO0FBQUEsT0F4R0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlHQTtBQUVSO0FBQUVOLEdBallJRCxtQkFBaUI7QUFBQStJLEtBQWpCL0k7QUFtWU4sZUFBZUE7QUFBa0IsSUFBQStJO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJEYXRhVGFibGUiLCJhcGkiLCJOYXZiYXIiLCJTaWRlYmFyIiwiU2VsZWN0IiwiRHJvcGRvd24iLCJDaXJjdWxhckxvYWRlciIsIklvTWRNb3JlIiwiQ3VzdG9tQWxlcnREaWFsb2ciLCJQaWdteVBheW91dFJlcG9ydCIsIl9zIiwiZGF0YVRhYmxlIiwic2V0RGF0YVRhYmxlIiwidXNlU3RhdGUiLCJ1c2VycyIsInNldFVzZXJzIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzZWxlY3RlZEZyb21EYXRlIiwic2V0U2VsZWN0ZWRGcm9tRGF0ZSIsInNlbGVjdGVkVG9EYXRlIiwic2V0U2VsZWN0ZWRUb0RhdGUiLCJzaG93RmlsdGVyRmllbGQiLCJzZXRTaG93RmlsdGVyRmllbGQiLCJzdW1tYXJ5Iiwic2V0U3VtbWFyeSIsInRvdGFsQW1vdW50IiwidG90YWxDb3VudCIsInRvdGFsVXNlcnMiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInVzZXIiLCJmaWx0ZXJUeXBlIiwiaGFuZGxlQW50RFNlbGVjdCIsImZpZWxkIiwidmFsdWUiLCJwcmV2IiwiZm9ybWF0RGF0ZSIsImRhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJoYW5kbGVTZWxlY3RGaWx0ZXIiLCJ0b2RheSIsIkRhdGUiLCJmcm9tIiwidG8iLCJ5Iiwic2V0RGF0ZSIsImdldERhdGUiLCJzdGFydCIsImdldEZ1bGxZZWFyIiwiZ2V0TW9udGgiLCJlbmQiLCJmZXRjaFVzZXJzIiwicmVzIiwiZ2V0IiwiZGF0YSIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImZldGNoUGlnbXlQYXlvdXRzIiwidXJsIiwicGFyYW1zIiwiVVJMU2VhcmNoUGFyYW1zIiwiYXBwZW5kIiwidG9TdHJpbmciLCJyZWR1Y2UiLCJzdW0iLCJpdGVtIiwiTnVtYmVyIiwiYW1vdW50IiwidW5pcXVlVXNlcnMiLCJTZXQiLCJtYXAiLCJkIiwidXNlcl9pZCIsIl9pZCIsImZpbHRlciIsIkJvb2xlYW4iLCJsZW5ndGgiLCJzaXplIiwiZm9ybWF0dGVkIiwiaW5kZXgiLCJwaWdtZSIsInJlZmVycmVkX2J5IiwicmVmVHlwZSIsInJlZmVycmVkX3R5cGUiLCJlbXAiLCJyZWZlcnJlZF9lbXBsb3llZSIsIm5hbWUiLCJwaG9uZV9udW1iZXIiLCJlbXBsb3llZUNvZGUiLCJhZ2VudCIsInJlZmVycmVkX2FnZW50IiwiY3VzdCIsInJlZmVycmVkX2N1c3RvbWVyIiwiZnVsbF9uYW1lIiwic3RhdHVzQmFkZ2UiLCJyZXFTdGF0dXMiLCJyZXF1ZXN0X3N0YXR1cyIsImlkIiwic2xObyIsInBob25lIiwic3RhcnRfZGF0ZSIsInNwbGl0IiwicmV2ZXJzZSIsImpvaW4iLCJwaWdteUlkIiwicGlnbWVfaWQiLCJtYXR1cml0eVBlcmlvZCIsIm1hdHVyaXR5X3BlcmlvZCIsInBheWFibGVBbW91bnQiLCJwYXlhYmxlX2Ftb3VudCIsInBheW1lbnRfZGV0YWlscyIsImR1cmF0aW9uIiwibWF0dXJpdHlfYW1vdW50IiwidG90YWxfcGFpZCIsInBheVR5cGUiLCJwYXlfdHlwZSIsInRyYW5zYWN0aW9uSWQiLCJ0cmFuc2FjdGlvbl9pZCIsInJlY2VpcHQiLCJyZWNlaXB0X25vIiwicGF5X2RhdGUiLCJzdGF0dXMiLCJjbG9zdXJlX3R5cGUiLCJpc19wcml6ZWQiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImxhYmVsIiwiaGFuZGxlUHJpbnQiLCJwYXlvdXRJZCIsIndpbmRvdyIsIm9wZW4iLCJjb2x1bW5zIiwiaGVhZGVyIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJ1bmRlZmluZWQiLCJ2YWwiLCJ1IiwiZSIsInRhcmdldCIsInRvTG9jYWxlU3RyaW5nIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGlnbXlQYXlvdXRSZXBvcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgRHJvcGRvd24gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcblxyXG5jb25zdCBQaWdteVBheW91dFJlcG9ydCA9ICgpID0+IHtcclxuICAgIGNvbnN0IFtkYXRhVGFibGUsIHNldERhdGFUYWJsZV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgICBjb25zdCBbc2VsZWN0ZWRGcm9tRGF0ZSwgc2V0U2VsZWN0ZWRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFtzZWxlY3RlZFRvRGF0ZSwgc2V0U2VsZWN0ZWRUb0RhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbc2hvd0ZpbHRlckZpZWxkLCBzZXRTaG93RmlsdGVyRmllbGRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAgIGNvbnN0IFtzdW1tYXJ5LCBzZXRTdW1tYXJ5XSA9IHVzZVN0YXRlKHtcclxuICAgICAgICB0b3RhbEFtb3VudDogMCxcclxuICAgICAgICB0b3RhbENvdW50OiAwLFxyXG4gICAgICAgIHRvdGFsVXNlcnM6IDAsXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgICAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICAgICAgdXNlcjogXCJcIixcclxuICAgICAgICBmaWx0ZXJUeXBlOiBcIlRvZGF5XCIsXHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyBIYW5kbGUgU2VsZWN0XHJcbiAgICBjb25zdCBoYW5kbGVBbnREU2VsZWN0ID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbZmllbGRdOiB2YWx1ZSB9KSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGZvcm1hdERhdGUgPSAoZGF0ZSkgPT4gZGF0ZS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1DQVwiKTtcclxuXHJcbiAgICAvLyBGaWx0ZXIgTG9naWNcclxuICAgIGNvbnN0IGhhbmRsZVNlbGVjdEZpbHRlciA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgICAgIHNldFNob3dGaWx0ZXJGaWVsZChmYWxzZSk7XHJcblxyXG4gICAgICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICAgICAgICBsZXQgZnJvbSA9IFwiXCI7XHJcbiAgICAgICAgbGV0IHRvID0gXCJcIjtcclxuXHJcbiAgICAgICAgaWYgKHZhbHVlID09PSBcIlRvZGF5XCIpIHtcclxuICAgICAgICAgICAgZnJvbSA9IHRvID0gZm9ybWF0RGF0ZSh0b2RheSk7XHJcbiAgICAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJZZXN0ZXJkYXlcIikge1xyXG4gICAgICAgICAgICBjb25zdCB5ID0gbmV3IERhdGUodG9kYXkpO1xyXG4gICAgICAgICAgICB5LnNldERhdGUodG9kYXkuZ2V0RGF0ZSgpIC0gMSk7XHJcbiAgICAgICAgICAgIGZyb20gPSB0byA9IGZvcm1hdERhdGUoeSk7XHJcbiAgICAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzTW9udGhcIikge1xyXG4gICAgICAgICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDEpO1xyXG4gICAgICAgICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpICsgMSwgMCk7XHJcbiAgICAgICAgICAgIGZyb20gPSBmb3JtYXREYXRlKHN0YXJ0KTtcclxuICAgICAgICAgICAgdG8gPSBmb3JtYXREYXRlKGVuZCk7XHJcbiAgICAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJDdXN0b21cIikge1xyXG4gICAgICAgICAgICBzZXRTaG93RmlsdGVyRmllbGQodHJ1ZSk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZnJvbSk7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRUb0RhdGUodG8pO1xyXG4gICAgfTtcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGhhbmRsZVNlbGVjdEZpbHRlcihmb3JtRGF0YS5maWx0ZXJUeXBlKTtcclxuICAgIH0sIFtmb3JtRGF0YS5maWx0ZXJUeXBlXSk7XHJcblxyXG4gICAgLy8gRmV0Y2ggVXNlcnNcclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgZmV0Y2hVc2VycyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuICAgICAgICAgICAgICAgIHNldFVzZXJzKHJlcy5kYXRhIHx8IFtdKTtcclxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlcnM6XCIsIGVycik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgICAgIGZldGNoVXNlcnMoKTtcclxuICAgIH0sIFtdKTtcclxuXHJcbiAgICAvLyDinIUgRmV0Y2ggUGlnbXkgUGF5b3V0c1xyXG4gICAgY29uc3QgZmV0Y2hQaWdteVBheW91dHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgICAgICAgIGxldCB1cmwgPSBgdjEvYWRtaW4vcGF5bWVudHMtb3V0L3BpZ21lLXBheW91dGA7XHJcbiAgICAgICAgICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChmb3JtRGF0YS51c2VyKSBwYXJhbXMuYXBwZW5kKFwidXNlcl9pZFwiLCBmb3JtRGF0YS51c2VyKTtcclxuICAgICAgICAgICAgaWYgKHNlbGVjdGVkRnJvbURhdGUpIHBhcmFtcy5hcHBlbmQoXCJmcm9tX2RhdGVcIiwgc2VsZWN0ZWRGcm9tRGF0ZSk7XHJcbiAgICAgICAgICAgIGlmIChzZWxlY3RlZFRvRGF0ZSkgcGFyYW1zLmFwcGVuZChcInRvX2RhdGVcIiwgc2VsZWN0ZWRUb0RhdGUpO1xyXG5cclxuICAgICAgICAgICAgaWYgKHBhcmFtcy50b1N0cmluZygpKSB1cmwgKz0gYD8ke3BhcmFtcy50b1N0cmluZygpfWA7XHJcblxyXG4gICAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KHVybCk7XHJcbiAgICAgICAgICAgIGNvbnN0IGRhdGEgPSByZXM/LmRhdGE/LmRhdGEgfHwgW107XHJcblxyXG4gICAgICAgICAgICAvLyBTdW1tYXJ5XHJcbiAgICAgICAgICAgIGNvbnN0IHRvdGFsQW1vdW50ID0gZGF0YS5yZWR1Y2UoXHJcbiAgICAgICAgICAgICAgICAoc3VtLCBpdGVtKSA9PiBzdW0gKyBOdW1iZXIoaXRlbT8uYW1vdW50IHx8IDApLFxyXG4gICAgICAgICAgICAgICAgMCxcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgY29uc3QgdW5pcXVlVXNlcnMgPSBuZXcgU2V0KGRhdGEubWFwKChkKSA9PiBkPy51c2VyX2lkPy5faWQpLmZpbHRlcihCb29sZWFuKSk7XHJcblxyXG4gICAgICAgICAgICBzZXRTdW1tYXJ5KHtcclxuICAgICAgICAgICAgICAgIHRvdGFsQW1vdW50LFxyXG4gICAgICAgICAgICAgICAgdG90YWxDb3VudDogZGF0YS5sZW5ndGgsXHJcbiAgICAgICAgICAgICAgICB0b3RhbFVzZXJzOiB1bmlxdWVVc2Vycy5zaXplLFxyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIC8vIEZvcm1hdCB0YWJsZSBkYXRhIHdpdGggYWRkaXRpb25hbCBmaWVsZHNcclxuICAgICAgICAgICAgY29uc3QgZm9ybWF0dGVkID0gZGF0YS5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBwaWdtZSA9IGl0ZW0/LnBpZ21lIHx8IHt9O1xyXG4gICAgICAgICAgICAgICAgY29uc3QgdXNlciA9IGl0ZW0/LnVzZXJfaWQgfHwge307XHJcblxyXG4gICAgICAgICAgICAgICAgLy8gLS0tLS0tLS0gQ29tcHV0ZSByZWZlcnJlZF9ieSAoc2FtZSBsb2dpYyBhcyBpbiBib3Jyb3dlciBsaXN0KSAtLS0tLS0tLVxyXG4gICAgICAgICAgICAgICAgbGV0IHJlZmVycmVkX2J5ID0gXCJOL0FcIjtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHJlZlR5cGUgPSBwaWdtZT8ucmVmZXJyZWRfdHlwZTsgLy8gXCJFbXBsb3llZVwiLCBcIkFnZW50XCIsIFwiQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgaWYgKHJlZlR5cGUgPT09IFwiRW1wbG95ZWVcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGVtcCA9IHBpZ21lPy5yZWZlcnJlZF9lbXBsb3llZTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZW1wKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlZmVycmVkX2J5ID0gYCR7ZW1wLm5hbWV9IHwgJHtlbXAucGhvbmVfbnVtYmVyIHx8IGVtcC5lbXBsb3llZUNvZGUgfHwgXCJcIn1gO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAocmVmVHlwZSA9PT0gXCJBZ2VudFwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYWdlbnQgPSBwaWdtZT8ucmVmZXJyZWRfYWdlbnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFnZW50KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlZmVycmVkX2J5ID0gYCR7YWdlbnQubmFtZX0gfCAke2FnZW50LnBob25lX251bWJlciB8fCBcIlwifWA7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChyZWZUeXBlID09PSBcIkN1c3RvbWVyXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBjdXN0ID0gcGlnbWU/LnJlZmVycmVkX2N1c3RvbWVyO1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChjdXN0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlZmVycmVkX2J5ID0gYCR7Y3VzdC5mdWxsX25hbWV9IHwgJHtjdXN0LnBob25lX251bWJlciB8fCBcIlwifWA7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIC8vIC0tLS0tLS0tIFN0YXR1cyBiYWRnZSAobGlrZSB0aGUgYm9ycm93ZXIgdGFibGUpIC0tLS0tLS0tXHJcbiAgICAgICAgICAgICAgICBsZXQgc3RhdHVzQmFkZ2UgPSBudWxsO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcmVxU3RhdHVzID0gcGlnbWU/LnJlcXVlc3Rfc3RhdHVzO1xyXG4gICAgICAgICAgICAgICAgaWYgKHJlcVN0YXR1cyA9PT0gXCJSRVFVRVNURURcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIHN0YXR1c0JhZGdlID0gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCBiZy15ZWxsb3ctMTAwIHRleHQteWVsbG93LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVxdWVzdGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChyZXFTdGF0dXMgPT09IFwiQVBQUk9WRURcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIHN0YXR1c0JhZGdlID0gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCBiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFwcHJvdmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChyZXFTdGF0dXMgPT09IFwiQ0xPU0VEXCIgfHwgcmVxU3RhdHVzID09PSBcIkRPTkVcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIHN0YXR1c0JhZGdlID0gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCBiZy1ncmF5LTEwMCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVxU3RhdHVzID09PSBcIkRPTkVcIiA/IFwiQ2xvc2VkIChEb25lKVwiIDogXCJDbG9zZWRcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHN0YXR1c0JhZGdlID0gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14c1wiPi08L3NwYW4+O1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ6IGl0ZW0/Ll9pZCxcclxuICAgICAgICAgICAgICAgICAgICBzbE5vOiBpbmRleCArIDEsXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC8vIEJhc2ljIGN1c3RvbWVyIGluZm9cclxuICAgICAgICAgICAgICAgICAgICBuYW1lOiB1c2VyPy5mdWxsX25hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgcGhvbmU6IHVzZXI/LnBob25lX251bWJlciB8fCBcIi1cIixcclxuICAgICAgICAgICAgICAgICAgICBzdGFydF9kYXRlOiBwaWdtZT8uc3RhcnRfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5zcGxpdChcIi1cIilcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnJldmVyc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuam9pbihcIi1cIikgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gUGlnbXkgZGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgIHBpZ215SWQ6IHBpZ21lPy5waWdtZV9pZCB8fCBcIi1cIixcclxuICAgICAgICAgICAgICAgICAgICBtYXR1cml0eVBlcmlvZDogcGlnbWU/Lm1hdHVyaXR5X3BlcmlvZCB8fCBcIi1cIixcclxuICAgICAgICAgICAgICAgICAgICBwYXlhYmxlQW1vdW50OiBwaWdtZT8ucGF5YWJsZV9hbW91bnQgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgcGF5bWVudF9kZXRhaWxzOiBgJHtwaWdtZT8ubWF0dXJpdHlfcGVyaW9kIHx8IFwiXCJ9IOKAkyDigrkke3BpZ21lPy5wYXlhYmxlX2Ftb3VudCB8fCBcIjBcIn1gLFxyXG4gICAgICAgICAgICAgICAgICAgIGR1cmF0aW9uOiBwaWdtZT8uZHVyYXRpb24gPyBgJHtwaWdtZS5kdXJhdGlvbn0gTW9udGhzYCA6IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIG1hdHVyaXR5X2Ftb3VudDogcGlnbWU/Lm1hdHVyaXR5X2Ftb3VudCxcclxuICAgICAgICAgICAgICAgICAgICAvLyBGaW5hbmNpYWxzXHJcbiAgICAgICAgICAgICAgICAgICAgdG90YWxfcGFpZDogTnVtYmVyKHBpZ21lPy50b3RhbF9wYWlkIHx8IDApLFxyXG4gICAgICAgICAgICAgICAgICAgIHBheVR5cGU6IGl0ZW0/LnBheV90eXBlIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zYWN0aW9uSWQ6IGl0ZW0/LnRyYW5zYWN0aW9uX2lkIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIHJlY2VpcHQ6IGl0ZW0/LnJlY2VpcHRfbm8gfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0ZTogaXRlbT8ucGF5X2RhdGU/LnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuc3BsaXQoXCItXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5yZXZlcnNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmpvaW4oXCItXCIpIHx8IFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAvLyAtLS0tLS0tLSBORVcgRklFTERTIChmcm9tIGJvcnJvd2VyIGNvZGUpIC0tLS0tLS0tXHJcbiAgICAgICAgICAgICAgICAgICAgcmVmZXJyZWRfdHlwZTogcGlnbWU/LnJlZmVycmVkX3R5cGUgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICAgICAgICByZWZlcnJlZF9ieSwgICAgICAgICAgLy8gY29tcHV0ZWQgYWJvdmVcclxuICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IHN0YXR1c0JhZGdlLCAgLy8gSlNYIGJhZGdlXHJcbiAgICAgICAgICAgICAgICAgICAgY2xvc3VyZV90eXBlOiBwaWdtZT8uY2xvc3VyZV90eXBlIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGlzX3ByaXplZDogcGlnbWU/LmlzX3ByaXplZCA/IFwiWWVzXCIgOiBcIk5vXCIsXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC8vIEFjdGlvbiBkcm9wZG93biAoa2VlcCBhcyBpcylcclxuICAgICAgICAgICAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGdhcC0yXCIga2V5PXtpdGVtLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUHJpbnQoaXRlbS5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQcmludFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgIH07XHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgc2V0RGF0YVRhYmxlKGZvcm1hdHRlZCk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCLinYwgUGlnbXkgUGF5b3V0IEZldGNoIEVycm9yOlwiLCBlcnIpO1xyXG4gICAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gZmV0Y2ggcGlnbXkgcGF5b3V0IGRhdGFcIixcclxuICAgICAgICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICAvLyDinIUgVHJpZ2dlciBGZXRjaFxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBpZiAoc2VsZWN0ZWRGcm9tRGF0ZSAmJiBzZWxlY3RlZFRvRGF0ZSkge1xyXG4gICAgICAgICAgICBmZXRjaFBpZ215UGF5b3V0cygpO1xyXG4gICAgICAgIH1cclxuICAgIH0sIFtzZWxlY3RlZEZyb21EYXRlLCBzZWxlY3RlZFRvRGF0ZSwgZm9ybURhdGEudXNlcl0pO1xyXG5cclxuICAgIC8vIOKchSBQcmludCBoYW5kbGVyIChzaW1wbGlmaWVkIOKAkyBhZGFwdCBhcyBuZWVkZWQpXHJcbiAgICBjb25zdCBoYW5kbGVQcmludCA9IGFzeW5jIChwYXlvdXRJZCkgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIC8vIE9wdGlvbmFsbHkgZmV0Y2ggc2luZ2xlIHBheW91dCBkZXRhaWxzIGFuZCBnZW5lcmF0ZSBhIHJlY2VpcHQgUERGXHJcbiAgICAgICAgICAgIHdpbmRvdy5vcGVuKGAvcHJpbnQvcGlnbXktcGF5b3V0LyR7cGF5b3V0SWR9YCwgXCJfYmxhbmtcIik7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIlByaW50IGVycm9yOlwiLCBlcnJvcik7XHJcbiAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBnZW5lcmF0ZSBwcmludFwiLFxyXG4gICAgICAgICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIC8vIOKchSBUYWJsZSBDb2x1bW5zXHJcbiAgICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgICAgIHsga2V5OiBcInNsTm9cIiwgaGVhZGVyOiBcIlNsIE5vXCIgfSxcclxuICAgICAgICB7IGtleTogXCJwaWdteUlkXCIsIGhlYWRlcjogXCJQaWdteSBJRFwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiZGF0ZVwiLCBoZWFkZXI6IFwiUGF5IERhdGVcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcInBob25lXCIsIGhlYWRlcjogXCJQaG9uZVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwic3RhcnRfZGF0ZVwiLCBoZWFkZXI6IFwiU3RhcnQgRGF0ZVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiZHVyYXRpb25cIiwgaGVhZGVyOiBcIkR1cmF0aW9uIChNb250aHMpXCIgfSxcclxuICAgICAgICB7IGtleTogXCJjbG9zdXJlX3R5cGVcIiwgaGVhZGVyOiBcIkNsb3N1cmUgVHlwZVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwicmVjZWlwdFwiLCBoZWFkZXI6IFwiUmVjZWlwdCBOb1wiIH0sXHJcbiAgICAgICAgLy8geyBrZXk6IFwicGF5YWJsZUFtb3VudFwiLCBoZWFkZXI6IFwiUGF5YWJsZSBBbW91bnRcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcInBheW1lbnRfZGV0YWlsc1wiLCBoZWFkZXI6IFwiUGF5bWVudCBEZXRhaWxzXCIgfSxcclxuICAgICAgICB7IGtleTogXCJwYXlUeXBlXCIsIGhlYWRlcjogXCJQYXkgVHlwZVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwidHJhbnNhY3Rpb25JZFwiLCBoZWFkZXI6IFwiVHJhbnNhY3Rpb24gSURcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcInRvdGFsX3BhaWRcIiwgaGVhZGVyOiBcIlBhaWQgQW1vdW50XCIgfSxcclxuICAgICAgICB7IGtleTogXCJtYXR1cml0eV9hbW91bnRcIiwgaGVhZGVyOiBcIk1hdHVyaXR5IEFtb3VudFwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gICAgXTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0xMFwiPlxyXG4gICAgICAgICAgICA8TmF2YmFyIHZpc2liaWxpdHk9e3RydWV9IC8+XHJcbiAgICAgICAgICAgIDxDdXN0b21BbGVydERpYWxvZ1xyXG4gICAgICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtNyBvdmVyZmxvdy14LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbWItNlwiPlBpZ215IFBheW1lbnQgT3V0IFJlcG9ydDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIEZpbHRlcnMgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWVuZCBnYXAtNCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIFVzZXIgU2VsZWN0ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1kOnctMS80XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLVs0MnB4XVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFsbCBVc2Vyc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnVzZXIgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IGhhbmRsZUFudERTZWxlY3QoXCJ1c2VyXCIsIHZhbCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiXCI+QWxsPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3VzZXJzLm1hcCgodSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dS5faWR9IHZhbHVlPXt1Ll9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt1LmZ1bGxfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBGaWx0ZXIgVHlwZSAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtZDp3LTEvNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1bNDJweF1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmZpbHRlclR5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4gaGFuZGxlQW50RFNlbGVjdChcImZpbHRlclR5cGVcIiwgdmFsKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJUb2RheVwiPlRvZGF5PC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJZZXN0ZXJkYXlcIj5ZZXN0ZXJkYXk8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlRoaXNNb250aFwiPlRoaXMgTW9udGg8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIkN1c3RvbVwiPkN1c3RvbTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBEYXRlIEZpbHRlcnMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAge3Nob3dGaWx0ZXJGaWVsZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtZDp3LTEvNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLVs0MnB4XSBweC0zIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEZyb21EYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkRnJvbURhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtZDp3LTEvNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLVs0MnB4XSBweC0zIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFRvRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZFRvRGF0ZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFN1bW1hcnkgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTQgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS0xMDAgcC00IHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+VG90YWwgQW1vdW50PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDI+4oK5e3N1bW1hcnkudG90YWxBbW91bnQudG9Mb2NhbGVTdHJpbmcoKX08L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyZWVuLTEwMCBwLTQgcm91bmRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cD5Ub3RhbCBUcmFuc2FjdGlvbnM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMj57c3VtbWFyeS50b3RhbENvdW50fTwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmcteWVsbG93LTEwMCBwLTQgcm91bmRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cD5Ub3RhbCBDdXN0b21lcnM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMj57c3VtbWFyeS50b3RhbFVzZXJzfTwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogVGFibGUgKi99XHJcbiAgICAgICAgICAgICAgICB7ZGF0YVRhYmxlLmxlbmd0aCA+IDAgJiYgIWxvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhPXtkYXRhVGFibGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJQaWdteV9QYXlvdXRfUmVwb3J0XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXtsb2FkaW5nfSAvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUGlnbXlQYXlvdXRSZXBvcnQ7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1BpZ215UGF5b3V0UmVwb3J0LmpzeCJ9