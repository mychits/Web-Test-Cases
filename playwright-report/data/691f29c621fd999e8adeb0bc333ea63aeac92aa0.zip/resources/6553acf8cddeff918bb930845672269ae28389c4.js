import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/modals/ReConfirmModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ReConfirmModal.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { IoMdClose } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
const formatLabel = (key) => {
  return key.replace(/_/g, " ").replace(/\b\w/g, (char) => char.toUpperCase());
};
const ReConfirmModal = ({
  isOpen,
  title = "Confirm Details",
  data,
  onCancel,
  onConfirm,
  confirmText = "Confirm",
  cancelText = "Edit"
}) => {
  if (!isOpen) return null;
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[9999] flex items-center justify-center bg-black/50", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white w-full max-w-lg rounded-lg shadow-lg p-6 relative", children: [
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: onCancel,
        className: "absolute top-4 right-4 text-gray-600 hover:bg-gray-100 p-2 rounded-full",
        children: /* @__PURE__ */ jsxDEV(IoMdClose, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ReConfirmModal.jsx",
          lineNumber: 28,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ReConfirmModal.jsx",
        lineNumber: 24,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold mb-4", children: title }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ReConfirmModal.jsx",
      lineNumber: 31,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-3 max-h-96 overflow-y-auto", children: Object.entries(data).filter(([key]) => key !== "track_source").filter(([key]) => {
      if (key.endsWith("_select")) return true;
      return !data[`${key}_select`];
    }).map(([key, value]) => {
      const label = formatLabel(key.replace(/_select$/, ""));
      return /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between border-b pb-2 text-sm", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: label }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ReConfirmModal.jsx",
          lineNumber: 48,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "mr-2", children: value }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ReConfirmModal.jsx",
          lineNumber: 49,
          columnNumber: 11
        }, this)
      ] }, key, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ReConfirmModal.jsx",
        lineNumber: 47,
        columnNumber: 15
      }, this);
    }) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ReConfirmModal.jsx",
      lineNumber: 33,
      columnNumber: 6
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-4 mt-6", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: onCancel,
          className: "px-4 py-2 border rounded-lg text-gray-700 hover:bg-gray-100",
          children: cancelText
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ReConfirmModal.jsx",
          lineNumber: 56,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: onConfirm,
          className: "px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700",
          children: confirmText
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ReConfirmModal.jsx",
          lineNumber: 62,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ReConfirmModal.jsx",
      lineNumber: 55,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ReConfirmModal.jsx",
    lineNumber: 23,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ReConfirmModal.jsx",
    lineNumber: 22,
    columnNumber: 5
  }, this);
};
_c = ReConfirmModal;
export default ReConfirmModal;
var _c;
$RefreshReg$(_c, "ReConfirmModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ReConfirmModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ReConfirmModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkJVO0FBM0JWLDJCQUEwQjtBQUFnQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFMUMsTUFBTUEsY0FBY0EsQ0FBQ0MsUUFBUTtBQUMzQixTQUFPQSxJQUNKQyxRQUFRLE1BQU0sR0FBRyxFQUNqQkEsUUFBUSxTQUFTLENBQUNDLFNBQVNBLEtBQUtDLFlBQVksQ0FBQztBQUNsRDtBQUdBLE1BQU1DLGlCQUFpQkEsQ0FBQztBQUFBLEVBQ3RCQztBQUFBQSxFQUNBQyxRQUFRO0FBQUEsRUFDUkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUMsY0FBYztBQUFBLEVBQ2RDLGFBQWE7QUFDZixNQUFNO0FBQ0osTUFBSSxDQUFDTixPQUFRLFFBQU87QUFFcEIsU0FDRSx1QkFBQyxTQUFJLFdBQVUsdUVBQ2IsaUNBQUMsU0FBSSxXQUFVLDhEQUNiO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVNHO0FBQUFBLFFBQ1QsV0FBVTtBQUFBLFFBRVYsaUNBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVU7QUFBQTtBQUFBLE1BSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBS0E7QUFBQSxJQUVBLHVCQUFDLFFBQUcsV0FBVSwwQkFBMEJGLG1CQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQThDO0FBQUEsSUFFakQsdUJBQUMsU0FBSSxXQUFVLHNDQUNqQk0saUJBQU9DLFFBQVFOLElBQUksRUFFakJPLE9BQU8sQ0FBQyxDQUFDZCxHQUFHLE1BQU1BLFFBQVEsY0FBYyxFQUN4Q2MsT0FBTyxDQUFDLENBQUNkLEdBQUcsTUFBTTtBQUVqQixVQUFJQSxJQUFJZSxTQUFTLFNBQVMsRUFBRyxRQUFPO0FBRXBDLGFBQU8sQ0FBQ1IsS0FBSyxHQUFHUCxHQUFHLFNBQVM7QUFBQSxJQUM5QixDQUFDLEVBQ0FnQixJQUFJLENBQUMsQ0FBQ2hCLEtBQUtpQixLQUFLLE1BQU07QUFFckIsWUFBTUMsUUFBUW5CLFlBQVlDLElBQUlDLFFBQVEsWUFBWSxFQUFFLENBQUM7QUFDckQsYUFDRSx1QkFBQyxTQUFjLFdBQVUsOENBQ3ZCO0FBQUEsK0JBQUMsVUFBSyxXQUFVLGVBQWVpQixtQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQztBQUFBLFFBQ3JDLHVCQUFDLFVBQUssV0FBVSxRQUFRRCxtQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QjtBQUFBLFdBRnRCakIsS0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxJQUVKLENBQUMsS0FuQkE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9CTDtBQUFBLElBRVEsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVNRO0FBQUFBLFVBQ1QsV0FBVTtBQUFBLFVBRVRHO0FBQUFBO0FBQUFBLFFBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTRjtBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUVUQztBQUFBQTtBQUFBQSxRQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtBO0FBQUEsU0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxPQTdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBOENBLEtBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnREE7QUFFSjtBQUFFUyxLQTlESWY7QUFnRU4sZUFBZUE7QUFBZSxJQUFBZTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiZm9ybWF0TGFiZWwiLCJrZXkiLCJyZXBsYWNlIiwiY2hhciIsInRvVXBwZXJDYXNlIiwiUmVDb25maXJtTW9kYWwiLCJpc09wZW4iLCJ0aXRsZSIsImRhdGEiLCJvbkNhbmNlbCIsIm9uQ29uZmlybSIsImNvbmZpcm1UZXh0IiwiY2FuY2VsVGV4dCIsIk9iamVjdCIsImVudHJpZXMiLCJmaWx0ZXIiLCJlbmRzV2l0aCIsIm1hcCIsInZhbHVlIiwibGFiZWwiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJSZUNvbmZpcm1Nb2RhbC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW9NZENsb3NlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcblxyXG5jb25zdCBmb3JtYXRMYWJlbCA9IChrZXkpID0+IHtcclxuICByZXR1cm4ga2V5XHJcbiAgICAucmVwbGFjZSgvXy9nLCBcIiBcIilcclxuICAgIC5yZXBsYWNlKC9cXGJcXHcvZywgKGNoYXIpID0+IGNoYXIudG9VcHBlckNhc2UoKSk7XHJcbn07XHJcblxyXG5cclxuY29uc3QgUmVDb25maXJtTW9kYWwgPSAoe1xyXG4gIGlzT3BlbixcclxuICB0aXRsZSA9IFwiQ29uZmlybSBEZXRhaWxzXCIsXHJcbiAgZGF0YSxcclxuICBvbkNhbmNlbCxcclxuICBvbkNvbmZpcm0sXHJcbiAgY29uZmlybVRleHQgPSBcIkNvbmZpcm1cIixcclxuICBjYW5jZWxUZXh0ID0gXCJFZGl0XCIsXHJcbn0pID0+IHtcclxuICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7IC8vIOKchSBleGl0IGVhcmx5IGlmIG1vZGFsIGlzIGNsb3NlZFxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotWzk5OTldIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWJsYWNrLzUwXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgdy1mdWxsIG1heC13LWxnIHJvdW5kZWQtbGcgc2hhZG93LWxnIHAtNiByZWxhdGl2ZVwiPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIG9uQ2xpY2s9e29uQ2FuY2VsfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTQgcmlnaHQtNCB0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktMTAwIHAtMiByb3VuZGVkLWZ1bGxcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxJb01kQ2xvc2UgLz5cclxuICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIG1iLTRcIj57dGl0bGV9PC9oMj5cclxuXHJcbiAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMgbWF4LWgtOTYgb3ZlcmZsb3cteS1hdXRvXCI+XHJcbiAge09iamVjdC5lbnRyaWVzKGRhdGEpXHJcbiAgICAvLyBSZW1vdmUgdHJhY2tfc291cmNlIGFuZCBhbnkgb3JpZ2luYWwgZmllbGQgdGhhdCBoYXMgYSBcIl9zZWxlY3RcIiBjb3VudGVycGFydFxyXG4gICAgLmZpbHRlcigoW2tleV0pID0+IGtleSAhPT0gXCJ0cmFja19zb3VyY2VcIilcclxuICAgIC5maWx0ZXIoKFtrZXldKSA9PiB7XHJcbiAgICAgIC8vIElmIHRoaXMga2V5IGVuZHMgd2l0aCBcIl9zZWxlY3RcIiwga2VlcCBpdFxyXG4gICAgICBpZiAoa2V5LmVuZHNXaXRoKFwiX3NlbGVjdFwiKSkgcmV0dXJuIHRydWU7XHJcbiAgICAgIC8vIE90aGVyd2lzZSwgb25seSBrZWVwIGtleXMgdGhhdCBkbyBOT1QgaGF2ZSBhIFwiX3NlbGVjdFwiIHZlcnNpb24gaW4gZGF0YVxyXG4gICAgICByZXR1cm4gIWRhdGFbYCR7a2V5fV9zZWxlY3RgXTtcclxuICAgIH0pXHJcbiAgICAubWFwKChba2V5LCB2YWx1ZV0pID0+IHtcclxuICAgICAgLy8gUmVtb3ZlIFwiX3NlbGVjdFwiIHN1ZmZpeCBmcm9tIGxhYmVsIGlmIHByZXNlbnRcclxuICAgICAgY29uc3QgbGFiZWwgPSBmb3JtYXRMYWJlbChrZXkucmVwbGFjZSgvX3NlbGVjdCQvLCBcIlwiKSk7XHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBrZXk9e2tleX0gY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgcGItMiB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPntsYWJlbH08L3NwYW4+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtci0yXCI+e3ZhbHVlfTwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKTtcclxuICAgIH0pfVxyXG48L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC00IG10LTZcIj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17b25DYW5jZWx9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgcm91bmRlZC1sZyB0ZXh0LWdyYXktNzAwIGhvdmVyOmJnLWdyYXktMTAwXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2NhbmNlbFRleHR9XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17b25Db25maXJtfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctYmx1ZS02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIGhvdmVyOmJnLWJsdWUtNzAwXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2NvbmZpcm1UZXh0fVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFJlQ29uZmlybU1vZGFsO1xyXG5cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL2NvbXBvbmVudHMvbW9kYWxzL1JlQ29uZmlybU1vZGFsLmpzeCJ9