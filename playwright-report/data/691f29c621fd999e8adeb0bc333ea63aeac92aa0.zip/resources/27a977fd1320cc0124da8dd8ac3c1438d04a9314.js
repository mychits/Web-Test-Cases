import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LeadWhatsappMessageMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { Users, Briefcase, ChevronRight, Zap } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import { MdEmail } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { RiMoneyRupeeCircleLine } from "/node_modules/.vite/deps/react-icons_ri.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const LeadWhatsappMessageMenu = () => {
  const leadwhatsappCategories = [
    {
      id: 2,
      title: "Welcome Message",
      description: "Manage Welcome Message",
      icon: /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
        lineNumber: 19,
        columnNumber: 11
      }, this),
      color: "from-violet-600 to-violet-700",
      lightColor: "bg-violet-50",
      borderColor: "border-violet-200",
      href: "/market-menu/whatsapp-marketing/lead-whatsapp-marketing/lead-welcome-message",
      //   target:"_self",
      stats: "Active Lead Whatsapp Message"
    },
    {
      id: 2,
      title: "ReferredBy Whatsapp",
      description: "ReferredBy Whatsapp",
      icon: /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
        lineNumber: 31,
        columnNumber: 11
      }, this),
      color: "from-violet-600 to-violet-700",
      lightColor: "bg-violet-50",
      borderColor: "border-violet-200",
      href: "/market-menu/whatsapp-marketing/lead-whatsapp-marketing/lead-referredby-message",
      //   target:"_self",
      stats: "Active Lead ReferredBy Whatsapp Message"
    }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen w-full bg-gray-50", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
      lineNumber: 46,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
        lineNumber: 48,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
          /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
            lineNumber: 51,
            columnNumber: 18
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-3xl font-bold text-gray-900", children: "Lead Whatsapp Message Management" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
            lineNumber: 52,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mt-2", children: "Manage and organize your Due Whatsapp Message" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
            lineNumber: 55,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
          lineNumber: 50,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6", children: leadwhatsappCategories.map(
          (category) => /* @__PURE__ */ jsxDEV(Link, { to: category.href, className: "group", children: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `relative h-full overflow-hidden rounded-xl bg-white border ${category.borderColor} shadow-md hover:shadow-lg transition-all duration-300`,
              children: [
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${category.color} opacity-5 group-hover:opacity-10 rounded-full -mr-16 -mt-16 transition-all duration-300 blur-xl`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
                    lineNumber: 66,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "relative p-7", children: [
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: `inline-flex items-center justify-center w-14 h-14 ${category.lightColor} rounded-lg mb-5 group-hover:scale-105 transition-transform duration-300`,
                      children: /* @__PURE__ */ jsxDEV("div", { children: category.icon }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
                        lineNumber: 74,
                        columnNumber: 25
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
                      lineNumber: 71,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "mb-5", children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900 mb-2 group-hover:text-gray-950 transition-colors", children: category.title }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
                      lineNumber: 78,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600 leading-relaxed", children: category.description }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
                      lineNumber: 81,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
                    lineNumber: 77,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-4 border-t border-gray-100 group-hover:border-gray-200 transition-colors", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-gray-500 uppercase tracking-wide group-hover:text-gray-700 transition-colors", children: category.stats }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
                      lineNumber: 87,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: `p-1.5 rounded-lg bg-gradient-to-br ${category.color} opacity-0 group-hover:opacity-100 transform translate-x-1 group-hover:translate-x-0 transition-all duration-300`,
                        children: /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-4 h-4 text-white" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
                          lineNumber: 93,
                          columnNumber: 27
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
                        lineNumber: 90,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
                    lineNumber: 86,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
                  lineNumber: 70,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r ${category.color} opacity-0 group-hover:opacity-100 transition-opacity duration-300`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
                    lineNumber: 98,
                    columnNumber: 21
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
              lineNumber: 63,
              columnNumber: 19
            },
            this
          ) }, category.id, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
            lineNumber: 62,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
          lineNumber: 60,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-16 p-8 bg-gradient-to-br from-violet-50 to-indigo-50 rounded-2xl border border-violet-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsxDEV(Zap, { className: "w-6 h-6 text-violet-600 mt-1" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
            lineNumber: 108,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
            lineNumber: 107,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-slate-900 mb-2", children: "Quick Tips" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
              lineNumber: 111,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-slate-700", children: "Manage Lead whatsapp and more with Marketing Management—everything in one place." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
              lineNumber: 112,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
            lineNumber: 110,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
          lineNumber: 106,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
          lineNumber: 105,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
        lineNumber: 49,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
      lineNumber: 47,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
    lineNumber: 45,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx",
    lineNumber: 44,
    columnNumber: 5
  }, this);
};
_c = LeadWhatsappMessageMenu;
export default LeadWhatsappMessageMenu;
var _c;
$RefreshReg$(_c, "LeadWhatsappMessageMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LeadWhatsappMessageMenu.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JZO0FBbEJaLDJCQUFxQjtBQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDdkMsT0FBT0EsWUFBWTtBQUNuQixPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLE9BQU9DLFdBQVdDLGNBQWFDLFdBQVk7QUFDcEQsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsOEJBQThCO0FBQ3ZDLE9BQU9DLGdCQUFnQjtBQUl2QixNQUFNQywwQkFBMEJBLE1BQU07QUFDcEMsUUFBTUMseUJBQXlCO0FBQUEsSUFFNUI7QUFBQSxNQUNDQyxJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLGFBQWE7QUFBQSxNQUNiQyxNQUFNLHVCQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStCO0FBQUEsTUFDckNDLE9BQU87QUFBQSxNQUNQQyxZQUFZO0FBQUEsTUFDWkMsYUFBYTtBQUFBLE1BQ2JDLE1BQU07QUFBQTtBQUFBLE1BRU5DLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQztBQUFBLE1BQ0NSLElBQUk7QUFBQSxNQUNKQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE1BQU0sdUJBQUMsY0FBVyxXQUFVLGFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0I7QUFBQSxNQUNyQ0MsT0FBTztBQUFBLE1BQ1BDLFlBQVk7QUFBQSxNQUNaQyxhQUFhO0FBQUEsTUFDYkMsTUFBTTtBQUFBO0FBQUEsTUFFTkMsT0FBTztBQUFBLElBQ1Q7QUFBQSxFQUFDO0FBS0gsU0FDRSx1QkFBQyxTQUFJLFdBQVUsY0FDYixpQ0FBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSwyQkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUTtBQUFBLElBQ1IsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSw2QkFBQyxVQUFPLFlBQVksUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QjtBQUFBLE1BQ3pCLHVCQUFDLFNBQUksV0FBVSxPQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLFFBQ1Y7QUFBQSxpQ0FBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFXO0FBQUEsVUFDZCx1QkFBQyxRQUFHLFdBQVUsb0NBQW1DLGdEQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsc0JBQXFCLDZEQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSx3REFDWlQsaUNBQXVCVTtBQUFBQSxVQUFJLENBQUNDLGFBQzNCLHVCQUFDLFFBQXVCLElBQUlBLFNBQVNILE1BQU0sV0FBVSxTQUNuRDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVyw4REFBOERHLFNBQVNKLFdBQVc7QUFBQSxjQUU3RjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVcsc0RBQXNESSxTQUFTTixLQUFLO0FBQUE7QUFBQSxrQkFEakY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNvTDtBQUFBLGdCQUdwTCx1QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFXLHFEQUFxRE0sU0FBU0wsVUFBVTtBQUFBLHNCQUVuRixpQ0FBQyxTQUFLSyxtQkFBU1AsUUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFvQjtBQUFBO0FBQUEsb0JBSHRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsMkNBQUMsUUFBRyxXQUFVLG9GQUNYTyxtQkFBU1QsU0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsT0FBRSxXQUFVLHlDQUNWUyxtQkFBU1IsZUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFPQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSxpSEFDYjtBQUFBLDJDQUFDLFVBQUssV0FBVSx5R0FDYlEsbUJBQVNGLFNBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVcsc0NBQXNDRSxTQUFTTixLQUFLO0FBQUEsd0JBRS9ELGlDQUFDLGdCQUFhLFdBQVUsd0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTRDO0FBQUE7QUFBQSxzQkFIOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUlBO0FBQUEsdUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFTQTtBQUFBLHFCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTBCQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVcsd0RBQXdETSxTQUFTTixLQUFLO0FBQUE7QUFBQSxrQkFEbkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUN3SjtBQUFBO0FBQUE7QUFBQSxZQXBDMUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBc0NBLEtBdkNTTSxTQUFTVixJQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXdDQTtBQUFBLFFBQ0QsS0EzQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRDQTtBQUFBLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLGdHQUNqQixpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxpQkFDYixpQ0FBQyxPQUFJLFdBQVUsa0NBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkMsS0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSw2Q0FBNEMsMEJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9FO0FBQUEsWUFDcEUsdUJBQUMsT0FBRSxXQUFVLGtCQUFpQixnR0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEc7QUFBQSxlQUZoSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUEsS0FURTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUo7QUFBQSxXQWxFQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUVBO0FBQUEsU0FyRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNFQTtBQUFBLE9BeEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5RUEsS0ExRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJFQTtBQUVKO0FBQUVXLEtBN0dJYjtBQStHTixlQUFlQTtBQUF3QixJQUFBYTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiTmF2YmFyIiwiU2lkZWJhciIsIlVzZXJzIiwiQnJpZWZjYXNlIiwiQ2hldnJvblJpZ2h0IiwiWmFwIiwiTWRFbWFpbCIsIkZhV2hhdHNhcHAiLCJSaU1vbmV5UnVwZWVDaXJjbGVMaW5lIiwiQnJlYWRjcnVtYiIsIkxlYWRXaGF0c2FwcE1lc3NhZ2VNZW51IiwibGVhZHdoYXRzYXBwQ2F0ZWdvcmllcyIsImlkIiwidGl0bGUiLCJkZXNjcmlwdGlvbiIsImljb24iLCJjb2xvciIsImxpZ2h0Q29sb3IiLCJib3JkZXJDb2xvciIsImhyZWYiLCJzdGF0cyIsIm1hcCIsImNhdGVnb3J5IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTGVhZFdoYXRzYXBwTWVzc2FnZU1lbnUuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgeyBVc2VycywgQnJpZWZjYXNlLCBDaGV2cm9uUmlnaHQsWmFwICB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgTWRFbWFpbCB9IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5pbXBvcnQgeyBGYVdoYXRzYXBwIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IFJpTW9uZXlSdXBlZUNpcmNsZUxpbmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvcmlcIjtcclxuaW1wb3J0IEJyZWFkY3J1bWIgZnJvbSBcIi4uL2hlbHBlcnMvQnJlYWRjcnVtYlwiO1xyXG5cclxuXHJcblxyXG5jb25zdCBMZWFkV2hhdHNhcHBNZXNzYWdlTWVudSA9ICgpID0+IHtcclxuICBjb25zdCBsZWFkd2hhdHNhcHBDYXRlZ29yaWVzID0gW1xyXG4gIFxyXG4gICAgIHtcclxuICAgICAgaWQ6IDIsXHJcbiAgICAgIHRpdGxlOiBcIldlbGNvbWUgTWVzc2FnZVwiLFxyXG4gICAgICBkZXNjcmlwdGlvbjogXCJNYW5hZ2UgV2VsY29tZSBNZXNzYWdlXCIsXHJcbiAgICAgIGljb246IDxGYVdoYXRzYXBwIGNsYXNzTmFtZT1cInctOCBoLThcIiAvPixcclxuICAgICAgY29sb3I6IFwiZnJvbS12aW9sZXQtNjAwIHRvLXZpb2xldC03MDBcIixcclxuICAgICAgbGlnaHRDb2xvcjogXCJiZy12aW9sZXQtNTBcIixcclxuICAgICAgYm9yZGVyQ29sb3I6IFwiYm9yZGVyLXZpb2xldC0yMDBcIixcclxuICAgICAgaHJlZjogXCIvbWFya2V0LW1lbnUvd2hhdHNhcHAtbWFya2V0aW5nL2xlYWQtd2hhdHNhcHAtbWFya2V0aW5nL2xlYWQtd2VsY29tZS1tZXNzYWdlXCIsXHJcbiAgICAvLyAgIHRhcmdldDpcIl9zZWxmXCIsXHJcbiAgICAgIHN0YXRzOiBcIkFjdGl2ZSBMZWFkIFdoYXRzYXBwIE1lc3NhZ2VcIixcclxuICAgIH0sXHJcbiAgICAge1xyXG4gICAgICBpZDogMixcclxuICAgICAgdGl0bGU6IFwiUmVmZXJyZWRCeSBXaGF0c2FwcFwiLFxyXG4gICAgICBkZXNjcmlwdGlvbjogXCJSZWZlcnJlZEJ5IFdoYXRzYXBwXCIsXHJcbiAgICAgIGljb246IDxGYVdoYXRzYXBwIGNsYXNzTmFtZT1cInctOCBoLThcIiAvPixcclxuICAgICAgY29sb3I6IFwiZnJvbS12aW9sZXQtNjAwIHRvLXZpb2xldC03MDBcIixcclxuICAgICAgbGlnaHRDb2xvcjogXCJiZy12aW9sZXQtNTBcIixcclxuICAgICAgYm9yZGVyQ29sb3I6IFwiYm9yZGVyLXZpb2xldC0yMDBcIixcclxuICAgICAgaHJlZjogXCIvbWFya2V0LW1lbnUvd2hhdHNhcHAtbWFya2V0aW5nL2xlYWQtd2hhdHNhcHAtbWFya2V0aW5nL2xlYWQtcmVmZXJyZWRieS1tZXNzYWdlXCIsXHJcbiAgICAvLyAgIHRhcmdldDpcIl9zZWxmXCIsXHJcbiAgICAgIHN0YXRzOiBcIkFjdGl2ZSBMZWFkIFJlZmVycmVkQnkgV2hhdHNhcHAgTWVzc2FnZVwiLFxyXG4gICAgfSxcclxuICAgXHJcbiAgICAgXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtc2NyZWVuIHctZnVsbCBiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgPE5hdmJhciB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLThcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XHJcbiAgICAgICAgICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgTGVhZCBXaGF0c2FwcCBNZXNzYWdlIE1hbmFnZW1lbnRcclxuICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgbXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgTWFuYWdlIGFuZCBvcmdhbml6ZSB5b3VyIER1ZSBXaGF0c2FwcCBNZXNzYWdlXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMiBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgIHtsZWFkd2hhdHNhcHBDYXRlZ29yaWVzLm1hcCgoY2F0ZWdvcnkpID0+IChcclxuICAgICAgICAgICAgICAgIDxMaW5rIGtleT17Y2F0ZWdvcnkuaWR9IHRvPXtjYXRlZ29yeS5ocmVmfSBjbGFzc05hbWU9XCJncm91cFwiID5cclxuICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIGgtZnVsbCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBiZy13aGl0ZSBib3JkZXIgJHtjYXRlZ29yeS5ib3JkZXJDb2xvcn0gc2hhZG93LW1kIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCB3LTMyIGgtMzIgYmctZ3JhZGllbnQtdG8tYnIgJHtjYXRlZ29yeS5jb2xvcn0gb3BhY2l0eS01IGdyb3VwLWhvdmVyOm9wYWNpdHktMTAgcm91bmRlZC1mdWxsIC1tci0xNiAtbXQtMTYgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGJsdXIteGxgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcC03XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LTE0IGgtMTQgJHtjYXRlZ29yeS5saWdodENvbG9yfSByb3VuZGVkLWxnIG1iLTUgZ3JvdXAtaG92ZXI6c2NhbGUtMTA1IHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTMwMGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+e2NhdGVnb3J5Lmljb259PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgbWItMiBncm91cC1ob3Zlcjp0ZXh0LWdyYXktOTUwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2NhdGVnb3J5LnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDAgbGVhZGluZy1yZWxheGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2NhdGVnb3J5LmRlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwdC00IGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBncm91cC1ob3Zlcjpib3JkZXItZ3JheS0yMDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIGdyb3VwLWhvdmVyOnRleHQtZ3JheS03MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnkuc3RhdHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMS41IHJvdW5kZWQtbGcgYmctZ3JhZGllbnQtdG8tYnIgJHtjYXRlZ29yeS5jb2xvcn0gb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zZm9ybSB0cmFuc2xhdGUteC0xIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwYH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXdoaXRlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYWJzb2x1dGUgdG9wLTAgbGVmdC0wIHJpZ2h0LTAgaC0wLjUgYmctZ3JhZGllbnQtdG8tciAke2NhdGVnb3J5LmNvbG9yfSBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5IGR1cmF0aW9uLTMwMGB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTYgcC04IGJnLWdyYWRpZW50LXRvLWJyIGZyb20tdmlvbGV0LTUwIHRvLWluZGlnby01MCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXZpb2xldC0xMDBcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICA8WmFwIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC12aW9sZXQtNjAwIG10LTFcIiAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwIG1iLTJcIj5RdWljayBUaXBzPC9oMz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNzAwXCI+TWFuYWdlIExlYWQgd2hhdHNhcHAgYW5kIG1vcmUgd2l0aCBNYXJrZXRpbmcgTWFuYWdlbWVudOKAlGV2ZXJ5dGhpbmcgaW4gb25lIHBsYWNlLjwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBMZWFkV2hhdHNhcHBNZXNzYWdlTWVudTtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0xlYWRXaGF0c2FwcE1lc3NhZ2VNZW51LmpzeCJ9