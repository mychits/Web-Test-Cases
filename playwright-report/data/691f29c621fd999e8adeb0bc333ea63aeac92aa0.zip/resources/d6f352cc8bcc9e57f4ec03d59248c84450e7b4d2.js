import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PincodeReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { Dropdown, Select, Row, Col, Card } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import {
  UserOutlined,
  TeamOutlined,
  AppstoreOutlined,
  EnvironmentOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
const PincodeReport = () => {
  _s();
  const [isLoading, setIsLoading] = useState(false);
  const [allUsers, setAllUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [selectedPincode, setSelectedPincode] = useState("");
  const [selectedReferredEmployee, setSelectedReferredEmployee] = useState("");
  const [selectedUserId, setSelectedUserId] = useState("");
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const onGlobalSearchChangeHandler = (e) => {
    setSearchText(e.target.value);
  };
  const pincodeOptions = useMemo(() => {
    const uniquePincodes = [...new Set(allUsers.map((user) => user.pincode))].filter(Boolean);
    return uniquePincodes.map((pincode) => ({ value: pincode, label: pincode }));
  }, [allUsers]);
  const referredEmployeeOptions = useMemo(() => {
    const uniqueEmployees = [...new Set(allUsers.map((user) => user.referred_employee_name))].filter(Boolean);
    return uniqueEmployees.map((employee) => ({ value: employee, label: employee }));
  }, [allUsers]);
  const userOptions = useMemo(() => {
    const uniqueUsers = [...new Set(allUsers.map((user) => user.full_name))].filter(Boolean);
    return uniqueUsers.map((user) => ({ value: user, label: user }));
  }, [allUsers]);
  useEffect(() => {
    const fetchAllPincodeData = async () => {
      setIsLoading(true);
      try {
        const response = await api.get("/v1/admin/users/list-pincode");
        if (response.data && response.data.success) {
          const formattedData = response.data.data.map((user, index) => ({
            _id: user._id,
            id: index + 1,
            full_name: user.full_name || "N/A",
            phone_number: user.phone_number || "N/A",
            address: user.address || "N/A",
            pincode: user.pincode || "N/A",
            referred_employee_name: user?.referred_employee?.name || "N/A",
            referred_employee_phone: user?.referred_employee?.phone_number || "N/A",
            referred_employee_id: user?.referred_employee?._id || "N/A",
            action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center gap-2", children: /* @__PURE__ */ jsxDEV(
              Dropdown,
              {
                menu: {
                  items: [
                    {
                      key: "1",
                      label: /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: "text-green-600",
                          onClick: () => handleUpdateModalOpen(user._id),
                          children: "Edit"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
                          lineNumber: 82,
                          columnNumber: 21
                        },
                        this
                      )
                    },
                    {
                      key: "2",
                      label: /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: "text-red-600",
                          onClick: () => handleDeleteModalOpen(user._id),
                          children: "Delete"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
                          lineNumber: 93,
                          columnNumber: 21
                        },
                        this
                      )
                    }
                  ]
                },
                placement: "bottomLeft",
                children: /* @__PURE__ */ jsxDEV(IoMdMore, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
                  lineNumber: 105,
                  columnNumber: 19
                }, this)
              },
              user._id,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
                lineNumber: 75,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
              lineNumber: 74,
              columnNumber: 13
            }, this)
          }));
          setAllUsers(formattedData);
          setFilteredUsers(formattedData);
        }
      } catch (error) {
        console.error("Error fetching pincode data:", error);
        setAlertConfig({
          visibility: true,
          message: "Error fetching pincode data. Please try again.",
          type: "error"
        });
      } finally {
        setIsLoading(false);
      }
    };
    fetchAllPincodeData();
  }, []);
  useEffect(() => {
    let filtered = [...allUsers];
    if (selectedPincode) {
      filtered = filtered.filter((user) => user.pincode === selectedPincode);
    }
    if (selectedReferredEmployee) {
      filtered = filtered.filter((user) => user.referred_employee_name === selectedReferredEmployee);
    }
    if (selectedUserId) {
      filtered = filtered.filter((user) => user.full_name === selectedUserId);
    }
    setFilteredUsers(filtered);
  }, [allUsers, selectedPincode, selectedReferredEmployee, selectedUserId]);
  const clearAllFilters = () => {
    setSelectedPincode("");
    setSelectedReferredEmployee("");
    setSelectedUserId("");
  };
  const overview = useMemo(() => {
    const uniqueUsers = new Set(filteredUsers.map((user) => user._id));
    const uniquePincodes = new Set(filteredUsers.map((user) => user.pincode));
    const uniqueEmployees = new Set(
      filteredUsers.map((user) => user.referred_employee_id)
    );
    return {
      totalUsers: uniqueUsers.size,
      totalPincodes: uniquePincodes.size,
      totalEmployees: uniqueEmployees.size,
      totalUsersWithAddress: filteredUsers.filter(
        (user) => user.address !== "N/A"
      ).length
    };
  }, [filteredUsers]);
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "full_name", header: "Full Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "address", header: "Address" },
    { key: "pincode", header: "Pincode" },
    { key: "referred_employee_name", header: "Referred Employee" },
    { key: "referred_employee_phone", header: "Employee Phone" }
  ];
  const handleUpdateModalOpen = (id) => {
    console.log("Edit user:", id);
  };
  const handleDeleteModalOpen = (id) => {
    console.log("Delete user:", id);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full overflow-x-hidden", children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
        lineNumber: 195,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 mt-30", children: [
      /* @__PURE__ */ jsxDEV(
        CustomAlert,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
          lineNumber: 200,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-7", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "font-bold text-2xl", children: "Pincode Report" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
          lineNumber: 206,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-end gap-6 w-full", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 font-medium text-gray-700", children: "Pincode" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
              lineNumber: 213,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                popupMatchSelectWidth: false,
                placeholder: "Select Pincode",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-64 h-11",
                value: selectedPincode || void 0,
                onChange: setSelectedPincode,
                allowClear: true,
                children: pincodeOptions.map(
                  (option) => /* @__PURE__ */ jsxDEV(Select.Option, { value: option.value, children: option.label }, option.value, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
                    lineNumber: 232,
                    columnNumber: 23
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
                lineNumber: 216,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
            lineNumber: 212,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 font-medium text-gray-700", children: "Referred Employee" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
              lineNumber: 241,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                popupMatchSelectWidth: false,
                placeholder: "Select Referred Employee",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-64 h-11",
                value: selectedReferredEmployee || void 0,
                onChange: setSelectedReferredEmployee,
                allowClear: true,
                children: referredEmployeeOptions.map(
                  (option) => /* @__PURE__ */ jsxDEV(Select.Option, { value: option.value, children: option.label }, option.value, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
                    lineNumber: 260,
                    columnNumber: 23
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
                lineNumber: 244,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
            lineNumber: 240,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 font-medium text-gray-700", children: "User" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
              lineNumber: 269,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                popupMatchSelectWidth: false,
                placeholder: "Select User",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                className: "w-64 h-11",
                value: selectedUserId || void 0,
                onChange: setSelectedUserId,
                allowClear: true,
                children: userOptions.map(
                  (option) => /* @__PURE__ */ jsxDEV(Select.Option, { value: option.value, children: option.label }, option.value, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
                    lineNumber: 288,
                    columnNumber: 23
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
                lineNumber: 272,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
            lineNumber: 268,
            columnNumber: 19
          }, this),
          (selectedPincode || selectedReferredEmployee || selectedUserId) && /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: clearAllFilters,
              className: "h-11 px-6 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors flex items-center",
              children: "Clear Filters"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
              lineNumber: 298,
              columnNumber: 23
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
            lineNumber: 297,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
          lineNumber: 210,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
          lineNumber: 209,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
          lineNumber: 208,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Row, { gutter: [20, 20], className: "mb-6", children: [
          {
            title: "Total Users",
            value: overview.totalUsers,
            color: "text-blue-600",
            icon: /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-2xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
              lineNumber: 317,
              columnNumber: 23
            }, this)
          },
          {
            title: "Unique Pincodes",
            value: overview.totalPincodes,
            color: "text-green-600",
            icon: /* @__PURE__ */ jsxDEV(EnvironmentOutlined, { className: "text-2xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
              lineNumber: 323,
              columnNumber: 23
            }, this)
          },
          {
            title: "Referred Employees",
            value: overview.totalEmployees,
            color: "text-purple-600",
            icon: /* @__PURE__ */ jsxDEV(TeamOutlined, { className: "text-2xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
              lineNumber: 329,
              columnNumber: 23
            }, this)
          },
          {
            title: "Users with Address",
            value: overview.totalUsersWithAddress,
            color: "text-orange-600",
            icon: /* @__PURE__ */ jsxDEV(AppstoreOutlined, { className: "text-2xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
              lineNumber: 335,
              columnNumber: 23
            }, this)
          }
        ].map(
          (item, index) => /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 8, lg: 6, xl: 6, children: /* @__PURE__ */ jsxDEV(
            Card,
            {
              bordered: false,
              className: "rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300",
              bodyStyle: { padding: 20 },
              children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: `text-3xl ${item.color}`, children: item.icon }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
                  lineNumber: 345,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm font-medium", children: item.title }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
                    lineNumber: 347,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("h2", { className: `text-xl font-bold mt-1 ${item.color}`, children: item.value }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
                    lineNumber: 350,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
                  lineNumber: 346,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
                lineNumber: 344,
                columnNumber: 21
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
              lineNumber: 339,
              columnNumber: 19
            },
            this
          ) }, index, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
            lineNumber: 338,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
          lineNumber: 311,
          columnNumber: 13
        }, this),
        filteredUsers && filteredUsers.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "w-full overflow-x-auto scrollbar-thin", children: /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: filterOption(filteredUsers, searchText),
            columns,
            exportedPdfName: "Pincode Report",
            exportedFileName: "Pincode_Report.csv"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
            lineNumber: 363,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
          lineNumber: 362,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex w-full justify-center items-center min-h-[200px]", children: isLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
          lineNumber: 373,
          columnNumber: 15
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-gray-500 text-center", children: [
          /* @__PURE__ */ jsxDEV(EnvironmentOutlined, { className: "text-4xl mb-2" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
            lineNumber: 376,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "No data found" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
            lineNumber: 377,
            columnNumber: 21
          }, this),
          allUsers.length === 0 && /* @__PURE__ */ jsxDEV("p", { className: "text-sm", children: "No pincode data available" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
            lineNumber: 379,
            columnNumber: 17
          }, this),
          (selectedPincode || selectedReferredEmployee || selectedUserId) && /* @__PURE__ */ jsxDEV("p", { className: "text-sm", children: "Try adjusting your filters" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
            lineNumber: 382,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
          lineNumber: 375,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
          lineNumber: 371,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
        lineNumber: 205,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
      lineNumber: 199,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
    lineNumber: 194,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx",
    lineNumber: 193,
    columnNumber: 5
  }, this);
};
_s(PincodeReport, "79GoQ/MTjkQIE1K5dVsVuHnlpTw=");
_c = PincodeReport;
export default PincodeReport;
var _c;
$RefreshReg$(_c, "PincodeReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PincodeReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUYwQjsyQkFqRjFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsU0FBU0MsZ0JBQWdCO0FBQzdDLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxpQkFBaUI7QUFDeEIsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGtCQUFrQjtBQUN6QixTQUFTQyxVQUFVQyxRQUFRQyxLQUFLQyxLQUFLQyxZQUFZO0FBQ2pEO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUVQLE1BQU1DLGdCQUFnQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzFCLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJcEIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3FCLFVBQVVDLFdBQVcsSUFBSXRCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUN1QixlQUFlQyxnQkFBZ0IsSUFBSXhCLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUN5QixZQUFZQyxhQUFhLElBQUkxQixTQUFTLEVBQUU7QUFHL0MsUUFBTSxDQUFDMkIsaUJBQWlCQyxrQkFBa0IsSUFBSTVCLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUM2QiwwQkFBMEJDLDJCQUEyQixJQUFJOUIsU0FBUyxFQUFFO0FBQzNFLFFBQU0sQ0FBQytCLGdCQUFnQkMsaUJBQWlCLElBQUloQyxTQUFTLEVBQUU7QUFFdkQsUUFBTSxDQUFDaUMsYUFBYUMsY0FBYyxJQUFJbEMsU0FBUztBQUFBLElBQzdDbUMsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBRUQsUUFBTUMsOEJBQThCQSxDQUFDQyxNQUFNO0FBQ3pDYixrQkFBY2EsRUFBRUMsT0FBT0MsS0FBSztBQUFBLEVBQzlCO0FBR0EsUUFBTUMsaUJBQWlCM0MsUUFBUSxNQUFNO0FBQ25DLFVBQU00QyxpQkFBaUIsQ0FBQyxHQUFHLElBQUlDLElBQUl2QixTQUFTd0IsSUFBSSxDQUFDQyxTQUFTQSxLQUFLQyxPQUFPLENBQUMsQ0FBQyxFQUFFQyxPQUFPQyxPQUFPO0FBQ3hGLFdBQU9OLGVBQWVFLElBQUksQ0FBQUUsYUFBWSxFQUFFTixPQUFPTSxTQUFTRyxPQUFPSCxRQUFRLEVBQUU7QUFBQSxFQUMzRSxHQUFHLENBQUMxQixRQUFRLENBQUM7QUFFYixRQUFNOEIsMEJBQTBCcEQsUUFBUSxNQUFNO0FBQzVDLFVBQU1xRCxrQkFBa0IsQ0FBQyxHQUFHLElBQUlSLElBQUl2QixTQUFTd0IsSUFBSSxDQUFDQyxTQUFTQSxLQUFLTyxzQkFBc0IsQ0FBQyxDQUFDLEVBQUVMLE9BQU9DLE9BQU87QUFDeEcsV0FBT0csZ0JBQWdCUCxJQUFJLENBQUFTLGNBQWEsRUFBRWIsT0FBT2EsVUFBVUosT0FBT0ksU0FBUyxFQUFFO0FBQUEsRUFDL0UsR0FBRyxDQUFDakMsUUFBUSxDQUFDO0FBRWIsUUFBTWtDLGNBQWN4RCxRQUFRLE1BQU07QUFDaEMsVUFBTXlELGNBQWMsQ0FBQyxHQUFHLElBQUlaLElBQUl2QixTQUFTd0IsSUFBSSxDQUFDQyxTQUFTQSxLQUFLVyxTQUFTLENBQUMsQ0FBQyxFQUFFVCxPQUFPQyxPQUFPO0FBQ3ZGLFdBQU9PLFlBQVlYLElBQUksQ0FBQUMsVUFBUyxFQUFFTCxPQUFPSyxNQUFNSSxPQUFPSixLQUFLLEVBQUU7QUFBQSxFQUMvRCxHQUFHLENBQUN6QixRQUFRLENBQUM7QUFHYnZCLFlBQVUsTUFBTTtBQUNkLFVBQU00RCxzQkFBc0IsWUFBWTtBQUN0Q3RDLG1CQUFhLElBQUk7QUFDakIsVUFBSTtBQUNGLGNBQU11QyxXQUFXLE1BQU0xRCxJQUFJMkQsSUFBSSw4QkFBOEI7QUFFN0QsWUFBSUQsU0FBU0UsUUFBUUYsU0FBU0UsS0FBS0MsU0FBUztBQUMxQyxnQkFBTUMsZ0JBQWdCSixTQUFTRSxLQUFLQSxLQUFLaEIsSUFBSSxDQUFDQyxNQUFNa0IsV0FBVztBQUFBLFlBQzdEQyxLQUFLbkIsS0FBS21CO0FBQUFBLFlBQ1ZDLElBQUlGLFFBQVE7QUFBQSxZQUNaUCxXQUFXWCxLQUFLVyxhQUFhO0FBQUEsWUFDN0JVLGNBQWNyQixLQUFLcUIsZ0JBQWdCO0FBQUEsWUFDbkNDLFNBQVN0QixLQUFLc0IsV0FBVztBQUFBLFlBQ3pCckIsU0FBU0QsS0FBS0MsV0FBVztBQUFBLFlBQ3pCTSx3QkFBd0JQLE1BQU11QixtQkFBbUJDLFFBQVE7QUFBQSxZQUN6REMseUJBQXlCekIsTUFBTXVCLG1CQUFtQkYsZ0JBQWdCO0FBQUEsWUFDbEVLLHNCQUFzQjFCLE1BQU11QixtQkFBbUJKLE9BQU87QUFBQSxZQUN0RFEsUUFDRSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFFQyxNQUFNO0FBQUEsa0JBQ0pDLE9BQU87QUFBQSxvQkFDTDtBQUFBLHNCQUNFQyxLQUFLO0FBQUEsc0JBQ0x6QixPQUNFO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFdBQVU7QUFBQSwwQkFDVixTQUFTLE1BQU0wQixzQkFBc0I5QixLQUFLbUIsR0FBRztBQUFBLDBCQUFFO0FBQUE7QUFBQSx3QkFGakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUtBO0FBQUEsb0JBRUo7QUFBQSxvQkFDQTtBQUFBLHNCQUNFVSxLQUFLO0FBQUEsc0JBQ0x6QixPQUNFO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFdBQVU7QUFBQSwwQkFDVixTQUFTLE1BQU0yQixzQkFBc0IvQixLQUFLbUIsR0FBRztBQUFBLDBCQUFFO0FBQUE7QUFBQSx3QkFGakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUtBO0FBQUEsb0JBRUo7QUFBQSxrQkFBQztBQUFBLGdCQUVMO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUVWLGlDQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBUztBQUFBO0FBQUEsY0E3QkpuQixLQUFLbUI7QUFBQUEsY0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBK0JBLEtBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUNBO0FBQUEsVUFFSixFQUFFO0FBRUYzQyxzQkFBWXlDLGFBQWE7QUFDekJ2QywyQkFBaUJ1QyxhQUFhO0FBQUEsUUFDaEM7QUFBQSxNQUNGLFNBQVNlLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sZ0NBQWdDQSxLQUFLO0FBQ25ENUMsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNILFVBQUM7QUFDQ2pCLHFCQUFhLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFFQXNDLHdCQUFvQjtBQUFBLEVBQ3RCLEdBQUcsRUFBRTtBQUdMNUQsWUFBVSxNQUFNO0FBQ2QsUUFBSWtGLFdBQVcsQ0FBQyxHQUFHM0QsUUFBUTtBQUUzQixRQUFJTSxpQkFBaUI7QUFDbkJxRCxpQkFBV0EsU0FBU2hDLE9BQU8sQ0FBQUYsU0FBUUEsS0FBS0MsWUFBWXBCLGVBQWU7QUFBQSxJQUNyRTtBQUVBLFFBQUlFLDBCQUEwQjtBQUM1Qm1ELGlCQUFXQSxTQUFTaEMsT0FBTyxDQUFBRixTQUFRQSxLQUFLTywyQkFBMkJ4Qix3QkFBd0I7QUFBQSxJQUM3RjtBQUVBLFFBQUlFLGdCQUFnQjtBQUNsQmlELGlCQUFXQSxTQUFTaEMsT0FBTyxDQUFBRixTQUFRQSxLQUFLVyxjQUFjMUIsY0FBYztBQUFBLElBQ3RFO0FBRUFQLHFCQUFpQndELFFBQVE7QUFBQSxFQUMzQixHQUFHLENBQUMzRCxVQUFVTSxpQkFBaUJFLDBCQUEwQkUsY0FBYyxDQUFDO0FBR3hFLFFBQU1rRCxrQkFBa0JBLE1BQU07QUFDNUJyRCx1QkFBbUIsRUFBRTtBQUNyQkUsZ0NBQTRCLEVBQUU7QUFDOUJFLHNCQUFrQixFQUFFO0FBQUEsRUFDdEI7QUFHQSxRQUFNa0QsV0FBV25GLFFBQVEsTUFBTTtBQUM3QixVQUFNeUQsY0FBYyxJQUFJWixJQUFJckIsY0FBY3NCLElBQUksQ0FBQ0MsU0FBU0EsS0FBS21CLEdBQUcsQ0FBQztBQUNqRSxVQUFNdEIsaUJBQWlCLElBQUlDLElBQUlyQixjQUFjc0IsSUFBSSxDQUFDQyxTQUFTQSxLQUFLQyxPQUFPLENBQUM7QUFDeEUsVUFBTUssa0JBQWtCLElBQUlSO0FBQUFBLE1BQzFCckIsY0FBY3NCLElBQUksQ0FBQ0MsU0FBU0EsS0FBSzBCLG9CQUFvQjtBQUFBLElBQ3ZEO0FBRUEsV0FBTztBQUFBLE1BQ0xXLFlBQVkzQixZQUFZNEI7QUFBQUEsTUFDeEJDLGVBQWUxQyxlQUFleUM7QUFBQUEsTUFDOUJFLGdCQUFnQmxDLGdCQUFnQmdDO0FBQUFBLE1BQ2hDRyx1QkFBdUJoRSxjQUFjeUI7QUFBQUEsUUFDbkMsQ0FBQ0YsU0FBU0EsS0FBS3NCLFlBQVk7QUFBQSxNQUM3QixFQUFFb0I7QUFBQUEsSUFDSjtBQUFBLEVBQ0YsR0FBRyxDQUFDakUsYUFBYSxDQUFDO0FBRWxCLFFBQU1rRSxVQUFVO0FBQUEsSUFDZCxFQUFFZCxLQUFLLE1BQU1lLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVmLEtBQUssYUFBYWUsUUFBUSxZQUFZO0FBQUEsSUFDeEMsRUFBRWYsS0FBSyxnQkFBZ0JlLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVmLEtBQUssV0FBV2UsUUFBUSxVQUFVO0FBQUEsSUFDcEMsRUFBRWYsS0FBSyxXQUFXZSxRQUFRLFVBQVU7QUFBQSxJQUNwQyxFQUFFZixLQUFLLDBCQUEwQmUsUUFBUSxvQkFBb0I7QUFBQSxJQUM3RCxFQUFFZixLQUFLLDJCQUEyQmUsUUFBUSxpQkFBaUI7QUFBQSxFQUFDO0FBSTlELFFBQU1kLHdCQUF3QkEsQ0FBQ1YsT0FBTztBQUNwQ2EsWUFBUVksSUFBSSxjQUFjekIsRUFBRTtBQUFBLEVBQzlCO0FBRUEsUUFBTVcsd0JBQXdCQSxDQUFDWCxPQUFPO0FBQ3BDYSxZQUFRWSxJQUFJLGdCQUFnQnpCLEVBQUU7QUFBQSxFQUNoQztBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDRCQUNiLGlDQUFDLFNBQ0M7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLFlBQVk7QUFBQTtBQUFBLE1BRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRW1CO0FBQUEsSUFFbkIsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU1qQyxZQUFZSTtBQUFBQSxVQUNsQixXQUFXSixZQUFZRTtBQUFBQSxVQUN2QixTQUFTRixZQUFZRztBQUFBQTtBQUFBQSxRQUh2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHK0I7QUFBQSxNQUUvQix1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxzQkFBcUIsOEJBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUQ7QUFBQSxRQUVqRCx1QkFBQyxTQUFJLFdBQVUsYUFDYixpQ0FBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxTQUFJLFdBQVUseUNBRWI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSx3Q0FBdUMsdUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQSx1QkFBdUI7QUFBQSxnQkFDdkIsYUFBWTtBQUFBLGdCQUNaLGNBQWMsQ0FBQ3dELE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1RDLFlBQVksRUFDWkMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsZ0JBRWpDLFdBQVU7QUFBQSxnQkFDVixPQUFPckUsbUJBQW1CdUU7QUFBQUEsZ0JBQzFCLFVBQVV0RTtBQUFBQSxnQkFDVixZQUFVO0FBQUEsZ0JBRVRjLHlCQUFlRztBQUFBQSxrQkFBSSxDQUFDZ0QsV0FDbkIsdUJBQUMsT0FBTyxRQUFQLEVBQWlDLE9BQU9BLE9BQU9wRCxPQUM3Q29ELGlCQUFPM0MsU0FEVTJDLE9BQU9wRCxPQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBLGNBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQW9CQTtBQUFBLGVBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUJBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSx3Q0FBdUMsaUNBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQSx1QkFBdUI7QUFBQSxnQkFDdkIsYUFBWTtBQUFBLGdCQUNaLGNBQWMsQ0FBQ21ELE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1RDLFlBQVksRUFDWkMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsZ0JBRWpDLFdBQVU7QUFBQSxnQkFDVixPQUFPbkUsNEJBQTRCcUU7QUFBQUEsZ0JBQ25DLFVBQVVwRTtBQUFBQSxnQkFDVixZQUFVO0FBQUEsZ0JBRVRxQixrQ0FBd0JOO0FBQUFBLGtCQUFJLENBQUNnRCxXQUM1Qix1QkFBQyxPQUFPLFFBQVAsRUFBaUMsT0FBT0EsT0FBT3BELE9BQzdDb0QsaUJBQU8zQyxTQURVMkMsT0FBT3BELE9BQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDRDtBQUFBO0FBQUEsY0FuQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBb0JBO0FBQUEsZUF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5QkE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLHdDQUF1QyxvQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLHVCQUF1QjtBQUFBLGdCQUN2QixhQUFZO0FBQUEsZ0JBQ1osY0FBYyxDQUFDbUQsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pDLFNBQVMsRUFDVEMsWUFBWSxFQUNaQyxTQUFTTCxNQUFNSSxZQUFZLENBQUM7QUFBQSxnQkFFakMsV0FBVTtBQUFBLGdCQUNWLE9BQU9qRSxrQkFBa0JtRTtBQUFBQSxnQkFDekIsVUFBVWxFO0FBQUFBLGdCQUNWLFlBQVU7QUFBQSxnQkFFVHVCLHNCQUFZVjtBQUFBQSxrQkFBSSxDQUFDZ0QsV0FDaEIsdUJBQUMsT0FBTyxRQUFQLEVBQWlDLE9BQU9BLE9BQU9wRCxPQUM3Q29ELGlCQUFPM0MsU0FEVTJDLE9BQU9wRCxPQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBLGNBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQW9CQTtBQUFBLGVBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUJBO0FBQUEsV0FHRWQsbUJBQW1CRSw0QkFBNEJFLG1CQUMvQyx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBU2tEO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBQWlHO0FBQUE7QUFBQSxZQUY3RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxhQTlGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0dBLEtBakdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrR0EsS0FuR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9HQTtBQUFBLFFBR0EsdUJBQUMsT0FBSSxRQUFRLENBQUMsSUFBSSxFQUFFLEdBQUcsV0FBVSxRQUM5QjtBQUFBLFVBQ0M7QUFBQSxZQUNFa0IsT0FBTztBQUFBLFlBQ1AxRCxPQUFPeUMsU0FBU0M7QUFBQUEsWUFDaEJpQixPQUFPO0FBQUEsWUFDUEMsTUFBTSx1QkFBQyxnQkFBYSxXQUFVLGNBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtDO0FBQUEsVUFDMUM7QUFBQSxVQUNBO0FBQUEsWUFDRUYsT0FBTztBQUFBLFlBQ1AxRCxPQUFPeUMsU0FBU0c7QUFBQUEsWUFDaEJlLE9BQU87QUFBQSxZQUNQQyxNQUFNLHVCQUFDLHVCQUFvQixXQUFVLGNBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlDO0FBQUEsVUFDakQ7QUFBQSxVQUNBO0FBQUEsWUFDRUYsT0FBTztBQUFBLFlBQ1AxRCxPQUFPeUMsU0FBU0k7QUFBQUEsWUFDaEJjLE9BQU87QUFBQSxZQUNQQyxNQUFNLHVCQUFDLGdCQUFhLFdBQVUsY0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0M7QUFBQSxVQUMxQztBQUFBLFVBQ0E7QUFBQSxZQUNFRixPQUFPO0FBQUEsWUFDUDFELE9BQU95QyxTQUFTSztBQUFBQSxZQUNoQmEsT0FBTztBQUFBLFlBQ1BDLE1BQU0sdUJBQUMsb0JBQWlCLFdBQVUsY0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0M7QUFBQSxVQUM5QztBQUFBLFFBQUMsRUFDRHhEO0FBQUFBLFVBQUksQ0FBQ3lELE1BQU10QyxVQUNYLHVCQUFDLE9BQWdCLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLEdBQ2pEO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxVQUFVO0FBQUEsY0FDVixXQUFVO0FBQUEsY0FDVixXQUFXLEVBQUV1QyxTQUFTLEdBQUc7QUFBQSxjQUV6QixpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVcsWUFBWUQsS0FBS0YsS0FBSyxJQUFLRSxlQUFLRCxRQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRDtBQUFBLGdCQUNyRCx1QkFBQyxTQUNDO0FBQUEseUNBQUMsT0FBRSxXQUFVLHFDQUNWQyxlQUFLSCxTQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxRQUFHLFdBQVcsMEJBQTBCRyxLQUFLRixLQUFLLElBQ2hERSxlQUFLN0QsU0FEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFPQTtBQUFBLG1CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQTtBQUFBLFlBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBZ0JBLEtBakJRdUIsT0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQTtBQUFBLFFBQ0QsS0E5Q0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStDQTtBQUFBLFFBR0N6QyxpQkFBaUJBLGNBQWNpRSxTQUFTLEtBQUssQ0FBQ3JFLFlBQzdDLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBTVosYUFBYWdCLGVBQWVFLFVBQVU7QUFBQSxZQUM1QztBQUFBLFlBQ0EsaUJBQWdCO0FBQUEsWUFDaEIsa0JBQWlCO0FBQUE7QUFBQSxVQUpuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJdUMsS0FMekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BLElBRUEsdUJBQUMsU0FBSSxXQUFVLHlEQUNaTixzQkFDQyx1QkFBQyxrQkFBZSxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFDLElBRXJDLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLGlDQUFDLHVCQUFvQixXQUFVLG1CQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QztBQUFBLFVBQzlDLHVCQUFDLE9BQUUsNkJBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0I7QUFBQSxVQUNmRSxTQUFTbUUsV0FBVyxLQUNuQix1QkFBQyxPQUFFLFdBQVUsV0FBVSx5Q0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0Q7QUFBQSxXQUVoRDdELG1CQUFtQkUsNEJBQTRCRSxtQkFDL0MsdUJBQUMsT0FBRSxXQUFVLFdBQVUsMENBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlEO0FBQUEsYUFQckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBLEtBYko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsV0FyTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVMQTtBQUFBLFNBN0xGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4TEE7QUFBQSxPQW5NRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb01BLEtBck1GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzTUE7QUFFSjtBQUFFYixHQXZYSUQsZUFBYTtBQUFBdUYsS0FBYnZGO0FBeVhOLGVBQWVBO0FBQWMsSUFBQXVGO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VNZW1vIiwidXNlU3RhdGUiLCJhcGkiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydCIsIklvTWRNb3JlIiwiQ2lyY3VsYXJMb2FkZXIiLCJOYXZiYXIiLCJmaWx0ZXJPcHRpb24iLCJEcm9wZG93biIsIlNlbGVjdCIsIlJvdyIsIkNvbCIsIkNhcmQiLCJVc2VyT3V0bGluZWQiLCJUZWFtT3V0bGluZWQiLCJBcHBzdG9yZU91dGxpbmVkIiwiRW52aXJvbm1lbnRPdXRsaW5lZCIsIlBpbmNvZGVSZXBvcnQiLCJfcyIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsImFsbFVzZXJzIiwic2V0QWxsVXNlcnMiLCJmaWx0ZXJlZFVzZXJzIiwic2V0RmlsdGVyZWRVc2VycyIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0Iiwic2VsZWN0ZWRQaW5jb2RlIiwic2V0U2VsZWN0ZWRQaW5jb2RlIiwic2VsZWN0ZWRSZWZlcnJlZEVtcGxveWVlIiwic2V0U2VsZWN0ZWRSZWZlcnJlZEVtcGxveWVlIiwic2VsZWN0ZWRVc2VySWQiLCJzZXRTZWxlY3RlZFVzZXJJZCIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsInR5cGUiLCJvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJwaW5jb2RlT3B0aW9ucyIsInVuaXF1ZVBpbmNvZGVzIiwiU2V0IiwibWFwIiwidXNlciIsInBpbmNvZGUiLCJmaWx0ZXIiLCJCb29sZWFuIiwibGFiZWwiLCJyZWZlcnJlZEVtcGxveWVlT3B0aW9ucyIsInVuaXF1ZUVtcGxveWVlcyIsInJlZmVycmVkX2VtcGxveWVlX25hbWUiLCJlbXBsb3llZSIsInVzZXJPcHRpb25zIiwidW5pcXVlVXNlcnMiLCJmdWxsX25hbWUiLCJmZXRjaEFsbFBpbmNvZGVEYXRhIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwic3VjY2VzcyIsImZvcm1hdHRlZERhdGEiLCJpbmRleCIsIl9pZCIsImlkIiwicGhvbmVfbnVtYmVyIiwiYWRkcmVzcyIsInJlZmVycmVkX2VtcGxveWVlIiwibmFtZSIsInJlZmVycmVkX2VtcGxveWVlX3Bob25lIiwicmVmZXJyZWRfZW1wbG95ZWVfaWQiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImhhbmRsZVVwZGF0ZU1vZGFsT3BlbiIsImhhbmRsZURlbGV0ZU1vZGFsT3BlbiIsImVycm9yIiwiY29uc29sZSIsImZpbHRlcmVkIiwiY2xlYXJBbGxGaWx0ZXJzIiwib3ZlcnZpZXciLCJ0b3RhbFVzZXJzIiwic2l6ZSIsInRvdGFsUGluY29kZXMiLCJ0b3RhbEVtcGxveWVlcyIsInRvdGFsVXNlcnNXaXRoQWRkcmVzcyIsImxlbmd0aCIsImNvbHVtbnMiLCJoZWFkZXIiLCJsb2ciLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidG9TdHJpbmciLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwidW5kZWZpbmVkIiwidGl0bGUiLCJjb2xvciIsImljb24iLCJpdGVtIiwicGFkZGluZyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlBpbmNvZGVSZXBvcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydCBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnRcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgeyBEcm9wZG93biwgU2VsZWN0LCBSb3csIENvbCwgQ2FyZCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7XHJcbiAgVXNlck91dGxpbmVkLFxyXG4gIFRlYW1PdXRsaW5lZCxcclxuICBBcHBzdG9yZU91dGxpbmVkLFxyXG4gIEVudmlyb25tZW50T3V0bGluZWQsXHJcbn0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcblxyXG5jb25zdCBQaW5jb2RlUmVwb3J0ID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FsbFVzZXJzLCBzZXRBbGxVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkVXNlcnMsIHNldEZpbHRlcmVkVXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIFxyXG4gIC8vIEZpbHRlciBzdGF0ZXNcclxuICBjb25zdCBbc2VsZWN0ZWRQaW5jb2RlLCBzZXRTZWxlY3RlZFBpbmNvZGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkUmVmZXJyZWRFbXBsb3llZSwgc2V0U2VsZWN0ZWRSZWZlcnJlZEVtcGxveWVlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFVzZXJJZCwgc2V0U2VsZWN0ZWRVc2VySWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgXHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuXHJcbiAgY29uc3Qgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgIHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpO1xyXG4gIH07XHJcblxyXG4gIC8vIEdldCB1bmlxdWUgb3B0aW9ucyBmcm9tIHRhYmxlIGRhdGFcclxuICBjb25zdCBwaW5jb2RlT3B0aW9ucyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgdW5pcXVlUGluY29kZXMgPSBbLi4ubmV3IFNldChhbGxVc2Vycy5tYXAoKHVzZXIpID0+IHVzZXIucGluY29kZSkpXS5maWx0ZXIoQm9vbGVhbik7XHJcbiAgICByZXR1cm4gdW5pcXVlUGluY29kZXMubWFwKHBpbmNvZGUgPT4gKHsgdmFsdWU6IHBpbmNvZGUsIGxhYmVsOiBwaW5jb2RlIH0pKTtcclxuICB9LCBbYWxsVXNlcnNdKTtcclxuXHJcbiAgY29uc3QgcmVmZXJyZWRFbXBsb3llZU9wdGlvbnMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IHVuaXF1ZUVtcGxveWVlcyA9IFsuLi5uZXcgU2V0KGFsbFVzZXJzLm1hcCgodXNlcikgPT4gdXNlci5yZWZlcnJlZF9lbXBsb3llZV9uYW1lKSldLmZpbHRlcihCb29sZWFuKTtcclxuICAgIHJldHVybiB1bmlxdWVFbXBsb3llZXMubWFwKGVtcGxveWVlID0+ICh7IHZhbHVlOiBlbXBsb3llZSwgbGFiZWw6IGVtcGxveWVlIH0pKTtcclxuICB9LCBbYWxsVXNlcnNdKTtcclxuXHJcbiAgY29uc3QgdXNlck9wdGlvbnMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IHVuaXF1ZVVzZXJzID0gWy4uLm5ldyBTZXQoYWxsVXNlcnMubWFwKCh1c2VyKSA9PiB1c2VyLmZ1bGxfbmFtZSkpXS5maWx0ZXIoQm9vbGVhbik7XHJcbiAgICByZXR1cm4gdW5pcXVlVXNlcnMubWFwKHVzZXIgPT4gKHsgdmFsdWU6IHVzZXIsIGxhYmVsOiB1c2VyIH0pKTtcclxuICB9LCBbYWxsVXNlcnNdKTtcclxuXHJcbiAgLy8gRmV0Y2ggYWxsIGRhdGEgb24gY29tcG9uZW50IG1vdW50XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQWxsUGluY29kZURhdGEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdjEvYWRtaW4vdXNlcnMvbGlzdC1waW5jb2RlXCIpO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEuc3VjY2Vzcykge1xyXG4gICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlLmRhdGEuZGF0YS5tYXAoKHVzZXIsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgICBfaWQ6IHVzZXIuX2lkLFxyXG4gICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICBmdWxsX25hbWU6IHVzZXIuZnVsbF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIHBob25lX251bWJlcjogdXNlci5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgYWRkcmVzczogdXNlci5hZGRyZXNzIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIHBpbmNvZGU6IHVzZXIucGluY29kZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICByZWZlcnJlZF9lbXBsb3llZV9uYW1lOiB1c2VyPy5yZWZlcnJlZF9lbXBsb3llZT8ubmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICByZWZlcnJlZF9lbXBsb3llZV9waG9uZTogdXNlcj8ucmVmZXJyZWRfZW1wbG95ZWU/LnBob25lX251bWJlciB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICByZWZlcnJlZF9lbXBsb3llZV9pZDogdXNlcj8ucmVmZXJyZWRfZW1wbG95ZWU/Ll9pZCB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgICAga2V5PXt1c2VyLl9pZH1cclxuICAgICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVXBkYXRlTW9kYWxPcGVuKHVzZXIuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBFZGl0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGVNb2RhbE9wZW4odXNlci5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPElvTWRNb3JlIC8+XHJcbiAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApLFxyXG4gICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgXHJcbiAgICAgICAgICBzZXRBbGxVc2Vycyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgICAgIHNldEZpbHRlcmVkVXNlcnMoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBwaW5jb2RlIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJFcnJvciBmZXRjaGluZyBwaW5jb2RlIGRhdGEuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaEFsbFBpbmNvZGVEYXRhKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICAvLyBBcHBseSBmaWx0ZXJzIHdoZW5ldmVyIGZpbHRlciBzZWxlY3Rpb25zIGNoYW5nZVxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBsZXQgZmlsdGVyZWQgPSBbLi4uYWxsVXNlcnNdO1xyXG5cclxuICAgIGlmIChzZWxlY3RlZFBpbmNvZGUpIHtcclxuICAgICAgZmlsdGVyZWQgPSBmaWx0ZXJlZC5maWx0ZXIodXNlciA9PiB1c2VyLnBpbmNvZGUgPT09IHNlbGVjdGVkUGluY29kZSk7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHNlbGVjdGVkUmVmZXJyZWRFbXBsb3llZSkge1xyXG4gICAgICBmaWx0ZXJlZCA9IGZpbHRlcmVkLmZpbHRlcih1c2VyID0+IHVzZXIucmVmZXJyZWRfZW1wbG95ZWVfbmFtZSA9PT0gc2VsZWN0ZWRSZWZlcnJlZEVtcGxveWVlKTtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoc2VsZWN0ZWRVc2VySWQpIHtcclxuICAgICAgZmlsdGVyZWQgPSBmaWx0ZXJlZC5maWx0ZXIodXNlciA9PiB1c2VyLmZ1bGxfbmFtZSA9PT0gc2VsZWN0ZWRVc2VySWQpO1xyXG4gICAgfVxyXG5cclxuICAgIHNldEZpbHRlcmVkVXNlcnMoZmlsdGVyZWQpO1xyXG4gIH0sIFthbGxVc2Vycywgc2VsZWN0ZWRQaW5jb2RlLCBzZWxlY3RlZFJlZmVycmVkRW1wbG95ZWUsIHNlbGVjdGVkVXNlcklkXSk7XHJcblxyXG4gIC8vIENsZWFyIGFsbCBmaWx0ZXJzXHJcbiAgY29uc3QgY2xlYXJBbGxGaWx0ZXJzID0gKCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRQaW5jb2RlKFwiXCIpO1xyXG4gICAgc2V0U2VsZWN0ZWRSZWZlcnJlZEVtcGxveWVlKFwiXCIpO1xyXG4gICAgc2V0U2VsZWN0ZWRVc2VySWQoXCJcIik7XHJcbiAgfTtcclxuXHJcbiAgLy8gT3ZlcnZpZXcgc3RhdGlzdGljc1xyXG4gIGNvbnN0IG92ZXJ2aWV3ID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCB1bmlxdWVVc2VycyA9IG5ldyBTZXQoZmlsdGVyZWRVc2Vycy5tYXAoKHVzZXIpID0+IHVzZXIuX2lkKSk7XHJcbiAgICBjb25zdCB1bmlxdWVQaW5jb2RlcyA9IG5ldyBTZXQoZmlsdGVyZWRVc2Vycy5tYXAoKHVzZXIpID0+IHVzZXIucGluY29kZSkpO1xyXG4gICAgY29uc3QgdW5pcXVlRW1wbG95ZWVzID0gbmV3IFNldChcclxuICAgICAgZmlsdGVyZWRVc2Vycy5tYXAoKHVzZXIpID0+IHVzZXIucmVmZXJyZWRfZW1wbG95ZWVfaWQpXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHRvdGFsVXNlcnM6IHVuaXF1ZVVzZXJzLnNpemUsXHJcbiAgICAgIHRvdGFsUGluY29kZXM6IHVuaXF1ZVBpbmNvZGVzLnNpemUsXHJcbiAgICAgIHRvdGFsRW1wbG95ZWVzOiB1bmlxdWVFbXBsb3llZXMuc2l6ZSxcclxuICAgICAgdG90YWxVc2Vyc1dpdGhBZGRyZXNzOiBmaWx0ZXJlZFVzZXJzLmZpbHRlcihcclxuICAgICAgICAodXNlcikgPT4gdXNlci5hZGRyZXNzICE9PSBcIk4vQVwiXHJcbiAgICAgICkubGVuZ3RoLFxyXG4gICAgfTtcclxuICB9LCBbZmlsdGVyZWRVc2Vyc10pO1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJmdWxsX25hbWVcIiwgaGVhZGVyOiBcIkZ1bGwgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJhZGRyZXNzXCIsIGhlYWRlcjogXCJBZGRyZXNzXCIgfSxcclxuICAgIHsga2V5OiBcInBpbmNvZGVcIiwgaGVhZGVyOiBcIlBpbmNvZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVmZXJyZWRfZW1wbG95ZWVfbmFtZVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgRW1wbG95ZWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVmZXJyZWRfZW1wbG95ZWVfcGhvbmVcIiwgaGVhZGVyOiBcIkVtcGxveWVlIFBob25lXCIgfSxcclxuICBdO1xyXG5cclxuICAvLyBQbGFjZWhvbGRlciBmdW5jdGlvbnMgZm9yIGVkaXQvZGVsZXRlXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxPcGVuID0gKGlkKSA9PiB7XHJcbiAgICBjb25zb2xlLmxvZyhcIkVkaXQgdXNlcjpcIiwgaWQpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZU1vZGFsT3BlbiA9IChpZCkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coXCJEZWxldGUgdXNlcjpcIiwgaWQpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBvdmVyZmxvdy14LWhpZGRlblwiPlxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG10LTMwXCI+XHJcbiAgICAgICAgICA8Q3VzdG9tQWxlcnRcclxuICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIHAtN1wiPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtMnhsXCI+UGluY29kZSBSZXBvcnQ8L2gxPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLThcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtZW5kIGdhcC02IHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICB7LyogUGluY29kZSBGaWx0ZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFBpbmNvZGVcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBQaW5jb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNjQgaC0xMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRQaW5jb2RlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXRTZWxlY3RlZFBpbmNvZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3BpbmNvZGVPcHRpb25zLm1hcCgob3B0aW9uKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17b3B0aW9uLnZhbHVlfSB2YWx1ZT17b3B0aW9uLnZhbHVlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7b3B0aW9uLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogUmVmZXJyZWQgRW1wbG95ZWUgRmlsdGVyICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBSZWZlcnJlZCBFbXBsb3llZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFJlZmVycmVkIEVtcGxveWVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNjQgaC0xMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRSZWZlcnJlZEVtcGxveWVlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXRTZWxlY3RlZFJlZmVycmVkRW1wbG95ZWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3JlZmVycmVkRW1wbG95ZWVPcHRpb25zLm1hcCgob3B0aW9uKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17b3B0aW9uLnZhbHVlfSB2YWx1ZT17b3B0aW9uLnZhbHVlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7b3B0aW9uLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogVXNlciBGaWx0ZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFVzZXJcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBVc2VyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNjQgaC0xMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRVc2VySWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFNlbGVjdGVkVXNlcklkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHt1c2VyT3B0aW9ucy5tYXAoKG9wdGlvbikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e29wdGlvbi52YWx1ZX0gdmFsdWU9e29wdGlvbi52YWx1ZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge29wdGlvbi5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIENsZWFyIEZpbHRlcnMgQnV0dG9uICovfVxyXG4gICAgICAgICAgICAgICAgICB7KHNlbGVjdGVkUGluY29kZSB8fCBzZWxlY3RlZFJlZmVycmVkRW1wbG95ZWUgfHwgc2VsZWN0ZWRVc2VySWQpICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17Y2xlYXJBbGxGaWx0ZXJzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTExIHB4LTYgYmctcmVkLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgaG92ZXI6YmctcmVkLTYwMCB0cmFuc2l0aW9uLWNvbG9ycyBmbGV4IGl0ZW1zLWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENsZWFyIEZpbHRlcnNcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIE92ZXJ2aWV3IENhcmRzICovfVxyXG4gICAgICAgICAgICA8Um93IGd1dHRlcj17WzIwLCAyMF19IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICB0aXRsZTogXCJUb3RhbCBVc2Vyc1wiLFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZTogb3ZlcnZpZXcudG90YWxVc2VycyxcclxuICAgICAgICAgICAgICAgICAgY29sb3I6IFwidGV4dC1ibHVlLTYwMFwiLFxyXG4gICAgICAgICAgICAgICAgICBpY29uOiA8VXNlck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtMnhsXCIgLz4sXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICB0aXRsZTogXCJVbmlxdWUgUGluY29kZXNcIixcclxuICAgICAgICAgICAgICAgICAgdmFsdWU6IG92ZXJ2aWV3LnRvdGFsUGluY29kZXMsXHJcbiAgICAgICAgICAgICAgICAgIGNvbG9yOiBcInRleHQtZ3JlZW4tNjAwXCIsXHJcbiAgICAgICAgICAgICAgICAgIGljb246IDxFbnZpcm9ubWVudE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtMnhsXCIgLz4sXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICB0aXRsZTogXCJSZWZlcnJlZCBFbXBsb3llZXNcIixcclxuICAgICAgICAgICAgICAgICAgdmFsdWU6IG92ZXJ2aWV3LnRvdGFsRW1wbG95ZWVzLFxyXG4gICAgICAgICAgICAgICAgICBjb2xvcjogXCJ0ZXh0LXB1cnBsZS02MDBcIixcclxuICAgICAgICAgICAgICAgICAgaWNvbjogPFRlYW1PdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bFwiIC8+LFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiVXNlcnMgd2l0aCBBZGRyZXNzXCIsXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlOiBvdmVydmlldy50b3RhbFVzZXJzV2l0aEFkZHJlc3MsXHJcbiAgICAgICAgICAgICAgICAgIGNvbG9yOiBcInRleHQtb3JhbmdlLTYwMFwiLFxyXG4gICAgICAgICAgICAgICAgICBpY29uOiA8QXBwc3RvcmVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bFwiIC8+LFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICBdLm1hcCgoaXRlbSwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgIDxDb2wga2V5PXtpbmRleH0geHM9ezI0fSBzbT17MTJ9IG1kPXs4fSBsZz17Nn0geGw9ezZ9PlxyXG4gICAgICAgICAgICAgICAgICA8Q2FyZFxyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlcmVkPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBzaGFkb3ctbGcgaG92ZXI6c2hhZG93LXhsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgYm9keVN0eWxlPXt7IHBhZGRpbmc6IDIwIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHRleHQtM3hsICR7aXRlbS5jb2xvcn1gfT57aXRlbS5pY29ufTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT17YHRleHQteGwgZm9udC1ib2xkIG10LTEgJHtpdGVtLmNvbG9yfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L1Jvdz5cclxuXHJcbiAgICAgICAgICAgIHsvKiBEYXRhIFRhYmxlICovfVxyXG4gICAgICAgICAgICB7ZmlsdGVyZWRVc2VycyAmJiBmaWx0ZXJlZFVzZXJzLmxlbmd0aCA+IDAgJiYgIWlzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBvdmVyZmxvdy14LWF1dG8gc2Nyb2xsYmFyLXRoaW5cIj5cclxuICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKGZpbHRlcmVkVXNlcnMsIHNlYXJjaFRleHQpfVxyXG4gICAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJQaW5jb2RlIFJlcG9ydFwiXHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJQaW5jb2RlX1JlcG9ydC5jc3ZcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggdy1mdWxsIGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBtaW4taC1bMjAwcHhdXCI+XHJcbiAgICAgICAgICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXtpc0xvYWRpbmd9IC8+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8RW52aXJvbm1lbnRPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBtYi0yXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8cD5ObyBkYXRhIGZvdW5kPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIHthbGxVc2Vycy5sZW5ndGggPT09IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbVwiPk5vIHBpbmNvZGUgZGF0YSBhdmFpbGFibGU8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICB7KHNlbGVjdGVkUGluY29kZSB8fCBzZWxlY3RlZFJlZmVycmVkRW1wbG95ZWUgfHwgc2VsZWN0ZWRVc2VySWQpICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc21cIj5UcnkgYWRqdXN0aW5nIHlvdXIgZmlsdGVyczwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUGluY29kZVJlcG9ydDsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvUGluY29kZVJlcG9ydC5qc3gifQ==