import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/employee/EmployeeTasks.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import API from "/src/instance/TokenInstance.js";
import { notification, Modal, Form, Input, Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { CheckCircle, ClipboardCheck, AlertCircle, UserPlus, RotateCcw, LayoutGrid, List, History } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
function EmployeeTasks() {
  _s();
  const [myTasks, setMyTasks] = useState([]);
  const [myReassignedHistory, setMyReassignedHistory] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [viewMode, setViewMode] = useState("list");
  const [filterStatus, setFilterStatus] = useState("is Pending");
  const [employees, setEmployees] = useState([]);
  const [isCompletionModalOpen, setIsCompletionModalOpen] = useState(false);
  const [isReassignModalOpen, setIsReassignModalOpen] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState(null);
  const [completionForm] = Form.useForm();
  const [reassignForm] = Form.useForm();
  const userStr = localStorage.getItem("user");
  const loggedInUser = userStr ? JSON.parse(userStr) : null;
  const myId = loggedInUser?._id;
  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const res = await API.get("/admin/get-sub-admins");
        setEmployees(res.data || []);
      } catch (error) {
        console.error("Error fetching employees:", error);
      }
    };
    fetchEmployees();
  }, []);
  useEffect(() => {
    if (!myId) return;
    const fetchMyTasks = async () => {
      try {
        setIsLoading(true);
        const res = await API.get("/complaints/all");
        const complaints = res.data?.data || res.data || [];
        const assignedToMe = complaints.filter((item) => {
          if (!item.assignedTo) return false;
          let assignedId = null;
          if (typeof item.assignedTo === "object" && item.assignedTo._id) {
            assignedId = item.assignedTo._id;
          } else if (typeof item.assignedTo === "string") {
            assignedId = item.assignedTo;
          }
          return String(assignedId) === String(myId);
        });
        const myReassignedHistory2 = complaints.filter((item) => {
          if (!item.reassignedBy) return false;
          let reassignedId = null;
          if (typeof item.reassignedBy === "object" && item.reassignedBy._id) {
            reassignedId = item.reassignedBy._id;
          } else if (typeof item.reassignedBy === "string") {
            reassignedId = item.reassignedBy;
          }
          return String(reassignedId) === String(myId);
        });
        setMyTasks(assignedToMe);
        setMyReassignedHistory(myReassignedHistory2);
      } catch (error) {
        console.error("Error fetching tasks:", error);
        notification.error({ message: "Error", description: "Failed to load tasks" });
      } finally {
        setIsLoading(false);
      }
    };
    fetchMyTasks();
  }, [myId]);
  const pendingCount = myTasks.filter((t) => t.status !== "Closed").length;
  const closedCount = myTasks.filter((t) => t.status === "Closed").length;
  const reassignCount = myReassignedHistory.length;
  let tasksToRender = [];
  if (filterStatus === "Reassigned") {
    tasksToRender = myReassignedHistory;
  } else {
    tasksToRender = myTasks.filter((task) => {
      if (filterStatus === null) return true;
      return task.status === filterStatus;
    });
  }
  const openCompletionModal = (task) => {
    setSelectedTaskId(task._id);
    setIsCompletionModalOpen(true);
  };
  const openReassignModal = (task) => {
    setSelectedTaskId(task._id);
    setIsReassignModalOpen(true);
  };
  const handleReassignSubmit = async (values) => {
    try {
      const selectedEmployee = employees.find((e) => e._id === values.assignedTo);
      const assignedToName = selectedEmployee ? selectedEmployee.name : "";
      const payload = {
        assignedTo: values.assignedTo,
        assignedToName,
        reassignmentNote: values.reassignmentNote,
        reassignedBy: myId,
        // Save who reassigned it
        status: "is Pending"
      };
      await API.put(`/complaints/update/${selectedTaskId}`, payload);
      notification.success({
        message: "Task Reassigned",
        description: `Task assigned to ${assignedToName}`
      });
      setMyTasks((prev) => prev.filter((t) => t._id !== selectedTaskId));
      setMyReassignedHistory((prev) => [...prev, { ...payload, _id: selectedTaskId, subject: myTasks.find((t) => t._id === selectedTaskId)?.subject, message: myTasks.find((t) => t._id === selectedTaskId)?.message }]);
      setIsReassignModalOpen(false);
      reassignForm.resetFields();
      setSelectedTaskId(null);
    } catch (error) {
      console.error(error);
      notification.error({ message: "Error", description: "Failed to reassign task" });
    }
  };
  const handleCompleteSubmit = async (values) => {
    try {
      const payload = {
        status: "Closed",
        resolutionNote: values.resolutionNote
      };
      await API.put(`/complaints/update/${selectedTaskId}`, payload);
      notification.success({ message: "Task Completed", description: "Ticket marked as Closed" });
      setMyTasks(
        (prev) => prev.map(
          (task) => task._id === selectedTaskId ? { ...task, status: "Closed", resolutionNote: values.resolutionNote } : task
        )
      );
      setIsCompletionModalOpen(false);
      completionForm.resetFields();
      setSelectedTaskId(null);
    } catch (error) {
      console.error(error);
      notification.error({ message: "Error", description: "Unable to update task status" });
    }
  };
  const containerClass = viewMode === "grid" ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" : "flex flex-col gap-3";
  return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen bg-gray-100 mt-20", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
      lineNumber: 200,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 flex flex-col mb-2", children: [
      /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
        lineNumber: 202,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("main", { className: "flex-1 pt-2 px-6 mb-5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold", children: "My Assigned Tasks" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
            lineNumber: 206,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex bg-white p-1 rounded-lg border border-gray-300 shadow-sm", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setViewMode("list"),
                className: `p-2 rounded-md ${viewMode === "list" ? "bg-violet-100 text-violet-600" : "text-gray-400 hover:bg-gray-100"}`,
                children: /* @__PURE__ */ jsxDEV(List, { size: 20 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                  lineNumber: 213,
                  columnNumber: 17
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                lineNumber: 209,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setViewMode("grid"),
                className: `p-2 rounded-md ${viewMode === "grid" ? "bg-violet-100 text-violet-600" : "text-gray-400 hover:bg-gray-100"}`,
                children: /* @__PURE__ */ jsxDEV(LayoutGrid, { size: 20 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                  lineNumber: 219,
                  columnNumber: 17
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                lineNumber: 215,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
            lineNumber: 208,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
          lineNumber: 205,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 mb-8", children: [
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              onClick: () => setFilterStatus((prev) => prev === "is Pending" ? null : "is Pending"),
              className: `relative overflow-hidden rounded-xl shadow-sm hover:shadow-md transition-all duration-300 cursor-pointer border-2 ${filterStatus === "is Pending" ? "border-yellow-500 ring-1 ring-yellow-500 bg-white" : "border-transparent bg-white"}`,
              children: /* @__PURE__ */ jsxDEV("div", { className: "p-6 bg-yellow-200 hover:bg-yellow-100 transition rounded-t-xl", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center justify-center w-12 h-12 bg-yellow-100 text-yellow-600 rounded-lg", children: /* @__PURE__ */ jsxDEV(AlertCircle, { size: 24 }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                    lineNumber: 236,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                    lineNumber: 235,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-gray-900", children: "Pending" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                      lineNumber: 239,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "In Progress" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                      lineNumber: 240,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                    lineNumber: 238,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                  lineNumber: 234,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-yellow-600", children: pendingCount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                  lineNumber: 244,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                  lineNumber: 243,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                lineNumber: 233,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                lineNumber: 232,
                columnNumber: 15
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
              lineNumber: 228,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              onClick: () => setFilterStatus((prev) => prev === "Closed" ? null : "Closed"),
              className: `relative overflow-hidden rounded-xl shadow-sm hover:shadow-md transition-all duration-300 cursor-pointer border-2 ${filterStatus === "Closed" ? "border-green-500 ring-1 ring-green-500 bg-white" : "border-transparent bg-white"}`,
              children: /* @__PURE__ */ jsxDEV("div", { className: "p-6 bg-green-200 hover:bg-green-100 transition rounded-t-xl", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center justify-center w-12 h-12 bg-green-100 text-green-600 rounded-lg", children: /* @__PURE__ */ jsxDEV(ClipboardCheck, { size: 24 }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                    lineNumber: 259,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                    lineNumber: 258,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-gray-900", children: "Closed" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                      lineNumber: 262,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Completed Tasks" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                      lineNumber: 263,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                    lineNumber: 261,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                  lineNumber: 257,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-green-600", children: closedCount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                  lineNumber: 267,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                  lineNumber: 266,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                lineNumber: 256,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                lineNumber: 255,
                columnNumber: 15
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
              lineNumber: 251,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              onClick: () => setFilterStatus((prev) => prev === "Reassigned" ? null : "Reassigned"),
              className: `relative overflow-hidden rounded-xl shadow-sm hover:shadow-md transition-all duration-300 cursor-pointer border-2 ${filterStatus === "Reassigned" ? "border-purple-500 ring-1 ring-purple-500 bg-white" : "border-transparent bg-white"}`,
              children: /* @__PURE__ */ jsxDEV("div", { className: "p-6 bg-purple-200 hover:bg-purple-100 transition rounded-t-xl", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center justify-center w-12 h-12 bg-purple-100 text-purple-600 rounded-lg", children: /* @__PURE__ */ jsxDEV(History, { size: 24 }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                    lineNumber: 282,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                    lineNumber: 281,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-gray-900", children: "Reassigned" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                      lineNumber: 285,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "By Me (History)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                      lineNumber: 286,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                    lineNumber: 284,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                  lineNumber: 280,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-purple-600", children: reassignCount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                  lineNumber: 290,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                  lineNumber: 289,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                lineNumber: 279,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                lineNumber: 278,
                columnNumber: 15
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
              lineNumber: 274,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
          lineNumber: 225,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: !isLoading && tasksToRender.length === 0,
            data: filterStatus === "Reassigned" ? "History" : "Tasks"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
            lineNumber: 299,
            columnNumber: 11
          },
          this
        ),
        !isLoading && tasksToRender.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: containerClass, children: tasksToRender.map(
          (task) => /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "bg-white p-4 rounded-lg shadow border border-gray-200 flex flex-col justify-between hover:shadow-md transition h-full",
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row justify-between items-start gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: /* @__PURE__ */ jsxDEV("span", { className: `inline-block px-2 py-0.5 text-[10px] font-bold rounded text-white ${task.status === "Closed" ? "bg-green-600" : "bg-yellow-500"}`, children: task.status }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                      lineNumber: 319,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                      lineNumber: 318,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "text-xs", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-500", children: "Subject:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                          lineNumber: 328,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 ml-1 break-words", children: task.subject }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                          lineNumber: 329,
                          columnNumber: 27
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                        lineNumber: 327,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "text-xs", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-500", children: "Description:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                          lineNumber: 332,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 ml-1 break-words line-clamp-3", children: task.message }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                          lineNumber: 333,
                          columnNumber: 27
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                        lineNumber: 331,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                      lineNumber: 326,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                    lineNumber: 316,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "md:w-auto w-full flex flex-col items-center gap-2 flex-shrink-0 mt-2", children: task.status !== "Closed" ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        onClick: () => openCompletionModal(task),
                        className: "flex items-center justify-center gap-1 px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white text-xs rounded shadow-sm transition",
                        children: [
                          /* @__PURE__ */ jsxDEV(CheckCircle, { size: 12 }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                            lineNumber: 346,
                            columnNumber: 29
                          }, this),
                          " Mark completed"
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                        lineNumber: 342,
                        columnNumber: 27
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        onClick: () => openReassignModal(task),
                        className: "flex items-center justify-center gap-1 px-3 py-1.5 bg-orange-500 hover:bg-orange-600 text-white text-xs rounded shadow-sm transition",
                        children: [
                          /* @__PURE__ */ jsxDEV(UserPlus, { size: 12 }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                            lineNumber: 352,
                            columnNumber: 29
                          }, this),
                          " Re-assign"
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                        lineNumber: 348,
                        columnNumber: 27
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                    lineNumber: 341,
                    columnNumber: 19
                  }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-1 px-3 py-1.5 bg-green-50 text-green-600 text-xs font-medium rounded", children: [
                    /* @__PURE__ */ jsxDEV(CheckCircle, { size: 12 }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                      lineNumber: 357,
                      columnNumber: 27
                    }, this),
                    " Closed"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                    lineNumber: 356,
                    columnNumber: 19
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                    lineNumber: 339,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                  lineNumber: 313,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-3 space-y-2", children: [
                  task.reassignmentNote && /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-yellow-50 rounded border border-yellow-200 text-[10px]", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "font-bold text-yellow-800 mb-0.5 flex items-center gap-1", children: [
                      /* @__PURE__ */ jsxDEV(RotateCcw, { size: 10 }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                        lineNumber: 368,
                        columnNumber: 27
                      }, this),
                      " Reassigned Note:"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                      lineNumber: 367,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-gray-800", children: task.reassignmentNote }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                      lineNumber: 370,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                    lineNumber: 366,
                    columnNumber: 17
                  }, this),
                  task.status === "Closed" && task.resolutionNote && /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-green-50 rounded border border-green-200 text-[10px]", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "font-bold text-green-800 mb-0.5 flex items-center gap-1", children: [
                      /* @__PURE__ */ jsxDEV(CheckCircle, { size: 10 }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                        lineNumber: 376,
                        columnNumber: 27
                      }, this),
                      " Resolved:"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                      lineNumber: 375,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-gray-800", children: task.resolutionNote }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                      lineNumber: 378,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                    lineNumber: 374,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
                  lineNumber: 364,
                  columnNumber: 19
                }, this)
              ]
            },
            task._id,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
              lineNumber: 308,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
          lineNumber: 306,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
        lineNumber: 204,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
      lineNumber: 201,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: "Complete Task",
        open: isCompletionModalOpen,
        onCancel: () => {
          setIsCompletionModalOpen(false);
          completionForm.resetFields();
        },
        footer: null,
        children: /* @__PURE__ */ jsxDEV(Form, { form: completionForm, layout: "vertical", onFinish: handleCompleteSubmit, children: [
          /* @__PURE__ */ jsxDEV(Form.Item, { label: "Resolution Note", name: "resolutionNote", rules: [{ required: true, message: "Please add a note!" }], children: /* @__PURE__ */ jsxDEV(Input.TextArea, { rows: 4, placeholder: "Describe how you resolved this issue..." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
            lineNumber: 398,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
            lineNumber: 397,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-2 mt-4", children: [
            /* @__PURE__ */ jsxDEV("button", { onClick: () => setIsCompletionModalOpen(false), className: "px-4 py-2 border rounded hover:bg-gray-100", children: "Cancel" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
              lineNumber: 401,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "px-4 py-2 bg-violet-600 text-white rounded hover:bg-violet-700", children: "Submit" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
              lineNumber: 402,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
            lineNumber: 400,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
          lineNumber: 396,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
        lineNumber: 390,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: "Reassign Task",
        open: isReassignModalOpen,
        onCancel: () => {
          setIsReassignModalOpen(false);
          reassignForm.resetFields();
        },
        footer: null,
        children: /* @__PURE__ */ jsxDEV(Form, { form: reassignForm, layout: "vertical", onFinish: handleReassignSubmit, children: [
          /* @__PURE__ */ jsxDEV(Form.Item, { label: "Assign To", name: "assignedTo", rules: [{ required: true, message: "Please select an employee!" }], children: /* @__PURE__ */ jsxDEV(
            Select,
            {
              showSearch: true,
              placeholder: "Search employee...",
              filterOption: (input, option) => (option?.label ?? "").toLowerCase().includes(input.toLowerCase()),
              options: employees.map((emp) => ({ value: emp._id, label: emp.name }))
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
              lineNumber: 416,
              columnNumber: 13
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
            lineNumber: 415,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(Form.Item, { label: "Reason for Reassignment", name: "reassignmentNote", rules: [{ required: true, message: "Please explain why!" }], children: /* @__PURE__ */ jsxDEV(Input.TextArea, { rows: 4, placeholder: "Why are you reassigning this task?" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
            lineNumber: 424,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
            lineNumber: 423,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-2 mt-4", children: [
            /* @__PURE__ */ jsxDEV("button", { onClick: () => setIsReassignModalOpen(false), className: "px-4 py-2 border rounded hover:bg-gray-100", children: "Cancel" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
              lineNumber: 427,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "px-4 py-2 bg-orange-600 text-white rounded hover:bg-orange-700", children: "Reassign" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
              lineNumber: 428,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
            lineNumber: 426,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
          lineNumber: 414,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
        lineNumber: 408,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx",
    lineNumber: 199,
    columnNumber: 5
  }, this);
}
_s(EmployeeTasks, "FwNe6u+FqWpy7SgKqplAxWY9EHU=", false, function() {
  return [Form.useForm, Form.useForm];
});
_c = EmployeeTasks;
export default EmployeeTasks;
var _c;
$RefreshReg$(_c, "EmployeeTasks");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/employee/EmployeeTasks.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdU1NLFNBNklrQixVQTdJbEI7MkJBdk1OO0FBQW9CQSxvQkFBZ0IsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzQyxPQUFPQyxTQUFTO0FBQ2hCLFNBQVNDLGNBQWNDLE9BQU9DLE1BQU1DLE9BQU9DLGNBQWM7QUFDekQsU0FBU0MsYUFBYUMsZ0JBQWdCQyxhQUFhQyxVQUFVQyxXQUFXQyxZQUFZQyxNQUFNQyxlQUFlO0FBQ3pHLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxvQkFBb0I7QUFFM0IsU0FBU0MsZ0JBQWdCO0FBQUFDLEtBQUE7QUFDdkIsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUlyQixTQUFTLEVBQUU7QUFFekMsUUFBTSxDQUFDc0IscUJBQXFCQyxzQkFBc0IsSUFBSXZCLFNBQVMsRUFBRTtBQUVqRSxRQUFNLENBQUN3QixXQUFXQyxZQUFZLElBQUl6QixTQUFTLElBQUk7QUFDL0MsUUFBTSxDQUFDMEIsVUFBVUMsV0FBVyxJQUFJM0IsU0FBUyxNQUFNO0FBRy9DLFFBQU0sQ0FBQzRCLGNBQWNDLGVBQWUsSUFBSTdCLFNBQVMsWUFBWTtBQUc3RCxRQUFNLENBQUM4QixXQUFXQyxZQUFZLElBQUkvQixTQUFTLEVBQUU7QUFHN0MsUUFBTSxDQUFDZ0MsdUJBQXVCQyx3QkFBd0IsSUFBSWpDLFNBQVMsS0FBSztBQUN4RSxRQUFNLENBQUNrQyxxQkFBcUJDLHNCQUFzQixJQUFJbkMsU0FBUyxLQUFLO0FBQ3BFLFFBQU0sQ0FBQ29DLGdCQUFnQkMsaUJBQWlCLElBQUlyQyxTQUFTLElBQUk7QUFFekQsUUFBTSxDQUFDc0MsY0FBYyxJQUFJbEMsS0FBS21DLFFBQVE7QUFDdEMsUUFBTSxDQUFDQyxZQUFZLElBQUlwQyxLQUFLbUMsUUFBUTtBQUdwQyxRQUFNRSxVQUFVQyxhQUFhQyxRQUFRLE1BQU07QUFDM0MsUUFBTUMsZUFBZUgsVUFBVUksS0FBS0MsTUFBTUwsT0FBTyxJQUFJO0FBQ3JELFFBQU1NLE9BQU9ILGNBQWNJO0FBRzNCQyxZQUFVLE1BQU07QUFDZCxVQUFNQyxpQkFBaUIsWUFBWTtBQUNqQyxVQUFJO0FBQ0YsY0FBTUMsTUFBTSxNQUFNbEQsSUFBSW1ELElBQUksdUJBQXVCO0FBQ2pEckIscUJBQWFvQixJQUFJRSxRQUFRLEVBQUU7QUFBQSxNQUM3QixTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUFBLE1BQ2xEO0FBQUEsSUFDRjtBQUNBSixtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsRUFBRTtBQUVMRCxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUNGLEtBQU07QUFFWCxVQUFNUyxlQUFlLFlBQVk7QUFDL0IsVUFBSTtBQUNGL0IscUJBQWEsSUFBSTtBQUNqQixjQUFNMEIsTUFBTSxNQUFNbEQsSUFBSW1ELElBQUksaUJBQWlCO0FBQzNDLGNBQU1LLGFBQWFOLElBQUlFLE1BQU1BLFFBQVFGLElBQUlFLFFBQVE7QUFHakQsY0FBTUssZUFBZUQsV0FBV0UsT0FBTyxDQUFDQyxTQUFTO0FBQy9DLGNBQUksQ0FBQ0EsS0FBS0MsV0FBWSxRQUFPO0FBQzdCLGNBQUlDLGFBQWE7QUFDakIsY0FBSSxPQUFPRixLQUFLQyxlQUFlLFlBQVlELEtBQUtDLFdBQVdiLEtBQUs7QUFDOURjLHlCQUFhRixLQUFLQyxXQUFXYjtBQUFBQSxVQUMvQixXQUFXLE9BQU9ZLEtBQUtDLGVBQWUsVUFBVTtBQUM5Q0MseUJBQWFGLEtBQUtDO0FBQUFBLFVBQ3BCO0FBQ0EsaUJBQU9FLE9BQU9ELFVBQVUsTUFBTUMsT0FBT2hCLElBQUk7QUFBQSxRQUMzQyxDQUFDO0FBR0QsY0FBTXpCLHVCQUFzQm1DLFdBQVdFLE9BQU8sQ0FBQ0MsU0FBUztBQUNwRCxjQUFJLENBQUNBLEtBQUtJLGFBQWMsUUFBTztBQUMvQixjQUFJQyxlQUFlO0FBQ25CLGNBQUksT0FBT0wsS0FBS0ksaUJBQWlCLFlBQVlKLEtBQUtJLGFBQWFoQixLQUFLO0FBQ2hFaUIsMkJBQWVMLEtBQUtJLGFBQWFoQjtBQUFBQSxVQUNyQyxXQUFXLE9BQU9ZLEtBQUtJLGlCQUFpQixVQUFVO0FBQzlDQywyQkFBZUwsS0FBS0k7QUFBQUEsVUFDeEI7QUFDQSxpQkFBT0QsT0FBT0UsWUFBWSxNQUFNRixPQUFPaEIsSUFBSTtBQUFBLFFBQy9DLENBQUM7QUFFRDFCLG1CQUFXcUMsWUFBWTtBQUN2Qm5DLCtCQUF1QkQsb0JBQW1CO0FBQUEsTUFFNUMsU0FBU2dDLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0seUJBQXlCQSxLQUFLO0FBQzVDcEQscUJBQWFvRCxNQUFNLEVBQUVZLFNBQVMsU0FBU0MsYUFBYSx1QkFBdUIsQ0FBQztBQUFBLE1BQzlFLFVBQUM7QUFDQzFDLHFCQUFhLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFFQStCLGlCQUFhO0FBQUEsRUFDZixHQUFHLENBQUNULElBQUksQ0FBQztBQUdULFFBQU1xQixlQUFlaEQsUUFBUXVDLE9BQU8sQ0FBQVUsTUFBS0EsRUFBRUMsV0FBVyxRQUFRLEVBQUVDO0FBQ2hFLFFBQU1DLGNBQWNwRCxRQUFRdUMsT0FBTyxDQUFBVSxNQUFLQSxFQUFFQyxXQUFXLFFBQVEsRUFBRUM7QUFDL0QsUUFBTUUsZ0JBQWdCbkQsb0JBQW9CaUQ7QUFJMUMsTUFBSUcsZ0JBQWdCO0FBRXBCLE1BQUk5QyxpQkFBaUIsY0FBYztBQUVqQzhDLG9CQUFnQnBEO0FBQUFBLEVBQ2xCLE9BQU87QUFFTG9ELG9CQUFnQnRELFFBQVF1QyxPQUFPLENBQUFnQixTQUFRO0FBQ3JDLFVBQUkvQyxpQkFBaUIsS0FBTSxRQUFPO0FBQ2xDLGFBQU8rQyxLQUFLTCxXQUFXMUM7QUFBQUEsSUFDekIsQ0FBQztBQUFBLEVBQ0g7QUFHQSxRQUFNZ0Qsc0JBQXNCQSxDQUFDRCxTQUFTO0FBQ3BDdEMsc0JBQWtCc0MsS0FBSzNCLEdBQUc7QUFDMUJmLDZCQUF5QixJQUFJO0FBQUEsRUFDL0I7QUFFQSxRQUFNNEMsb0JBQW9CQSxDQUFDRixTQUFTO0FBQ2xDdEMsc0JBQWtCc0MsS0FBSzNCLEdBQUc7QUFDMUJiLDJCQUF1QixJQUFJO0FBQUEsRUFDN0I7QUFHQSxRQUFNMkMsdUJBQXVCLE9BQU9DLFdBQVc7QUFDN0MsUUFBSTtBQUNGLFlBQU1DLG1CQUFtQmxELFVBQVVtRCxLQUFLLENBQUFDLE1BQUtBLEVBQUVsQyxRQUFRK0IsT0FBT2xCLFVBQVU7QUFDeEUsWUFBTXNCLGlCQUFpQkgsbUJBQW1CQSxpQkFBaUJJLE9BQU87QUFFbEUsWUFBTUMsVUFBVTtBQUFBLFFBQ2R4QixZQUFZa0IsT0FBT2xCO0FBQUFBLFFBQ25Cc0I7QUFBQUEsUUFDQUcsa0JBQWtCUCxPQUFPTztBQUFBQSxRQUN6QnRCLGNBQWNqQjtBQUFBQTtBQUFBQSxRQUNkdUIsUUFBUTtBQUFBLE1BQ1Y7QUFFQSxZQUFNckUsSUFBSXNGLElBQUksc0JBQXNCbkQsY0FBYyxJQUFJaUQsT0FBTztBQUU3RG5GLG1CQUFhc0YsUUFBUTtBQUFBLFFBQ25CdEIsU0FBUztBQUFBLFFBQ1RDLGFBQWEsb0JBQW9CZ0IsY0FBYztBQUFBLE1BQ2pELENBQUM7QUFHRDlELGlCQUFXLENBQUNvRSxTQUFTQSxLQUFLOUIsT0FBTyxDQUFBVSxNQUFLQSxFQUFFckIsUUFBUVosY0FBYyxDQUFDO0FBRy9EYiw2QkFBdUIsQ0FBQ2tFLFNBQVMsQ0FBQyxHQUFHQSxNQUFNLEVBQUUsR0FBR0osU0FBU3JDLEtBQUtaLGdCQUFnQnNELFNBQVN0RSxRQUFRNkQsS0FBSyxDQUFBWixNQUFHQSxFQUFFckIsUUFBTVosY0FBYyxHQUFHc0QsU0FBU3hCLFNBQVM5QyxRQUFRNkQsS0FBSyxDQUFBWixNQUFHQSxFQUFFckIsUUFBTVosY0FBYyxHQUFHOEIsUUFBUSxDQUFDLENBQUM7QUFFck0vQiw2QkFBdUIsS0FBSztBQUM1QkssbUJBQWFtRCxZQUFZO0FBQ3pCdEQsd0JBQWtCLElBQUk7QUFBQSxJQUV4QixTQUFTaUIsT0FBTztBQUNkQyxjQUFRRCxNQUFNQSxLQUFLO0FBQ25CcEQsbUJBQWFvRCxNQUFNLEVBQUVZLFNBQVMsU0FBU0MsYUFBYSwwQkFBMEIsQ0FBQztBQUFBLElBQ2pGO0FBQUEsRUFDRjtBQUdBLFFBQU15Qix1QkFBdUIsT0FBT2IsV0FBVztBQUM3QyxRQUFJO0FBQ0YsWUFBTU0sVUFBVTtBQUFBLFFBQ2RmLFFBQVE7QUFBQSxRQUNSdUIsZ0JBQWdCZCxPQUFPYztBQUFBQSxNQUN6QjtBQUVBLFlBQU01RixJQUFJc0YsSUFBSSxzQkFBc0JuRCxjQUFjLElBQUlpRCxPQUFPO0FBRTdEbkYsbUJBQWFzRixRQUFRLEVBQUV0QixTQUFTLGtCQUFrQkMsYUFBYSwwQkFBMEIsQ0FBQztBQUUxRjlDO0FBQUFBLFFBQVcsQ0FBQ29FLFNBQ1ZBLEtBQUtLO0FBQUFBLFVBQUksQ0FBQ25CLFNBQ1JBLEtBQUszQixRQUFRWixpQkFDVCxFQUFFLEdBQUd1QyxNQUFNTCxRQUFRLFVBQVV1QixnQkFBZ0JkLE9BQU9jLGVBQWUsSUFDbkVsQjtBQUFBQSxRQUNOO0FBQUEsTUFDRjtBQUVBMUMsK0JBQXlCLEtBQUs7QUFDOUJLLHFCQUFlcUQsWUFBWTtBQUMzQnRELHdCQUFrQixJQUFJO0FBQUEsSUFFeEIsU0FBU2lCLE9BQU87QUFDZEMsY0FBUUQsTUFBTUEsS0FBSztBQUNuQnBELG1CQUFhb0QsTUFBTSxFQUFFWSxTQUFTLFNBQVNDLGFBQWEsK0JBQStCLENBQUM7QUFBQSxJQUN0RjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNEIsaUJBQWlCckUsYUFBYSxTQUNoQyx5REFDQTtBQUVKLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsMkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVE7QUFBQSxJQUNSLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLDZCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFPO0FBQUEsTUFFUCx1QkFBQyxVQUFLLFdBQVUseUJBQ2Q7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsc0JBQXFCLGlDQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRDtBQUFBLFVBRXBELHVCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNQyxZQUFZLE1BQU07QUFBQSxnQkFDakMsV0FBVyxrQkFBa0JELGFBQWEsU0FBUyxrQ0FBa0MsaUNBQWlDO0FBQUEsZ0JBRXRILGlDQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWU7QUFBQTtBQUFBLGNBSmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTUMsWUFBWSxNQUFNO0FBQUEsZ0JBQ2pDLFdBQVcsa0JBQWtCRCxhQUFhLFNBQVMsa0NBQWtDLGlDQUFpQztBQUFBLGdCQUV0SCxpQ0FBQyxjQUFXLE1BQU0sTUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUI7QUFBQTtBQUFBLGNBSnZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsYUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLDhDQUdiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTUcsZ0JBQWdCLENBQUE0RCxTQUFRQSxTQUFTLGVBQWUsT0FBTyxZQUFZO0FBQUEsY0FDbEYsV0FBVyxxSEFBcUg3RCxpQkFBaUIsZUFBZSxzREFBc0QsNkJBQTZCO0FBQUEsY0FFblAsaUNBQUMsU0FBSSxXQUFVLGlFQUNiLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSw4RkFDYixpQ0FBQyxlQUFZLE1BQU0sTUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0IsS0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFNBQ0M7QUFBQSwyQ0FBQyxRQUFHLFdBQVUsbUNBQWtDLHVCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF1RDtBQUFBLG9CQUN2RCx1QkFBQyxPQUFFLFdBQVUseUJBQXdCLDJCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnRDtBQUFBLHVCQUZsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEscUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFRQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiLGlDQUFDLE9BQUUsV0FBVSxzQ0FBc0N3QywwQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0UsS0FEbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBYUEsS0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWVBO0FBQUE7QUFBQSxZQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFvQkE7QUFBQSxVQUdBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU12QyxnQkFBZ0IsQ0FBQTRELFNBQVFBLFNBQVMsV0FBVyxPQUFPLFFBQVE7QUFBQSxjQUMxRSxXQUFXLHFIQUFxSDdELGlCQUFpQixXQUFXLG9EQUFvRCw2QkFBNkI7QUFBQSxjQUU3TyxpQ0FBQyxTQUFJLFdBQVUsK0RBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLDRGQUNiLGlDQUFDLGtCQUFlLE1BQU0sTUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUIsS0FEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFNBQ0M7QUFBQSwyQ0FBQyxRQUFHLFdBQVUsbUNBQWtDLHNCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFzRDtBQUFBLG9CQUN0RCx1QkFBQyxPQUFFLFdBQVUseUJBQXdCLCtCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFvRDtBQUFBLHVCQUZ0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEscUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFRQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiLGlDQUFDLE9BQUUsV0FBVSxxQ0FBcUM0Qyx5QkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEQsS0FEaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBYUEsS0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWVBO0FBQUE7QUFBQSxZQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFvQkE7QUFBQSxVQUdBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU0zQyxnQkFBZ0IsQ0FBQTRELFNBQVFBLFNBQVMsZUFBZSxPQUFPLFlBQVk7QUFBQSxjQUNsRixXQUFXLHFIQUFxSDdELGlCQUFpQixlQUFlLHNEQUFzRCw2QkFBNkI7QUFBQSxjQUVuUCxpQ0FBQyxTQUFJLFdBQVUsaUVBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLDhGQUNiLGlDQUFDLFdBQVEsTUFBTSxNQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtCLEtBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxTQUNDO0FBQUEsMkNBQUMsUUFBRyxXQUFVLG1DQUFrQywwQkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMEQ7QUFBQSxvQkFDMUQsdUJBQUMsT0FBRSxXQUFVLHlCQUF3QiwrQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0Q7QUFBQSx1QkFGdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLHFCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUUE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYixpQ0FBQyxPQUFFLFdBQVUsc0NBQXNDNkMsMkJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlFLEtBRG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBLEtBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBO0FBQUEsWUFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBb0JBO0FBQUEsYUFyRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVFQTtBQUFBLFFBR0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxTQUFTLENBQUNqRCxhQUFha0QsY0FBY0gsV0FBVztBQUFBLFlBQ2hELE1BQU0zQyxpQkFBaUIsZUFBZSxZQUFZO0FBQUE7QUFBQSxVQUhwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHNEQ7QUFBQSxRQUczRCxDQUFDSixhQUFha0QsY0FBY0gsU0FBUyxLQUNwQyx1QkFBQyxTQUFJLFdBQVd3QixnQkFDYnJCLHdCQUFjb0I7QUFBQUEsVUFBSSxDQUFDbkIsU0FDbEI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLFdBQVU7QUFBQSxjQUdWO0FBQUEsdUNBQUMsU0FBSSxXQUFVLCtEQUdiO0FBQUEseUNBQUMsU0FBSSxXQUFVLGtCQUViO0FBQUEsMkNBQUMsU0FBSSxXQUFVLFFBQ2IsaUNBQUMsVUFBSyxXQUFXLHFFQUFxRUEsS0FBS0wsV0FBVyxXQUFXLGlCQUFpQixlQUFlLElBRTlJSyxlQUFLTCxVQUZSO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsb0JBR0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSw2Q0FBQyxTQUFJLFdBQVUsV0FDYjtBQUFBLCtDQUFDLFVBQUssV0FBVSwrQkFBOEIsd0JBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXNEO0FBQUEsd0JBQ3RELHVCQUFDLFVBQUssV0FBVSxrQ0FBa0NLLGVBQUtlLFdBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQStEO0FBQUEsMkJBRmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBR0E7QUFBQSxzQkFDQSx1QkFBQyxTQUFJLFdBQVUsV0FDYjtBQUFBLCtDQUFDLFVBQUssV0FBVSwrQkFBOEIsNEJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTBEO0FBQUEsd0JBQzFELHVCQUFDLFVBQUssV0FBVSwrQ0FBK0NmLGVBQUtULFdBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTRFO0FBQUEsMkJBRjlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBR0E7QUFBQSx5QkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVNBO0FBQUEsdUJBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBb0JBO0FBQUEsa0JBR0EsdUJBQUMsU0FBSSxXQUFVLHdFQUNaUyxlQUFLTCxXQUFXLFdBQ2YsbUNBQ0U7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxTQUFTLE1BQU1NLG9CQUFvQkQsSUFBSTtBQUFBLHdCQUN2QyxXQUFVO0FBQUEsd0JBRVY7QUFBQSxpREFBQyxlQUFZLE1BQU0sTUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBc0I7QUFBQSwwQkFBRztBQUFBO0FBQUE7QUFBQSxzQkFKM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsU0FBUyxNQUFNRSxrQkFBa0JGLElBQUk7QUFBQSx3QkFDckMsV0FBVTtBQUFBLHdCQUVWO0FBQUEsaURBQUMsWUFBUyxNQUFNLE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQW1CO0FBQUEsMEJBQUc7QUFBQTtBQUFBO0FBQUEsc0JBSnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLHVCQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBYUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsNkdBQ2I7QUFBQSwyQ0FBQyxlQUFZLE1BQU0sTUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBc0I7QUFBQSxvQkFBRztBQUFBLHVCQUQzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBLEtBbkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBcUJBO0FBQUEscUJBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZ0RBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNaQTtBQUFBQSx1QkFBS1csb0JBQ0osdUJBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEsMkNBQUMsT0FBRSxXQUFVLDREQUNYO0FBQUEsNkNBQUMsYUFBVSxNQUFNLE1BQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQW9CO0FBQUEsc0JBQUc7QUFBQSx5QkFEekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLE9BQUUsV0FBVSxpQkFBaUJYLGVBQUtXLG9CQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFvRDtBQUFBLHVCQUp0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEsa0JBRURYLEtBQUtMLFdBQVcsWUFBWUssS0FBS2tCLGtCQUNoQyx1QkFBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQSwyQ0FBQyxPQUFFLFdBQVUsMkRBQ1g7QUFBQSw2Q0FBQyxlQUFZLE1BQU0sTUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBc0I7QUFBQSxzQkFBRztBQUFBLHlCQUQzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsT0FBRSxXQUFVLGlCQUFpQmxCLGVBQUtrQixrQkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBa0Q7QUFBQSx1QkFKcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLHFCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaUJBO0FBQUE7QUFBQTtBQUFBLFlBeEVLbEIsS0FBSzNCO0FBQUFBLFlBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQTBFQTtBQUFBLFFBQ0QsS0E3RUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThFQTtBQUFBLFdBcExKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzTEE7QUFBQSxTQXpMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMExBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTTtBQUFBLFFBQ04sTUFBTWhCO0FBQUFBLFFBQ04sVUFBVSxNQUFNO0FBQUVDLG1DQUF5QixLQUFLO0FBQUdLLHlCQUFlcUQsWUFBWTtBQUFBLFFBQUc7QUFBQSxRQUNqRixRQUFRO0FBQUEsUUFFUixpQ0FBQyxRQUFLLE1BQU1yRCxnQkFBZ0IsUUFBTyxZQUFXLFVBQVVzRCxzQkFDdEQ7QUFBQSxpQ0FBQyxLQUFLLE1BQUwsRUFBVSxPQUFNLG1CQUFrQixNQUFLLGtCQUFpQixPQUFPLENBQUMsRUFBRUksVUFBVSxNQUFNOUIsU0FBUyxxQkFBcUIsQ0FBQyxHQUNoSCxpQ0FBQyxNQUFNLFVBQU4sRUFBZSxNQUFNLEdBQUcsYUFBWSw2Q0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEUsS0FEaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsbUNBQUMsWUFBTyxTQUFTLE1BQU1qQyx5QkFBeUIsS0FBSyxHQUFHLFdBQVUsOENBQTZDLHNCQUEvRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxSDtBQUFBLFlBQ3JILHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsa0VBQWlFLHNCQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RztBQUFBLGVBRnpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBO0FBQUEsTUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFlQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLE1BQU1DO0FBQUFBLFFBQ04sVUFBVSxNQUFNO0FBQUVDLGlDQUF1QixLQUFLO0FBQUdLLHVCQUFhbUQsWUFBWTtBQUFBLFFBQUc7QUFBQSxRQUM3RSxRQUFRO0FBQUEsUUFFUixpQ0FBQyxRQUFLLE1BQU1uRCxjQUFjLFFBQU8sWUFBVyxVQUFVc0Msc0JBQ3BEO0FBQUEsaUNBQUMsS0FBSyxNQUFMLEVBQVUsT0FBTSxhQUFZLE1BQUssY0FBYSxPQUFPLENBQUMsRUFBRWtCLFVBQVUsTUFBTTlCLFNBQVMsNkJBQTZCLENBQUMsR0FDOUc7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDO0FBQUEsY0FDQSxhQUFZO0FBQUEsY0FDWixjQUFjLENBQUMrQixPQUFPQyxZQUFZQSxRQUFRQyxTQUFTLElBQUlDLFlBQVksRUFBRUMsU0FBU0osTUFBTUcsWUFBWSxDQUFDO0FBQUEsY0FDakcsU0FBU3RFLFVBQVVnRSxJQUFJLENBQUFRLFNBQVEsRUFBRUMsT0FBT0QsSUFBSXRELEtBQUttRCxPQUFPRyxJQUFJbEIsS0FBSyxFQUFFO0FBQUE7QUFBQSxZQUpyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJdUUsS0FMekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsT0FBTSwyQkFBMEIsTUFBSyxvQkFBbUIsT0FBTyxDQUFDLEVBQUVZLFVBQVUsTUFBTTlCLFNBQVMsc0JBQXNCLENBQUMsR0FDM0gsaUNBQUMsTUFBTSxVQUFOLEVBQWUsTUFBTSxHQUFHLGFBQVksd0NBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlFLEtBRDNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLG1DQUFDLFlBQU8sU0FBUyxNQUFNL0IsdUJBQXVCLEtBQUssR0FBRyxXQUFVLDhDQUE2QyxzQkFBN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUg7QUFBQSxZQUNuSCx1QkFBQyxZQUFPLE1BQUssVUFBUyxXQUFVLGtFQUFpRSx3QkFBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUc7QUFBQSxlQUYzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUE7QUFBQSxNQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF1QkE7QUFBQSxPQXhPRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeU9BO0FBRUo7QUFBQ2hCLEdBemFRRCxlQUFhO0FBQUEsVUFtQktkLEtBQUttQyxTQUNQbkMsS0FBS21DLE9BQU87QUFBQTtBQUFBaUUsS0FwQjVCdEY7QUEyYVQsZUFBZUE7QUFBYyxJQUFBc0Y7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQVBJIiwibm90aWZpY2F0aW9uIiwiTW9kYWwiLCJGb3JtIiwiSW5wdXQiLCJTZWxlY3QiLCJDaGVja0NpcmNsZSIsIkNsaXBib2FyZENoZWNrIiwiQWxlcnRDaXJjbGUiLCJVc2VyUGx1cyIsIlJvdGF0ZUNjdyIsIkxheW91dEdyaWQiLCJMaXN0IiwiSGlzdG9yeSIsIlNpZGViYXIiLCJOYXZiYXIiLCJDaXJjdWxhckxvYWRlciIsIkVtcGxveWVlVGFza3MiLCJfcyIsIm15VGFza3MiLCJzZXRNeVRhc2tzIiwibXlSZWFzc2lnbmVkSGlzdG9yeSIsInNldE15UmVhc3NpZ25lZEhpc3RvcnkiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJ2aWV3TW9kZSIsInNldFZpZXdNb2RlIiwiZmlsdGVyU3RhdHVzIiwic2V0RmlsdGVyU3RhdHVzIiwiZW1wbG95ZWVzIiwic2V0RW1wbG95ZWVzIiwiaXNDb21wbGV0aW9uTW9kYWxPcGVuIiwic2V0SXNDb21wbGV0aW9uTW9kYWxPcGVuIiwiaXNSZWFzc2lnbk1vZGFsT3BlbiIsInNldElzUmVhc3NpZ25Nb2RhbE9wZW4iLCJzZWxlY3RlZFRhc2tJZCIsInNldFNlbGVjdGVkVGFza0lkIiwiY29tcGxldGlvbkZvcm0iLCJ1c2VGb3JtIiwicmVhc3NpZ25Gb3JtIiwidXNlclN0ciIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJsb2dnZWRJblVzZXIiLCJKU09OIiwicGFyc2UiLCJteUlkIiwiX2lkIiwidXNlRWZmZWN0IiwiZmV0Y2hFbXBsb3llZXMiLCJyZXMiLCJnZXQiLCJkYXRhIiwiZXJyb3IiLCJjb25zb2xlIiwiZmV0Y2hNeVRhc2tzIiwiY29tcGxhaW50cyIsImFzc2lnbmVkVG9NZSIsImZpbHRlciIsIml0ZW0iLCJhc3NpZ25lZFRvIiwiYXNzaWduZWRJZCIsIlN0cmluZyIsInJlYXNzaWduZWRCeSIsInJlYXNzaWduZWRJZCIsIm1lc3NhZ2UiLCJkZXNjcmlwdGlvbiIsInBlbmRpbmdDb3VudCIsInQiLCJzdGF0dXMiLCJsZW5ndGgiLCJjbG9zZWRDb3VudCIsInJlYXNzaWduQ291bnQiLCJ0YXNrc1RvUmVuZGVyIiwidGFzayIsIm9wZW5Db21wbGV0aW9uTW9kYWwiLCJvcGVuUmVhc3NpZ25Nb2RhbCIsImhhbmRsZVJlYXNzaWduU3VibWl0IiwidmFsdWVzIiwic2VsZWN0ZWRFbXBsb3llZSIsImZpbmQiLCJlIiwiYXNzaWduZWRUb05hbWUiLCJuYW1lIiwicGF5bG9hZCIsInJlYXNzaWdubWVudE5vdGUiLCJwdXQiLCJzdWNjZXNzIiwicHJldiIsInN1YmplY3QiLCJyZXNldEZpZWxkcyIsImhhbmRsZUNvbXBsZXRlU3VibWl0IiwicmVzb2x1dGlvbk5vdGUiLCJtYXAiLCJjb250YWluZXJDbGFzcyIsInJlcXVpcmVkIiwiaW5wdXQiLCJvcHRpb24iLCJsYWJlbCIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJlbXAiLCJ2YWx1ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkVtcGxveWVlVGFza3MuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IEFQSSBmcm9tIFwiLi4vLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgeyBub3RpZmljYXRpb24sIE1vZGFsLCBGb3JtLCBJbnB1dCwgU2VsZWN0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgQ2hlY2tDaXJjbGUsIENsaXBib2FyZENoZWNrLCBBbGVydENpcmNsZSwgVXNlclBsdXMsIFJvdGF0ZUNjdywgTGF5b3V0R3JpZCwgTGlzdCwgSGlzdG9yeSB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjsgXHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcblxyXG5mdW5jdGlvbiBFbXBsb3llZVRhc2tzKCkge1xyXG4gIGNvbnN0IFtteVRhc2tzLCBzZXRNeVRhc2tzXSA9IHVzZVN0YXRlKFtdKTtcclxuICAvLyBBRERFRDogU3RhdGUgdG8gc3RvcmUgaGlzdG9yeSBvZiB0YXNrcyBJIHJlYXNzaWduZWRcclxuICBjb25zdCBbbXlSZWFzc2lnbmVkSGlzdG9yeSwgc2V0TXlSZWFzc2lnbmVkSGlzdG9yeV0gPSB1c2VTdGF0ZShbXSk7IFxyXG4gIFxyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbdmlld01vZGUsIHNldFZpZXdNb2RlXSA9IHVzZVN0YXRlKFwibGlzdFwiKTtcclxuXHJcbiAgLy8gRmlsdGVyIFN0YXRlXHJcbiAgY29uc3QgW2ZpbHRlclN0YXR1cywgc2V0RmlsdGVyU3RhdHVzXSA9IHVzZVN0YXRlKFwiaXMgUGVuZGluZ1wiKTtcclxuXHJcbiAgLy8gTGlzdHMgZm9yIERyb3Bkb3duc1xyXG4gIGNvbnN0IFtlbXBsb3llZXMsIHNldEVtcGxveWVlc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgXHJcbiAgLy8gTW9kYWwgU3RhdGVzXHJcbiAgY29uc3QgW2lzQ29tcGxldGlvbk1vZGFsT3Blbiwgc2V0SXNDb21wbGV0aW9uTW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNSZWFzc2lnbk1vZGFsT3Blbiwgc2V0SXNSZWFzc2lnbk1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkVGFza0lkLCBzZXRTZWxlY3RlZFRhc2tJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgY29uc3QgW2NvbXBsZXRpb25Gb3JtXSA9IEZvcm0udXNlRm9ybSgpO1xyXG4gIGNvbnN0IFtyZWFzc2lnbkZvcm1dID0gRm9ybS51c2VGb3JtKCk7XHJcblxyXG4gIC8vIC0tLSBGRVRDSCBVU0VSIElEIC0tLVxyXG4gIGNvbnN0IHVzZXJTdHIgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgY29uc3QgbG9nZ2VkSW5Vc2VyID0gdXNlclN0ciA/IEpTT04ucGFyc2UodXNlclN0cikgOiBudWxsO1xyXG4gIGNvbnN0IG15SWQgPSBsb2dnZWRJblVzZXI/Ll9pZDtcclxuXHJcbiAgLy8gRmV0Y2ggRW1wbG95ZWVzIGZvciBSZWFzc2lnbm1lbnRcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgQVBJLmdldChcIi9hZG1pbi9nZXQtc3ViLWFkbWluc1wiKTtcclxuICAgICAgICBzZXRFbXBsb3llZXMocmVzLmRhdGEgfHwgW10pO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbXBsb3llZXM6XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoRW1wbG95ZWVzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKCFteUlkKSByZXR1cm47XHJcblxyXG4gICAgY29uc3QgZmV0Y2hNeVRhc2tzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBBUEkuZ2V0KFwiL2NvbXBsYWludHMvYWxsXCIpO1xyXG4gICAgICAgIGNvbnN0IGNvbXBsYWludHMgPSByZXMuZGF0YT8uZGF0YSB8fCByZXMuZGF0YSB8fCBbXTtcclxuXHJcbiAgICAgICAgLy8gMS4gVGFza3MgY3VycmVudGx5IGFzc2lnbmVkIHRvIG1lXHJcbiAgICAgICAgY29uc3QgYXNzaWduZWRUb01lID0gY29tcGxhaW50cy5maWx0ZXIoKGl0ZW0pID0+IHtcclxuICAgICAgICAgIGlmICghaXRlbS5hc3NpZ25lZFRvKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgICBsZXQgYXNzaWduZWRJZCA9IG51bGw7XHJcbiAgICAgICAgICBpZiAodHlwZW9mIGl0ZW0uYXNzaWduZWRUbyA9PT0gXCJvYmplY3RcIiAmJiBpdGVtLmFzc2lnbmVkVG8uX2lkKSB7XHJcbiAgICAgICAgICAgIGFzc2lnbmVkSWQgPSBpdGVtLmFzc2lnbmVkVG8uX2lkO1xyXG4gICAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgaXRlbS5hc3NpZ25lZFRvID09PSBcInN0cmluZ1wiKSB7XHJcbiAgICAgICAgICAgIGFzc2lnbmVkSWQgPSBpdGVtLmFzc2lnbmVkVG87XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICByZXR1cm4gU3RyaW5nKGFzc2lnbmVkSWQpID09PSBTdHJpbmcobXlJZCk7XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIC8vIDIuIFRhc2tzIEkgaGF2ZSByZWFzc2lnbmVkIHRvIG90aGVycyAoSGlzdG9yeSlcclxuICAgICAgICBjb25zdCBteVJlYXNzaWduZWRIaXN0b3J5ID0gY29tcGxhaW50cy5maWx0ZXIoKGl0ZW0pID0+IHtcclxuICAgICAgICAgICAgaWYgKCFpdGVtLnJlYXNzaWduZWRCeSkgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgICAgICBsZXQgcmVhc3NpZ25lZElkID0gbnVsbDtcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBpdGVtLnJlYXNzaWduZWRCeSA9PT0gXCJvYmplY3RcIiAmJiBpdGVtLnJlYXNzaWduZWRCeS5faWQpIHtcclxuICAgICAgICAgICAgICAgIHJlYXNzaWduZWRJZCA9IGl0ZW0ucmVhc3NpZ25lZEJ5Ll9pZDtcclxuICAgICAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgaXRlbS5yZWFzc2lnbmVkQnkgPT09IFwic3RyaW5nXCIpIHtcclxuICAgICAgICAgICAgICAgIHJlYXNzaWduZWRJZCA9IGl0ZW0ucmVhc3NpZ25lZEJ5O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybiBTdHJpbmcocmVhc3NpZ25lZElkKSA9PT0gU3RyaW5nKG15SWQpO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBzZXRNeVRhc2tzKGFzc2lnbmVkVG9NZSk7XHJcbiAgICAgICAgc2V0TXlSZWFzc2lnbmVkSGlzdG9yeShteVJlYXNzaWduZWRIaXN0b3J5KTtcclxuXHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHRhc2tzOlwiLCBlcnJvcik7XHJcbiAgICAgICAgbm90aWZpY2F0aW9uLmVycm9yKHsgbWVzc2FnZTogXCJFcnJvclwiLCBkZXNjcmlwdGlvbjogXCJGYWlsZWQgdG8gbG9hZCB0YXNrc1wiIH0pO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hNeVRhc2tzKCk7XHJcbiAgfSwgW215SWRdKTtcclxuXHJcbiAgLy8gLS0tIENBTENVTEFURSBDT1VOVFMgLS0tXHJcbiAgY29uc3QgcGVuZGluZ0NvdW50ID0gbXlUYXNrcy5maWx0ZXIodCA9PiB0LnN0YXR1cyAhPT0gXCJDbG9zZWRcIikubGVuZ3RoO1xyXG4gIGNvbnN0IGNsb3NlZENvdW50ID0gbXlUYXNrcy5maWx0ZXIodCA9PiB0LnN0YXR1cyA9PT0gXCJDbG9zZWRcIikubGVuZ3RoO1xyXG4gIGNvbnN0IHJlYXNzaWduQ291bnQgPSBteVJlYXNzaWduZWRIaXN0b3J5Lmxlbmd0aDtcclxuXHJcbiAgLy8gLS0tIEZJTFRFUiBMT0dJQyAtLS1cclxuICAvLyBEZXRlcm1pbmUgd2hpY2ggbGlzdCB0byBzaG93IGJhc2VkIG9uIHRoZSBhY3RpdmUgY2FyZFxyXG4gIGxldCB0YXNrc1RvUmVuZGVyID0gW107XHJcblxyXG4gIGlmIChmaWx0ZXJTdGF0dXMgPT09IFwiUmVhc3NpZ25lZFwiKSB7XHJcbiAgICAvLyBJZiBSZWFzc2lnbmVkIGNhcmQgaXMgY2xpY2tlZCwgc2hvdyB0aGUgaGlzdG9yeVxyXG4gICAgdGFza3NUb1JlbmRlciA9IG15UmVhc3NpZ25lZEhpc3Rvcnk7XHJcbiAgfSBlbHNlIHtcclxuICAgIC8vIE90aGVyd2lzZSwgc2hvdyBmaWx0ZXJlZCBteVRhc2tzIChQZW5kaW5nL0Nsb3NlZClcclxuICAgIHRhc2tzVG9SZW5kZXIgPSBteVRhc2tzLmZpbHRlcih0YXNrID0+IHtcclxuICAgICAgaWYgKGZpbHRlclN0YXR1cyA9PT0gbnVsbCkgcmV0dXJuIHRydWU7XHJcbiAgICAgIHJldHVybiB0YXNrLnN0YXR1cyA9PT0gZmlsdGVyU3RhdHVzO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICAvLyAtLS0gT1BFTiBNT0RBTFMgLS0tXHJcbiAgY29uc3Qgb3BlbkNvbXBsZXRpb25Nb2RhbCA9ICh0YXNrKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZFRhc2tJZCh0YXNrLl9pZCk7XHJcbiAgICBzZXRJc0NvbXBsZXRpb25Nb2RhbE9wZW4odHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb3BlblJlYXNzaWduTW9kYWwgPSAodGFzaykgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRUYXNrSWQodGFzay5faWQpO1xyXG4gICAgc2V0SXNSZWFzc2lnbk1vZGFsT3Blbih0cnVlKTtcclxuICB9O1xyXG5cclxuICAvLyAtLS0gSEFORExFIFJFQVNTSUdOTUVOVCAtLS1cclxuICBjb25zdCBoYW5kbGVSZWFzc2lnblN1Ym1pdCA9IGFzeW5jICh2YWx1ZXMpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHNlbGVjdGVkRW1wbG95ZWUgPSBlbXBsb3llZXMuZmluZChlID0+IGUuX2lkID09PSB2YWx1ZXMuYXNzaWduZWRUbyk7XHJcbiAgICAgIGNvbnN0IGFzc2lnbmVkVG9OYW1lID0gc2VsZWN0ZWRFbXBsb3llZSA/IHNlbGVjdGVkRW1wbG95ZWUubmFtZSA6IFwiXCI7XHJcblxyXG4gICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgIGFzc2lnbmVkVG86IHZhbHVlcy5hc3NpZ25lZFRvLFxyXG4gICAgICAgIGFzc2lnbmVkVG9OYW1lOiBhc3NpZ25lZFRvTmFtZSxcclxuICAgICAgICByZWFzc2lnbm1lbnROb3RlOiB2YWx1ZXMucmVhc3NpZ25tZW50Tm90ZSxcclxuICAgICAgICByZWFzc2lnbmVkQnk6IG15SWQsIC8vIFNhdmUgd2hvIHJlYXNzaWduZWQgaXRcclxuICAgICAgICBzdGF0dXM6IFwiaXMgUGVuZGluZ1wiXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBhd2FpdCBBUEkucHV0KGAvY29tcGxhaW50cy91cGRhdGUvJHtzZWxlY3RlZFRhc2tJZH1gLCBwYXlsb2FkKTtcclxuXHJcbiAgICAgIG5vdGlmaWNhdGlvbi5zdWNjZXNzKHtcclxuICAgICAgICBtZXNzYWdlOiBcIlRhc2sgUmVhc3NpZ25lZFwiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBgVGFzayBhc3NpZ25lZCB0byAke2Fzc2lnbmVkVG9OYW1lfWAsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgLy8gUmVtb3ZlIGZyb20gbXlUYXNrcyBsb2NhbGx5XHJcbiAgICAgIHNldE15VGFza3MoKHByZXYpID0+IHByZXYuZmlsdGVyKHQgPT4gdC5faWQgIT09IHNlbGVjdGVkVGFza0lkKSk7XHJcbiAgICAgIFxyXG4gICAgICAvLyBBZGQgdG8gaGlzdG9yeSBsb2NhbGx5XHJcbiAgICAgIHNldE15UmVhc3NpZ25lZEhpc3RvcnkoKHByZXYpID0+IFsuLi5wcmV2LCB7IC4uLnBheWxvYWQsIF9pZDogc2VsZWN0ZWRUYXNrSWQsIHN1YmplY3Q6IG15VGFza3MuZmluZCh0PT50Ll9pZD09PXNlbGVjdGVkVGFza0lkKT8uc3ViamVjdCwgbWVzc2FnZTogbXlUYXNrcy5maW5kKHQ9PnQuX2lkPT09c2VsZWN0ZWRUYXNrSWQpPy5tZXNzYWdlIH1dKTtcclxuXHJcbiAgICAgIHNldElzUmVhc3NpZ25Nb2RhbE9wZW4oZmFsc2UpO1xyXG4gICAgICByZWFzc2lnbkZvcm0ucmVzZXRGaWVsZHMoKTtcclxuICAgICAgc2V0U2VsZWN0ZWRUYXNrSWQobnVsbCk7XHJcblxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIG5vdGlmaWNhdGlvbi5lcnJvcih7IG1lc3NhZ2U6IFwiRXJyb3JcIiwgZGVzY3JpcHRpb246IFwiRmFpbGVkIHRvIHJlYXNzaWduIHRhc2tcIiB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyAtLS0gSEFORExFIENPTVBMRVRJT04gLS0tXHJcbiAgY29uc3QgaGFuZGxlQ29tcGxldGVTdWJtaXQgPSBhc3luYyAodmFsdWVzKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgIHN0YXR1czogXCJDbG9zZWRcIixcclxuICAgICAgICByZXNvbHV0aW9uTm90ZTogdmFsdWVzLnJlc29sdXRpb25Ob3RlLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgYXdhaXQgQVBJLnB1dChgL2NvbXBsYWludHMvdXBkYXRlLyR7c2VsZWN0ZWRUYXNrSWR9YCwgcGF5bG9hZCk7XHJcblxyXG4gICAgICBub3RpZmljYXRpb24uc3VjY2Vzcyh7IG1lc3NhZ2U6IFwiVGFzayBDb21wbGV0ZWRcIiwgZGVzY3JpcHRpb246IFwiVGlja2V0IG1hcmtlZCBhcyBDbG9zZWRcIiB9KTtcclxuXHJcbiAgICAgIHNldE15VGFza3MoKHByZXYpID0+XHJcbiAgICAgICAgcHJldi5tYXAoKHRhc2spID0+XHJcbiAgICAgICAgICB0YXNrLl9pZCA9PT0gc2VsZWN0ZWRUYXNrSWRcclxuICAgICAgICAgICAgPyB7IC4uLnRhc2ssIHN0YXR1czogXCJDbG9zZWRcIiwgcmVzb2x1dGlvbk5vdGU6IHZhbHVlcy5yZXNvbHV0aW9uTm90ZSB9XHJcbiAgICAgICAgICAgIDogdGFza1xyXG4gICAgICAgIClcclxuICAgICAgKTtcclxuXHJcbiAgICAgIHNldElzQ29tcGxldGlvbk1vZGFsT3BlbihmYWxzZSk7XHJcbiAgICAgIGNvbXBsZXRpb25Gb3JtLnJlc2V0RmllbGRzKCk7XHJcbiAgICAgIHNldFNlbGVjdGVkVGFza0lkKG51bGwpO1xyXG5cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICBub3RpZmljYXRpb24uZXJyb3IoeyBtZXNzYWdlOiBcIkVycm9yXCIsIGRlc2NyaXB0aW9uOiBcIlVuYWJsZSB0byB1cGRhdGUgdGFzayBzdGF0dXNcIiB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBjb250YWluZXJDbGFzcyA9IHZpZXdNb2RlID09PSAnZ3JpZCdcclxuICAgID8gXCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIGdhcC00XCJcclxuICAgIDogXCJmbGV4IGZsZXgtY29sIGdhcC0zXCI7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtc2NyZWVuIGJnLWdyYXktMTAwIG10LTIwXCI+XHJcbiAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggZmxleC1jb2wgbWItMlwiPlxyXG4gICAgICAgIDxOYXZiYXIgLz5cclxuXHJcbiAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC0xIHB0LTIgcHgtNiBtYi01XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi02XCI+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGRcIj5NeSBBc3NpZ25lZCBUYXNrczwvaDE+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggYmctd2hpdGUgcC0xIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3TW9kZSgnbGlzdCcpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQtbWQgJHt2aWV3TW9kZSA9PT0gJ2xpc3QnID8gJ2JnLXZpb2xldC0xMDAgdGV4dC12aW9sZXQtNjAwJyA6ICd0ZXh0LWdyYXktNDAwIGhvdmVyOmJnLWdyYXktMTAwJ31gfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxMaXN0IHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdNb2RlKCdncmlkJyl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTIgcm91bmRlZC1tZCAke3ZpZXdNb2RlID09PSAnZ3JpZCcgPyAnYmctdmlvbGV0LTEwMCB0ZXh0LXZpb2xldC02MDAnIDogJ3RleHQtZ3JheS00MDAgaG92ZXI6YmctZ3JheS0xMDAnfWB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPExheW91dEdyaWQgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIC0tLSBEQVNIQk9BUkQgQ0FSRFMgLS0tICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC02IG1iLThcIj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBQZW5kaW5nIENhcmQgKi99XHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRGaWx0ZXJTdGF0dXMocHJldiA9PiBwcmV2ID09PSBcImlzIFBlbmRpbmdcIiA/IG51bGwgOiBcImlzIFBlbmRpbmdcIil9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQteGwgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgY3Vyc29yLXBvaW50ZXIgYm9yZGVyLTIgJHtmaWx0ZXJTdGF0dXMgPT09IFwiaXMgUGVuZGluZ1wiID8gXCJib3JkZXIteWVsbG93LTUwMCByaW5nLTEgcmluZy15ZWxsb3ctNTAwIGJnLXdoaXRlXCIgOiBcImJvcmRlci10cmFuc3BhcmVudCBiZy13aGl0ZVwifWB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBiZy15ZWxsb3ctMjAwIGhvdmVyOmJnLXllbGxvdy0xMDAgdHJhbnNpdGlvbiByb3VuZGVkLXQteGxcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LTEyIGgtMTIgYmcteWVsbG93LTEwMCB0ZXh0LXllbGxvdy02MDAgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEFsZXJ0Q2lyY2xlIHNpemU9ezI0fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlBlbmRpbmc8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+SW4gUHJvZ3Jlc3M8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC15ZWxsb3ctNjAwXCI+e3BlbmRpbmdDb3VudH08L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIENsb3NlZCBDYXJkICovfVxyXG4gICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RmlsdGVyU3RhdHVzKHByZXYgPT4gcHJldiA9PT0gXCJDbG9zZWRcIiA/IG51bGwgOiBcIkNsb3NlZFwiKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2ByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBzaGFkb3ctc20gaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBjdXJzb3ItcG9pbnRlciBib3JkZXItMiAke2ZpbHRlclN0YXR1cyA9PT0gXCJDbG9zZWRcIiA/IFwiYm9yZGVyLWdyZWVuLTUwMCByaW5nLTEgcmluZy1ncmVlbi01MDAgYmctd2hpdGVcIiA6IFwiYm9yZGVyLXRyYW5zcGFyZW50IGJnLXdoaXRlXCJ9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IGJnLWdyZWVuLTIwMCBob3ZlcjpiZy1ncmVlbi0xMDAgdHJhbnNpdGlvbiByb3VuZGVkLXQteGxcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB3LTEyIGgtMTIgYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tNjAwIHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDbGlwYm9hcmRDaGVjayBzaXplPXsyNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5DbG9zZWQ8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+Q29tcGxldGVkIFRhc2tzPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtZ3JlZW4tNjAwXCI+e2Nsb3NlZENvdW50fTwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogUmVhc3NpZ25lZCAvIEhpc3RvcnkgQ2FyZCAqL31cclxuICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZpbHRlclN0YXR1cyhwcmV2ID0+IHByZXYgPT09IFwiUmVhc3NpZ25lZFwiID8gbnVsbCA6IFwiUmVhc3NpZ25lZFwiKX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2ByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBzaGFkb3ctc20gaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBjdXJzb3ItcG9pbnRlciBib3JkZXItMiAke2ZpbHRlclN0YXR1cyA9PT0gXCJSZWFzc2lnbmVkXCIgPyBcImJvcmRlci1wdXJwbGUtNTAwIHJpbmctMSByaW5nLXB1cnBsZS01MDAgYmctd2hpdGVcIiA6IFwiYm9yZGVyLXRyYW5zcGFyZW50IGJnLXdoaXRlXCJ9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IGJnLXB1cnBsZS0yMDAgaG92ZXI6YmctcHVycGxlLTEwMCB0cmFuc2l0aW9uIHJvdW5kZWQtdC14bFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMTIgaC0xMiBiZy1wdXJwbGUtMTAwIHRleHQtcHVycGxlLTYwMCByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SGlzdG9yeSBzaXplPXsyNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5SZWFzc2lnbmVkPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPkJ5IE1lIChIaXN0b3J5KTwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LXB1cnBsZS02MDBcIj57cmVhc3NpZ25Db3VudH08L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiAtLS0gREFUQSBMSVNUL0dSSUQgU0VDVElPTiAtLS0gKi99XHJcbiAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgIGZhaWx1cmU9eyFpc0xvYWRpbmcgJiYgdGFza3NUb1JlbmRlci5sZW5ndGggPT09IDB9XHJcbiAgICAgICAgICAgIGRhdGE9e2ZpbHRlclN0YXR1cyA9PT0gXCJSZWFzc2lnbmVkXCIgPyBcIkhpc3RvcnlcIiA6IFwiVGFza3NcIn1cclxuICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgeyFpc0xvYWRpbmcgJiYgdGFza3NUb1JlbmRlci5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2NvbnRhaW5lckNsYXNzfT5cclxuICAgICAgICAgICAgICB7dGFza3NUb1JlbmRlci5tYXAoKHRhc2spID0+IChcclxuICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAga2V5PXt0YXNrLl9pZH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC00IHJvdW5kZWQtbGcgc2hhZG93IGJvcmRlciBib3JkZXItZ3JheS0yMDAgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb24gaC1mdWxsXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgey8qIFJPVyAxOiBDb250ZW50ICYgQnV0dG9ucyAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydCBnYXAtNFwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogQ29udGVudCBBcmVhICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBCYWRnZSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BpbmxpbmUtYmxvY2sgcHgtMiBweS0wLjUgdGV4dC1bMTBweF0gZm9udC1ib2xkIHJvdW5kZWQgdGV4dC13aGl0ZSAke3Rhc2suc3RhdHVzID09PSBcIkNsb3NlZFwiID8gXCJiZy1ncmVlbi02MDBcIiA6IFwiYmcteWVsbG93LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt0YXNrLnN0YXR1c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIFN1YmplY3QgYW5kIERlc2NyaXB0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwXCI+U3ViamVjdDo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMCBtbC0xIGJyZWFrLXdvcmRzXCI+e3Rhc2suc3ViamVjdH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDBcIj5EZXNjcmlwdGlvbjo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTkwMCBtbC0xIGJyZWFrLXdvcmRzIGxpbmUtY2xhbXAtM1wiPnt0YXNrLm1lc3NhZ2V9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogQnV0dG9uIEFyZWEgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZDp3LWF1dG8gdy1mdWxsIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC0yIGZsZXgtc2hyaW5rLTAgbXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3Rhc2suc3RhdHVzICE9PSBcIkNsb3NlZFwiID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9wZW5Db21wbGV0aW9uTW9kYWwodGFzayl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMSBweC0zIHB5LTEuNSBiZy1ncmVlbi02MDAgaG92ZXI6YmctZ3JlZW4tNzAwIHRleHQtd2hpdGUgdGV4dC14cyByb3VuZGVkIHNoYWRvdy1zbSB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUgc2l6ZT17MTJ9IC8+IE1hcmsgY29tcGxldGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb3BlblJlYXNzaWduTW9kYWwodGFzayl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMSBweC0zIHB5LTEuNSBiZy1vcmFuZ2UtNTAwIGhvdmVyOmJnLW9yYW5nZS02MDAgdGV4dC13aGl0ZSB0ZXh0LXhzIHJvdW5kZWQgc2hhZG93LXNtIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxVc2VyUGx1cyBzaXplPXsxMn0gLz4gUmUtYXNzaWduXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMSBweC0zIHB5LTEuNSBiZy1ncmVlbi01MCB0ZXh0LWdyZWVuLTYwMCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUgc2l6ZT17MTJ9IC8+IENsb3NlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIFJPVyAyOiBOb3RlcyAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIHNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt0YXNrLnJlYXNzaWdubWVudE5vdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmcteWVsbG93LTUwIHJvdW5kZWQgYm9yZGVyIGJvcmRlci15ZWxsb3ctMjAwIHRleHQtWzEwcHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXllbGxvdy04MDAgbWItMC41IGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFJvdGF0ZUNjdyBzaXplPXsxMH0gLz4gUmVhc3NpZ25lZCBOb3RlOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS04MDBcIj57dGFzay5yZWFzc2lnbm1lbnROb3RlfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAge3Rhc2suc3RhdHVzID09PSBcIkNsb3NlZFwiICYmIHRhc2sucmVzb2x1dGlvbk5vdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmctZ3JlZW4tNTAgcm91bmRlZCBib3JkZXIgYm9yZGVyLWdyZWVuLTIwMCB0ZXh0LVsxMHB4XVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ncmVlbi04MDAgbWItMC41IGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlIHNpemU9ezEwfSAvPiBSZXNvbHZlZDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwXCI+e3Rhc2sucmVzb2x1dGlvbk5vdGV9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvbWFpbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogLS0tIENPTVBMRVRJT04gTU9EQUwgLS0tICovfVxyXG4gICAgICA8TW9kYWxcclxuICAgICAgICB0aXRsZT1cIkNvbXBsZXRlIFRhc2tcIlxyXG4gICAgICAgIG9wZW49e2lzQ29tcGxldGlvbk1vZGFsT3Blbn1cclxuICAgICAgICBvbkNhbmNlbD17KCkgPT4geyBzZXRJc0NvbXBsZXRpb25Nb2RhbE9wZW4oZmFsc2UpOyBjb21wbGV0aW9uRm9ybS5yZXNldEZpZWxkcygpOyB9fVxyXG4gICAgICAgIGZvb3Rlcj17bnVsbH1cclxuICAgICAgPlxyXG4gICAgICAgIDxGb3JtIGZvcm09e2NvbXBsZXRpb25Gb3JtfSBsYXlvdXQ9XCJ2ZXJ0aWNhbFwiIG9uRmluaXNoPXtoYW5kbGVDb21wbGV0ZVN1Ym1pdH0+XHJcbiAgICAgICAgICA8Rm9ybS5JdGVtIGxhYmVsPVwiUmVzb2x1dGlvbiBOb3RlXCIgbmFtZT1cInJlc29sdXRpb25Ob3RlXCIgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiAnUGxlYXNlIGFkZCBhIG5vdGUhJyB9XX0+XHJcbiAgICAgICAgICAgIDxJbnB1dC5UZXh0QXJlYSByb3dzPXs0fSBwbGFjZWhvbGRlcj1cIkRlc2NyaWJlIGhvdyB5b3UgcmVzb2x2ZWQgdGhpcyBpc3N1ZS4uLlwiIC8+XHJcbiAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMiBtdC00XCI+XHJcbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0SXNDb21wbGV0aW9uTW9kYWxPcGVuKGZhbHNlKX0gY2xhc3NOYW1lPVwicHgtNCBweS0yIGJvcmRlciByb3VuZGVkIGhvdmVyOmJnLWdyYXktMTAwXCI+Q2FuY2VsPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy12aW9sZXQtNjAwIHRleHQtd2hpdGUgcm91bmRlZCBob3ZlcjpiZy12aW9sZXQtNzAwXCI+U3VibWl0PC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L0Zvcm0+XHJcbiAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICB7LyogLS0tIFJFQVNTSUdOIE1PREFMIC0tLSAqL31cclxuICAgICAgPE1vZGFsXHJcbiAgICAgICAgdGl0bGU9XCJSZWFzc2lnbiBUYXNrXCJcclxuICAgICAgICBvcGVuPXtpc1JlYXNzaWduTW9kYWxPcGVufVxyXG4gICAgICAgIG9uQ2FuY2VsPXsoKSA9PiB7IHNldElzUmVhc3NpZ25Nb2RhbE9wZW4oZmFsc2UpOyByZWFzc2lnbkZvcm0ucmVzZXRGaWVsZHMoKTsgfX1cclxuICAgICAgICBmb290ZXI9e251bGx9XHJcbiAgICAgID5cclxuICAgICAgICA8Rm9ybSBmb3JtPXtyZWFzc2lnbkZvcm19IGxheW91dD1cInZlcnRpY2FsXCIgb25GaW5pc2g9e2hhbmRsZVJlYXNzaWduU3VibWl0fT5cclxuICAgICAgICAgIDxGb3JtLkl0ZW0gbGFiZWw9XCJBc3NpZ24gVG9cIiBuYW1lPVwiYXNzaWduZWRUb1wiIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogJ1BsZWFzZSBzZWxlY3QgYW4gZW1wbG95ZWUhJyB9XX0+XHJcbiAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggZW1wbG95ZWUuLi5cIlxyXG4gICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+IChvcHRpb24/LmxhYmVsID8/IFwiXCIpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSl9XHJcbiAgICAgICAgICAgICAgb3B0aW9ucz17ZW1wbG95ZWVzLm1hcChlbXAgPT4gKHsgdmFsdWU6IGVtcC5faWQsIGxhYmVsOiBlbXAubmFtZSB9KSl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgIDxGb3JtLkl0ZW0gbGFiZWw9XCJSZWFzb24gZm9yIFJlYXNzaWdubWVudFwiIG5hbWU9XCJyZWFzc2lnbm1lbnROb3RlXCIgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiAnUGxlYXNlIGV4cGxhaW4gd2h5IScgfV19PlxyXG4gICAgICAgICAgICA8SW5wdXQuVGV4dEFyZWEgcm93cz17NH0gcGxhY2Vob2xkZXI9XCJXaHkgYXJlIHlvdSByZWFzc2lnbmluZyB0aGlzIHRhc2s/XCIgLz5cclxuICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0yIG10LTRcIj5cclxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRJc1JlYXNzaWduTW9kYWxPcGVuKGZhbHNlKX0gY2xhc3NOYW1lPVwicHgtNCBweS0yIGJvcmRlciByb3VuZGVkIGhvdmVyOmJnLWdyYXktMTAwXCI+Q2FuY2VsPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1vcmFuZ2UtNjAwIHRleHQtd2hpdGUgcm91bmRlZCBob3ZlcjpiZy1vcmFuZ2UtNzAwXCI+UmVhc3NpZ248L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvRm9ybT5cclxuICAgICAgPC9Nb2RhbD5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEVtcGxveWVlVGFza3M7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL2NvbXBvbmVudHMvZW1wbG95ZWUvRW1wbG95ZWVUYXNrcy5qc3gifQ==