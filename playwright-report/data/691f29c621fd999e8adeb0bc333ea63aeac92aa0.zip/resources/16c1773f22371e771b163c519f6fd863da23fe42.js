import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CustomerAppInstallation.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import CustomerAppEvents from "/src/pages/CustomerAppEvents.jsx";
import {
  Users,
  CheckCircle,
  XCircle
} from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
function CustomerAppInstallation() {
  _s();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [statusFilter, setStatusFilter] = useState("");
  const [search, setSearch] = useState("");
  const [activeTab, setActiveTab] = useState("installation");
  const [alert, setAlert] = useState({
    show: false,
    type: "",
    message: ""
  });
  const fetchData = async () => {
    try {
      setLoading(true);
      const res = await api.get(
        "/v1/admin/users/mobile-app-installs"
      );
      setData(res.data?.data || []);
    } catch (error) {
      setAlert({
        show: true,
        type: "error",
        message: error?.response?.data?.message || "Failed to fetch installation report"
      });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);
  const installedCount = data.filter(
    (item) => item.verdict === true
  ).length;
  const notInstalledCount = data.filter(
    (item) => item.verdict === false
  ).length;
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "customer_id", header: "Customer ID" },
    { key: "full_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "email", header: "Email" },
    { key: "status", header: "Status" },
    { key: "last_login", header: "Last Login" },
    { key: "last_failed", header: "Last Failed" },
    { key: "failure_reason", header: "Reason" }
  ];
  const tableData = data.map((item, index) => ({
    id: index + 1,
    customer_id: item.customer_id || "-",
    full_name: item.full_name || "-",
    phone_number: item.phone_number || "-",
    email: item.email || "-",
    status: item.verdict ? "Installed" : "Not Installed",
    last_login: item.last_successful_login_at ? new Date(item.last_successful_login_at).toLocaleString() : "-",
    last_failed: item.last_failed_login_at ? new Date(item.last_failed_login_at).toLocaleString() : "-",
    failure_reason: item.failure_reason || "-"
  }));
  const filtereddata = tableData.filter((item) => {
    const matchesStatus = !statusFilter || item.status === statusFilter;
    const matchesSearch = !search || item.customer_id?.toLowerCase().includes(search.toLowerCase()) || item.full_name?.toLowerCase().includes(search.toLowerCase()) || item.email?.toLowerCase().includes(search.toLowerCase());
    return matchesStatus && matchesSearch;
  });
  if (loading) {
    return /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
      lineNumber: 108,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "p-6 bg-gray-50 min-h-screen", children: [
    /* @__PURE__ */ jsxDEV(
      CustomAlert,
      {
        show: alert.show,
        type: alert.type,
        message: alert.message,
        onClose: () => setAlert({ show: false, type: "", message: "" })
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
        lineNumber: 113,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-md border border-gray-100 p-2 mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => setActiveTab("installation"),
          className: `px-5 py-3 rounded-xl text-sm font-semibold transition-all duration-200 ${activeTab === "installation" ? "bg-blue-600 text-white shadow-md" : "text-gray-600 hover:bg-gray-100"}`,
          children: "App Installation"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
          lineNumber: 125,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => setActiveTab("events"),
          className: `px-5 py-3 rounded-xl text-sm font-semibold transition-all duration-200 ${activeTab === "events" ? "bg-blue-600 text-white shadow-md" : "text-gray-600 hover:bg-gray-100"}`,
          children: "Customer App Events"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
          lineNumber: 136,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
      lineNumber: 124,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
      lineNumber: 123,
      columnNumber: 7
    }, this),
    activeTab === "installation" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row md:items-center md:justify-between mb-6", children: /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold text-gray-800", children: "Customer App Installation Report" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
          lineNumber: 155,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 mt-1", children: "Track customer app installations and login activity." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
          lineNumber: 159,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
        lineNumber: 154,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
        lineNumber: 153,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-md border border-gray-100 p-5 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-gray-700", children: "Filters" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
            lineNumber: 168,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setSearch("");
                setStatusFilter("");
              },
              className: "text-sm font-medium text-blue-600 hover:text-blue-800",
              children: "Clear Filters"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
              lineNumber: 172,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
          lineNumber: 167,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-600 mb-2", children: "Search Customer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
              lineNumber: 186,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                placeholder: "Customer ID, Name, Email...",
                value: search,
                onChange: (e) => setSearch(e.target.value),
                className: "w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
                lineNumber: 190,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
            lineNumber: 185,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-600 mb-2", children: "Installation Status" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
              lineNumber: 201,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                value: statusFilter,
                onChange: (e) => setStatusFilter(e.target.value),
                className: "w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500",
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "", children: "All Status" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
                    lineNumber: 210,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Installed", children: "Installed" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
                    lineNumber: 211,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "Not Installed", children: "Not Installed" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
                    lineNumber: 212,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
                lineNumber: 205,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
            lineNumber: 200,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
          lineNumber: 183,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
        lineNumber: 166,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-indigo-500 to-purple-600 rounded-2xl p-6 text-white shadow-lg mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row justify-between items-center", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-semibold", children: "Installation Overview" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
            lineNumber: 222,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-indigo-100 mt-1", children: [
            installedCount,
            " of ",
            data.length,
            " customers have installed the mobile application."
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
            lineNumber: 226,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
          lineNumber: 221,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-5xl font-bold mt-4 md:mt-0", children: [
          data.length > 0 ? Math.round(
            installedCount / data.length * 100
          ) : 0,
          "%"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
          lineNumber: 232,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
        lineNumber: 220,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
        lineNumber: 219,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6 mb-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "relative overflow-hidden bg-white rounded-2xl shadow-md border", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 left-0 h-1 w-full bg-blue-500" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
            lineNumber: 247,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-6 flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm", children: "Total Customers" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
                lineNumber: 251,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("h2", { className: "text-4xl font-bold text-gray-800 mt-2", children: data.length }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
                lineNumber: 255,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
              lineNumber: 250,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 rounded-xl bg-blue-100 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(
              Users,
              {
                size: 28,
                className: "text-blue-600"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
                lineNumber: 261,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
              lineNumber: 260,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
            lineNumber: 249,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
          lineNumber: 246,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative overflow-hidden bg-white rounded-2xl shadow-md border", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 left-0 h-1 w-full bg-green-500" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
            lineNumber: 271,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-6 flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm", children: "Installed" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
                lineNumber: 275,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("h2", { className: "text-4xl font-bold text-green-600 mt-2", children: installedCount }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
                lineNumber: 279,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
              lineNumber: 274,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 rounded-xl bg-green-100 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(
              CheckCircle,
              {
                size: 28,
                className: "text-green-600"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
                lineNumber: 285,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
              lineNumber: 284,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
            lineNumber: 273,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
          lineNumber: 270,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "relative overflow-hidden bg-white rounded-2xl shadow-md border", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 left-0 h-1 w-full bg-red-500" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
            lineNumber: 295,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-6 flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm", children: "Not Installed" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
                lineNumber: 299,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("h2", { className: "text-4xl font-bold text-red-600 mt-2", children: notInstalledCount }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
                lineNumber: 303,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
              lineNumber: 298,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 rounded-xl bg-red-100 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(
              XCircle,
              {
                size: 28,
                className: "text-red-600"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
                lineNumber: 309,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
              lineNumber: 308,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
            lineNumber: 297,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
          lineNumber: 294,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
        lineNumber: 244,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-md border border-gray-100 p-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-700", children: "Customer Details" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
            lineNumber: 321,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500", children: [
            filtereddata.length,
            " Records"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
            lineNumber: 325,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
          lineNumber: 320,
          columnNumber: 13
        }, this),
        filtereddata.length > 0 ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            columns,
            data: filtereddata
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
            lineNumber: 331,
            columnNumber: 11
          },
          this
        ) : /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center py-16", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center mb-4", children: /* @__PURE__ */ jsxDEV(
            XCircle,
            {
              size: 40,
              className: "text-gray-400"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
              lineNumber: 338,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
            lineNumber: 337,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-700", children: "No Data Found" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
            lineNumber: 344,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 mt-2 text-center", children: "No customers match the selected filters." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
            lineNumber: 348,
            columnNumber: 17
          }, this),
          (search || statusFilter) && /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setSearch("");
                setStatusFilter("");
              },
              className: "mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700",
              children: "Clear Filters"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
              lineNumber: 353,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
          lineNumber: 336,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
        lineNumber: 319,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
      lineNumber: 151,
      columnNumber: 7
    }, this),
    activeTab === "events" && /* @__PURE__ */ jsxDEV(CustomerAppEvents, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
      lineNumber: 371,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx",
    lineNumber: 112,
    columnNumber: 5
  }, this);
}
_s(CustomerAppInstallation, "M3e3Fzr2HovLPlYdWyI8EFF1Fmg=");
_c = CustomerAppInstallation;
export default CustomerAppInstallation;
var _c;
$RefreshReg$(_c, "CustomerAppInstallation");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAppInstallation.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkdXLFNBMkNILFVBM0NHOzs7Ozs7Ozs7Ozs7Ozs7OztBQTFHWCxPQUFPQSxTQUFTQyxXQUFXQyxnQkFBZ0I7QUFDM0MsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsdUJBQXVCO0FBQzlCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUVQLFNBQVNDLDBCQUEwQjtBQUFBQyxLQUFBO0FBQ2pDLFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJWixTQUFTLEVBQUU7QUFDbkMsUUFBTSxDQUFDYSxTQUFTQyxVQUFVLElBQUlkLFNBQVMsS0FBSztBQUM1QyxRQUFNLENBQUNlLGNBQWNDLGVBQWUsSUFBSWhCLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUNpQixRQUFRQyxTQUFTLElBQUlsQixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDbUIsV0FBV0MsWUFBWSxJQUFJcEIsU0FBUyxjQUFjO0FBQ3pELFFBQU0sQ0FBQ3FCLE9BQU9DLFFBQVEsSUFBSXRCLFNBQVM7QUFBQSxJQUNqQ3VCLE1BQU07QUFBQSxJQUNOQyxNQUFNO0FBQUEsSUFDTkMsU0FBUztBQUFBLEVBQ1gsQ0FBQztBQUVELFFBQU1DLFlBQVksWUFBWTtBQUM1QixRQUFJO0FBQ0ZaLGlCQUFXLElBQUk7QUFFZixZQUFNYSxNQUFNLE1BQU0xQixJQUFJMkI7QUFBQUEsUUFDcEI7QUFBQSxNQUNGO0FBRUFoQixjQUFRZSxJQUFJaEIsTUFBTUEsUUFBUSxFQUFFO0FBQUEsSUFDOUIsU0FBU2tCLE9BQU87QUFDZFAsZUFBUztBQUFBLFFBQ1BDLE1BQU07QUFBQSxRQUNOQyxNQUFNO0FBQUEsUUFDTkMsU0FDRUksT0FBT0MsVUFBVW5CLE1BQU1jLFdBQ3ZCO0FBQUEsTUFDSixDQUFDO0FBQUEsSUFDSCxVQUFDO0FBQ0NYLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQWYsWUFBVSxNQUFNO0FBQ2QyQixjQUFVO0FBQUEsRUFDWixHQUFHLEVBQUU7QUFFTCxRQUFNSyxpQkFBaUJwQixLQUFLcUI7QUFBQUEsSUFDMUIsQ0FBQ0MsU0FBU0EsS0FBS0MsWUFBWTtBQUFBLEVBQzdCLEVBQUVDO0FBRUYsUUFBTUMsb0JBQW9CekIsS0FBS3FCO0FBQUFBLElBQzdCLENBQUNDLFNBQVNBLEtBQUtDLFlBQVk7QUFBQSxFQUM3QixFQUFFQztBQUVGLFFBQU1FLFVBQVU7QUFBQSxJQUNkLEVBQUVDLEtBQUssTUFBTUMsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxlQUFlQyxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFRCxLQUFLLGFBQWFDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDNUMsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVELEtBQUssU0FBU0MsUUFBUSxRQUFRO0FBQUEsSUFDaEMsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVELEtBQUssZUFBZUMsUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRUQsS0FBSyxrQkFBa0JDLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHN0MsUUFBTUMsWUFBWTdCLEtBQUs4QixJQUFJLENBQUNSLE1BQU1TLFdBQVc7QUFBQSxJQUMzQ0MsSUFBSUQsUUFBUTtBQUFBLElBQ1pFLGFBQWFYLEtBQUtXLGVBQWU7QUFBQSxJQUNqQ0MsV0FBV1osS0FBS1ksYUFBYTtBQUFBLElBQzdCQyxjQUFjYixLQUFLYSxnQkFBZ0I7QUFBQSxJQUNuQ0MsT0FBT2QsS0FBS2MsU0FBUztBQUFBLElBQ3JCQyxRQUFRZixLQUFLQyxVQUFVLGNBQWM7QUFBQSxJQUNyQ2UsWUFBWWhCLEtBQUtpQiwyQkFDYixJQUFJQyxLQUFLbEIsS0FBS2lCLHdCQUF3QixFQUFFRSxlQUFlLElBQ3ZEO0FBQUEsSUFDSkMsYUFBYXBCLEtBQUtxQix1QkFDZCxJQUFJSCxLQUFLbEIsS0FBS3FCLG9CQUFvQixFQUFFRixlQUFlLElBQ25EO0FBQUEsSUFDSkcsZ0JBQWdCdEIsS0FBS3NCLGtCQUFrQjtBQUFBLEVBQ3pDLEVBQUU7QUFFRixRQUFNQyxlQUFlaEIsVUFBVVIsT0FBTyxDQUFDQyxTQUFTO0FBQzlDLFVBQU13QixnQkFDSixDQUFDMUMsZ0JBQWdCa0IsS0FBS2UsV0FBV2pDO0FBRW5DLFVBQU0yQyxnQkFDSixDQUFDekMsVUFDRGdCLEtBQUtXLGFBQ0RlLFlBQVksRUFDYkMsU0FBUzNDLE9BQU8wQyxZQUFZLENBQUMsS0FDaEMxQixLQUFLWSxXQUNEYyxZQUFZLEVBQ2JDLFNBQVMzQyxPQUFPMEMsWUFBWSxDQUFDLEtBQ2hDMUIsS0FBS2MsT0FDRFksWUFBWSxFQUNiQyxTQUFTM0MsT0FBTzBDLFlBQVksQ0FBQztBQUVsQyxXQUFPRixpQkFBaUJDO0FBQUFBLEVBQzFCLENBQUM7QUFFRCxNQUFJN0MsU0FBUztBQUNYLFdBQU8sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlO0FBQUEsRUFDeEI7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNUSxNQUFNRTtBQUFBQSxRQUNaLE1BQU1GLE1BQU1HO0FBQUFBLFFBQ1osU0FBU0gsTUFBTUk7QUFBQUEsUUFDZixTQUFTLE1BQ1BILFNBQVMsRUFBRUMsTUFBTSxPQUFPQyxNQUFNLElBQUlDLFNBQVMsR0FBRyxDQUFDO0FBQUE7QUFBQSxNQUxuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNRztBQUFBLElBSUgsdUJBQUMsU0FBSSxXQUFVLGtFQUNiLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU1MLGFBQWEsY0FBYztBQUFBLFVBQzFDLFdBQVcsMEVBQ1RELGNBQWMsaUJBQ1YscUNBQ0EsaUNBQWlDO0FBQUEsVUFDcEM7QUFBQTtBQUFBLFFBTkw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BU0E7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU1DLGFBQWEsUUFBUTtBQUFBLFVBQ3BDLFdBQVcsMEVBQ1RELGNBQWMsV0FDVixxQ0FDQSxpQ0FBaUM7QUFBQSxVQUNwQztBQUFBO0FBQUEsUUFOTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFTQTtBQUFBLFNBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQkEsS0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdCQTtBQUFBLElBR0NBLGNBQWMsa0JBQ2IsbUNBRUU7QUFBQSw2QkFBQyxTQUFJLFdBQVUscUVBQ2IsaUNBQUMsU0FDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSxvQ0FBbUMsZ0RBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUEsdUJBQUMsT0FBRSxXQUFVLHNCQUFxQixvRUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxrRUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSwrQkFBOEIsdUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU07QUFDYkQsMEJBQVUsRUFBRTtBQUNaRixnQ0FBZ0IsRUFBRTtBQUFBLGNBQ3BCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FBdUQ7QUFBQTtBQUFBLFlBTG5FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBO0FBQUEsYUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FFYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLCtCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxhQUFZO0FBQUEsZ0JBQ1osT0FBT0M7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDNEMsTUFBTTNDLFVBQVUyQyxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsZ0JBQ3pDLFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS29IO0FBQUEsZUFWdEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLFVBR0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0MsbUNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBT2hEO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQzhDLE1BQU03QyxnQkFBZ0I2QyxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsZ0JBQy9DLFdBQVU7QUFBQSxnQkFFVjtBQUFBLHlDQUFDLFlBQU8sT0FBTSxJQUFHLDBCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQjtBQUFBLGtCQUMzQix1QkFBQyxZQUFPLE9BQU0sYUFBWSx5QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUM7QUFBQSxrQkFDbkMsdUJBQUMsWUFBTyxPQUFNLGlCQUFnQiw2QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkM7QUFBQTtBQUFBO0FBQUEsY0FQN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUE7QUFBQSxlQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxhQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0NBO0FBQUEsV0FqREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtEQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLDRGQUNiLGlDQUFDLFNBQUksV0FBVSwwREFDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxRQUFHLFdBQVUseUJBQXdCLHFDQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQSx1QkFBQyxPQUFFLFdBQVUsd0JBQ1ZoQztBQUFBQTtBQUFBQSxZQUFlO0FBQUEsWUFBS3BCLEtBQUt3QjtBQUFBQSxZQUFPO0FBQUEsZUFEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsbUNBQ1p4QjtBQUFBQSxlQUFLd0IsU0FBUyxJQUNYNkIsS0FBS0M7QUFBQUEsWUFDRmxDLGlCQUFpQnBCLEtBQUt3QixTQUFVO0FBQUEsVUFDbkMsSUFDQTtBQUFBLFVBQUU7QUFBQSxhQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQkEsS0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNCQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLDhDQUViO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGtFQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGtEQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThEO0FBQUEsVUFFOUQsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsbUNBQUMsU0FDQztBQUFBLHFDQUFDLE9BQUUsV0FBVSx5QkFBd0IsK0JBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVBLHVCQUFDLFFBQUcsV0FBVSx5Q0FDWHhCLGVBQUt3QixVQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUscUVBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFNO0FBQUEsZ0JBQ04sV0FBVTtBQUFBO0FBQUEsY0FGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFFMkIsS0FIN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLGVBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsYUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFCQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLGtFQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG1EQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStEO0FBQUEsVUFFL0QsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsbUNBQUMsU0FDQztBQUFBLHFDQUFDLE9BQUUsV0FBVSx5QkFBd0IseUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVBLHVCQUFDLFFBQUcsV0FBVSwwQ0FDWEosNEJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxzRUFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQU07QUFBQSxnQkFDTixXQUFVO0FBQUE7QUFBQSxjQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUU0QixLQUg5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQkE7QUFBQSxhQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUJBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsa0VBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsaURBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkQ7QUFBQSxVQUU3RCx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsT0FBRSxXQUFVLHlCQUF3Qiw2QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBRUEsdUJBQUMsUUFBRyxXQUFVLHdDQUNYSywrQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLG9FQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBTTtBQUFBLGdCQUNOLFdBQVU7QUFBQTtBQUFBLGNBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRTBCLEtBSDVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxlQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQTtBQUFBLGFBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxQkE7QUFBQSxXQXZFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0VBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsdUNBQXNDLGdDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQSx1QkFBQyxVQUFLLFdBQVUseUJBQ2JvQjtBQUFBQSx5QkFBYXJCO0FBQUFBLFlBQU87QUFBQSxlQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUVDcUIsYUFBYXJCLFNBQVMsSUFDckI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxNQUFNcUI7QUFBQUE7QUFBQUEsVUFGUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFcUIsSUFHckIsdUJBQUMsU0FBSSxXQUFVLG1EQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDRFQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNO0FBQUEsY0FDTixXQUFVO0FBQUE7QUFBQSxZQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUUyQixLQUg3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFFQSx1QkFBQyxRQUFHLFdBQVUsdUNBQXNDLDZCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQSx1QkFBQyxPQUFFLFdBQVUsa0NBQWlDLHdEQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsV0FFRXZDLFVBQVVGLGlCQUNWO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU07QUFDYkcsMEJBQVUsRUFBRTtBQUNaRixnQ0FBZ0IsRUFBRTtBQUFBLGNBQ3BCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FBb0U7QUFBQTtBQUFBLFlBTGhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBO0FBQUEsYUF6Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJCQTtBQUFBLFdBNUNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4Q0E7QUFBQSxTQXRORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdU5BO0FBQUEsSUFJREcsY0FBYyxZQUNiLHVCQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0I7QUFBQSxPQW5RdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFRQTtBQUVKO0FBQUNULEdBeldRRCx5QkFBdUI7QUFBQXlELEtBQXZCekQ7QUEyV1QsZUFBZUE7QUFBd0IsSUFBQXlEO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiYXBpIiwiRGF0YVRhYmxlIiwiQ3VzdG9tQWxlcnQiLCJDaXJjdWxhckxvYWRlciIsIkN1c3RvbWVyQXBwRXZlbnRzIiwiVXNlcnMiLCJDaGVja0NpcmNsZSIsIlhDaXJjbGUiLCJDdXN0b21lckFwcEluc3RhbGxhdGlvbiIsIl9zIiwiZGF0YSIsInNldERhdGEiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsInN0YXR1c0ZpbHRlciIsInNldFN0YXR1c0ZpbHRlciIsInNlYXJjaCIsInNldFNlYXJjaCIsImFjdGl2ZVRhYiIsInNldEFjdGl2ZVRhYiIsImFsZXJ0Iiwic2V0QWxlcnQiLCJzaG93IiwidHlwZSIsIm1lc3NhZ2UiLCJmZXRjaERhdGEiLCJyZXMiLCJnZXQiLCJlcnJvciIsInJlc3BvbnNlIiwiaW5zdGFsbGVkQ291bnQiLCJmaWx0ZXIiLCJpdGVtIiwidmVyZGljdCIsImxlbmd0aCIsIm5vdEluc3RhbGxlZENvdW50IiwiY29sdW1ucyIsImtleSIsImhlYWRlciIsInRhYmxlRGF0YSIsIm1hcCIsImluZGV4IiwiaWQiLCJjdXN0b21lcl9pZCIsImZ1bGxfbmFtZSIsInBob25lX251bWJlciIsImVtYWlsIiwic3RhdHVzIiwibGFzdF9sb2dpbiIsImxhc3Rfc3VjY2Vzc2Z1bF9sb2dpbl9hdCIsIkRhdGUiLCJ0b0xvY2FsZVN0cmluZyIsImxhc3RfZmFpbGVkIiwibGFzdF9mYWlsZWRfbG9naW5fYXQiLCJmYWlsdXJlX3JlYXNvbiIsImZpbHRlcmVkZGF0YSIsIm1hdGNoZXNTdGF0dXMiLCJtYXRjaGVzU2VhcmNoIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsIk1hdGgiLCJyb3VuZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkN1c3RvbWVyQXBwSW5zdGFsbGF0aW9uLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydCBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnRcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IEN1c3RvbWVyQXBwRXZlbnRzIGZyb20gXCIuL0N1c3RvbWVyQXBwRXZlbnRzXCI7XHJcbmltcG9ydCB7XHJcbiAgVXNlcnMsXHJcbiAgQ2hlY2tDaXJjbGUsXHJcbiAgWENpcmNsZSxcclxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcblxyXG5mdW5jdGlvbiBDdXN0b21lckFwcEluc3RhbGxhdGlvbigpIHtcclxuICBjb25zdCBbZGF0YSwgc2V0RGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzdGF0dXNGaWx0ZXIsIHNldFN0YXR1c0ZpbHRlcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VhcmNoLCBzZXRTZWFyY2hdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKFwiaW5zdGFsbGF0aW9uXCIpO1xyXG4gIGNvbnN0IFthbGVydCwgc2V0QWxlcnRdID0gdXNlU3RhdGUoe1xyXG4gICAgc2hvdzogZmFsc2UsXHJcbiAgICB0eXBlOiBcIlwiLFxyXG4gICAgbWVzc2FnZTogXCJcIixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgZmV0Y2hEYXRhID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgXCIvdjEvYWRtaW4vdXNlcnMvbW9iaWxlLWFwcC1pbnN0YWxsc1wiXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBzZXREYXRhKHJlcy5kYXRhPy5kYXRhIHx8IFtdKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNldEFsZXJ0KHtcclxuICAgICAgICBzaG93OiB0cnVlLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICBtZXNzYWdlOlxyXG4gICAgICAgICAgZXJyb3I/LnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8XHJcbiAgICAgICAgICBcIkZhaWxlZCB0byBmZXRjaCBpbnN0YWxsYXRpb24gcmVwb3J0XCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoRGF0YSgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgaW5zdGFsbGVkQ291bnQgPSBkYXRhLmZpbHRlcihcclxuICAgIChpdGVtKSA9PiBpdGVtLnZlcmRpY3QgPT09IHRydWVcclxuICApLmxlbmd0aDtcclxuXHJcbiAgY29uc3Qgbm90SW5zdGFsbGVkQ291bnQgPSBkYXRhLmZpbHRlcihcclxuICAgIChpdGVtKSA9PiBpdGVtLnZlcmRpY3QgPT09IGZhbHNlXHJcbiAgKS5sZW5ndGg7XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImN1c3RvbWVyX2lkXCIsIGhlYWRlcjogXCJDdXN0b21lciBJRFwiIH0sXHJcbiAgICB7IGtleTogXCJmdWxsX25hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwiZW1haWxcIiwgaGVhZGVyOiBcIkVtYWlsXCIgfSxcclxuICAgIHsga2V5OiBcInN0YXR1c1wiLCBoZWFkZXI6IFwiU3RhdHVzXCIgfSxcclxuICAgIHsga2V5OiBcImxhc3RfbG9naW5cIiwgaGVhZGVyOiBcIkxhc3QgTG9naW5cIiB9LFxyXG4gICAgeyBrZXk6IFwibGFzdF9mYWlsZWRcIiwgaGVhZGVyOiBcIkxhc3QgRmFpbGVkXCIgfSxcclxuICAgIHsga2V5OiBcImZhaWx1cmVfcmVhc29uXCIsIGhlYWRlcjogXCJSZWFzb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IHRhYmxlRGF0YSA9IGRhdGEubWFwKChpdGVtLCBpbmRleCkgPT4gKHtcclxuICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICBjdXN0b21lcl9pZDogaXRlbS5jdXN0b21lcl9pZCB8fCBcIi1cIixcclxuICAgIGZ1bGxfbmFtZTogaXRlbS5mdWxsX25hbWUgfHwgXCItXCIsXHJcbiAgICBwaG9uZV9udW1iZXI6IGl0ZW0ucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgZW1haWw6IGl0ZW0uZW1haWwgfHwgXCItXCIsXHJcbiAgICBzdGF0dXM6IGl0ZW0udmVyZGljdCA/IFwiSW5zdGFsbGVkXCIgOiBcIk5vdCBJbnN0YWxsZWRcIixcclxuICAgIGxhc3RfbG9naW46IGl0ZW0ubGFzdF9zdWNjZXNzZnVsX2xvZ2luX2F0XHJcbiAgICAgID8gbmV3IERhdGUoaXRlbS5sYXN0X3N1Y2Nlc3NmdWxfbG9naW5fYXQpLnRvTG9jYWxlU3RyaW5nKClcclxuICAgICAgOiBcIi1cIixcclxuICAgIGxhc3RfZmFpbGVkOiBpdGVtLmxhc3RfZmFpbGVkX2xvZ2luX2F0XHJcbiAgICAgID8gbmV3IERhdGUoaXRlbS5sYXN0X2ZhaWxlZF9sb2dpbl9hdCkudG9Mb2NhbGVTdHJpbmcoKVxyXG4gICAgICA6IFwiLVwiLFxyXG4gICAgZmFpbHVyZV9yZWFzb246IGl0ZW0uZmFpbHVyZV9yZWFzb24gfHwgXCItXCIsXHJcbiAgfSkpO1xyXG5cclxuICBjb25zdCBmaWx0ZXJlZGRhdGEgPSB0YWJsZURhdGEuZmlsdGVyKChpdGVtKSA9PiB7XHJcbiAgICBjb25zdCBtYXRjaGVzU3RhdHVzID1cclxuICAgICAgIXN0YXR1c0ZpbHRlciB8fCBpdGVtLnN0YXR1cyA9PT0gc3RhdHVzRmlsdGVyO1xyXG5cclxuICAgIGNvbnN0IG1hdGNoZXNTZWFyY2ggPVxyXG4gICAgICAhc2VhcmNoIHx8XHJcbiAgICAgIGl0ZW0uY3VzdG9tZXJfaWRcclxuICAgICAgICA/LnRvTG93ZXJDYXNlKClcclxuICAgICAgICAuaW5jbHVkZXMoc2VhcmNoLnRvTG93ZXJDYXNlKCkpIHx8XHJcbiAgICAgIGl0ZW0uZnVsbF9uYW1lXHJcbiAgICAgICAgPy50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgLmluY2x1ZGVzKHNlYXJjaC50b0xvd2VyQ2FzZSgpKSB8fFxyXG4gICAgICBpdGVtLmVtYWlsXHJcbiAgICAgICAgPy50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgLmluY2x1ZGVzKHNlYXJjaC50b0xvd2VyQ2FzZSgpKTtcclxuXHJcbiAgICByZXR1cm4gbWF0Y2hlc1N0YXR1cyAmJiBtYXRjaGVzU2VhcmNoO1xyXG4gIH0pO1xyXG5cclxuICBpZiAobG9hZGluZykge1xyXG4gICAgcmV0dXJuIDxDaXJjdWxhckxvYWRlciAvPjtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBiZy1ncmF5LTUwIG1pbi1oLXNjcmVlblwiPlxyXG4gICAgICA8Q3VzdG9tQWxlcnRcclxuICAgICAgICBzaG93PXthbGVydC5zaG93fVxyXG4gICAgICAgIHR5cGU9e2FsZXJ0LnR5cGV9XHJcbiAgICAgICAgbWVzc2FnZT17YWxlcnQubWVzc2FnZX1cclxuICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgc2V0QWxlcnQoeyBzaG93OiBmYWxzZSwgdHlwZTogXCJcIiwgbWVzc2FnZTogXCJcIiB9KVxyXG4gICAgICAgIH1cclxuICAgICAgLz5cclxuXHJcbiAgICAgIHsvKiBUYWJzICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy1tZCBib3JkZXIgYm9yZGVyLWdyYXktMTAwIHAtMiBtYi02XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoXCJpbnN0YWxsYXRpb25cIil9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTUgcHktMyByb3VuZGVkLXhsIHRleHQtc20gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgJHtcclxuICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09IFwiaW5zdGFsbGF0aW9uXCJcclxuICAgICAgICAgICAgICAgID8gXCJiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZFwiXHJcbiAgICAgICAgICAgICAgICA6IFwidGV4dC1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTEwMFwiXHJcbiAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBBcHAgSW5zdGFsbGF0aW9uXHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYihcImV2ZW50c1wiKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNSBweS0zIHJvdW5kZWQteGwgdGV4dC1zbSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCAke1xyXG4gICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gXCJldmVudHNcIlxyXG4gICAgICAgICAgICAgICAgPyBcImJnLWJsdWUtNjAwIHRleHQtd2hpdGUgc2hhZG93LW1kXCJcclxuICAgICAgICAgICAgICAgIDogXCJ0ZXh0LWdyYXktNjAwIGhvdmVyOmJnLWdyYXktMTAwXCJcclxuICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIEN1c3RvbWVyIEFwcCBFdmVudHNcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBBcHAgSW5zdGFsbGF0aW9uIFRhYiAqL31cclxuICAgICAge2FjdGl2ZVRhYiA9PT0gXCJpbnN0YWxsYXRpb25cIiAmJiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgIHsvKiBIZWFkZXIgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cgbWQ6aXRlbXMtY2VudGVyIG1kOmp1c3RpZnktYmV0d2VlbiBtYi02XCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICBDdXN0b21lciBBcHAgSW5zdGFsbGF0aW9uIFJlcG9ydFxyXG4gICAgICAgICAgICAgIDwvaDE+XHJcblxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgVHJhY2sgY3VzdG9tZXIgYXBwIGluc3RhbGxhdGlvbnMgYW5kIGxvZ2luIGFjdGl2aXR5LlxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogRmlsdGVycyAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LW1kIGJvcmRlciBib3JkZXItZ3JheS0xMDAgcC01IG1iLTZcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgIEZpbHRlcnNcclxuICAgICAgICAgICAgICA8L2gzPlxyXG5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIHNldFNlYXJjaChcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgc2V0U3RhdHVzRmlsdGVyKFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ibHVlLTYwMCBob3Zlcjp0ZXh0LWJsdWUtODAwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBDbGVhciBGaWx0ZXJzXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgey8qIFNlYXJjaCAqL31cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIFNlYXJjaCBDdXN0b21lclxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkN1c3RvbWVyIElELCBOYW1lLCBFbWFpbC4uLlwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2h9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC14bCBweC00IHB5LTMgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBTdGF0dXMgKi99XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICBJbnN0YWxsYXRpb24gU3RhdHVzXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3N0YXR1c0ZpbHRlcn1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTdGF0dXNGaWx0ZXIoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLXhsIHB4LTQgcHktMyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+QWxsIFN0YXR1czwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiSW5zdGFsbGVkXCI+SW5zdGFsbGVkPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJOb3QgSW5zdGFsbGVkXCI+Tm90IEluc3RhbGxlZDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIE92ZXJ2aWV3IEJhbm5lciAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLWluZGlnby01MDAgdG8tcHVycGxlLTYwMCByb3VuZGVkLTJ4bCBwLTYgdGV4dC13aGl0ZSBzaGFkb3ctbGcgbWItNlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgIEluc3RhbGxhdGlvbiBPdmVydmlld1xyXG4gICAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWluZGlnby0xMDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICB7aW5zdGFsbGVkQ291bnR9IG9mIHtkYXRhLmxlbmd0aH0gY3VzdG9tZXJzIGhhdmVcclxuICAgICAgICAgICAgICAgICAgaW5zdGFsbGVkIHRoZSBtb2JpbGUgYXBwbGljYXRpb24uXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC01eGwgZm9udC1ib2xkIG10LTQgbWQ6bXQtMFwiPlxyXG4gICAgICAgICAgICAgICAge2RhdGEubGVuZ3RoID4gMFxyXG4gICAgICAgICAgICAgICAgICA/IE1hdGgucm91bmQoXHJcbiAgICAgICAgICAgICAgICAgICAgICAoaW5zdGFsbGVkQ291bnQgLyBkYXRhLmxlbmd0aCkgKiAxMDBcclxuICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgIDogMH1cclxuICAgICAgICAgICAgICAgICVcclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogU3RhdHMgQ2FyZHMgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTYgbWItNlwiPlxyXG4gICAgICAgICAgICB7LyogVG90YWwgQ3VzdG9tZXJzICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiBiZy13aGl0ZSByb3VuZGVkLTJ4bCBzaGFkb3ctbWQgYm9yZGVyXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMCBsZWZ0LTAgaC0xIHctZnVsbCBiZy1ibHVlLTUwMFwiPjwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFRvdGFsIEN1c3RvbWVyc1xyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC00eGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDAgbXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtkYXRhLmxlbmd0aH1cclxuICAgICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNCBoLTE0IHJvdW5kZWQteGwgYmctYmx1ZS0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPFVzZXJzXHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT17Mjh9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogSW5zdGFsbGVkICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiBiZy13aGl0ZSByb3VuZGVkLTJ4bCBzaGFkb3ctbWQgYm9yZGVyXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMCBsZWZ0LTAgaC0xIHctZnVsbCBiZy1ncmVlbi01MDBcIj48L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICBJbnN0YWxsZWRcclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtNHhsIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTYwMCBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2luc3RhbGxlZENvdW50fVxyXG4gICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE0IGgtMTQgcm91bmRlZC14bCBiZy1ncmVlbi0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlXHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT17Mjh9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIE5vdCBJbnN0YWxsZWQgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIGJnLXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy1tZCBib3JkZXJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0wIGxlZnQtMCBoLTEgdy1mdWxsIGJnLXJlZC01MDBcIj48L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICBOb3QgSW5zdGFsbGVkXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBmb250LWJvbGQgdGV4dC1yZWQtNjAwIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICB7bm90SW5zdGFsbGVkQ291bnR9XHJcbiAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTQgaC0xNCByb3VuZGVkLXhsIGJnLXJlZC0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPFhDaXJjbGVcclxuICAgICAgICAgICAgICAgICAgICBzaXplPXsyOH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIFRhYmxlIENhcmQgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy1tZCBib3JkZXIgYm9yZGVyLWdyYXktMTAwIHAtNFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi00XCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICBDdXN0b21lciBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICB7ZmlsdGVyZWRkYXRhLmxlbmd0aH0gUmVjb3Jkc1xyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7ZmlsdGVyZWRkYXRhLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlcmVkZGF0YX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktMTZcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0yMCBoLTIwIHJvdW5kZWQtZnVsbCBiZy1ncmF5LTEwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxYQ2lyY2xlXHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT17NDB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgTm8gRGF0YSBGb3VuZFxyXG4gICAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIG10LTIgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgTm8gY3VzdG9tZXJzIG1hdGNoIHRoZSBzZWxlY3RlZCBmaWx0ZXJzLlxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgIHsoc2VhcmNoIHx8IHN0YXR1c0ZpbHRlcikgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0U2VhcmNoKFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0U3RhdHVzRmlsdGVyKFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtNCBweC00IHB5LTIgYmctYmx1ZS02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIGhvdmVyOmJnLWJsdWUtNzAwXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIENsZWFyIEZpbHRlcnNcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC8+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogQ3VzdG9tZXIgQXBwIEV2ZW50cyBUYWIgKi99XHJcbiAgICAgIHthY3RpdmVUYWIgPT09IFwiZXZlbnRzXCIgJiYgKFxyXG4gICAgICAgIDxDdXN0b21lckFwcEV2ZW50cyAvPlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ3VzdG9tZXJBcHBJbnN0YWxsYXRpb247Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0N1c3RvbWVyQXBwSW5zdGFsbGF0aW9uLmpzeCJ9