import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/IndividualRegistrationChitPaymentLink.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import Modal from "/src/components/modals/Modal.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Dropdown, Modal as AntModal, Alert } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import BackdropBlurLoader from "/src/components/loaders/BackdropBlurLoader.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const IndividualRegistrationChitPaymentLink = () => {
  _s();
  const [groups, setGroups] = useState([]);
  const [actualGroups, setActualGroups] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState("");
  const [TablePayments, setTablePayments] = useState([]);
  const [selectedAuctionGroup, setSelectedAuctionGroup] = useState("");
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [selectedAuctionGroupId, setSelectedAuctionGroupId] = useState("");
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [viewLoader, setViewLoader] = useState(false);
  const [filteredAuction, setFilteredAuction] = useState([]);
  const [groupInfo, setGroupInfo] = useState({});
  const [showModal, setShowModal] = useState(false);
  const [showModalView, setShowModalView] = useState(false);
  const [currentViewGroup, setCurrentViewGroup] = useState(null);
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const tomorrow = /* @__PURE__ */ new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowFormatted = tomorrow.toISOString().split("T")[0];
  const [isLoading, setIsLoading] = useState(false);
  const [loading, setLoading] = useState(false);
  const [disabled, setDisabled] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [borrowers, setBorrowers] = useState([]);
  const [pigmeCustomers, setPigmeCustomers] = useState([]);
  const [enableGroupColumn, setEnableGroupColumn] = useState(true);
  const [paymentGroupTickets, setPaymentGroupTickets] = useState([]);
  const [render, setRerender] = useState(0);
  const [openBackdropLoader, setOpenBackdropLoader] = useState(false);
  const [currentGroupId, setCurrentGroupId] = useState(null);
  const [alert, setAlert] = useState({
    visible: false,
    message: "",
    type: "info"
  });
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const dropDownItems = (group) => {
    const dropDownItemList = [
      {
        key: "1",
        label: /* @__PURE__ */ jsxDEV(Link, { to: `/print/${group._id}`, className: "text-violet-600 ", children: "Print" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
          lineNumber: 69,
          columnNumber: 7
        }, this)
      },
      {
        key: "3",
        label: /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "text-green-600",
            onClick: () => handleViewModalOpen(group._id),
            children: "View"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
            lineNumber: 77,
            columnNumber: 7
          },
          this
        )
      }
    ];
    return dropDownItemList;
  };
  const GlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    user_id: "",
    amount: "",
    payment_group_tickets: [],
    expiry: tomorrowFormatted,
    // Use the correctly calculated tomorrow
    send_sms: true,
    send_email: true
  });
  useEffect(() => {
    const usr = localStorage.getItem("user");
    let admin_type = null;
    try {
      if (usr) {
        admin_type = JSON.parse(usr);
      }
    } catch (e) {
      console.error("Failed to parse user from localStorage:", e);
    }
    const fetchTodaysPayments = async () => {
      try {
        setTablePayments([]);
        setIsLoading(true);
        const response = await api.get("/paymentapi/payment-link/registration/", {
          params: {
            from_date: today,
            to_date: today
          }
        });
        if (response.data && response.data.length > 0) {
          const formattedData = response.data.map((group, index) => {
            if (!group?.group_id?.group_name) return {};
            return {
              _id: group._id,
              id: index + 1,
              name: group?.user_id?.full_name,
              phone_number: group?.user_id?.phone_number,
              group_name: group?.group_id?.group_name,
              ticket: group.ticket,
              amount: group.amount,
              payment_status: group.payment_status,
              transaction_date: formatPayDate(group.createdAt),
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  trigger: ["click"],
                  menu: {
                    items: dropDownItems(group)
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                    lineNumber: 148,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                  lineNumber: 141,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 140,
                columnNumber: 15
              }, this)
            };
          });
          setTablePayments(formattedData);
          setEnableGroupColumn(true);
        } else {
          setFilteredAuction([]);
        }
      } catch (error) {
        console.error("Error fetching payment Link data:", error);
        setFilteredAuction([]);
        setAlert({
          visible: true,
          message: "Failed to load payment data",
          type: "error"
        });
      } finally {
        setIsLoading(false);
      }
    };
    fetchTodaysPayments();
  }, [render]);
  useEffect(() => {
    setBorrowers([]);
    const fetchCustomerLoanDetails = async () => {
      try {
        const response = await api.get(
          `/loans/get-borrower-by-user-id/${selectedGroupId}`
        );
        if (response.status >= 400)
          throw new Error("fetching loan borrowers Failed");
        setBorrowers(response.data);
      } catch (err) {
        console.log("Error Occurred");
      }
    };
    fetchCustomerLoanDetails();
  }, [selectedGroupId]);
  useEffect(() => {
    setPigmeCustomers([]);
    const fetchCustomerLoanDetails = async () => {
      try {
        const response = await api.get(
          `/pigme/get-pigme-customer-by-user-id/${selectedGroupId}`
        );
        if (response.status >= 400)
          throw new Error("fetching pigme customers Failed");
        setPigmeCustomers(response.data);
      } catch (err) {
        console.log(
          "Error Occurred while fetching pigme customers,",
          err.message
        );
      }
    };
    fetchCustomerLoanDetails();
  }, [selectedGroupId]);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/user/get-user");
        setGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setActualGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  const validateForm = () => {
    const newErrors = {};
    if (!selectedGroupId) {
      newErrors.customer = "Please select a customer";
    }
    if (!paymentGroupTickets || paymentGroupTickets.length === 0) {
      newErrors.payment_group_tickets = "Please select a group and ticket";
    }
    const amount = parseFloat(formData.amount);
    if (isNaN(amount) || amount <= 0) {
      newErrors.amount = "Please enter a valid positive amount";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevData) => ({ ...prevData, [name]: "" }));
  };
  const handlePaymentAntSelect = (values) => {
    setPaymentGroupTickets(values);
  };
  const handleGroupChange = async (groupId) => {
    setSelectedGroup(groupId);
    if (groupId) {
      try {
        const response = await api.get(`/enroll/get-group-enroll/${groupId}`);
        if (response.data && response.data.length > 0) {
          setFilteredUsers(response.data);
        } else {
          setFilteredUsers([]);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredUsers([]);
      }
    } else {
      setFilteredUsers([]);
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Customer Phone Number" }
  ];
  if (enableGroupColumn) {
    columns.push({ key: "group_name", header: "Group Name" });
  }
  columns.push(
    { key: "ticket", header: "Ticket Number" },
    { key: "amount", header: "Amount" },
    { key: "payment_status", header: "Payment Status" },
    { key: "action", header: "Action" }
  );
  const handleCustomer = async (groupId) => {
    setSelectedGroupId(groupId);
    setFormData((prevFormData) => ({
      ...prevFormData,
      user_id: groupId
    }));
    setErrors((prevData) => ({ ...prevData, customer: "" }));
    setPaymentGroupTickets([]);
    handleGroupChange(groupId);
    handleGroupAuctionChange(groupId);
    if (groupId) {
      try {
        const response = await api.get(`/group/get-by-id-group/${groupId}`);
        setGroupInfo(response.data || {});
      } catch (error) {
        setGroupInfo({});
      }
    } else {
      setGroupInfo({});
    }
  };
  const handleGroupPayment = async (groupId) => {
    setSelectedAuctionGroupId(groupId);
    handleGroupPaymentChange(groupId);
  };
  const formatPayDate = (dateString) => {
    return dateString?.split("T")[0];
  };
  const handleGroupPaymentChange = async (groupId) => {
    setSelectedAuctionGroup(groupId);
    if (groupId) {
      let url;
      if (groupId === "today") {
        url = `/paymentapi/payment-link/registration/get-payments?from_date=${today}&to_date=${today}`;
        setEnableGroupColumn(true);
      } else {
        url = `/paymentapi/payment-link/registration/${groupId}`;
        setEnableGroupColumn(false);
      }
      try {
        setTablePayments([]);
        setIsLoading(true);
        const response = await api.get(url);
        if (response.data && response.data.length > 0) {
          const formattedData = response.data.map((group, index) => {
            if (!group?.group_id?.group_name) return {};
            return {
              _id: group._id,
              id: index + 1,
              name: group?.user_id?.full_name,
              phone_number: group?.user_id?.phone_number,
              group_name: group?.group_id?.group_name,
              ticket: group.ticket,
              amount: group.amount,
              transaction_date: group?.createdAt?.split("T")[0],
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  trigger: ["click"],
                  menu: {
                    items: dropDownItems(group)
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                    lineNumber: 377,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                  lineNumber: 370,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 369,
                columnNumber: 15
              }, this)
            };
          });
          setTablePayments(formattedData);
        } else {
          setFilteredAuction([]);
        }
      } catch (error) {
        console.error("Error fetching payment data:", error);
        setFilteredAuction([]);
        setAlert({
          visible: true,
          message: "Failed to load payment data",
          type: "error"
        });
      } finally {
        setIsLoading(false);
      }
    } else {
      setFilteredAuction([]);
    }
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    try {
      if (isValid) {
        setDisabled(true);
        setAlert({ visible: false, message: "", type: "info" });
        setShowModal(false);
        let payload;
        const usr = localStorage.getItem("user");
        let admin_type = null;
        try {
          if (usr) {
            admin_type = JSON.parse(usr);
          }
        } catch (e2) {
          console.error("Failed to parse user from localStorage:", e2);
        }
        formData.payment_group_tickets = paymentGroupTickets;
        formData.admin_type = admin_type?._id;
        setOpenBackdropLoader(true);
        const response = await api.post("/paymentapi/payment-link/registration", formData);
        if (response.status === 201) {
          setSelectedGroupId("");
          setPaymentGroupTickets([]);
          setDisabled(false);
          setFormData({
            user_id: "",
            amount: "",
            payment_group_tickets: [],
            expiry: tomorrowFormatted,
            // Reset with correct tomorrow date
            send_sms: true,
            send_email: true
          });
          setAlert({
            visible: true,
            message: "Payment Added Successfully",
            type: "success"
          });
        }
        if (response.status >= 400) {
          setShowModal(false);
          setSelectedGroupId("");
          setPaymentGroupTickets([]);
          setDisabled(false);
          setFormData({
            user_id: "",
            amount: "",
            payment_group_tickets: [],
            expiry: tomorrowFormatted,
            // Reset with correct tomorrow date
            send_sms: true,
            send_email: true
          });
          setAlert({
            visible: true,
            message: "Payment Added Failed",
            type: "error"
          });
        }
      }
    } catch (error) {
      setShowModal(false);
      setSelectedGroupId("");
      setFormData({
        user_id: "",
        amount: "",
        payment_group_tickets: [],
        expiry: tomorrowFormatted,
        // Reset with correct tomorrow date
        send_sms: true,
        send_email: true
      });
      setAlert({
        visible: true,
        message: `Error submitting payment data: ${error.message}`,
        type: "error"
      });
      setDisabled(false);
      console.error("Error submitting payment data:", error);
    } finally {
      setOpenBackdropLoader(false);
      setRerender((prev) => prev + 1);
    }
  };
  const handleViewModalOpen = async (groupId) => {
    try {
      setLoading(true);
      setShowModalView(true);
      setCurrentGroupId(groupId);
      setViewLoader(true);
      const response = await api.get(`/paymentapi/payment-link/registration/${groupId}`);
      setCurrentViewGroup(response.data);
    } catch (error) {
      console.error("Error viewing Payment:", error);
      setAlert({
        visible: true,
        message: "Failed to load payment details",
        type: "error"
      });
    } finally {
      setLoading(false);
      setViewLoader(false);
    }
  };
  const handleGroupAuctionChange = async (groupId) => {
    if (groupId) {
      try {
        const response = await api.post(
          `/enroll/get-user-tickets-report/${groupId}`
        );
        if (response.data && response.data.length > 0) {
          const validAuctions = response.data.filter(
            (auction) => auction.enrollment && auction.enrollment.group
          );
          setFilteredAuction(validAuctions);
        } else {
          setFilteredAuction([]);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredAuction([]);
        setAlert({
          visible: true,
          message: "Failed to load group auction data",
          type: "error"
        });
      }
    } else {
      setFilteredAuction([]);
    }
  };
  const selectednewGroup = actualGroups.find(
    (g) => g._id === selectedAuctionGroupId
  );
  return /* @__PURE__ */ jsxDEV(Fragment, { children: openBackdropLoader ? /* @__PURE__ */ jsxDEV(BackdropBlurLoader, { title: "payment Data processing...." }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
    lineNumber: 546,
    columnNumber: 7
  }, this) : /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
      lineNumber: 550,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: GlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
        lineNumber: 551,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
        lineNumber: 555,
        columnNumber: 11
      },
      this
    ),
    alert.visible && /* @__PURE__ */ jsxDEV("div", { className: "fixed top-4 right-4 z-50 w-96", children: /* @__PURE__ */ jsxDEV(
      Alert,
      {
        message: alert.message,
        type: alert.type,
        showIcon: true,
        closable: true,
        onClose: () => setAlert({ ...alert, visible: false })
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
        lineNumber: 567,
        columnNumber: 17
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
      lineNumber: 566,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
        lineNumber: 578,
        columnNumber: 18
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Registration Payment Links" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
        lineNumber: 579,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6  mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-10", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "font-bold", children: "Search or Select Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
            lineNumber: 582,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                placeholder: "Today's Payment",
                popupMatchSelectWidth: false,
                showSearch: true,
                className: "w-full   h-14 max-w-md",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                value: selectedAuctionGroupId || void 0,
                onChange: handleGroupPayment,
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "today", children: "Today's Payments" }, "#1", false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                    lineNumber: 598,
                    columnNumber: 23
                  }, this),
                  actualGroups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                      lineNumber: 602,
                      columnNumber: 21
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 584,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setShowModal(true),
                className: "ml-4 bg-violet-600 text-white px-4 py-2 rounded shadow-md hover:bg-violet-800 transition duration-200",
                children: "+ Add Payment Link"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 608,
                columnNumber: 23
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 607,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
            lineNumber: 583,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
          lineNumber: 581,
          columnNumber: 17
        }, this),
        TablePayments && TablePayments.length > 0 ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: TablePayments.filter(
              (item) => Object.values(item).some(
                (value) => String(value).toLowerCase().includes(searchText.toLowerCase())
              )
            ),
            columns,
            exportedPdfName: "Payments",
            printHeaderKeys: ["Group Name"],
            printHeaderValues: [
              selectednewGroup?.group_name || "Today's"
            ],
            exportedFileName: `Payments.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
            lineNumber: 619,
            columnNumber: 15
          },
          this
        ) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10 text-center text-gray-500", children: /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            data: "Payments Data",
            failure: TablePayments.length <= 0 && selectedAuctionGroupId
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
            lineNumber: 637,
            columnNumber: 21
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
          lineNumber: 636,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
        lineNumber: 580,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
      lineNumber: 577,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModal,
        onClose: () => {
          setSelectedGroupId("");
          setShowModal(false);
          setErrors({});
          setPaymentGroupTickets([]);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-6 text-xl font-bold text-gray-900 border-b pb-2", children: "Add Payment Link" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
            lineNumber: 659,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  htmlFor: "customer",
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  children: [
                    "Customer ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                      lineNumber: 669,
                      columnNumber: 32
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                  lineNumber: 665,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  id: "customer",
                  className: `bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg w-full ${fieldSize.height}`,
                  placeholder: "Select or Search Customer",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  filterOption: (input, option) => option?.children?.toString().toLowerCase().includes(input.toLowerCase()),
                  value: selectedGroupId || void 0,
                  onChange: handleCustomer,
                  children: groups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: `${group.full_name} | ${group.phone_number}` }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                      lineNumber: 687,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                  lineNumber: 671,
                  columnNumber: 21
                },
                this
              ),
              errors.customer && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-red-500", children: errors.customer }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 693,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 664,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  htmlFor: "group-ticket",
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  children: [
                    "Group & Ticket ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                      lineNumber: 704,
                      columnNumber: 38
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                  lineNumber: 700,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  id: "group-ticket",
                  mode: "multiple",
                  placeholder: "Select Group | Ticket",
                  onChange: handlePaymentAntSelect,
                  value: paymentGroupTickets,
                  className: `bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full ${fieldSize.height}`,
                  children: [
                    filteredAuction.map((entry, index) => {
                      const groupName = entry?.enrollment?.group?.group_name || "Unnamed Group";
                      const groupId = entry?.enrollment?.group?._id || `missing-${index}`;
                      const ticket = entry?.enrollment?.tickets || "Unknown";
                      return /* @__PURE__ */ jsxDEV(
                        Select.Option,
                        {
                          value: `chit-${groupId}|${ticket}`,
                          children: [
                            groupName,
                            " | ",
                            ticket
                          ]
                        },
                        `chit-${groupId}|${ticket}`,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                          lineNumber: 722,
                          columnNumber: 25
                        },
                        this
                      );
                    }),
                    pigmeCustomers?.map(
                      (pigme) => /* @__PURE__ */ jsxDEV(
                        Select.Option,
                        {
                          value: `pigme-${pigme._id}`,
                          children: `${pigme.pigme_id} | ₹ ${pigme.payable_amount}`
                        },
                        pigme._id,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                          lineNumber: 731,
                          columnNumber: 21
                        },
                        this
                      )
                    ),
                    borrowers?.map(
                      (borrower) => /* @__PURE__ */ jsxDEV(
                        Select.Option,
                        {
                          value: `loan-${borrower._id}`,
                          children: `loan-${borrower.loan_id} | ₹ ${borrower.loan_amount}`
                        },
                        borrower._id,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                          lineNumber: 739,
                          columnNumber: 21
                        },
                        this
                      )
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                  lineNumber: 706,
                  columnNumber: 21
                },
                this
              ),
              errors.payment_group_tickets && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-red-500", children: errors.payment_group_tickets }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 748,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 699,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col space-y-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    htmlFor: "amount",
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    children: [
                      "Amount ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                        lineNumber: 760,
                        columnNumber: 32
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                    lineNumber: 756,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    id: "amount",
                    type: "number",
                    name: "amount",
                    value: formData.amount,
                    onChange: handleChange,
                    placeholder: "Enter Amount",
                    required: true,
                    className: "flex-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                    lineNumber: 763,
                    columnNumber: 25
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                  lineNumber: 762,
                  columnNumber: 23
                }, this),
                errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-red-500", children: errors.amount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                  lineNumber: 775,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 755,
                columnNumber: 21
              }, this),
              formData.amount && paymentGroupTickets.length > 1 && /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Individual Ticket Amount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                  lineNumber: 783,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    className: "w-full bg-gray-100 border border-gray-300 text-gray-700 text-sm rounded-lg p-2.5 cursor-not-allowed",
                    placeholder: "Total Amount",
                    value: (Number(formData.amount) / paymentGroupTickets.length).toFixed(2),
                    disabled: true
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                    lineNumber: 786,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 782,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 754,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  htmlFor: "expiry",
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  children: "Expiry Date"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                  lineNumber: 800,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  id: "expiry",
                  type: "date",
                  name: "expiry",
                  min: tomorrowFormatted,
                  value: formData.expiry,
                  onChange: handleChange,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                  lineNumber: 806,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 799,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  id: "send_sms",
                  type: "checkbox",
                  name: "send_sms",
                  checked: formData.send_sms,
                  onChange: (e) => setFormData((prev) => ({
                    ...prev,
                    send_sms: e.target.checked
                  })),
                  className: "w-4 h-4 border border-gray-300 rounded bg-gray-50"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                  lineNumber: 819,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  htmlFor: "send_sms",
                  className: "ml-2 text-sm font-medium text-gray-900",
                  children: "Send SMS"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                  lineNumber: 832,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 818,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  id: "send_email",
                  type: "checkbox",
                  name: "send_email",
                  checked: formData.send_email,
                  onChange: (e) => setFormData((prev) => ({
                    ...prev,
                    send_email: e.target.checked
                  })),
                  className: "w-4 h-4 border border-gray-300 rounded bg-gray-50"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                  lineNumber: 842,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  htmlFor: "send_email",
                  className: "ml-2 text-sm font-medium text-gray-900",
                  children: "Send Email"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                  lineNumber: 855,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 841,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-4", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 active:bg-violet-900 \r\n                   border-2 border-violet-700 focus:ring-4 focus:outline-none focus:ring-violet-300 \r\n                   font-medium rounded-lg text-sm px-5 py-2.5 transition-colors duration-200",
                children: "Add Payment Link"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 864,
                columnNumber: 21
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 863,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
            lineNumber: 663,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
          lineNumber: 658,
          columnNumber: 15
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
        lineNumber: 649,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      AntModal,
      {
        open: showModalView,
        onCancel: () => setShowModalView(false),
        onClose: () => setShowModalView(false),
        onOk: () => setShowModalView(false),
        onReload: () => handleViewModalOpen(currentGroupId),
        footer: /* @__PURE__ */ jsxDEV("div", {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
          lineNumber: 883,
          columnNumber: 21
        }, this),
        loading: viewLoader,
        children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Payment Details" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
            lineNumber: 886,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Group: " }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 891,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.group_id?.group_name
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 890,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Group Value:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 895,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.group_id?.group_value
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 894,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Group Installment:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 899,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.group_id?.group_install
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 898,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "User:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 903,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.user_id?.full_name,
              " ",
              "| Ticket: ",
              currentViewGroup?.ticket
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 902,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Bid Amount:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 907,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.group_id?.group_value - currentViewGroup?.win_amount ? currentViewGroup?.group_id?.group_value - currentViewGroup?.win_amount : ""
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 906,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Commission:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 915,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.commission
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 914,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Winning Amount:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 918,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.win_amount
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 917,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Divident:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 922,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.divident
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 921,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Divident per Head:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 925,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.divident_head
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 924,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Next Payable:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 929,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.payable
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 928,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Auction Date:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 932,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.auction_date
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 931,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Next Date:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 936,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.next_date
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 935,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Created At:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 939,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.createdAt?.split("T")[0]
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 938,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Updated At:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
                lineNumber: 943,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.updatedAt?.split("T")[0]
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
              lineNumber: 942,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
            lineNumber: 889,
            columnNumber: 15
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
        lineNumber: 877,
        columnNumber: 13
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
    lineNumber: 549,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
    lineNumber: 548,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx",
    lineNumber: 544,
    columnNumber: 5
  }, this);
};
_s(IndividualRegistrationChitPaymentLink, "t8iQ59ZWGJSzuQEIcUXyWmns31M=");
_c = IndividualRegistrationChitPaymentLink;
export default IndividualRegistrationChitPaymentLink;
var _c;
$RefreshReg$(_c, "IndividualRegistrationChitPaymentLink");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualRegistrationChitPaymentLink.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0VVLFNBMmROLFVBM2RNOzJCQXBFVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLFNBQVNBLFdBQVdDLGdCQUFnQjtBQUNwQyxPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLFFBQVFDLFVBQVVMLFNBQVNNLFVBQVVDLGFBQWE7QUFDM0QsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFlBQVk7QUFDckIsT0FBT0Msd0JBQXdCO0FBQy9CLFNBQVNDLGlCQUFpQjtBQUMxQixPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0MsZ0JBQWdCO0FBRXZCLE1BQU1DLHdDQUF3Q0EsTUFBTTtBQUFBQyxLQUFBO0FBQ2xELFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJcEIsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ3FCLGNBQWNDLGVBQWUsSUFBSXRCLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUN1QixlQUFlQyxnQkFBZ0IsSUFBSXhCLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUN5QixlQUFlQyxnQkFBZ0IsSUFBSTFCLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUMyQixzQkFBc0JDLHVCQUF1QixJQUFJNUIsU0FBUyxFQUFFO0FBQ25FLFFBQU0sQ0FBQzZCLGlCQUFpQkMsa0JBQWtCLElBQUk5QixTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDK0Isd0JBQXdCQyx5QkFBeUIsSUFBSWhDLFNBQVMsRUFBRTtBQUN2RSxRQUFNLENBQUNpQyxlQUFlQyxnQkFBZ0IsSUFBSWxDLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNtQyxZQUFZQyxhQUFhLElBQUlwQyxTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDcUMsaUJBQWlCQyxrQkFBa0IsSUFBSXRDLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUN1QyxXQUFXQyxZQUFZLElBQUl4QyxTQUFTLENBQUMsQ0FBQztBQUM3QyxRQUFNLENBQUN5QyxXQUFXQyxZQUFZLElBQUkxQyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDMkMsZUFBZUMsZ0JBQWdCLElBQUk1QyxTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDNkMsa0JBQWtCQyxtQkFBbUIsSUFBSTlDLFNBQVMsSUFBSTtBQUM3RCxRQUFNK0MsU0FBUSxvQkFBSUMsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFHbkQsUUFBTUMsV0FBVyxvQkFBSUgsS0FBSztBQUMxQkcsV0FBU0MsUUFBUUQsU0FBU0UsUUFBUSxJQUFJLENBQUM7QUFDdkMsUUFBTUMsb0JBQW9CSCxTQUFTRixZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFFN0QsUUFBTSxDQUFDSyxXQUFXQyxZQUFZLElBQUl4RCxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDeUQsU0FBU0MsVUFBVSxJQUFJMUQsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQzJELFVBQVVDLFdBQVcsSUFBSTVELFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUM2RCxZQUFZQyxhQUFhLElBQUk5RCxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDK0QsV0FBV0MsWUFBWSxJQUFJaEUsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ2lFLGdCQUFnQkMsaUJBQWlCLElBQUlsRSxTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDbUUsbUJBQW1CQyxvQkFBb0IsSUFBSXBFLFNBQVMsSUFBSTtBQUMvRCxRQUFNLENBQUNxRSxxQkFBcUJDLHNCQUFzQixJQUFJdEUsU0FBUyxFQUFFO0FBQ2pFLFFBQU0sQ0FBQ3VFLFFBQVFDLFdBQVcsSUFBSXhFLFNBQVMsQ0FBQztBQUN4QyxRQUFNLENBQUN5RSxvQkFBb0JDLHFCQUFxQixJQUFJMUUsU0FBUyxLQUFLO0FBQ2xFLFFBQU0sQ0FBQzJFLGdCQUFnQkMsaUJBQWlCLElBQUk1RSxTQUFTLElBQUk7QUFHekQsUUFBTSxDQUFDNkUsT0FBT0MsUUFBUSxJQUFJOUUsU0FBUztBQUFBLElBQ2pDK0UsU0FBUztBQUFBLElBQ1RDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBRUQsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUluRixTQUFTO0FBQUEsSUFDM0NvRixZQUFZO0FBQUEsSUFDWkosU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFFSCxRQUFNSSxnQkFBZ0JBLENBQUNDLFVBQVU7QUFDL0IsVUFBTUMsbUJBQW1CO0FBQUEsTUFDdkI7QUFBQSxRQUNFQyxLQUFLO0FBQUEsUUFDTEMsT0FDRSx1QkFBQyxRQUFLLElBQUksVUFBVUgsTUFBTUksR0FBRyxJQUFJLFdBQVUsb0JBQW1CLHFCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxNQUVKO0FBQUEsTUFDQTtBQUFBLFFBQ0VGLEtBQUs7QUFBQSxRQUNMQyxPQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixTQUFTLE1BQU1FLG9CQUFvQkwsTUFBTUksR0FBRztBQUFBLFlBQUU7QUFBQTtBQUFBLFVBRmhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsTUFFSjtBQUFBLElBQUM7QUFHSCxXQUFPSDtBQUFBQSxFQUNUO0FBRUEsUUFBTUssNEJBQTRCQSxDQUFDQyxNQUFNO0FBQ3ZDLFVBQU0sRUFBRUMsTUFBTSxJQUFJRCxFQUFFRTtBQUNwQmpDLGtCQUFjZ0MsS0FBSztBQUFBLEVBQ3JCO0FBRUEsUUFBTSxDQUFDRSxRQUFRQyxTQUFTLElBQUlqRyxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUNrRyxVQUFVQyxXQUFXLElBQUluRyxTQUFTO0FBQUEsSUFDdkNvRyxTQUFTO0FBQUEsSUFDVEMsUUFBUTtBQUFBLElBQ1JDLHVCQUF1QjtBQUFBLElBQ3ZCQyxRQUFRakQ7QUFBQUE7QUFBQUEsSUFDUmtELFVBQVU7QUFBQSxJQUNWQyxZQUFZO0FBQUEsRUFDZCxDQUFDO0FBRUQxRyxZQUFVLE1BQU07QUFDZCxVQUFNMkcsTUFBTUMsYUFBYUMsUUFBUSxNQUFNO0FBQ3ZDLFFBQUlDLGFBQWE7QUFDakIsUUFBSTtBQUNGLFVBQUlILEtBQUs7QUFDUEcscUJBQWFDLEtBQUtDLE1BQU1MLEdBQUc7QUFBQSxNQUM3QjtBQUFBLElBQ0YsU0FBU2IsR0FBRztBQUNWbUIsY0FBUUMsTUFBTSwyQ0FBMkNwQixDQUFDO0FBQUEsSUFDNUQ7QUFFQSxVQUFNcUIsc0JBQXNCLFlBQVk7QUFDdEMsVUFBSTtBQUNGeEYseUJBQWlCLEVBQUU7QUFDbkI4QixxQkFBYSxJQUFJO0FBQ2pCLGNBQU0yRCxXQUFXLE1BQU1qSCxJQUFJa0gsSUFBSSwwQ0FBMEM7QUFBQSxVQUN2RUMsUUFBUTtBQUFBLFlBQ05DLFdBQVd2RTtBQUFBQSxZQUNYd0UsU0FBU3hFO0FBQUFBLFVBQ1g7QUFBQSxRQUNGLENBQUM7QUFDRCxZQUFJb0UsU0FBU0ssUUFBUUwsU0FBU0ssS0FBS0MsU0FBUyxHQUFHO0FBQzdDLGdCQUFNQyxnQkFBZ0JQLFNBQVNLLEtBQUtHLElBQUksQ0FBQ3JDLE9BQU9zQyxVQUFVO0FBQ3hELGdCQUFJLENBQUN0QyxPQUFPdUMsVUFBVUMsV0FBWSxRQUFPLENBQUM7QUFDMUMsbUJBQU87QUFBQSxjQUNMcEMsS0FBS0osTUFBTUk7QUFBQUEsY0FDWHFDLElBQUlILFFBQVE7QUFBQSxjQUNaSSxNQUFNMUMsT0FBT2MsU0FBUzZCO0FBQUFBLGNBQ3RCQyxjQUFjNUMsT0FBT2MsU0FBUzhCO0FBQUFBLGNBQzlCSixZQUFZeEMsT0FBT3VDLFVBQVVDO0FBQUFBLGNBQzdCSyxRQUFRN0MsTUFBTTZDO0FBQUFBLGNBQ2Q5QixRQUFRZixNQUFNZTtBQUFBQSxjQUNkK0IsZ0JBQWdCOUMsTUFBTThDO0FBQUFBLGNBQ3RCQyxrQkFBa0JDLGNBQWNoRCxNQUFNaUQsU0FBUztBQUFBLGNBQy9DQyxRQUNFLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTLENBQUMsT0FBTztBQUFBLGtCQUNqQixNQUFNO0FBQUEsb0JBQ0pDLE9BQU9wRCxjQUFjQyxLQUFLO0FBQUEsa0JBQzVCO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUVWLGlDQUFDLFlBQVMsV0FBVSxlQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQjtBQUFBO0FBQUEsZ0JBUGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLFlBRUo7QUFBQSxVQUNGLENBQUM7QUFDRDVELDJCQUFpQmdHLGFBQWE7QUFDOUJ0RCwrQkFBcUIsSUFBSTtBQUFBLFFBQzNCLE9BQU87QUFDTDlCLDZCQUFtQixFQUFFO0FBQUEsUUFDdkI7QUFBQSxNQUNGLFNBQVMyRSxPQUFPO0FBQ2RELGdCQUFRQyxNQUFNLHFDQUFxQ0EsS0FBSztBQUN4RDNFLDJCQUFtQixFQUFFO0FBRXJCd0MsaUJBQVM7QUFBQSxVQUNQQyxTQUFTO0FBQUEsVUFDVEMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNILFVBQUM7QUFDQ3pCLHFCQUFhLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFFQTBELHdCQUFvQjtBQUFBLEVBQ3RCLEdBQUcsQ0FBQzNDLE1BQU0sQ0FBQztBQUVYeEUsWUFBVSxNQUFNO0FBQ2RpRSxpQkFBYSxFQUFFO0FBQ2YsVUFBTTBFLDJCQUEyQixZQUFZO0FBQzNDLFVBQUk7QUFDRixjQUFNdkIsV0FBVyxNQUFNakgsSUFBSWtIO0FBQUFBLFVBQ3pCLGtDQUFrQ3ZGLGVBQWU7QUFBQSxRQUNuRDtBQUNBLFlBQUlzRixTQUFTd0IsVUFBVTtBQUNyQixnQkFBTSxJQUFJQyxNQUFNLGdDQUFnQztBQUNsRDVFLHFCQUFhbUQsU0FBU0ssSUFBSTtBQUFBLE1BQzVCLFNBQVNxQixLQUFLO0FBQ1o3QixnQkFBUThCLElBQUksZ0JBQWdCO0FBQUEsTUFDOUI7QUFBQSxJQUNGO0FBRUFKLDZCQUF5QjtBQUFBLEVBQzNCLEdBQUcsQ0FBQzdHLGVBQWUsQ0FBQztBQUVwQjlCLFlBQVUsTUFBTTtBQUNkbUUsc0JBQWtCLEVBQUU7QUFDcEIsVUFBTXdFLDJCQUEyQixZQUFZO0FBQzNDLFVBQUk7QUFDRixjQUFNdkIsV0FBVyxNQUFNakgsSUFBSWtIO0FBQUFBLFVBQ3pCLHdDQUF3Q3ZGLGVBQWU7QUFBQSxRQUN6RDtBQUNBLFlBQUlzRixTQUFTd0IsVUFBVTtBQUNyQixnQkFBTSxJQUFJQyxNQUFNLGlDQUFpQztBQUNuRDFFLDBCQUFrQmlELFNBQVNLLElBQUk7QUFBQSxNQUNqQyxTQUFTcUIsS0FBSztBQUNaN0IsZ0JBQVE4QjtBQUFBQSxVQUNOO0FBQUEsVUFDQUQsSUFBSTdEO0FBQUFBLFFBQ047QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUVBMEQsNkJBQXlCO0FBQUEsRUFDM0IsR0FBRyxDQUFDN0csZUFBZSxDQUFDO0FBRXBCOUIsWUFBVSxNQUFNO0FBQ2QsVUFBTWdKLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTTVCLFdBQVcsTUFBTWpILElBQUlrSCxJQUFJLGdCQUFnQjtBQUMvQ2hHLGtCQUFVK0YsU0FBU0ssSUFBSTtBQUFBLE1BQ3pCLFNBQVNQLE9BQU87QUFDZEQsZ0JBQVFDLE1BQU0sOEJBQThCQSxLQUFLO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBQ0E4QixnQkFBWTtBQUFBLEVBQ2QsR0FBRyxFQUFFO0FBRUxoSixZQUFVLE1BQU07QUFDZCxVQUFNZ0osY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRixjQUFNNUIsV0FBVyxNQUFNakgsSUFBSWtILElBQUksd0JBQXdCO0FBQ3ZEOUYsd0JBQWdCNkYsU0FBU0ssSUFBSTtBQUFBLE1BQy9CLFNBQVNQLE9BQU87QUFDZEQsZ0JBQVFDLE1BQU0sOEJBQThCQSxLQUFLO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBQ0E4QixnQkFBWTtBQUFBLEVBQ2QsR0FBRyxFQUFFO0FBRUwsUUFBTUMsZUFBZUEsTUFBTTtBQUN6QixVQUFNQyxZQUFZLENBQUM7QUFFbkIsUUFBSSxDQUFDcEgsaUJBQWlCO0FBQ3BCb0gsZ0JBQVVDLFdBQVc7QUFBQSxJQUN2QjtBQUVBLFFBQUksQ0FBQzdFLHVCQUF1QkEsb0JBQW9Cb0QsV0FBVyxHQUFHO0FBQzVEd0IsZ0JBQVUzQyx3QkFBd0I7QUFBQSxJQUNwQztBQUVBLFVBQU1ELFNBQVM4QyxXQUFXakQsU0FBU0csTUFBTTtBQUN6QyxRQUFJK0MsTUFBTS9DLE1BQU0sS0FBS0EsVUFBVSxHQUFHO0FBQ2hDNEMsZ0JBQVU1QyxTQUFTO0FBQUEsSUFDckI7QUFFQUosY0FBVWdELFNBQVM7QUFDbkIsV0FBT0ksT0FBT0MsS0FBS0wsU0FBUyxFQUFFeEIsV0FBVztBQUFBLEVBQzNDO0FBRUEsUUFBTThCLGVBQWVBLENBQUMxRCxNQUFNO0FBQzFCLFVBQU0sRUFBRW1DLE1BQU1sQyxNQUFNLElBQUlELEVBQUVFO0FBQzFCSSxnQkFBWSxDQUFDcUQsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ3hCLElBQUksR0FBR2xDO0FBQUFBLElBQ1YsRUFBRTtBQUNGRyxjQUFVLENBQUN1RCxjQUFjLEVBQUUsR0FBR0EsVUFBVSxDQUFDeEIsSUFBSSxHQUFHLEdBQUcsRUFBRTtBQUFBLEVBQ3ZEO0FBRUEsUUFBTXlCLHlCQUF5QkEsQ0FBQ0MsV0FBVztBQUN6Q3BGLDJCQUF1Qm9GLE1BQU07QUFBQSxFQUMvQjtBQUVBLFFBQU1DLG9CQUFvQixPQUFPQyxZQUFZO0FBQzNDcEkscUJBQWlCb0ksT0FBTztBQUV4QixRQUFJQSxTQUFTO0FBQ1gsVUFBSTtBQUNGLGNBQU16QyxXQUFXLE1BQU1qSCxJQUFJa0gsSUFBSSw0QkFBNEJ3QyxPQUFPLEVBQUU7QUFDcEUsWUFBSXpDLFNBQVNLLFFBQVFMLFNBQVNLLEtBQUtDLFNBQVMsR0FBRztBQUM3Q3ZGLDJCQUFpQmlGLFNBQVNLLElBQUk7QUFBQSxRQUNoQyxPQUFPO0FBQ0x0RiwyQkFBaUIsRUFBRTtBQUFBLFFBQ3JCO0FBQUEsTUFDRixTQUFTK0UsT0FBTztBQUNkRCxnQkFBUUMsTUFBTSxtQ0FBbUNBLEtBQUs7QUFDdEQvRSx5QkFBaUIsRUFBRTtBQUFBLE1BQ3JCO0FBQUEsSUFDRixPQUFPO0FBQ0xBLHVCQUFpQixFQUFFO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBRUEsUUFBTTJILFVBQVU7QUFBQSxJQUNkLEVBQUVyRSxLQUFLLE1BQU1zRSxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFdEUsS0FBSyxvQkFBb0JzRSxRQUFRLG1CQUFtQjtBQUFBLElBQ3RELEVBQUV0RSxLQUFLLFFBQVFzRSxRQUFRLGdCQUFnQjtBQUFBLElBQ3ZDLEVBQUV0RSxLQUFLLGdCQUFnQnNFLFFBQVEsd0JBQXdCO0FBQUEsRUFBQztBQUUxRCxNQUFJM0YsbUJBQW1CO0FBQ3JCMEYsWUFBUUUsS0FBSyxFQUFFdkUsS0FBSyxjQUFjc0UsUUFBUSxhQUFhLENBQUM7QUFBQSxFQUMxRDtBQUNBRCxVQUFRRTtBQUFBQSxJQUNOLEVBQUV2RSxLQUFLLFVBQVVzRSxRQUFRLGdCQUFnQjtBQUFBLElBQ3pDLEVBQUV0RSxLQUFLLFVBQVVzRSxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFdEUsS0FBSyxrQkFBa0JzRSxRQUFRLGlCQUFpQjtBQUFBLElBQ2xELEVBQUV0RSxLQUFLLFVBQVVzRSxRQUFRLFNBQVM7QUFBQSxFQUNwQztBQUVBLFFBQU1FLGlCQUFpQixPQUFPSixZQUFZO0FBQ3hDOUgsdUJBQW1COEgsT0FBTztBQUMxQnpELGdCQUFZLENBQUM4RCxrQkFBa0I7QUFBQSxNQUM3QixHQUFHQTtBQUFBQSxNQUNIN0QsU0FBU3dEO0FBQUFBLElBQ1gsRUFBRTtBQUNGM0QsY0FBVSxDQUFDdUQsY0FBYyxFQUFFLEdBQUdBLFVBQVVOLFVBQVUsR0FBRyxFQUFFO0FBQ3ZENUUsMkJBQXVCLEVBQUU7QUFDekJxRixzQkFBa0JDLE9BQU87QUFDekJNLDZCQUF5Qk4sT0FBTztBQUVoQyxRQUFJQSxTQUFTO0FBQ1gsVUFBSTtBQUNGLGNBQU16QyxXQUFXLE1BQU1qSCxJQUFJa0gsSUFBSSwwQkFBMEJ3QyxPQUFPLEVBQUU7QUFDbEVwSCxxQkFBYTJFLFNBQVNLLFFBQVEsQ0FBQyxDQUFDO0FBQUEsTUFDbEMsU0FBU1AsT0FBTztBQUNkekUscUJBQWEsQ0FBQyxDQUFDO0FBQUEsTUFDakI7QUFBQSxJQUNGLE9BQU87QUFDTEEsbUJBQWEsQ0FBQyxDQUFDO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBRUEsUUFBTTJILHFCQUFxQixPQUFPUCxZQUFZO0FBQzVDNUgsOEJBQTBCNEgsT0FBTztBQUNqQ1EsNkJBQXlCUixPQUFPO0FBQUEsRUFDbEM7QUFFQSxRQUFNdEIsZ0JBQWdCQSxDQUFDK0IsZUFBZTtBQUNwQyxXQUFPQSxZQUFZbkgsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQ2pDO0FBRUEsUUFBTWtILDJCQUEyQixPQUFPUixZQUFZO0FBQ2xEaEksNEJBQXdCZ0ksT0FBTztBQUMvQixRQUFJQSxTQUFTO0FBQ1gsVUFBSVU7QUFDSixVQUFJVixZQUFZLFNBQVM7QUFDdkJVLGNBQU0sZ0VBQWdFdkgsS0FBSyxZQUFZQSxLQUFLO0FBQzVGcUIsNkJBQXFCLElBQUk7QUFBQSxNQUMzQixPQUFPO0FBQ0xrRyxjQUFNLHlDQUF5Q1YsT0FBTztBQUN0RHhGLDZCQUFxQixLQUFLO0FBQUEsTUFDNUI7QUFDQSxVQUFJO0FBQ0YxQyx5QkFBaUIsRUFBRTtBQUNuQjhCLHFCQUFhLElBQUk7QUFDakIsY0FBTTJELFdBQVcsTUFBTWpILElBQUlrSCxJQUFJa0QsR0FBRztBQUVsQyxZQUFJbkQsU0FBU0ssUUFBUUwsU0FBU0ssS0FBS0MsU0FBUyxHQUFHO0FBQzdDLGdCQUFNQyxnQkFBZ0JQLFNBQVNLLEtBQUtHLElBQUksQ0FBQ3JDLE9BQU9zQyxVQUFVO0FBQ3hELGdCQUFJLENBQUN0QyxPQUFPdUMsVUFBVUMsV0FBWSxRQUFPLENBQUM7QUFDMUMsbUJBQU87QUFBQSxjQUNMcEMsS0FBS0osTUFBTUk7QUFBQUEsY0FDWHFDLElBQUlILFFBQVE7QUFBQSxjQUNaSSxNQUFNMUMsT0FBT2MsU0FBUzZCO0FBQUFBLGNBQ3RCQyxjQUFjNUMsT0FBT2MsU0FBUzhCO0FBQUFBLGNBQzlCSixZQUFZeEMsT0FBT3VDLFVBQVVDO0FBQUFBLGNBQzdCSyxRQUFRN0MsTUFBTTZDO0FBQUFBLGNBQ2Q5QixRQUFRZixNQUFNZTtBQUFBQSxjQUNkZ0Msa0JBQWtCL0MsT0FBT2lELFdBQVdyRixNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsY0FDaERzRixRQUNFLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTLENBQUMsT0FBTztBQUFBLGtCQUNqQixNQUFNO0FBQUEsb0JBQ0pDLE9BQU9wRCxjQUFjQyxLQUFLO0FBQUEsa0JBQzVCO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUVWLGlDQUFDLFlBQVMsV0FBVSxlQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQjtBQUFBO0FBQUEsZ0JBUGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLFlBRUo7QUFBQSxVQUNGLENBQUM7QUFDRDVELDJCQUFpQmdHLGFBQWE7QUFBQSxRQUNoQyxPQUFPO0FBQ0xwRiw2QkFBbUIsRUFBRTtBQUFBLFFBQ3ZCO0FBQUEsTUFDRixTQUFTMkUsT0FBTztBQUNkRCxnQkFBUUMsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFDbkQzRSwyQkFBbUIsRUFBRTtBQUVyQndDLGlCQUFTO0FBQUEsVUFDUEMsU0FBUztBQUFBLFVBQ1RDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSCxVQUFDO0FBQ0N6QixxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGLE9BQU87QUFDTGxCLHlCQUFtQixFQUFFO0FBQUEsSUFDdkI7QUFBQSxFQUNGO0FBRUEsUUFBTWlJLGVBQWUsT0FBTzFFLE1BQU07QUFDaENBLE1BQUUyRSxlQUFlO0FBQ2pCLFVBQU1DLFVBQVV6QixhQUFhO0FBQzdCLFFBQUk7QUFDRixVQUFJeUIsU0FBUztBQUNYN0csb0JBQVksSUFBSTtBQUNoQmtCLGlCQUFTLEVBQUVDLFNBQVMsT0FBT0MsU0FBUyxJQUFJQyxNQUFNLE9BQU8sQ0FBQztBQUN0RHZDLHFCQUFhLEtBQUs7QUFDbEIsWUFBSWdJO0FBQ0osY0FBTWhFLE1BQU1DLGFBQWFDLFFBQVEsTUFBTTtBQUN2QyxZQUFJQyxhQUFhO0FBQ2pCLFlBQUk7QUFDRixjQUFJSCxLQUFLO0FBQ1BHLHlCQUFhQyxLQUFLQyxNQUFNTCxHQUFHO0FBQUEsVUFDN0I7QUFBQSxRQUNGLFNBQVNiLElBQUc7QUFDVm1CLGtCQUFRQyxNQUFNLDJDQUEyQ3BCLEVBQUM7QUFBQSxRQUM1RDtBQUNBSyxpQkFBU0ksd0JBQXdCakM7QUFDakM2QixpQkFBU1csYUFBYUEsWUFBWW5CO0FBQ2xDaEIsOEJBQXNCLElBQUk7QUFDMUIsY0FBTXlDLFdBQVcsTUFBTWpILElBQUl5SyxLQUFLLHlDQUF5Q3pFLFFBQVE7QUFDakYsWUFBSWlCLFNBQVN3QixXQUFXLEtBQUs7QUFDM0I3Ryw2QkFBbUIsRUFBRTtBQUNyQndDLGlDQUF1QixFQUFFO0FBQ3pCVixzQkFBWSxLQUFLO0FBQ2pCdUMsc0JBQVk7QUFBQSxZQUNWQyxTQUFTO0FBQUEsWUFDVEMsUUFBUTtBQUFBLFlBQ1JDLHVCQUF1QjtBQUFBLFlBQ3ZCQyxRQUFRakQ7QUFBQUE7QUFBQUEsWUFDUmtELFVBQVU7QUFBQSxZQUNWQyxZQUFZO0FBQUEsVUFDZCxDQUFDO0FBQ0QzQixtQkFBUztBQUFBLFlBQ1BDLFNBQVM7QUFBQSxZQUNUQyxTQUFTO0FBQUEsWUFDVEMsTUFBTTtBQUFBLFVBQ1IsQ0FBQztBQUFBLFFBQ0g7QUFFQSxZQUFJa0MsU0FBU3dCLFVBQVUsS0FBSztBQUMxQmpHLHVCQUFhLEtBQUs7QUFDbEJaLDZCQUFtQixFQUFFO0FBQ3JCd0MsaUNBQXVCLEVBQUU7QUFDekJWLHNCQUFZLEtBQUs7QUFDakJ1QyxzQkFBWTtBQUFBLFlBQ1ZDLFNBQVM7QUFBQSxZQUNUQyxRQUFRO0FBQUEsWUFDUkMsdUJBQXVCO0FBQUEsWUFDdkJDLFFBQVFqRDtBQUFBQTtBQUFBQSxZQUNSa0QsVUFBVTtBQUFBLFlBQ1ZDLFlBQVk7QUFBQSxVQUNkLENBQUM7QUFDRDNCLG1CQUFTO0FBQUEsWUFDUEMsU0FBUztBQUFBLFlBQ1RDLFNBQVM7QUFBQSxZQUNUQyxNQUFNO0FBQUEsVUFDUixDQUFDO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFBQSxJQUNGLFNBQVNnQyxPQUFPO0FBQ2R2RSxtQkFBYSxLQUFLO0FBQ2xCWix5QkFBbUIsRUFBRTtBQUNyQnFFLGtCQUFZO0FBQUEsUUFDVkMsU0FBUztBQUFBLFFBQ1RDLFFBQVE7QUFBQSxRQUNSQyx1QkFBdUI7QUFBQSxRQUN2QkMsUUFBUWpEO0FBQUFBO0FBQUFBLFFBQ1JrRCxVQUFVO0FBQUEsUUFDVkMsWUFBWTtBQUFBLE1BQ2QsQ0FBQztBQUNEM0IsZUFBUztBQUFBLFFBQ1BDLFNBQVM7QUFBQSxRQUNUQyxTQUFTLGtDQUFrQ2lDLE1BQU1qQyxPQUFPO0FBQUEsUUFDeERDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFDRHJCLGtCQUFZLEtBQUs7QUFDakJvRCxjQUFRQyxNQUFNLGtDQUFrQ0EsS0FBSztBQUFBLElBQ3ZELFVBQUM7QUFDQ3ZDLDRCQUFzQixLQUFLO0FBQzNCRixrQkFBWSxDQUFDb0csU0FBU0EsT0FBTyxDQUFDO0FBQUEsSUFDaEM7QUFBQSxFQUNGO0FBRUEsUUFBTWpGLHNCQUFzQixPQUFPaUUsWUFBWTtBQUM3QyxRQUFJO0FBQ0ZsRyxpQkFBVyxJQUFJO0FBQ2ZkLHVCQUFpQixJQUFJO0FBQ3JCZ0Msd0JBQWtCZ0YsT0FBTztBQUN6QnhILG9CQUFjLElBQUk7QUFDbEIsWUFBTStFLFdBQVcsTUFBTWpILElBQUlrSCxJQUFJLHlDQUF5Q3dDLE9BQU8sRUFBRTtBQUNqRjlHLDBCQUFvQnFFLFNBQVNLLElBQUk7QUFBQSxJQUNuQyxTQUFTUCxPQUFPO0FBQ2RELGNBQVFDLE1BQU0sMEJBQTBCQSxLQUFLO0FBQzdDbkMsZUFBUztBQUFBLFFBQ1BDLFNBQVM7QUFBQSxRQUNUQyxTQUFTO0FBQUEsUUFDVEMsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDdkIsaUJBQVcsS0FBSztBQUNoQnRCLG9CQUFjLEtBQUs7QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNOEgsMkJBQTJCLE9BQU9OLFlBQVk7QUFDbEQsUUFBSUEsU0FBUztBQUNYLFVBQUk7QUFDRixjQUFNekMsV0FBVyxNQUFNakgsSUFBSXlLO0FBQUFBLFVBQ3pCLG1DQUFtQ2YsT0FBTztBQUFBLFFBQzVDO0FBQ0EsWUFBSXpDLFNBQVNLLFFBQVFMLFNBQVNLLEtBQUtDLFNBQVMsR0FBRztBQUM3QyxnQkFBTW9ELGdCQUFnQjFELFNBQVNLLEtBQUtzRDtBQUFBQSxZQUNsQyxDQUFDQyxZQUFZQSxRQUFRQyxjQUFjRCxRQUFRQyxXQUFXMUY7QUFBQUEsVUFDeEQ7QUFDQWhELDZCQUFtQnVJLGFBQWE7QUFBQSxRQUNsQyxPQUFPO0FBQ0x2SSw2QkFBbUIsRUFBRTtBQUFBLFFBQ3ZCO0FBQUEsTUFDRixTQUFTMkUsT0FBTztBQUNkRCxnQkFBUUMsTUFBTSxtQ0FBbUNBLEtBQUs7QUFDdEQzRSwyQkFBbUIsRUFBRTtBQUVyQndDLGlCQUFTO0FBQUEsVUFDUEMsU0FBUztBQUFBLFVBQ1RDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsT0FBTztBQUNMM0MseUJBQW1CLEVBQUU7QUFBQSxJQUN2QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNMkksbUJBQW1CNUosYUFBYTZKO0FBQUFBLElBQ3BDLENBQUNDLE1BQU1BLEVBQUV6RixRQUFRM0Q7QUFBQUEsRUFDbkI7QUFFQSxTQUNFLG1DQUNHMEMsK0JBQ0MsdUJBQUMsc0JBQW1CLE9BQU8saUNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBeUQsSUFFekQsdUJBQUMsU0FDRCxpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDJCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFRO0FBQUEsSUFDUjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsNkJBQTZCbUI7QUFBQUEsUUFDN0IsWUFBWTtBQUFBO0FBQUEsTUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFbUI7QUFBQSxJQUVuQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTVYsWUFBWUQ7QUFBQUEsUUFDbEIsV0FBV0MsWUFBWUU7QUFBQUEsUUFDdkIsU0FBU0YsWUFBWUY7QUFBQUEsUUFDckIsU0FBUyxNQUNQRyxlQUFlLENBQUN5RixVQUFVLEVBQUUsR0FBR0EsTUFBTXhGLFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxNQUw3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNRztBQUFBLElBSUFQLE1BQU1FLFdBQ0wsdUJBQUMsU0FBSSxXQUFVLGlDQUNiO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFTRixNQUFNRztBQUFBQSxRQUNmLE1BQU1ILE1BQU1JO0FBQUFBLFFBQ1o7QUFBQSxRQUNBO0FBQUEsUUFDQSxTQUFTLE1BQU1ILFNBQVMsRUFBRSxHQUFHRCxPQUFPRSxTQUFTLE1BQU0sQ0FBQztBQUFBO0FBQUEsTUFMdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBS3dELEtBTjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBR0YsdUJBQUMsU0FBSSxXQUFVLGlCQUNWO0FBQUEsNkJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFXO0FBQUEsTUFDZCx1QkFBQyxRQUFHLFdBQVUsMEJBQXlCLDBDQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlFO0FBQUEsTUFDakUsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxhQUFZLHNDQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRDtBQUFBLFVBQ25ELHVCQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsYUFBWTtBQUFBLGdCQUNaLHVCQUF1QjtBQUFBLGdCQUN2QjtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFDVixjQUFjLENBQUNxRyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUQyxZQUFZLEVBQ1pDLFNBQVNMLE1BQU1JLFlBQVksQ0FBQztBQUFBLGdCQUVqQyxPQUFPekosMEJBQTBCMko7QUFBQUEsZ0JBQ2pDLFVBQVV2QjtBQUFBQSxnQkFFVjtBQUFBLHlDQUFDLE9BQU8sUUFBUCxFQUF5QixPQUFPLFNBQVMsZ0NBQXRCLE1BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQzlJLGFBQWFzRztBQUFBQSxvQkFBSSxDQUFDckMsVUFDakIsdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU1JLEtBQ3pDSixnQkFBTXdDLGNBRFd4QyxNQUFNSSxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBO0FBQUEsY0FyQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBc0JBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNaEQsYUFBYSxJQUFJO0FBQUEsZ0JBQ2hDLFdBQVU7QUFBQSxnQkFBdUc7QUFBQTtBQUFBLGNBRm5IO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLGVBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0NBO0FBQUEsYUFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1DQTtBQUFBLFFBRUNqQixpQkFBaUJBLGNBQWNnRyxTQUFTLElBQ3ZDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFNaEcsY0FBY3FKO0FBQUFBLGNBQU8sQ0FBQ2EsU0FDMUJ0QyxPQUFPSyxPQUFPaUMsSUFBSSxFQUFFQztBQUFBQSxnQkFBSyxDQUFDOUYsVUFDeEIrRixPQUFPL0YsS0FBSyxFQUNUMEYsWUFBWSxFQUNaQyxTQUFTNUgsV0FBVzJILFlBQVksQ0FBQztBQUFBLGNBQ3RDO0FBQUEsWUFDRjtBQUFBLFlBQ0E7QUFBQSxZQUNBLGlCQUFnQjtBQUFBLFlBQ2hCLGlCQUFpQixDQUFDLFlBQVk7QUFBQSxZQUM5QixtQkFBbUI7QUFBQSxjQUNqQlAsa0JBQWtCbkQsY0FBYztBQUFBLFlBQVM7QUFBQSxZQUUzQyxrQkFBa0I7QUFBQTtBQUFBLFVBZHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWNtQyxJQUduQyx1QkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxNQUFLO0FBQUEsWUFDTCxTQUNFckcsY0FBY2dHLFVBQVUsS0FBSzFGO0FBQUFBO0FBQUFBLFVBSmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtHLEtBTkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0FoRUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtFQTtBQUFBLFNBckVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzRUE7QUFBQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXVTtBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiWCw2QkFBbUIsRUFBRTtBQUNyQlksdUJBQWEsS0FBSztBQUNsQnVELG9CQUFVLENBQUMsQ0FBQztBQUNaM0IsaUNBQXVCLEVBQUU7QUFBQSxRQUMzQjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHNEQUFxRCxnQ0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUEsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVWlHLGNBQWMsWUFBVSxNQUM1RDtBQUFBLG1DQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUTtBQUFBLGtCQUNSLFdBQVU7QUFBQSxrQkFBOEM7QUFBQTtBQUFBLG9CQUUvQyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdDO0FBQUE7QUFBQTtBQUFBLGdCQUozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsSUFBRztBQUFBLGtCQUNILFdBQVcsNkVBQTZFekosVUFBVWdMLE1BQU07QUFBQSxrQkFDeEcsYUFBWTtBQUFBLGtCQUNaLHVCQUF1QjtBQUFBLGtCQUN2QjtBQUFBLGtCQUNBLGNBQWMsQ0FBQ1YsT0FBT0MsV0FDcEJBLFFBQVFDLFVBQ0pDLFNBQVMsRUFDVkMsWUFBWSxFQUNaQyxTQUFTTCxNQUFNSSxZQUFZLENBQUM7QUFBQSxrQkFFakMsT0FBTzNKLG1CQUFtQjZKO0FBQUFBLGtCQUMxQixVQUFVMUI7QUFBQUEsa0JBRVQ3SSxpQkFBT3dHO0FBQUFBLG9CQUFJLENBQUNyQyxVQUNYLHVCQUFDLE9BQU8sUUFBUCxFQUE4QixPQUFPQSxNQUFNSSxLQUN6QyxhQUFHSixNQUFNMkMsU0FBUyxNQUFNM0MsTUFBTTRDLFlBQVksTUFEekI1QyxNQUFNSSxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQW5CSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FvQkE7QUFBQSxjQUNDTSxPQUFPa0QsWUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZsRCxpQkFBT2tELFlBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQS9CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlDQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFRO0FBQUEsa0JBQ1IsV0FBVTtBQUFBLGtCQUE4QztBQUFBO0FBQUEsb0JBRXpDLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQTtBQUFBO0FBQUEsZ0JBSmpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxJQUFHO0FBQUEsa0JBQ0gsTUFBSztBQUFBLGtCQUNMLGFBQVk7QUFBQSxrQkFDWixVQUFVTztBQUFBQSxrQkFDVixPQUFPcEY7QUFBQUEsa0JBQ1AsV0FBVywySEFBMkh2RCxVQUFVZ0wsTUFBTTtBQUFBLGtCQUVySnpKO0FBQUFBLG9DQUFnQnNGLElBQUksQ0FBQ29FLE9BQU9uRSxVQUFVO0FBQ3JDLDRCQUFNb0UsWUFDSkQsT0FBT2YsWUFBWTFGLE9BQU93QyxjQUMxQjtBQUNGLDRCQUFNOEIsVUFDSm1DLE9BQU9mLFlBQVkxRixPQUFPSSxPQUFPLFdBQVdrQyxLQUFLO0FBQ25ELDRCQUFNTyxTQUFTNEQsT0FBT2YsWUFBWWlCLFdBQVc7QUFDN0MsNkJBQ0U7QUFBQSx3QkFBQyxPQUFPO0FBQUEsd0JBQVA7QUFBQSwwQkFFQyxPQUFPLFFBQVFyQyxPQUFPLElBQUl6QixNQUFNO0FBQUEsMEJBRS9CNkQ7QUFBQUE7QUFBQUEsNEJBQVU7QUFBQSw0QkFBSTdEO0FBQUFBO0FBQUFBO0FBQUFBLHdCQUhWLFFBQVF5QixPQUFPLElBQUl6QixNQUFNO0FBQUEsd0JBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBS0E7QUFBQSxvQkFFSixDQUFDO0FBQUEsb0JBQ0FsRSxnQkFBZ0IwRDtBQUFBQSxzQkFBSSxDQUFDdUUsVUFDcEI7QUFBQSx3QkFBQyxPQUFPO0FBQUEsd0JBQVA7QUFBQSwwQkFFQyxPQUFPLFNBQVNBLE1BQU14RyxHQUFHO0FBQUEsMEJBRXhCLGFBQUd3RyxNQUFNQyxRQUFRLFFBQVFELE1BQU1FLGNBQWM7QUFBQTtBQUFBLHdCQUh6Q0YsTUFBTXhHO0FBQUFBLHdCQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBS0E7QUFBQSxvQkFDRDtBQUFBLG9CQUNBM0IsV0FBVzREO0FBQUFBLHNCQUFJLENBQUMwRSxhQUNmO0FBQUEsd0JBQUMsT0FBTztBQUFBLHdCQUFQO0FBQUEsMEJBRUMsT0FBTyxRQUFRQSxTQUFTM0csR0FBRztBQUFBLDBCQUUxQixrQkFBUTJHLFNBQVNDLE9BQU8sUUFBUUQsU0FBU0UsV0FBVztBQUFBO0FBQUEsd0JBSGhERixTQUFTM0c7QUFBQUEsd0JBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBS0E7QUFBQSxvQkFDRDtBQUFBO0FBQUE7QUFBQSxnQkF2Q0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBd0NBO0FBQUEsY0FDQ00sT0FBT00seUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWTixpQkFBT00seUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQW5ESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFEQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFRO0FBQUEsb0JBQ1IsV0FBVTtBQUFBLG9CQUE4QztBQUFBO0FBQUEsc0JBRWpELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQTtBQUFBO0FBQUEsa0JBSnpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxJQUFHO0FBQUEsb0JBQ0gsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPSixTQUFTRztBQUFBQSxvQkFDaEIsVUFBVWtEO0FBQUFBLG9CQUNWLGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRMkksS0FUN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFXQTtBQUFBLGdCQUNDdkQsT0FBT0ssVUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZMLGlCQUFPSyxVQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkF0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF3QkE7QUFBQSxjQUVDSCxTQUFTRyxVQUFVaEMsb0JBQW9Cb0QsU0FBUyxLQUMvQyx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQyx3Q0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQ1YsYUFBWTtBQUFBLG9CQUNaLFFBQ0UrRSxPQUFPdEcsU0FBU0csTUFBTSxJQUFJaEMsb0JBQW9Cb0QsUUFDOUNnRixRQUFRLENBQUM7QUFBQSxvQkFDWCxVQUFRO0FBQUE7QUFBQSxrQkFQVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT1U7QUFBQSxtQkFYWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBO0FBQUEsaUJBekNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkNBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVE7QUFBQSxrQkFDUixXQUFVO0FBQUEsa0JBQThDO0FBQUE7QUFBQSxnQkFGMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLElBQUc7QUFBQSxrQkFDSCxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLEtBQUtuSjtBQUFBQSxrQkFDTCxPQUFPNEMsU0FBU0s7QUFBQUEsa0JBQ2hCLFVBQVVnRDtBQUFBQSxrQkFDVixXQUFVO0FBQUE7QUFBQSxnQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPMkk7QUFBQSxpQkFkN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLElBQUc7QUFBQSxrQkFDSCxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLFNBQVNyRCxTQUFTTTtBQUFBQSxrQkFDbEIsVUFBVSxDQUFDWCxNQUNUTSxZQUFZLENBQUN5RSxVQUFVO0FBQUEsb0JBQ3JCLEdBQUdBO0FBQUFBLG9CQUNIcEUsVUFBVVgsRUFBRUUsT0FBTzJHO0FBQUFBLGtCQUNyQixFQUFFO0FBQUEsa0JBRUosV0FBVTtBQUFBO0FBQUEsZ0JBWFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBVytEO0FBQUEsY0FFL0Q7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUTtBQUFBLGtCQUNSLFdBQVU7QUFBQSxrQkFBd0M7QUFBQTtBQUFBLGdCQUZwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGlCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9CQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsSUFBRztBQUFBLGtCQUNILE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsU0FBU3hHLFNBQVNPO0FBQUFBLGtCQUNsQixVQUFVLENBQUNaLE1BQ1RNLFlBQVksQ0FBQ3lFLFVBQVU7QUFBQSxvQkFDckIsR0FBR0E7QUFBQUEsb0JBQ0huRSxZQUFZWixFQUFFRSxPQUFPMkc7QUFBQUEsa0JBQ3ZCLEVBQUU7QUFBQSxrQkFFSixXQUFVO0FBQUE7QUFBQSxnQkFYWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FXK0Q7QUFBQSxjQUUvRDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFRO0FBQUEsa0JBQ1IsV0FBVTtBQUFBLGtCQUF3QztBQUFBO0FBQUEsZ0JBRnBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsaUJBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0JBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUU2RDtBQUFBO0FBQUEsY0FKekU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsZUFqTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrTkE7QUFBQSxhQXZORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd05BO0FBQUE7QUFBQSxNQWpPRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFrT0E7QUFBQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNL0o7QUFBQUEsUUFDTixVQUFVLE1BQU1DLGlCQUFpQixLQUFLO0FBQUEsUUFDdEMsU0FBUyxNQUFNQSxpQkFBaUIsS0FBSztBQUFBLFFBQ3JDLE1BQU0sTUFBTUEsaUJBQWlCLEtBQUs7QUFBQSxRQUNsQyxVQUFVLE1BQU0rQyxvQkFBb0JoQixjQUFjO0FBQUEsUUFDbEQsUUFBUSx1QkFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBSztBQUFBLFFBQ2IsU0FBU3hDO0FBQUFBLFFBRVQ7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLCtCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsaUlBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLHVCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWU7QUFBQSxjQUFVO0FBQUEsY0FDeEJVLGtCQUFrQmdGLFVBQVVDO0FBQUFBLGlCQUYvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLDRCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9CO0FBQUEsY0FBVTtBQUFBLGNBQzdCakYsa0JBQWtCZ0YsVUFBVThFO0FBQUFBLGlCQUYvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLGtDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBCO0FBQUEsY0FBVTtBQUFBLGNBQ25DOUosa0JBQWtCZ0YsVUFBVStFO0FBQUFBLGlCQUYvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLHFCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWE7QUFBQSxjQUFTO0FBQUEsY0FBRS9KLGtCQUFrQnVELFNBQVM2QjtBQUFBQSxjQUFXO0FBQUEsY0FBSTtBQUFBLGNBQ3ZEcEYsa0JBQWtCc0Y7QUFBQUEsaUJBRi9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHFDQUFDLFlBQU8sMkJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUI7QUFBQSxjQUFVO0FBQUEsY0FDNUJ0RixrQkFBa0JnRixVQUFVOEUsY0FDN0I5SixrQkFBa0JnSyxhQUNkaEssa0JBQWtCZ0YsVUFBVThFLGNBQzVCOUosa0JBQWtCZ0ssYUFDbEI7QUFBQSxpQkFOTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLDJCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1CO0FBQUEsY0FBUztBQUFBLGNBQUVoSyxrQkFBa0JpSztBQUFBQSxpQkFEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTywrQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QjtBQUFBLGNBQVU7QUFBQSxjQUNoQ2pLLGtCQUFrQmdLO0FBQUFBLGlCQUZyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLHlCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlCO0FBQUEsY0FBUztBQUFBLGNBQUVoSyxrQkFBa0JrSztBQUFBQSxpQkFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTyxrQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQjtBQUFBLGNBQVU7QUFBQSxjQUNuQ2xLLGtCQUFrQm1LO0FBQUFBLGlCQUZyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLDZCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFCO0FBQUEsY0FBUztBQUFBLGNBQUVuSyxrQkFBa0JvSztBQUFBQSxpQkFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTyw2QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxQjtBQUFBLGNBQVU7QUFBQSxjQUM5QnBLLGtCQUFrQnFLO0FBQUFBLGlCQUZyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLDBCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtCO0FBQUEsY0FBUztBQUFBLGNBQUVySyxrQkFBa0JzSztBQUFBQSxpQkFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTywyQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQjtBQUFBLGNBQVU7QUFBQSxjQUM1QnRLLGtCQUFrQjBGLFdBQVdyRixNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsaUJBRjVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHFDQUFDLFlBQU8sMkJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUI7QUFBQSxjQUFVO0FBQUEsY0FDNUJMLGtCQUFrQnVLLFdBQVdsSyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsaUJBRjVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQXhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlEQTtBQUFBO0FBQUE7QUFBQSxNQXJFRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFzRUE7QUFBQSxPQTlZSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK1lFLEtBaFpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpWkEsS0FyWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVaQTtBQUVKO0FBQUVoQyxHQXg2QklELHVDQUFxQztBQUFBb00sS0FBckNwTTtBQTA2Qk4sZUFBZUE7QUFBc0MsSUFBQW9NO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJhcGkiLCJNb2RhbCIsIkRhdGFUYWJsZSIsIkNpcmN1bGFyTG9hZGVyIiwiTmF2YmFyIiwiU2VsZWN0IiwiRHJvcGRvd24iLCJBbnRNb2RhbCIsIkFsZXJ0IiwiSW9NZE1vcmUiLCJMaW5rIiwiQmFja2Ryb3BCbHVyTG9hZGVyIiwiZmllbGRTaXplIiwiQ3VzdG9tQWxlcnREaWFsb2ciLCJCcmVhZGNydW1iIiwiSW5kaXZpZHVhbFJlZ2lzdHJhdGlvbkNoaXRQYXltZW50TGluayIsIl9zIiwiZ3JvdXBzIiwic2V0R3JvdXBzIiwiYWN0dWFsR3JvdXBzIiwic2V0QWN0dWFsR3JvdXBzIiwic2VsZWN0ZWRHcm91cCIsInNldFNlbGVjdGVkR3JvdXAiLCJUYWJsZVBheW1lbnRzIiwic2V0VGFibGVQYXltZW50cyIsInNlbGVjdGVkQXVjdGlvbkdyb3VwIiwic2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXAiLCJzZWxlY3RlZEdyb3VwSWQiLCJzZXRTZWxlY3RlZEdyb3VwSWQiLCJzZWxlY3RlZEF1Y3Rpb25Hcm91cElkIiwic2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCIsImZpbHRlcmVkVXNlcnMiLCJzZXRGaWx0ZXJlZFVzZXJzIiwidmlld0xvYWRlciIsInNldFZpZXdMb2FkZXIiLCJmaWx0ZXJlZEF1Y3Rpb24iLCJzZXRGaWx0ZXJlZEF1Y3Rpb24iLCJncm91cEluZm8iLCJzZXRHcm91cEluZm8iLCJzaG93TW9kYWwiLCJzZXRTaG93TW9kYWwiLCJzaG93TW9kYWxWaWV3Iiwic2V0U2hvd01vZGFsVmlldyIsImN1cnJlbnRWaWV3R3JvdXAiLCJzZXRDdXJyZW50Vmlld0dyb3VwIiwidG9kYXkiLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsInRvbW9ycm93Iiwic2V0RGF0ZSIsImdldERhdGUiLCJ0b21vcnJvd0Zvcm1hdHRlZCIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZGlzYWJsZWQiLCJzZXREaXNhYmxlZCIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwiYm9ycm93ZXJzIiwic2V0Qm9ycm93ZXJzIiwicGlnbWVDdXN0b21lcnMiLCJzZXRQaWdtZUN1c3RvbWVycyIsImVuYWJsZUdyb3VwQ29sdW1uIiwic2V0RW5hYmxlR3JvdXBDb2x1bW4iLCJwYXltZW50R3JvdXBUaWNrZXRzIiwic2V0UGF5bWVudEdyb3VwVGlja2V0cyIsInJlbmRlciIsInNldFJlcmVuZGVyIiwib3BlbkJhY2tkcm9wTG9hZGVyIiwic2V0T3BlbkJhY2tkcm9wTG9hZGVyIiwiY3VycmVudEdyb3VwSWQiLCJzZXRDdXJyZW50R3JvdXBJZCIsImFsZXJ0Iiwic2V0QWxlcnQiLCJ2aXNpYmxlIiwibWVzc2FnZSIsInR5cGUiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsImRyb3BEb3duSXRlbXMiLCJncm91cCIsImRyb3BEb3duSXRlbUxpc3QiLCJrZXkiLCJsYWJlbCIsIl9pZCIsImhhbmRsZVZpZXdNb2RhbE9wZW4iLCJHbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInZhbHVlIiwidGFyZ2V0IiwiZXJyb3JzIiwic2V0RXJyb3JzIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInVzZXJfaWQiLCJhbW91bnQiLCJwYXltZW50X2dyb3VwX3RpY2tldHMiLCJleHBpcnkiLCJzZW5kX3NtcyIsInNlbmRfZW1haWwiLCJ1c3IiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiYWRtaW5fdHlwZSIsIkpTT04iLCJwYXJzZSIsImNvbnNvbGUiLCJlcnJvciIsImZldGNoVG9kYXlzUGF5bWVudHMiLCJyZXNwb25zZSIsImdldCIsInBhcmFtcyIsImZyb21fZGF0ZSIsInRvX2RhdGUiLCJkYXRhIiwibGVuZ3RoIiwiZm9ybWF0dGVkRGF0YSIsIm1hcCIsImluZGV4IiwiZ3JvdXBfaWQiLCJncm91cF9uYW1lIiwiaWQiLCJuYW1lIiwiZnVsbF9uYW1lIiwicGhvbmVfbnVtYmVyIiwidGlja2V0IiwicGF5bWVudF9zdGF0dXMiLCJ0cmFuc2FjdGlvbl9kYXRlIiwiZm9ybWF0UGF5RGF0ZSIsImNyZWF0ZWRBdCIsImFjdGlvbiIsIml0ZW1zIiwiZmV0Y2hDdXN0b21lckxvYW5EZXRhaWxzIiwic3RhdHVzIiwiRXJyb3IiLCJlcnIiLCJsb2ciLCJmZXRjaEdyb3VwcyIsInZhbGlkYXRlRm9ybSIsIm5ld0Vycm9ycyIsImN1c3RvbWVyIiwicGFyc2VGbG9hdCIsImlzTmFOIiwiT2JqZWN0Iiwia2V5cyIsImhhbmRsZUNoYW5nZSIsInByZXZEYXRhIiwiaGFuZGxlUGF5bWVudEFudFNlbGVjdCIsInZhbHVlcyIsImhhbmRsZUdyb3VwQ2hhbmdlIiwiZ3JvdXBJZCIsImNvbHVtbnMiLCJoZWFkZXIiLCJwdXNoIiwiaGFuZGxlQ3VzdG9tZXIiLCJwcmV2Rm9ybURhdGEiLCJoYW5kbGVHcm91cEF1Y3Rpb25DaGFuZ2UiLCJoYW5kbGVHcm91cFBheW1lbnQiLCJoYW5kbGVHcm91cFBheW1lbnRDaGFuZ2UiLCJkYXRlU3RyaW5nIiwidXJsIiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJpc1ZhbGlkIiwicGF5bG9hZCIsInBvc3QiLCJwcmV2IiwidmFsaWRBdWN0aW9ucyIsImZpbHRlciIsImF1Y3Rpb24iLCJlbnJvbGxtZW50Iiwic2VsZWN0ZWRuZXdHcm91cCIsImZpbmQiLCJnIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvU3RyaW5nIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsInVuZGVmaW5lZCIsIml0ZW0iLCJzb21lIiwiU3RyaW5nIiwiaGVpZ2h0IiwiZW50cnkiLCJncm91cE5hbWUiLCJ0aWNrZXRzIiwicGlnbWUiLCJwaWdtZV9pZCIsInBheWFibGVfYW1vdW50IiwiYm9ycm93ZXIiLCJsb2FuX2lkIiwibG9hbl9hbW91bnQiLCJOdW1iZXIiLCJ0b0ZpeGVkIiwiY2hlY2tlZCIsImdyb3VwX3ZhbHVlIiwiZ3JvdXBfaW5zdGFsbCIsIndpbl9hbW91bnQiLCJjb21taXNzaW9uIiwiZGl2aWRlbnQiLCJkaXZpZGVudF9oZWFkIiwicGF5YWJsZSIsImF1Y3Rpb25fZGF0ZSIsIm5leHRfZGF0ZSIsInVwZGF0ZWRBdCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkluZGl2aWR1YWxSZWdpc3RyYXRpb25DaGl0UGF5bWVudExpbmsuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IHsgU2VsZWN0LCBEcm9wZG93biwgTW9kYWwgYXMgQW50TW9kYWwsIEFsZXJ0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBCYWNrZHJvcEJsdXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9CYWNrZHJvcEJsdXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgZmllbGRTaXplIH0gZnJvbSBcIi4uL2RhdGEvZmllbGRTaXplXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydERpYWxvZyBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2dcIjtcclxuaW1wb3J0IEJyZWFkY3J1bWIgZnJvbSBcIi4uL2hlbHBlcnMvQnJlYWRjcnVtYlwiO1xyXG5cclxuY29uc3QgSW5kaXZpZHVhbFJlZ2lzdHJhdGlvbkNoaXRQYXltZW50TGluayA9ICgpID0+IHtcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthY3R1YWxHcm91cHMsIHNldEFjdHVhbEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXAsIHNldFNlbGVjdGVkR3JvdXBdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW1RhYmxlUGF5bWVudHMsIHNldFRhYmxlUGF5bWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEF1Y3Rpb25Hcm91cCwgc2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXBJZCwgc2V0U2VsZWN0ZWRHcm91cElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEF1Y3Rpb25Hcm91cElkLCBzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtmaWx0ZXJlZFVzZXJzLCBzZXRGaWx0ZXJlZFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdmlld0xvYWRlciwgc2V0Vmlld0xvYWRlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkQXVjdGlvbiwgc2V0RmlsdGVyZWRBdWN0aW9uXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZ3JvdXBJbmZvLCBzZXRHcm91cEluZm9dID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbFZpZXcsIHNldFNob3dNb2RhbFZpZXddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50Vmlld0dyb3VwLCBzZXRDdXJyZW50Vmlld0dyb3VwXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcclxuICBcclxuICAvLyBDYWxjdWxhdGUgdG9tb3Jyb3cgY29ycmVjdGx5IChjdXJyZW50IGRhdGUgKyAxIGRheSlcclxuICBjb25zdCB0b21vcnJvdyA9IG5ldyBEYXRlKCk7XHJcbiAgdG9tb3Jyb3cuc2V0RGF0ZSh0b21vcnJvdy5nZXREYXRlKCkgKyAxKTtcclxuICBjb25zdCB0b21vcnJvd0Zvcm1hdHRlZCA9IHRvbW9ycm93LnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdO1xyXG5cclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZGlzYWJsZWQsIHNldERpc2FibGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYm9ycm93ZXJzLCBzZXRCb3Jyb3dlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtwaWdtZUN1c3RvbWVycywgc2V0UGlnbWVDdXN0b21lcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtlbmFibGVHcm91cENvbHVtbiwgc2V0RW5hYmxlR3JvdXBDb2x1bW5dID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW3BheW1lbnRHcm91cFRpY2tldHMsIHNldFBheW1lbnRHcm91cFRpY2tldHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtyZW5kZXIsIHNldFJlcmVuZGVyXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFtvcGVuQmFja2Ryb3BMb2FkZXIsIHNldE9wZW5CYWNrZHJvcExvYWRlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2N1cnJlbnRHcm91cElkLCBzZXRDdXJyZW50R3JvdXBJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBcclxuICAvLyBBbGVydCBzdGF0ZSBmb3IgQW50IERlc2lnbiBBbGVydFxyXG4gIGNvbnN0IFthbGVydCwgc2V0QWxlcnRdID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJsZTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCJcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgICB0eXBlOiBcImluZm9cIixcclxuICAgIH0pO1xyXG5cclxuICBjb25zdCBkcm9wRG93bkl0ZW1zID0gKGdyb3VwKSA9PiB7XHJcbiAgICBjb25zdCBkcm9wRG93bkl0ZW1MaXN0ID0gW1xyXG4gICAgICB7XHJcbiAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgPExpbmsgdG89e2AvcHJpbnQvJHtncm91cC5faWR9YH0gY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwIFwiPlxyXG4gICAgICAgICAgICBQcmludFxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICksXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBrZXk6IFwiM1wiLFxyXG4gICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVmlld01vZGFsT3Blbihncm91cC5faWQpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBWaWV3XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApLFxyXG4gICAgICB9LFxyXG4gICAgXTtcclxuXHJcbiAgICByZXR1cm4gZHJvcERvd25JdGVtTGlzdDtcclxuICB9O1xyXG4gIFxyXG4gIGNvbnN0IEdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRTZWFyY2hUZXh0KHZhbHVlKTtcclxuICB9O1xyXG4gIFxyXG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICB1c2VyX2lkOiBcIlwiLFxyXG4gICAgYW1vdW50OiBcIlwiLFxyXG4gICAgcGF5bWVudF9ncm91cF90aWNrZXRzOiBbXSxcclxuICAgIGV4cGlyeTogdG9tb3Jyb3dGb3JtYXR0ZWQsIC8vIFVzZSB0aGUgY29ycmVjdGx5IGNhbGN1bGF0ZWQgdG9tb3Jyb3dcclxuICAgIHNlbmRfc21zOiB0cnVlLFxyXG4gICAgc2VuZF9lbWFpbDogdHJ1ZSxcclxuICB9KTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHVzciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGxldCBhZG1pbl90eXBlID0gbnVsbDtcclxuICAgIHRyeSB7XHJcbiAgICAgIGlmICh1c3IpIHtcclxuICAgICAgICBhZG1pbl90eXBlID0gSlNPTi5wYXJzZSh1c3IpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gcGFyc2UgdXNlciBmcm9tIGxvY2FsU3RvcmFnZTpcIiwgZSk7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgZmV0Y2hUb2RheXNQYXltZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRUYWJsZVBheW1lbnRzKFtdKTtcclxuICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3BheW1lbnRhcGkvcGF5bWVudC1saW5rL3JlZ2lzdHJhdGlvbi9cIiwge1xyXG4gICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgIGZyb21fZGF0ZTogdG9kYXksXHJcbiAgICAgICAgICAgIHRvX2RhdGU6IHRvZGF5LFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9KTtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLm1hcCgoZ3JvdXAsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIGlmICghZ3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9uYW1lKSByZXR1cm4ge307XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgX2lkOiBncm91cC5faWQsXHJcbiAgICAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgICBuYW1lOiBncm91cD8udXNlcl9pZD8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgICAgIHBob25lX251bWJlcjogZ3JvdXA/LnVzZXJfaWQ/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgICBncm91cF9uYW1lOiBncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgICAgdGlja2V0OiBncm91cC50aWNrZXQsXHJcbiAgICAgICAgICAgICAgYW1vdW50OiBncm91cC5hbW91bnQsXHJcbiAgICAgICAgICAgICAgcGF5bWVudF9zdGF0dXM6IGdyb3VwLnBheW1lbnRfc3RhdHVzLFxyXG4gICAgICAgICAgICAgIHRyYW5zYWN0aW9uX2RhdGU6IGZvcm1hdFBheURhdGUoZ3JvdXAuY3JlYXRlZEF0KSxcclxuICAgICAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpdGVtczogZHJvcERvd25JdGVtcyhncm91cCksXHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgc2V0VGFibGVQYXltZW50cyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgICAgIHNldEVuYWJsZUdyb3VwQ29sdW1uKHRydWUpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24oW10pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcGF5bWVudCBMaW5rIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24oW10pO1xyXG4gICAgICAgIC8vIFNob3cgZXJyb3IgYWxlcnRcclxuICAgICAgICBzZXRBbGVydCh7XHJcbiAgICAgICAgICB2aXNpYmxlOiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gbG9hZCBwYXltZW50IGRhdGFcIixcclxuICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIlxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hUb2RheXNQYXltZW50cygpO1xyXG4gIH0sIFtyZW5kZXJdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldEJvcnJvd2VycyhbXSk7XHJcbiAgICBjb25zdCBmZXRjaEN1c3RvbWVyTG9hbkRldGFpbHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgICAgYC9sb2Fucy9nZXQtYm9ycm93ZXItYnktdXNlci1pZC8ke3NlbGVjdGVkR3JvdXBJZH1gXHJcbiAgICAgICAgKTtcclxuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID49IDQwMClcclxuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcImZldGNoaW5nIGxvYW4gYm9ycm93ZXJzIEZhaWxlZFwiKTtcclxuICAgICAgICBzZXRCb3Jyb3dlcnMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiRXJyb3IgT2NjdXJyZWRcIik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hDdXN0b21lckxvYW5EZXRhaWxzKCk7XHJcbiAgfSwgW3NlbGVjdGVkR3JvdXBJZF0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgc2V0UGlnbWVDdXN0b21lcnMoW10pO1xyXG4gICAgY29uc3QgZmV0Y2hDdXN0b21lckxvYW5EZXRhaWxzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICAgIGAvcGlnbWUvZ2V0LXBpZ21lLWN1c3RvbWVyLWJ5LXVzZXItaWQvJHtzZWxlY3RlZEdyb3VwSWR9YFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA+PSA0MDApXHJcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJmZXRjaGluZyBwaWdtZSBjdXN0b21lcnMgRmFpbGVkXCIpO1xyXG4gICAgICAgIHNldFBpZ21lQ3VzdG9tZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcclxuICAgICAgICAgIFwiRXJyb3IgT2NjdXJyZWQgd2hpbGUgZmV0Y2hpbmcgcGlnbWUgY3VzdG9tZXJzLFwiLFxyXG4gICAgICAgICAgZXJyLm1lc3NhZ2VcclxuICAgICAgICApO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoQ3VzdG9tZXJMb2FuRGV0YWlscygpO1xyXG4gIH0sIFtzZWxlY3RlZEdyb3VwSWRdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpO1xyXG4gICAgICAgIHNldEdyb3VwcyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hHcm91cHMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEdyb3VwcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvZ3JvdXAvZ2V0LWdyb3VwLWFkbWluXCIpO1xyXG4gICAgICAgIHNldEFjdHVhbEdyb3VwcyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hHcm91cHMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IHZhbGlkYXRlRm9ybSA9ICgpID0+IHtcclxuICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG5cclxuICAgIGlmICghc2VsZWN0ZWRHcm91cElkKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5jdXN0b21lciA9IFwiUGxlYXNlIHNlbGVjdCBhIGN1c3RvbWVyXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFwYXltZW50R3JvdXBUaWNrZXRzIHx8IHBheW1lbnRHcm91cFRpY2tldHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5wYXltZW50X2dyb3VwX3RpY2tldHMgPSBcIlBsZWFzZSBzZWxlY3QgYSBncm91cCBhbmQgdGlja2V0XCI7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgYW1vdW50ID0gcGFyc2VGbG9hdChmb3JtRGF0YS5hbW91bnQpO1xyXG4gICAgaWYgKGlzTmFOKGFtb3VudCkgfHwgYW1vdW50IDw9IDApIHtcclxuICAgICAgbmV3RXJyb3JzLmFtb3VudCA9IFwiUGxlYXNlIGVudGVyIGEgdmFsaWQgcG9zaXRpdmUgYW1vdW50XCI7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0RXJyb3JzKG5ld0Vycm9ycyk7XHJcbiAgICByZXR1cm4gT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldkRhdGEpID0+ICh7IC4uLnByZXZEYXRhLCBbbmFtZV06IFwiXCIgfSkpO1xyXG4gIH07XHJcbiAgXHJcbiAgY29uc3QgaGFuZGxlUGF5bWVudEFudFNlbGVjdCA9ICh2YWx1ZXMpID0+IHtcclxuICAgIHNldFBheW1lbnRHcm91cFRpY2tldHModmFsdWVzKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVHcm91cENoYW5nZSA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZEdyb3VwKGdyb3VwSWQpO1xyXG5cclxuICAgIGlmIChncm91cElkKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvZW5yb2xsL2dldC1ncm91cC1lbnJvbGwvJHtncm91cElkfWApO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRVc2VycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRVc2VycyhbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbnJvbGxtZW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKFtdKTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0RmlsdGVyZWRVc2VycyhbXSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwidHJhbnNhY3Rpb25fZGF0ZVwiLCBoZWFkZXI6IFwiVHJhbnNhY3Rpb24gRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgUGhvbmUgTnVtYmVyXCIgfSxcclxuICBdO1xyXG4gIGlmIChlbmFibGVHcm91cENvbHVtbikge1xyXG4gICAgY29sdW1ucy5wdXNoKHsga2V5OiBcImdyb3VwX25hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9KTtcclxuICB9XHJcbiAgY29sdW1ucy5wdXNoKFxyXG4gICAgeyBrZXk6IFwidGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXQgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudFwiLCBoZWFkZXI6IFwiQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcInBheW1lbnRfc3RhdHVzXCIsIGhlYWRlcjogXCJQYXltZW50IFN0YXR1c1wiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH1cclxuICApO1xyXG5cclxuICBjb25zdCBoYW5kbGVDdXN0b21lciA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZEdyb3VwSWQoZ3JvdXBJZCk7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkZvcm1EYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2Rm9ybURhdGEsXHJcbiAgICAgIHVzZXJfaWQ6IGdyb3VwSWQsXHJcbiAgICB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXZEYXRhKSA9PiAoeyAuLi5wcmV2RGF0YSwgY3VzdG9tZXI6IFwiXCIgfSkpO1xyXG4gICAgc2V0UGF5bWVudEdyb3VwVGlja2V0cyhbXSk7XHJcbiAgICBoYW5kbGVHcm91cENoYW5nZShncm91cElkKTtcclxuICAgIGhhbmRsZUdyb3VwQXVjdGlvbkNoYW5nZShncm91cElkKTtcclxuXHJcbiAgICBpZiAoZ3JvdXBJZCkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL2dyb3VwL2dldC1ieS1pZC1ncm91cC8ke2dyb3VwSWR9YCk7XHJcbiAgICAgICAgc2V0R3JvdXBJbmZvKHJlc3BvbnNlLmRhdGEgfHwge30pO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIHNldEdyb3VwSW5mbyh7fSk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEdyb3VwSW5mbyh7fSk7XHJcbiAgICB9XHJcbiAgfTtcclxuICBcclxuICBjb25zdCBoYW5kbGVHcm91cFBheW1lbnQgPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBJZChncm91cElkKTtcclxuICAgIGhhbmRsZUdyb3VwUGF5bWVudENoYW5nZShncm91cElkKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBmb3JtYXRQYXlEYXRlID0gKGRhdGVTdHJpbmcpID0+IHtcclxuICAgIHJldHVybiBkYXRlU3RyaW5nPy5zcGxpdChcIlRcIilbMF07XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3JvdXBQYXltZW50Q2hhbmdlID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHNldFNlbGVjdGVkQXVjdGlvbkdyb3VwKGdyb3VwSWQpO1xyXG4gICAgaWYgKGdyb3VwSWQpIHtcclxuICAgICAgbGV0IHVybDtcclxuICAgICAgaWYgKGdyb3VwSWQgPT09IFwidG9kYXlcIikge1xyXG4gICAgICAgIHVybCA9IGAvcGF5bWVudGFwaS9wYXltZW50LWxpbmsvcmVnaXN0cmF0aW9uL2dldC1wYXltZW50cz9mcm9tX2RhdGU9JHt0b2RheX0mdG9fZGF0ZT0ke3RvZGF5fWA7XHJcbiAgICAgICAgc2V0RW5hYmxlR3JvdXBDb2x1bW4odHJ1ZSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdXJsID0gYC9wYXltZW50YXBpL3BheW1lbnQtbGluay9yZWdpc3RyYXRpb24vJHtncm91cElkfWA7XHJcbiAgICAgICAgc2V0RW5hYmxlR3JvdXBDb2x1bW4oZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0VGFibGVQYXltZW50cyhbXSk7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldCh1cmwpO1xyXG5cclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLm1hcCgoZ3JvdXAsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIGlmICghZ3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9uYW1lKSByZXR1cm4ge307XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgX2lkOiBncm91cC5faWQsXHJcbiAgICAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgICBuYW1lOiBncm91cD8udXNlcl9pZD8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgICAgIHBob25lX251bWJlcjogZ3JvdXA/LnVzZXJfaWQ/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgICBncm91cF9uYW1lOiBncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgICAgdGlja2V0OiBncm91cC50aWNrZXQsXHJcbiAgICAgICAgICAgICAgYW1vdW50OiBncm91cC5hbW91bnQsXHJcbiAgICAgICAgICAgICAgdHJhbnNhY3Rpb25fZGF0ZTogZ3JvdXA/LmNyZWF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICAgICAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgIGl0ZW1zOiBkcm9wRG93bkl0ZW1zKGdyb3VwKSxcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBzZXRUYWJsZVBheW1lbnRzKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24oW10pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcGF5bWVudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgICAgICAvLyBTaG93IGVycm9yIGFsZXJ0XHJcbiAgICAgICAgc2V0QWxlcnQoe1xyXG4gICAgICAgICAgdmlzaWJsZTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGxvYWQgcGF5bWVudCBkYXRhXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCJcclxuICAgICAgICB9KTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24oW10pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBjb25zdCBpc1ZhbGlkID0gdmFsaWRhdGVGb3JtKCk7XHJcbiAgICB0cnkge1xyXG4gICAgICBpZiAoaXNWYWxpZCkge1xyXG4gICAgICAgIHNldERpc2FibGVkKHRydWUpO1xyXG4gICAgICAgIHNldEFsZXJ0KHsgdmlzaWJsZTogZmFsc2UsIG1lc3NhZ2U6IFwiXCIsIHR5cGU6IFwiaW5mb1wiIH0pO1xyXG4gICAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgbGV0IHBheWxvYWQ7XHJcbiAgICAgICAgY29uc3QgdXNyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgICAgIGxldCBhZG1pbl90eXBlID0gbnVsbDtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgaWYgKHVzcikge1xyXG4gICAgICAgICAgICBhZG1pbl90eXBlID0gSlNPTi5wYXJzZSh1c3IpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gcGFyc2UgdXNlciBmcm9tIGxvY2FsU3RvcmFnZTpcIiwgZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGZvcm1EYXRhLnBheW1lbnRfZ3JvdXBfdGlja2V0cyA9IHBheW1lbnRHcm91cFRpY2tldHM7XHJcbiAgICAgICAgZm9ybURhdGEuYWRtaW5fdHlwZSA9IGFkbWluX3R5cGU/Ll9pZDtcclxuICAgICAgICBzZXRPcGVuQmFja2Ryb3BMb2FkZXIodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChcIi9wYXltZW50YXBpL3BheW1lbnQtbGluay9yZWdpc3RyYXRpb25cIiwgZm9ybURhdGEpO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDIwMSkge1xyXG4gICAgICAgICAgc2V0U2VsZWN0ZWRHcm91cElkKFwiXCIpO1xyXG4gICAgICAgICAgc2V0UGF5bWVudEdyb3VwVGlja2V0cyhbXSk7XHJcbiAgICAgICAgICBzZXREaXNhYmxlZChmYWxzZSk7XHJcbiAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgIHVzZXJfaWQ6IFwiXCIsXHJcbiAgICAgICAgICAgIGFtb3VudDogXCJcIixcclxuICAgICAgICAgICAgcGF5bWVudF9ncm91cF90aWNrZXRzOiBbXSxcclxuICAgICAgICAgICAgZXhwaXJ5OiB0b21vcnJvd0Zvcm1hdHRlZCwgLy8gUmVzZXQgd2l0aCBjb3JyZWN0IHRvbW9ycm93IGRhdGVcclxuICAgICAgICAgICAgc2VuZF9zbXM6IHRydWUsXHJcbiAgICAgICAgICAgIHNlbmRfZW1haWw6IHRydWUsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIHNldEFsZXJ0KHtcclxuICAgICAgICAgICAgdmlzaWJsZTogdHJ1ZSxcclxuICAgICAgICAgICAgbWVzc2FnZTogXCJQYXltZW50IEFkZGVkIFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA+PSA0MDApIHtcclxuICAgICAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgICBzZXRTZWxlY3RlZEdyb3VwSWQoXCJcIik7XHJcbiAgICAgICAgICBzZXRQYXltZW50R3JvdXBUaWNrZXRzKFtdKTtcclxuICAgICAgICAgIHNldERpc2FibGVkKGZhbHNlKTtcclxuICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgdXNlcl9pZDogXCJcIixcclxuICAgICAgICAgICAgYW1vdW50OiBcIlwiLFxyXG4gICAgICAgICAgICBwYXltZW50X2dyb3VwX3RpY2tldHM6IFtdLFxyXG4gICAgICAgICAgICBleHBpcnk6IHRvbW9ycm93Rm9ybWF0dGVkLCAvLyBSZXNldCB3aXRoIGNvcnJlY3QgdG9tb3Jyb3cgZGF0ZVxyXG4gICAgICAgICAgICBzZW5kX3NtczogdHJ1ZSxcclxuICAgICAgICAgICAgc2VuZF9lbWFpbDogdHJ1ZSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgc2V0QWxlcnQoe1xyXG4gICAgICAgICAgICB2aXNpYmxlOiB0cnVlLFxyXG4gICAgICAgICAgICBtZXNzYWdlOiBcIlBheW1lbnQgQWRkZWQgRmFpbGVkXCIsXHJcbiAgICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgc2V0U2VsZWN0ZWRHcm91cElkKFwiXCIpO1xyXG4gICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgdXNlcl9pZDogXCJcIixcclxuICAgICAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgcGF5bWVudF9ncm91cF90aWNrZXRzOiBbXSxcclxuICAgICAgICBleHBpcnk6IHRvbW9ycm93Rm9ybWF0dGVkLCAvLyBSZXNldCB3aXRoIGNvcnJlY3QgdG9tb3Jyb3cgZGF0ZVxyXG4gICAgICAgIHNlbmRfc21zOiB0cnVlLFxyXG4gICAgICAgIHNlbmRfZW1haWw6IHRydWUsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRBbGVydCh7XHJcbiAgICAgICAgdmlzaWJsZTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBgRXJyb3Igc3VibWl0dGluZyBwYXltZW50IGRhdGE6ICR7ZXJyb3IubWVzc2FnZX1gLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICAgIHNldERpc2FibGVkKGZhbHNlKTtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHN1Ym1pdHRpbmcgcGF5bWVudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRPcGVuQmFja2Ryb3BMb2FkZXIoZmFsc2UpO1xyXG4gICAgICBzZXRSZXJlbmRlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVZpZXdNb2RhbE9wZW4gPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgICAgc2V0U2hvd01vZGFsVmlldyh0cnVlKTtcclxuICAgICAgc2V0Q3VycmVudEdyb3VwSWQoZ3JvdXBJZCk7XHJcbiAgICAgIHNldFZpZXdMb2FkZXIodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3BheW1lbnRhcGkvcGF5bWVudC1saW5rL3JlZ2lzdHJhdGlvbi8ke2dyb3VwSWR9YCk7XHJcbiAgICAgIHNldEN1cnJlbnRWaWV3R3JvdXAocmVzcG9uc2UuZGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3Igdmlld2luZyBQYXltZW50OlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0KHtcclxuICAgICAgICB2aXNpYmxlOiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGxvYWQgcGF5bWVudCBkZXRhaWxzXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiXHJcbiAgICAgIH0pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIHNldFZpZXdMb2FkZXIoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUdyb3VwQXVjdGlvbkNoYW5nZSA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICBpZiAoZ3JvdXBJZCkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoXHJcbiAgICAgICAgICBgL2Vucm9sbC9nZXQtdXNlci10aWNrZXRzLXJlcG9ydC8ke2dyb3VwSWR9YFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBjb25zdCB2YWxpZEF1Y3Rpb25zID0gcmVzcG9uc2UuZGF0YS5maWx0ZXIoXHJcbiAgICAgICAgICAgIChhdWN0aW9uKSA9PiBhdWN0aW9uLmVucm9sbG1lbnQgJiYgYXVjdGlvbi5lbnJvbGxtZW50Lmdyb3VwXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKHZhbGlkQXVjdGlvbnMpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24oW10pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW5yb2xsbWVudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgICAgICAvLyBTaG93IGVycm9yIGFsZXJ0XHJcbiAgICAgICAgc2V0QWxlcnQoe1xyXG4gICAgICAgICAgdmlzaWJsZTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGxvYWQgZ3JvdXAgYXVjdGlvbiBkYXRhXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCJcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgIH1cclxuICB9O1xyXG4gIFxyXG4gIGNvbnN0IHNlbGVjdGVkbmV3R3JvdXAgPSBhY3R1YWxHcm91cHMuZmluZChcclxuICAgIChnKSA9PiBnLl9pZCA9PT0gc2VsZWN0ZWRBdWN0aW9uR3JvdXBJZFxyXG4gICk7XHJcbiAgXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIHtvcGVuQmFja2Ryb3BMb2FkZXIgPyAoXHJcbiAgICAgICAgPEJhY2tkcm9wQmx1ckxvYWRlciB0aXRsZT17XCJwYXltZW50IERhdGEgcHJvY2Vzc2luZy4uLi5cIn0gLz5cclxuICAgICAgKSA6IChcclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiID5cclxuICAgICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17R2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn1cclxuICAgICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHsvKiBBbnQgRGVzaWduIEFsZXJ0ICovfVxyXG4gICAgICAgICAgICB7YWxlcnQudmlzaWJsZSAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCB0b3AtNCByaWdodC00IHotNTAgdy05NlwiPlxyXG4gICAgICAgICAgICAgICAgPEFsZXJ0XHJcbiAgICAgICAgICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Lm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9e2FsZXJ0LnR5cGV9XHJcbiAgICAgICAgICAgICAgICAgIHNob3dJY29uXHJcbiAgICAgICAgICAgICAgICAgIGNsb3NhYmxlXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEFsZXJ0KHsgLi4uYWxlcnQsIHZpc2libGU6IGZhbHNlIH0pfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5SZWdpc3RyYXRpb24gUGF5bWVudCBMaW5rczwvaDE+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02ICBtYi04XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTEwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb250LWJvbGRcIj5TZWFyY2ggb3IgU2VsZWN0IEdyb3VwPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJUb2RheSdzIFBheW1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCAgIGgtMTQgbWF4LXctbWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQXVjdGlvbkdyb3VwSWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUdyb3VwUGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e1wiIzFcIn0gdmFsdWU9e1widG9kYXlcIn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFRvZGF5J3MgUGF5bWVudHNcclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIHthY3R1YWxHcm91cHMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dNb2RhbCh0cnVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtNCBiZy12aW9sZXQtNjAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLXZpb2xldC04MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICArIEFkZCBQYXltZW50IExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHtUYWJsZVBheW1lbnRzICYmIFRhYmxlUGF5bWVudHMubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGE9e1RhYmxlUGF5bWVudHMuZmlsdGVyKChpdGVtKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgT2JqZWN0LnZhbHVlcyhpdGVtKS5zb21lKCh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgU3RyaW5nKHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKHNlYXJjaFRleHQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiUGF5bWVudHNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1wiR3JvdXAgTmFtZVwiXX1cclxuICAgICAgICAgICAgICAgICAgICBwcmludEhlYWRlclZhbHVlcz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRuZXdHcm91cD8uZ3JvdXBfbmFtZSB8fCBcIlRvZGF5J3NcIixcclxuICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BQYXltZW50cy5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMCB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgIGRhdGE9XCJQYXltZW50cyBEYXRhXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZhaWx1cmU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBUYWJsZVBheW1lbnRzLmxlbmd0aCA8PSAwICYmIHNlbGVjdGVkQXVjdGlvbkdyb3VwSWRcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWx9XHJcbiAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRHcm91cElkKFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICAgICAgICAgICAgICBzZXRQYXltZW50R3JvdXBUaWNrZXRzKFtdKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi02IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgYm9yZGVyLWIgcGItMlwiPlxyXG4gICAgICAgICAgICAgICAgICBBZGQgUGF5bWVudCBMaW5rXHJcbiAgICAgICAgICAgICAgICA8L2gzPlxyXG5cclxuICAgICAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IG5vVmFsaWRhdGU+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIEN1c3RvbWVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgJHtmaWVsZFNpemUuaGVpZ2h0fWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBvciBTZWFyY2ggQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbj8uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/LnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkR3JvdXBJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ3VzdG9tZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2dyb3Vwcy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7YCR7Z3JvdXAuZnVsbF9uYW1lfSB8ICR7Z3JvdXAucGhvbmVfbnVtYmVyfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY3VzdG9tZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmN1c3RvbWVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cC10aWNrZXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIEdyb3VwICYgVGlja2V0IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImdyb3VwLXRpY2tldFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBtb2RlPVwibXVsdGlwbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgR3JvdXAgfCBUaWNrZXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVBheW1lbnRBbnRTZWxlY3R9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGF5bWVudEdyb3VwVGlja2V0c31cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsICR7ZmllbGRTaXplLmhlaWdodH1gfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZEF1Y3Rpb24ubWFwKChlbnRyeSwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZ3JvdXBOYW1lID1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBlbnRyeT8uZW5yb2xsbWVudD8uZ3JvdXA/Lmdyb3VwX25hbWUgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBcIlVubmFtZWQgR3JvdXBcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZ3JvdXBJZCA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZW50cnk/LmVucm9sbG1lbnQ/Lmdyb3VwPy5faWQgfHwgYG1pc3NpbmctJHtpbmRleH1gO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0aWNrZXQgPSBlbnRyeT8uZW5yb2xsbWVudD8udGlja2V0cyB8fCBcIlVua25vd25cIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtgY2hpdC0ke2dyb3VwSWR9fCR7dGlja2V0fWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YGNoaXQtJHtncm91cElkfXwke3RpY2tldH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cE5hbWV9IHwge3RpY2tldH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgIHtwaWdtZUN1c3RvbWVycz8ubWFwKChwaWdtZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17cGlnbWUuX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgcGlnbWUtJHtwaWdtZS5faWR9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtgJHtwaWdtZS5waWdtZV9pZH0gfCDigrkgJHtwaWdtZS5wYXlhYmxlX2Ftb3VudH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHtib3Jyb3dlcnM/Lm1hcCgoYm9ycm93ZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2JvcnJvd2VyLl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YGxvYW4tJHtib3Jyb3dlci5faWR9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtgbG9hbi0ke2JvcnJvd2VyLmxvYW5faWR9IHwg4oK5ICR7Ym9ycm93ZXIubG9hbl9hbW91bnR9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXltZW50X2dyb3VwX3RpY2tldHMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBheW1lbnRfZ3JvdXBfdGlja2V0c31cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEFtb3VudCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5hbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYW1vdW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuYW1vdW50ICYmIHBheW1lbnRHcm91cFRpY2tldHMubGVuZ3RoID4gMSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBJbmRpdmlkdWFsIFRpY2tldCBBbW91bnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1ncmF5LTEwMCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS03MDAgdGV4dC1zbSByb3VuZGVkLWxnIHAtMi41IGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJUb3RhbCBBbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXsoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBOdW1iZXIoZm9ybURhdGEuYW1vdW50KSAvIHBheW1lbnRHcm91cFRpY2tldHMubGVuZ3RoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKS50b0ZpeGVkKDIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgey8qIEV4cGlyeSBEYXRlIEZpZWxkICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImV4cGlyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRXhwaXJ5IERhdGVcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJleHBpcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImV4cGlyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBtaW49e3RvbW9ycm93Rm9ybWF0dGVkfSAvLyBQcmV2ZW50IHNlbGVjdGluZyBwYXN0IGRhdGVzXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZXhwaXJ5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBTZW5kIFNNUyBDaGVja2JveCAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJzZW5kX3Ntc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInNlbmRfc21zXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLnNlbmRfc21zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNlbmRfc21zOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIGJnLWdyYXktNTBcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwic2VuZF9zbXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFNlbmQgU01TXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogU2VuZCBFbWFpbCBDaGVja2JveCAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJzZW5kX2VtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwic2VuZF9lbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5zZW5kX2VtYWlsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNlbmRfZW1haWw6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgYmctZ3JheS01MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJzZW5kX2VtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTZW5kIEVtYWlsXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgcHQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzQgdGV4dC13aGl0ZSBiZy12aW9sZXQtNzAwIGhvdmVyOmJnLXZpb2xldC04MDAgYWN0aXZlOmJnLXZpb2xldC05MDAgXHJcbiAgICAgICAgICAgICAgICAgICBib3JkZXItMiBib3JkZXItdmlvbGV0LTcwMCBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctdmlvbGV0LTMwMCBcclxuICAgICAgICAgICAgICAgICAgIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIEFkZCBQYXltZW50IExpbmtcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICAgICAgICA8QW50TW9kYWxcclxuICAgICAgICAgICAgICBvcGVuPXtzaG93TW9kYWxWaWV3fVxyXG4gICAgICAgICAgICAgIG9uQ2FuY2VsPXsoKSA9PiBzZXRTaG93TW9kYWxWaWV3KGZhbHNlKX1cclxuICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTaG93TW9kYWxWaWV3KGZhbHNlKX1cclxuICAgICAgICAgICAgICBvbk9rPXsoKSA9PiBzZXRTaG93TW9kYWxWaWV3KGZhbHNlKX1cclxuICAgICAgICAgICAgICBvblJlbG9hZD17KCkgPT4gaGFuZGxlVmlld01vZGFsT3BlbihjdXJyZW50R3JvdXBJZCl9XHJcbiAgICAgICAgICAgICAgZm9vdGVyPXs8ZGl2PjwvZGl2Pn1cclxuICAgICAgICAgICAgICBsb2FkaW5nPXt2aWV3TG9hZGVyfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgUGF5bWVudCBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+R3JvdXA6IDwvc3Ryb25nPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAge2N1cnJlbnRWaWV3R3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+R3JvdXAgVmFsdWU6PC9zdHJvbmc+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICB7Y3VycmVudFZpZXdHcm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX3ZhbHVlfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+R3JvdXAgSW5zdGFsbG1lbnQ6PC9zdHJvbmc+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICB7Y3VycmVudFZpZXdHcm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX2luc3RhbGx9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGdhcC14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5Vc2VyOjwvc3Ryb25nPiB7Y3VycmVudFZpZXdHcm91cD8udXNlcl9pZD8uZnVsbF9uYW1lfXtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgfCBUaWNrZXQ6IHtjdXJyZW50Vmlld0dyb3VwPy50aWNrZXR9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGdhcC14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5CaWQgQW1vdW50Ojwvc3Ryb25nPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAge2N1cnJlbnRWaWV3R3JvdXA/Lmdyb3VwX2lkPy5ncm91cF92YWx1ZSAtXHJcbiAgICAgICAgICAgICAgICAgIGN1cnJlbnRWaWV3R3JvdXA/Lndpbl9hbW91bnRcclxuICAgICAgICAgICAgICAgICAgICA/IGN1cnJlbnRWaWV3R3JvdXA/Lmdyb3VwX2lkPy5ncm91cF92YWx1ZSAtXHJcbiAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50Vmlld0dyb3VwPy53aW5fYW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgOiBcIlwifVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+Q29tbWlzc2lvbjo8L3N0cm9uZz4ge2N1cnJlbnRWaWV3R3JvdXA/LmNvbW1pc3Npb259XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGdhcC14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5XaW5uaW5nIEFtb3VudDo8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50Vmlld0dyb3VwPy53aW5fYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+RGl2aWRlbnQ6PC9zdHJvbmc+IHtjdXJyZW50Vmlld0dyb3VwPy5kaXZpZGVudH1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZ2FwLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPkRpdmlkZW50IHBlciBIZWFkOjwvc3Ryb25nPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAge2N1cnJlbnRWaWV3R3JvdXA/LmRpdmlkZW50X2hlYWR9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGdhcC14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5OZXh0IFBheWFibGU6PC9zdHJvbmc+IHtjdXJyZW50Vmlld0dyb3VwPy5wYXlhYmxlfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+QXVjdGlvbiBEYXRlOjwvc3Ryb25nPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAge2N1cnJlbnRWaWV3R3JvdXA/LmF1Y3Rpb25fZGF0ZX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZ2FwLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPk5leHQgRGF0ZTo8L3N0cm9uZz4ge2N1cnJlbnRWaWV3R3JvdXA/Lm5leHRfZGF0ZX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZ2FwLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPkNyZWF0ZWQgQXQ6PC9zdHJvbmc+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICB7Y3VycmVudFZpZXdHcm91cD8uY3JlYXRlZEF0Py5zcGxpdChcIlRcIilbMF19XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGdhcC14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5VcGRhdGVkIEF0Ojwvc3Ryb25nPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAge2N1cnJlbnRWaWV3R3JvdXA/LnVwZGF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvQW50TW9kYWw+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBJbmRpdmlkdWFsUmVnaXN0cmF0aW9uQ2hpdFBheW1lbnRMaW5rO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvSW5kaXZpZHVhbFJlZ2lzdHJhdGlvbkNoaXRQYXltZW50TGluay5qc3gifQ==