import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/GroupMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { Users, ChevronRight, Zap, Shield, UserCheck, Sparkles, ArrowUpRight, Grid3x3, UserMinus, AlertTriangle } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import { IoIosPersonAdd } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { MdCancel } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { FaPlus } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import __vite__cjsImport10_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport10_react["useEffect"]; const useState = __vite__cjsImport10_react["useState"];
import User from "/src/pages/User.jsx";
import UnApprovedCustomer from "/src/pages/UnApprovedCustomer.jsx";
import { GoDotFill } from "/node_modules/.vite/deps/react-icons_go.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import Group from "/src/pages/Group.jsx";
import FilterGroups from "/src/pages/FilterGroups.jsx";
const GroupMenu = () => {
  _s();
  const [filter, setFilter] = useState("group");
  const [showTips, setShowTips] = useState(false);
  const [total, setTotal] = useState({ totalCustomer: 0, totalUnverifiedCustomers: 0 });
  const navigate = useNavigate();
  const [showUserModal, setShowUserModal] = useState(false);
  const [errors, setErrors] = useState({});
  const [areas, setAreas] = useState([]);
  const cardData = [
    {
      title: "Total Customers",
      value: total.totalCustomer,
      description: "Overall Registered Users",
      icon: /* @__PURE__ */ jsxDEV(Users, { size: 20 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
        lineNumber: 57,
        columnNumber: 11
      }, this),
      iconColor: "text-blue-500",
      iconBgColor: "bg-blue-50",
      titleColor: "text-blue-600",
      dividerColor: "bg-blue-200"
    },
    {
      title: "Active Customers",
      value: "560",
      description: "Verified & Active Users",
      icon: /* @__PURE__ */ jsxDEV(UserCheck, { size: 20 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
        lineNumber: 67,
        columnNumber: 11
      }, this),
      iconColor: "text-emerald-500",
      iconBgColor: "bg-emerald-50",
      titleColor: "text-emerald-600",
      dividerColor: "bg-emerald-200"
    },
    {
      title: "Unverified Customers",
      value: total.totalUnverifiedCustomers,
      description: "Pending Verification",
      icon: /* @__PURE__ */ jsxDEV(UserMinus, { size: 20 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
        lineNumber: 77,
        columnNumber: 11
      }, this),
      iconColor: "text-amber-500",
      iconBgColor: "bg-amber-50",
      titleColor: "text-amber-600",
      dividerColor: "bg-amber-200"
    },
    {
      title: "Overdue Payments",
      value: "₹1,50,000",
      description: "Pending Collections",
      icon: /* @__PURE__ */ jsxDEV(AlertTriangle, { size: 20 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
        lineNumber: 87,
        columnNumber: 11
      }, this),
      iconColor: "text-red-500",
      iconBgColor: "bg-red-50",
      titleColor: "text-red-600",
      dividerColor: "bg-red-200"
    }
  ];
  useEffect(() => {
    const fetchTotalCount = async () => {
      try {
        const [response1] = await Promise.all(
          [
            api.get("/group/get-group-admin")
          ]
        );
        const data1 = await response1.data;
        const mobileAccess = data1?.filter(
          (item) => item?.mobile_access === true
        );
        setTotal((prev) => ({
          ...prev,
          // keep existing values
          totalCustomer: data1?.length,
          totalUnverifiedCustomers: mobileAccess?.length || 0
        }));
      } catch (error) {
        console.error("Error fetching total counts:", error);
      }
    };
    fetchTotalCount();
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen w-full relative overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
        lineNumber: 130,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-hidden", children: [
        /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
          lineNumber: 132,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-8 relative", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "relative group", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "absolute -inset-1 bg-gradient-to-r from-violet-600 to-purple-600 rounded-2xl blur-lg opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-tilt" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
                  lineNumber: 139,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "relative w-12 h-12 rounded-2xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-2xl", children: /* @__PURE__ */ jsxDEV(Users, { className: "w-6 h-6 text-white" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
                  lineNumber: 141,
                  columnNumber: 45
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
                  lineNumber: 140,
                  columnNumber: 41
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
                lineNumber: 138,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold bg-gradient-to-r from-slate-900 via-purple-900 to-slate-900 bg-clip-text text-transparent", children: "Group Management" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
                  lineNumber: 145,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-slate-600 mt-1 text-sm", children: "Manage and organize your Group base" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
                  lineNumber: 148,
                  columnNumber: 41
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
                lineNumber: 144,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
              lineNumber: 137,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setShowTips((prev) => !prev),
                className: "text-violet-500 font-medium hover:underline mb-2",
                children: showTips ? "Hide Quick Tips" : "Show Quick Tips"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
                lineNumber: 166,
                columnNumber: 37
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
              lineNumber: 152,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
            lineNumber: 136,
            columnNumber: 29
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
            lineNumber: 135,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative w-full h-0 top-1", children: /* @__PURE__ */ jsxDEV("div", { className: "absolute top-12 right-4", children: showTips && /* @__PURE__ */ jsxDEV("div", { className: "absolute bottom-full right-0  mb-2 \r\n                      w-80 p-3 bg-gray-800 text-white text-xs rounded-md \r\n                      shadow-lg z-[9999]", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setShowTips(false),
                className: "absolute  right-1 text-red text-sm font-bold hover:text-gray-300",
                children: "×"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
                lineNumber: 185,
                columnNumber: 41
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold mb-1 inline-block border-b-2 border-violet-500", children: "Quick Tips" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
              lineNumber: 191,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "leading-relaxed flex items-start gap-2", children: [
              /* @__PURE__ */ jsxDEV(GoDotFill, { className: "text-red-500 mt-1" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
                lineNumber: 193,
                columnNumber: 45
              }, this),
              "Use the Group directory to manage Groups, update Group information all in one place."
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
              lineNumber: 192,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "leading-relaxed flex items-start gap-2", children: [
              /* @__PURE__ */ jsxDEV(GoDotFill, { className: "text-red-500 mt-1" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
                lineNumber: 197,
                columnNumber: 45
              }, this),
              "Use the Mobile Access directory to display groups based on the app selection."
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
              lineNumber: 196,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
            lineNumber: 182,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
            lineNumber: 178,
            columnNumber: 29
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
            lineNumber: 175,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 mb-6 mt-5", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setFilter("group"),
                className: `px-4 py-2 rounded ${filter === "group" ? "bg-violet-500 text-white" : "bg-gray-200"}`,
                children: [
                  "Groups",
                  /* @__PURE__ */ jsxDEV("span", { className: `ml-2 px-2 py-0.5 text-xs font-bold rounded-full bg-purple-400 text-black"}`, children: total?.totalCustomer }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
                    lineNumber: 256,
                    columnNumber: 33
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
                lineNumber: 248,
                columnNumber: 29
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setFilter("mobile-access"),
                className: `px-4 py-2 rounded ${filter === "mobile-access" ? "bg-violet-500 text-white" : "bg-gray-200"}`,
                children: [
                  "Mobile Access Groups",
                  /* @__PURE__ */ jsxDEV("span", { className: `ml-2 px-2 py-0.5 text-xs font-bold rounded-full bg-purple-400 text-black"}`, children: total?.totalUnverifiedCustomers }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
                    lineNumber: 269,
                    columnNumber: 33
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
                lineNumber: 261,
                columnNumber: 29
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
            lineNumber: 247,
            columnNumber: 25
          }, this),
          filter === "group" && /* @__PURE__ */ jsxDEV(
            Group,
            {
              showUserModal,
              setShowUserModal,
              errors,
              setErrors
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
              lineNumber: 276,
              columnNumber: 48
            },
            this
          ),
          filter === "mobile-access" && /* @__PURE__ */ jsxDEV(FilterGroups, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
            lineNumber: 283,
            columnNumber: 56
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
          lineNumber: 133,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
        lineNumber: 131,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
      lineNumber: 120,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("style", { jsx: true, children: `
        @keyframes blob {
          0% {
            transform: translate(0px, 0px) scale(1);
          }
          33% {
            transform: translate(30px, -50px) scale(1.1);
          }
          66% {
            transform: translate(-20px, 20px) scale(0.9);
          }
          100% {
            transform: translate(0px, 0px) scale(1);
          }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
        @keyframes tilt {
          0%, 50%, 100% {
            transform: rotate(0deg);
          }
          25% {
            transform: rotate(0.5deg);
          }
          75% {
            transform: rotate(-0.5deg);
          }
        }
        .animate-tilt {
          animation: tilt 10s infinite;
        }
      ` }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
      lineNumber: 321,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx",
    lineNumber: 119,
    columnNumber: 5
  }, this);
};
_s(GroupMenu, "D7ddN12NtNMp9WPcDRt5xbObAUs=", false, function() {
  return [useNavigate];
});
_c = GroupMenu;
export default GroupMenu;
var _c;
$RefreshReg$(_c, "GroupMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GroupMenu.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0RrQjsyQkF4RGxCO0FBQWVBLE1BQVcsY0FBUSw2QkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDcEQsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLE9BQU9DLGNBQWNDLEtBQUtDLFFBQVFDLFdBQVdDLFVBQVVDLGNBQWNDLFNBQVNDLFdBQVdDLHFCQUFxQjtBQUN2SCxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLFVBQVU7QUFDakIsT0FBT0Msd0JBQXdCO0FBQy9CLFNBQVNDLGlCQUFpQjtBQUMxQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0Msa0JBQWtCO0FBRXpCLE1BQU1DLFlBQVlBLE1BQU07QUFBQUMsS0FBQTtBQUNwQixRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSVYsU0FBUyxPQUFPO0FBQzVDLFFBQU0sQ0FBQ1csVUFBVUMsV0FBVyxJQUFJWixTQUFTLEtBQUs7QUFDOUMsUUFBTSxDQUFDYSxPQUFPQyxRQUFRLElBQUlkLFNBQVMsRUFBRWUsZUFBZSxHQUFHQywwQkFBMEIsRUFBRSxDQUFDO0FBQ3BGLFFBQU1DLFdBQVdsQyxZQUFZO0FBQzdCLFFBQU0sQ0FBQ21DLGVBQWVDLGdCQUFnQixJQUFJbkIsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQ29CLFFBQVFDLFNBQVMsSUFBSXJCLFNBQVMsQ0FBQyxDQUFDO0FBNkJ2QyxRQUFNLENBQUNzQixPQUFPQyxRQUFRLElBQUl2QixTQUFTLEVBQUU7QUFDckMsUUFBTXdCLFdBQVc7QUFBQSxJQUNiO0FBQUEsTUFDSUMsT0FBTztBQUFBLE1BQ1BDLE9BQU9iLE1BQU1FO0FBQUFBLE1BQ2JZLGFBQWE7QUFBQSxNQUNiQyxNQUFNLHVCQUFDLFNBQU0sTUFBTSxNQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0I7QUFBQSxNQUN0QkMsV0FBVztBQUFBLE1BQ1hDLGFBQWE7QUFBQSxNQUNiQyxZQUFZO0FBQUEsTUFDWkMsY0FBYztBQUFBLElBQ2xCO0FBQUEsSUFDQTtBQUFBLE1BQ0lQLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE1BQU0sdUJBQUMsYUFBVSxNQUFNLE1BQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0I7QUFBQSxNQUMxQkMsV0FBVztBQUFBLE1BQ1hDLGFBQWE7QUFBQSxNQUNiQyxZQUFZO0FBQUEsTUFDWkMsY0FBYztBQUFBLElBQ2xCO0FBQUEsSUFDQTtBQUFBLE1BQ0lQLE9BQU87QUFBQSxNQUNQQyxPQUFPYixNQUFNRztBQUFBQSxNQUNiVyxhQUFhO0FBQUEsTUFDYkMsTUFBTSx1QkFBQyxhQUFVLE1BQU0sTUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQjtBQUFBLE1BQzFCQyxXQUFXO0FBQUEsTUFDWEMsYUFBYTtBQUFBLE1BQ2JDLFlBQVk7QUFBQSxNQUNaQyxjQUFjO0FBQUEsSUFDbEI7QUFBQSxJQUNBO0FBQUEsTUFDSVAsT0FBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTSx1QkFBQyxpQkFBYyxNQUFNLE1BQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0I7QUFBQSxNQUM5QkMsV0FBVztBQUFBLE1BQ1hDLGFBQWE7QUFBQSxNQUNiQyxZQUFZO0FBQUEsTUFDWkMsY0FBYztBQUFBLElBQ2xCO0FBQUEsRUFBQztBQUVMakMsWUFBVSxNQUFNO0FBRVosVUFBTWtDLGtCQUFrQixZQUFZO0FBQ2hDLFVBQUk7QUFDQSxjQUFNLENBQUNDLFNBQVMsSUFBSSxNQUFNQyxRQUFRQztBQUFBQSxVQUFJO0FBQUEsWUFDbENoQyxJQUFJaUMsSUFBSSx3QkFBd0I7QUFBQSxVQUFDO0FBQUEsUUFDcEM7QUFDRCxjQUFNQyxRQUFRLE1BQU1KLFVBQVVLO0FBQzlCLGNBQU1DLGVBQWVGLE9BQU83QjtBQUFBQSxVQUN4QixDQUFDZ0MsU0FBU0EsTUFBTUMsa0JBQWtCO0FBQUEsUUFDdEM7QUFDQTVCLGlCQUFTLENBQUE2QixVQUFTO0FBQUEsVUFDZCxHQUFHQTtBQUFBQTtBQUFBQSxVQUNINUIsZUFBZXVCLE9BQU9NO0FBQUFBLFVBQ3RCNUIsMEJBQTBCd0IsY0FBY0ksVUFBVTtBQUFBLFFBRXRELEVBQUU7QUFBQSxNQUNOLFNBQVNDLE9BQU87QUFDWkMsZ0JBQVFELE1BQU0sZ0NBQWdDQSxLQUFLO0FBQUEsTUFDdkQ7QUFBQSxJQUNKO0FBQ0FaLG9CQUFnQjtBQUFBLEVBQ3BCLEdBQUcsRUFBRTtBQUVMLFNBQ0ksdUJBQUMsU0FBSSxXQUFVLGNBQ1g7QUFBQSwyQkFBQyxTQUFJLFdBQVUscURBVVg7QUFBQSw2QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BQ1IsdUJBQUMsU0FBSSxXQUFVLDBCQUNYO0FBQUEsK0JBQUMsVUFBTyxZQUFZLFFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUI7QUFBQSxRQUN6Qix1QkFBQyxTQUFJLFdBQVUsZ0JBRVg7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsUUFDWCxpQ0FBQyxTQUFJLFdBQVUscUNBQ1g7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMkJBQ1g7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsa0JBQ1g7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsNExBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd007QUFBQSxnQkFDeE0sdUJBQUMsU0FBSSxXQUFVLDhIQUNYLGlDQUFDLFNBQU0sV0FBVSx3QkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUMsS0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBLHVCQUFDLFNBQ0c7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsZ0hBQStHLGdDQUE3SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsT0FBRSxXQUFVLCtCQUE4QixtREFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEU7QUFBQSxtQkFKbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGlCQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBY0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFjWDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLFNBQVMsTUFBTXJCLFlBQVksQ0FBQStCLFNBQVEsQ0FBQ0EsSUFBSTtBQUFBLGdCQUN4QyxXQUFVO0FBQUEsZ0JBRVRoQyxxQkFBVyxvQkFBb0I7QUFBQTtBQUFBLGNBSnBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBLEtBbkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0JBO0FBQUEsZUFwQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQ0EsS0F0Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1Q0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSw2QkFHWCxpQ0FBQyxTQUFJLFdBQVUsMkJBR1ZBLHNCQUNHLHVCQUFDLFNBQUksV0FBVSxnS0FHWDtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csU0FBUyxNQUFNQyxZQUFZLEtBQUs7QUFBQSxnQkFDaEMsV0FBVTtBQUFBLGdCQUFrRTtBQUFBO0FBQUEsY0FGaEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSxnRUFBK0QsMEJBQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVGO0FBQUEsWUFDdkYsdUJBQUMsT0FBRSxXQUFVLDBDQUNUO0FBQUEscUNBQUMsYUFBVSxXQUFVLHVCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QztBQUFBLGNBQUc7QUFBQSxpQkFEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLDBDQUNUO0FBQUEscUNBQUMsYUFBVSxXQUFVLHVCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QztBQUFBLGNBQUc7QUFBQSxpQkFEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBLEtBdEJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0JBLEtBM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNEJBO0FBQUEsVUE0Q0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNYO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxTQUFTLE1BQU1GLFVBQVUsT0FBTztBQUFBLGdCQUNoQyxXQUFXLHFCQUFxQkQsV0FBVyxVQUNyQyw2QkFDQSxhQUFhO0FBQUEsZ0JBQ1o7QUFBQTtBQUFBLGtCQUdQLHVCQUFDLFVBQUssV0FBVyw4RUFDWkksaUJBQU9FLGlCQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQTtBQUFBO0FBQUEsY0FWSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFXQTtBQUFBLFlBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxTQUFTLE1BQU1MLFVBQVUsZUFBZTtBQUFBLGdCQUN4QyxXQUFXLHFCQUFxQkQsV0FBVyxrQkFDckMsNkJBQ0EsYUFBYTtBQUFBLGdCQUNaO0FBQUE7QUFBQSxrQkFHUCx1QkFBQyxVQUFLLFdBQVcsOEVBQ1pJLGlCQUFPRyw0QkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUE7QUFBQTtBQUFBLGNBVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBV0E7QUFBQSxlQXpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTJCQTtBQUFBLFVBRUNQLFdBQVcsV0FBVztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ3BCO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUE7QUFBQSxZQUptQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJRTtBQUFBLFVBR3hCQSxXQUFXLG1CQUFtQix1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFhO0FBQUEsYUF0SmhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3TEE7QUFBQSxXQTFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMkxBO0FBQUEsU0F0TUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVNQTtBQUFBLElBRUEsdUJBQUMsV0FBTSxLQUFHLE1BQUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNDSjtBQUFBLE9BaFBBO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpUEE7QUFFUjtBQUFFRCxHQTFWSUQsV0FBUztBQUFBLFVBSU14QixXQUFXO0FBQUE7QUFBQWdFLEtBSjFCeEM7QUE0Vk4sZUFBZUE7QUFBVSxJQUFBd0M7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZU5hdmlnYXRlIiwiTmF2YmFyIiwiU2lkZWJhciIsIlVzZXJzIiwiQ2hldnJvblJpZ2h0IiwiWmFwIiwiU2hpZWxkIiwiVXNlckNoZWNrIiwiU3BhcmtsZXMiLCJBcnJvd1VwUmlnaHQiLCJHcmlkM3gzIiwiVXNlck1pbnVzIiwiQWxlcnRUcmlhbmdsZSIsIklvSW9zUGVyc29uQWRkIiwiTWRDYW5jZWwiLCJGYVBsdXMiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlVzZXIiLCJVbkFwcHJvdmVkQ3VzdG9tZXIiLCJHb0RvdEZpbGwiLCJhcGkiLCJHcm91cCIsIkZpbHRlckdyb3VwcyIsIkdyb3VwTWVudSIsIl9zIiwiZmlsdGVyIiwic2V0RmlsdGVyIiwic2hvd1RpcHMiLCJzZXRTaG93VGlwcyIsInRvdGFsIiwic2V0VG90YWwiLCJ0b3RhbEN1c3RvbWVyIiwidG90YWxVbnZlcmlmaWVkQ3VzdG9tZXJzIiwibmF2aWdhdGUiLCJzaG93VXNlck1vZGFsIiwic2V0U2hvd1VzZXJNb2RhbCIsImVycm9ycyIsInNldEVycm9ycyIsImFyZWFzIiwic2V0QXJlYXMiLCJjYXJkRGF0YSIsInRpdGxlIiwidmFsdWUiLCJkZXNjcmlwdGlvbiIsImljb24iLCJpY29uQ29sb3IiLCJpY29uQmdDb2xvciIsInRpdGxlQ29sb3IiLCJkaXZpZGVyQ29sb3IiLCJmZXRjaFRvdGFsQ291bnQiLCJyZXNwb25zZTEiLCJQcm9taXNlIiwiYWxsIiwiZ2V0IiwiZGF0YTEiLCJkYXRhIiwibW9iaWxlQWNjZXNzIiwiaXRlbSIsIm1vYmlsZV9hY2Nlc3MiLCJwcmV2IiwibGVuZ3RoIiwiZXJyb3IiLCJjb25zb2xlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiR3JvdXBNZW51LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCB7IFVzZXJzLCBDaGV2cm9uUmlnaHQsIFphcCwgU2hpZWxkLCBVc2VyQ2hlY2ssIFNwYXJrbGVzLCBBcnJvd1VwUmlnaHQsIEdyaWQzeDMsIFVzZXJNaW51cywgQWxlcnRUcmlhbmdsZSB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgSW9Jb3NQZXJzb25BZGQgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IHsgTWRDYW5jZWwgfSBmcm9tIFwicmVhY3QtaWNvbnMvbWRcIjtcclxuaW1wb3J0IHsgRmFQbHVzIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFVzZXIgZnJvbSBcIi4vVXNlclwiO1xyXG5pbXBvcnQgVW5BcHByb3ZlZEN1c3RvbWVyIGZyb20gXCIuL1VuQXBwcm92ZWRDdXN0b21lclwiO1xyXG5pbXBvcnQgeyBHb0RvdEZpbGwgfSBmcm9tIFwicmVhY3QtaWNvbnMvZ29cIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgR3JvdXAgZnJvbSBcIi4vR3JvdXBcIjtcclxuaW1wb3J0IEZpbHRlckdyb3VwcyBmcm9tIFwiLi9GaWx0ZXJHcm91cHNcIjtcclxuXHJcbmNvbnN0IEdyb3VwTWVudSA9ICgpID0+IHtcclxuICAgIGNvbnN0IFtmaWx0ZXIsIHNldEZpbHRlcl0gPSB1c2VTdGF0ZShcImdyb3VwXCIpO1xyXG4gICAgY29uc3QgW3Nob3dUaXBzLCBzZXRTaG93VGlwc10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbdG90YWwsIHNldFRvdGFsXSA9IHVzZVN0YXRlKHsgdG90YWxDdXN0b21lcjogMCwgdG90YWxVbnZlcmlmaWVkQ3VzdG9tZXJzOiAwIH0pO1xyXG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gICAgY29uc3QgW3Nob3dVc2VyTW9kYWwsIHNldFNob3dVc2VyTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuICAgIC8vIGNvbnN0IHVzZXJDYXRlZ29yaWVzID0gW1xyXG4gICAgLy8gICB7XHJcbiAgICAvLyAgICAgaWQ6IDEsXHJcbiAgICAvLyAgICAgdGl0bGU6IFwiQ3VzdG9tZXJzXCIsXHJcbiAgICAvLyAgICAgZGVzY3JpcHRpb246IFwiTWFuYWdlIGN1c3RvbWVyIHJlY29yZHMgYW5kIGluZm9ybWF0aW9uXCIsXHJcbiAgICAvLyAgICAgaWNvbjogSW9Jb3NQZXJzb25BZGQsXHJcbiAgICAvLyAgICAgZ3JhZGllbnQ6IFwiZnJvbS12aW9sZXQtNTAwIHZpYS1wdXJwbGUtNTAwIHRvLXBpbmstNTAwXCIsXHJcbiAgICAvLyAgICAgYmdHcmFkaWVudDogXCJmcm9tLXZpb2xldC01MCB2aWEtcHVycGxlLTUwIHRvLXBpbmstNTBcIixcclxuICAgIC8vICAgICBocmVmOiBcIi9jdXN0b21lci1tZW51L3VzZXJcIixcclxuICAgIC8vICAgICBzdGF0czogXCJBY3RpdmUgQ3VzdG9tZXJzXCIsXHJcbiAgICAvLyAgICAgc2Vjb25kYXJ5SWNvbjogU2hpZWxkLFxyXG4gICAgLy8gICAgIGljb25Db2xvcjogXCJ0ZXh0LXZpb2xldC02MDBcIixcclxuICAgIC8vICAgICBiZ0NvbG9yOiBcImJnLXZpb2xldC0xMDBcIlxyXG4gICAgLy8gICB9LFxyXG4gICAgLy8gICB7XHJcbiAgICAvLyAgICAgaWQ6IDIsXHJcbiAgICAvLyAgICAgdGl0bGU6IFwiVW52ZXJpZmllZCBDdXN0b21lcnNcIixcclxuICAgIC8vICAgICBkZXNjcmlwdGlvbjogXCJNYW5hZ2UgdW52ZXJpZmllZCBjdXN0b21lciByZWNvcmRzXCIsXHJcbiAgICAvLyAgICAgaWNvbjogTWRDYW5jZWwsXHJcbiAgICAvLyAgICAgZ3JhZGllbnQ6IFwiZnJvbS1hbWJlci01MDAgdmlhLW9yYW5nZS01MDAgdG8tcmVkLTUwMFwiLFxyXG4gICAgLy8gICAgIGJnR3JhZGllbnQ6IFwiZnJvbS1hbWJlci01MCB2aWEtb3JhbmdlLTUwIHRvLXJlZC01MFwiLFxyXG4gICAgLy8gICAgIGhyZWY6IFwiL2N1c3RvbWVyLW1lbnUvdW4tYXBwcm92ZWQtY3VzdG9tZXJcIixcclxuICAgIC8vICAgICBzdGF0czogXCJVbnZlcmlmaWVkIEN1c3RvbWVyc1wiLFxyXG4gICAgLy8gICAgIHNlY29uZGFyeUljb246IFVzZXJDaGVjayxcclxuICAgIC8vICAgICBpY29uQ29sb3I6IFwidGV4dC1hbWJlci02MDBcIixcclxuICAgIC8vICAgICBiZ0NvbG9yOiBcImJnLWFtYmVyLTEwMFwiXHJcbiAgICAvLyAgIH0sXHJcbiAgICAvLyBdO1xyXG4gICAgY29uc3QgW2FyZWFzLCBzZXRBcmVhc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgICBjb25zdCBjYXJkRGF0YSA9IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHRpdGxlOiBcIlRvdGFsIEN1c3RvbWVyc1wiLFxyXG4gICAgICAgICAgICB2YWx1ZTogdG90YWwudG90YWxDdXN0b21lcixcclxuICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiT3ZlcmFsbCBSZWdpc3RlcmVkIFVzZXJzXCIsXHJcbiAgICAgICAgICAgIGljb246IDxVc2VycyBzaXplPXsyMH0gLz4sXHJcbiAgICAgICAgICAgIGljb25Db2xvcjogXCJ0ZXh0LWJsdWUtNTAwXCIsXHJcbiAgICAgICAgICAgIGljb25CZ0NvbG9yOiBcImJnLWJsdWUtNTBcIixcclxuICAgICAgICAgICAgdGl0bGVDb2xvcjogXCJ0ZXh0LWJsdWUtNjAwXCIsXHJcbiAgICAgICAgICAgIGRpdmlkZXJDb2xvcjogXCJiZy1ibHVlLTIwMFwiXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHRpdGxlOiBcIkFjdGl2ZSBDdXN0b21lcnNcIixcclxuICAgICAgICAgICAgdmFsdWU6IFwiNTYwXCIsXHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlZlcmlmaWVkICYgQWN0aXZlIFVzZXJzXCIsXHJcbiAgICAgICAgICAgIGljb246IDxVc2VyQ2hlY2sgc2l6ZT17MjB9IC8+LFxyXG4gICAgICAgICAgICBpY29uQ29sb3I6IFwidGV4dC1lbWVyYWxkLTUwMFwiLFxyXG4gICAgICAgICAgICBpY29uQmdDb2xvcjogXCJiZy1lbWVyYWxkLTUwXCIsXHJcbiAgICAgICAgICAgIHRpdGxlQ29sb3I6IFwidGV4dC1lbWVyYWxkLTYwMFwiLFxyXG4gICAgICAgICAgICBkaXZpZGVyQ29sb3I6IFwiYmctZW1lcmFsZC0yMDBcIlxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICB0aXRsZTogXCJVbnZlcmlmaWVkIEN1c3RvbWVyc1wiLFxyXG4gICAgICAgICAgICB2YWx1ZTogdG90YWwudG90YWxVbnZlcmlmaWVkQ3VzdG9tZXJzLFxyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJQZW5kaW5nIFZlcmlmaWNhdGlvblwiLFxyXG4gICAgICAgICAgICBpY29uOiA8VXNlck1pbnVzIHNpemU9ezIwfSAvPixcclxuICAgICAgICAgICAgaWNvbkNvbG9yOiBcInRleHQtYW1iZXItNTAwXCIsXHJcbiAgICAgICAgICAgIGljb25CZ0NvbG9yOiBcImJnLWFtYmVyLTUwXCIsXHJcbiAgICAgICAgICAgIHRpdGxlQ29sb3I6IFwidGV4dC1hbWJlci02MDBcIixcclxuICAgICAgICAgICAgZGl2aWRlckNvbG9yOiBcImJnLWFtYmVyLTIwMFwiXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHRpdGxlOiBcIk92ZXJkdWUgUGF5bWVudHNcIixcclxuICAgICAgICAgICAgdmFsdWU6IFwi4oK5MSw1MCwwMDBcIixcclxuICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiUGVuZGluZyBDb2xsZWN0aW9uc1wiLFxyXG4gICAgICAgICAgICBpY29uOiA8QWxlcnRUcmlhbmdsZSBzaXplPXsyMH0gLz4sXHJcbiAgICAgICAgICAgIGljb25Db2xvcjogXCJ0ZXh0LXJlZC01MDBcIixcclxuICAgICAgICAgICAgaWNvbkJnQ29sb3I6IFwiYmctcmVkLTUwXCIsXHJcbiAgICAgICAgICAgIHRpdGxlQ29sb3I6IFwidGV4dC1yZWQtNjAwXCIsXHJcbiAgICAgICAgICAgIGRpdmlkZXJDb2xvcjogXCJiZy1yZWQtMjAwXCJcclxuICAgICAgICB9XHJcbiAgICBdO1xyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICAvLyBGZXRjaCB0b3RhbCBjb3VudHMgZnJvbSBBUElcclxuICAgICAgICBjb25zdCBmZXRjaFRvdGFsQ291bnQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBbcmVzcG9uc2UxXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICAgICAgICAgICAgICBhcGkuZ2V0KFwiL2dyb3VwL2dldC1ncm91cC1hZG1pblwiKSxcclxuICAgICAgICAgICAgICAgIF0pO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZGF0YTEgPSBhd2FpdCByZXNwb25zZTEuZGF0YTtcclxuICAgICAgICAgICAgICAgIGNvbnN0IG1vYmlsZUFjY2VzcyA9IGRhdGExPy5maWx0ZXIoXHJcbiAgICAgICAgICAgICAgICAgICAgKGl0ZW0pID0+IGl0ZW0/Lm1vYmlsZV9hY2Nlc3MgPT09IHRydWVcclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICBzZXRUb3RhbChwcmV2ID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgLi4ucHJldiwgICAgICAgICAgICAgICAvLyBrZWVwIGV4aXN0aW5nIHZhbHVlc1xyXG4gICAgICAgICAgICAgICAgICAgIHRvdGFsQ3VzdG9tZXI6IGRhdGExPy5sZW5ndGgsXHJcbiAgICAgICAgICAgICAgICAgICAgdG90YWxVbnZlcmlmaWVkQ3VzdG9tZXJzOiBtb2JpbGVBY2Nlc3M/Lmxlbmd0aCB8fCAwXHJcblxyXG4gICAgICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHRvdGFsIGNvdW50czpcIiwgZXJyb3IpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICBmZXRjaFRvdGFsQ291bnQoKTtcclxuICAgIH0sIFtdKTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtc2NyZWVuIHctZnVsbCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tc2xhdGUtNTAgdmlhLXdoaXRlIHRvLWdyYXktNTBcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0wIC1sZWZ0LTQgdy03MiBoLTcyIGJnLXB1cnBsZS0zMDAgcm91bmRlZC1mdWxsIG1peC1ibGVuZC1tdWx0aXBseSBmaWx0ZXIgYmx1ci14bCBvcGFjaXR5LTIwIGFuaW1hdGUtYmxvYlwiPjwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0wIC1yaWdodC00IHctNzIgaC03MiBiZy15ZWxsb3ctMzAwIHJvdW5kZWQtZnVsbCBtaXgtYmxlbmQtbXVsdGlwbHkgZmlsdGVyIGJsdXIteGwgb3BhY2l0eS0yMCBhbmltYXRlLWJsb2IgYW5pbWF0aW9uLWRlbGF5LTIwMDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtYm90dG9tLTggbGVmdC0yMCB3LTcyIGgtNzIgYmctcGluay0zMDAgcm91bmRlZC1mdWxsIG1peC1ibGVuZC1tdWx0aXBseSBmaWx0ZXIgYmx1ci14bCBvcGFjaXR5LTIwIGFuaW1hdGUtYmxvYiBhbmltYXRpb24tZGVsYXktNDAwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+ICovfVxyXG5cclxuICAgICAgICAgICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8TmF2YmFyIHZpc2liaWxpdHk9e3RydWV9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTggcmVsYXRpdmVcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLWluc2V0LTEgYmctZ3JhZGllbnQtdG8tciBmcm9tLXZpb2xldC02MDAgdG8tcHVycGxlLTYwMCByb3VuZGVkLTJ4bCBibHVyLWxnIG9wYWNpdHktNzUgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0xMDAwIGdyb3VwLWhvdmVyOmR1cmF0aW9uLTIwMCBhbmltYXRlLXRpbHRcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy0xMiBoLTEyIHJvdW5kZWQtMnhsIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tdmlvbGV0LTUwMCB0by1wdXJwbGUtNjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNoYWRvdy0yeGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VXNlcnMgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LXdoaXRlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgYmctZ3JhZGllbnQtdG8tciBmcm9tLXNsYXRlLTkwMCB2aWEtcHVycGxlLTkwMCB0by1zbGF0ZS05MDAgYmctY2xpcC10ZXh0IHRleHQtdHJhbnNwYXJlbnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBHcm91cCBNYW5hZ2VtZW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDAgbXQtMSB0ZXh0LXNtXCI+TWFuYWdlIGFuZCBvcmdhbml6ZSB5b3VyIEdyb3VwIGJhc2U8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RmlsdGVyKFwiZ3JvdXBcIik7ICAgLy8gc3dpdGNoIHRhYlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dVc2VyTW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgd2luZG93Lm9wZW4oXCIvYWRkLW5ldy1jdXN0b21lclwiLCBcIl9ibGFua1wiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC00IGJnLXZpb2xldC01MDAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZCBzaGFkb3ctbWQgaG92ZXI6YmctYmx1ZS04MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICArIEFkZCBHcm91cFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dUaXBzKHByZXYgPT4gIXByZXYpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNTAwIGZvbnQtbWVkaXVtIGhvdmVyOnVuZGVybGluZSBtYi0yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Nob3dUaXBzID8gXCJIaWRlIFF1aWNrIFRpcHNcIiA6IFwiU2hvdyBRdWljayBUaXBzXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBoLTAgdG9wLTFcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogSW5mbyBJY29uICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMTIgcmlnaHQtNFwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogVG9vbHRpcCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2hvd1RpcHMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS1mdWxsIHJpZ2h0LTAgIG1iLTIgXHJcbiAgICAgICAgICAgICAgICAgICAgICB3LTgwIHAtMyBiZy1ncmF5LTgwMCB0ZXh0LXdoaXRlIHRleHQteHMgcm91bmRlZC1tZCBcclxuICAgICAgICAgICAgICAgICAgICAgIHNoYWRvdy1sZyB6LVs5OTk5XVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dUaXBzKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSAgcmlnaHQtMSB0ZXh0LXJlZCB0ZXh0LXNtIGZvbnQtYm9sZCBob3Zlcjp0ZXh0LWdyYXktMzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDDl1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCBtYi0xIGlubGluZS1ibG9jayBib3JkZXItYi0yIGJvcmRlci12aW9sZXQtNTAwXCI+UXVpY2sgVGlwczwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJsZWFkaW5nLXJlbGF4ZWQgZmxleCBpdGVtcy1zdGFydCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxHb0RvdEZpbGwgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIG10LTFcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFVzZSB0aGUgR3JvdXAgZGlyZWN0b3J5IHRvIG1hbmFnZSBHcm91cHMsIHVwZGF0ZSBHcm91cCBpbmZvcm1hdGlvbiBhbGwgaW4gb25lIHBsYWNlLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibGVhZGluZy1yZWxheGVkIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8R29Eb3RGaWxsIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBtdC0xXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBVc2UgdGhlIE1vYmlsZSBBY2Nlc3MgZGlyZWN0b3J5IHRvIGRpc3BsYXkgZ3JvdXBzIGJhc2VkIG9uIHRoZSBhcHAgc2VsZWN0aW9uLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogTWFpbiBNZXRyaWMgQ2FyZHMgUm93ICovfVxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTYgZ2FwLTZcIj5cclxuICAgICAgICAgICAgICB7Y2FyZERhdGEubWFwKChjYXJkLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICBrZXk9e2luZGV4fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC0yeGwgcC0yIGJnLXdoaXRlIHNoYWRvdy1sZyBob3ZlcjpzaGFkb3cteGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGhvdmVyOi10cmFuc2xhdGUteS0yIGN1cnNvci1kZWZhdWx0IGJvcmRlciBib3JkZXItZ3JheS0xMDBcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIC1yaWdodC00IC10b3AtNCBvcGFjaXR5LTEwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B0ZXh0LTV4bCAke2NhcmQuaWNvbkNvbG9yfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2NhcmQuaWNvbn1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIHRleHQtY2VudGVyIHNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQtZnVsbCAke2NhcmQuaWNvbkJnQ29sb3J9IHNoYWRvdy1tZGB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2Ake2NhcmQuaWNvbkNvbG9yfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Y2FyZC5pY29ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPXtgdGV4dC1zbSBmb250LXNlbWlib2xkIHRyYWNraW5nLXdpZGUgdXBwZXJjYXNlICR7Y2FyZC50aXRsZUNvbG9yfSBtYi0yYH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtjYXJkLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIG1iLTIgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Y2FyZC52YWx1ZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgaC0xIHctMTYgbXgtYXV0byByb3VuZGVkLWZ1bGwgJHtjYXJkLmRpdmlkZXJDb2xvcn1gfSAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEycHhdIHRleHQtZ3JheS02MDAgbXQtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Y2FyZC5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9kaXY+ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogRmlsdGVyICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTQgbWItNiBtdC01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RmlsdGVyKFwiZ3JvdXBcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQgJHtmaWx0ZXIgPT09IFwiZ3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctdmlvbGV0LTUwMCB0ZXh0LXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWdyYXktMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgR3JvdXBzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgbWwtMiBweC0yIHB5LTAuNSB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLWZ1bGwgYmctcHVycGxlLTQwMCB0ZXh0LWJsYWNrXCJ9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0b3RhbD8udG90YWxDdXN0b21lcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RmlsdGVyKFwibW9iaWxlLWFjY2Vzc1wiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTIgcm91bmRlZCAke2ZpbHRlciA9PT0gXCJtb2JpbGUtYWNjZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXZpb2xldC01MDAgdGV4dC13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmF5LTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE1vYmlsZSBBY2Nlc3MgR3JvdXBzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgbWwtMiBweC0yIHB5LTAuNSB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLWZ1bGwgYmctcHVycGxlLTQwMCB0ZXh0LWJsYWNrXCJ9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0b3RhbD8udG90YWxVbnZlcmlmaWVkQ3VzdG9tZXJzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBSZW5kZXIgQ29tcG9uZW50IEJhc2VkIG9uIEZpbHRlciAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpbHRlciA9PT0gXCJncm91cFwiICYmIDxHcm91cFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1VzZXJNb2RhbD17c2hvd1VzZXJNb2RhbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dVc2VyTW9kYWw9e3NldFNob3dVc2VyTW9kYWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlcnJvcnM9e2Vycm9yc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEVycm9ycz17c2V0RXJyb3JzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPn1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmaWx0ZXIgPT09IFwibW9iaWxlLWFjY2Vzc1wiICYmIDxGaWx0ZXJHcm91cHMgLz59XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC04IG1iLTEyXCI+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8L2Rpdj4gKi99XHJcblxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcC04IGJnLWdyYWRpZW50LXRvLWJyIGZyb20tdmlvbGV0LTUwIHZpYS1wdXJwbGUtNTAgdG8tcGluay01MCByb3VuZGVkLTN4bCBib3JkZXIgYm9yZGVyLXdoaXRlLzUwIHNoYWRvdy0yeGwgb3ZlcmZsb3ctaGlkZGVuIG10LTRcIj5cclxuICAgICAgIFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCB3LTQwIGgtNDAgYmctZ3JhZGllbnQtdG8tYmwgZnJvbS12aW9sZXQtMjAwLzMwIHRvLXRyYW5zcGFyZW50IHJvdW5kZWQtZnVsbCBibHVyLTN4bFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTAgbGVmdC0wIHctNDAgaC00MCBiZy1ncmFkaWVudC10by10ciBmcm9tLXB1cnBsZS0yMDAvMzAgdG8tdHJhbnNwYXJlbnQgcm91bmRlZC1mdWxsIGJsdXItM3hsXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIC1pbnNldC0yIGJnLWdyYWRpZW50LXRvLXIgZnJvbS12aW9sZXQtNTAwIHRvLXB1cnBsZS01MDAgcm91bmRlZC0yeGwgYmx1ci1sZyBvcGFjaXR5LTUwIGdyb3VwLWhvdmVyOm9wYWNpdHktNzUgdHJhbnNpdGlvbiBkdXJhdGlvbi0zMDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LTE0IGgtMTQgcm91bmRlZC0yeGwgYmctd2hpdGUgc2hhZG93LXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFphcCBjbGFzc05hbWU9XCJ3LTcgaC03IHRleHQtdmlvbGV0LTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgbWItMiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFF1aWNrIFRpcHNcclxuICAgICAgICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXZpb2xldC01MDAgYW5pbWF0ZS1wdWxzZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNzAwIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFVzZSB0aGUgQ3VzdG9tZXIgZGlyZWN0b3J5IHRvIG1hbmFnZSBjdXN0b21lciBpbmZvcm1hdGlvbiwgdXBkYXRlIGN1c3RvbWVyIGRldGFpbHMgYWxsIGluIG9uZSBwbGFjZS5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTcwMCBsZWFkaW5nLXJlbGF4ZWQgbXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFVzZSB0aGUgQ3VzdG9tZXIgZGlyZWN0b3J5IHRvIG1hbmFnZSBVbnZlcmlmaWVkIEN1c3RvbWVycyBJbmZvcm1hdGlvbiwgdXBkYXRlIGN1c3RvbWVyIGluZm9ybWF0aW9uIGFsbCBpbiBvbmUgcGxhY2UuXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj4gKi99XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPHN0eWxlIGpzeD57YFxyXG4gICAgICAgIEBrZXlmcmFtZXMgYmxvYiB7XHJcbiAgICAgICAgICAwJSB7XHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKDBweCwgMHB4KSBzY2FsZSgxKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIDMzJSB7XHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKDMwcHgsIC01MHB4KSBzY2FsZSgxLjEpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgNjYlIHtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTIwcHgsIDIwcHgpIHNjYWxlKDAuOSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICAxMDAlIHtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoMHB4LCAwcHgpIHNjYWxlKDEpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAuYW5pbWF0ZS1ibG9iIHtcclxuICAgICAgICAgIGFuaW1hdGlvbjogYmxvYiA3cyBpbmZpbml0ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLmFuaW1hdGlvbi1kZWxheS0yMDAwIHtcclxuICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMnM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5hbmltYXRpb24tZGVsYXktNDAwMCB7XHJcbiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDRzO1xyXG4gICAgICAgIH1cclxuICAgICAgICBAa2V5ZnJhbWVzIHRpbHQge1xyXG4gICAgICAgICAgMCUsIDUwJSwgMTAwJSB7XHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogcm90YXRlKDBkZWcpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgMjUlIHtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoMC41ZGVnKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIDc1JSB7XHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogcm90YXRlKC0wLjVkZWcpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAuYW5pbWF0ZS10aWx0IHtcclxuICAgICAgICAgIGFuaW1hdGlvbjogdGlsdCAxMHMgaW5maW5pdGU7XHJcbiAgICAgICAgfVxyXG4gICAgICBgfTwvc3R5bGU+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgR3JvdXBNZW51OyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9Hcm91cE1lbnUuanN4In0=