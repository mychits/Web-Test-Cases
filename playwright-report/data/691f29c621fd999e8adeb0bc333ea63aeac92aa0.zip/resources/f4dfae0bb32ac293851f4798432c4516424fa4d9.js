import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Analytics.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area
} from "/node_modules/.vite/deps/recharts.js?v=819e0a34";
import {
  FaUsers,
  FaUserTie,
  FaUserFriends,
  FaLayerGroup,
  FaWallet
} from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
const customerGrowth = [
  { month: "Jan", customers: 820, agents: 40, employees: 22 },
  { month: "Feb", customers: 902, agents: 44, employees: 24 },
  { month: "Mar", customers: 970, agents: 48, employees: 26 },
  { month: "Apr", customers: 1040, agents: 51, employees: 28 },
  { month: "May", customers: 1110, agents: 55, employees: 31 },
  { month: "Jun", customers: 1180, agents: 58, employees: 34 },
  { month: "Jul", customers: 1284, agents: 62, employees: 38 }
];
const groupStatus = [
  { name: "Active", value: 94, color: "#3b82f6" },
  { name: "Completed", value: 58, color: "#22c55e" },
  { name: "Upcoming", value: 21, color: "#f59e0b" },
  { name: "Closed", value: 9, color: "#ef4444" }
];
const auctionBids = [
  { month: "Jan", auctions: 14, bids: 62 },
  { month: "Feb", auctions: 18, bids: 74 },
  { month: "Mar", auctions: 16, bids: 68 },
  { month: "Apr", auctions: 21, bids: 89 },
  { month: "May", auctions: 19, bids: 81 },
  { month: "Jun", auctions: 24, bids: 96 },
  { month: "Jul", auctions: 27, bids: 108 }
];
const visitorEnquiry = [
  { day: "Mon", visitors: 32, enquiries: 12, calls: 18 },
  { day: "Tue", visitors: 41, enquiries: 15, calls: 22 },
  { day: "Wed", visitors: 38, enquiries: 11, calls: 19 },
  { day: "Thu", visitors: 55, enquiries: 20, calls: 27 },
  { day: "Fri", visitors: 49, enquiries: 17, calls: 24 },
  { day: "Sat", visitors: 60, enquiries: 24, calls: 30 },
  { day: "Sun", visitors: 28, enquiries: 9, calls: 14 }
];
const leadFunnel = [
  { stage: "New", value: 156 },
  { stage: "Contacted", value: 112 },
  { stage: "Interested", value: 74 },
  { stage: "Converted", value: 38 }
];
const taskStatus = [
  { name: "Pending", value: 48, color: "#f59e0b" },
  { name: "In Progress", value: 26, color: "#3b82f6" },
  { name: "Completed", value: 71, color: "#22c55e" }
];
const enrollmentTrend = [
  { month: "Jan", enrollments: 18 },
  { month: "Feb", enrollments: 24 },
  { month: "Mar", enrollments: 21 },
  { month: "Apr", enrollments: 29 },
  { month: "May", enrollments: 33 },
  { month: "Jun", enrollments: 27 },
  { month: "Jul", enrollments: 35 }
];
const accountsSummary = [
  { month: "Jan", collections: 42e4, disbursements: 18e4 },
  { month: "Feb", collections: 46e4, disbursements: 21e4 },
  { month: "Mar", collections: 505e3, disbursements: 24e4 },
  { month: "Apr", collections: 54e4, disbursements: 26e4 },
  { month: "May", collections: 59e4, disbursements: 3e5 },
  { month: "Jun", collections: 63e4, disbursements: 32e4 },
  { month: "Jul", collections: 675e3, disbursements: 35e4 }
];
const rawGroupData = [
  { code: "MCF-5L-AG-50M", type: "Double Group", value: 5e5, members: 50, installment: 1e4, start: "19/02/2025", end: "19/04/2026", daily: 1e3, vacant: 5, weekly: 1e4, monthly: 3e4 },
  { code: "MCF-5L-AG-100M", type: "Double Group", value: 5e5, members: 100, installment: 5e3, start: "22/05/2025", end: "22/09/2027", daily: 500, vacant: 4, weekly: 5e3, monthly: 15e3 },
  { code: "MCF-1L-AG-50M", type: "Double Group", value: 1e5, members: 50, installment: 2e3, start: "10/03/2025", end: "10/05/2026", daily: 200, vacant: 5, weekly: 2e3, monthly: 6e3 },
  { code: "MCF-1L-BG-50M", type: "Double Group", value: 1e5, members: 50, installment: 2e3, start: "22/05/2025", end: "22/07/2026", daily: 200, vacant: 6, weekly: 2e3, monthly: 6e3 },
  { code: "MCF-5L-BG-100M", type: "Double Group", value: 5e5, members: 100, installment: 5e3, start: "10/01/2026", end: "10/05/2028", daily: 500, vacant: 7, weekly: 5e3, monthly: 15e3 },
  { code: "MCF-1L-AG-100M", type: "Double Group", value: 1e5, members: 100, installment: 1e3, start: "31/05/2025", end: "30/09/2027", daily: 100, vacant: 2, weekly: 1e3, monthly: 3e3 },
  { code: "MCF-5L-BG-50M", type: "Double Group", value: 5e5, members: 50, installment: 1e4, start: "30/06/2025", end: "30/08/2026", daily: 1e3, vacant: 3, weekly: 1e4, monthly: 3e4 },
  { code: "MCF-1L-CG-50M", type: "Double Group", value: 1e5, members: 50, installment: 2e3, start: "31/07/2025", end: "30/09/2026", daily: 200, vacant: 3, weekly: 2e3, monthly: 6e3 },
  { code: "MCF-50K-50M", type: "Divident Group", value: 5e4, members: 50, installment: 1e3, start: "29/06/2025", end: "29/08/2026", daily: 100, vacant: 6, weekly: 1e3, monthly: 3e3 },
  { code: "MCF-25L-AG-40M", type: "Divident Group", value: 25e5, members: 40, installment: 62500, start: "15/03/2026", end: "15/06/2029", daily: 2100, vacant: 6, weekly: 0, monthly: 62500 },
  { code: "MCF-1L-DG-50M", type: "Double Group", value: 1e5, members: 50, installment: 2e3, start: "10/10/2025", end: "10/12/2026", daily: 200, vacant: 7, weekly: 2e3, monthly: 6e3 },
  { code: "MCF-1L-BG-100M", type: "Double Group", value: 1e5, members: 100, installment: 1e3, start: "20/03/2026", end: "20/07/2028", daily: 100, vacant: 9, weekly: 1e3, monthly: 3e3 },
  { code: "MCF-5L-AG-40M", type: "Divident Group", value: 5e5, members: 40, installment: 12500, start: "15/03/2026", end: "15/06/2029", daily: 0, vacant: 4, weekly: 0, monthly: 12500 },
  { code: "MCF-5L-CG-50M", type: "Double Group", value: 5e5, members: 50, installment: 1e4, start: "20/11/2025", end: "20/01/2027", daily: 1e3, vacant: 6, weekly: 1e4, monthly: 3e4 },
  { code: "MCF-5L-AG-25M", type: "Divident Group", value: 5e5, members: 25, installment: 2e4, start: "15/03/2026", end: "15/03/2028", daily: 666, vacant: 4, weekly: 4666, monthly: 2e4 },
  { code: "MCF-1L-EG-50M", type: "Double Group", value: 1e5, members: 50, installment: 2e3, start: "10/01/2026", end: "10/03/2027", daily: 200, vacant: 6, weekly: 2e3, monthly: 6e3 },
  { code: "MCF-1L-FG-50M", type: "Double Group", value: 1e5, members: 50, installment: 2e3, start: "28/02/2026", end: "03/05/2027", daily: 200, vacant: 5, weekly: 2e3, monthly: 6e3 },
  { code: "MCF-N5L-DG-50M", type: "Double Group", value: 5e5, members: 50, installment: 3e4, start: "10/05/2026", end: null, daily: 1e3, vacant: 15, weekly: 1e4, monthly: 3e4 },
  { code: "MCF-N5L-BG-25M", type: "Divident Group", value: 5e5, members: 25, installment: 2e4, start: "15/04/2026", end: "15/04/2028", daily: 750, vacant: 10, weekly: 5e3, monthly: 2e4 },
  { code: "MCF-N1L-GG-50M", type: "Double Group", value: 1e5, members: 50, installment: 2e3, start: "01/05/2026", end: "01/06/2027", daily: 200, vacant: 10, weekly: 2e3, monthly: 6e3 },
  { code: "MCF-N5L-BG-100M", type: "Double Group", value: 5e5, members: 100, installment: 5e3, start: "20/04/2026", end: null, daily: 500, vacant: 20, weekly: 5e3, monthly: 15e3 },
  { code: "MCF-NA1L-20M", type: "Fixed Group", value: 1e5, members: 20, installment: 5e3, start: "15/07/2026", end: "15/03/2028", daily: 200, vacant: 7, weekly: 1250, monthly: 5e3 },
  { code: "MCF-NA2L-20M", type: "Fixed Group", value: 2e5, members: 20, installment: 1e4, start: "15/07/2026", end: "15/03/2028", daily: 340, vacant: 7, weekly: 3400, monthly: 1e4 },
  { code: "MCF-NA3L-20M", type: "Fixed Group", value: 3e5, members: 20, installment: 15e3, start: "15/06/2026", end: "15/02/2028", daily: 500, vacant: 8, weekly: 5e3, monthly: 15e3 },
  { code: "MCF-NA5L-20M", type: "Fixed Group", value: 5e5, members: 20, installment: 25e3, start: "15/07/2026", end: "15/03/2028", daily: 840, vacant: 10, weekly: 8400, monthly: 25e3 },
  { code: "MCF-N25L-BG-40M", type: "Fixed Group", value: 25e5, members: 40, installment: 62500, start: "15/03/2026", end: "15/04/2026", daily: 1700, vacant: 10, weekly: 0, monthly: 62500 },
  { code: "MCF-5L-DG-50M", type: "Double Group", value: 5e5, members: 50, installment: 1e4, start: "20/04/2026", end: "20/06/2027", daily: 1e3, vacant: 10, weekly: 1e4, monthly: 3e4 },
  { code: "MCF-NB5L-20M", type: "Fixed-divident Group", value: 5e5, members: 20, installment: 25e3, start: "15/09/2026", end: "15/05/2028", daily: 840, vacant: 10, weekly: 8400, monthly: 25e3 },
  { code: "MCF-NB2L-20M", type: "Fixed-divident Group", value: 2e5, members: 20, installment: 1e4, start: "15/09/2026", end: "15/05/2028", daily: 340, vacant: 8, weekly: 3400, monthly: 1e4 },
  { code: "MCF-NB1L-20M", type: "Fixed-divident Group", value: 1e5, members: 20, installment: 5e3, start: "15/09/2026", end: "15/05/2028", daily: 200, vacant: 8, weekly: 1250, monthly: 5e3 }
];
const groupSeatFillChartData = rawGroupData.map((g) => ({
  name: g.code,
  filled: g.members - g.vacant,
  vacant: g.vacant
}));
const groupTypeColors = {
  "Double Group": "#3b82f6",
  "Divident Group": "#f59e0b",
  "Fixed Group": "#22c55e",
  "Fixed-divident Group": "#a855f7"
};
const groupCategory = Object.entries(
  rawGroupData.reduce((acc, g) => {
    acc[g.type] = (acc[g.type] || 0) + 1;
    return acc;
  }, {})
).map(([name, value]) => ({ name, value, color: groupTypeColors[name] || "#94a3b8" }));
const groupValueByType = Object.entries(
  rawGroupData.reduce((acc, g) => {
    acc[g.type] = (acc[g.type] || 0) + g.value;
    return acc;
  }, {})
).map(([type, totalValue]) => ({ type, totalValue }));
const customerStatusSplit = [
  { name: "Active", value: 812, color: "#22c55e" },
  { name: "Hold", value: 146, color: "#f59e0b" },
  { name: "Suspend", value: 58, color: "#ef4444" },
  { name: "Unverified", value: 268, color: "#94a3b8" }
];
const staffTypeSplit = [
  { name: "Collection Agents", value: 62, color: "#3b82f6" },
  { name: "Office Employees", value: 38, color: "#a855f7" }
];
const paymentInBreakdown = [
  { type: "Registration Fee", amount: 84e3 },
  { type: "Payment Receipt", amount: 312e3 },
  { type: "Payment Links", amount: 96e3 },
  { type: "Chit Transfer", amount: 128e3 },
  { type: "Employee Advance", amount: 42e3 }
];
const paymentOutBreakdown = [
  { type: "Chit Payout", amount: 21e4 },
  { type: "Chit Cancel", amount: 38e3 },
  { type: "Loan Payout", amount: 96e3 },
  { type: "Pigmy Payout", amount: 54e3 },
  { type: "Others", amount: 18e3 },
  { type: "Employee Salary", amount: 145e3 },
  { type: "Employee Incentive", amount: 27e3 }
];
const marketingChannels = [
  { name: "WhatsApp", value: 420, color: "#22c55e" },
  { name: "Email", value: 185, color: "#3b82f6" },
  { name: "SMS", value: 260, color: "#f59e0b" },
  { name: "RCS", value: 95, color: "#a855f7" }
];
const ChartCard = ({ title, subtitle, children, className = "", accent = "#0071e3" }) => /* @__PURE__ */ jsxDEV(
  "div",
  {
    className: `rounded-2xl border border-slate-200/70 bg-white/80 p-5 shadow-sm shadow-slate-900/[0.03] backdrop-blur-xl transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md hover:shadow-slate-900/10 ${className}`,
    style: { "--chart-accent": accent },
    children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-slate-900", children: title }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 197,
          columnNumber: 7
        }, this),
        subtitle && /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500", children: subtitle }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 198,
          columnNumber: 20
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 196,
        columnNumber: 5
      }, this),
      children
    ]
  },
  void 0,
  true,
  {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
    lineNumber: 192,
    columnNumber: 1
  },
  this
);
_c = ChartCard;
export function DashboardAnalyticsContent({ embedded = false } = {}) {
  _s();
  const [loading, setLoading] = useState(true);
  const [groups, setGroups] = useState([]);
  const [users, setUsers] = useState([]);
  const [agents, setAgents] = useState([]);
  const [staff, setStaffs] = useState([]);
  const [employee, setEmployees] = useState([]);
  const [totalAmount, setTotalAmount] = useState(0);
  const [paymentsPerMonthValue, setPaymentsPerMonthValue] = useState("0");
  const [targetValue, setTotalTargetAmount] = useState(0);
  const fetchGroupData = useCallback(async () => {
    try {
      const response = await api.get("/group/get-group-admin");
      setGroups(response.data);
    } catch (error) {
      console.error("Error fetching group data:", error);
      setGroups([]);
    }
  }, []);
  const fetchUserData = useCallback(async () => {
    try {
      const response = await api.get("/user/get-user");
      setUsers(response.data || []);
    } catch (error) {
      console.error("Error fetching user data:", error);
      setUsers([]);
    }
  }, []);
  const fetchAgentData = useCallback(async () => {
    try {
      const response = await api.get("/agent/get");
      const verifiedAgent = (response.data.agent || []).filter(
        (agent) => agent.isVerified === true
      );
      setAgents(verifiedAgent || []);
    } catch (error) {
      console.error("Error fetching agent data:", error);
      setAgents([]);
    }
  }, []);
  const fetchStaffData = useCallback(async () => {
    try {
      const response = await api.get("/agent/get-agent");
      const verifiedStaff = (response.data || []).filter(
        (staff2) => staff2.isVerified === true
      );
      setStaffs(verifiedStaff || []);
    } catch (error) {
      console.error("Error fetching staff data:", error);
      setStaffs([]);
    }
  }, []);
  const fetchEmployeeData = useCallback(async () => {
    try {
      const response = await api.get("/agent/get-employee");
      const verifiedEmployee = (response.data?.employee || []).filter(
        (employee2) => employee2.isVerified === true
      );
      setEmployees(verifiedEmployee || []);
    } catch (error) {
      console.error("Error fetching employee data:", error);
      setEmployees([]);
    }
  }, []);
  const fetchTotalAmount = useCallback(async () => {
    try {
      const response = await api.get("/payment/get-total-payment-amount");
      setTotalAmount(response?.data?.totalAmount || 0);
    } catch (error) {
      console.error("Error fetching total amount:", error);
      setTotalAmount(0);
    }
  }, []);
  const fetchMonthlyPayments = useCallback(async () => {
    try {
      const today = /* @__PURE__ */ new Date();
      const currentMonth = today.getMonth();
      const currentYear = today.getFullYear();
      const formatDate = (date) => {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const day = String(date.getDate()).padStart(2, "0");
        return `${year}-${month}-${day}`;
      };
      const firstDay = formatDate(new Date(currentYear, currentMonth, 1));
      const lastDay = new Date(currentYear, currentMonth + 1, 0);
      const lastDayFormatted = formatDate(lastDay);
      const response = await api.get("/payment/get-current-month-payment", {
        params: {
          from_date: firstDay,
          to_date: lastDayFormatted
        }
      });
      setPaymentsPerMonthValue(response?.data?.monthlyPayment || "₹0.00");
    } catch (err) {
      console.error("Error fetching monthly payment data:", err.message);
      setPaymentsPerMonthValue("₹0.00");
    }
  }, []);
  const fetchTotalBranchTarget = useCallback(async () => {
    try {
      const response = await api.get("/payment/branch/target");
      setTotalTargetAmount(response?.data?.data?.[0]?.branchTarget || 0);
    } catch (error) {
      console.error("Error fetching branch target amount:", error);
      setTotalTargetAmount(0);
    }
  }, []);
  useEffect(
    () => {
      setLoading(true);
      Promise.all(
        [
          fetchGroupData(),
          fetchUserData(),
          fetchAgentData(),
          fetchStaffData(),
          fetchEmployeeData(),
          fetchTotalAmount(),
          fetchMonthlyPayments(),
          fetchTotalBranchTarget()
        ]
      ).then(() => setLoading(false));
    },
    [
      fetchGroupData,
      fetchUserData,
      fetchAgentData,
      fetchStaffData,
      fetchEmployeeData,
      fetchTotalAmount,
      fetchMonthlyPayments,
      fetchTotalBranchTarget
    ]
  );
  const kpis = [
    {
      label: "Total Customers",
      value: users?.length?.toLocaleString() || "0",
      icon: /* @__PURE__ */ jsxDEV(FaUsers, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 356,
        columnNumber: 11
      }, this),
      color: "bg-blue-500"
    },
    {
      label: "Active Agents",
      value: agents?.length?.toLocaleString() || "0",
      icon: /* @__PURE__ */ jsxDEV(FaUserTie, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 362,
        columnNumber: 11
      }, this),
      color: "bg-green-500"
    },
    {
      label: "Employees",
      value: employee?.length?.toLocaleString() || "0",
      icon: /* @__PURE__ */ jsxDEV(FaUserFriends, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 368,
        columnNumber: 11
      }, this),
      color: "bg-purple-500"
    },
    {
      label: "Staff",
      value: staff?.length?.toLocaleString() || "0",
      icon: /* @__PURE__ */ jsxDEV(FaUserFriends, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 374,
        columnNumber: 11
      }, this),
      color: "bg-indigo-500"
    },
    {
      label: "Groups Running",
      value: groups?.length?.toLocaleString() || "0",
      icon: /* @__PURE__ */ jsxDEV(FaLayerGroup, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 380,
        columnNumber: 11
      }, this),
      color: "bg-amber-500"
    },
    {
      label: "Branch Target",
      value: `₹${(targetValue ?? 0)?.toLocaleString("en-IN")}`,
      icon: /* @__PURE__ */ jsxDEV(FaWallet, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 386,
        columnNumber: 11
      }, this),
      color: "bg-neutral-500"
    },
    {
      label: "Total Payments",
      value: `${(totalAmount ?? 0)?.toLocaleString("en-IN")}`,
      icon: /* @__PURE__ */ jsxDEV(FaWallet, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 392,
        columnNumber: 11
      }, this),
      color: "bg-yellow-500"
    },
    {
      label: "Current Month Payments",
      value: typeof paymentsPerMonthValue === "string" ? paymentsPerMonthValue : `₹${(paymentsPerMonthValue ?? 0)?.toLocaleString("en-IN")}`,
      icon: /* @__PURE__ */ jsxDEV(FaWallet, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 400,
        columnNumber: 11
      }, this),
      color: "bg-teal-500"
    }
  ];
  const SkeletonCard = () => /* @__PURE__ */ jsxDEV("div", { className: "flex animate-pulse items-center gap-3 rounded-2xl border border-slate-200/70 bg-white/70 p-4 shadow-sm shadow-slate-900/[0.03]", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "h-11 w-11 rounded-xl bg-slate-200/80" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
      lineNumber: 407,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-2 h-3 w-20 rounded bg-slate-200/80" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 409,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "h-5 w-16 rounded bg-slate-200/80" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 410,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
      lineNumber: 408,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
    lineNumber: 406,
    columnNumber: 3
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: embedded ? "" : "flex pt-[68px]", children: [
    !embedded && /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
      lineNumber: 417,
      columnNumber: 21
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: embedded ? "space-y-6" : "min-h-screen flex-grow bg-slate-50 px-4 py-6 text-slate-900 sm:px-6 lg:px-8", children: [
      !embedded && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold tracking-tight text-slate-950", children: "Analytics Dashboard" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 423,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-500", children: "Overview of customers, agents, groups, auctions and more" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 424,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 422,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6 grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4", children: loading ? Array(8).fill(0).map((_, i) => /* @__PURE__ */ jsxDEV(SkeletonCard, {}, i, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 428,
          columnNumber: 44
        }, this)) : kpis.map(
          (k, i) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 rounded-2xl border border-slate-200/70 bg-white/80 p-4 shadow-sm shadow-slate-900/[0.03] backdrop-blur-xl transition duration-200 hover:-translate-y-0.5 hover:shadow-md hover:shadow-slate-900/10", children: [
            /* @__PURE__ */ jsxDEV("div", { className: `${k.color} flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-xl text-lg text-white shadow-sm shadow-slate-900/10`, children: k.icon }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
              lineNumber: 431,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "whitespace-normal text-xs font-medium text-slate-500", children: k.label }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
                lineNumber: 435,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "break-words text-xl font-semibold text-slate-900", children: k.value }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
                lineNumber: 436,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
              lineNumber: 434,
              columnNumber: 21
            }, this)
          ] }, i, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 430,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 426,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 421,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mb-6 grid grid-cols-1 gap-5 xl:grid-cols-2", children: [
        /* @__PURE__ */ jsxDEV(ChartCard, { title: "Customer, Agent & Employee Growth", subtitle: "Last 7 months", accent: "#3b82f6", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 280, children: /* @__PURE__ */ jsxDEV(LineChart, { data: customerGrowth, children: [
          /* @__PURE__ */ jsxDEV(CartesianGrid, { strokeDasharray: "3 3", stroke: "#eee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 448,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(XAxis, { dataKey: "month", tick: { fontSize: 12 } }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 449,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(YAxis, { tick: { fontSize: 12 } }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 450,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Tooltip, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 451,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Legend, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 452,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Line, { type: "monotone", dataKey: "customers", stroke: "#3b82f6", strokeWidth: 2 }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 453,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Line, { type: "monotone", dataKey: "agents", stroke: "#22c55e", strokeWidth: 2 }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 454,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Line, { type: "monotone", dataKey: "employees", stroke: "#a855f7", strokeWidth: 2 }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 455,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 447,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 446,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 445,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(ChartCard, { title: "Group Status Breakdown", subtitle: "By current stage", accent: "#f59e0b", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 280, children: /* @__PURE__ */ jsxDEV(PieChart, { children: [
          /* @__PURE__ */ jsxDEV(
            Pie,
            {
              data: groupStatus,
              dataKey: "value",
              nameKey: "name",
              cx: "50%",
              cy: "50%",
              outerRadius: 90,
              label: ({ name, value }) => `${name}: ${value}`,
              children: groupStatus.map(
                (entry, i) => /* @__PURE__ */ jsxDEV(Cell, { fill: entry.color }, i, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
                  lineNumber: 473,
                  columnNumber: 19
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
              lineNumber: 463,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(Tooltip, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 476,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Legend, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 477,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 462,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 461,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 460,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(ChartCard, { title: "Auctions & Bids", subtitle: "Monthly trend", accent: "#ef4444", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 280, children: /* @__PURE__ */ jsxDEV(BarChart, { data: auctionBids, children: [
          /* @__PURE__ */ jsxDEV(CartesianGrid, { strokeDasharray: "3 3", stroke: "#eee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 485,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(XAxis, { dataKey: "month", tick: { fontSize: 12 } }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 486,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(YAxis, { tick: { fontSize: 12 } }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 487,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Tooltip, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 488,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Legend, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 489,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Bar, { dataKey: "auctions", fill: "#f59e0b", radius: [4, 4, 0, 0] }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 490,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Bar, { dataKey: "bids", fill: "#3b82f6", radius: [4, 4, 0, 0] }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 491,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 484,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 483,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 482,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(ChartCard, { title: "Visitor Enquiries & Calls", subtitle: "This week", accent: "#22c55e", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 280, children: /* @__PURE__ */ jsxDEV(AreaChart, { data: visitorEnquiry, children: [
          /* @__PURE__ */ jsxDEV(CartesianGrid, { strokeDasharray: "3 3", stroke: "#eee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 499,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(XAxis, { dataKey: "day", tick: { fontSize: 12 } }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 500,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(YAxis, { tick: { fontSize: 12 } }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 501,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Tooltip, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 502,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Legend, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 503,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Area, { type: "monotone", dataKey: "visitors", stackId: "1", stroke: "#3b82f6", fill: "#93c5fd" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 504,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Area, { type: "monotone", dataKey: "enquiries", stackId: "1", stroke: "#22c55e", fill: "#86efac" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 505,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Area, { type: "monotone", dataKey: "calls", stackId: "1", stroke: "#f97316", fill: "#fdba74" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 506,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 498,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 497,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 496,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(ChartCard, { title: "Lead Funnel", subtitle: "From new lead to conversion", accent: "#6366f1", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 260, children: /* @__PURE__ */ jsxDEV(BarChart, { data: leadFunnel, layout: "vertical", margin: { left: 20 }, children: [
          /* @__PURE__ */ jsxDEV(CartesianGrid, { strokeDasharray: "3 3", stroke: "#eee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 514,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(XAxis, { type: "number", tick: { fontSize: 12 } }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 515,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(YAxis, { dataKey: "stage", type: "category", tick: { fontSize: 12 }, width: 90 }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 516,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Tooltip, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 517,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Bar, { dataKey: "value", fill: "#6366f1", radius: [0, 4, 4, 0] }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 518,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 513,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 512,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 511,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(ChartCard, { title: "Task Status", subtitle: "Current task distribution", accent: "#f59e0b", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 260, children: /* @__PURE__ */ jsxDEV(PieChart, { children: [
          /* @__PURE__ */ jsxDEV(
            Pie,
            {
              data: taskStatus,
              dataKey: "value",
              nameKey: "name",
              cx: "50%",
              cy: "50%",
              innerRadius: 55,
              outerRadius: 90,
              label: ({ name, value }) => `${name}: ${value}`,
              children: taskStatus.map(
                (entry, i) => /* @__PURE__ */ jsxDEV(Cell, { fill: entry.color }, i, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
                  lineNumber: 537,
                  columnNumber: 19
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
              lineNumber: 526,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(Tooltip, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 540,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Legend, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 541,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 525,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 524,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 523,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 444,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mb-6 grid grid-cols-1 gap-5 xl:grid-cols-2", children: [
        /* @__PURE__ */ jsxDEV(ChartCard, { title: "Enrollments", subtitle: "New enrollments per month", accent: "#14b8a6", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 260, children: /* @__PURE__ */ jsxDEV(AreaChart, { data: enrollmentTrend, children: [
          /* @__PURE__ */ jsxDEV(CartesianGrid, { strokeDasharray: "3 3", stroke: "#eee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 551,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(XAxis, { dataKey: "month", tick: { fontSize: 12 } }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 552,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(YAxis, { tick: { fontSize: 12 } }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 553,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Tooltip, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 554,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Area, { type: "monotone", dataKey: "enrollments", stroke: "#14b8a6", fill: "#5eead4" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 555,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 550,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 549,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 548,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(ChartCard, { title: "Accounts: Collections vs Disbursements", subtitle: "Monthly (₹)", accent: "#22c55e", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 260, children: /* @__PURE__ */ jsxDEV(BarChart, { data: accountsSummary, children: [
          /* @__PURE__ */ jsxDEV(CartesianGrid, { strokeDasharray: "3 3", stroke: "#eee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 563,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(XAxis, { dataKey: "month", tick: { fontSize: 12 } }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 564,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(YAxis, { tick: { fontSize: 12 }, tickFormatter: (v) => `${v / 1e3}k` }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 565,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Tooltip, { formatter: (v) => `₹${v.toLocaleString()}` }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 566,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Legend, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 567,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Bar, { dataKey: "collections", fill: "#22c55e", radius: [4, 4, 0, 0] }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 568,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Bar, { dataKey: "disbursements", fill: "#ef4444", radius: [4, 4, 0, 0] }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 569,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 562,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 561,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 560,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 547,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mb-3", children: /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-slate-900", children: [
        "Group Insights ",
        /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-normal text-slate-500", children: [
          "(",
          rawGroupData.length,
          " groups)"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 578,
          columnNumber: 28
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 577,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 576,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mb-6 grid grid-cols-1 gap-5 xl:grid-cols-3", children: [
        /* @__PURE__ */ jsxDEV(
          ChartCard,
          {
            title: "Seat Fill Status Per Group",
            subtitle: `Filled vs vacant seats (${rawGroupData.length} groups)`,
            accent: "#3b82f6",
            className: "lg:col-span-2",
            children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 720, children: /* @__PURE__ */ jsxDEV(BarChart, { data: groupSeatFillChartData, layout: "vertical", margin: { left: 10, right: 10 }, children: [
              /* @__PURE__ */ jsxDEV(CartesianGrid, { strokeDasharray: "3 3", stroke: "#eee" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
                lineNumber: 590,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(XAxis, { type: "number", tick: { fontSize: 11 } }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
                lineNumber: 591,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(YAxis, { dataKey: "name", type: "category", tick: { fontSize: 10 }, width: 110 }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
                lineNumber: 592,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(Tooltip, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
                lineNumber: 593,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(Legend, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
                lineNumber: 594,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(Bar, { dataKey: "filled", stackId: "a", fill: "#3b82f6", name: "Filled" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
                lineNumber: 595,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(Bar, { dataKey: "vacant", stackId: "a", fill: "#fbbf24", name: "Vacant", radius: [0, 4, 4, 0] }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
                lineNumber: 596,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
              lineNumber: 589,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
              lineNumber: 588,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 582,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-5", children: [
          /* @__PURE__ */ jsxDEV(ChartCard, { title: "Group Type Distribution", subtitle: "Count of groups by type", accent: "#f59e0b", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 240, children: /* @__PURE__ */ jsxDEV(PieChart, { children: [
            /* @__PURE__ */ jsxDEV(
              Pie,
              {
                data: groupCategory,
                dataKey: "value",
                nameKey: "name",
                cx: "50%",
                cy: "50%",
                outerRadius: 85,
                label: ({ value }) => value,
                children: groupCategory.map(
                  (entry, i) => /* @__PURE__ */ jsxDEV(Cell, { fill: entry.color }, i, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
                    lineNumber: 615,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
                lineNumber: 605,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(Tooltip, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
              lineNumber: 618,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Legend, { wrapperStyle: { fontSize: 11 } }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
              lineNumber: 619,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 604,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 603,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 602,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(ChartCard, { title: "Total Chit Value by Type", subtitle: "Sum of group values (₹)", accent: "#22c55e", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 220, children: /* @__PURE__ */ jsxDEV(BarChart, { data: groupValueByType, children: [
            /* @__PURE__ */ jsxDEV(CartesianGrid, { strokeDasharray: "3 3", stroke: "#eee" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
              lineNumber: 627,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(XAxis, { dataKey: "type", tick: { fontSize: 9 }, interval: 0, angle: -15, textAnchor: "end", height: 50 }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
              lineNumber: 628,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(YAxis, { tick: { fontSize: 10 }, tickFormatter: (v) => `${v / 1e5}L` }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
              lineNumber: 629,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Tooltip, { formatter: (v) => `₹${v.toLocaleString()}` }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
              lineNumber: 630,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Bar, { dataKey: "totalValue", fill: "#22c55e", radius: [4, 4, 0, 0] }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
              lineNumber: 631,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 626,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 625,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 624,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(ChartCard, { title: "Staff Split", subtitle: "Collection agents vs office employees", accent: "#a855f7", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 200, children: /* @__PURE__ */ jsxDEV(PieChart, { children: [
            /* @__PURE__ */ jsxDEV(
              Pie,
              {
                data: staffTypeSplit,
                dataKey: "value",
                nameKey: "name",
                cx: "50%",
                cy: "50%",
                innerRadius: 45,
                outerRadius: 75,
                label: ({ value }) => value,
                children: staffTypeSplit.map(
                  (entry, i) => /* @__PURE__ */ jsxDEV(Cell, { fill: entry.color }, i, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
                    lineNumber: 650,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
                lineNumber: 639,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(Tooltip, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
              lineNumber: 653,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(Legend, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
              lineNumber: 654,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 638,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 637,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 636,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 601,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 581,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mb-3", children: /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-slate-900", children: "Customer Status" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 663,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 662,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mb-6 grid grid-cols-1 gap-5 xl:grid-cols-2", children: [
        /* @__PURE__ */ jsxDEV(ChartCard, { title: "Customer Status Breakdown", subtitle: "Active, hold, suspend, unverified", accent: "#22c55e", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 280, children: /* @__PURE__ */ jsxDEV(PieChart, { children: [
          /* @__PURE__ */ jsxDEV(
            Pie,
            {
              data: customerStatusSplit,
              dataKey: "value",
              nameKey: "name",
              cx: "50%",
              cy: "50%",
              outerRadius: 95,
              label: ({ name, value }) => `${name}: ${value}`,
              children: customerStatusSplit.map(
                (entry, i) => /* @__PURE__ */ jsxDEV(Cell, { fill: entry.color }, i, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
                  lineNumber: 679,
                  columnNumber: 19
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
              lineNumber: 669,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(Tooltip, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 682,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Legend, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 683,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 668,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 667,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 666,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(ChartCard, { title: "Customer Status (Count)", subtitle: "Same data as bar view", accent: "#3b82f6", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 280, children: /* @__PURE__ */ jsxDEV(BarChart, { data: customerStatusSplit, children: [
          /* @__PURE__ */ jsxDEV(CartesianGrid, { strokeDasharray: "3 3", stroke: "#eee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 691,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(XAxis, { dataKey: "name", tick: { fontSize: 12 } }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 692,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(YAxis, { tick: { fontSize: 12 } }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 693,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Tooltip, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 694,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Bar, { dataKey: "value", radius: [4, 4, 0, 0], children: customerStatusSplit.map(
            (entry, i) => /* @__PURE__ */ jsxDEV(Cell, { fill: entry.color }, i, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
              lineNumber: 697,
              columnNumber: 19
            }, this)
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 695,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 690,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 689,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 688,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 665,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mb-3", children: /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-slate-900", children: "Payment In / Payment Out" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 707,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 706,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mb-6 grid grid-cols-1 gap-5 xl:grid-cols-2", children: [
        /* @__PURE__ */ jsxDEV(ChartCard, { title: "Payment In", subtitle: "Registration, receipts, links, transfer, advance", accent: "#22c55e", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 300, children: /* @__PURE__ */ jsxDEV(BarChart, { data: paymentInBreakdown, layout: "vertical", margin: { left: 30 }, children: [
          /* @__PURE__ */ jsxDEV(CartesianGrid, { strokeDasharray: "3 3", stroke: "#eee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 713,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(XAxis, { type: "number", tick: { fontSize: 11 }, tickFormatter: (v) => `${v / 1e3}k` }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 714,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(YAxis, { dataKey: "type", type: "category", tick: { fontSize: 11 }, width: 130 }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 715,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Tooltip, { formatter: (v) => `₹${v.toLocaleString()}` }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 716,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Bar, { dataKey: "amount", fill: "#22c55e", radius: [0, 4, 4, 0] }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 717,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 712,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 711,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 710,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(ChartCard, { title: "Payment Out", subtitle: "Payouts, cancellations, salary, incentive", accent: "#ef4444", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 300, children: /* @__PURE__ */ jsxDEV(BarChart, { data: paymentOutBreakdown, layout: "vertical", margin: { left: 30 }, children: [
          /* @__PURE__ */ jsxDEV(CartesianGrid, { strokeDasharray: "3 3", stroke: "#eee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 725,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(XAxis, { type: "number", tick: { fontSize: 11 }, tickFormatter: (v) => `${v / 1e3}k` }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 726,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(YAxis, { dataKey: "type", type: "category", tick: { fontSize: 11 }, width: 130 }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 727,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Tooltip, { formatter: (v) => `₹${v.toLocaleString()}` }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 728,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Bar, { dataKey: "amount", fill: "#ef4444", radius: [0, 4, 4, 0] }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 729,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 724,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 723,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 722,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 709,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mb-3", children: /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-slate-900", children: "Marketing" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 737,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 736,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6", children: [
        /* @__PURE__ */ jsxDEV(ChartCard, { title: "Marketing Channel Split", subtitle: "WhatsApp, Email, SMS, RCS", accent: "#22c55e", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 280, children: /* @__PURE__ */ jsxDEV(PieChart, { children: [
          /* @__PURE__ */ jsxDEV(
            Pie,
            {
              data: marketingChannels,
              dataKey: "value",
              nameKey: "name",
              cx: "50%",
              cy: "50%",
              outerRadius: 95,
              label: ({ name, value }) => `${name}: ${value}`,
              children: marketingChannels.map(
                (entry, i) => /* @__PURE__ */ jsxDEV(Cell, { fill: entry.color }, i, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
                  lineNumber: 753,
                  columnNumber: 19
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
              lineNumber: 743,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(Tooltip, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 756,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Legend, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 757,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 742,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 741,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 740,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(ChartCard, { title: "Marketing Messages Sent", subtitle: "By channel", accent: "#f59e0b", children: /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 280, children: /* @__PURE__ */ jsxDEV(BarChart, { data: marketingChannels, children: [
          /* @__PURE__ */ jsxDEV(CartesianGrid, { strokeDasharray: "3 3", stroke: "#eee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 765,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(XAxis, { dataKey: "name", tick: { fontSize: 12 } }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 766,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(YAxis, { tick: { fontSize: 12 } }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 767,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Tooltip, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 768,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(Bar, { dataKey: "value", radius: [4, 4, 0, 0], children: marketingChannels.map(
            (entry, i) => /* @__PURE__ */ jsxDEV(Cell, { fill: entry.color }, i, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
              lineNumber: 771,
              columnNumber: 19
            }, this)
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
            lineNumber: 769,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 764,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 763,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
          lineNumber: 762,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
        lineNumber: 739,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
      lineNumber: 419,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
    lineNumber: 416,
    columnNumber: 5
  }, this);
}
_s(DashboardAnalyticsContent, "P1f5o7rDMgRcCwVOPByP+vMbdaM=");
_c2 = DashboardAnalyticsContent;
function Analytics() {
  return /* @__PURE__ */ jsxDEV(DashboardAnalyticsContent, {}, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx",
    lineNumber: 784,
    columnNumber: 10
  }, this);
}
_c3 = Analytics;
export default Analytics;
var _c, _c2, _c3;
$RefreshReg$(_c, "ChartCard");
$RefreshReg$(_c2, "DashboardAnalyticsContent");
$RefreshReg$(_c3, "Analytics");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Analytics.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb01NLFNBZ09JLFVBaE9KOzJCQXBNTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLFNBQVNBLFVBQVVDLFdBQVdDLG1CQUFtQjtBQUNqRCxPQUFPQyxhQUFhO0FBQ3BCO0FBQUEsRUFDRUM7QUFBQUEsRUFBVUM7QUFBQUEsRUFBS0M7QUFBQUEsRUFBT0M7QUFBQUEsRUFBT0M7QUFBQUEsRUFBZUM7QUFBQUEsRUFBU0M7QUFBQUEsRUFDckRDO0FBQUFBLEVBQXFCQztBQUFBQSxFQUFXQztBQUFBQSxFQUFNQztBQUFBQSxFQUFVQztBQUFBQSxFQUFLQztBQUFBQSxFQUNyREM7QUFBQUEsRUFBV0M7QUFBQUEsT0FDTjtBQUNQO0FBQUEsRUFDRUM7QUFBQUEsRUFBU0M7QUFBQUEsRUFBV0M7QUFBQUEsRUFBZUM7QUFBQUEsRUFBY0M7QUFBQUEsT0FDNUM7QUFDUCxPQUFPQyxTQUFTO0FBR2hCLE1BQU1DLGlCQUFpQjtBQUFBLEVBQ3JCLEVBQUVDLE9BQU8sT0FBT0MsV0FBVyxLQUFLQyxRQUFRLElBQUlDLFdBQVcsR0FBRztBQUFBLEVBQzFELEVBQUVILE9BQU8sT0FBT0MsV0FBVyxLQUFLQyxRQUFRLElBQUlDLFdBQVcsR0FBRztBQUFBLEVBQzFELEVBQUVILE9BQU8sT0FBT0MsV0FBVyxLQUFLQyxRQUFRLElBQUlDLFdBQVcsR0FBRztBQUFBLEVBQzFELEVBQUVILE9BQU8sT0FBT0MsV0FBVyxNQUFNQyxRQUFRLElBQUlDLFdBQVcsR0FBRztBQUFBLEVBQzNELEVBQUVILE9BQU8sT0FBT0MsV0FBVyxNQUFNQyxRQUFRLElBQUlDLFdBQVcsR0FBRztBQUFBLEVBQzNELEVBQUVILE9BQU8sT0FBT0MsV0FBVyxNQUFNQyxRQUFRLElBQUlDLFdBQVcsR0FBRztBQUFBLEVBQzNELEVBQUVILE9BQU8sT0FBT0MsV0FBVyxNQUFNQyxRQUFRLElBQUlDLFdBQVcsR0FBRztBQUFDO0FBRzlELE1BQU1DLGNBQWM7QUFBQSxFQUNsQixFQUFFQyxNQUFNLFVBQVVDLE9BQU8sSUFBSUMsT0FBTyxVQUFVO0FBQUEsRUFDOUMsRUFBRUYsTUFBTSxhQUFhQyxPQUFPLElBQUlDLE9BQU8sVUFBVTtBQUFBLEVBQ2pELEVBQUVGLE1BQU0sWUFBWUMsT0FBTyxJQUFJQyxPQUFPLFVBQVU7QUFBQSxFQUNoRCxFQUFFRixNQUFNLFVBQVVDLE9BQU8sR0FBR0MsT0FBTyxVQUFVO0FBQUM7QUFHaEQsTUFBTUMsY0FBYztBQUFBLEVBQ2xCLEVBQUVSLE9BQU8sT0FBT1MsVUFBVSxJQUFJQyxNQUFNLEdBQUc7QUFBQSxFQUN2QyxFQUFFVixPQUFPLE9BQU9TLFVBQVUsSUFBSUMsTUFBTSxHQUFHO0FBQUEsRUFDdkMsRUFBRVYsT0FBTyxPQUFPUyxVQUFVLElBQUlDLE1BQU0sR0FBRztBQUFBLEVBQ3ZDLEVBQUVWLE9BQU8sT0FBT1MsVUFBVSxJQUFJQyxNQUFNLEdBQUc7QUFBQSxFQUN2QyxFQUFFVixPQUFPLE9BQU9TLFVBQVUsSUFBSUMsTUFBTSxHQUFHO0FBQUEsRUFDdkMsRUFBRVYsT0FBTyxPQUFPUyxVQUFVLElBQUlDLE1BQU0sR0FBRztBQUFBLEVBQ3ZDLEVBQUVWLE9BQU8sT0FBT1MsVUFBVSxJQUFJQyxNQUFNLElBQUk7QUFBQztBQUczQyxNQUFNQyxpQkFBaUI7QUFBQSxFQUNyQixFQUFFQyxLQUFLLE9BQU9DLFVBQVUsSUFBSUMsV0FBVyxJQUFJQyxPQUFPLEdBQUc7QUFBQSxFQUNyRCxFQUFFSCxLQUFLLE9BQU9DLFVBQVUsSUFBSUMsV0FBVyxJQUFJQyxPQUFPLEdBQUc7QUFBQSxFQUNyRCxFQUFFSCxLQUFLLE9BQU9DLFVBQVUsSUFBSUMsV0FBVyxJQUFJQyxPQUFPLEdBQUc7QUFBQSxFQUNyRCxFQUFFSCxLQUFLLE9BQU9DLFVBQVUsSUFBSUMsV0FBVyxJQUFJQyxPQUFPLEdBQUc7QUFBQSxFQUNyRCxFQUFFSCxLQUFLLE9BQU9DLFVBQVUsSUFBSUMsV0FBVyxJQUFJQyxPQUFPLEdBQUc7QUFBQSxFQUNyRCxFQUFFSCxLQUFLLE9BQU9DLFVBQVUsSUFBSUMsV0FBVyxJQUFJQyxPQUFPLEdBQUc7QUFBQSxFQUNyRCxFQUFFSCxLQUFLLE9BQU9DLFVBQVUsSUFBSUMsV0FBVyxHQUFHQyxPQUFPLEdBQUc7QUFBQztBQUd2RCxNQUFNQyxhQUFhO0FBQUEsRUFDakIsRUFBRUMsT0FBTyxPQUFPWCxPQUFPLElBQUk7QUFBQSxFQUMzQixFQUFFVyxPQUFPLGFBQWFYLE9BQU8sSUFBSTtBQUFBLEVBQ2pDLEVBQUVXLE9BQU8sY0FBY1gsT0FBTyxHQUFHO0FBQUEsRUFDakMsRUFBRVcsT0FBTyxhQUFhWCxPQUFPLEdBQUc7QUFBQztBQUduQyxNQUFNWSxhQUFhO0FBQUEsRUFDakIsRUFBRWIsTUFBTSxXQUFXQyxPQUFPLElBQUlDLE9BQU8sVUFBVTtBQUFBLEVBQy9DLEVBQUVGLE1BQU0sZUFBZUMsT0FBTyxJQUFJQyxPQUFPLFVBQVU7QUFBQSxFQUNuRCxFQUFFRixNQUFNLGFBQWFDLE9BQU8sSUFBSUMsT0FBTyxVQUFVO0FBQUM7QUFHcEQsTUFBTVksa0JBQWtCO0FBQUEsRUFDdEIsRUFBRW5CLE9BQU8sT0FBT29CLGFBQWEsR0FBRztBQUFBLEVBQ2hDLEVBQUVwQixPQUFPLE9BQU9vQixhQUFhLEdBQUc7QUFBQSxFQUNoQyxFQUFFcEIsT0FBTyxPQUFPb0IsYUFBYSxHQUFHO0FBQUEsRUFDaEMsRUFBRXBCLE9BQU8sT0FBT29CLGFBQWEsR0FBRztBQUFBLEVBQ2hDLEVBQUVwQixPQUFPLE9BQU9vQixhQUFhLEdBQUc7QUFBQSxFQUNoQyxFQUFFcEIsT0FBTyxPQUFPb0IsYUFBYSxHQUFHO0FBQUEsRUFDaEMsRUFBRXBCLE9BQU8sT0FBT29CLGFBQWEsR0FBRztBQUFDO0FBR25DLE1BQU1DLGtCQUFrQjtBQUFBLEVBQ3RCLEVBQUVyQixPQUFPLE9BQU9zQixhQUFhLE1BQVFDLGVBQWUsS0FBTztBQUFBLEVBQzNELEVBQUV2QixPQUFPLE9BQU9zQixhQUFhLE1BQVFDLGVBQWUsS0FBTztBQUFBLEVBQzNELEVBQUV2QixPQUFPLE9BQU9zQixhQUFhLE9BQVFDLGVBQWUsS0FBTztBQUFBLEVBQzNELEVBQUV2QixPQUFPLE9BQU9zQixhQUFhLE1BQVFDLGVBQWUsS0FBTztBQUFBLEVBQzNELEVBQUV2QixPQUFPLE9BQU9zQixhQUFhLE1BQVFDLGVBQWUsSUFBTztBQUFBLEVBQzNELEVBQUV2QixPQUFPLE9BQU9zQixhQUFhLE1BQVFDLGVBQWUsS0FBTztBQUFBLEVBQzNELEVBQUV2QixPQUFPLE9BQU9zQixhQUFhLE9BQVFDLGVBQWUsS0FBTztBQUFDO0FBSTlELE1BQU1DLGVBQWU7QUFBQSxFQUNuQixFQUFFQyxNQUFNLGlCQUFpQkMsTUFBTSxnQkFBZ0JwQixPQUFPLEtBQVFxQixTQUFTLElBQUlDLGFBQWEsS0FBT0MsT0FBTyxjQUFjQyxLQUFLLGNBQWNDLE9BQU8sS0FBTUMsUUFBUSxHQUFHQyxRQUFRLEtBQU9DLFNBQVMsSUFBTTtBQUFBLEVBQzdMLEVBQUVULE1BQU0sa0JBQWtCQyxNQUFNLGdCQUFnQnBCLE9BQU8sS0FBUXFCLFNBQVMsS0FBS0MsYUFBYSxLQUFNQyxPQUFPLGNBQWNDLEtBQUssY0FBY0MsT0FBTyxLQUFLQyxRQUFRLEdBQUdDLFFBQVEsS0FBTUMsU0FBUyxLQUFNO0FBQUEsRUFDNUwsRUFBRVQsTUFBTSxpQkFBaUJDLE1BQU0sZ0JBQWdCcEIsT0FBTyxLQUFRcUIsU0FBUyxJQUFJQyxhQUFhLEtBQU1DLE9BQU8sY0FBY0MsS0FBSyxjQUFjQyxPQUFPLEtBQUtDLFFBQVEsR0FBR0MsUUFBUSxLQUFNQyxTQUFTLElBQUs7QUFBQSxFQUN6TCxFQUFFVCxNQUFNLGlCQUFpQkMsTUFBTSxnQkFBZ0JwQixPQUFPLEtBQVFxQixTQUFTLElBQUlDLGFBQWEsS0FBTUMsT0FBTyxjQUFjQyxLQUFLLGNBQWNDLE9BQU8sS0FBS0MsUUFBUSxHQUFHQyxRQUFRLEtBQU1DLFNBQVMsSUFBSztBQUFBLEVBQ3pMLEVBQUVULE1BQU0sa0JBQWtCQyxNQUFNLGdCQUFnQnBCLE9BQU8sS0FBUXFCLFNBQVMsS0FBS0MsYUFBYSxLQUFNQyxPQUFPLGNBQWNDLEtBQUssY0FBY0MsT0FBTyxLQUFLQyxRQUFRLEdBQUdDLFFBQVEsS0FBTUMsU0FBUyxLQUFNO0FBQUEsRUFDNUwsRUFBRVQsTUFBTSxrQkFBa0JDLE1BQU0sZ0JBQWdCcEIsT0FBTyxLQUFRcUIsU0FBUyxLQUFLQyxhQUFhLEtBQU1DLE9BQU8sY0FBY0MsS0FBSyxjQUFjQyxPQUFPLEtBQUtDLFFBQVEsR0FBR0MsUUFBUSxLQUFNQyxTQUFTLElBQUs7QUFBQSxFQUMzTCxFQUFFVCxNQUFNLGlCQUFpQkMsTUFBTSxnQkFBZ0JwQixPQUFPLEtBQVFxQixTQUFTLElBQUlDLGFBQWEsS0FBT0MsT0FBTyxjQUFjQyxLQUFLLGNBQWNDLE9BQU8sS0FBTUMsUUFBUSxHQUFHQyxRQUFRLEtBQU9DLFNBQVMsSUFBTTtBQUFBLEVBQzdMLEVBQUVULE1BQU0saUJBQWlCQyxNQUFNLGdCQUFnQnBCLE9BQU8sS0FBUXFCLFNBQVMsSUFBSUMsYUFBYSxLQUFNQyxPQUFPLGNBQWNDLEtBQUssY0FBY0MsT0FBTyxLQUFLQyxRQUFRLEdBQUdDLFFBQVEsS0FBTUMsU0FBUyxJQUFLO0FBQUEsRUFDekwsRUFBRVQsTUFBTSxlQUFlQyxNQUFNLGtCQUFrQnBCLE9BQU8sS0FBT3FCLFNBQVMsSUFBSUMsYUFBYSxLQUFNQyxPQUFPLGNBQWNDLEtBQUssY0FBY0MsT0FBTyxLQUFLQyxRQUFRLEdBQUdDLFFBQVEsS0FBTUMsU0FBUyxJQUFLO0FBQUEsRUFDeEwsRUFBRVQsTUFBTSxrQkFBa0JDLE1BQU0sa0JBQWtCcEIsT0FBTyxNQUFTcUIsU0FBUyxJQUFJQyxhQUFhLE9BQU9DLE9BQU8sY0FBY0MsS0FBSyxjQUFjQyxPQUFPLE1BQU1DLFFBQVEsR0FBR0MsUUFBUSxHQUFHQyxTQUFTLE1BQU07QUFBQSxFQUM3TCxFQUFFVCxNQUFNLGlCQUFpQkMsTUFBTSxnQkFBZ0JwQixPQUFPLEtBQVFxQixTQUFTLElBQUlDLGFBQWEsS0FBTUMsT0FBTyxjQUFjQyxLQUFLLGNBQWNDLE9BQU8sS0FBS0MsUUFBUSxHQUFHQyxRQUFRLEtBQU1DLFNBQVMsSUFBSztBQUFBLEVBQ3pMLEVBQUVULE1BQU0sa0JBQWtCQyxNQUFNLGdCQUFnQnBCLE9BQU8sS0FBUXFCLFNBQVMsS0FBS0MsYUFBYSxLQUFNQyxPQUFPLGNBQWNDLEtBQUssY0FBY0MsT0FBTyxLQUFLQyxRQUFRLEdBQUdDLFFBQVEsS0FBTUMsU0FBUyxJQUFLO0FBQUEsRUFDM0wsRUFBRVQsTUFBTSxpQkFBaUJDLE1BQU0sa0JBQWtCcEIsT0FBTyxLQUFRcUIsU0FBUyxJQUFJQyxhQUFhLE9BQU9DLE9BQU8sY0FBY0MsS0FBSyxjQUFjQyxPQUFPLEdBQUdDLFFBQVEsR0FBR0MsUUFBUSxHQUFHQyxTQUFTLE1BQU07QUFBQSxFQUN4TCxFQUFFVCxNQUFNLGlCQUFpQkMsTUFBTSxnQkFBZ0JwQixPQUFPLEtBQVFxQixTQUFTLElBQUlDLGFBQWEsS0FBT0MsT0FBTyxjQUFjQyxLQUFLLGNBQWNDLE9BQU8sS0FBTUMsUUFBUSxHQUFHQyxRQUFRLEtBQU9DLFNBQVMsSUFBTTtBQUFBLEVBQzdMLEVBQUVULE1BQU0saUJBQWlCQyxNQUFNLGtCQUFrQnBCLE9BQU8sS0FBUXFCLFNBQVMsSUFBSUMsYUFBYSxLQUFPQyxPQUFPLGNBQWNDLEtBQUssY0FBY0MsT0FBTyxLQUFLQyxRQUFRLEdBQUdDLFFBQVEsTUFBTUMsU0FBUyxJQUFNO0FBQUEsRUFDN0wsRUFBRVQsTUFBTSxpQkFBaUJDLE1BQU0sZ0JBQWdCcEIsT0FBTyxLQUFRcUIsU0FBUyxJQUFJQyxhQUFhLEtBQU1DLE9BQU8sY0FBY0MsS0FBSyxjQUFjQyxPQUFPLEtBQUtDLFFBQVEsR0FBR0MsUUFBUSxLQUFNQyxTQUFTLElBQUs7QUFBQSxFQUN6TCxFQUFFVCxNQUFNLGlCQUFpQkMsTUFBTSxnQkFBZ0JwQixPQUFPLEtBQVFxQixTQUFTLElBQUlDLGFBQWEsS0FBTUMsT0FBTyxjQUFjQyxLQUFLLGNBQWNDLE9BQU8sS0FBS0MsUUFBUSxHQUFHQyxRQUFRLEtBQU1DLFNBQVMsSUFBSztBQUFBLEVBQ3pMLEVBQUVULE1BQU0sa0JBQWtCQyxNQUFNLGdCQUFnQnBCLE9BQU8sS0FBUXFCLFNBQVMsSUFBSUMsYUFBYSxLQUFPQyxPQUFPLGNBQWNDLEtBQUssTUFBTUMsT0FBTyxLQUFNQyxRQUFRLElBQUlDLFFBQVEsS0FBT0MsU0FBUyxJQUFNO0FBQUEsRUFDdkwsRUFBRVQsTUFBTSxrQkFBa0JDLE1BQU0sa0JBQWtCcEIsT0FBTyxLQUFRcUIsU0FBUyxJQUFJQyxhQUFhLEtBQU9DLE9BQU8sY0FBY0MsS0FBSyxjQUFjQyxPQUFPLEtBQUtDLFFBQVEsSUFBSUMsUUFBUSxLQUFNQyxTQUFTLElBQU07QUFBQSxFQUMvTCxFQUFFVCxNQUFNLGtCQUFrQkMsTUFBTSxnQkFBZ0JwQixPQUFPLEtBQVFxQixTQUFTLElBQUlDLGFBQWEsS0FBTUMsT0FBTyxjQUFjQyxLQUFLLGNBQWNDLE9BQU8sS0FBS0MsUUFBUSxJQUFJQyxRQUFRLEtBQU1DLFNBQVMsSUFBSztBQUFBLEVBQzNMLEVBQUVULE1BQU0sbUJBQW1CQyxNQUFNLGdCQUFnQnBCLE9BQU8sS0FBUXFCLFNBQVMsS0FBS0MsYUFBYSxLQUFNQyxPQUFPLGNBQWNDLEtBQUssTUFBTUMsT0FBTyxLQUFLQyxRQUFRLElBQUlDLFFBQVEsS0FBTUMsU0FBUyxLQUFNO0FBQUEsRUFDdEwsRUFBRVQsTUFBTSxnQkFBZ0JDLE1BQU0sZUFBZXBCLE9BQU8sS0FBUXFCLFNBQVMsSUFBSUMsYUFBYSxLQUFNQyxPQUFPLGNBQWNDLEtBQUssY0FBY0MsT0FBTyxLQUFLQyxRQUFRLEdBQUdDLFFBQVEsTUFBTUMsU0FBUyxJQUFLO0FBQUEsRUFDdkwsRUFBRVQsTUFBTSxnQkFBZ0JDLE1BQU0sZUFBZXBCLE9BQU8sS0FBUXFCLFNBQVMsSUFBSUMsYUFBYSxLQUFPQyxPQUFPLGNBQWNDLEtBQUssY0FBY0MsT0FBTyxLQUFLQyxRQUFRLEdBQUdDLFFBQVEsTUFBTUMsU0FBUyxJQUFNO0FBQUEsRUFDekwsRUFBRVQsTUFBTSxnQkFBZ0JDLE1BQU0sZUFBZXBCLE9BQU8sS0FBUXFCLFNBQVMsSUFBSUMsYUFBYSxNQUFPQyxPQUFPLGNBQWNDLEtBQUssY0FBY0MsT0FBTyxLQUFLQyxRQUFRLEdBQUdDLFFBQVEsS0FBTUMsU0FBUyxLQUFNO0FBQUEsRUFDekwsRUFBRVQsTUFBTSxnQkFBZ0JDLE1BQU0sZUFBZXBCLE9BQU8sS0FBUXFCLFNBQVMsSUFBSUMsYUFBYSxNQUFPQyxPQUFPLGNBQWNDLEtBQUssY0FBY0MsT0FBTyxLQUFLQyxRQUFRLElBQUlDLFFBQVEsTUFBTUMsU0FBUyxLQUFNO0FBQUEsRUFDMUwsRUFBRVQsTUFBTSxtQkFBbUJDLE1BQU0sZUFBZXBCLE9BQU8sTUFBU3FCLFNBQVMsSUFBSUMsYUFBYSxPQUFPQyxPQUFPLGNBQWNDLEtBQUssY0FBY0MsT0FBTyxNQUFNQyxRQUFRLElBQUlDLFFBQVEsR0FBR0MsU0FBUyxNQUFNO0FBQUEsRUFDNUwsRUFBRVQsTUFBTSxpQkFBaUJDLE1BQU0sZ0JBQWdCcEIsT0FBTyxLQUFRcUIsU0FBUyxJQUFJQyxhQUFhLEtBQU9DLE9BQU8sY0FBY0MsS0FBSyxjQUFjQyxPQUFPLEtBQU1DLFFBQVEsSUFBSUMsUUFBUSxLQUFPQyxTQUFTLElBQU07QUFBQSxFQUM5TCxFQUFFVCxNQUFNLGdCQUFnQkMsTUFBTSx3QkFBd0JwQixPQUFPLEtBQVFxQixTQUFTLElBQUlDLGFBQWEsTUFBT0MsT0FBTyxjQUFjQyxLQUFLLGNBQWNDLE9BQU8sS0FBS0MsUUFBUSxJQUFJQyxRQUFRLE1BQU1DLFNBQVMsS0FBTTtBQUFBLEVBQ25NLEVBQUVULE1BQU0sZ0JBQWdCQyxNQUFNLHdCQUF3QnBCLE9BQU8sS0FBUXFCLFNBQVMsSUFBSUMsYUFBYSxLQUFPQyxPQUFPLGNBQWNDLEtBQUssY0FBY0MsT0FBTyxLQUFLQyxRQUFRLEdBQUdDLFFBQVEsTUFBTUMsU0FBUyxJQUFNO0FBQUEsRUFDbE0sRUFBRVQsTUFBTSxnQkFBZ0JDLE1BQU0sd0JBQXdCcEIsT0FBTyxLQUFRcUIsU0FBUyxJQUFJQyxhQUFhLEtBQU1DLE9BQU8sY0FBY0MsS0FBSyxjQUFjQyxPQUFPLEtBQUtDLFFBQVEsR0FBR0MsUUFBUSxNQUFNQyxTQUFTLElBQUs7QUFBQztBQUluTSxNQUFNQyx5QkFBeUJYLGFBQWFZLElBQUksQ0FBQ0MsT0FBTztBQUFBLEVBQ3REaEMsTUFBTWdDLEVBQUVaO0FBQUFBLEVBQ1JhLFFBQVFELEVBQUVWLFVBQVVVLEVBQUVMO0FBQUFBLEVBQ3RCQSxRQUFRSyxFQUFFTDtBQUNaLEVBQUU7QUFHRixNQUFNTyxrQkFBa0I7QUFBQSxFQUN0QixnQkFBZ0I7QUFBQSxFQUNoQixrQkFBa0I7QUFBQSxFQUNsQixlQUFlO0FBQUEsRUFDZix3QkFBd0I7QUFDMUI7QUFDQSxNQUFNQyxnQkFBZ0JDLE9BQU9DO0FBQUFBLEVBQzNCbEIsYUFBYW1CLE9BQU8sQ0FBQ0MsS0FBS1AsTUFBTTtBQUM5Qk8sUUFBSVAsRUFBRVgsSUFBSSxLQUFLa0IsSUFBSVAsRUFBRVgsSUFBSSxLQUFLLEtBQUs7QUFDbkMsV0FBT2tCO0FBQUFBLEVBQ1QsR0FBRyxDQUFDLENBQUM7QUFDUCxFQUFFUixJQUFJLENBQUMsQ0FBQy9CLE1BQU1DLEtBQUssT0FBTyxFQUFFRCxNQUFNQyxPQUFPQyxPQUFPZ0MsZ0JBQWdCbEMsSUFBSSxLQUFLLFVBQVUsRUFBRTtBQUdyRixNQUFNd0MsbUJBQW1CSixPQUFPQztBQUFBQSxFQUM5QmxCLGFBQWFtQixPQUFPLENBQUNDLEtBQUtQLE1BQU07QUFDOUJPLFFBQUlQLEVBQUVYLElBQUksS0FBS2tCLElBQUlQLEVBQUVYLElBQUksS0FBSyxLQUFLVyxFQUFFL0I7QUFDckMsV0FBT3NDO0FBQUFBLEVBQ1QsR0FBRyxDQUFDLENBQUM7QUFDUCxFQUFFUixJQUFJLENBQUMsQ0FBQ1YsTUFBTW9CLFVBQVUsT0FBTyxFQUFFcEIsTUFBTW9CLFdBQVcsRUFBRTtBQUdwRCxNQUFNQyxzQkFBc0I7QUFBQSxFQUMxQixFQUFFMUMsTUFBTSxVQUFVQyxPQUFPLEtBQUtDLE9BQU8sVUFBVTtBQUFBLEVBQy9DLEVBQUVGLE1BQU0sUUFBUUMsT0FBTyxLQUFLQyxPQUFPLFVBQVU7QUFBQSxFQUM3QyxFQUFFRixNQUFNLFdBQVdDLE9BQU8sSUFBSUMsT0FBTyxVQUFVO0FBQUEsRUFDL0MsRUFBRUYsTUFBTSxjQUFjQyxPQUFPLEtBQUtDLE9BQU8sVUFBVTtBQUFDO0FBSXRELE1BQU15QyxpQkFBaUI7QUFBQSxFQUNyQixFQUFFM0MsTUFBTSxxQkFBcUJDLE9BQU8sSUFBSUMsT0FBTyxVQUFVO0FBQUEsRUFDekQsRUFBRUYsTUFBTSxvQkFBb0JDLE9BQU8sSUFBSUMsT0FBTyxVQUFVO0FBQUM7QUFJM0QsTUFBTTBDLHFCQUFxQjtBQUFBLEVBQ3pCLEVBQUV2QixNQUFNLG9CQUFvQndCLFFBQVEsS0FBTTtBQUFBLEVBQzFDLEVBQUV4QixNQUFNLG1CQUFtQndCLFFBQVEsTUFBTztBQUFBLEVBQzFDLEVBQUV4QixNQUFNLGlCQUFpQndCLFFBQVEsS0FBTTtBQUFBLEVBQ3ZDLEVBQUV4QixNQUFNLGlCQUFpQndCLFFBQVEsTUFBTztBQUFBLEVBQ3hDLEVBQUV4QixNQUFNLG9CQUFvQndCLFFBQVEsS0FBTTtBQUFDO0FBSTdDLE1BQU1DLHNCQUFzQjtBQUFBLEVBQzFCLEVBQUV6QixNQUFNLGVBQWV3QixRQUFRLEtBQU87QUFBQSxFQUN0QyxFQUFFeEIsTUFBTSxlQUFld0IsUUFBUSxLQUFNO0FBQUEsRUFDckMsRUFBRXhCLE1BQU0sZUFBZXdCLFFBQVEsS0FBTTtBQUFBLEVBQ3JDLEVBQUV4QixNQUFNLGdCQUFnQndCLFFBQVEsS0FBTTtBQUFBLEVBQ3RDLEVBQUV4QixNQUFNLFVBQVV3QixRQUFRLEtBQU07QUFBQSxFQUNoQyxFQUFFeEIsTUFBTSxtQkFBbUJ3QixRQUFRLE1BQU87QUFBQSxFQUMxQyxFQUFFeEIsTUFBTSxzQkFBc0J3QixRQUFRLEtBQU07QUFBQztBQUkvQyxNQUFNRSxvQkFBb0I7QUFBQSxFQUN4QixFQUFFL0MsTUFBTSxZQUFZQyxPQUFPLEtBQUtDLE9BQU8sVUFBVTtBQUFBLEVBQ2pELEVBQUVGLE1BQU0sU0FBU0MsT0FBTyxLQUFLQyxPQUFPLFVBQVU7QUFBQSxFQUM5QyxFQUFFRixNQUFNLE9BQU9DLE9BQU8sS0FBS0MsT0FBTyxVQUFVO0FBQUEsRUFDNUMsRUFBRUYsTUFBTSxPQUFPQyxPQUFPLElBQUlDLE9BQU8sVUFBVTtBQUFDO0FBSTlDLE1BQU04QyxZQUFZQSxDQUFDLEVBQUVDLE9BQU9DLFVBQVVDLFVBQVVDLFlBQVksSUFBSUMsU0FBUyxVQUFVLE1BQ2pGO0FBQUEsRUFBQztBQUFBO0FBQUEsSUFDQyxXQUFXLDBNQUEwTUQsU0FBUztBQUFBLElBQzlOLE9BQU8sRUFBRSxrQkFBa0JDLE9BQU87QUFBQSxJQUVsQztBQUFBLDZCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDBDQUEwQ0osbUJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEQ7QUFBQSxRQUM3REMsWUFBWSx1QkFBQyxPQUFFLFdBQVUsMEJBQTBCQSxzQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRDtBQUFBLFdBRi9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0NDO0FBQUFBO0FBQUFBO0FBQUFBLEVBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVNBO0FBQ0FHLEtBWElOO0FBYUMsZ0JBQVNPLDBCQUEwQixFQUFFQyxXQUFXLE1BQU0sSUFBSSxDQUFDLEdBQUc7QUFBQUMsS0FBQTtBQUVuRSxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSTFGLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUMyRixRQUFRQyxTQUFTLElBQUk1RixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDNkYsT0FBT0MsUUFBUSxJQUFJOUYsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQzRCLFFBQVFtRSxTQUFTLElBQUkvRixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDZ0csT0FBT0MsU0FBUyxJQUFJakcsU0FBUyxFQUFFO0FBQ3RDLFFBQU0sQ0FBQ2tHLFVBQVVDLFlBQVksSUFBSW5HLFNBQVMsRUFBRTtBQUM1QyxRQUFNLENBQUNvRyxhQUFhQyxjQUFjLElBQUlyRyxTQUFTLENBQUM7QUFDaEQsUUFBTSxDQUFDc0csdUJBQXVCQyx3QkFBd0IsSUFBSXZHLFNBQVMsR0FBRztBQUN0RSxRQUFNLENBQUN3RyxhQUFhQyxvQkFBb0IsSUFBSXpHLFNBQVMsQ0FBQztBQUd0RCxRQUFNMEcsaUJBQWlCeEcsWUFBWSxZQUFZO0FBQzdDLFFBQUk7QUFDRixZQUFNeUcsV0FBVyxNQUFNbkYsSUFBSW9GLElBQUksd0JBQXdCO0FBQ3ZEaEIsZ0JBQVVlLFNBQVNFLElBQUk7QUFBQSxJQUN6QixTQUFTQyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sOEJBQThCQSxLQUFLO0FBQ2pEbEIsZ0JBQVUsRUFBRTtBQUFBLElBQ2Q7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFFBQU1vQixnQkFBZ0I5RyxZQUFZLFlBQVk7QUFDNUMsUUFBSTtBQUNGLFlBQU15RyxXQUFXLE1BQU1uRixJQUFJb0YsSUFBSSxnQkFBZ0I7QUFDL0NkLGVBQVNhLFNBQVNFLFFBQVEsRUFBRTtBQUFBLElBQzlCLFNBQVNDLE9BQU87QUFDZEMsY0FBUUQsTUFBTSw2QkFBNkJBLEtBQUs7QUFDaERoQixlQUFTLEVBQUU7QUFBQSxJQUNiO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxRQUFNbUIsaUJBQWlCL0csWUFBWSxZQUFZO0FBQzdDLFFBQUk7QUFDRixZQUFNeUcsV0FBVyxNQUFNbkYsSUFBSW9GLElBQUksWUFBWTtBQUMzQyxZQUFNTSxpQkFBaUJQLFNBQVNFLEtBQUtNLFNBQVMsSUFBSUM7QUFBQUEsUUFDaEQsQ0FBQ0QsVUFBVUEsTUFBTUUsZUFBZTtBQUFBLE1BQ2xDO0FBQ0F0QixnQkFBVW1CLGlCQUFpQixFQUFFO0FBQUEsSUFDL0IsU0FBU0osT0FBTztBQUNkQyxjQUFRRCxNQUFNLDhCQUE4QkEsS0FBSztBQUNqRGYsZ0JBQVUsRUFBRTtBQUFBLElBQ2Q7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFFBQU11QixpQkFBaUJwSCxZQUFZLFlBQVk7QUFDN0MsUUFBSTtBQUNGLFlBQU15RyxXQUFXLE1BQU1uRixJQUFJb0YsSUFBSSxrQkFBa0I7QUFDakQsWUFBTVcsaUJBQWlCWixTQUFTRSxRQUFRLElBQUlPO0FBQUFBLFFBQzFDLENBQUNwQixXQUFVQSxPQUFNcUIsZUFBZTtBQUFBLE1BQ2xDO0FBQ0FwQixnQkFBVXNCLGlCQUFpQixFQUFFO0FBQUEsSUFDL0IsU0FBU1QsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDhCQUE4QkEsS0FBSztBQUNqRGIsZ0JBQVUsRUFBRTtBQUFBLElBQ2Q7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFFBQU11QixvQkFBb0J0SCxZQUFZLFlBQVk7QUFDaEQsUUFBSTtBQUNGLFlBQU15RyxXQUFXLE1BQU1uRixJQUFJb0YsSUFBSSxxQkFBcUI7QUFDcEQsWUFBTWEsb0JBQW9CZCxTQUFTRSxNQUFNWCxZQUFZLElBQUlrQjtBQUFBQSxRQUN2RCxDQUFDbEIsY0FBYUEsVUFBU21CLGVBQWU7QUFBQSxNQUN4QztBQUNBbEIsbUJBQWFzQixvQkFBb0IsRUFBRTtBQUFBLElBQ3JDLFNBQVNYLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxpQ0FBaUNBLEtBQUs7QUFDcERYLG1CQUFhLEVBQUU7QUFBQSxJQUNqQjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTXVCLG1CQUFtQnhILFlBQVksWUFBWTtBQUMvQyxRQUFJO0FBQ0YsWUFBTXlHLFdBQVcsTUFBTW5GLElBQUlvRixJQUFJLG1DQUFtQztBQUNsRVAscUJBQWVNLFVBQVVFLE1BQU1ULGVBQWUsQ0FBQztBQUFBLElBQ2pELFNBQVNVLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFDbkRULHFCQUFlLENBQUM7QUFBQSxJQUNsQjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTXNCLHVCQUF1QnpILFlBQVksWUFBWTtBQUNuRCxRQUFJO0FBQ0YsWUFBTTBILFFBQVEsb0JBQUlDLEtBQUs7QUFDdkIsWUFBTUMsZUFBZUYsTUFBTUcsU0FBUztBQUNwQyxZQUFNQyxjQUFjSixNQUFNSyxZQUFZO0FBRXRDLFlBQU1DLGFBQWFBLENBQUNDLFNBQVM7QUFDM0IsY0FBTUMsT0FBT0QsS0FBS0YsWUFBWTtBQUM5QixjQUFNdkcsUUFBUTJHLE9BQU9GLEtBQUtKLFNBQVMsSUFBSSxDQUFDLEVBQUVPLFNBQVMsR0FBRyxHQUFHO0FBQ3pELGNBQU1oRyxNQUFNK0YsT0FBT0YsS0FBS0ksUUFBUSxDQUFDLEVBQUVELFNBQVMsR0FBRyxHQUFHO0FBQ2xELGVBQU8sR0FBR0YsSUFBSSxJQUFJMUcsS0FBSyxJQUFJWSxHQUFHO0FBQUEsTUFDaEM7QUFFQSxZQUFNa0csV0FBV04sV0FBVyxJQUFJTCxLQUFLRyxhQUFhRixjQUFjLENBQUMsQ0FBQztBQUNsRSxZQUFNVyxVQUFVLElBQUlaLEtBQUtHLGFBQWFGLGVBQWUsR0FBRyxDQUFDO0FBQ3pELFlBQU1ZLG1CQUFtQlIsV0FBV08sT0FBTztBQUUzQyxZQUFNOUIsV0FBVyxNQUFNbkYsSUFBSW9GLElBQUksc0NBQXNDO0FBQUEsUUFDbkUrQixRQUFRO0FBQUEsVUFDTkMsV0FBV0o7QUFBQUEsVUFDWEssU0FBU0g7QUFBQUEsUUFDWDtBQUFBLE1BQ0YsQ0FBQztBQUVEbkMsK0JBQXlCSSxVQUFVRSxNQUFNaUMsa0JBQWtCLE9BQU87QUFBQSxJQUNwRSxTQUFTQyxLQUFLO0FBQ1poQyxjQUFRRCxNQUFNLHdDQUF3Q2lDLElBQUlDLE9BQU87QUFDakV6QywrQkFBeUIsT0FBTztBQUFBLElBQ2xDO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxRQUFNMEMseUJBQXlCL0ksWUFBWSxZQUFZO0FBQ3JELFFBQUk7QUFDRixZQUFNeUcsV0FBVyxNQUFNbkYsSUFBSW9GLElBQUksd0JBQXdCO0FBQ3ZESCwyQkFBcUJFLFVBQVVFLE1BQU1BLE9BQU8sQ0FBQyxHQUFHcUMsZ0JBQWdCLENBQUM7QUFBQSxJQUNuRSxTQUFTcEMsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHdDQUF3Q0EsS0FBSztBQUMzREwsMkJBQXFCLENBQUM7QUFBQSxJQUN4QjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBR0x4RztBQUFBQSxJQUFVLE1BQU07QUFDZHlGLGlCQUFXLElBQUk7QUFDZnlELGNBQVFDO0FBQUFBLFFBQUk7QUFBQSxVQUNWMUMsZUFBZTtBQUFBLFVBQ2ZNLGNBQWM7QUFBQSxVQUNkQyxlQUFlO0FBQUEsVUFDZkssZUFBZTtBQUFBLFVBQ2ZFLGtCQUFrQjtBQUFBLFVBQ2xCRSxpQkFBaUI7QUFBQSxVQUNqQkMscUJBQXFCO0FBQUEsVUFDckJzQix1QkFBdUI7QUFBQSxRQUFDO0FBQUEsTUFDekIsRUFBRUksS0FBSyxNQUFNM0QsV0FBVyxLQUFLLENBQUM7QUFBQSxJQUNqQztBQUFBLElBQUc7QUFBQSxNQUNEZ0I7QUFBQUEsTUFDQU07QUFBQUEsTUFDQUM7QUFBQUEsTUFDQUs7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQXNCO0FBQUFBLElBQXNCO0FBQUEsRUFDdkI7QUFHRCxRQUFNSyxPQUFPO0FBQUEsSUFDWDtBQUFBLE1BQ0VDLE9BQU87QUFBQSxNQUNQdkgsT0FBTzZELE9BQU8yRCxRQUFRQyxlQUFlLEtBQUs7QUFBQSxNQUMxQ0MsTUFBTSx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BQ2R6SCxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFc0gsT0FBTztBQUFBLE1BQ1B2SCxPQUFPSixRQUFRNEgsUUFBUUMsZUFBZSxLQUFLO0FBQUEsTUFDM0NDLE1BQU0sdUJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVU7QUFBQSxNQUNoQnpILE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0VzSCxPQUFPO0FBQUEsTUFDUHZILE9BQU9rRSxVQUFVc0QsUUFBUUMsZUFBZSxLQUFLO0FBQUEsTUFDN0NDLE1BQU0sdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFjO0FBQUEsTUFDcEJ6SCxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFc0gsT0FBTztBQUFBLE1BQ1B2SCxPQUFPZ0UsT0FBT3dELFFBQVFDLGVBQWUsS0FBSztBQUFBLE1BQzFDQyxNQUFNLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYztBQUFBLE1BQ3BCekgsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNBO0FBQUEsTUFDRXNILE9BQU87QUFBQSxNQUNQdkgsT0FBTzJELFFBQVE2RCxRQUFRQyxlQUFlLEtBQUs7QUFBQSxNQUMzQ0MsTUFBTSx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWE7QUFBQSxNQUNuQnpILE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0VzSCxPQUFPO0FBQUEsTUFDUHZILE9BQU8sS0FBS3dFLGVBQWUsSUFBSWlELGVBQWUsT0FBTyxDQUFDO0FBQUEsTUFDdERDLE1BQU0sdUJBQUMsY0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVM7QUFBQSxNQUNmekgsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNBO0FBQUEsTUFDRXNILE9BQU87QUFBQSxNQUNQdkgsT0FBTyxJQUFJb0UsZUFBZSxJQUFJcUQsZUFBZSxPQUFPLENBQUM7QUFBQSxNQUNyREMsTUFBTSx1QkFBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUztBQUFBLE1BQ2Z6SCxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFc0gsT0FBTztBQUFBLE1BQ1B2SCxPQUFPLE9BQU9zRSwwQkFBMEIsV0FDcENBLHdCQUNBLEtBQUtBLHlCQUF5QixJQUFJbUQsZUFBZSxPQUFPLENBQUM7QUFBQSxNQUM3REMsTUFBTSx1QkFBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUztBQUFBLE1BQ2Z6SCxPQUFPO0FBQUEsSUFDVDtBQUFBLEVBQUM7QUFHSCxRQUFNMEgsZUFBZUEsTUFDbkIsdUJBQUMsU0FBSSxXQUFVLGtJQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLDBDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0Q7QUFBQSxJQUN0RCx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSwyQ0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXVEO0FBQUEsTUFDdkQsdUJBQUMsU0FBSSxXQUFVLHNDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0Q7QUFBQSxTQUZwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxPQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FNQTtBQUdGLFNBQ0UsdUJBQUMsU0FBSSxXQUFXcEUsV0FBVyxLQUFLLGtCQUM3QjtBQUFBLEtBQUNBLFlBQVksdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVE7QUFBQSxJQUV0Qix1QkFBQyxTQUFJLFdBQVdBLFdBQVcsY0FBYywrRUFDdEM7QUFBQSxPQUFDQSxZQUNBLG1DQUNFO0FBQUEsK0JBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0RBQXVELG1DQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RjtBQUFBLFVBQ3hGLHVCQUFDLE9BQUUsV0FBVSwwQkFBeUIsd0VBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThGO0FBQUEsYUFGaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsNkRBQ1pFLG9CQUNHbUUsTUFBTSxDQUFDLEVBQUVDLEtBQUssQ0FBQyxFQUFFL0YsSUFBSSxDQUFDZ0csR0FBR0MsTUFBTSx1QkFBQyxrQkFBa0JBLEdBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUIsQ0FBRyxJQUN2RFQsS0FBS3hGO0FBQUFBLFVBQUksQ0FBQ2tHLEdBQUdELE1BQ2IsdUJBQUMsU0FBWSxXQUFVLDhOQUNyQjtBQUFBLG1DQUFDLFNBQUksV0FBVyxHQUFHQyxFQUFFL0gsS0FBSyx5SEFDdkIrSCxZQUFFTixRQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLHFDQUFDLE9BQUUsV0FBVSx3REFBd0RNLFlBQUVULFNBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZFO0FBQUEsY0FDN0UsdUJBQUMsT0FBRSxXQUFVLG9EQUFvRFMsWUFBRWhJLFNBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlFO0FBQUEsaUJBRjNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQVBRK0gsR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsUUFDRCxLQWJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFdBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQkE7QUFBQSxNQUdGLHVCQUFDLFNBQUksV0FBVSw4Q0FDYjtBQUFBLCtCQUFDLGFBQVUsT0FBTSxxQ0FBb0MsVUFBUyxpQkFBZ0IsUUFBTyxXQUNuRixpQ0FBQyx1QkFBb0IsT0FBTSxRQUFPLFFBQVEsS0FDeEMsaUNBQUMsYUFBVSxNQUFNdEksZ0JBQ2Y7QUFBQSxpQ0FBQyxpQkFBYyxpQkFBZ0IsT0FBTSxRQUFPLFVBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtEO0FBQUEsVUFDbEQsdUJBQUMsU0FBTSxTQUFRLFNBQVEsTUFBTSxFQUFFd0ksVUFBVSxHQUFHLEtBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThDO0FBQUEsVUFDOUMsdUJBQUMsU0FBTSxNQUFNLEVBQUVBLFVBQVUsR0FBRyxLQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QjtBQUFBLFVBQzlCLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBUTtBQUFBLFVBQ1IsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFPO0FBQUEsVUFDUCx1QkFBQyxRQUFLLE1BQUssWUFBVyxTQUFRLGFBQVksUUFBTyxXQUFVLGFBQWEsS0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEU7QUFBQSxVQUMxRSx1QkFBQyxRQUFLLE1BQUssWUFBVyxTQUFRLFVBQVMsUUFBTyxXQUFVLGFBQWEsS0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUU7QUFBQSxVQUN2RSx1QkFBQyxRQUFLLE1BQUssWUFBVyxTQUFRLGFBQVksUUFBTyxXQUFVLGFBQWEsS0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEU7QUFBQSxhQVI1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0EsS0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUVBLHVCQUFDLGFBQVUsT0FBTSwwQkFBeUIsVUFBUyxvQkFBbUIsUUFBTyxXQUMzRSxpQ0FBQyx1QkFBb0IsT0FBTSxRQUFPLFFBQVEsS0FDeEMsaUNBQUMsWUFDQztBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNbkk7QUFBQUEsY0FDTixTQUFRO0FBQUEsY0FDUixTQUFRO0FBQUEsY0FDUixJQUFHO0FBQUEsY0FDSCxJQUFHO0FBQUEsY0FDSCxhQUFhO0FBQUEsY0FDYixPQUFPLENBQUMsRUFBRUMsTUFBTUMsTUFBTSxNQUFNLEdBQUdELElBQUksS0FBS0MsS0FBSztBQUFBLGNBRTVDRixzQkFBWWdDO0FBQUFBLGdCQUFJLENBQUNvRyxPQUFPSCxNQUN2Qix1QkFBQyxRQUFhLE1BQU1HLE1BQU1qSSxTQUFmOEgsR0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLGNBQ2pDO0FBQUE7QUFBQSxZQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVlBO0FBQUEsVUFDQSx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVE7QUFBQSxVQUNSLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBTztBQUFBLGFBZlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdCQSxLQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0JBLEtBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxRQUVBLHVCQUFDLGFBQVUsT0FBTSxtQkFBa0IsVUFBUyxpQkFBZ0IsUUFBTyxXQUNqRSxpQ0FBQyx1QkFBb0IsT0FBTSxRQUFPLFFBQVEsS0FDeEMsaUNBQUMsWUFBUyxNQUFNN0gsYUFDZDtBQUFBLGlDQUFDLGlCQUFjLGlCQUFnQixPQUFNLFFBQU8sVUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Q7QUFBQSxVQUNsRCx1QkFBQyxTQUFNLFNBQVEsU0FBUSxNQUFNLEVBQUUrSCxVQUFVLEdBQUcsS0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQSxVQUM5Qyx1QkFBQyxTQUFNLE1BQU0sRUFBRUEsVUFBVSxHQUFHLEtBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThCO0FBQUEsVUFDOUIsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFRO0FBQUEsVUFDUix1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQU87QUFBQSxVQUNQLHVCQUFDLE9BQUksU0FBUSxZQUFXLE1BQUssV0FBVSxRQUFRLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxLQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RDtBQUFBLFVBQzVELHVCQUFDLE9BQUksU0FBUSxRQUFPLE1BQUssV0FBVSxRQUFRLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxLQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBLGFBUDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFFBRUEsdUJBQUMsYUFBVSxPQUFNLDZCQUE0QixVQUFTLGFBQVksUUFBTyxXQUN2RSxpQ0FBQyx1QkFBb0IsT0FBTSxRQUFPLFFBQVEsS0FDeEMsaUNBQUMsYUFBVSxNQUFNNUgsZ0JBQ2Y7QUFBQSxpQ0FBQyxpQkFBYyxpQkFBZ0IsT0FBTSxRQUFPLFVBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtEO0FBQUEsVUFDbEQsdUJBQUMsU0FBTSxTQUFRLE9BQU0sTUFBTSxFQUFFNEgsVUFBVSxHQUFHLEtBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRDO0FBQUEsVUFDNUMsdUJBQUMsU0FBTSxNQUFNLEVBQUVBLFVBQVUsR0FBRyxLQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QjtBQUFBLFVBQzlCLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBUTtBQUFBLFVBQ1IsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFPO0FBQUEsVUFDUCx1QkFBQyxRQUFLLE1BQUssWUFBVyxTQUFRLFlBQVcsU0FBUSxLQUFJLFFBQU8sV0FBVSxNQUFLLGFBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9GO0FBQUEsVUFDcEYsdUJBQUMsUUFBSyxNQUFLLFlBQVcsU0FBUSxhQUFZLFNBQVEsS0FBSSxRQUFPLFdBQVUsTUFBSyxhQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRjtBQUFBLFVBQ3JGLHVCQUFDLFFBQUssTUFBSyxZQUFXLFNBQVEsU0FBUSxTQUFRLEtBQUksUUFBTyxXQUFVLE1BQUssYUFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUY7QUFBQSxhQVJuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0EsS0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUVBLHVCQUFDLGFBQVUsT0FBTSxlQUFjLFVBQVMsK0JBQThCLFFBQU8sV0FDM0UsaUNBQUMsdUJBQW9CLE9BQU0sUUFBTyxRQUFRLEtBQ3hDLGlDQUFDLFlBQVMsTUFBTXZILFlBQVksUUFBTyxZQUFXLFFBQVEsRUFBRXlILE1BQU0sR0FBRyxHQUMvRDtBQUFBLGlDQUFDLGlCQUFjLGlCQUFnQixPQUFNLFFBQU8sVUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Q7QUFBQSxVQUNsRCx1QkFBQyxTQUFNLE1BQUssVUFBUyxNQUFNLEVBQUVGLFVBQVUsR0FBRyxLQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QztBQUFBLFVBQzVDLHVCQUFDLFNBQU0sU0FBUSxTQUFRLE1BQUssWUFBVyxNQUFNLEVBQUVBLFVBQVUsR0FBRyxHQUFHLE9BQU8sTUFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUU7QUFBQSxVQUN6RSx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVE7QUFBQSxVQUNSLHVCQUFDLE9BQUksU0FBUSxTQUFRLE1BQUssV0FBVSxRQUFRLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxLQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RDtBQUFBLGFBTDNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBRUEsdUJBQUMsYUFBVSxPQUFNLGVBQWMsVUFBUyw2QkFBNEIsUUFBTyxXQUN6RSxpQ0FBQyx1QkFBb0IsT0FBTSxRQUFPLFFBQVEsS0FDeEMsaUNBQUMsWUFDQztBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNckg7QUFBQUEsY0FDTixTQUFRO0FBQUEsY0FDUixTQUFRO0FBQUEsY0FDUixJQUFHO0FBQUEsY0FDSCxJQUFHO0FBQUEsY0FDSCxhQUFhO0FBQUEsY0FDYixhQUFhO0FBQUEsY0FDYixPQUFPLENBQUMsRUFBRWIsTUFBTUMsTUFBTSxNQUFNLEdBQUdELElBQUksS0FBS0MsS0FBSztBQUFBLGNBRTVDWSxxQkFBV2tCO0FBQUFBLGdCQUFJLENBQUNvRyxPQUFPSCxNQUN0Qix1QkFBQyxRQUFhLE1BQU1HLE1BQU1qSSxTQUFmOEgsR0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLGNBQ2pDO0FBQUE7QUFBQSxZQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWFBO0FBQUEsVUFDQSx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVE7QUFBQSxVQUNSLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBTztBQUFBLGFBaEJUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQSxLQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUJBO0FBQUEsV0FwR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFHQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEsK0JBQUMsYUFBVSxPQUFNLGVBQWMsVUFBUyw2QkFBNEIsUUFBTyxXQUN6RSxpQ0FBQyx1QkFBb0IsT0FBTSxRQUFPLFFBQVEsS0FDeEMsaUNBQUMsYUFBVSxNQUFNbEgsaUJBQ2Y7QUFBQSxpQ0FBQyxpQkFBYyxpQkFBZ0IsT0FBTSxRQUFPLFVBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtEO0FBQUEsVUFDbEQsdUJBQUMsU0FBTSxTQUFRLFNBQVEsTUFBTSxFQUFFb0gsVUFBVSxHQUFHLEtBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThDO0FBQUEsVUFDOUMsdUJBQUMsU0FBTSxNQUFNLEVBQUVBLFVBQVUsR0FBRyxLQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QjtBQUFBLFVBQzlCLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBUTtBQUFBLFVBQ1IsdUJBQUMsUUFBSyxNQUFLLFlBQVcsU0FBUSxlQUFjLFFBQU8sV0FBVSxNQUFLLGFBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJFO0FBQUEsYUFMN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFFQSx1QkFBQyxhQUFVLE9BQU0sMENBQXlDLFVBQVMsZUFBYyxRQUFPLFdBQ3RGLGlDQUFDLHVCQUFvQixPQUFNLFFBQU8sUUFBUSxLQUN4QyxpQ0FBQyxZQUFTLE1BQU1sSCxpQkFDZDtBQUFBLGlDQUFDLGlCQUFjLGlCQUFnQixPQUFNLFFBQU8sVUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Q7QUFBQSxVQUNsRCx1QkFBQyxTQUFNLFNBQVEsU0FBUSxNQUFNLEVBQUVrSCxVQUFVLEdBQUcsS0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQSxVQUM5Qyx1QkFBQyxTQUFNLE1BQU0sRUFBRUEsVUFBVSxHQUFHLEdBQUcsZUFBZSxDQUFDRyxNQUFNLEdBQUdBLElBQUksR0FBSSxPQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRTtBQUFBLFVBQ3BFLHVCQUFDLFdBQVEsV0FBVyxDQUFDQSxNQUFNLElBQUlBLEVBQUVYLGVBQWUsQ0FBQyxNQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRDtBQUFBLFVBQ3BELHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBTztBQUFBLFVBQ1AsdUJBQUMsT0FBSSxTQUFRLGVBQWMsTUFBSyxXQUFVLFFBQVEsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLEtBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStEO0FBQUEsVUFDL0QsdUJBQUMsT0FBSSxTQUFRLGlCQUFnQixNQUFLLFdBQVUsUUFBUSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsS0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUU7QUFBQSxhQVBuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxXQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEJBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDO0FBQUE7QUFBQSxRQUNwQyx1QkFBQyxVQUFLLFdBQVUsc0NBQXFDO0FBQUE7QUFBQSxVQUFFdkcsYUFBYXNHO0FBQUFBLFVBQU87QUFBQSxhQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1GO0FBQUEsV0FEcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sVUFBVSwyQkFBMkJ0RyxhQUFhc0csTUFBTTtBQUFBLFlBQ3hELFFBQU87QUFBQSxZQUNQLFdBQVU7QUFBQSxZQUVWLGlDQUFDLHVCQUFvQixPQUFNLFFBQU8sUUFBUSxLQUN4QyxpQ0FBQyxZQUFTLE1BQU0zRix3QkFBd0IsUUFBTyxZQUFXLFFBQVEsRUFBRXNHLE1BQU0sSUFBSUUsT0FBTyxHQUFHLEdBQ3RGO0FBQUEscUNBQUMsaUJBQWMsaUJBQWdCLE9BQU0sUUFBTyxVQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRDtBQUFBLGNBQ2xELHVCQUFDLFNBQU0sTUFBSyxVQUFTLE1BQU0sRUFBRUosVUFBVSxHQUFHLEtBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRDO0FBQUEsY0FDNUMsdUJBQUMsU0FBTSxTQUFRLFFBQU8sTUFBSyxZQUFXLE1BQU0sRUFBRUEsVUFBVSxHQUFHLEdBQUcsT0FBTyxPQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RTtBQUFBLGNBQ3pFLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBUTtBQUFBLGNBQ1IsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFPO0FBQUEsY0FDUCx1QkFBQyxPQUFJLFNBQVEsVUFBUyxTQUFRLEtBQUksTUFBSyxXQUFVLE1BQUssWUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEQ7QUFBQSxjQUM5RCx1QkFBQyxPQUFJLFNBQVEsVUFBUyxTQUFRLEtBQUksTUFBSyxXQUFVLE1BQUssVUFBUyxRQUFRLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxLQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRjtBQUFBLGlCQVB0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBO0FBQUEsVUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBaUJBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSxpQ0FBQyxhQUFVLE9BQU0sMkJBQTBCLFVBQVMsMkJBQTBCLFFBQU8sV0FDbkYsaUNBQUMsdUJBQW9CLE9BQU0sUUFBTyxRQUFRLEtBQ3hDLGlDQUFDLFlBQ0M7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQU0vRjtBQUFBQSxnQkFDTixTQUFRO0FBQUEsZ0JBQ1IsU0FBUTtBQUFBLGdCQUNSLElBQUc7QUFBQSxnQkFDSCxJQUFHO0FBQUEsZ0JBQ0gsYUFBYTtBQUFBLGdCQUNiLE9BQU8sQ0FBQyxFQUFFbEMsTUFBTSxNQUFNQTtBQUFBQSxnQkFFckJrQyx3QkFBY0o7QUFBQUEsa0JBQUksQ0FBQ29HLE9BQU9ILE1BQ3pCLHVCQUFDLFFBQWEsTUFBTUcsTUFBTWpJLFNBQWY4SCxHQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEsZ0JBQ2pDO0FBQUE7QUFBQSxjQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVlBO0FBQUEsWUFDQSx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVE7QUFBQSxZQUNSLHVCQUFDLFVBQU8sY0FBYyxFQUFFRSxVQUFVLEdBQUcsS0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUM7QUFBQSxlQWZ6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQSxLQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQSxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CQTtBQUFBLFVBRUEsdUJBQUMsYUFBVSxPQUFNLDRCQUEyQixVQUFTLDJCQUEwQixRQUFPLFdBQ3BGLGlDQUFDLHVCQUFvQixPQUFNLFFBQU8sUUFBUSxLQUN4QyxpQ0FBQyxZQUFTLE1BQU0xRixrQkFDZDtBQUFBLG1DQUFDLGlCQUFjLGlCQUFnQixPQUFNLFFBQU8sVUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0Q7QUFBQSxZQUNsRCx1QkFBQyxTQUFNLFNBQVEsUUFBTyxNQUFNLEVBQUUwRixVQUFVLEVBQUUsR0FBRyxVQUFVLEdBQUcsT0FBTyxLQUFLLFlBQVcsT0FBTSxRQUFRLE1BQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtHO0FBQUEsWUFDbEcsdUJBQUMsU0FBTSxNQUFNLEVBQUVBLFVBQVUsR0FBRyxHQUFHLGVBQWUsQ0FBQ0csTUFBTSxHQUFHQSxJQUFJLEdBQU0sT0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0U7QUFBQSxZQUN0RSx1QkFBQyxXQUFRLFdBQVcsQ0FBQ0EsTUFBTSxJQUFJQSxFQUFFWCxlQUFlLENBQUMsTUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Q7QUFBQSxZQUNwRCx1QkFBQyxPQUFJLFNBQVEsY0FBYSxNQUFLLFdBQVUsUUFBUSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsS0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEQ7QUFBQSxlQUxoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUVBLHVCQUFDLGFBQVUsT0FBTSxlQUFjLFVBQVMseUNBQXdDLFFBQU8sV0FDckYsaUNBQUMsdUJBQW9CLE9BQU0sUUFBTyxRQUFRLEtBQ3hDLGlDQUFDLFlBQ0M7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQU0vRTtBQUFBQSxnQkFDTixTQUFRO0FBQUEsZ0JBQ1IsU0FBUTtBQUFBLGdCQUNSLElBQUc7QUFBQSxnQkFDSCxJQUFHO0FBQUEsZ0JBQ0gsYUFBYTtBQUFBLGdCQUNiLGFBQWE7QUFBQSxnQkFDYixPQUFPLENBQUMsRUFBRTFDLE1BQU0sTUFBTUE7QUFBQUEsZ0JBRXJCMEMseUJBQWVaO0FBQUFBLGtCQUFJLENBQUNvRyxPQUFPSCxNQUMxQix1QkFBQyxRQUFhLE1BQU1HLE1BQU1qSSxTQUFmOEgsR0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBLGdCQUNqQztBQUFBO0FBQUEsY0FaSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFhQTtBQUFBLFlBQ0EsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFRO0FBQUEsWUFDUix1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQU87QUFBQSxlQWhCVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQSxLQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQSxLQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFCQTtBQUFBLGFBeERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5REE7QUFBQSxXQTdFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOEVBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLCtCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9FLEtBRHRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEsK0JBQUMsYUFBVSxPQUFNLDZCQUE0QixVQUFTLHFDQUFvQyxRQUFPLFdBQy9GLGlDQUFDLHVCQUFvQixPQUFNLFFBQU8sUUFBUSxLQUN4QyxpQ0FBQyxZQUNDO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU10RjtBQUFBQSxjQUNOLFNBQVE7QUFBQSxjQUNSLFNBQVE7QUFBQSxjQUNSLElBQUc7QUFBQSxjQUNILElBQUc7QUFBQSxjQUNILGFBQWE7QUFBQSxjQUNiLE9BQU8sQ0FBQyxFQUFFMUMsTUFBTUMsTUFBTSxNQUFNLEdBQUdELElBQUksS0FBS0MsS0FBSztBQUFBLGNBRTVDeUMsOEJBQW9CWDtBQUFBQSxnQkFBSSxDQUFDb0csT0FBT0gsTUFDL0IsdUJBQUMsUUFBYSxNQUFNRyxNQUFNakksU0FBZjhILEdBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxjQUNqQztBQUFBO0FBQUEsWUFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFZQTtBQUFBLFVBQ0EsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFRO0FBQUEsVUFDUix1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQU87QUFBQSxhQWZUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkEsS0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtCQSxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsUUFFQSx1QkFBQyxhQUFVLE9BQU0sMkJBQTBCLFVBQVMseUJBQXdCLFFBQU8sV0FDakYsaUNBQUMsdUJBQW9CLE9BQU0sUUFBTyxRQUFRLEtBQ3hDLGlDQUFDLFlBQVMsTUFBTXRGLHFCQUNkO0FBQUEsaUNBQUMsaUJBQWMsaUJBQWdCLE9BQU0sUUFBTyxVQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRDtBQUFBLFVBQ2xELHVCQUFDLFNBQU0sU0FBUSxRQUFPLE1BQU0sRUFBRXdGLFVBQVUsR0FBRyxLQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QztBQUFBLFVBQzdDLHVCQUFDLFNBQU0sTUFBTSxFQUFFQSxVQUFVLEdBQUcsS0FBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEI7QUFBQSxVQUM5Qix1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVE7QUFBQSxVQUNSLHVCQUFDLE9BQUksU0FBUSxTQUFRLFFBQVEsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQ3JDeEYsOEJBQW9CWDtBQUFBQSxZQUFJLENBQUNvRyxPQUFPSCxNQUMvQix1QkFBQyxRQUFhLE1BQU1HLE1BQU1qSSxTQUFmOEgsR0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLFVBQ2pDLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLGFBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBLEtBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsV0FyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNDQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2IsaUNBQUMsUUFBRyxXQUFVLHdDQUF1Qyx3Q0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RSxLQUQvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSw4Q0FDYjtBQUFBLCtCQUFDLGFBQVUsT0FBTSxjQUFhLFVBQVMsb0RBQW1ELFFBQU8sV0FDL0YsaUNBQUMsdUJBQW9CLE9BQU0sUUFBTyxRQUFRLEtBQ3hDLGlDQUFDLFlBQVMsTUFBTXBGLG9CQUFvQixRQUFPLFlBQVcsUUFBUSxFQUFFd0YsTUFBTSxHQUFHLEdBQ3ZFO0FBQUEsaUNBQUMsaUJBQWMsaUJBQWdCLE9BQU0sUUFBTyxVQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRDtBQUFBLFVBQ2xELHVCQUFDLFNBQU0sTUFBSyxVQUFTLE1BQU0sRUFBRUYsVUFBVSxHQUFHLEdBQUcsZUFBZSxDQUFDRyxNQUFNLEdBQUdBLElBQUksR0FBSSxPQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRjtBQUFBLFVBQ2xGLHVCQUFDLFNBQU0sU0FBUSxRQUFPLE1BQUssWUFBVyxNQUFNLEVBQUVILFVBQVUsR0FBRyxHQUFHLE9BQU8sT0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUU7QUFBQSxVQUN6RSx1QkFBQyxXQUFRLFdBQVcsQ0FBQ0csTUFBTSxJQUFJQSxFQUFFWCxlQUFlLENBQUMsTUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxVQUNwRCx1QkFBQyxPQUFJLFNBQVEsVUFBUyxNQUFLLFdBQVUsUUFBUSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsS0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEQ7QUFBQSxhQUw1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUVBLHVCQUFDLGFBQVUsT0FBTSxlQUFjLFVBQVMsNkNBQTRDLFFBQU8sV0FDekYsaUNBQUMsdUJBQW9CLE9BQU0sUUFBTyxRQUFRLEtBQ3hDLGlDQUFDLFlBQVMsTUFBTTVFLHFCQUFxQixRQUFPLFlBQVcsUUFBUSxFQUFFc0YsTUFBTSxHQUFHLEdBQ3hFO0FBQUEsaUNBQUMsaUJBQWMsaUJBQWdCLE9BQU0sUUFBTyxVQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRDtBQUFBLFVBQ2xELHVCQUFDLFNBQU0sTUFBSyxVQUFTLE1BQU0sRUFBRUYsVUFBVSxHQUFHLEdBQUcsZUFBZSxDQUFDRyxNQUFNLEdBQUdBLElBQUksR0FBSSxPQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRjtBQUFBLFVBQ2xGLHVCQUFDLFNBQU0sU0FBUSxRQUFPLE1BQUssWUFBVyxNQUFNLEVBQUVILFVBQVUsR0FBRyxHQUFHLE9BQU8sT0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUU7QUFBQSxVQUN6RSx1QkFBQyxXQUFRLFdBQVcsQ0FBQ0csTUFBTSxJQUFJQSxFQUFFWCxlQUFlLENBQUMsTUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxVQUNwRCx1QkFBQyxPQUFJLFNBQVEsVUFBUyxNQUFLLFdBQVUsUUFBUSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsS0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEQ7QUFBQSxhQUw1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxXQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0JBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLHlCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThELEtBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsK0JBQUMsYUFBVSxPQUFNLDJCQUEwQixVQUFTLDZCQUE0QixRQUFPLFdBQ3JGLGlDQUFDLHVCQUFvQixPQUFNLFFBQU8sUUFBUSxLQUN4QyxpQ0FBQyxZQUNDO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU0zRTtBQUFBQSxjQUNOLFNBQVE7QUFBQSxjQUNSLFNBQVE7QUFBQSxjQUNSLElBQUc7QUFBQSxjQUNILElBQUc7QUFBQSxjQUNILGFBQWE7QUFBQSxjQUNiLE9BQU8sQ0FBQyxFQUFFL0MsTUFBTUMsTUFBTSxNQUFNLEdBQUdELElBQUksS0FBS0MsS0FBSztBQUFBLGNBRTVDOEMsNEJBQWtCaEI7QUFBQUEsZ0JBQUksQ0FBQ29HLE9BQU9ILE1BQzdCLHVCQUFDLFFBQWEsTUFBTUcsTUFBTWpJLFNBQWY4SCxHQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsY0FDakM7QUFBQTtBQUFBLFlBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBWUE7QUFBQSxVQUNBLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBUTtBQUFBLFVBQ1IsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFPO0FBQUEsYUFmVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBLEtBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkEsS0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9CQTtBQUFBLFFBRUEsdUJBQUMsYUFBVSxPQUFNLDJCQUEwQixVQUFTLGNBQWEsUUFBTyxXQUN0RSxpQ0FBQyx1QkFBb0IsT0FBTSxRQUFPLFFBQVEsS0FDeEMsaUNBQUMsWUFBUyxNQUFNakYsbUJBQ2Q7QUFBQSxpQ0FBQyxpQkFBYyxpQkFBZ0IsT0FBTSxRQUFPLFVBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtEO0FBQUEsVUFDbEQsdUJBQUMsU0FBTSxTQUFRLFFBQU8sTUFBTSxFQUFFbUYsVUFBVSxHQUFHLEtBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZDO0FBQUEsVUFDN0MsdUJBQUMsU0FBTSxNQUFNLEVBQUVBLFVBQVUsR0FBRyxLQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QjtBQUFBLFVBQzlCLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBUTtBQUFBLFVBQ1IsdUJBQUMsT0FBSSxTQUFRLFNBQVEsUUFBUSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsR0FDckNuRiw0QkFBa0JoQjtBQUFBQSxZQUFJLENBQUNvRyxPQUFPSCxNQUM3Qix1QkFBQyxRQUFhLE1BQU1HLE1BQU1qSSxTQUFmOEgsR0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLFVBQ2pDLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLGFBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBLEtBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsV0FyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNDQTtBQUFBLFNBdFdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1V0E7QUFBQSxPQTFXRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMldBO0FBRUo7QUFBQ3ZFLEdBamtCZUYsMkJBQXlCO0FBQUFnRixNQUF6QmhGO0FBbWtCaEIsU0FBU2lGLFlBQVk7QUFDbkIsU0FBTyx1QkFBQywrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTBCO0FBQ25DO0FBQUNDLE1BRlFEO0FBSVQsZUFBZUE7QUFBVSxJQUFBbEYsSUFBQWlGLEtBQUFFO0FBQUFDLGFBQUFwRixJQUFBO0FBQUFvRixhQUFBSCxLQUFBO0FBQUFHLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZUNhbGxiYWNrIiwiU2lkZWJhciIsIkJhckNoYXJ0IiwiQmFyIiwiWEF4aXMiLCJZQXhpcyIsIkNhcnRlc2lhbkdyaWQiLCJUb29sdGlwIiwiTGVnZW5kIiwiUmVzcG9uc2l2ZUNvbnRhaW5lciIsIkxpbmVDaGFydCIsIkxpbmUiLCJQaWVDaGFydCIsIlBpZSIsIkNlbGwiLCJBcmVhQ2hhcnQiLCJBcmVhIiwiRmFVc2VycyIsIkZhVXNlclRpZSIsIkZhVXNlckZyaWVuZHMiLCJGYUxheWVyR3JvdXAiLCJGYVdhbGxldCIsImFwaSIsImN1c3RvbWVyR3Jvd3RoIiwibW9udGgiLCJjdXN0b21lcnMiLCJhZ2VudHMiLCJlbXBsb3llZXMiLCJncm91cFN0YXR1cyIsIm5hbWUiLCJ2YWx1ZSIsImNvbG9yIiwiYXVjdGlvbkJpZHMiLCJhdWN0aW9ucyIsImJpZHMiLCJ2aXNpdG9yRW5xdWlyeSIsImRheSIsInZpc2l0b3JzIiwiZW5xdWlyaWVzIiwiY2FsbHMiLCJsZWFkRnVubmVsIiwic3RhZ2UiLCJ0YXNrU3RhdHVzIiwiZW5yb2xsbWVudFRyZW5kIiwiZW5yb2xsbWVudHMiLCJhY2NvdW50c1N1bW1hcnkiLCJjb2xsZWN0aW9ucyIsImRpc2J1cnNlbWVudHMiLCJyYXdHcm91cERhdGEiLCJjb2RlIiwidHlwZSIsIm1lbWJlcnMiLCJpbnN0YWxsbWVudCIsInN0YXJ0IiwiZW5kIiwiZGFpbHkiLCJ2YWNhbnQiLCJ3ZWVrbHkiLCJtb250aGx5IiwiZ3JvdXBTZWF0RmlsbENoYXJ0RGF0YSIsIm1hcCIsImciLCJmaWxsZWQiLCJncm91cFR5cGVDb2xvcnMiLCJncm91cENhdGVnb3J5IiwiT2JqZWN0IiwiZW50cmllcyIsInJlZHVjZSIsImFjYyIsImdyb3VwVmFsdWVCeVR5cGUiLCJ0b3RhbFZhbHVlIiwiY3VzdG9tZXJTdGF0dXNTcGxpdCIsInN0YWZmVHlwZVNwbGl0IiwicGF5bWVudEluQnJlYWtkb3duIiwiYW1vdW50IiwicGF5bWVudE91dEJyZWFrZG93biIsIm1hcmtldGluZ0NoYW5uZWxzIiwiQ2hhcnRDYXJkIiwidGl0bGUiLCJzdWJ0aXRsZSIsImNoaWxkcmVuIiwiY2xhc3NOYW1lIiwiYWNjZW50IiwiX2MiLCJEYXNoYm9hcmRBbmFseXRpY3NDb250ZW50IiwiZW1iZWRkZWQiLCJfcyIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZ3JvdXBzIiwic2V0R3JvdXBzIiwidXNlcnMiLCJzZXRVc2VycyIsInNldEFnZW50cyIsInN0YWZmIiwic2V0U3RhZmZzIiwiZW1wbG95ZWUiLCJzZXRFbXBsb3llZXMiLCJ0b3RhbEFtb3VudCIsInNldFRvdGFsQW1vdW50IiwicGF5bWVudHNQZXJNb250aFZhbHVlIiwic2V0UGF5bWVudHNQZXJNb250aFZhbHVlIiwidGFyZ2V0VmFsdWUiLCJzZXRUb3RhbFRhcmdldEFtb3VudCIsImZldGNoR3JvdXBEYXRhIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwiZXJyb3IiLCJjb25zb2xlIiwiZmV0Y2hVc2VyRGF0YSIsImZldGNoQWdlbnREYXRhIiwidmVyaWZpZWRBZ2VudCIsImFnZW50IiwiZmlsdGVyIiwiaXNWZXJpZmllZCIsImZldGNoU3RhZmZEYXRhIiwidmVyaWZpZWRTdGFmZiIsImZldGNoRW1wbG95ZWVEYXRhIiwidmVyaWZpZWRFbXBsb3llZSIsImZldGNoVG90YWxBbW91bnQiLCJmZXRjaE1vbnRobHlQYXltZW50cyIsInRvZGF5IiwiRGF0ZSIsImN1cnJlbnRNb250aCIsImdldE1vbnRoIiwiY3VycmVudFllYXIiLCJnZXRGdWxsWWVhciIsImZvcm1hdERhdGUiLCJkYXRlIiwieWVhciIsIlN0cmluZyIsInBhZFN0YXJ0IiwiZ2V0RGF0ZSIsImZpcnN0RGF5IiwibGFzdERheSIsImxhc3REYXlGb3JtYXR0ZWQiLCJwYXJhbXMiLCJmcm9tX2RhdGUiLCJ0b19kYXRlIiwibW9udGhseVBheW1lbnQiLCJlcnIiLCJtZXNzYWdlIiwiZmV0Y2hUb3RhbEJyYW5jaFRhcmdldCIsImJyYW5jaFRhcmdldCIsIlByb21pc2UiLCJhbGwiLCJ0aGVuIiwia3BpcyIsImxhYmVsIiwibGVuZ3RoIiwidG9Mb2NhbGVTdHJpbmciLCJpY29uIiwiU2tlbGV0b25DYXJkIiwiQXJyYXkiLCJmaWxsIiwiXyIsImkiLCJrIiwiZm9udFNpemUiLCJlbnRyeSIsImxlZnQiLCJ2IiwicmlnaHQiLCJfYzIiLCJBbmFseXRpY3MiLCJfYzMiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQW5hbHl0aWNzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSByZWFjdC9wcm9wLXR5cGVzICovXHJcbmltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZUNhbGxiYWNrIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQge1xyXG4gIEJhckNoYXJ0LCBCYXIsIFhBeGlzLCBZQXhpcywgQ2FydGVzaWFuR3JpZCwgVG9vbHRpcCwgTGVnZW5kLFxyXG4gIFJlc3BvbnNpdmVDb250YWluZXIsIExpbmVDaGFydCwgTGluZSwgUGllQ2hhcnQsIFBpZSwgQ2VsbCxcclxuICBBcmVhQ2hhcnQsIEFyZWEsXHJcbn0gZnJvbSBcInJlY2hhcnRzXCI7XHJcbmltcG9ydCB7XHJcbiAgRmFVc2VycywgRmFVc2VyVGllLCBGYVVzZXJGcmllbmRzLCBGYUxheWVyR3JvdXAsIEZhV2FsbGV0LFxyXG59IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcblxyXG4vLyAtLS0tLS0tLS0tIER1bW15IGRhdGEgZm9yIGdyYXBocyAoa2VlcGluZyBhcyBpcykgLS0tLS0tLS0tLVxyXG5jb25zdCBjdXN0b21lckdyb3d0aCA9IFtcclxuICB7IG1vbnRoOiBcIkphblwiLCBjdXN0b21lcnM6IDgyMCwgYWdlbnRzOiA0MCwgZW1wbG95ZWVzOiAyMiB9LFxyXG4gIHsgbW9udGg6IFwiRmViXCIsIGN1c3RvbWVyczogOTAyLCBhZ2VudHM6IDQ0LCBlbXBsb3llZXM6IDI0IH0sXHJcbiAgeyBtb250aDogXCJNYXJcIiwgY3VzdG9tZXJzOiA5NzAsIGFnZW50czogNDgsIGVtcGxveWVlczogMjYgfSxcclxuICB7IG1vbnRoOiBcIkFwclwiLCBjdXN0b21lcnM6IDEwNDAsIGFnZW50czogNTEsIGVtcGxveWVlczogMjggfSxcclxuICB7IG1vbnRoOiBcIk1heVwiLCBjdXN0b21lcnM6IDExMTAsIGFnZW50czogNTUsIGVtcGxveWVlczogMzEgfSxcclxuICB7IG1vbnRoOiBcIkp1blwiLCBjdXN0b21lcnM6IDExODAsIGFnZW50czogNTgsIGVtcGxveWVlczogMzQgfSxcclxuICB7IG1vbnRoOiBcIkp1bFwiLCBjdXN0b21lcnM6IDEyODQsIGFnZW50czogNjIsIGVtcGxveWVlczogMzggfSxcclxuXTtcclxuXHJcbmNvbnN0IGdyb3VwU3RhdHVzID0gW1xyXG4gIHsgbmFtZTogXCJBY3RpdmVcIiwgdmFsdWU6IDk0LCBjb2xvcjogXCIjM2I4MmY2XCIgfSxcclxuICB7IG5hbWU6IFwiQ29tcGxldGVkXCIsIHZhbHVlOiA1OCwgY29sb3I6IFwiIzIyYzU1ZVwiIH0sXHJcbiAgeyBuYW1lOiBcIlVwY29taW5nXCIsIHZhbHVlOiAyMSwgY29sb3I6IFwiI2Y1OWUwYlwiIH0sXHJcbiAgeyBuYW1lOiBcIkNsb3NlZFwiLCB2YWx1ZTogOSwgY29sb3I6IFwiI2VmNDQ0NFwiIH0sXHJcbl07XHJcblxyXG5jb25zdCBhdWN0aW9uQmlkcyA9IFtcclxuICB7IG1vbnRoOiBcIkphblwiLCBhdWN0aW9uczogMTQsIGJpZHM6IDYyIH0sXHJcbiAgeyBtb250aDogXCJGZWJcIiwgYXVjdGlvbnM6IDE4LCBiaWRzOiA3NCB9LFxyXG4gIHsgbW9udGg6IFwiTWFyXCIsIGF1Y3Rpb25zOiAxNiwgYmlkczogNjggfSxcclxuICB7IG1vbnRoOiBcIkFwclwiLCBhdWN0aW9uczogMjEsIGJpZHM6IDg5IH0sXHJcbiAgeyBtb250aDogXCJNYXlcIiwgYXVjdGlvbnM6IDE5LCBiaWRzOiA4MSB9LFxyXG4gIHsgbW9udGg6IFwiSnVuXCIsIGF1Y3Rpb25zOiAyNCwgYmlkczogOTYgfSxcclxuICB7IG1vbnRoOiBcIkp1bFwiLCBhdWN0aW9uczogMjcsIGJpZHM6IDEwOCB9LFxyXG5dO1xyXG5cclxuY29uc3QgdmlzaXRvckVucXVpcnkgPSBbXHJcbiAgeyBkYXk6IFwiTW9uXCIsIHZpc2l0b3JzOiAzMiwgZW5xdWlyaWVzOiAxMiwgY2FsbHM6IDE4IH0sXHJcbiAgeyBkYXk6IFwiVHVlXCIsIHZpc2l0b3JzOiA0MSwgZW5xdWlyaWVzOiAxNSwgY2FsbHM6IDIyIH0sXHJcbiAgeyBkYXk6IFwiV2VkXCIsIHZpc2l0b3JzOiAzOCwgZW5xdWlyaWVzOiAxMSwgY2FsbHM6IDE5IH0sXHJcbiAgeyBkYXk6IFwiVGh1XCIsIHZpc2l0b3JzOiA1NSwgZW5xdWlyaWVzOiAyMCwgY2FsbHM6IDI3IH0sXHJcbiAgeyBkYXk6IFwiRnJpXCIsIHZpc2l0b3JzOiA0OSwgZW5xdWlyaWVzOiAxNywgY2FsbHM6IDI0IH0sXHJcbiAgeyBkYXk6IFwiU2F0XCIsIHZpc2l0b3JzOiA2MCwgZW5xdWlyaWVzOiAyNCwgY2FsbHM6IDMwIH0sXHJcbiAgeyBkYXk6IFwiU3VuXCIsIHZpc2l0b3JzOiAyOCwgZW5xdWlyaWVzOiA5LCBjYWxsczogMTQgfSxcclxuXTtcclxuXHJcbmNvbnN0IGxlYWRGdW5uZWwgPSBbXHJcbiAgeyBzdGFnZTogXCJOZXdcIiwgdmFsdWU6IDE1NiB9LFxyXG4gIHsgc3RhZ2U6IFwiQ29udGFjdGVkXCIsIHZhbHVlOiAxMTIgfSxcclxuICB7IHN0YWdlOiBcIkludGVyZXN0ZWRcIiwgdmFsdWU6IDc0IH0sXHJcbiAgeyBzdGFnZTogXCJDb252ZXJ0ZWRcIiwgdmFsdWU6IDM4IH0sXHJcbl07XHJcblxyXG5jb25zdCB0YXNrU3RhdHVzID0gW1xyXG4gIHsgbmFtZTogXCJQZW5kaW5nXCIsIHZhbHVlOiA0OCwgY29sb3I6IFwiI2Y1OWUwYlwiIH0sXHJcbiAgeyBuYW1lOiBcIkluIFByb2dyZXNzXCIsIHZhbHVlOiAyNiwgY29sb3I6IFwiIzNiODJmNlwiIH0sXHJcbiAgeyBuYW1lOiBcIkNvbXBsZXRlZFwiLCB2YWx1ZTogNzEsIGNvbG9yOiBcIiMyMmM1NWVcIiB9LFxyXG5dO1xyXG5cclxuY29uc3QgZW5yb2xsbWVudFRyZW5kID0gW1xyXG4gIHsgbW9udGg6IFwiSmFuXCIsIGVucm9sbG1lbnRzOiAxOCB9LFxyXG4gIHsgbW9udGg6IFwiRmViXCIsIGVucm9sbG1lbnRzOiAyNCB9LFxyXG4gIHsgbW9udGg6IFwiTWFyXCIsIGVucm9sbG1lbnRzOiAyMSB9LFxyXG4gIHsgbW9udGg6IFwiQXByXCIsIGVucm9sbG1lbnRzOiAyOSB9LFxyXG4gIHsgbW9udGg6IFwiTWF5XCIsIGVucm9sbG1lbnRzOiAzMyB9LFxyXG4gIHsgbW9udGg6IFwiSnVuXCIsIGVucm9sbG1lbnRzOiAyNyB9LFxyXG4gIHsgbW9udGg6IFwiSnVsXCIsIGVucm9sbG1lbnRzOiAzNSB9LFxyXG5dO1xyXG5cclxuY29uc3QgYWNjb3VudHNTdW1tYXJ5ID0gW1xyXG4gIHsgbW9udGg6IFwiSmFuXCIsIGNvbGxlY3Rpb25zOiA0MjAwMDAsIGRpc2J1cnNlbWVudHM6IDE4MDAwMCB9LFxyXG4gIHsgbW9udGg6IFwiRmViXCIsIGNvbGxlY3Rpb25zOiA0NjAwMDAsIGRpc2J1cnNlbWVudHM6IDIxMDAwMCB9LFxyXG4gIHsgbW9udGg6IFwiTWFyXCIsIGNvbGxlY3Rpb25zOiA1MDUwMDAsIGRpc2J1cnNlbWVudHM6IDI0MDAwMCB9LFxyXG4gIHsgbW9udGg6IFwiQXByXCIsIGNvbGxlY3Rpb25zOiA1NDAwMDAsIGRpc2J1cnNlbWVudHM6IDI2MDAwMCB9LFxyXG4gIHsgbW9udGg6IFwiTWF5XCIsIGNvbGxlY3Rpb25zOiA1OTAwMDAsIGRpc2J1cnNlbWVudHM6IDMwMDAwMCB9LFxyXG4gIHsgbW9udGg6IFwiSnVuXCIsIGNvbGxlY3Rpb25zOiA2MzAwMDAsIGRpc2J1cnNlbWVudHM6IDMyMDAwMCB9LFxyXG4gIHsgbW9udGg6IFwiSnVsXCIsIGNvbGxlY3Rpb25zOiA2NzUwMDAsIGRpc2J1cnNlbWVudHM6IDM1MDAwMCB9LFxyXG5dO1xyXG5cclxuLy8gLS0tLS0tLS0tLSBSRUFMIEdyb3VwIGRhdGEgKHJlcGxhY2VzIGR1bW15IGdyb3VwU2VhdEZpbGwgLyBncm91cENhdGVnb3J5KSAtLS0tLS0tLS0tXHJcbmNvbnN0IHJhd0dyb3VwRGF0YSA9IFtcclxuICB7IGNvZGU6IFwiTUNGLTVMLUFHLTUwTVwiLCB0eXBlOiBcIkRvdWJsZSBHcm91cFwiLCB2YWx1ZTogNTAwMDAwLCBtZW1iZXJzOiA1MCwgaW5zdGFsbG1lbnQ6IDEwMDAwLCBzdGFydDogXCIxOS8wMi8yMDI1XCIsIGVuZDogXCIxOS8wNC8yMDI2XCIsIGRhaWx5OiAxMDAwLCB2YWNhbnQ6IDUsIHdlZWtseTogMTAwMDAsIG1vbnRobHk6IDMwMDAwIH0sXHJcbiAgeyBjb2RlOiBcIk1DRi01TC1BRy0xMDBNXCIsIHR5cGU6IFwiRG91YmxlIEdyb3VwXCIsIHZhbHVlOiA1MDAwMDAsIG1lbWJlcnM6IDEwMCwgaW5zdGFsbG1lbnQ6IDUwMDAsIHN0YXJ0OiBcIjIyLzA1LzIwMjVcIiwgZW5kOiBcIjIyLzA5LzIwMjdcIiwgZGFpbHk6IDUwMCwgdmFjYW50OiA0LCB3ZWVrbHk6IDUwMDAsIG1vbnRobHk6IDE1MDAwIH0sXHJcbiAgeyBjb2RlOiBcIk1DRi0xTC1BRy01ME1cIiwgdHlwZTogXCJEb3VibGUgR3JvdXBcIiwgdmFsdWU6IDEwMDAwMCwgbWVtYmVyczogNTAsIGluc3RhbGxtZW50OiAyMDAwLCBzdGFydDogXCIxMC8wMy8yMDI1XCIsIGVuZDogXCIxMC8wNS8yMDI2XCIsIGRhaWx5OiAyMDAsIHZhY2FudDogNSwgd2Vla2x5OiAyMDAwLCBtb250aGx5OiA2MDAwIH0sXHJcbiAgeyBjb2RlOiBcIk1DRi0xTC1CRy01ME1cIiwgdHlwZTogXCJEb3VibGUgR3JvdXBcIiwgdmFsdWU6IDEwMDAwMCwgbWVtYmVyczogNTAsIGluc3RhbGxtZW50OiAyMDAwLCBzdGFydDogXCIyMi8wNS8yMDI1XCIsIGVuZDogXCIyMi8wNy8yMDI2XCIsIGRhaWx5OiAyMDAsIHZhY2FudDogNiwgd2Vla2x5OiAyMDAwLCBtb250aGx5OiA2MDAwIH0sXHJcbiAgeyBjb2RlOiBcIk1DRi01TC1CRy0xMDBNXCIsIHR5cGU6IFwiRG91YmxlIEdyb3VwXCIsIHZhbHVlOiA1MDAwMDAsIG1lbWJlcnM6IDEwMCwgaW5zdGFsbG1lbnQ6IDUwMDAsIHN0YXJ0OiBcIjEwLzAxLzIwMjZcIiwgZW5kOiBcIjEwLzA1LzIwMjhcIiwgZGFpbHk6IDUwMCwgdmFjYW50OiA3LCB3ZWVrbHk6IDUwMDAsIG1vbnRobHk6IDE1MDAwIH0sXHJcbiAgeyBjb2RlOiBcIk1DRi0xTC1BRy0xMDBNXCIsIHR5cGU6IFwiRG91YmxlIEdyb3VwXCIsIHZhbHVlOiAxMDAwMDAsIG1lbWJlcnM6IDEwMCwgaW5zdGFsbG1lbnQ6IDEwMDAsIHN0YXJ0OiBcIjMxLzA1LzIwMjVcIiwgZW5kOiBcIjMwLzA5LzIwMjdcIiwgZGFpbHk6IDEwMCwgdmFjYW50OiAyLCB3ZWVrbHk6IDEwMDAsIG1vbnRobHk6IDMwMDAgfSxcclxuICB7IGNvZGU6IFwiTUNGLTVMLUJHLTUwTVwiLCB0eXBlOiBcIkRvdWJsZSBHcm91cFwiLCB2YWx1ZTogNTAwMDAwLCBtZW1iZXJzOiA1MCwgaW5zdGFsbG1lbnQ6IDEwMDAwLCBzdGFydDogXCIzMC8wNi8yMDI1XCIsIGVuZDogXCIzMC8wOC8yMDI2XCIsIGRhaWx5OiAxMDAwLCB2YWNhbnQ6IDMsIHdlZWtseTogMTAwMDAsIG1vbnRobHk6IDMwMDAwIH0sXHJcbiAgeyBjb2RlOiBcIk1DRi0xTC1DRy01ME1cIiwgdHlwZTogXCJEb3VibGUgR3JvdXBcIiwgdmFsdWU6IDEwMDAwMCwgbWVtYmVyczogNTAsIGluc3RhbGxtZW50OiAyMDAwLCBzdGFydDogXCIzMS8wNy8yMDI1XCIsIGVuZDogXCIzMC8wOS8yMDI2XCIsIGRhaWx5OiAyMDAsIHZhY2FudDogMywgd2Vla2x5OiAyMDAwLCBtb250aGx5OiA2MDAwIH0sXHJcbiAgeyBjb2RlOiBcIk1DRi01MEstNTBNXCIsIHR5cGU6IFwiRGl2aWRlbnQgR3JvdXBcIiwgdmFsdWU6IDUwMDAwLCBtZW1iZXJzOiA1MCwgaW5zdGFsbG1lbnQ6IDEwMDAsIHN0YXJ0OiBcIjI5LzA2LzIwMjVcIiwgZW5kOiBcIjI5LzA4LzIwMjZcIiwgZGFpbHk6IDEwMCwgdmFjYW50OiA2LCB3ZWVrbHk6IDEwMDAsIG1vbnRobHk6IDMwMDAgfSxcclxuICB7IGNvZGU6IFwiTUNGLTI1TC1BRy00ME1cIiwgdHlwZTogXCJEaXZpZGVudCBHcm91cFwiLCB2YWx1ZTogMjUwMDAwMCwgbWVtYmVyczogNDAsIGluc3RhbGxtZW50OiA2MjUwMCwgc3RhcnQ6IFwiMTUvMDMvMjAyNlwiLCBlbmQ6IFwiMTUvMDYvMjAyOVwiLCBkYWlseTogMjEwMCwgdmFjYW50OiA2LCB3ZWVrbHk6IDAsIG1vbnRobHk6IDYyNTAwIH0sXHJcbiAgeyBjb2RlOiBcIk1DRi0xTC1ERy01ME1cIiwgdHlwZTogXCJEb3VibGUgR3JvdXBcIiwgdmFsdWU6IDEwMDAwMCwgbWVtYmVyczogNTAsIGluc3RhbGxtZW50OiAyMDAwLCBzdGFydDogXCIxMC8xMC8yMDI1XCIsIGVuZDogXCIxMC8xMi8yMDI2XCIsIGRhaWx5OiAyMDAsIHZhY2FudDogNywgd2Vla2x5OiAyMDAwLCBtb250aGx5OiA2MDAwIH0sXHJcbiAgeyBjb2RlOiBcIk1DRi0xTC1CRy0xMDBNXCIsIHR5cGU6IFwiRG91YmxlIEdyb3VwXCIsIHZhbHVlOiAxMDAwMDAsIG1lbWJlcnM6IDEwMCwgaW5zdGFsbG1lbnQ6IDEwMDAsIHN0YXJ0OiBcIjIwLzAzLzIwMjZcIiwgZW5kOiBcIjIwLzA3LzIwMjhcIiwgZGFpbHk6IDEwMCwgdmFjYW50OiA5LCB3ZWVrbHk6IDEwMDAsIG1vbnRobHk6IDMwMDAgfSxcclxuICB7IGNvZGU6IFwiTUNGLTVMLUFHLTQwTVwiLCB0eXBlOiBcIkRpdmlkZW50IEdyb3VwXCIsIHZhbHVlOiA1MDAwMDAsIG1lbWJlcnM6IDQwLCBpbnN0YWxsbWVudDogMTI1MDAsIHN0YXJ0OiBcIjE1LzAzLzIwMjZcIiwgZW5kOiBcIjE1LzA2LzIwMjlcIiwgZGFpbHk6IDAsIHZhY2FudDogNCwgd2Vla2x5OiAwLCBtb250aGx5OiAxMjUwMCB9LFxyXG4gIHsgY29kZTogXCJNQ0YtNUwtQ0ctNTBNXCIsIHR5cGU6IFwiRG91YmxlIEdyb3VwXCIsIHZhbHVlOiA1MDAwMDAsIG1lbWJlcnM6IDUwLCBpbnN0YWxsbWVudDogMTAwMDAsIHN0YXJ0OiBcIjIwLzExLzIwMjVcIiwgZW5kOiBcIjIwLzAxLzIwMjdcIiwgZGFpbHk6IDEwMDAsIHZhY2FudDogNiwgd2Vla2x5OiAxMDAwMCwgbW9udGhseTogMzAwMDAgfSxcclxuICB7IGNvZGU6IFwiTUNGLTVMLUFHLTI1TVwiLCB0eXBlOiBcIkRpdmlkZW50IEdyb3VwXCIsIHZhbHVlOiA1MDAwMDAsIG1lbWJlcnM6IDI1LCBpbnN0YWxsbWVudDogMjAwMDAsIHN0YXJ0OiBcIjE1LzAzLzIwMjZcIiwgZW5kOiBcIjE1LzAzLzIwMjhcIiwgZGFpbHk6IDY2NiwgdmFjYW50OiA0LCB3ZWVrbHk6IDQ2NjYsIG1vbnRobHk6IDIwMDAwIH0sXHJcbiAgeyBjb2RlOiBcIk1DRi0xTC1FRy01ME1cIiwgdHlwZTogXCJEb3VibGUgR3JvdXBcIiwgdmFsdWU6IDEwMDAwMCwgbWVtYmVyczogNTAsIGluc3RhbGxtZW50OiAyMDAwLCBzdGFydDogXCIxMC8wMS8yMDI2XCIsIGVuZDogXCIxMC8wMy8yMDI3XCIsIGRhaWx5OiAyMDAsIHZhY2FudDogNiwgd2Vla2x5OiAyMDAwLCBtb250aGx5OiA2MDAwIH0sXHJcbiAgeyBjb2RlOiBcIk1DRi0xTC1GRy01ME1cIiwgdHlwZTogXCJEb3VibGUgR3JvdXBcIiwgdmFsdWU6IDEwMDAwMCwgbWVtYmVyczogNTAsIGluc3RhbGxtZW50OiAyMDAwLCBzdGFydDogXCIyOC8wMi8yMDI2XCIsIGVuZDogXCIwMy8wNS8yMDI3XCIsIGRhaWx5OiAyMDAsIHZhY2FudDogNSwgd2Vla2x5OiAyMDAwLCBtb250aGx5OiA2MDAwIH0sXHJcbiAgeyBjb2RlOiBcIk1DRi1ONUwtREctNTBNXCIsIHR5cGU6IFwiRG91YmxlIEdyb3VwXCIsIHZhbHVlOiA1MDAwMDAsIG1lbWJlcnM6IDUwLCBpbnN0YWxsbWVudDogMzAwMDAsIHN0YXJ0OiBcIjEwLzA1LzIwMjZcIiwgZW5kOiBudWxsLCBkYWlseTogMTAwMCwgdmFjYW50OiAxNSwgd2Vla2x5OiAxMDAwMCwgbW9udGhseTogMzAwMDAgfSxcclxuICB7IGNvZGU6IFwiTUNGLU41TC1CRy0yNU1cIiwgdHlwZTogXCJEaXZpZGVudCBHcm91cFwiLCB2YWx1ZTogNTAwMDAwLCBtZW1iZXJzOiAyNSwgaW5zdGFsbG1lbnQ6IDIwMDAwLCBzdGFydDogXCIxNS8wNC8yMDI2XCIsIGVuZDogXCIxNS8wNC8yMDI4XCIsIGRhaWx5OiA3NTAsIHZhY2FudDogMTAsIHdlZWtseTogNTAwMCwgbW9udGhseTogMjAwMDAgfSxcclxuICB7IGNvZGU6IFwiTUNGLU4xTC1HRy01ME1cIiwgdHlwZTogXCJEb3VibGUgR3JvdXBcIiwgdmFsdWU6IDEwMDAwMCwgbWVtYmVyczogNTAsIGluc3RhbGxtZW50OiAyMDAwLCBzdGFydDogXCIwMS8wNS8yMDI2XCIsIGVuZDogXCIwMS8wNi8yMDI3XCIsIGRhaWx5OiAyMDAsIHZhY2FudDogMTAsIHdlZWtseTogMjAwMCwgbW9udGhseTogNjAwMCB9LFxyXG4gIHsgY29kZTogXCJNQ0YtTjVMLUJHLTEwME1cIiwgdHlwZTogXCJEb3VibGUgR3JvdXBcIiwgdmFsdWU6IDUwMDAwMCwgbWVtYmVyczogMTAwLCBpbnN0YWxsbWVudDogNTAwMCwgc3RhcnQ6IFwiMjAvMDQvMjAyNlwiLCBlbmQ6IG51bGwsIGRhaWx5OiA1MDAsIHZhY2FudDogMjAsIHdlZWtseTogNTAwMCwgbW9udGhseTogMTUwMDAgfSxcclxuICB7IGNvZGU6IFwiTUNGLU5BMUwtMjBNXCIsIHR5cGU6IFwiRml4ZWQgR3JvdXBcIiwgdmFsdWU6IDEwMDAwMCwgbWVtYmVyczogMjAsIGluc3RhbGxtZW50OiA1MDAwLCBzdGFydDogXCIxNS8wNy8yMDI2XCIsIGVuZDogXCIxNS8wMy8yMDI4XCIsIGRhaWx5OiAyMDAsIHZhY2FudDogNywgd2Vla2x5OiAxMjUwLCBtb250aGx5OiA1MDAwIH0sXHJcbiAgeyBjb2RlOiBcIk1DRi1OQTJMLTIwTVwiLCB0eXBlOiBcIkZpeGVkIEdyb3VwXCIsIHZhbHVlOiAyMDAwMDAsIG1lbWJlcnM6IDIwLCBpbnN0YWxsbWVudDogMTAwMDAsIHN0YXJ0OiBcIjE1LzA3LzIwMjZcIiwgZW5kOiBcIjE1LzAzLzIwMjhcIiwgZGFpbHk6IDM0MCwgdmFjYW50OiA3LCB3ZWVrbHk6IDM0MDAsIG1vbnRobHk6IDEwMDAwIH0sXHJcbiAgeyBjb2RlOiBcIk1DRi1OQTNMLTIwTVwiLCB0eXBlOiBcIkZpeGVkIEdyb3VwXCIsIHZhbHVlOiAzMDAwMDAsIG1lbWJlcnM6IDIwLCBpbnN0YWxsbWVudDogMTUwMDAsIHN0YXJ0OiBcIjE1LzA2LzIwMjZcIiwgZW5kOiBcIjE1LzAyLzIwMjhcIiwgZGFpbHk6IDUwMCwgdmFjYW50OiA4LCB3ZWVrbHk6IDUwMDAsIG1vbnRobHk6IDE1MDAwIH0sXHJcbiAgeyBjb2RlOiBcIk1DRi1OQTVMLTIwTVwiLCB0eXBlOiBcIkZpeGVkIEdyb3VwXCIsIHZhbHVlOiA1MDAwMDAsIG1lbWJlcnM6IDIwLCBpbnN0YWxsbWVudDogMjUwMDAsIHN0YXJ0OiBcIjE1LzA3LzIwMjZcIiwgZW5kOiBcIjE1LzAzLzIwMjhcIiwgZGFpbHk6IDg0MCwgdmFjYW50OiAxMCwgd2Vla2x5OiA4NDAwLCBtb250aGx5OiAyNTAwMCB9LFxyXG4gIHsgY29kZTogXCJNQ0YtTjI1TC1CRy00ME1cIiwgdHlwZTogXCJGaXhlZCBHcm91cFwiLCB2YWx1ZTogMjUwMDAwMCwgbWVtYmVyczogNDAsIGluc3RhbGxtZW50OiA2MjUwMCwgc3RhcnQ6IFwiMTUvMDMvMjAyNlwiLCBlbmQ6IFwiMTUvMDQvMjAyNlwiLCBkYWlseTogMTcwMCwgdmFjYW50OiAxMCwgd2Vla2x5OiAwLCBtb250aGx5OiA2MjUwMCB9LFxyXG4gIHsgY29kZTogXCJNQ0YtNUwtREctNTBNXCIsIHR5cGU6IFwiRG91YmxlIEdyb3VwXCIsIHZhbHVlOiA1MDAwMDAsIG1lbWJlcnM6IDUwLCBpbnN0YWxsbWVudDogMTAwMDAsIHN0YXJ0OiBcIjIwLzA0LzIwMjZcIiwgZW5kOiBcIjIwLzA2LzIwMjdcIiwgZGFpbHk6IDEwMDAsIHZhY2FudDogMTAsIHdlZWtseTogMTAwMDAsIG1vbnRobHk6IDMwMDAwIH0sXHJcbiAgeyBjb2RlOiBcIk1DRi1OQjVMLTIwTVwiLCB0eXBlOiBcIkZpeGVkLWRpdmlkZW50IEdyb3VwXCIsIHZhbHVlOiA1MDAwMDAsIG1lbWJlcnM6IDIwLCBpbnN0YWxsbWVudDogMjUwMDAsIHN0YXJ0OiBcIjE1LzA5LzIwMjZcIiwgZW5kOiBcIjE1LzA1LzIwMjhcIiwgZGFpbHk6IDg0MCwgdmFjYW50OiAxMCwgd2Vla2x5OiA4NDAwLCBtb250aGx5OiAyNTAwMCB9LFxyXG4gIHsgY29kZTogXCJNQ0YtTkIyTC0yME1cIiwgdHlwZTogXCJGaXhlZC1kaXZpZGVudCBHcm91cFwiLCB2YWx1ZTogMjAwMDAwLCBtZW1iZXJzOiAyMCwgaW5zdGFsbG1lbnQ6IDEwMDAwLCBzdGFydDogXCIxNS8wOS8yMDI2XCIsIGVuZDogXCIxNS8wNS8yMDI4XCIsIGRhaWx5OiAzNDAsIHZhY2FudDogOCwgd2Vla2x5OiAzNDAwLCBtb250aGx5OiAxMDAwMCB9LFxyXG4gIHsgY29kZTogXCJNQ0YtTkIxTC0yME1cIiwgdHlwZTogXCJGaXhlZC1kaXZpZGVudCBHcm91cFwiLCB2YWx1ZTogMTAwMDAwLCBtZW1iZXJzOiAyMCwgaW5zdGFsbG1lbnQ6IDUwMDAsIHN0YXJ0OiBcIjE1LzA5LzIwMjZcIiwgZW5kOiBcIjE1LzA1LzIwMjhcIiwgZGFpbHk6IDIwMCwgdmFjYW50OiA4LCB3ZWVrbHk6IDEyNTAsIG1vbnRobHk6IDUwMDAgfSxcclxuXTtcclxuXHJcbi8vIEZpbGxlZCA9IG1lbWJlcnMgLSB2YWNhbnQgc2VhdHNcclxuY29uc3QgZ3JvdXBTZWF0RmlsbENoYXJ0RGF0YSA9IHJhd0dyb3VwRGF0YS5tYXAoKGcpID0+ICh7XHJcbiAgbmFtZTogZy5jb2RlLFxyXG4gIGZpbGxlZDogZy5tZW1iZXJzIC0gZy52YWNhbnQsXHJcbiAgdmFjYW50OiBnLnZhY2FudCxcclxufSkpO1xyXG5cclxuLy8gR3JvdXAgdHlwZSBkaXN0cmlidXRpb24gKHJlcGxhY2VzIERpdmlkZW5kL0ZpeGVkLW9ubHkgcGllKVxyXG5jb25zdCBncm91cFR5cGVDb2xvcnMgPSB7XHJcbiAgXCJEb3VibGUgR3JvdXBcIjogXCIjM2I4MmY2XCIsXHJcbiAgXCJEaXZpZGVudCBHcm91cFwiOiBcIiNmNTllMGJcIixcclxuICBcIkZpeGVkIEdyb3VwXCI6IFwiIzIyYzU1ZVwiLFxyXG4gIFwiRml4ZWQtZGl2aWRlbnQgR3JvdXBcIjogXCIjYTg1NWY3XCIsXHJcbn07XHJcbmNvbnN0IGdyb3VwQ2F0ZWdvcnkgPSBPYmplY3QuZW50cmllcyhcclxuICByYXdHcm91cERhdGEucmVkdWNlKChhY2MsIGcpID0+IHtcclxuICAgIGFjY1tnLnR5cGVdID0gKGFjY1tnLnR5cGVdIHx8IDApICsgMTtcclxuICAgIHJldHVybiBhY2M7XHJcbiAgfSwge30pXHJcbikubWFwKChbbmFtZSwgdmFsdWVdKSA9PiAoeyBuYW1lLCB2YWx1ZSwgY29sb3I6IGdyb3VwVHlwZUNvbG9yc1tuYW1lXSB8fCBcIiM5NGEzYjhcIiB9KSk7XHJcblxyXG4vLyBHcm91cCB2YWx1ZSBkaXN0cmlidXRpb24gKGJvbnVzIGNoYXJ0OiB0b3RhbCBjaGl0IHZhbHVlIGJ5IGdyb3VwIHR5cGUpXHJcbmNvbnN0IGdyb3VwVmFsdWVCeVR5cGUgPSBPYmplY3QuZW50cmllcyhcclxuICByYXdHcm91cERhdGEucmVkdWNlKChhY2MsIGcpID0+IHtcclxuICAgIGFjY1tnLnR5cGVdID0gKGFjY1tnLnR5cGVdIHx8IDApICsgZy52YWx1ZTtcclxuICAgIHJldHVybiBhY2M7XHJcbiAgfSwge30pXHJcbikubWFwKChbdHlwZSwgdG90YWxWYWx1ZV0pID0+ICh7IHR5cGUsIHRvdGFsVmFsdWUgfSkpO1xyXG5cclxuLy8gLS0tLS0tLS0tLSBDdXN0b21lciBzdGF0dXMgc3BsaXQgLS0tLS0tLS0tLVxyXG5jb25zdCBjdXN0b21lclN0YXR1c1NwbGl0ID0gW1xyXG4gIHsgbmFtZTogXCJBY3RpdmVcIiwgdmFsdWU6IDgxMiwgY29sb3I6IFwiIzIyYzU1ZVwiIH0sXHJcbiAgeyBuYW1lOiBcIkhvbGRcIiwgdmFsdWU6IDE0NiwgY29sb3I6IFwiI2Y1OWUwYlwiIH0sXHJcbiAgeyBuYW1lOiBcIlN1c3BlbmRcIiwgdmFsdWU6IDU4LCBjb2xvcjogXCIjZWY0NDQ0XCIgfSxcclxuICB7IG5hbWU6IFwiVW52ZXJpZmllZFwiLCB2YWx1ZTogMjY4LCBjb2xvcjogXCIjOTRhM2I4XCIgfSxcclxuXTtcclxuXHJcbi8vIC0tLS0tLS0tLS0gQ29sbGVjdGlvbiBhZ2VudHMgdnMgT2ZmaWNlIGVtcGxveWVlcyAtLS0tLS0tLS0tXHJcbmNvbnN0IHN0YWZmVHlwZVNwbGl0ID0gW1xyXG4gIHsgbmFtZTogXCJDb2xsZWN0aW9uIEFnZW50c1wiLCB2YWx1ZTogNjIsIGNvbG9yOiBcIiMzYjgyZjZcIiB9LFxyXG4gIHsgbmFtZTogXCJPZmZpY2UgRW1wbG95ZWVzXCIsIHZhbHVlOiAzOCwgY29sb3I6IFwiI2E4NTVmN1wiIH0sXHJcbl07XHJcblxyXG4vLyAtLS0tLS0tLS0tIFBheW1lbnQgSW4gYnJlYWtkb3duIC0tLS0tLS0tLS1cclxuY29uc3QgcGF5bWVudEluQnJlYWtkb3duID0gW1xyXG4gIHsgdHlwZTogXCJSZWdpc3RyYXRpb24gRmVlXCIsIGFtb3VudDogODQwMDAgfSxcclxuICB7IHR5cGU6IFwiUGF5bWVudCBSZWNlaXB0XCIsIGFtb3VudDogMzEyMDAwIH0sXHJcbiAgeyB0eXBlOiBcIlBheW1lbnQgTGlua3NcIiwgYW1vdW50OiA5NjAwMCB9LFxyXG4gIHsgdHlwZTogXCJDaGl0IFRyYW5zZmVyXCIsIGFtb3VudDogMTI4MDAwIH0sXHJcbiAgeyB0eXBlOiBcIkVtcGxveWVlIEFkdmFuY2VcIiwgYW1vdW50OiA0MjAwMCB9LFxyXG5dO1xyXG5cclxuLy8gLS0tLS0tLS0tLSBQYXltZW50IE91dCBicmVha2Rvd24gLS0tLS0tLS0tLVxyXG5jb25zdCBwYXltZW50T3V0QnJlYWtkb3duID0gW1xyXG4gIHsgdHlwZTogXCJDaGl0IFBheW91dFwiLCBhbW91bnQ6IDIxMDAwMCB9LFxyXG4gIHsgdHlwZTogXCJDaGl0IENhbmNlbFwiLCBhbW91bnQ6IDM4MDAwIH0sXHJcbiAgeyB0eXBlOiBcIkxvYW4gUGF5b3V0XCIsIGFtb3VudDogOTYwMDAgfSxcclxuICB7IHR5cGU6IFwiUGlnbXkgUGF5b3V0XCIsIGFtb3VudDogNTQwMDAgfSxcclxuICB7IHR5cGU6IFwiT3RoZXJzXCIsIGFtb3VudDogMTgwMDAgfSxcclxuICB7IHR5cGU6IFwiRW1wbG95ZWUgU2FsYXJ5XCIsIGFtb3VudDogMTQ1MDAwIH0sXHJcbiAgeyB0eXBlOiBcIkVtcGxveWVlIEluY2VudGl2ZVwiLCBhbW91bnQ6IDI3MDAwIH0sXHJcbl07XHJcblxyXG4vLyAtLS0tLS0tLS0tIE1hcmtldGluZyBjaGFubmVsIGJyZWFrZG93biAtLS0tLS0tLS0tXHJcbmNvbnN0IG1hcmtldGluZ0NoYW5uZWxzID0gW1xyXG4gIHsgbmFtZTogXCJXaGF0c0FwcFwiLCB2YWx1ZTogNDIwLCBjb2xvcjogXCIjMjJjNTVlXCIgfSxcclxuICB7IG5hbWU6IFwiRW1haWxcIiwgdmFsdWU6IDE4NSwgY29sb3I6IFwiIzNiODJmNlwiIH0sXHJcbiAgeyBuYW1lOiBcIlNNU1wiLCB2YWx1ZTogMjYwLCBjb2xvcjogXCIjZjU5ZTBiXCIgfSxcclxuICB7IG5hbWU6IFwiUkNTXCIsIHZhbHVlOiA5NSwgY29sb3I6IFwiI2E4NTVmN1wiIH0sXHJcbl07XHJcblxyXG4vLyAtLS0tLS0tLS0tIFJldXNhYmxlIGNhcmQgd3JhcHBlciB3aXRoIGhvdmVyIGJvcmRlciAtLS0tLS0tLS0tXHJcbmNvbnN0IENoYXJ0Q2FyZCA9ICh7IHRpdGxlLCBzdWJ0aXRsZSwgY2hpbGRyZW4sIGNsYXNzTmFtZSA9IFwiXCIsIGFjY2VudCA9IFwiIzAwNzFlM1wiIH0pID0+IChcclxuICA8ZGl2XHJcbiAgICBjbGFzc05hbWU9e2Byb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC83MCBiZy13aGl0ZS84MCBwLTUgc2hhZG93LXNtIHNoYWRvdy1zbGF0ZS05MDAvWzAuMDNdIGJhY2tkcm9wLWJsdXIteGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIGhvdmVyOi10cmFuc2xhdGUteS0wLjUgaG92ZXI6c2hhZG93LW1kIGhvdmVyOnNoYWRvdy1zbGF0ZS05MDAvMTAgJHtjbGFzc05hbWV9YH1cclxuICAgIHN0eWxlPXt7IFwiLS1jaGFydC1hY2NlbnRcIjogYWNjZW50IH19XHJcbiAgPlxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbiAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPnt0aXRsZX08L2gzPlxyXG4gICAgICB7c3VidGl0bGUgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPntzdWJ0aXRsZX08L3A+fVxyXG4gICAgPC9kaXY+XHJcbiAgICB7Y2hpbGRyZW59XHJcbiAgPC9kaXY+XHJcbik7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gRGFzaGJvYXJkQW5hbHl0aWNzQ29udGVudCh7IGVtYmVkZGVkID0gZmFsc2UgfSA9IHt9KSB7XHJcbiAgLy8gU3RhdGUgZm9yIHJlYWwgZGF0YVxyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtncm91cHMsIHNldEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc3RhZmYsIHNldFN0YWZmc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2VtcGxveWVlLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt0b3RhbEFtb3VudCwgc2V0VG90YWxBbW91bnRdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW3BheW1lbnRzUGVyTW9udGhWYWx1ZSwgc2V0UGF5bWVudHNQZXJNb250aFZhbHVlXSA9IHVzZVN0YXRlKFwiMFwiKTtcclxuICBjb25zdCBbdGFyZ2V0VmFsdWUsIHNldFRvdGFsVGFyZ2V0QW1vdW50XSA9IHVzZVN0YXRlKDApO1xyXG5cclxuICAvLyBGZXRjaCBmdW5jdGlvbnMgKGNvcGllZCBmcm9tIEhvbWUgcGFnZSkg4oCUIFVOQ0hBTkdFRFxyXG4gIGNvbnN0IGZldGNoR3JvdXBEYXRhID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2dyb3VwL2dldC1ncm91cC1hZG1pblwiKTtcclxuICAgICAgc2V0R3JvdXBzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGdyb3VwIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgc2V0R3JvdXBzKFtdKTtcclxuICAgIH1cclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IGZldGNoVXNlckRhdGEgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuICAgICAgc2V0VXNlcnMocmVzcG9uc2UuZGF0YSB8fCBbXSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlciBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldFVzZXJzKFtdKTtcclxuICAgIH1cclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IGZldGNoQWdlbnREYXRhID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2FnZW50L2dldFwiKTtcclxuICAgICAgY29uc3QgdmVyaWZpZWRBZ2VudCA9IChyZXNwb25zZS5kYXRhLmFnZW50IHx8IFtdKS5maWx0ZXIoXHJcbiAgICAgICAgKGFnZW50KSA9PiBhZ2VudC5pc1ZlcmlmaWVkID09PSB0cnVlLFxyXG4gICAgICApO1xyXG4gICAgICBzZXRBZ2VudHModmVyaWZpZWRBZ2VudCB8fCBbXSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYWdlbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBZ2VudHMoW10pO1xyXG4gICAgfVxyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hTdGFmZkRhdGEgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYWdlbnQvZ2V0LWFnZW50XCIpO1xyXG4gICAgICBjb25zdCB2ZXJpZmllZFN0YWZmID0gKHJlc3BvbnNlLmRhdGEgfHwgW10pLmZpbHRlcihcclxuICAgICAgICAoc3RhZmYpID0+IHN0YWZmLmlzVmVyaWZpZWQgPT09IHRydWUsXHJcbiAgICAgICk7XHJcbiAgICAgIHNldFN0YWZmcyh2ZXJpZmllZFN0YWZmIHx8IFtdKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBzdGFmZiBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldFN0YWZmcyhbXSk7XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBmZXRjaEVtcGxveWVlRGF0YSA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9hZ2VudC9nZXQtZW1wbG95ZWVcIik7XHJcbiAgICAgIGNvbnN0IHZlcmlmaWVkRW1wbG95ZWUgPSAocmVzcG9uc2UuZGF0YT8uZW1wbG95ZWUgfHwgW10pLmZpbHRlcihcclxuICAgICAgICAoZW1wbG95ZWUpID0+IGVtcGxveWVlLmlzVmVyaWZpZWQgPT09IHRydWUsXHJcbiAgICAgICk7XHJcbiAgICAgIHNldEVtcGxveWVlcyh2ZXJpZmllZEVtcGxveWVlIHx8IFtdKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbXBsb3llZSBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEVtcGxveWVlcyhbXSk7XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBmZXRjaFRvdGFsQW1vdW50ID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3BheW1lbnQvZ2V0LXRvdGFsLXBheW1lbnQtYW1vdW50XCIpO1xyXG4gICAgICBzZXRUb3RhbEFtb3VudChyZXNwb25zZT8uZGF0YT8udG90YWxBbW91bnQgfHwgMCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdG90YWwgYW1vdW50OlwiLCBlcnJvcik7XHJcbiAgICAgIHNldFRvdGFsQW1vdW50KDApO1xyXG4gICAgfVxyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hNb250aGx5UGF5bWVudHMgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgICAgIGNvbnN0IGN1cnJlbnRNb250aCA9IHRvZGF5LmdldE1vbnRoKCk7XHJcbiAgICAgIGNvbnN0IGN1cnJlbnRZZWFyID0gdG9kYXkuZ2V0RnVsbFllYXIoKTtcclxuXHJcbiAgICAgIGNvbnN0IGZvcm1hdERhdGUgPSAoZGF0ZSkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHllYXIgPSBkYXRlLmdldEZ1bGxZZWFyKCk7XHJcbiAgICAgICAgY29uc3QgbW9udGggPSBTdHJpbmcoZGF0ZS5nZXRNb250aCgpICsgMSkucGFkU3RhcnQoMiwgXCIwXCIpO1xyXG4gICAgICAgIGNvbnN0IGRheSA9IFN0cmluZyhkYXRlLmdldERhdGUoKSkucGFkU3RhcnQoMiwgXCIwXCIpO1xyXG4gICAgICAgIHJldHVybiBgJHt5ZWFyfS0ke21vbnRofS0ke2RheX1gO1xyXG4gICAgICB9O1xyXG5cclxuICAgICAgY29uc3QgZmlyc3REYXkgPSBmb3JtYXREYXRlKG5ldyBEYXRlKGN1cnJlbnRZZWFyLCBjdXJyZW50TW9udGgsIDEpKTtcclxuICAgICAgY29uc3QgbGFzdERheSA9IG5ldyBEYXRlKGN1cnJlbnRZZWFyLCBjdXJyZW50TW9udGggKyAxLCAwKTtcclxuICAgICAgY29uc3QgbGFzdERheUZvcm1hdHRlZCA9IGZvcm1hdERhdGUobGFzdERheSk7XHJcblxyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvcGF5bWVudC9nZXQtY3VycmVudC1tb250aC1wYXltZW50XCIsIHtcclxuICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgIGZyb21fZGF0ZTogZmlyc3REYXksXHJcbiAgICAgICAgICB0b19kYXRlOiBsYXN0RGF5Rm9ybWF0dGVkLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc2V0UGF5bWVudHNQZXJNb250aFZhbHVlKHJlc3BvbnNlPy5kYXRhPy5tb250aGx5UGF5bWVudCB8fCBcIuKCuTAuMDBcIik7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIG1vbnRobHkgcGF5bWVudCBkYXRhOlwiLCBlcnIubWVzc2FnZSk7XHJcbiAgICAgIHNldFBheW1lbnRzUGVyTW9udGhWYWx1ZShcIuKCuTAuMDBcIik7XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBmZXRjaFRvdGFsQnJhbmNoVGFyZ2V0ID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3BheW1lbnQvYnJhbmNoL3RhcmdldFwiKTtcclxuICAgICAgc2V0VG90YWxUYXJnZXRBbW91bnQocmVzcG9uc2U/LmRhdGE/LmRhdGE/LlswXT8uYnJhbmNoVGFyZ2V0IHx8IDApO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGJyYW5jaCB0YXJnZXQgYW1vdW50OlwiLCBlcnJvcik7XHJcbiAgICAgIHNldFRvdGFsVGFyZ2V0QW1vdW50KDApO1xyXG4gICAgfVxyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8gRmV0Y2ggYWxsIGRhdGEgb24gbW91bnQg4oCUIFVOQ0hBTkdFRFxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgUHJvbWlzZS5hbGwoW1xyXG4gICAgICBmZXRjaEdyb3VwRGF0YSgpLFxyXG4gICAgICBmZXRjaFVzZXJEYXRhKCksXHJcbiAgICAgIGZldGNoQWdlbnREYXRhKCksXHJcbiAgICAgIGZldGNoU3RhZmZEYXRhKCksXHJcbiAgICAgIGZldGNoRW1wbG95ZWVEYXRhKCksXHJcbiAgICAgIGZldGNoVG90YWxBbW91bnQoKSxcclxuICAgICAgZmV0Y2hNb250aGx5UGF5bWVudHMoKSxcclxuICAgICAgZmV0Y2hUb3RhbEJyYW5jaFRhcmdldCgpLFxyXG4gICAgXSkudGhlbigoKSA9PiBzZXRMb2FkaW5nKGZhbHNlKSk7XHJcbiAgfSwgW1xyXG4gICAgZmV0Y2hHcm91cERhdGEsXHJcbiAgICBmZXRjaFVzZXJEYXRhLFxyXG4gICAgZmV0Y2hBZ2VudERhdGEsXHJcbiAgICBmZXRjaFN0YWZmRGF0YSxcclxuICAgIGZldGNoRW1wbG95ZWVEYXRhLFxyXG4gICAgZmV0Y2hUb3RhbEFtb3VudCxcclxuICAgIGZldGNoTW9udGhseVBheW1lbnRzLFxyXG4gICAgZmV0Y2hUb3RhbEJyYW5jaFRhcmdldCxcclxuICBdKTtcclxuXHJcbiAgLy8gUHJlcGFyZSBLUEkgZGF0YSB3aXRoIHJlYWwgdmFsdWVzIOKAlCBVTkNIQU5HRURcclxuICBjb25zdCBrcGlzID0gW1xyXG4gICAge1xyXG4gICAgICBsYWJlbDogXCJUb3RhbCBDdXN0b21lcnNcIixcclxuICAgICAgdmFsdWU6IHVzZXJzPy5sZW5ndGg/LnRvTG9jYWxlU3RyaW5nKCkgfHwgXCIwXCIsXHJcbiAgICAgIGljb246IDxGYVVzZXJzIC8+LFxyXG4gICAgICBjb2xvcjogXCJiZy1ibHVlLTUwMFwiXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBsYWJlbDogXCJBY3RpdmUgQWdlbnRzXCIsXHJcbiAgICAgIHZhbHVlOiBhZ2VudHM/Lmxlbmd0aD8udG9Mb2NhbGVTdHJpbmcoKSB8fCBcIjBcIixcclxuICAgICAgaWNvbjogPEZhVXNlclRpZSAvPixcclxuICAgICAgY29sb3I6IFwiYmctZ3JlZW4tNTAwXCJcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGxhYmVsOiBcIkVtcGxveWVlc1wiLFxyXG4gICAgICB2YWx1ZTogZW1wbG95ZWU/Lmxlbmd0aD8udG9Mb2NhbGVTdHJpbmcoKSB8fCBcIjBcIixcclxuICAgICAgaWNvbjogPEZhVXNlckZyaWVuZHMgLz4sXHJcbiAgICAgIGNvbG9yOiBcImJnLXB1cnBsZS01MDBcIlxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgbGFiZWw6IFwiU3RhZmZcIixcclxuICAgICAgdmFsdWU6IHN0YWZmPy5sZW5ndGg/LnRvTG9jYWxlU3RyaW5nKCkgfHwgXCIwXCIsXHJcbiAgICAgIGljb246IDxGYVVzZXJGcmllbmRzIC8+LFxyXG4gICAgICBjb2xvcjogXCJiZy1pbmRpZ28tNTAwXCJcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGxhYmVsOiBcIkdyb3VwcyBSdW5uaW5nXCIsXHJcbiAgICAgIHZhbHVlOiBncm91cHM/Lmxlbmd0aD8udG9Mb2NhbGVTdHJpbmcoKSB8fCBcIjBcIixcclxuICAgICAgaWNvbjogPEZhTGF5ZXJHcm91cCAvPixcclxuICAgICAgY29sb3I6IFwiYmctYW1iZXItNTAwXCJcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGxhYmVsOiBcIkJyYW5jaCBUYXJnZXRcIixcclxuICAgICAgdmFsdWU6IGDigrkkeyh0YXJnZXRWYWx1ZSA/PyAwKT8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gLFxyXG4gICAgICBpY29uOiA8RmFXYWxsZXQgLz4sXHJcbiAgICAgIGNvbG9yOiBcImJnLW5ldXRyYWwtNTAwXCJcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGxhYmVsOiBcIlRvdGFsIFBheW1lbnRzXCIsXHJcbiAgICAgIHZhbHVlOiBgJHsodG90YWxBbW91bnQgPz8gMCk/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgICAgaWNvbjogPEZhV2FsbGV0IC8+LFxyXG4gICAgICBjb2xvcjogXCJiZy15ZWxsb3ctNTAwXCJcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGxhYmVsOiBcIkN1cnJlbnQgTW9udGggUGF5bWVudHNcIixcclxuICAgICAgdmFsdWU6IHR5cGVvZiBwYXltZW50c1Blck1vbnRoVmFsdWUgPT09ICdzdHJpbmcnXHJcbiAgICAgICAgPyBwYXltZW50c1Blck1vbnRoVmFsdWVcclxuICAgICAgICA6IGDigrkkeyhwYXltZW50c1Blck1vbnRoVmFsdWUgPz8gMCk/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgICAgaWNvbjogPEZhV2FsbGV0IC8+LFxyXG4gICAgICBjb2xvcjogXCJiZy10ZWFsLTUwMFwiXHJcbiAgICB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IFNrZWxldG9uQ2FyZCA9ICgpID0+IChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBhbmltYXRlLXB1bHNlIGl0ZW1zLWNlbnRlciBnYXAtMyByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC83MCBiZy13aGl0ZS83MCBwLTQgc2hhZG93LXNtIHNoYWRvdy1zbGF0ZS05MDAvWzAuMDNdXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0xMSB3LTExIHJvdW5kZWQteGwgYmctc2xhdGUtMjAwLzgwXCI+PC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yIGgtMyB3LTIwIHJvdW5kZWQgYmctc2xhdGUtMjAwLzgwXCI+PC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTUgdy0xNiByb3VuZGVkIGJnLXNsYXRlLTIwMC84MFwiPjwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17ZW1iZWRkZWQgPyBcIlwiIDogXCJmbGV4IHB0LVs2OHB4XVwifT5cclxuICAgICAgeyFlbWJlZGRlZCAmJiA8U2lkZWJhciAvPn1cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtlbWJlZGRlZCA/IFwic3BhY2UteS02XCIgOiBcIm1pbi1oLXNjcmVlbiBmbGV4LWdyb3cgYmctc2xhdGUtNTAgcHgtNCBweS02IHRleHQtc2xhdGUtOTAwIHNtOnB4LTYgbGc6cHgtOFwifT5cclxuICAgICAgICB7IWVtYmVkZGVkICYmIChcclxuICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtc2xhdGUtOTUwXCI+QW5hbHl0aWNzIERhc2hib2FyZDwvaDE+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTUwMFwiPk92ZXJ2aWV3IG9mIGN1c3RvbWVycywgYWdlbnRzLCBncm91cHMsIGF1Y3Rpb25zIGFuZCBtb3JlPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02IGdyaWQgZ3JpZC1jb2xzLTEgZ2FwLTMgc206Z3JpZC1jb2xzLTIgeGw6Z3JpZC1jb2xzLTRcIj5cclxuICAgICAgICAgICAgICB7bG9hZGluZ1xyXG4gICAgICAgICAgICAgICAgPyBBcnJheSg4KS5maWxsKDApLm1hcCgoXywgaSkgPT4gPFNrZWxldG9uQ2FyZCBrZXk9e2l9IC8+KVxyXG4gICAgICAgICAgICAgICAgOiBrcGlzLm1hcCgoaywgaSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aX0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvNzAgYmctd2hpdGUvODAgcC00IHNoYWRvdy1zbSBzaGFkb3ctc2xhdGUtOTAwL1swLjAzXSBiYWNrZHJvcC1ibHVyLXhsIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwIGhvdmVyOi10cmFuc2xhdGUteS0wLjUgaG92ZXI6c2hhZG93LW1kIGhvdmVyOnNoYWRvdy1zbGF0ZS05MDAvMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YCR7ay5jb2xvcn0gZmxleCBoLTExIHctMTEgZmxleC1zaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCB0ZXh0LWxnIHRleHQtd2hpdGUgc2hhZG93LXNtIHNoYWRvdy1zbGF0ZS05MDAvMTBgfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtrLmljb259XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwid2hpdGVzcGFjZS1ub3JtYWwgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTUwMFwiPntrLmxhYmVsfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImJyZWFrLXdvcmRzIHRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPntrLnZhbHVlfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8Lz5cclxuICAgICAgICApfVxyXG4gICAgICAgIHsvKiBPcmlnaW5hbCBjaGFydHMg4oCUIFVOQ0hBTkdFRCAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgZ3JpZCBncmlkLWNvbHMtMSBnYXAtNSB4bDpncmlkLWNvbHMtMlwiPlxyXG4gICAgICAgICAgPENoYXJ0Q2FyZCB0aXRsZT1cIkN1c3RvbWVyLCBBZ2VudCAmIEVtcGxveWVlIEdyb3d0aFwiIHN1YnRpdGxlPVwiTGFzdCA3IG1vbnRoc1wiIGFjY2VudD1cIiMzYjgyZjZcIj5cclxuICAgICAgICAgICAgPFJlc3BvbnNpdmVDb250YWluZXIgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PXsyODB9PlxyXG4gICAgICAgICAgICAgIDxMaW5lQ2hhcnQgZGF0YT17Y3VzdG9tZXJHcm93dGh9PlxyXG4gICAgICAgICAgICAgICAgPENhcnRlc2lhbkdyaWQgc3Ryb2tlRGFzaGFycmF5PVwiMyAzXCIgc3Ryb2tlPVwiI2VlZVwiIC8+XHJcbiAgICAgICAgICAgICAgICA8WEF4aXMgZGF0YUtleT1cIm1vbnRoXCIgdGljaz17eyBmb250U2l6ZTogMTIgfX0gLz5cclxuICAgICAgICAgICAgICAgIDxZQXhpcyB0aWNrPXt7IGZvbnRTaXplOiAxMiB9fSAvPlxyXG4gICAgICAgICAgICAgICAgPFRvb2x0aXAgLz5cclxuICAgICAgICAgICAgICAgIDxMZWdlbmQgLz5cclxuICAgICAgICAgICAgICAgIDxMaW5lIHR5cGU9XCJtb25vdG9uZVwiIGRhdGFLZXk9XCJjdXN0b21lcnNcIiBzdHJva2U9XCIjM2I4MmY2XCIgc3Ryb2tlV2lkdGg9ezJ9IC8+XHJcbiAgICAgICAgICAgICAgICA8TGluZSB0eXBlPVwibW9ub3RvbmVcIiBkYXRhS2V5PVwiYWdlbnRzXCIgc3Ryb2tlPVwiIzIyYzU1ZVwiIHN0cm9rZVdpZHRoPXsyfSAvPlxyXG4gICAgICAgICAgICAgICAgPExpbmUgdHlwZT1cIm1vbm90b25lXCIgZGF0YUtleT1cImVtcGxveWVlc1wiIHN0cm9rZT1cIiNhODU1ZjdcIiBzdHJva2VXaWR0aD17Mn0gLz5cclxuICAgICAgICAgICAgICA8L0xpbmVDaGFydD5cclxuICAgICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxyXG4gICAgICAgICAgPC9DaGFydENhcmQ+XHJcblxyXG4gICAgICAgICAgPENoYXJ0Q2FyZCB0aXRsZT1cIkdyb3VwIFN0YXR1cyBCcmVha2Rvd25cIiBzdWJ0aXRsZT1cIkJ5IGN1cnJlbnQgc3RhZ2VcIiBhY2NlbnQ9XCIjZjU5ZTBiXCI+XHJcbiAgICAgICAgICAgIDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD17MjgwfT5cclxuICAgICAgICAgICAgICA8UGllQ2hhcnQ+XHJcbiAgICAgICAgICAgICAgICA8UGllXHJcbiAgICAgICAgICAgICAgICAgIGRhdGE9e2dyb3VwU3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICBkYXRhS2V5PVwidmFsdWVcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lS2V5PVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIGN4PVwiNTAlXCJcclxuICAgICAgICAgICAgICAgICAgY3k9XCI1MCVcIlxyXG4gICAgICAgICAgICAgICAgICBvdXRlclJhZGl1cz17OTB9XHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPXsoeyBuYW1lLCB2YWx1ZSB9KSA9PiBgJHtuYW1lfTogJHt2YWx1ZX1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7Z3JvdXBTdGF0dXMubWFwKChlbnRyeSwgaSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxDZWxsIGtleT17aX0gZmlsbD17ZW50cnkuY29sb3J9IC8+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9QaWU+XHJcbiAgICAgICAgICAgICAgICA8VG9vbHRpcCAvPlxyXG4gICAgICAgICAgICAgICAgPExlZ2VuZCAvPlxyXG4gICAgICAgICAgICAgIDwvUGllQ2hhcnQ+XHJcbiAgICAgICAgICAgIDwvUmVzcG9uc2l2ZUNvbnRhaW5lcj5cclxuICAgICAgICAgIDwvQ2hhcnRDYXJkPlxyXG5cclxuICAgICAgICAgIDxDaGFydENhcmQgdGl0bGU9XCJBdWN0aW9ucyAmIEJpZHNcIiBzdWJ0aXRsZT1cIk1vbnRobHkgdHJlbmRcIiBhY2NlbnQ9XCIjZWY0NDQ0XCI+XHJcbiAgICAgICAgICAgIDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD17MjgwfT5cclxuICAgICAgICAgICAgICA8QmFyQ2hhcnQgZGF0YT17YXVjdGlvbkJpZHN9PlxyXG4gICAgICAgICAgICAgICAgPENhcnRlc2lhbkdyaWQgc3Ryb2tlRGFzaGFycmF5PVwiMyAzXCIgc3Ryb2tlPVwiI2VlZVwiIC8+XHJcbiAgICAgICAgICAgICAgICA8WEF4aXMgZGF0YUtleT1cIm1vbnRoXCIgdGljaz17eyBmb250U2l6ZTogMTIgfX0gLz5cclxuICAgICAgICAgICAgICAgIDxZQXhpcyB0aWNrPXt7IGZvbnRTaXplOiAxMiB9fSAvPlxyXG4gICAgICAgICAgICAgICAgPFRvb2x0aXAgLz5cclxuICAgICAgICAgICAgICAgIDxMZWdlbmQgLz5cclxuICAgICAgICAgICAgICAgIDxCYXIgZGF0YUtleT1cImF1Y3Rpb25zXCIgZmlsbD1cIiNmNTllMGJcIiByYWRpdXM9e1s0LCA0LCAwLCAwXX0gLz5cclxuICAgICAgICAgICAgICAgIDxCYXIgZGF0YUtleT1cImJpZHNcIiBmaWxsPVwiIzNiODJmNlwiIHJhZGl1cz17WzQsIDQsIDAsIDBdfSAvPlxyXG4gICAgICAgICAgICAgIDwvQmFyQ2hhcnQ+XHJcbiAgICAgICAgICAgIDwvUmVzcG9uc2l2ZUNvbnRhaW5lcj5cclxuICAgICAgICAgIDwvQ2hhcnRDYXJkPlxyXG5cclxuICAgICAgICAgIDxDaGFydENhcmQgdGl0bGU9XCJWaXNpdG9yIEVucXVpcmllcyAmIENhbGxzXCIgc3VidGl0bGU9XCJUaGlzIHdlZWtcIiBhY2NlbnQ9XCIjMjJjNTVlXCI+XHJcbiAgICAgICAgICAgIDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD17MjgwfT5cclxuICAgICAgICAgICAgICA8QXJlYUNoYXJ0IGRhdGE9e3Zpc2l0b3JFbnF1aXJ5fT5cclxuICAgICAgICAgICAgICAgIDxDYXJ0ZXNpYW5HcmlkIHN0cm9rZURhc2hhcnJheT1cIjMgM1wiIHN0cm9rZT1cIiNlZWVcIiAvPlxyXG4gICAgICAgICAgICAgICAgPFhBeGlzIGRhdGFLZXk9XCJkYXlcIiB0aWNrPXt7IGZvbnRTaXplOiAxMiB9fSAvPlxyXG4gICAgICAgICAgICAgICAgPFlBeGlzIHRpY2s9e3sgZm9udFNpemU6IDEyIH19IC8+XHJcbiAgICAgICAgICAgICAgICA8VG9vbHRpcCAvPlxyXG4gICAgICAgICAgICAgICAgPExlZ2VuZCAvPlxyXG4gICAgICAgICAgICAgICAgPEFyZWEgdHlwZT1cIm1vbm90b25lXCIgZGF0YUtleT1cInZpc2l0b3JzXCIgc3RhY2tJZD1cIjFcIiBzdHJva2U9XCIjM2I4MmY2XCIgZmlsbD1cIiM5M2M1ZmRcIiAvPlxyXG4gICAgICAgICAgICAgICAgPEFyZWEgdHlwZT1cIm1vbm90b25lXCIgZGF0YUtleT1cImVucXVpcmllc1wiIHN0YWNrSWQ9XCIxXCIgc3Ryb2tlPVwiIzIyYzU1ZVwiIGZpbGw9XCIjODZlZmFjXCIgLz5cclxuICAgICAgICAgICAgICAgIDxBcmVhIHR5cGU9XCJtb25vdG9uZVwiIGRhdGFLZXk9XCJjYWxsc1wiIHN0YWNrSWQ9XCIxXCIgc3Ryb2tlPVwiI2Y5NzMxNlwiIGZpbGw9XCIjZmRiYTc0XCIgLz5cclxuICAgICAgICAgICAgICA8L0FyZWFDaGFydD5cclxuICAgICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxyXG4gICAgICAgICAgPC9DaGFydENhcmQ+XHJcblxyXG4gICAgICAgICAgPENoYXJ0Q2FyZCB0aXRsZT1cIkxlYWQgRnVubmVsXCIgc3VidGl0bGU9XCJGcm9tIG5ldyBsZWFkIHRvIGNvbnZlcnNpb25cIiBhY2NlbnQ9XCIjNjM2NmYxXCI+XHJcbiAgICAgICAgICAgIDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD17MjYwfT5cclxuICAgICAgICAgICAgICA8QmFyQ2hhcnQgZGF0YT17bGVhZEZ1bm5lbH0gbGF5b3V0PVwidmVydGljYWxcIiBtYXJnaW49e3sgbGVmdDogMjAgfX0+XHJcbiAgICAgICAgICAgICAgICA8Q2FydGVzaWFuR3JpZCBzdHJva2VEYXNoYXJyYXk9XCIzIDNcIiBzdHJva2U9XCIjZWVlXCIgLz5cclxuICAgICAgICAgICAgICAgIDxYQXhpcyB0eXBlPVwibnVtYmVyXCIgdGljaz17eyBmb250U2l6ZTogMTIgfX0gLz5cclxuICAgICAgICAgICAgICAgIDxZQXhpcyBkYXRhS2V5PVwic3RhZ2VcIiB0eXBlPVwiY2F0ZWdvcnlcIiB0aWNrPXt7IGZvbnRTaXplOiAxMiB9fSB3aWR0aD17OTB9IC8+XHJcbiAgICAgICAgICAgICAgICA8VG9vbHRpcCAvPlxyXG4gICAgICAgICAgICAgICAgPEJhciBkYXRhS2V5PVwidmFsdWVcIiBmaWxsPVwiIzYzNjZmMVwiIHJhZGl1cz17WzAsIDQsIDQsIDBdfSAvPlxyXG4gICAgICAgICAgICAgIDwvQmFyQ2hhcnQ+XHJcbiAgICAgICAgICAgIDwvUmVzcG9uc2l2ZUNvbnRhaW5lcj5cclxuICAgICAgICAgIDwvQ2hhcnRDYXJkPlxyXG5cclxuICAgICAgICAgIDxDaGFydENhcmQgdGl0bGU9XCJUYXNrIFN0YXR1c1wiIHN1YnRpdGxlPVwiQ3VycmVudCB0YXNrIGRpc3RyaWJ1dGlvblwiIGFjY2VudD1cIiNmNTllMGJcIj5cclxuICAgICAgICAgICAgPFJlc3BvbnNpdmVDb250YWluZXIgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PXsyNjB9PlxyXG4gICAgICAgICAgICAgIDxQaWVDaGFydD5cclxuICAgICAgICAgICAgICAgIDxQaWVcclxuICAgICAgICAgICAgICAgICAgZGF0YT17dGFza1N0YXR1c31cclxuICAgICAgICAgICAgICAgICAgZGF0YUtleT1cInZhbHVlXCJcclxuICAgICAgICAgICAgICAgICAgbmFtZUtleT1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICBjeD1cIjUwJVwiXHJcbiAgICAgICAgICAgICAgICAgIGN5PVwiNTAlXCJcclxuICAgICAgICAgICAgICAgICAgaW5uZXJSYWRpdXM9ezU1fVxyXG4gICAgICAgICAgICAgICAgICBvdXRlclJhZGl1cz17OTB9XHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPXsoeyBuYW1lLCB2YWx1ZSB9KSA9PiBgJHtuYW1lfTogJHt2YWx1ZX1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7dGFza1N0YXR1cy5tYXAoKGVudHJ5LCBpKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPENlbGwga2V5PXtpfSBmaWxsPXtlbnRyeS5jb2xvcn0gLz5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1BpZT5cclxuICAgICAgICAgICAgICAgIDxUb29sdGlwIC8+XHJcbiAgICAgICAgICAgICAgICA8TGVnZW5kIC8+XHJcbiAgICAgICAgICAgICAgPC9QaWVDaGFydD5cclxuICAgICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxyXG4gICAgICAgICAgPC9DaGFydENhcmQ+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiBncmlkIGdyaWQtY29scy0xIGdhcC01IHhsOmdyaWQtY29scy0yXCI+XHJcbiAgICAgICAgICA8Q2hhcnRDYXJkIHRpdGxlPVwiRW5yb2xsbWVudHNcIiBzdWJ0aXRsZT1cIk5ldyBlbnJvbGxtZW50cyBwZXIgbW9udGhcIiBhY2NlbnQ9XCIjMTRiOGE2XCI+XHJcbiAgICAgICAgICAgIDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD17MjYwfT5cclxuICAgICAgICAgICAgICA8QXJlYUNoYXJ0IGRhdGE9e2Vucm9sbG1lbnRUcmVuZH0+XHJcbiAgICAgICAgICAgICAgICA8Q2FydGVzaWFuR3JpZCBzdHJva2VEYXNoYXJyYXk9XCIzIDNcIiBzdHJva2U9XCIjZWVlXCIgLz5cclxuICAgICAgICAgICAgICAgIDxYQXhpcyBkYXRhS2V5PVwibW9udGhcIiB0aWNrPXt7IGZvbnRTaXplOiAxMiB9fSAvPlxyXG4gICAgICAgICAgICAgICAgPFlBeGlzIHRpY2s9e3sgZm9udFNpemU6IDEyIH19IC8+XHJcbiAgICAgICAgICAgICAgICA8VG9vbHRpcCAvPlxyXG4gICAgICAgICAgICAgICAgPEFyZWEgdHlwZT1cIm1vbm90b25lXCIgZGF0YUtleT1cImVucm9sbG1lbnRzXCIgc3Ryb2tlPVwiIzE0YjhhNlwiIGZpbGw9XCIjNWVlYWQ0XCIgLz5cclxuICAgICAgICAgICAgICA8L0FyZWFDaGFydD5cclxuICAgICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxyXG4gICAgICAgICAgPC9DaGFydENhcmQ+XHJcblxyXG4gICAgICAgICAgPENoYXJ0Q2FyZCB0aXRsZT1cIkFjY291bnRzOiBDb2xsZWN0aW9ucyB2cyBEaXNidXJzZW1lbnRzXCIgc3VidGl0bGU9XCJNb250aGx5ICjigrkpXCIgYWNjZW50PVwiIzIyYzU1ZVwiPlxyXG4gICAgICAgICAgICA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9ezI2MH0+XHJcbiAgICAgICAgICAgICAgPEJhckNoYXJ0IGRhdGE9e2FjY291bnRzU3VtbWFyeX0+XHJcbiAgICAgICAgICAgICAgICA8Q2FydGVzaWFuR3JpZCBzdHJva2VEYXNoYXJyYXk9XCIzIDNcIiBzdHJva2U9XCIjZWVlXCIgLz5cclxuICAgICAgICAgICAgICAgIDxYQXhpcyBkYXRhS2V5PVwibW9udGhcIiB0aWNrPXt7IGZvbnRTaXplOiAxMiB9fSAvPlxyXG4gICAgICAgICAgICAgICAgPFlBeGlzIHRpY2s9e3sgZm9udFNpemU6IDEyIH19IHRpY2tGb3JtYXR0ZXI9eyh2KSA9PiBgJHt2IC8gMTAwMH1rYH0gLz5cclxuICAgICAgICAgICAgICAgIDxUb29sdGlwIGZvcm1hdHRlcj17KHYpID0+IGDigrkke3YudG9Mb2NhbGVTdHJpbmcoKX1gfSAvPlxyXG4gICAgICAgICAgICAgICAgPExlZ2VuZCAvPlxyXG4gICAgICAgICAgICAgICAgPEJhciBkYXRhS2V5PVwiY29sbGVjdGlvbnNcIiBmaWxsPVwiIzIyYzU1ZVwiIHJhZGl1cz17WzQsIDQsIDAsIDBdfSAvPlxyXG4gICAgICAgICAgICAgICAgPEJhciBkYXRhS2V5PVwiZGlzYnVyc2VtZW50c1wiIGZpbGw9XCIjZWY0NDQ0XCIgcmFkaXVzPXtbNCwgNCwgMCwgMF19IC8+XHJcbiAgICAgICAgICAgICAgPC9CYXJDaGFydD5cclxuICAgICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxyXG4gICAgICAgICAgPC9DaGFydENhcmQ+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PSBHcm91cCBJbnNpZ2h0cyAoUkVBTCBEQVRBKSA9PT09PT09PT09PT09PT09PSAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTNcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDBcIj5cclxuICAgICAgICAgICAgR3JvdXAgSW5zaWdodHMgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW5vcm1hbCB0ZXh0LXNsYXRlLTUwMFwiPih7cmF3R3JvdXBEYXRhLmxlbmd0aH0gZ3JvdXBzKTwvc3Bhbj5cclxuICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02IGdyaWQgZ3JpZC1jb2xzLTEgZ2FwLTUgeGw6Z3JpZC1jb2xzLTNcIj5cclxuICAgICAgICAgIDxDaGFydENhcmRcclxuICAgICAgICAgICAgdGl0bGU9XCJTZWF0IEZpbGwgU3RhdHVzIFBlciBHcm91cFwiXHJcbiAgICAgICAgICAgIHN1YnRpdGxlPXtgRmlsbGVkIHZzIHZhY2FudCBzZWF0cyAoJHtyYXdHcm91cERhdGEubGVuZ3RofSBncm91cHMpYH1cclxuICAgICAgICAgICAgYWNjZW50PVwiIzNiODJmNlwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTJcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9ezcyMH0+XHJcbiAgICAgICAgICAgICAgPEJhckNoYXJ0IGRhdGE9e2dyb3VwU2VhdEZpbGxDaGFydERhdGF9IGxheW91dD1cInZlcnRpY2FsXCIgbWFyZ2luPXt7IGxlZnQ6IDEwLCByaWdodDogMTAgfX0+XHJcbiAgICAgICAgICAgICAgICA8Q2FydGVzaWFuR3JpZCBzdHJva2VEYXNoYXJyYXk9XCIzIDNcIiBzdHJva2U9XCIjZWVlXCIgLz5cclxuICAgICAgICAgICAgICAgIDxYQXhpcyB0eXBlPVwibnVtYmVyXCIgdGljaz17eyBmb250U2l6ZTogMTEgfX0gLz5cclxuICAgICAgICAgICAgICAgIDxZQXhpcyBkYXRhS2V5PVwibmFtZVwiIHR5cGU9XCJjYXRlZ29yeVwiIHRpY2s9e3sgZm9udFNpemU6IDEwIH19IHdpZHRoPXsxMTB9IC8+XHJcbiAgICAgICAgICAgICAgICA8VG9vbHRpcCAvPlxyXG4gICAgICAgICAgICAgICAgPExlZ2VuZCAvPlxyXG4gICAgICAgICAgICAgICAgPEJhciBkYXRhS2V5PVwiZmlsbGVkXCIgc3RhY2tJZD1cImFcIiBmaWxsPVwiIzNiODJmNlwiIG5hbWU9XCJGaWxsZWRcIiAvPlxyXG4gICAgICAgICAgICAgICAgPEJhciBkYXRhS2V5PVwidmFjYW50XCIgc3RhY2tJZD1cImFcIiBmaWxsPVwiI2ZiYmYyNFwiIG5hbWU9XCJWYWNhbnRcIiByYWRpdXM9e1swLCA0LCA0LCAwXX0gLz5cclxuICAgICAgICAgICAgICA8L0JhckNoYXJ0PlxyXG4gICAgICAgICAgICA8L1Jlc3BvbnNpdmVDb250YWluZXI+XHJcbiAgICAgICAgICA8L0NoYXJ0Q2FyZD5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTVcIj5cclxuICAgICAgICAgICAgPENoYXJ0Q2FyZCB0aXRsZT1cIkdyb3VwIFR5cGUgRGlzdHJpYnV0aW9uXCIgc3VidGl0bGU9XCJDb3VudCBvZiBncm91cHMgYnkgdHlwZVwiIGFjY2VudD1cIiNmNTllMGJcIj5cclxuICAgICAgICAgICAgICA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9ezI0MH0+XHJcbiAgICAgICAgICAgICAgICA8UGllQ2hhcnQ+XHJcbiAgICAgICAgICAgICAgICAgIDxQaWVcclxuICAgICAgICAgICAgICAgICAgICBkYXRhPXtncm91cENhdGVnb3J5fVxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGFLZXk9XCJ2YWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZUtleT1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGN4PVwiNTAlXCJcclxuICAgICAgICAgICAgICAgICAgICBjeT1cIjUwJVwiXHJcbiAgICAgICAgICAgICAgICAgICAgb3V0ZXJSYWRpdXM9ezg1fVxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsPXsoeyB2YWx1ZSB9KSA9PiB2YWx1ZX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtncm91cENhdGVnb3J5Lm1hcCgoZW50cnksIGkpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxDZWxsIGtleT17aX0gZmlsbD17ZW50cnkuY29sb3J9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvUGllPlxyXG4gICAgICAgICAgICAgICAgICA8VG9vbHRpcCAvPlxyXG4gICAgICAgICAgICAgICAgICA8TGVnZW5kIHdyYXBwZXJTdHlsZT17eyBmb250U2l6ZTogMTEgfX0gLz5cclxuICAgICAgICAgICAgICAgIDwvUGllQ2hhcnQ+XHJcbiAgICAgICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxyXG4gICAgICAgICAgICA8L0NoYXJ0Q2FyZD5cclxuXHJcbiAgICAgICAgICAgIDxDaGFydENhcmQgdGl0bGU9XCJUb3RhbCBDaGl0IFZhbHVlIGJ5IFR5cGVcIiBzdWJ0aXRsZT1cIlN1bSBvZiBncm91cCB2YWx1ZXMgKOKCuSlcIiBhY2NlbnQ9XCIjMjJjNTVlXCI+XHJcbiAgICAgICAgICAgICAgPFJlc3BvbnNpdmVDb250YWluZXIgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PXsyMjB9PlxyXG4gICAgICAgICAgICAgICAgPEJhckNoYXJ0IGRhdGE9e2dyb3VwVmFsdWVCeVR5cGV9PlxyXG4gICAgICAgICAgICAgICAgICA8Q2FydGVzaWFuR3JpZCBzdHJva2VEYXNoYXJyYXk9XCIzIDNcIiBzdHJva2U9XCIjZWVlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPFhBeGlzIGRhdGFLZXk9XCJ0eXBlXCIgdGljaz17eyBmb250U2l6ZTogOSB9fSBpbnRlcnZhbD17MH0gYW5nbGU9ey0xNX0gdGV4dEFuY2hvcj1cImVuZFwiIGhlaWdodD17NTB9IC8+XHJcbiAgICAgICAgICAgICAgICAgIDxZQXhpcyB0aWNrPXt7IGZvbnRTaXplOiAxMCB9fSB0aWNrRm9ybWF0dGVyPXsodikgPT4gYCR7diAvIDEwMDAwMH1MYH0gLz5cclxuICAgICAgICAgICAgICAgICAgPFRvb2x0aXAgZm9ybWF0dGVyPXsodikgPT4gYOKCuSR7di50b0xvY2FsZVN0cmluZygpfWB9IC8+XHJcbiAgICAgICAgICAgICAgICAgIDxCYXIgZGF0YUtleT1cInRvdGFsVmFsdWVcIiBmaWxsPVwiIzIyYzU1ZVwiIHJhZGl1cz17WzQsIDQsIDAsIDBdfSAvPlxyXG4gICAgICAgICAgICAgICAgPC9CYXJDaGFydD5cclxuICAgICAgICAgICAgICA8L1Jlc3BvbnNpdmVDb250YWluZXI+XHJcbiAgICAgICAgICAgIDwvQ2hhcnRDYXJkPlxyXG5cclxuICAgICAgICAgICAgPENoYXJ0Q2FyZCB0aXRsZT1cIlN0YWZmIFNwbGl0XCIgc3VidGl0bGU9XCJDb2xsZWN0aW9uIGFnZW50cyB2cyBvZmZpY2UgZW1wbG95ZWVzXCIgYWNjZW50PVwiI2E4NTVmN1wiPlxyXG4gICAgICAgICAgICAgIDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD17MjAwfT5cclxuICAgICAgICAgICAgICAgIDxQaWVDaGFydD5cclxuICAgICAgICAgICAgICAgICAgPFBpZVxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGE9e3N0YWZmVHlwZVNwbGl0fVxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGFLZXk9XCJ2YWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZUtleT1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGN4PVwiNTAlXCJcclxuICAgICAgICAgICAgICAgICAgICBjeT1cIjUwJVwiXHJcbiAgICAgICAgICAgICAgICAgICAgaW5uZXJSYWRpdXM9ezQ1fVxyXG4gICAgICAgICAgICAgICAgICAgIG91dGVyUmFkaXVzPXs3NX1cclxuICAgICAgICAgICAgICAgICAgICBsYWJlbD17KHsgdmFsdWUgfSkgPT4gdmFsdWV9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7c3RhZmZUeXBlU3BsaXQubWFwKChlbnRyeSwgaSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPENlbGwga2V5PXtpfSBmaWxsPXtlbnRyeS5jb2xvcn0gLz5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9QaWU+XHJcbiAgICAgICAgICAgICAgICAgIDxUb29sdGlwIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxMZWdlbmQgLz5cclxuICAgICAgICAgICAgICAgIDwvUGllQ2hhcnQ+XHJcbiAgICAgICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxyXG4gICAgICAgICAgICA8L0NoYXJ0Q2FyZD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogPT09PT09PT09PT09PT09PT0gQ3VzdG9tZXIgU3RhdHVzID09PT09PT09PT09PT09PT09ICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItM1wiPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPkN1c3RvbWVyIFN0YXR1czwvaDI+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02IGdyaWQgZ3JpZC1jb2xzLTEgZ2FwLTUgeGw6Z3JpZC1jb2xzLTJcIj5cclxuICAgICAgICAgIDxDaGFydENhcmQgdGl0bGU9XCJDdXN0b21lciBTdGF0dXMgQnJlYWtkb3duXCIgc3VidGl0bGU9XCJBY3RpdmUsIGhvbGQsIHN1c3BlbmQsIHVudmVyaWZpZWRcIiBhY2NlbnQ9XCIjMjJjNTVlXCI+XHJcbiAgICAgICAgICAgIDxSZXNwb25zaXZlQ29udGFpbmVyIHdpZHRoPVwiMTAwJVwiIGhlaWdodD17MjgwfT5cclxuICAgICAgICAgICAgICA8UGllQ2hhcnQ+XHJcbiAgICAgICAgICAgICAgICA8UGllXHJcbiAgICAgICAgICAgICAgICAgIGRhdGE9e2N1c3RvbWVyU3RhdHVzU3BsaXR9XHJcbiAgICAgICAgICAgICAgICAgIGRhdGFLZXk9XCJ2YWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWVLZXk9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgY3g9XCI1MCVcIlxyXG4gICAgICAgICAgICAgICAgICBjeT1cIjUwJVwiXHJcbiAgICAgICAgICAgICAgICAgIG91dGVyUmFkaXVzPXs5NX1cclxuICAgICAgICAgICAgICAgICAgbGFiZWw9eyh7IG5hbWUsIHZhbHVlIH0pID0+IGAke25hbWV9OiAke3ZhbHVlfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtjdXN0b21lclN0YXR1c1NwbGl0Lm1hcCgoZW50cnksIGkpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8Q2VsbCBrZXk9e2l9IGZpbGw9e2VudHJ5LmNvbG9yfSAvPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvUGllPlxyXG4gICAgICAgICAgICAgICAgPFRvb2x0aXAgLz5cclxuICAgICAgICAgICAgICAgIDxMZWdlbmQgLz5cclxuICAgICAgICAgICAgICA8L1BpZUNoYXJ0PlxyXG4gICAgICAgICAgICA8L1Jlc3BvbnNpdmVDb250YWluZXI+XHJcbiAgICAgICAgICA8L0NoYXJ0Q2FyZD5cclxuXHJcbiAgICAgICAgICA8Q2hhcnRDYXJkIHRpdGxlPVwiQ3VzdG9tZXIgU3RhdHVzIChDb3VudClcIiBzdWJ0aXRsZT1cIlNhbWUgZGF0YSBhcyBiYXIgdmlld1wiIGFjY2VudD1cIiMzYjgyZjZcIj5cclxuICAgICAgICAgICAgPFJlc3BvbnNpdmVDb250YWluZXIgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PXsyODB9PlxyXG4gICAgICAgICAgICAgIDxCYXJDaGFydCBkYXRhPXtjdXN0b21lclN0YXR1c1NwbGl0fT5cclxuICAgICAgICAgICAgICAgIDxDYXJ0ZXNpYW5HcmlkIHN0cm9rZURhc2hhcnJheT1cIjMgM1wiIHN0cm9rZT1cIiNlZWVcIiAvPlxyXG4gICAgICAgICAgICAgICAgPFhBeGlzIGRhdGFLZXk9XCJuYW1lXCIgdGljaz17eyBmb250U2l6ZTogMTIgfX0gLz5cclxuICAgICAgICAgICAgICAgIDxZQXhpcyB0aWNrPXt7IGZvbnRTaXplOiAxMiB9fSAvPlxyXG4gICAgICAgICAgICAgICAgPFRvb2x0aXAgLz5cclxuICAgICAgICAgICAgICAgIDxCYXIgZGF0YUtleT1cInZhbHVlXCIgcmFkaXVzPXtbNCwgNCwgMCwgMF19PlxyXG4gICAgICAgICAgICAgICAgICB7Y3VzdG9tZXJTdGF0dXNTcGxpdC5tYXAoKGVudHJ5LCBpKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPENlbGwga2V5PXtpfSBmaWxsPXtlbnRyeS5jb2xvcn0gLz5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L0Jhcj5cclxuICAgICAgICAgICAgICA8L0JhckNoYXJ0PlxyXG4gICAgICAgICAgICA8L1Jlc3BvbnNpdmVDb250YWluZXI+XHJcbiAgICAgICAgICA8L0NoYXJ0Q2FyZD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qID09PT09PT09PT09PT09PT09IFBheW1lbnQgSW4gLyBQYXltZW50IE91dCA9PT09PT09PT09PT09PT09PSAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTNcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDBcIj5QYXltZW50IEluIC8gUGF5bWVudCBPdXQ8L2gyPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiBncmlkIGdyaWQtY29scy0xIGdhcC01IHhsOmdyaWQtY29scy0yXCI+XHJcbiAgICAgICAgICA8Q2hhcnRDYXJkIHRpdGxlPVwiUGF5bWVudCBJblwiIHN1YnRpdGxlPVwiUmVnaXN0cmF0aW9uLCByZWNlaXB0cywgbGlua3MsIHRyYW5zZmVyLCBhZHZhbmNlXCIgYWNjZW50PVwiIzIyYzU1ZVwiPlxyXG4gICAgICAgICAgICA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9ezMwMH0+XHJcbiAgICAgICAgICAgICAgPEJhckNoYXJ0IGRhdGE9e3BheW1lbnRJbkJyZWFrZG93bn0gbGF5b3V0PVwidmVydGljYWxcIiBtYXJnaW49e3sgbGVmdDogMzAgfX0+XHJcbiAgICAgICAgICAgICAgICA8Q2FydGVzaWFuR3JpZCBzdHJva2VEYXNoYXJyYXk9XCIzIDNcIiBzdHJva2U9XCIjZWVlXCIgLz5cclxuICAgICAgICAgICAgICAgIDxYQXhpcyB0eXBlPVwibnVtYmVyXCIgdGljaz17eyBmb250U2l6ZTogMTEgfX0gdGlja0Zvcm1hdHRlcj17KHYpID0+IGAke3YgLyAxMDAwfWtgfSAvPlxyXG4gICAgICAgICAgICAgICAgPFlBeGlzIGRhdGFLZXk9XCJ0eXBlXCIgdHlwZT1cImNhdGVnb3J5XCIgdGljaz17eyBmb250U2l6ZTogMTEgfX0gd2lkdGg9ezEzMH0gLz5cclxuICAgICAgICAgICAgICAgIDxUb29sdGlwIGZvcm1hdHRlcj17KHYpID0+IGDigrkke3YudG9Mb2NhbGVTdHJpbmcoKX1gfSAvPlxyXG4gICAgICAgICAgICAgICAgPEJhciBkYXRhS2V5PVwiYW1vdW50XCIgZmlsbD1cIiMyMmM1NWVcIiByYWRpdXM9e1swLCA0LCA0LCAwXX0gLz5cclxuICAgICAgICAgICAgICA8L0JhckNoYXJ0PlxyXG4gICAgICAgICAgICA8L1Jlc3BvbnNpdmVDb250YWluZXI+XHJcbiAgICAgICAgICA8L0NoYXJ0Q2FyZD5cclxuXHJcbiAgICAgICAgICA8Q2hhcnRDYXJkIHRpdGxlPVwiUGF5bWVudCBPdXRcIiBzdWJ0aXRsZT1cIlBheW91dHMsIGNhbmNlbGxhdGlvbnMsIHNhbGFyeSwgaW5jZW50aXZlXCIgYWNjZW50PVwiI2VmNDQ0NFwiPlxyXG4gICAgICAgICAgICA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9ezMwMH0+XHJcbiAgICAgICAgICAgICAgPEJhckNoYXJ0IGRhdGE9e3BheW1lbnRPdXRCcmVha2Rvd259IGxheW91dD1cInZlcnRpY2FsXCIgbWFyZ2luPXt7IGxlZnQ6IDMwIH19PlxyXG4gICAgICAgICAgICAgICAgPENhcnRlc2lhbkdyaWQgc3Ryb2tlRGFzaGFycmF5PVwiMyAzXCIgc3Ryb2tlPVwiI2VlZVwiIC8+XHJcbiAgICAgICAgICAgICAgICA8WEF4aXMgdHlwZT1cIm51bWJlclwiIHRpY2s9e3sgZm9udFNpemU6IDExIH19IHRpY2tGb3JtYXR0ZXI9eyh2KSA9PiBgJHt2IC8gMTAwMH1rYH0gLz5cclxuICAgICAgICAgICAgICAgIDxZQXhpcyBkYXRhS2V5PVwidHlwZVwiIHR5cGU9XCJjYXRlZ29yeVwiIHRpY2s9e3sgZm9udFNpemU6IDExIH19IHdpZHRoPXsxMzB9IC8+XHJcbiAgICAgICAgICAgICAgICA8VG9vbHRpcCBmb3JtYXR0ZXI9eyh2KSA9PiBg4oK5JHt2LnRvTG9jYWxlU3RyaW5nKCl9YH0gLz5cclxuICAgICAgICAgICAgICAgIDxCYXIgZGF0YUtleT1cImFtb3VudFwiIGZpbGw9XCIjZWY0NDQ0XCIgcmFkaXVzPXtbMCwgNCwgNCwgMF19IC8+XHJcbiAgICAgICAgICAgICAgPC9CYXJDaGFydD5cclxuICAgICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxyXG4gICAgICAgICAgPC9DaGFydENhcmQ+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PSBNYXJrZXRpbmcgPT09PT09PT09PT09PT09PT0gKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zXCI+XHJcbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwXCI+TWFya2V0aW5nPC9oMj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbGc6Z3JpZC1jb2xzLTIgZ2FwLTZcIj5cclxuICAgICAgICAgIDxDaGFydENhcmQgdGl0bGU9XCJNYXJrZXRpbmcgQ2hhbm5lbCBTcGxpdFwiIHN1YnRpdGxlPVwiV2hhdHNBcHAsIEVtYWlsLCBTTVMsIFJDU1wiIGFjY2VudD1cIiMyMmM1NWVcIj5cclxuICAgICAgICAgICAgPFJlc3BvbnNpdmVDb250YWluZXIgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PXsyODB9PlxyXG4gICAgICAgICAgICAgIDxQaWVDaGFydD5cclxuICAgICAgICAgICAgICAgIDxQaWVcclxuICAgICAgICAgICAgICAgICAgZGF0YT17bWFya2V0aW5nQ2hhbm5lbHN9XHJcbiAgICAgICAgICAgICAgICAgIGRhdGFLZXk9XCJ2YWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWVLZXk9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgY3g9XCI1MCVcIlxyXG4gICAgICAgICAgICAgICAgICBjeT1cIjUwJVwiXHJcbiAgICAgICAgICAgICAgICAgIG91dGVyUmFkaXVzPXs5NX1cclxuICAgICAgICAgICAgICAgICAgbGFiZWw9eyh7IG5hbWUsIHZhbHVlIH0pID0+IGAke25hbWV9OiAke3ZhbHVlfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHttYXJrZXRpbmdDaGFubmVscy5tYXAoKGVudHJ5LCBpKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPENlbGwga2V5PXtpfSBmaWxsPXtlbnRyeS5jb2xvcn0gLz5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1BpZT5cclxuICAgICAgICAgICAgICAgIDxUb29sdGlwIC8+XHJcbiAgICAgICAgICAgICAgICA8TGVnZW5kIC8+XHJcbiAgICAgICAgICAgICAgPC9QaWVDaGFydD5cclxuICAgICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxyXG4gICAgICAgICAgPC9DaGFydENhcmQ+XHJcblxyXG4gICAgICAgICAgPENoYXJ0Q2FyZCB0aXRsZT1cIk1hcmtldGluZyBNZXNzYWdlcyBTZW50XCIgc3VidGl0bGU9XCJCeSBjaGFubmVsXCIgYWNjZW50PVwiI2Y1OWUwYlwiPlxyXG4gICAgICAgICAgICA8UmVzcG9uc2l2ZUNvbnRhaW5lciB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9ezI4MH0+XHJcbiAgICAgICAgICAgICAgPEJhckNoYXJ0IGRhdGE9e21hcmtldGluZ0NoYW5uZWxzfT5cclxuICAgICAgICAgICAgICAgIDxDYXJ0ZXNpYW5HcmlkIHN0cm9rZURhc2hhcnJheT1cIjMgM1wiIHN0cm9rZT1cIiNlZWVcIiAvPlxyXG4gICAgICAgICAgICAgICAgPFhBeGlzIGRhdGFLZXk9XCJuYW1lXCIgdGljaz17eyBmb250U2l6ZTogMTIgfX0gLz5cclxuICAgICAgICAgICAgICAgIDxZQXhpcyB0aWNrPXt7IGZvbnRTaXplOiAxMiB9fSAvPlxyXG4gICAgICAgICAgICAgICAgPFRvb2x0aXAgLz5cclxuICAgICAgICAgICAgICAgIDxCYXIgZGF0YUtleT1cInZhbHVlXCIgcmFkaXVzPXtbNCwgNCwgMCwgMF19PlxyXG4gICAgICAgICAgICAgICAgICB7bWFya2V0aW5nQ2hhbm5lbHMubWFwKChlbnRyeSwgaSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxDZWxsIGtleT17aX0gZmlsbD17ZW50cnkuY29sb3J9IC8+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9CYXI+XHJcbiAgICAgICAgICAgICAgPC9CYXJDaGFydD5cclxuICAgICAgICAgICAgPC9SZXNwb25zaXZlQ29udGFpbmVyPlxyXG4gICAgICAgICAgPC9DaGFydENhcmQ+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuZnVuY3Rpb24gQW5hbHl0aWNzKCkge1xyXG4gIHJldHVybiA8RGFzaGJvYXJkQW5hbHl0aWNzQ29udGVudCAvPjtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQW5hbHl0aWNzO1xyXG5cclxuXHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9BbmFseXRpY3MuanN4In0=