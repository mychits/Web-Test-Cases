import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/DueEmail.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { notification } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { MdMarkEmailRead } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const DueEmail = () => {
  _s();
  const [searchText, setSearchText] = useState("");
  const [usersData, setUsersData] = useState([]);
  const [groupFilter, setGroupFilter] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [activeUserData, setActiveUserData] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [totalUsers, setTotalUsers] = useState(0);
  const [notifier, contextHolder] = notification.useNotification();
  const groupOptions = [...new Set(usersData.map((u) => u.groupName))];
  const filteredUsers = useMemo(() => {
    const filtered = filterOption(
      usersData.filter((u) => {
        const matchGroup = groupFilter ? u.groupName === groupFilter : true;
        const enrollmentDate = new Date(u.enrollmentDate);
        const matchFromDate = fromDate ? enrollmentDate >= new Date(fromDate) : true;
        const matchToDate = toDate ? enrollmentDate <= new Date(toDate) : true;
        return matchGroup && matchFromDate && matchToDate;
      }),
      searchText
    );
    return filtered.map((user, index) => {
      const isSelected = !!activeUserData[user._id]?.info?.status;
      return {
        ...user,
        sl_no: index + 1,
        checkBoxs: /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "checkbox",
            checked: isSelected,
            onChange: (e) => {
              setActiveUserData((prev) => ({
                ...prev,
                [user._id]: {
                  info: {
                    status: e.target.checked,
                    balance: user.balance,
                    userPhone: user.userPhone,
                    paymentsTicket: user.paymentsTicket,
                    groupName: user.groupName,
                    userName: user.userName,
                    groupId: user.groupId,
                    userId: user.userId,
                    amountPaid: user.amountPaid,
                    amountToBePaid: user.totalToBePaid,
                    userEmail: user.userEmail
                  }
                }
              }));
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
            lineNumber: 48,
            columnNumber: 9
          },
          this
        ),
        isSelected
      };
    });
  }, [usersData, groupFilter, fromDate, toDate, searchText, activeUserData]);
  const visibleSelectedCount = useMemo(() => {
    return filteredUsers.filter((user) => user.isSelected).length;
  }, [filteredUsers]);
  const sendEmail = async () => {
    const key = "updatable";
    try {
      notifier.open({
        key,
        message: "Sending Emails..",
        description: "Processing...",
        className: "bg-violet-300 rounded-lg font-bold",
        duration: 2
      });
      const selectedUsers = {};
      filteredUsers.forEach((user) => {
        if (user.isSelected && activeUserData[user._id]) {
          selectedUsers[user._id] = activeUserData[user._id];
        }
      });
      await api.post("/email/due-email", selectedUsers);
      const updatedActiveUserData = { ...activeUserData };
      filteredUsers.forEach((user) => {
        if (user.isSelected) {
          delete updatedActiveUserData[user._id];
        }
      });
      setActiveUserData(updatedActiveUserData);
      notifier.open({
        key,
        message: "Emails Sent Successfully",
        description: "Success",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
    } catch (err) {
      notifier.open({
        key,
        message: "Failed to Send Emails",
        description: err.message || "Something went wrong",
        className: "bg-red-300 rounded-lg font-bold",
        duration: 2
      });
    }
  };
  const fetchData = async () => {
    try {
      setIsLoading(true);
      const reportResponse = await api.get("/user/get-due-email-payments");
      const usersList = [];
      const tempActive = {};
      reportResponse.data.forEach((usrData) => {
        if (usrData?.data) {
          usrData.data.forEach((data) => {
            if (data?.enrollment?.group) {
              const groupInstall = parseInt(
                data.enrollment.group.group_install
              );
              const groupId = data.enrollment.group._id;
              const groupType = data.enrollment.group.group_type;
              const totalPaidAmount = data.payments.totalPaidAmount;
              const auctionCount = parseInt(data?.auction?.auctionCount);
              const totalPayable = data.payable.totalPayable;
              const totalProfit = data.profit.totalProfit;
              const firstDividentHead = data.firstAuction.firstDividentHead;
              const id = data?.enrollment?._id;
              const userPhone = usrData.phone_number;
              const userEmail = usrData.email;
              const paymentsTicket = data.payments.ticket;
              const groupName = data.enrollment.group.group_name;
              const totalToBePaid = groupType === "double" ? groupInstall * auctionCount + groupInstall : totalPayable + groupInstall + totalProfit;
              const amountToBePaid = groupType === "double" ? groupInstall * auctionCount + groupInstall : totalPayable + groupInstall + totalProfit;
              const balance = groupType === "double" ? groupInstall * auctionCount + groupInstall - totalPaidAmount : totalPayable + groupInstall + firstDividentHead - totalPaidAmount;
              if (balance <= 0) return;
              const userName = usrData.userName;
              tempActive[id] = {
                info: {
                  status: false,
                  balance
                }
              };
              const tempUsr = {
                _id: id,
                userName,
                userPhone,
                customerId: usrData.customer_id,
                amountPaid: totalPaidAmount,
                paymentsTicket,
                amountToBePaid,
                groupName,
                userEmail,
                payment_type: data?.enrollment?.payment_type,
                totalToBePaid,
                balance,
                groupId,
                userId: usrData?._id
              };
              usersList.push(tempUsr);
            }
          });
        }
      });
      setUsersData(usersList);
      setTotalUsers(usersList.length);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);
  const Auctioncolumns = [
    { key: "sl_no", header: "SL. NO" },
    { key: "userName", header: "Customer Name" },
    { key: "userPhone", header: "Phone Number" },
    { key: "customerId", header: "Customer Id" },
    { key: "groupName", header: "Group Name" },
    { key: "userEmail", header: "Email" },
    { key: "payment_type", header: "Payment Type" },
    { key: "paymentsTicket", header: "Ticket" },
    { key: "totalToBePaid", header: "Amount Payable" },
    { key: "amountPaid", header: "Paid Amount" },
    { key: "balance", header: "Balance" },
    { key: "checkBoxs", header: "Select User" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "w-screen", children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
        lineNumber: 236,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
      lineNumber: 240,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 mt-2", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
        lineNumber: 243,
        columnNumber: 16
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-center", children: "Outstanding Email Messages" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
        lineNumber: 244,
        columnNumber: 13
      }, this),
      contextHolder,
      isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-green-600" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
        lineNumber: 250,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
        lineNumber: 249,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-start border-b border-gray-300 mb-4" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
          lineNumber: 255,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-4 mb-6", children: /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Group Filter" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
              lineNumber: 260,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                style: { width: 200 },
                allowClear: true,
                placeholder: "--All groups--",
                onChange: (value) => setGroupFilter(value),
                value: groupFilter || void 0,
                children: groupOptions.map(
                  (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group, children: group }, group, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
                    lineNumber: 271,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
                lineNumber: 263,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
            lineNumber: 259,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
            lineNumber: 258,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mb-4", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: sendEmail,
              className: "relative bg-violet-600 text-white px-4 py-2 rounded shadow-md hover:bg-violet-700 transition duration-200 flex items-center",
              children: [
                visibleSelectedCount > 0 && /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "min-w-6 h-6 absolute -right-3 -top-2 shadow-lg hover:bg-red-600 bg-red-400 rounded-full text-white flex items-center justify-center text-xs",
                    title: `Message will be sent to total ${visibleSelectedCount} customers`,
                    children: /* @__PURE__ */ jsxDEV("span", { children: visibleSelectedCount }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
                      lineNumber: 288,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
                    lineNumber: 284,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(MdMarkEmailRead, { className: "mr-2", size: 20 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
                  lineNumber: 291,
                  columnNumber: 21
                }, this),
                "Email"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
              lineNumber: 279,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
            lineNumber: 278,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: filteredUsers,
              columns: Auctioncolumns,
              catcher: "_id",
              exportedPdfName: "Due Email",
              printHeaderKeys: ["Group Name"],
              printHeaderValues: [groupFilter],
              exportedFileName: `Due Email.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
              lineNumber: 295,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
          lineNumber: 257,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
        lineNumber: 253,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
      lineNumber: 242,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
    lineNumber: 235,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx",
    lineNumber: 234,
    columnNumber: 5
  }, this);
};
_s(DueEmail, "s7XK8nFGNcWMPxK2A58pkJWZq2g=", false, function() {
  return [notification.useNotification];
});
_c = DueEmail;
export default DueEmail;
var _c;
$RefreshReg$(_c, "DueEmail");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DueEmail.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0NVOzJCQS9DVjtBQUFnQkEsTUFBV0MsY0FBVUMsT0FBTyxzQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzRCxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLGNBQWM7QUFDdkIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyx1QkFBdUI7QUFDaEMsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxnQkFBZ0I7QUFFdkIsTUFBTUMsV0FBV0EsTUFBTTtBQUFBQyxLQUFBO0FBQ3JCLFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJaEIsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ2lCLFdBQVdDLFlBQVksSUFBSWxCLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNtQixhQUFhQyxjQUFjLElBQUlwQixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDcUIsVUFBVUMsV0FBVyxJQUFJdEIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ3VCLFFBQVFDLFNBQVMsSUFBSXhCLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUN5QixnQkFBZ0JDLGlCQUFpQixJQUFJMUIsU0FBUyxDQUFDLENBQUM7QUFDdkQsUUFBTSxDQUFDMkIsV0FBV0MsWUFBWSxJQUFJNUIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzZCLFlBQVlDLGFBQWEsSUFBSTlCLFNBQVMsQ0FBQztBQUM5QyxRQUFNLENBQUMrQixVQUFVQyxhQUFhLElBQUl2QixhQUFhd0IsZ0JBQWdCO0FBRS9ELFFBQU1DLGVBQWUsQ0FBQyxHQUFHLElBQUlDLElBQUlsQixVQUFVbUIsSUFBSSxDQUFDQyxNQUFNQSxFQUFFQyxTQUFTLENBQUMsQ0FBQztBQUVuRSxRQUFNQyxnQkFBZ0J0QyxRQUFRLE1BQU07QUFDbEMsVUFBTXVDLFdBQVdqQztBQUFBQSxNQUNmVSxVQUFVd0IsT0FBTyxDQUFDSixNQUFNO0FBQ3RCLGNBQU1LLGFBQWF2QixjQUFja0IsRUFBRUMsY0FBY25CLGNBQWM7QUFDL0QsY0FBTXdCLGlCQUFpQixJQUFJQyxLQUFLUCxFQUFFTSxjQUFjO0FBQ2hELGNBQU1FLGdCQUFnQnhCLFdBQ2xCc0Isa0JBQWtCLElBQUlDLEtBQUt2QixRQUFRLElBQ25DO0FBQ0osY0FBTXlCLGNBQWN2QixTQUFTb0Isa0JBQWtCLElBQUlDLEtBQUtyQixNQUFNLElBQUk7QUFDbEUsZUFBT21CLGNBQWNHLGlCQUFpQkM7QUFBQUEsTUFDeEMsQ0FBQztBQUFBLE1BQ0QvQjtBQUFBQSxJQUNGO0FBRUEsV0FBT3lCLFNBQVNKLElBQUksQ0FBQ1csTUFBTUMsVUFBVTtBQUNuQyxZQUFNQyxhQUFhLENBQUMsQ0FBQ3hCLGVBQWVzQixLQUFLRyxHQUFHLEdBQUdDLE1BQU1DO0FBRXJELGFBQU87QUFBQSxRQUNMLEdBQUdMO0FBQUFBLFFBQ0hNLE9BQU9MLFFBQVE7QUFBQSxRQUNmTSxXQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTTDtBQUFBQSxZQUNULFVBQVUsQ0FBQ00sTUFBTTtBQUNmN0IsZ0NBQWtCLENBQUM4QixVQUFVO0FBQUEsZ0JBQzNCLEdBQUdBO0FBQUFBLGdCQUNILENBQUNULEtBQUtHLEdBQUcsR0FBRztBQUFBLGtCQUNWQyxNQUFNO0FBQUEsb0JBQ0pDLFFBQVFHLEVBQUVFLE9BQU9DO0FBQUFBLG9CQUNqQkMsU0FBU1osS0FBS1k7QUFBQUEsb0JBQ2RDLFdBQVdiLEtBQUthO0FBQUFBLG9CQUNoQkMsZ0JBQWdCZCxLQUFLYztBQUFBQSxvQkFDckJ2QixXQUFXUyxLQUFLVDtBQUFBQSxvQkFDaEJ3QixVQUFVZixLQUFLZTtBQUFBQSxvQkFDZkMsU0FBU2hCLEtBQUtnQjtBQUFBQSxvQkFDZEMsUUFBUWpCLEtBQUtpQjtBQUFBQSxvQkFDYkMsWUFBWWxCLEtBQUtrQjtBQUFBQSxvQkFDakJDLGdCQUFnQm5CLEtBQUtvQjtBQUFBQSxvQkFDckJDLFdBQVdyQixLQUFLcUI7QUFBQUEsa0JBQ2xCO0FBQUEsZ0JBQ0Y7QUFBQSxjQUNGLEVBQUU7QUFBQSxZQUNKO0FBQUE7QUFBQSxVQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFzQkk7QUFBQSxRQUdObkI7QUFBQUEsTUFDRjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDaEMsV0FBV0UsYUFBYUUsVUFBVUUsUUFBUVIsWUFBWVUsY0FBYyxDQUFDO0FBRXpFLFFBQU00Qyx1QkFBdUJwRSxRQUFRLE1BQU07QUFDekMsV0FBT3NDLGNBQWNFLE9BQU8sQ0FBQ00sU0FBU0EsS0FBS0UsVUFBVSxFQUFFcUI7QUFBQUEsRUFDekQsR0FBRyxDQUFDL0IsYUFBYSxDQUFDO0FBRW5CLFFBQU1nQyxZQUFZLFlBQVk7QUFDN0IsVUFBTUMsTUFBTTtBQUNaLFFBQUk7QUFDRnpDLGVBQVMwQyxLQUFLO0FBQUEsUUFDWkQ7QUFBQUEsUUFDQUUsU0FBUztBQUFBLFFBQ1RDLGFBQWE7QUFBQSxRQUNiQyxXQUFXO0FBQUEsUUFDWEMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUdELFlBQU1DLGdCQUFnQixDQUFDO0FBQ3ZCdkMsb0JBQWN3QyxRQUFRLENBQUNoQyxTQUFTO0FBQzlCLFlBQUlBLEtBQUtFLGNBQWN4QixlQUFlc0IsS0FBS0csR0FBRyxHQUFHO0FBQy9DNEIsd0JBQWMvQixLQUFLRyxHQUFHLElBQUl6QixlQUFlc0IsS0FBS0csR0FBRztBQUFBLFFBQ25EO0FBQUEsTUFDRixDQUFDO0FBRUQsWUFBTWhELElBQUk4RSxLQUFLLG9CQUFvQkYsYUFBYTtBQUdoRCxZQUFNRyx3QkFBd0IsRUFBRSxHQUFHeEQsZUFBZTtBQUNsRGMsb0JBQWN3QyxRQUFRLENBQUNoQyxTQUFTO0FBQzlCLFlBQUlBLEtBQUtFLFlBQVk7QUFDbkIsaUJBQU9nQyxzQkFBc0JsQyxLQUFLRyxHQUFHO0FBQUEsUUFDdkM7QUFBQSxNQUNGLENBQUM7QUFDRHhCLHdCQUFrQnVELHFCQUFxQjtBQUV2Q2xELGVBQVMwQyxLQUFLO0FBQUEsUUFDWkQ7QUFBQUEsUUFDQUUsU0FBUztBQUFBLFFBQ1RDLGFBQWE7QUFBQSxRQUNiQyxXQUFXO0FBQUEsUUFDWEMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0gsU0FBU0ssS0FBSztBQUNabkQsZUFBUzBDLEtBQUs7QUFBQSxRQUNaRDtBQUFBQSxRQUNBRSxTQUFTO0FBQUEsUUFDVEMsYUFBYU8sSUFBSVIsV0FBVztBQUFBLFFBQzVCRSxXQUFXO0FBQUEsUUFDWEMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBR0UsUUFBTU0sWUFBWSxZQUFZO0FBQzVCLFFBQUk7QUFDRnZELG1CQUFhLElBQUk7QUFDakIsWUFBTXdELGlCQUFpQixNQUFNbEYsSUFBSW1GLElBQUksOEJBQThCO0FBRW5FLFlBQU1DLFlBQVk7QUFDbEIsWUFBTUMsYUFBYSxDQUFDO0FBRXBCSCxxQkFBZUksS0FBS1QsUUFBUSxDQUFDVSxZQUFZO0FBQ3ZDLFlBQUlBLFNBQVNELE1BQU07QUFDakJDLGtCQUFRRCxLQUFLVCxRQUFRLENBQUNTLFNBQVM7QUFDN0IsZ0JBQUlBLE1BQU1FLFlBQVlDLE9BQU87QUFDM0Isb0JBQU1DLGVBQWVDO0FBQUFBLGdCQUNuQkwsS0FBS0UsV0FBV0MsTUFBTUc7QUFBQUEsY0FDeEI7QUFDQSxvQkFBTS9CLFVBQVV5QixLQUFLRSxXQUFXQyxNQUFNekM7QUFDdEMsb0JBQU02QyxZQUFZUCxLQUFLRSxXQUFXQyxNQUFNSztBQUN4QyxvQkFBTUMsa0JBQWtCVCxLQUFLVSxTQUFTRDtBQUN0QyxvQkFBTUUsZUFBZU4sU0FBU0wsTUFBTVksU0FBU0QsWUFBWTtBQUN6RCxvQkFBTUUsZUFBZWIsS0FBS2MsUUFBUUQ7QUFDbEMsb0JBQU1FLGNBQWNmLEtBQUtnQixPQUFPRDtBQUNoQyxvQkFBTUUsb0JBQW9CakIsS0FBS2tCLGFBQWFEO0FBQzVDLG9CQUFNRSxLQUFLbkIsTUFBTUUsWUFBWXhDO0FBQzdCLG9CQUFNVSxZQUFZNkIsUUFBUW1CO0FBQzFCLG9CQUFNeEMsWUFBWXFCLFFBQVFvQjtBQUMxQixvQkFBTWhELGlCQUFpQjJCLEtBQUtVLFNBQVNZO0FBQ3JDLG9CQUFNeEUsWUFBWWtELEtBQUtFLFdBQVdDLE1BQU1vQjtBQUN4QyxvQkFBTTVDLGdCQUNKNEIsY0FBYyxXQUNWSCxlQUFlTyxlQUFlUCxlQUM5QlMsZUFBZVQsZUFBZVc7QUFDcEMsb0JBQU1yQyxpQkFBaUI2QixjQUFjLFdBQy9CSCxlQUFlTyxlQUFlUCxlQUM5QlMsZUFBZVQsZUFBZVc7QUFDcEMsb0JBQU01QyxVQUNKb0MsY0FBYyxXQUNWSCxlQUFlTyxlQUFlUCxlQUFlSyxrQkFDN0NJLGVBQ0FULGVBQ0FhLG9CQUNBUjtBQUVOLGtCQUFJdEMsV0FBVyxFQUFHO0FBRWxCLG9CQUFNRyxXQUFXMkIsUUFBUTNCO0FBQ3pCeUIseUJBQVdvQixFQUFFLElBQUk7QUFBQSxnQkFDZnhELE1BQU07QUFBQSxrQkFDSkMsUUFBUTtBQUFBLGtCQUNSTztBQUFBQSxnQkFDRjtBQUFBLGNBQ0Y7QUFFQSxvQkFBTXFELFVBQVU7QUFBQSxnQkFDZDlELEtBQUt5RDtBQUFBQSxnQkFDTDdDO0FBQUFBLGdCQUNBRjtBQUFBQSxnQkFDQXFELFlBQVl4QixRQUFReUI7QUFBQUEsZ0JBQ3BCakQsWUFBWWdDO0FBQUFBLGdCQUNacEM7QUFBQUEsZ0JBQ0FLO0FBQUFBLGdCQUNBNUI7QUFBQUEsZ0JBQ0E4QjtBQUFBQSxnQkFDQStDLGNBQWMzQixNQUFNRSxZQUFZeUI7QUFBQUEsZ0JBQ2hDaEQ7QUFBQUEsZ0JBQ0FSO0FBQUFBLGdCQUNBSTtBQUFBQSxnQkFDQUMsUUFBUXlCLFNBQVN2QztBQUFBQSxjQUNuQjtBQUNBb0Msd0JBQVU4QixLQUFLSixPQUFPO0FBQUEsWUFDeEI7QUFBQSxVQUNGLENBQUM7QUFBQSxRQUNIO0FBQUEsTUFDRixDQUFDO0FBRUQ5RixtQkFBYW9FLFNBQVM7QUFDdEJ4RCxvQkFBY3dELFVBQVVoQixNQUFNO0FBQUEsSUFDaEMsU0FBUytDLE9BQU87QUFDZEMsY0FBUUQsTUFBTSx3QkFBd0JBLEtBQUs7QUFBQSxJQUM3QyxVQUFDO0FBQ0N6RixtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUE3QixZQUFVLE1BQU07QUFDZG9GLGNBQVU7QUFBQSxFQUNaLEdBQUcsRUFBRTtBQUVMLFFBQU1vQyxpQkFBaUI7QUFBQSxJQUNyQixFQUFFL0MsS0FBSyxTQUFTZ0QsUUFBUSxTQUFTO0FBQUEsSUFDakMsRUFBRWhELEtBQUssWUFBWWdELFFBQVEsZ0JBQWdCO0FBQUEsSUFDM0MsRUFBRWhELEtBQUssYUFBYWdELFFBQVEsZUFBZTtBQUFBLElBQzNDLEVBQUVoRCxLQUFLLGNBQWNnRCxRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFaEQsS0FBSyxhQUFhZ0QsUUFBUSxhQUFhO0FBQUEsSUFDekMsRUFBQ2hELEtBQUssYUFBYWdELFFBQVEsUUFBTztBQUFBLElBQ2xDLEVBQUVoRCxLQUFLLGdCQUFnQmdELFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVoRCxLQUFLLGtCQUFrQmdELFFBQVEsU0FBUztBQUFBLElBQzFDLEVBQUVoRCxLQUFLLGlCQUFpQmdELFFBQVEsaUJBQWlCO0FBQUEsSUFDakQsRUFBRWhELEtBQUssY0FBY2dELFFBQVEsY0FBYztBQUFBLElBQzNDLEVBQUVoRCxLQUFLLFdBQVdnRCxRQUFRLFVBQVU7QUFBQSxJQUNwQyxFQUFFaEQsS0FBSyxhQUFhZ0QsUUFBUSxjQUFjO0FBQUEsRUFBQztBQUc3QyxTQUNFLHVCQUFDLFNBQUksV0FBVSxZQUNiLGlDQUFDLFNBQUksV0FBVSxjQUNiO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLDZCQUE2QixDQUFDakUsTUFBTXZDLGNBQWN1QyxFQUFFRSxPQUFPZ0UsS0FBSztBQUFBLFFBQ2hFLFlBQVk7QUFBQTtBQUFBLE1BRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRW1CO0FBQUEsSUFFbkIsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVE7QUFBQSxJQUVOLHVCQUFDLFNBQUksV0FBVSxzQkFDVjtBQUFBLDZCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBVztBQUFBLE1BQ2QsdUJBQUMsUUFBRyxXQUFVLGtDQUFpQywwQ0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQ3pGO0FBQUFBLE1BQ0lMLFlBQ1AsdUJBQUMsU0FBSSxXQUFVLFVBQ2IsaUNBQUMsa0JBQWUsT0FBTSxvQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzQyxLQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsSUFFRSx1QkFBQyxTQUFJLFdBQVUsYUFFYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxzREFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtFO0FBQUEsUUFFbEUsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMENBQ2IsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0MsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTyxFQUFFK0YsT0FBTyxJQUFJO0FBQUEsZ0JBQ3BCO0FBQUEsZ0JBQ0EsYUFBWTtBQUFBLGdCQUNaLFVBQVUsQ0FBQ0QsVUFBVXJHLGVBQWVxRyxLQUFLO0FBQUEsZ0JBQ3pDLE9BQU90RyxlQUFld0c7QUFBQUEsZ0JBRXJCekYsdUJBQWFFO0FBQUFBLGtCQUFJLENBQUN1RCxVQUNqQix1QkFBQyxPQUFPLFFBQVAsRUFBMEIsT0FBT0EsT0FDL0JBLG1CQURpQkEsT0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGdCQUNEO0FBQUE7QUFBQSxjQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVlBO0FBQUEsZUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBU3BCO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBRVRGO0FBQUFBLHVDQUF1QixLQUN0QjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsT0FBTyxpQ0FBaUNBLG9CQUFvQjtBQUFBLG9CQUU1RCxpQ0FBQyxVQUFNQSxrQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE0QjtBQUFBO0FBQUEsa0JBSjlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUVGLHVCQUFDLG1CQUFnQixXQUFVLFFBQU8sTUFBTSxNQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyQztBQUFBLGdCQUFHO0FBQUE7QUFBQTtBQUFBLFlBWmhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNOUI7QUFBQUEsY0FDTixTQUFTZ0Y7QUFBQUEsY0FDVCxTQUFRO0FBQUEsY0FDUixpQkFBZ0I7QUFBQSxjQUNoQixpQkFBaUIsQ0FBQyxZQUFZO0FBQUEsY0FDOUIsbUJBQW1CLENBQUNwRyxXQUFXO0FBQUEsY0FDL0Isa0JBQWtCO0FBQUE7QUFBQSxZQVBwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPb0M7QUFBQSxhQTdDdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStDQTtBQUFBLFdBbkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxREE7QUFBQSxTQWhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0VBO0FBQUEsT0F6RUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJFQSxLQTVFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkVBO0FBRUo7QUFBRUwsR0EzU0lELFVBQVE7QUFBQSxVQVNzQkosYUFBYXdCLGVBQWU7QUFBQTtBQUFBMkYsS0FUMUQvRztBQTZTTixlQUFlQTtBQUFTLElBQUErRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VNZW1vIiwiYXBpIiwiRGF0YVRhYmxlIiwiQ2lyY3VsYXJMb2FkZXIiLCJTZWxlY3QiLCJOYXZiYXIiLCJmaWx0ZXJPcHRpb24iLCJGYVdoYXRzYXBwIiwibm90aWZpY2F0aW9uIiwiTWRNYXJrRW1haWxSZWFkIiwiU2lkZWJhciIsIkJyZWFkY3J1bWIiLCJEdWVFbWFpbCIsIl9zIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJ1c2Vyc0RhdGEiLCJzZXRVc2Vyc0RhdGEiLCJncm91cEZpbHRlciIsInNldEdyb3VwRmlsdGVyIiwiZnJvbURhdGUiLCJzZXRGcm9tRGF0ZSIsInRvRGF0ZSIsInNldFRvRGF0ZSIsImFjdGl2ZVVzZXJEYXRhIiwic2V0QWN0aXZlVXNlckRhdGEiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJ0b3RhbFVzZXJzIiwic2V0VG90YWxVc2VycyIsIm5vdGlmaWVyIiwiY29udGV4dEhvbGRlciIsInVzZU5vdGlmaWNhdGlvbiIsImdyb3VwT3B0aW9ucyIsIlNldCIsIm1hcCIsInUiLCJncm91cE5hbWUiLCJmaWx0ZXJlZFVzZXJzIiwiZmlsdGVyZWQiLCJmaWx0ZXIiLCJtYXRjaEdyb3VwIiwiZW5yb2xsbWVudERhdGUiLCJEYXRlIiwibWF0Y2hGcm9tRGF0ZSIsIm1hdGNoVG9EYXRlIiwidXNlciIsImluZGV4IiwiaXNTZWxlY3RlZCIsIl9pZCIsImluZm8iLCJzdGF0dXMiLCJzbF9ubyIsImNoZWNrQm94cyIsImUiLCJwcmV2IiwidGFyZ2V0IiwiY2hlY2tlZCIsImJhbGFuY2UiLCJ1c2VyUGhvbmUiLCJwYXltZW50c1RpY2tldCIsInVzZXJOYW1lIiwiZ3JvdXBJZCIsInVzZXJJZCIsImFtb3VudFBhaWQiLCJhbW91bnRUb0JlUGFpZCIsInRvdGFsVG9CZVBhaWQiLCJ1c2VyRW1haWwiLCJ2aXNpYmxlU2VsZWN0ZWRDb3VudCIsImxlbmd0aCIsInNlbmRFbWFpbCIsImtleSIsIm9wZW4iLCJtZXNzYWdlIiwiZGVzY3JpcHRpb24iLCJjbGFzc05hbWUiLCJkdXJhdGlvbiIsInNlbGVjdGVkVXNlcnMiLCJmb3JFYWNoIiwicG9zdCIsInVwZGF0ZWRBY3RpdmVVc2VyRGF0YSIsImVyciIsImZldGNoRGF0YSIsInJlcG9ydFJlc3BvbnNlIiwiZ2V0IiwidXNlcnNMaXN0IiwidGVtcEFjdGl2ZSIsImRhdGEiLCJ1c3JEYXRhIiwiZW5yb2xsbWVudCIsImdyb3VwIiwiZ3JvdXBJbnN0YWxsIiwicGFyc2VJbnQiLCJncm91cF9pbnN0YWxsIiwiZ3JvdXBUeXBlIiwiZ3JvdXBfdHlwZSIsInRvdGFsUGFpZEFtb3VudCIsInBheW1lbnRzIiwiYXVjdGlvbkNvdW50IiwiYXVjdGlvbiIsInRvdGFsUGF5YWJsZSIsInBheWFibGUiLCJ0b3RhbFByb2ZpdCIsInByb2ZpdCIsImZpcnN0RGl2aWRlbnRIZWFkIiwiZmlyc3RBdWN0aW9uIiwiaWQiLCJwaG9uZV9udW1iZXIiLCJlbWFpbCIsInRpY2tldCIsImdyb3VwX25hbWUiLCJ0ZW1wVXNyIiwiY3VzdG9tZXJJZCIsImN1c3RvbWVyX2lkIiwicGF5bWVudF90eXBlIiwicHVzaCIsImVycm9yIiwiY29uc29sZSIsIkF1Y3Rpb25jb2x1bW5zIiwiaGVhZGVyIiwidmFsdWUiLCJ3aWR0aCIsInVuZGVmaW5lZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkR1ZUVtYWlsLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlTWVtbyB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgU2VsZWN0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgeyBGYVdoYXRzYXBwIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IG5vdGlmaWNhdGlvbiB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IE1kTWFya0VtYWlsUmVhZCB9IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IEJyZWFkY3J1bWIgZnJvbSBcIi4uL2hlbHBlcnMvQnJlYWRjcnVtYlwiO1xyXG5cclxuY29uc3QgRHVlRW1haWwgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3VzZXJzRGF0YSwgc2V0VXNlcnNEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZ3JvdXBGaWx0ZXIsIHNldEdyb3VwRmlsdGVyXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtmcm9tRGF0ZSwgc2V0RnJvbURhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3RvRGF0ZSwgc2V0VG9EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFthY3RpdmVVc2VyRGF0YSwgc2V0QWN0aXZlVXNlckRhdGFdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3RvdGFsVXNlcnMsIHNldFRvdGFsVXNlcnNdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW25vdGlmaWVyLCBjb250ZXh0SG9sZGVyXSA9IG5vdGlmaWNhdGlvbi51c2VOb3RpZmljYXRpb24oKTtcclxuXHJcbiAgY29uc3QgZ3JvdXBPcHRpb25zID0gWy4uLm5ldyBTZXQodXNlcnNEYXRhLm1hcCgodSkgPT4gdS5ncm91cE5hbWUpKV07XHJcblxyXG4gIGNvbnN0IGZpbHRlcmVkVXNlcnMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IGZpbHRlcmVkID0gZmlsdGVyT3B0aW9uKFxyXG4gICAgICB1c2Vyc0RhdGEuZmlsdGVyKCh1KSA9PiB7XHJcbiAgICAgICAgY29uc3QgbWF0Y2hHcm91cCA9IGdyb3VwRmlsdGVyID8gdS5ncm91cE5hbWUgPT09IGdyb3VwRmlsdGVyIDogdHJ1ZTtcclxuICAgICAgICBjb25zdCBlbnJvbGxtZW50RGF0ZSA9IG5ldyBEYXRlKHUuZW5yb2xsbWVudERhdGUpO1xyXG4gICAgICAgIGNvbnN0IG1hdGNoRnJvbURhdGUgPSBmcm9tRGF0ZVxyXG4gICAgICAgICAgPyBlbnJvbGxtZW50RGF0ZSA+PSBuZXcgRGF0ZShmcm9tRGF0ZSlcclxuICAgICAgICAgIDogdHJ1ZTtcclxuICAgICAgICBjb25zdCBtYXRjaFRvRGF0ZSA9IHRvRGF0ZSA/IGVucm9sbG1lbnREYXRlIDw9IG5ldyBEYXRlKHRvRGF0ZSkgOiB0cnVlO1xyXG4gICAgICAgIHJldHVybiBtYXRjaEdyb3VwICYmIG1hdGNoRnJvbURhdGUgJiYgbWF0Y2hUb0RhdGU7XHJcbiAgICAgIH0pLFxyXG4gICAgICBzZWFyY2hUZXh0XHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiBmaWx0ZXJlZC5tYXAoKHVzZXIsIGluZGV4KSA9PiB7XHJcbiAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSAhIWFjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXT8uaW5mbz8uc3RhdHVzO1xyXG5cclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi51c2VyLFxyXG4gICAgICAgIHNsX25vOiBpbmRleCArIDEsXHJcbiAgICAgICAgY2hlY2tCb3hzOiAoXHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgY2hlY2tlZD17aXNTZWxlY3RlZH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0QWN0aXZlVXNlckRhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgW3VzZXIuX2lkXToge1xyXG4gICAgICAgICAgICAgICAgICBpbmZvOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgIGJhbGFuY2U6IHVzZXIuYmFsYW5jZSxcclxuICAgICAgICAgICAgICAgICAgICB1c2VyUGhvbmU6IHVzZXIudXNlclBob25lLFxyXG4gICAgICAgICAgICAgICAgICAgIHBheW1lbnRzVGlja2V0OiB1c2VyLnBheW1lbnRzVGlja2V0LFxyXG4gICAgICAgICAgICAgICAgICAgIGdyb3VwTmFtZTogdXNlci5ncm91cE5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlck5hbWU6IHVzZXIudXNlck5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgZ3JvdXBJZDogdXNlci5ncm91cElkLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJJZDogdXNlci51c2VySWQsXHJcbiAgICAgICAgICAgICAgICAgICAgYW1vdW50UGFpZDogdXNlci5hbW91bnRQYWlkLFxyXG4gICAgICAgICAgICAgICAgICAgIGFtb3VudFRvQmVQYWlkOiB1c2VyLnRvdGFsVG9CZVBhaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlckVtYWlsOiB1c2VyLnVzZXJFbWFpbCxcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApLFxyXG4gICAgICAgIGlzU2VsZWN0ZWQsXHJcbiAgICAgIH07XHJcbiAgICB9KTtcclxuICB9LCBbdXNlcnNEYXRhLCBncm91cEZpbHRlciwgZnJvbURhdGUsIHRvRGF0ZSwgc2VhcmNoVGV4dCwgYWN0aXZlVXNlckRhdGFdKTtcclxuXHJcbiAgY29uc3QgdmlzaWJsZVNlbGVjdGVkQ291bnQgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiBmaWx0ZXJlZFVzZXJzLmZpbHRlcigodXNlcikgPT4gdXNlci5pc1NlbGVjdGVkKS5sZW5ndGg7XHJcbiAgfSwgW2ZpbHRlcmVkVXNlcnNdKTtcclxuXHJcbiBjb25zdCBzZW5kRW1haWwgPSBhc3luYyAoKSA9PiB7XHJcbiAgY29uc3Qga2V5ID0gXCJ1cGRhdGFibGVcIjtcclxuICB0cnkge1xyXG4gICAgbm90aWZpZXIub3Blbih7XHJcbiAgICAgIGtleSxcclxuICAgICAgbWVzc2FnZTogXCJTZW5kaW5nIEVtYWlscy4uXCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIlByb2Nlc3NpbmcuLi5cIixcclxuICAgICAgY2xhc3NOYW1lOiBcImJnLXZpb2xldC0zMDAgcm91bmRlZC1sZyBmb250LWJvbGRcIixcclxuICAgICAgZHVyYXRpb246IDIsXHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyBQcmVwYXJlIHNlbGVjdGVkIHVzZXJzXHJcbiAgICBjb25zdCBzZWxlY3RlZFVzZXJzID0ge307XHJcbiAgICBmaWx0ZXJlZFVzZXJzLmZvckVhY2goKHVzZXIpID0+IHtcclxuICAgICAgaWYgKHVzZXIuaXNTZWxlY3RlZCAmJiBhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF0pIHtcclxuICAgICAgICBzZWxlY3RlZFVzZXJzW3VzZXIuX2lkXSA9IGFjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgYXdhaXQgYXBpLnBvc3QoXCIvZW1haWwvZHVlLWVtYWlsXCIsIHNlbGVjdGVkVXNlcnMpO1xyXG5cclxuICAgIC8vIENsZWFudXAgYWZ0ZXIgc2VuZGluZ1xyXG4gICAgY29uc3QgdXBkYXRlZEFjdGl2ZVVzZXJEYXRhID0geyAuLi5hY3RpdmVVc2VyRGF0YSB9O1xyXG4gICAgZmlsdGVyZWRVc2Vycy5mb3JFYWNoKCh1c2VyKSA9PiB7XHJcbiAgICAgIGlmICh1c2VyLmlzU2VsZWN0ZWQpIHtcclxuICAgICAgICBkZWxldGUgdXBkYXRlZEFjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgICBzZXRBY3RpdmVVc2VyRGF0YSh1cGRhdGVkQWN0aXZlVXNlckRhdGEpO1xyXG5cclxuICAgIG5vdGlmaWVyLm9wZW4oe1xyXG4gICAgICBrZXksXHJcbiAgICAgIG1lc3NhZ2U6IFwiRW1haWxzIFNlbnQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIlN1Y2Nlc3NcIixcclxuICAgICAgY2xhc3NOYW1lOiBcImJnLWdyZWVuLTMwMCByb3VuZGVkLWxnIGZvbnQtYm9sZFwiLFxyXG4gICAgICBkdXJhdGlvbjogMixcclxuICAgIH0pO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgbm90aWZpZXIub3Blbih7XHJcbiAgICAgIGtleSxcclxuICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gU2VuZCBFbWFpbHNcIixcclxuICAgICAgZGVzY3JpcHRpb246IGVyci5tZXNzYWdlIHx8IFwiU29tZXRoaW5nIHdlbnQgd3JvbmdcIixcclxuICAgICAgY2xhc3NOYW1lOiBcImJnLXJlZC0zMDAgcm91bmRlZC1sZyBmb250LWJvbGRcIixcclxuICAgICAgZHVyYXRpb246IDIsXHJcbiAgICB9KTtcclxuICB9XHJcbn07XHJcblxyXG5cclxuICBjb25zdCBmZXRjaERhdGEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHJlcG9ydFJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2dldC1kdWUtZW1haWwtcGF5bWVudHNcIik7XHJcbiAgICBcclxuICAgICAgY29uc3QgdXNlcnNMaXN0ID0gW107XHJcbiAgICAgIGNvbnN0IHRlbXBBY3RpdmUgPSB7fTtcclxuXHJcbiAgICAgIHJlcG9ydFJlc3BvbnNlLmRhdGEuZm9yRWFjaCgodXNyRGF0YSkgPT4ge1xyXG4gICAgICAgIGlmICh1c3JEYXRhPy5kYXRhKSB7XHJcbiAgICAgICAgICB1c3JEYXRhLmRhdGEuZm9yRWFjaCgoZGF0YSkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoZGF0YT8uZW5yb2xsbWVudD8uZ3JvdXApIHtcclxuICAgICAgICAgICAgICBjb25zdCBncm91cEluc3RhbGwgPSBwYXJzZUludChcclxuICAgICAgICAgICAgICAgIGRhdGEuZW5yb2xsbWVudC5ncm91cC5ncm91cF9pbnN0YWxsXHJcbiAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICBjb25zdCBncm91cElkID0gZGF0YS5lbnJvbGxtZW50Lmdyb3VwLl9pZDtcclxuICAgICAgICAgICAgICBjb25zdCBncm91cFR5cGUgPSBkYXRhLmVucm9sbG1lbnQuZ3JvdXAuZ3JvdXBfdHlwZTtcclxuICAgICAgICAgICAgICBjb25zdCB0b3RhbFBhaWRBbW91bnQgPSBkYXRhLnBheW1lbnRzLnRvdGFsUGFpZEFtb3VudDtcclxuICAgICAgICAgICAgICBjb25zdCBhdWN0aW9uQ291bnQgPSBwYXJzZUludChkYXRhPy5hdWN0aW9uPy5hdWN0aW9uQ291bnQpO1xyXG4gICAgICAgICAgICAgIGNvbnN0IHRvdGFsUGF5YWJsZSA9IGRhdGEucGF5YWJsZS50b3RhbFBheWFibGU7XHJcbiAgICAgICAgICAgICAgY29uc3QgdG90YWxQcm9maXQgPSBkYXRhLnByb2ZpdC50b3RhbFByb2ZpdDtcclxuICAgICAgICAgICAgICBjb25zdCBmaXJzdERpdmlkZW50SGVhZCA9IGRhdGEuZmlyc3RBdWN0aW9uLmZpcnN0RGl2aWRlbnRIZWFkO1xyXG4gICAgICAgICAgICAgIGNvbnN0IGlkID0gZGF0YT8uZW5yb2xsbWVudD8uX2lkO1xyXG4gICAgICAgICAgICAgIGNvbnN0IHVzZXJQaG9uZSA9IHVzckRhdGEucGhvbmVfbnVtYmVyO1xyXG4gICAgICAgICAgICAgIGNvbnN0IHVzZXJFbWFpbCA9IHVzckRhdGEuZW1haWw7XHJcbiAgICAgICAgICAgICAgY29uc3QgcGF5bWVudHNUaWNrZXQgPSBkYXRhLnBheW1lbnRzLnRpY2tldDtcclxuICAgICAgICAgICAgICBjb25zdCBncm91cE5hbWUgPSBkYXRhLmVucm9sbG1lbnQuZ3JvdXAuZ3JvdXBfbmFtZTtcclxuICAgICAgICAgICAgICBjb25zdCB0b3RhbFRvQmVQYWlkID1cclxuICAgICAgICAgICAgICAgIGdyb3VwVHlwZSA9PT0gXCJkb3VibGVcIlxyXG4gICAgICAgICAgICAgICAgICA/IGdyb3VwSW5zdGFsbCAqIGF1Y3Rpb25Db3VudCArIGdyb3VwSW5zdGFsbFxyXG4gICAgICAgICAgICAgICAgICA6IHRvdGFsUGF5YWJsZSArIGdyb3VwSW5zdGFsbCArIHRvdGFsUHJvZml0O1xyXG4gICAgICAgICAgICAgIGNvbnN0IGFtb3VudFRvQmVQYWlkID0gZ3JvdXBUeXBlID09PSBcImRvdWJsZVwiXHJcbiAgICAgICAgICAgICAgICAgID8gZ3JvdXBJbnN0YWxsICogYXVjdGlvbkNvdW50ICsgZ3JvdXBJbnN0YWxsXHJcbiAgICAgICAgICAgICAgICAgIDogdG90YWxQYXlhYmxlICsgZ3JvdXBJbnN0YWxsICsgdG90YWxQcm9maXQ7XHJcbiAgICAgICAgICAgICAgY29uc3QgYmFsYW5jZSA9XHJcbiAgICAgICAgICAgICAgICBncm91cFR5cGUgPT09IFwiZG91YmxlXCJcclxuICAgICAgICAgICAgICAgICAgPyBncm91cEluc3RhbGwgKiBhdWN0aW9uQ291bnQgKyBncm91cEluc3RhbGwgLSB0b3RhbFBhaWRBbW91bnRcclxuICAgICAgICAgICAgICAgICAgOiB0b3RhbFBheWFibGUgK1xyXG4gICAgICAgICAgICAgICAgICAgIGdyb3VwSW5zdGFsbCArXHJcbiAgICAgICAgICAgICAgICAgICAgZmlyc3REaXZpZGVudEhlYWQgLVxyXG4gICAgICAgICAgICAgICAgICAgIHRvdGFsUGFpZEFtb3VudDtcclxuXHJcbiAgICAgICAgICAgICAgaWYgKGJhbGFuY2UgPD0gMCkgcmV0dXJuO1xyXG5cclxuICAgICAgICAgICAgICBjb25zdCB1c2VyTmFtZSA9IHVzckRhdGEudXNlck5hbWU7XHJcbiAgICAgICAgICAgICAgdGVtcEFjdGl2ZVtpZF0gPSB7XHJcbiAgICAgICAgICAgICAgICBpbmZvOiB7XHJcbiAgICAgICAgICAgICAgICAgIHN0YXR1czogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgIGJhbGFuY2UsXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAgIGNvbnN0IHRlbXBVc3IgPSB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IGlkLFxyXG4gICAgICAgICAgICAgICAgdXNlck5hbWUsXHJcbiAgICAgICAgICAgICAgICB1c2VyUGhvbmUsXHJcbiAgICAgICAgICAgICAgICBjdXN0b21lcklkOiB1c3JEYXRhLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgYW1vdW50UGFpZDogdG90YWxQYWlkQW1vdW50LFxyXG4gICAgICAgICAgICAgICAgcGF5bWVudHNUaWNrZXQsXHJcbiAgICAgICAgICAgICAgICBhbW91bnRUb0JlUGFpZCxcclxuICAgICAgICAgICAgICAgIGdyb3VwTmFtZSxcclxuICAgICAgICAgICAgICAgIHVzZXJFbWFpbCxcclxuICAgICAgICAgICAgICAgIHBheW1lbnRfdHlwZTogZGF0YT8uZW5yb2xsbWVudD8ucGF5bWVudF90eXBlLFxyXG4gICAgICAgICAgICAgICAgdG90YWxUb0JlUGFpZDogdG90YWxUb0JlUGFpZCxcclxuICAgICAgICAgICAgICAgIGJhbGFuY2UsXHJcbiAgICAgICAgICAgICAgICBncm91cElkOiBncm91cElkLFxyXG4gICAgICAgICAgICAgICAgdXNlcklkOiB1c3JEYXRhPy5faWQsXHJcbiAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICB1c2Vyc0xpc3QucHVzaCh0ZW1wVXNyKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHNldFVzZXJzRGF0YSh1c2Vyc0xpc3QpO1xyXG4gICAgICBzZXRUb3RhbFVzZXJzKHVzZXJzTGlzdC5sZW5ndGgpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGRhdGE6XCIsIGVycm9yKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoRGF0YSgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgQXVjdGlvbmNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJzbF9ub1wiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcInVzZXJOYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInVzZXJQaG9uZVwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImN1c3RvbWVySWRcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIElkXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwTmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbiAgICB7a2V5OiBcInVzZXJFbWFpbFwiLCBoZWFkZXI6IFwiRW1haWxcIn0sXHJcbiAgICB7IGtleTogXCJwYXltZW50X3R5cGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJwYXltZW50c1RpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0XCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsVG9CZVBhaWRcIiwgaGVhZGVyOiBcIkFtb3VudCBQYXlhYmxlXCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudFBhaWRcIiwgaGVhZGVyOiBcIlBhaWQgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcImJhbGFuY2VcIiwgaGVhZGVyOiBcIkJhbGFuY2VcIiB9LFxyXG4gICAgeyBrZXk6IFwiY2hlY2tCb3hzXCIsIGhlYWRlcjogXCJTZWxlY3QgVXNlclwiIH0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwidy1zY3JlZW5cIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXsoZSkgPT4gc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICBcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtNyBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICBPdXRzdGFuZGluZyBFbWFpbCBNZXNzYWdlc1xyXG4gICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICB7Y29udGV4dEhvbGRlcn1cclxuICAgICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgY29sb3I9XCJ0ZXh0LWdyZWVuLTYwMFwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1zdGFydCBib3JkZXItYiBib3JkZXItZ3JheS0zMDAgbWItNFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTBcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEdyb3VwIEZpbHRlclxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDIwMCB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCItLUFsbCBncm91cHMtLVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBzZXRHcm91cEZpbHRlcih2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXBGaWx0ZXIgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cE9wdGlvbnMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwfSB2YWx1ZT17Z3JvdXB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17c2VuZEVtYWlsfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLXZpb2xldC02MDAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZCBzaGFkb3ctbWQgaG92ZXI6YmctdmlvbGV0LTcwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCBmbGV4IGl0ZW1zLWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7dmlzaWJsZVNlbGVjdGVkQ291bnQgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWluLXctNiBoLTYgYWJzb2x1dGUgLXJpZ2h0LTMgLXRvcC0yIHNoYWRvdy1sZyBob3ZlcjpiZy1yZWQtNjAwIGJnLXJlZC00MDAgcm91bmRlZC1mdWxsIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC14c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtgTWVzc2FnZSB3aWxsIGJlIHNlbnQgdG8gdG90YWwgJHt2aXNpYmxlU2VsZWN0ZWRDb3VudH0gY3VzdG9tZXJzYH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3Zpc2libGVTZWxlY3RlZENvdW50fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPE1kTWFya0VtYWlsUmVhZCBjbGFzc05hbWU9XCJtci0yXCIgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgRW1haWxcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyZWRVc2Vyc31cclxuICAgICAgICAgICAgICAgICAgY29sdW1ucz17QXVjdGlvbmNvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgIGNhdGNoZXI9XCJfaWRcIlxyXG4gICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJEdWUgRW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICBwcmludEhlYWRlcktleXM9e1tcIkdyb3VwIE5hbWVcIl19XHJcbiAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbZ3JvdXBGaWx0ZXJdfVxyXG4gICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgRHVlIEVtYWlsLmNzdmB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIFxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEdWVFbWFpbDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0R1ZUVtYWlsLmpzeCJ9