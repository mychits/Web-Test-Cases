import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/BidWinner.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { notification } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { FaUsers, FaCheckCircle } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const BidWinner = () => {
  _s();
  const [searchText, setSearchText] = useState("");
  const [usersData, setUsersData] = useState([]);
  const [groupFilter, setGroupFilter] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [activeUserData, setActiveUserData] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [totalUsers, setTotalUsers] = useState(0);
  const [notifier, contextHolder] = notification.useNotification();
  const [selectAll, setSelectAll] = useState(false);
  const [winTicket, setWinTicket] = useState("");
  const groupOptions = [...new Set(usersData.map((u) => u.groupName))];
  const filteredUsers = useMemo(() => {
    const filtered = filterOption(
      usersData.filter((u) => {
        const matchGroup = groupFilter ? u.groupName === groupFilter : true;
        const enrollmentDate = new Date(u.enrollmentDate);
        const matchFromDate = fromDate ? enrollmentDate >= new Date(fromDate) : true;
        const matchToDate = toDate ? enrollmentDate <= new Date(toDate) : true;
        return matchGroup && matchFromDate && matchToDate;
      }),
      searchText
    );
    return filtered.map((user, index) => {
      const isSelected = !!activeUserData[user._id]?.info?.status;
      return {
        ...user,
        sl_no: index + 1,
        checkBoxs: /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "checkbox",
            checked: isSelected,
            onChange: (e) => {
              setActiveUserData((prev) => ({
                ...prev,
                [user._id]: {
                  info: {
                    status: e.target.checked,
                    userPhone: user.userPhone,
                    groupName: user.groupName,
                    userName: user.userName,
                    paymentsTicket: user.paymentsTicket,
                    groupId: user.groupId,
                    userId: user.userId
                  }
                }
              }));
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
            lineNumber: 351,
            columnNumber: 9
          },
          this
        ),
        isSelected
      };
    });
  }, [usersData, groupFilter, fromDate, toDate, searchText, activeUserData]);
  const visibleSelectedCount = useMemo(
    () => filteredUsers.filter((user) => user.isSelected).length,
    [filteredUsers]
  );
  const sendWhatsapp = async () => {
    const key = "updatable";
    try {
      notifier.open({
        key,
        message: "Sending Messages Via Whatsapp..",
        description: "Processing...",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
      const visibleActiveUsers = {};
      filteredUsers.forEach((user) => {
        if (user.isSelected && activeUserData[user._id]) {
          visibleActiveUsers[user._id] = activeUserData[user._id];
        }
      });
      await api.post("/whatsapp/whatsapp-bid-winner", {
        receivers: visibleActiveUsers,
        winTicket
      });
      const newActiveUserData = { ...activeUserData };
      filteredUsers.forEach((user) => {
        if (user.isSelected) delete newActiveUserData[user._id];
      });
      setActiveUserData(newActiveUserData);
      notifier.open({
        key,
        message: "Whatsapp Messages Sent Successfully",
        description: "Success",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
    } catch (err) {
      notifier.open({
        key,
        message: "Failed to Send Whatsapp",
        description: err.message || "Something went wrong",
        className: "bg-red-300 rounded-lg font-bold",
        duration: 2
      });
    }
  };
  useEffect(() => {
    const allChecked = filteredUsers.length > 0 && filteredUsers.every((user) => activeUserData[user._id]?.info?.status);
    setSelectAll(allChecked);
  }, [filteredUsers, activeUserData]);
  const fetchData = async () => {
    try {
      setIsLoading(true);
      const reportResponse = await api.get("/user/all-customers-report");
      const usersList = [];
      const tempActive = {};
      reportResponse.data.forEach((usrData) => {
        if (usrData?.data) {
          usrData.data.forEach((data) => {
            if (data?.enrollment?.group) {
              const groupId = data.enrollment.group._id;
              const id = data?.enrollment?._id;
              const userPhone = usrData.phone_number;
              const groupName = data.enrollment.group.group_name;
              const userName = usrData.userName;
              const paymentsTicket = data.payments.ticket;
              tempActive[id] = { info: { status: false } };
              usersList.push({
                _id: id,
                userName,
                userPhone,
                customerId: usrData.customer_id,
                groupName,
                paymentsTicket,
                groupId,
                userId: usrData?._id,
                toDate
              });
            }
          });
        }
      });
      setUsersData(usersList);
      setTotalUsers(usersList.length);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);
  const Auctioncolumns = [
    { key: "sl_no", header: "SL. NO" },
    { key: "checkBoxs", header: "Select User" },
    { key: "userName", header: "Customer Name" },
    { key: "userPhone", header: "Phone Number" },
    { key: "customerId", header: "Customer Id" },
    { key: "groupName", header: "Group Name" },
    { key: "paymentsTicket", header: "Ticket" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
        lineNumber: 496,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
      lineNumber: 500,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
        lineNumber: 503,
        columnNumber: 16
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-center mt-2", children: "Auction Bid Winner" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
        lineNumber: 504,
        columnNumber: 13
      }, this),
      contextHolder,
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-start border-b border-gray-300 mb-4" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
          lineNumber: 508,
          columnNumber: 15
        }, this),
        isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-green-600" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
          lineNumber: 511,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
          lineNumber: 510,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-6 mt-8 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Total Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
                  lineNumber: 519,
                  columnNumber: 7
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-violet-700", children: filteredUsers.length }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
                  lineNumber: 520,
                  columnNumber: 7
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
                lineNumber: 518,
                columnNumber: 5
              }, this),
              /* @__PURE__ */ jsxDEV(FaUsers, { className: "text-violet-600 text-4xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
                lineNumber: 524,
                columnNumber: 5
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
              lineNumber: 517,
              columnNumber: 3
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Selected Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
                  lineNumber: 529,
                  columnNumber: 7
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-green-700", children: visibleSelectedCount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
                  lineNumber: 530,
                  columnNumber: 7
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
                lineNumber: 528,
                columnNumber: 5
              }, this),
              /* @__PURE__ */ jsxDEV(FaCheckCircle, { className: "text-green-600 text-4xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
                lineNumber: 534,
                columnNumber: 5
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
              lineNumber: 527,
              columnNumber: 3
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
            lineNumber: 516,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-4 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Select Group" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
                lineNumber: 539,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  style: { width: 200 },
                  allowClear: true,
                  placeholder: "--All groups--",
                  onChange: (value) => setGroupFilter(value),
                  value: groupFilter || void 0,
                  className: "w-full max-w-xs h-11",
                  children: groupOptions.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group, children: group }, group, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
                      lineNumber: 551,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
                  lineNumber: 542,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
              lineNumber: 538,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Auction Won Ticket Number" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
                lineNumber: 559,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  className: "w-full max-w-xs h-11 rounded-md border border-gray-300 px-2",
                  value: winTicket,
                  onChange: (e) => setWinTicket(e.target.value),
                  placeholder: "Enter ticket number"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
                  lineNumber: 562,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
              lineNumber: 558,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-5", children: "Select All" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
                lineNumber: 572,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  className: "ml-4 w-4 h-4 mb-3",
                  checked: selectAll,
                  onChange: (e) => {
                    const checked = e.target.checked;
                    setSelectAll(checked);
                    const updatedData = { ...activeUserData };
                    filteredUsers.forEach((user) => {
                      updatedData[user._id] = {
                        info: {
                          status: checked,
                          userPhone: user.userPhone,
                          groupName: user.groupName,
                          userName: user.userName,
                          groupId: user.groupId,
                          userId: user.userId
                        }
                      };
                    });
                    setActiveUserData(updatedData);
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
                  lineNumber: 575,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
              lineNumber: 571,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
            lineNumber: 537,
            columnNumber: 17
          }, this),
          winTicket.trim() !== "" && visibleSelectedCount > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mb-4", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: sendWhatsapp,
              className: "relative bg-green-600 text-white px-4 py-2 rounded shadow-md hover:bg-green-700 transition duration-200 flex items-center",
              children: [
                visibleSelectedCount > 0 && /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "min-w-6 h-6 absolute -right-3 -top-2 shadow-lg hover:bg-red-600 bg-red-400 rounded-full text-white flex items-center justify-center text-xs",
                    title: `Message will be sent to total ${visibleSelectedCount} customers`,
                    children: /* @__PURE__ */ jsxDEV("span", { children: visibleSelectedCount }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
                      lineNumber: 613,
                      columnNumber: 27
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
                    lineNumber: 609,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "mr-2", size: 20 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
                  lineNumber: 616,
                  columnNumber: 23
                }, this),
                "WhatsApp"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
              lineNumber: 604,
              columnNumber: 21
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
            lineNumber: 603,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: filteredUsers,
              columns: Auctioncolumns,
              catcher: "_id",
              exportedPdfName: "Bid Winner",
              printHeaderKeys: ["Group Name"],
              printHeaderValues: [groupFilter],
              exportedFileName: `Bid Winner.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
              lineNumber: 622,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
          lineNumber: 515,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
        lineNumber: 507,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
      lineNumber: 502,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
    lineNumber: 495,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx",
    lineNumber: 494,
    columnNumber: 5
  }, this);
};
_s(BidWinner, "STVjQxlF6XqnbAitRWotRDtFdII=", false, function() {
  return [notification.useNotification];
});
_c = BidWinner;
export default BidWinner;
var _c;
$RefreshReg$(_c, "BidWinner");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/BidWinner.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOFZVOzJCQTlWVjtBQUFnQkEsTUFBV0MsY0FBVUMsT0FBTyxzQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzRCxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLGNBQWM7QUFDdkIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG9CQUFvQjtBQUM3QixPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLFNBQVNDLHFCQUFxQjtBQUN2QyxPQUFPQyxnQkFBZ0I7QUFpVHZCLE1BQU1DLFlBQVlBLE1BQU07QUFBQUMsS0FBQTtBQUN0QixRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSWpCLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNrQixXQUFXQyxZQUFZLElBQUluQixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDb0IsYUFBYUMsY0FBYyxJQUFJckIsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ3NCLFVBQVVDLFdBQVcsSUFBSXZCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUN3QixRQUFRQyxTQUFTLElBQUl6QixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDMEIsZ0JBQWdCQyxpQkFBaUIsSUFBSTNCLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZELFFBQU0sQ0FBQzRCLFdBQVdDLFlBQVksSUFBSTdCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUM4QixZQUFZQyxhQUFhLElBQUkvQixTQUFTLENBQUM7QUFDOUMsUUFBTSxDQUFDZ0MsVUFBVUMsYUFBYSxJQUFJeEIsYUFBYXlCLGdCQUFnQjtBQUMvRCxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSXBDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNxQyxXQUFXQyxZQUFZLElBQUl0QyxTQUFTLEVBQUU7QUFDN0MsUUFBTXVDLGVBQWUsQ0FBQyxHQUFHLElBQUlDLElBQUl0QixVQUFVdUIsSUFBSSxDQUFDQyxNQUFNQSxFQUFFQyxTQUFTLENBQUMsQ0FBQztBQUVuRSxRQUFNQyxnQkFBZ0IzQyxRQUFRLE1BQU07QUFDbEMsVUFBTTRDLFdBQVd0QztBQUFBQSxNQUNmVyxVQUFVNEIsT0FBTyxDQUFDSixNQUFNO0FBQ3RCLGNBQU1LLGFBQWEzQixjQUFjc0IsRUFBRUMsY0FBY3ZCLGNBQWM7QUFDL0QsY0FBTTRCLGlCQUFpQixJQUFJQyxLQUFLUCxFQUFFTSxjQUFjO0FBQ2hELGNBQU1FLGdCQUFnQjVCLFdBQ2xCMEIsa0JBQWtCLElBQUlDLEtBQUszQixRQUFRLElBQ25DO0FBQ0osY0FBTTZCLGNBQWMzQixTQUFTd0Isa0JBQWtCLElBQUlDLEtBQUt6QixNQUFNLElBQUk7QUFDbEUsZUFBT3VCLGNBQWNHLGlCQUFpQkM7QUFBQUEsTUFDeEMsQ0FBQztBQUFBLE1BQ0RuQztBQUFBQSxJQUNGO0FBRUEsV0FBTzZCLFNBQVNKLElBQUksQ0FBQ1csTUFBTUMsVUFBVTtBQUNuQyxZQUFNQyxhQUFhLENBQUMsQ0FBQzVCLGVBQWUwQixLQUFLRyxHQUFHLEdBQUdDLE1BQU1DO0FBQ3JELGFBQU87QUFBQSxRQUNMLEdBQUdMO0FBQUFBLFFBQ0hNLE9BQU9MLFFBQVE7QUFBQSxRQUNmTSxXQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxTQUFTTDtBQUFBQSxZQUNULFVBQVUsQ0FBQ00sTUFBTTtBQUNmakMsZ0NBQWtCLENBQUNrQyxVQUFVO0FBQUEsZ0JBQzNCLEdBQUdBO0FBQUFBLGdCQUNILENBQUNULEtBQUtHLEdBQUcsR0FBRztBQUFBLGtCQUNWQyxNQUFNO0FBQUEsb0JBQ0pDLFFBQVFHLEVBQUVFLE9BQU9DO0FBQUFBLG9CQUNqQkMsV0FBV1osS0FBS1k7QUFBQUEsb0JBQ2hCckIsV0FBV1MsS0FBS1Q7QUFBQUEsb0JBQ2hCc0IsVUFBVWIsS0FBS2E7QUFBQUEsb0JBQ2ZDLGdCQUFnQmQsS0FBS2M7QUFBQUEsb0JBQ3JCQyxTQUFTZixLQUFLZTtBQUFBQSxvQkFDZEMsUUFBUWhCLEtBQUtnQjtBQUFBQSxrQkFDZjtBQUFBLGdCQUNGO0FBQUEsY0FDRixFQUFFO0FBQUEsWUFDSjtBQUFBO0FBQUEsVUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBa0JJO0FBQUEsUUFHTmQ7QUFBQUEsTUFDRjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDcEMsV0FBV0UsYUFBYUUsVUFBVUUsUUFBUVIsWUFBWVUsY0FBYyxDQUFDO0FBRXpFLFFBQU0yQyx1QkFBdUJwRTtBQUFBQSxJQUMzQixNQUFNMkMsY0FBY0UsT0FBTyxDQUFDTSxTQUFTQSxLQUFLRSxVQUFVLEVBQUVnQjtBQUFBQSxJQUN0RCxDQUFDMUIsYUFBYTtBQUFBLEVBQ2hCO0FBRUEsUUFBTTJCLGVBQWUsWUFBWTtBQUMvQixVQUFNQyxNQUFNO0FBQ1osUUFBSTtBQUNGeEMsZUFBU3lDLEtBQUs7QUFBQSxRQUNaRDtBQUFBQSxRQUNBRSxTQUFTO0FBQUEsUUFDVEMsYUFBYTtBQUFBLFFBQ2JDLFdBQVc7QUFBQSxRQUNYQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBRUQsWUFBTUMscUJBQXFCLENBQUM7QUFDNUJsQyxvQkFBY21DLFFBQVEsQ0FBQzNCLFNBQVM7QUFDOUIsWUFBSUEsS0FBS0UsY0FBYzVCLGVBQWUwQixLQUFLRyxHQUFHLEdBQUc7QUFDL0N1Qiw2QkFBbUIxQixLQUFLRyxHQUFHLElBQUk3QixlQUFlMEIsS0FBS0csR0FBRztBQUFBLFFBQ3hEO0FBQUEsTUFDRixDQUFDO0FBRUQsWUFBTXJELElBQUk4RSxLQUFLLGlDQUFpQztBQUFBLFFBQzlDQyxXQUFXSDtBQUFBQSxRQUNYekM7QUFBQUEsTUFDRixDQUFDO0FBRUQsWUFBTTZDLG9CQUFvQixFQUFFLEdBQUd4RCxlQUFlO0FBQzlDa0Isb0JBQWNtQyxRQUFRLENBQUMzQixTQUFTO0FBQzlCLFlBQUlBLEtBQUtFLFdBQVksUUFBTzRCLGtCQUFrQjlCLEtBQUtHLEdBQUc7QUFBQSxNQUN4RCxDQUFDO0FBQ0Q1Qix3QkFBa0J1RCxpQkFBaUI7QUFFbkNsRCxlQUFTeUMsS0FBSztBQUFBLFFBQ1pEO0FBQUFBLFFBQ0FFLFNBQVM7QUFBQSxRQUNUQyxhQUFhO0FBQUEsUUFDYkMsV0FBVztBQUFBLFFBQ1hDLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFBQSxJQUNILFNBQVNNLEtBQUs7QUFDWm5ELGVBQVN5QyxLQUFLO0FBQUEsUUFDWkQ7QUFBQUEsUUFDQUUsU0FBUztBQUFBLFFBQ1RDLGFBQWFRLElBQUlULFdBQVc7QUFBQSxRQUM1QkUsV0FBVztBQUFBLFFBQ1hDLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBOUUsWUFBVSxNQUFNO0FBQ2QsVUFBTXFGLGFBQ0p4QyxjQUFjMEIsU0FBUyxLQUN2QjFCLGNBQWN5QyxNQUFNLENBQUNqQyxTQUFTMUIsZUFBZTBCLEtBQUtHLEdBQUcsR0FBR0MsTUFBTUMsTUFBTTtBQUN0RXJCLGlCQUFhZ0QsVUFBVTtBQUFBLEVBQ3pCLEdBQUcsQ0FBQ3hDLGVBQWVsQixjQUFjLENBQUM7QUFFbEMsUUFBTTRELFlBQVksWUFBWTtBQUM1QixRQUFJO0FBQ0Z6RCxtQkFBYSxJQUFJO0FBQ2pCLFlBQU0wRCxpQkFBaUIsTUFBTXJGLElBQUlzRixJQUFJLDRCQUE0QjtBQUNqRSxZQUFNQyxZQUFZO0FBQ2xCLFlBQU1DLGFBQWEsQ0FBQztBQUVwQkgscUJBQWVJLEtBQUtaLFFBQVEsQ0FBQ2EsWUFBWTtBQUN2QyxZQUFJQSxTQUFTRCxNQUFNO0FBQ2pCQyxrQkFBUUQsS0FBS1osUUFBUSxDQUFDWSxTQUFTO0FBQzdCLGdCQUFJQSxNQUFNRSxZQUFZQyxPQUFPO0FBQzNCLG9CQUFNM0IsVUFBVXdCLEtBQUtFLFdBQVdDLE1BQU12QztBQUN0QyxvQkFBTXdDLEtBQUtKLE1BQU1FLFlBQVl0QztBQUM3QixvQkFBTVMsWUFBWTRCLFFBQVFJO0FBQzFCLG9CQUFNckQsWUFBWWdELEtBQUtFLFdBQVdDLE1BQU1HO0FBQ3hDLG9CQUFNaEMsV0FBVzJCLFFBQVEzQjtBQUN6QixvQkFBTUMsaUJBQWlCeUIsS0FBS08sU0FBU0M7QUFDckNULHlCQUFXSyxFQUFFLElBQUksRUFBRXZDLE1BQU0sRUFBRUMsUUFBUSxNQUFNLEVBQUU7QUFDM0NnQyx3QkFBVVcsS0FBSztBQUFBLGdCQUNiN0MsS0FBS3dDO0FBQUFBLGdCQUNMOUI7QUFBQUEsZ0JBQ0FEO0FBQUFBLGdCQUNBcUMsWUFBWVQsUUFBUVU7QUFBQUEsZ0JBQ3BCM0Q7QUFBQUEsZ0JBQ0F1QjtBQUFBQSxnQkFDQUM7QUFBQUEsZ0JBQ0FDLFFBQVF3QixTQUFTckM7QUFBQUEsZ0JBQ2pCL0I7QUFBQUEsY0FDRixDQUFDO0FBQUEsWUFDSDtBQUFBLFVBQ0YsQ0FBQztBQUFBLFFBQ0g7QUFBQSxNQUNGLENBQUM7QUFFREwsbUJBQWFzRSxTQUFTO0FBQ3RCMUQsb0JBQWMwRCxVQUFVbkIsTUFBTTtBQUFBLElBQ2hDLFNBQVNpQyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sd0JBQXdCQSxLQUFLO0FBQUEsSUFDN0MsVUFBQztBQUNDMUUsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBOUIsWUFBVSxNQUFNO0FBQ2R1RixjQUFVO0FBQUEsRUFDWixHQUFHLEVBQUU7QUFFTCxRQUFNbUIsaUJBQWlCO0FBQUEsSUFDckIsRUFBRWpDLEtBQUssU0FBU2tDLFFBQVEsU0FBUztBQUFBLElBQ2pDLEVBQUVsQyxLQUFLLGFBQWFrQyxRQUFRLGNBQWM7QUFBQSxJQUMxQyxFQUFFbEMsS0FBSyxZQUFZa0MsUUFBUSxnQkFBZ0I7QUFBQSxJQUMzQyxFQUFFbEMsS0FBSyxhQUFha0MsUUFBUSxlQUFlO0FBQUEsSUFDM0MsRUFBRWxDLEtBQUssY0FBY2tDLFFBQVEsY0FBYztBQUFBLElBQzNDLEVBQUVsQyxLQUFLLGFBQWFrQyxRQUFRLGFBQWE7QUFBQSxJQUN6QyxFQUFFbEMsS0FBSyxrQkFBa0JrQyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBRzdDLFNBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ1gsaUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsNkJBQTZCLENBQUM5QyxNQUFNM0MsY0FBYzJDLEVBQUVFLE9BQU82QyxLQUFLO0FBQUEsUUFDaEUsWUFBWTtBQUFBO0FBQUEsTUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFbUI7QUFBQSxJQUVuQix1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUTtBQUFBLElBRU4sdUJBQUMsU0FBSSxXQUFVLGlCQUNWO0FBQUEsNkJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFXO0FBQUEsTUFDZCx1QkFBQyxRQUFHLFdBQVUsdUNBQXNDLGtDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNFO0FBQUEsTUFFckUxRTtBQUFBQSxNQUNELHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHNEQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0U7QUFBQSxRQUNoRUwsWUFDTix1QkFBQyxTQUFJLFdBQVUsVUFDYixpQ0FBQyxrQkFBZSxPQUFNLG9CQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNDLEtBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUdJLHVCQUFDLFNBQUksV0FBVSxTQUNEO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG1EQUN6QztBQUFBLG1DQUFDLFNBQUksV0FBVSx5RUFDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxPQUFFLFdBQVUseUJBQXdCLCtCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRDtBQUFBLGdCQUNwRCx1QkFBQyxPQUFFLFdBQVUsc0NBQ1ZnQix3QkFBYzBCLFVBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxXQUFRLFdBQVUsOEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZDO0FBQUEsaUJBUC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSx3RUFDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxPQUFFLFdBQVUseUJBQXdCLGtDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RDtBQUFBLGdCQUN2RCx1QkFBQyxPQUFFLFdBQVUscUNBQ1ZELGtDQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxpQkFBYyxXQUFVLDZCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRDtBQUFBLGlCQVBwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUFuQjBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0I1QjtBQUFBLFVBQ2dCLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPLEVBQUV1QyxPQUFPLElBQUk7QUFBQSxrQkFDcEI7QUFBQSxrQkFDQSxhQUFZO0FBQUEsa0JBQ1osVUFBVSxDQUFDRCxVQUFVdEYsZUFBZXNGLEtBQUs7QUFBQSxrQkFDekMsT0FBT3ZGLGVBQWV5RjtBQUFBQSxrQkFDdEIsV0FBVTtBQUFBLGtCQUVUdEUsdUJBQWFFO0FBQUFBLG9CQUFJLENBQUNxRCxVQUNqQix1QkFBQyxPQUFPLFFBQVAsRUFBMEIsT0FBT0EsT0FDL0JBLG1CQURpQkEsT0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFaSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FhQTtBQUFBLGlCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtCQTtBQUFBLFlBRUEsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0MseUNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsT0FBT3pEO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQ3VCLE1BQU10QixhQUFhc0IsRUFBRUUsT0FBTzZDLEtBQUs7QUFBQSxrQkFDNUMsYUFBWTtBQUFBO0FBQUEsZ0JBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS21DO0FBQUEsaUJBVHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxZQUVBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDBCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLFNBQVN4RTtBQUFBQSxrQkFDVCxVQUFVLENBQUN5QixNQUFNO0FBQ2YsMEJBQU1HLFVBQVVILEVBQUVFLE9BQU9DO0FBQ3pCM0IsaUNBQWEyQixPQUFPO0FBQ3BCLDBCQUFNK0MsY0FBYyxFQUFFLEdBQUdwRixlQUFlO0FBQ3hDa0Isa0NBQWNtQyxRQUFRLENBQUMzQixTQUFTO0FBQzlCMEQsa0NBQVkxRCxLQUFLRyxHQUFHLElBQUk7QUFBQSx3QkFDdEJDLE1BQU07QUFBQSwwQkFDSkMsUUFBUU07QUFBQUEsMEJBQ1JDLFdBQVdaLEtBQUtZO0FBQUFBLDBCQUNoQnJCLFdBQVdTLEtBQUtUO0FBQUFBLDBCQUNoQnNCLFVBQVViLEtBQUthO0FBQUFBLDBCQUNmRSxTQUFTZixLQUFLZTtBQUFBQSwwQkFDZEMsUUFBUWhCLEtBQUtnQjtBQUFBQSx3QkFDZjtBQUFBLHNCQUNGO0FBQUEsb0JBQ0YsQ0FBQztBQUNEekMsc0NBQWtCbUYsV0FBVztBQUFBLGtCQUMvQjtBQUFBO0FBQUEsZ0JBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXFCSTtBQUFBLGlCQXpCTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJCQTtBQUFBLGVBN0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBOERBO0FBQUEsVUFHQ3pFLFVBQVUwRSxLQUFLLE1BQU0sTUFBTTFDLHVCQUF1QixLQUNqRCx1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVNFO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBRVRGO0FBQUFBLHVDQUF1QixLQUN0QjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsT0FBTyxpQ0FBaUNBLG9CQUFvQjtBQUFBLG9CQUU1RCxpQ0FBQyxVQUFNQSxrQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE0QjtBQUFBO0FBQUEsa0JBSjlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUVGLHVCQUFDLGNBQVcsV0FBVSxRQUFPLE1BQU0sTUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0M7QUFBQSxnQkFBRztBQUFBO0FBQUE7QUFBQSxZQVozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFjQSxLQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBO0FBQUEsVUFHRjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTXpCO0FBQUFBLGNBQ04sU0FBUzZEO0FBQUFBLGNBQ1QsU0FBUTtBQUFBLGNBQ1IsaUJBQWdCO0FBQUEsY0FDaEIsaUJBQWlCLENBQUMsWUFBWTtBQUFBLGNBQzlCLG1CQUFtQixDQUFDckYsV0FBVztBQUFBLGNBQy9CLGtCQUFrQjtBQUFBO0FBQUEsWUFQcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT3FDO0FBQUEsYUFsSHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvSEE7QUFBQSxXQTVIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOEhBO0FBQUEsU0FuSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9JQTtBQUFBLE9BM0lKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2SUEsS0E5SUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStJRTtBQUVKO0FBQUVMLEdBbFVJRCxXQUFTO0FBQUEsVUFTcUJMLGFBQWF5QixlQUFlO0FBQUE7QUFBQThFLEtBVDFEbEc7QUFvVU4sZUFBZUE7QUFBVSxJQUFBa0c7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlTWVtbyIsImFwaSIsIkRhdGFUYWJsZSIsIkNpcmN1bGFyTG9hZGVyIiwiU2VsZWN0IiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwiRmFXaGF0c2FwcCIsIm5vdGlmaWNhdGlvbiIsIlNpZGViYXIiLCJGYVVzZXJzIiwiRmFDaGVja0NpcmNsZSIsIkJyZWFkY3J1bWIiLCJCaWRXaW5uZXIiLCJfcyIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwidXNlcnNEYXRhIiwic2V0VXNlcnNEYXRhIiwiZ3JvdXBGaWx0ZXIiLCJzZXRHcm91cEZpbHRlciIsImZyb21EYXRlIiwic2V0RnJvbURhdGUiLCJ0b0RhdGUiLCJzZXRUb0RhdGUiLCJhY3RpdmVVc2VyRGF0YSIsInNldEFjdGl2ZVVzZXJEYXRhIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwidG90YWxVc2VycyIsInNldFRvdGFsVXNlcnMiLCJub3RpZmllciIsImNvbnRleHRIb2xkZXIiLCJ1c2VOb3RpZmljYXRpb24iLCJzZWxlY3RBbGwiLCJzZXRTZWxlY3RBbGwiLCJ3aW5UaWNrZXQiLCJzZXRXaW5UaWNrZXQiLCJncm91cE9wdGlvbnMiLCJTZXQiLCJtYXAiLCJ1IiwiZ3JvdXBOYW1lIiwiZmlsdGVyZWRVc2VycyIsImZpbHRlcmVkIiwiZmlsdGVyIiwibWF0Y2hHcm91cCIsImVucm9sbG1lbnREYXRlIiwiRGF0ZSIsIm1hdGNoRnJvbURhdGUiLCJtYXRjaFRvRGF0ZSIsInVzZXIiLCJpbmRleCIsImlzU2VsZWN0ZWQiLCJfaWQiLCJpbmZvIiwic3RhdHVzIiwic2xfbm8iLCJjaGVja0JveHMiLCJlIiwicHJldiIsInRhcmdldCIsImNoZWNrZWQiLCJ1c2VyUGhvbmUiLCJ1c2VyTmFtZSIsInBheW1lbnRzVGlja2V0IiwiZ3JvdXBJZCIsInVzZXJJZCIsInZpc2libGVTZWxlY3RlZENvdW50IiwibGVuZ3RoIiwic2VuZFdoYXRzYXBwIiwia2V5Iiwib3BlbiIsIm1lc3NhZ2UiLCJkZXNjcmlwdGlvbiIsImNsYXNzTmFtZSIsImR1cmF0aW9uIiwidmlzaWJsZUFjdGl2ZVVzZXJzIiwiZm9yRWFjaCIsInBvc3QiLCJyZWNlaXZlcnMiLCJuZXdBY3RpdmVVc2VyRGF0YSIsImVyciIsImFsbENoZWNrZWQiLCJldmVyeSIsImZldGNoRGF0YSIsInJlcG9ydFJlc3BvbnNlIiwiZ2V0IiwidXNlcnNMaXN0IiwidGVtcEFjdGl2ZSIsImRhdGEiLCJ1c3JEYXRhIiwiZW5yb2xsbWVudCIsImdyb3VwIiwiaWQiLCJwaG9uZV9udW1iZXIiLCJncm91cF9uYW1lIiwicGF5bWVudHMiLCJ0aWNrZXQiLCJwdXNoIiwiY3VzdG9tZXJJZCIsImN1c3RvbWVyX2lkIiwiZXJyb3IiLCJjb25zb2xlIiwiQXVjdGlvbmNvbHVtbnMiLCJoZWFkZXIiLCJ2YWx1ZSIsIndpZHRoIiwidW5kZWZpbmVkIiwidXBkYXRlZERhdGEiLCJ0cmltIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQmlkV2lubmVyLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlTWVtbyB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgU2VsZWN0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgeyBGYVdoYXRzYXBwIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IG5vdGlmaWNhdGlvbiB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgeyBGYVVzZXJzLCBGYUNoZWNrQ2lyY2xlIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuXHJcblxyXG4vLyBjb25zdCBCaWRXaW5uZXIgPSAoKSA9PiB7XHJcbi8vICAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbi8vICAgY29uc3QgW3VzZXJzRGF0YSwgc2V0VXNlcnNEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbZ3JvdXBGaWx0ZXIsIHNldEdyb3VwRmlsdGVyXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFtmcm9tRGF0ZSwgc2V0RnJvbURhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbi8vICAgY29uc3QgW3RvRGF0ZSwgc2V0VG9EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFthY3RpdmVVc2VyRGF0YSwgc2V0QWN0aXZlVXNlckRhdGFdID0gdXNlU3RhdGUoe30pO1xyXG4vLyAgIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW3RvdGFsVXNlcnMsIHNldFRvdGFsVXNlcnNdID0gdXNlU3RhdGUoMCk7XHJcbi8vICAgY29uc3QgW25vdGlmaWVyLCBjb250ZXh0SG9sZGVyXSA9IG5vdGlmaWNhdGlvbi51c2VOb3RpZmljYXRpb24oKTtcclxuLy8gICBjb25zdCBbc2VsZWN0QWxsLCBzZXRTZWxlY3RBbGxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFt3aW5UaWNrZXQsIHNldFdpblRpY2tldF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBncm91cE9wdGlvbnMgPSBbLi4ubmV3IFNldCh1c2Vyc0RhdGEubWFwKCh1KSA9PiB1Lmdyb3VwTmFtZSkpXTtcclxuXHJcbi8vICAgY29uc3QgZmlsdGVyZWRVc2VycyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgZmlsdGVyZWQgPSBmaWx0ZXJPcHRpb24oXHJcbi8vICAgICAgIHVzZXJzRGF0YS5maWx0ZXIoKHUpID0+IHtcclxuLy8gICAgICAgICBjb25zdCBtYXRjaEdyb3VwID0gZ3JvdXBGaWx0ZXIgPyB1Lmdyb3VwTmFtZSA9PT0gZ3JvdXBGaWx0ZXIgOiB0cnVlO1xyXG4vLyAgICAgICAgIGNvbnN0IGVucm9sbG1lbnREYXRlID0gbmV3IERhdGUodS5lbnJvbGxtZW50RGF0ZSk7XHJcbi8vICAgICAgICAgY29uc3QgbWF0Y2hGcm9tRGF0ZSA9IGZyb21EYXRlXHJcbi8vICAgICAgICAgICA/IGVucm9sbG1lbnREYXRlID49IG5ldyBEYXRlKGZyb21EYXRlKVxyXG4vLyAgICAgICAgICAgOiB0cnVlO1xyXG4vLyAgICAgICAgIGNvbnN0IG1hdGNoVG9EYXRlID0gdG9EYXRlID8gZW5yb2xsbWVudERhdGUgPD0gbmV3IERhdGUodG9EYXRlKSA6IHRydWU7XHJcbi8vICAgICAgICAgcmV0dXJuIG1hdGNoR3JvdXAgJiYgbWF0Y2hGcm9tRGF0ZSAmJiBtYXRjaFRvRGF0ZTtcclxuLy8gICAgICAgfSksXHJcbi8vICAgICAgIHNlYXJjaFRleHRcclxuLy8gICAgICk7XHJcblxyXG4vLyAgICAgcmV0dXJuIGZpbHRlcmVkLm1hcCgodXNlciwgaW5kZXgpID0+IHtcclxuLy8gICAgICAgY29uc3QgaXNTZWxlY3RlZCA9ICEhYWN0aXZlVXNlckRhdGFbdXNlci5faWRdPy5pbmZvPy5zdGF0dXM7XHJcblxyXG4vLyAgICAgICByZXR1cm4ge1xyXG4vLyAgICAgICAgIC4uLnVzZXIsXHJcbi8vICAgICAgICAgc2xfbm86IGluZGV4ICsgMSxcclxuLy8gICAgICAgICBjaGVja0JveHM6IChcclxuLy8gICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4vLyAgICAgICAgICAgICBjaGVja2VkPXtpc1NlbGVjdGVkfVxyXG4vLyAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuLy8gICAgICAgICAgICAgICBzZXRBY3RpdmVVc2VyRGF0YSgocHJldikgPT4gKHtcclxuLy8gICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbi8vICAgICAgICAgICAgICAgICBbdXNlci5faWRdOiB7XHJcbi8vICAgICAgICAgICAgICAgICAgIGluZm86IHtcclxuLy8gICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgdXNlclBob25lOiB1c2VyLnVzZXJQaG9uZSxcclxuLy8gICAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHVzZXJOYW1lOiB1c2VyLnVzZXJOYW1lLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHBheW1lbnRzVGlja2V0OiB1c2VyLnBheW1lbnRzVGlja2V0LFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGdyb3VwSWQ6IHVzZXIuZ3JvdXBJZCxcclxuLy8gICAgICAgICAgICAgICAgICAgICB1c2VySWQ6IHVzZXIudXNlcklkLFxyXG4vLyAgICAgICAgICAgICAgICAgICB9LFxyXG4vLyAgICAgICAgICAgICAgICAgfSxcclxuLy8gICAgICAgICAgICAgICB9KSk7XHJcbi8vICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICksXHJcbi8vICAgICAgICAgaXNTZWxlY3RlZCxcclxuLy8gICAgICAgfTtcclxuLy8gICAgIH0pO1xyXG4vLyAgIH0sIFt1c2Vyc0RhdGEsIGdyb3VwRmlsdGVyLCBmcm9tRGF0ZSwgdG9EYXRlLCBzZWFyY2hUZXh0LCBhY3RpdmVVc2VyRGF0YV0pO1xyXG5cclxuLy8gICBjb25zdCB2aXNpYmxlU2VsZWN0ZWRDb3VudCA9IHVzZU1lbW8oKCkgPT4ge1xyXG4vLyAgICAgcmV0dXJuIGZpbHRlcmVkVXNlcnMuZmlsdGVyKCh1c2VyKSA9PiB1c2VyLmlzU2VsZWN0ZWQpLmxlbmd0aDtcclxuLy8gICB9LCBbZmlsdGVyZWRVc2Vyc10pO1xyXG5cclxuLy8gICBjb25zdCBzZW5kV2hhdHNhcHAgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICBjb25zdCBrZXkgPSBcInVwZGF0YWJsZVwiO1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgbm90aWZpZXIub3Blbih7XHJcbi8vICAgICAgICAga2V5LFxyXG4vLyAgICAgICAgIG1lc3NhZ2U6IFwiU2VuZGluZyBNZXNzYWdlcyBWaWEgV2hhdHNhcHAuLlwiLFxyXG4vLyAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlByb2Nlc3NpbmcuLi5cIixcclxuLy8gICAgICAgICBjbGFzc05hbWU6IFwiYmctZ3JlZW4tMzAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbi8vICAgICAgICAgZHVyYXRpb246IDIsXHJcbi8vICAgICAgIH0pO1xyXG5cclxuLy8gICAgICAgY29uc3QgdmlzaWJsZUFjdGl2ZVVzZXJzID0ge307XHJcbi8vICAgICAgIGZpbHRlcmVkVXNlcnMuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4vLyAgICAgICAgIGlmICh1c2VyLmlzU2VsZWN0ZWQgJiYgYWN0aXZlVXNlckRhdGFbdXNlci5faWRdKSB7XHJcbi8vICAgICAgICAgICB2aXNpYmxlQWN0aXZlVXNlcnNbdXNlci5faWRdID0gYWN0aXZlVXNlckRhdGFbdXNlci5faWRdO1xyXG4vLyAgICAgICAgIH1cclxuLy8gICAgICAgfSk7XHJcblxyXG4vLyAgICAgICBhd2FpdCBhcGkucG9zdChcIi93aGF0c2FwcC93aGF0c2FwcC1iaWQtd2lubmVyXCIsIHtcclxuLy8gICByZWNlaXZlcnM6IHZpc2libGVBY3RpdmVVc2VycyxcclxuLy8gICB3aW5UaWNrZXQ6IHdpblRpY2tldCxcclxuLy8gfSk7XHJcblxyXG4vLyAgICAgICBjb25zdCBuZXdBY3RpdmVVc2VyRGF0YSA9IHsgLi4uYWN0aXZlVXNlckRhdGEgfTtcclxuLy8gICAgICAgZmlsdGVyZWRVc2Vycy5mb3JFYWNoKCh1c2VyKSA9PiB7XHJcbi8vICAgICAgICAgaWYgKHVzZXIuaXNTZWxlY3RlZCkge1xyXG4vLyAgICAgICAgICAgZGVsZXRlIG5ld0FjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXTtcclxuLy8gICAgICAgICB9XHJcbi8vICAgICAgIH0pO1xyXG4vLyAgICAgICBzZXRBY3RpdmVVc2VyRGF0YShuZXdBY3RpdmVVc2VyRGF0YSk7XHJcblxyXG4vLyAgICAgICBub3RpZmllci5vcGVuKHtcclxuLy8gICAgICAgICBrZXksXHJcbi8vICAgICAgICAgbWVzc2FnZTogXCJXaGF0c2FwcCBNZXNzYWdlcyBIYXMgQmVlbiBTZW50IFN1Y2Nlc3NmdWxseVwiLFxyXG4vLyAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlN1Y2Nlc3NcIixcclxuLy8gICAgICAgICBjbGFzc05hbWU6IFwiYmctZ3JlZW4tMzAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbi8vICAgICAgICAgZHVyYXRpb246IDIsXHJcbi8vICAgICAgIH0pO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbi8vICAgICAgIG5vdGlmaWVyLm9wZW4oe1xyXG4vLyAgICAgICAgIGtleSxcclxuLy8gICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBTZW5kIFdoYXRzYXBwXCIsXHJcbi8vICAgICAgICAgZGVzY3JpcHRpb246IGVyci5tZXNzYWdlIHx8IFwiU29tZXRoaW5nIHdlbnQgd3JvbmdcIixcclxuLy8gICAgICAgICBjbGFzc05hbWU6IFwiYmctcmVkLTMwMCByb3VuZGVkLWxnIGZvbnQtYm9sZFwiLFxyXG4vLyAgICAgICAgIGR1cmF0aW9uOiAyLFxyXG4vLyAgICAgICB9KTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICAvLyBBdXRvbWF0aWNhbGx5IHVwZGF0ZSBzZWxlY3RBbGwgYmFzZWQgb24gZmlsdGVyZWRVc2Vyc1xyXG4vLyAgICAgY29uc3QgYWxsQ2hlY2tlZCA9XHJcbi8vICAgICAgIGZpbHRlcmVkVXNlcnMubGVuZ3RoID4gMCAmJlxyXG4vLyAgICAgICBmaWx0ZXJlZFVzZXJzLmV2ZXJ5KCh1c2VyKSA9PiBhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF0/LmluZm8/LnN0YXR1cyk7XHJcbi8vICAgICBzZXRTZWxlY3RBbGwoYWxsQ2hlY2tlZCk7XHJcbi8vICAgfSwgW2ZpbHRlcmVkVXNlcnMsIGFjdGl2ZVVzZXJEYXRhXSk7XHJcbi8vICAgY29uc3QgZmV0Y2hEYXRhID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4vLyAgICAgICBjb25zdCByZXBvcnRSZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9hbGwtY3VzdG9tZXJzLXJlcG9ydFwiKTtcclxuLy8gICAgICAgY29uc3QgdXNlcnNMaXN0ID0gW107XHJcbi8vICAgICAgIGNvbnN0IHRlbXBBY3RpdmUgPSB7fTtcclxuXHJcbi8vICAgICAgIHJlcG9ydFJlc3BvbnNlLmRhdGEuZm9yRWFjaCgodXNyRGF0YSkgPT4ge1xyXG4vLyAgICAgICAgIGlmICh1c3JEYXRhPy5kYXRhKSB7XHJcbi8vICAgICAgICAgICB1c3JEYXRhLmRhdGEuZm9yRWFjaCgoZGF0YSkgPT4ge1xyXG4vLyAgICAgICAgICAgICBpZiAoZGF0YT8uZW5yb2xsbWVudD8uZ3JvdXApIHtcclxuLy8gICAgICAgICAgICAgICBjb25zdCBncm91cElkID0gZGF0YS5lbnJvbGxtZW50Lmdyb3VwLl9pZDtcclxuLy8gICAgICAgICAgICAgICBjb25zdCBpZCA9IGRhdGE/LmVucm9sbG1lbnQ/Ll9pZDtcclxuLy8gICAgICAgICAgICAgICBjb25zdCB1c2VyUGhvbmUgPSB1c3JEYXRhLnBob25lX251bWJlcjtcclxuLy8gICAgICAgICAgICAgICBjb25zdCBncm91cE5hbWUgPSBkYXRhLmVucm9sbG1lbnQuZ3JvdXAuZ3JvdXBfbmFtZTtcclxuLy8gICAgICAgICAgICAgICBjb25zdCB1c2VyTmFtZSA9IHVzckRhdGEudXNlck5hbWU7XHJcbi8vICAgICAgICAgICAgICAgY29uc3QgcGF5bWVudHNUaWNrZXQgPSBkYXRhLnBheW1lbnRzLnRpY2tldDtcclxuLy8gICAgICAgICAgICAgICB0ZW1wQWN0aXZlW2lkXSA9IHtcclxuLy8gICAgICAgICAgICAgICAgIGluZm86IHtcclxuLy8gICAgICAgICAgICAgICAgICAgc3RhdHVzOiBmYWxzZSxcclxuLy8gICAgICAgICAgICAgICAgIH0sXHJcbi8vICAgICAgICAgICAgICAgfTtcclxuXHJcbi8vICAgICAgICAgICAgICAgY29uc3QgdGVtcFVzciA9IHtcclxuLy8gICAgICAgICAgICAgICAgIF9pZDogaWQsXHJcbi8vICAgICAgICAgICAgICAgICB1c2VyTmFtZSxcclxuLy8gICAgICAgICAgICAgICAgIHVzZXJQaG9uZSxcclxuLy8gICAgICAgICAgICAgICAgIGN1c3RvbWVySWQ6IHVzckRhdGEuY3VzdG9tZXJfaWQsXHJcbi8vICAgICAgICAgICAgICAgICBncm91cE5hbWUsXHJcbi8vICAgICAgICAgICAgICAgICBwYXltZW50c1RpY2tldCxcclxuLy8gICAgICAgICAgICAgICAgIGdyb3VwSWQ6IGdyb3VwSWQsXHJcbi8vICAgICAgICAgICAgICAgICB1c2VySWQ6IHVzckRhdGE/Ll9pZCxcclxuLy8gICAgICAgICAgICAgICAgIHRvRGF0ZTogdG9EYXRlLFxyXG4vLyAgICAgICAgICAgICAgIH07XHJcbi8vICAgICAgICAgICAgICAgdXNlcnNMaXN0LnB1c2godGVtcFVzcik7XHJcbi8vICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgIH0pO1xyXG4vLyAgICAgICAgIH1cclxuLy8gICAgICAgfSk7XHJcblxyXG4vLyAgICAgICBzZXRVc2Vyc0RhdGEodXNlcnNMaXN0KTtcclxuLy8gICAgICAgc2V0VG90YWxVc2Vycyh1c2Vyc0xpc3QubGVuZ3RoKTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBkYXRhOlwiLCBlcnJvcik7XHJcbi8vICAgICB9IGZpbmFsbHkge1xyXG4vLyAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBmZXRjaERhdGEoKTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIGNvbnN0IEF1Y3Rpb25jb2x1bW5zID0gW1xyXG4vLyAgICAgeyBrZXk6IFwic2xfbm9cIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbi8vICAgICB7IGtleTogXCJjaGVja0JveHNcIiwgaGVhZGVyOiBcIlNlbGVjdCBVc2VyXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInVzZXJOYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInVzZXJQaG9uZVwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImN1c3RvbWVySWRcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIElkXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImdyb3VwTmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbi8vICAgICB7a2V5OiBcInBheW1lbnRzVGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIn0sXHJcbi8vICAgXTtcclxuXHJcbi8vICAgcmV0dXJuIChcclxuLy8gICAgIDxkaXYgY2xhc3NOYW1lPVwidy1zY3JlZW5cIj5cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTMwXCI+XHJcbi8vICAgICAgICAgPE5hdmJhclxyXG4vLyAgICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXsoZSkgPT4gc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4vLyAgICAgICAgIC8+XHJcbi8vICAgICAgICAge2lzTG9hZGluZyA/IChcclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbi8vICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBjb2xvcj1cInRleHQtZ3JlZW4tNjAwXCIgLz5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuLy8gICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWNlbnRlclwiPlxyXG4vLyAgICAgICAgICAgICAgIEF1Y3Rpb24gQmlkIFdpbm5lclxyXG4vLyAgICAgICAgICAgICA8L2gxPlxyXG4vLyAgICAgICAgICAgICB7Y29udGV4dEhvbGRlcn1cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLThcIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1zdGFydCBib3JkZXItYiBib3JkZXItZ3JheS0zMDAgbWItNFwiPjwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTBcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC00IG1iLTZcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBHcm91cFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDIwMCB9fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCItLUFsbCBncm91cHMtLVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBzZXRHcm91cEZpbHRlcih2YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXBGaWx0ZXIgfHwgdW5kZWZpbmVkfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LXhzIGgtMTEgXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXBPcHRpb25zLm1hcCgoZ3JvdXApID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtncm91cH0gdmFsdWU9e2dyb3VwfT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgQXVjdGlvbiBXb24gVGlja2V0IE51bWJlclxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXcteHMgaC0xMSByb3VuZGVkLW1kXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt3aW5UaWNrZXR9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFdpblRpY2tldChlLnRhcmdldC52YWx1ZSl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi01XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgQWxsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC00IHctNCBoLTQgbWItM1wiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtzZWxlY3RBbGx9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY2hlY2tlZCA9IGUudGFyZ2V0LmNoZWNrZWQ7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdEFsbChjaGVja2VkKTsgLy8gU2V0IGdsb2JhbCBjaGVja2JveCBzdGF0ZVxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdXBkYXRlZERhdGEgPSB7IC4uLmFjdGl2ZVVzZXJEYXRhIH07XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAvLyBMb29wIHRocm91Z2ggYWxsIGZpbHRlcmVkIHVzZXJzIGFuZCBhcHBseSB0aGUgc2VsZWN0aW9uXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcmVkVXNlcnMuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWREYXRhW3VzZXIuX2lkXSA9IHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZm86IHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBjaGVja2VkLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyUGhvbmU6IHVzZXIudXNlclBob25lLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyTmFtZTogdXNlci51c2VyTmFtZSxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXBJZDogdXNlci5ncm91cElkLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VySWQ6IHVzZXIudXNlcklkLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKHVwZGF0ZWREYXRhKTtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBtYi00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtzZW5kV2hhdHNhcHB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgYmctZ3JlZW4tNjAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLWdyZWVuLTcwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCBmbGV4IGl0ZW1zLWNlbnRlclwiXHJcbi8vICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7dmlzaWJsZVNlbGVjdGVkQ291bnQgPiAwICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWluLXctNiBoLTYgYWJzb2x1dGUgLXJpZ2h0LTMgLXRvcC0yIHNoYWRvdy1sZyBob3ZlcjpiZy1yZWQtNjAwIGJnLXJlZC00MDAgcm91bmRlZC1mdWxsIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC14c1wiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtgTWVzc2FnZSB3aWxsIGJlIHNlbnQgdG8gdG90YWwgJHt2aXNpYmxlU2VsZWN0ZWRDb3VudH0gY3VzdG9tZXJzYH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3Zpc2libGVTZWxlY3RlZENvdW50fTwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPEZhV2hhdHNhcHAgY2xhc3NOYW1lPVwibXItMlwiIHNpemU9ezIwfSAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIFdoYXRzQXBwXHJcbi8vICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbi8vICAgICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlcmVkVXNlcnN9XHJcbi8vICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e0F1Y3Rpb25jb2x1bW5zfVxyXG4vLyAgICAgICAgICAgICAgICAgICBjYXRjaGVyPVwiX2lkXCJcclxuLy8gICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiQmlkIFdpbm5lclwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1wiR3JvdXAgTmFtZVwiXX1cclxuLy8gICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJWYWx1ZXM9e1tncm91cEZpbHRlcl19XHJcbi8vICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BCaWQgV2lubmVyLmNzdmB9XHJcbi8vICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICl9XHJcbi8vICAgICAgIDwvZGl2PlxyXG4vLyAgICAgPC9kaXY+XHJcbi8vICAgKTtcclxuLy8gfTtcclxuXHJcbmNvbnN0IEJpZFdpbm5lciA9ICgpID0+IHtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbdXNlcnNEYXRhLCBzZXRVc2Vyc0RhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtncm91cEZpbHRlciwgc2V0R3JvdXBGaWx0ZXJdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2Zyb21EYXRlLCBzZXRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbdG9EYXRlLCBzZXRUb0RhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FjdGl2ZVVzZXJEYXRhLCBzZXRBY3RpdmVVc2VyRGF0YV0gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdG90YWxVc2Vycywgc2V0VG90YWxVc2Vyc10gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbbm90aWZpZXIsIGNvbnRleHRIb2xkZXJdID0gbm90aWZpY2F0aW9uLnVzZU5vdGlmaWNhdGlvbigpO1xyXG4gIGNvbnN0IFtzZWxlY3RBbGwsIHNldFNlbGVjdEFsbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3dpblRpY2tldCwgc2V0V2luVGlja2V0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IGdyb3VwT3B0aW9ucyA9IFsuLi5uZXcgU2V0KHVzZXJzRGF0YS5tYXAoKHUpID0+IHUuZ3JvdXBOYW1lKSldO1xyXG5cclxuICBjb25zdCBmaWx0ZXJlZFVzZXJzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBmaWx0ZXJlZCA9IGZpbHRlck9wdGlvbihcclxuICAgICAgdXNlcnNEYXRhLmZpbHRlcigodSkgPT4ge1xyXG4gICAgICAgIGNvbnN0IG1hdGNoR3JvdXAgPSBncm91cEZpbHRlciA/IHUuZ3JvdXBOYW1lID09PSBncm91cEZpbHRlciA6IHRydWU7XHJcbiAgICAgICAgY29uc3QgZW5yb2xsbWVudERhdGUgPSBuZXcgRGF0ZSh1LmVucm9sbG1lbnREYXRlKTtcclxuICAgICAgICBjb25zdCBtYXRjaEZyb21EYXRlID0gZnJvbURhdGVcclxuICAgICAgICAgID8gZW5yb2xsbWVudERhdGUgPj0gbmV3IERhdGUoZnJvbURhdGUpXHJcbiAgICAgICAgICA6IHRydWU7XHJcbiAgICAgICAgY29uc3QgbWF0Y2hUb0RhdGUgPSB0b0RhdGUgPyBlbnJvbGxtZW50RGF0ZSA8PSBuZXcgRGF0ZSh0b0RhdGUpIDogdHJ1ZTtcclxuICAgICAgICByZXR1cm4gbWF0Y2hHcm91cCAmJiBtYXRjaEZyb21EYXRlICYmIG1hdGNoVG9EYXRlO1xyXG4gICAgICB9KSxcclxuICAgICAgc2VhcmNoVGV4dFxyXG4gICAgKTtcclxuXHJcbiAgICByZXR1cm4gZmlsdGVyZWQubWFwKCh1c2VyLCBpbmRleCkgPT4ge1xyXG4gICAgICBjb25zdCBpc1NlbGVjdGVkID0gISFhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF0/LmluZm8/LnN0YXR1cztcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi51c2VyLFxyXG4gICAgICAgIHNsX25vOiBpbmRleCArIDEsXHJcbiAgICAgICAgY2hlY2tCb3hzOiAoXHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgY2hlY2tlZD17aXNTZWxlY3RlZH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0QWN0aXZlVXNlckRhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgW3VzZXIuX2lkXToge1xyXG4gICAgICAgICAgICAgICAgICBpbmZvOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJQaG9uZTogdXNlci51c2VyUGhvbmUsXHJcbiAgICAgICAgICAgICAgICAgICAgZ3JvdXBOYW1lOiB1c2VyLmdyb3VwTmFtZSxcclxuICAgICAgICAgICAgICAgICAgICB1c2VyTmFtZTogdXNlci51c2VyTmFtZSxcclxuICAgICAgICAgICAgICAgICAgICBwYXltZW50c1RpY2tldDogdXNlci5wYXltZW50c1RpY2tldCxcclxuICAgICAgICAgICAgICAgICAgICBncm91cElkOiB1c2VyLmdyb3VwSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlcklkOiB1c2VyLnVzZXJJZCxcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApLFxyXG4gICAgICAgIGlzU2VsZWN0ZWQsXHJcbiAgICAgIH07XHJcbiAgICB9KTtcclxuICB9LCBbdXNlcnNEYXRhLCBncm91cEZpbHRlciwgZnJvbURhdGUsIHRvRGF0ZSwgc2VhcmNoVGV4dCwgYWN0aXZlVXNlckRhdGFdKTtcclxuXHJcbiAgY29uc3QgdmlzaWJsZVNlbGVjdGVkQ291bnQgPSB1c2VNZW1vKFxyXG4gICAgKCkgPT4gZmlsdGVyZWRVc2Vycy5maWx0ZXIoKHVzZXIpID0+IHVzZXIuaXNTZWxlY3RlZCkubGVuZ3RoLFxyXG4gICAgW2ZpbHRlcmVkVXNlcnNdXHJcbiAgKTtcclxuXHJcbiAgY29uc3Qgc2VuZFdoYXRzYXBwID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgY29uc3Qga2V5ID0gXCJ1cGRhdGFibGVcIjtcclxuICAgIHRyeSB7XHJcbiAgICAgIG5vdGlmaWVyLm9wZW4oe1xyXG4gICAgICAgIGtleSxcclxuICAgICAgICBtZXNzYWdlOiBcIlNlbmRpbmcgTWVzc2FnZXMgVmlhIFdoYXRzYXBwLi5cIixcclxuICAgICAgICBkZXNjcmlwdGlvbjogXCJQcm9jZXNzaW5nLi4uXCIsXHJcbiAgICAgICAgY2xhc3NOYW1lOiBcImJnLWdyZWVuLTMwMCByb3VuZGVkLWxnIGZvbnQtYm9sZFwiLFxyXG4gICAgICAgIGR1cmF0aW9uOiAyLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IHZpc2libGVBY3RpdmVVc2VycyA9IHt9O1xyXG4gICAgICBmaWx0ZXJlZFVzZXJzLmZvckVhY2goKHVzZXIpID0+IHtcclxuICAgICAgICBpZiAodXNlci5pc1NlbGVjdGVkICYmIGFjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXSkge1xyXG4gICAgICAgICAgdmlzaWJsZUFjdGl2ZVVzZXJzW3VzZXIuX2lkXSA9IGFjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgYXdhaXQgYXBpLnBvc3QoXCIvd2hhdHNhcHAvd2hhdHNhcHAtYmlkLXdpbm5lclwiLCB7XHJcbiAgICAgICAgcmVjZWl2ZXJzOiB2aXNpYmxlQWN0aXZlVXNlcnMsXHJcbiAgICAgICAgd2luVGlja2V0OiB3aW5UaWNrZXQsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgbmV3QWN0aXZlVXNlckRhdGEgPSB7IC4uLmFjdGl2ZVVzZXJEYXRhIH07XHJcbiAgICAgIGZpbHRlcmVkVXNlcnMuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4gICAgICAgIGlmICh1c2VyLmlzU2VsZWN0ZWQpIGRlbGV0ZSBuZXdBY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF07XHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRBY3RpdmVVc2VyRGF0YShuZXdBY3RpdmVVc2VyRGF0YSk7XHJcblxyXG4gICAgICBub3RpZmllci5vcGVuKHtcclxuICAgICAgICBrZXksXHJcbiAgICAgICAgbWVzc2FnZTogXCJXaGF0c2FwcCBNZXNzYWdlcyBTZW50IFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIlN1Y2Nlc3NcIixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYmctZ3JlZW4tMzAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbiAgICAgICAgZHVyYXRpb246IDIsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIG5vdGlmaWVyLm9wZW4oe1xyXG4gICAgICAgIGtleSxcclxuICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBTZW5kIFdoYXRzYXBwXCIsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IGVyci5tZXNzYWdlIHx8IFwiU29tZXRoaW5nIHdlbnQgd3JvbmdcIixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYmctcmVkLTMwMCByb3VuZGVkLWxnIGZvbnQtYm9sZFwiLFxyXG4gICAgICAgIGR1cmF0aW9uOiAyLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgYWxsQ2hlY2tlZCA9XHJcbiAgICAgIGZpbHRlcmVkVXNlcnMubGVuZ3RoID4gMCAmJlxyXG4gICAgICBmaWx0ZXJlZFVzZXJzLmV2ZXJ5KCh1c2VyKSA9PiBhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF0/LmluZm8/LnN0YXR1cyk7XHJcbiAgICBzZXRTZWxlY3RBbGwoYWxsQ2hlY2tlZCk7XHJcbiAgfSwgW2ZpbHRlcmVkVXNlcnMsIGFjdGl2ZVVzZXJEYXRhXSk7XHJcblxyXG4gIGNvbnN0IGZldGNoRGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgY29uc3QgcmVwb3J0UmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvYWxsLWN1c3RvbWVycy1yZXBvcnRcIik7XHJcbiAgICAgIGNvbnN0IHVzZXJzTGlzdCA9IFtdO1xyXG4gICAgICBjb25zdCB0ZW1wQWN0aXZlID0ge307XHJcblxyXG4gICAgICByZXBvcnRSZXNwb25zZS5kYXRhLmZvckVhY2goKHVzckRhdGEpID0+IHtcclxuICAgICAgICBpZiAodXNyRGF0YT8uZGF0YSkge1xyXG4gICAgICAgICAgdXNyRGF0YS5kYXRhLmZvckVhY2goKGRhdGEpID0+IHtcclxuICAgICAgICAgICAgaWYgKGRhdGE/LmVucm9sbG1lbnQ/Lmdyb3VwKSB7XHJcbiAgICAgICAgICAgICAgY29uc3QgZ3JvdXBJZCA9IGRhdGEuZW5yb2xsbWVudC5ncm91cC5faWQ7XHJcbiAgICAgICAgICAgICAgY29uc3QgaWQgPSBkYXRhPy5lbnJvbGxtZW50Py5faWQ7XHJcbiAgICAgICAgICAgICAgY29uc3QgdXNlclBob25lID0gdXNyRGF0YS5waG9uZV9udW1iZXI7XHJcbiAgICAgICAgICAgICAgY29uc3QgZ3JvdXBOYW1lID0gZGF0YS5lbnJvbGxtZW50Lmdyb3VwLmdyb3VwX25hbWU7XHJcbiAgICAgICAgICAgICAgY29uc3QgdXNlck5hbWUgPSB1c3JEYXRhLnVzZXJOYW1lO1xyXG4gICAgICAgICAgICAgIGNvbnN0IHBheW1lbnRzVGlja2V0ID0gZGF0YS5wYXltZW50cy50aWNrZXQ7XHJcbiAgICAgICAgICAgICAgdGVtcEFjdGl2ZVtpZF0gPSB7IGluZm86IHsgc3RhdHVzOiBmYWxzZSB9IH07XHJcbiAgICAgICAgICAgICAgdXNlcnNMaXN0LnB1c2goe1xyXG4gICAgICAgICAgICAgICAgX2lkOiBpZCxcclxuICAgICAgICAgICAgICAgIHVzZXJOYW1lLFxyXG4gICAgICAgICAgICAgICAgdXNlclBob25lLFxyXG4gICAgICAgICAgICAgICAgY3VzdG9tZXJJZDogdXNyRGF0YS5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgIGdyb3VwTmFtZSxcclxuICAgICAgICAgICAgICAgIHBheW1lbnRzVGlja2V0LFxyXG4gICAgICAgICAgICAgICAgZ3JvdXBJZCxcclxuICAgICAgICAgICAgICAgIHVzZXJJZDogdXNyRGF0YT8uX2lkLFxyXG4gICAgICAgICAgICAgICAgdG9EYXRlOiB0b0RhdGUsXHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcblxyXG4gICAgICBzZXRVc2Vyc0RhdGEodXNlcnNMaXN0KTtcclxuICAgICAgc2V0VG90YWxVc2Vycyh1c2Vyc0xpc3QubGVuZ3RoKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaERhdGEoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IEF1Y3Rpb25jb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwic2xfbm9cIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJjaGVja0JveHNcIiwgaGVhZGVyOiBcIlNlbGVjdCBVc2VyXCIgfSxcclxuICAgIHsga2V5OiBcInVzZXJOYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInVzZXJQaG9uZVwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImN1c3RvbWVySWRcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIElkXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwTmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwYXltZW50c1RpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0XCIgfSxcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17KGUpID0+IHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxTaWRlYmFyLz5cclxuICAgICAgIFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1jZW50ZXIgbXQtMlwiPkF1Y3Rpb24gQmlkIFdpbm5lcjwvaDE+XHJcblxyXG4gICAgICAgICAgICB7Y29udGV4dEhvbGRlcn1cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLThcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1zdGFydCBib3JkZXItYiBib3JkZXItZ3JheS0zMDAgbWItNFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGNvbG9yPVwidGV4dC1ncmVlbi02MDBcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTYgbXQtOCBtYi02XCI+XHJcbiAgPGRpdiBjbGFzc05hbWU9XCJiZy12aW9sZXQtMTAwIHJvdW5kZWQteGwgcC02IHNoYWRvdyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgIDxkaXY+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlRvdGFsIEN1c3RvbWVyczwvcD5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtdmlvbGV0LTcwMFwiPlxyXG4gICAgICAgIHtmaWx0ZXJlZFVzZXJzLmxlbmd0aH1cclxuICAgICAgPC9wPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8RmFVc2VycyBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDAgdGV4dC00eGxcIiAvPlxyXG4gIDwvZGl2PlxyXG5cclxuICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyZWVuLTEwMCByb3VuZGVkLXhsIHAtNiBzaGFkb3cgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICA8ZGl2PlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5TZWxlY3RlZCBDdXN0b21lcnM8L3A+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgIHt2aXNpYmxlU2VsZWN0ZWRDb3VudH1cclxuICAgICAgPC9wPlxyXG4gICAgPC9kaXY+XHJcbiAgICA8RmFDaGVja0NpcmNsZSBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMCB0ZXh0LTR4bFwiIC8+XHJcbiAgPC9kaXY+XHJcbjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTQgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IEdyb3VwXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogMjAwIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIi0tQWxsIGdyb3Vwcy0tXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldEdyb3VwRmlsdGVyKHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cEZpbHRlciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXcteHMgaC0xMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2dyb3VwT3B0aW9ucy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXB9IHZhbHVlPXtncm91cH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQXVjdGlvbiBXb24gVGlja2V0IE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXcteHMgaC0xMSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcHgtMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17d2luVGlja2V0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRXaW5UaWNrZXQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aWNrZXQgbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgQWxsXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC00IHctNCBoLTQgbWItM1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtzZWxlY3RBbGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY2hlY2tlZCA9IGUudGFyZ2V0LmNoZWNrZWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdEFsbChjaGVja2VkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdXBkYXRlZERhdGEgPSB7IC4uLmFjdGl2ZVVzZXJEYXRhIH07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcmVkVXNlcnMuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWREYXRhW3VzZXIuX2lkXSA9IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZm86IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBjaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyUGhvbmU6IHVzZXIudXNlclBob25lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyTmFtZTogdXNlci51c2VyTmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXBJZDogdXNlci5ncm91cElkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VySWQ6IHVzZXIudXNlcklkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlVXNlckRhdGEodXBkYXRlZERhdGEpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiDinIUgU2hvdyBXaGF0c0FwcCBidXR0b24gb25seSBpZiB0aWNrZXQgbnVtYmVyIGhhcyB2YWx1ZSAqL31cclxuICAgICAgICAgICAgICAgIHt3aW5UaWNrZXQudHJpbSgpICE9PSBcIlwiICYmIHZpc2libGVTZWxlY3RlZENvdW50ID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17c2VuZFdoYXRzYXBwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgYmctZ3JlZW4tNjAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLWdyZWVuLTcwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCBmbGV4IGl0ZW1zLWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3Zpc2libGVTZWxlY3RlZENvdW50ID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtaW4tdy02IGgtNiBhYnNvbHV0ZSAtcmlnaHQtMyAtdG9wLTIgc2hhZG93LWxnIGhvdmVyOmJnLXJlZC02MDAgYmctcmVkLTQwMCByb3VuZGVkLWZ1bGwgdGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXhzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17YE1lc3NhZ2Ugd2lsbCBiZSBzZW50IHRvIHRvdGFsICR7dmlzaWJsZVNlbGVjdGVkQ291bnR9IGN1c3RvbWVyc2B9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57dmlzaWJsZVNlbGVjdGVkQ291bnR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8RmFXaGF0c2FwcCBjbGFzc05hbWU9XCJtci0yXCIgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICBXaGF0c0FwcFxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJlZFVzZXJzfVxyXG4gICAgICAgICAgICAgICAgICBjb2x1bW5zPXtBdWN0aW9uY29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgY2F0Y2hlcj1cIl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkJpZCBXaW5uZXJcIlxyXG4gICAgICAgICAgICAgICAgICBwcmludEhlYWRlcktleXM9e1tcIkdyb3VwIE5hbWVcIl19XHJcbiAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbZ3JvdXBGaWx0ZXJdfVxyXG4gICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgQmlkIFdpbm5lci5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgIFxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBCaWRXaW5uZXI7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9CaWRXaW5uZXIuanN4In0=