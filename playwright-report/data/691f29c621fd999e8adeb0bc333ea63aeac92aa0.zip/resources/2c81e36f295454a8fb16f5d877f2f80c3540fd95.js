import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CreateBidRequest.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import {
  Form,
  Input,
  DatePicker,
  TimePicker,
  Button,
  Select,
  notification,
  Spin,
  Tag,
  Alert
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import {
  ClockCircleOutlined,
  UserOutlined,
  CalendarOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import API from "/src/instance/TokenInstance.js";
import __vite__cjsImport7_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport7_dayjs.__esModule ? __vite__cjsImport7_dayjs.default : __vite__cjsImport7_dayjs;
const { Option } = Select;
function CreateBidRequest() {
  _s();
  const [api, contextHolder] = notification.useNotification();
  const [createForm] = Form.useForm();
  const [users, setUsers] = useState([]);
  const [loadingUsers, setLoadingUsers] = useState(true);
  const [loading, setLoading] = useState(false);
  const [createGroups, setCreateGroups] = useState([]);
  const [groupTickets, setGroupTickets] = useState([]);
  const [selectedTicketIndex, setSelectedTicketIndex] = useState(null);
  const [selectedEnrollmentId, setSelectedEnrollmentId] = useState(null);
  const [selectedGroupId, setSelectedGroupId] = useState(null);
  const [adminName, setAdminName] = useState("");
  const [adminId, setAdminId] = useState("");
  const [adminEmail, setAdminEmail] = useState("");
  const [adminPhone, setAdminPhone] = useState("");
  const [customerOverview, setCustomerOverview] = useState(null);
  const [loadingOverview, setLoadingOverview] = useState(false);
  const [nextAuctionDate, setNextAuctionDate] = useState(null);
  const [loadingNextAuction, setLoadingNextAuction] = useState(false);
  const [auctionInfo, setAuctionInfo] = useState({
    nextDate: null,
    lastDate: null,
    totalAuctions: 0,
    nextAuctionType: null,
    totalPayable: 0,
    totalProfit: 0,
    totalInvestment: 0,
    totalBalance: 0,
    totalPenalty: 0,
    totalLateFee: 0,
    isPrized: false
  });
  const fetchCustomerOverview = async (userId, groupId, ticket) => {
    if (!userId || !groupId || !ticket) {
      console.log("Missing required params for customer overview");
      return null;
    }
    setLoadingOverview(true);
    try {
      const response = await API.get(
        `/v1/admin/users/overview/single?user_id=${userId}&group_id=${groupId}&ticket=${ticket}`
      );
      console.log("Customer Overview Response:", response.data);
      if (response.data && response.data.success) {
        const overviewData = response.data.data;
        setCustomerOverview(overviewData);
        if (overviewData.is_prized === true) {
          api.error({
            message: "Ticket Already Prized",
            description: "This ticket has already been prized in an auction. You cannot raise a bid request for this ticket.",
            duration: 5
          });
          setAuctionInfo({
            nextDate: null,
            lastDate: null,
            totalAuctions: 0,
            nextAuctionType: null,
            totalPayable: overviewData.total_payable || 0,
            totalProfit: overviewData.total_profit || 0,
            totalInvestment: overviewData.total_investment || 0,
            totalBalance: overviewData.total_balance || 0,
            totalPenalty: overviewData.total_penalty || 0,
            totalLateFee: overviewData.total_late_fee || 0,
            isPrized: true
          });
          setNextAuctionDate(null);
          createForm.setFieldsValue({
            auctionDate: null
          });
          return overviewData;
        }
        if (overviewData.next_auction_date) {
          const formattedNextDate = dayjs(overviewData.next_auction_date);
          setAuctionInfo({
            nextDate: formattedNextDate,
            lastDate: null,
            totalAuctions: 0,
            nextAuctionType: overviewData.auction_type || "Normal Auction",
            totalPayable: overviewData.total_payable || 0,
            totalProfit: overviewData.total_profit || 0,
            totalInvestment: overviewData.total_investment || 0,
            totalBalance: overviewData.total_balance || 0,
            totalPenalty: overviewData.total_penalty || 0,
            totalLateFee: overviewData.total_late_fee || 0,
            isPrized: false
          });
          setNextAuctionDate(formattedNextDate);
          createForm.setFieldsValue({
            auctionDate: formattedNextDate
          });
          const auctionType = overviewData.auction_type || "Normal";
          api.success({
            message: "Customer Data Loaded",
            description: `Next ${auctionType} Auction: ${formattedNextDate.format("DD-MM-YYYY")}`,
            duration: 3
          });
          return overviewData;
        } else {
          api.warning({
            message: "No Upcoming Auction",
            description: "No future auction found for this customer.",
            duration: 3
          });
          return null;
        }
      } else {
        api.error({
          message: "Error",
          description: "Failed to fetch customer overview data."
        });
        return null;
      }
    } catch (error) {
      console.error("Error fetching customer overview:", error);
      if (error.response?.data?.message?.includes("prized")) {
        api.error({
          message: "Ticket Already Prized",
          description: "This ticket has already been prized in an auction.",
          duration: 5
        });
        setAuctionInfo((prev) => ({ ...prev, isPrized: true }));
      } else {
        api.error({
          message: "Error",
          description: error.response?.data?.message || "Failed to fetch customer data."
        });
      }
      return null;
    } finally {
      setLoadingOverview(false);
    }
  };
  const fetchAdminProfile = async () => {
    try {
      const userStr = localStorage.getItem("user");
      if (!userStr) return;
      const user = JSON.parse(userStr);
      const userId = user._id;
      if (!userId) return;
      try {
        const res = await API.get(`/admin/get-admin/${userId}`);
        const name = res.data.name || user.admin_name || user.full_name || user.name;
        const phone = res.data.phone_number || user.phone_number || user.mobile;
        const email = res.data.email || user.email;
        setAdminName(name);
        setAdminId(userId);
        setAdminPhone(phone);
        setAdminEmail(email);
        createForm.setFieldsValue({
          adminName: name,
          adminId: userId,
          adminPhone: phone,
          adminEmail: email
        });
      } catch (adminError) {
        const name = user.full_name || user.name || user.admin_name || "Admin";
        const phone = user.phone_number || user.mobile;
        const email = user.email;
        setAdminName(name);
        setAdminId(userId);
        setAdminPhone(phone);
        setAdminEmail(email);
        createForm.setFieldsValue({
          adminName: name,
          adminId: userId,
          adminPhone: phone,
          adminEmail: email
        });
      }
    } catch (error) {
      console.error("Failed to fetch admin profile:", error);
      setAdminName("Admin");
      createForm.setFieldsValue({ adminName: "Admin" });
    }
  };
  const fetchUsers = async () => {
    try {
      setLoadingUsers(true);
      const response = await API.get("/user/get-user");
      setUsers(response.data || []);
    } catch (error) {
      console.error("Error fetching users:", error);
      api.error({ message: "Error", description: "Failed to fetch users." });
    } finally {
      setLoadingUsers(false);
    }
  };
  const fetchAuctionInfo = async (groupId, userId, ticketNumber) => {
    if (!groupId) return { count: 0, isPrized: false };
    try {
      const response = await API.get(
        `/bid-request/get-group-auction-stats/${groupId}`
      );
      const data = response.data;
      if (!data || !data.success) {
        return { count: 0, isPrized: false };
      }
      const count = data.count || 0;
      const prizedList = data.prizedTickets || [];
      const isPrized = prizedList.some(
        (item) => String(item.user_id) === String(userId) && String(item.ticket) === String(ticketNumber)
      );
      return { count, isPrized };
    } catch (error) {
      console.error("Error fetching auction stats:", error);
      return { count: 0, isPrized: false };
    }
  };
  const handleGroupChange = async (groupId) => {
    setSelectedGroupId(groupId);
    const selectedGroup = createGroups.find((g) => g.id === groupId);
    if (!selectedGroup) return;
    setGroupTickets(selectedGroup.tickets);
    createForm.setFieldsValue({
      ticketIndex: void 0,
      groupName: selectedGroup.groupName,
      startDate: selectedGroup.startDate,
      endDate: selectedGroup.endDate,
      auctionsDone: selectedGroup.auctionsDone,
      agentName: selectedGroup.agentName,
      referredType: selectedGroup.referredType,
      referredBy: selectedGroup.referredBy
    });
    setCustomerOverview(null);
    setAuctionInfo({
      nextDate: null,
      lastDate: null,
      totalAuctions: 0,
      nextAuctionType: null,
      totalPayable: 0,
      totalProfit: 0,
      totalInvestment: 0,
      totalBalance: 0,
      totalPenalty: 0,
      totalLateFee: 0,
      isPrized: false
    });
    setNextAuctionDate(null);
    createForm.setFieldsValue({
      auctionDate: null
    });
  };
  const handleTicketChange = async (index) => {
    setSelectedTicketIndex(index);
    const ticket = groupTickets[index];
    if (!ticket) return;
    setSelectedEnrollmentId(ticket.enrollmentId);
    createForm.setFieldsValue({
      ticketNumber: ticket.ticketNumber
    });
    const userId = createForm.getFieldValue("subscriberId");
    if (userId && selectedGroupId && ticket.ticketNumber) {
      await fetchCustomerOverview(userId, selectedGroupId, ticket.ticketNumber);
    }
  };
  const fetchCreateCustomerDetails = async (userId) => {
    try {
      const response = await API.post(
        `/enroll/get-user-tickets-report/${userId}`
      );
      const dataList = response.data || response.data?.data || [];
      if (dataList && dataList.length > 0) {
        const groupedData = {};
        for (const item of dataList) {
          const enrollment = item?.enrollment;
          const groupData = enrollment?.group;
          if (!groupData?._id) continue;
          const ticketNumber = enrollment?.tickets || enrollment?.ticket_number || "N/A";
          const auctionInfo2 = await fetchAuctionInfo(
            groupData?._id,
            userId,
            ticketNumber
          );
          let referredType = "N/A";
          let referredBy = "N/A";
          let agentName = "N/A";
          if (enrollment?.agent?.name) {
            referredType = "Agent";
            agentName = enrollment.agent.name;
            referredBy = `${enrollment.agent.name} | ${enrollment.agent.phone_number}`;
          } else if (groupData?.agent?.name) {
            referredType = "Agent";
            agentName = groupData.agent.name;
            referredBy = `${groupData.agent.name} | ${groupData.agent.phone_number}`;
          }
          if (!groupedData[groupData._id]) {
            groupedData[groupData._id] = {
              id: groupData._id,
              groupName: groupData.group_name,
              startDate: groupData?.start_date ? groupData.start_date.split("T")[0] : "N/A",
              endDate: groupData?.end_date ? groupData.end_date.split("T")[0] : "N/A",
              auctionsDone: auctionInfo2.count,
              agentName,
              referredType,
              referredBy,
              tickets: []
            };
          }
          groupedData[groupData._id].tickets.push({
            ticketNumber,
            enrollmentId: enrollment?._id,
            isPrized: auctionInfo2.isPrized
          });
        }
        const finalGroups = Object.values(groupedData);
        setCreateGroups(finalGroups);
        if (finalGroups.length > 0) {
          const firstGroup = finalGroups[0];
          setSelectedGroupId(firstGroup.id);
          setGroupTickets(firstGroup.tickets);
          createForm.setFieldsValue({
            selectedGroupId: firstGroup.id,
            groupName: firstGroup.groupName,
            startDate: firstGroup.startDate,
            endDate: firstGroup.endDate,
            auctionsDone: firstGroup.auctionsDone,
            agentName: firstGroup.agentName,
            referredType: firstGroup.referredType,
            referredBy: firstGroup.referredBy
          });
          if (firstGroup.tickets.length > 0) {
            const firstTicket = firstGroup.tickets[0];
            if (!firstTicket.isPrized) {
              setSelectedTicketIndex(0);
              createForm.setFieldsValue({
                ticketNumber: firstTicket.ticketNumber,
                ticketIndex: 0
              });
              setSelectedEnrollmentId(firstTicket.enrollmentId);
              await fetchCustomerOverview(
                userId,
                firstGroup.id,
                firstTicket.ticketNumber
              );
            } else {
              api.warning({
                message: "Ticket Already Prized",
                description: "The first available ticket is already prized. Please select another ticket.",
                duration: 4
              });
            }
          }
        }
      } else {
        api.warning({
          message: "No Tickets Found",
          description: "This customer is not enrolled in any active groups."
        });
        setCreateGroups([]);
        setSelectedEnrollmentId(null);
        createForm.setFieldsValue({
          agentName: "N/A",
          referredType: "N/A",
          referredBy: "N/A"
        });
      }
    } catch (error) {
      console.error("Error fetching customer details:", error);
      api.error({
        message: "Error Fetching Details",
        description: "Could not load customer tickets. Please try again."
      });
      setCreateGroups([]);
      setSelectedEnrollmentId(null);
    }
  };
  const handleCreateCustomerSelect = (userId) => {
    const selectedUser = users.find((u) => u._id === userId);
    if (selectedUser) {
      const cName = selectedUser.full_name || selectedUser.name;
      const cPhone = selectedUser.phone_number || selectedUser.mobile;
      createForm.setFieldsValue({
        subscriberName: cName,
        mobileNumber: cPhone,
        subscriberId: userId,
        groupName: "Loading...",
        ticketNumber: "Loading...",
        agentName: "Loading...",
        referredType: "Loading...",
        referredBy: "Loading..."
      });
      setCreateGroups([]);
      setSelectedEnrollmentId(null);
      setCustomerOverview(null);
      setAuctionInfo({
        nextDate: null,
        lastDate: null,
        totalAuctions: 0,
        nextAuctionType: null,
        totalPayable: 0,
        totalProfit: 0,
        totalInvestment: 0,
        totalBalance: 0,
        totalPenalty: 0,
        totalLateFee: 0,
        isPrized: false
      });
      setNextAuctionDate(null);
      createForm.setFieldsValue({
        auctionDate: null
      });
      fetchCreateCustomerDetails(userId);
    }
  };
  const handleCreateFinish = async (values) => {
    try {
      setLoading(true);
      const selectedGroup = createGroups.find(
        (g) => g.id === values.selectedGroupId
      );
      const selectedTicket = groupTickets[values.ticketIndex];
      if (!selectedGroup) {
        api.error({
          message: "Error",
          description: "Please select a group first."
        });
        setLoading(false);
        return;
      }
      if (customerOverview?.is_prized === true || selectedTicket?.isPrized) {
        api.error({
          message: "Request Denied",
          description: "This ticket is already prized. Bid request cannot be raised."
        });
        setLoading(false);
        return;
      }
      const formattedTime = values.auctionTime ? values.auctionTime.format("HH:mm") : null;
      const auctionDateToSend = values.auctionDate ? values.auctionDate.format("YYYY-MM-DD") : nextAuctionDate ? nextAuctionDate.format("YYYY-MM-DD") : null;
      console.log("Sending auction date:", auctionDateToSend);
      const payload = {
        date: values.date ? values.date.format("YYYY-MM-DD") : dayjs().format("YYYY-MM-DD"),
        subscriberId: values.subscriberId,
        subscriberName: values.subscriberName,
        mobileNumber: values.mobileNumber,
        groupName: selectedGroup.groupName,
        ticketNumber: selectedTicket.ticketNumber,
        auctionDate: auctionDateToSend,
        auction_time: formattedTime,
        agentName: selectedGroup.agentName,
        referredType: selectedGroup.referredType,
        referredBy: selectedGroup.referredBy,
        groupId: selectedGroup.id,
        adminUserId: values.adminUserId || adminId,
        adminName: values.adminName || adminName,
        adminPhone: values.adminPhone || adminPhone,
        enrollmentId: selectedTicket.enrollmentId
      };
      const response = await API.post("/bid-request/create", payload);
      api.success({
        message: "Success",
        description: "Bid Request submitted successfully!"
      });
      setTimeout(() => window.close(), 1500);
    } catch (error) {
      console.error("Error:", error);
      console.error("Error response:", error.response);
      api.error({
        message: "Error",
        description: error.response?.data?.message || "Failed to save request."
      });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchUsers();
    fetchAdminProfile();
    createForm.setFieldsValue({ date: dayjs() });
  }, []);
  const isSubmitDisabled = createGroups.length === 0 || !selectedGroupId || !groupTickets.length || !nextAuctionDate || customerOverview?.is_prized === true || selectedTicketIndex === null || groupTickets[selectedTicketIndex]?.isPrized === true;
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gray-100 p-6 flex justify-center", children: [
    contextHolder,
    /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-4xl bg-white shadow-lg font-sans text-sm text-gray-800 rounded-lg", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "border-b-2 border-blue-900 p-6 mb-6 flex justify-between items-center", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-blue-900 uppercase tracking-wider", children: "New Bid Request" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
          lineNumber: 1645,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { onClick: () => window.close(), children: "Close Tab" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
          lineNumber: 1648,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
        lineNumber: 1644,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "px-8 pb-8", children: /* @__PURE__ */ jsxDEV(
        Form,
        {
          form: createForm,
          layout: "vertical",
          onFinish: handleCreateFinish,
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-blue-900 mb-4 border-b pb-2 text-lg", children: "Subscriber Details" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                lineNumber: 1658,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mb-5", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-2", children: [
                  "Admin Name ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1664,
                    columnNumber: 30
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1663,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Form.Item,
                  {
                    name: "adminName",
                    rules: [
                      { required: true, message: "Admin name is required!" }
                    ],
                    className: "mb-0",
                    children: /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        placeholder: "Auto-fetched from profile",
                        readOnly: true,
                        className: "bg-gray-50 border-gray-300 text-gray-600 cursor-not-allowed rounded-md",
                        prefix: /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-gray-400" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                          lineNumber: 1677,
                          columnNumber: 29
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                        lineNumber: 1673,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1666,
                    columnNumber: 17
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(Form.Item, { name: "adminId", hidden: true, children: /* @__PURE__ */ jsxDEV(Input, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1681,
                  columnNumber: 19
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1680,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Form.Item, { name: "adminPhone", hidden: true, children: /* @__PURE__ */ jsxDEV(Input, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1684,
                  columnNumber: 19
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1683,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Form.Item, { name: "adminEmail", hidden: true, children: /* @__PURE__ */ jsxDEV(Input, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1687,
                  columnNumber: 19
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1686,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                lineNumber: 1662,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mb-5", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-2", children: [
                  "Search Customer (Name/Phone)",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1694,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1692,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Form.Item,
                  {
                    name: "subscriberId",
                    rules: [
                      { required: true, message: "Please select a customer!" }
                    ],
                    className: "mb-0",
                    children: /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        showSearch: true,
                        placeholder: "Type name or phone number...",
                        onChange: handleCreateCustomerSelect,
                        loading: loadingUsers,
                        notFoundContent: loadingUsers ? /* @__PURE__ */ jsxDEV(Spin, { size: "small" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                          lineNumber: 1710,
                          columnNumber: 21
                        }, this) : "No customers found",
                        filterOption: (input, option) => (option?.label ?? "").toLowerCase().includes(input.toLowerCase()),
                        options: users.map((user) => ({
                          value: user._id,
                          label: `${user.full_name || user.name || "Unknown"} - ${user.phone_number || user.mobile || "No Phone"}`
                        })),
                        size: "large"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                        lineNumber: 1703,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1696,
                    columnNumber: 17
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                lineNumber: 1691,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6 bg-gray-50 p-4 rounded-lg border border-gray-200 mb-6", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Subscriber Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1731,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Form.Item,
                    {
                      name: "subscriberName",
                      rules: [{ required: true, message: "Required!" }],
                      className: "mb-0",
                      children: /* @__PURE__ */ jsxDEV(Input, { readOnly: true, className: "bg-gray-100 border-gray-300" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                        lineNumber: 1739,
                        columnNumber: 21
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                      lineNumber: 1734,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1730,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Mobile Number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1743,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Form.Item,
                    {
                      name: "mobileNumber",
                      rules: [{ required: true, message: "Required!" }],
                      className: "mb-0",
                      children: /* @__PURE__ */ jsxDEV(Input, { readOnly: true, className: "bg-gray-100 border-gray-300" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                        lineNumber: 1751,
                        columnNumber: 21
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                      lineNumber: 1746,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1742,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                lineNumber: 1729,
                columnNumber: 15
              }, this),
              createGroups.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 text-lg mb-2", children: [
                      "Select Group ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                        lineNumber: 1762,
                        columnNumber: 38
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                      lineNumber: 1761,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Form.Item,
                      {
                        name: "selectedGroupId",
                        rules: [
                          { required: true, message: "Please select group!" }
                        ],
                        className: "mb-0",
                        children: /* @__PURE__ */ jsxDEV(
                          Select,
                          {
                            size: "large",
                            placeholder: "Select Group",
                            onChange: handleGroupChange,
                            children: createGroups.map(
                              (group) => /* @__PURE__ */ jsxDEV(Option, { value: group.id, children: group.groupName }, group.id, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                                lineNumber: 1777,
                                columnNumber: 25
                              }, this)
                            )
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                            lineNumber: 1771,
                            columnNumber: 25
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                        lineNumber: 1764,
                        columnNumber: 23
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1760,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 text-lg mb-2", children: [
                      "Select Ticket ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                        lineNumber: 1788,
                        columnNumber: 39
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                      lineNumber: 1787,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Form.Item,
                      {
                        name: "ticketIndex",
                        rules: [
                          { required: true, message: "Please select ticket!" }
                        ],
                        className: "mb-0",
                        children: /* @__PURE__ */ jsxDEV(
                          Select,
                          {
                            size: "large",
                            placeholder: "Select Ticket",
                            onChange: handleTicketChange,
                            children: groupTickets.map(
                              (ticket, index) => /* @__PURE__ */ jsxDEV(
                                Option,
                                {
                                  value: index,
                                  disabled: ticket.isPrized,
                                  children: [
                                    "Ticket #",
                                    ticket.ticketNumber,
                                    ticket.isPrized ? " (Already Prized)" : ""
                                  ]
                                },
                                index,
                                true,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                                  lineNumber: 1803,
                                  columnNumber: 25
                                },
                                this
                              )
                            )
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                            lineNumber: 1797,
                            columnNumber: 25
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                        lineNumber: 1790,
                        columnNumber: 23
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1786,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1758,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Auction Start Date" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                      lineNumber: 1819,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(Form.Item, { name: "startDate", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        readOnly: true,
                        className: "bg-blue-50 border-blue-200 text-blue-900 font-semibold h-10"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                        lineNumber: 1823,
                        columnNumber: 25
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                      lineNumber: 1822,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1818,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Auction End Date" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                      lineNumber: 1830,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(Form.Item, { name: "endDate", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        readOnly: true,
                        className: "bg-blue-50 border-blue-200 text-blue-900 font-semibold h-10"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                        lineNumber: 1834,
                        columnNumber: 25
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                      lineNumber: 1833,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1829,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Auctions Done" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                      lineNumber: 1841,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(Form.Item, { name: "auctionsDone", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        readOnly: true,
                        className: "bg-green-50 border-green-200 text-green-900 font-bold text-center h-10"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                        lineNumber: 1845,
                        columnNumber: 25
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                      lineNumber: 1844,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1840,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1817,
                  columnNumber: 19
                }, this),
                selectedEnrollmentId && /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500 mt-2 p-2 bg-gray-50 rounded", children: [
                  "Enrollment ID: ",
                  selectedEnrollmentId
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1854,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                lineNumber: 1757,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4 mt-4", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Primary Group Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1863,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(Form.Item, { name: "groupName", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      readOnly: true,
                      className: "bg-blue-50 border-blue-300 font-semibold"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                      lineNumber: 1867,
                      columnNumber: 21
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1866,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1862,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: "Primary Ticket Number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1874,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(Form.Item, { name: "ticketNumber", className: "mb-0", children: /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      readOnly: true,
                      className: "bg-blue-50 border-blue-300 font-semibold"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                      lineNumber: 1878,
                      columnNumber: 21
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1877,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1873,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                lineNumber: 1861,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
              lineNumber: 1657,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-blue-900 mb-4 border-b pb-2 text-lg", children: "Auction Details" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                lineNumber: 1888,
                columnNumber: 15
              }, this),
              loadingOverview && /* @__PURE__ */ jsxDEV("div", { className: "mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(Spin, { size: "small" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1896,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-blue-600", children: "Loading customer auction details..." }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1897,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                lineNumber: 1895,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                lineNumber: 1894,
                columnNumber: 15
              }, this),
              !loadingOverview && customerOverview?.is_prized === true && /* @__PURE__ */ jsxDEV(
                Alert,
                {
                  message: "Ticket Already Prized",
                  description: "This ticket has already been prized in an auction. You cannot raise a bid request for this ticket.",
                  type: "error",
                  showIcon: true,
                  className: "mb-4",
                  icon: /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1912,
                    columnNumber: 23
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1906,
                  columnNumber: 15
                },
                this
              ),
              !loadingOverview && auctionInfo.nextDate && customerOverview?.is_prized !== true && /* @__PURE__ */ jsxDEV("div", { className: "mb-4 p-3 bg-green-50 border border-green-200 rounded-lg", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(CalendarOutlined, { className: "text-green-600 text-lg" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1919,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-700", children: [
                  /* @__PURE__ */ jsxDEV("strong", { children: "Next Auction Date:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1922,
                    columnNumber: 25
                  }, this),
                  " ",
                  auctionInfo.nextDate.format("DD-MM-YYYY"),
                  auctionInfo.nextAuctionType && /* @__PURE__ */ jsxDEV(
                    Tag,
                    {
                      color: auctionInfo.nextAuctionType === "Free Auction" ? "gold" : "blue",
                      className: "ml-2",
                      children: auctionInfo.nextAuctionType
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                      lineNumber: 1925,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1921,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1920,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                lineNumber: 1918,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                lineNumber: 1917,
                columnNumber: 15
              }, this),
              !loadingOverview && !auctionInfo.nextDate && createGroups.length > 0 && customerOverview?.is_prized !== true && /* @__PURE__ */ jsxDEV(
                Alert,
                {
                  message: "No Upcoming Auction Found",
                  description: "This customer doesn't have any scheduled auction. Please set the auction date manually or configure the group's auction schedule.",
                  type: "warning",
                  showIcon: true,
                  className: "mb-4",
                  icon: /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1949,
                    columnNumber: 23
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1943,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: [
                    "Auction Date ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                      lineNumber: 1956,
                      columnNumber: 34
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1955,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Form.Item,
                    {
                      name: "auctionDate",
                      rules: [
                        {
                          required: true,
                          message: "Please select auction date!"
                        }
                      ],
                      className: "mb-0",
                      children: /* @__PURE__ */ jsxDEV(
                        DatePicker,
                        {
                          style: { width: "100%" },
                          className: "border-gray-400 h-10",
                          placeholder: "Select Auction Date",
                          format: "DD-MM-YYYY",
                          disabled: customerOverview?.is_prized === true,
                          disabledDate: (current) => {
                            return current && current < dayjs().startOf("day");
                          }
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                          lineNumber: 1968,
                          columnNumber: 21
                        },
                        this
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                      lineNumber: 1958,
                      columnNumber: 19
                    },
                    this
                  ),
                  auctionInfo.nextDate && customerOverview?.is_prized !== true && /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-green-600 mt-1", children: "Next auction date auto-loaded from customer overview" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1980,
                    columnNumber: 19
                  }, this),
                  customerOverview?.is_prized === true && /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-red-600 mt-1", children: "Cannot select date - ticket is already prized" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1985,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1954,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block font-semibold text-gray-700 mb-1", children: [
                    "Request Time ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                      lineNumber: 1992,
                      columnNumber: 34
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                    lineNumber: 1991,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Form.Item,
                    {
                      name: "auctionTime",
                      initialValue: dayjs(),
                      rules: [
                        {
                          required: true,
                          message: "Please select auction time!"
                        }
                      ],
                      className: "mb-0",
                      children: /* @__PURE__ */ jsxDEV(
                        TimePicker,
                        {
                          style: { width: "100%" },
                          className: "border-gray-400 h-10",
                          format: "h:mm A",
                          use12Hours: true,
                          placeholder: "Select Time",
                          minuteStep: 15,
                          disabled: customerOverview?.is_prized === true
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                          lineNumber: 2005,
                          columnNumber: 21
                        },
                        this
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                      lineNumber: 1994,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 1990,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                lineNumber: 1953,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
              lineNumber: 1887,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 pt-4 border-t", children: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  onClick: () => window.close(),
                  className: "flex-1 h-12 font-semibold border-gray-400 text-lg",
                  children: "Cancel"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 2020,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "primary",
                  htmlType: "submit",
                  loading,
                  className: "flex-1 bg-blue-900 hover:bg-blue-800 h-12 font-bold uppercase tracking-wide text-lg",
                  disabled: isSubmitDisabled,
                  children: customerOverview?.is_prized === true ? "Already Prized" : "Submit Request"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
                  lineNumber: 2026,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
              lineNumber: 2019,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
          lineNumber: 1652,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
        lineNumber: 1651,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
      lineNumber: 1643,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx",
    lineNumber: 1641,
    columnNumber: 5
  }, this);
}
_s(CreateBidRequest, "Nfwx8JGNDuaIX0p+C0y8nclemt8=", false, function() {
  return [notification.useNotification, Form.useForm];
});
_c = CreateBidRequest;
export default CreateBidRequest;
var _c;
$RefreshReg$(_c, "CreateBidRequest");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateBidRequest.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNG1EVTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFsbUJWLE9BQU9BLFNBQVNDLFVBQVVDLGlCQUFpQjtBQUMzQztBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUDtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLFdBQVc7QUFFbEIsTUFBTSxFQUFFQyxPQUFPLElBQUlWO0FBRW5CLFNBQVNXLG1CQUFtQjtBQUFBQyxLQUFBO0FBQzFCLFFBQU0sQ0FBQ0MsS0FBS0MsYUFBYSxJQUFJYixhQUFhYyxnQkFBZ0I7QUFDMUQsUUFBTSxDQUFDQyxVQUFVLElBQUlyQixLQUFLc0IsUUFBUTtBQUVsQyxRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSTFCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUMyQixjQUFjQyxlQUFlLElBQUk1QixTQUFTLElBQUk7QUFDckQsUUFBTSxDQUFDNkIsU0FBU0MsVUFBVSxJQUFJOUIsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQytCLGNBQWNDLGVBQWUsSUFBSWhDLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUNpQyxjQUFjQyxlQUFlLElBQUlsQyxTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDbUMscUJBQXFCQyxzQkFBc0IsSUFBSXBDLFNBQVMsSUFBSTtBQUNuRSxRQUFNLENBQUNxQyxzQkFBc0JDLHVCQUF1QixJQUFJdEMsU0FBUyxJQUFJO0FBQ3JFLFFBQU0sQ0FBQ3VDLGlCQUFpQkMsa0JBQWtCLElBQUl4QyxTQUFTLElBQUk7QUFHM0QsUUFBTSxDQUFDeUMsV0FBV0MsWUFBWSxJQUFJMUMsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQzJDLFNBQVNDLFVBQVUsSUFBSTVDLFNBQVMsRUFBRTtBQUN6QyxRQUFNLENBQUM2QyxZQUFZQyxhQUFhLElBQUk5QyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDK0MsWUFBWUMsYUFBYSxJQUFJaEQsU0FBUyxFQUFFO0FBRy9DLFFBQU0sQ0FBQ2lELGtCQUFrQkMsbUJBQW1CLElBQUlsRCxTQUFTLElBQUk7QUFDN0QsUUFBTSxDQUFDbUQsaUJBQWlCQyxrQkFBa0IsSUFBSXBELFNBQVMsS0FBSztBQUc1RCxRQUFNLENBQUNxRCxpQkFBaUJDLGtCQUFrQixJQUFJdEQsU0FBUyxJQUFJO0FBQzNELFFBQU0sQ0FBQ3VELG9CQUFvQkMscUJBQXFCLElBQUl4RCxTQUFTLEtBQUs7QUFDbEUsUUFBTSxDQUFDeUQsYUFBYUMsY0FBYyxJQUFJMUQsU0FBUztBQUFBLElBQzdDMkQsVUFBVTtBQUFBLElBQ1ZDLFVBQVU7QUFBQSxJQUNWQyxlQUFlO0FBQUEsSUFDZkMsaUJBQWlCO0FBQUEsSUFDakJDLGNBQWM7QUFBQSxJQUNkQyxhQUFhO0FBQUEsSUFDYkMsaUJBQWlCO0FBQUEsSUFDakJDLGNBQWM7QUFBQSxJQUNkQyxjQUFjO0FBQUEsSUFDZEMsY0FBYztBQUFBLElBQ2RDLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFHRCxRQUFNQyx3QkFBd0IsT0FBT0MsUUFBUUMsU0FBU0MsV0FBVztBQUMvRCxRQUFJLENBQUNGLFVBQVUsQ0FBQ0MsV0FBVyxDQUFDQyxRQUFRO0FBQ2xDQyxjQUFRQyxJQUFJLCtDQUErQztBQUMzRCxhQUFPO0FBQUEsSUFDVDtBQUVBdkIsdUJBQW1CLElBQUk7QUFFdkIsUUFBSTtBQUNGLFlBQU13QixXQUFXLE1BQU03RCxJQUFJOEQ7QUFBQUEsUUFDekIsMkNBQTJDTixNQUFNLGFBQWFDLE9BQU8sV0FBV0MsTUFBTTtBQUFBLE1BQ3hGO0FBRUFDLGNBQVFDLElBQUksK0JBQStCQyxTQUFTRSxJQUFJO0FBRXhELFVBQUlGLFNBQVNFLFFBQVFGLFNBQVNFLEtBQUtDLFNBQVM7QUFDMUMsY0FBTUMsZUFBZUosU0FBU0UsS0FBS0E7QUFDbkM1Qiw0QkFBb0I4QixZQUFZO0FBR2hDLFlBQUlBLGFBQWFDLGNBQWMsTUFBTTtBQUNuQzdELGNBQUk4RCxNQUFNO0FBQUEsWUFDUkMsU0FBUztBQUFBLFlBQ1RDLGFBQWE7QUFBQSxZQUNiQyxVQUFVO0FBQUEsVUFDWixDQUFDO0FBRUQzQix5QkFBZTtBQUFBLFlBQ2JDLFVBQVU7QUFBQSxZQUNWQyxVQUFVO0FBQUEsWUFDVkMsZUFBZTtBQUFBLFlBQ2ZDLGlCQUFpQjtBQUFBLFlBQ2pCQyxjQUFjaUIsYUFBYU0saUJBQWlCO0FBQUEsWUFDNUN0QixhQUFhZ0IsYUFBYU8sZ0JBQWdCO0FBQUEsWUFDMUN0QixpQkFBaUJlLGFBQWFRLG9CQUFvQjtBQUFBLFlBQ2xEdEIsY0FBY2MsYUFBYVMsaUJBQWlCO0FBQUEsWUFDNUN0QixjQUFjYSxhQUFhVSxpQkFBaUI7QUFBQSxZQUM1Q3RCLGNBQWNZLGFBQWFXLGtCQUFrQjtBQUFBLFlBQzdDdEIsVUFBVTtBQUFBLFVBQ1osQ0FBQztBQUVEZiw2QkFBbUIsSUFBSTtBQUN2Qi9CLHFCQUFXcUUsZUFBZTtBQUFBLFlBQ3hCQyxhQUFhO0FBQUEsVUFDZixDQUFDO0FBRUQsaUJBQU9iO0FBQUFBLFFBQ1Q7QUFHQSxZQUFJQSxhQUFhYyxtQkFBbUI7QUFDbEMsZ0JBQU1DLG9CQUFvQi9FLE1BQU1nRSxhQUFhYyxpQkFBaUI7QUFFOURwQyx5QkFBZTtBQUFBLFlBQ2JDLFVBQVVvQztBQUFBQSxZQUNWbkMsVUFBVTtBQUFBLFlBQ1ZDLGVBQWU7QUFBQSxZQUNmQyxpQkFBaUJrQixhQUFhZ0IsZ0JBQWdCO0FBQUEsWUFDOUNqQyxjQUFjaUIsYUFBYU0saUJBQWlCO0FBQUEsWUFDNUN0QixhQUFhZ0IsYUFBYU8sZ0JBQWdCO0FBQUEsWUFDMUN0QixpQkFBaUJlLGFBQWFRLG9CQUFvQjtBQUFBLFlBQ2xEdEIsY0FBY2MsYUFBYVMsaUJBQWlCO0FBQUEsWUFDNUN0QixjQUFjYSxhQUFhVSxpQkFBaUI7QUFBQSxZQUM1Q3RCLGNBQWNZLGFBQWFXLGtCQUFrQjtBQUFBLFlBQzdDdEIsVUFBVTtBQUFBLFVBQ1osQ0FBQztBQUVEZiw2QkFBbUJ5QyxpQkFBaUI7QUFFcEN4RSxxQkFBV3FFLGVBQWU7QUFBQSxZQUN4QkMsYUFBYUU7QUFBQUEsVUFDZixDQUFDO0FBR0QsZ0JBQU1FLGNBQWNqQixhQUFhZ0IsZ0JBQWdCO0FBQ2pENUUsY0FBSTJELFFBQVE7QUFBQSxZQUNWSSxTQUFTO0FBQUEsWUFDVEMsYUFBYSxRQUFRYSxXQUFXLGFBQWFGLGtCQUFrQkcsT0FBTyxZQUFZLENBQUM7QUFBQSxZQUNuRmIsVUFBVTtBQUFBLFVBQ1osQ0FBQztBQUVELGlCQUFPTDtBQUFBQSxRQUNULE9BQU87QUFDTDVELGNBQUkrRSxRQUFRO0FBQUEsWUFDVmhCLFNBQVM7QUFBQSxZQUNUQyxhQUFhO0FBQUEsWUFDYkMsVUFBVTtBQUFBLFVBQ1osQ0FBQztBQUNELGlCQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0YsT0FBTztBQUNMakUsWUFBSThELE1BQU07QUFBQSxVQUNSQyxTQUFTO0FBQUEsVUFDVEMsYUFBYTtBQUFBLFFBQ2YsQ0FBQztBQUNELGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRixTQUFTRixPQUFPO0FBQ2RSLGNBQVFRLE1BQU0scUNBQXFDQSxLQUFLO0FBRXhELFVBQUlBLE1BQU1OLFVBQVVFLE1BQU1LLFNBQVNpQixTQUFTLFFBQVEsR0FBRztBQUNyRGhGLFlBQUk4RCxNQUFNO0FBQUEsVUFDUkMsU0FBUztBQUFBLFVBQ1RDLGFBQWE7QUFBQSxVQUNiQyxVQUFVO0FBQUEsUUFDWixDQUFDO0FBQ0QzQix1QkFBZSxDQUFBMkMsVUFBUyxFQUFFLEdBQUdBLE1BQU1oQyxVQUFVLEtBQUssRUFBRTtBQUFBLE1BQ3RELE9BQU87QUFDTGpELFlBQUk4RCxNQUFNO0FBQUEsVUFDUkMsU0FBUztBQUFBLFVBQ1RDLGFBQWFGLE1BQU1OLFVBQVVFLE1BQU1LLFdBQVc7QUFBQSxRQUNoRCxDQUFDO0FBQUEsTUFDSDtBQUNBLGFBQU87QUFBQSxJQUNULFVBQUM7QUFDQy9CLHlCQUFtQixLQUFLO0FBQUEsSUFDMUI7QUFBQSxFQUNGO0FBR0EsUUFBTWtELG9CQUFvQixZQUFZO0FBQ3BDLFFBQUk7QUFDRixZQUFNQyxVQUFVQyxhQUFhQyxRQUFRLE1BQU07QUFDM0MsVUFBSSxDQUFDRixRQUFTO0FBQ2QsWUFBTUcsT0FBT0MsS0FBS0MsTUFBTUwsT0FBTztBQUMvQixZQUFNaEMsU0FBU21DLEtBQUtHO0FBQ3BCLFVBQUksQ0FBQ3RDLE9BQVE7QUFFYixVQUFJO0FBQ0YsY0FBTXVDLE1BQU0sTUFBTS9GLElBQUk4RCxJQUFJLG9CQUFvQk4sTUFBTSxFQUFFO0FBQ3RELGNBQU13QyxPQUFPRCxJQUFJaEMsS0FBS2lDLFFBQVFMLEtBQUtNLGNBQWNOLEtBQUtPLGFBQWFQLEtBQUtLO0FBQ3hFLGNBQU1HLFFBQVFKLElBQUloQyxLQUFLcUMsZ0JBQWdCVCxLQUFLUyxnQkFBZ0JULEtBQUtVO0FBQ2pFLGNBQU1DLFFBQVFQLElBQUloQyxLQUFLdUMsU0FBU1gsS0FBS1c7QUFFckMzRSxxQkFBYXFFLElBQUk7QUFDakJuRSxtQkFBVzJCLE1BQU07QUFDakJ2QixzQkFBY2tFLEtBQUs7QUFDbkJwRSxzQkFBY3VFLEtBQUs7QUFFbkI5RixtQkFBV3FFLGVBQWU7QUFBQSxVQUN4Qm5ELFdBQVdzRTtBQUFBQSxVQUNYcEUsU0FBUzRCO0FBQUFBLFVBQ1R4QixZQUFZbUU7QUFBQUEsVUFDWnJFLFlBQVl3RTtBQUFBQSxRQUNkLENBQUM7QUFBQSxNQUNILFNBQVNDLFlBQVk7QUFDbkIsY0FBTVAsT0FBT0wsS0FBS08sYUFBYVAsS0FBS0ssUUFBUUwsS0FBS00sY0FBYztBQUMvRCxjQUFNRSxRQUFRUixLQUFLUyxnQkFBZ0JULEtBQUtVO0FBQ3hDLGNBQU1DLFFBQVFYLEtBQUtXO0FBRW5CM0UscUJBQWFxRSxJQUFJO0FBQ2pCbkUsbUJBQVcyQixNQUFNO0FBQ2pCdkIsc0JBQWNrRSxLQUFLO0FBQ25CcEUsc0JBQWN1RSxLQUFLO0FBRW5COUYsbUJBQVdxRSxlQUFlO0FBQUEsVUFDeEJuRCxXQUFXc0U7QUFBQUEsVUFDWHBFLFNBQVM0QjtBQUFBQSxVQUNUeEIsWUFBWW1FO0FBQUFBLFVBQ1pyRSxZQUFZd0U7QUFBQUEsUUFDZCxDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsU0FBU25DLE9BQU87QUFDZFIsY0FBUVEsTUFBTSxrQ0FBa0NBLEtBQUs7QUFDckR4QyxtQkFBYSxPQUFPO0FBQ3BCbkIsaUJBQVdxRSxlQUFlLEVBQUVuRCxXQUFXLFFBQVEsQ0FBQztBQUFBLElBQ2xEO0FBQUEsRUFDRjtBQUVBLFFBQU04RSxhQUFhLFlBQVk7QUFDN0IsUUFBSTtBQUNGM0Ysc0JBQWdCLElBQUk7QUFDcEIsWUFBTWdELFdBQVcsTUFBTTdELElBQUk4RCxJQUFJLGdCQUFnQjtBQUMvQ25ELGVBQVNrRCxTQUFTRSxRQUFRLEVBQUU7QUFBQSxJQUM5QixTQUFTSSxPQUFPO0FBQ2RSLGNBQVFRLE1BQU0seUJBQXlCQSxLQUFLO0FBQzVDOUQsVUFBSThELE1BQU0sRUFBRUMsU0FBUyxTQUFTQyxhQUFhLHlCQUF5QixDQUFDO0FBQUEsSUFDdkUsVUFBQztBQUNDeEQsc0JBQWdCLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNEYsbUJBQW1CLE9BQU9oRCxTQUFTRCxRQUFRa0QsaUJBQWlCO0FBQ2hFLFFBQUksQ0FBQ2pELFFBQVMsUUFBTyxFQUFFa0QsT0FBTyxHQUFHckQsVUFBVSxNQUFNO0FBRWpELFFBQUk7QUFDRixZQUFNTyxXQUFXLE1BQU03RCxJQUFJOEQ7QUFBQUEsUUFDekIsd0NBQXdDTCxPQUFPO0FBQUEsTUFDakQ7QUFDQSxZQUFNTSxPQUFPRixTQUFTRTtBQUV0QixVQUFJLENBQUNBLFFBQVEsQ0FBQ0EsS0FBS0MsU0FBUztBQUMxQixlQUFPLEVBQUUyQyxPQUFPLEdBQUdyRCxVQUFVLE1BQU07QUFBQSxNQUNyQztBQUVBLFlBQU1xRCxRQUFRNUMsS0FBSzRDLFNBQVM7QUFDNUIsWUFBTUMsYUFBYTdDLEtBQUs4QyxpQkFBaUI7QUFDekMsWUFBTXZELFdBQVdzRCxXQUFXRTtBQUFBQSxRQUMxQixDQUFDQyxTQUNDQyxPQUFPRCxLQUFLRSxPQUFPLE1BQU1ELE9BQU94RCxNQUFNLEtBQ3RDd0QsT0FBT0QsS0FBS3JELE1BQU0sTUFBTXNELE9BQU9OLFlBQVk7QUFBQSxNQUMvQztBQUVBLGFBQU8sRUFBRUMsT0FBT3JELFNBQVM7QUFBQSxJQUMzQixTQUFTYSxPQUFPO0FBQ2RSLGNBQVFRLE1BQU0saUNBQWlDQSxLQUFLO0FBQ3BELGFBQU8sRUFBRXdDLE9BQU8sR0FBR3JELFVBQVUsTUFBTTtBQUFBLElBQ3JDO0FBQUEsRUFDRjtBQUVBLFFBQU00RCxvQkFBb0IsT0FBT3pELFlBQVk7QUFDM0NoQyx1QkFBbUJnQyxPQUFPO0FBRTFCLFVBQU0wRCxnQkFBZ0JuRyxhQUFhb0csS0FBSyxDQUFDQyxNQUFNQSxFQUFFQyxPQUFPN0QsT0FBTztBQUMvRCxRQUFJLENBQUMwRCxjQUFlO0FBRXBCaEcsb0JBQWdCZ0csY0FBY0ksT0FBTztBQUVyQy9HLGVBQVdxRSxlQUFlO0FBQUEsTUFDeEIyQyxhQUFhQztBQUFBQSxNQUNiQyxXQUFXUCxjQUFjTztBQUFBQSxNQUN6QkMsV0FBV1IsY0FBY1E7QUFBQUEsTUFDekJDLFNBQVNULGNBQWNTO0FBQUFBLE1BQ3ZCQyxjQUFjVixjQUFjVTtBQUFBQSxNQUM1QkMsV0FBV1gsY0FBY1c7QUFBQUEsTUFDekJDLGNBQWNaLGNBQWNZO0FBQUFBLE1BQzVCQyxZQUFZYixjQUFjYTtBQUFBQSxJQUM1QixDQUFDO0FBR0Q3Rix3QkFBb0IsSUFBSTtBQUN4QlEsbUJBQWU7QUFBQSxNQUNiQyxVQUFVO0FBQUEsTUFDVkMsVUFBVTtBQUFBLE1BQ1ZDLGVBQWU7QUFBQSxNQUNmQyxpQkFBaUI7QUFBQSxNQUNqQkMsY0FBYztBQUFBLE1BQ2RDLGFBQWE7QUFBQSxNQUNiQyxpQkFBaUI7QUFBQSxNQUNqQkMsY0FBYztBQUFBLE1BQ2RDLGNBQWM7QUFBQSxNQUNkQyxjQUFjO0FBQUEsTUFDZEMsVUFBVTtBQUFBLElBQ1osQ0FBQztBQUNEZix1QkFBbUIsSUFBSTtBQUN2Qi9CLGVBQVdxRSxlQUFlO0FBQUEsTUFDeEJDLGFBQWE7QUFBQSxJQUNmLENBQUM7QUFBQSxFQUNIO0FBR0EsUUFBTW1ELHFCQUFxQixPQUFPQyxVQUFVO0FBQzFDN0csMkJBQXVCNkcsS0FBSztBQUU1QixVQUFNeEUsU0FBU3hDLGFBQWFnSCxLQUFLO0FBQ2pDLFFBQUksQ0FBQ3hFLE9BQVE7QUFFYm5DLDRCQUF3Qm1DLE9BQU95RSxZQUFZO0FBRTNDM0gsZUFBV3FFLGVBQWU7QUFBQSxNQUN4QjZCLGNBQWNoRCxPQUFPZ0Q7QUFBQUEsSUFDdkIsQ0FBQztBQUdELFVBQU1sRCxTQUFTaEQsV0FBVzRILGNBQWMsY0FBYztBQUN0RCxRQUFJNUUsVUFBVWhDLG1CQUFtQmtDLE9BQU9nRCxjQUFjO0FBQ3BELFlBQU1uRCxzQkFBc0JDLFFBQVFoQyxpQkFBaUJrQyxPQUFPZ0QsWUFBWTtBQUFBLElBQzFFO0FBQUEsRUFDRjtBQUVBLFFBQU0yQiw2QkFBNkIsT0FBTzdFLFdBQVc7QUFDbkQsUUFBSTtBQUNGLFlBQU1LLFdBQVcsTUFBTTdELElBQUlzSTtBQUFBQSxRQUN6QixtQ0FBbUM5RSxNQUFNO0FBQUEsTUFDM0M7QUFDQSxZQUFNK0UsV0FBVzFFLFNBQVNFLFFBQVFGLFNBQVNFLE1BQU1BLFFBQVE7QUFFekQsVUFBSXdFLFlBQVlBLFNBQVNDLFNBQVMsR0FBRztBQUNuQyxjQUFNQyxjQUFjLENBQUM7QUFFckIsbUJBQVcxQixRQUFRd0IsVUFBVTtBQUMzQixnQkFBTUcsYUFBYTNCLE1BQU0yQjtBQUN6QixnQkFBTUMsWUFBWUQsWUFBWUU7QUFFOUIsY0FBSSxDQUFDRCxXQUFXN0MsSUFBSztBQUVyQixnQkFBTVksZUFBZWdDLFlBQVluQixXQUFXbUIsWUFBWUcsaUJBQWlCO0FBRXpFLGdCQUFNbkcsZUFBYyxNQUFNK0Q7QUFBQUEsWUFDeEJrQyxXQUFXN0M7QUFBQUEsWUFDWHRDO0FBQUFBLFlBQ0FrRDtBQUFBQSxVQUNGO0FBRUEsY0FBSXFCLGVBQWU7QUFDbkIsY0FBSUMsYUFBYTtBQUNqQixjQUFJRixZQUFZO0FBRWhCLGNBQUlZLFlBQVlJLE9BQU85QyxNQUFNO0FBQzNCK0IsMkJBQWU7QUFDZkQsd0JBQVlZLFdBQVdJLE1BQU05QztBQUM3QmdDLHlCQUFhLEdBQUdVLFdBQVdJLE1BQU05QyxJQUFJLE1BQU0wQyxXQUFXSSxNQUFNMUMsWUFBWTtBQUFBLFVBQzFFLFdBQVd1QyxXQUFXRyxPQUFPOUMsTUFBTTtBQUNqQytCLDJCQUFlO0FBQ2ZELHdCQUFZYSxVQUFVRyxNQUFNOUM7QUFDNUJnQyx5QkFBYSxHQUFHVyxVQUFVRyxNQUFNOUMsSUFBSSxNQUFNMkMsVUFBVUcsTUFBTTFDLFlBQVk7QUFBQSxVQUN4RTtBQUVBLGNBQUksQ0FBQ3FDLFlBQVlFLFVBQVU3QyxHQUFHLEdBQUc7QUFDL0IyQyx3QkFBWUUsVUFBVTdDLEdBQUcsSUFBSTtBQUFBLGNBQzNCd0IsSUFBSXFCLFVBQVU3QztBQUFBQSxjQUNkNEIsV0FBV2lCLFVBQVVJO0FBQUFBLGNBQ3JCcEIsV0FBV2dCLFdBQVdLLGFBQ2xCTCxVQUFVSyxXQUFXQyxNQUFNLEdBQUcsRUFBRSxDQUFDLElBQ2pDO0FBQUEsY0FDSnJCLFNBQVNlLFdBQVdPLFdBQ2hCUCxVQUFVTyxTQUFTRCxNQUFNLEdBQUcsRUFBRSxDQUFDLElBQy9CO0FBQUEsY0FDSnBCLGNBQWNuRixhQUFZaUU7QUFBQUEsY0FDMUJtQjtBQUFBQSxjQUNBQztBQUFBQSxjQUNBQztBQUFBQSxjQUNBVCxTQUFTO0FBQUEsWUFDWDtBQUFBLFVBQ0Y7QUFFQWtCLHNCQUFZRSxVQUFVN0MsR0FBRyxFQUFFeUIsUUFBUTRCLEtBQUs7QUFBQSxZQUN0Q3pDO0FBQUFBLFlBQ0F5QixjQUFjTyxZQUFZNUM7QUFBQUEsWUFDMUJ4QyxVQUFVWixhQUFZWTtBQUFBQSxVQUN4QixDQUFDO0FBQUEsUUFDSDtBQUVBLGNBQU04RixjQUFjQyxPQUFPQyxPQUFPYixXQUFXO0FBQzdDeEgsd0JBQWdCbUksV0FBVztBQUUzQixZQUFJQSxZQUFZWixTQUFTLEdBQUc7QUFDMUIsZ0JBQU1lLGFBQWFILFlBQVksQ0FBQztBQUNoQzNILDZCQUFtQjhILFdBQVdqQyxFQUFFO0FBQ2hDbkcsMEJBQWdCb0ksV0FBV2hDLE9BQU87QUFFbEMvRyxxQkFBV3FFLGVBQWU7QUFBQSxZQUN4QnJELGlCQUFpQitILFdBQVdqQztBQUFBQSxZQUM1QkksV0FBVzZCLFdBQVc3QjtBQUFBQSxZQUN0QkMsV0FBVzRCLFdBQVc1QjtBQUFBQSxZQUN0QkMsU0FBUzJCLFdBQVczQjtBQUFBQSxZQUNwQkMsY0FBYzBCLFdBQVcxQjtBQUFBQSxZQUN6QkMsV0FBV3lCLFdBQVd6QjtBQUFBQSxZQUN0QkMsY0FBY3dCLFdBQVd4QjtBQUFBQSxZQUN6QkMsWUFBWXVCLFdBQVd2QjtBQUFBQSxVQUN6QixDQUFDO0FBR0QsY0FBSXVCLFdBQVdoQyxRQUFRaUIsU0FBUyxHQUFHO0FBQ2pDLGtCQUFNZ0IsY0FBY0QsV0FBV2hDLFFBQVEsQ0FBQztBQUN4QyxnQkFBSSxDQUFDaUMsWUFBWWxHLFVBQVU7QUFDekJqQyxxQ0FBdUIsQ0FBQztBQUN4QmIseUJBQVdxRSxlQUFlO0FBQUEsZ0JBQ3hCNkIsY0FBYzhDLFlBQVk5QztBQUFBQSxnQkFDMUJjLGFBQWE7QUFBQSxjQUNmLENBQUM7QUFDRGpHLHNDQUF3QmlJLFlBQVlyQixZQUFZO0FBR2hELG9CQUFNNUU7QUFBQUEsZ0JBQ0pDO0FBQUFBLGdCQUNBK0YsV0FBV2pDO0FBQUFBLGdCQUNYa0MsWUFBWTlDO0FBQUFBLGNBQ2Q7QUFBQSxZQUNGLE9BQU87QUFFTHJHLGtCQUFJK0UsUUFBUTtBQUFBLGdCQUNWaEIsU0FBUztBQUFBLGdCQUNUQyxhQUFhO0FBQUEsZ0JBQ2JDLFVBQVU7QUFBQSxjQUNaLENBQUM7QUFBQSxZQUNIO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGLE9BQU87QUFDTGpFLFlBQUkrRSxRQUFRO0FBQUEsVUFDVmhCLFNBQVM7QUFBQSxVQUNUQyxhQUFhO0FBQUEsUUFDZixDQUFDO0FBQ0RwRCx3QkFBZ0IsRUFBRTtBQUNsQk0sZ0NBQXdCLElBQUk7QUFDNUJmLG1CQUFXcUUsZUFBZTtBQUFBLFVBQ3hCaUQsV0FBVztBQUFBLFVBQ1hDLGNBQWM7QUFBQSxVQUNkQyxZQUFZO0FBQUEsUUFDZCxDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsU0FBUzdELE9BQU87QUFDZFIsY0FBUVEsTUFBTSxvQ0FBb0NBLEtBQUs7QUFDdkQ5RCxVQUFJOEQsTUFBTTtBQUFBLFFBQ1JDLFNBQVM7QUFBQSxRQUNUQyxhQUFhO0FBQUEsTUFDZixDQUFDO0FBQ0RwRCxzQkFBZ0IsRUFBRTtBQUNsQk0sOEJBQXdCLElBQUk7QUFBQSxJQUM5QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNa0ksNkJBQTZCQSxDQUFDakcsV0FBVztBQUM3QyxVQUFNa0csZUFBZWhKLE1BQU0wRyxLQUFLLENBQUN1QyxNQUFNQSxFQUFFN0QsUUFBUXRDLE1BQU07QUFDdkQsUUFBSWtHLGNBQWM7QUFDaEIsWUFBTUUsUUFBUUYsYUFBYXhELGFBQWF3RCxhQUFhMUQ7QUFDckQsWUFBTTZELFNBQVNILGFBQWF0RCxnQkFBZ0JzRCxhQUFhckQ7QUFDekQ3RixpQkFBV3FFLGVBQWU7QUFBQSxRQUN4QmlGLGdCQUFnQkY7QUFBQUEsUUFDaEJHLGNBQWNGO0FBQUFBLFFBQ2RHLGNBQWN4RztBQUFBQSxRQUNka0UsV0FBVztBQUFBLFFBQ1hoQixjQUFjO0FBQUEsUUFDZG9CLFdBQVc7QUFBQSxRQUNYQyxjQUFjO0FBQUEsUUFDZEMsWUFBWTtBQUFBLE1BQ2QsQ0FBQztBQUNEL0csc0JBQWdCLEVBQUU7QUFDbEJNLDhCQUF3QixJQUFJO0FBQzVCWSwwQkFBb0IsSUFBSTtBQUN4QlEscUJBQWU7QUFBQSxRQUNiQyxVQUFVO0FBQUEsUUFDVkMsVUFBVTtBQUFBLFFBQ1ZDLGVBQWU7QUFBQSxRQUNmQyxpQkFBaUI7QUFBQSxRQUNqQkMsY0FBYztBQUFBLFFBQ2RDLGFBQWE7QUFBQSxRQUNiQyxpQkFBaUI7QUFBQSxRQUNqQkMsY0FBYztBQUFBLFFBQ2RDLGNBQWM7QUFBQSxRQUNkQyxjQUFjO0FBQUEsUUFDZEMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUNEZix5QkFBbUIsSUFBSTtBQUN2Qi9CLGlCQUFXcUUsZUFBZTtBQUFBLFFBQ3hCQyxhQUFhO0FBQUEsTUFDZixDQUFDO0FBQ0R1RCxpQ0FBMkI3RSxNQUFNO0FBQUEsSUFDbkM7QUFBQSxFQUNGO0FBRUEsUUFBTXlHLHFCQUFxQixPQUFPWCxXQUFXO0FBQzNDLFFBQUk7QUFDRnZJLGlCQUFXLElBQUk7QUFFZixZQUFNb0csZ0JBQWdCbkcsYUFBYW9HO0FBQUFBLFFBQ2pDLENBQUNDLE1BQU1BLEVBQUVDLE9BQU9nQyxPQUFPOUg7QUFBQUEsTUFDekI7QUFFQSxZQUFNMEksaUJBQWlCaEosYUFBYW9JLE9BQU85QixXQUFXO0FBRXRELFVBQUksQ0FBQ0wsZUFBZTtBQUNsQjlHLFlBQUk4RCxNQUFNO0FBQUEsVUFDUkMsU0FBUztBQUFBLFVBQ1RDLGFBQWE7QUFBQSxRQUNmLENBQUM7QUFDRHRELG1CQUFXLEtBQUs7QUFDaEI7QUFBQSxNQUNGO0FBR0EsVUFBSW1CLGtCQUFrQmdDLGNBQWMsUUFBUWdHLGdCQUFnQjVHLFVBQVU7QUFDcEVqRCxZQUFJOEQsTUFBTTtBQUFBLFVBQ1JDLFNBQVM7QUFBQSxVQUNUQyxhQUFhO0FBQUEsUUFDZixDQUFDO0FBQ0R0RCxtQkFBVyxLQUFLO0FBQ2hCO0FBQUEsTUFDRjtBQUVBLFlBQU1vSixnQkFBZ0JiLE9BQU9jLGNBQ3pCZCxPQUFPYyxZQUFZakYsT0FBTyxPQUFPLElBQ2pDO0FBR0osWUFBTWtGLG9CQUFvQmYsT0FBT3hFLGNBQzdCd0UsT0FBT3hFLFlBQVlLLE9BQU8sWUFBWSxJQUN0QzdDLGtCQUNBQSxnQkFBZ0I2QyxPQUFPLFlBQVksSUFDbkM7QUFFSnhCLGNBQVFDLElBQUkseUJBQXlCeUcsaUJBQWlCO0FBRXRELFlBQU1DLFVBQVU7QUFBQSxRQUNkQyxNQUFNakIsT0FBT2lCLE9BQ1RqQixPQUFPaUIsS0FBS3BGLE9BQU8sWUFBWSxJQUMvQmxGLE1BQU0sRUFBRWtGLE9BQU8sWUFBWTtBQUFBLFFBQy9CNkUsY0FBY1YsT0FBT1U7QUFBQUEsUUFDckJGLGdCQUFnQlIsT0FBT1E7QUFBQUEsUUFDdkJDLGNBQWNULE9BQU9TO0FBQUFBLFFBQ3JCckMsV0FBV1AsY0FBY087QUFBQUEsUUFDekJoQixjQUFjd0QsZUFBZXhEO0FBQUFBLFFBQzdCNUIsYUFBYXVGO0FBQUFBLFFBQ2JHLGNBQWNMO0FBQUFBLFFBQ2RyQyxXQUFXWCxjQUFjVztBQUFBQSxRQUN6QkMsY0FBY1osY0FBY1k7QUFBQUEsUUFDNUJDLFlBQVliLGNBQWNhO0FBQUFBLFFBQzFCdkUsU0FBUzBELGNBQWNHO0FBQUFBLFFBQ3ZCbUQsYUFBYW5CLE9BQU9tQixlQUFlN0k7QUFBQUEsUUFDbkNGLFdBQVc0SCxPQUFPNUgsYUFBYUE7QUFBQUEsUUFDL0JNLFlBQVlzSCxPQUFPdEgsY0FBY0E7QUFBQUEsUUFDakNtRyxjQUFjK0IsZUFBZS9CO0FBQUFBLE1BQy9CO0FBRUEsWUFBTXRFLFdBQVcsTUFBTTdELElBQUlzSSxLQUFLLHVCQUF1QmdDLE9BQU87QUFFOURqSyxVQUFJMkQsUUFBUTtBQUFBLFFBQ1ZJLFNBQVM7QUFBQSxRQUNUQyxhQUFhO0FBQUEsTUFDZixDQUFDO0FBRURxRyxpQkFBVyxNQUFNQyxPQUFPQyxNQUFNLEdBQUcsSUFBSTtBQUFBLElBQ3ZDLFNBQVN6RyxPQUFPO0FBQ2RSLGNBQVFRLE1BQU0sVUFBVUEsS0FBSztBQUM3QlIsY0FBUVEsTUFBTSxtQkFBbUJBLE1BQU1OLFFBQVE7QUFDL0N4RCxVQUFJOEQsTUFBTTtBQUFBLFFBQ1JDLFNBQVM7QUFBQSxRQUNUQyxhQUFhRixNQUFNTixVQUFVRSxNQUFNSyxXQUFXO0FBQUEsTUFDaEQsQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDckQsaUJBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUVBN0IsWUFBVSxNQUFNO0FBQ2RzSCxlQUFXO0FBQ1hqQixzQkFBa0I7QUFDbEIvRSxlQUFXcUUsZUFBZSxFQUFFMEYsTUFBTXRLLE1BQU0sRUFBRSxDQUFDO0FBQUEsRUFDN0MsR0FBRyxFQUFFO0FBR0wsUUFBTTRLLG1CQUNKN0osYUFBYXdILFdBQVcsS0FDeEIsQ0FBQ2hILG1CQUNELENBQUNOLGFBQWFzSCxVQUNkLENBQUNsRyxtQkFDREosa0JBQWtCZ0MsY0FBYyxRQUNoQzlDLHdCQUF3QixRQUN4QkYsYUFBYUUsbUJBQW1CLEdBQUdrQyxhQUFhO0FBRWxELFNBQ0UsdUJBQUMsU0FBSSxXQUFVLG9EQUNaaEQ7QUFBQUE7QUFBQUEsSUFDRCx1QkFBQyxTQUFJLFdBQVUsa0ZBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUseUVBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsNkRBQTRELCtCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFVBQU8sU0FBUyxNQUFNcUssT0FBT0MsTUFBTSxHQUFHLHlCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdEO0FBQUEsV0FKbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTXBLO0FBQUFBLFVBQ04sUUFBTztBQUFBLFVBQ1AsVUFBVXlKO0FBQUFBLFVBRVY7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHFDQUFDLFFBQUcsV0FBVSxzREFBcUQsa0NBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDBDQUF5QztBQUFBO0FBQUEsa0JBQzdDLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxxQkFEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUMsS0FBSztBQUFBLGtCQUFMO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE9BQU87QUFBQSxzQkFDTCxFQUFFYSxVQUFVLE1BQU0xRyxTQUFTLDBCQUEwQjtBQUFBLG9CQUFDO0FBQUEsb0JBRXhELFdBQVU7QUFBQSxvQkFFVjtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxXQUFVO0FBQUEsd0JBQ1YsUUFBUSx1QkFBQyxnQkFBYSxXQUFVLG1CQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUF1QztBQUFBO0FBQUEsc0JBSmpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFJcUQ7QUFBQTtBQUFBLGtCQVh2RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBYUE7QUFBQSxnQkFDQSx1QkFBQyxLQUFLLE1BQUwsRUFBVSxNQUFLLFdBQVUsUUFBTSxNQUM5QixpQ0FBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQU0sS0FEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxjQUFhLFFBQU0sTUFDakMsaUNBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFNLEtBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE1BQUssY0FBYSxRQUFNLE1BQ2pDLGlDQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBTSxLQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkEyQkE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDBDQUF5QztBQUFBO0FBQUEsa0JBQzNCO0FBQUEsa0JBQzdCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxxQkFGbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUMsS0FBSztBQUFBLGtCQUFMO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE9BQU87QUFBQSxzQkFDTCxFQUFFMEcsVUFBVSxNQUFNMUcsU0FBUyw0QkFBNEI7QUFBQSxvQkFBQztBQUFBLG9CQUUxRCxXQUFVO0FBQUEsb0JBRVY7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0M7QUFBQSx3QkFDQSxhQUFZO0FBQUEsd0JBQ1osVUFBVXFGO0FBQUFBLHdCQUNWLFNBQVM3STtBQUFBQSx3QkFDVCxpQkFDRUEsZUFDRSx1QkFBQyxRQUFLLE1BQUssV0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFrQixJQUVsQjtBQUFBLHdCQUdKLGNBQWMsQ0FBQ21LLE9BQU9DLFlBQ25CQSxRQUFRQyxTQUFTLElBQ2ZDLFlBQVksRUFDWjdGLFNBQVMwRixNQUFNRyxZQUFZLENBQUM7QUFBQSx3QkFFakMsU0FBU3hLLE1BQU15SyxJQUFJLENBQUN4RixVQUFVO0FBQUEsMEJBQzVCeUYsT0FBT3pGLEtBQUtHO0FBQUFBLDBCQUNabUYsT0FBTyxHQUFHdEYsS0FBS08sYUFBYVAsS0FBS0ssUUFBUSxTQUFTLE1BQU1MLEtBQUtTLGdCQUFnQlQsS0FBS1UsVUFBVSxVQUFVO0FBQUEsd0JBQ3hHLEVBQUU7QUFBQSx3QkFDRixNQUFLO0FBQUE7QUFBQSxzQkFyQlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQXFCYztBQUFBO0FBQUEsa0JBNUJoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBOEJBO0FBQUEsbUJBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBb0NBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsK0ZBQ2I7QUFBQSx1Q0FBQyxTQUNDO0FBQUEseUNBQUMsV0FBTSxXQUFVLDBDQUF5QywrQkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUMsS0FBSztBQUFBLG9CQUFMO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE9BQU8sQ0FBQyxFQUFFeUUsVUFBVSxNQUFNMUcsU0FBUyxZQUFZLENBQUM7QUFBQSxzQkFDaEQsV0FBVTtBQUFBLHNCQUVWLGlDQUFDLFNBQU0sVUFBUSxNQUFDLFdBQVUsaUNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXVEO0FBQUE7QUFBQSxvQkFMekQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU1BO0FBQUEscUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFXQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsMENBQXlDLDZCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQyxLQUFLO0FBQUEsb0JBQUw7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsT0FBTyxDQUFDLEVBQUUwRyxVQUFVLE1BQU0xRyxTQUFTLFlBQVksQ0FBQztBQUFBLHNCQUNoRCxXQUFVO0FBQUEsc0JBRVYsaUNBQUMsU0FBTSxVQUFRLE1BQUMsV0FBVSxpQ0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBdUQ7QUFBQTtBQUFBLG9CQUx6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTUE7QUFBQSxxQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVdBO0FBQUEsbUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeUJBO0FBQUEsY0FFQ3BELGFBQWF3SCxTQUFTLEtBQ3JCLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxTQUFJLFdBQVUseUNBRWI7QUFBQSx5Q0FBQyxTQUNDO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGtEQUFpRDtBQUFBO0FBQUEsc0JBQ25ELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQSx5QkFEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUMsS0FBSztBQUFBLHNCQUFMO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE9BQU87QUFBQSwwQkFDTCxFQUFFc0MsVUFBVSxNQUFNMUcsU0FBUyx1QkFBdUI7QUFBQSx3QkFBQztBQUFBLHdCQUVyRCxXQUFVO0FBQUEsd0JBRVY7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsTUFBSztBQUFBLDRCQUNMLGFBQVk7QUFBQSw0QkFDWixVQUFVOEM7QUFBQUEsNEJBRVRsRyx1QkFBYW1LO0FBQUFBLDhCQUFJLENBQUN2QyxVQUNqQix1QkFBQyxVQUFzQixPQUFPQSxNQUFNdEIsSUFDakNzQixnQkFBTWxCLGFBRElrQixNQUFNdEIsSUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FFQTtBQUFBLDRCQUNEO0FBQUE7QUFBQSwwQkFUSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBVUE7QUFBQTtBQUFBLHNCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBa0JBO0FBQUEsdUJBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBdUJBO0FBQUEsa0JBR0EsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLHNCQUNsRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUEseUJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDLEtBQUs7QUFBQSxzQkFBTDtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxPQUFPO0FBQUEsMEJBQ0wsRUFBRXdELFVBQVUsTUFBTTFHLFNBQVMsd0JBQXdCO0FBQUEsd0JBQUM7QUFBQSx3QkFFdEQsV0FBVTtBQUFBLHdCQUVWO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE1BQUs7QUFBQSw0QkFDTCxhQUFZO0FBQUEsNEJBQ1osVUFBVTZEO0FBQUFBLDRCQUVUL0csdUJBQWFpSztBQUFBQSw4QkFBSSxDQUFDekgsUUFBUXdFLFVBQ3pCO0FBQUEsZ0NBQUM7QUFBQTtBQUFBLGtDQUVDLE9BQU9BO0FBQUFBLGtDQUNQLFVBQVV4RSxPQUFPSjtBQUFBQSxrQ0FBUztBQUFBO0FBQUEsb0NBRWpCSSxPQUFPZ0Q7QUFBQUEsb0NBQ2ZoRCxPQUFPSixXQUFXLHNCQUFzQjtBQUFBO0FBQUE7QUFBQSxnQ0FMcEM0RTtBQUFBQSxnQ0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQU9BO0FBQUEsNEJBQ0Q7QUFBQTtBQUFBLDBCQWRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFlQTtBQUFBO0FBQUEsc0JBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkF1QkE7QUFBQSx1QkEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkE0QkE7QUFBQSxxQkF4REY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF5REE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsbURBQ2I7QUFBQSx5Q0FBQyxTQUNDO0FBQUEsMkNBQUMsV0FBTSxXQUFVLDBDQUF5QyxrQ0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE1BQUssYUFBWSxXQUFVLFFBQ3BDO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDO0FBQUEsd0JBQ0EsV0FBVTtBQUFBO0FBQUEsc0JBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUV5RSxLQUgzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsdUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFVQTtBQUFBLGtCQUNBLHVCQUFDLFNBQ0M7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsMENBQXlDLGdDQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxXQUFVLFdBQVUsUUFDbEM7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0M7QUFBQSx3QkFDQSxXQUFVO0FBQUE7QUFBQSxzQkFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBRXlFLEtBSDNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBS0E7QUFBQSx1QkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVVBO0FBQUEsa0JBQ0EsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSwwQ0FBeUMsNkJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxLQUFLLE1BQUwsRUFBVSxNQUFLLGdCQUFlLFdBQVUsUUFDdkM7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0M7QUFBQSx3QkFDQSxXQUFVO0FBQUE7QUFBQSxzQkFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBRW9GLEtBSHRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBS0E7QUFBQSx1QkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVVBO0FBQUEscUJBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0NBO0FBQUEsZ0JBRUM1Ryx3QkFDQyx1QkFBQyxTQUFJLFdBQVUscURBQW9EO0FBQUE7QUFBQSxrQkFDakRBO0FBQUFBLHFCQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBbkdKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUdBO0FBQUEsY0FHRix1QkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSx1Q0FBQyxTQUNDO0FBQUEseUNBQUMsV0FBTSxXQUFVLDBDQUF5QyxrQ0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE1BQUssYUFBWSxXQUFVLFFBQ3BDO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDO0FBQUEsc0JBQ0EsV0FBVTtBQUFBO0FBQUEsb0JBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUVzRCxLQUh4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEscUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsMENBQXlDLHFDQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxnQkFBZSxXQUFVLFFBQ3ZDO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDO0FBQUEsc0JBQ0EsV0FBVTtBQUFBO0FBQUEsb0JBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUVzRCxLQUh4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEscUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLG1CQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXVCQTtBQUFBLGlCQW5PRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9PQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsc0RBQXFELCtCQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FHQ2MsbUJBQ0MsdUJBQUMsU0FBSSxXQUFVLHlEQUNiLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHVDQUFDLFFBQUssTUFBSyxXQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtCO0FBQUEsZ0JBQ2xCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsbURBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBSUQsQ0FBQ0EsbUJBQW1CRixrQkFBa0JnQyxjQUFjLFFBQ25EO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVE7QUFBQSxrQkFDUixhQUFZO0FBQUEsa0JBQ1osTUFBSztBQUFBLGtCQUNMO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUNWLE1BQU0sdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0I7QUFBQTtBQUFBLGdCQU41QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNZ0M7QUFBQSxjQUlqQyxDQUFDOUIsbUJBQW1CTSxZQUFZRSxZQUFZVixrQkFBa0JnQyxjQUFjLFFBQzNFLHVCQUFDLFNBQUksV0FBVSwyREFDYixpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSx1Q0FBQyxvQkFBaUIsV0FBVSw0QkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0Q7QUFBQSxnQkFDcEQsdUJBQUMsU0FDQyxpQ0FBQyxVQUFLLFdBQVUseUJBQ2Q7QUFBQSx5Q0FBQyxZQUFPLGtDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBCO0FBQUEsa0JBQVU7QUFBQSxrQkFDbkN4QixZQUFZRSxTQUFTdUMsT0FBTyxZQUFZO0FBQUEsa0JBQ3hDekMsWUFBWUssbUJBQ1g7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FDRUwsWUFBWUssb0JBQW9CLGlCQUM1QixTQUNBO0FBQUEsc0JBRU4sV0FBVTtBQUFBLHNCQUVUTCxzQkFBWUs7QUFBQUE7QUFBQUEsb0JBUmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVNBO0FBQUEscUJBYko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFlQSxLQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlCQTtBQUFBLG1CQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW9CQSxLQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNCQTtBQUFBLGNBR0QsQ0FBQ1gsbUJBQW1CLENBQUNNLFlBQVlFLFlBQVk1QixhQUFhd0gsU0FBUyxLQUFLdEcsa0JBQWtCZ0MsY0FBYyxRQUN2RztBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFRO0FBQUEsa0JBQ1IsYUFBWTtBQUFBLGtCQUNaLE1BQUs7QUFBQSxrQkFDTDtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFDVixNQUFNLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9CO0FBQUE7QUFBQSxnQkFONUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTWdDO0FBQUEsY0FJbEMsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsdUNBQUMsU0FDQztBQUFBLHlDQUFDLFdBQU0sV0FBVSwwQ0FBeUM7QUFBQTtBQUFBLG9CQUMzQyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdDO0FBQUEsdUJBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDLEtBQUs7QUFBQSxvQkFBTDtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxPQUFPO0FBQUEsd0JBQ0w7QUFBQSwwQkFDRTRHLFVBQVU7QUFBQSwwQkFDVjFHLFNBQVM7QUFBQSx3QkFDWDtBQUFBLHNCQUFDO0FBQUEsc0JBRUgsV0FBVTtBQUFBLHNCQUVWO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE9BQU8sRUFBRWlILE9BQU8sT0FBTztBQUFBLDBCQUN2QixXQUFVO0FBQUEsMEJBQ1YsYUFBWTtBQUFBLDBCQUNaLFFBQU87QUFBQSwwQkFDUCxVQUFVbkosa0JBQWtCZ0MsY0FBYztBQUFBLDBCQUMxQyxjQUFjLENBQUNvSCxZQUFZO0FBQ3pCLG1DQUFPQSxXQUFXQSxVQUFVckwsTUFBTSxFQUFFc0wsUUFBUSxLQUFLO0FBQUEsMEJBQ25EO0FBQUE7QUFBQSx3QkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBUUk7QUFBQTtBQUFBLG9CQWxCTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBb0JBO0FBQUEsa0JBQ0M3SSxZQUFZRSxZQUFZVixrQkFBa0JnQyxjQUFjLFFBQ3ZELHVCQUFDLFNBQUksV0FBVSwrQkFBOEIsb0VBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFFRGhDLGtCQUFrQmdDLGNBQWMsUUFDL0IsdUJBQUMsU0FBSSxXQUFVLDZCQUE0Qiw2REFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQWpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW1DQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsMENBQXlDO0FBQUE7QUFBQSxvQkFDM0MsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQztBQUFBLHVCQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQyxLQUFLO0FBQUEsb0JBQUw7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsY0FBY2pFLE1BQU07QUFBQSxzQkFDcEIsT0FBTztBQUFBLHdCQUNMO0FBQUEsMEJBQ0U2SyxVQUFVO0FBQUEsMEJBQ1YxRyxTQUFTO0FBQUEsd0JBQ1g7QUFBQSxzQkFBQztBQUFBLHNCQUVILFdBQVU7QUFBQSxzQkFFVjtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxPQUFPLEVBQUVpSCxPQUFPLE9BQU87QUFBQSwwQkFDdkIsV0FBVTtBQUFBLDBCQUNWLFFBQU87QUFBQSwwQkFDUDtBQUFBLDBCQUNBLGFBQVk7QUFBQSwwQkFDWixZQUFZO0FBQUEsMEJBQ1osVUFBVW5KLGtCQUFrQmdDLGNBQWM7QUFBQTtBQUFBLHdCQVA1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBT2lEO0FBQUE7QUFBQSxvQkFsQm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFvQkE7QUFBQSxxQkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF5QkE7QUFBQSxtQkE5REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkErREE7QUFBQSxpQkFqSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrSUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVMsTUFBTXlHLE9BQU9DLE1BQU07QUFBQSxrQkFDNUIsV0FBVTtBQUFBLGtCQUFtRDtBQUFBO0FBQUEsZ0JBRi9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsVUFBUztBQUFBLGtCQUNUO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUNWLFVBQVVDO0FBQUFBLGtCQUVUM0ksNEJBQWtCZ0MsY0FBYyxPQUFPLG1CQUFtQjtBQUFBO0FBQUEsZ0JBUDdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBO0FBQUEsaUJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQTtBQUFBO0FBQUEsUUEvWEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BZ1lBLEtBallGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrWUE7QUFBQSxTQTFZRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMllBO0FBQUEsT0E3WUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThZQTtBQUVKO0FBQUM5RCxHQXY5QlFELGtCQUFnQjtBQUFBLFVBQ01WLGFBQWFjLGlCQUNyQnBCLEtBQUtzQixPQUFPO0FBQUE7QUFBQStLLEtBRjFCckw7QUF5OUJULGVBQWVBO0FBQWlCLElBQUFxTDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIkZvcm0iLCJJbnB1dCIsIkRhdGVQaWNrZXIiLCJUaW1lUGlja2VyIiwiQnV0dG9uIiwiU2VsZWN0Iiwibm90aWZpY2F0aW9uIiwiU3BpbiIsIlRhZyIsIkFsZXJ0IiwiQ2xvY2tDaXJjbGVPdXRsaW5lZCIsIlVzZXJPdXRsaW5lZCIsIkNhbGVuZGFyT3V0bGluZWQiLCJBUEkiLCJkYXlqcyIsIk9wdGlvbiIsIkNyZWF0ZUJpZFJlcXVlc3QiLCJfcyIsImFwaSIsImNvbnRleHRIb2xkZXIiLCJ1c2VOb3RpZmljYXRpb24iLCJjcmVhdGVGb3JtIiwidXNlRm9ybSIsInVzZXJzIiwic2V0VXNlcnMiLCJsb2FkaW5nVXNlcnMiLCJzZXRMb2FkaW5nVXNlcnMiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImNyZWF0ZUdyb3VwcyIsInNldENyZWF0ZUdyb3VwcyIsImdyb3VwVGlja2V0cyIsInNldEdyb3VwVGlja2V0cyIsInNlbGVjdGVkVGlja2V0SW5kZXgiLCJzZXRTZWxlY3RlZFRpY2tldEluZGV4Iiwic2VsZWN0ZWRFbnJvbGxtZW50SWQiLCJzZXRTZWxlY3RlZEVucm9sbG1lbnRJZCIsInNlbGVjdGVkR3JvdXBJZCIsInNldFNlbGVjdGVkR3JvdXBJZCIsImFkbWluTmFtZSIsInNldEFkbWluTmFtZSIsImFkbWluSWQiLCJzZXRBZG1pbklkIiwiYWRtaW5FbWFpbCIsInNldEFkbWluRW1haWwiLCJhZG1pblBob25lIiwic2V0QWRtaW5QaG9uZSIsImN1c3RvbWVyT3ZlcnZpZXciLCJzZXRDdXN0b21lck92ZXJ2aWV3IiwibG9hZGluZ092ZXJ2aWV3Iiwic2V0TG9hZGluZ092ZXJ2aWV3IiwibmV4dEF1Y3Rpb25EYXRlIiwic2V0TmV4dEF1Y3Rpb25EYXRlIiwibG9hZGluZ05leHRBdWN0aW9uIiwic2V0TG9hZGluZ05leHRBdWN0aW9uIiwiYXVjdGlvbkluZm8iLCJzZXRBdWN0aW9uSW5mbyIsIm5leHREYXRlIiwibGFzdERhdGUiLCJ0b3RhbEF1Y3Rpb25zIiwibmV4dEF1Y3Rpb25UeXBlIiwidG90YWxQYXlhYmxlIiwidG90YWxQcm9maXQiLCJ0b3RhbEludmVzdG1lbnQiLCJ0b3RhbEJhbGFuY2UiLCJ0b3RhbFBlbmFsdHkiLCJ0b3RhbExhdGVGZWUiLCJpc1ByaXplZCIsImZldGNoQ3VzdG9tZXJPdmVydmlldyIsInVzZXJJZCIsImdyb3VwSWQiLCJ0aWNrZXQiLCJjb25zb2xlIiwibG9nIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwic3VjY2VzcyIsIm92ZXJ2aWV3RGF0YSIsImlzX3ByaXplZCIsImVycm9yIiwibWVzc2FnZSIsImRlc2NyaXB0aW9uIiwiZHVyYXRpb24iLCJ0b3RhbF9wYXlhYmxlIiwidG90YWxfcHJvZml0IiwidG90YWxfaW52ZXN0bWVudCIsInRvdGFsX2JhbGFuY2UiLCJ0b3RhbF9wZW5hbHR5IiwidG90YWxfbGF0ZV9mZWUiLCJzZXRGaWVsZHNWYWx1ZSIsImF1Y3Rpb25EYXRlIiwibmV4dF9hdWN0aW9uX2RhdGUiLCJmb3JtYXR0ZWROZXh0RGF0ZSIsImF1Y3Rpb25fdHlwZSIsImF1Y3Rpb25UeXBlIiwiZm9ybWF0Iiwid2FybmluZyIsImluY2x1ZGVzIiwicHJldiIsImZldGNoQWRtaW5Qcm9maWxlIiwidXNlclN0ciIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJ1c2VyIiwiSlNPTiIsInBhcnNlIiwiX2lkIiwicmVzIiwibmFtZSIsImFkbWluX25hbWUiLCJmdWxsX25hbWUiLCJwaG9uZSIsInBob25lX251bWJlciIsIm1vYmlsZSIsImVtYWlsIiwiYWRtaW5FcnJvciIsImZldGNoVXNlcnMiLCJmZXRjaEF1Y3Rpb25JbmZvIiwidGlja2V0TnVtYmVyIiwiY291bnQiLCJwcml6ZWRMaXN0IiwicHJpemVkVGlja2V0cyIsInNvbWUiLCJpdGVtIiwiU3RyaW5nIiwidXNlcl9pZCIsImhhbmRsZUdyb3VwQ2hhbmdlIiwic2VsZWN0ZWRHcm91cCIsImZpbmQiLCJnIiwiaWQiLCJ0aWNrZXRzIiwidGlja2V0SW5kZXgiLCJ1bmRlZmluZWQiLCJncm91cE5hbWUiLCJzdGFydERhdGUiLCJlbmREYXRlIiwiYXVjdGlvbnNEb25lIiwiYWdlbnROYW1lIiwicmVmZXJyZWRUeXBlIiwicmVmZXJyZWRCeSIsImhhbmRsZVRpY2tldENoYW5nZSIsImluZGV4IiwiZW5yb2xsbWVudElkIiwiZ2V0RmllbGRWYWx1ZSIsImZldGNoQ3JlYXRlQ3VzdG9tZXJEZXRhaWxzIiwicG9zdCIsImRhdGFMaXN0IiwibGVuZ3RoIiwiZ3JvdXBlZERhdGEiLCJlbnJvbGxtZW50IiwiZ3JvdXBEYXRhIiwiZ3JvdXAiLCJ0aWNrZXRfbnVtYmVyIiwiYWdlbnQiLCJncm91cF9uYW1lIiwic3RhcnRfZGF0ZSIsInNwbGl0IiwiZW5kX2RhdGUiLCJwdXNoIiwiZmluYWxHcm91cHMiLCJPYmplY3QiLCJ2YWx1ZXMiLCJmaXJzdEdyb3VwIiwiZmlyc3RUaWNrZXQiLCJoYW5kbGVDcmVhdGVDdXN0b21lclNlbGVjdCIsInNlbGVjdGVkVXNlciIsInUiLCJjTmFtZSIsImNQaG9uZSIsInN1YnNjcmliZXJOYW1lIiwibW9iaWxlTnVtYmVyIiwic3Vic2NyaWJlcklkIiwiaGFuZGxlQ3JlYXRlRmluaXNoIiwic2VsZWN0ZWRUaWNrZXQiLCJmb3JtYXR0ZWRUaW1lIiwiYXVjdGlvblRpbWUiLCJhdWN0aW9uRGF0ZVRvU2VuZCIsInBheWxvYWQiLCJkYXRlIiwiYXVjdGlvbl90aW1lIiwiYWRtaW5Vc2VySWQiLCJzZXRUaW1lb3V0Iiwid2luZG93IiwiY2xvc2UiLCJpc1N1Ym1pdERpc2FibGVkIiwicmVxdWlyZWQiLCJpbnB1dCIsIm9wdGlvbiIsImxhYmVsIiwidG9Mb3dlckNhc2UiLCJtYXAiLCJ2YWx1ZSIsIndpZHRoIiwiY3VycmVudCIsInN0YXJ0T2YiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDcmVhdGVCaWRSZXF1ZXN0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJcclxuLy8gaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuLy8gaW1wb3J0IHtcclxuLy8gICBGb3JtLFxyXG4vLyAgIElucHV0LFxyXG4vLyAgIERhdGVQaWNrZXIsXHJcbi8vICAgVGltZVBpY2tlcixcclxuLy8gICBCdXR0b24sXHJcbi8vICAgU2VsZWN0LFxyXG4vLyAgIG5vdGlmaWNhdGlvbixcclxuLy8gICBTcGluLFxyXG4vLyAgIFRhZyxcclxuLy8gICBBbGVydCxcclxuLy8gfSBmcm9tIFwiYW50ZFwiO1xyXG4vLyBpbXBvcnQge1xyXG4vLyAgIENsb2NrQ2lyY2xlT3V0bGluZWQsXHJcbi8vICAgVXNlck91dGxpbmVkLFxyXG4vLyAgIENhbGVuZGFyT3V0bGluZWQsXHJcbi8vIH0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcbi8vIGltcG9ydCBBUEkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuLy8gaW1wb3J0IGRheWpzIGZyb20gXCJkYXlqc1wiO1xyXG5cclxuLy8gY29uc3QgeyBPcHRpb24gfSA9IFNlbGVjdDtcclxuXHJcbi8vIGZ1bmN0aW9uIENyZWF0ZUJpZFJlcXVlc3QoKSB7XHJcbi8vICAgY29uc3QgW2FwaSwgY29udGV4dEhvbGRlcl0gPSBub3RpZmljYXRpb24udXNlTm90aWZpY2F0aW9uKCk7XHJcbi8vICAgY29uc3QgW2NyZWF0ZUZvcm1dID0gRm9ybS51c2VGb3JtKCk7XHJcblxyXG4vLyAgIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtsb2FkaW5nVXNlcnMsIHNldExvYWRpbmdVc2Vyc10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuLy8gICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgLy8gICBjb25zdCBbY3JlYXRlR3JvdXBzLCBzZXRDcmVhdGVHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIC8vICAgY29uc3QgW3NlbGVjdGVkQ3JlYXRlR3JvdXBJbmRleCwgc2V0U2VsZWN0ZWRDcmVhdGVHcm91cEluZGV4XSA9IHVzZVN0YXRlKDApO1xyXG4vLyAgIGNvbnN0IFtjcmVhdGVHcm91cHMsIHNldENyZWF0ZUdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vIC8vICAgY29uc3QgW3NlbGVjdGVkR3JvdXBJZCwgc2V0U2VsZWN0ZWRHcm91cElkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4vLyAgIGNvbnN0IFtncm91cFRpY2tldHMsIHNldEdyb3VwVGlja2V0c10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW3NlbGVjdGVkVGlja2V0SW5kZXgsIHNldFNlbGVjdGVkVGlja2V0SW5kZXhdID0gdXNlU3RhdGUobnVsbCk7XHJcbi8vICAgY29uc3QgW3NlbGVjdGVkRW5yb2xsbWVudElkLCBzZXRTZWxlY3RlZEVucm9sbG1lbnRJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuLy8gICBjb25zdCBbc2VsZWN0ZWRDcmVhdGVHcm91cEluZGV4LHNldFNlbGVjdGVkQ3JlYXRlR3JvdXBJbmRleCBdID0gdXNlU3RhdGUobnVsbCk7XHJcbi8vICAgY29uc3QgW3NlbGVjdGVkR3JvdXBJZCwgc2V0U2VsZWN0ZWRHcm91cElkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG5cclxuLy8gICAvLyBOZXcgc3RhdGUgZm9yIGFkbWluIHVzZXIgKGZvbGxvd2luZyBzYW1lIHBhdHRlcm4gYXMgSGVscEFuZFN1cHBvcnQpXHJcbi8vICAgY29uc3QgW2FkbWluTmFtZSwgc2V0QWRtaW5OYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFthZG1pbklkLCBzZXRBZG1pbklkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFthZG1pbkVtYWlsLCBzZXRBZG1pbkVtYWlsXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4vLyAgIGNvbnN0IFthZG1pblBob25lLCBzZXRBZG1pblBob25lXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuLy8gICAvLyBOZXcgc3RhdGUgZm9yIG5leHQgYXVjdGlvbiBkYXRlXHJcbi8vICAgY29uc3QgW25leHRBdWN0aW9uRGF0ZSwgc2V0TmV4dEF1Y3Rpb25EYXRlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4vLyAgIGNvbnN0IFtsb2FkaW5nTmV4dEF1Y3Rpb24sIHNldExvYWRpbmdOZXh0QXVjdGlvbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW2F1Y3Rpb25JbmZvLCBzZXRBdWN0aW9uSW5mb10gPSB1c2VTdGF0ZSh7XHJcbi8vICAgICBuZXh0RGF0ZTogbnVsbCxcclxuLy8gICAgIGxhc3REYXRlOiBudWxsLFxyXG4vLyAgICAgdG90YWxBdWN0aW9uczogMCxcclxuLy8gICB9KTtcclxuXHJcbi8vICAgLy8g4pyFIEZ1bmN0aW9uIHRvIGZldGNoIGFkbWluIHByb2ZpbGUgKGV4YWN0bHkgbGlrZSBIZWxwQW5kU3VwcG9ydClcclxuLy8gICBjb25zdCBmZXRjaEFkbWluUHJvZmlsZSA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGNvbnN0IHVzZXJTdHIgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbi8vICAgICAgIGlmICghdXNlclN0cikgcmV0dXJuO1xyXG4vLyAgICAgICBjb25zdCB1c2VyID0gSlNPTi5wYXJzZSh1c2VyU3RyKTtcclxuLy8gICAgICAgY29uc3QgdXNlcklkID0gdXNlci5faWQ7XHJcbi8vICAgICAgIGlmICghdXNlcklkKSByZXR1cm47XHJcblxyXG4vLyAgICAgICAvLyBUcnkgdG8gZmV0Y2ggZnJvbSBhZG1pbiBlbmRwb2ludFxyXG4vLyAgICAgICB0cnkge1xyXG4vLyAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IEFQSS5nZXQoYC9hZG1pbi9nZXQtYWRtaW4vJHt1c2VySWR9YCk7XHJcbi8vICAgICAgICAgY29uc3QgbmFtZSA9XHJcbi8vICAgICAgICAgICByZXMuZGF0YS5uYW1lIHx8IHVzZXIuYWRtaW5fbmFtZSB8fCB1c2VyLmZ1bGxfbmFtZSB8fCB1c2VyLm5hbWU7XHJcbi8vICAgICAgICAgY29uc3QgcGhvbmUgPSByZXMuZGF0YS5waG9uZV9udW1iZXIgfHwgdXNlci5waG9uZV9udW1iZXIgfHwgdXNlci5tb2JpbGU7XHJcbi8vICAgICAgICAgY29uc3QgZW1haWwgPSByZXMuZGF0YS5lbWFpbCB8fCB1c2VyLmVtYWlsO1xyXG5cclxuLy8gICAgICAgICBzZXRBZG1pbk5hbWUobmFtZSk7XHJcbi8vICAgICAgICAgc2V0QWRtaW5JZCh1c2VySWQpO1xyXG4vLyAgICAgICAgIHNldEFkbWluUGhvbmUocGhvbmUpO1xyXG4vLyAgICAgICAgIHNldEFkbWluRW1haWwoZW1haWwpO1xyXG5cclxuLy8gICAgICAgICAvLyBTZXQgZm9ybSB2YWx1ZXNcclxuLy8gICAgICAgICBjcmVhdGVGb3JtLnNldEZpZWxkc1ZhbHVlKHtcclxuLy8gICAgICAgICAgIGFkbWluTmFtZTogbmFtZSxcclxuLy8gICAgICAgICAgIGFkbWluSWQ6IHVzZXJJZCxcclxuLy8gICAgICAgICAgIGFkbWluUGhvbmU6IHBob25lLFxyXG4vLyAgICAgICAgICAgYWRtaW5FbWFpbDogZW1haWwsXHJcbi8vICAgICAgICAgfSk7XHJcbi8vICAgICAgIH0gY2F0Y2ggKGFkbWluRXJyb3IpIHtcclxuLy8gICAgICAgICAvLyBJZiBhZG1pbiBlbmRwb2ludCBmYWlscywgdXNlIGRhdGEgZnJvbSBsb2NhbFN0b3JhZ2VcclxuLy8gICAgICAgICAvLyBjb25zb2xlLmxvZyhcIkFkbWluIGVuZHBvaW50IGZhaWxlZCwgdXNpbmcgbG9jYWxTdG9yYWdlIGRhdGFcIik7XHJcbi8vICAgICAgICAgY29uc3QgbmFtZSA9IHVzZXIuZnVsbF9uYW1lIHx8IHVzZXIubmFtZSB8fCB1c2VyLmFkbWluX25hbWUgfHwgXCJBZG1pblwiO1xyXG4vLyAgICAgICAgIGNvbnN0IHBob25lID0gdXNlci5waG9uZV9udW1iZXIgfHwgdXNlci5tb2JpbGU7XHJcbi8vICAgICAgICAgY29uc3QgZW1haWwgPSB1c2VyLmVtYWlsO1xyXG5cclxuLy8gICAgICAgICBzZXRBZG1pbk5hbWUobmFtZSk7XHJcbi8vICAgICAgICAgc2V0QWRtaW5JZCh1c2VySWQpO1xyXG4vLyAgICAgICAgIHNldEFkbWluUGhvbmUocGhvbmUpO1xyXG4vLyAgICAgICAgIHNldEFkbWluRW1haWwoZW1haWwpO1xyXG5cclxuLy8gICAgICAgICBjcmVhdGVGb3JtLnNldEZpZWxkc1ZhbHVlKHtcclxuLy8gICAgICAgICAgIGFkbWluTmFtZTogbmFtZSxcclxuLy8gICAgICAgICAgIGFkbWluSWQ6IHVzZXJJZCxcclxuLy8gICAgICAgICAgIGFkbWluUGhvbmU6IHBob25lLFxyXG4vLyAgICAgICAgICAgYWRtaW5FbWFpbDogZW1haWwsXHJcbi8vICAgICAgICAgfSk7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggYWRtaW4gcHJvZmlsZTpcIiwgZXJyb3IpO1xyXG4vLyAgICAgICAvLyBTZXQgZGVmYXVsdCB2YWx1ZXMgaWYgZXZlcnl0aGluZyBmYWlsc1xyXG4vLyAgICAgICBzZXRBZG1pbk5hbWUoXCJBZG1pblwiKTtcclxuLy8gICAgICAgY3JlYXRlRm9ybS5zZXRGaWVsZHNWYWx1ZSh7IGFkbWluTmFtZTogXCJBZG1pblwiIH0pO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGZldGNoVXNlcnMgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICB0cnkge1xyXG4vLyAgICAgICBzZXRMb2FkaW5nVXNlcnModHJ1ZSk7XHJcbi8vICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldChcIi91c2VyL2dldC11c2VyXCIpO1xyXG4vLyAgICAgICBzZXRVc2VycyhyZXNwb25zZS5kYXRhIHx8IFtdKTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyczpcIiwgZXJyb3IpO1xyXG4vLyAgICAgICBhcGkuZXJyb3IoeyBtZXNzYWdlOiBcIkVycm9yXCIsIGRlc2NyaXB0aW9uOiBcIkZhaWxlZCB0byBmZXRjaCB1c2Vycy5cIiB9KTtcclxuLy8gICAgIH0gZmluYWxseSB7XHJcbi8vICAgICAgIHNldExvYWRpbmdVc2VycyhmYWxzZSk7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vIGNvbnN0IGZldGNoTmV4dEF1Y3Rpb25EYXRlID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuLy8gICBpZiAoIWdyb3VwSWQpIHJldHVybjtcclxuXHJcbi8vICAgc2V0TG9hZGluZ05leHRBdWN0aW9uKHRydWUpO1xyXG5cclxuLy8gICB0cnkge1xyXG4vLyAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBUEkuZ2V0KGAvYXVjdGlvbi9nZXQtZ3JvdXAtYXVjdGlvbi8ke2dyb3VwSWR9YCk7XHJcbi8vICAgICBjb25zdCBhdWN0aW9ucyA9IHJlc3BvbnNlLmRhdGEgfHwgW107XHJcblxyXG4vLyAgICAgaWYgKGF1Y3Rpb25zLmxlbmd0aCA+IDApIHtcclxuLy8gICAgICAgLy8gU29ydCBieSBjcmVhdGVkQXQgZGVzY2VuZGluZyBhbmQgZ2V0IGZpcnN0IGl0ZW0ncyBuZXh0X2RhdGVcclxuLy8gICAgICAgY29uc3QgbmV4dERhdGUgPSBhdWN0aW9ucy5zb3J0KChhLCBiKSA9PiBcclxuLy8gICAgICAgICBuZXcgRGF0ZShiLmNyZWF0ZWRBdCkgLSBuZXcgRGF0ZShhLmNyZWF0ZWRBdClcclxuLy8gICAgICAgKVswXT8ubmV4dF9kYXRlO1xyXG4gICAgICBcclxuLy8gICAgICAgY29uc3QgdG90YWxBdWN0aW9ucyA9IGF1Y3Rpb25zLmxlbmd0aDtcclxuXHJcbi8vICAgICAgIGlmIChuZXh0RGF0ZSkge1xyXG4vLyAgICAgICAgIGNvbnN0IGZvcm1hdHRlZE5leHREYXRlID0gZGF5anMobmV4dERhdGUpO1xyXG4gICAgICAgIFxyXG4vLyAgICAgICAgIHNldEF1Y3Rpb25JbmZvKHtcclxuLy8gICAgICAgICAgIG5leHREYXRlOiBmb3JtYXR0ZWROZXh0RGF0ZSxcclxuLy8gICAgICAgICAgIGxhc3REYXRlOiBudWxsLFxyXG4vLyAgICAgICAgICAgdG90YWxBdWN0aW9uczogdG90YWxBdWN0aW9ucyxcclxuLy8gICAgICAgICB9KTtcclxuXHJcbi8vICAgICAgICAgc2V0TmV4dEF1Y3Rpb25EYXRlKGZvcm1hdHRlZE5leHREYXRlKTtcclxuXHJcbi8vICAgICAgICAgY3JlYXRlRm9ybS5zZXRGaWVsZHNWYWx1ZSh7XHJcbi8vICAgICAgICAgICBhdWN0aW9uRGF0ZTogZm9ybWF0dGVkTmV4dERhdGUsXHJcbi8vICAgICAgICAgfSk7XHJcblxyXG4vLyAgICAgICAgIGFwaS5zdWNjZXNzKHtcclxuLy8gICAgICAgICAgIG1lc3NhZ2U6IFwiQXVjdGlvbiBEYXRlIExvYWRlZFwiLFxyXG4vLyAgICAgICAgICAgZGVzY3JpcHRpb246IGBOZXh0IGF1Y3Rpb24gZGF0ZTogJHtmb3JtYXR0ZWROZXh0RGF0ZS5mb3JtYXQoXCJERC1NTS1ZWVlZXCIpfWAsXHJcbi8vICAgICAgICAgICBkdXJhdGlvbjogMyxcclxuLy8gICAgICAgICB9KTtcclxuLy8gICAgICAgfSBlbHNlIHtcclxuLy8gICAgICAgICBzZXRBdWN0aW9uSW5mbyh7XHJcbi8vICAgICAgICAgICBuZXh0RGF0ZTogbnVsbCxcclxuLy8gICAgICAgICAgIGxhc3REYXRlOiBudWxsLFxyXG4vLyAgICAgICAgICAgdG90YWxBdWN0aW9uczogdG90YWxBdWN0aW9ucyxcclxuLy8gICAgICAgICB9KTtcclxuLy8gICAgICAgICBzZXROZXh0QXVjdGlvbkRhdGUobnVsbCk7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH1cclxuLy8gICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgY29uc29sZS5lcnJvcihcIkVycm9yOlwiLCBlcnJvcik7XHJcbi8vICAgfSBmaW5hbGx5IHtcclxuLy8gICAgIHNldExvYWRpbmdOZXh0QXVjdGlvbihmYWxzZSk7XHJcbi8vICAgfVxyXG4vLyB9O1xyXG5cclxuLy8gLy8ge2NvbnNvbGUubG9nKFxyXG4vLyAvLyAgIFwiQ3VycmVudCBBdWN0aW9uIERhdGU6XCIsXHJcbi8vIC8vICAgY3JlYXRlRm9ybS5nZXRGaWVsZFZhbHVlKFwiYXVjdGlvbkRhdGVcIik/LmZvcm1hdChcIkRELU1NLVlZWVlcIilcclxuLy8gLy8gKX1cclxuXHJcblxyXG4vLyAgIGNvbnN0IGZldGNoQXVjdGlvbkluZm8gPSBhc3luYyAoZ3JvdXBJZCwgdXNlcklkLCB0aWNrZXROdW1iZXIpID0+IHtcclxuLy8gICAgIGlmICghZ3JvdXBJZCkgcmV0dXJuIHsgY291bnQ6IDAsIGlzUHJpemVkOiBmYWxzZSB9O1xyXG5cclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldChcclxuLy8gICAgICAgICBgL2JpZC1yZXF1ZXN0L2dldC1ncm91cC1hdWN0aW9uLXN0YXRzLyR7Z3JvdXBJZH1gLFxyXG4vLyAgICAgICApO1xyXG4vLyAgICAgICBjb25zdCBkYXRhID0gcmVzcG9uc2UuZGF0YTtcclxuXHJcbi8vICAgICAgIGlmICghZGF0YSB8fCAhZGF0YS5zdWNjZXNzKSB7XHJcbi8vICAgICAgICAgcmV0dXJuIHsgY291bnQ6IDAsIGlzUHJpemVkOiBmYWxzZSB9O1xyXG4vLyAgICAgICB9XHJcblxyXG4vLyAgICAgICBjb25zdCBjb3VudCA9IGRhdGEuY291bnQgfHwgMDtcclxuLy8gICAgICAgY29uc3QgcHJpemVkTGlzdCA9IGRhdGEucHJpemVkVGlja2V0cyB8fCBbXTtcclxuLy8gICAgICAgY29uc3QgaXNQcml6ZWQgPSBwcml6ZWRMaXN0LnNvbWUoXHJcbi8vICAgICAgICAgKGl0ZW0pID0+XHJcbi8vICAgICAgICAgICBTdHJpbmcoaXRlbS51c2VyX2lkKSA9PT0gU3RyaW5nKHVzZXJJZCkgJiZcclxuLy8gICAgICAgICAgIFN0cmluZyhpdGVtLnRpY2tldCkgPT09IFN0cmluZyh0aWNrZXROdW1iZXIpLFxyXG4vLyAgICAgICApO1xyXG5cclxuLy8gICAgICAgcmV0dXJuIHsgY291bnQsIGlzUHJpemVkIH07XHJcbi8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYXVjdGlvbiBzdGF0czpcIiwgZXJyb3IpO1xyXG4vLyAgICAgICByZXR1cm4geyBjb3VudDogMCwgaXNQcml6ZWQ6IGZhbHNlIH07XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlR3JvdXBDaGFuZ2UgPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4vLyAgIHNldFNlbGVjdGVkR3JvdXBJZChncm91cElkKTtcclxuXHJcbi8vICAgY29uc3Qgc2VsZWN0ZWRHcm91cCA9IGNyZWF0ZUdyb3Vwcy5maW5kKFxyXG4vLyAgICAgKGcpID0+IGcuaWQgPT09IGdyb3VwSWRcclxuLy8gICApO1xyXG5cclxuLy8gICBpZiAoIXNlbGVjdGVkR3JvdXApIHJldHVybjtcclxuXHJcbi8vICAgc2V0R3JvdXBUaWNrZXRzKHNlbGVjdGVkR3JvdXAudGlja2V0cyk7XHJcblxyXG4vLyAgIGNyZWF0ZUZvcm0uc2V0RmllbGRzVmFsdWUoe1xyXG4vLyAgICAgdGlja2V0SW5kZXg6IHVuZGVmaW5lZCxcclxuLy8gICAgIGdyb3VwTmFtZTogc2VsZWN0ZWRHcm91cC5ncm91cE5hbWUsXHJcbi8vICAgICBzdGFydERhdGU6IHNlbGVjdGVkR3JvdXAuc3RhcnREYXRlLFxyXG4vLyAgICAgZW5kRGF0ZTogc2VsZWN0ZWRHcm91cC5lbmREYXRlLFxyXG4vLyAgICAgYXVjdGlvbnNEb25lOiBzZWxlY3RlZEdyb3VwLmF1Y3Rpb25zRG9uZSxcclxuLy8gICAgIGFnZW50TmFtZTogc2VsZWN0ZWRHcm91cC5hZ2VudE5hbWUsXHJcbi8vICAgICByZWZlcnJlZFR5cGU6IHNlbGVjdGVkR3JvdXAucmVmZXJyZWRUeXBlLFxyXG4vLyAgICAgcmVmZXJyZWRCeTogc2VsZWN0ZWRHcm91cC5yZWZlcnJlZEJ5LFxyXG4vLyAgIH0pO1xyXG5cclxuLy8gICBhd2FpdCBmZXRjaE5leHRBdWN0aW9uRGF0ZShncm91cElkKTtcclxuLy8gfTtcclxuXHJcbi8vIGNvbnN0IGhhbmRsZVRpY2tldENoYW5nZSA9IChpbmRleCkgPT4ge1xyXG4vLyAgIHNldFNlbGVjdGVkVGlja2V0SW5kZXgoaW5kZXgpO1xyXG5cclxuLy8gICBjb25zdCB0aWNrZXQgPSBncm91cFRpY2tldHNbaW5kZXhdO1xyXG5cclxuLy8gICBpZiAoIXRpY2tldCkgcmV0dXJuO1xyXG5cclxuLy8gICBzZXRTZWxlY3RlZEVucm9sbG1lbnRJZCh0aWNrZXQuZW5yb2xsbWVudElkKTtcclxuXHJcbi8vICAgY3JlYXRlRm9ybS5zZXRGaWVsZHNWYWx1ZSh7XHJcbi8vICAgICB0aWNrZXROdW1iZXI6IHRpY2tldC50aWNrZXROdW1iZXIsXHJcbi8vICAgfSk7XHJcblxyXG4vLyAgIGlmICh0aWNrZXQuaXNQcml6ZWQpIHtcclxuLy8gICAgIGFwaS5lcnJvcih7XHJcbi8vICAgICAgIG1lc3NhZ2U6IFwiVGlja2V0IEFscmVhZHkgUHJpemVkXCIsXHJcbi8vICAgICAgIGRlc2NyaXB0aW9uOiBcIlRoaXMgdGlja2V0IGlzIGFscmVhZHkgcHJpemVkLlwiLFxyXG4vLyAgICAgfSk7XHJcbi8vICAgfVxyXG4vLyB9O1xyXG5cclxuXHJcbi8vICAgY29uc3QgZmV0Y2hDcmVhdGVDdXN0b21lckRldGFpbHMgPSBhc3luYyAodXNlcklkKSA9PiB7XHJcbi8vICAgICB0cnkge1xyXG4vLyAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEFQSS5wb3N0KFxyXG4vLyAgICAgICAgIGAvZW5yb2xsL2dldC11c2VyLXRpY2tldHMtcmVwb3J0LyR7dXNlcklkfWAsXHJcbi8vICAgICAgICk7XHJcbi8vICAgICAgIGNvbnN0IGRhdGFMaXN0ID0gcmVzcG9uc2UuZGF0YSB8fCByZXNwb25zZS5kYXRhPy5kYXRhIHx8IFtdO1xyXG5cclxuLy8gICAgICAgaWYgKGRhdGFMaXN0ICYmIGRhdGFMaXN0Lmxlbmd0aCA+IDApIHtcclxuLy8gICAgICAgICBjb25zdCBncm91cGVkRGF0YSA9IHt9O1xyXG5cclxuLy8gICAgICAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgZGF0YUxpc3QpIHtcclxuLy8gICAgICAgICAgIGNvbnN0IGVucm9sbG1lbnQgPSBpdGVtPy5lbnJvbGxtZW50O1xyXG4vLyAgICAgICAgICAgY29uc3QgZ3JvdXBEYXRhID0gZW5yb2xsbWVudD8uZ3JvdXA7XHJcblxyXG4vLyAgICAgICAgICAgaWYgKCFncm91cERhdGE/Ll9pZCkgY29udGludWU7XHJcblxyXG4vLyAgICAgICAgICAgY29uc3QgdGlja2V0TnVtYmVyID1cclxuLy8gICAgICAgICAgICAgZW5yb2xsbWVudD8udGlja2V0cyB8fCBlbnJvbGxtZW50Py50aWNrZXRfbnVtYmVyIHx8IFwiTi9BXCI7XHJcblxyXG4vLyAgICAgICAgICAgY29uc3QgYXVjdGlvbkluZm8gPSBhd2FpdCBmZXRjaEF1Y3Rpb25JbmZvKFxyXG4vLyAgICAgICAgICAgICBncm91cERhdGE/Ll9pZCxcclxuLy8gICAgICAgICAgICAgdXNlcklkLFxyXG4vLyAgICAgICAgICAgICB0aWNrZXROdW1iZXIsXHJcbi8vICAgICAgICAgICApO1xyXG5cclxuLy8gICAgICAgICAgIGxldCByZWZlcnJlZFR5cGUgPSBcIk4vQVwiO1xyXG4vLyAgICAgICAgICAgbGV0IHJlZmVycmVkQnkgPSBcIk4vQVwiO1xyXG4vLyAgICAgICAgICAgbGV0IGFnZW50TmFtZSA9IFwiTi9BXCI7XHJcblxyXG4vLyAgICAgICAgICAgaWYgKGVucm9sbG1lbnQ/LmFnZW50Py5uYW1lKSB7XHJcbi8vICAgICAgICAgICAgIHJlZmVycmVkVHlwZSA9IFwiQWdlbnRcIjtcclxuLy8gICAgICAgICAgICAgYWdlbnROYW1lID0gZW5yb2xsbWVudC5hZ2VudC5uYW1lO1xyXG4vLyAgICAgICAgICAgICByZWZlcnJlZEJ5ID0gYCR7ZW5yb2xsbWVudC5hZ2VudC5uYW1lfSB8ICR7ZW5yb2xsbWVudC5hZ2VudC5waG9uZV9udW1iZXJ9YDtcclxuLy8gICAgICAgICAgIH0gZWxzZSBpZiAoZ3JvdXBEYXRhPy5hZ2VudD8ubmFtZSkge1xyXG4vLyAgICAgICAgICAgICByZWZlcnJlZFR5cGUgPSBcIkFnZW50XCI7XHJcbi8vICAgICAgICAgICAgIGFnZW50TmFtZSA9IGdyb3VwRGF0YS5hZ2VudC5uYW1lO1xyXG4vLyAgICAgICAgICAgICByZWZlcnJlZEJ5ID0gYCR7Z3JvdXBEYXRhLmFnZW50Lm5hbWV9IHwgJHtncm91cERhdGEuYWdlbnQucGhvbmVfbnVtYmVyfWA7XHJcbi8vICAgICAgICAgICB9XHJcblxyXG4vLyAgICAgICAgICAgaWYgKCFncm91cGVkRGF0YVtncm91cERhdGEuX2lkXSkge1xyXG4vLyAgICAgICAgICAgICBncm91cGVkRGF0YVtncm91cERhdGEuX2lkXSA9IHtcclxuLy8gICAgICAgICAgICAgICBpZDogZ3JvdXBEYXRhLl9pZCxcclxuLy8gICAgICAgICAgICAgICBncm91cE5hbWU6IGdyb3VwRGF0YS5ncm91cF9uYW1lLFxyXG4vLyAgICAgICAgICAgICAgIHN0YXJ0RGF0ZTogZ3JvdXBEYXRhPy5zdGFydF9kYXRlXHJcbi8vICAgICAgICAgICAgICAgICA/IGdyb3VwRGF0YS5zdGFydF9kYXRlLnNwbGl0KFwiVFwiKVswXVxyXG4vLyAgICAgICAgICAgICAgICAgOiBcIk4vQVwiLFxyXG4vLyAgICAgICAgICAgICAgIGVuZERhdGU6IGdyb3VwRGF0YT8uZW5kX2RhdGVcclxuLy8gICAgICAgICAgICAgICAgID8gZ3JvdXBEYXRhLmVuZF9kYXRlLnNwbGl0KFwiVFwiKVswXVxyXG4vLyAgICAgICAgICAgICAgICAgOiBcIk4vQVwiLFxyXG4vLyAgICAgICAgICAgICAgIGF1Y3Rpb25zRG9uZTogYXVjdGlvbkluZm8uY291bnQsXHJcbi8vICAgICAgICAgICAgICAgYWdlbnROYW1lLFxyXG4vLyAgICAgICAgICAgICAgIHJlZmVycmVkVHlwZSxcclxuLy8gICAgICAgICAgICAgICByZWZlcnJlZEJ5LFxyXG4vLyAgICAgICAgICAgICAgIHRpY2tldHM6IFtdLFxyXG4vLyAgICAgICAgICAgICB9O1xyXG4vLyAgICAgICAgICAgfVxyXG5cclxuLy8gICAgICAgICAgIGdyb3VwZWREYXRhW2dyb3VwRGF0YS5faWRdLnRpY2tldHMucHVzaCh7XHJcbi8vICAgICAgICAgICAgIHRpY2tldE51bWJlcixcclxuLy8gICAgICAgICAgICAgZW5yb2xsbWVudElkOiBlbnJvbGxtZW50Py5faWQsXHJcbi8vICAgICAgICAgICAgIGlzUHJpemVkOiBhdWN0aW9uSW5mby5pc1ByaXplZCxcclxuLy8gICAgICAgICAgIH0pO1xyXG4vLyAgICAgICAgIH1cclxuXHJcbi8vICAgICAgICAgY29uc3QgZmluYWxHcm91cHMgPSBPYmplY3QudmFsdWVzKGdyb3VwZWREYXRhKTtcclxuXHJcbi8vICAgICAgICAgc2V0Q3JlYXRlR3JvdXBzKGZpbmFsR3JvdXBzKTtcclxuXHJcbi8vICAgICAgICBpZiAoZmluYWxHcm91cHMubGVuZ3RoID4gMCkge1xyXG4vLyAgIGNvbnN0IGZpcnN0R3JvdXAgPSBmaW5hbEdyb3Vwc1swXTtcclxuXHJcbi8vICAgc2V0U2VsZWN0ZWRHcm91cElkKGZpcnN0R3JvdXAuaWQpO1xyXG4vLyAgIHNldEdyb3VwVGlja2V0cyhmaXJzdEdyb3VwLnRpY2tldHMpO1xyXG5cclxuLy8gICBjcmVhdGVGb3JtLnNldEZpZWxkc1ZhbHVlKHtcclxuLy8gICAgIHNlbGVjdGVkR3JvdXBJZDogZmlyc3RHcm91cC5pZCxcclxuLy8gICAgIGdyb3VwTmFtZTogZmlyc3RHcm91cC5ncm91cE5hbWUsXHJcbi8vICAgICBzdGFydERhdGU6IGZpcnN0R3JvdXAuc3RhcnREYXRlLFxyXG4vLyAgICAgZW5kRGF0ZTogZmlyc3RHcm91cC5lbmREYXRlLFxyXG4vLyAgICAgYXVjdGlvbnNEb25lOiBmaXJzdEdyb3VwLmF1Y3Rpb25zRG9uZSxcclxuLy8gICAgIGFnZW50TmFtZTogZmlyc3RHcm91cC5hZ2VudE5hbWUsXHJcbi8vICAgICByZWZlcnJlZFR5cGU6IGZpcnN0R3JvdXAucmVmZXJyZWRUeXBlLFxyXG4vLyAgICAgcmVmZXJyZWRCeTogZmlyc3RHcm91cC5yZWZlcnJlZEJ5LFxyXG4vLyAgIH0pO1xyXG5cclxuLy8gICBhd2FpdCBmZXRjaE5leHRBdWN0aW9uRGF0ZShmaXJzdEdyb3VwLmlkKTtcclxuLy8gfVxyXG5cclxuLy8gICAgICAgICAvLyBjb25zdCBmaXJzdEF2YWlsYWJsZUluZGV4ID0gZ3JvdXBzRGF0YS5maW5kSW5kZXgoKGcpID0+ICFnLmlzUHJpemVkKTtcclxuLy8gICAgICAgICAvLyBjb25zdCBpbml0aWFsSW5kZXggPVxyXG4vLyAgICAgICAgIC8vICAgZmlyc3RBdmFpbGFibGVJbmRleCAhPT0gLTEgPyBmaXJzdEF2YWlsYWJsZUluZGV4IDogMDtcclxuXHJcbi8vICAgICAgICAgLy8gaWYgKGdyb3Vwc0RhdGEubGVuZ3RoID4gMCkge1xyXG4vLyAgICAgICAgIC8vICAgc2V0U2VsZWN0ZWRDcmVhdGVHcm91cEluZGV4KGluaXRpYWxJbmRleCk7XHJcbi8vICAgICAgICAgLy8gICBjb25zdCBncm91cCA9IGdyb3Vwc0RhdGFbaW5pdGlhbEluZGV4XTtcclxuLy8gICAgICAgICAvLyAgIHNldFNlbGVjdGVkRW5yb2xsbWVudElkKGdyb3VwLmVucm9sbG1lbnRJZCk7XHJcblxyXG4vLyAgICAgICAgIC8vICAgY3JlYXRlRm9ybS5zZXRGaWVsZHNWYWx1ZSh7XHJcbi8vICAgICAgICAgLy8gICAgIGdyb3VwTmFtZTogZ3JvdXAuZ3JvdXBOYW1lLFxyXG4vLyAgICAgICAgIC8vICAgICB0aWNrZXROdW1iZXI6IGdyb3VwLnRpY2tldE51bWJlcixcclxuLy8gICAgICAgICAvLyAgICAgc2VsZWN0ZWRHcm91cEluZGV4OiBpbml0aWFsSW5kZXgsXHJcbi8vICAgICAgICAgLy8gICAgIHN0YXJ0RGF0ZTogZ3JvdXAuc3RhcnREYXRlLFxyXG4vLyAgICAgICAgIC8vICAgICBlbmREYXRlOiBncm91cC5lbmREYXRlLFxyXG4vLyAgICAgICAgIC8vICAgICBhdWN0aW9uc0RvbmU6IGdyb3VwLmF1Y3Rpb25zRG9uZSxcclxuLy8gICAgICAgICAvLyAgICAgYWdlbnROYW1lOiBncm91cC5hZ2VudE5hbWUsXHJcbi8vICAgICAgICAgLy8gICAgIHJlZmVycmVkVHlwZTogZ3JvdXAucmVmZXJyZWRUeXBlLFxyXG4vLyAgICAgICAgIC8vICAgICByZWZlcnJlZEJ5OiBncm91cC5yZWZlcnJlZEJ5LFxyXG4vLyAgICAgICAgIC8vICAgfSk7XHJcblxyXG4vLyAgICAgICAgIC8vICAgLy8g4pyFIEZldGNoIG5leHQgYXVjdGlvbiBkYXRlIGZvciB0aGlzIGdyb3VwXHJcbi8vICAgICAgICAgLy8gICBhd2FpdCBmZXRjaE5leHRBdWN0aW9uRGF0ZShncm91cC5pZCk7XHJcblxyXG4vLyAgICAgICAgIGlmIChmaW5hbEdyb3Vwcy5sZW5ndGggPiAwKSB7XHJcbi8vICAgY29uc3QgZmlyc3RHcm91cCA9IGZpbmFsR3JvdXBzWzBdO1xyXG5cclxuLy8gICBzZXRTZWxlY3RlZEdyb3VwSWQoZmlyc3RHcm91cC5pZCk7XHJcbi8vICAgc2V0R3JvdXBUaWNrZXRzKGZpcnN0R3JvdXAudGlja2V0cyk7XHJcblxyXG4vLyAgIGNyZWF0ZUZvcm0uc2V0RmllbGRzVmFsdWUoe1xyXG4vLyAgICAgc2VsZWN0ZWRHcm91cElkOiBmaXJzdEdyb3VwLmlkLFxyXG4vLyAgICAgZ3JvdXBOYW1lOiBmaXJzdEdyb3VwLmdyb3VwTmFtZSxcclxuLy8gICAgIHN0YXJ0RGF0ZTogZmlyc3RHcm91cC5zdGFydERhdGUsXHJcbi8vICAgICBlbmREYXRlOiBmaXJzdEdyb3VwLmVuZERhdGUsXHJcbi8vICAgICBhdWN0aW9uc0RvbmU6IGZpcnN0R3JvdXAuYXVjdGlvbnNEb25lLFxyXG4vLyAgICAgYWdlbnROYW1lOiBmaXJzdEdyb3VwLmFnZW50TmFtZSxcclxuLy8gICAgIHJlZmVycmVkVHlwZTogZmlyc3RHcm91cC5yZWZlcnJlZFR5cGUsXHJcbi8vICAgICByZWZlcnJlZEJ5OiBmaXJzdEdyb3VwLnJlZmVycmVkQnksXHJcbi8vICAgfSk7XHJcblxyXG4vLyAgIGF3YWl0IGZldGNoTmV4dEF1Y3Rpb25EYXRlKGZpcnN0R3JvdXAuaWQpO1xyXG5cclxuXHJcbi8vICAgICAgICAgLy8gICBpZiAoZ3JvdXAuaXNQcml6ZWQpIHtcclxuLy8gICAgICAgICAvLyAgICAgYXBpLndhcm5pbmcoe1xyXG4vLyAgICAgICAgIC8vICAgICAgIG1lc3NhZ2U6IFwiVGlja2V0IEFscmVhZHkgUHJpemVkXCIsXHJcbi8vICAgICAgICAgLy8gICAgICAgZGVzY3JpcHRpb246XHJcbi8vICAgICAgICAgLy8gICAgICAgICBcIlRoaXMgY3VzdG9tZXIgaGFzIHByaXplZCB0aWNrZXRzLiBQbGVhc2Ugc2VsZWN0IGFuIGF2YWlsYWJsZSB0aWNrZXQuXCIsXHJcbi8vICAgICAgICAgLy8gICAgIH0pO1xyXG4vLyAgICAgICAgIC8vICAgfVxyXG4vLyAgICAgICAgIH1cclxuLy8gICAgICAgfSBlbHNlIHtcclxuLy8gICAgICAgICBhcGkud2FybmluZyh7XHJcbi8vICAgICAgICAgICBtZXNzYWdlOiBcIk5vIFRpY2tldHMgRm91bmRcIixcclxuLy8gICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlRoaXMgY3VzdG9tZXIgaXMgbm90IGVucm9sbGVkIGluIGFueSBhY3RpdmUgZ3JvdXBzLlwiLFxyXG4vLyAgICAgICAgIH0pO1xyXG4vLyAgICAgICAgIHNldENyZWF0ZUdyb3VwcyhbXSk7XHJcbi8vICAgICAgICAgc2V0U2VsZWN0ZWRFbnJvbGxtZW50SWQobnVsbCk7XHJcbi8vICAgICAgICAgY3JlYXRlRm9ybS5zZXRGaWVsZHNWYWx1ZSh7XHJcbi8vICAgICAgICAgICBhZ2VudE5hbWU6IFwiTi9BXCIsXHJcbi8vICAgICAgICAgICByZWZlcnJlZFR5cGU6IFwiTi9BXCIsXHJcbi8vICAgICAgICAgICByZWZlcnJlZEJ5OiBcIk4vQVwiLFxyXG4vLyAgICAgICAgIH0pO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgY3VzdG9tZXIgZGV0YWlsczpcIiwgZXJyb3IpO1xyXG4vLyAgICAgICBhcGkuZXJyb3Ioe1xyXG4vLyAgICAgICAgIG1lc3NhZ2U6IFwiRXJyb3IgRmV0Y2hpbmcgRGV0YWlsc1wiLFxyXG4vLyAgICAgICAgIGRlc2NyaXB0aW9uOiBcIkNvdWxkIG5vdCBsb2FkIGN1c3RvbWVyIHRpY2tldHMuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXHJcbi8vICAgICAgIH0pO1xyXG4vLyAgICAgICBzZXRDcmVhdGVHcm91cHMoW10pO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZEVucm9sbG1lbnRJZChudWxsKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuXHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZUNyZWF0ZUN1c3RvbWVyU2VsZWN0ID0gKHVzZXJJZCkgPT4ge1xyXG4vLyAgICAgY29uc3Qgc2VsZWN0ZWRVc2VyID0gdXNlcnMuZmluZCgodSkgPT4gdS5faWQgPT09IHVzZXJJZCk7XHJcbi8vICAgICBpZiAoc2VsZWN0ZWRVc2VyKSB7XHJcbi8vICAgICAgIGNvbnN0IGNOYW1lID0gc2VsZWN0ZWRVc2VyLmZ1bGxfbmFtZSB8fCBzZWxlY3RlZFVzZXIubmFtZTtcclxuLy8gICAgICAgY29uc3QgY1Bob25lID0gc2VsZWN0ZWRVc2VyLnBob25lX251bWJlciB8fCBzZWxlY3RlZFVzZXIubW9iaWxlO1xyXG4vLyAgICAgICBjcmVhdGVGb3JtLnNldEZpZWxkc1ZhbHVlKHtcclxuLy8gICAgICAgICBzdWJzY3JpYmVyTmFtZTogY05hbWUsXHJcbi8vICAgICAgICAgbW9iaWxlTnVtYmVyOiBjUGhvbmUsXHJcbi8vICAgICAgICAgc3Vic2NyaWJlcklkOiB1c2VySWQsXHJcbi8vICAgICAgICAgZ3JvdXBOYW1lOiBcIkxvYWRpbmcuLi5cIixcclxuLy8gICAgICAgICB0aWNrZXROdW1iZXI6IFwiTG9hZGluZy4uLlwiLFxyXG4vLyAgICAgICAgIGFnZW50TmFtZTogXCJMb2FkaW5nLi4uXCIsXHJcbi8vICAgICAgICAgcmVmZXJyZWRUeXBlOiBcIkxvYWRpbmcuLi5cIixcclxuLy8gICAgICAgICByZWZlcnJlZEJ5OiBcIkxvYWRpbmcuLi5cIixcclxuLy8gICAgICAgfSk7XHJcbi8vICAgICAgIHNldENyZWF0ZUdyb3VwcyhbXSk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkQ3JlYXRlR3JvdXBJbmRleCgwKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWRFbnJvbGxtZW50SWQobnVsbCk7XHJcbi8vICAgICAgIC8vIFJlc2V0IGF1Y3Rpb24gaW5mb1xyXG4vLyAgICAgICBzZXRBdWN0aW9uSW5mbyh7IG5leHREYXRlOiBudWxsLCBsYXN0RGF0ZTogbnVsbCwgdG90YWxBdWN0aW9uczogMCB9KTtcclxuLy8gICAgICAgc2V0TmV4dEF1Y3Rpb25EYXRlKG51bGwpO1xyXG4vLyAgICAgICBmZXRjaENyZWF0ZUN1c3RvbWVyRGV0YWlscyh1c2VySWQpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZUNyZWF0ZUdyb3VwU2VsZWN0ID0gYXN5bmMgKGluZGV4KSA9PiB7XHJcbi8vICAgICBzZXRTZWxlY3RlZENyZWF0ZUdyb3VwSW5kZXgoaW5kZXgpO1xyXG4vLyAgICAgY29uc3Qgc2VsZWN0ZWRHcm91cCA9IGNyZWF0ZUdyb3Vwc1tpbmRleF07XHJcbi8vICAgICBpZiAoc2VsZWN0ZWRHcm91cCkge1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZEVucm9sbG1lbnRJZChzZWxlY3RlZEdyb3VwLmVucm9sbG1lbnRJZCk7XHJcbi8vICAgICAgIGNyZWF0ZUZvcm0uc2V0RmllbGRzVmFsdWUoe1xyXG4vLyAgICAgICAgIGdyb3VwTmFtZTogc2VsZWN0ZWRHcm91cC5ncm91cE5hbWUsXHJcbi8vICAgICAgICAgdGlja2V0TnVtYmVyOiBzZWxlY3RlZFRpY2tldC50aWNrZXROdW1iZXIsXHJcbi8vICAgICAgICAgc2VsZWN0ZWRHcm91cEluZGV4OiBpbmRleCxcclxuLy8gICAgICAgICBzdGFydERhdGU6IHNlbGVjdGVkR3JvdXAuc3RhcnREYXRlLFxyXG4vLyAgICAgICAgIGVuZERhdGU6IHNlbGVjdGVkR3JvdXAuZW5kRGF0ZSxcclxuLy8gICAgICAgICBhdWN0aW9uc0RvbmU6IHNlbGVjdGVkR3JvdXAuYXVjdGlvbnNEb25lLFxyXG4vLyAgICAgICAgIGFnZW50TmFtZTogc2VsZWN0ZWRHcm91cC5hZ2VudE5hbWUsXHJcbi8vICAgICAgICAgcmVmZXJyZWRUeXBlOiBzZWxlY3RlZEdyb3VwLnJlZmVycmVkVHlwZSxcclxuLy8gICAgICAgICByZWZlcnJlZEJ5OiBzZWxlY3RlZEdyb3VwLnJlZmVycmVkQnksXHJcbi8vICAgICAgIH0pO1xyXG5cclxuLy8gICAgICAgLy8g4pyFIEZldGNoIG5leHQgYXVjdGlvbiBkYXRlIGZvciB0aGUgc2VsZWN0ZWQgZ3JvdXBcclxuLy8gICAgICAgYXdhaXQgZmV0Y2hOZXh0QXVjdGlvbkRhdGUoc2VsZWN0ZWRHcm91cC5pZCk7XHJcblxyXG4vLyAgICAgICBpZiAoc2VsZWN0ZWRHcm91cC5pc1ByaXplZCkge1xyXG4vLyAgICAgICAgIGFwaS5lcnJvcih7XHJcbi8vICAgICAgICAgICBtZXNzYWdlOiBcIlRpY2tldCBOb3QgQXZhaWxhYmxlXCIsXHJcbi8vICAgICAgICAgICBkZXNjcmlwdGlvbjpcclxuLy8gICAgICAgICAgICAgXCJUaGlzIHRpY2tldCBpcyBhbHJlYWR5IHByaXplZC4gWW91IGNhbm5vdCByYWlzZSBhIHJlcXVlc3QgZm9yIGl0LlwiLFxyXG4vLyAgICAgICAgIH0pO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgLy8gSW4gQ3JlYXRlQmlkUmVxdWVzdCBjb21wb25lbnQsIHVwZGF0ZSB0aGUgaGFuZGxlQ3JlYXRlRmluaXNoIGZ1bmN0aW9uOlxyXG5cclxuLy8gY29uc3QgaGFuZGxlQ3JlYXRlRmluaXNoID0gYXN5bmMgKHZhbHVlcykgPT4ge1xyXG4vLyAgIHRyeSB7XHJcbi8vICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgXHJcbi8vICAgICBjb25zdCBzZWxlY3RlZEdyb3VwID0gY3JlYXRlR3JvdXBzLmZpbmQoXHJcbi8vICAgICAgIChnKSA9PiBnLmlkID09PSB2YWx1ZXMuc2VsZWN0ZWRHcm91cElkXHJcbi8vICAgICApO1xyXG5cclxuLy8gICAgIGNvbnN0IHNlbGVjdGVkVGlja2V0ID0gZ3JvdXBUaWNrZXRzW3ZhbHVlcy50aWNrZXRJbmRleF07XHJcblxyXG4vLyAgICAgaWYgKCFzZWxlY3RlZEdyb3VwKSB7XHJcbi8vICAgICAgIGFwaS5lcnJvcih7XHJcbi8vICAgICAgICAgbWVzc2FnZTogXCJFcnJvclwiLFxyXG4vLyAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlBsZWFzZSBzZWxlY3QgYSBncm91cCBmaXJzdC5cIixcclxuLy8gICAgICAgfSk7XHJcbi8vICAgICAgIHJldHVybjtcclxuLy8gICAgIH1cclxuXHJcbi8vICAgICBpZiAoc2VsZWN0ZWRUaWNrZXQ/LmlzUHJpemVkKSB7XHJcbi8vICAgICAgIGFwaS5lcnJvcih7XHJcbi8vICAgICAgICAgbWVzc2FnZTogXCJSZXF1ZXN0IERlbmllZFwiLFxyXG4vLyAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlRoaXMgdGlja2V0IGlzIGFscmVhZHkgcHJpemVkLiBCaWQgcmVxdWVzdCBjYW5ub3QgYmUgcmFpc2VkLlwiLFxyXG4vLyAgICAgICB9KTtcclxuLy8gICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbi8vICAgICAgIHJldHVybjtcclxuLy8gICAgIH1cclxuXHJcbi8vICAgICBjb25zdCBmb3JtYXR0ZWRUaW1lID0gdmFsdWVzLmF1Y3Rpb25UaW1lXHJcbi8vICAgICAgID8gdmFsdWVzLmF1Y3Rpb25UaW1lLmZvcm1hdChcIkhIOm1tXCIpXHJcbi8vICAgICAgIDogbnVsbDtcclxuXHJcblxyXG4vLyAgICAgY29uc3QgYXVjdGlvbkRhdGVUb1NlbmQgPSB2YWx1ZXMuYXVjdGlvbkRhdGUgXHJcbi8vICAgICAgID8gdmFsdWVzLmF1Y3Rpb25EYXRlLmZvcm1hdChcIllZWVktTU0tRERcIilcclxuLy8gICAgICAgOiAobmV4dEF1Y3Rpb25EYXRlID8gbmV4dEF1Y3Rpb25EYXRlLmZvcm1hdChcIllZWVktTU0tRERcIikgOiBudWxsKTtcclxuXHJcbi8vICAgICBjb25zb2xlLmxvZyhcIlNlbmRpbmcgYXVjdGlvbiBkYXRlOlwiLCBhdWN0aW9uRGF0ZVRvU2VuZCk7IFxyXG5cclxuLy8gICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbi8vICAgICAgIGRhdGU6IHZhbHVlcy5kYXRlXHJcbi8vICAgICAgICAgPyB2YWx1ZXMuZGF0ZS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpXHJcbi8vICAgICAgICAgOiBkYXlqcygpLmZvcm1hdChcIllZWVktTU0tRERcIiksXHJcbi8vICAgICAgIHN1YnNjcmliZXJJZDogdmFsdWVzLnN1YnNjcmliZXJJZCxcclxuLy8gICAgICAgc3Vic2NyaWJlck5hbWU6IHZhbHVlcy5zdWJzY3JpYmVyTmFtZSxcclxuLy8gICAgICAgbW9iaWxlTnVtYmVyOiB2YWx1ZXMubW9iaWxlTnVtYmVyLFxyXG4vLyAgICAgICBncm91cE5hbWU6IHNlbGVjdGVkR3JvdXAuZ3JvdXBOYW1lLFxyXG4vLyAgICAgICB0aWNrZXROdW1iZXI6IHNlbGVjdGVkVGlja2V0LnRpY2tldE51bWJlcixcclxuLy8gICAgICAgYXVjdGlvbkRhdGU6IGF1Y3Rpb25EYXRlVG9TZW5kLCBcclxuLy8gICAgICAgYXVjdGlvbl90aW1lOiBmb3JtYXR0ZWRUaW1lLFxyXG4vLyAgICAgICBhZ2VudE5hbWU6IHNlbGVjdGVkR3JvdXAuYWdlbnROYW1lLFxyXG4vLyAgICAgICByZWZlcnJlZFR5cGU6IHNlbGVjdGVkR3JvdXAucmVmZXJyZWRUeXBlLFxyXG4vLyAgICAgICByZWZlcnJlZEJ5OiBzZWxlY3RlZEdyb3VwLnJlZmVycmVkQnksXHJcbi8vICAgICAgIGdyb3VwSWQ6IHNlbGVjdGVkR3JvdXAuaWQsXHJcbi8vICAgICAgIGFkbWluVXNlcklkOiB2YWx1ZXMuYWRtaW5Vc2VySWQgfHwgYWRtaW5JZCxcclxuLy8gICAgICAgYWRtaW5OYW1lOiB2YWx1ZXMuYWRtaW5OYW1lIHx8IGFkbWluTmFtZSxcclxuLy8gICAgICAgYWRtaW5QaG9uZTogdmFsdWVzLmFkbWluUGhvbmUgfHwgYWRtaW5QaG9uZSxcclxuLy8gICAgICAgZW5yb2xsbWVudElkOiBzZWxlY3RlZFRpY2tldC5lbnJvbGxtZW50SWQsXHJcbi8vICAgICB9O1xyXG5cclxuLy8gICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLnBvc3QoXCIvYmlkLXJlcXVlc3QvY3JlYXRlXCIsIHBheWxvYWQpO1xyXG4gICAgXHJcbi8vICAgICBhcGkuc3VjY2Vzcyh7XHJcbi8vICAgICAgIG1lc3NhZ2U6IFwiU3VjY2Vzc1wiLFxyXG4vLyAgICAgICBkZXNjcmlwdGlvbjogXCJCaWQgUmVxdWVzdCBzdWJtaXR0ZWQgc3VjY2Vzc2Z1bGx5IVwiLFxyXG4vLyAgICAgfSk7XHJcblxyXG4vLyAgICAgc2V0VGltZW91dCgoKSA9PiB3aW5kb3cuY2xvc2UoKSwgMTUwMCk7XHJcbi8vICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvcjpcIiwgZXJyb3IpO1xyXG4vLyAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHJlc3BvbnNlOlwiLCBlcnJvci5yZXNwb25zZSk7XHJcbi8vICAgICBhcGkuZXJyb3Ioe1xyXG4vLyAgICAgICBtZXNzYWdlOiBcIkVycm9yXCIsXHJcbi8vICAgICAgIGRlc2NyaXB0aW9uOiBlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBzYXZlIHJlcXVlc3QuXCIsXHJcbi8vICAgICB9KTtcclxuLy8gICB9IGZpbmFsbHkge1xyXG4vLyAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbi8vICAgfVxyXG4vLyB9O1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgZmV0Y2hVc2VycygpO1xyXG4vLyAgICAgZmV0Y2hBZG1pblByb2ZpbGUoKTtcclxuLy8gICAgIGNyZWF0ZUZvcm0uc2V0RmllbGRzVmFsdWUoeyBkYXRlOiBkYXlqcygpIH0pO1xyXG4vLyAgIH0sIFtdKTtcclxuXHJcbi8vICAgY29uc3QgaXNTdWJtaXREaXNhYmxlZCA9XHJcbi8vICAgICBjcmVhdGVHcm91cHMubGVuZ3RoID09PSAwIHx8XHJcbi8vICAgICBjcmVhdGVHcm91cHNbc2VsZWN0ZWRDcmVhdGVHcm91cEluZGV4XT8uaXNQcml6ZWQ7XHJcblxyXG4vLyAgIHJldHVybiAoXHJcbi8vICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1ncmF5LTEwMCBwLTYgZmxleCBqdXN0aWZ5LWNlbnRlclwiPlxyXG4vLyAgICAgICB7Y29udGV4dEhvbGRlcn1cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXctNHhsIGJnLXdoaXRlIHNoYWRvdy1sZyBmb250LXNhbnMgdGV4dC1zbSB0ZXh0LWdyYXktODAwIHJvdW5kZWQtbGdcIj5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iLTIgYm9yZGVyLWJsdWUtOTAwIHAtNiBtYi02IGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4vLyAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWJsdWUtOTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4vLyAgICAgICAgICAgICBOZXcgQmlkIFJlcXVlc3RcclxuLy8gICAgICAgICAgIDwvaDI+XHJcbi8vICAgICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9eygpID0+IHdpbmRvdy5jbG9zZSgpfT5DbG9zZSBUYWI8L0J1dHRvbj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC04IHBiLThcIj5cclxuLy8gICAgICAgICAgIDxGb3JtXHJcbi8vICAgICAgICAgICAgIGZvcm09e2NyZWF0ZUZvcm19XHJcbi8vICAgICAgICAgICAgIGxheW91dD1cInZlcnRpY2FsXCJcclxuLy8gICAgICAgICAgICAgb25GaW5pc2g9e2hhbmRsZUNyZWF0ZUZpbmlzaH1cclxuLy8gICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XHJcbi8vICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWJsdWUtOTAwIG1iLTQgYm9yZGVyLWIgcGItMiB0ZXh0LWxnXCI+XHJcbi8vICAgICAgICAgICAgICAgICBTdWJzY3JpYmVyIERldGFpbHNcclxuLy8gICAgICAgICAgICAgICA8L2gzPlxyXG5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTVcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICBBZG1pbiBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4vLyAgICAgICAgICAgICAgICAgICBuYW1lPVwiYWRtaW5OYW1lXCJcclxuLy8gICAgICAgICAgICAgICAgICAgcnVsZXM9e1tcclxuLy8gICAgICAgICAgICAgICAgICAgICB7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIkFkbWluIG5hbWUgaXMgcmVxdWlyZWQhXCIgfSxcclxuLy8gICAgICAgICAgICAgICAgICAgXX1cclxuLy8gICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMFwiXHJcbi8vICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQXV0by1mZXRjaGVkIGZyb20gcHJvZmlsZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktNjAwIGN1cnNvci1ub3QtYWxsb3dlZCByb3VuZGVkLW1kXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBwcmVmaXg9ezxVc2VyT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiIC8+fVxyXG4vLyAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbi8vICAgICAgICAgICAgICAgICB7LyogSGlkZGVuIGZpZWxkcyBmb3IgYWRtaW4gZGV0YWlscyAqL31cclxuLy8gICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbmFtZT1cImFkbWluSWRcIiBoaWRkZW4+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxJbnB1dCAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbi8vICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJhZG1pblBob25lXCIgaGlkZGVuPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8SW5wdXQgLz5cclxuLy8gICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4vLyAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbSBuYW1lPVwiYWRtaW5FbWFpbFwiIGhpZGRlbj5cclxuLy8gICAgICAgICAgICAgICAgICAgPElucHV0IC8+XHJcbi8vICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi01XCI+XHJcbi8vICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgU2VhcmNoIEN1c3RvbWVyIChOYW1lL1Bob25lKXtcIiBcIn1cclxuLy8gICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbi8vICAgICAgICAgICAgICAgICAgIG5hbWU9XCJzdWJzY3JpYmVySWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBydWxlcz17W1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIHsgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiUGxlYXNlIHNlbGVjdCBhIGN1c3RvbWVyIVwiIH0sXHJcbi8vICAgICAgICAgICAgICAgICAgIF19XHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTBcIlxyXG4vLyAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVHlwZSBuYW1lIG9yIHBob25lIG51bWJlci4uLlwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNyZWF0ZUN1c3RvbWVyU2VsZWN0fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e2xvYWRpbmdVc2Vyc31cclxuLy8gICAgICAgICAgICAgICAgICAgICBub3RGb3VuZENvbnRlbnQ9e1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZ1VzZXJzID8gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8U3BpbiBzaXplPVwic21hbGxcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgXCJObyBjdXN0b21lcnMgZm91bmRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgKG9wdGlvbj8ubGFiZWwgPz8gXCJcIilcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbi8vICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e3VzZXJzLm1hcCgodXNlcikgPT4gKHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiB1c2VyLl9pZCxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBgJHt1c2VyLmZ1bGxfbmFtZSB8fCB1c2VyLm5hbWUgfHwgXCJVbmtub3duXCJ9IC0gJHt1c2VyLnBob25lX251bWJlciB8fCB1c2VyLm1vYmlsZSB8fCBcIk5vIFBob25lXCJ9YCxcclxuLy8gICAgICAgICAgICAgICAgICAgICB9KSl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTYgYmctZ3JheS01MCBwLTQgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMjAwIG1iLTZcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIFN1YnNjcmliZXIgTmFtZVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbi8vICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInN1YnNjcmliZXJOYW1lXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiUmVxdWlyZWQhXCIgfV19XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8SW5wdXQgcmVhZE9ubHkgY2xhc3NOYW1lPVwiYmctZ3JheS0xMDAgYm9yZGVyLWdyYXktMzAwXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIE1vYmlsZSBOdW1iZXJcclxuLy8gICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJtb2JpbGVOdW1iZXJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJSZXF1aXJlZCFcIiB9XX1cclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi0wXCJcclxuLy8gICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxJbnB1dCByZWFkT25seSBjbGFzc05hbWU9XCJiZy1ncmF5LTEwMCBib3JkZXItZ3JheS0zMDBcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICB7Y3JlYXRlR3JvdXBzLmxlbmd0aCA+IDAgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgLy8gPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuLy8gICAgICAgICAgICAgICAgIC8vICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCB0ZXh0LWxnXCI+XHJcbi8vICAgICAgICAgICAgICAgICAvLyAgICAgU2VsZWN0IEdyb3VwIGZvciBCaWQgUmVxdWVzdHtcIiBcIn1cclxuLy8gICAgICAgICAgICAgICAgIC8vICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgLy8gICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgLy8gICA8Rm9ybS5JdGVtXHJcbi8vICAgICAgICAgICAgICAgICAvLyAgICAgbmFtZT1cInNlbGVjdGVkR3JvdXBJbmRleFwiXHJcbi8vICAgICAgICAgICAgICAgICAvLyAgICAgcnVsZXM9e1tcclxuLy8gICAgICAgICAgICAgICAgIC8vICAgICAgIHsgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiUGxlYXNlIHNlbGVjdCBhIGdyb3VwIVwiIH0sXHJcbi8vICAgICAgICAgICAgICAgICAvLyAgICAgXX1cclxuLy8gICAgICAgICAgICAgICAgIC8vICAgICBjbGFzc05hbWU9XCJtYi00XCJcclxuLy8gICAgICAgICAgICAgICAgIC8vICAgICBpbml0aWFsVmFsdWU9ezB9XHJcbi8vICAgICAgICAgICAgICAgICAvLyAgID5cclxuLy8gICAgICAgICAgICAgICAgIC8vICAgICA8U2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAvLyAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4vLyAgICAgICAgICAgICAgICAgLy8gICAgICAgcGxhY2Vob2xkZXI9XCJDaG9vc2Ugd2hpY2ggZ3JvdXAuLi5cIlxyXG4vLyAgICAgICAgICAgICAgICAgLy8gICAgICAgb25DaGFuZ2U9e2hhbmRsZUNyZWF0ZUdyb3VwU2VsZWN0fVxyXG4vLyAgICAgICAgICAgICAgICAgLy8gICAgICAgdmFsdWU9e3NlbGVjdGVkQ3JlYXRlR3JvdXBJbmRleH1cclxuLy8gICAgICAgICAgICAgICAgIC8vICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbi8vICAgICAgICAgICAgICAgICAvLyAgICAgICBkcm9wZG93blN0eWxlPXt7IG1heEhlaWdodDogXCI0MDBweFwiIH19XHJcbi8vICAgICAgICAgICAgICAgICAvLyAgICAgICBvcHRpb25MYWJlbFByb3A9XCJsYWJlbFwiXHJcbi8vICAgICAgICAgICAgICAgICAvLyAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgLy8gICAgICAge2NyZWF0ZUdyb3Vwcy5tYXAoKGdyb3VwLCBpbmRleCkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgLy8gICAgICAgICA8T3B0aW9uXHJcbi8vICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAga2V5PXtncm91cC5pZH1cclxuLy8gICAgICAgICAgICAgICAgIC8vICAgICAgICAgICB2YWx1ZT17aW5kZXh9XHJcbi8vICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgbGFiZWw9e2Ake2dyb3VwLmdyb3VwTmFtZX0gKFRpY2tldDogJHtncm91cC50aWNrZXROdW1iZXJ9KWB9XHJcbi8vICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgY2xhc3NOYW1lPVwicHktM1wiXHJcbi8vICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgZGlzYWJsZWQ9e2dyb3VwLmlzUHJpemVkfVxyXG4vLyAgICAgICAgICAgICAgICAgLy8gICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuLy8gICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgdGV4dC1iYXNlXCI+XHJcbi8vICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwTmFtZX1cclxuLy8gICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgbXQtMC41XCI+XHJcbi8vICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAgICAgVGlja2V0OiB7Z3JvdXAudGlja2V0TnVtYmVyfVxyXG4vLyAgICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgIHtncm91cC5pc1ByaXplZCAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAgIDxUYWdcclxuLy8gICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgICBjb2xvcj1cImVycm9yXCJcclxuLy8gICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC0yIHRleHQteHMgZm9udC1ib2xkXCJcclxuLy8gICAgICAgICAgICAgICAgIC8vICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgICAgIEFscmVhZHkgUHJpemVkXHJcbi8vICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICAgIDwvVGFnPlxyXG4vLyAgICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICAgIC8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIC8vICAgICAgICAgPC9PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAvLyAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgICAgIC8vICAgICA8L1NlbGVjdD5cclxuLy8gICAgICAgICAgICAgICAgIC8vICAgPC9Gb3JtLkl0ZW0+XHJcbi8vIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG5cclxuLy8gICB7LyogR1JPVVAgU0VMRUNUICovfVxyXG4vLyAgIDxkaXY+XHJcbi8vICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIHRleHQtbGcgbWItMlwiPlxyXG4vLyAgICAgICBTZWxlY3QgR3JvdXAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuLy8gICAgIDwvbGFiZWw+XHJcblxyXG4vLyAgICAgPEZvcm0uSXRlbVxyXG4vLyAgICAgICBuYW1lPVwic2VsZWN0ZWRHcm91cElkXCJcclxuLy8gICAgICAgcnVsZXM9e1tcclxuLy8gICAgICAgICB7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIlBsZWFzZSBzZWxlY3QgZ3JvdXAhXCIgfSxcclxuLy8gICAgICAgXX1cclxuLy8gICAgICAgY2xhc3NOYW1lPVwibWItMFwiXHJcbi8vICAgICA+XHJcbi8vICAgICAgIDxTZWxlY3RcclxuLy8gICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4vLyAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEdyb3VwXCJcclxuLy8gICAgICAgICBvbkNoYW5nZT17aGFuZGxlR3JvdXBDaGFuZ2V9XHJcbi8vICAgICAgID5cclxuLy8gICAgICAgICB7Y3JlYXRlR3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuLy8gICAgICAgICAgIDxPcHRpb24ga2V5PXtncm91cC5pZH0gdmFsdWU9e2dyb3VwLmlkfT5cclxuLy8gICAgICAgICAgICAge2dyb3VwLmdyb3VwTmFtZX1cclxuLy8gICAgICAgICAgIDwvT3B0aW9uPlxyXG4vLyAgICAgICAgICkpfVxyXG4vLyAgICAgICA8L1NlbGVjdD5cclxuLy8gICAgIDwvRm9ybS5JdGVtPlxyXG4vLyAgIDwvZGl2PlxyXG5cclxuLy8gICB7LyogVElDS0VUIFNFTEVDVCAqL31cclxuLy8gICA8ZGl2PlxyXG4vLyAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCB0ZXh0LWxnIG1iLTJcIj5cclxuLy8gICAgICAgU2VsZWN0IFRpY2tldCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4vLyAgICAgPC9sYWJlbD5cclxuXHJcbi8vICAgICA8Rm9ybS5JdGVtXHJcbi8vICAgICAgIG5hbWU9XCJ0aWNrZXRJbmRleFwiXHJcbi8vICAgICAgIHJ1bGVzPXtbXHJcbi8vICAgICAgICAgeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJQbGVhc2Ugc2VsZWN0IHRpY2tldCFcIiB9LFxyXG4vLyAgICAgICBdfVxyXG4vLyAgICAgICBjbGFzc05hbWU9XCJtYi0wXCJcclxuLy8gICAgID5cclxuLy8gICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbi8vICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgVGlja2V0XCJcclxuLy8gICAgICAgICBvbkNoYW5nZT17aGFuZGxlVGlja2V0Q2hhbmdlfVxyXG4vLyAgICAgICA+XHJcbi8vICAgICAgICAge2dyb3VwVGlja2V0cy5tYXAoKHRpY2tldCwgaW5kZXgpID0+IChcclxuLy8gICAgICAgICAgIDxPcHRpb25cclxuLy8gICAgICAgICAgICAga2V5PXtpbmRleH1cclxuLy8gICAgICAgICAgICAgdmFsdWU9e2luZGV4fVxyXG4vLyAgICAgICAgICAgICBkaXNhYmxlZD17dGlja2V0LmlzUHJpemVkfVxyXG4vLyAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICBUaWNrZXQgI3t0aWNrZXQudGlja2V0TnVtYmVyfVxyXG4vLyAgICAgICAgICAgICB7dGlja2V0LmlzUHJpemVkID8gXCIgKEFscmVhZHkgUHJpemVkKVwiIDogXCJcIn1cclxuLy8gICAgICAgICAgIDwvT3B0aW9uPlxyXG4vLyAgICAgICAgICkpfVxyXG4vLyAgICAgICA8L1NlbGVjdD5cclxuLy8gICAgIDwvRm9ybS5JdGVtPlxyXG4vLyAgIDwvZGl2PlxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICBcclxuXHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNCBtYi02XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBBdWN0aW9uIFN0YXJ0IERhdGVcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJzdGFydERhdGVcIiBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYmx1ZS01MCBib3JkZXItYmx1ZS0yMDAgdGV4dC1ibHVlLTkwMCBmb250LXNlbWlib2xkIGgtMTBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBBdWN0aW9uIEVuZCBEYXRlXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbSBuYW1lPVwiZW5kRGF0ZVwiIGNsYXNzTmFtZT1cIm1iLTBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ibHVlLTUwIGJvcmRlci1ibHVlLTIwMCB0ZXh0LWJsdWUtOTAwIGZvbnQtc2VtaWJvbGQgaC0xMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIEF1Y3Rpb25zIERvbmVcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJhdWN0aW9uc0RvbmVcIiBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JlZW4tNTAgYm9yZGVyLWdyZWVuLTIwMCB0ZXh0LWdyZWVuLTkwMCBmb250LWJvbGQgdGV4dC1jZW50ZXIgaC0xMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRFbnJvbGxtZW50SWQgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTIgcC0yIGJnLWdyYXktNTAgcm91bmRlZFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgRW5yb2xsbWVudCBJRDoge3NlbGVjdGVkRW5yb2xsbWVudElkfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgKX1cclxuXHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICBQcmltYXJ5IEdyb3VwIE5hbWVcclxuLy8gICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbSBuYW1lPVwiZ3JvdXBOYW1lXCIgY2xhc3NOYW1lPVwibWItMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWJsdWUtNTAgYm9yZGVyLWJsdWUtMzAwIGZvbnQtc2VtaWJvbGRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICBQcmltYXJ5IFRpY2tldCBOdW1iZXJcclxuLy8gICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbSBuYW1lPVwidGlja2V0TnVtYmVyXCIgY2xhc3NOYW1lPVwibWItMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWJsdWUtNTAgYm9yZGVyLWJsdWUtMzAwIGZvbnQtc2VtaWJvbGRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XHJcbi8vICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWJsdWUtOTAwIG1iLTQgYm9yZGVyLWIgcGItMiB0ZXh0LWxnXCI+XHJcbi8vICAgICAgICAgICAgICAgICBBdWN0aW9uIERldGFpbHNcclxuLy8gICAgICAgICAgICAgICA8L2gzPlxyXG5cclxuLy8gICAgICAgICAgICAgICB7Lyog4pyFIERpc3BsYXkgTmV4dCBBdWN0aW9uIERhdGUgSW5mb3JtYXRpb24gKi99XHJcbi8vICAgICAgICAgICAgICAge2xvYWRpbmdOZXh0QXVjdGlvbiAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgcC0zIGJnLWJsdWUtNTAgYm9yZGVyIGJvcmRlci1ibHVlLTIwMCByb3VuZGVkLWxnXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8U3BpbiBzaXplPVwic21hbGxcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIExvYWRpbmcgbmV4dCBhdWN0aW9uIGRhdGUuLi5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgKX1cclxuXHJcblxyXG4vLyAgICAgICAgICAgICAgIHshbG9hZGluZ05leHRBdWN0aW9uICYmIGF1Y3Rpb25JbmZvLm5leHREYXRlICYmIChcclxuLy8gICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgcC0zIGJnLWdyZWVuLTUwIGJvcmRlciBib3JkZXItZ3JlZW4tMjAwIHJvdW5kZWQtbGdcIj5cclxuLy8gICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuLy8gICAgICAgPENhbGVuZGFyT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDAgdGV4dC1sZ1wiIC8+XHJcbi8vICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+XHJcbi8vICAgICAgICAgICA8c3Ryb25nPk5leHQgQXVjdGlvbiBEYXRlOjwvc3Ryb25nPntcIiBcIn1cclxuLy8gICAgICAgICAgIHthdWN0aW9uSW5mby5uZXh0RGF0ZS5mb3JtYXQoXCJERC1NTS1ZWVlZXCIpfVxyXG4vLyAgICAgICAgICAge2F1Y3Rpb25JbmZvLnRvdGFsQXVjdGlvbnMgPiAwICYmIChcclxuLy8gICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMiB0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cclxuLy8gICAgICAgICAgICAgICAoQXVjdGlvbiAje2F1Y3Rpb25JbmZvLnRvdGFsQXVjdGlvbnMgKyAxfSlcclxuLy8gICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgKX1cclxuLy8gICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgIDwvZGl2PlxyXG4vLyAgICAgPC9kaXY+XHJcbi8vICAgPC9kaXY+XHJcbi8vICl9XHJcblxyXG4vLyAgICAgICAgICAgICAgIHsvKiB7IWxvYWRpbmdOZXh0QXVjdGlvbiAmJiBhdWN0aW9uSW5mby5uZXh0RGF0ZSAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgcC0zIGJnLWdyZWVuLTUwIGJvcmRlciBib3JkZXItZ3JlZW4tMjAwIHJvdW5kZWQtbGdcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxDYWxlbmRhck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwIHRleHQtbGdcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5OZXh0IEF1Y3Rpb24gRGF0ZTo8L3N0cm9uZz57XCIgXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHthdWN0aW9uSW5mby5uZXh0RGF0ZS5mb3JtYXQoXCJERC1NTS1ZWVlZXCIpfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAge2F1Y3Rpb25JbmZvLnRvdGFsQXVjdGlvbnMgPiAwICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG1sLTNcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAoQXVjdGlvbiAje2F1Y3Rpb25JbmZvLnRvdGFsQXVjdGlvbnMgKyAxfSlcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICApfSAqL31cclxuXHJcbi8vICAgICAgICAgICAgICAgeyFsb2FkaW5nTmV4dEF1Y3Rpb24gJiZcclxuLy8gICAgICAgICAgICAgICAgICFhdWN0aW9uSW5mby5uZXh0RGF0ZSAmJlxyXG4vLyAgICAgICAgICAgICAgICAgY3JlYXRlR3JvdXBzLmxlbmd0aCA+IDAgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8QWxlcnRcclxuLy8gICAgICAgICAgICAgICAgICAgICBtZXNzYWdlPVwiTm8gVXBjb21pbmcgQXVjdGlvbiBGb3VuZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb249XCJUaGlzIGdyb3VwIGRvZXNuJ3QgaGF2ZSBhbnkgc2NoZWR1bGVkIGF1Y3Rpb24uIFBsZWFzZSBzZXQgdGhlIGF1Y3Rpb24gZGF0ZSBtYW51YWxseSBvciBjb25maWd1cmUgdGhlIGdyb3VwJ3MgYXVjdGlvbiBzY2hlZHVsZS5cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ3YXJuaW5nXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBzaG93SWNvblxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGljb249ezxDbG9ja0NpcmNsZU91dGxpbmVkIC8+fVxyXG4vLyAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgKX1cclxuXHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02XCI+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICBBdWN0aW9uIERhdGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhdWN0aW9uRGF0ZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgcnVsZXM9e1tcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6IHRydWUsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIHNlbGVjdCBhdWN0aW9uIGRhdGUhXCIsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIF19XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8RGF0ZVBpY2tlclxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItZ3JheS00MDAgaC0xMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBBdWN0aW9uIERhdGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgZm9ybWF0PVwiREQtTU0tWVlZWVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZERhdGU9eyhjdXJyZW50KSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC8vIE9wdGlvbmFsOiBEaXNhYmxlIHBhc3QgZGF0ZXNcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGN1cnJlbnQgJiYgY3VycmVudCA8IGRheWpzKCkuc3RhcnRPZihcImRheVwiKTtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbi8vICAgICAgICAgICAgICAgICAgIHthdWN0aW9uSW5mby5uZXh0RGF0ZSAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JlZW4tNjAwIG10LTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIE5leHQgYXVjdGlvbiBkYXRlIGF1dG8tbG9hZGVkIGZyb20gZ3JvdXAgc2V0dGluZ3NcclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgUmVxdWVzdCBUaW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbi8vICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImF1Y3Rpb25UaW1lXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICBpbml0aWFsVmFsdWU9e2RheWpzKCl9IC8vIEN1cnJlbnQgVGltZVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiB0cnVlLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBzZWxlY3QgYXVjdGlvbiB0aW1lIVwiLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuLy8gICAgICAgICAgICAgICAgICAgICBdfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPFRpbWVQaWNrZXJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyLWdyYXktNDAwIGgtMTBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgZm9ybWF0PVwiaDptbSBBXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHVzZTEySG91cnNcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFRpbWVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgbWludXRlU3RlcD17MTV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTQgcHQtNCBib3JkZXItdFwiPlxyXG4vLyAgICAgICAgICAgICAgIDxCdXR0b25cclxuLy8gICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHdpbmRvdy5jbG9zZSgpfVxyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIGgtMTIgZm9udC1zZW1pYm9sZCBib3JkZXItZ3JheS00MDAgdGV4dC1sZ1wiXHJcbi8vICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgQ2FuY2VsXHJcbi8vICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbi8vICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4vLyAgICAgICAgICAgICAgICAgaHRtbFR5cGU9XCJzdWJtaXRcIlxyXG4vLyAgICAgICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZ31cclxuLy8gICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBiZy1ibHVlLTkwMCBob3ZlcjpiZy1ibHVlLTgwMCBoLTEyIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSB0ZXh0LWxnXCJcclxuLy8gICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdERpc2FibGVkfVxyXG4vLyAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgIFN1Ym1pdCBSZXF1ZXN0XHJcbi8vICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgPC9Gb3JtPlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgIDwvZGl2PlxyXG4vLyAgICk7XHJcbi8vIH1cclxuXHJcbi8vIGV4cG9ydCBkZWZhdWx0IENyZWF0ZUJpZFJlcXVlc3Q7XHJcblxyXG5cclxuXHJcblxyXG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQge1xyXG4gIEZvcm0sXHJcbiAgSW5wdXQsXHJcbiAgRGF0ZVBpY2tlcixcclxuICBUaW1lUGlja2VyLFxyXG4gIEJ1dHRvbixcclxuICBTZWxlY3QsXHJcbiAgbm90aWZpY2F0aW9uLFxyXG4gIFNwaW4sXHJcbiAgVGFnLFxyXG4gIEFsZXJ0LFxyXG59IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7XHJcbiAgQ2xvY2tDaXJjbGVPdXRsaW5lZCxcclxuICBVc2VyT3V0bGluZWQsXHJcbiAgQ2FsZW5kYXJPdXRsaW5lZCxcclxufSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuaW1wb3J0IEFQSSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgZGF5anMgZnJvbSBcImRheWpzXCI7XHJcblxyXG5jb25zdCB7IE9wdGlvbiB9ID0gU2VsZWN0O1xyXG5cclxuZnVuY3Rpb24gQ3JlYXRlQmlkUmVxdWVzdCgpIHtcclxuICBjb25zdCBbYXBpLCBjb250ZXh0SG9sZGVyXSA9IG5vdGlmaWNhdGlvbi51c2VOb3RpZmljYXRpb24oKTtcclxuICBjb25zdCBbY3JlYXRlRm9ybV0gPSBGb3JtLnVzZUZvcm0oKTtcclxuXHJcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2xvYWRpbmdVc2Vycywgc2V0TG9hZGluZ1VzZXJzXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3JlYXRlR3JvdXBzLCBzZXRDcmVhdGVHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtncm91cFRpY2tldHMsIHNldEdyb3VwVGlja2V0c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkVGlja2V0SW5kZXgsIHNldFNlbGVjdGVkVGlja2V0SW5kZXhdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3NlbGVjdGVkRW5yb2xsbWVudElkLCBzZXRTZWxlY3RlZEVucm9sbG1lbnRJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc2VsZWN0ZWRHcm91cElkLCBzZXRTZWxlY3RlZEdyb3VwSWRdID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIC8vIEFkbWluIHVzZXIgc3RhdGVcclxuICBjb25zdCBbYWRtaW5OYW1lLCBzZXRBZG1pbk5hbWVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FkbWluSWQsIHNldEFkbWluSWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FkbWluRW1haWwsIHNldEFkbWluRW1haWxdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FkbWluUGhvbmUsIHNldEFkbWluUGhvbmVdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIC8vIOKchSBDdXN0b21lciBPdmVydmlldyBEYXRhXHJcbiAgY29uc3QgW2N1c3RvbWVyT3ZlcnZpZXcsIHNldEN1c3RvbWVyT3ZlcnZpZXddID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2xvYWRpbmdPdmVydmlldywgc2V0TG9hZGluZ092ZXJ2aWV3XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgLy8gQXVjdGlvbiBpbmZvIHN0YXRlXHJcbiAgY29uc3QgW25leHRBdWN0aW9uRGF0ZSwgc2V0TmV4dEF1Y3Rpb25EYXRlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtsb2FkaW5nTmV4dEF1Y3Rpb24sIHNldExvYWRpbmdOZXh0QXVjdGlvbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2F1Y3Rpb25JbmZvLCBzZXRBdWN0aW9uSW5mb10gPSB1c2VTdGF0ZSh7XHJcbiAgICBuZXh0RGF0ZTogbnVsbCxcclxuICAgIGxhc3REYXRlOiBudWxsLFxyXG4gICAgdG90YWxBdWN0aW9uczogMCxcclxuICAgIG5leHRBdWN0aW9uVHlwZTogbnVsbCxcclxuICAgIHRvdGFsUGF5YWJsZTogMCxcclxuICAgIHRvdGFsUHJvZml0OiAwLFxyXG4gICAgdG90YWxJbnZlc3RtZW50OiAwLFxyXG4gICAgdG90YWxCYWxhbmNlOiAwLFxyXG4gICAgdG90YWxQZW5hbHR5OiAwLFxyXG4gICAgdG90YWxMYXRlRmVlOiAwLFxyXG4gICAgaXNQcml6ZWQ6IGZhbHNlLFxyXG4gIH0pO1xyXG5cclxuICAvLyDinIUgRklYRUQ6IEZldGNoIGN1c3RvbWVyIG92ZXJ2aWV3IHVzaW5nIHRoZSB3b3JraW5nIEFQSVxyXG4gIGNvbnN0IGZldGNoQ3VzdG9tZXJPdmVydmlldyA9IGFzeW5jICh1c2VySWQsIGdyb3VwSWQsIHRpY2tldCkgPT4ge1xyXG4gICAgaWYgKCF1c2VySWQgfHwgIWdyb3VwSWQgfHwgIXRpY2tldCkge1xyXG4gICAgICBjb25zb2xlLmxvZyhcIk1pc3NpbmcgcmVxdWlyZWQgcGFyYW1zIGZvciBjdXN0b21lciBvdmVydmlld1wiKTtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0TG9hZGluZ092ZXJ2aWV3KHRydWUpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldChcclxuICAgICAgICBgL3YxL2FkbWluL3VzZXJzL292ZXJ2aWV3L3NpbmdsZT91c2VyX2lkPSR7dXNlcklkfSZncm91cF9pZD0ke2dyb3VwSWR9JnRpY2tldD0ke3RpY2tldH1gXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBjb25zb2xlLmxvZyhcIkN1c3RvbWVyIE92ZXJ2aWV3IFJlc3BvbnNlOlwiLCByZXNwb25zZS5kYXRhKTtcclxuXHJcbiAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEuc3VjY2Vzcykge1xyXG4gICAgICAgIGNvbnN0IG92ZXJ2aWV3RGF0YSA9IHJlc3BvbnNlLmRhdGEuZGF0YTtcclxuICAgICAgICBzZXRDdXN0b21lck92ZXJ2aWV3KG92ZXJ2aWV3RGF0YSk7XHJcblxyXG4gICAgICAgIC8vIOKchSBDaGVjayBpZiB0aWNrZXQgaXMgYWxyZWFkeSBwcml6ZWRcclxuICAgICAgICBpZiAob3ZlcnZpZXdEYXRhLmlzX3ByaXplZCA9PT0gdHJ1ZSkge1xyXG4gICAgICAgICAgYXBpLmVycm9yKHtcclxuICAgICAgICAgICAgbWVzc2FnZTogXCJUaWNrZXQgQWxyZWFkeSBQcml6ZWRcIixcclxuICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiVGhpcyB0aWNrZXQgaGFzIGFscmVhZHkgYmVlbiBwcml6ZWQgaW4gYW4gYXVjdGlvbi4gWW91IGNhbm5vdCByYWlzZSBhIGJpZCByZXF1ZXN0IGZvciB0aGlzIHRpY2tldC5cIixcclxuICAgICAgICAgICAgZHVyYXRpb246IDUsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIFxyXG4gICAgICAgICAgc2V0QXVjdGlvbkluZm8oe1xyXG4gICAgICAgICAgICBuZXh0RGF0ZTogbnVsbCxcclxuICAgICAgICAgICAgbGFzdERhdGU6IG51bGwsXHJcbiAgICAgICAgICAgIHRvdGFsQXVjdGlvbnM6IDAsXHJcbiAgICAgICAgICAgIG5leHRBdWN0aW9uVHlwZTogbnVsbCxcclxuICAgICAgICAgICAgdG90YWxQYXlhYmxlOiBvdmVydmlld0RhdGEudG90YWxfcGF5YWJsZSB8fCAwLFxyXG4gICAgICAgICAgICB0b3RhbFByb2ZpdDogb3ZlcnZpZXdEYXRhLnRvdGFsX3Byb2ZpdCB8fCAwLFxyXG4gICAgICAgICAgICB0b3RhbEludmVzdG1lbnQ6IG92ZXJ2aWV3RGF0YS50b3RhbF9pbnZlc3RtZW50IHx8IDAsXHJcbiAgICAgICAgICAgIHRvdGFsQmFsYW5jZTogb3ZlcnZpZXdEYXRhLnRvdGFsX2JhbGFuY2UgfHwgMCxcclxuICAgICAgICAgICAgdG90YWxQZW5hbHR5OiBvdmVydmlld0RhdGEudG90YWxfcGVuYWx0eSB8fCAwLFxyXG4gICAgICAgICAgICB0b3RhbExhdGVGZWU6IG92ZXJ2aWV3RGF0YS50b3RhbF9sYXRlX2ZlZSB8fCAwLFxyXG4gICAgICAgICAgICBpc1ByaXplZDogdHJ1ZSxcclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIHNldE5leHRBdWN0aW9uRGF0ZShudWxsKTtcclxuICAgICAgICAgIGNyZWF0ZUZvcm0uc2V0RmllbGRzVmFsdWUoe1xyXG4gICAgICAgICAgICBhdWN0aW9uRGF0ZTogbnVsbCxcclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIHJldHVybiBvdmVydmlld0RhdGE7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyDinIUgRXh0cmFjdCBuZXh0IGF1Y3Rpb24gZGF0ZSBmcm9tIHRoZSBvdmVydmlldyBkYXRhXHJcbiAgICAgICAgaWYgKG92ZXJ2aWV3RGF0YS5uZXh0X2F1Y3Rpb25fZGF0ZSkge1xyXG4gICAgICAgICAgY29uc3QgZm9ybWF0dGVkTmV4dERhdGUgPSBkYXlqcyhvdmVydmlld0RhdGEubmV4dF9hdWN0aW9uX2RhdGUpO1xyXG4gICAgICAgICAgXHJcbiAgICAgICAgICBzZXRBdWN0aW9uSW5mbyh7XHJcbiAgICAgICAgICAgIG5leHREYXRlOiBmb3JtYXR0ZWROZXh0RGF0ZSxcclxuICAgICAgICAgICAgbGFzdERhdGU6IG51bGwsXHJcbiAgICAgICAgICAgIHRvdGFsQXVjdGlvbnM6IDAsXHJcbiAgICAgICAgICAgIG5leHRBdWN0aW9uVHlwZTogb3ZlcnZpZXdEYXRhLmF1Y3Rpb25fdHlwZSB8fCAnTm9ybWFsIEF1Y3Rpb24nLFxyXG4gICAgICAgICAgICB0b3RhbFBheWFibGU6IG92ZXJ2aWV3RGF0YS50b3RhbF9wYXlhYmxlIHx8IDAsXHJcbiAgICAgICAgICAgIHRvdGFsUHJvZml0OiBvdmVydmlld0RhdGEudG90YWxfcHJvZml0IHx8IDAsXHJcbiAgICAgICAgICAgIHRvdGFsSW52ZXN0bWVudDogb3ZlcnZpZXdEYXRhLnRvdGFsX2ludmVzdG1lbnQgfHwgMCxcclxuICAgICAgICAgICAgdG90YWxCYWxhbmNlOiBvdmVydmlld0RhdGEudG90YWxfYmFsYW5jZSB8fCAwLFxyXG4gICAgICAgICAgICB0b3RhbFBlbmFsdHk6IG92ZXJ2aWV3RGF0YS50b3RhbF9wZW5hbHR5IHx8IDAsXHJcbiAgICAgICAgICAgIHRvdGFsTGF0ZUZlZTogb3ZlcnZpZXdEYXRhLnRvdGFsX2xhdGVfZmVlIHx8IDAsXHJcbiAgICAgICAgICAgIGlzUHJpemVkOiBmYWxzZSxcclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIHNldE5leHRBdWN0aW9uRGF0ZShmb3JtYXR0ZWROZXh0RGF0ZSk7XHJcblxyXG4gICAgICAgICAgY3JlYXRlRm9ybS5zZXRGaWVsZHNWYWx1ZSh7XHJcbiAgICAgICAgICAgIGF1Y3Rpb25EYXRlOiBmb3JtYXR0ZWROZXh0RGF0ZSxcclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIC8vIFNob3cgc3VjY2VzcyB3aXRoIGF1Y3Rpb24gaW5mb1xyXG4gICAgICAgICAgY29uc3QgYXVjdGlvblR5cGUgPSBvdmVydmlld0RhdGEuYXVjdGlvbl90eXBlIHx8ICdOb3JtYWwnO1xyXG4gICAgICAgICAgYXBpLnN1Y2Nlc3Moe1xyXG4gICAgICAgICAgICBtZXNzYWdlOiBcIkN1c3RvbWVyIERhdGEgTG9hZGVkXCIsXHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBgTmV4dCAke2F1Y3Rpb25UeXBlfSBBdWN0aW9uOiAke2Zvcm1hdHRlZE5leHREYXRlLmZvcm1hdChcIkRELU1NLVlZWVlcIil9YCxcclxuICAgICAgICAgICAgZHVyYXRpb246IDMsXHJcbiAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICByZXR1cm4gb3ZlcnZpZXdEYXRhO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBhcGkud2FybmluZyh7XHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IFwiTm8gVXBjb21pbmcgQXVjdGlvblwiLFxyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJObyBmdXR1cmUgYXVjdGlvbiBmb3VuZCBmb3IgdGhpcyBjdXN0b21lci5cIixcclxuICAgICAgICAgICAgZHVyYXRpb246IDMsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBhcGkuZXJyb3Ioe1xyXG4gICAgICAgICAgbWVzc2FnZTogXCJFcnJvclwiLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IFwiRmFpbGVkIHRvIGZldGNoIGN1c3RvbWVyIG92ZXJ2aWV3IGRhdGEuXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBjdXN0b21lciBvdmVydmlldzpcIiwgZXJyb3IpO1xyXG4gICAgICBcclxuICAgICAgaWYgKGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlPy5pbmNsdWRlcyhcInByaXplZFwiKSkge1xyXG4gICAgICAgIGFwaS5lcnJvcih7XHJcbiAgICAgICAgICBtZXNzYWdlOiBcIlRpY2tldCBBbHJlYWR5IFByaXplZFwiLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IFwiVGhpcyB0aWNrZXQgaGFzIGFscmVhZHkgYmVlbiBwcml6ZWQgaW4gYW4gYXVjdGlvbi5cIixcclxuICAgICAgICAgIGR1cmF0aW9uOiA1LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldEF1Y3Rpb25JbmZvKHByZXYgPT4gKHsgLi4ucHJldiwgaXNQcml6ZWQ6IHRydWUgfSkpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGFwaS5lcnJvcih7XHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkVycm9yXCIsXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbjogZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gZmV0Y2ggY3VzdG9tZXIgZGF0YS5cIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldExvYWRpbmdPdmVydmlldyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8g4pyFIEZ1bmN0aW9uIHRvIGZldGNoIGFkbWluIHByb2ZpbGVcclxuICBjb25zdCBmZXRjaEFkbWluUHJvZmlsZSA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHVzZXJTdHIgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICAgIGlmICghdXNlclN0cikgcmV0dXJuO1xyXG4gICAgICBjb25zdCB1c2VyID0gSlNPTi5wYXJzZSh1c2VyU3RyKTtcclxuICAgICAgY29uc3QgdXNlcklkID0gdXNlci5faWQ7XHJcbiAgICAgIGlmICghdXNlcklkKSByZXR1cm47XHJcblxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IEFQSS5nZXQoYC9hZG1pbi9nZXQtYWRtaW4vJHt1c2VySWR9YCk7XHJcbiAgICAgICAgY29uc3QgbmFtZSA9IHJlcy5kYXRhLm5hbWUgfHwgdXNlci5hZG1pbl9uYW1lIHx8IHVzZXIuZnVsbF9uYW1lIHx8IHVzZXIubmFtZTtcclxuICAgICAgICBjb25zdCBwaG9uZSA9IHJlcy5kYXRhLnBob25lX251bWJlciB8fCB1c2VyLnBob25lX251bWJlciB8fCB1c2VyLm1vYmlsZTtcclxuICAgICAgICBjb25zdCBlbWFpbCA9IHJlcy5kYXRhLmVtYWlsIHx8IHVzZXIuZW1haWw7XHJcblxyXG4gICAgICAgIHNldEFkbWluTmFtZShuYW1lKTtcclxuICAgICAgICBzZXRBZG1pbklkKHVzZXJJZCk7XHJcbiAgICAgICAgc2V0QWRtaW5QaG9uZShwaG9uZSk7XHJcbiAgICAgICAgc2V0QWRtaW5FbWFpbChlbWFpbCk7XHJcblxyXG4gICAgICAgIGNyZWF0ZUZvcm0uc2V0RmllbGRzVmFsdWUoe1xyXG4gICAgICAgICAgYWRtaW5OYW1lOiBuYW1lLFxyXG4gICAgICAgICAgYWRtaW5JZDogdXNlcklkLFxyXG4gICAgICAgICAgYWRtaW5QaG9uZTogcGhvbmUsXHJcbiAgICAgICAgICBhZG1pbkVtYWlsOiBlbWFpbCxcclxuICAgICAgICB9KTtcclxuICAgICAgfSBjYXRjaCAoYWRtaW5FcnJvcikge1xyXG4gICAgICAgIGNvbnN0IG5hbWUgPSB1c2VyLmZ1bGxfbmFtZSB8fCB1c2VyLm5hbWUgfHwgdXNlci5hZG1pbl9uYW1lIHx8IFwiQWRtaW5cIjtcclxuICAgICAgICBjb25zdCBwaG9uZSA9IHVzZXIucGhvbmVfbnVtYmVyIHx8IHVzZXIubW9iaWxlO1xyXG4gICAgICAgIGNvbnN0IGVtYWlsID0gdXNlci5lbWFpbDtcclxuXHJcbiAgICAgICAgc2V0QWRtaW5OYW1lKG5hbWUpO1xyXG4gICAgICAgIHNldEFkbWluSWQodXNlcklkKTtcclxuICAgICAgICBzZXRBZG1pblBob25lKHBob25lKTtcclxuICAgICAgICBzZXRBZG1pbkVtYWlsKGVtYWlsKTtcclxuXHJcbiAgICAgICAgY3JlYXRlRm9ybS5zZXRGaWVsZHNWYWx1ZSh7XHJcbiAgICAgICAgICBhZG1pbk5hbWU6IG5hbWUsXHJcbiAgICAgICAgICBhZG1pbklkOiB1c2VySWQsXHJcbiAgICAgICAgICBhZG1pblBob25lOiBwaG9uZSxcclxuICAgICAgICAgIGFkbWluRW1haWw6IGVtYWlsLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIGFkbWluIHByb2ZpbGU6XCIsIGVycm9yKTtcclxuICAgICAgc2V0QWRtaW5OYW1lKFwiQWRtaW5cIik7XHJcbiAgICAgIGNyZWF0ZUZvcm0uc2V0RmllbGRzVmFsdWUoeyBhZG1pbk5hbWU6IFwiQWRtaW5cIiB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaFVzZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0TG9hZGluZ1VzZXJzKHRydWUpO1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEFQSS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuICAgICAgc2V0VXNlcnMocmVzcG9uc2UuZGF0YSB8fCBbXSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlcnM6XCIsIGVycm9yKTtcclxuICAgICAgYXBpLmVycm9yKHsgbWVzc2FnZTogXCJFcnJvclwiLCBkZXNjcmlwdGlvbjogXCJGYWlsZWQgdG8gZmV0Y2ggdXNlcnMuXCIgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nVXNlcnMoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoQXVjdGlvbkluZm8gPSBhc3luYyAoZ3JvdXBJZCwgdXNlcklkLCB0aWNrZXROdW1iZXIpID0+IHtcclxuICAgIGlmICghZ3JvdXBJZCkgcmV0dXJuIHsgY291bnQ6IDAsIGlzUHJpemVkOiBmYWxzZSB9O1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldChcclxuICAgICAgICBgL2JpZC1yZXF1ZXN0L2dldC1ncm91cC1hdWN0aW9uLXN0YXRzLyR7Z3JvdXBJZH1gLFxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCBkYXRhID0gcmVzcG9uc2UuZGF0YTtcclxuXHJcbiAgICAgIGlmICghZGF0YSB8fCAhZGF0YS5zdWNjZXNzKSB7XHJcbiAgICAgICAgcmV0dXJuIHsgY291bnQ6IDAsIGlzUHJpemVkOiBmYWxzZSB9O1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCBjb3VudCA9IGRhdGEuY291bnQgfHwgMDtcclxuICAgICAgY29uc3QgcHJpemVkTGlzdCA9IGRhdGEucHJpemVkVGlja2V0cyB8fCBbXTtcclxuICAgICAgY29uc3QgaXNQcml6ZWQgPSBwcml6ZWRMaXN0LnNvbWUoXHJcbiAgICAgICAgKGl0ZW0pID0+XHJcbiAgICAgICAgICBTdHJpbmcoaXRlbS51c2VyX2lkKSA9PT0gU3RyaW5nKHVzZXJJZCkgJiZcclxuICAgICAgICAgIFN0cmluZyhpdGVtLnRpY2tldCkgPT09IFN0cmluZyh0aWNrZXROdW1iZXIpLFxyXG4gICAgICApO1xyXG5cclxuICAgICAgcmV0dXJuIHsgY291bnQsIGlzUHJpemVkIH07XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYXVjdGlvbiBzdGF0czpcIiwgZXJyb3IpO1xyXG4gICAgICByZXR1cm4geyBjb3VudDogMCwgaXNQcml6ZWQ6IGZhbHNlIH07XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3JvdXBDaGFuZ2UgPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRHcm91cElkKGdyb3VwSWQpO1xyXG5cclxuICAgIGNvbnN0IHNlbGVjdGVkR3JvdXAgPSBjcmVhdGVHcm91cHMuZmluZCgoZykgPT4gZy5pZCA9PT0gZ3JvdXBJZCk7XHJcbiAgICBpZiAoIXNlbGVjdGVkR3JvdXApIHJldHVybjtcclxuXHJcbiAgICBzZXRHcm91cFRpY2tldHMoc2VsZWN0ZWRHcm91cC50aWNrZXRzKTtcclxuXHJcbiAgICBjcmVhdGVGb3JtLnNldEZpZWxkc1ZhbHVlKHtcclxuICAgICAgdGlja2V0SW5kZXg6IHVuZGVmaW5lZCxcclxuICAgICAgZ3JvdXBOYW1lOiBzZWxlY3RlZEdyb3VwLmdyb3VwTmFtZSxcclxuICAgICAgc3RhcnREYXRlOiBzZWxlY3RlZEdyb3VwLnN0YXJ0RGF0ZSxcclxuICAgICAgZW5kRGF0ZTogc2VsZWN0ZWRHcm91cC5lbmREYXRlLFxyXG4gICAgICBhdWN0aW9uc0RvbmU6IHNlbGVjdGVkR3JvdXAuYXVjdGlvbnNEb25lLFxyXG4gICAgICBhZ2VudE5hbWU6IHNlbGVjdGVkR3JvdXAuYWdlbnROYW1lLFxyXG4gICAgICByZWZlcnJlZFR5cGU6IHNlbGVjdGVkR3JvdXAucmVmZXJyZWRUeXBlLFxyXG4gICAgICByZWZlcnJlZEJ5OiBzZWxlY3RlZEdyb3VwLnJlZmVycmVkQnksXHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyBSZXNldCBjdXN0b21lciBvdmVydmlldyB3aGVuIGdyb3VwIGNoYW5nZXNcclxuICAgIHNldEN1c3RvbWVyT3ZlcnZpZXcobnVsbCk7XHJcbiAgICBzZXRBdWN0aW9uSW5mbyh7XHJcbiAgICAgIG5leHREYXRlOiBudWxsLFxyXG4gICAgICBsYXN0RGF0ZTogbnVsbCxcclxuICAgICAgdG90YWxBdWN0aW9uczogMCxcclxuICAgICAgbmV4dEF1Y3Rpb25UeXBlOiBudWxsLFxyXG4gICAgICB0b3RhbFBheWFibGU6IDAsXHJcbiAgICAgIHRvdGFsUHJvZml0OiAwLFxyXG4gICAgICB0b3RhbEludmVzdG1lbnQ6IDAsXHJcbiAgICAgIHRvdGFsQmFsYW5jZTogMCxcclxuICAgICAgdG90YWxQZW5hbHR5OiAwLFxyXG4gICAgICB0b3RhbExhdGVGZWU6IDAsXHJcbiAgICAgIGlzUHJpemVkOiBmYWxzZSxcclxuICAgIH0pO1xyXG4gICAgc2V0TmV4dEF1Y3Rpb25EYXRlKG51bGwpO1xyXG4gICAgY3JlYXRlRm9ybS5zZXRGaWVsZHNWYWx1ZSh7XHJcbiAgICAgIGF1Y3Rpb25EYXRlOiBudWxsLFxyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgLy8g4pyFIEZJWEVEOiBIYW5kbGUgdGlja2V0IGNoYW5nZSB3aXRoIGN1c3RvbWVyIG92ZXJ2aWV3IGZldGNoXHJcbiAgY29uc3QgaGFuZGxlVGlja2V0Q2hhbmdlID0gYXN5bmMgKGluZGV4KSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZFRpY2tldEluZGV4KGluZGV4KTtcclxuXHJcbiAgICBjb25zdCB0aWNrZXQgPSBncm91cFRpY2tldHNbaW5kZXhdO1xyXG4gICAgaWYgKCF0aWNrZXQpIHJldHVybjtcclxuXHJcbiAgICBzZXRTZWxlY3RlZEVucm9sbG1lbnRJZCh0aWNrZXQuZW5yb2xsbWVudElkKTtcclxuXHJcbiAgICBjcmVhdGVGb3JtLnNldEZpZWxkc1ZhbHVlKHtcclxuICAgICAgdGlja2V0TnVtYmVyOiB0aWNrZXQudGlja2V0TnVtYmVyLFxyXG4gICAgfSk7XHJcblxyXG4gICAgLy8g4pyFIEZldGNoIGN1c3RvbWVyIG92ZXJ2aWV3IHdoZW4gdGlja2V0IGlzIHNlbGVjdGVkXHJcbiAgICBjb25zdCB1c2VySWQgPSBjcmVhdGVGb3JtLmdldEZpZWxkVmFsdWUoXCJzdWJzY3JpYmVySWRcIik7XHJcbiAgICBpZiAodXNlcklkICYmIHNlbGVjdGVkR3JvdXBJZCAmJiB0aWNrZXQudGlja2V0TnVtYmVyKSB7XHJcbiAgICAgIGF3YWl0IGZldGNoQ3VzdG9tZXJPdmVydmlldyh1c2VySWQsIHNlbGVjdGVkR3JvdXBJZCwgdGlja2V0LnRpY2tldE51bWJlcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hDcmVhdGVDdXN0b21lckRldGFpbHMgPSBhc3luYyAodXNlcklkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEFQSS5wb3N0KFxyXG4gICAgICAgIGAvZW5yb2xsL2dldC11c2VyLXRpY2tldHMtcmVwb3J0LyR7dXNlcklkfWAsXHJcbiAgICAgICk7XHJcbiAgICAgIGNvbnN0IGRhdGFMaXN0ID0gcmVzcG9uc2UuZGF0YSB8fCByZXNwb25zZS5kYXRhPy5kYXRhIHx8IFtdO1xyXG5cclxuICAgICAgaWYgKGRhdGFMaXN0ICYmIGRhdGFMaXN0Lmxlbmd0aCA+IDApIHtcclxuICAgICAgICBjb25zdCBncm91cGVkRGF0YSA9IHt9O1xyXG5cclxuICAgICAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgZGF0YUxpc3QpIHtcclxuICAgICAgICAgIGNvbnN0IGVucm9sbG1lbnQgPSBpdGVtPy5lbnJvbGxtZW50O1xyXG4gICAgICAgICAgY29uc3QgZ3JvdXBEYXRhID0gZW5yb2xsbWVudD8uZ3JvdXA7XHJcblxyXG4gICAgICAgICAgaWYgKCFncm91cERhdGE/Ll9pZCkgY29udGludWU7XHJcblxyXG4gICAgICAgICAgY29uc3QgdGlja2V0TnVtYmVyID0gZW5yb2xsbWVudD8udGlja2V0cyB8fCBlbnJvbGxtZW50Py50aWNrZXRfbnVtYmVyIHx8IFwiTi9BXCI7XHJcblxyXG4gICAgICAgICAgY29uc3QgYXVjdGlvbkluZm8gPSBhd2FpdCBmZXRjaEF1Y3Rpb25JbmZvKFxyXG4gICAgICAgICAgICBncm91cERhdGE/Ll9pZCxcclxuICAgICAgICAgICAgdXNlcklkLFxyXG4gICAgICAgICAgICB0aWNrZXROdW1iZXIsXHJcbiAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgIGxldCByZWZlcnJlZFR5cGUgPSBcIk4vQVwiO1xyXG4gICAgICAgICAgbGV0IHJlZmVycmVkQnkgPSBcIk4vQVwiO1xyXG4gICAgICAgICAgbGV0IGFnZW50TmFtZSA9IFwiTi9BXCI7XHJcblxyXG4gICAgICAgICAgaWYgKGVucm9sbG1lbnQ/LmFnZW50Py5uYW1lKSB7XHJcbiAgICAgICAgICAgIHJlZmVycmVkVHlwZSA9IFwiQWdlbnRcIjtcclxuICAgICAgICAgICAgYWdlbnROYW1lID0gZW5yb2xsbWVudC5hZ2VudC5uYW1lO1xyXG4gICAgICAgICAgICByZWZlcnJlZEJ5ID0gYCR7ZW5yb2xsbWVudC5hZ2VudC5uYW1lfSB8ICR7ZW5yb2xsbWVudC5hZ2VudC5waG9uZV9udW1iZXJ9YDtcclxuICAgICAgICAgIH0gZWxzZSBpZiAoZ3JvdXBEYXRhPy5hZ2VudD8ubmFtZSkge1xyXG4gICAgICAgICAgICByZWZlcnJlZFR5cGUgPSBcIkFnZW50XCI7XHJcbiAgICAgICAgICAgIGFnZW50TmFtZSA9IGdyb3VwRGF0YS5hZ2VudC5uYW1lO1xyXG4gICAgICAgICAgICByZWZlcnJlZEJ5ID0gYCR7Z3JvdXBEYXRhLmFnZW50Lm5hbWV9IHwgJHtncm91cERhdGEuYWdlbnQucGhvbmVfbnVtYmVyfWA7XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgaWYgKCFncm91cGVkRGF0YVtncm91cERhdGEuX2lkXSkge1xyXG4gICAgICAgICAgICBncm91cGVkRGF0YVtncm91cERhdGEuX2lkXSA9IHtcclxuICAgICAgICAgICAgICBpZDogZ3JvdXBEYXRhLl9pZCxcclxuICAgICAgICAgICAgICBncm91cE5hbWU6IGdyb3VwRGF0YS5ncm91cF9uYW1lLFxyXG4gICAgICAgICAgICAgIHN0YXJ0RGF0ZTogZ3JvdXBEYXRhPy5zdGFydF9kYXRlXHJcbiAgICAgICAgICAgICAgICA/IGdyb3VwRGF0YS5zdGFydF9kYXRlLnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgICAgICAgICAgOiBcIk4vQVwiLFxyXG4gICAgICAgICAgICAgIGVuZERhdGU6IGdyb3VwRGF0YT8uZW5kX2RhdGVcclxuICAgICAgICAgICAgICAgID8gZ3JvdXBEYXRhLmVuZF9kYXRlLnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgICAgICAgICAgOiBcIk4vQVwiLFxyXG4gICAgICAgICAgICAgIGF1Y3Rpb25zRG9uZTogYXVjdGlvbkluZm8uY291bnQsXHJcbiAgICAgICAgICAgICAgYWdlbnROYW1lLFxyXG4gICAgICAgICAgICAgIHJlZmVycmVkVHlwZSxcclxuICAgICAgICAgICAgICByZWZlcnJlZEJ5LFxyXG4gICAgICAgICAgICAgIHRpY2tldHM6IFtdLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIGdyb3VwZWREYXRhW2dyb3VwRGF0YS5faWRdLnRpY2tldHMucHVzaCh7XHJcbiAgICAgICAgICAgIHRpY2tldE51bWJlcixcclxuICAgICAgICAgICAgZW5yb2xsbWVudElkOiBlbnJvbGxtZW50Py5faWQsXHJcbiAgICAgICAgICAgIGlzUHJpemVkOiBhdWN0aW9uSW5mby5pc1ByaXplZCxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgZmluYWxHcm91cHMgPSBPYmplY3QudmFsdWVzKGdyb3VwZWREYXRhKTtcclxuICAgICAgICBzZXRDcmVhdGVHcm91cHMoZmluYWxHcm91cHMpO1xyXG5cclxuICAgICAgICBpZiAoZmluYWxHcm91cHMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgY29uc3QgZmlyc3RHcm91cCA9IGZpbmFsR3JvdXBzWzBdO1xyXG4gICAgICAgICAgc2V0U2VsZWN0ZWRHcm91cElkKGZpcnN0R3JvdXAuaWQpO1xyXG4gICAgICAgICAgc2V0R3JvdXBUaWNrZXRzKGZpcnN0R3JvdXAudGlja2V0cyk7XHJcblxyXG4gICAgICAgICAgY3JlYXRlRm9ybS5zZXRGaWVsZHNWYWx1ZSh7XHJcbiAgICAgICAgICAgIHNlbGVjdGVkR3JvdXBJZDogZmlyc3RHcm91cC5pZCxcclxuICAgICAgICAgICAgZ3JvdXBOYW1lOiBmaXJzdEdyb3VwLmdyb3VwTmFtZSxcclxuICAgICAgICAgICAgc3RhcnREYXRlOiBmaXJzdEdyb3VwLnN0YXJ0RGF0ZSxcclxuICAgICAgICAgICAgZW5kRGF0ZTogZmlyc3RHcm91cC5lbmREYXRlLFxyXG4gICAgICAgICAgICBhdWN0aW9uc0RvbmU6IGZpcnN0R3JvdXAuYXVjdGlvbnNEb25lLFxyXG4gICAgICAgICAgICBhZ2VudE5hbWU6IGZpcnN0R3JvdXAuYWdlbnROYW1lLFxyXG4gICAgICAgICAgICByZWZlcnJlZFR5cGU6IGZpcnN0R3JvdXAucmVmZXJyZWRUeXBlLFxyXG4gICAgICAgICAgICByZWZlcnJlZEJ5OiBmaXJzdEdyb3VwLnJlZmVycmVkQnksXHJcbiAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAvLyDinIUgQXV0by1zZWxlY3QgZmlyc3QgdGlja2V0IGFuZCBmZXRjaCBvdmVydmlld1xyXG4gICAgICAgICAgaWYgKGZpcnN0R3JvdXAudGlja2V0cy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGZpcnN0VGlja2V0ID0gZmlyc3RHcm91cC50aWNrZXRzWzBdO1xyXG4gICAgICAgICAgICBpZiAoIWZpcnN0VGlja2V0LmlzUHJpemVkKSB7XHJcbiAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRUaWNrZXRJbmRleCgwKTtcclxuICAgICAgICAgICAgICBjcmVhdGVGb3JtLnNldEZpZWxkc1ZhbHVlKHtcclxuICAgICAgICAgICAgICAgIHRpY2tldE51bWJlcjogZmlyc3RUaWNrZXQudGlja2V0TnVtYmVyLFxyXG4gICAgICAgICAgICAgICAgdGlja2V0SW5kZXg6IDAsXHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRFbnJvbGxtZW50SWQoZmlyc3RUaWNrZXQuZW5yb2xsbWVudElkKTtcclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAvLyDinIUgRmV0Y2ggY3VzdG9tZXIgb3ZlcnZpZXcgZm9yIGZpcnN0IHRpY2tldFxyXG4gICAgICAgICAgICAgIGF3YWl0IGZldGNoQ3VzdG9tZXJPdmVydmlldyhcclxuICAgICAgICAgICAgICAgIHVzZXJJZCxcclxuICAgICAgICAgICAgICAgIGZpcnN0R3JvdXAuaWQsXHJcbiAgICAgICAgICAgICAgICBmaXJzdFRpY2tldC50aWNrZXROdW1iZXJcclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgIC8vIEZpcnN0IHRpY2tldCBpcyBwcml6ZWQsIHNob3cgd2FybmluZ1xyXG4gICAgICAgICAgICAgIGFwaS53YXJuaW5nKHtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiVGlja2V0IEFscmVhZHkgUHJpemVkXCIsXHJcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJUaGUgZmlyc3QgYXZhaWxhYmxlIHRpY2tldCBpcyBhbHJlYWR5IHByaXplZC4gUGxlYXNlIHNlbGVjdCBhbm90aGVyIHRpY2tldC5cIixcclxuICAgICAgICAgICAgICAgIGR1cmF0aW9uOiA0LFxyXG4gICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGFwaS53YXJuaW5nKHtcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiTm8gVGlja2V0cyBGb3VuZFwiLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IFwiVGhpcyBjdXN0b21lciBpcyBub3QgZW5yb2xsZWQgaW4gYW55IGFjdGl2ZSBncm91cHMuXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2V0Q3JlYXRlR3JvdXBzKFtdKTtcclxuICAgICAgICBzZXRTZWxlY3RlZEVucm9sbG1lbnRJZChudWxsKTtcclxuICAgICAgICBjcmVhdGVGb3JtLnNldEZpZWxkc1ZhbHVlKHtcclxuICAgICAgICAgIGFnZW50TmFtZTogXCJOL0FcIixcclxuICAgICAgICAgIHJlZmVycmVkVHlwZTogXCJOL0FcIixcclxuICAgICAgICAgIHJlZmVycmVkQnk6IFwiTi9BXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBjdXN0b21lciBkZXRhaWxzOlwiLCBlcnJvcik7XHJcbiAgICAgIGFwaS5lcnJvcih7XHJcbiAgICAgICAgbWVzc2FnZTogXCJFcnJvciBGZXRjaGluZyBEZXRhaWxzXCIsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IFwiQ291bGQgbm90IGxvYWQgY3VzdG9tZXIgdGlja2V0cy4gUGxlYXNlIHRyeSBhZ2Fpbi5cIixcclxuICAgICAgfSk7XHJcbiAgICAgIHNldENyZWF0ZUdyb3VwcyhbXSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRW5yb2xsbWVudElkKG51bGwpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNyZWF0ZUN1c3RvbWVyU2VsZWN0ID0gKHVzZXJJZCkgPT4ge1xyXG4gICAgY29uc3Qgc2VsZWN0ZWRVc2VyID0gdXNlcnMuZmluZCgodSkgPT4gdS5faWQgPT09IHVzZXJJZCk7XHJcbiAgICBpZiAoc2VsZWN0ZWRVc2VyKSB7XHJcbiAgICAgIGNvbnN0IGNOYW1lID0gc2VsZWN0ZWRVc2VyLmZ1bGxfbmFtZSB8fCBzZWxlY3RlZFVzZXIubmFtZTtcclxuICAgICAgY29uc3QgY1Bob25lID0gc2VsZWN0ZWRVc2VyLnBob25lX251bWJlciB8fCBzZWxlY3RlZFVzZXIubW9iaWxlO1xyXG4gICAgICBjcmVhdGVGb3JtLnNldEZpZWxkc1ZhbHVlKHtcclxuICAgICAgICBzdWJzY3JpYmVyTmFtZTogY05hbWUsXHJcbiAgICAgICAgbW9iaWxlTnVtYmVyOiBjUGhvbmUsXHJcbiAgICAgICAgc3Vic2NyaWJlcklkOiB1c2VySWQsXHJcbiAgICAgICAgZ3JvdXBOYW1lOiBcIkxvYWRpbmcuLi5cIixcclxuICAgICAgICB0aWNrZXROdW1iZXI6IFwiTG9hZGluZy4uLlwiLFxyXG4gICAgICAgIGFnZW50TmFtZTogXCJMb2FkaW5nLi4uXCIsXHJcbiAgICAgICAgcmVmZXJyZWRUeXBlOiBcIkxvYWRpbmcuLi5cIixcclxuICAgICAgICByZWZlcnJlZEJ5OiBcIkxvYWRpbmcuLi5cIixcclxuICAgICAgfSk7XHJcbiAgICAgIHNldENyZWF0ZUdyb3VwcyhbXSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRW5yb2xsbWVudElkKG51bGwpO1xyXG4gICAgICBzZXRDdXN0b21lck92ZXJ2aWV3KG51bGwpO1xyXG4gICAgICBzZXRBdWN0aW9uSW5mbyh7XHJcbiAgICAgICAgbmV4dERhdGU6IG51bGwsXHJcbiAgICAgICAgbGFzdERhdGU6IG51bGwsXHJcbiAgICAgICAgdG90YWxBdWN0aW9uczogMCxcclxuICAgICAgICBuZXh0QXVjdGlvblR5cGU6IG51bGwsXHJcbiAgICAgICAgdG90YWxQYXlhYmxlOiAwLFxyXG4gICAgICAgIHRvdGFsUHJvZml0OiAwLFxyXG4gICAgICAgIHRvdGFsSW52ZXN0bWVudDogMCxcclxuICAgICAgICB0b3RhbEJhbGFuY2U6IDAsXHJcbiAgICAgICAgdG90YWxQZW5hbHR5OiAwLFxyXG4gICAgICAgIHRvdGFsTGF0ZUZlZTogMCxcclxuICAgICAgICBpc1ByaXplZDogZmFsc2UsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXROZXh0QXVjdGlvbkRhdGUobnVsbCk7XHJcbiAgICAgIGNyZWF0ZUZvcm0uc2V0RmllbGRzVmFsdWUoe1xyXG4gICAgICAgIGF1Y3Rpb25EYXRlOiBudWxsLFxyXG4gICAgICB9KTtcclxuICAgICAgZmV0Y2hDcmVhdGVDdXN0b21lckRldGFpbHModXNlcklkKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDcmVhdGVGaW5pc2ggPSBhc3luYyAodmFsdWVzKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgICBcclxuICAgICAgY29uc3Qgc2VsZWN0ZWRHcm91cCA9IGNyZWF0ZUdyb3Vwcy5maW5kKFxyXG4gICAgICAgIChnKSA9PiBnLmlkID09PSB2YWx1ZXMuc2VsZWN0ZWRHcm91cElkXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBjb25zdCBzZWxlY3RlZFRpY2tldCA9IGdyb3VwVGlja2V0c1t2YWx1ZXMudGlja2V0SW5kZXhdO1xyXG5cclxuICAgICAgaWYgKCFzZWxlY3RlZEdyb3VwKSB7XHJcbiAgICAgICAgYXBpLmVycm9yKHtcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiRXJyb3JcIixcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlBsZWFzZSBzZWxlY3QgYSBncm91cCBmaXJzdC5cIixcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIOKchSBDaGVjayBpZiB0aWNrZXQgaXMgcHJpemVkIGJlZm9yZSBzdWJtaXR0aW5nXHJcbiAgICAgIGlmIChjdXN0b21lck92ZXJ2aWV3Py5pc19wcml6ZWQgPT09IHRydWUgfHwgc2VsZWN0ZWRUaWNrZXQ/LmlzUHJpemVkKSB7XHJcbiAgICAgICAgYXBpLmVycm9yKHtcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiUmVxdWVzdCBEZW5pZWRcIixcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlRoaXMgdGlja2V0IGlzIGFscmVhZHkgcHJpemVkLiBCaWQgcmVxdWVzdCBjYW5ub3QgYmUgcmFpc2VkLlwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgZm9ybWF0dGVkVGltZSA9IHZhbHVlcy5hdWN0aW9uVGltZVxyXG4gICAgICAgID8gdmFsdWVzLmF1Y3Rpb25UaW1lLmZvcm1hdChcIkhIOm1tXCIpXHJcbiAgICAgICAgOiBudWxsO1xyXG5cclxuICAgICAgLy8g4pyFIFVzZSB0aGUgYXVjdGlvbiBkYXRlIGZyb20gY3VzdG9tZXIgb3ZlcnZpZXcgb3IgZm9ybVxyXG4gICAgICBjb25zdCBhdWN0aW9uRGF0ZVRvU2VuZCA9IHZhbHVlcy5hdWN0aW9uRGF0ZSBcclxuICAgICAgICA/IHZhbHVlcy5hdWN0aW9uRGF0ZS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpXHJcbiAgICAgICAgOiBuZXh0QXVjdGlvbkRhdGUgXHJcbiAgICAgICAgPyBuZXh0QXVjdGlvbkRhdGUuZm9ybWF0KFwiWVlZWS1NTS1ERFwiKVxyXG4gICAgICAgIDogbnVsbDtcclxuXHJcbiAgICAgIGNvbnNvbGUubG9nKFwiU2VuZGluZyBhdWN0aW9uIGRhdGU6XCIsIGF1Y3Rpb25EYXRlVG9TZW5kKTsgXHJcblxyXG4gICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgIGRhdGU6IHZhbHVlcy5kYXRlXHJcbiAgICAgICAgICA/IHZhbHVlcy5kYXRlLmZvcm1hdChcIllZWVktTU0tRERcIilcclxuICAgICAgICAgIDogZGF5anMoKS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpLFxyXG4gICAgICAgIHN1YnNjcmliZXJJZDogdmFsdWVzLnN1YnNjcmliZXJJZCxcclxuICAgICAgICBzdWJzY3JpYmVyTmFtZTogdmFsdWVzLnN1YnNjcmliZXJOYW1lLFxyXG4gICAgICAgIG1vYmlsZU51bWJlcjogdmFsdWVzLm1vYmlsZU51bWJlcixcclxuICAgICAgICBncm91cE5hbWU6IHNlbGVjdGVkR3JvdXAuZ3JvdXBOYW1lLFxyXG4gICAgICAgIHRpY2tldE51bWJlcjogc2VsZWN0ZWRUaWNrZXQudGlja2V0TnVtYmVyLFxyXG4gICAgICAgIGF1Y3Rpb25EYXRlOiBhdWN0aW9uRGF0ZVRvU2VuZCxcclxuICAgICAgICBhdWN0aW9uX3RpbWU6IGZvcm1hdHRlZFRpbWUsXHJcbiAgICAgICAgYWdlbnROYW1lOiBzZWxlY3RlZEdyb3VwLmFnZW50TmFtZSxcclxuICAgICAgICByZWZlcnJlZFR5cGU6IHNlbGVjdGVkR3JvdXAucmVmZXJyZWRUeXBlLFxyXG4gICAgICAgIHJlZmVycmVkQnk6IHNlbGVjdGVkR3JvdXAucmVmZXJyZWRCeSxcclxuICAgICAgICBncm91cElkOiBzZWxlY3RlZEdyb3VwLmlkLFxyXG4gICAgICAgIGFkbWluVXNlcklkOiB2YWx1ZXMuYWRtaW5Vc2VySWQgfHwgYWRtaW5JZCxcclxuICAgICAgICBhZG1pbk5hbWU6IHZhbHVlcy5hZG1pbk5hbWUgfHwgYWRtaW5OYW1lLFxyXG4gICAgICAgIGFkbWluUGhvbmU6IHZhbHVlcy5hZG1pblBob25lIHx8IGFkbWluUGhvbmUsXHJcbiAgICAgICAgZW5yb2xsbWVudElkOiBzZWxlY3RlZFRpY2tldC5lbnJvbGxtZW50SWQsXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEFQSS5wb3N0KFwiL2JpZC1yZXF1ZXN0L2NyZWF0ZVwiLCBwYXlsb2FkKTtcclxuICAgICAgXHJcbiAgICAgIGFwaS5zdWNjZXNzKHtcclxuICAgICAgICBtZXNzYWdlOiBcIlN1Y2Nlc3NcIixcclxuICAgICAgICBkZXNjcmlwdGlvbjogXCJCaWQgUmVxdWVzdCBzdWJtaXR0ZWQgc3VjY2Vzc2Z1bGx5IVwiLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gd2luZG93LmNsb3NlKCksIDE1MDApO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yOlwiLCBlcnJvcik7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciByZXNwb25zZTpcIiwgZXJyb3IucmVzcG9uc2UpO1xyXG4gICAgICBhcGkuZXJyb3Ioe1xyXG4gICAgICAgIG1lc3NhZ2U6IFwiRXJyb3JcIixcclxuICAgICAgICBkZXNjcmlwdGlvbjogZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gc2F2ZSByZXF1ZXN0LlwiLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaFVzZXJzKCk7XHJcbiAgICBmZXRjaEFkbWluUHJvZmlsZSgpO1xyXG4gICAgY3JlYXRlRm9ybS5zZXRGaWVsZHNWYWx1ZSh7IGRhdGU6IGRheWpzKCkgfSk7XHJcbiAgfSwgW10pO1xyXG5cclxuICAvLyDinIUgRW5oYW5jZWQgc3VibWl0IGRpc2FibGVkIGxvZ2ljXHJcbiAgY29uc3QgaXNTdWJtaXREaXNhYmxlZCA9XHJcbiAgICBjcmVhdGVHcm91cHMubGVuZ3RoID09PSAwIHx8XHJcbiAgICAhc2VsZWN0ZWRHcm91cElkIHx8XHJcbiAgICAhZ3JvdXBUaWNrZXRzLmxlbmd0aCB8fFxyXG4gICAgIW5leHRBdWN0aW9uRGF0ZSB8fFxyXG4gICAgY3VzdG9tZXJPdmVydmlldz8uaXNfcHJpemVkID09PSB0cnVlIHx8XHJcbiAgICBzZWxlY3RlZFRpY2tldEluZGV4ID09PSBudWxsIHx8XHJcbiAgICBncm91cFRpY2tldHNbc2VsZWN0ZWRUaWNrZXRJbmRleF0/LmlzUHJpemVkID09PSB0cnVlO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctZ3JheS0xMDAgcC02IGZsZXgganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAge2NvbnRleHRIb2xkZXJ9XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LTR4bCBiZy13aGl0ZSBzaGFkb3ctbGcgZm9udC1zYW5zIHRleHQtc20gdGV4dC1ncmF5LTgwMCByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYi0yIGJvcmRlci1ibHVlLTkwMCBwLTYgbWItNiBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ibHVlLTkwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgTmV3IEJpZCBSZXF1ZXN0XHJcbiAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB3aW5kb3cuY2xvc2UoKX0+Q2xvc2UgVGFiPC9CdXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtOCBwYi04XCI+XHJcbiAgICAgICAgICA8Rm9ybVxyXG4gICAgICAgICAgICBmb3JtPXtjcmVhdGVGb3JtfVxyXG4gICAgICAgICAgICBsYXlvdXQ9XCJ2ZXJ0aWNhbFwiXHJcbiAgICAgICAgICAgIG9uRmluaXNoPXtoYW5kbGVDcmVhdGVGaW5pc2h9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ibHVlLTkwMCBtYi00IGJvcmRlci1iIHBiLTIgdGV4dC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgU3Vic2NyaWJlciBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi01XCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgQWRtaW4gTmFtZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgbmFtZT1cImFkbWluTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJBZG1pbiBuYW1lIGlzIHJlcXVpcmVkIVwiIH0sXHJcbiAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTBcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkF1dG8tZmV0Y2hlZCBmcm9tIHByb2ZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTYwMCBjdXJzb3Itbm90LWFsbG93ZWQgcm91bmRlZC1tZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcHJlZml4PXs8VXNlck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIiAvPn1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgPEZvcm0uSXRlbSBuYW1lPVwiYWRtaW5JZFwiIGhpZGRlbj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0IC8+XHJcbiAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbmFtZT1cImFkbWluUGhvbmVcIiBoaWRkZW4+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dCAvPlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJhZG1pbkVtYWlsXCIgaGlkZGVuPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXQgLz5cclxuICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTVcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICBTZWFyY2ggQ3VzdG9tZXIgKE5hbWUvUGhvbmUpe1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInN1YnNjcmliZXJJZFwiXHJcbiAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJQbGVhc2Ugc2VsZWN0IGEgY3VzdG9tZXIhXCIgfSxcclxuICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJUeXBlIG5hbWUgb3IgcGhvbmUgbnVtYmVyLi4uXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ3JlYXRlQ3VzdG9tZXJTZWxlY3R9XHJcbiAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZ1VzZXJzfVxyXG4gICAgICAgICAgICAgICAgICAgIG5vdEZvdW5kQ29udGVudD17XHJcbiAgICAgICAgICAgICAgICAgICAgICBsb2FkaW5nVXNlcnMgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTcGluIHNpemU9XCJzbWFsbFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcIk5vIGN1c3RvbWVycyBmb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAob3B0aW9uPy5sYWJlbCA/PyBcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17dXNlcnMubWFwKCh1c2VyKSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IHVzZXIuX2lkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IGAke3VzZXIuZnVsbF9uYW1lIHx8IHVzZXIubmFtZSB8fCBcIlVua25vd25cIn0gLSAke3VzZXIucGhvbmVfbnVtYmVyIHx8IHVzZXIubW9iaWxlIHx8IFwiTm8gUGhvbmVcIn1gLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pKX1cclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNiBiZy1ncmF5LTUwIHAtNCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDAgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgU3Vic2NyaWJlciBOYW1lXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwic3Vic2NyaWJlck5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJSZXF1aXJlZCFcIiB9XX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi0wXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dCByZWFkT25seSBjbGFzc05hbWU9XCJiZy1ncmF5LTEwMCBib3JkZXItZ3JheS0zMDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgTW9iaWxlIE51bWJlclxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm1vYmlsZU51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIlJlcXVpcmVkIVwiIH1dfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0IHJlYWRPbmx5IGNsYXNzTmFtZT1cImJnLWdyYXktMTAwIGJvcmRlci1ncmF5LTMwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHtjcmVhdGVHcm91cHMubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICB7LyogR1JPVVAgU0VMRUNUICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIHRleHQtbGcgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgR3JvdXAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJzZWxlY3RlZEdyb3VwSWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBydWxlcz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiUGxlYXNlIHNlbGVjdCBncm91cCFcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi0wXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgR3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVHcm91cENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtjcmVhdGVHcm91cHMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiBrZXk9e2dyb3VwLmlkfSB2YWx1ZT17Z3JvdXAuaWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBOYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBUSUNLRVQgU0VMRUNUICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIHRleHQtbGcgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgVGlja2V0IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwidGlja2V0SW5kZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBydWxlcz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiUGxlYXNlIHNlbGVjdCB0aWNrZXQhXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFRpY2tldFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVRpY2tldENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cFRpY2tldHMubWFwKCh0aWNrZXQsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8T3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpbmRleH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3RpY2tldC5pc1ByaXplZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGlja2V0ICN7dGlja2V0LnRpY2tldE51bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RpY2tldC5pc1ByaXplZCA/IFwiIChBbHJlYWR5IFByaXplZClcIiA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L09wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTQgbWItNiBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBdWN0aW9uIFN0YXJ0IERhdGVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJzdGFydERhdGVcIiBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYmx1ZS01MCBib3JkZXItYmx1ZS0yMDAgdGV4dC1ibHVlLTkwMCBmb250LXNlbWlib2xkIGgtMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBdWN0aW9uIEVuZCBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbSBuYW1lPVwiZW5kRGF0ZVwiIGNsYXNzTmFtZT1cIm1iLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ibHVlLTUwIGJvcmRlci1ibHVlLTIwMCB0ZXh0LWJsdWUtOTAwIGZvbnQtc2VtaWJvbGQgaC0xMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEF1Y3Rpb25zIERvbmVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJhdWN0aW9uc0RvbmVcIiBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JlZW4tNTAgYm9yZGVyLWdyZWVuLTIwMCB0ZXh0LWdyZWVuLTkwMCBmb250LWJvbGQgdGV4dC1jZW50ZXIgaC0xMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRFbnJvbGxtZW50SWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTIgcC0yIGJnLWdyYXktNTAgcm91bmRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRW5yb2xsbWVudCBJRDoge3NlbGVjdGVkRW5yb2xsbWVudElkfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00IG10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFByaW1hcnkgR3JvdXAgTmFtZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJncm91cE5hbWVcIiBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYmx1ZS01MCBib3JkZXItYmx1ZS0zMDAgZm9udC1zZW1pYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFByaW1hcnkgVGlja2V0IE51bWJlclxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJ0aWNrZXROdW1iZXJcIiBjbGFzc05hbWU9XCJtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYmx1ZS01MCBib3JkZXItYmx1ZS0zMDAgZm9udC1zZW1pYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLThcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtYmx1ZS05MDAgbWItNCBib3JkZXItYiBwYi0yIHRleHQtbGdcIj5cclxuICAgICAgICAgICAgICAgIEF1Y3Rpb24gRGV0YWlsc1xyXG4gICAgICAgICAgICAgIDwvaDM+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiDinIUgRGlzcGxheSBOZXh0IEF1Y3Rpb24gRGF0ZSBJbmZvcm1hdGlvbiAqL31cclxuICAgICAgICAgICAgICB7bG9hZGluZ092ZXJ2aWV3ICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBwLTMgYmctYmx1ZS01MCBib3JkZXIgYm9yZGVyLWJsdWUtMjAwIHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTcGluIHNpemU9XCJzbWFsbFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgTG9hZGluZyBjdXN0b21lciBhdWN0aW9uIGRldGFpbHMuLi5cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgey8qIOKchSBTaG93IEFscmVhZHkgUHJpemVkIEFsZXJ0ICovfVxyXG4gICAgICAgICAgICAgIHshbG9hZGluZ092ZXJ2aWV3ICYmIGN1c3RvbWVyT3ZlcnZpZXc/LmlzX3ByaXplZCA9PT0gdHJ1ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8QWxlcnRcclxuICAgICAgICAgICAgICAgICAgbWVzc2FnZT1cIlRpY2tldCBBbHJlYWR5IFByaXplZFwiXHJcbiAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uPVwiVGhpcyB0aWNrZXQgaGFzIGFscmVhZHkgYmVlbiBwcml6ZWQgaW4gYW4gYXVjdGlvbi4gWW91IGNhbm5vdCByYWlzZSBhIGJpZCByZXF1ZXN0IGZvciB0aGlzIHRpY2tldC5cIlxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZXJyb3JcIlxyXG4gICAgICAgICAgICAgICAgICBzaG93SWNvblxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi00XCJcclxuICAgICAgICAgICAgICAgICAgaWNvbj17PENsb2NrQ2lyY2xlT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHshbG9hZGluZ092ZXJ2aWV3ICYmIGF1Y3Rpb25JbmZvLm5leHREYXRlICYmIGN1c3RvbWVyT3ZlcnZpZXc/LmlzX3ByaXplZCAhPT0gdHJ1ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgcC0zIGJnLWdyZWVuLTUwIGJvcmRlciBib3JkZXItZ3JlZW4tMjAwIHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDYWxlbmRhck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwIHRleHQtbGdcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5OZXh0IEF1Y3Rpb24gRGF0ZTo8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHthdWN0aW9uSW5mby5uZXh0RGF0ZS5mb3JtYXQoXCJERC1NTS1ZWVlZXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7YXVjdGlvbkluZm8ubmV4dEF1Y3Rpb25UeXBlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8VGFnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1Y3Rpb25JbmZvLm5leHRBdWN0aW9uVHlwZSA9PT0gXCJGcmVlIEF1Y3Rpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJnb2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC0yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YXVjdGlvbkluZm8ubmV4dEF1Y3Rpb25UeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvVGFnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHshbG9hZGluZ092ZXJ2aWV3ICYmICFhdWN0aW9uSW5mby5uZXh0RGF0ZSAmJiBjcmVhdGVHcm91cHMubGVuZ3RoID4gMCAmJiBjdXN0b21lck92ZXJ2aWV3Py5pc19wcml6ZWQgIT09IHRydWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgPEFsZXJ0XHJcbiAgICAgICAgICAgICAgICAgIG1lc3NhZ2U9XCJObyBVcGNvbWluZyBBdWN0aW9uIEZvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb249XCJUaGlzIGN1c3RvbWVyIGRvZXNuJ3QgaGF2ZSBhbnkgc2NoZWR1bGVkIGF1Y3Rpb24uIFBsZWFzZSBzZXQgdGhlIGF1Y3Rpb24gZGF0ZSBtYW51YWxseSBvciBjb25maWd1cmUgdGhlIGdyb3VwJ3MgYXVjdGlvbiBzY2hlZHVsZS5cIlxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwid2FybmluZ1wiXHJcbiAgICAgICAgICAgICAgICAgIHNob3dJY29uXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTRcIlxyXG4gICAgICAgICAgICAgICAgICBpY29uPXs8Q2xvY2tDaXJjbGVPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBBdWN0aW9uIERhdGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhdWN0aW9uRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcnVsZXM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIHNlbGVjdCBhdWN0aW9uIGRhdGUhXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8RGF0ZVBpY2tlclxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItZ3JheS00MDAgaC0xMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBBdWN0aW9uIERhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZm9ybWF0PVwiREQtTU0tWVlZWVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Y3VzdG9tZXJPdmVydmlldz8uaXNfcHJpemVkID09PSB0cnVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWREYXRlPXsoY3VycmVudCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gY3VycmVudCAmJiBjdXJyZW50IDwgZGF5anMoKS5zdGFydE9mKFwiZGF5XCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAge2F1Y3Rpb25JbmZvLm5leHREYXRlICYmIGN1c3RvbWVyT3ZlcnZpZXc/LmlzX3ByaXplZCAhPT0gdHJ1ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JlZW4tNjAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIE5leHQgYXVjdGlvbiBkYXRlIGF1dG8tbG9hZGVkIGZyb20gY3VzdG9tZXIgb3ZlcnZpZXdcclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAge2N1c3RvbWVyT3ZlcnZpZXc/LmlzX3ByaXplZCA9PT0gdHJ1ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtcmVkLTYwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBDYW5ub3Qgc2VsZWN0IGRhdGUgLSB0aWNrZXQgaXMgYWxyZWFkeSBwcml6ZWRcclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUmVxdWVzdCBUaW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYXVjdGlvblRpbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGluaXRpYWxWYWx1ZT17ZGF5anMoKX1cclxuICAgICAgICAgICAgICAgICAgICBydWxlcz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogXCJQbGVhc2Ugc2VsZWN0IGF1Y3Rpb24gdGltZSFcIixcclxuICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi0wXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxUaW1lUGlja2VyXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlci1ncmF5LTQwMCBoLTEwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZvcm1hdD1cImg6bW0gQVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB1c2UxMkhvdXJzXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBUaW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG1pbnV0ZVN0ZXA9ezE1fVxyXG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2N1c3RvbWVyT3ZlcnZpZXc/LmlzX3ByaXplZCA9PT0gdHJ1ZX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNCBwdC00IGJvcmRlci10XCI+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gd2luZG93LmNsb3NlKCl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgaC0xMiBmb250LXNlbWlib2xkIGJvcmRlci1ncmF5LTQwMCB0ZXh0LWxnXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICBodG1sVHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIGJnLWJsdWUtOTAwIGhvdmVyOmJnLWJsdWUtODAwIGgtMTIgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtbGdcIlxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU3VibWl0RGlzYWJsZWR9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge2N1c3RvbWVyT3ZlcnZpZXc/LmlzX3ByaXplZCA9PT0gdHJ1ZSA/IFwiQWxyZWFkeSBQcml6ZWRcIiA6IFwiU3VibWl0IFJlcXVlc3RcIn1cclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L0Zvcm0+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ3JlYXRlQmlkUmVxdWVzdDsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvQ3JlYXRlQmlkUmVxdWVzdC5qc3gifQ==