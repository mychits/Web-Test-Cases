import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PayOutSalary.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import API from "/src/instance/TokenInstance.js";
import Modal from "/src/components/modals/Modal.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Tooltip, notification, Dropdown, Input } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import SettingSidebar from "/src/components/layouts/SettingSidebar.jsx";
import SalarySlipPrint from "/src/components/printFormats/SalarySlipPrint.jsx";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import EditSalaryModal from "/src/components/modals/EditSalaryModal.jsx";
import { DollarOutlined, CalendarOutlined, EditOutlined, InfoCircleOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
const PayoutSalary = () => {
  _s();
  const paymentFor = "salary";
  const [api, contextHolder] = notification.useNotification();
  const [dateMode, setDateMode] = useState("month");
  const [showSalaryModal, setShowSalaryModal] = useState(false);
  const [modifyPayment, setModifyPayment] = useState(false);
  const [adminId, setAdminId] = useState("");
  const [absent, setAbsent] = useState(0);
  const [selectedMonth, setSelectedMonth] = useState("");
  const [existingOtherPayments, setIsExistingOtherPayments] = useState("");
  const [alreadyPaidSalaryAmount, setAlreadyPaidSalaryAmount] = useState("");
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    noReload: false,
    type: "info"
  });
  const [targetData, setTargetData] = useState({
    target: 0,
    achieved: 0,
    remaining: 0,
    difference: 0,
    incentiveAmount: "₹0.00",
    incentivePercent: "0%"
  });
  const [agents, setAgents] = useState([]);
  const [salaryPayments, setSalaryPayments] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [adminName, setAdminName] = useState("");
  const [errors, setErrors] = useState({});
  const [reRender, setReRender] = useState(0);
  const [salaryCalculationDetails, setSalaryCalculationDetails] = useState(null);
  const [manualPaidAmount, setManualPaidAmount] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [editingSalary, setEditingSalary] = useState(null);
  const [isSalaryAlreadyPaid, setIsSalaryAlreadyPaid] = useState(false);
  const [isCalculationForExistingPayment, setIsCalculationForExistingPayment] = useState(false);
  const today = /* @__PURE__ */ new Date();
  const currentMonth = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}`;
  const [salaryForm, setSalaryForm] = useState({
    agent_id: "",
    pay_date: today.toISOString().split("T")[0],
    from_date: "",
    to_date: "",
    amount: "",
    pay_type: "cash",
    transaction_id: "",
    note: "",
    pay_for: paymentFor,
    admin_type: ""
  });
  const [employeeDetails, setEmployeeDetails] = useState({
    joining_date: "",
    salary: ""
  });
  const [totalWithIncentive, setTotalWithIncentive] = useState("0.00");
  const [calculatedSalary, setCalculatedSalary] = useState("");
  const [alreadyPaid, setAlreadyPaid] = useState("0.00");
  const [remainingSalary, setRemainingSalary] = useState("0.00");
  const formatDate = (date) => {
    if (!date) return "";
    if (typeof date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return date;
    }
    const d = new Date(date);
    if (isNaN(d)) return "";
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };
  const [otherPaymentsList, setOtherPaymentsList] = useState([{ reason: "", amount: "" }]);
  const handleAddOtherPayment = () => {
    setOtherPaymentsList([...otherPaymentsList, { reason: "", amount: "" }]);
  };
  const handleOtherPaymentChange = (index, field, value) => {
    const updated = [...otherPaymentsList];
    updated[index][field] = value;
    setOtherPaymentsList(updated);
  };
  const handleRemoveOtherPayment = (index) => {
    setOtherPaymentsList(otherPaymentsList.filter((_, i) => i !== index));
  };
  useEffect(() => {
    setSelectedMonth(currentMonth);
  }, []);
  useEffect(() => {
    if (dateMode === "month" && selectedMonth) {
      const [year, month] = selectedMonth.split("-").map(Number);
      const fromDate = `${year}-${String(month).padStart(2, "0")}-01`;
      const lastDay = new Date(year, month, 0).getDate();
      const toDate = `${year}-${String(month).padStart(2, "0")}-${String(lastDay).padStart(2, "0")}`;
      setSalaryForm((prev) => ({
        ...prev,
        from_date: fromDate,
        to_date: toDate
      }));
    }
  }, [selectedMonth, dateMode]);
  const checkIfSalaryAlreadyPaid = async (empId, fromDate, toDate) => {
    try {
      const response = await API.get("/salary/get-salary-payments", {
        params: {
          empId,
          from_date: formatDate(fromDate),
          to_date: formatDate(toDate)
        }
      });
      const salaryArray = Array.isArray(response.data) ? response.data : response.data.data || [];
      const paidAmount = salaryArray.filter((p) => {
        const pAgentId = p.employee_id?._id ? String(p.employee_id._id) : String(p.employee_id);
        const paymentDate = new Date(formatDate(p.payout_metadata?.date_range?.from));
        return pAgentId === String(empId) && paymentDate >= new Date(formatDate(fromDate)) && paymentDate <= new Date(formatDate(toDate));
      }).reduce((sum, p) => sum + parseFloat(p.payout_metadata?.total_paid_amount || 0), 0);
      const otherPay = salaryArray.filter((p) => {
        const pAgentId = p.employee_id?._id ? String(p.employee_id._id) : String(p.employee_id);
        const paymentDate = new Date(formatDate(p.payout_metadata?.date_range?.from));
        return pAgentId === String(empId) && paymentDate >= new Date(formatDate(fromDate)) && paymentDate <= new Date(formatDate(toDate));
      }).reduce((sum, p) => sum + parseFloat(p.payout_metadata?.other_payments || 0), 0);
      const sPay = salaryArray.filter((p) => {
        const pAgentId = p.employee_id?._id ? String(p.employee_id._id) : String(p.employee_id);
        const paymentDate = new Date(formatDate(p.payout_metadata?.date_range?.from));
        return pAgentId === String(empId) && paymentDate >= new Date(formatDate(fromDate)) && paymentDate <= new Date(formatDate(toDate));
      }).reduce((sum, p) => sum + parseFloat(p.payout_metadata?.total_salary || 0), 0);
      const alreadyPaid2 = paidAmount > 0;
      const isCalculationForExisting = alreadyPaid2 && salaryCalculationDetails && salaryCalculationDetails?.totalSalary === paidAmount;
      setIsCalculationForExistingPayment(isCalculationForExisting);
      setIsSalaryAlreadyPaid(alreadyPaid2);
      setAlreadyPaidSalaryAmount(sPay);
      setIsExistingOtherPayments(otherPay || "0.0");
      return {
        isPaid: alreadyPaid2,
        totalPaid: paidAmount
      };
    } catch (error) {
      setAlreadyPaidSalaryAmount("0.0");
      setSalaryCalculationDetails("0.0");
      console.error("Error checking existing payments:", error);
      return {
        isPaid: false,
        totalPaid: 0
      };
    }
  };
  const calculateProRatedSalary = async (fromDateStr, toDateStr, monthlySalary, empId) => {
    if (!empId || !fromDateStr || !toDateStr) {
      setCalculatedSalary("");
      setAlreadyPaid("0.00");
      setRemainingSalary("0.00");
      setAlertConfig({
        visibility: true,
        message: "Please select valid dates and employee.",
        type: "warning",
        noReload: true
      });
      return;
    }
    const paymentStatus = await checkIfSalaryAlreadyPaid(empId, fromDateStr, toDateStr);
    setIsSalaryAlreadyPaid(paymentStatus.isPaid);
    if (paymentStatus.isPaid) {
      setCalculatedSalary("");
      setAlreadyPaid(paymentStatus.totalPaid.toFixed(2));
      setRemainingSalary("0.00");
      setSalaryCalculationDetails({
        totalSalary: paymentStatus.totalPaid,
        leave_info: {
          total_leaves_used: 0,
          total_absences: 0,
          current_leave_balance: 0,
          monthly_breakdown: [],
          full_year_report: []
        },
        deductionDetails: []
      });
      setAlertConfig({
        visibility: true,
        message: `Salary has already been paid for this period. Total paid: ₹${paymentStatus.totalPaid.toFixed(2)}`,
        type: "warning",
        noReload: true
      });
      return;
    }
    try {
      setIsLoading(true);
      const res = await API.post("/salary/calculate", {
        empId,
        from_date: formatDate(fromDateStr),
        to_date: formatDate(toDateStr)
      });
      const { totalSalary } = res.data;
      console.log(totalSalary, "salary calculation response");
      setSalaryCalculationDetails(res.data);
      const payable = parseFloat(totalSalary).toFixed(2);
      setCalculatedSalary(payable);
      setTotalWithIncentive(payable);
      const paymentsRes = await API.get("/salary/get-salary-payments");
      const fromDate = new Date(formatDate(fromDateStr));
      const toDate = new Date(formatDate(toDateStr));
      const salaryArray = Array.isArray(paymentsRes.data) ? paymentsRes.data : paymentsRes.data.data || [];
      const paidInPeriod = salaryArray.filter((p) => {
        const pAgentId = p.employee_id?._id ? String(p.employee_id._id) : String(p.employee_id);
        const payDate = new Date(formatDate(p.payout_metadata?.date_range?.from));
        return pAgentId === String(empId) && payDate >= fromDate && payDate <= toDate;
      }).reduce((sum, p) => sum + parseFloat(p.payout_metadata?.total_paid_amount || 0), 0);
      const alreadyPaidAmt = paidInPeriod.toFixed(2);
      const remaining = Math.max(0, parseFloat(payable) - paidInPeriod).toFixed(2);
      setAlreadyPaid(alreadyPaidAmt);
      setRemainingSalary(remaining);
      setAlertConfig({
        visibility: true,
        message: "Salary calculated successfully!",
        type: "success",
        noReload: true
      });
    } catch (error) {
      console.error("Calculate salary error:", error);
      const message = error.response?.data?.error || error.response?.data?.details || error.message || "Failed to calculate salary";
      setAlertConfig({
        visibility: true,
        message,
        type: "error",
        noReload: true
      });
      setCalculatedSalary("");
      setAlreadyPaid("0.00");
      setRemainingSalary("0.00");
    } finally {
      setIsLoading(false);
    }
  };
  const fetchEmployeeDetails = async (empId) => {
    try {
      const res = await API.get(`/agent/get-additional-employee-info-by-id/${empId}`);
      const emp = res?.data?.employee;
      if (emp) {
        const joining = emp.joining_date?.split("T")[0] || "";
        const baseSalary = emp.salary || "";
        setEmployeeDetails({ joining_date: joining, salary: baseSalary });
        const todayStr = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
        const newFromDate = joining || todayStr;
        const newToDate = todayStr;
        setSalaryForm((prev) => ({
          ...prev,
          from_date: newFromDate,
          to_date: newToDate
        }));
        if (dateMode === "month") {
          const joinDate = new Date(joining || todayStr);
          const sm = `${joinDate.getFullYear()}-${String(joinDate.getMonth() + 1).padStart(2, "0")}`;
          setSelectedMonth(sm);
        }
      }
    } catch (err) {
      console.error("Error fetching employee info", err);
      setEmployeeDetails({ joining_date: "", salary: "" });
      setCalculatedSalary("");
    }
  };
  const fetchAgents = async () => {
    try {
      const response = await API.get("/employee");
      setAgents(response.data?.employee || []);
    } catch (error) {
      console.error("Failed to fetch Agents");
    }
  };
  const fetchSalaryPayments = async () => {
    setIsLoading(true);
    try {
      const response = await API.get("/salary/get-salary-payments");
      const salaryArray = Array.isArray(response.data) ? response.data : response.data.data || [];
      console.log("Fetched Salary Payments:", salaryArray);
      const responseData = salaryArray.map((payment, index) => ({
        id: index + 1,
        _id: payment._id,
        pay_date: payment.payout_metadata?.date_range?.from?.split("T")[0] || payment.pay_date?.split("T")[0] || "-",
        agent_id: payment.employee_id?._id || "-",
        agent_name: payment.employee_id?.name || payment.employee_id?.full_name || payment.agent_name || "N/A",
        from_date: payment.payout_metadata?.date_range?.from?.split("T")[0],
        to_date: payment.payout_metadata?.date_range?.to?.split("T")[0],
        total_salary: payment.payout_metadata?.total_salary || 0,
        total_paid_amount: payment.payout_metadata?.total_paid_amount || 0,
        // other_payments: payment.payout_metadata?.other_payments || 0,
        other_payments: Array.isArray(payment.payout_metadata?.other_payments) ? payment.payout_metadata.other_payments.reduce(
          (sum, p) => sum + parseFloat(p.amount || 0),
          0
        ).toFixed(2) : parseFloat(payment.payout_metadata?.other_payments || 0).toFixed(2),
        pay_type: payment.payout_metadata?.pay_type || payment.pay_type || "N/A",
        receipt_no: payment.payout_metadata?.receipt_no || payment.receipt_no || "-",
        note: payment.payout_metadata?.note || payment.note || "-",
        disbursed_by: payment.payout_metadata?.disbursed_by || payment.disbursed_by || "Admin",
        action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
          Dropdown,
          {
            trigger: ["click"],
            dropdownRender: (menu) => /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-lg border border-gray-100 p-2 min-w-[240px]", children: [
              /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: "flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors duration-200 group",
                  onClick: () => {
                    setEditingSalary(payment);
                    setIsEditing(true);
                  },
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "w-9 h-9 rounded-lg bg-violet-50 flex items-center justify-center group-hover:bg-violet-100 transition-colors duration-200", children: /* @__PURE__ */ jsxDEV("svg", { xmlns: "http://www.w3.org/2000/svg", className: "h-4 w-4 text-violet-600", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 393,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 392,
                      columnNumber: 23
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 391,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-700", children: "Edit Payment" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 397,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-500", children: "Modify payment details" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 398,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 396,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 384,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: "flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors duration-200 group",
                  onClick: (e) => {
                    e.stopPropagation();
                  },
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "w-9 h-9 rounded-lg bg-emerald-50 flex items-center justify-center group-hover:bg-emerald-100 transition-colors duration-200", children: /* @__PURE__ */ jsxDEV("svg", { xmlns: "http://www.w3.org/2000/svg", className: "h-4 w-4 text-emerald-600", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 409,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 408,
                      columnNumber: 23
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 407,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: /* @__PURE__ */ jsxDEV(SalarySlipPrint, { payment }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 413,
                      columnNumber: 23
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 412,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 401,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "h-px bg-gray-200 my-2 mx-2" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                lineNumber: 417,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
              lineNumber: 383,
              columnNumber: 13
            }, this),
            placement: "bottomRight",
            children: /* @__PURE__ */ jsxDEV("div", { className: "cursor-pointer p-2 hover:bg-gray-50 rounded-lg transition-all duration-200 border border-transparent hover:border-gray-200 hover:shadow-sm", children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-xl text-gray-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
              lineNumber: 425,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
              lineNumber: 424,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
            lineNumber: 380,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
          lineNumber: 379,
          columnNumber: 9
        }, this)
      }));
      setSalaryPayments(responseData);
    } catch (error) {
      console.error("Failed to fetch Salary payments", error);
      setSalaryPayments([]);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    setAdminId(userObj._id);
    setAdminName(userObj.name || "");
    if (userObj?.admin_access_right_id?.access_permissions?.edit_payment) {
      setModifyPayment(
        userObj.admin_access_right_id.access_permissions.edit_payment === "true"
      );
    }
  }, []);
  useEffect(() => {
    if (alertConfig.visibility && alertConfig.noReload) {
      const timer = setTimeout(() => {
        setAlertConfig((prev) => ({ ...prev, visibility: false }));
      }, 4e3);
      return () => clearTimeout(timer);
    }
  }, [alertConfig.visibility]);
  useEffect(() => {
    fetchAgents();
    fetchSalaryPayments();
  }, [reRender]);
  const handleSalaryChange = (e) => {
    const { name, value } = e.target;
    const todayStr = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    setSalaryForm((prev) => {
      const updated = { ...prev, [name]: value };
      const from = updated.from_date ? new Date(updated.from_date) : null;
      const to = updated.to_date ? new Date(updated.to_date) : null;
      const today2 = new Date(todayStr);
      let fromError = "";
      let toError = "";
      if (from && isNaN(from.getTime())) {
        fromError = "Invalid From Date";
      } else if (from && from > today2) {
        fromError = "From Date cannot be in the future.";
      }
      if (to && isNaN(to.getTime())) {
        toError = "Invalid To Date";
      } else if (to && to > today2) {
        toError = "To Date cannot be in the future.";
      }
      if (from && to && !isNaN(from.getTime()) && !isNaN(to.getTime()) && from > to) {
        fromError = "From Date cannot be greater than To Date.";
        toError = "To Date cannot be less than From Date.";
      }
      setErrors((prevErrors) => ({
        ...prevErrors,
        from_date: fromError,
        to_date: toError
      }));
      return updated;
    });
    setOtherPaymentsList([{ reason: "", amount: "" }]);
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };
  const validateForm = () => {
    const newErrors = {};
    if (!salaryForm.agent_id) newErrors.agent_id = "Please select an agent";
    if (salaryForm.pay_type === "online" && !salaryForm.transaction_id)
      newErrors.pay_type = "Transaction ID is required for online payments";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    if (!isValid) return;
    const paymentStatus = await checkIfSalaryAlreadyPaid(
      salaryForm.agent_id,
      salaryForm.from_date,
      salaryForm.to_date
    );
    if (paymentStatus.isPaid) {
      api.open({
        message: "Cannot create new payment",
        description: "Salary has already been paid for this period.",
        className: "bg-red-500 rounded-lg font-semibold text-white"
      });
      return;
    }
    let totalPaidAmount = 0;
    totalPaidAmount = manualPaidAmount ? parseFloat(manualPaidAmount) : parseFloat(calculatedSalary || 0);
    const otherPaymentsTotal = otherPaymentsList.reduce((sum, p) => {
      const val = parseFloat(p.amount);
      return !isNaN(val) ? sum + val : sum;
    }, 0);
    totalPaidAmount += otherPaymentsTotal;
    const payload = {
      empId: salaryForm.agent_id,
      from_date: salaryForm.from_date,
      to_date: salaryForm.to_date,
      note: salaryForm.note,
      pay_type: salaryForm.pay_type,
      transaction_id: salaryForm.transaction_id,
      total_paid_amount: totalPaidAmount,
      other_payments: otherPaymentsList.filter((p) => p.reason && p.amount).map((p) => ({
        description: p.reason.trim(),
        amount: Number(p.amount)
      }))
    };
    try {
      setIsLoading(true);
      const res = await API.post("/salary/save", payload);
      api.open({
        message: "Salary Processed Successfully",
        description: res.data.message || "Salary calculated and payout record created.",
        className: "bg-green-500 rounded-lg font-semibold text-white"
      });
      setShowSalaryModal(false);
      resetForm();
      setReRender((val) => val + 1);
      fetchSalaryPayments();
    } catch (error) {
      const message = error.response?.data?.error || error.response?.data?.message || error.message || "Failed to process salary";
      api.open({
        message: "Salary Processing Failed",
        description: message,
        className: "bg-red-500 rounded-lg font-semibold text-white"
      });
    } finally {
      setIsLoading(false);
    }
  };
  const resetForm = () => {
    setDateMode("month");
    const today2 = /* @__PURE__ */ new Date();
    const currentMonth2 = `${today2.getFullYear()}-${String(today2.getMonth() + 1).padStart(2, "0")}`;
    setSelectedMonth(currentMonth2);
    setSalaryForm({
      agent_id: "",
      pay_date: today2.toISOString().split("T")[0],
      from_date: "",
      to_date: "",
      amount: "",
      pay_type: "cash",
      transaction_id: "",
      note: "",
      pay_for: paymentFor,
      admin_type: adminId
    });
    setEmployeeDetails({ joining_date: "", salary: "" });
    setCalculatedSalary("");
    setManualPaidAmount("");
    setOtherPaymentsList([{ reason: "", amount: "" }]);
    setAlreadyPaid("0.00");
    setRemainingSalary("0.00");
    setSalaryCalculationDetails(null);
    setIsSalaryAlreadyPaid(false);
    setIsCalculationForExistingPayment(false);
  };
  const salaryColumns = [
    { key: "id", header: "SL. NO" },
    { key: "pay_date", header: "Pay Date" },
    { key: "agent_name", header: "Agent" },
    { key: "total_paid_amount", header: "Total Paid Amount (₹)" },
    { key: "other_payments", header: "Additional Payments (₹)" },
    { key: "total_salary", header: "Total Salary Amount (₹)" },
    { key: "pay_type", header: "Payment Mode" },
    { key: "receipt_no", header: "Receipt No" },
    { key: "from_date", header: "From Date" },
    { key: "to_date", header: "To Date" },
    { key: "note", header: "Note" },
    { key: "disbursed_by", header: "Disbursed by" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    contextHolder,
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
        lineNumber: 655,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
        lineNumber: 656,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        CustomAlert,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          noReload: alertConfig.noReload
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
          lineNumber: 657,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-2xl text-red-500 font-bold", children: paymentFor?.toUpperCase() }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
              lineNumber: 667,
              columnNumber: 15
            }, this),
            " Payments Out"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
            lineNumber: 666,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Tooltip, { title: "Add Salary Payment", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowSalaryModal(true);
                resetForm();
              },
              className: "ml-4 bg-violet-900 text-white px-4 py-2 rounded shadow-md hover:bg-violet-600 transition duration-200 flex items-center",
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "mr-2", children: "+" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 677,
                  columnNumber: 17
                }, this),
                " Salary Payment"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
              lineNumber: 670,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
            lineNumber: 669,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
          lineNumber: 665,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-8 bg-white p-6 rounded-lg shadow-md", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold mb-4 text-violet-800 border-b pb-2", children: "Salary Payments" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
            lineNumber: 683,
            columnNumber: 13
          }, this),
          salaryPayments.length > 0 ? /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: salaryPayments,
              columns: salaryColumns,
              exportedPdfName: "PayOut Salary",
              exportedFileName: `PayOut Salary.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
              lineNumber: 685,
              columnNumber: 13
            },
            this
          ) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10 text-center text-gray-500", children: /* @__PURE__ */ jsxDEV(
            CircularLoader,
            {
              isLoading,
              data: "Salary Payments",
              failure: salaryPayments.length === 0
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
              lineNumber: 693,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
            lineNumber: 692,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
          lineNumber: 682,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
        lineNumber: 664,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Modal,
        {
          isVisible: showSalaryModal,
          onClose: () => {
            setShowSalaryModal(false);
            resetForm();
          },
          children: /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-slate-50 to-slate-100 py-6 px-6 lg:px-8 text-left max-h-[90vh] my-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-6 pb-4 border-b border-slate-200", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-lg bg-gradient-to-br from-violet-500 to-violet-600 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-6 h-6 text-white", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0 0c0 3.517 2.843 6.38 6.36 6.38a6.36 6.36 0 006.36-6.38 6.36 6.36 0 00-6.36-6.38c-3.517 0-6.36 2.863-6.36 6.38m0 0c0 3.517 2.843 6.38 6.36 6.38a6.36 6.36 0 006.36-6.38 6.36 6.36 0 00-6.36-6.38c-3.517 0-6.36 2.863-6.36 6.38z" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                lineNumber: 715,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                lineNumber: 714,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                lineNumber: 713,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900", children: "Salary Payment" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 719,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Process and manage employee salary disbursement" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 720,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                lineNumber: 718,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
              lineNumber: 712,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
              lineNumber: 711,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-5 border border-slate-200 shadow-sm", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-800", children: [
                  "Select Employee ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 728,
                    columnNumber: 35
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 727,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: "w-full",
                    placeholder: "Search and select employee...",
                    showSearch: true,
                    optionFilterProp: "children",
                    filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                    value: salaryForm.agent_id || void 0,
                    onChange: (value) => {
                      setErrors((prev) => ({ ...prev, agent_id: "" }));
                      setSalaryForm((prev) => ({
                        ...prev,
                        agent_id: value,
                        amount: ""
                      }));
                      setEmployeeDetails({ joining_date: "", salary: "" });
                      setCalculatedSalary("");
                      setManualPaidAmount("");
                      setOtherPaymentsList([{ reason: "", amount: "" }]);
                      setAlreadyPaid("0.00");
                      setRemainingSalary("0.00");
                      fetchEmployeeDetails(value);
                    },
                    children: agents.map(
                      (agent) => /* @__PURE__ */ jsxDEV(Select.Option, { value: agent._id, children: `${agent.name} | ${agent.phone_number}` }, agent._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 757,
                        columnNumber: 19
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 730,
                    columnNumber: 17
                  },
                  this
                ),
                errors.agent_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-2 flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxDEV("span", { children: "⚠" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 764,
                    columnNumber: 21
                  }, this),
                  " ",
                  errors.agent_id
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 763,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                lineNumber: 726,
                columnNumber: 15
              }, this),
              employeeDetails.joining_date && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg p-4 border border-slate-200 shadow-sm", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1", children: "Joining Date" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 773,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-gray-900", children: employeeDetails?.joining_date }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 774,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 772,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg p-4 border border-slate-200 shadow-sm", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1", children: "Monthly Salary" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 777,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-green-700", children: [
                      "₹",
                      employeeDetails?.salary
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 778,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 776,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 771,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-5 border border-slate-200 shadow-sm", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "font-medium text-gray-900 mb-3 flex items-center", children: [
                    /* @__PURE__ */ jsxDEV(CalendarOutlined, { className: "mr-2 text-violet-500" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 787,
                      columnNumber: 23
                    }, this),
                    "Salary Period"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 786,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-6 mb-5", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "inline-flex items-center cursor-pointer", children: [
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "radio",
                          className: "form-radio text-violet-600",
                          checked: dateMode === "month",
                          onChange: () => setDateMode("month")
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 792,
                          columnNumber: 25
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV("span", { className: "ml-2 text-sm font-medium text-gray-700", children: "Month" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 798,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 791,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("label", { className: "inline-flex items-center cursor-pointer", children: [
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "radio",
                          className: "form-radio text-violet-600",
                          checked: dateMode === "custom",
                          onChange: () => setDateMode("custom")
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 801,
                          columnNumber: 25
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV("span", { className: "ml-2 text-sm font-medium text-gray-700", children: "Custom Date Range" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 807,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 800,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 790,
                    columnNumber: 21
                  }, this),
                  dateMode === "month" && /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Select Month" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 814,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "month",
                        value: selectedMonth,
                        onChange: (e) => {
                          setSelectedMonth(e.target.value);
                          setOtherPaymentsList([{ reason: "", amount: "" }]);
                        },
                        className: "w-full px-3.5 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-500"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 815,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 813,
                    columnNumber: 19
                  }, this),
                  dateMode === "custom" && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "From Date" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 832,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "date",
                          name: "from_date",
                          value: salaryForm.from_date,
                          max: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
                          onChange: handleSalaryChange,
                          className: "w-full px-3.5 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent text-gray-900"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 833,
                          columnNumber: 27
                        },
                        this
                      ),
                      errors.from_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1 flex items-center gap-1", children: [
                        /* @__PURE__ */ jsxDEV("span", { children: "⚠" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 843,
                          columnNumber: 31
                        }, this),
                        " ",
                        errors.from_date
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 842,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 831,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "To Date" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 848,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "date",
                          name: "to_date",
                          value: salaryForm.to_date,
                          max: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
                          onChange: handleSalaryChange,
                          className: "w-full px-3.5 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent text-gray-900"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 849,
                          columnNumber: 27
                        },
                        this
                      ),
                      errors.to_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1 flex items-center gap-1", children: [
                        /* @__PURE__ */ jsxDEV("span", { children: "⚠" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 859,
                          columnNumber: 31
                        }, this),
                        " ",
                        errors.to_date
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 858,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 847,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 830,
                    columnNumber: 19
                  }, this),
                  salaryForm.from_date && salaryForm.to_date && /* @__PURE__ */ jsxDEV("div", { className: "text-right mt-4", children: /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      className: "bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white px-6 py-2.5 rounded-lg font-medium transition-all shadow-md hover:shadow-lg",
                      onClick: () => {
                        if (salaryForm.agent_id && salaryForm.from_date && salaryForm.to_date && employeeDetails.salary) {
                          const fd = formatDate(salaryForm.from_date);
                          const td = formatDate(salaryForm.to_date);
                          calculateProRatedSalary(fd, td, employeeDetails.salary, salaryForm.agent_id);
                        }
                      },
                      children: "Calculate Salary"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 869,
                      columnNumber: 25
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 868,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 785,
                  columnNumber: 19
                }, this),
                isSalaryAlreadyPaid && !isCalculationForExistingPayment && /* @__PURE__ */ jsxDEV("div", { className: "bg-yellow-50 p-4 rounded-lg border border-yellow-200 mb-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start", children: [
                  /* @__PURE__ */ jsxDEV(InfoCircleOutlined, { className: "text-yellow-500 mt-1 mr-2" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 895,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-yellow-800", children: "Salary Already Paid" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 897,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-yellow-600 mt-1", children: "This salary period has already been processed." }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 898,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "mt-3 grid grid-cols-3 gap-3", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-3 rounded-lg border border-yellow-100", children: [
                        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-yellow-700 font-medium", children: "Salary Amount" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 902,
                          columnNumber: 31
                        }, this),
                        /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-yellow-900", children: [
                          "₹",
                          alreadyPaidSalaryAmount || "0.0"
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 903,
                          columnNumber: 31
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 901,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-3 rounded-lg border border-yellow-100", children: [
                        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-yellow-700 font-medium", children: "Already Paid" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 906,
                          columnNumber: 31
                        }, this),
                        /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-yellow-900", children: [
                          "₹",
                          alreadyPaid
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 907,
                          columnNumber: 31
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 905,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-3 rounded-lg border border-yellow-100", children: [
                        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-yellow-700 font-medium", children: "Other Payments" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 910,
                          columnNumber: 31
                        }, this),
                        /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-yellow-900", children: [
                          "₹",
                          existingOtherPayments || "0.00"
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 911,
                          columnNumber: 31
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 909,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 900,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "mt-3 pt-3 border-t border-yellow-200", children: /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-yellow-800", children: [
                      "Total Amount: ₹",
                      parseFloat(alreadyPaid) + (parseFloat(existingOtherPayments) || 0)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 916,
                      columnNumber: 29
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 915,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 896,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 894,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 893,
                  columnNumber: 17
                }, this),
                calculatedSalary && !isSalaryAlreadyPaid && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-violet-50 to-violet-100 rounded-xl p-5 border border-violet-300 shadow-sm", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-violet-700 uppercase tracking-wider mb-2", children: "Total Payable Amount" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 926,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-violet-900", children: [
                    "₹",
                    calculatedSalary
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 927,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 925,
                  columnNumber: 17
                }, this),
                salaryCalculationDetails && !isSalaryAlreadyPaid && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-slate-100 to-slate-50 px-5 py-3 border-b border-slate-200", children: /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5 text-slate-600", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M9 7h6m0 10v-3m-3 3v3m-6-6v6m0-11V5a2 2 0 012-2h6a2 2 0 012 2v11m-6 0h6" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 936,
                      columnNumber: 29
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 935,
                      columnNumber: 27
                    }, this),
                    isSalaryAlreadyPaid && isCalculationForExistingPayment ? "Existing Payment Details" : "Salary Breakdown"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 934,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 933,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "p-5 space-y-5", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-50 p-4 rounded-lg border border-slate-200", children: [
                      /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-700 mb-3", children: "Leave Summary" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 943,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-3", children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-3 rounded border border-slate-100", children: [
                          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 font-medium", children: "Leaves Used" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 946,
                            columnNumber: 31
                          }, this),
                          /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-gray-900 mt-1", children: salaryCalculationDetails?.leave_info?.total_leaves_used }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 947,
                            columnNumber: 31
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 945,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-3 rounded border border-slate-100", children: [
                          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 font-medium", children: "Total Absences" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 952,
                            columnNumber: 31
                          }, this),
                          /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-gray-900 mt-1", children: salaryCalculationDetails?.leave_info?.total_absences }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 953,
                            columnNumber: 31
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 951,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-3 rounded border border-slate-100", children: [
                          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 font-medium", children: "Leave Balance" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 958,
                            columnNumber: 31
                          }, this),
                          /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-gray-900 mt-1", children: salaryCalculationDetails?.leave_info?.current_leave_balance }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 959,
                            columnNumber: 31
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 957,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 944,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 942,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-700 mb-3", children: "Monthly Details" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 966,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto rounded-lg border border-slate-200", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full text-sm", children: [
                        /* @__PURE__ */ jsxDEV("thead", { className: "bg-gradient-to-r from-slate-100 to-slate-50 border-b border-slate-200", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                          /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2.5 text-left text-xs font-semibold text-gray-700", children: "Month" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 971,
                            columnNumber: 35
                          }, this),
                          /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2.5 text-left text-xs font-semibold text-gray-700", children: "Absences" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 972,
                            columnNumber: 35
                          }, this),
                          /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2.5 text-left text-xs font-semibold text-gray-700", children: "Leaves Used" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 973,
                            columnNumber: 35
                          }, this),
                          /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2.5 text-left text-xs font-semibold text-gray-700", children: "Deductions" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 974,
                            columnNumber: 35
                          }, this),
                          /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-2.5 text-right text-xs font-semibold text-gray-700", children: "Salary Amount" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 975,
                            columnNumber: 35
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 970,
                          columnNumber: 33
                        }, this) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 969,
                          columnNumber: 31
                        }, this),
                        /* @__PURE__ */ jsxDEV("tbody", { className: "text-gray-800", children: salaryCalculationDetails?.leave_info?.monthly_breakdown.map(
                          (m, i) => /* @__PURE__ */ jsxDEV("tr", { className: "border-b border-slate-100 last:border-0 hover:bg-slate-50 transition-colors", children: [
                            /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 font-medium text-gray-900", children: m.month }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                              lineNumber: 981,
                              columnNumber: 37
                            }, this),
                            /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3", children: m.total_absences }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                              lineNumber: 982,
                              columnNumber: 37
                            }, this),
                            /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3", children: m.leaves_used }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                              lineNumber: 983,
                              columnNumber: 37
                            }, this),
                            /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-right font-medium text-red-600", children: [
                              "₹",
                              m.deductions.reduce((sum, d) => sum + parseFloat(d.amount || 0), 0).toFixed(2)
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                              lineNumber: 984,
                              columnNumber: 37
                            }, this),
                            /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-right font-medium text-violet-700", children: [
                              "₹",
                              m.salary_amount ? m.salary_amount.toFixed(2) : "0.00"
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                              lineNumber: 987,
                              columnNumber: 37
                            }, this)
                          ] }, i, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 980,
                            columnNumber: 29
                          }, this)
                        ) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 978,
                          columnNumber: 31
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 968,
                        columnNumber: 29
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 967,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 965,
                      columnNumber: 25
                    }, this),
                    salaryCalculationDetails?.deductions_info?.details?.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-700 mb-3", children: "Deductions" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 998,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 bg-red-50 p-4 rounded-lg border border-red-200", children: salaryCalculationDetails?.deductions_info.details.map(
                        (d, i) => /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center py-2 border-b border-red-100 last:border-0", children: [
                          /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-700", children: [
                            d.justification,
                            d.note && ` (${d.note})`
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 1002,
                            columnNumber: 35
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-red-700", children: [
                            "-₹",
                            parseFloat(d.amount).toFixed(2)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 1003,
                            columnNumber: 35
                          }, this)
                        ] }, i, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 1001,
                          columnNumber: 25
                        }, this)
                      ) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 999,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 997,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 941,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 932,
                  columnNumber: 17
                }, this),
                calculatedSalary && !isSalaryAlreadyPaid && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-green-50 rounded-lg p-4 border border-green-200", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-green-700 uppercase tracking-wider mb-1", children: "Already Paid" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 1016,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-green-900", children: [
                      "₹",
                      alreadyPaid
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 1017,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 1015,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-orange-50 rounded-lg p-4 border border-orange-200", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-orange-700 uppercase tracking-wider mb-1", children: "Remaining" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 1020,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-orange-900", children: [
                      "₹",
                      remainingSalary
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 1021,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 1019,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 1014,
                  columnNumber: 17
                }, this),
                calculatedSalary && !isSalaryAlreadyPaid && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 bg-white rounded-xl p-5 border border-slate-200 shadow-sm", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-800 mb-2", children: "Payable Amount (₹)" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 1028,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      step: "0.01",
                      min: "0",
                      value: manualPaidAmount,
                      onChange: (e) => setManualPaidAmount(e.target.value),
                      className: `w-full px-3 py-2 border rounded-md ${errors.total_paid_amount ? "border-red-500" : "border-gray-300 focus:border-violet-500"}`,
                      placeholder: "Enter Payable amount"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 1031,
                      columnNumber: 23
                    },
                    this
                  ),
                  errors.total_paid_amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.total_paid_amount }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 1042,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: [
                    "Leave blank to use calculated amount (",
                    calculatedSalary,
                    "₹)"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 1044,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 1027,
                  columnNumber: 17
                }, this),
                calculatedSalary && !isSalaryAlreadyPaid && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-5 border border-slate-200 shadow-sm", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "font-medium text-gray-900 mb-3 flex items-center", children: "Additional Payments" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 1053,
                    columnNumber: 23
                  }, this),
                  otherPaymentsList.map(
                    (item, index) => /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-3 mb-3 items-center", children: [
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Payment Description" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 1060,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          "input",
                          {
                            type: "text",
                            placeholder: "e.g., Transport Reimbursement, Bonus",
                            value: item.reason,
                            onChange: (e) => handleOtherPaymentChange(index, "reason", e.target.value),
                            className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-violet-500"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 1063,
                            columnNumber: 29
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 1059,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Payment Amount (₹)" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 1073,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          "input",
                          {
                            type: "number",
                            step: "0.01",
                            min: "0",
                            placeholder: "Enter amount",
                            value: item.amount,
                            onChange: (e) => handleOtherPaymentChange(index, "amount", e.target.value),
                            className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-violet-500"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 1076,
                            columnNumber: 29
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 1072,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex items-end", children: index > 0 && /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          type: "button",
                          onClick: () => handleRemoveOtherPayment(index),
                          className: "text-red-500 hover:text-red-700 font-semibold px-3 py-2",
                          children: "Remove"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 1089,
                          columnNumber: 23
                        },
                        this
                      ) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 1087,
                        columnNumber: 27
                      }, this)
                    ] }, index, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 1058,
                      columnNumber: 19
                    }, this)
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "mt-3", children: /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: handleAddOtherPayment,
                      className: "bg-green-600 text-white text-sm font-medium px-4 py-2 rounded-lg hover:bg-green-700 transition-all",
                      children: "+ Add Another Payment"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 1102,
                      columnNumber: 25
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 1101,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-2", children: "Add one or more extra payments such as incentives, reimbursements, or bonuses." }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 1111,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 1052,
                  columnNumber: 17
                }, this),
                calculatedSalary && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-5 border border-slate-200 shadow-sm", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-800 mb-2", children: "Payment Date" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 1123,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "date",
                        name: "pay_date",
                        value: salaryForm.pay_date,
                        onChange: handleSalaryChange,
                        className: "w-full px-3.5 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent text-gray-900",
                        disabled: !modifyPayment
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 1126,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 1122,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-3 border border-slate-200 shadow-sm", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-800 mb-2", children: "Payment Mode" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 1136,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        value: salaryForm.pay_type,
                        onChange: (value) => setSalaryForm({ ...salaryForm, pay_type: value }),
                        className: "w-full",
                        children: [
                          /* @__PURE__ */ jsxDEV(Select.Option, { value: "cash", children: "Cash" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 1144,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV(Select.Option, { value: "online", children: "Online Transfer" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 1145,
                            columnNumber: 27
                          }, this),
                          modifyPayment && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                            /* @__PURE__ */ jsxDEV(Select.Option, { value: "cheque", children: "Cheque" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                              lineNumber: 1148,
                              columnNumber: 31
                            }, this),
                            /* @__PURE__ */ jsxDEV(Select.Option, { value: "bank_transfer", children: "Bank Transfer" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                              lineNumber: 1149,
                              columnNumber: 31
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 1147,
                            columnNumber: 23
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 1139,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 1135,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 1121,
                  columnNumber: 17
                }, this),
                calculatedSalary && salaryForm.pay_type === "online" && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-5 border border-slate-200 shadow-sm", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-800 mb-2", children: "Transaction ID" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 1159,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      value: salaryForm.transaction_id,
                      onChange: (e) => setSalaryForm({ ...salaryForm, transaction_id: e.target.value }),
                      className: `w-full px-3 py-2 border rounded-md ${errors.transaction_id ? "border-red-500" : "border-gray-300 focus:border-violet-500"}`,
                      placeholder: "Enter transaction ID"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 1162,
                      columnNumber: 23
                    },
                    this
                  ),
                  errors.transaction_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.transaction_id }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 1170,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 1158,
                  columnNumber: 17
                }, this),
                calculatedSalary && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-5 border border-slate-200 shadow-sm", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-800 mb-2", children: "Additional Notes" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 1177,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "textarea",
                    {
                      value: salaryForm.note,
                      onChange: (e) => setSalaryForm({ ...salaryForm, note: e.target.value }),
                      className: `w-full px-3 py-2 border rounded-md ${errors.note ? "border-red-500" : "border-gray-300 focus:border-violet-500"}`,
                      rows: "3",
                      placeholder: "Add any notes about this payment..."
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 1180,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: "These notes will be visible on the salary slip" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 1188,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 1176,
                  columnNumber: 17
                }, this),
                calculatedSalary && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-violet-50 to-violet-100 rounded-xl p-5 border border-violet-300 shadow-sm", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-violet-700 uppercase tracking-wider mb-2", children: "Disbursed By" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 1196,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-violet-900 flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 rounded-full bg-violet-500 flex items-center justify-center text-white text-sm font-bold", children: adminName?.charAt(0).toUpperCase() }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 1198,
                      columnNumber: 25
                    }, this),
                    adminName
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                    lineNumber: 1197,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 1195,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "p-4 border-t border-gray-200 mt-6 flex justify-end gap-3", children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: () => {
                        setShowSalaryModal(false);
                        resetForm();
                      },
                      className: "px-5 py-2.5 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors",
                      children: "Cancel"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 1208,
                      columnNumber: 21
                    },
                    this
                  ),
                  !isSalaryAlreadyPaid && /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "submit",
                      disabled: isLoading,
                      className: `px-5 py-2.5 rounded-lg text-white font-medium transition-colors ${isLoading ? "bg-gray-400 cursor-not-allowed" : "bg-violet-600 hover:bg-violet-700"}`,
                      children: isLoading ? /* @__PURE__ */ jsxDEV("span", { className: "flex items-center", children: [
                        /* @__PURE__ */ jsxDEV("svg", { className: "animate-spin -ml-1 mr-2 h-4 w-4 text-white", fill: "none", viewBox: "0 0 24 24", children: [
                          /* @__PURE__ */ jsxDEV("circle", { className: "opacity-25", cx: "12", cy: "12", r: "10", stroke: "currentColor", strokeWidth: "4" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 1229,
                            columnNumber: 29
                          }, this),
                          /* @__PURE__ */ jsxDEV("path", { className: "opacity-75", fill: "currentColor", d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                            lineNumber: 1230,
                            columnNumber: 29
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                          lineNumber: 1228,
                          columnNumber: 27
                        }, this),
                        "Processing..."
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                        lineNumber: 1227,
                        columnNumber: 21
                      }, this) : "Save Payment"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                      lineNumber: 1218,
                      columnNumber: 46
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                  lineNumber: 1207,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
                lineNumber: 770,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
              lineNumber: 725,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
            lineNumber: 710,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
          lineNumber: 703,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        EditSalaryModal,
        {
          isVisible: isEditing,
          onClose: () => {
            setIsEditing(false);
            setEditingSalary(null);
          },
          salary: editingSalary,
          onEditSuccess: () => {
            setIsEditing(false);
            setEditingSalary(null);
            setReRender((prev) => prev + 1);
            fetchSalaryPayments();
          }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
          lineNumber: 1246,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
      lineNumber: 654,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx",
    lineNumber: 652,
    columnNumber: 5
  }, this);
};
_s(PayoutSalary, "5TZw28EuxmyECV+Qskt+uIRG+NI=", false, function() {
  return [notification.useNotification];
});
_c = PayoutSalary;
export default PayoutSalary;
var _c;
$RefreshReg$(_c, "PayoutSalary");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutSalary.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd1l3QixTQWt2QkksVUFsdkJKOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZZeEIsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLFFBQVFDLFNBQVNDLGNBQWNDLFVBQVVDLGFBQWE7QUFDL0QsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLHFCQUFxQjtBQUM1QixTQUFTQyxnQkFBZ0I7QUFDekIsT0FBT0MscUJBQXFCO0FBQzVCLFNBQVNDLGdCQUFnQkMsa0JBQWtCQyxjQUFjQywwQkFBMEI7QUFFbkYsTUFBTUMsZUFBZUEsTUFBTTtBQUFBQyxLQUFBO0FBQ3pCLFFBQU1DLGFBQWE7QUFDbkIsUUFBTSxDQUFDQyxLQUFLQyxhQUFhLElBQUlmLGFBQWFnQixnQkFBZ0I7QUFDMUQsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUk1QixTQUFTLE9BQU87QUFDaEQsUUFBTSxDQUFDNkIsaUJBQWlCQyxrQkFBa0IsSUFBSTlCLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUMrQixlQUFlQyxnQkFBZ0IsSUFBSWhDLFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUNpQyxTQUFTQyxVQUFVLElBQUlsQyxTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDbUMsUUFBUUMsU0FBUyxJQUFJcEMsU0FBUyxDQUFDO0FBQ3RDLFFBQU0sQ0FBQ3FDLGVBQWVDLGdCQUFnQixJQUFJdEMsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ3VDLHVCQUF1QkMsMEJBQTBCLElBQUl4QyxTQUFTLEVBQUU7QUFDdkUsUUFBTSxDQUFDeUMseUJBQXlCQywwQkFBMEIsSUFBSTFDLFNBQVMsRUFBRTtBQUN6RSxRQUFNLENBQUMyQyxhQUFhQyxjQUFjLElBQUk1QyxTQUFTO0FBQUEsSUFDN0M2QyxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLFVBQVU7QUFBQSxJQUNWQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUlsRCxTQUFTO0FBQUEsSUFDM0NtRCxRQUFRO0FBQUEsSUFDUkMsVUFBVTtBQUFBLElBQ1ZDLFdBQVc7QUFBQSxJQUNYQyxZQUFZO0FBQUEsSUFDWkMsaUJBQWlCO0FBQUEsSUFDakJDLGtCQUFrQjtBQUFBLEVBQ3BCLENBQUM7QUFDRCxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSTFELFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUMyRCxnQkFBZ0JDLGlCQUFpQixJQUFJNUQsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQzZELFdBQVdDLFlBQVksSUFBSTlELFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMrRCxXQUFXQyxZQUFZLElBQUloRSxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDaUUsUUFBUUMsU0FBUyxJQUFJbEUsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDbUUsVUFBVUMsV0FBVyxJQUFJcEUsU0FBUyxDQUFDO0FBQzFDLFFBQU0sQ0FBQ3FFLDBCQUEwQkMsMkJBQTJCLElBQUl0RSxTQUFTLElBQUk7QUFDN0UsUUFBTSxDQUFDdUUsa0JBQWtCQyxtQkFBbUIsSUFBSXhFLFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUN5RSxXQUFXQyxZQUFZLElBQUkxRSxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDMkUsZUFBZUMsZ0JBQWdCLElBQUk1RSxTQUFTLElBQUk7QUFDdkQsUUFBTSxDQUFDNkUscUJBQXFCQyxzQkFBc0IsSUFBSTlFLFNBQVMsS0FBSztBQUNwRSxRQUFNLENBQUMrRSxpQ0FBaUNDLGtDQUFrQyxJQUFJaEYsU0FBUyxLQUFLO0FBRzVGLFFBQU1pRixRQUFRLG9CQUFJQyxLQUFLO0FBQ3ZCLFFBQU1DLGVBQWUsR0FBR0YsTUFBTUcsWUFBWSxDQUFDLElBQUlDLE9BQU9KLE1BQU1LLFNBQVMsSUFBSSxDQUFDLEVBQUVDLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFFNUYsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUl6RixTQUFTO0FBQUEsSUFDM0MwRixVQUFVO0FBQUEsSUFDVkMsVUFBVVYsTUFBTVcsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsSUFDMUNDLFdBQVc7QUFBQSxJQUNYQyxTQUFTO0FBQUEsSUFDVEMsUUFBUTtBQUFBLElBQ1JDLFVBQVU7QUFBQSxJQUNWQyxnQkFBZ0I7QUFBQSxJQUNoQkMsTUFBTTtBQUFBLElBQ05DLFNBQVM3RTtBQUFBQSxJQUNUOEUsWUFBWTtBQUFBLEVBQ2QsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsaUJBQWlCQyxrQkFBa0IsSUFBSXZHLFNBQVM7QUFBQSxJQUNyRHdHLGNBQWM7QUFBQSxJQUNkQyxRQUFRO0FBQUEsRUFDVixDQUFDO0FBRUQsUUFBTSxDQUFDQyxvQkFBb0JDLHFCQUFxQixJQUFJM0csU0FBUyxNQUFNO0FBQ25FLFFBQU0sQ0FBQzRHLGtCQUFrQkMsbUJBQW1CLElBQUk3RyxTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDOEcsYUFBYUMsY0FBYyxJQUFJL0csU0FBUyxNQUFNO0FBQ3JELFFBQU0sQ0FBQ2dILGlCQUFpQkMsa0JBQWtCLElBQUlqSCxTQUFTLE1BQU07QUFFN0QsUUFBTWtILGFBQWFBLENBQUNDLFNBQVM7QUFDM0IsUUFBSSxDQUFDQSxLQUFNLFFBQU87QUFDbEIsUUFBSSxPQUFPQSxTQUFTLFlBQVksc0JBQXNCQyxLQUFLRCxJQUFJLEdBQUc7QUFDaEUsYUFBT0E7QUFBQUEsSUFDVDtBQUNBLFVBQU1FLElBQUksSUFBSW5DLEtBQUtpQyxJQUFJO0FBQ3ZCLFFBQUlHLE1BQU1ELENBQUMsRUFBRyxRQUFPO0FBQ3JCLFVBQU1FLE9BQU9GLEVBQUVqQyxZQUFZO0FBQzNCLFVBQU1vQyxRQUFRbkMsT0FBT2dDLEVBQUUvQixTQUFTLElBQUksQ0FBQyxFQUFFQyxTQUFTLEdBQUcsR0FBRztBQUN0RCxVQUFNa0MsTUFBTXBDLE9BQU9nQyxFQUFFSyxRQUFRLENBQUMsRUFBRW5DLFNBQVMsR0FBRyxHQUFHO0FBQy9DLFdBQU8sR0FBR2dDLElBQUksSUFBSUMsS0FBSyxJQUFJQyxHQUFHO0FBQUEsRUFDaEM7QUFHQSxRQUFNLENBQUNFLG1CQUFtQkMsb0JBQW9CLElBQUk1SCxTQUFTLENBQUMsRUFBRTZILFFBQVEsSUFBSTdCLFFBQVEsR0FBRyxDQUFDLENBQUM7QUFFdkYsUUFBTThCLHdCQUF3QkEsTUFBTTtBQUNsQ0YseUJBQXFCLENBQUMsR0FBR0QsbUJBQW1CLEVBQUVFLFFBQVEsSUFBSTdCLFFBQVEsR0FBRyxDQUFDLENBQUM7QUFBQSxFQUN6RTtBQUVBLFFBQU0rQiwyQkFBMkJBLENBQUNDLE9BQU9DLE9BQU9DLFVBQVU7QUFDeEQsVUFBTUMsVUFBVSxDQUFDLEdBQUdSLGlCQUFpQjtBQUNyQ1EsWUFBUUgsS0FBSyxFQUFFQyxLQUFLLElBQUlDO0FBQ3hCTix5QkFBcUJPLE9BQU87QUFBQSxFQUM5QjtBQUVBLFFBQU1DLDJCQUEyQkEsQ0FBQ0osVUFBVTtBQUMxQ0oseUJBQXFCRCxrQkFBa0JVLE9BQU8sQ0FBQ0MsR0FBR0MsTUFBTUEsTUFBTVAsS0FBSyxDQUFDO0FBQUEsRUFDdEU7QUFJQWpJLFlBQVUsTUFBTTtBQUNkdUMscUJBQWlCNkMsWUFBWTtBQUFBLEVBQy9CLEdBQUcsRUFBRTtBQUdMcEYsWUFBVSxNQUFNO0FBQ2QsUUFBSTRCLGFBQWEsV0FBV1UsZUFBZTtBQUN6QyxZQUFNLENBQUNrRixNQUFNQyxLQUFLLElBQUluRixjQUFjd0QsTUFBTSxHQUFHLEVBQUUyQyxJQUFJQyxNQUFNO0FBQ3pELFlBQU1DLFdBQVcsR0FBR25CLElBQUksSUFBSWxDLE9BQU9tQyxLQUFLLEVBQUVqQyxTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQzFELFlBQU1vRCxVQUFVLElBQUl6RCxLQUFLcUMsTUFBTUMsT0FBTyxDQUFDLEVBQUVFLFFBQVE7QUFDakQsWUFBTWtCLFNBQVMsR0FBR3JCLElBQUksSUFBSWxDLE9BQU9tQyxLQUFLLEVBQUVqQyxTQUFTLEdBQUcsR0FBRyxDQUFDLElBQUlGLE9BQU9zRCxPQUFPLEVBQUVwRCxTQUFTLEdBQUcsR0FBRyxDQUFDO0FBQzVGRSxvQkFBYyxDQUFDb0QsVUFBVTtBQUFBLFFBQ3ZCLEdBQUdBO0FBQUFBLFFBQ0gvQyxXQUFXNEM7QUFBQUEsUUFDWDNDLFNBQVM2QztBQUFBQSxNQUNYLEVBQUU7QUFBQSxJQUNKO0FBQUEsRUFDRixHQUFHLENBQUN2RyxlQUFlVixRQUFRLENBQUM7QUFFNUIsUUFBTW1ILDJCQUEyQixPQUFPQyxPQUFPTCxVQUFVRSxXQUFXO0FBQ2xFLFFBQUk7QUFDRixZQUFNSSxXQUFXLE1BQU05SSxJQUFJK0ksSUFBSSwrQkFBK0I7QUFBQSxRQUM1REMsUUFBUTtBQUFBLFVBQ05IO0FBQUFBLFVBQ0FqRCxXQUFXb0IsV0FBV3dCLFFBQVE7QUFBQSxVQUM5QjNDLFNBQVNtQixXQUFXMEIsTUFBTTtBQUFBLFFBQzVCO0FBQUEsTUFDRixDQUFDO0FBRUQsWUFBTU8sY0FBY0MsTUFBTUMsUUFBUUwsU0FBU00sSUFBSSxJQUFJTixTQUFTTSxPQUFPTixTQUFTTSxLQUFLQSxRQUFRO0FBRXpGLFlBQU1DLGFBQWFKLFlBQ2hCZCxPQUFPLENBQUNtQixNQUFNO0FBQ2IsY0FBTUMsV0FBV0QsRUFBRUUsYUFBYUMsTUFBTXRFLE9BQU9tRSxFQUFFRSxZQUFZQyxHQUFHLElBQUl0RSxPQUFPbUUsRUFBRUUsV0FBVztBQUN0RixjQUFNRSxjQUFjLElBQUkxRSxLQUFLZ0MsV0FBV3NDLEVBQUVLLGlCQUFpQkMsWUFBWUMsSUFBSSxDQUFDO0FBQzVFLGVBQU9OLGFBQWFwRSxPQUFPMEQsS0FBSyxLQUM5QmEsZUFBZSxJQUFJMUUsS0FBS2dDLFdBQVd3QixRQUFRLENBQUMsS0FDNUNrQixlQUFlLElBQUkxRSxLQUFLZ0MsV0FBVzBCLE1BQU0sQ0FBQztBQUFBLE1BQzlDLENBQUMsRUFDQW9CLE9BQU8sQ0FBQ0MsS0FBS1QsTUFBTVMsTUFBTUMsV0FBV1YsRUFBRUssaUJBQWlCTSxxQkFBcUIsQ0FBQyxHQUFHLENBQUM7QUFDcEYsWUFBTUMsV0FBV2pCLFlBQ2RkLE9BQU8sQ0FBQ21CLE1BQU07QUFDYixjQUFNQyxXQUFXRCxFQUFFRSxhQUFhQyxNQUFNdEUsT0FBT21FLEVBQUVFLFlBQVlDLEdBQUcsSUFBSXRFLE9BQU9tRSxFQUFFRSxXQUFXO0FBQ3RGLGNBQU1FLGNBQWMsSUFBSTFFLEtBQUtnQyxXQUFXc0MsRUFBRUssaUJBQWlCQyxZQUFZQyxJQUFJLENBQUM7QUFDNUUsZUFBT04sYUFBYXBFLE9BQU8wRCxLQUFLLEtBQzlCYSxlQUFlLElBQUkxRSxLQUFLZ0MsV0FBV3dCLFFBQVEsQ0FBQyxLQUM1Q2tCLGVBQWUsSUFBSTFFLEtBQUtnQyxXQUFXMEIsTUFBTSxDQUFDO0FBQUEsTUFDOUMsQ0FBQyxFQUNBb0IsT0FBTyxDQUFDQyxLQUFLVCxNQUFNUyxNQUFNQyxXQUFXVixFQUFFSyxpQkFBaUJRLGtCQUFrQixDQUFDLEdBQUcsQ0FBQztBQUNqRixZQUFNQyxPQUFPbkIsWUFDVmQsT0FBTyxDQUFDbUIsTUFBTTtBQUNiLGNBQU1DLFdBQVdELEVBQUVFLGFBQWFDLE1BQU10RSxPQUFPbUUsRUFBRUUsWUFBWUMsR0FBRyxJQUFJdEUsT0FBT21FLEVBQUVFLFdBQVc7QUFDdEYsY0FBTUUsY0FBYyxJQUFJMUUsS0FBS2dDLFdBQVdzQyxFQUFFSyxpQkFBaUJDLFlBQVlDLElBQUksQ0FBQztBQUM1RSxlQUFPTixhQUFhcEUsT0FBTzBELEtBQUssS0FDOUJhLGVBQWUsSUFBSTFFLEtBQUtnQyxXQUFXd0IsUUFBUSxDQUFDLEtBQzVDa0IsZUFBZSxJQUFJMUUsS0FBS2dDLFdBQVcwQixNQUFNLENBQUM7QUFBQSxNQUM5QyxDQUFDLEVBQ0FvQixPQUFPLENBQUNDLEtBQUtULE1BQU1TLE1BQU1DLFdBQVdWLEVBQUVLLGlCQUFpQlUsZ0JBQWdCLENBQUMsR0FBRyxDQUFDO0FBQy9FLFlBQU16RCxlQUFjeUMsYUFBYTtBQUdqQyxZQUFNaUIsMkJBQTJCMUQsZ0JBQy9CekMsNEJBQ0FBLDBCQUEwQm9HLGdCQUFnQmxCO0FBRTVDdkUseUNBQW1Dd0Ysd0JBQXdCO0FBQzNEMUYsNkJBQXVCZ0MsWUFBVztBQUNsQ3BFLGlDQUEyQjRILElBQUk7QUFDL0I5SCxpQ0FBMkI0SCxZQUFZLEtBQUs7QUFDNUMsYUFBTztBQUFBLFFBQ0xNLFFBQVE1RDtBQUFBQSxRQUNSNkQsV0FBV3BCO0FBQUFBLE1BQ2I7QUFBQSxJQUNGLFNBQVNxQixPQUFPO0FBQ2RsSSxpQ0FBMkIsS0FBSztBQUNoQzRCLGtDQUE0QixLQUFLO0FBRWpDdUcsY0FBUUQsTUFBTSxxQ0FBcUNBLEtBQUs7QUFDeEQsYUFBTztBQUFBLFFBQ0xGLFFBQVE7QUFBQSxRQUNSQyxXQUFXO0FBQUEsTUFDYjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTUcsMEJBQTBCLE9BQU9DLGFBQWFDLFdBQVdDLGVBQWVsQyxVQUFVO0FBQ3RGLFFBQUksQ0FBQ0EsU0FBUyxDQUFDZ0MsZUFBZSxDQUFDQyxXQUFXO0FBQ3hDbkUsMEJBQW9CLEVBQUU7QUFDdEJFLHFCQUFlLE1BQU07QUFDckJFLHlCQUFtQixNQUFNO0FBQ3pCckUscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RFLE1BQU07QUFBQSxRQUNORCxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQ0Q7QUFBQSxJQUNGO0FBR0EsVUFBTW1JLGdCQUFnQixNQUFNcEMseUJBQXlCQyxPQUFPZ0MsYUFBYUMsU0FBUztBQUNsRmxHLDJCQUF1Qm9HLGNBQWNSLE1BQU07QUFFM0MsUUFBSVEsY0FBY1IsUUFBUTtBQUN4QjdELDBCQUFvQixFQUFFO0FBQ3RCRSxxQkFBZW1FLGNBQWNQLFVBQVVRLFFBQVEsQ0FBQyxDQUFDO0FBQ2pEbEUseUJBQW1CLE1BQU07QUFDekIzQyxrQ0FBNEI7QUFBQSxRQUMxQm1HLGFBQWFTLGNBQWNQO0FBQUFBLFFBQzNCUyxZQUFZO0FBQUEsVUFDVkMsbUJBQW1CO0FBQUEsVUFDbkJDLGdCQUFnQjtBQUFBLFVBQ2hCQyx1QkFBdUI7QUFBQSxVQUN2QkMsbUJBQW1CO0FBQUEsVUFDbkJDLGtCQUFrQjtBQUFBLFFBQ3BCO0FBQUEsUUFDQUMsa0JBQWtCO0FBQUEsTUFDcEIsQ0FBQztBQUVEOUkscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUyw4REFBOERvSSxjQUFjUCxVQUFVUSxRQUFRLENBQUMsQ0FBQztBQUFBLFFBQ3pHbkksTUFBTTtBQUFBLFFBQ05ELFVBQVU7QUFBQSxNQUNaLENBQUM7QUFDRDtBQUFBLElBQ0Y7QUFFQSxRQUFJO0FBQ0ZlLG1CQUFhLElBQUk7QUFDakIsWUFBTTZILE1BQU0sTUFBTXpMLElBQUkwTCxLQUFLLHFCQUFxQjtBQUFBLFFBQzlDN0M7QUFBQUEsUUFDQWpELFdBQVdvQixXQUFXNkQsV0FBVztBQUFBLFFBQ2pDaEYsU0FBU21CLFdBQVc4RCxTQUFTO0FBQUEsTUFDL0IsQ0FBQztBQUVELFlBQU0sRUFBRVAsWUFBWSxJQUFJa0IsSUFBSXJDO0FBQzVCdUIsY0FBUWdCLElBQUlwQixhQUFhLDZCQUE2QjtBQUN0RG5HLGtDQUE0QnFILElBQUlyQyxJQUFJO0FBQ3BDLFlBQU13QyxVQUFVNUIsV0FBV08sV0FBVyxFQUFFVSxRQUFRLENBQUM7QUFDakR0RSwwQkFBb0JpRixPQUFPO0FBQzNCbkYsNEJBQXNCbUYsT0FBTztBQUM3QixZQUFNQyxjQUFjLE1BQU03TCxJQUFJK0ksSUFBSSw2QkFBNkI7QUFFL0QsWUFBTVAsV0FBVyxJQUFJeEQsS0FBS2dDLFdBQVc2RCxXQUFXLENBQUM7QUFDakQsWUFBTW5DLFNBQVMsSUFBSTFELEtBQUtnQyxXQUFXOEQsU0FBUyxDQUFDO0FBQzdDLFlBQU03QixjQUFjQyxNQUFNQyxRQUFRMEMsWUFBWXpDLElBQUksSUFDOUN5QyxZQUFZekMsT0FDWnlDLFlBQVl6QyxLQUFLQSxRQUFRO0FBQzdCLFlBQU0wQyxlQUFlN0MsWUFDbEJkLE9BQU8sQ0FBQ21CLE1BQU07QUFDYixjQUFNQyxXQUFXRCxFQUFFRSxhQUFhQyxNQUFNdEUsT0FBT21FLEVBQUVFLFlBQVlDLEdBQUcsSUFBSXRFLE9BQU9tRSxFQUFFRSxXQUFXO0FBQ3RGLGNBQU11QyxVQUFVLElBQUkvRyxLQUFLZ0MsV0FBV3NDLEVBQUVLLGlCQUFpQkMsWUFBWUMsSUFBSSxDQUFDO0FBQ3hFLGVBQU9OLGFBQWFwRSxPQUFPMEQsS0FBSyxLQUFLa0QsV0FBV3ZELFlBQVl1RCxXQUFXckQ7QUFBQUEsTUFDekUsQ0FBQyxFQUNBb0IsT0FBTyxDQUFDQyxLQUFLVCxNQUFNUyxNQUFNQyxXQUFXVixFQUFFSyxpQkFBaUJNLHFCQUFxQixDQUFDLEdBQUcsQ0FBQztBQUNwRixZQUFNK0IsaUJBQWlCRixhQUFhYixRQUFRLENBQUM7QUFDN0MsWUFBTTlILFlBQVk4SSxLQUFLQyxJQUFJLEdBQUdsQyxXQUFXNEIsT0FBTyxJQUFJRSxZQUFZLEVBQUViLFFBQVEsQ0FBQztBQUMzRXBFLHFCQUFlbUYsY0FBYztBQUM3QmpGLHlCQUFtQjVELFNBQVM7QUFDNUJULHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNURSxNQUFNO0FBQUEsUUFDTkQsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0gsU0FBUzZILE9BQU87QUFDZEMsY0FBUUQsTUFBTSwyQkFBMkJBLEtBQUs7QUFDOUMsWUFBTTlILFVBQ0o4SCxNQUFNNUIsVUFBVU0sTUFBTXNCLFNBQ3RCQSxNQUFNNUIsVUFBVU0sTUFBTStDLFdBQ3RCekIsTUFBTTlILFdBQ047QUFDRkYscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkM7QUFBQUEsUUFDQUUsTUFBTTtBQUFBLFFBQ05ELFVBQVU7QUFBQSxNQUNaLENBQUM7QUFDRDhELDBCQUFvQixFQUFFO0FBQ3RCRSxxQkFBZSxNQUFNO0FBQ3JCRSx5QkFBbUIsTUFBTTtBQUFBLElBQzNCLFVBQUM7QUFDQ25ELG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNd0ksdUJBQXVCLE9BQU92RCxVQUFVO0FBQzVDLFFBQUk7QUFDRixZQUFNNEMsTUFBTSxNQUFNekwsSUFBSStJLElBQUksNkNBQTZDRixLQUFLLEVBQUU7QUFDOUUsWUFBTXdELE1BQU1aLEtBQUtyQyxNQUFNa0Q7QUFDdkIsVUFBSUQsS0FBSztBQUNQLGNBQU1FLFVBQVVGLElBQUkvRixjQUFjWCxNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUs7QUFDbkQsY0FBTTZHLGFBQWFILElBQUk5RixVQUFVO0FBQ2pDRiwyQkFBbUIsRUFBRUMsY0FBY2lHLFNBQVNoRyxRQUFRaUcsV0FBVyxDQUFDO0FBQ2hFLGNBQU1DLFlBQVcsb0JBQUl6SCxLQUFLLEdBQUVVLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUN0RCxjQUFNK0csY0FBY0gsV0FBV0U7QUFDL0IsY0FBTUUsWUFBWUY7QUFDbEJsSCxzQkFBYyxDQUFDb0QsVUFBVTtBQUFBLFVBQ3ZCLEdBQUdBO0FBQUFBLFVBQ0gvQyxXQUFXOEc7QUFBQUEsVUFDWDdHLFNBQVM4RztBQUFBQSxRQUNYLEVBQUU7QUFFRixZQUFJbEwsYUFBYSxTQUFTO0FBQ3hCLGdCQUFNbUwsV0FBVyxJQUFJNUgsS0FBS3VILFdBQVdFLFFBQVE7QUFDN0MsZ0JBQU1JLEtBQUssR0FBR0QsU0FBUzFILFlBQVksQ0FBQyxJQUFJQyxPQUFPeUgsU0FBU3hILFNBQVMsSUFBSSxDQUFDLEVBQUVDLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFDeEZqRCwyQkFBaUJ5SyxFQUFFO0FBQUEsUUFDckI7QUFBQSxNQUNGO0FBQUEsSUFDRixTQUFTQyxLQUFLO0FBQ1puQyxjQUFRRCxNQUFNLGdDQUFnQ29DLEdBQUc7QUFDakR6Ryx5QkFBbUIsRUFBRUMsY0FBYyxJQUFJQyxRQUFRLEdBQUcsQ0FBQztBQUNuREksMEJBQW9CLEVBQUU7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNb0csY0FBYyxZQUFZO0FBQzlCLFFBQUk7QUFDRixZQUFNakUsV0FBVyxNQUFNOUksSUFBSStJLElBQUksV0FBVztBQUMxQ3ZGLGdCQUFVc0YsU0FBU00sTUFBTWtELFlBQVksRUFBRTtBQUFBLElBQ3pDLFNBQVM1QixPQUFPO0FBQ2RDLGNBQVFELE1BQU0sd0JBQXdCO0FBQUEsSUFDeEM7QUFBQSxFQUNGO0FBRUEsUUFBTXNDLHNCQUFzQixZQUFZO0FBQ3RDcEosaUJBQWEsSUFBSTtBQUNqQixRQUFJO0FBQ0YsWUFBTWtGLFdBQVcsTUFBTTlJLElBQUkrSSxJQUFJLDZCQUE2QjtBQUM1RCxZQUFNRSxjQUFjQyxNQUFNQyxRQUFRTCxTQUFTTSxJQUFJLElBQUlOLFNBQVNNLE9BQU9OLFNBQVNNLEtBQUtBLFFBQVE7QUFDekZ1QixjQUFRZ0IsSUFBSSw0QkFBNEIxQyxXQUFXO0FBQ25ELFlBQU1nRSxlQUFlaEUsWUFBWVgsSUFBSSxDQUFDNEUsU0FBU3BGLFdBQVc7QUFBQSxRQUN4RHFGLElBQUlyRixRQUFRO0FBQUEsUUFDWjJCLEtBQUt5RCxRQUFRekQ7QUFBQUEsUUFDYmhFLFVBQ0V5SCxRQUFRdkQsaUJBQWlCQyxZQUFZQyxNQUFNbEUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUN2RHVILFFBQVF6SCxVQUFVRSxNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQzlCO0FBQUEsUUFDRkgsVUFBVTBILFFBQVExRCxhQUFhQyxPQUFPO0FBQUEsUUFDdEMyRCxZQUNFRixRQUFRMUQsYUFBYTZELFFBQ3JCSCxRQUFRMUQsYUFBYThELGFBQ3JCSixRQUFRRSxjQUNSO0FBQUEsUUFDRnhILFdBQVdzSCxRQUFRdkQsaUJBQWlCQyxZQUFZQyxNQUFNbEUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLFFBQ2xFRSxTQUFTcUgsUUFBUXZELGlCQUFpQkMsWUFBWTJELElBQUk1SCxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsUUFDOUQwRSxjQUFjNkMsUUFBUXZELGlCQUFpQlUsZ0JBQWdCO0FBQUEsUUFDdkRKLG1CQUFtQmlELFFBQVF2RCxpQkFBaUJNLHFCQUFxQjtBQUFBO0FBQUEsUUFHakVFLGdCQUFnQmpCLE1BQU1DLFFBQVErRCxRQUFRdkQsaUJBQWlCUSxjQUFjLElBQ2pFK0MsUUFBUXZELGdCQUFnQlEsZUFBZUw7QUFBQUEsVUFDdkMsQ0FBQ0MsS0FBS1QsTUFBTVMsTUFBTUMsV0FBV1YsRUFBRXhELFVBQVUsQ0FBQztBQUFBLFVBQzFDO0FBQUEsUUFDRixFQUFFbUYsUUFBUSxDQUFDLElBQ1RqQixXQUFXa0QsUUFBUXZELGlCQUFpQlEsa0JBQWtCLENBQUMsRUFBRWMsUUFBUSxDQUFDO0FBQUEsUUFHdEVsRixVQUFVbUgsUUFBUXZELGlCQUFpQjVELFlBQVltSCxRQUFRbkgsWUFBWTtBQUFBLFFBQ25FeUgsWUFBWU4sUUFBUXZELGlCQUFpQjZELGNBQWNOLFFBQVFNLGNBQWM7QUFBQSxRQUN6RXZILE1BQU1pSCxRQUFRdkQsaUJBQWlCMUQsUUFBUWlILFFBQVFqSCxRQUFRO0FBQUEsUUFDdkR3SCxjQUFjUCxRQUFRdkQsaUJBQWlCOEQsZ0JBQWdCUCxRQUFRTyxnQkFBZ0I7QUFBQSxRQUUvRUMsUUFDRSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsWUFDakIsZ0JBQWdCLENBQUNDLFNBQ2YsdUJBQUMsU0FBSSxXQUFVLDBFQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVMsTUFBTTtBQUNiakoscUNBQWlCd0ksT0FBTztBQUN4QjFJLGlDQUFhLElBQUk7QUFBQSxrQkFDbkI7QUFBQSxrQkFFQTtBQUFBLDJDQUFDLFVBQUssV0FBVSw2SEFDZCxpQ0FBQyxTQUFJLE9BQU0sOEJBQTZCLFdBQVUsMkJBQTBCLE1BQUssUUFBTyxTQUFRLGFBQVksUUFBTyxnQkFDakgsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxhQUFhLEdBQUcsR0FBRSw0SEFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkwsS0FEL0w7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSUE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSw2Q0FBQyxVQUFLLFdBQVUscUNBQW9DLDRCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnRTtBQUFBLHNCQUNoRSx1QkFBQyxVQUFLLFdBQVUseUJBQXdCLHNDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE4RDtBQUFBLHlCQUZoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUE7QUFBQTtBQUFBLGdCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWdCQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVMsQ0FBQ29KLE1BQU07QUFDZEEsc0JBQUVDLGdCQUFnQjtBQUFBLGtCQUNwQjtBQUFBLGtCQUVBO0FBQUEsMkNBQUMsVUFBSyxXQUFVLCtIQUNkLGlDQUFDLFNBQUksT0FBTSw4QkFBNkIsV0FBVSw0QkFBMkIsTUFBSyxRQUFPLFNBQVEsYUFBWSxRQUFPLGdCQUNsSCxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQWEsR0FBRyxHQUFFLGtMQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtUCxLQURyUDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFJQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSx3QkFDYixpQ0FBQyxtQkFBZ0IsV0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBa0MsS0FEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBO0FBQUE7QUFBQSxnQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FjQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLGdDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRDO0FBQUEsaUJBbEM5QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFDQTtBQUFBLFlBRUYsV0FBVTtBQUFBLFlBRVYsaUNBQUMsU0FBSSxXQUFVLDhJQUNiLGlDQUFDLFlBQVMsV0FBVSwyQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkMsS0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBO0FBQUEsVUE5Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBK0NBLEtBaERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpREE7QUFBQSxNQUVKLEVBQUU7QUFDRm5LLHdCQUFrQnVKLFlBQVk7QUFBQSxJQUNoQyxTQUFTdkMsT0FBTztBQUNkQyxjQUFRRCxNQUFNLG1DQUFtQ0EsS0FBSztBQUN0RGhILHdCQUFrQixFQUFFO0FBQUEsSUFDdEIsVUFBQztBQUNDRSxtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUEvRCxZQUFVLE1BQU07QUFDZCxVQUFNaU8sT0FBT0MsYUFBYUMsUUFBUSxNQUFNO0FBQ3hDLFVBQU1DLFVBQVVDLEtBQUtDLE1BQU1MLElBQUk7QUFDL0I5TCxlQUFXaU0sUUFBUXhFLEdBQUc7QUFDdEIzRixpQkFBYW1LLFFBQVFaLFFBQVEsRUFBRTtBQUMvQixRQUFJWSxTQUFTRyx1QkFBdUJDLG9CQUFvQkMsY0FBYztBQUNwRXhNO0FBQUFBLFFBQ0VtTSxRQUFRRyxzQkFBc0JDLG1CQUFtQkMsaUJBQWlCO0FBQUEsTUFDcEU7QUFBQSxJQUNGO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTHpPLFlBQVUsTUFBTTtBQUNkLFFBQUk0QyxZQUFZRSxjQUFjRixZQUFZSSxVQUFVO0FBQ2xELFlBQU0wTCxRQUFRQyxXQUFXLE1BQU07QUFDN0I5TCx1QkFBZSxDQUFDaUcsVUFBVSxFQUFFLEdBQUdBLE1BQU1oRyxZQUFZLE1BQU0sRUFBRTtBQUFBLE1BQzNELEdBQUcsR0FBSTtBQUNQLGFBQU8sTUFBTThMLGFBQWFGLEtBQUs7QUFBQSxJQUNqQztBQUFBLEVBQ0YsR0FBRyxDQUFDOUwsWUFBWUUsVUFBVSxDQUFDO0FBRTNCOUMsWUFBVSxNQUFNO0FBQ2RrTixnQkFBWTtBQUNaQyx3QkFBb0I7QUFBQSxFQUN0QixHQUFHLENBQUMvSSxRQUFRLENBQUM7QUFFYixRQUFNeUsscUJBQXFCQSxDQUFDZCxNQUFNO0FBQ2hDLFVBQU0sRUFBRVAsTUFBTXJGLE1BQU0sSUFBSTRGLEVBQUUzSztBQUMxQixVQUFNd0osWUFBVyxvQkFBSXpILEtBQUssR0FBRVUsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBRXRESixrQkFBYyxDQUFDb0QsU0FBUztBQUN0QixZQUFNVixVQUFVLEVBQUUsR0FBR1UsTUFBTSxDQUFDMEUsSUFBSSxHQUFHckYsTUFBTTtBQUN6QyxZQUFNNkIsT0FBTzVCLFFBQVFyQyxZQUFZLElBQUlaLEtBQUtpRCxRQUFRckMsU0FBUyxJQUFJO0FBQy9ELFlBQU0ySCxLQUFLdEYsUUFBUXBDLFVBQVUsSUFBSWIsS0FBS2lELFFBQVFwQyxPQUFPLElBQUk7QUFDekQsWUFBTWQsU0FBUSxJQUFJQyxLQUFLeUgsUUFBUTtBQUUvQixVQUFJa0MsWUFBWTtBQUNoQixVQUFJQyxVQUFVO0FBRWQsVUFBSS9FLFFBQVF6QyxNQUFNeUMsS0FBS2dGLFFBQVEsQ0FBQyxHQUFHO0FBQ2pDRixvQkFBWTtBQUFBLE1BQ2QsV0FBVzlFLFFBQVFBLE9BQU85RSxRQUFPO0FBQy9CNEosb0JBQVk7QUFBQSxNQUNkO0FBRUEsVUFBSXBCLE1BQU1uRyxNQUFNbUcsR0FBR3NCLFFBQVEsQ0FBQyxHQUFHO0FBQzdCRCxrQkFBVTtBQUFBLE1BQ1osV0FBV3JCLE1BQU1BLEtBQUt4SSxRQUFPO0FBQzNCNkosa0JBQVU7QUFBQSxNQUNaO0FBRUEsVUFBSS9FLFFBQVEwRCxNQUFNLENBQUNuRyxNQUFNeUMsS0FBS2dGLFFBQVEsQ0FBQyxLQUFLLENBQUN6SCxNQUFNbUcsR0FBR3NCLFFBQVEsQ0FBQyxLQUFLaEYsT0FBTzBELElBQUk7QUFDN0VvQixvQkFBWTtBQUNaQyxrQkFBVTtBQUFBLE1BQ1o7QUFFQTVLLGdCQUFVLENBQUM4SyxnQkFBZ0I7QUFBQSxRQUN6QixHQUFHQTtBQUFBQSxRQUNIbEosV0FBVytJO0FBQUFBLFFBQ1g5SSxTQUFTK0k7QUFBQUEsTUFDWCxFQUFFO0FBRUYsYUFBTzNHO0FBQUFBLElBQ1QsQ0FBQztBQUVEUCx5QkFBcUIsQ0FBQyxFQUFFQyxRQUFRLElBQUk3QixRQUFRLEdBQUcsQ0FBQyxDQUFDO0FBRWpEOUIsY0FBVSxDQUFDMkUsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQzBFLElBQUksR0FBRyxHQUFHLEVBQUU7QUFBQSxFQUMvQztBQUVBLFFBQU0wQixlQUFlQSxNQUFNO0FBQ3pCLFVBQU1DLFlBQVksQ0FBQztBQUNuQixRQUFJLENBQUMxSixXQUFXRSxTQUFVd0osV0FBVXhKLFdBQVc7QUFDL0MsUUFBSUYsV0FBV1MsYUFBYSxZQUFZLENBQUNULFdBQVdVO0FBQ2xEZ0osZ0JBQVVqSixXQUFXO0FBQ3ZCL0IsY0FBVWdMLFNBQVM7QUFDbkIsV0FBT0MsT0FBT0MsS0FBS0YsU0FBUyxFQUFFRyxXQUFXO0FBQUEsRUFDM0M7QUFJQSxRQUFNQyxlQUFlLE9BQU94QixNQUFNO0FBQ2hDQSxNQUFFeUIsZUFBZTtBQUNqQixVQUFNQyxVQUFVUCxhQUFhO0FBQzdCLFFBQUksQ0FBQ08sUUFBUztBQUdkLFVBQU10RSxnQkFBZ0IsTUFBTXBDO0FBQUFBLE1BQzFCdEQsV0FBV0U7QUFBQUEsTUFDWEYsV0FBV007QUFBQUEsTUFDWE4sV0FBV087QUFBQUEsSUFDYjtBQUVBLFFBQUltRixjQUFjUixRQUFRO0FBQ3hCbEosVUFBSWlPLEtBQUs7QUFBQSxRQUNQM00sU0FBUztBQUFBLFFBQ1Q0TSxhQUFhO0FBQUEsUUFDYkMsV0FBVztBQUFBLE1BQ2IsQ0FBQztBQUNEO0FBQUEsSUFDRjtBQUdBLFFBQUlDLGtCQUFrQjtBQUN0QkEsc0JBQWtCckwsbUJBQ2QyRixXQUFXM0YsZ0JBQWdCLElBQzNCMkYsV0FBV3RELG9CQUFvQixDQUFDO0FBR3BDLFVBQU1pSixxQkFBcUJsSSxrQkFBa0JxQyxPQUFPLENBQUNDLEtBQUtULE1BQU07QUFDOUQsWUFBTXNHLE1BQU01RixXQUFXVixFQUFFeEQsTUFBTTtBQUMvQixhQUFPLENBQUNzQixNQUFNd0ksR0FBRyxJQUFJN0YsTUFBTTZGLE1BQU03RjtBQUFBQSxJQUNuQyxHQUFHLENBQUM7QUFFSjJGLHVCQUFtQkM7QUFHbkIsVUFBTUUsVUFBVTtBQUFBLE1BQ2RoSCxPQUFPdkQsV0FBV0U7QUFBQUEsTUFDbEJJLFdBQVdOLFdBQVdNO0FBQUFBLE1BQ3RCQyxTQUFTUCxXQUFXTztBQUFBQSxNQUNwQkksTUFBTVgsV0FBV1c7QUFBQUEsTUFDakJGLFVBQVVULFdBQVdTO0FBQUFBLE1BQ3JCQyxnQkFBZ0JWLFdBQVdVO0FBQUFBLE1BQzNCaUUsbUJBQW1CeUY7QUFBQUEsTUFDbkJ2RixnQkFBZ0IxQyxrQkFDYlUsT0FBTyxDQUFDbUIsTUFBTUEsRUFBRTNCLFVBQVUyQixFQUFFeEQsTUFBTSxFQUNsQ3dDLElBQUksQ0FBQ2dCLE9BQU87QUFBQSxRQUNYa0csYUFBYWxHLEVBQUUzQixPQUFPbUksS0FBSztBQUFBLFFBQzNCaEssUUFBUXlDLE9BQU9lLEVBQUV4RCxNQUFNO0FBQUEsTUFDekIsRUFBRTtBQUFBLElBQ047QUFFQSxRQUFJO0FBQ0ZsQyxtQkFBYSxJQUFJO0FBQ2pCLFlBQU02SCxNQUFNLE1BQU16TCxJQUFJMEwsS0FBSyxnQkFBZ0JtRSxPQUFPO0FBRWxEdk8sVUFBSWlPLEtBQUs7QUFBQSxRQUNQM00sU0FBUztBQUFBLFFBQ1Q0TSxhQUFhL0QsSUFBSXJDLEtBQUt4RyxXQUFXO0FBQUEsUUFDakM2TSxXQUFXO0FBQUEsTUFDYixDQUFDO0FBRUQ3Tix5QkFBbUIsS0FBSztBQUN4Qm1PLGdCQUFVO0FBQ1Y3TCxrQkFBWSxDQUFDMEwsUUFBUUEsTUFBTSxDQUFDO0FBQzVCNUMsMEJBQW9CO0FBQUEsSUFDdEIsU0FBU3RDLE9BQU87QUFDZCxZQUFNOUgsVUFDSjhILE1BQU01QixVQUFVTSxNQUFNc0IsU0FDdEJBLE1BQU01QixVQUFVTSxNQUFNeEcsV0FDdEI4SCxNQUFNOUgsV0FDTjtBQUNGdEIsVUFBSWlPLEtBQUs7QUFBQSxRQUNQM00sU0FBUztBQUFBLFFBQ1Q0TSxhQUFhNU07QUFBQUEsUUFDYjZNLFdBQVc7QUFBQSxNQUNiLENBQUM7QUFBQSxJQUNILFVBQUM7QUFDQzdMLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFHQSxRQUFNbU0sWUFBWUEsTUFBTTtBQUN0QnJPLGdCQUFZLE9BQU87QUFDbkIsVUFBTXFELFNBQVEsb0JBQUlDLEtBQUs7QUFDdkIsVUFBTUMsZ0JBQWUsR0FBR0YsT0FBTUcsWUFBWSxDQUFDLElBQUlDLE9BQU9KLE9BQU1LLFNBQVMsSUFBSSxDQUFDLEVBQUVDLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFDNUZqRCxxQkFBaUI2QyxhQUFZO0FBRTdCTSxrQkFBYztBQUFBLE1BQ1pDLFVBQVU7QUFBQSxNQUNWQyxVQUFVVixPQUFNVyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxNQUMxQ0MsV0FBVztBQUFBLE1BQ1hDLFNBQVM7QUFBQSxNQUNUQyxRQUFRO0FBQUEsTUFDUkMsVUFBVTtBQUFBLE1BQ1ZDLGdCQUFnQjtBQUFBLE1BQ2hCQyxNQUFNO0FBQUEsTUFDTkMsU0FBUzdFO0FBQUFBLE1BQ1Q4RSxZQUFZcEU7QUFBQUEsSUFDZCxDQUFDO0FBRURzRSx1QkFBbUIsRUFBRUMsY0FBYyxJQUFJQyxRQUFRLEdBQUcsQ0FBQztBQUNuREksd0JBQW9CLEVBQUU7QUFDdEJyQyx3QkFBb0IsRUFBRTtBQUV0Qm9ELHlCQUFxQixDQUFDLEVBQUVDLFFBQVEsSUFBSTdCLFFBQVEsR0FBRyxDQUFDLENBQUM7QUFDakRlLG1CQUFlLE1BQU07QUFDckJFLHVCQUFtQixNQUFNO0FBQ3pCM0MsZ0NBQTRCLElBQUk7QUFDaENRLDJCQUF1QixLQUFLO0FBQzVCRSx1Q0FBbUMsS0FBSztBQUFBLEVBQzFDO0FBRUEsUUFBTWtMLGdCQUFnQjtBQUFBLElBQ3BCLEVBQUVDLEtBQUssTUFBTUMsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxZQUFZQyxRQUFRLFdBQVc7QUFBQSxJQUN0QyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsUUFBUTtBQUFBLElBQ3JDLEVBQUVELEtBQUsscUJBQXFCQyxRQUFRLHdCQUF3QjtBQUFBLElBQzVELEVBQUVELEtBQUssa0JBQWtCQyxRQUFRLDBCQUEwQjtBQUFBLElBQzNELEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLDBCQUEwQjtBQUFBLElBQ3pELEVBQUVELEtBQUssWUFBWUMsUUFBUSxlQUFlO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFRCxLQUFLLGFBQWFDLFFBQVEsWUFBWTtBQUFBLElBQ3hDLEVBQUVELEtBQUssV0FBV0MsUUFBUSxVQUFVO0FBQUEsSUFDcEMsRUFBRUQsS0FBSyxRQUFRQyxRQUFRLE9BQU87QUFBQSxJQUM5QixFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFNBQ0UsbUNBQ0czTztBQUFBQTtBQUFBQSxJQUNELHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsNkJBQUMsVUFBTyxZQUFZLFFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUI7QUFBQSxNQUN6Qix1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BQ1I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU1rQixZQUFZSztBQUFBQSxVQUNsQixXQUFXTCxZQUFZRTtBQUFBQSxVQUN2QixTQUFTRixZQUFZRztBQUFBQSxVQUNyQixVQUFVSCxZQUFZSTtBQUFBQTtBQUFBQSxRQUp4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJaUM7QUFBQSxNQUdqQyx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMEJBQ1o7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsbUNBQW1DeEIsc0JBQVk4TyxZQUFZLEtBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZFO0FBQUEsWUFBTztBQUFBLGVBRHRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFdBQVEsT0FBTSxzQkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNO0FBQ2J2TyxtQ0FBbUIsSUFBSTtBQUN2Qm1PLDBCQUFVO0FBQUEsY0FDWjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsUUFBTyxpQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0I7QUFBQSxnQkFBTztBQUFBO0FBQUE7QUFBQSxZQVBqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxhQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDREQUEyRCwrQkFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0Y7QUFBQSxVQUN2RnRNLGVBQWUwTCxTQUFTLElBQ3ZCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNMUw7QUFBQUEsY0FDTixTQUFTdU07QUFBQUEsY0FDVCxpQkFBZ0I7QUFBQSxjQUNoQixrQkFBa0I7QUFBQTtBQUFBLFlBSnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUl3QyxJQUd4Qyx1QkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDO0FBQUEsY0FDQSxNQUFLO0FBQUEsY0FDTCxTQUFTdk0sZUFBZTBMLFdBQVc7QUFBQTtBQUFBLFlBSHJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUd1QyxLQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsYUFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtCQTtBQUFBLFdBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQ0E7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFXeE47QUFBQUEsVUFDWCxTQUFTLE1BQU07QUFDYkMsK0JBQW1CLEtBQUs7QUFDeEJtTyxzQkFBVTtBQUFBLFVBQ1o7QUFBQSxVQUVBLGlDQUFDLFNBQUksV0FBVSw4RkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSx1Q0FDYixpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUseUdBQ2IsaUNBQUMsU0FBSSxXQUFVLHNCQUFxQixNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQzVFLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUsbVNBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9XLEtBRHRXO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsUUFBRyxXQUFVLG1DQUFrQyw4QkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEQ7QUFBQSxnQkFDOUQsdUJBQUMsT0FBRSxXQUFVLHlCQUF3QiwrREFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0Y7QUFBQSxtQkFGdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUEsWUFFQSx1QkFBQyxVQUFLLFdBQVUsYUFBWSxVQUFVWCxjQUNwQztBQUFBLHFDQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLGtCQUNoRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEscUJBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0Esa0JBQWlCO0FBQUEsb0JBQ2pCLGNBQWMsQ0FBQ2dCLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUFTQyxZQUFZLEVBQUVDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLG9CQUU1RCxPQUFPakwsV0FBV0UsWUFBWWlMO0FBQUFBLG9CQUM5QixVQUFVLENBQUN6SSxVQUFVO0FBQ25CaEUsZ0NBQVUsQ0FBQzJFLFVBQVUsRUFBRSxHQUFHQSxNQUFNbkQsVUFBVSxHQUFHLEVBQUU7QUFDL0NELG9DQUFjLENBQUNvRCxVQUFVO0FBQUEsd0JBQ3ZCLEdBQUdBO0FBQUFBLHdCQUNIbkQsVUFBVXdDO0FBQUFBLHdCQUNWbEMsUUFBUTtBQUFBLHNCQUNWLEVBQUU7QUFDRk8seUNBQW1CLEVBQUVDLGNBQWMsSUFBSUMsUUFBUSxHQUFHLENBQUM7QUFDbkRJLDBDQUFvQixFQUFFO0FBQ3RCckMsMENBQW9CLEVBQUU7QUFFdEJvRCwyQ0FBcUIsQ0FBQyxFQUFFQyxRQUFRLElBQUk3QixRQUFRLEdBQUcsQ0FBQyxDQUFDO0FBQ2pEZSxxQ0FBZSxNQUFNO0FBQ3JCRSx5Q0FBbUIsTUFBTTtBQUN6QnFGLDJDQUFxQnBFLEtBQUs7QUFBQSxvQkFDNUI7QUFBQSxvQkFFQ3pFLGlCQUFPK0U7QUFBQUEsc0JBQUksQ0FBQ29JLFVBQ1gsdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU1qSCxLQUN6QyxhQUFHaUgsTUFBTXJELElBQUksTUFBTXFELE1BQU1DLFlBQVksTUFEcEJELE1BQU1qSCxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBLGtCQTlCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBK0JBO0FBQUEsZ0JBQ0MxRixPQUFPeUIsWUFDTix1QkFBQyxPQUFFLFdBQVUscURBQ1g7QUFBQSx5Q0FBQyxVQUFLLGlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQU87QUFBQSxrQkFBTztBQUFBLGtCQUFFekIsT0FBT3lCO0FBQUFBLHFCQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBdkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeUNBO0FBQUEsY0FFQ1ksZ0JBQWdCRSxnQkFDZixtQ0FDRTtBQUFBLHVDQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLDJDQUFDLE9BQUUsV0FBVSxxRUFBb0UsNEJBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTZGO0FBQUEsb0JBQzdGLHVCQUFDLE9BQUUsV0FBVSxtQ0FBbUNGLDJCQUFpQkUsZ0JBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQThFO0FBQUEsdUJBRmhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSwyQ0FBQyxPQUFFLFdBQVUscUVBQW9FLDhCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErRjtBQUFBLG9CQUMvRix1QkFBQyxPQUFFLFdBQVUsb0NBQW1DO0FBQUE7QUFBQSxzQkFBRUYsaUJBQWlCRztBQUFBQSx5QkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMEU7QUFBQSx1QkFGNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLHFCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBU0E7QUFBQSxnQkFLQSx1QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsb0RBQ1o7QUFBQSwyQ0FBQyxvQkFBaUIsV0FBVSwwQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBa0Q7QUFBQSxvQkFBRztBQUFBLHVCQUR2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLDJDQUNmO0FBQUE7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLFdBQVU7QUFBQSwwQkFDVixTQUFTOUUsYUFBYTtBQUFBLDBCQUN0QixVQUFVLE1BQU1DLFlBQVksT0FBTztBQUFBO0FBQUEsd0JBSnJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFJdUM7QUFBQSxzQkFFdkMsdUJBQUMsVUFBSyxXQUFVLDBDQUF5QyxxQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBOEQ7QUFBQSx5QkFQaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFRQTtBQUFBLG9CQUNBLHVCQUFDLFdBQU0sV0FBVSwyQ0FDZjtBQUFBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxXQUFVO0FBQUEsMEJBQ1YsU0FBU0QsYUFBYTtBQUFBLDBCQUN0QixVQUFVLE1BQU1DLFlBQVksUUFBUTtBQUFBO0FBQUEsd0JBSnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFJd0M7QUFBQSxzQkFFeEMsdUJBQUMsVUFBSyxXQUFVLDBDQUF5QyxpQ0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBMEU7QUFBQSx5QkFQNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFRQTtBQUFBLHVCQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQW1CQTtBQUFBLGtCQUdDRCxhQUFhLFdBQ1osdUJBQUMsU0FDQztBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTRFO0FBQUEsb0JBQzVFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxPQUFPVTtBQUFBQSx3QkFDUCxVQUFVLENBQUN5TCxNQUFNO0FBQ2Z4TCwyQ0FBaUJ3TCxFQUFFM0ssT0FBTytFLEtBQUs7QUFDL0JOLCtDQUFxQixDQUFDLEVBQUVDLFFBQVEsSUFBSTdCLFFBQVEsR0FBRyxDQUFDLENBQUM7QUFBQSx3QkFDbkQ7QUFBQSx3QkFFQSxXQUFVO0FBQUE7QUFBQSxzQkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBUTJIO0FBQUEsdUJBVjdIO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBWUE7QUFBQSxrQkFJRHJFLGFBQWEsWUFDWix1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSwyQ0FBQyxTQUNDO0FBQUEsNkNBQUMsV0FBTSxXQUFVLGdEQUErQyx5QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBeUU7QUFBQSxzQkFDekU7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLE1BQUs7QUFBQSwwQkFDTCxPQUFPNkQsV0FBV007QUFBQUEsMEJBQ2xCLE1BQUssb0JBQUlaLEtBQUssR0FBRVUsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsMEJBQzFDLFVBQVUrSTtBQUFBQSwwQkFDVixXQUFVO0FBQUE7QUFBQSx3QkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTWtLO0FBQUEsc0JBRWpLM0ssT0FBTzZCLGFBQ04sdUJBQUMsT0FBRSxXQUFVLHFEQUNYO0FBQUEsK0NBQUMsVUFBSyxpQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFPO0FBQUEsd0JBQU87QUFBQSx3QkFBRTdCLE9BQU82QjtBQUFBQSwyQkFEekI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBZUE7QUFBQSxvQkFDQSx1QkFBQyxTQUNDO0FBQUEsNkNBQUMsV0FBTSxXQUFVLGdEQUErQyx1QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBdUU7QUFBQSxzQkFDdkU7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLE1BQUs7QUFBQSwwQkFDTCxPQUFPTixXQUFXTztBQUFBQSwwQkFDbEIsTUFBSyxvQkFBSWIsS0FBSyxHQUFFVSxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSwwQkFDMUMsVUFBVStJO0FBQUFBLDBCQUNWLFdBQVU7QUFBQTtBQUFBLHdCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFNa0s7QUFBQSxzQkFFakszSyxPQUFPOEIsV0FDTix1QkFBQyxPQUFFLFdBQVUscURBQ1g7QUFBQSwrQ0FBQyxVQUFLLGlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQU87QUFBQSx3QkFBTztBQUFBLHdCQUFFOUIsT0FBTzhCO0FBQUFBLDJCQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBYko7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFlQTtBQUFBLHVCQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWlDQTtBQUFBLGtCQUlEUCxXQUFXTSxhQUFhTixXQUFXTyxXQUNsQyx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFdBQVU7QUFBQSxzQkFDVixTQUFTLE1BQU07QUFDYiw0QkFDRVAsV0FBV0UsWUFDWEYsV0FBV00sYUFDWE4sV0FBV08sV0FDWE8sZ0JBQWdCRyxRQUNoQjtBQUNBLGdDQUFNcUssS0FBSzVKLFdBQVcxQixXQUFXTSxTQUFTO0FBQzFDLGdDQUFNaUwsS0FBSzdKLFdBQVcxQixXQUFXTyxPQUFPO0FBQ3hDK0Usa0RBQXdCZ0csSUFBSUMsSUFBSXpLLGdCQUFnQkcsUUFBUWpCLFdBQVdFLFFBQVE7QUFBQSx3QkFFN0U7QUFBQSxzQkFDRjtBQUFBLHNCQUFFO0FBQUE7QUFBQSxvQkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBa0JBLEtBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBb0JBO0FBQUEscUJBdkdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBeUdBO0FBQUEsZ0JBRUNiLHVCQUF1QixDQUFDRSxtQ0FDdkIsdUJBQUMsU0FBSSxXQUFVLDZEQUNiLGlDQUFDLFNBQUksV0FBVSxvQkFDYjtBQUFBLHlDQUFDLHNCQUFtQixXQUFVLCtCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RDtBQUFBLGtCQUN6RCx1QkFBQyxTQUNDO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHVDQUFzQyxtQ0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBc0U7QUFBQSxvQkFDdEUsdUJBQUMsT0FBRSxXQUFVLGdDQUErQiw4REFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMEY7QUFBQSxvQkFFMUYsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsNkNBQUMsU0FBSSxXQUFVLG9EQUNiO0FBQUEsK0NBQUMsT0FBRSxXQUFVLHVDQUFzQyw2QkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBZ0U7QUFBQSx3QkFDaEUsdUJBQUMsT0FBRSxXQUFVLHFDQUFvQztBQUFBO0FBQUEsMEJBQUV0QywyQkFBMkI7QUFBQSw2QkFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBb0Y7QUFBQSwyQkFGdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksV0FBVSxvREFDYjtBQUFBLCtDQUFDLE9BQUUsV0FBVSx1Q0FBc0MsNEJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQStEO0FBQUEsd0JBQy9ELHVCQUFDLE9BQUUsV0FBVSxxQ0FBb0M7QUFBQTtBQUFBLDBCQUFFcUU7QUFBQUEsNkJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQStEO0FBQUEsMkJBRmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBR0E7QUFBQSxzQkFDQSx1QkFBQyxTQUFJLFdBQVUsb0RBQ2I7QUFBQSwrQ0FBQyxPQUFFLFdBQVUsdUNBQXNDLDhCQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFpRTtBQUFBLHdCQUNqRSx1QkFBQyxPQUFFLFdBQVUscUNBQW9DO0FBQUE7QUFBQSwwQkFBRXZFLHlCQUF5QjtBQUFBLDZCQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFtRjtBQUFBLDJCQUZyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEseUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFhQTtBQUFBLG9CQUVBLHVCQUFDLFNBQUksV0FBVSx3Q0FDYixpQ0FBQyxPQUFFLFdBQVUseUNBQXdDO0FBQUE7QUFBQSxzQkFBZ0IySCxXQUFXcEQsV0FBVyxLQUFLb0QsV0FBVzNILHFCQUFxQixLQUFLO0FBQUEseUJBQXJJO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXdJLEtBRDFJO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFzQkE7QUFBQSxxQkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF5QkEsS0ExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkEyQkE7QUFBQSxnQkFJRHFFLG9CQUFvQixDQUFDL0IsdUJBQ3BCLHVCQUFDLFNBQUksV0FBVSxtR0FDYjtBQUFBLHlDQUFDLE9BQUUsV0FBVSx1RUFBc0Usb0NBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVHO0FBQUEsa0JBQ3ZHLHVCQUFDLE9BQUUsV0FBVSxzQ0FBcUM7QUFBQTtBQUFBLG9CQUFFK0I7QUFBQUEsdUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFFO0FBQUEscUJBRnZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFHRHZDLDRCQUE0QixDQUFDUSx1QkFDNUIsdUJBQUMsU0FBSSxXQUFVLHlFQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLG1GQUNiLGlDQUFDLFFBQUcsV0FBVSx1REFDWjtBQUFBLDJDQUFDLFNBQUksV0FBVSwwQkFBeUIsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUNoRixpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQVksS0FBSSxHQUFFLDZFQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE4SSxLQURoSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0NBLHVCQUF1QkUsa0NBQWtDLDZCQUE2QjtBQUFBLHVCQUp6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFPQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSxzREFDYjtBQUFBLDZDQUFDLE9BQUUsV0FBVSw0Q0FBMkMsNkJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXFFO0FBQUEsc0JBQ3JFLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLCtDQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLGlEQUFDLE9BQUUsV0FBVSxxQ0FBb0MsMkJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQTREO0FBQUEsMEJBQzVELHVCQUFDLE9BQUUsV0FBVSx3Q0FDVlYsb0NBQTBCK0csWUFBWUMscUJBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSw2QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUtBO0FBQUEsd0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEsaURBQUMsT0FBRSxXQUFVLHFDQUFvQyw4QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBK0Q7QUFBQSwwQkFDL0QsdUJBQUMsT0FBRSxXQUFVLHdDQUNWaEgsb0NBQTBCK0csWUFBWUUsa0JBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSw2QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUtBO0FBQUEsd0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEsaURBQUMsT0FBRSxXQUFVLHFDQUFvQyw2QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBOEQ7QUFBQSwwQkFDOUQsdUJBQUMsT0FBRSxXQUFVLHdDQUNWakgsb0NBQTBCK0csWUFBWUcseUJBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSw2QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUtBO0FBQUEsMkJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBbUJBO0FBQUEseUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBc0JBO0FBQUEsb0JBQ0EsdUJBQUMsU0FDQztBQUFBLDZDQUFDLE9BQUUsV0FBVSw0Q0FBMkMsK0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXVFO0FBQUEsc0JBQ3ZFLHVCQUFDLFNBQUksV0FBVSxzREFDYixpQ0FBQyxXQUFNLFdBQVUsa0JBQ2Y7QUFBQSwrQ0FBQyxXQUFNLFdBQVUseUVBQ2YsaUNBQUMsUUFDQztBQUFBLGlEQUFDLFFBQUcsV0FBVSw2REFBNEQscUJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQStFO0FBQUEsMEJBQy9FLHVCQUFDLFFBQUcsV0FBVSw2REFBNEQsd0JBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWtGO0FBQUEsMEJBQ2xGLHVCQUFDLFFBQUcsV0FBVSw2REFBNEQsMkJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQXFGO0FBQUEsMEJBQ3JGLHVCQUFDLFFBQUcsV0FBVSw2REFBNEQsMEJBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQW9GO0FBQUEsMEJBQ3BGLHVCQUFDLFFBQUcsV0FBVSw4REFBNkQsNkJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQXdGO0FBQUEsNkJBTDFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQVFBO0FBQUEsd0JBQ0EsdUJBQUMsV0FBTSxXQUFVLGlCQUNkbEgsb0NBQTBCK0csWUFBWUksa0JBQWtCaEQ7QUFBQUEsMEJBQUksQ0FBQ3dJLEdBQUd6SSxNQUMvRCx1QkFBQyxRQUFXLFdBQVUsK0VBQ3BCO0FBQUEsbURBQUMsUUFBRyxXQUFVLHVDQUF1Q3lJLFlBQUV4SixTQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUE2RDtBQUFBLDRCQUM3RCx1QkFBQyxRQUFHLFdBQVUsYUFBYXdKLFlBQUUxRixrQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBNEM7QUFBQSw0QkFDNUMsdUJBQUMsUUFBRyxXQUFVLGFBQWEwRixZQUFFQyxlQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUF5QztBQUFBLDRCQUN6Qyx1QkFBQyxRQUFHLFdBQVUsaURBQWdEO0FBQUE7QUFBQSw4QkFDMURELEVBQUVFLFdBQVdsSCxPQUFPLENBQUNDLEtBQUs1QyxNQUFNNEMsTUFBTUMsV0FBVzdDLEVBQUVyQixVQUFVLENBQUMsR0FBRyxDQUFDLEVBQUVtRixRQUFRLENBQUM7QUFBQSxpQ0FEakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FFQTtBQUFBLDRCQUNBLHVCQUFDLFFBQUcsV0FBVSxvREFBbUQ7QUFBQTtBQUFBLDhCQUM3RDZGLEVBQUVHLGdCQUFnQkgsRUFBRUcsY0FBY2hHLFFBQVEsQ0FBQyxJQUFJO0FBQUEsaUNBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQSwrQkFUTzVDLEdBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FVQTtBQUFBLHdCQUNELEtBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFjQTtBQUFBLDJCQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQXlCQSxLQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQTJCQTtBQUFBLHlCQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQThCQTtBQUFBLG9CQUNDbEUsMEJBQTBCK00saUJBQWlCL0UsU0FBU2dELFNBQVMsS0FDNUQsdUJBQUMsU0FDQztBQUFBLDZDQUFDLE9BQUUsV0FBVSw0Q0FBMkMsMEJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWtFO0FBQUEsc0JBQ2xFLHVCQUFDLFNBQUksV0FBVSw0REFDWmhMLG9DQUEwQitNLGdCQUFnQi9FLFFBQVE3RDtBQUFBQSx3QkFBSSxDQUFDbkIsR0FBR2tCLE1BQ3pELHVCQUFDLFNBQVksV0FBVSxnRkFDckI7QUFBQSxpREFBQyxVQUFLLFdBQVUseUJBQXlCbEI7QUFBQUEsOEJBQUVnSztBQUFBQSw0QkFBZWhLLEVBQUVsQixRQUFRLEtBQUtrQixFQUFFbEIsSUFBSTtBQUFBLCtCQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFtRjtBQUFBLDBCQUNuRix1QkFBQyxVQUFLLFdBQVUsOEJBQTZCO0FBQUE7QUFBQSw0QkFBRytELFdBQVc3QyxFQUFFckIsTUFBTSxFQUFFbUYsUUFBUSxDQUFDO0FBQUEsK0JBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWdGO0FBQUEsNkJBRnhFNUMsR0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUdBO0FBQUEsc0JBQ0QsS0FOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQU9BO0FBQUEseUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFVQTtBQUFBLHVCQWxFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQW9FQTtBQUFBLHFCQTdFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQThFQTtBQUFBLGdCQUdEM0Isb0JBQW9CLENBQUMvQix1QkFDcEIsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLHNEQUNiO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHNFQUFxRSw0QkFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOEY7QUFBQSxvQkFDOUYsdUJBQUMsT0FBRSxXQUFVLHFDQUFvQztBQUFBO0FBQUEsc0JBQUVpQztBQUFBQSx5QkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0Q7QUFBQSx1QkFGakU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSx3REFDYjtBQUFBLDJDQUFDLE9BQUUsV0FBVSx1RUFBc0UseUJBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTRGO0FBQUEsb0JBQzVGLHVCQUFDLE9BQUUsV0FBVSxzQ0FBcUM7QUFBQTtBQUFBLHNCQUFFRTtBQUFBQSx5QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0U7QUFBQSx1QkFGdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLHFCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBU0E7QUFBQSxnQkFHREosb0JBQW9CLENBQUMvQix1QkFDcEIsdUJBQUMsU0FBSSxXQUFVLGtFQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGtEQUFpRCxrQ0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxNQUFLO0FBQUEsc0JBQ0wsS0FBSTtBQUFBLHNCQUNKLE9BQU9OO0FBQUFBLHNCQUNQLFVBQVUsQ0FBQ3VKLE1BQU10SixvQkFBb0JzSixFQUFFM0ssT0FBTytFLEtBQUs7QUFBQSxzQkFDbkQsV0FBVyxzQ0FBc0NqRSxPQUFPa0csb0JBQW9CLG1CQUFtQix5Q0FBeUM7QUFBQSxzQkFFeEksYUFBWTtBQUFBO0FBQUEsb0JBUmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVFvQztBQUFBLGtCQUVuQ2xHLE9BQU9rRyxxQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCbEcsaUJBQU9rRyxxQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUU7QUFBQSxrQkFFckUsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QjtBQUFBO0FBQUEsb0JBQ0R2RDtBQUFBQSxvQkFBaUI7QUFBQSx1QkFEMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW9CQTtBQUFBLGdCQUlEQSxvQkFBb0IsQ0FBQy9CLHVCQUNwQix1QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsb0RBQW1ELG1DQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBRUM4QyxrQkFBa0JhO0FBQUFBLG9CQUFJLENBQUM4SSxNQUFNdEosVUFDNUIsdUJBQUMsU0FBZ0IsV0FBVSwyREFDekI7QUFBQSw2Q0FBQyxTQUNDO0FBQUEsK0NBQUMsV0FBTSxXQUFVLGdEQUErQyxtQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHdCQUNBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE1BQUs7QUFBQSw0QkFDTCxhQUFZO0FBQUEsNEJBQ1osT0FBT3NKLEtBQUt6SjtBQUFBQSw0QkFDWixVQUFVLENBQUNpRyxNQUFNL0YseUJBQXlCQyxPQUFPLFVBQVU4RixFQUFFM0ssT0FBTytFLEtBQUs7QUFBQSw0QkFDekUsV0FBVTtBQUFBO0FBQUEsMEJBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUtzSDtBQUFBLDJCQVR4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQVdBO0FBQUEsc0JBRUEsdUJBQUMsU0FDQztBQUFBLCtDQUFDLFdBQU0sV0FBVSxnREFBK0Msa0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSx3QkFDQTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxNQUFLO0FBQUEsNEJBQ0wsTUFBSztBQUFBLDRCQUNMLEtBQUk7QUFBQSw0QkFDSixhQUFZO0FBQUEsNEJBQ1osT0FBT29KLEtBQUt0TDtBQUFBQSw0QkFDWixVQUFVLENBQUM4SCxNQUFNL0YseUJBQXlCQyxPQUFPLFVBQVU4RixFQUFFM0ssT0FBTytFLEtBQUs7QUFBQSw0QkFDekUsV0FBVTtBQUFBO0FBQUEsMEJBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQU9zSDtBQUFBLDJCQVh4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQWFBO0FBQUEsc0JBRUEsdUJBQUMsU0FBSSxXQUFVLGtCQUNaRixrQkFBUSxLQUNQO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxTQUFTLE1BQU1JLHlCQUF5QkosS0FBSztBQUFBLDBCQUM3QyxXQUFVO0FBQUEsMEJBQXlEO0FBQUE7QUFBQSx3QkFIckU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQU1BLEtBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFVQTtBQUFBLHlCQXZDUUEsT0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQXdDQTtBQUFBLGtCQUNEO0FBQUEsa0JBRUQsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVNGO0FBQUFBLHNCQUNULFdBQVU7QUFBQSxzQkFBb0c7QUFBQTtBQUFBLG9CQUhoSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVFBO0FBQUEsa0JBRUEsdUJBQUMsT0FBRSxXQUFVLDhCQUE2Qiw4RkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQTdERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQThEQTtBQUFBLGdCQU1EbEIsb0JBQ0MsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLDZEQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGtEQUFpRCw0QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT3BCLFdBQVdHO0FBQUFBLHdCQUNsQixVQUFVaUo7QUFBQUEsd0JBQ1YsV0FBVTtBQUFBLHdCQUNWLFVBQVUsQ0FBQzdNO0FBQUFBO0FBQUFBLHNCQU5iO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNMkI7QUFBQSx1QkFWN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFZQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxrREFBaUQsNEJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUFPeUQsV0FBV1M7QUFBQUEsd0JBQ2xCLFVBQVUsQ0FBQ2lDLFVBQVV6QyxjQUFjLEVBQUUsR0FBR0QsWUFBWVMsVUFBVWlDLE1BQU0sQ0FBQztBQUFBLHdCQUNyRSxXQUFVO0FBQUEsd0JBRVY7QUFBQSxpREFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFFBQU8sb0JBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWdDO0FBQUEsMEJBQ2hDLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sVUFBUywrQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBNkM7QUFBQSwwQkFDNUNuRyxpQkFDQyxtQ0FDRTtBQUFBLG1EQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sVUFBUyxzQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBb0M7QUFBQSw0QkFDcEMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxpQkFBZ0IsNkJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQWtEO0FBQUEsK0JBRnBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBR0E7QUFBQTtBQUFBO0FBQUEsc0JBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQWFBO0FBQUEsdUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBa0JBO0FBQUEscUJBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaUNBO0FBQUEsZ0JBR0Q2RSxvQkFBb0JwQixXQUFXUyxhQUFhLFlBQzNDLHVCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxrREFBaUQsOEJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUFPVCxXQUFXVTtBQUFBQSxzQkFDbEIsVUFBVSxDQUFDNEgsTUFBTXJJLGNBQWMsRUFBRSxHQUFHRCxZQUFZVSxnQkFBZ0I0SCxFQUFFM0ssT0FBTytFLE1BQU0sQ0FBQztBQUFBLHNCQUNoRixXQUFXLHNDQUFzQ2pFLE9BQU9pQyxpQkFBaUIsbUJBQW1CLHlDQUF5QztBQUFBLHNCQUVySSxhQUFZO0FBQUE7QUFBQSxvQkFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS29DO0FBQUEsa0JBRW5DakMsT0FBT2lDLGtCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJqQyxpQkFBT2lDLGtCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnRTtBQUFBLHFCQVpwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWNBO0FBQUEsZ0JBR0RVLG9CQUNDLHVCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxrREFBaUQsZ0NBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUFPcEIsV0FBV1c7QUFBQUEsc0JBQ2xCLFVBQVUsQ0FBQzJILE1BQU1ySSxjQUFjLEVBQUUsR0FBR0QsWUFBWVcsTUFBTTJILEVBQUUzSyxPQUFPK0UsTUFBTSxDQUFDO0FBQUEsc0JBQ3RFLFdBQVcsc0NBQXNDakUsT0FBT2tDLE9BQU8sbUJBQW1CLHlDQUF5QztBQUFBLHNCQUUzSCxNQUFLO0FBQUEsc0JBQ0wsYUFBWTtBQUFBO0FBQUEsb0JBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU1tRDtBQUFBLGtCQUVuRCx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLDhEQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFlQTtBQUFBLGdCQUdEUyxvQkFDQyx1QkFBQyxTQUFJLFdBQVUsbUdBQ2I7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsdUVBQXNFLDRCQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErRjtBQUFBLGtCQUMvRix1QkFBQyxPQUFFLFdBQVUsNkRBQ1g7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsb0dBQ1o3QyxxQkFBV3dOLE9BQU8sQ0FBQyxFQUFFbEIsWUFBWSxLQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0N0TTtBQUFBQSx1QkFKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEscUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFRQTtBQUFBLGdCQUlGLHVCQUFDLFNBQUksV0FBVSw0REFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxTQUFTLE1BQU07QUFDYmpDLDJDQUFtQixLQUFLO0FBQ3hCbU8sa0NBQVU7QUFBQSxzQkFDWjtBQUFBLHNCQUNBLFdBQVU7QUFBQSxzQkFBZ0c7QUFBQTtBQUFBLG9CQU41RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBU0E7QUFBQSxrQkFDQyxDQUFDcEwsdUJBQXdCO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUN6QixNQUFLO0FBQUEsc0JBQ0wsVUFBVWhCO0FBQUFBLHNCQUNWLFdBQVcsbUVBQW1FQSxZQUMxRSxtQ0FDQSxtQ0FBbUM7QUFBQSxzQkFHdENBLHNCQUNDLHVCQUFDLFVBQUssV0FBVSxxQkFDZDtBQUFBLCtDQUFDLFNBQUksV0FBVSw4Q0FBNkMsTUFBSyxRQUFPLFNBQVEsYUFDOUU7QUFBQSxpREFBQyxZQUFPLFdBQVUsY0FBYSxJQUFHLE1BQUssSUFBRyxNQUFLLEdBQUUsTUFBSyxRQUFPLGdCQUFlLGFBQVksT0FBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBNEY7QUFBQSwwQkFDNUYsdUJBQUMsVUFBSyxXQUFVLGNBQWEsTUFBSyxnQkFBZSxHQUFFLHFIQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFxSztBQUFBLDZCQUZ2SztBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUdBO0FBQUEsd0JBQU07QUFBQSwyQkFKUjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQU1BLElBRUE7QUFBQTtBQUFBLG9CQWpCc0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQW1CMUI7QUFBQSxxQkE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkErQkE7QUFBQSxtQkFwZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxZEE7QUFBQSxpQkFsZ0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb2dCQTtBQUFBLGVBbmhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9oQkE7QUFBQTtBQUFBLFFBM2hCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUE0aEJBO0FBQUEsTUFHQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBV1k7QUFBQUEsVUFDWCxTQUFTLE1BQU07QUFDYkMseUJBQWEsS0FBSztBQUNsQkUsNkJBQWlCLElBQUk7QUFBQSxVQUN2QjtBQUFBLFVBQ0EsUUFBUUQ7QUFBQUEsVUFDUixlQUFlLE1BQU07QUFDbkJELHlCQUFhLEtBQUs7QUFDbEJFLDZCQUFpQixJQUFJO0FBQ3JCUix3QkFBWSxDQUFBeUUsU0FBUUEsT0FBTyxDQUFDO0FBQzVCcUUsZ0NBQW9CO0FBQUEsVUFDdEI7QUFBQTtBQUFBLFFBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BWUk7QUFBQSxTQTVsQk47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThsQkE7QUFBQSxPQWhtQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWltQkE7QUFFSjtBQUFFNUwsR0E5dENJRCxjQUFZO0FBQUEsVUFFYVgsYUFBYWdCLGVBQWU7QUFBQTtBQUFBOFAsS0FGckRuUTtBQWd1Q04sZUFBZUE7QUFBYSxJQUFBbVE7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiU2lkZWJhciIsIkFQSSIsIk1vZGFsIiwiRGF0YVRhYmxlIiwiQ3VzdG9tQWxlcnQiLCJDaXJjdWxhckxvYWRlciIsIk5hdmJhciIsIlNlbGVjdCIsIlRvb2x0aXAiLCJub3RpZmljYXRpb24iLCJEcm9wZG93biIsIklucHV0IiwiU2V0dGluZ1NpZGViYXIiLCJTYWxhcnlTbGlwUHJpbnQiLCJJb01kTW9yZSIsIkVkaXRTYWxhcnlNb2RhbCIsIkRvbGxhck91dGxpbmVkIiwiQ2FsZW5kYXJPdXRsaW5lZCIsIkVkaXRPdXRsaW5lZCIsIkluZm9DaXJjbGVPdXRsaW5lZCIsIlBheW91dFNhbGFyeSIsIl9zIiwicGF5bWVudEZvciIsImFwaSIsImNvbnRleHRIb2xkZXIiLCJ1c2VOb3RpZmljYXRpb24iLCJkYXRlTW9kZSIsInNldERhdGVNb2RlIiwic2hvd1NhbGFyeU1vZGFsIiwic2V0U2hvd1NhbGFyeU1vZGFsIiwibW9kaWZ5UGF5bWVudCIsInNldE1vZGlmeVBheW1lbnQiLCJhZG1pbklkIiwic2V0QWRtaW5JZCIsImFic2VudCIsInNldEFic2VudCIsInNlbGVjdGVkTW9udGgiLCJzZXRTZWxlY3RlZE1vbnRoIiwiZXhpc3RpbmdPdGhlclBheW1lbnRzIiwic2V0SXNFeGlzdGluZ090aGVyUGF5bWVudHMiLCJhbHJlYWR5UGFpZFNhbGFyeUFtb3VudCIsInNldEFscmVhZHlQYWlkU2FsYXJ5QW1vdW50IiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwibm9SZWxvYWQiLCJ0eXBlIiwidGFyZ2V0RGF0YSIsInNldFRhcmdldERhdGEiLCJ0YXJnZXQiLCJhY2hpZXZlZCIsInJlbWFpbmluZyIsImRpZmZlcmVuY2UiLCJpbmNlbnRpdmVBbW91bnQiLCJpbmNlbnRpdmVQZXJjZW50IiwiYWdlbnRzIiwic2V0QWdlbnRzIiwic2FsYXJ5UGF5bWVudHMiLCJzZXRTYWxhcnlQYXltZW50cyIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsImFkbWluTmFtZSIsInNldEFkbWluTmFtZSIsImVycm9ycyIsInNldEVycm9ycyIsInJlUmVuZGVyIiwic2V0UmVSZW5kZXIiLCJzYWxhcnlDYWxjdWxhdGlvbkRldGFpbHMiLCJzZXRTYWxhcnlDYWxjdWxhdGlvbkRldGFpbHMiLCJtYW51YWxQYWlkQW1vdW50Iiwic2V0TWFudWFsUGFpZEFtb3VudCIsImlzRWRpdGluZyIsInNldElzRWRpdGluZyIsImVkaXRpbmdTYWxhcnkiLCJzZXRFZGl0aW5nU2FsYXJ5IiwiaXNTYWxhcnlBbHJlYWR5UGFpZCIsInNldElzU2FsYXJ5QWxyZWFkeVBhaWQiLCJpc0NhbGN1bGF0aW9uRm9yRXhpc3RpbmdQYXltZW50Iiwic2V0SXNDYWxjdWxhdGlvbkZvckV4aXN0aW5nUGF5bWVudCIsInRvZGF5IiwiRGF0ZSIsImN1cnJlbnRNb250aCIsImdldEZ1bGxZZWFyIiwiU3RyaW5nIiwiZ2V0TW9udGgiLCJwYWRTdGFydCIsInNhbGFyeUZvcm0iLCJzZXRTYWxhcnlGb3JtIiwiYWdlbnRfaWQiLCJwYXlfZGF0ZSIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJmcm9tX2RhdGUiLCJ0b19kYXRlIiwiYW1vdW50IiwicGF5X3R5cGUiLCJ0cmFuc2FjdGlvbl9pZCIsIm5vdGUiLCJwYXlfZm9yIiwiYWRtaW5fdHlwZSIsImVtcGxveWVlRGV0YWlscyIsInNldEVtcGxveWVlRGV0YWlscyIsImpvaW5pbmdfZGF0ZSIsInNhbGFyeSIsInRvdGFsV2l0aEluY2VudGl2ZSIsInNldFRvdGFsV2l0aEluY2VudGl2ZSIsImNhbGN1bGF0ZWRTYWxhcnkiLCJzZXRDYWxjdWxhdGVkU2FsYXJ5IiwiYWxyZWFkeVBhaWQiLCJzZXRBbHJlYWR5UGFpZCIsInJlbWFpbmluZ1NhbGFyeSIsInNldFJlbWFpbmluZ1NhbGFyeSIsImZvcm1hdERhdGUiLCJkYXRlIiwidGVzdCIsImQiLCJpc05hTiIsInllYXIiLCJtb250aCIsImRheSIsImdldERhdGUiLCJvdGhlclBheW1lbnRzTGlzdCIsInNldE90aGVyUGF5bWVudHNMaXN0IiwicmVhc29uIiwiaGFuZGxlQWRkT3RoZXJQYXltZW50IiwiaGFuZGxlT3RoZXJQYXltZW50Q2hhbmdlIiwiaW5kZXgiLCJmaWVsZCIsInZhbHVlIiwidXBkYXRlZCIsImhhbmRsZVJlbW92ZU90aGVyUGF5bWVudCIsImZpbHRlciIsIl8iLCJpIiwibWFwIiwiTnVtYmVyIiwiZnJvbURhdGUiLCJsYXN0RGF5IiwidG9EYXRlIiwicHJldiIsImNoZWNrSWZTYWxhcnlBbHJlYWR5UGFpZCIsImVtcElkIiwicmVzcG9uc2UiLCJnZXQiLCJwYXJhbXMiLCJzYWxhcnlBcnJheSIsIkFycmF5IiwiaXNBcnJheSIsImRhdGEiLCJwYWlkQW1vdW50IiwicCIsInBBZ2VudElkIiwiZW1wbG95ZWVfaWQiLCJfaWQiLCJwYXltZW50RGF0ZSIsInBheW91dF9tZXRhZGF0YSIsImRhdGVfcmFuZ2UiLCJmcm9tIiwicmVkdWNlIiwic3VtIiwicGFyc2VGbG9hdCIsInRvdGFsX3BhaWRfYW1vdW50Iiwib3RoZXJQYXkiLCJvdGhlcl9wYXltZW50cyIsInNQYXkiLCJ0b3RhbF9zYWxhcnkiLCJpc0NhbGN1bGF0aW9uRm9yRXhpc3RpbmciLCJ0b3RhbFNhbGFyeSIsImlzUGFpZCIsInRvdGFsUGFpZCIsImVycm9yIiwiY29uc29sZSIsImNhbGN1bGF0ZVByb1JhdGVkU2FsYXJ5IiwiZnJvbURhdGVTdHIiLCJ0b0RhdGVTdHIiLCJtb250aGx5U2FsYXJ5IiwicGF5bWVudFN0YXR1cyIsInRvRml4ZWQiLCJsZWF2ZV9pbmZvIiwidG90YWxfbGVhdmVzX3VzZWQiLCJ0b3RhbF9hYnNlbmNlcyIsImN1cnJlbnRfbGVhdmVfYmFsYW5jZSIsIm1vbnRobHlfYnJlYWtkb3duIiwiZnVsbF95ZWFyX3JlcG9ydCIsImRlZHVjdGlvbkRldGFpbHMiLCJyZXMiLCJwb3N0IiwibG9nIiwicGF5YWJsZSIsInBheW1lbnRzUmVzIiwicGFpZEluUGVyaW9kIiwicGF5RGF0ZSIsImFscmVhZHlQYWlkQW10IiwiTWF0aCIsIm1heCIsImRldGFpbHMiLCJmZXRjaEVtcGxveWVlRGV0YWlscyIsImVtcCIsImVtcGxveWVlIiwiam9pbmluZyIsImJhc2VTYWxhcnkiLCJ0b2RheVN0ciIsIm5ld0Zyb21EYXRlIiwibmV3VG9EYXRlIiwiam9pbkRhdGUiLCJzbSIsImVyciIsImZldGNoQWdlbnRzIiwiZmV0Y2hTYWxhcnlQYXltZW50cyIsInJlc3BvbnNlRGF0YSIsInBheW1lbnQiLCJpZCIsImFnZW50X25hbWUiLCJuYW1lIiwiZnVsbF9uYW1lIiwidG8iLCJyZWNlaXB0X25vIiwiZGlzYnVyc2VkX2J5IiwiYWN0aW9uIiwibWVudSIsImUiLCJzdG9wUHJvcGFnYXRpb24iLCJ1c2VyIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInVzZXJPYmoiLCJKU09OIiwicGFyc2UiLCJhZG1pbl9hY2Nlc3NfcmlnaHRfaWQiLCJhY2Nlc3NfcGVybWlzc2lvbnMiLCJlZGl0X3BheW1lbnQiLCJ0aW1lciIsInNldFRpbWVvdXQiLCJjbGVhclRpbWVvdXQiLCJoYW5kbGVTYWxhcnlDaGFuZ2UiLCJmcm9tRXJyb3IiLCJ0b0Vycm9yIiwiZ2V0VGltZSIsInByZXZFcnJvcnMiLCJ2YWxpZGF0ZUZvcm0iLCJuZXdFcnJvcnMiLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJpc1ZhbGlkIiwib3BlbiIsImRlc2NyaXB0aW9uIiwiY2xhc3NOYW1lIiwidG90YWxQYWlkQW1vdW50Iiwib3RoZXJQYXltZW50c1RvdGFsIiwidmFsIiwicGF5bG9hZCIsInRyaW0iLCJyZXNldEZvcm0iLCJzYWxhcnlDb2x1bW5zIiwia2V5IiwiaGVhZGVyIiwidG9VcHBlckNhc2UiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsInVuZGVmaW5lZCIsImFnZW50IiwicGhvbmVfbnVtYmVyIiwiZmQiLCJ0ZCIsIm0iLCJsZWF2ZXNfdXNlZCIsImRlZHVjdGlvbnMiLCJzYWxhcnlfYW1vdW50IiwiZGVkdWN0aW9uc19pbmZvIiwianVzdGlmaWNhdGlvbiIsIml0ZW0iLCJjaGFyQXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQYXlPdXRTYWxhcnkuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIlxyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgQVBJIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0XCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IHsgU2VsZWN0LCBUb29sdGlwLCBub3RpZmljYXRpb24sIERyb3Bkb3duLCBJbnB1dCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBTZXR0aW5nU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NldHRpbmdTaWRlYmFyXCI7XHJcbmltcG9ydCBTYWxhcnlTbGlwUHJpbnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvcHJpbnRGb3JtYXRzL1NhbGFyeVNsaXBQcmludFwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgRWRpdFNhbGFyeU1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9FZGl0U2FsYXJ5TW9kYWxcIjtcclxuaW1wb3J0IHsgRG9sbGFyT3V0bGluZWQsIENhbGVuZGFyT3V0bGluZWQsIEVkaXRPdXRsaW5lZCwgSW5mb0NpcmNsZU91dGxpbmVkIH0gZnJvbSAnQGFudC1kZXNpZ24vaWNvbnMnO1xyXG5cclxuY29uc3QgUGF5b3V0U2FsYXJ5ID0gKCkgPT4ge1xyXG4gIGNvbnN0IHBheW1lbnRGb3IgPSBcInNhbGFyeVwiO1xyXG4gIGNvbnN0IFthcGksIGNvbnRleHRIb2xkZXJdID0gbm90aWZpY2F0aW9uLnVzZU5vdGlmaWNhdGlvbigpO1xyXG4gIGNvbnN0IFtkYXRlTW9kZSwgc2V0RGF0ZU1vZGVdID0gdXNlU3RhdGUoXCJtb250aFwiKTtcclxuICBjb25zdCBbc2hvd1NhbGFyeU1vZGFsLCBzZXRTaG93U2FsYXJ5TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFttb2RpZnlQYXltZW50LCBzZXRNb2RpZnlQYXltZW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbYWRtaW5JZCwgc2V0QWRtaW5JZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWJzZW50LCBzZXRBYnNlbnRdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW3NlbGVjdGVkTW9udGgsIHNldFNlbGVjdGVkTW9udGhdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2V4aXN0aW5nT3RoZXJQYXltZW50cywgc2V0SXNFeGlzdGluZ090aGVyUGF5bWVudHNdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FscmVhZHlQYWlkU2FsYXJ5QW1vdW50LCBzZXRBbHJlYWR5UGFpZFNhbGFyeUFtb3VudF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgIG5vUmVsb2FkOiBmYWxzZSxcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFt0YXJnZXREYXRhLCBzZXRUYXJnZXREYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIHRhcmdldDogMCxcclxuICAgIGFjaGlldmVkOiAwLFxyXG4gICAgcmVtYWluaW5nOiAwLFxyXG4gICAgZGlmZmVyZW5jZTogMCxcclxuICAgIGluY2VudGl2ZUFtb3VudDogXCLigrkwLjAwXCIsXHJcbiAgICBpbmNlbnRpdmVQZXJjZW50OiBcIjAlXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2FsYXJ5UGF5bWVudHMsIHNldFNhbGFyeVBheW1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFthZG1pbk5hbWUsIHNldEFkbWluTmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtyZVJlbmRlciwgc2V0UmVSZW5kZXJdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW3NhbGFyeUNhbGN1bGF0aW9uRGV0YWlscywgc2V0U2FsYXJ5Q2FsY3VsYXRpb25EZXRhaWxzXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFttYW51YWxQYWlkQW1vdW50LCBzZXRNYW51YWxQYWlkQW1vdW50XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtpc0VkaXRpbmcsIHNldElzRWRpdGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2VkaXRpbmdTYWxhcnksIHNldEVkaXRpbmdTYWxhcnldID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2lzU2FsYXJ5QWxyZWFkeVBhaWQsIHNldElzU2FsYXJ5QWxyZWFkeVBhaWRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpc0NhbGN1bGF0aW9uRm9yRXhpc3RpbmdQYXltZW50LCBzZXRJc0NhbGN1bGF0aW9uRm9yRXhpc3RpbmdQYXltZW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAvLyAgY29uc3QgW290aGVyUGF5bWVudHMsIHNldE90aGVyUGF5bWVudHNdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICBjb25zdCBjdXJyZW50TW9udGggPSBgJHt0b2RheS5nZXRGdWxsWWVhcigpfS0ke1N0cmluZyh0b2RheS5nZXRNb250aCgpICsgMSkucGFkU3RhcnQoMiwgXCIwXCIpfWA7XHJcblxyXG4gIGNvbnN0IFtzYWxhcnlGb3JtLCBzZXRTYWxhcnlGb3JtXSA9IHVzZVN0YXRlKHtcclxuICAgIGFnZW50X2lkOiBcIlwiLFxyXG4gICAgcGF5X2RhdGU6IHRvZGF5LnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgZnJvbV9kYXRlOiBcIlwiLFxyXG4gICAgdG9fZGF0ZTogXCJcIixcclxuICAgIGFtb3VudDogXCJcIixcclxuICAgIHBheV90eXBlOiBcImNhc2hcIixcclxuICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgbm90ZTogXCJcIixcclxuICAgIHBheV9mb3I6IHBheW1lbnRGb3IsXHJcbiAgICBhZG1pbl90eXBlOiBcIlwiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbZW1wbG95ZWVEZXRhaWxzLCBzZXRFbXBsb3llZURldGFpbHNdID0gdXNlU3RhdGUoe1xyXG4gICAgam9pbmluZ19kYXRlOiBcIlwiLFxyXG4gICAgc2FsYXJ5OiBcIlwiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbdG90YWxXaXRoSW5jZW50aXZlLCBzZXRUb3RhbFdpdGhJbmNlbnRpdmVdID0gdXNlU3RhdGUoXCIwLjAwXCIpO1xyXG4gIGNvbnN0IFtjYWxjdWxhdGVkU2FsYXJ5LCBzZXRDYWxjdWxhdGVkU2FsYXJ5XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFthbHJlYWR5UGFpZCwgc2V0QWxyZWFkeVBhaWRdID0gdXNlU3RhdGUoXCIwLjAwXCIpO1xyXG4gIGNvbnN0IFtyZW1haW5pbmdTYWxhcnksIHNldFJlbWFpbmluZ1NhbGFyeV0gPSB1c2VTdGF0ZShcIjAuMDBcIik7XHJcblxyXG4gIGNvbnN0IGZvcm1hdERhdGUgPSAoZGF0ZSkgPT4ge1xyXG4gICAgaWYgKCFkYXRlKSByZXR1cm4gXCJcIjtcclxuICAgIGlmICh0eXBlb2YgZGF0ZSA9PT0gXCJzdHJpbmdcIiAmJiAvXlxcZHs0fS1cXGR7Mn0tXFxkezJ9JC8udGVzdChkYXRlKSkge1xyXG4gICAgICByZXR1cm4gZGF0ZTtcclxuICAgIH1cclxuICAgIGNvbnN0IGQgPSBuZXcgRGF0ZShkYXRlKTtcclxuICAgIGlmIChpc05hTihkKSkgcmV0dXJuIFwiXCI7XHJcbiAgICBjb25zdCB5ZWFyID0gZC5nZXRGdWxsWWVhcigpO1xyXG4gICAgY29uc3QgbW9udGggPSBTdHJpbmcoZC5nZXRNb250aCgpICsgMSkucGFkU3RhcnQoMiwgXCIwXCIpO1xyXG4gICAgY29uc3QgZGF5ID0gU3RyaW5nKGQuZ2V0RGF0ZSgpKS5wYWRTdGFydCgyLCBcIjBcIik7XHJcbiAgICByZXR1cm4gYCR7eWVhcn0tJHttb250aH0tJHtkYXl9YDtcclxuICB9O1xyXG5cclxuXHJcbiAgY29uc3QgW290aGVyUGF5bWVudHNMaXN0LCBzZXRPdGhlclBheW1lbnRzTGlzdF0gPSB1c2VTdGF0ZShbeyByZWFzb246IFwiXCIsIGFtb3VudDogXCJcIiB9XSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFkZE90aGVyUGF5bWVudCA9ICgpID0+IHtcclxuICAgIHNldE90aGVyUGF5bWVudHNMaXN0KFsuLi5vdGhlclBheW1lbnRzTGlzdCwgeyByZWFzb246IFwiXCIsIGFtb3VudDogXCJcIiB9XSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlT3RoZXJQYXltZW50Q2hhbmdlID0gKGluZGV4LCBmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIGNvbnN0IHVwZGF0ZWQgPSBbLi4ub3RoZXJQYXltZW50c0xpc3RdO1xyXG4gICAgdXBkYXRlZFtpbmRleF1bZmllbGRdID0gdmFsdWU7XHJcbiAgICBzZXRPdGhlclBheW1lbnRzTGlzdCh1cGRhdGVkKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVSZW1vdmVPdGhlclBheW1lbnQgPSAoaW5kZXgpID0+IHtcclxuICAgIHNldE90aGVyUGF5bWVudHNMaXN0KG90aGVyUGF5bWVudHNMaXN0LmZpbHRlcigoXywgaSkgPT4gaSAhPT0gaW5kZXgpKTtcclxuICB9O1xyXG5cclxuXHJcbiAgLy8gSW5pdGlhbGl6ZSBzZWxlY3RlZE1vbnRoXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldFNlbGVjdGVkTW9udGgoY3VycmVudE1vbnRoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIC8vIEF1dG8tdXBkYXRlIGZyb21fZGF0ZSAvIHRvX2RhdGUgd2hlbiBtb250aCBjaGFuZ2VzXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChkYXRlTW9kZSA9PT0gXCJtb250aFwiICYmIHNlbGVjdGVkTW9udGgpIHtcclxuICAgICAgY29uc3QgW3llYXIsIG1vbnRoXSA9IHNlbGVjdGVkTW9udGguc3BsaXQoXCItXCIpLm1hcChOdW1iZXIpO1xyXG4gICAgICBjb25zdCBmcm9tRGF0ZSA9IGAke3llYXJ9LSR7U3RyaW5nKG1vbnRoKS5wYWRTdGFydCgyLCBcIjBcIil9LTAxYDtcclxuICAgICAgY29uc3QgbGFzdERheSA9IG5ldyBEYXRlKHllYXIsIG1vbnRoLCAwKS5nZXREYXRlKCk7XHJcbiAgICAgIGNvbnN0IHRvRGF0ZSA9IGAke3llYXJ9LSR7U3RyaW5nKG1vbnRoKS5wYWRTdGFydCgyLCBcIjBcIil9LSR7U3RyaW5nKGxhc3REYXkpLnBhZFN0YXJ0KDIsIFwiMFwiKX1gO1xyXG4gICAgICBzZXRTYWxhcnlGb3JtKChwcmV2KSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgZnJvbV9kYXRlOiBmcm9tRGF0ZSxcclxuICAgICAgICB0b19kYXRlOiB0b0RhdGUsXHJcbiAgICAgIH0pKTtcclxuICAgIH1cclxuICB9LCBbc2VsZWN0ZWRNb250aCwgZGF0ZU1vZGVdKTtcclxuXHJcbiAgY29uc3QgY2hlY2tJZlNhbGFyeUFscmVhZHlQYWlkID0gYXN5bmMgKGVtcElkLCBmcm9tRGF0ZSwgdG9EYXRlKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IEFQSS5nZXQoXCIvc2FsYXJ5L2dldC1zYWxhcnktcGF5bWVudHNcIiwge1xyXG4gICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgZW1wSWQsXHJcbiAgICAgICAgICBmcm9tX2RhdGU6IGZvcm1hdERhdGUoZnJvbURhdGUpLFxyXG4gICAgICAgICAgdG9fZGF0ZTogZm9ybWF0RGF0ZSh0b0RhdGUpXHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IHNhbGFyeUFycmF5ID0gQXJyYXkuaXNBcnJheShyZXNwb25zZS5kYXRhKSA/IHJlc3BvbnNlLmRhdGEgOiByZXNwb25zZS5kYXRhLmRhdGEgfHwgW107XHJcblxyXG4gICAgICBjb25zdCBwYWlkQW1vdW50ID0gc2FsYXJ5QXJyYXlcclxuICAgICAgICAuZmlsdGVyKChwKSA9PiB7XHJcbiAgICAgICAgICBjb25zdCBwQWdlbnRJZCA9IHAuZW1wbG95ZWVfaWQ/Ll9pZCA/IFN0cmluZyhwLmVtcGxveWVlX2lkLl9pZCkgOiBTdHJpbmcocC5lbXBsb3llZV9pZCk7XHJcbiAgICAgICAgICBjb25zdCBwYXltZW50RGF0ZSA9IG5ldyBEYXRlKGZvcm1hdERhdGUocC5wYXlvdXRfbWV0YWRhdGE/LmRhdGVfcmFuZ2U/LmZyb20pKTtcclxuICAgICAgICAgIHJldHVybiBwQWdlbnRJZCA9PT0gU3RyaW5nKGVtcElkKSAmJlxyXG4gICAgICAgICAgICBwYXltZW50RGF0ZSA+PSBuZXcgRGF0ZShmb3JtYXREYXRlKGZyb21EYXRlKSkgJiZcclxuICAgICAgICAgICAgcGF5bWVudERhdGUgPD0gbmV3IERhdGUoZm9ybWF0RGF0ZSh0b0RhdGUpKTtcclxuICAgICAgICB9KVxyXG4gICAgICAgIC5yZWR1Y2UoKHN1bSwgcCkgPT4gc3VtICsgcGFyc2VGbG9hdChwLnBheW91dF9tZXRhZGF0YT8udG90YWxfcGFpZF9hbW91bnQgfHwgMCksIDApO1xyXG4gICAgICBjb25zdCBvdGhlclBheSA9IHNhbGFyeUFycmF5XHJcbiAgICAgICAgLmZpbHRlcigocCkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgcEFnZW50SWQgPSBwLmVtcGxveWVlX2lkPy5faWQgPyBTdHJpbmcocC5lbXBsb3llZV9pZC5faWQpIDogU3RyaW5nKHAuZW1wbG95ZWVfaWQpO1xyXG4gICAgICAgICAgY29uc3QgcGF5bWVudERhdGUgPSBuZXcgRGF0ZShmb3JtYXREYXRlKHAucGF5b3V0X21ldGFkYXRhPy5kYXRlX3JhbmdlPy5mcm9tKSk7XHJcbiAgICAgICAgICByZXR1cm4gcEFnZW50SWQgPT09IFN0cmluZyhlbXBJZCkgJiZcclxuICAgICAgICAgICAgcGF5bWVudERhdGUgPj0gbmV3IERhdGUoZm9ybWF0RGF0ZShmcm9tRGF0ZSkpICYmXHJcbiAgICAgICAgICAgIHBheW1lbnREYXRlIDw9IG5ldyBEYXRlKGZvcm1hdERhdGUodG9EYXRlKSk7XHJcbiAgICAgICAgfSlcclxuICAgICAgICAucmVkdWNlKChzdW0sIHApID0+IHN1bSArIHBhcnNlRmxvYXQocC5wYXlvdXRfbWV0YWRhdGE/Lm90aGVyX3BheW1lbnRzIHx8IDApLCAwKTtcclxuICAgICAgY29uc3Qgc1BheSA9IHNhbGFyeUFycmF5XHJcbiAgICAgICAgLmZpbHRlcigocCkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgcEFnZW50SWQgPSBwLmVtcGxveWVlX2lkPy5faWQgPyBTdHJpbmcocC5lbXBsb3llZV9pZC5faWQpIDogU3RyaW5nKHAuZW1wbG95ZWVfaWQpO1xyXG4gICAgICAgICAgY29uc3QgcGF5bWVudERhdGUgPSBuZXcgRGF0ZShmb3JtYXREYXRlKHAucGF5b3V0X21ldGFkYXRhPy5kYXRlX3JhbmdlPy5mcm9tKSk7XHJcbiAgICAgICAgICByZXR1cm4gcEFnZW50SWQgPT09IFN0cmluZyhlbXBJZCkgJiZcclxuICAgICAgICAgICAgcGF5bWVudERhdGUgPj0gbmV3IERhdGUoZm9ybWF0RGF0ZShmcm9tRGF0ZSkpICYmXHJcbiAgICAgICAgICAgIHBheW1lbnREYXRlIDw9IG5ldyBEYXRlKGZvcm1hdERhdGUodG9EYXRlKSk7XHJcbiAgICAgICAgfSlcclxuICAgICAgICAucmVkdWNlKChzdW0sIHApID0+IHN1bSArIHBhcnNlRmxvYXQocC5wYXlvdXRfbWV0YWRhdGE/LnRvdGFsX3NhbGFyeSB8fCAwKSwgMCk7XHJcbiAgICAgIGNvbnN0IGFscmVhZHlQYWlkID0gcGFpZEFtb3VudCA+IDA7XHJcblxyXG4gICAgICAvLyBDaGVjayBpZiB0aGlzIGlzIGEgY2FsY3VsYXRpb24gZm9yIGV4aXN0aW5nIHBheW1lbnRcclxuICAgICAgY29uc3QgaXNDYWxjdWxhdGlvbkZvckV4aXN0aW5nID0gYWxyZWFkeVBhaWQgJiZcclxuICAgICAgICBzYWxhcnlDYWxjdWxhdGlvbkRldGFpbHMgJiZcclxuICAgICAgICBzYWxhcnlDYWxjdWxhdGlvbkRldGFpbHM/LnRvdGFsU2FsYXJ5ID09PSBwYWlkQW1vdW50O1xyXG5cclxuICAgICAgc2V0SXNDYWxjdWxhdGlvbkZvckV4aXN0aW5nUGF5bWVudChpc0NhbGN1bGF0aW9uRm9yRXhpc3RpbmcpO1xyXG4gICAgICBzZXRJc1NhbGFyeUFscmVhZHlQYWlkKGFscmVhZHlQYWlkKTtcclxuICAgICAgc2V0QWxyZWFkeVBhaWRTYWxhcnlBbW91bnQoc1BheSk7XHJcbiAgICAgIHNldElzRXhpc3RpbmdPdGhlclBheW1lbnRzKG90aGVyUGF5IHx8IFwiMC4wXCIpO1xyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIGlzUGFpZDogYWxyZWFkeVBhaWQsXHJcbiAgICAgICAgdG90YWxQYWlkOiBwYWlkQW1vdW50XHJcbiAgICAgIH07XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzZXRBbHJlYWR5UGFpZFNhbGFyeUFtb3VudChcIjAuMFwiKVxyXG4gICAgICBzZXRTYWxhcnlDYWxjdWxhdGlvbkRldGFpbHMoXCIwLjBcIik7XHJcblxyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgY2hlY2tpbmcgZXhpc3RpbmcgcGF5bWVudHM6XCIsIGVycm9yKTtcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICBpc1BhaWQ6IGZhbHNlLFxyXG4gICAgICAgIHRvdGFsUGFpZDogMFxyXG4gICAgICB9O1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNhbGN1bGF0ZVByb1JhdGVkU2FsYXJ5ID0gYXN5bmMgKGZyb21EYXRlU3RyLCB0b0RhdGVTdHIsIG1vbnRobHlTYWxhcnksIGVtcElkKSA9PiB7XHJcbiAgICBpZiAoIWVtcElkIHx8ICFmcm9tRGF0ZVN0ciB8fCAhdG9EYXRlU3RyKSB7XHJcbiAgICAgIHNldENhbGN1bGF0ZWRTYWxhcnkoXCJcIik7XHJcbiAgICAgIHNldEFscmVhZHlQYWlkKFwiMC4wMFwiKTtcclxuICAgICAgc2V0UmVtYWluaW5nU2FsYXJ5KFwiMC4wMFwiKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJQbGVhc2Ugc2VsZWN0IHZhbGlkIGRhdGVzIGFuZCBlbXBsb3llZS5cIixcclxuICAgICAgICB0eXBlOiBcIndhcm5pbmdcIixcclxuICAgICAgICBub1JlbG9hZDogdHJ1ZSxcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICAvLyBDaGVjayBpZiBzYWxhcnkgaXMgYWxyZWFkeSBwYWlkIGZvciB0aGlzIHBlcmlvZFxyXG4gICAgY29uc3QgcGF5bWVudFN0YXR1cyA9IGF3YWl0IGNoZWNrSWZTYWxhcnlBbHJlYWR5UGFpZChlbXBJZCwgZnJvbURhdGVTdHIsIHRvRGF0ZVN0cik7XHJcbiAgICBzZXRJc1NhbGFyeUFscmVhZHlQYWlkKHBheW1lbnRTdGF0dXMuaXNQYWlkKTtcclxuXHJcbiAgICBpZiAocGF5bWVudFN0YXR1cy5pc1BhaWQpIHtcclxuICAgICAgc2V0Q2FsY3VsYXRlZFNhbGFyeShcIlwiKTtcclxuICAgICAgc2V0QWxyZWFkeVBhaWQocGF5bWVudFN0YXR1cy50b3RhbFBhaWQudG9GaXhlZCgyKSk7XHJcbiAgICAgIHNldFJlbWFpbmluZ1NhbGFyeShcIjAuMDBcIik7XHJcbiAgICAgIHNldFNhbGFyeUNhbGN1bGF0aW9uRGV0YWlscyh7XHJcbiAgICAgICAgdG90YWxTYWxhcnk6IHBheW1lbnRTdGF0dXMudG90YWxQYWlkLFxyXG4gICAgICAgIGxlYXZlX2luZm86IHtcclxuICAgICAgICAgIHRvdGFsX2xlYXZlc191c2VkOiAwLFxyXG4gICAgICAgICAgdG90YWxfYWJzZW5jZXM6IDAsXHJcbiAgICAgICAgICBjdXJyZW50X2xlYXZlX2JhbGFuY2U6IDAsXHJcbiAgICAgICAgICBtb250aGx5X2JyZWFrZG93bjogW10sXHJcbiAgICAgICAgICBmdWxsX3llYXJfcmVwb3J0OiBbXVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZGVkdWN0aW9uRGV0YWlsczogW11cclxuICAgICAgfSk7XHJcblxyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBgU2FsYXJ5IGhhcyBhbHJlYWR5IGJlZW4gcGFpZCBmb3IgdGhpcyBwZXJpb2QuIFRvdGFsIHBhaWQ6IOKCuSR7cGF5bWVudFN0YXR1cy50b3RhbFBhaWQudG9GaXhlZCgyKX1gLFxyXG4gICAgICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgQVBJLnBvc3QoXCIvc2FsYXJ5L2NhbGN1bGF0ZVwiLCB7XHJcbiAgICAgICAgZW1wSWQsXHJcbiAgICAgICAgZnJvbV9kYXRlOiBmb3JtYXREYXRlKGZyb21EYXRlU3RyKSxcclxuICAgICAgICB0b19kYXRlOiBmb3JtYXREYXRlKHRvRGF0ZVN0ciksXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgeyB0b3RhbFNhbGFyeSB9ID0gcmVzLmRhdGE7XHJcbiAgICAgIGNvbnNvbGUubG9nKHRvdGFsU2FsYXJ5LCBcInNhbGFyeSBjYWxjdWxhdGlvbiByZXNwb25zZVwiKTtcclxuICAgICAgc2V0U2FsYXJ5Q2FsY3VsYXRpb25EZXRhaWxzKHJlcy5kYXRhKTtcclxuICAgICAgY29uc3QgcGF5YWJsZSA9IHBhcnNlRmxvYXQodG90YWxTYWxhcnkpLnRvRml4ZWQoMik7XHJcbiAgICAgIHNldENhbGN1bGF0ZWRTYWxhcnkocGF5YWJsZSk7XHJcbiAgICAgIHNldFRvdGFsV2l0aEluY2VudGl2ZShwYXlhYmxlKTtcclxuICAgICAgY29uc3QgcGF5bWVudHNSZXMgPSBhd2FpdCBBUEkuZ2V0KFwiL3NhbGFyeS9nZXQtc2FsYXJ5LXBheW1lbnRzXCIpO1xyXG5cclxuICAgICAgY29uc3QgZnJvbURhdGUgPSBuZXcgRGF0ZShmb3JtYXREYXRlKGZyb21EYXRlU3RyKSk7XHJcbiAgICAgIGNvbnN0IHRvRGF0ZSA9IG5ldyBEYXRlKGZvcm1hdERhdGUodG9EYXRlU3RyKSk7XHJcbiAgICAgIGNvbnN0IHNhbGFyeUFycmF5ID0gQXJyYXkuaXNBcnJheShwYXltZW50c1Jlcy5kYXRhKVxyXG4gICAgICAgID8gcGF5bWVudHNSZXMuZGF0YVxyXG4gICAgICAgIDogcGF5bWVudHNSZXMuZGF0YS5kYXRhIHx8IFtdO1xyXG4gICAgICBjb25zdCBwYWlkSW5QZXJpb2QgPSBzYWxhcnlBcnJheVxyXG4gICAgICAgIC5maWx0ZXIoKHApID0+IHtcclxuICAgICAgICAgIGNvbnN0IHBBZ2VudElkID0gcC5lbXBsb3llZV9pZD8uX2lkID8gU3RyaW5nKHAuZW1wbG95ZWVfaWQuX2lkKSA6IFN0cmluZyhwLmVtcGxveWVlX2lkKTtcclxuICAgICAgICAgIGNvbnN0IHBheURhdGUgPSBuZXcgRGF0ZShmb3JtYXREYXRlKHAucGF5b3V0X21ldGFkYXRhPy5kYXRlX3JhbmdlPy5mcm9tKSk7XHJcbiAgICAgICAgICByZXR1cm4gcEFnZW50SWQgPT09IFN0cmluZyhlbXBJZCkgJiYgcGF5RGF0ZSA+PSBmcm9tRGF0ZSAmJiBwYXlEYXRlIDw9IHRvRGF0ZTtcclxuICAgICAgICB9KVxyXG4gICAgICAgIC5yZWR1Y2UoKHN1bSwgcCkgPT4gc3VtICsgcGFyc2VGbG9hdChwLnBheW91dF9tZXRhZGF0YT8udG90YWxfcGFpZF9hbW91bnQgfHwgMCksIDApO1xyXG4gICAgICBjb25zdCBhbHJlYWR5UGFpZEFtdCA9IHBhaWRJblBlcmlvZC50b0ZpeGVkKDIpO1xyXG4gICAgICBjb25zdCByZW1haW5pbmcgPSBNYXRoLm1heCgwLCBwYXJzZUZsb2F0KHBheWFibGUpIC0gcGFpZEluUGVyaW9kKS50b0ZpeGVkKDIpO1xyXG4gICAgICBzZXRBbHJlYWR5UGFpZChhbHJlYWR5UGFpZEFtdCk7XHJcbiAgICAgIHNldFJlbWFpbmluZ1NhbGFyeShyZW1haW5pbmcpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIlNhbGFyeSBjYWxjdWxhdGVkIHN1Y2Nlc3NmdWxseSFcIixcclxuICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICBub1JlbG9hZDogdHJ1ZSxcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiQ2FsY3VsYXRlIHNhbGFyeSBlcnJvcjpcIiwgZXJyb3IpO1xyXG4gICAgICBjb25zdCBtZXNzYWdlID1cclxuICAgICAgICBlcnJvci5yZXNwb25zZT8uZGF0YT8uZXJyb3IgfHxcclxuICAgICAgICBlcnJvci5yZXNwb25zZT8uZGF0YT8uZGV0YWlscyB8fFxyXG4gICAgICAgIGVycm9yLm1lc3NhZ2UgfHxcclxuICAgICAgICBcIkZhaWxlZCB0byBjYWxjdWxhdGUgc2FsYXJ5XCI7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IG1lc3NhZ2UsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0Q2FsY3VsYXRlZFNhbGFyeShcIlwiKTtcclxuICAgICAgc2V0QWxyZWFkeVBhaWQoXCIwLjAwXCIpO1xyXG4gICAgICBzZXRSZW1haW5pbmdTYWxhcnkoXCIwLjAwXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaEVtcGxveWVlRGV0YWlscyA9IGFzeW5jIChlbXBJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgQVBJLmdldChgL2FnZW50L2dldC1hZGRpdGlvbmFsLWVtcGxveWVlLWluZm8tYnktaWQvJHtlbXBJZH1gKTtcclxuICAgICAgY29uc3QgZW1wID0gcmVzPy5kYXRhPy5lbXBsb3llZTtcclxuICAgICAgaWYgKGVtcCkge1xyXG4gICAgICAgIGNvbnN0IGpvaW5pbmcgPSBlbXAuam9pbmluZ19kYXRlPy5zcGxpdChcIlRcIilbMF0gfHwgXCJcIjtcclxuICAgICAgICBjb25zdCBiYXNlU2FsYXJ5ID0gZW1wLnNhbGFyeSB8fCBcIlwiO1xyXG4gICAgICAgIHNldEVtcGxveWVlRGV0YWlscyh7IGpvaW5pbmdfZGF0ZTogam9pbmluZywgc2FsYXJ5OiBiYXNlU2FsYXJ5IH0pO1xyXG4gICAgICAgIGNvbnN0IHRvZGF5U3RyID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcclxuICAgICAgICBjb25zdCBuZXdGcm9tRGF0ZSA9IGpvaW5pbmcgfHwgdG9kYXlTdHI7XHJcbiAgICAgICAgY29uc3QgbmV3VG9EYXRlID0gdG9kYXlTdHI7XHJcbiAgICAgICAgc2V0U2FsYXJ5Rm9ybSgocHJldikgPT4gKHtcclxuICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICBmcm9tX2RhdGU6IG5ld0Zyb21EYXRlLFxyXG4gICAgICAgICAgdG9fZGF0ZTogbmV3VG9EYXRlLFxyXG4gICAgICAgIH0pKTtcclxuICAgICAgICAvLyBBbHNvIHVwZGF0ZSBtb250aCBmaWVsZCBpZiBpbiBtb250aCBtb2RlXHJcbiAgICAgICAgaWYgKGRhdGVNb2RlID09PSBcIm1vbnRoXCIpIHtcclxuICAgICAgICAgIGNvbnN0IGpvaW5EYXRlID0gbmV3IERhdGUoam9pbmluZyB8fCB0b2RheVN0cik7XHJcbiAgICAgICAgICBjb25zdCBzbSA9IGAke2pvaW5EYXRlLmdldEZ1bGxZZWFyKCl9LSR7U3RyaW5nKGpvaW5EYXRlLmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCBcIjBcIil9YDtcclxuICAgICAgICAgIHNldFNlbGVjdGVkTW9udGgoc20pO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbXBsb3llZSBpbmZvXCIsIGVycik7XHJcbiAgICAgIHNldEVtcGxveWVlRGV0YWlscyh7IGpvaW5pbmdfZGF0ZTogXCJcIiwgc2FsYXJ5OiBcIlwiIH0pO1xyXG4gICAgICBzZXRDYWxjdWxhdGVkU2FsYXJ5KFwiXCIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoQWdlbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBUEkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4gICAgICBzZXRBZ2VudHMocmVzcG9uc2UuZGF0YT8uZW1wbG95ZWUgfHwgW10pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBBZ2VudHNcIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hTYWxhcnlQYXltZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldChcIi9zYWxhcnkvZ2V0LXNhbGFyeS1wYXltZW50c1wiKTtcclxuICAgICAgY29uc3Qgc2FsYXJ5QXJyYXkgPSBBcnJheS5pc0FycmF5KHJlc3BvbnNlLmRhdGEpID8gcmVzcG9uc2UuZGF0YSA6IHJlc3BvbnNlLmRhdGEuZGF0YSB8fCBbXTtcclxuICAgICAgY29uc29sZS5sb2coXCJGZXRjaGVkIFNhbGFyeSBQYXltZW50czpcIiwgc2FsYXJ5QXJyYXkpO1xyXG4gICAgICBjb25zdCByZXNwb25zZURhdGEgPSBzYWxhcnlBcnJheS5tYXAoKHBheW1lbnQsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgX2lkOiBwYXltZW50Ll9pZCxcclxuICAgICAgICBwYXlfZGF0ZTpcclxuICAgICAgICAgIHBheW1lbnQucGF5b3V0X21ldGFkYXRhPy5kYXRlX3JhbmdlPy5mcm9tPy5zcGxpdChcIlRcIilbMF0gfHxcclxuICAgICAgICAgIHBheW1lbnQucGF5X2RhdGU/LnNwbGl0KFwiVFwiKVswXSB8fFxyXG4gICAgICAgICAgXCItXCIsXHJcbiAgICAgICAgYWdlbnRfaWQ6IHBheW1lbnQuZW1wbG95ZWVfaWQ/Ll9pZCB8fCBcIi1cIixcclxuICAgICAgICBhZ2VudF9uYW1lOlxyXG4gICAgICAgICAgcGF5bWVudC5lbXBsb3llZV9pZD8ubmFtZSB8fFxyXG4gICAgICAgICAgcGF5bWVudC5lbXBsb3llZV9pZD8uZnVsbF9uYW1lIHx8XHJcbiAgICAgICAgICBwYXltZW50LmFnZW50X25hbWUgfHxcclxuICAgICAgICAgIFwiTi9BXCIsXHJcbiAgICAgICAgZnJvbV9kYXRlOiBwYXltZW50LnBheW91dF9tZXRhZGF0YT8uZGF0ZV9yYW5nZT8uZnJvbT8uc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICAgIHRvX2RhdGU6IHBheW1lbnQucGF5b3V0X21ldGFkYXRhPy5kYXRlX3JhbmdlPy50bz8uc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICAgIHRvdGFsX3NhbGFyeTogcGF5bWVudC5wYXlvdXRfbWV0YWRhdGE/LnRvdGFsX3NhbGFyeSB8fCAwLFxyXG4gICAgICAgIHRvdGFsX3BhaWRfYW1vdW50OiBwYXltZW50LnBheW91dF9tZXRhZGF0YT8udG90YWxfcGFpZF9hbW91bnQgfHwgMCxcclxuICAgICAgICAvLyBvdGhlcl9wYXltZW50czogcGF5bWVudC5wYXlvdXRfbWV0YWRhdGE/Lm90aGVyX3BheW1lbnRzIHx8IDAsXHJcblxyXG4gICAgICAgIG90aGVyX3BheW1lbnRzOiBBcnJheS5pc0FycmF5KHBheW1lbnQucGF5b3V0X21ldGFkYXRhPy5vdGhlcl9wYXltZW50cylcclxuICAgICAgICAgID8gcGF5bWVudC5wYXlvdXRfbWV0YWRhdGEub3RoZXJfcGF5bWVudHMucmVkdWNlKFxyXG4gICAgICAgICAgICAoc3VtLCBwKSA9PiBzdW0gKyBwYXJzZUZsb2F0KHAuYW1vdW50IHx8IDApLFxyXG4gICAgICAgICAgICAwXHJcbiAgICAgICAgICApLnRvRml4ZWQoMilcclxuICAgICAgICAgIDogcGFyc2VGbG9hdChwYXltZW50LnBheW91dF9tZXRhZGF0YT8ub3RoZXJfcGF5bWVudHMgfHwgMCkudG9GaXhlZCgyKSxcclxuXHJcblxyXG4gICAgICAgIHBheV90eXBlOiBwYXltZW50LnBheW91dF9tZXRhZGF0YT8ucGF5X3R5cGUgfHwgcGF5bWVudC5wYXlfdHlwZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgIHJlY2VpcHRfbm86IHBheW1lbnQucGF5b3V0X21ldGFkYXRhPy5yZWNlaXB0X25vIHx8IHBheW1lbnQucmVjZWlwdF9ubyB8fCBcIi1cIixcclxuICAgICAgICBub3RlOiBwYXltZW50LnBheW91dF9tZXRhZGF0YT8ubm90ZSB8fCBwYXltZW50Lm5vdGUgfHwgXCItXCIsXHJcbiAgICAgICAgZGlzYnVyc2VkX2J5OiBwYXltZW50LnBheW91dF9tZXRhZGF0YT8uZGlzYnVyc2VkX2J5IHx8IHBheW1lbnQuZGlzYnVyc2VkX2J5IHx8IFwiQWRtaW5cIixcclxuICAgICAgICBcclxuICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICBkcm9wZG93blJlbmRlcj17KG1lbnUpID0+IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctbGcgYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBwLTIgbWluLXctWzI0MHB4XVwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHgtMyBweS0yLjUgcm91bmRlZC1sZyBob3ZlcjpiZy1ncmF5LTUwIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMCBncm91cFwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0RWRpdGluZ1NhbGFyeShwYXltZW50KTtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldElzRWRpdGluZyh0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy05IGgtOSByb3VuZGVkLWxnIGJnLXZpb2xldC01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBncm91cC1ob3ZlcjpiZy12aW9sZXQtMTAwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgY2xhc3NOYW1lPVwiaC00IHctNCB0ZXh0LXZpb2xldC02MDBcIiBmaWxsPVwibm9uZVwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPXsyfSBkPVwiTTExIDVINmEyIDIgMCAwMC0yIDJ2MTFhMiAyIDAgMDAyIDJoMTFhMiAyIDAgMDAyLTJ2LTVtLTEuNDE0LTkuNDE0YTIgMiAwIDExMi44MjggMi44MjhMMTEuODI4IDE1SDl2LTIuODI4bDguNTg2LTguNTg2elwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+RWRpdCBQYXltZW50PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+TW9kaWZ5IHBheW1lbnQgZGV0YWlsczwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC0zIHB5LTIuNSByb3VuZGVkLWxnIGhvdmVyOmJnLWdyYXktNTAgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMjAwIGdyb3VwXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy05IGgtOSByb3VuZGVkLWxnIGJnLWVtZXJhbGQtNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ3JvdXAtaG92ZXI6YmctZW1lcmFsZC0xMDAgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiBjbGFzc05hbWU9XCJoLTQgdy00IHRleHQtZW1lcmFsZC02MDBcIiBmaWxsPVwibm9uZVwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPXsyfSBkPVwiTTE3IDE3aDJhMiAyIDAgMDAyLTJ2LTRhMiAyIDAgMDAtMi0ySDVhMiAyIDAgMDAtMiAydjRhMiAyIDAgMDAyIDJoMm0yIDRoNmEyIDIgMCAwMDItMnYtNGEyIDIgMCAwMC0yLTJIOWEyIDIgMCAwMC0yIDJ2NGEyIDIgMCAwMDIgMnptOC0xMlY1YTIgMiAwIDAwLTItMkg5YTIgMiAwIDAwLTIgMnY0aDEwelwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNhbGFyeVNsaXBQcmludCBwYXltZW50PXtwYXltZW50fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1weCBiZy1ncmF5LTIwMCBteS0yIG14LTJcIj48L2Rpdj5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21SaWdodFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyIHAtMiBob3ZlcjpiZy1ncmF5LTUwIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgaG92ZXI6Ym9yZGVyLWdyYXktMjAwIGhvdmVyOnNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQteGwgdGV4dC1ncmF5LTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApLFxyXG4gICAgICB9KSk7XHJcbiAgICAgIHNldFNhbGFyeVBheW1lbnRzKHJlc3BvbnNlRGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIFNhbGFyeSBwYXltZW50c1wiLCBlcnJvcik7XHJcbiAgICAgIHNldFNhbGFyeVBheW1lbnRzKFtdKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHVzZXIgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBjb25zdCB1c2VyT2JqID0gSlNPTi5wYXJzZSh1c2VyKTtcclxuICAgIHNldEFkbWluSWQodXNlck9iai5faWQpO1xyXG4gICAgc2V0QWRtaW5OYW1lKHVzZXJPYmoubmFtZSB8fCBcIlwiKTtcclxuICAgIGlmICh1c2VyT2JqPy5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQ/LmFjY2Vzc19wZXJtaXNzaW9ucz8uZWRpdF9wYXltZW50KSB7XHJcbiAgICAgIHNldE1vZGlmeVBheW1lbnQoXHJcbiAgICAgICAgdXNlck9iai5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQuYWNjZXNzX3Blcm1pc3Npb25zLmVkaXRfcGF5bWVudCA9PT0gXCJ0cnVlXCJcclxuICAgICAgKTtcclxuICAgIH1cclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoYWxlcnRDb25maWcudmlzaWJpbGl0eSAmJiBhbGVydENvbmZpZy5ub1JlbG9hZCkge1xyXG4gICAgICBjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSk7XHJcbiAgICAgIH0sIDQwMDApO1xyXG4gICAgICByZXR1cm4gKCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVyKTtcclxuICAgIH1cclxuICB9LCBbYWxlcnRDb25maWcudmlzaWJpbGl0eV0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hBZ2VudHMoKTtcclxuICAgIGZldGNoU2FsYXJ5UGF5bWVudHMoKTtcclxuICB9LCBbcmVSZW5kZXJdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU2FsYXJ5Q2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgY29uc3QgdG9kYXlTdHIgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdO1xyXG5cclxuICAgIHNldFNhbGFyeUZvcm0oKHByZXYpID0+IHtcclxuICAgICAgY29uc3QgdXBkYXRlZCA9IHsgLi4ucHJldiwgW25hbWVdOiB2YWx1ZSB9O1xyXG4gICAgICBjb25zdCBmcm9tID0gdXBkYXRlZC5mcm9tX2RhdGUgPyBuZXcgRGF0ZSh1cGRhdGVkLmZyb21fZGF0ZSkgOiBudWxsO1xyXG4gICAgICBjb25zdCB0byA9IHVwZGF0ZWQudG9fZGF0ZSA/IG5ldyBEYXRlKHVwZGF0ZWQudG9fZGF0ZSkgOiBudWxsO1xyXG4gICAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKHRvZGF5U3RyKTsgXHJcblxyXG4gICAgICBsZXQgZnJvbUVycm9yID0gXCJcIjtcclxuICAgICAgbGV0IHRvRXJyb3IgPSBcIlwiO1xyXG5cclxuICAgICAgaWYgKGZyb20gJiYgaXNOYU4oZnJvbS5nZXRUaW1lKCkpKSB7XHJcbiAgICAgICAgZnJvbUVycm9yID0gXCJJbnZhbGlkIEZyb20gRGF0ZVwiO1xyXG4gICAgICB9IGVsc2UgaWYgKGZyb20gJiYgZnJvbSA+IHRvZGF5KSB7XHJcbiAgICAgICAgZnJvbUVycm9yID0gXCJGcm9tIERhdGUgY2Fubm90IGJlIGluIHRoZSBmdXR1cmUuXCI7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmICh0byAmJiBpc05hTih0by5nZXRUaW1lKCkpKSB7XHJcbiAgICAgICAgdG9FcnJvciA9IFwiSW52YWxpZCBUbyBEYXRlXCI7XHJcbiAgICAgIH0gZWxzZSBpZiAodG8gJiYgdG8gPiB0b2RheSkge1xyXG4gICAgICAgIHRvRXJyb3IgPSBcIlRvIERhdGUgY2Fubm90IGJlIGluIHRoZSBmdXR1cmUuXCI7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChmcm9tICYmIHRvICYmICFpc05hTihmcm9tLmdldFRpbWUoKSkgJiYgIWlzTmFOKHRvLmdldFRpbWUoKSkgJiYgZnJvbSA+IHRvKSB7XHJcbiAgICAgICAgZnJvbUVycm9yID0gXCJGcm9tIERhdGUgY2Fubm90IGJlIGdyZWF0ZXIgdGhhbiBUbyBEYXRlLlwiO1xyXG4gICAgICAgIHRvRXJyb3IgPSBcIlRvIERhdGUgY2Fubm90IGJlIGxlc3MgdGhhbiBGcm9tIERhdGUuXCI7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHNldEVycm9ycygocHJldkVycm9ycykgPT4gKHtcclxuICAgICAgICAuLi5wcmV2RXJyb3JzLFxyXG4gICAgICAgIGZyb21fZGF0ZTogZnJvbUVycm9yLFxyXG4gICAgICAgIHRvX2RhdGU6IHRvRXJyb3IsXHJcbiAgICAgIH0pKTtcclxuXHJcbiAgICAgIHJldHVybiB1cGRhdGVkO1xyXG4gICAgfSk7XHJcblxyXG4gICAgc2V0T3RoZXJQYXltZW50c0xpc3QoW3sgcmVhc29uOiBcIlwiLCBhbW91bnQ6IFwiXCIgfV0pO1xyXG5cclxuICAgIHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgW25hbWVdOiBcIlwiIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCB2YWxpZGF0ZUZvcm0gPSAoKSA9PiB7XHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuICAgIGlmICghc2FsYXJ5Rm9ybS5hZ2VudF9pZCkgbmV3RXJyb3JzLmFnZW50X2lkID0gXCJQbGVhc2Ugc2VsZWN0IGFuIGFnZW50XCI7XHJcbiAgICBpZiAoc2FsYXJ5Rm9ybS5wYXlfdHlwZSA9PT0gXCJvbmxpbmVcIiAmJiAhc2FsYXJ5Rm9ybS50cmFuc2FjdGlvbl9pZClcclxuICAgICAgbmV3RXJyb3JzLnBheV90eXBlID0gXCJUcmFuc2FjdGlvbiBJRCBpcyByZXF1aXJlZCBmb3Igb25saW5lIHBheW1lbnRzXCI7XHJcbiAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBcclxuXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGNvbnN0IGlzVmFsaWQgPSB2YWxpZGF0ZUZvcm0oKTtcclxuICAgIGlmICghaXNWYWxpZCkgcmV0dXJuO1xyXG5cclxuICAgIC8vIENoZWNrIGlmIHNhbGFyeSBhbHJlYWR5IHBhaWRcclxuICAgIGNvbnN0IHBheW1lbnRTdGF0dXMgPSBhd2FpdCBjaGVja0lmU2FsYXJ5QWxyZWFkeVBhaWQoXHJcbiAgICAgIHNhbGFyeUZvcm0uYWdlbnRfaWQsXHJcbiAgICAgIHNhbGFyeUZvcm0uZnJvbV9kYXRlLFxyXG4gICAgICBzYWxhcnlGb3JtLnRvX2RhdGVcclxuICAgICk7XHJcblxyXG4gICAgaWYgKHBheW1lbnRTdGF0dXMuaXNQYWlkKSB7XHJcbiAgICAgIGFwaS5vcGVuKHtcclxuICAgICAgICBtZXNzYWdlOiBcIkNhbm5vdCBjcmVhdGUgbmV3IHBheW1lbnRcIixcclxuICAgICAgICBkZXNjcmlwdGlvbjogXCJTYWxhcnkgaGFzIGFscmVhZHkgYmVlbiBwYWlkIGZvciB0aGlzIHBlcmlvZC5cIixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYmctcmVkLTUwMCByb3VuZGVkLWxnIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZVwiLFxyXG4gICAgICB9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIENhbGN1bGF0ZSB0b3RhbCBwYWlkIGFtb3VudCAoYmFzZSBzYWxhcnkgKyBtYW51YWwgYW1vdW50ICsgb3RoZXIgcGF5bWVudHMpXHJcbiAgICBsZXQgdG90YWxQYWlkQW1vdW50ID0gMDtcclxuICAgIHRvdGFsUGFpZEFtb3VudCA9IG1hbnVhbFBhaWRBbW91bnRcclxuICAgICAgPyBwYXJzZUZsb2F0KG1hbnVhbFBhaWRBbW91bnQpXHJcbiAgICAgIDogcGFyc2VGbG9hdChjYWxjdWxhdGVkU2FsYXJ5IHx8IDApO1xyXG5cclxuICAgIC8vIEFkZCB1cCBvdGhlciBwYXltZW50IGFtb3VudHNcclxuICAgIGNvbnN0IG90aGVyUGF5bWVudHNUb3RhbCA9IG90aGVyUGF5bWVudHNMaXN0LnJlZHVjZSgoc3VtLCBwKSA9PiB7XHJcbiAgICAgIGNvbnN0IHZhbCA9IHBhcnNlRmxvYXQocC5hbW91bnQpO1xyXG4gICAgICByZXR1cm4gIWlzTmFOKHZhbCkgPyBzdW0gKyB2YWwgOiBzdW07XHJcbiAgICB9LCAwKTtcclxuXHJcbiAgICB0b3RhbFBhaWRBbW91bnQgKz0gb3RoZXJQYXltZW50c1RvdGFsO1xyXG5cclxuICAgIC8vIFByZXBhcmUgcGF5bG9hZFxyXG4gICAgY29uc3QgcGF5bG9hZCA9IHtcclxuICAgICAgZW1wSWQ6IHNhbGFyeUZvcm0uYWdlbnRfaWQsXHJcbiAgICAgIGZyb21fZGF0ZTogc2FsYXJ5Rm9ybS5mcm9tX2RhdGUsXHJcbiAgICAgIHRvX2RhdGU6IHNhbGFyeUZvcm0udG9fZGF0ZSxcclxuICAgICAgbm90ZTogc2FsYXJ5Rm9ybS5ub3RlLFxyXG4gICAgICBwYXlfdHlwZTogc2FsYXJ5Rm9ybS5wYXlfdHlwZSxcclxuICAgICAgdHJhbnNhY3Rpb25faWQ6IHNhbGFyeUZvcm0udHJhbnNhY3Rpb25faWQsXHJcbiAgICAgIHRvdGFsX3BhaWRfYW1vdW50OiB0b3RhbFBhaWRBbW91bnQsXHJcbiAgICAgIG90aGVyX3BheW1lbnRzOiBvdGhlclBheW1lbnRzTGlzdFxyXG4gICAgICAgIC5maWx0ZXIoKHApID0+IHAucmVhc29uICYmIHAuYW1vdW50KVxyXG4gICAgICAgIC5tYXAoKHApID0+ICh7XHJcbiAgICAgICAgICBkZXNjcmlwdGlvbjogcC5yZWFzb24udHJpbSgpLFxyXG4gICAgICAgICAgYW1vdW50OiBOdW1iZXIocC5hbW91bnQpLFxyXG4gICAgICAgIH0pKSxcclxuICAgIH07XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBBUEkucG9zdChcIi9zYWxhcnkvc2F2ZVwiLCBwYXlsb2FkKTtcclxuXHJcbiAgICAgIGFwaS5vcGVuKHtcclxuICAgICAgICBtZXNzYWdlOiBcIlNhbGFyeSBQcm9jZXNzZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IHJlcy5kYXRhLm1lc3NhZ2UgfHwgXCJTYWxhcnkgY2FsY3VsYXRlZCBhbmQgcGF5b3V0IHJlY29yZCBjcmVhdGVkLlwiLFxyXG4gICAgICAgIGNsYXNzTmFtZTogXCJiZy1ncmVlbi01MDAgcm91bmRlZC1sZyBmb250LXNlbWlib2xkIHRleHQtd2hpdGVcIixcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBzZXRTaG93U2FsYXJ5TW9kYWwoZmFsc2UpO1xyXG4gICAgICByZXNldEZvcm0oKTtcclxuICAgICAgc2V0UmVSZW5kZXIoKHZhbCkgPT4gdmFsICsgMSk7XHJcbiAgICAgIGZldGNoU2FsYXJ5UGF5bWVudHMoKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnN0IG1lc3NhZ2UgPVxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlPy5kYXRhPy5lcnJvciB8fFxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8XHJcbiAgICAgICAgZXJyb3IubWVzc2FnZSB8fFxyXG4gICAgICAgIFwiRmFpbGVkIHRvIHByb2Nlc3Mgc2FsYXJ5XCI7XHJcbiAgICAgIGFwaS5vcGVuKHtcclxuICAgICAgICBtZXNzYWdlOiBcIlNhbGFyeSBQcm9jZXNzaW5nIEZhaWxlZFwiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBtZXNzYWdlLFxyXG4gICAgICAgIGNsYXNzTmFtZTogXCJiZy1yZWQtNTAwIHJvdW5kZWQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuXHJcbiAgY29uc3QgcmVzZXRGb3JtID0gKCkgPT4ge1xyXG4gICAgc2V0RGF0ZU1vZGUoXCJtb250aFwiKTtcclxuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICAgIGNvbnN0IGN1cnJlbnRNb250aCA9IGAke3RvZGF5LmdldEZ1bGxZZWFyKCl9LSR7U3RyaW5nKHRvZGF5LmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCBcIjBcIil9YDtcclxuICAgIHNldFNlbGVjdGVkTW9udGgoY3VycmVudE1vbnRoKTtcclxuXHJcbiAgICBzZXRTYWxhcnlGb3JtKHtcclxuICAgICAgYWdlbnRfaWQ6IFwiXCIsXHJcbiAgICAgIHBheV9kYXRlOiB0b2RheS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgZnJvbV9kYXRlOiBcIlwiLFxyXG4gICAgICB0b19kYXRlOiBcIlwiLFxyXG4gICAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICAgIHBheV90eXBlOiBcImNhc2hcIixcclxuICAgICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICAgIG5vdGU6IFwiXCIsXHJcbiAgICAgIHBheV9mb3I6IHBheW1lbnRGb3IsXHJcbiAgICAgIGFkbWluX3R5cGU6IGFkbWluSWQsXHJcbiAgICB9KTtcclxuXHJcbiAgICBzZXRFbXBsb3llZURldGFpbHMoeyBqb2luaW5nX2RhdGU6IFwiXCIsIHNhbGFyeTogXCJcIiB9KTtcclxuICAgIHNldENhbGN1bGF0ZWRTYWxhcnkoXCJcIik7XHJcbiAgICBzZXRNYW51YWxQYWlkQW1vdW50KFwiXCIpO1xyXG4gICAgLy8gc2V0T3RoZXJQYXltZW50cyhcIlwiKTtcclxuICAgIHNldE90aGVyUGF5bWVudHNMaXN0KFt7IHJlYXNvbjogXCJcIiwgYW1vdW50OiBcIlwiIH1dKTtcclxuICAgIHNldEFscmVhZHlQYWlkKFwiMC4wMFwiKTtcclxuICAgIHNldFJlbWFpbmluZ1NhbGFyeShcIjAuMDBcIik7XHJcbiAgICBzZXRTYWxhcnlDYWxjdWxhdGlvbkRldGFpbHMobnVsbCk7XHJcbiAgICBzZXRJc1NhbGFyeUFscmVhZHlQYWlkKGZhbHNlKTtcclxuICAgIHNldElzQ2FsY3VsYXRpb25Gb3JFeGlzdGluZ1BheW1lbnQoZmFsc2UpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHNhbGFyeUNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcInBheV9kYXRlXCIsIGhlYWRlcjogXCJQYXkgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJhZ2VudF9uYW1lXCIsIGhlYWRlcjogXCJBZ2VudFwiIH0sXHJcbiAgICB7IGtleTogXCJ0b3RhbF9wYWlkX2Ftb3VudFwiLCBoZWFkZXI6IFwiVG90YWwgUGFpZCBBbW91bnQgKOKCuSlcIiB9LFxyXG4gICAgeyBrZXk6IFwib3RoZXJfcGF5bWVudHNcIiwgaGVhZGVyOiBcIkFkZGl0aW9uYWwgUGF5bWVudHMgKOKCuSlcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxfc2FsYXJ5XCIsIGhlYWRlcjogXCJUb3RhbCBTYWxhcnkgQW1vdW50ICjigrkpXCIgfSxcclxuICAgIHsga2V5OiBcInBheV90eXBlXCIsIGhlYWRlcjogXCJQYXltZW50IE1vZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVjZWlwdF9ub1wiLCBoZWFkZXI6IFwiUmVjZWlwdCBOb1wiIH0sXHJcbiAgICB7IGtleTogXCJmcm9tX2RhdGVcIiwgaGVhZGVyOiBcIkZyb20gRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0b19kYXRlXCIsIGhlYWRlcjogXCJUbyBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcIm5vdGVcIiwgaGVhZGVyOiBcIk5vdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZGlzYnVyc2VkX2J5XCIsIGhlYWRlcjogXCJEaXNidXJzZWQgYnlcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICB7Y29udGV4dEhvbGRlcn1cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgPE5hdmJhciB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG4gICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgPEN1c3RvbUFsZXJ0XHJcbiAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgIG5vUmVsb2FkPXthbGVydENvbmZpZy5ub1JlbG9hZH1cclxuICAgICAgICAvPlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGwgdGV4dC1yZWQtNTAwIGZvbnQtYm9sZFwiPntwYXltZW50Rm9yPy50b1VwcGVyQ2FzZSgpfTwvc3Bhbj4gUGF5bWVudHMgT3V0XHJcbiAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgIDxUb29sdGlwIHRpdGxlPVwiQWRkIFNhbGFyeSBQYXltZW50XCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBzZXRTaG93U2FsYXJ5TW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgIHJlc2V0Rm9ybSgpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTQgYmctdmlvbGV0LTkwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy12aW9sZXQtNjAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwIGZsZXggaXRlbXMtY2VudGVyXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtci0yXCI+Kzwvc3Bhbj4gU2FsYXJ5IFBheW1lbnRcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9Ub29sdGlwPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IGJnLXdoaXRlIHAtNiByb3VuZGVkLWxnIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIG1iLTQgdGV4dC12aW9sZXQtODAwIGJvcmRlci1iIHBiLTJcIj5TYWxhcnkgUGF5bWVudHM8L2gyPlxyXG4gICAgICAgICAgICB7c2FsYXJ5UGF5bWVudHMubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICBkYXRhPXtzYWxhcnlQYXltZW50c31cclxuICAgICAgICAgICAgICAgIGNvbHVtbnM9e3NhbGFyeUNvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJQYXlPdXQgU2FsYXJ5XCJcclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BQYXlPdXQgU2FsYXJ5LmNzdmB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwIHRleHQtY2VudGVyIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgZGF0YT1cIlNhbGFyeSBQYXltZW50c1wiXHJcbiAgICAgICAgICAgICAgICAgIGZhaWx1cmU9e3NhbGFyeVBheW1lbnRzLmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dTYWxhcnlNb2RhbH1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0U2hvd1NhbGFyeU1vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgcmVzZXRGb3JtKCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1zbGF0ZS01MCB0by1zbGF0ZS0xMDAgcHktNiBweC02IGxnOnB4LTggdGV4dC1sZWZ0IG1heC1oLVs5MHZoXSBteS0yXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiBwYi00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDBcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLWxnIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tdmlvbGV0LTUwMCB0by12aW9sZXQtNjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LXdoaXRlXCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTIgOGMtMS42NTcgMC0zIC44OTUtMyAyczEuMzQzIDIgMyAyIDMgLjg5NSAzIDItMS4zNDMgMi0zIDJtMCAwYzAgMy41MTcgMi44NDMgNi4zOCA2LjM2IDYuMzhhNi4zNiA2LjM2IDAgMDA2LjM2LTYuMzggNi4zNiA2LjM2IDAgMDAtNi4zNi02LjM4Yy0zLjUxNyAwLTYuMzYgMi44NjMtNi4zNiA2LjM4bTAgMGMwIDMuNTE3IDIuODQzIDYuMzggNi4zNiA2LjM4YTYuMzYgNi4zNiAwIDAwNi4zNi02LjM4IDYuMzYgNi4zNiAwIDAwLTYuMzYtNi4zOGMtMy41MTcgMC02LjM2IDIuODYzLTYuMzYgNi4zOHpcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5TYWxhcnkgUGF5bWVudDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlByb2Nlc3MgYW5kIG1hbmFnZSBlbXBsb3llZSBzYWxhcnkgZGlzYnVyc2VtZW50PC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHAtNSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFNlbGVjdCBFbXBsb3llZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggYW5kIHNlbGVjdCBlbXBsb3llZS4uLlwiXHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtzYWxhcnlGb3JtLmFnZW50X2lkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgYWdlbnRfaWQ6IFwiXCIgfSkpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFNhbGFyeUZvcm0oKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgYWdlbnRfaWQ6IHZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgYW1vdW50OiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRFbXBsb3llZURldGFpbHMoeyBqb2luaW5nX2RhdGU6IFwiXCIsIHNhbGFyeTogXCJcIiB9KTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRDYWxjdWxhdGVkU2FsYXJ5KFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldE1hbnVhbFBhaWRBbW91bnQoXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gc2V0T3RoZXJQYXltZW50cyhcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRPdGhlclBheW1lbnRzTGlzdChbeyByZWFzb246IFwiXCIsIGFtb3VudDogXCJcIiB9XSk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0QWxyZWFkeVBhaWQoXCIwLjAwXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFJlbWFpbmluZ1NhbGFyeShcIjAuMDBcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgZmV0Y2hFbXBsb3llZURldGFpbHModmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7YWdlbnRzLm1hcCgoYWdlbnQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2FnZW50Ll9pZH0gdmFsdWU9e2FnZW50Ll9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7YCR7YWdlbnQubmFtZX0gfCAke2FnZW50LnBob25lX251bWJlcn1gfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMuYWdlbnRfaWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0yIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+4pqgPC9zcGFuPiB7ZXJyb3JzLmFnZW50X2lkfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7ZW1wbG95ZWVEZXRhaWxzLmpvaW5pbmdfZGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgcC00IGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTFcIj5Kb2luaW5nIERhdGU8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+e2VtcGxveWVlRGV0YWlscz8uam9pbmluZ19kYXRlfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgcC00IGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTFcIj5Nb250aGx5IFNhbGFyeTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JlZW4tNzAwXCI+4oK5e2VtcGxveWVlRGV0YWlscz8uc2FsYXJ5fTwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBNb250aCBSYW5nZSBUb2dnbGUgJiBJbnB1dHMgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBwLTUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDAgbWItMyBmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENhbGVuZGFyT3V0bGluZWQgY2xhc3NOYW1lPVwibXItMiB0ZXh0LXZpb2xldC01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2FsYXJ5IFBlcmlvZFxyXG4gICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTYgbWItNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicmFkaW9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0tcmFkaW8gdGV4dC12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtkYXRlTW9kZSA9PT0gXCJtb250aFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiBzZXREYXRlTW9kZShcIm1vbnRoXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPk1vbnRoPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhZGlvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLXJhZGlvIHRleHQtdmlvbGV0LTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17ZGF0ZU1vZGUgPT09IFwiY3VzdG9tXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IHNldERhdGVNb2RlKFwiY3VzdG9tXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPkN1c3RvbSBEYXRlIFJhbmdlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIFNpbmdsZSBNb250aCBJbnB1dCAqL31cclxuICAgICAgICAgICAgICAgICAgICB7ZGF0ZU1vZGUgPT09IFwibW9udGhcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5TZWxlY3QgTW9udGg8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibW9udGhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZE1vbnRofVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRNb250aChlLnRhcmdldC52YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRPdGhlclBheW1lbnRzTGlzdChbeyByZWFzb246IFwiXCIsIGFtb3VudDogXCJcIiB9XSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMuNSBweS0yLjUgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgcm91bmRlZC1sZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogQ3VzdG9tIERhdGUgSW5wdXRzICovfVxyXG4gICAgICAgICAgICAgICAgICAgIHtkYXRlTW9kZSA9PT0gXCJjdXN0b21cIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5Gcm9tIERhdGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImZyb21fZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2FsYXJ5Rm9ybS5mcm9tX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXg9e25ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU2FsYXJ5Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMuNSBweS0yLjUgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgcm91bmRlZC1sZyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmZyb21fZGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKaoDwvc3Bhbj4ge2Vycm9ycy5mcm9tX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+VG8gRGF0ZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwidG9fZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2FsYXJ5Rm9ybS50b19kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4PXtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVNhbGFyeUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zLjUgcHktMi41IGJvcmRlciBib3JkZXItc2xhdGUtMzAwIHJvdW5kZWQtbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy50b19kYXRlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4pqgPC9zcGFuPiB7ZXJyb3JzLnRvX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogQ2FsY3VsYXRlIEJ1dHRvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICB7c2FsYXJ5Rm9ybS5mcm9tX2RhdGUgJiYgc2FsYXJ5Rm9ybS50b19kYXRlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodCBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tZ3JlZW4tNTAwIHRvLWdyZWVuLTYwMCBob3Zlcjpmcm9tLWdyZWVuLTYwMCBob3Zlcjp0by1ncmVlbi03MDAgdGV4dC13aGl0ZSBweC02IHB5LTIuNSByb3VuZGVkLWxnIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2FsYXJ5Rm9ybS5hZ2VudF9pZCAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzYWxhcnlGb3JtLmZyb21fZGF0ZSAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzYWxhcnlGb3JtLnRvX2RhdGUgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZW1wbG95ZWVEZXRhaWxzLnNhbGFyeVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZkID0gZm9ybWF0RGF0ZShzYWxhcnlGb3JtLmZyb21fZGF0ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRkID0gZm9ybWF0RGF0ZShzYWxhcnlGb3JtLnRvX2RhdGUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYWxjdWxhdGVQcm9SYXRlZFNhbGFyeShmZCwgdGQsIGVtcGxveWVlRGV0YWlscy5zYWxhcnksIHNhbGFyeUZvcm0uYWdlbnRfaWQpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQ2FsY3VsYXRlIFNhbGFyeVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAge2lzU2FsYXJ5QWxyZWFkeVBhaWQgJiYgIWlzQ2FsY3VsYXRpb25Gb3JFeGlzdGluZ1BheW1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmcteWVsbG93LTUwIHAtNCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXIteWVsbG93LTIwMCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEluZm9DaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXllbGxvdy01MDAgbXQtMSBtci0yXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQteWVsbG93LTgwMFwiPlNhbGFyeSBBbHJlYWR5IFBhaWQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXllbGxvdy02MDAgbXQtMVwiPlRoaXMgc2FsYXJ5IHBlcmlvZCBoYXMgYWxyZWFkeSBiZWVuIHByb2Nlc3NlZC48L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBncmlkIGdyaWQtY29scy0zIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtMyByb3VuZGVkLWxnIGJvcmRlciBib3JkZXIteWVsbG93LTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQteWVsbG93LTcwMCBmb250LW1lZGl1bVwiPlNhbGFyeSBBbW91bnQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQteWVsbG93LTkwMFwiPuKCuXthbHJlYWR5UGFpZFNhbGFyeUFtb3VudCB8fCBcIjAuMFwifTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTMgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXllbGxvdy0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXllbGxvdy03MDAgZm9udC1tZWRpdW1cIj5BbHJlYWR5IFBhaWQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQteWVsbG93LTkwMFwiPuKCuXthbHJlYWR5UGFpZH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC0zIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci15ZWxsb3ctMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC15ZWxsb3ctNzAwIGZvbnQtbWVkaXVtXCI+T3RoZXIgUGF5bWVudHM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQteWVsbG93LTkwMFwiPuKCuXtleGlzdGluZ090aGVyUGF5bWVudHMgfHwgXCIwLjAwXCJ9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBwdC0zIGJvcmRlci10IGJvcmRlci15ZWxsb3ctMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC15ZWxsb3ctODAwXCI+VG90YWwgQW1vdW50OiDigrl7cGFyc2VGbG9hdChhbHJlYWR5UGFpZCkgKyAocGFyc2VGbG9hdChleGlzdGluZ090aGVyUGF5bWVudHMpIHx8IDApfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBDYWxjdWxhdGVkIFNhbGFyeSBIaWdobGlnaHQgKi99XHJcbiAgICAgICAgICAgICAgICAgIHtjYWxjdWxhdGVkU2FsYXJ5ICYmICFpc1NhbGFyeUFscmVhZHlQYWlkICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS12aW9sZXQtNTAgdG8tdmlvbGV0LTEwMCByb3VuZGVkLXhsIHAtNSBib3JkZXIgYm9yZGVyLXZpb2xldC0zMDAgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC12aW9sZXQtNzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0yXCI+VG90YWwgUGF5YWJsZSBBbW91bnQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC12aW9sZXQtOTAwXCI+4oK5e2NhbGN1bGF0ZWRTYWxhcnl9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICB7LyogU2FsYXJ5IEJyZWFrZG93biBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICB7c2FsYXJ5Q2FsY3VsYXRpb25EZXRhaWxzICYmICFpc1NhbGFyeUFscmVhZHlQYWlkICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgc2hhZG93LXNtIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tc2xhdGUtMTAwIHRvLXNsYXRlLTUwIHB4LTUgcHktMyBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1zbGF0ZS02MDBcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTkgN2g2bTAgMTB2LTNtLTMgM3YzbS02LTZ2Nm0wLTExVjVhMiAyIDAgMDEyLTJoNmEyIDIgMCAwMTIgMnYxMW0tNiAwaDZcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1NhbGFyeUFscmVhZHlQYWlkICYmIGlzQ2FsY3VsYXRpb25Gb3JFeGlzdGluZ1BheW1lbnQgPyBcIkV4aXN0aW5nIFBheW1lbnQgRGV0YWlsc1wiIDogXCJTYWxhcnkgQnJlYWtkb3duXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01IHNwYWNlLXktNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTUwIHAtNCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItM1wiPkxlYXZlIFN1bW1hcnk8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtMyByb3VuZGVkIGJvcmRlciBib3JkZXItc2xhdGUtMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPkxlYXZlcyBVc2VkPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2FsYXJ5Q2FsY3VsYXRpb25EZXRhaWxzPy5sZWF2ZV9pbmZvPy50b3RhbF9sZWF2ZXNfdXNlZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtMyByb3VuZGVkIGJvcmRlciBib3JkZXItc2xhdGUtMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPlRvdGFsIEFic2VuY2VzPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2FsYXJ5Q2FsY3VsYXRpb25EZXRhaWxzPy5sZWF2ZV9pbmZvPy50b3RhbF9hYnNlbmNlc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtMyByb3VuZGVkIGJvcmRlciBib3JkZXItc2xhdGUtMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPkxlYXZlIEJhbGFuY2U8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzYWxhcnlDYWxjdWxhdGlvbkRldGFpbHM/LmxlYXZlX2luZm8/LmN1cnJlbnRfbGVhdmVfYmFsYW5jZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTNcIj5Nb250aGx5IERldGFpbHM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG8gcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tc2xhdGUtMTAwIHRvLXNsYXRlLTUwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0yLjUgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+TW9udGg8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMi41IHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPkFic2VuY2VzPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTIuNSB0ZXh0LWxlZnQgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5MZWF2ZXMgVXNlZDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0yLjUgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+RGVkdWN0aW9uczwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0yLjUgdGV4dC1yaWdodCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlNhbGFyeSBBbW91bnQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NhbGFyeUNhbGN1bGF0aW9uRGV0YWlscz8ubGVhdmVfaW5mbz8ubW9udGhseV9icmVha2Rvd24ubWFwKChtLCBpKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtpfSBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGxhc3Q6Ym9yZGVyLTAgaG92ZXI6Ymctc2xhdGUtNTAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMyBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+e20ubW9udGh9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktM1wiPnttLnRvdGFsX2Fic2VuY2VzfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTNcIj57bS5sZWF2ZXNfdXNlZH08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtcmlnaHQgZm9udC1tZWRpdW0gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e20uZGVkdWN0aW9ucy5yZWR1Y2UoKHN1bSwgZCkgPT4gc3VtICsgcGFyc2VGbG9hdChkLmFtb3VudCB8fCAwKSwgMCkudG9GaXhlZCgyKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LXJpZ2h0IGZvbnQtbWVkaXVtIHRleHQtdmlvbGV0LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXttLnNhbGFyeV9hbW91bnQgPyBtLnNhbGFyeV9hbW91bnQudG9GaXhlZCgyKSA6IFwiMC4wMFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c2FsYXJ5Q2FsY3VsYXRpb25EZXRhaWxzPy5kZWR1Y3Rpb25zX2luZm8/LmRldGFpbHM/Lmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0zXCI+RGVkdWN0aW9uczwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIGJnLXJlZC01MCBwLTQgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXJlZC0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NhbGFyeUNhbGN1bGF0aW9uRGV0YWlscz8uZGVkdWN0aW9uc19pbmZvLmRldGFpbHMubWFwKChkLCBpKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBweS0yIGJvcmRlci1iIGJvcmRlci1yZWQtMTAwIGxhc3Q6Ym9yZGVyLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTcwMFwiPntkLmp1c3RpZmljYXRpb259e2Qubm90ZSAmJiBgICgke2Qubm90ZX0pYH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtcmVkLTcwMFwiPi3igrl7cGFyc2VGbG9hdChkLmFtb3VudCkudG9GaXhlZCgyKX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIHtjYWxjdWxhdGVkU2FsYXJ5ICYmICFpc1NhbGFyeUFscmVhZHlQYWlkICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTQgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmVlbi01MCByb3VuZGVkLWxnIHAtNCBib3JkZXIgYm9yZGVyLWdyZWVuLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmVlbi03MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTFcIj5BbHJlYWR5IFBhaWQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTkwMFwiPuKCuXthbHJlYWR5UGFpZH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctb3JhbmdlLTUwIHJvdW5kZWQtbGcgcC00IGJvcmRlciBib3JkZXItb3JhbmdlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1vcmFuZ2UtNzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xXCI+UmVtYWluaW5nPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1vcmFuZ2UtOTAwXCI+4oK5e3JlbWFpbmluZ1NhbGFyeX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgey8qIE1hbnVhbCBQYWlkIEFtb3VudCBJbnB1dCAqL31cclxuICAgICAgICAgICAgICAgICAge2NhbGN1bGF0ZWRTYWxhcnkgJiYgIWlzU2FsYXJ5QWxyZWFkeVBhaWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBiZy13aGl0ZSByb3VuZGVkLXhsIHAtNSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFBheWFibGUgQW1vdW50ICjigrkpXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdGVwPVwiMC4wMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bWFudWFsUGFpZEFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNYW51YWxQYWlkQW1vdW50KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHB4LTMgcHktMiBib3JkZXIgcm91bmRlZC1tZCAke2Vycm9ycy50b3RhbF9wYWlkX2Ftb3VudCA/ICdib3JkZXItcmVkLTUwMCcgOiAnYm9yZGVyLWdyYXktMzAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBheWFibGUgYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnRvdGFsX3BhaWRfYW1vdW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPntlcnJvcnMudG90YWxfcGFpZF9hbW91bnR9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIExlYXZlIGJsYW5rIHRvIHVzZSBjYWxjdWxhdGVkIGFtb3VudCAoe2NhbGN1bGF0ZWRTYWxhcnl94oK5KVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIE90aGVyIFBheW1lbnRzIEZpZWxkICovfVxyXG4gICAgICAgICAgICAgICAgICB7Y2FsY3VsYXRlZFNhbGFyeSAmJiAhaXNTYWxhcnlBbHJlYWR5UGFpZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHAtNSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwIG1iLTMgZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWRkaXRpb25hbCBQYXltZW50c1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7b3RoZXJQYXltZW50c0xpc3QubWFwKChpdGVtLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aW5kZXh9IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTMgbWItMyBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBheW1lbnQgRGVzY3JpcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4sIFRyYW5zcG9ydCBSZWltYnVyc2VtZW50LCBCb251c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpdGVtLnJlYXNvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVPdGhlclBheW1lbnRDaGFuZ2UoaW5kZXgsIFwicmVhc29uXCIsIGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IEFtb3VudCAo4oK5KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW49XCIwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17aXRlbS5hbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlT3RoZXJQYXltZW50Q2hhbmdlKGluZGV4LCBcImFtb3VudFwiLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1lbmRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpbmRleCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUmVtb3ZlT3RoZXJQYXltZW50KGluZGV4KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgaG92ZXI6dGV4dC1yZWQtNzAwIGZvbnQtc2VtaWJvbGQgcHgtMyBweS0yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJlbW92ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVBZGRPdGhlclBheW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JlZW4tNjAwIHRleHQtd2hpdGUgdGV4dC1zbSBmb250LW1lZGl1bSBweC00IHB5LTIgcm91bmRlZC1sZyBob3ZlcjpiZy1ncmVlbi03MDAgdHJhbnNpdGlvbi1hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKyBBZGQgQW5vdGhlciBQYXltZW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWRkIG9uZSBvciBtb3JlIGV4dHJhIHBheW1lbnRzIHN1Y2ggYXMgaW5jZW50aXZlcywgcmVpbWJ1cnNlbWVudHMsIG9yIGJvbnVzZXMuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICApfVxyXG5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICB7Y2FsY3VsYXRlZFNhbGFyeSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgcC01IGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFBheW1lbnQgRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBheV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2FsYXJ5Rm9ybS5wYXlfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU2FsYXJ5Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zLjUgcHktMi41IGJvcmRlciBib3JkZXItc2xhdGUtMzAwIHJvdW5kZWQtbGcgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshbW9kaWZ5UGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHAtMyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IE1vZGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzYWxhcnlGb3JtLnBheV90eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldFNhbGFyeUZvcm0oeyAuLi5zYWxhcnlGb3JtLCBwYXlfdHlwZTogdmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiY2FzaFwiPkNhc2g8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJvbmxpbmVcIj5PbmxpbmUgVHJhbnNmZXI8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge21vZGlmeVBheW1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJjaGVxdWVcIj5DaGVxdWU8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiYmFua190cmFuc2ZlclwiPkJhbmsgVHJhbnNmZXI8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAge2NhbGN1bGF0ZWRTYWxhcnkgJiYgc2FsYXJ5Rm9ybS5wYXlfdHlwZSA9PT0gXCJvbmxpbmVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHAtNSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFRyYW5zYWN0aW9uIElEXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzYWxhcnlGb3JtLnRyYW5zYWN0aW9uX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNhbGFyeUZvcm0oeyAuLi5zYWxhcnlGb3JtLCB0cmFuc2FjdGlvbl9pZDogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIHJvdW5kZWQtbWQgJHtlcnJvcnMudHJhbnNhY3Rpb25faWQgPyAnYm9yZGVyLXJlZC01MDAnIDogJ2JvcmRlci1ncmF5LTMwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0cmFuc2FjdGlvbiBJRFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy50cmFuc2FjdGlvbl9pZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57ZXJyb3JzLnRyYW5zYWN0aW9uX2lkfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICB7Y2FsY3VsYXRlZFNhbGFyeSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHAtNSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEFkZGl0aW9uYWwgTm90ZXNcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NhbGFyeUZvcm0ubm90ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTYWxhcnlGb3JtKHsgLi4uc2FsYXJ5Rm9ybSwgbm90ZTogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBweC0zIHB5LTIgYm9yZGVyIHJvdW5kZWQtbWQgJHtlcnJvcnMubm90ZSA/ICdib3JkZXItcmVkLTUwMCcgOiAnYm9yZGVyLWdyYXktMzAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICByb3dzPVwiM1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQWRkIGFueSBub3RlcyBhYm91dCB0aGlzIHBheW1lbnQuLi5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFRoZXNlIG5vdGVzIHdpbGwgYmUgdmlzaWJsZSBvbiB0aGUgc2FsYXJ5IHNsaXBcclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIHtjYWxjdWxhdGVkU2FsYXJ5ICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS12aW9sZXQtNTAgdG8tdmlvbGV0LTEwMCByb3VuZGVkLXhsIHAtNSBib3JkZXIgYm9yZGVyLXZpb2xldC0zMDAgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC12aW9sZXQtNzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0yXCI+RGlzYnVyc2VkIEJ5PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC12aW9sZXQtOTAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWZ1bGwgYmctdmlvbGV0LTUwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXdoaXRlIHRleHQtc20gZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2FkbWluTmFtZT8uY2hhckF0KDApLnRvVXBwZXJDYXNlKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7YWRtaW5OYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIEFjdGlvbiBCdXR0b25zICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBib3JkZXItdCBib3JkZXItZ3JheS0yMDAgbXQtNiBmbGV4IGp1c3RpZnktZW5kIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dTYWxhcnlNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc2V0Rm9ybSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMi41IGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyB0ZXh0LWdyYXktNzAwIGhvdmVyOmJnLWdyYXktNTAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIHshaXNTYWxhcnlBbHJlYWR5UGFpZCAmJiAoPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNSBweS0yLjUgcm91bmRlZC1sZyB0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tY29sb3JzICR7aXNMb2FkaW5nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWdyYXktNDAwIGN1cnNvci1ub3QtYWxsb3dlZCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctdmlvbGV0LTYwMCBob3ZlcjpiZy12aW9sZXQtNzAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIC1tbC0xIG1yLTIgaC00IHctNCB0ZXh0LXdoaXRlXCIgZmlsbD1cIm5vbmVcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Y2lyY2xlIGNsYXNzTmFtZT1cIm9wYWNpdHktMjVcIiBjeD1cIjEyXCIgY3k9XCIxMlwiIHI9XCIxMFwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiNFwiPjwvY2lyY2xlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggY2xhc3NOYW1lPVwib3BhY2l0eS03NVwiIGZpbGw9XCJjdXJyZW50Q29sb3JcIiBkPVwiTTQgMTJhOCA4IDAgMDE4LThWMEM1LjM3MyAwIDAgNS4zNzMgMCAxMmg0em0yIDUuMjkxQTcuOTYyIDcuOTYyIDAgMDE0IDEySDBjMCAzLjA0MiAxLjEzNSA1LjgyNCAzIDcuOTM4bDMtMi42NDd6XCI+PC9wYXRoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFByb2Nlc3NpbmcuLi5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJTYXZlIFBheW1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj4pfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICAgIHsvKiBFZGl0IFNhbGFyeSBNb2RhbCAqL31cclxuICAgICAgICA8RWRpdFNhbGFyeU1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e2lzRWRpdGluZ31cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0SXNFZGl0aW5nKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0RWRpdGluZ1NhbGFyeShudWxsKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgICBzYWxhcnk9e2VkaXRpbmdTYWxhcnl9XHJcbiAgICAgICAgICBvbkVkaXRTdWNjZXNzPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldElzRWRpdGluZyhmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldEVkaXRpbmdTYWxhcnkobnVsbCk7XHJcbiAgICAgICAgICAgIHNldFJlUmVuZGVyKHByZXYgPT4gcHJldiArIDEpO1xyXG4gICAgICAgICAgICBmZXRjaFNhbGFyeVBheW1lbnRzKCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFBheW91dFNhbGFyeTsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvUGF5T3V0U2FsYXJ5LmpzeCJ9