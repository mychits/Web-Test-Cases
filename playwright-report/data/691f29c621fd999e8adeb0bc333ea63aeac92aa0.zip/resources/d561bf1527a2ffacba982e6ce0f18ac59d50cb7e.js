import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AuctionWhatsappMessageMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { Users, Briefcase, ChevronRight, Zap } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import { MdEmail } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { RiMoneyRupeeCircleLine } from "/node_modules/.vite/deps/react-icons_ri.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const AuctionWhatsappMessageMenu = () => {
  const auctionwhatsappCategories = [
    {
      id: 1,
      title: "Auction Intimation",
      description: "Manage Auction Intimation Message",
      icon: /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
        lineNumber: 19,
        columnNumber: 11
      }, this),
      color: "from-violet-600 to-violet-700",
      lightColor: "bg-violet-50",
      borderColor: "border-violet-200",
      href: "/market-menu/whatsapp-marketing/auction-whatsapp-marketing/auction-intimation-message",
      //   target:"_self",
      stats: "Active Auction Intimation Whatsapp Message"
    },
    {
      id: 2,
      title: "Bid Winner",
      description: "Manage Bid Winner Message",
      icon: /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
        lineNumber: 31,
        columnNumber: 11
      }, this),
      color: "from-violet-600 to-violet-700",
      lightColor: "bg-violet-50",
      borderColor: "border-violet-200",
      href: "/market-menu/whatsapp-marketing/auction-whatsapp-marketing/bid-winner",
      //   target:"_self",
      stats: "Active Bid Winner Whatsapp Message"
    },
    {
      id: 3,
      title: "Bid Status",
      description: "Manage Bid Status Message",
      icon: /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
        lineNumber: 43,
        columnNumber: 11
      }, this),
      color: "from-violet-600 to-violet-700",
      lightColor: "bg-violet-50",
      borderColor: "border-violet-200",
      href: "/market-menu/whatsapp-marketing/auction-whatsapp-marketing/bid-status",
      //   target:"_self",
      stats: "Active Bid Status Whatsapp Message"
    },
    {
      id: 4,
      title: "Winner Documents",
      description: "Manage Bid Winner Documents Message",
      icon: /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
        lineNumber: 56,
        columnNumber: 11
      }, this),
      color: "from-violet-600 to-violet-700",
      lightColor: "bg-violet-50",
      borderColor: "border-violet-200",
      href: "/market-menu/whatsapp-marketing/auction-whatsapp-marketing/winner-document",
      //   target:"_self",
      stats: "Active Bid Winner Documents Whatsapp Message"
    },
    {
      id: 5,
      title: "Auction Info",
      description: "Manage Auction Info Message",
      icon: /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
        lineNumber: 69,
        columnNumber: 11
      }, this),
      color: "from-violet-600 to-violet-700",
      lightColor: "bg-violet-50",
      borderColor: "border-violet-200",
      href: "/market-menu/whatsapp-marketing/auction-whatsapp-marketing/auction-info",
      //   target:"_self",
      stats: "Active Auction Info Whatsapp Message"
    },
    {
      id: 6,
      title: "Auction Terms & Conditions",
      description: "Manage Auction Terms & Conditions Message",
      icon: /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "w-8 h-8" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
        lineNumber: 82,
        columnNumber: 11
      }, this),
      color: "from-violet-600 to-violet-700",
      lightColor: "bg-violet-50",
      borderColor: "border-violet-200",
      href: "/market-menu/whatsapp-marketing/auction-whatsapp-marketing/auction-terms-condition",
      //   target:"_self",
      stats: "Active Auction Terms & Conditions Whatsapp Message"
    }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen w-full bg-gray-50", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
      lineNumber: 97,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
        lineNumber: 99,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-8", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
          lineNumber: 101,
          columnNumber: 16
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-3xl font-bold text-gray-900", children: "Auction Whatsapp Message Management" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
            lineNumber: 103,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mt-2", children: "Manage and organize your Customer Whatsapp Message" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
            lineNumber: 106,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
          lineNumber: 102,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6", children: auctionwhatsappCategories.map(
          (category) => /* @__PURE__ */ jsxDEV(Link, { to: category.href, className: "group", children: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `relative h-full overflow-hidden rounded-xl bg-white border ${category.borderColor} shadow-md hover:shadow-lg transition-all duration-300`,
              children: [
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${category.color} opacity-5 group-hover:opacity-10 rounded-full -mr-16 -mt-16 transition-all duration-300 blur-xl`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
                    lineNumber: 117,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "relative p-7", children: [
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: `inline-flex items-center justify-center w-14 h-14 ${category.lightColor} rounded-lg mb-5 group-hover:scale-105 transition-transform duration-300`,
                      children: /* @__PURE__ */ jsxDEV("div", { children: category.icon }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
                        lineNumber: 125,
                        columnNumber: 25
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
                      lineNumber: 122,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "mb-5", children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900 mb-2 group-hover:text-gray-950 transition-colors", children: category.title }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
                      lineNumber: 129,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600 leading-relaxed", children: category.description }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
                      lineNumber: 132,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
                    lineNumber: 128,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-4 border-t border-gray-100 group-hover:border-gray-200 transition-colors", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-gray-500 uppercase tracking-wide group-hover:text-gray-700 transition-colors", children: category.stats }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
                      lineNumber: 138,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: `p-1.5 rounded-lg bg-gradient-to-br ${category.color} opacity-0 group-hover:opacity-100 transform translate-x-1 group-hover:translate-x-0 transition-all duration-300`,
                        children: /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-4 h-4 text-white" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
                          lineNumber: 144,
                          columnNumber: 27
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
                        lineNumber: 141,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
                    lineNumber: 137,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
                  lineNumber: 121,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r ${category.color} opacity-0 group-hover:opacity-100 transition-opacity duration-300`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
                    lineNumber: 149,
                    columnNumber: 21
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
              lineNumber: 114,
              columnNumber: 19
            },
            this
          ) }, category.id, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
            lineNumber: 113,
            columnNumber: 15
          }, this)
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
          lineNumber: 111,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-16 p-8 bg-gradient-to-br from-violet-50 to-indigo-50 rounded-2xl border border-violet-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsxDEV(Zap, { className: "w-6 h-6 text-violet-600 mt-1" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
            lineNumber: 159,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
            lineNumber: 158,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-slate-900 mb-2", children: "Quick Tips" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
              lineNumber: 162,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-slate-700", children: "Manage Auction whatsapp and more with Marketing Management—everything in one place." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
              lineNumber: 163,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
            lineNumber: 161,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
          lineNumber: 157,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
          lineNumber: 156,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
        lineNumber: 100,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
      lineNumber: 98,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
    lineNumber: 96,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx",
    lineNumber: 95,
    columnNumber: 5
  }, this);
};
_c = AuctionWhatsappMessageMenu;
export default AuctionWhatsappMessageMenu;
var _c;
$RefreshReg$(_c, "AuctionWhatsappMessageMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWhatsappMessageMenu.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JZO0FBbEJaLDJCQUFxQjtBQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDdkMsT0FBT0EsWUFBWTtBQUNuQixPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLE9BQU9DLFdBQVdDLGNBQWFDLFdBQVk7QUFDcEQsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsOEJBQThCO0FBQ3ZDLE9BQU9DLGdCQUFnQjtBQUl2QixNQUFNQyw2QkFBNkJBLE1BQU07QUFDdkMsUUFBTUMsNEJBQTRCO0FBQUEsSUFFL0I7QUFBQSxNQUNDQyxJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLGFBQWE7QUFBQSxNQUNiQyxNQUFNLHVCQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStCO0FBQUEsTUFDckNDLE9BQU87QUFBQSxNQUNQQyxZQUFZO0FBQUEsTUFDWkMsYUFBYTtBQUFBLE1BQ2JDLE1BQU07QUFBQTtBQUFBLE1BRU5DLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQztBQUFBLE1BQ0NSLElBQUk7QUFBQSxNQUNKQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE1BQU0sdUJBQUMsY0FBVyxXQUFVLGFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0I7QUFBQSxNQUNyQ0MsT0FBTztBQUFBLE1BQ1BDLFlBQVk7QUFBQSxNQUNaQyxhQUFhO0FBQUEsTUFDYkMsTUFBTTtBQUFBO0FBQUEsTUFFTkMsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNFO0FBQUEsTUFDQVIsSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTSx1QkFBQyxjQUFXLFdBQVUsYUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQjtBQUFBLE1BQ3JDQyxPQUFPO0FBQUEsTUFDUEMsWUFBWTtBQUFBLE1BQ1pDLGFBQWE7QUFBQSxNQUNiQyxNQUFNO0FBQUE7QUFBQSxNQUVOQyxPQUFPO0FBQUEsSUFDVDtBQUFBLElBRUc7QUFBQSxNQUNEUixJQUFJO0FBQUEsTUFDSkMsT0FBTztBQUFBLE1BQ1BDLGFBQWE7QUFBQSxNQUNiQyxNQUFNLHVCQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStCO0FBQUEsTUFDckNDLE9BQU87QUFBQSxNQUNQQyxZQUFZO0FBQUEsTUFDWkMsYUFBYTtBQUFBLE1BQ2JDLE1BQU07QUFBQTtBQUFBLE1BRU5DLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFFSztBQUFBLE1BQ0hSLElBQUk7QUFBQSxNQUNKQyxPQUFPO0FBQUEsTUFDUEMsYUFBYTtBQUFBLE1BQ2JDLE1BQU0sdUJBQUMsY0FBVyxXQUFVLGFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0I7QUFBQSxNQUNyQ0MsT0FBTztBQUFBLE1BQ1BDLFlBQVk7QUFBQSxNQUNaQyxhQUFhO0FBQUEsTUFDYkMsTUFBTTtBQUFBO0FBQUEsTUFFTkMsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUVHO0FBQUEsTUFDRFIsSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTSx1QkFBQyxjQUFXLFdBQVUsYUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQjtBQUFBLE1BQ3JDQyxPQUFPO0FBQUEsTUFDUEMsWUFBWTtBQUFBLE1BQ1pDLGFBQWE7QUFBQSxNQUNiQyxNQUFNO0FBQUE7QUFBQSxNQUVOQyxPQUFPO0FBQUEsSUFDVDtBQUFBLEVBQUM7QUFLSCxTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNiLGlDQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLDJCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFRO0FBQUEsSUFDUix1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDZCQUFDLFVBQU8sWUFBWSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFDekIsdUJBQUMsU0FBSSxXQUFVLE9BQ1Y7QUFBQSwrQkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVc7QUFBQSxRQUNkLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLG9DQUFtQyxtREFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLHNCQUFxQixrRUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ1pULG9DQUEwQlU7QUFBQUEsVUFBSSxDQUFDQyxhQUM5Qix1QkFBQyxRQUF1QixJQUFJQSxTQUFTSCxNQUFNLFdBQVUsU0FDbkQ7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVcsOERBQThERyxTQUFTSixXQUFXO0FBQUEsY0FFN0Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFXLHNEQUFzREksU0FBU04sS0FBSztBQUFBO0FBQUEsa0JBRGpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDb0w7QUFBQSxnQkFHcEwsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVyxxREFBcURNLFNBQVNMLFVBQVU7QUFBQSxzQkFFbkYsaUNBQUMsU0FBS0ssbUJBQVNQLFFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBb0I7QUFBQTtBQUFBLG9CQUh0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSUE7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDJDQUFDLFFBQUcsV0FBVSxvRkFDWE8sbUJBQVNULFNBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLE9BQUUsV0FBVSx5Q0FDVlMsbUJBQVNSLGVBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBT0E7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsaUhBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUseUdBQ2JRLG1CQUFTRixTQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFXLHNDQUFzQ0UsU0FBU04sS0FBSztBQUFBLHdCQUUvRCxpQ0FBQyxnQkFBYSxXQUFVLHdCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE0QztBQUFBO0FBQUEsc0JBSDlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFJQTtBQUFBLHVCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBU0E7QUFBQSxxQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkEwQkE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFXLHdEQUF3RE0sU0FBU04sS0FBSztBQUFBO0FBQUEsa0JBRG5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFDd0o7QUFBQTtBQUFBO0FBQUEsWUFwQzFKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXNDQSxLQXZDU00sU0FBU1YsSUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3Q0E7QUFBQSxRQUNELEtBM0NIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0Q0E7QUFBQSxRQUNFLHVCQUFDLFNBQUksV0FBVSxnR0FDakIsaUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsaUJBQ2IsaUNBQUMsT0FBSSxXQUFVLGtDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZDLEtBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsNkNBQTRDLDBCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRTtBQUFBLFlBQ3BFLHVCQUFDLE9BQUUsV0FBVSxrQkFBaUIsbUdBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlIO0FBQUEsZUFGbkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBLEtBVEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVKO0FBQUEsV0FsRUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1FQTtBQUFBLFNBckVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzRUE7QUFBQSxPQXhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUVBLEtBMUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyRUE7QUFFSjtBQUFFVyxLQWhLSWI7QUFrS04sZUFBZUE7QUFBMkIsSUFBQWE7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIk5hdmJhciIsIlNpZGViYXIiLCJVc2VycyIsIkJyaWVmY2FzZSIsIkNoZXZyb25SaWdodCIsIlphcCIsIk1kRW1haWwiLCJGYVdoYXRzYXBwIiwiUmlNb25leVJ1cGVlQ2lyY2xlTGluZSIsIkJyZWFkY3J1bWIiLCJBdWN0aW9uV2hhdHNhcHBNZXNzYWdlTWVudSIsImF1Y3Rpb253aGF0c2FwcENhdGVnb3JpZXMiLCJpZCIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJpY29uIiwiY29sb3IiLCJsaWdodENvbG9yIiwiYm9yZGVyQ29sb3IiLCJocmVmIiwic3RhdHMiLCJtYXAiLCJjYXRlZ29yeSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkF1Y3Rpb25XaGF0c2FwcE1lc3NhZ2VNZW51LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IHsgVXNlcnMsIEJyaWVmY2FzZSwgQ2hldnJvblJpZ2h0LFphcCAgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IE1kRW1haWwgfSBmcm9tIFwicmVhY3QtaWNvbnMvbWRcIjtcclxuaW1wb3J0IHsgRmFXaGF0c2FwcCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyBSaU1vbmV5UnVwZWVDaXJjbGVMaW5lIH0gZnJvbSBcInJlYWN0LWljb25zL3JpXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuXHJcblxyXG5cclxuY29uc3QgQXVjdGlvbldoYXRzYXBwTWVzc2FnZU1lbnUgPSAoKSA9PiB7XHJcbiAgY29uc3QgYXVjdGlvbndoYXRzYXBwQ2F0ZWdvcmllcyA9IFtcclxuICBcclxuICAgICB7XHJcbiAgICAgIGlkOiAxLFxyXG4gICAgICB0aXRsZTogXCJBdWN0aW9uIEludGltYXRpb25cIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiTWFuYWdlIEF1Y3Rpb24gSW50aW1hdGlvbiBNZXNzYWdlXCIsXHJcbiAgICAgIGljb246IDxGYVdoYXRzYXBwIGNsYXNzTmFtZT1cInctOCBoLThcIiAvPixcclxuICAgICAgY29sb3I6IFwiZnJvbS12aW9sZXQtNjAwIHRvLXZpb2xldC03MDBcIixcclxuICAgICAgbGlnaHRDb2xvcjogXCJiZy12aW9sZXQtNTBcIixcclxuICAgICAgYm9yZGVyQ29sb3I6IFwiYm9yZGVyLXZpb2xldC0yMDBcIixcclxuICAgICAgaHJlZjogXCIvbWFya2V0LW1lbnUvd2hhdHNhcHAtbWFya2V0aW5nL2F1Y3Rpb24td2hhdHNhcHAtbWFya2V0aW5nL2F1Y3Rpb24taW50aW1hdGlvbi1tZXNzYWdlXCIsXHJcbiAgICAvLyAgIHRhcmdldDpcIl9zZWxmXCIsXHJcbiAgICAgIHN0YXRzOiBcIkFjdGl2ZSBBdWN0aW9uIEludGltYXRpb24gV2hhdHNhcHAgTWVzc2FnZVwiLFxyXG4gICAgfSxcclxuICAgICB7XHJcbiAgICAgIGlkOiAyLFxyXG4gICAgICB0aXRsZTogXCJCaWQgV2lubmVyXCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBCaWQgV2lubmVyIE1lc3NhZ2VcIixcclxuICAgICAgaWNvbjogPEZhV2hhdHNhcHAgY2xhc3NOYW1lPVwidy04IGgtOFwiIC8+LFxyXG4gICAgICBjb2xvcjogXCJmcm9tLXZpb2xldC02MDAgdG8tdmlvbGV0LTcwMFwiLFxyXG4gICAgICBsaWdodENvbG9yOiBcImJnLXZpb2xldC01MFwiLFxyXG4gICAgICBib3JkZXJDb2xvcjogXCJib3JkZXItdmlvbGV0LTIwMFwiLFxyXG4gICAgICBocmVmOiBcIi9tYXJrZXQtbWVudS93aGF0c2FwcC1tYXJrZXRpbmcvYXVjdGlvbi13aGF0c2FwcC1tYXJrZXRpbmcvYmlkLXdpbm5lclwiLFxyXG4gICAgLy8gICB0YXJnZXQ6XCJfc2VsZlwiLFxyXG4gICAgICBzdGF0czogXCJBY3RpdmUgQmlkIFdpbm5lciBXaGF0c2FwcCBNZXNzYWdlXCIsXHJcbiAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgIGlkOiAzLFxyXG4gICAgICB0aXRsZTogXCJCaWQgU3RhdHVzXCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBCaWQgU3RhdHVzIE1lc3NhZ2VcIixcclxuICAgICAgaWNvbjogPEZhV2hhdHNhcHAgY2xhc3NOYW1lPVwidy04IGgtOFwiIC8+LFxyXG4gICAgICBjb2xvcjogXCJmcm9tLXZpb2xldC02MDAgdG8tdmlvbGV0LTcwMFwiLFxyXG4gICAgICBsaWdodENvbG9yOiBcImJnLXZpb2xldC01MFwiLFxyXG4gICAgICBib3JkZXJDb2xvcjogXCJib3JkZXItdmlvbGV0LTIwMFwiLFxyXG4gICAgICBocmVmOiBcIi9tYXJrZXQtbWVudS93aGF0c2FwcC1tYXJrZXRpbmcvYXVjdGlvbi13aGF0c2FwcC1tYXJrZXRpbmcvYmlkLXN0YXR1c1wiLFxyXG4gICAgLy8gICB0YXJnZXQ6XCJfc2VsZlwiLFxyXG4gICAgICBzdGF0czogXCJBY3RpdmUgQmlkIFN0YXR1cyBXaGF0c2FwcCBNZXNzYWdlXCIsXHJcbiAgICB9LFxyXG5cclxuICAgICAgIHtcclxuICAgICAgaWQ6IDQsXHJcbiAgICAgIHRpdGxlOiBcIldpbm5lciBEb2N1bWVudHNcIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiTWFuYWdlIEJpZCBXaW5uZXIgRG9jdW1lbnRzIE1lc3NhZ2VcIixcclxuICAgICAgaWNvbjogPEZhV2hhdHNhcHAgY2xhc3NOYW1lPVwidy04IGgtOFwiIC8+LFxyXG4gICAgICBjb2xvcjogXCJmcm9tLXZpb2xldC02MDAgdG8tdmlvbGV0LTcwMFwiLFxyXG4gICAgICBsaWdodENvbG9yOiBcImJnLXZpb2xldC01MFwiLFxyXG4gICAgICBib3JkZXJDb2xvcjogXCJib3JkZXItdmlvbGV0LTIwMFwiLFxyXG4gICAgICBocmVmOiBcIi9tYXJrZXQtbWVudS93aGF0c2FwcC1tYXJrZXRpbmcvYXVjdGlvbi13aGF0c2FwcC1tYXJrZXRpbmcvd2lubmVyLWRvY3VtZW50XCIsXHJcbiAgICAvLyAgIHRhcmdldDpcIl9zZWxmXCIsXHJcbiAgICAgIHN0YXRzOiBcIkFjdGl2ZSBCaWQgV2lubmVyIERvY3VtZW50cyBXaGF0c2FwcCBNZXNzYWdlXCIsXHJcbiAgICB9LFxyXG5cclxuICAgICAgICAge1xyXG4gICAgICBpZDogNSxcclxuICAgICAgdGl0bGU6IFwiQXVjdGlvbiBJbmZvXCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBBdWN0aW9uIEluZm8gTWVzc2FnZVwiLFxyXG4gICAgICBpY29uOiA8RmFXaGF0c2FwcCBjbGFzc05hbWU9XCJ3LTggaC04XCIgLz4sXHJcbiAgICAgIGNvbG9yOiBcImZyb20tdmlvbGV0LTYwMCB0by12aW9sZXQtNzAwXCIsXHJcbiAgICAgIGxpZ2h0Q29sb3I6IFwiYmctdmlvbGV0LTUwXCIsXHJcbiAgICAgIGJvcmRlckNvbG9yOiBcImJvcmRlci12aW9sZXQtMjAwXCIsXHJcbiAgICAgIGhyZWY6IFwiL21hcmtldC1tZW51L3doYXRzYXBwLW1hcmtldGluZy9hdWN0aW9uLXdoYXRzYXBwLW1hcmtldGluZy9hdWN0aW9uLWluZm9cIixcclxuICAgIC8vICAgdGFyZ2V0OlwiX3NlbGZcIixcclxuICAgICAgc3RhdHM6IFwiQWN0aXZlIEF1Y3Rpb24gSW5mbyBXaGF0c2FwcCBNZXNzYWdlXCIsXHJcbiAgICB9LFxyXG5cclxuICAgICAgIHtcclxuICAgICAgaWQ6IDYsXHJcbiAgICAgIHRpdGxlOiBcIkF1Y3Rpb24gVGVybXMgJiBDb25kaXRpb25zXCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBBdWN0aW9uIFRlcm1zICYgQ29uZGl0aW9ucyBNZXNzYWdlXCIsXHJcbiAgICAgIGljb246IDxGYVdoYXRzYXBwIGNsYXNzTmFtZT1cInctOCBoLThcIiAvPixcclxuICAgICAgY29sb3I6IFwiZnJvbS12aW9sZXQtNjAwIHRvLXZpb2xldC03MDBcIixcclxuICAgICAgbGlnaHRDb2xvcjogXCJiZy12aW9sZXQtNTBcIixcclxuICAgICAgYm9yZGVyQ29sb3I6IFwiYm9yZGVyLXZpb2xldC0yMDBcIixcclxuICAgICAgaHJlZjogXCIvbWFya2V0LW1lbnUvd2hhdHNhcHAtbWFya2V0aW5nL2F1Y3Rpb24td2hhdHNhcHAtbWFya2V0aW5nL2F1Y3Rpb24tdGVybXMtY29uZGl0aW9uXCIsXHJcbiAgICAvLyAgIHRhcmdldDpcIl9zZWxmXCIsXHJcbiAgICAgIHN0YXRzOiBcIkFjdGl2ZSBBdWN0aW9uIFRlcm1zICYgQ29uZGl0aW9ucyBXaGF0c2FwcCBNZXNzYWdlXCIsXHJcbiAgICB9LFxyXG4gICBcclxuICAgICBcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4taC1zY3JlZW4gdy1mdWxsIGJnLWdyYXktNTBcIj5cclxuICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICA8TmF2YmFyIHZpc2liaWxpdHk9e3RydWV9IC8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtOFwiPlxyXG4gICAgICAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLThcIj5cclxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgQXVjdGlvbiBXaGF0c2FwcCBNZXNzYWdlIE1hbmFnZW1lbnRcclxuICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgbXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgTWFuYWdlIGFuZCBvcmdhbml6ZSB5b3VyIEN1c3RvbWVyIFdoYXRzYXBwIE1lc3NhZ2VcclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIGdhcC02XCI+XHJcbiAgICAgICAgICAgICAge2F1Y3Rpb253aGF0c2FwcENhdGVnb3JpZXMubWFwKChjYXRlZ29yeSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPExpbmsga2V5PXtjYXRlZ29yeS5pZH0gdG89e2NhdGVnb3J5LmhyZWZ9IGNsYXNzTmFtZT1cImdyb3VwXCIgPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcmVsYXRpdmUgaC1mdWxsIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLXhsIGJnLXdoaXRlIGJvcmRlciAke2NhdGVnb3J5LmJvcmRlckNvbG9yfSBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMGB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BhYnNvbHV0ZSB0b3AtMCByaWdodC0wIHctMzIgaC0zMiBiZy1ncmFkaWVudC10by1iciAke2NhdGVnb3J5LmNvbG9yfSBvcGFjaXR5LTUgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMCByb3VuZGVkLWZ1bGwgLW1yLTE2IC1tdC0xNiB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgYmx1ci14bGB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBwLTdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHctMTQgaC0xNCAke2NhdGVnb3J5LmxpZ2h0Q29sb3J9IHJvdW5kZWQtbGcgbWItNSBncm91cC1ob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwYH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj57Y2F0ZWdvcnkuaWNvbn08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBtYi0yIGdyb3VwLWhvdmVyOnRleHQtZ3JheS05NTAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnkudGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2F0ZWdvcnkuZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIGdyb3VwLWhvdmVyOmJvcmRlci1ncmF5LTIwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgZ3JvdXAtaG92ZXI6dGV4dC1ncmF5LTcwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtjYXRlZ29yeS5zdGF0c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0xLjUgcm91bmRlZC1sZyBiZy1ncmFkaWVudC10by1iciAke2NhdGVnb3J5LmNvbG9yfSBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNmb3JtIHRyYW5zbGF0ZS14LTEgZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtd2hpdGVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BhYnNvbHV0ZSB0b3AtMCBsZWZ0LTAgcmlnaHQtMCBoLTAuNSBiZy1ncmFkaWVudC10by1yICR7Y2F0ZWdvcnkuY29sb3J9IG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHkgZHVyYXRpb24tMzAwYH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xNiBwLTggYmctZ3JhZGllbnQtdG8tYnIgZnJvbS12aW9sZXQtNTAgdG8taW5kaWdvLTUwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItdmlvbGV0LTEwMFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LXZpb2xldC02MDAgbXQtMVwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgbWItMlwiPlF1aWNrIFRpcHM8L2gzPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS03MDBcIj5NYW5hZ2UgQXVjdGlvbiB3aGF0c2FwcCBhbmQgbW9yZSB3aXRoIE1hcmtldGluZyBNYW5hZ2VtZW504oCUZXZlcnl0aGluZyBpbiBvbmUgcGxhY2UuPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEF1Y3Rpb25XaGF0c2FwcE1lc3NhZ2VNZW51O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvQXVjdGlvbldoYXRzYXBwTWVzc2FnZU1lbnUuanN4In0=