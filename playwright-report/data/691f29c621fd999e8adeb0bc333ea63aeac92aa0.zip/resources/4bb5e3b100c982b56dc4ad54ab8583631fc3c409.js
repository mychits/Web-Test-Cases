import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/FilterGroups.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Input, Select, Dropdown, Collapse } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
const { Panel } = Collapse;
const FilterGroups = () => {
  _s();
  const [groups, setGroups] = useState([]);
  const [TableGroups, setTableGroups] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentGroup, setCurrentGroup] = useState(null);
  const [currentUpdateGroup, setCurrentUpdateGroup] = useState(null);
  const [searchText, setSearchText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [updatingGroups, setUpdatingGroups] = useState(/* @__PURE__ */ new Set());
  const [filterGroup, setFilterGroup] = useState("");
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [formData, setFormData] = useState({
    group_name: "",
    group_type: "",
    group_value: "",
    group_install: "",
    group_members: "",
    group_duration: "",
    start_date: "",
    end_date: "",
    minimum_bid: "",
    maximum_bid: "",
    commission: 5,
    incentives: "",
    reg_fee: "",
    filter_group: "",
    createdAt: "",
    app_display_vacany_seat: "",
    auction_processing_type: "",
    auction_mode: "",
    group_code: ""
  });
  const [errors, setErrors] = useState({});
  const [updateFormData, setUpdateFormData] = useState({
    group_name: "",
    group_type: "",
    group_value: "",
    group_install: "",
    group_members: "",
    group_duration: "",
    start_date: "",
    end_date: "",
    minimum_bid: "",
    maximum_bid: "",
    commission: "",
    incentives: "",
    reg_fee: "",
    filter_group: "",
    app_display_vacany_seat: "",
    auction_processing_type: "",
    auction_mode: "",
    group_code: ""
  });
  const groupOptions = [
    { value: "New Groups", label: "New Groups" },
    { value: "Ongoing Groups", label: "Ongoing Groups" },
    { value: "Upcoming Groups", label: "Upcoming Groups" },
    { value: "Vacant Groups", label: "Vacant Groups" }
  ];
  const groupType = [
    { value: "divident", label: "Divident Group" },
    { value: "double", label: "Double Group" }
  ];
  const handleAntDSelect = (field, value) => {
    setFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: ""
    }));
  };
  const handleAntInputDSelect = (field, value) => {
    setUpdateFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors({ ...errors, [field]: "" });
  };
  const handleShareClick = (groupId) => {
    if (!groupId) {
      console.error("Missing or invalid groupId");
      return;
    }
    const baseUrl = "http://prod-chit.s3-website.eu-north-1.amazonaws.com";
    const fullUrl = `${baseUrl}/enrollment-request-form/?group_id=${groupId}`;
    window.open(fullUrl, "_blank");
  };
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/group/get-group-admin");
        const allGroups = response.data;
        setGroups(response.data);
        const filteredGroups2 = filterGroup ? allGroups.filter((group) => group?.filter_group === filterGroup) : allGroups;
        const formattedData = filteredGroups2.map((group, index) => ({
          _id: group?._id,
          checkBox: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV("div", { className: "border border-red-400 text-white px-4 py-2 rounded-md shadow hover:border-red-700 transition duration-200", children: /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "checkbox",
              checked: group.mobile_access,
              onChange: () => handleMobileAccessChange(group._id, !group.mobile_access),
              disabled: updatingGroups.has(group._id),
              className: "form-checkbox h-4 w-4 text-red-600 focus:ring-0 focus:ring-offset-0 focus:outline-none checked:bg-red-600 border-gray-300 rounded"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 146,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 145,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 144,
            columnNumber: 11
          }, this),
          id: index + 1,
          name: group?.group_name,
          type: group?.group_type.charAt(0).toUpperCase() + group?.group_type.slice(1) + " Group",
          value: group?.group_value,
          installment: group?.group_install,
          members: group?.group_members,
          filter_group: group?.filter_group,
          app_display_vacany_seat: group?.app_display_vacany_seat,
          date: group?.createdAt?.split("T")[0],
          auction_processing_type: group?.auction_processing_type,
          auction_mode: group?.auction_mode,
          group_code: group?.group_code,
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              trigger: ["click"],
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-green-600",
                        onClick: () => handleUpdateModalOpen(group?._id),
                        children: "Edit"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                        lineNumber: 189,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-red-600",
                        onClick: () => handleDeleteModalOpen(group?._id),
                        children: "Delete"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                        lineNumber: 200,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "3",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        onClick: () => handleShareClick(group?._id),
                        className: " text-violet-600 ",
                        children: "Copy"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                        lineNumber: 211,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 223,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 182,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 174,
            columnNumber: 11
          }, this)
        }));
        setTableGroups(formattedData);
      } catch (error) {
        console.error("Error fetching group data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchGroups();
  }, [updatingGroups, reloadTrigger, filterGroup]);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevData) => ({
      ...prevData,
      [name]: ""
    }));
  };
  const validateForm = (type) => {
    const newErrors = {};
    const data = type === "addGroup" ? formData : updateFormData;
    if (!data.group_name.trim()) {
      newErrors.group_name = "Group Name is required";
    }
    if (!data.group_type) {
      newErrors.group_type = "Group Type is required";
    }
    if (!data.group_value) {
      newErrors.group_value = "Group Value is required";
    } else if (isNaN(data.group_value) || data.group_value <= 0) {
      newErrors.group_value = "Group Value must be greater than zero (no";
    }
    if (!data.group_install) {
      newErrors.group_install = "Group Installment Amount is required";
    } else if (!data.group_install || isNaN(data.group_install) || data.group_install <= 0) {
      newErrors.group_install = "Group Installment Amount must be greater than zero (no symbols).";
    }
    if (!data.app_display_vacany_seat) {
      newErrors.app_display_vacany_seat = "Please Enter App Display Vacany Seat";
    }
    if (!data.group_members) {
      newErrors.group_members = "Group Members is required";
    } else if (!data.group_members || isNaN(data.group_members) || data.group_members <= 0) {
      newErrors.group_members = "Group Members must be greater than zero (no symbols).";
    }
    if (!data.group_duration) {
      newErrors.group_duration = "Group Duration is required";
    } else if (!data.group_duration || isNaN(data.group_duration) || data.group_duration <= 0) {
      newErrors.group_duration = "Group Duration must be greater than zero (no symbols).";
    }
    if (!data.reg_fee) {
      newErrors.reg_fee = "Registration Fee is required";
    } else if (!data.reg_fee || isNaN(data.reg_fee) || data.reg_fee < 0) {
      newErrors.reg_fee = "Registration Fee must be a zero or greater than zero (no symbols).";
    }
    if (!data.start_date) {
      newErrors.start_date = "Start Date is required";
    }
    if (formData.end_date && !data.end_date) {
      newErrors.end_date = "End Date is required";
    } else if (formData.end_date && new Date(data.end_date) < new Date(data.start_date)) {
      newErrors.end_date = "End Date cannot be earlier than Start Date";
    }
    if (!data.minimum_bid) {
      newErrors.minimum_bid = "Minimum Bid is required";
    } else if (!data.minimum_bid || isNaN(data.minimum_bid) || data.minimum_bid <= 0) {
      newErrors.minimum_bid = "Minimum Bid must be greater than zero (no symbols).";
    }
    if (!data.maximum_bid) {
      newErrors.maximum_bid = "Maximum Bid is required";
    } else if (!data.maximum_bid || isNaN(data.maximum_bid) || data.maximum_bid <= 0) {
      newErrors.maximum_bid = "Maximum Bid must be greater than zero (no symbols).";
    } else if (parseFloat(data.maximum_bid) < parseFloat(data.minimum_bid)) {
      newErrors.maximum_bid = "Maximum Bid must be greater than or equal to Minimum Bid";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleMobileAccessChange = async (groupId, newValue) => {
    setUpdatingGroups((prev) => /* @__PURE__ */ new Set([...prev, groupId]));
    try {
      setGroups(
        (prev) => prev.map(
          (group) => group._id === groupId ? { ...group, mobile_access: newValue } : group
        )
      );
      await api.patch(`/group/update-mobile-access/${groupId}`, {
        mobile_access: newValue
      });
      const response = await api.get("/group/get-group-admin");
      setGroups(response.data);
    } catch (error) {
      setGroups(
        (prev) => prev.map(
          (group) => group._id === groupId ? { ...group, mobile_access: !newValue } : group
        )
      );
      console.error("Error updating mobile access:", error);
      setAlertConfig({
        message: "Failed to update mobile access",
        type: "error",
        visibility: true
      });
    } finally {
      setUpdatingGroups((prev) => {
        const newSet = new Set(prev);
        newSet.delete(groupId);
        return newSet;
      });
    }
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm("addGroup");
    try {
      if (isValid) {
        const response = await api.post("/group/add-group", formData, {
          headers: {
            "Content-Type": "application/json"
          }
        });
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "Group Added Successfully",
          type: "success"
        });
        setShowModal(false);
        setFormData({
          group_name: "",
          group_type: "",
          group_value: "",
          group_install: "",
          group_members: "",
          group_duration: "",
          start_date: "",
          end_date: "",
          minimum_bid: "",
          maximum_bid: "",
          commission: "",
          filter_group: "",
          app_display_vacany_seat: "",
          auction_processing_type: "",
          auction_mode: ""
        });
      } else {
        console.log(errors);
      }
    } catch (error) {
      console.error("Error adding group:", error);
    }
  };
  const filteredGroups = groups.filter(
    (group) => group.group_name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const handleDeleteModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/group/get-by-id-group/${groupId}`);
      setCurrentGroup(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching group:", error);
    }
  };
  const handleUpdateModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/group/get-by-id-group/${groupId}`);
      const groupData = response.data;
      const formattedStartDate = groupData?.start_date?.split("T")[0];
      const formattedEndDate = groupData?.end_date?.split("T")[0];
      setCurrentUpdateGroup(response.data);
      setUpdateFormData({
        group_name: response?.data?.group_name,
        group_type: response?.data?.group_type,
        group_value: response?.data?.group_value,
        group_install: response?.data?.group_install,
        group_members: response?.data?.group_members,
        group_duration: response?.data?.group_duration,
        start_date: formattedStartDate,
        end_date: formattedEndDate,
        minimum_bid: response?.data?.minimum_bid,
        maximum_bid: response?.data?.maximum_bid,
        commission: response?.data?.commission,
        incentives: response?.data?.incentives,
        reg_fee: response?.data?.reg_fee,
        app_display_vacany_seat: response?.data?.app_display_vacany_seat,
        auction_processing_type: response?.data?.auction_processing_type,
        auction_mode: response?.data?.auction_mode,
        filter_group: response?.data?.filter_group
      });
      setShowModalUpdate(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching group:", error);
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors({ ...errors, [name]: "" });
  };
  const handleDeleteGroup = async () => {
    if (currentGroup) {
      try {
        await api.delete(`/group/delete-group/${currentGroup._id}`);
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          message: "Group deleted successfully",
          type: "success",
          visibility: true
        });
        setShowModalDelete(false);
        setCurrentGroup(null);
      } catch (error) {
        console.error("Error deleting group:", error);
      }
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    try {
      if (isValid) {
        await api.put(
          `/group/update-group/${currentUpdateGroup._id}`,
          updateFormData
        );
        setShowModalUpdate(false);
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          message: "Group updated successfully",
          type: "success",
          visibility: true
        });
      }
    } catch (error) {
      console.error("Error updating group:", error);
    }
  };
  const columns = [
    { key: "checkBox", header: "Mobile Access" },
    { key: "id", header: "SL. NO" },
    { key: "group_code", header: "Group Code" },
    { key: "name", header: "Group Name" },
    { key: "type", header: "Group Type" },
    { key: "date", header: "Created On" },
    { key: "value", header: "Group Value" },
    { key: "installment", header: "Group Installment" },
    { key: "members", header: "Group Members" },
    { key: "app_display_vacany_seat", header: "App Display Vacany Seat" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        visibility: true,
        onGlobalSearchChangeHandler
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
        lineNumber: 558,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
        lineNumber: 562,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex ", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-grow  overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl text-center font-semibold", children: "Mobile Access Groups" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
          lineNumber: 575,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => {
              setShowModal(true);
              setErrors({});
            },
            className: "ml-4 bg-violet-950 text-white px-4 py-2 rounded shadow-md hover:bg-violet-800 transition duration-200",
            children: "+ Add Group"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 580,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
        lineNumber: 574,
        columnNumber: 13
      }, this),
      TableGroups.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          catcher: "_id",
          updateHandler: handleUpdateModalOpen,
          data: filterOption(TableGroups, searchText),
          columns,
          exportedPdfName: `Filter Groups`,
          exportedFileName: `Filter Groups.csv`
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
          lineNumber: 616,
          columnNumber: 13
        },
        this
      ) : /* @__PURE__ */ jsxDEV(
        CircularLoader,
        {
          isLoading,
          failure: TableGroups.length <= 0,
          data: "Group Data"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
          lineNumber: 625,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
      lineNumber: 573,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
      lineNumber: 570,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Group" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
        lineNumber: 635,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "email",
              children: [
                "Group Name ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 672,
                  columnNumber: 30
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 668,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "text",
              name: "group_name",
              value: formData.group_name,
              onChange: handleChange,
              id: "name",
              placeholder: "Enter the Group Name",
              required: true,
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 674,
              columnNumber: 17
            },
            this
          ),
          errors.group_name && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 685,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
          lineNumber: 667,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "category",
                children: [
                  "Group Type ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 696,
                    columnNumber: 32
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 692,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                placeholder: "Select Group Type",
                popupMatchSelectWidth: false,
                showSearch: true,
                name: "group_type",
                filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                value: formData?.group_type || void 0,
                onChange: (value) => handleAntDSelect("group_type", value),
                children: groupType.map(
                  (option) => /* @__PURE__ */ jsxDEV(Select.Option, { value: option.value, children: option.label }, option.value, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 714,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 699,
                columnNumber: 19
              },
              this
            ),
            errors.group_type && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_type }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 720,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 691,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "App Display Vacany Seat",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 731,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 726,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "number",
                name: "app_display_vacany_seat",
                value: formData.app_display_vacany_seat,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter App Display Vacany Seat",
                required: true,
                className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 733,
                columnNumber: 19
              },
              this
            ),
            errors.app_display_vacany_seat && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.app_display_vacany_seat }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 744,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 725,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
          lineNumber: 690,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Group Value ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 756,
                    columnNumber: 33
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 752,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "group_value",
                value: formData.group_value,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Group Value",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 758,
                columnNumber: 19
              },
              this
            ),
            errors.group_value && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_value }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 769,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 751,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Group Installment Amount",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 780,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 775,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "group_install",
                value: formData.group_install,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Group Installment Amount",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 782,
                columnNumber: 19
              },
              this
            ),
            errors.group_install && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_install }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 793,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 774,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
          lineNumber: 750,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Group Members ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 805,
                    columnNumber: 35
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 801,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "group_members",
                value: formData.group_members,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Group Members",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 807,
                columnNumber: 19
              },
              this
            ),
            errors.group_members && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_members }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 818,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 800,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Group Duration ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 828,
                    columnNumber: 36
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 824,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "group_duration",
                value: formData.group_duration,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Group Duration",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 830,
                columnNumber: 19
              },
              this
            ),
            errors.group_duration && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_duration }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 841,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 823,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
          lineNumber: 799,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "date",
              children: [
                "Registration Fee ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 853,
                  columnNumber: 38
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 849,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "number",
              name: "reg_fee",
              value: formData.reg_fee,
              onChange: handleChange,
              id: "text",
              placeholder: "Enter Registration Fee",
              required: true,
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 855,
              columnNumber: 19
            },
            this
          ),
          errors.reg_fee && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.reg_fee }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 866,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
          lineNumber: 848,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
          lineNumber: 847,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Start Date ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 878,
                    columnNumber: 32
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 874,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "date",
                name: "start_date",
                value: formData.start_date,
                onChange: handleChange,
                id: "date",
                placeholder: "Enter the Date",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 880,
                columnNumber: 19
              },
              this
            ),
            errors.start_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.start_date }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 891,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 873,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: "End Date"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 897,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "date",
                name: "end_date",
                value: formData.end_date,
                onChange: handleChange,
                id: "date",
                placeholder: "Enter the Date",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 903,
                columnNumber: 19
              },
              this
            ),
            errors.end_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.end_date }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 914,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 896,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
          lineNumber: 872,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Minimum Bid ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 926,
                    columnNumber: 33
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 922,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "minimum_bid",
                value: formData.minimum_bid,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Minimum Bid",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 928,
                columnNumber: 19
              },
              this
            ),
            errors.minimum_bid && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.minimum_bid }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 939,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 921,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Maximum Bid ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 949,
                    columnNumber: 33
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 945,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "maximum_bid",
                value: formData.maximum_bid,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Maximum Bid",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 951,
                columnNumber: 19
              },
              this
            ),
            errors.maximum_bid && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.maximum_bid }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 962,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 944,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
          lineNumber: 920,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Commission %" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 970,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "commission",
                value: formData.commission,
                onChange: handleChange,
                placeholder: "Enter Commission",
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 973,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 969,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Incentives" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 983,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "text",
                name: "incentives",
                value: formData.incentives,
                onChange: handleChange,
                placeholder: "Enter Incentives",
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 986,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 982,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
          lineNumber: 968,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          Collapse,
          {
            defaultActiveKey: ["1"],
            className: "bg-white rounded-xl shadow-md border border-gray-200",
            children: /* @__PURE__ */ jsxDEV(
              Panel,
              {
                header: /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800", children: "Auction Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 1003,
                  columnNumber: 19
                }, this),
                children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Auction Processing Type" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                      lineNumber: 1013,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select Auction Processing Type",
                        popupMatchSelectWidth: false,
                        showSearch: true,
                        name: "auction_processing_type",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: formData?.auction_processing_type || void 0,
                        onChange: (value) => handleAntDSelect("auction_processing_type", value),
                        children: ["SYSTEM", "MANUAL"].map(
                          (stype) => /* @__PURE__ */ jsxDEV(Select.Option, { value: stype, children: stype.charAt(0).toUpperCase() + stype.slice(1).toLowerCase() }, stype, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                            lineNumber: 1031,
                            columnNumber: 25
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                        lineNumber: 1016,
                        columnNumber: 23
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1012,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Auction Mode" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                      lineNumber: 1041,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select Auction Mode",
                        popupMatchSelectWidth: false,
                        showSearch: true,
                        name: "auction_mode",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: formData?.auction_mode || void 0,
                        onChange: (value) => handleAntDSelect("auction_mode", value),
                        children: ["ONLINE", "OFFLINE"].map(
                          (stype) => /* @__PURE__ */ jsxDEV(Select.Option, { value: stype, children: stype.charAt(0).toUpperCase() + stype.slice(1).toLowerCase() }, stype, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                            lineNumber: 1059,
                            columnNumber: 25
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                        lineNumber: 1044,
                        columnNumber: 23
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1040,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 1009,
                  columnNumber: 19
                }, this)
              },
              "1",
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 1001,
                columnNumber: 17
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 997,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800\r\n              focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center border-2 border-black",
            children: "Save Group"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 1070,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
          lineNumber: 1069,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
        lineNumber: 636,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
      lineNumber: 634,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
      lineNumber: 633,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 1086,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: [
                    "Group Name ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                      lineNumber: 1124,
                      columnNumber: 30
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 1120,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "group_name",
                  value: updateFormData.group_name,
                  onChange: handleInputChange,
                  id: "name",
                  placeholder: "Enter the Group Name",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 1126,
                  columnNumber: 17
                },
                this
              ),
              errors.group_name && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_name }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 1137,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 1119,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "category",
                    children: [
                      "Group Type ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                        lineNumber: 1148,
                        columnNumber: 32
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1144,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                    placeholder: "Select Group Type",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "group_type",
                    filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                    value: updateFormData?.group_type || void 0,
                    onChange: (value) => handleAntInputDSelect("group_type", value),
                    children: groupType.map(
                      (option) => /* @__PURE__ */ jsxDEV(Select.Option, { value: option.value, children: option.label }, option.value, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                        lineNumber: 1167,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1150,
                    columnNumber: 19
                  },
                  this
                ),
                errors.group_type && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_type }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 1173,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 1143,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "App Display Vacany Seat",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                        lineNumber: 1184,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1179,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "app_display_vacany_seat",
                    value: updateFormData.app_display_vacany_seat,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter App Display Vacany Seat",
                    required: true,
                    className: `no-spinner bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1186,
                    columnNumber: 19
                  },
                  this
                ),
                errors.app_display_vacany_seat && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.app_display_vacany_seat }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 1197,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 1178,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 1142,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Group Value ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                        lineNumber: 1210,
                        columnNumber: 33
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1206,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "group_value",
                    value: updateFormData.group_value,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Group Value",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1212,
                    columnNumber: 19
                  },
                  this
                ),
                errors.group_value && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_value }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 1223,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 1205,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Group Installment Amount",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                        lineNumber: 1234,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1229,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "group_install",
                    value: updateFormData.group_install,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Group Installment Amount",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1236,
                    columnNumber: 19
                  },
                  this
                ),
                errors.group_install && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_install }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 1247,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 1228,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 1204,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Group Members ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                        lineNumber: 1259,
                        columnNumber: 35
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1255,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "group_members",
                    value: updateFormData.group_members,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Group Members",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1261,
                    columnNumber: 19
                  },
                  this
                ),
                errors.group_members && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_members }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 1272,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 1254,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Group Duration ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                        lineNumber: 1282,
                        columnNumber: 36
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1278,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "group_duration",
                    value: updateFormData.group_duration,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Group Duration",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1284,
                    columnNumber: 19
                  },
                  this
                ),
                errors.group_duration && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.group_duration }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 1295,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 1277,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 1253,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: [
                    "Registration Fee ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                      lineNumber: 1306,
                      columnNumber: 36
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 1302,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "number",
                  name: "reg_fee",
                  value: updateFormData.reg_fee,
                  onChange: handleInputChange,
                  id: "name",
                  placeholder: "Enter the Registration Fee",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 1308,
                  columnNumber: 17
                },
                this
              ),
              errors.reg_fee && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.reg_fee }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 1319,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 1301,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Start Date ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                        lineNumber: 1328,
                        columnNumber: 32
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1324,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "date",
                    name: "start_date",
                    value: updateFormData.start_date,
                    onChange: handleInputChange,
                    id: "date",
                    placeholder: "Enter the Date",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1330,
                    columnNumber: 19
                  },
                  this
                ),
                errors.start_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.start_date }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 1341,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 1323,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: "End Date"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1347,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "date",
                    name: "end_date",
                    value: updateFormData.end_date,
                    onChange: handleInputChange,
                    id: "date",
                    placeholder: "Enter the Date",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1353,
                    columnNumber: 19
                  },
                  this
                ),
                errors.end_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.end_date }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 1364,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 1346,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 1322,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Minimum Bid % ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                        lineNumber: 1376,
                        columnNumber: 35
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1372,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "minimum_bid",
                    value: updateFormData.minimum_bid,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Minimum Bid",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1378,
                    columnNumber: 19
                  },
                  this
                ),
                errors.minimum_bid && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.minimum_bid }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 1389,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 1371,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Maximum Bid % ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                        lineNumber: 1399,
                        columnNumber: 35
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1395,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "maximum_bid",
                    value: updateFormData.maximum_bid,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Maximum Bid",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1401,
                    columnNumber: 19
                  },
                  this
                ),
                errors.maximum_bid && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.maximum_bid }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 1412,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 1394,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 1370,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Commission %" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 1421,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "commission",
                    value: updateFormData.commission,
                    onChange: handleInputChange,
                    placeholder: "Enter Commission",
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1424,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 1420,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Incentives" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 1434,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "incentives",
                    value: updateFormData.incentives,
                    onChange: handleInputChange,
                    placeholder: "Enter Incentives",
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1437,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 1433,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 1419,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Collapse,
              {
                defaultActiveKey: ["1"],
                className: "bg-white rounded-xl shadow-md border border-gray-200",
                children: /* @__PURE__ */ jsxDEV(
                  Panel,
                  {
                    header: /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800", children: "Auction Details" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                      lineNumber: 1453,
                      columnNumber: 19
                    }, this),
                    children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Auction Processing Type" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                          lineNumber: 1462,
                          columnNumber: 23
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          Select,
                          {
                            className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                            placeholder: "Select Processing Type",
                            popupMatchSelectWidth: false,
                            showSearch: true,
                            name: "auction_processing_type",
                            filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                            value: updateFormData?.auction_processing_type || void 0,
                            onChange: (value) => handleAntInputDSelect(
                              "auction_processing_type",
                              value
                            ),
                            children: ["SYSTEM", "MANUAL"].map(
                              (stype) => /* @__PURE__ */ jsxDEV(Select.Option, { value: stype, children: stype.charAt(0).toUpperCase() + stype.slice(1).toLowerCase() }, stype, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                                lineNumber: 1487,
                                columnNumber: 25
                              }, this)
                            )
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                            lineNumber: 1465,
                            columnNumber: 23
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                        lineNumber: 1461,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                        /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Auction Mode" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                          lineNumber: 1497,
                          columnNumber: 23
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          Select,
                          {
                            className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                            placeholder: "Select Auction Mode",
                            popupMatchSelectWidth: false,
                            showSearch: true,
                            name: "auction_mode",
                            filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                            value: updateFormData?.auction_mode || void 0,
                            onChange: (value) => handleAntInputDSelect("auction_mode", value),
                            children: ["ONLINE", "OFFLINE"].map(
                              (stype) => /* @__PURE__ */ jsxDEV(Select.Option, { value: stype, children: stype.charAt(0).toUpperCase() + stype.slice(1).toLowerCase() }, stype, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                                lineNumber: 1517,
                                columnNumber: 25
                              }, this)
                            )
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                            lineNumber: 1500,
                            columnNumber: 23
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                        lineNumber: 1496,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                      lineNumber: 1459,
                      columnNumber: 19
                    }, this)
                  },
                  "1",
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1451,
                    columnNumber: 17
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 1447,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800\r\n              focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center border-2 border-black",
                children: "Update"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                lineNumber: 1529,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 1528,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 1089,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
          lineNumber: 1085,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
        lineNumber: 1081,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentGroup(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
            lineNumber: 1548,
            columnNumber: 13
          }, this),
          currentGroup && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteGroup();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "groupName",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentGroup.group_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                          lineNumber: 1565,
                          columnNumber: 21
                        }, this),
                        " ",
                        "to confirm deletion.",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                          lineNumber: 1569,
                          columnNumber: 21
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                      lineNumber: 1560,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      id: "groupName",
                      placeholder: "Enter the Group Name",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                      lineNumber: 1571,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                  lineNumber: 1559,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\n          focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
                    lineNumber: 1579,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
              lineNumber: 1552,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
          lineNumber: 1547,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
        lineNumber: 1540,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
    lineNumber: 557,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx",
    lineNumber: 556,
    columnNumber: 5
  }, this);
};
_s(FilterGroups, "x5pCzXkPnsNROrTj8g5IYvqWp9k=");
_c = FilterGroups;
export default FilterGroups;
var _c;
$RefreshReg$(_c, "FilterGroups");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/FilterGroups.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUpnQixTQTBaWixVQTFaWTsyQkFqSmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsU0FBU0MsT0FBT0MsUUFBUUMsVUFBVUMsZ0JBQWdCO0FBQ2xELFNBQVNDLGdCQUFnQjtBQUN6QixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsdUJBQXVCO0FBQzlCLFNBQVNDLGlCQUFpQjtBQUMxQixNQUFNLEVBQUVDLE1BQU0sSUFBSVA7QUFDbEIsTUFBTVEsZUFBZUEsTUFBTTtBQUFBQyxLQUFBO0FBQ3pCLFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJbkIsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ29CLGFBQWFDLGNBQWMsSUFBSXJCLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUNzQixZQUFZQyxhQUFhLElBQUl2QixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDd0IsV0FBV0MsWUFBWSxJQUFJekIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzBCLGlCQUFpQkMsa0JBQWtCLElBQUkzQixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDNEIsaUJBQWlCQyxrQkFBa0IsSUFBSTdCLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUM4QixjQUFjQyxlQUFlLElBQUkvQixTQUFTLElBQUk7QUFDckQsUUFBTSxDQUFDZ0Msb0JBQW9CQyxxQkFBcUIsSUFBSWpDLFNBQVMsSUFBSTtBQUNqRSxRQUFNLENBQUNrQyxZQUFZQyxhQUFhLElBQUluQyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDb0MsV0FBV0MsWUFBWSxJQUFJckMsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3NDLGVBQWVDLGdCQUFnQixJQUFJdkMsU0FBUyxDQUFDO0FBRXBELFFBQU0sQ0FBQ3dDLGdCQUFnQkMsaUJBQWlCLElBQUl6QyxTQUFTLG9CQUFJMEMsSUFBSSxDQUFDO0FBRTlELFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJNUMsU0FBUyxFQUFFO0FBQ2pELFFBQU02Qyw4QkFBOEJBLENBQUNDLE1BQU07QUFDekMsVUFBTSxFQUFFQyxNQUFNLElBQUlELEVBQUVFO0FBQ3BCYixrQkFBY1ksS0FBSztBQUFBLEVBQ3JCO0FBQ0EsUUFBTSxDQUFDRSxhQUFhQyxjQUFjLElBQUlsRCxTQUFTO0FBQUEsSUFDN0NtRCxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFFRCxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSXZELFNBQVM7QUFBQSxJQUN2Q3dELFlBQVk7QUFBQSxJQUNaQyxZQUFZO0FBQUEsSUFDWkMsYUFBYTtBQUFBLElBQ2JDLGVBQWU7QUFBQSxJQUNmQyxlQUFlO0FBQUEsSUFDZkMsZ0JBQWdCO0FBQUEsSUFDaEJDLFlBQVk7QUFBQSxJQUNaQyxVQUFVO0FBQUEsSUFDVkMsYUFBYTtBQUFBLElBQ2JDLGFBQWE7QUFBQSxJQUNiQyxZQUFZO0FBQUEsSUFDWkMsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxjQUFjO0FBQUEsSUFDZEMsV0FBVztBQUFBLElBQ1hDLHlCQUF5QjtBQUFBLElBQ3pCQyx5QkFBeUI7QUFBQSxJQUN6QkMsY0FBYztBQUFBLElBQ2RDLFlBQVk7QUFBQSxFQUNkLENBQUM7QUFDRCxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSTVFLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLFFBQU0sQ0FBQzZFLGdCQUFnQkMsaUJBQWlCLElBQUk5RSxTQUFTO0FBQUEsSUFDbkR3RCxZQUFZO0FBQUEsSUFDWkMsWUFBWTtBQUFBLElBQ1pDLGFBQWE7QUFBQSxJQUNiQyxlQUFlO0FBQUEsSUFDZkMsZUFBZTtBQUFBLElBQ2ZDLGdCQUFnQjtBQUFBLElBQ2hCQyxZQUFZO0FBQUEsSUFDWkMsVUFBVTtBQUFBLElBQ1ZDLGFBQWE7QUFBQSxJQUNiQyxhQUFhO0FBQUEsSUFDYkMsWUFBWTtBQUFBLElBQ1pDLFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsY0FBYztBQUFBLElBQ2RFLHlCQUF5QjtBQUFBLElBQ3pCQyx5QkFBeUI7QUFBQSxJQUN6QkMsY0FBYztBQUFBLElBQ2RDLFlBQVk7QUFBQSxFQUNkLENBQUM7QUFFRCxRQUFNSyxlQUFlO0FBQUEsSUFDbkIsRUFBRWhDLE9BQU8sY0FBY2lDLE9BQU8sYUFBYTtBQUFBLElBQzNDLEVBQUVqQyxPQUFPLGtCQUFrQmlDLE9BQU8saUJBQWlCO0FBQUEsSUFDbkQsRUFBRWpDLE9BQU8sbUJBQW1CaUMsT0FBTyxrQkFBa0I7QUFBQSxJQUNyRCxFQUFFakMsT0FBTyxpQkFBaUJpQyxPQUFPLGdCQUFnQjtBQUFBLEVBQUM7QUFHcEQsUUFBTUMsWUFBWTtBQUFBLElBQ2hCLEVBQUVsQyxPQUFPLFlBQVlpQyxPQUFPLGlCQUFpQjtBQUFBLElBQzdDLEVBQUVqQyxPQUFPLFVBQVVpQyxPQUFPLGVBQWU7QUFBQSxFQUFDO0FBRTVDLFFBQU1FLG1CQUFtQkEsQ0FBQ0MsT0FBT3BDLFVBQVU7QUFDekNRLGdCQUFZLENBQUM2QixjQUFjO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRCxLQUFLLEdBQUdwQztBQUFBQSxJQUNYLEVBQUU7QUFFRjZCLGNBQVUsQ0FBQ1MsZ0JBQWdCO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRixLQUFLLEdBQUc7QUFBQSxJQUNYLEVBQUU7QUFBQSxFQUNKO0FBQ0EsUUFBTUcsd0JBQXdCQSxDQUFDSCxPQUFPcEMsVUFBVTtBQUM5QytCLHNCQUFrQixDQUFDTSxjQUFjO0FBQUEsTUFDL0IsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRCxLQUFLLEdBQUdwQztBQUFBQSxJQUNYLEVBQUU7QUFFRjZCLGNBQVUsRUFBRSxHQUFHRCxRQUFRLENBQUNRLEtBQUssR0FBRyxHQUFHLENBQUM7QUFBQSxFQUN0QztBQUNBLFFBQU1JLG1CQUFtQkEsQ0FBQ0MsWUFBWTtBQUNwQyxRQUFJLENBQUNBLFNBQVM7QUFDWkMsY0FBUUMsTUFBTSw0QkFBNEI7QUFDMUM7QUFBQSxJQUNGO0FBT0EsVUFBTUMsVUFBVTtBQUNoQixVQUFNQyxVQUFVLEdBQUdELE9BQU8sc0NBQXNDSCxPQUFPO0FBRXZFSyxXQUFPQyxLQUFLRixTQUFTLFFBQVE7QUFBQSxFQUMvQjtBQUVBN0YsWUFBVSxNQUFNO0FBQ2QsVUFBTWdHLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YxRCxxQkFBYSxJQUFJO0FBQ2pCLGNBQU0yRCxXQUFXLE1BQU03RixJQUFJOEYsSUFBSSx3QkFBd0I7QUFDdkQsY0FBTUMsWUFBWUYsU0FBU0c7QUFDM0JoRixrQkFBVTZFLFNBQVNHLElBQUk7QUFDdkIsY0FBTUMsa0JBQWlCekQsY0FDbkJ1RCxVQUFVRyxPQUFPLENBQUNDLFVBQVVBLE9BQU9qQyxpQkFBaUIxQixXQUFXLElBQy9EdUQ7QUFDSixjQUFNSyxnQkFBZ0JILGdCQUFlSSxJQUFJLENBQUNGLE9BQU9HLFdBQVc7QUFBQSxVQUMxREMsS0FBS0osT0FBT0k7QUFBQUEsVUFDWkMsVUFDRSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2IsaUNBQUMsU0FBSSxXQUFVLDZHQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTTCxNQUFNTTtBQUFBQSxjQUNmLFVBQVUsTUFDUkMseUJBQXlCUCxNQUFNSSxLQUFLLENBQUNKLE1BQU1NLGFBQWE7QUFBQSxjQUUxRCxVQUFVcEUsZUFBZXNFLElBQUlSLE1BQU1JLEdBQUc7QUFBQSxjQUN0QyxXQUFVO0FBQUE7QUFBQSxZQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU8rSSxLQVJqSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLFVBRUZLLElBQUlOLFFBQVE7QUFBQSxVQUNaTyxNQUFNVixPQUFPOUM7QUFBQUEsVUFDYkgsTUFDRWlELE9BQU83QyxXQUFXd0QsT0FBTyxDQUFDLEVBQUVDLFlBQVksSUFDeENaLE9BQU83QyxXQUFXMEQsTUFBTSxDQUFDLElBQ3pCO0FBQUEsVUFDRnBFLE9BQU91RCxPQUFPNUM7QUFBQUEsVUFDZDBELGFBQWFkLE9BQU8zQztBQUFBQSxVQUNwQjBELFNBQVNmLE9BQU8xQztBQUFBQSxVQUNoQlMsY0FBY2lDLE9BQU9qQztBQUFBQSxVQUNyQkUseUJBQXlCK0IsT0FBTy9CO0FBQUFBLFVBQ2hDK0MsTUFBTWhCLE9BQU9oQyxXQUFXaUQsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLFVBQ3BDL0MseUJBQXlCOEIsT0FBTzlCO0FBQUFBLFVBQ2hDQyxjQUFjNkIsT0FBTzdCO0FBQUFBLFVBQ3JCQyxZQUFZNEIsT0FBTzVCO0FBQUFBLFVBQ25COEMsUUFDRSx1QkFBQyxTQUFJLFdBQVUsNkJBUWI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsY0FDakIsTUFBTTtBQUFBLGdCQUNKQyxPQUFPO0FBQUEsa0JBQ0w7QUFBQSxvQkFDRUMsS0FBSztBQUFBLG9CQUNMMUMsT0FDRTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUyxNQUFNMkMsc0JBQXNCckIsT0FBT0ksR0FBRztBQUFBLHdCQUFFO0FBQUE7QUFBQSxzQkFGbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsa0JBRUo7QUFBQSxrQkFDQTtBQUFBLG9CQUNFZ0IsS0FBSztBQUFBLG9CQUNMMUMsT0FDRTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUyxNQUFNNEMsc0JBQXNCdEIsT0FBT0ksR0FBRztBQUFBLHdCQUFFO0FBQUE7QUFBQSxzQkFGbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsa0JBRUo7QUFBQSxrQkFDQTtBQUFBLG9CQUNFZ0IsS0FBSztBQUFBLG9CQUNMMUMsT0FDRTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxTQUFTLE1BQU1PLGlCQUFpQmUsT0FBT0ksR0FBRztBQUFBLHdCQUMxQyxXQUFVO0FBQUEsd0JBQW1CO0FBQUE7QUFBQSxzQkFGL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsa0JBRUo7QUFBQSxnQkFBQztBQUFBLGNBRUw7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUVWLGlDQUFDLFlBQVMsV0FBVSxlQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBO0FBQUEsWUF6Q2pDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQTBDQSxLQWxERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1EQTtBQUFBLFFBRUosRUFBRTtBQUNGckYsdUJBQWVrRixhQUFhO0FBQUEsTUFDOUIsU0FBU2IsT0FBTztBQUNkRCxnQkFBUUMsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxNQUNuRCxVQUFDO0FBQ0NyRCxxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBQ0EwRCxnQkFBWTtBQUFBLEVBQ2QsR0FBRyxDQUFDdkQsZ0JBQWdCRixlQUFlSyxXQUFXLENBQUM7QUFFL0MsUUFBTWtGLGVBQWVBLENBQUMvRSxNQUFNO0FBQzFCLFVBQU0sRUFBRWtFLE1BQU1qRSxNQUFNLElBQUlELEVBQUVFO0FBRTFCTyxnQkFBWSxDQUFDNkIsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQzRCLElBQUksR0FBR2pFO0FBQUFBLElBQ1YsRUFBRTtBQUVGNkIsY0FBVSxDQUFDUSxjQUFjO0FBQUEsTUFDdkIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDNEIsSUFBSSxHQUFHO0FBQUEsSUFDVixFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU1jLGVBQWVBLENBQUN6RSxTQUFTO0FBQzdCLFVBQU0wRSxZQUFZLENBQUM7QUFFbkIsVUFBTTVCLE9BQU85QyxTQUFTLGFBQWFDLFdBQVd1QjtBQUU5QyxRQUFJLENBQUNzQixLQUFLM0MsV0FBV3dFLEtBQUssR0FBRztBQUMzQkQsZ0JBQVV2RSxhQUFhO0FBQUEsSUFDekI7QUFFQSxRQUFJLENBQUMyQyxLQUFLMUMsWUFBWTtBQUNwQnNFLGdCQUFVdEUsYUFBYTtBQUFBLElBQ3pCO0FBQ0EsUUFBSSxDQUFDMEMsS0FBS3pDLGFBQWE7QUFDckJxRSxnQkFBVXJFLGNBQWM7QUFBQSxJQUMxQixXQUFXdUUsTUFBTTlCLEtBQUt6QyxXQUFXLEtBQUt5QyxLQUFLekMsZUFBZSxHQUFHO0FBQzNEcUUsZ0JBQVVyRSxjQUFjO0FBQUEsSUFDMUI7QUFFQSxRQUFJLENBQUN5QyxLQUFLeEMsZUFBZTtBQUN2Qm9FLGdCQUFVcEUsZ0JBQWdCO0FBQUEsSUFDNUIsV0FDRSxDQUFDd0MsS0FBS3hDLGlCQUNOc0UsTUFBTTlCLEtBQUt4QyxhQUFhLEtBQ3hCd0MsS0FBS3hDLGlCQUFpQixHQUN0QjtBQUNBb0UsZ0JBQVVwRSxnQkFDUjtBQUFBLElBQ0o7QUFDQSxRQUFJLENBQUN3QyxLQUFLNUIseUJBQXlCO0FBQ2pDd0QsZ0JBQVV4RCwwQkFBMEI7QUFBQSxJQUN0QztBQUVBLFFBQUksQ0FBQzRCLEtBQUt2QyxlQUFlO0FBQ3ZCbUUsZ0JBQVVuRSxnQkFBZ0I7QUFBQSxJQUM1QixXQUNFLENBQUN1QyxLQUFLdkMsaUJBQ05xRSxNQUFNOUIsS0FBS3ZDLGFBQWEsS0FDeEJ1QyxLQUFLdkMsaUJBQWlCLEdBQ3RCO0FBQ0FtRSxnQkFBVW5FLGdCQUNSO0FBQUEsSUFDSjtBQUVBLFFBQUksQ0FBQ3VDLEtBQUt0QyxnQkFBZ0I7QUFDeEJrRSxnQkFBVWxFLGlCQUFpQjtBQUFBLElBQzdCLFdBQ0UsQ0FBQ3NDLEtBQUt0QyxrQkFDTm9FLE1BQU05QixLQUFLdEMsY0FBYyxLQUN6QnNDLEtBQUt0QyxrQkFBa0IsR0FDdkI7QUFDQWtFLGdCQUFVbEUsaUJBQ1I7QUFBQSxJQUNKO0FBRUEsUUFBSSxDQUFDc0MsS0FBSy9CLFNBQVM7QUFDakIyRCxnQkFBVTNELFVBQVU7QUFBQSxJQUN0QixXQUFXLENBQUMrQixLQUFLL0IsV0FBVzZELE1BQU05QixLQUFLL0IsT0FBTyxLQUFLK0IsS0FBSy9CLFVBQVUsR0FBRztBQUNuRTJELGdCQUFVM0QsVUFDUjtBQUFBLElBQ0o7QUFFQSxRQUFJLENBQUMrQixLQUFLckMsWUFBWTtBQUNwQmlFLGdCQUFVakUsYUFBYTtBQUFBLElBQ3pCO0FBRUEsUUFBSVIsU0FBU1MsWUFBWSxDQUFDb0MsS0FBS3BDLFVBQVU7QUFDdkNnRSxnQkFBVWhFLFdBQVc7QUFBQSxJQUN2QixXQUNFVCxTQUFTUyxZQUNULElBQUltRSxLQUFLL0IsS0FBS3BDLFFBQVEsSUFBSSxJQUFJbUUsS0FBSy9CLEtBQUtyQyxVQUFVLEdBQ2xEO0FBQ0FpRSxnQkFBVWhFLFdBQVc7QUFBQSxJQUN2QjtBQUVBLFFBQUksQ0FBQ29DLEtBQUtuQyxhQUFhO0FBQ3JCK0QsZ0JBQVUvRCxjQUFjO0FBQUEsSUFDMUIsV0FDRSxDQUFDbUMsS0FBS25DLGVBQ05pRSxNQUFNOUIsS0FBS25DLFdBQVcsS0FDdEJtQyxLQUFLbkMsZUFBZSxHQUNwQjtBQUNBK0QsZ0JBQVUvRCxjQUNSO0FBQUEsSUFDSjtBQUVBLFFBQUksQ0FBQ21DLEtBQUtsQyxhQUFhO0FBQ3JCOEQsZ0JBQVU5RCxjQUFjO0FBQUEsSUFDMUIsV0FDRSxDQUFDa0MsS0FBS2xDLGVBQ05nRSxNQUFNOUIsS0FBS2xDLFdBQVcsS0FDdEJrQyxLQUFLbEMsZUFBZSxHQUNwQjtBQUNBOEQsZ0JBQVU5RCxjQUNSO0FBQUEsSUFDSixXQUFXa0UsV0FBV2hDLEtBQUtsQyxXQUFXLElBQUlrRSxXQUFXaEMsS0FBS25DLFdBQVcsR0FBRztBQUN0RStELGdCQUFVOUQsY0FDUjtBQUFBLElBQ0o7QUFFQVcsY0FBVW1ELFNBQVM7QUFDbkIsV0FBT0ssT0FBT0MsS0FBS04sU0FBUyxFQUFFTyxXQUFXO0FBQUEsRUFDM0M7QUFFQSxRQUFNekIsMkJBQTJCLE9BQU9yQixTQUFTK0MsYUFBYTtBQUM1RDlGLHNCQUFrQixDQUFDK0YsU0FBUyxvQkFBSTlGLElBQUksQ0FBQyxHQUFHOEYsTUFBTWhELE9BQU8sQ0FBQyxDQUFDO0FBRXZELFFBQUk7QUFDRnJFO0FBQUFBLFFBQVUsQ0FBQ3FILFNBQ1RBLEtBQUtoQztBQUFBQSxVQUFJLENBQUNGLFVBQ1JBLE1BQU1JLFFBQVFsQixVQUFVLEVBQUUsR0FBR2MsT0FBT00sZUFBZTJCLFNBQVMsSUFBSWpDO0FBQUFBLFFBQ2xFO0FBQUEsTUFDRjtBQUVBLFlBQU1uRyxJQUFJc0ksTUFBTSwrQkFBK0JqRCxPQUFPLElBQUk7QUFBQSxRQUN4RG9CLGVBQWUyQjtBQUFBQSxNQUNqQixDQUFDO0FBRUQsWUFBTXZDLFdBQVcsTUFBTTdGLElBQUk4RixJQUFJLHdCQUF3QjtBQUN2RDlFLGdCQUFVNkUsU0FBU0csSUFBSTtBQUFBLElBQ3pCLFNBQVNULE9BQU87QUFDZHZFO0FBQUFBLFFBQVUsQ0FBQ3FILFNBQ1RBLEtBQUtoQztBQUFBQSxVQUFJLENBQUNGLFVBQ1JBLE1BQU1JLFFBQVFsQixVQUFVLEVBQUUsR0FBR2MsT0FBT00sZUFBZSxDQUFDMkIsU0FBUyxJQUFJakM7QUFBQUEsUUFDbkU7QUFBQSxNQUNGO0FBQ0FiLGNBQVFDLE1BQU0saUNBQWlDQSxLQUFLO0FBQ3BEeEMscUJBQWU7QUFBQSxRQUNiRSxTQUFTO0FBQUEsUUFDVEMsTUFBTTtBQUFBLFFBRU5GLFlBQVk7QUFBQSxNQUNkLENBQUM7QUFBQSxJQUNILFVBQUM7QUFDQ1Ysd0JBQWtCLENBQUMrRixTQUFTO0FBQzFCLGNBQU1FLFNBQVMsSUFBSWhHLElBQUk4RixJQUFJO0FBQzNCRSxlQUFPQyxPQUFPbkQsT0FBTztBQUNyQixlQUFPa0Q7QUFBQUEsTUFDVCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNRSxlQUFlLE9BQU85RixNQUFNO0FBQ2hDQSxNQUFFK0YsZUFBZTtBQUVqQixVQUFNQyxVQUFVaEIsYUFBYSxVQUFVO0FBQ3ZDLFFBQUk7QUFDRixVQUFJZ0IsU0FBUztBQUNYLGNBQU05QyxXQUFXLE1BQU03RixJQUFJNEksS0FBSyxvQkFBb0J6RixVQUFVO0FBQUEsVUFDNUQwRixTQUFTO0FBQUEsWUFDUCxnQkFBZ0I7QUFBQSxVQUNsQjtBQUFBLFFBQ0YsQ0FBQztBQUVEekcseUJBQWlCLENBQUNpRyxTQUFTQSxPQUFPLENBQUM7QUFDbkN0Rix1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUVENUIscUJBQWEsS0FBSztBQUNsQjhCLG9CQUFZO0FBQUEsVUFDVkMsWUFBWTtBQUFBLFVBQ1pDLFlBQVk7QUFBQSxVQUNaQyxhQUFhO0FBQUEsVUFDYkMsZUFBZTtBQUFBLFVBQ2ZDLGVBQWU7QUFBQSxVQUNmQyxnQkFBZ0I7QUFBQSxVQUNoQkMsWUFBWTtBQUFBLFVBQ1pDLFVBQVU7QUFBQSxVQUNWQyxhQUFhO0FBQUEsVUFDYkMsYUFBYTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaRyxjQUFjO0FBQUEsVUFDZEUseUJBQXlCO0FBQUEsVUFDekJDLHlCQUF5QjtBQUFBLFVBQ3pCQyxjQUFjO0FBQUEsUUFDaEIsQ0FBQztBQUFBLE1BQ0gsT0FBTztBQUNMZ0IsZ0JBQVF3RCxJQUFJdEUsTUFBTTtBQUFBLE1BQ3BCO0FBQUEsSUFDRixTQUFTZSxPQUFPO0FBQ2RELGNBQVFDLE1BQU0sdUJBQXVCQSxLQUFLO0FBQUEsSUFDNUM7QUFBQSxFQUNGO0FBRUEsUUFBTVUsaUJBQWlCbEYsT0FBT21GO0FBQUFBLElBQU8sQ0FBQ0MsVUFDcENBLE1BQU05QyxXQUFXMEYsWUFBWSxFQUFFQyxTQUFTN0gsV0FBVzRILFlBQVksQ0FBQztBQUFBLEVBQ2xFO0FBRUEsUUFBTXRCLHdCQUF3QixPQUFPcEMsWUFBWTtBQUMvQyxRQUFJO0FBQ0YsWUFBTVEsV0FBVyxNQUFNN0YsSUFBSThGLElBQUksMEJBQTBCVCxPQUFPLEVBQUU7QUFDbEV6RCxzQkFBZ0JpRSxTQUFTRyxJQUFJO0FBQzdCeEUseUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTK0QsT0FBTztBQUNkRCxjQUFRQyxNQUFNLHlCQUF5QkEsS0FBSztBQUFBLElBQzlDO0FBQUEsRUFDRjtBQUVBLFFBQU1pQyx3QkFBd0IsT0FBT25DLFlBQVk7QUFDL0MsUUFBSTtBQUNGLFlBQU1RLFdBQVcsTUFBTTdGLElBQUk4RixJQUFJLDBCQUEwQlQsT0FBTyxFQUFFO0FBQ2xFLFlBQU00RCxZQUFZcEQsU0FBU0c7QUFDM0IsWUFBTWtELHFCQUFxQkQsV0FBV3RGLFlBQVl5RCxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQzlELFlBQU0rQixtQkFBbUJGLFdBQVdyRixVQUFVd0QsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUMxRHRGLDRCQUFzQitELFNBQVNHLElBQUk7QUFDbkNyQix3QkFBa0I7QUFBQSxRQUNoQnRCLFlBQVl3QyxVQUFVRyxNQUFNM0M7QUFBQUEsUUFDNUJDLFlBQVl1QyxVQUFVRyxNQUFNMUM7QUFBQUEsUUFDNUJDLGFBQWFzQyxVQUFVRyxNQUFNekM7QUFBQUEsUUFDN0JDLGVBQWVxQyxVQUFVRyxNQUFNeEM7QUFBQUEsUUFDL0JDLGVBQWVvQyxVQUFVRyxNQUFNdkM7QUFBQUEsUUFDL0JDLGdCQUFnQm1DLFVBQVVHLE1BQU10QztBQUFBQSxRQUNoQ0MsWUFBWXVGO0FBQUFBLFFBQ1p0RixVQUFVdUY7QUFBQUEsUUFDVnRGLGFBQWFnQyxVQUFVRyxNQUFNbkM7QUFBQUEsUUFDN0JDLGFBQWErQixVQUFVRyxNQUFNbEM7QUFBQUEsUUFDN0JDLFlBQVk4QixVQUFVRyxNQUFNakM7QUFBQUEsUUFDNUJDLFlBQVk2QixVQUFVRyxNQUFNaEM7QUFBQUEsUUFDNUJDLFNBQVM0QixVQUFVRyxNQUFNL0I7QUFBQUEsUUFDekJHLHlCQUF5QnlCLFVBQVVHLE1BQU01QjtBQUFBQSxRQUN6Q0MseUJBQXlCd0IsVUFBVUcsTUFBTTNCO0FBQUFBLFFBQ3pDQyxjQUFjdUIsVUFBVUcsTUFBTTFCO0FBQUFBLFFBQzlCSixjQUFjMkIsVUFBVUcsTUFBTTlCO0FBQUFBLE1BQ2hDLENBQUM7QUFDRHhDLHlCQUFtQixJQUFJO0FBQ3ZCK0MsZ0JBQVUsQ0FBQyxDQUFDO0FBQUEsSUFDZCxTQUFTYyxPQUFPO0FBQ2RELGNBQVFDLE1BQU0seUJBQXlCQSxLQUFLO0FBQUEsSUFDOUM7QUFBQSxFQUNGO0FBRUEsUUFBTTZELG9CQUFvQkEsQ0FBQ3pHLE1BQU07QUFDL0IsVUFBTSxFQUFFa0UsTUFBTWpFLE1BQU0sSUFBSUQsRUFBRUU7QUFFMUI4QixzQkFBa0IsQ0FBQ00sY0FBYztBQUFBLE1BQy9CLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQzRCLElBQUksR0FBR2pFO0FBQUFBLElBQ1YsRUFBRTtBQUNGNkIsY0FBVSxFQUFFLEdBQUdELFFBQVEsQ0FBQ3FDLElBQUksR0FBRyxHQUFHLENBQUM7QUFBQSxFQUNyQztBQUVBLFFBQU13QyxvQkFBb0IsWUFBWTtBQUNwQyxRQUFJMUgsY0FBYztBQUNoQixVQUFJO0FBQ0YsY0FBTTNCLElBQUl3SSxPQUFPLHVCQUF1QjdHLGFBQWE0RSxHQUFHLEVBQUU7QUFFMURuRSx5QkFBaUIsQ0FBQ2lHLFNBQVNBLE9BQU8sQ0FBQztBQUNuQ3RGLHVCQUFlO0FBQUEsVUFDYkUsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxVQUNORixZQUFZO0FBQUEsUUFDZCxDQUFDO0FBRUR4QiwyQkFBbUIsS0FBSztBQUN4Qkksd0JBQWdCLElBQUk7QUFBQSxNQUN0QixTQUFTMkQsT0FBTztBQUNkRCxnQkFBUUMsTUFBTSx5QkFBeUJBLEtBQUs7QUFBQSxNQUM5QztBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTStELGVBQWUsT0FBTzNHLE1BQU07QUFDaENBLE1BQUUrRixlQUFlO0FBQ2pCLFVBQU1DLFVBQVVoQixhQUFhO0FBRTdCLFFBQUk7QUFDRixVQUFJZ0IsU0FBUztBQUNYLGNBQU0zSSxJQUFJdUo7QUFBQUEsVUFDUix1QkFBdUIxSCxtQkFBbUIwRSxHQUFHO0FBQUEsVUFDN0M3QjtBQUFBQSxRQUNGO0FBQ0FoRCwyQkFBbUIsS0FBSztBQUV4QlUseUJBQWlCLENBQUNpRyxTQUFTQSxPQUFPLENBQUM7QUFDbkN0Rix1QkFBZTtBQUFBLFVBQ2JFLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsVUFDTkYsWUFBWTtBQUFBLFFBQ2QsQ0FBQztBQUFBLE1BR0g7QUFBQSxJQUNGLFNBQVN1QyxPQUFPO0FBQ2RELGNBQVFDLE1BQU0seUJBQXlCQSxLQUFLO0FBQUEsSUFDOUM7QUFBQSxFQUNGO0FBRUEsUUFBTWlFLFVBQVU7QUFBQSxJQUNkLEVBQUVqQyxLQUFLLFlBQVlrQyxRQUFRLGdCQUFnQjtBQUFBLElBQzNDLEVBQUVsQyxLQUFLLE1BQU1rQyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFbEMsS0FBSyxjQUFja0MsUUFBUSxhQUFhO0FBQUEsSUFDMUMsRUFBRWxDLEtBQUssUUFBUWtDLFFBQVEsYUFBYTtBQUFBLElBQ3BDLEVBQUVsQyxLQUFLLFFBQVFrQyxRQUFRLGFBQWE7QUFBQSxJQUNwQyxFQUFFbEMsS0FBSyxRQUFRa0MsUUFBUSxhQUFhO0FBQUEsSUFDcEMsRUFBRWxDLEtBQUssU0FBU2tDLFFBQVEsY0FBYztBQUFBLElBQ3RDLEVBQUVsQyxLQUFLLGVBQWVrQyxRQUFRLG9CQUFvQjtBQUFBLElBQ2xELEVBQUVsQyxLQUFLLFdBQVdrQyxRQUFRLGdCQUFnQjtBQUFBLElBQzFDLEVBQUVsQyxLQUFLLDJCQUEyQmtDLFFBQVEsMEJBQTBCO0FBQUEsSUFDcEUsRUFBRWxDLEtBQUssVUFBVWtDLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHckMsU0FDRSxtQ0FDRSxpQ0FBQyxTQUNDO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFlBQVk7QUFBQSxRQUNaO0FBQUE7QUFBQSxNQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUUyRDtBQUFBLElBRTNEO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNM0csWUFBWUk7QUFBQUEsUUFDbEIsV0FBV0osWUFBWUU7QUFBQUEsUUFDdkIsU0FBU0YsWUFBWUc7QUFBQUEsUUFDckIsU0FBUyxNQUNQRixlQUFlLENBQUNzRixVQUFVLEVBQUUsR0FBR0EsTUFBTXJGLFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxNQUw3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNRztBQUFBLElBRUgsdUJBQUMsU0FBSSxXQUFVLFNBR2IsaUNBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHNDQUFxQyxvQ0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFHQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNO0FBQ2IxQiwyQkFBYSxJQUFJO0FBQ2pCbUQsd0JBQVUsQ0FBQyxDQUFDO0FBQUEsWUFDZDtBQUFBLFlBQ0EsV0FBVTtBQUFBLFlBQXVHO0FBQUE7QUFBQSxVQUxuSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQTtBQUFBLFdBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWVBO0FBQUEsTUEwQkN4RCxZQUFZa0gsU0FBUyxLQUFLLENBQUNsRyxZQUMxQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUTtBQUFBLFVBQ1IsZUFBZXVGO0FBQUFBLFVBQ2YsTUFBTWhILGFBQWFTLGFBQWFjLFVBQVU7QUFBQSxVQUMxQztBQUFBLFVBQ0EsaUJBQWlCO0FBQUEsVUFDakIsa0JBQWtCO0FBQUE7QUFBQSxRQU5wQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNd0MsSUFHeEM7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDO0FBQUEsVUFDQSxTQUFTZCxZQUFZa0gsVUFBVTtBQUFBLFVBQy9CLE1BQU07QUFBQTtBQUFBLFFBSFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BR3FCO0FBQUEsU0F2RHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwREEsS0E3REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThEQTtBQUFBLElBQ0EsdUJBQUMsU0FBTSxXQUFXOUcsV0FBVyxTQUFTLE1BQU1DLGFBQWEsS0FBSyxHQUM1RCxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsd0NBQXVDLHlCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThEO0FBQUEsTUFDOUQsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVW1ILGNBQWMsWUFBVSxNQStCNUQ7QUFBQSwrQkFBQyxTQUNDO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLFNBQVE7QUFBQSxjQUFPO0FBQUE7QUFBQSxnQkFFSix1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQztBQUFBO0FBQUE7QUFBQSxZQUo5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLE9BQU90RixTQUFTRTtBQUFBQSxjQUNoQixVQUFVcUU7QUFBQUEsY0FDVixJQUFHO0FBQUEsY0FDSCxhQUFZO0FBQUEsY0FDWjtBQUFBLGNBQ0EsV0FBVyxxQ0FBcUMvRyxVQUFVK0ksTUFBTTtBQUFBO0FBQUEsWUFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUWlLO0FBQUEsVUFFaEtsRixPQUFPbkIsY0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZtQixpQkFBT25CLGNBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQkE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsU0FBUTtBQUFBLGdCQUFVO0FBQUE7QUFBQSxrQkFFUCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQztBQUFBO0FBQUE7QUFBQSxjQUo5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsYUFBWTtBQUFBLGdCQUNaLHVCQUF1QjtBQUFBLGdCQUN2QjtBQUFBLGdCQUNBLE1BQUs7QUFBQSxnQkFDTCxjQUFjLENBQUNzRyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmQsWUFBWSxFQUNaQyxTQUFTVyxNQUFNWixZQUFZLENBQUM7QUFBQSxnQkFFakMsT0FBTzVGLFVBQVVHLGNBQWN3RztBQUFBQSxnQkFDL0IsVUFBVSxDQUFDbEgsVUFBVW1DLGlCQUFpQixjQUFjbkMsS0FBSztBQUFBLGdCQUV4RGtDLG9CQUFVdUI7QUFBQUEsa0JBQUksQ0FBQ3VELFdBQ2QsdUJBQUMsT0FBTyxRQUFQLEVBQWlDLE9BQU9BLE9BQU9oSCxPQUM3Q2dILGlCQUFPL0UsU0FEVStFLE9BQU9oSCxPQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBLGNBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQW1CQTtBQUFBLFlBQ0M0QixPQUFPbEIsY0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZrQixpQkFBT2xCLGNBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBL0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUNBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBTTtBQUFBO0FBQUEsa0JBRVU7QUFBQSxrQkFDeEIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQTtBQUFBO0FBQUEsY0FMbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPSCxTQUFTaUI7QUFBQUEsZ0JBQ2hCLFVBQVVzRDtBQUFBQSxnQkFDVixJQUFHO0FBQUEsZ0JBQ0gsYUFBWTtBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsV0FBVyxnREFBZ0QvRyxVQUFVK0ksTUFBTTtBQUFBO0FBQUEsY0FSN0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUTRLO0FBQUEsWUFFM0tsRixPQUFPSiwyQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZJLGlCQUFPSiwyQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFyQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1QkE7QUFBQSxhQTFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkRBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBTTtBQUFBO0FBQUEsa0JBRUYsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQTtBQUFBO0FBQUEsY0FKL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPakIsU0FBU0k7QUFBQUEsZ0JBQ2hCLFVBQVVtRTtBQUFBQSxnQkFDVixJQUFHO0FBQUEsZ0JBQ0gsYUFBWTtBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsV0FBVyxxQ0FBcUMvRyxVQUFVK0ksTUFBTTtBQUFBO0FBQUEsY0FSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUWlLO0FBQUEsWUFFaEtsRixPQUFPakIsZUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZpQixpQkFBT2pCLGVBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0JBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBTTtBQUFBO0FBQUEsa0JBRVc7QUFBQSxrQkFDekIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQTtBQUFBO0FBQUEsY0FMbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPSixTQUFTSztBQUFBQSxnQkFDaEIsVUFBVWtFO0FBQUFBLGdCQUNWLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFXLHFDQUFxQy9HLFVBQVUrSSxNQUFNO0FBQUE7QUFBQSxjQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRaUs7QUFBQSxZQUVoS2xGLE9BQU9oQixpQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZnQixpQkFBT2hCLGlCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQXJCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVCQTtBQUFBLGFBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnREE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsU0FBUTtBQUFBLGdCQUFNO0FBQUE7QUFBQSxrQkFFQSx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQztBQUFBO0FBQUE7QUFBQSxjQUpqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9MLFNBQVNNO0FBQUFBLGdCQUNoQixVQUFVaUU7QUFBQUEsZ0JBQ1YsSUFBRztBQUFBLGdCQUNILGFBQVk7QUFBQSxnQkFDWjtBQUFBLGdCQUNBLFdBQVcscUNBQXFDL0csVUFBVStJLE1BQU07QUFBQTtBQUFBLGNBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFpSztBQUFBLFlBRWhLbEYsT0FBT2YsaUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWZSxpQkFBT2YsaUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0JBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBTTtBQUFBO0FBQUEsa0JBRUMsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQTtBQUFBO0FBQUEsY0FKbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPTixTQUFTTztBQUFBQSxnQkFDaEIsVUFBVWdFO0FBQUFBLGdCQUNWLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFXLHFDQUFxQy9HLFVBQVUrSSxNQUFNO0FBQUE7QUFBQSxjQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRaUs7QUFBQSxZQUVoS2xGLE9BQU9kLGtCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmMsaUJBQU9kLGtCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBLGFBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErQ0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYixpQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixTQUFRO0FBQUEsY0FBTTtBQUFBO0FBQUEsZ0JBRUcsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUM7QUFBQTtBQUFBO0FBQUEsWUFKcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxNQUFLO0FBQUEsY0FDTCxPQUFPUCxTQUFTYztBQUFBQSxjQUNoQixVQUFVeUQ7QUFBQUEsY0FDVixJQUFHO0FBQUEsY0FDSCxhQUFZO0FBQUEsY0FDWjtBQUFBLGNBQ0EsV0FBVyxxQ0FBcUMvRyxVQUFVK0ksTUFBTTtBQUFBO0FBQUEsWUFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUWlLO0FBQUEsVUFFaEtsRixPQUFPUCxXQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVk8saUJBQU9QLFdBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFzQkEsS0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFRO0FBQUEsZ0JBQU07QUFBQTtBQUFBLGtCQUVILHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlDO0FBQUE7QUFBQTtBQUFBLGNBSjlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsT0FBT2QsU0FBU1E7QUFBQUEsZ0JBQ2hCLFVBQVUrRDtBQUFBQSxnQkFDVixJQUFHO0FBQUEsZ0JBQ0gsYUFBWTtBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsV0FBVyxxQ0FBcUMvRyxVQUFVK0ksTUFBTTtBQUFBO0FBQUEsY0FSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUWlLO0FBQUEsWUFFaEtsRixPQUFPYixjQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmEsaUJBQU9iLGNBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0JBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBTTtBQUFBO0FBQUEsY0FGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPUixTQUFTUztBQUFBQSxnQkFDaEIsVUFBVThEO0FBQUFBLGdCQUNWLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFXLHFDQUFxQy9HLFVBQVUrSSxNQUFNO0FBQUE7QUFBQSxjQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRaUs7QUFBQSxZQUVoS2xGLE9BQU9aLFlBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWWSxpQkFBT1osWUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQSxhQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0NBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBTTtBQUFBO0FBQUEsa0JBRUYsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQTtBQUFBO0FBQUEsY0FKL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPVCxTQUFTVTtBQUFBQSxnQkFDaEIsVUFBVTZEO0FBQUFBLGdCQUNWLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFXLHFDQUFxQy9HLFVBQVUrSSxNQUFNO0FBQUE7QUFBQSxjQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRaUs7QUFBQSxZQUVoS2xGLE9BQU9YLGVBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWVyxpQkFBT1gsZUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsU0FBUTtBQUFBLGdCQUFNO0FBQUE7QUFBQSxrQkFFRix1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQztBQUFBO0FBQUE7QUFBQSxjQUovQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9WLFNBQVNXO0FBQUFBLGdCQUNoQixVQUFVNEQ7QUFBQUEsZ0JBQ1YsSUFBRztBQUFBLGdCQUNILGFBQVk7QUFBQSxnQkFDWjtBQUFBLGdCQUNBLFdBQVcscUNBQXFDL0csVUFBVStJLE1BQU07QUFBQTtBQUFBLGNBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFpSztBQUFBLFlBRWhLbEYsT0FBT1YsZUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZVLGlCQUFPVixlQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBLGFBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErQ0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9YLFNBQVNZO0FBQUFBLGdCQUNoQixVQUFVMkQ7QUFBQUEsZ0JBQ1YsYUFBWTtBQUFBLGdCQUNaLFdBQVcscUNBQXFDL0csVUFBVStJLE1BQU07QUFBQTtBQUFBLGNBTmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1pSztBQUFBLGVBVm5LO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQywwQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU92RyxTQUFTYTtBQUFBQSxnQkFDaEIsVUFBVTBEO0FBQUFBLGdCQUNWLGFBQVk7QUFBQSxnQkFDWixXQUFXLHFDQUFxQy9HLFVBQVUrSSxNQUFNO0FBQUE7QUFBQSxjQU5sRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNaUs7QUFBQSxlQVZuSztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsYUExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJCQTtBQUFBLFFBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLGtCQUFrQixDQUFDLEdBQUc7QUFBQSxZQUN0QixXQUFVO0FBQUEsWUFFVjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFFBQ0UsdUJBQUMsVUFBSyxXQUFVLHVDQUFzQywrQkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUlGLGlDQUFDLFNBQUksV0FBVSwyQ0FHYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyx1Q0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1osdUJBQXVCO0FBQUEsd0JBQ3ZCO0FBQUEsd0JBQ0EsTUFBSztBQUFBLHdCQUNMLGNBQWMsQ0FBQ0MsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQVNkLFlBQVksRUFBRUMsU0FBU1csTUFBTVosWUFBWSxDQUFDO0FBQUEsd0JBRTVELE9BQU81RixVQUFVa0IsMkJBQTJCeUY7QUFBQUEsd0JBQzVDLFVBQVUsQ0FBQ2xILFVBQ1RtQyxpQkFBaUIsMkJBQTJCbkMsS0FBSztBQUFBLHdCQUdsRCxXQUFDLFVBQVUsUUFBUSxFQUFFeUQ7QUFBQUEsMEJBQUksQ0FBQzBELFVBQ3pCLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPQSxPQUMvQkEsZ0JBQU1qRCxPQUFPLENBQUMsRUFBRUMsWUFBWSxJQUMzQmdELE1BQU0vQyxNQUFNLENBQUMsRUFBRStCLFlBQVksS0FGWGdCLE9BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBR0E7QUFBQSx3QkFDRDtBQUFBO0FBQUEsc0JBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFvQkE7QUFBQSx1QkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF5QkE7QUFBQSxrQkFHQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLHVCQUF1QjtBQUFBLHdCQUN2QjtBQUFBLHdCQUNBLE1BQUs7QUFBQSx3QkFDTCxjQUFjLENBQUNKLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUFTZCxZQUFZLEVBQUVDLFNBQVNXLE1BQU1aLFlBQVksQ0FBQztBQUFBLHdCQUU1RCxPQUFPNUYsVUFBVW1CLGdCQUFnQndGO0FBQUFBLHdCQUNqQyxVQUFVLENBQUNsSCxVQUNUbUMsaUJBQWlCLGdCQUFnQm5DLEtBQUs7QUFBQSx3QkFHdkMsV0FBQyxVQUFVLFNBQVMsRUFBRXlEO0FBQUFBLDBCQUFJLENBQUMwRCxVQUMxQix1QkFBQyxPQUFPLFFBQVAsRUFBMEIsT0FBT0EsT0FDL0JBLGdCQUFNakQsT0FBTyxDQUFDLEVBQUVDLFlBQVksSUFDM0JnRCxNQUFNL0MsTUFBTSxDQUFDLEVBQUUrQixZQUFZLEtBRlhnQixPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUdBO0FBQUEsd0JBQ0Q7QUFBQTtBQUFBLHNCQW5CSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBb0JBO0FBQUEsdUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBeUJBO0FBQUEscUJBeERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBeURBO0FBQUE7QUFBQSxjQTNESTtBQUFBLGNBTk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWtFQTtBQUFBO0FBQUEsVUF0RUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBdUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUNxSDtBQUFBO0FBQUEsVUFIakk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQXpiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMGJBO0FBQUEsU0E1YkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZiQSxLQTliRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK2JBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV3RJO0FBQUFBLFFBQ1gsU0FBUyxNQUFNQyxtQkFBbUIsS0FBSztBQUFBLFFBRXZDLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMsNEJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVU0SCxjQUFjLFlBQVUsTUE4QjVEO0FBQUEsbUNBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQU87QUFBQTtBQUFBLG9CQUVKLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUE7QUFBQTtBQUFBLGdCQUo5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPNUUsZUFBZXJCO0FBQUFBLGtCQUN0QixVQUFVK0Y7QUFBQUEsa0JBQ1YsSUFBRztBQUFBLGtCQUNILGFBQVk7QUFBQSxrQkFDWjtBQUFBLGtCQUNBLFdBQVcscUNBQXFDekksVUFBVStJLE1BQU07QUFBQTtBQUFBLGdCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRaUs7QUFBQSxjQUVoS2xGLE9BQU9uQixjQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVm1CLGlCQUFPbkIsY0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQVU7QUFBQTtBQUFBLHNCQUVQLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUo5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsYUFBWTtBQUFBLG9CQUNaLHVCQUF1QjtBQUFBLG9CQUN2QjtBQUFBLG9CQUNBLE1BQUs7QUFBQSxvQkFDTCxjQUFjLENBQUNzRyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmQsWUFBWSxFQUNaQyxTQUFTVyxNQUFNWixZQUFZLENBQUM7QUFBQSxvQkFFakMsT0FBT3JFLGdCQUFnQnBCLGNBQWN3RztBQUFBQSxvQkFDckMsVUFBVSxDQUFDbEgsVUFDVHVDLHNCQUFzQixjQUFjdkMsS0FBSztBQUFBLG9CQUcxQ2tDLG9CQUFVdUI7QUFBQUEsc0JBQUksQ0FBQ3VELFdBQ2QsdUJBQUMsT0FBTyxRQUFQLEVBQWlDLE9BQU9BLE9BQU9oSCxPQUM3Q2dILGlCQUFPL0UsU0FEVStFLE9BQU9oSCxPQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBLGtCQXBCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBcUJBO0FBQUEsZ0JBQ0M0QixPQUFPbEIsY0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZrQixpQkFBT2xCLGNBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQWhDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWtDQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxzQkFFVTtBQUFBLHNCQUN4Qix1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFMbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPb0IsZUFBZU47QUFBQUEsb0JBQ3RCLFVBQVVnRjtBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxnREFBZ0R6SSxVQUFVK0ksTUFBTTtBQUFBO0FBQUEsa0JBUjdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRNEs7QUFBQSxnQkFFM0tsRixPQUFPSiwyQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZJLGlCQUFPSiwyQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdUJBO0FBQUEsaUJBM0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNERBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLHNCQUVGLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUovQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9NLGVBQWVuQjtBQUFBQSxvQkFDdEIsVUFBVTZGO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLHFDQUFxQ3pJLFVBQVUrSSxNQUFNO0FBQUE7QUFBQSxrQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVFpSztBQUFBLGdCQUVoS2xGLE9BQU9qQixlQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmlCLGlCQUFPakIsZUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0JBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLHNCQUVXO0FBQUEsc0JBQ3pCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUxuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9tQixlQUFlbEI7QUFBQUEsb0JBQ3RCLFVBQVU0RjtBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxxQ0FBcUN6SSxVQUFVK0ksTUFBTTtBQUFBO0FBQUEsa0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRaUs7QUFBQSxnQkFFaEtsRixPQUFPaEIsaUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWZ0IsaUJBQU9oQixpQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdUJBO0FBQUEsaUJBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0RBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLHNCQUVBLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUpqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9rQixlQUFlakI7QUFBQUEsb0JBQ3RCLFVBQVUyRjtBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxxQ0FBcUN6SSxVQUFVK0ksTUFBTTtBQUFBO0FBQUEsa0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRaUs7QUFBQSxnQkFFaEtsRixPQUFPZixpQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZlLGlCQUFPZixpQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0JBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLHNCQUVDLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUpsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9pQixlQUFlaEI7QUFBQUEsb0JBQ3RCLFVBQVUwRjtBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxxQ0FBcUN6SSxVQUFVK0ksTUFBTTtBQUFBO0FBQUEsa0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRaUs7QUFBQSxnQkFFaEtsRixPQUFPZCxrQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZjLGlCQUFPZCxrQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0JBO0FBQUEsaUJBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0NBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBTztBQUFBO0FBQUEsb0JBRUUsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQTtBQUFBO0FBQUEsZ0JBSnBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU9nQixlQUFlVDtBQUFBQSxrQkFDdEIsVUFBVW1GO0FBQUFBLGtCQUNWLElBQUc7QUFBQSxrQkFDSCxhQUFZO0FBQUEsa0JBQ1o7QUFBQSxrQkFDQSxXQUFXLHFDQUFxQ3pJLFVBQVUrSSxNQUFNO0FBQUE7QUFBQSxnQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUWlLO0FBQUEsY0FFaEtsRixPQUFPUCxXQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJPLGlCQUFPUCxXQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RDtBQUFBLGlCQWxCN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQkE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBTTtBQUFBO0FBQUEsc0JBRUgsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUM7QUFBQTtBQUFBO0FBQUEsa0JBSjlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT1MsZUFBZWY7QUFBQUEsb0JBQ3RCLFVBQVV5RjtBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxxQ0FBcUN6SSxVQUFVK0ksTUFBTTtBQUFBO0FBQUEsa0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRaUs7QUFBQSxnQkFFaEtsRixPQUFPYixjQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmEsaUJBQU9iLGNBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNCQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxrQkFGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPZSxlQUFlZDtBQUFBQSxvQkFDdEIsVUFBVXdGO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLHFDQUFxQ3pJLFVBQVUrSSxNQUFNO0FBQUE7QUFBQSxrQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVFpSztBQUFBLGdCQUVoS2xGLE9BQU9aLFlBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWWSxpQkFBT1osWUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0JBO0FBQUEsaUJBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0NBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLHNCQUVBLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUpqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9jLGVBQWViO0FBQUFBLG9CQUN0QixVQUFVdUY7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDekksVUFBVStJLE1BQU07QUFBQTtBQUFBLGtCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUWlLO0FBQUEsZ0JBRWhLbEYsT0FBT1gsZUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZXLGlCQUFPWCxlQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFzQkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBTTtBQUFBO0FBQUEsc0JBRUEsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUM7QUFBQTtBQUFBO0FBQUEsa0JBSmpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT2EsZUFBZVo7QUFBQUEsb0JBQ3RCLFVBQVVzRjtBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxxQ0FBcUN6SSxVQUFVK0ksTUFBTTtBQUFBO0FBQUEsa0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRaUs7QUFBQSxnQkFFaEtsRixPQUFPVixlQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVlUsaUJBQU9WLGVBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNCQTtBQUFBLGlCQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQStDQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPWSxlQUFlWDtBQUFBQSxvQkFDdEIsVUFBVXFGO0FBQUFBLG9CQUNWLGFBQVk7QUFBQSxvQkFDWixXQUFXLHFDQUFxQ3pJLFVBQVUrSSxNQUFNO0FBQUE7QUFBQSxrQkFObEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1pSztBQUFBLG1CQVZuSztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0MsMEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9oRixlQUFlVjtBQUFBQSxvQkFDdEIsVUFBVW9GO0FBQUFBLG9CQUNWLGFBQVk7QUFBQSxvQkFDWixXQUFXLHFDQUFxQ3pJLFVBQVUrSSxNQUFNO0FBQUE7QUFBQSxrQkFObEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1pSztBQUFBLG1CQVZuSztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsaUJBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkJBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLGtCQUFrQixDQUFDLEdBQUc7QUFBQSxnQkFDdEIsV0FBVTtBQUFBLGdCQUVWO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFFBQ0UsdUJBQUMsVUFBSyxXQUFVLHVDQUFzQywrQkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUlGLGlDQUFDLFNBQUksV0FBVSwyQ0FFYjtBQUFBLDZDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsK0NBQUMsV0FBTSxXQUFVLGdEQUErQyx1Q0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHdCQUNBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVU7QUFBQSw0QkFDVixhQUFZO0FBQUEsNEJBQ1osdUJBQXVCO0FBQUEsNEJBQ3ZCO0FBQUEsNEJBQ0EsTUFBSztBQUFBLDRCQUNMLGNBQWMsQ0FBQ0MsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pkLFlBQVksRUFDWkMsU0FBU1csTUFBTVosWUFBWSxDQUFDO0FBQUEsNEJBRWpDLE9BQ0VyRSxnQkFBZ0JMLDJCQUEyQnlGO0FBQUFBLDRCQUU3QyxVQUFVLENBQUNsSCxVQUNUdUM7QUFBQUEsOEJBQ0U7QUFBQSw4QkFDQXZDO0FBQUFBLDRCQUNGO0FBQUEsNEJBR0QsV0FBQyxVQUFVLFFBQVEsRUFBRXlEO0FBQUFBLDhCQUFJLENBQUMwRCxVQUN6Qix1QkFBQyxPQUFPLFFBQVAsRUFBMEIsT0FBT0EsT0FDL0JBLGdCQUFNakQsT0FBTyxDQUFDLEVBQUVDLFlBQVksSUFDM0JnRCxNQUFNL0MsTUFBTSxDQUFDLEVBQUUrQixZQUFZLEtBRlhnQixPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUdBO0FBQUEsNEJBQ0Q7QUFBQTtBQUFBLDBCQTFCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBMkJBO0FBQUEsMkJBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBZ0NBO0FBQUEsc0JBR0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwrQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQ0E7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVTtBQUFBLDRCQUNWLGFBQVk7QUFBQSw0QkFDWix1QkFBdUI7QUFBQSw0QkFDdkI7QUFBQSw0QkFDQSxNQUFLO0FBQUEsNEJBQ0wsY0FBYyxDQUFDSixPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmQsWUFBWSxFQUNaQyxTQUFTVyxNQUFNWixZQUFZLENBQUM7QUFBQSw0QkFFakMsT0FBT3JFLGdCQUFnQkosZ0JBQWdCd0Y7QUFBQUEsNEJBQ3ZDLFVBQVUsQ0FBQ2xILFVBQ1R1QyxzQkFBc0IsZ0JBQWdCdkMsS0FBSztBQUFBLDRCQUc1QyxXQUFDLFVBQVUsU0FBUyxFQUFFeUQ7QUFBQUEsOEJBQUksQ0FBQzBELFVBQzFCLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPQSxPQUMvQkEsZ0JBQU1qRCxPQUFPLENBQUMsRUFBRUMsWUFBWSxJQUMzQmdELE1BQU0vQyxNQUFNLENBQUMsRUFBRStCLFlBQVksS0FGWGdCLE9BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBR0E7QUFBQSw0QkFDRDtBQUFBO0FBQUEsMEJBckJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFzQkE7QUFBQSwyQkExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkEyQkE7QUFBQSx5QkFoRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFpRUE7QUFBQTtBQUFBLGtCQW5FSTtBQUFBLGtCQU5OO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBMEVBO0FBQUE7QUFBQSxjQTlFRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUErRUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ3FIO0FBQUE7QUFBQSxjQUhqSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQS9iRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdjQTtBQUFBLGFBcGNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxY0E7QUFBQTtBQUFBLE1BemNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQTBjQTtBQUFBLElBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVd4STtBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiQyw2QkFBbUIsS0FBSztBQUN4QkksMEJBQWdCLElBQUk7QUFBQSxRQUN0QjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1Qyw0QkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0NELGdCQUNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxVQUFVLENBQUNnQixNQUFNO0FBQ2ZBLGtCQUFFK0YsZUFBZTtBQUNqQlcsa0NBQWtCO0FBQUEsY0FDcEI7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsU0FDQztBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixTQUFRO0FBQUEsc0JBQVc7QUFBQTtBQUFBLHdCQUVOO0FBQUEsd0JBQ2IsdUJBQUMsVUFBSyxXQUFVLDBCQUNiMUgsdUJBQWEwQixjQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQVE7QUFBQSx3QkFBSTtBQUFBLHdCQUNTO0FBQUEsd0JBQ3JCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWlDO0FBQUE7QUFBQTtBQUFBLG9CQVRuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBVUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWjtBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLMkk7QUFBQSxxQkFqQjdJO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBbUJBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDMkY7QUFBQTtBQUFBLGtCQUh2RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQTtBQUFBO0FBQUEsWUFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBa0NBO0FBQUEsYUF2Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlDQTtBQUFBO0FBQUEsTUFoREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBaURBO0FBQUEsT0F4Z0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5Z0NBLEtBMWdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMmdDQTtBQUVKO0FBQUV2QyxHQTFpRElELGNBQVk7QUFBQW1KLEtBQVpuSjtBQTRpRE4sZUFBZUE7QUFBYSxJQUFBbUo7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiU2lkZWJhciIsIk1vZGFsIiwiYXBpIiwiRGF0YVRhYmxlIiwiSW5wdXQiLCJTZWxlY3QiLCJEcm9wZG93biIsIkNvbGxhcHNlIiwiSW9NZE1vcmUiLCJOYXZiYXIiLCJmaWx0ZXJPcHRpb24iLCJDaXJjdWxhckxvYWRlciIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwiZmllbGRTaXplIiwiUGFuZWwiLCJGaWx0ZXJHcm91cHMiLCJfcyIsImdyb3VwcyIsInNldEdyb3VwcyIsIlRhYmxlR3JvdXBzIiwic2V0VGFibGVHcm91cHMiLCJzZWFyY2hUZXJtIiwic2V0U2VhcmNoVGVybSIsInNob3dNb2RhbCIsInNldFNob3dNb2RhbCIsInNob3dNb2RhbERlbGV0ZSIsInNldFNob3dNb2RhbERlbGV0ZSIsInNob3dNb2RhbFVwZGF0ZSIsInNldFNob3dNb2RhbFVwZGF0ZSIsImN1cnJlbnRHcm91cCIsInNldEN1cnJlbnRHcm91cCIsImN1cnJlbnRVcGRhdGVHcm91cCIsInNldEN1cnJlbnRVcGRhdGVHcm91cCIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJ1cGRhdGluZ0dyb3VwcyIsInNldFVwZGF0aW5nR3JvdXBzIiwiU2V0IiwiZmlsdGVyR3JvdXAiLCJzZXRGaWx0ZXJHcm91cCIsIm9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciIsImUiLCJ2YWx1ZSIsInRhcmdldCIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsInR5cGUiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwiZ3JvdXBfbmFtZSIsImdyb3VwX3R5cGUiLCJncm91cF92YWx1ZSIsImdyb3VwX2luc3RhbGwiLCJncm91cF9tZW1iZXJzIiwiZ3JvdXBfZHVyYXRpb24iLCJzdGFydF9kYXRlIiwiZW5kX2RhdGUiLCJtaW5pbXVtX2JpZCIsIm1heGltdW1fYmlkIiwiY29tbWlzc2lvbiIsImluY2VudGl2ZXMiLCJyZWdfZmVlIiwiZmlsdGVyX2dyb3VwIiwiY3JlYXRlZEF0IiwiYXBwX2Rpc3BsYXlfdmFjYW55X3NlYXQiLCJhdWN0aW9uX3Byb2Nlc3NpbmdfdHlwZSIsImF1Y3Rpb25fbW9kZSIsImdyb3VwX2NvZGUiLCJlcnJvcnMiLCJzZXRFcnJvcnMiLCJ1cGRhdGVGb3JtRGF0YSIsInNldFVwZGF0ZUZvcm1EYXRhIiwiZ3JvdXBPcHRpb25zIiwibGFiZWwiLCJncm91cFR5cGUiLCJoYW5kbGVBbnREU2VsZWN0IiwiZmllbGQiLCJwcmV2RGF0YSIsInByZXZFcnJvcnMiLCJoYW5kbGVBbnRJbnB1dERTZWxlY3QiLCJoYW5kbGVTaGFyZUNsaWNrIiwiZ3JvdXBJZCIsImNvbnNvbGUiLCJlcnJvciIsImJhc2VVcmwiLCJmdWxsVXJsIiwid2luZG93Iiwib3BlbiIsImZldGNoR3JvdXBzIiwicmVzcG9uc2UiLCJnZXQiLCJhbGxHcm91cHMiLCJkYXRhIiwiZmlsdGVyZWRHcm91cHMiLCJmaWx0ZXIiLCJncm91cCIsImZvcm1hdHRlZERhdGEiLCJtYXAiLCJpbmRleCIsIl9pZCIsImNoZWNrQm94IiwibW9iaWxlX2FjY2VzcyIsImhhbmRsZU1vYmlsZUFjY2Vzc0NoYW5nZSIsImhhcyIsImlkIiwibmFtZSIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwic2xpY2UiLCJpbnN0YWxsbWVudCIsIm1lbWJlcnMiLCJkYXRlIiwic3BsaXQiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImhhbmRsZVVwZGF0ZU1vZGFsT3BlbiIsImhhbmRsZURlbGV0ZU1vZGFsT3BlbiIsImhhbmRsZUNoYW5nZSIsInZhbGlkYXRlRm9ybSIsIm5ld0Vycm9ycyIsInRyaW0iLCJpc05hTiIsIkRhdGUiLCJwYXJzZUZsb2F0IiwiT2JqZWN0Iiwia2V5cyIsImxlbmd0aCIsIm5ld1ZhbHVlIiwicHJldiIsInBhdGNoIiwibmV3U2V0IiwiZGVsZXRlIiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJpc1ZhbGlkIiwicG9zdCIsImhlYWRlcnMiLCJsb2ciLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiZ3JvdXBEYXRhIiwiZm9ybWF0dGVkU3RhcnREYXRlIiwiZm9ybWF0dGVkRW5kRGF0ZSIsImhhbmRsZUlucHV0Q2hhbmdlIiwiaGFuZGxlRGVsZXRlR3JvdXAiLCJoYW5kbGVVcGRhdGUiLCJwdXQiLCJjb2x1bW5zIiwiaGVhZGVyIiwiaGVpZ2h0IiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInVuZGVmaW5lZCIsInN0eXBlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRmlsdGVyR3JvdXBzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgeyBJbnB1dCwgU2VsZWN0LCBEcm9wZG93biwgQ29sbGFwc2UgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydERpYWxvZyBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2dcIjtcclxuaW1wb3J0IHsgZmllbGRTaXplIH0gZnJvbSBcIi4uL2RhdGEvZmllbGRTaXplXCI7XHJcbmNvbnN0IHsgUGFuZWwgfSA9IENvbGxhcHNlO1xyXG5jb25zdCBGaWx0ZXJHcm91cHMgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2dyb3Vwcywgc2V0R3JvdXBzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbVGFibGVHcm91cHMsIHNldFRhYmxlR3JvdXBzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VhcmNoVGVybSwgc2V0U2VhcmNoVGVybV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2hvd01vZGFsLCBzZXRTaG93TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWxEZWxldGUsIHNldFNob3dNb2RhbERlbGV0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbFVwZGF0ZSwgc2V0U2hvd01vZGFsVXBkYXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudEdyb3VwLCBzZXRDdXJyZW50R3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2N1cnJlbnRVcGRhdGVHcm91cCwgc2V0Q3VycmVudFVwZGF0ZUdyb3VwXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3JlbG9hZFRyaWdnZXIsIHNldFJlbG9hZFRyaWdnZXJdID0gdXNlU3RhdGUoMCk7XHJcblxyXG4gIGNvbnN0IFt1cGRhdGluZ0dyb3Vwcywgc2V0VXBkYXRpbmdHcm91cHNdID0gdXNlU3RhdGUobmV3IFNldCgpKTtcclxuXHJcbiAgY29uc3QgW2ZpbHRlckdyb3VwLCBzZXRGaWx0ZXJHcm91cF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRTZWFyY2hUZXh0KHZhbHVlKTtcclxuICB9O1xyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgZ3JvdXBfbmFtZTogXCJcIixcclxuICAgIGdyb3VwX3R5cGU6IFwiXCIsXHJcbiAgICBncm91cF92YWx1ZTogXCJcIixcclxuICAgIGdyb3VwX2luc3RhbGw6IFwiXCIsXHJcbiAgICBncm91cF9tZW1iZXJzOiBcIlwiLFxyXG4gICAgZ3JvdXBfZHVyYXRpb246IFwiXCIsXHJcbiAgICBzdGFydF9kYXRlOiBcIlwiLFxyXG4gICAgZW5kX2RhdGU6IFwiXCIsXHJcbiAgICBtaW5pbXVtX2JpZDogXCJcIixcclxuICAgIG1heGltdW1fYmlkOiBcIlwiLFxyXG4gICAgY29tbWlzc2lvbjogNSxcclxuICAgIGluY2VudGl2ZXM6IFwiXCIsXHJcbiAgICByZWdfZmVlOiBcIlwiLFxyXG4gICAgZmlsdGVyX2dyb3VwOiBcIlwiLFxyXG4gICAgY3JlYXRlZEF0OiBcIlwiLFxyXG4gICAgYXBwX2Rpc3BsYXlfdmFjYW55X3NlYXQ6IFwiXCIsXHJcbiAgICBhdWN0aW9uX3Byb2Nlc3NpbmdfdHlwZTogXCJcIixcclxuICAgIGF1Y3Rpb25fbW9kZTogXCJcIixcclxuICAgIGdyb3VwX2NvZGU6IFwiXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbdXBkYXRlRm9ybURhdGEsIHNldFVwZGF0ZUZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGdyb3VwX25hbWU6IFwiXCIsXHJcbiAgICBncm91cF90eXBlOiBcIlwiLFxyXG4gICAgZ3JvdXBfdmFsdWU6IFwiXCIsXHJcbiAgICBncm91cF9pbnN0YWxsOiBcIlwiLFxyXG4gICAgZ3JvdXBfbWVtYmVyczogXCJcIixcclxuICAgIGdyb3VwX2R1cmF0aW9uOiBcIlwiLFxyXG4gICAgc3RhcnRfZGF0ZTogXCJcIixcclxuICAgIGVuZF9kYXRlOiBcIlwiLFxyXG4gICAgbWluaW11bV9iaWQ6IFwiXCIsXHJcbiAgICBtYXhpbXVtX2JpZDogXCJcIixcclxuICAgIGNvbW1pc3Npb246IFwiXCIsXHJcbiAgICBpbmNlbnRpdmVzOiBcIlwiLFxyXG4gICAgcmVnX2ZlZTogXCJcIixcclxuICAgIGZpbHRlcl9ncm91cDogXCJcIixcclxuICAgIGFwcF9kaXNwbGF5X3ZhY2FueV9zZWF0OiBcIlwiLFxyXG4gICAgYXVjdGlvbl9wcm9jZXNzaW5nX3R5cGU6IFwiXCIsXHJcbiAgICBhdWN0aW9uX21vZGU6IFwiXCIsXHJcbiAgICBncm91cF9jb2RlOiBcIlwiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBncm91cE9wdGlvbnMgPSBbXHJcbiAgICB7IHZhbHVlOiBcIk5ldyBHcm91cHNcIiwgbGFiZWw6IFwiTmV3IEdyb3Vwc1wiIH0sXHJcbiAgICB7IHZhbHVlOiBcIk9uZ29pbmcgR3JvdXBzXCIsIGxhYmVsOiBcIk9uZ29pbmcgR3JvdXBzXCIgfSxcclxuICAgIHsgdmFsdWU6IFwiVXBjb21pbmcgR3JvdXBzXCIsIGxhYmVsOiBcIlVwY29taW5nIEdyb3Vwc1wiIH0sXHJcbiAgICB7IHZhbHVlOiBcIlZhY2FudCBHcm91cHNcIiwgbGFiZWw6IFwiVmFjYW50IEdyb3Vwc1wiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgZ3JvdXBUeXBlID0gW1xyXG4gICAgeyB2YWx1ZTogXCJkaXZpZGVudFwiLCBsYWJlbDogXCJEaXZpZGVudCBHcm91cFwiIH0sXHJcbiAgICB7IHZhbHVlOiBcImRvdWJsZVwiLCBsYWJlbDogXCJEb3VibGUgR3JvdXBcIiB9LFxyXG4gIF07XHJcbiAgY29uc3QgaGFuZGxlQW50RFNlbGVjdCA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtmaWVsZF06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG5cclxuICAgIHNldEVycm9ycygocHJldkVycm9ycykgPT4gKHtcclxuICAgICAgLi4ucHJldkVycm9ycyxcclxuICAgICAgW2ZpZWxkXTogXCJcIixcclxuICAgIH0pKTtcclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZUFudElucHV0RFNlbGVjdCA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIHNldFVwZGF0ZUZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtmaWVsZF06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG5cclxuICAgIHNldEVycm9ycyh7IC4uLmVycm9ycywgW2ZpZWxkXTogXCJcIiB9KTtcclxuICB9O1xyXG4gIGNvbnN0IGhhbmRsZVNoYXJlQ2xpY2sgPSAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgaWYgKCFncm91cElkKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJNaXNzaW5nIG9yIGludmFsaWQgZ3JvdXBJZFwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIHdpbmRvdy5vcGVuKGAvZW5yb2xsbWVudC1yZXF1ZXN0LWZvcm0vP2dyb3VwX2lkPSR7Z3JvdXBJZH1gLCBcIl9ibGFua1wiKTtcclxuICAgIC8vIG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KFxyXG4gICAgLy8gICBsb2NhdGlvbi5vcmlnaW4gKyBgL2Vucm9sbG1lbnQtcmVxdWVzdC1mb3JtLz9ncm91cF9pZD0ke2dyb3VwSWR9YFxyXG4gICAgLy8gKTtcclxuXHJcbiAgICBjb25zdCBiYXNlVXJsID0gXCJodHRwOi8vcHJvZC1jaGl0LnMzLXdlYnNpdGUuZXUtbm9ydGgtMS5hbWF6b25hd3MuY29tXCI7XHJcbiAgICBjb25zdCBmdWxsVXJsID0gYCR7YmFzZVVybH0vZW5yb2xsbWVudC1yZXF1ZXN0LWZvcm0vP2dyb3VwX2lkPSR7Z3JvdXBJZH1gO1xyXG4gICAgLy8gbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQoZnVsbFVybCk7XHJcbiAgICB3aW5kb3cub3BlbihmdWxsVXJsLCBcIl9ibGFua1wiKTtcclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hHcm91cHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgICAgY29uc3QgYWxsR3JvdXBzID0gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgICBzZXRHcm91cHMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgICAgY29uc3QgZmlsdGVyZWRHcm91cHMgPSBmaWx0ZXJHcm91cFxyXG4gICAgICAgICAgPyBhbGxHcm91cHMuZmlsdGVyKChncm91cCkgPT4gZ3JvdXA/LmZpbHRlcl9ncm91cCA9PT0gZmlsdGVyR3JvdXApXHJcbiAgICAgICAgICA6IGFsbEdyb3VwcztcclxuICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gZmlsdGVyZWRHcm91cHMubWFwKChncm91cCwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICBfaWQ6IGdyb3VwPy5faWQsXHJcbiAgICAgICAgICBjaGVja0JveDogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItcmVkLTQwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkLW1kIHNoYWRvdyBob3Zlcjpib3JkZXItcmVkLTcwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2dyb3VwLm1vYmlsZV9hY2Nlc3N9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZU1vYmlsZUFjY2Vzc0NoYW5nZShncm91cC5faWQsICFncm91cC5tb2JpbGVfYWNjZXNzKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXt1cGRhdGluZ0dyb3Vwcy5oYXMoZ3JvdXAuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9ybS1jaGVja2JveCBoLTQgdy00IHRleHQtcmVkLTYwMCBmb2N1czpyaW5nLTAgZm9jdXM6cmluZy1vZmZzZXQtMCBmb2N1czpvdXRsaW5lLW5vbmUgY2hlY2tlZDpiZy1yZWQtNjAwIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSxcclxuICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICBuYW1lOiBncm91cD8uZ3JvdXBfbmFtZSxcclxuICAgICAgICAgIHR5cGU6XHJcbiAgICAgICAgICAgIGdyb3VwPy5ncm91cF90eXBlLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICtcclxuICAgICAgICAgICAgZ3JvdXA/Lmdyb3VwX3R5cGUuc2xpY2UoMSkgK1xyXG4gICAgICAgICAgICBcIiBHcm91cFwiLFxyXG4gICAgICAgICAgdmFsdWU6IGdyb3VwPy5ncm91cF92YWx1ZSxcclxuICAgICAgICAgIGluc3RhbGxtZW50OiBncm91cD8uZ3JvdXBfaW5zdGFsbCxcclxuICAgICAgICAgIG1lbWJlcnM6IGdyb3VwPy5ncm91cF9tZW1iZXJzLFxyXG4gICAgICAgICAgZmlsdGVyX2dyb3VwOiBncm91cD8uZmlsdGVyX2dyb3VwLFxyXG4gICAgICAgICAgYXBwX2Rpc3BsYXlfdmFjYW55X3NlYXQ6IGdyb3VwPy5hcHBfZGlzcGxheV92YWNhbnlfc2VhdCxcclxuICAgICAgICAgIGRhdGU6IGdyb3VwPy5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICAgIGF1Y3Rpb25fcHJvY2Vzc2luZ190eXBlOiBncm91cD8uYXVjdGlvbl9wcm9jZXNzaW5nX3R5cGUsXHJcbiAgICAgICAgICBhdWN0aW9uX21vZGU6IGdyb3VwPy5hdWN0aW9uX21vZGUsXHJcbiAgICAgICAgICBncm91cF9jb2RlOiBncm91cD8uZ3JvdXBfY29kZSxcclxuICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICB7LyogPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVXBkYXRlTW9kYWxPcGVuKGdyb3VwLl9pZCl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyZWVuLTQwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkLW1kIHNoYWRvdyBob3Zlcjpib3JkZXItZ3JlZW4tNzAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8Q2lFZGl0IGNvbG9yPVwiZ3JlZW5cIiAvPlxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPiAqL31cclxuXHJcbiAgICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVcGRhdGVNb2RhbE9wZW4oZ3JvdXA/Ll9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBFZGl0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGVNb2RhbE9wZW4oZ3JvdXA/Ll9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjNcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTaGFyZUNsaWNrKGdyb3VwPy5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIiB0ZXh0LXZpb2xldC02MDAgXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIENvcHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApLFxyXG4gICAgICAgIH0pKTtcclxuICAgICAgICBzZXRUYWJsZUdyb3Vwcyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFt1cGRhdGluZ0dyb3VwcywgcmVsb2FkVHJpZ2dlciwgZmlsdGVyR3JvdXBdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgLy8gYXBwbHkgdmFsaWRhdGlvbiBoZXJlXHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG5cclxuICAgIHNldEVycm9ycygocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IFwiXCIsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKHR5cGUpID0+IHtcclxuICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG5cclxuICAgIGNvbnN0IGRhdGEgPSB0eXBlID09PSBcImFkZEdyb3VwXCIgPyBmb3JtRGF0YSA6IHVwZGF0ZUZvcm1EYXRhO1xyXG5cclxuICAgIGlmICghZGF0YS5ncm91cF9uYW1lLnRyaW0oKSkge1xyXG4gICAgICBuZXdFcnJvcnMuZ3JvdXBfbmFtZSA9IFwiR3JvdXAgTmFtZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5ncm91cF90eXBlKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5ncm91cF90eXBlID0gXCJHcm91cCBUeXBlIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9XHJcbiAgICBpZiAoIWRhdGEuZ3JvdXBfdmFsdWUpIHtcclxuICAgICAgbmV3RXJyb3JzLmdyb3VwX3ZhbHVlID0gXCJHcm91cCBWYWx1ZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmIChpc05hTihkYXRhLmdyb3VwX3ZhbHVlKSB8fCBkYXRhLmdyb3VwX3ZhbHVlIDw9IDApIHtcclxuICAgICAgbmV3RXJyb3JzLmdyb3VwX3ZhbHVlID0gXCJHcm91cCBWYWx1ZSBtdXN0IGJlIGdyZWF0ZXIgdGhhbiB6ZXJvIChub1wiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5ncm91cF9pbnN0YWxsKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5ncm91cF9pbnN0YWxsID0gXCJHcm91cCBJbnN0YWxsbWVudCBBbW91bnQgaXMgcmVxdWlyZWRcIjtcclxuICAgIH0gZWxzZSBpZiAoXHJcbiAgICAgICFkYXRhLmdyb3VwX2luc3RhbGwgfHxcclxuICAgICAgaXNOYU4oZGF0YS5ncm91cF9pbnN0YWxsKSB8fFxyXG4gICAgICBkYXRhLmdyb3VwX2luc3RhbGwgPD0gMFxyXG4gICAgKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5ncm91cF9pbnN0YWxsID1cclxuICAgICAgICBcIkdyb3VwIEluc3RhbGxtZW50IEFtb3VudCBtdXN0IGJlIGdyZWF0ZXIgdGhhbiB6ZXJvIChubyBzeW1ib2xzKS5cIjtcclxuICAgIH1cclxuICAgIGlmICghZGF0YS5hcHBfZGlzcGxheV92YWNhbnlfc2VhdCkge1xyXG4gICAgICBuZXdFcnJvcnMuYXBwX2Rpc3BsYXlfdmFjYW55X3NlYXQgPSBcIlBsZWFzZSBFbnRlciBBcHAgRGlzcGxheSBWYWNhbnkgU2VhdFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5ncm91cF9tZW1iZXJzKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5ncm91cF9tZW1iZXJzID0gXCJHcm91cCBNZW1iZXJzIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9IGVsc2UgaWYgKFxyXG4gICAgICAhZGF0YS5ncm91cF9tZW1iZXJzIHx8XHJcbiAgICAgIGlzTmFOKGRhdGEuZ3JvdXBfbWVtYmVycykgfHxcclxuICAgICAgZGF0YS5ncm91cF9tZW1iZXJzIDw9IDBcclxuICAgICkge1xyXG4gICAgICBuZXdFcnJvcnMuZ3JvdXBfbWVtYmVycyA9XHJcbiAgICAgICAgXCJHcm91cCBNZW1iZXJzIG11c3QgYmUgZ3JlYXRlciB0aGFuIHplcm8gKG5vIHN5bWJvbHMpLlwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5ncm91cF9kdXJhdGlvbikge1xyXG4gICAgICBuZXdFcnJvcnMuZ3JvdXBfZHVyYXRpb24gPSBcIkdyb3VwIER1cmF0aW9uIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9IGVsc2UgaWYgKFxyXG4gICAgICAhZGF0YS5ncm91cF9kdXJhdGlvbiB8fFxyXG4gICAgICBpc05hTihkYXRhLmdyb3VwX2R1cmF0aW9uKSB8fFxyXG4gICAgICBkYXRhLmdyb3VwX2R1cmF0aW9uIDw9IDBcclxuICAgICkge1xyXG4gICAgICBuZXdFcnJvcnMuZ3JvdXBfZHVyYXRpb24gPVxyXG4gICAgICAgIFwiR3JvdXAgRHVyYXRpb24gbXVzdCBiZSBncmVhdGVyIHRoYW4gemVybyAobm8gc3ltYm9scykuXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFkYXRhLnJlZ19mZWUpIHtcclxuICAgICAgbmV3RXJyb3JzLnJlZ19mZWUgPSBcIlJlZ2lzdHJhdGlvbiBGZWUgaXMgcmVxdWlyZWRcIjtcclxuICAgIH0gZWxzZSBpZiAoIWRhdGEucmVnX2ZlZSB8fCBpc05hTihkYXRhLnJlZ19mZWUpIHx8IGRhdGEucmVnX2ZlZSA8IDApIHtcclxuICAgICAgbmV3RXJyb3JzLnJlZ19mZWUgPVxyXG4gICAgICAgIFwiUmVnaXN0cmF0aW9uIEZlZSBtdXN0IGJlIGEgemVybyBvciBncmVhdGVyIHRoYW4gemVybyAobm8gc3ltYm9scykuXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFkYXRhLnN0YXJ0X2RhdGUpIHtcclxuICAgICAgbmV3RXJyb3JzLnN0YXJ0X2RhdGUgPSBcIlN0YXJ0IERhdGUgaXMgcmVxdWlyZWRcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoZm9ybURhdGEuZW5kX2RhdGUgJiYgIWRhdGEuZW5kX2RhdGUpIHtcclxuICAgICAgbmV3RXJyb3JzLmVuZF9kYXRlID0gXCJFbmQgRGF0ZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmIChcclxuICAgICAgZm9ybURhdGEuZW5kX2RhdGUgJiZcclxuICAgICAgbmV3IERhdGUoZGF0YS5lbmRfZGF0ZSkgPCBuZXcgRGF0ZShkYXRhLnN0YXJ0X2RhdGUpXHJcbiAgICApIHtcclxuICAgICAgbmV3RXJyb3JzLmVuZF9kYXRlID0gXCJFbmQgRGF0ZSBjYW5ub3QgYmUgZWFybGllciB0aGFuIFN0YXJ0IERhdGVcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWRhdGEubWluaW11bV9iaWQpIHtcclxuICAgICAgbmV3RXJyb3JzLm1pbmltdW1fYmlkID0gXCJNaW5pbXVtIEJpZCBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmIChcclxuICAgICAgIWRhdGEubWluaW11bV9iaWQgfHxcclxuICAgICAgaXNOYU4oZGF0YS5taW5pbXVtX2JpZCkgfHxcclxuICAgICAgZGF0YS5taW5pbXVtX2JpZCA8PSAwXHJcbiAgICApIHtcclxuICAgICAgbmV3RXJyb3JzLm1pbmltdW1fYmlkID1cclxuICAgICAgICBcIk1pbmltdW0gQmlkIG11c3QgYmUgZ3JlYXRlciB0aGFuIHplcm8gKG5vIHN5bWJvbHMpLlwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5tYXhpbXVtX2JpZCkge1xyXG4gICAgICBuZXdFcnJvcnMubWF4aW11bV9iaWQgPSBcIk1heGltdW0gQmlkIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9IGVsc2UgaWYgKFxyXG4gICAgICAhZGF0YS5tYXhpbXVtX2JpZCB8fFxyXG4gICAgICBpc05hTihkYXRhLm1heGltdW1fYmlkKSB8fFxyXG4gICAgICBkYXRhLm1heGltdW1fYmlkIDw9IDBcclxuICAgICkge1xyXG4gICAgICBuZXdFcnJvcnMubWF4aW11bV9iaWQgPVxyXG4gICAgICAgIFwiTWF4aW11bSBCaWQgbXVzdCBiZSBncmVhdGVyIHRoYW4gemVybyAobm8gc3ltYm9scykuXCI7XHJcbiAgICB9IGVsc2UgaWYgKHBhcnNlRmxvYXQoZGF0YS5tYXhpbXVtX2JpZCkgPCBwYXJzZUZsb2F0KGRhdGEubWluaW11bV9iaWQpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5tYXhpbXVtX2JpZCA9XHJcbiAgICAgICAgXCJNYXhpbXVtIEJpZCBtdXN0IGJlIGdyZWF0ZXIgdGhhbiBvciBlcXVhbCB0byBNaW5pbXVtIEJpZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKG5ld0Vycm9ycykubGVuZ3RoID09PSAwO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZU1vYmlsZUFjY2Vzc0NoYW5nZSA9IGFzeW5jIChncm91cElkLCBuZXdWYWx1ZSkgPT4ge1xyXG4gICAgc2V0VXBkYXRpbmdHcm91cHMoKHByZXYpID0+IG5ldyBTZXQoWy4uLnByZXYsIGdyb3VwSWRdKSk7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0R3JvdXBzKChwcmV2KSA9PlxyXG4gICAgICAgIHByZXYubWFwKChncm91cCkgPT5cclxuICAgICAgICAgIGdyb3VwLl9pZCA9PT0gZ3JvdXBJZCA/IHsgLi4uZ3JvdXAsIG1vYmlsZV9hY2Nlc3M6IG5ld1ZhbHVlIH0gOiBncm91cFxyXG4gICAgICAgIClcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGF3YWl0IGFwaS5wYXRjaChgL2dyb3VwL3VwZGF0ZS1tb2JpbGUtYWNjZXNzLyR7Z3JvdXBJZH1gLCB7XHJcbiAgICAgICAgbW9iaWxlX2FjY2VzczogbmV3VmFsdWUsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2dyb3VwL2dldC1ncm91cC1hZG1pblwiKTtcclxuICAgICAgc2V0R3JvdXBzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgc2V0R3JvdXBzKChwcmV2KSA9PlxyXG4gICAgICAgIHByZXYubWFwKChncm91cCkgPT5cclxuICAgICAgICAgIGdyb3VwLl9pZCA9PT0gZ3JvdXBJZCA/IHsgLi4uZ3JvdXAsIG1vYmlsZV9hY2Nlc3M6ICFuZXdWYWx1ZSB9IDogZ3JvdXBcclxuICAgICAgICApXHJcbiAgICAgICk7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBtb2JpbGUgYWNjZXNzOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byB1cGRhdGUgbW9iaWxlIGFjY2Vzc1wiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuXHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRVcGRhdGluZ0dyb3VwcygocHJldikgPT4ge1xyXG4gICAgICAgIGNvbnN0IG5ld1NldCA9IG5ldyBTZXQocHJldik7XHJcbiAgICAgICAgbmV3U2V0LmRlbGV0ZShncm91cElkKTtcclxuICAgICAgICByZXR1cm4gbmV3U2V0O1xyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cclxuICAgIGNvbnN0IGlzVmFsaWQgPSB2YWxpZGF0ZUZvcm0oXCJhZGRHcm91cFwiKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGlmIChpc1ZhbGlkKSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChcIi9ncm91cC9hZGQtZ3JvdXBcIiwgZm9ybURhdGEsIHtcclxuICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8vIGFsZXJ0KFwiR3JvdXAgQWRkZWQgU3VjY2Vzc2Z1bGx5XCIpO1xyXG4gICAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJHcm91cCBBZGRlZCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgIGdyb3VwX25hbWU6IFwiXCIsXHJcbiAgICAgICAgICBncm91cF90eXBlOiBcIlwiLFxyXG4gICAgICAgICAgZ3JvdXBfdmFsdWU6IFwiXCIsXHJcbiAgICAgICAgICBncm91cF9pbnN0YWxsOiBcIlwiLFxyXG4gICAgICAgICAgZ3JvdXBfbWVtYmVyczogXCJcIixcclxuICAgICAgICAgIGdyb3VwX2R1cmF0aW9uOiBcIlwiLFxyXG4gICAgICAgICAgc3RhcnRfZGF0ZTogXCJcIixcclxuICAgICAgICAgIGVuZF9kYXRlOiBcIlwiLFxyXG4gICAgICAgICAgbWluaW11bV9iaWQ6IFwiXCIsXHJcbiAgICAgICAgICBtYXhpbXVtX2JpZDogXCJcIixcclxuICAgICAgICAgIGNvbW1pc3Npb246IFwiXCIsXHJcbiAgICAgICAgICBmaWx0ZXJfZ3JvdXA6IFwiXCIsXHJcbiAgICAgICAgICBhcHBfZGlzcGxheV92YWNhbnlfc2VhdDogXCJcIixcclxuICAgICAgICAgIGF1Y3Rpb25fcHJvY2Vzc2luZ190eXBlOiBcIlwiLFxyXG4gICAgICAgICAgYXVjdGlvbl9tb2RlOiBcIlwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGVycm9ycyk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBhZGRpbmcgZ3JvdXA6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmaWx0ZXJlZEdyb3VwcyA9IGdyb3Vwcy5maWx0ZXIoKGdyb3VwKSA9PlxyXG4gICAgZ3JvdXAuZ3JvdXBfbmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKSlcclxuICApO1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVNb2RhbE9wZW4gPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvZ3JvdXAvZ2V0LWJ5LWlkLWdyb3VwLyR7Z3JvdXBJZH1gKTtcclxuICAgICAgc2V0Q3VycmVudEdyb3VwKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICBzZXRTaG93TW9kYWxEZWxldGUodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXA6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGVNb2RhbE9wZW4gPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvZ3JvdXAvZ2V0LWJ5LWlkLWdyb3VwLyR7Z3JvdXBJZH1gKTtcclxuICAgICAgY29uc3QgZ3JvdXBEYXRhID0gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgY29uc3QgZm9ybWF0dGVkU3RhcnREYXRlID0gZ3JvdXBEYXRhPy5zdGFydF9kYXRlPy5zcGxpdChcIlRcIilbMF07XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZEVuZERhdGUgPSBncm91cERhdGE/LmVuZF9kYXRlPy5zcGxpdChcIlRcIilbMF07XHJcbiAgICAgIHNldEN1cnJlbnRVcGRhdGVHcm91cChyZXNwb25zZS5kYXRhKTtcclxuICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgIGdyb3VwX25hbWU6IHJlc3BvbnNlPy5kYXRhPy5ncm91cF9uYW1lLFxyXG4gICAgICAgIGdyb3VwX3R5cGU6IHJlc3BvbnNlPy5kYXRhPy5ncm91cF90eXBlLFxyXG4gICAgICAgIGdyb3VwX3ZhbHVlOiByZXNwb25zZT8uZGF0YT8uZ3JvdXBfdmFsdWUsXHJcbiAgICAgICAgZ3JvdXBfaW5zdGFsbDogcmVzcG9uc2U/LmRhdGE/Lmdyb3VwX2luc3RhbGwsXHJcbiAgICAgICAgZ3JvdXBfbWVtYmVyczogcmVzcG9uc2U/LmRhdGE/Lmdyb3VwX21lbWJlcnMsXHJcbiAgICAgICAgZ3JvdXBfZHVyYXRpb246IHJlc3BvbnNlPy5kYXRhPy5ncm91cF9kdXJhdGlvbixcclxuICAgICAgICBzdGFydF9kYXRlOiBmb3JtYXR0ZWRTdGFydERhdGUsXHJcbiAgICAgICAgZW5kX2RhdGU6IGZvcm1hdHRlZEVuZERhdGUsXHJcbiAgICAgICAgbWluaW11bV9iaWQ6IHJlc3BvbnNlPy5kYXRhPy5taW5pbXVtX2JpZCxcclxuICAgICAgICBtYXhpbXVtX2JpZDogcmVzcG9uc2U/LmRhdGE/Lm1heGltdW1fYmlkLFxyXG4gICAgICAgIGNvbW1pc3Npb246IHJlc3BvbnNlPy5kYXRhPy5jb21taXNzaW9uLFxyXG4gICAgICAgIGluY2VudGl2ZXM6IHJlc3BvbnNlPy5kYXRhPy5pbmNlbnRpdmVzLFxyXG4gICAgICAgIHJlZ19mZWU6IHJlc3BvbnNlPy5kYXRhPy5yZWdfZmVlLFxyXG4gICAgICAgIGFwcF9kaXNwbGF5X3ZhY2FueV9zZWF0OiByZXNwb25zZT8uZGF0YT8uYXBwX2Rpc3BsYXlfdmFjYW55X3NlYXQsXHJcbiAgICAgICAgYXVjdGlvbl9wcm9jZXNzaW5nX3R5cGU6IHJlc3BvbnNlPy5kYXRhPy5hdWN0aW9uX3Byb2Nlc3NpbmdfdHlwZSxcclxuICAgICAgICBhdWN0aW9uX21vZGU6IHJlc3BvbnNlPy5kYXRhPy5hdWN0aW9uX21vZGUsXHJcbiAgICAgICAgZmlsdGVyX2dyb3VwOiByZXNwb25zZT8uZGF0YT8uZmlsdGVyX2dyb3VwLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKHRydWUpO1xyXG4gICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGdyb3VwOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlSW5wdXRDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcblxyXG4gICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuICAgIHNldEVycm9ycyh7IC4uLmVycm9ycywgW25hbWVdOiBcIlwiIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUdyb3VwID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKGN1cnJlbnRHcm91cCkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGF3YWl0IGFwaS5kZWxldGUoYC9ncm91cC9kZWxldGUtZ3JvdXAvJHtjdXJyZW50R3JvdXAuX2lkfWApO1xyXG4gICAgICAgIC8vIGFsZXJ0KFwiR3JvdXAgZGVsZXRlZCBzdWNjZXNzZnVsbHlcIik7XHJcbiAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiR3JvdXAgZGVsZXRlZCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICBzZXRDdXJyZW50R3JvdXAobnVsbCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIGdyb3VwOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGUgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgaXNWYWxpZCA9IHZhbGlkYXRlRm9ybSgpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGlmIChpc1ZhbGlkKSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLnB1dChcclxuICAgICAgICAgIGAvZ3JvdXAvdXBkYXRlLWdyb3VwLyR7Y3VycmVudFVwZGF0ZUdyb3VwLl9pZH1gLFxyXG4gICAgICAgICAgdXBkYXRlRm9ybURhdGFcclxuICAgICAgICApO1xyXG4gICAgICAgIHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSk7XHJcbiAgICAgICAgLy8gYWxlcnQoXCJHcm91cCBVcGRhdGVkIFN1Y2Nlc3NmdWxseVwiKTtcclxuICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgbWVzc2FnZTogXCJHcm91cCB1cGRhdGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICAvL1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgZ3JvdXA6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiY2hlY2tCb3hcIiwgaGVhZGVyOiBcIk1vYmlsZSBBY2Nlc3NcIiB9LFxyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9jb2RlXCIsIGhlYWRlcjogXCJHcm91cCBDb2RlXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidHlwZVwiLCBoZWFkZXI6IFwiR3JvdXAgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJkYXRlXCIsIGhlYWRlcjogXCJDcmVhdGVkIE9uXCIgfSxcclxuICAgIHsga2V5OiBcInZhbHVlXCIsIGhlYWRlcjogXCJHcm91cCBWYWx1ZVwiIH0sXHJcbiAgICB7IGtleTogXCJpbnN0YWxsbWVudFwiLCBoZWFkZXI6IFwiR3JvdXAgSW5zdGFsbG1lbnRcIiB9LFxyXG4gICAgeyBrZXk6IFwibWVtYmVyc1wiLCBoZWFkZXI6IFwiR3JvdXAgTWVtYmVyc1wiIH0sXHJcbiAgICB7IGtleTogXCJhcHBfZGlzcGxheV92YWNhbnlfc2VhdFwiLCBoZWFkZXI6IFwiQXBwIERpc3BsYXkgVmFjYW55IFNlYXRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbiAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e29uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxDdXN0b21BbGVydERpYWxvZ1xyXG4gICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggXCI+XHJcbiAgICAgICAgICB7LyogPFNpZGViYXIgLz4gKi99XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIHRleHQtY2VudGVyIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgIE1vYmlsZSBBY2Nlc3MgR3JvdXBzXHJcbiAgICAgICAgICAgICAgPC9oMT5cclxuXHJcblxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTQgYmctdmlvbGV0LTk1MCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy12aW9sZXQtODAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICArIEFkZCBHcm91cFxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cIm1iLTEwXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXhsIG1iLTJcIj5TZWFyY2ggb3IgRmlsdGVyIEdyb3VwPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB3LWZ1bGwgbXQtNlwiPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRmlsdGVyIGJ5IEdyb3VwXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtmaWx0ZXJHcm91cH1cclxuICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgIGgtMTQgbWF4LXctbWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uPy5sYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldEZpbHRlckdyb3VwKHZhbHVlKX1cclxuICAgICAgICAgICAgICAgIG9wdGlvbnM9e1tcclxuICAgICAgICAgICAgICAgICAgeyB2YWx1ZTogXCJcIiwgbGFiZWw6IFwiQWxsIEdyb3Vwc1wiIH0sIFxyXG4gICAgICAgICAgICAgICAgICAuLi5ncm91cE9wdGlvbnMsIFxyXG4gICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj4gKi99XHJcblxyXG4gICAgICAgICAgICB7VGFibGVHcm91cHMubGVuZ3RoID4gMCAmJiAhaXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgIGNhdGNoZXI9XCJfaWRcIlxyXG4gICAgICAgICAgICAgICAgdXBkYXRlSGFuZGxlcj17aGFuZGxlVXBkYXRlTW9kYWxPcGVufVxyXG4gICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKFRhYmxlR3JvdXBzLCBzZWFyY2hUZXh0KX1cclxuICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9e2BGaWx0ZXIgR3JvdXBzYH1cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BGaWx0ZXIgR3JvdXBzLmNzdmB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICAgIGlzTG9hZGluZz17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgZmFpbHVyZT17VGFibGVHcm91cHMubGVuZ3RoIDw9IDB9XHJcbiAgICAgICAgICAgICAgICBkYXRhPXtcIkdyb3VwIERhdGFcIn1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPE1vZGFsIGlzVmlzaWJsZT17c2hvd01vZGFsfSBvbkNsb3NlPXsoKSA9PiBzZXRTaG93TW9kYWwoZmFsc2UpfT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5BZGQgR3JvdXA8L2gzPlxyXG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImZpbHRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEZpbHRlciBHcm91cHMgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgIFxyXG5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgRmlsdGVyIEdyb3Vwc1wiXHJcbiAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cImZpbHRlcl9ncm91cFwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LmZpbHRlcl9ncm91cCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcImZpbHRlcl9ncm91cFwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7Z3JvdXBPcHRpb25zLm1hcCgob3B0aW9uKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtvcHRpb24udmFsdWV9IHZhbHVlPXtvcHRpb24udmFsdWV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge29wdGlvbi5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9kaXY+ICovfVxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBHcm91cCBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEdyb3VwIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX25hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgR3JvdXAgVHlwZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEdyb3VwIFR5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/Lmdyb3VwX3R5cGUgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJncm91cF90eXBlXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtncm91cFR5cGUubWFwKChvcHRpb24pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17b3B0aW9uLnZhbHVlfSB2YWx1ZT17b3B0aW9uLnZhbHVlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge29wdGlvbi5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3JvdXBfdHlwZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF90eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQXBwIERpc3BsYXkgVmFjYW55IFNlYXR7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhcHBfZGlzcGxheV92YWNhbnlfc2VhdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmFwcF9kaXNwbGF5X3ZhY2FueV9zZWF0fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFwcCBEaXNwbGF5IFZhY2FueSBTZWF0XCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YG5vLXNwaW5uZXIgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYXBwX2Rpc3BsYXlfdmFjYW55X3NlYXQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYXBwX2Rpc3BsYXlfdmFjYW55X3NlYXR9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEdyb3VwIFZhbHVlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3JvdXBfdmFsdWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ncm91cF92YWx1ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBHcm91cCBWYWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF92YWx1ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF92YWx1ZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEdyb3VwIEluc3RhbGxtZW50IEFtb3VudHtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX2luc3RhbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ncm91cF9pbnN0YWxsfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEdyb3VwIEluc3RhbGxtZW50IEFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF9pbnN0YWxsICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX2luc3RhbGx9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEdyb3VwIE1lbWJlcnMgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9tZW1iZXJzXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZ3JvdXBfbWVtYmVyc31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBHcm91cCBNZW1iZXJzXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX21lbWJlcnMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3JvdXBfbWVtYmVyc31cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEdyb3VwIER1cmF0aW9uIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3JvdXBfZHVyYXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ncm91cF9kdXJhdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBHcm91cCBEdXJhdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF9kdXJhdGlvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF9kdXJhdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFJlZ2lzdHJhdGlvbiBGZWUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWdfZmVlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucmVnX2ZlZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBSZWdpc3RyYXRpb24gRmVlXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnJlZ19mZWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucmVnX2ZlZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgU3RhcnQgRGF0ZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJzdGFydF9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuc3RhcnRfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5zdGFydF9kYXRlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnN0YXJ0X2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBFbmQgRGF0ZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImVuZF9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZW5kX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIERhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZW5kX2RhdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZW5kX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIE1pbmltdW0gQmlkIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwibWluaW11bV9iaWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5taW5pbXVtX2JpZH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBNaW5pbXVtIEJpZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5taW5pbXVtX2JpZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5taW5pbXVtX2JpZH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIE1heGltdW0gQmlkIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwibWF4aW11bV9iaWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5tYXhpbXVtX2JpZH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBNYXhpbXVtIEJpZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5tYXhpbXVtX2JpZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5tYXhpbXVtX2JpZH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBDb21taXNzaW9uICVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvbW1pc3Npb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jb21taXNzaW9ufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBDb21taXNzaW9uXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBJbmNlbnRpdmVzXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiaW5jZW50aXZlc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmluY2VudGl2ZXN9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEluY2VudGl2ZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxDb2xsYXBzZVxyXG4gICAgICAgICAgICAgICAgZGVmYXVsdEFjdGl2ZUtleT17W1wiMVwiXX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LW1kIGJvcmRlciBib3JkZXItZ3JheS0yMDBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxQYW5lbFxyXG4gICAgICAgICAgICAgICAgICBoZWFkZXI9e1xyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBBdWN0aW9uIERldGFpbHNcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAga2V5PVwiMVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBBdWN0aW9uIFByb2Nlc3NpbmcgVHlwZSAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQXVjdGlvbiBQcm9jZXNzaW5nIFR5cGVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEF1Y3Rpb24gUHJvY2Vzc2luZyBUeXBlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYXVjdGlvbl9wcm9jZXNzaW5nX3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5hdWN0aW9uX3Byb2Nlc3NpbmdfdHlwZSB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcImF1Y3Rpb25fcHJvY2Vzc2luZ190eXBlXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtbXCJTWVNURU1cIiwgXCJNQU5VQUxcIl0ubWFwKChzdHlwZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17c3R5cGV9IHZhbHVlPXtzdHlwZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3R5cGUuY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlwZS5zbGljZSgxKS50b0xvd2VyQ2FzZSgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIEF1Y3Rpb24gTW9kZSAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQXVjdGlvbiBNb2RlXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBBdWN0aW9uIE1vZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhdWN0aW9uX21vZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5hdWN0aW9uX21vZGUgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudERTZWxlY3QoXCJhdWN0aW9uX21vZGVcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge1tcIk9OTElORVwiLCBcIk9GRkxJTkVcIl0ubWFwKChzdHlwZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17c3R5cGV9IHZhbHVlPXtzdHlwZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3R5cGUuY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlwZS5zbGljZSgxKS50b0xvd2VyQ2FzZSgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L1BhbmVsPlxyXG4gICAgICAgICAgICAgIDwvQ29sbGFwc2U+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzQgdGV4dC13aGl0ZSBiZy12aW9sZXQtNzAwIGhvdmVyOmJnLXZpb2xldC04MDBcclxuICAgICAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctdmlvbGV0LTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXIgYm9yZGVyLTIgYm9yZGVyLWJsYWNrXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgU2F2ZSBHcm91cFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbFVwZGF0ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSl9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgIFVwZGF0ZSBHcm91cFxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlVXBkYXRlfSBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImZpbHRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEZpbHRlciBHcm91cHMgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBGaWx0ZXIgR3JvdXBzXCJcclxuICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiZmlsdGVyX2dyb3VwXCJcclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uZmlsdGVyX2dyb3VwIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJmaWx0ZXJfZ3JvdXBcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2dyb3VwT3B0aW9ucy5tYXAoKG9wdGlvbikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17b3B0aW9uLnZhbHVlfSB2YWx1ZT17b3B0aW9uLnZhbHVlfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtvcHRpb24ubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PiAqL31cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgR3JvdXAgTmFtZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiZ3JvdXBfbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEdyb3VwIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX25hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgR3JvdXAgVHlwZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgR3JvdXAgVHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uZ3JvdXBfdHlwZSB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudElucHV0RFNlbGVjdChcImdyb3VwX3R5cGVcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2dyb3VwVHlwZS5tYXAoKG9wdGlvbikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtvcHRpb24udmFsdWV9IHZhbHVlPXtvcHRpb24udmFsdWV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7b3B0aW9uLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF90eXBlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBBcHAgRGlzcGxheSBWYWNhbnkgU2VhdHtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFwcF9kaXNwbGF5X3ZhY2FueV9zZWF0XCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuYXBwX2Rpc3BsYXlfdmFjYW55X3NlYXR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBcHAgRGlzcGxheSBWYWNhbnkgU2VhdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Buby1zcGlubmVyIGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFwcF9kaXNwbGF5X3ZhY2FueV9zZWF0ICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFwcF9kaXNwbGF5X3ZhY2FueV9zZWF0fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgR3JvdXAgVmFsdWUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF92YWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmdyb3VwX3ZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgR3JvdXAgVmFsdWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3JvdXBfdmFsdWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3JvdXBfdmFsdWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBHcm91cCBJbnN0YWxsbWVudCBBbW91bnR7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9pbnN0YWxsXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3JvdXBfaW5zdGFsbH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEdyb3VwIEluc3RhbGxtZW50IEFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF9pbnN0YWxsICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX2luc3RhbGx9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEdyb3VwIE1lbWJlcnMgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9tZW1iZXJzXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3JvdXBfbWVtYmVyc31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEdyb3VwIE1lbWJlcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3JvdXBfbWVtYmVycyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ncm91cF9tZW1iZXJzfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgR3JvdXAgRHVyYXRpb24gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9kdXJhdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmdyb3VwX2R1cmF0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgR3JvdXAgRHVyYXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3JvdXBfZHVyYXRpb24gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3JvdXBfZHVyYXRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFJlZ2lzdHJhdGlvbiBGZWUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwicmVnX2ZlZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5yZWdfZmVlfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIFJlZ2lzdHJhdGlvbiBGZWVcIlxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLnJlZ19mZWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+e2Vycm9ycy5yZWdfZmVlfTwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFN0YXJ0IERhdGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwic3RhcnRfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLnN0YXJ0X2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5zdGFydF9kYXRlICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnN0YXJ0X2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBFbmQgRGF0ZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImVuZF9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZW5kX2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgRGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5lbmRfZGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5lbmRfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgTWluaW11bSBCaWQgJSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm1pbmltdW1fYmlkXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEubWluaW11bV9iaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBNaW5pbXVtIEJpZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5taW5pbXVtX2JpZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5taW5pbXVtX2JpZH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIE1heGltdW0gQmlkICUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJtYXhpbXVtX2JpZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLm1heGltdW1fYmlkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgTWF4aW11bSBCaWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMubWF4aW11bV9iaWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubWF4aW11bV9iaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIENvbW1pc3Npb24gJVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29tbWlzc2lvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmNvbW1pc3Npb259XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQ29tbWlzc2lvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgSW5jZW50aXZlc1xyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImluY2VudGl2ZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5pbmNlbnRpdmVzfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEluY2VudGl2ZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPENvbGxhcHNlXHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0QWN0aXZlS2V5PXtbXCIxXCJdfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctbWQgYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFBhbmVsXHJcbiAgICAgICAgICAgICAgICAgIGhlYWRlcj17XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEF1Y3Rpb24gRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBrZXk9XCIxXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICB7LyogQXVjdGlvbiBQcm9jZXNzaW5nIFR5cGUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEF1Y3Rpb24gUHJvY2Vzc2luZyBUeXBlXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBQcm9jZXNzaW5nIFR5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhdWN0aW9uX3Byb2Nlc3NpbmdfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhPy5hdWN0aW9uX3Byb2Nlc3NpbmdfdHlwZSB8fCB1bmRlZmluZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudElucHV0RFNlbGVjdChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYXVjdGlvbl9wcm9jZXNzaW5nX3R5cGVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7W1wiU1lTVEVNXCIsIFwiTUFOVUFMXCJdLm1hcCgoc3R5cGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3N0eXBlfSB2YWx1ZT17c3R5cGV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0eXBlLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5cGUuc2xpY2UoMSkudG9Mb3dlckNhc2UoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBBdWN0aW9uIE1vZGUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEF1Y3Rpb24gTW9kZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgQXVjdGlvbiBNb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYXVjdGlvbl9tb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LmF1Y3Rpb25fbW9kZSB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFwiYXVjdGlvbl9tb2RlXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtbXCJPTkxJTkVcIiwgXCJPRkZMSU5FXCJdLm1hcCgoc3R5cGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3N0eXBlfSB2YWx1ZT17c3R5cGV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0eXBlLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5cGUuc2xpY2UoMSkudG9Mb3dlckNhc2UoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9QYW5lbD5cclxuICAgICAgICAgICAgICA8L0NvbGxhcHNlPlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvNCB0ZXh0LXdoaXRlIGJnLXZpb2xldC03MDAgaG92ZXI6YmctdmlvbGV0LTgwMFxyXG4gICAgICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy12aW9sZXQtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlciBib3JkZXItMiBib3JkZXItYmxhY2tcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBVcGRhdGVcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxEZWxldGV9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldEN1cnJlbnRHcm91cChudWxsKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgIERlbGV0ZSBHcm91cFxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICB7Y3VycmVudEdyb3VwICYmIChcclxuICAgICAgICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgICAgICAgb25TdWJtaXQ9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICAgICAgaGFuZGxlRGVsZXRlR3JvdXAoKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzcGFjZS15LTZcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZ3JvdXBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFBsZWFzZSBlbnRlcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnkgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudEdyb3VwLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICB0byBjb25maXJtIGRlbGV0aW9uLntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZ3JvdXBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBHcm91cCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtd2hpdGUgYmctcmVkLTcwMCBob3ZlcjpiZy1yZWQtODAwXHJcbiAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctdmlvbGV0LTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEZpbHRlckdyb3VwcztcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0ZpbHRlckdyb3Vwcy5qc3gifQ==