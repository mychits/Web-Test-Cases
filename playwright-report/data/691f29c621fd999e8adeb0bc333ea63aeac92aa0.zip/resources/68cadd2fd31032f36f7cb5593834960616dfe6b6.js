import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CustomerArea.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import { Input, Dropdown, Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import DataTable from "/src/components/layouts/Datatable.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
const AREA_TYPE_OPTIONS = [
  { value: "Village", label: "Village" },
  { value: "Town", label: "Town" },
  { value: "City", label: "City" },
  { value: "Ward", label: "Ward" },
  { value: "Layout", label: "Layout" },
  { value: "Locality", label: "Locality" },
  { value: "Zone", label: "Zone" },
  { value: "Other", label: "Other" }
];
const ENDPOINTS = {
  create: "/v1/admin/customer-area/",
  getAll: "/v1/admin/customer-area/",
  getById: (id) => `/v1/admin//customer-area/${id}`,
  update: (id) => `/v1/admin//customer-area/${id}`,
  delete: (id) => `/v1/admin//customer-area/${id}`
};
const CustomerArea = () => {
  _s();
  const [currentCustomerArea, setCurrentCustomerArea] = useState(null);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [currentUpdateCustomerArea, setCurrentUpdateCustomerArea] = useState(null);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [tableCustomerArea, setTableCustomerArea] = useState([]);
  const [customerAreaList, setCustomerAreaList] = useState([]);
  const [customerAreaData, setCustomerAreaData] = useState({
    area_name: "",
    area_type: "",
    pincode: "",
    description: ""
  });
  const [showModal, setShowModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [updateCustomerAreaData, setUpdateCustomerAreaData] = useState({
    area_name: "",
    area_type: "",
    pincode: "",
    description: ""
  });
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [searchText, setSearchText] = useState("");
  const GlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  useEffect(() => {
    const fetchCustomerArea = async () => {
      try {
        setIsLoading(true);
        const response = await api.get(ENDPOINTS.getAll);
        setCustomerAreaList(response?.data?.data);
        const customerAreaTableData = response?.data?.data.map(
          (customerArea, index) => {
            return {
              _id: customerArea?._id,
              id: index + 1,
              area_name: customerArea?.area_name,
              area_type: customerArea?.area_type,
              pincode: customerArea?.pincode,
              description: customerArea?.description,
              createdAt: customerArea.createdAt?.split("T")[0].split("-").reverse().join("-"),
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  trigger: ["click"],
                  menu: {
                    items: [
                      {
                        key: "1",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-green-600",
                            onClick: () => handleUpdateModalOpen(customerArea?._id),
                            children: "Edit"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
                            lineNumber: 108,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      {
                        key: "2",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-red-600",
                            onClick: () => handleDeleteModalOpen(customerArea?._id),
                            children: "Delete"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
                            lineNumber: 121,
                            columnNumber: 23
                          },
                          this
                        )
                      }
                    ]
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
                    lineNumber: 135,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
                  lineNumber: 101,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
                lineNumber: 100,
                columnNumber: 15
              }, this)
            };
          }
        );
        setTableCustomerArea(customerAreaTableData);
      } catch (error) {
        console.error("Error fetching customer area data:", error.message);
      } finally {
        setIsLoading(false);
      }
    };
    fetchCustomerArea();
  }, [reloadTrigger]);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setCustomerAreaData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateCustomerAreaData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post(ENDPOINTS.create, customerAreaData, {
        headers: {
          "Content-Type": "application/json"
        }
      });
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        type: "success",
        message: "Customer Area Added Successfully",
        visibility: true
      });
      setShowModal(false);
      setCustomerAreaData({
        branch_id: "",
        area_name: "",
        area_type: "",
        pincode: "",
        description: ""
      });
    } catch (error) {
      console.error("Error adding customer area:", error);
      if (error.response && error.response.data && error.response.data.message) {
        setAlertConfig({
          type: "error",
          message: `${error?.response?.data?.message}`,
          visibility: true
        });
      } else {
        setAlertConfig({
          type: "error",
          message: "An unexpected error occurred. Please try again.",
          visibility: true
        });
      }
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "createdAt", header: "Date" },
    { key: "area_name", header: "Customer Area Name" },
    { key: "area_type", header: "Area Type" },
    { key: "pincode", header: "Pincode" },
    { key: "description", header: "Description" },
    { key: "action", header: "Action" }
  ];
  const handleDeleteModalOpen = async (Id) => {
    try {
      const response = await api.get(ENDPOINTS.getById(Id));
      setCurrentCustomerArea(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching Customer area Data :", error);
    }
  };
  const handleUpdateModalOpen = async (Id) => {
    try {
      const response = await api.get(ENDPOINTS.getById(Id));
      setCurrentUpdateCustomerArea(response?.data);
      setUpdateCustomerAreaData({
        branch_id: response?.data?.branch_id?._id || response?.data?.branch_id,
        area_name: response?.data?.area_name,
        area_type: response?.data?.area_type,
        pincode: response?.data?.pincode,
        description: response?.data?.description
      });
      setShowModalUpdate(true);
    } catch (error) {
      console.error("Error fetching customer area data:", error);
    }
  };
  const handleDeleteCustomerArea = async () => {
    if (currentCustomerArea) {
      try {
        await api.delete(ENDPOINTS.delete(currentCustomerArea._id));
        setAlertConfig({
          visibility: true,
          message: "Customer Area deleted successfully",
          type: "success"
        });
        setReloadTrigger((prev) => prev + 1);
        setShowModalDelete(false);
        setCurrentCustomerArea(null);
      } catch (error) {
        console.error("Error deleting Customer Area:", error);
      }
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      await api.put(
        ENDPOINTS.update(currentUpdateCustomerArea._id),
        updateCustomerAreaData
      );
      setShowModalUpdate(false);
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        visibility: true,
        message: "Customer Area Updated Successfully",
        type: "success"
      });
    } catch (error) {
      console.error("Error updating Customer Area:", error);
      if (error.response && error.response.data && error.response.data.message) {
        setAlertConfig({
          visibility: true,
          message: `${error?.response?.data?.message}`,
          type: "error"
        });
      } else {
        setAlertConfig({
          visibility: true,
          message: "An unexpected error occurred. Please try again.",
          type: "error"
        });
      }
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
        lineNumber: 314,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: GlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
          lineNumber: 315,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
          lineNumber: 319,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 overflow-x-auto", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8 min-w-max", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Customer Area" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
            lineNumber: 331,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowModal(true);
              },
              className: "ml-4 bg-blue-950 text-white px-4 py-2 rounded shadow-md hover:bg-blue-800 transition duration-200",
              children: "+ Add Customer Area"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
              lineNumber: 333,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
          lineNumber: 330,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
          lineNumber: 329,
          columnNumber: 13
        }, this),
        tableCustomerArea?.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            catcher: "_id",
            updateHandler: handleUpdateModalOpen,
            data: filterOption(tableCustomerArea, searchText),
            columns,
            exportedPdfName: "Customer Area",
            exportedFileName: "Customer Area.csv"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
            lineNumber: 344,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: tableCustomerArea.length <= 0,
            data: " Customer Area Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
            lineNumber: 353,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
        lineNumber: 328,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
      lineNumber: 313,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Customer Area" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
        lineNumber: 365,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "area_name",
              children: "Customer Area Name"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
              lineNumber: 370,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "text",
              name: "area_name",
              value: customerAreaData?.area_name,
              onChange: handleChange,
              id: "area_name",
              placeholder: "Enter the Customer Area Name",
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
              lineNumber: 376,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
          lineNumber: 369,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "pincode",
              children: "Pincode"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
              lineNumber: 388,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "text",
              name: "pincode",
              value: customerAreaData?.pincode,
              onChange: handleChange,
              id: "pincode",
              placeholder: "Enter the Pincode",
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
              lineNumber: 394,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
          lineNumber: 387,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "area_type",
              children: "Area Type"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
              lineNumber: 406,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              size: "large",
              placeholder: "Select Area Type",
              value: customerAreaData?.area_type || void 0,
              onChange: (value) => handleChange({ target: { name: "area_type", value } }),
              style: { width: "100%" },
              options: AREA_TYPE_OPTIONS
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
              lineNumber: 412,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
          lineNumber: 405,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "description",
              children: "Description"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
              lineNumber: 427,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input.TextArea,
            {
              name: "description",
              value: customerAreaData?.description,
              onChange: handleChange,
              id: "description",
              placeholder: "Enter a Description",
              rows: 3,
              className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
              lineNumber: 433,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
          lineNumber: 426,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
            children: "Save Customer Area"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
            lineNumber: 445,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
          lineNumber: 444,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
        lineNumber: 368,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
      lineNumber: 364,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
      lineNumber: 363,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Customer Area" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
            lineNumber: 463,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "uarea_name",
                  children: "Customer Area Name"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
                  lineNumber: 468,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "area_name",
                  value: updateCustomerAreaData?.area_name,
                  onChange: handleInputChange,
                  id: "uarea_name",
                  placeholder: "Enter the Customer Area Name",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
                  lineNumber: 474,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
              lineNumber: 467,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "upincode",
                  children: "Pincode"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
                  lineNumber: 487,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "pincode",
                  value: updateCustomerAreaData?.pincode,
                  onChange: handleInputChange,
                  id: "upincode",
                  placeholder: "Enter the Pincode",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
                  lineNumber: 493,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
              lineNumber: 486,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "uarea_type",
                  children: "Area Type"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
                  lineNumber: 505,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  size: "large",
                  placeholder: "Select Area Type",
                  value: updateCustomerAreaData?.area_type || void 0,
                  onChange: (value) => handleInputChange({
                    target: { name: "area_type", value }
                  }),
                  style: { width: "100%" },
                  options: AREA_TYPE_OPTIONS
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
                  lineNumber: 511,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
              lineNumber: 504,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "udescription",
                  children: "Description"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
                  lineNumber: 528,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input.TextArea,
                {
                  name: "description",
                  value: updateCustomerAreaData?.description,
                  onChange: handleInputChange,
                  id: "udescription",
                  placeholder: "Enter a Description",
                  rows: 3,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
                  lineNumber: 534,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
              lineNumber: 527,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Update"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
                lineNumber: 546,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
              lineNumber: 545,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
            lineNumber: 466,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
          lineNumber: 462,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
        lineNumber: 458,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentCustomerArea(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Customer Area" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
            lineNumber: 567,
            columnNumber: 13
          }, this),
          currentCustomerArea && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteCustomerArea();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "areaName",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentCustomerArea?.area_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
                          lineNumber: 584,
                          columnNumber: 21
                        }, this),
                        " ",
                        "to confirm deletion."
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
                      lineNumber: 579,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      id: "areaName",
                      placeholder: "Enter the Customer Area Name",
                      required: true,
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
                      lineNumber: 589,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
                  lineNumber: 578,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\n          focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
                    lineNumber: 597,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
              lineNumber: 571,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
          lineNumber: 566,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
        lineNumber: 559,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
    lineNumber: 312,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx",
    lineNumber: 311,
    columnNumber: 5
  }, this);
};
_s(CustomerArea, "OL+o51cT1KkgOsLx2g1c2i5YULw=");
_c = CustomerArea;
export default CustomerArea;
var _c;
$RefreshReg$(_c, "CustomerArea");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerArea.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkc0QixTQTJNeEIsVUEzTXdCOzJCQTNHNUI7QUFBbUJBLG9CQUFpQixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxTQUFTO0FBQ2hCLFNBQVNDLE9BQU9DLFVBQVVDLGNBQWM7QUFDeEMsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLHVCQUF1QjtBQUM5QixTQUFTQyxpQkFBaUI7QUFJMUIsTUFBTUMsb0JBQW9CO0FBQUEsRUFDeEIsRUFBRUMsT0FBTyxXQUFXQyxPQUFPLFVBQVU7QUFBQSxFQUNyQyxFQUFFRCxPQUFPLFFBQVFDLE9BQU8sT0FBTztBQUFBLEVBQy9CLEVBQUVELE9BQU8sUUFBUUMsT0FBTyxPQUFPO0FBQUEsRUFDL0IsRUFBRUQsT0FBTyxRQUFRQyxPQUFPLE9BQU87QUFBQSxFQUMvQixFQUFFRCxPQUFPLFVBQVVDLE9BQU8sU0FBUztBQUFBLEVBQ25DLEVBQUVELE9BQU8sWUFBWUMsT0FBTyxXQUFXO0FBQUEsRUFDdkMsRUFBRUQsT0FBTyxRQUFRQyxPQUFPLE9BQU87QUFBQSxFQUMvQixFQUFFRCxPQUFPLFNBQVNDLE9BQU8sUUFBUTtBQUFDO0FBTXBDLE1BQU1DLFlBQVk7QUFBQSxFQUNoQkMsUUFBUTtBQUFBLEVBQ1JDLFFBQVE7QUFBQSxFQUNSQyxTQUFTQSxDQUFDQyxPQUFPLDRCQUE0QkEsRUFBRTtBQUFBLEVBQy9DQyxRQUFRQSxDQUFDRCxPQUFPLDRCQUE0QkEsRUFBRTtBQUFBLEVBQzlDRSxRQUFRQSxDQUFDRixPQUFPLDRCQUE0QkEsRUFBRTtBQUNoRDtBQUVBLE1BQU1HLGVBQWVBLE1BQU07QUFBQUMsS0FBQTtBQUd6QixRQUFNLENBQUNDLHFCQUFxQkMsc0JBQXNCLElBQUlDLFNBQVMsSUFBSTtBQUNuRSxRQUFNLENBQUNDLGlCQUFpQkMsa0JBQWtCLElBQUlGLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNHLDJCQUEyQkMsNEJBQTRCLElBQzVESixTQUFTLElBQUk7QUFDZixRQUFNLENBQUNLLGlCQUFpQkMsa0JBQWtCLElBQUlOLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNPLG1CQUFtQkMsb0JBQW9CLElBQUlSLFNBQVMsRUFBRTtBQUM3RCxRQUFNLENBQUNTLGtCQUFrQkMsbUJBQW1CLElBQUlWLFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUNXLGtCQUFrQkMsbUJBQW1CLElBQUlaLFNBQVM7QUFBQSxJQUV2RGEsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxJQUNYQyxTQUFTO0FBQUEsSUFDVEMsYUFBYTtBQUFBLEVBQ2YsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJbEIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ21CLFdBQVdDLFlBQVksSUFBSXBCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNxQixlQUFlQyxnQkFBZ0IsSUFBSXRCLFNBQVMsQ0FBQztBQUVwRCxRQUFNLENBQUN1Qix3QkFBd0JDLHlCQUF5QixJQUFJeEIsU0FBUztBQUFBLElBRW5FYSxXQUFXO0FBQUEsSUFDWEMsV0FBVztBQUFBLElBQ1hDLFNBQVM7QUFBQSxJQUNUQyxhQUFhO0FBQUEsRUFDZixDQUFDO0FBRUQsUUFBTSxDQUFDUyxhQUFhQyxjQUFjLElBQUkxQixTQUFTO0FBQUEsSUFDN0MyQixZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFFRCxRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSS9CLFNBQVMsRUFBRTtBQUMvQyxRQUFNZ0MsNEJBQTRCQSxDQUFDQyxNQUFNO0FBQ3ZDLFVBQU0sRUFBRTlDLE1BQU0sSUFBSThDLEVBQUVDO0FBQ3BCSCxrQkFBYzVDLEtBQUs7QUFBQSxFQUNyQjtBQUVBZixZQUFVLE1BQU07QUFDZCxVQUFNK0Qsb0JBQW9CLFlBQVk7QUFDcEMsVUFBSTtBQUNGZixxQkFBYSxJQUFJO0FBQ2pCLGNBQU1nQixXQUFXLE1BQU0zRCxJQUFJNEQsSUFBSWhELFVBQVVFLE1BQU07QUFDL0NtQiw0QkFBb0IwQixVQUFVRSxNQUFNQSxJQUFJO0FBQ3hDLGNBQU1DLHdCQUF3QkgsVUFBVUUsTUFBTUEsS0FBS0U7QUFBQUEsVUFDakQsQ0FBQ0MsY0FBY0MsVUFBVTtBQUN2QixtQkFBTztBQUFBLGNBQ0xDLEtBQUtGLGNBQWNFO0FBQUFBLGNBQ25CbEQsSUFBSWlELFFBQVE7QUFBQSxjQUNaN0IsV0FBVzRCLGNBQWM1QjtBQUFBQSxjQUN6QkMsV0FBVzJCLGNBQWMzQjtBQUFBQSxjQUN6QkMsU0FBUzBCLGNBQWMxQjtBQUFBQSxjQUN2QkMsYUFBYXlCLGNBQWN6QjtBQUFBQSxjQUMzQjRCLFdBQVdILGFBQWFHLFdBQVdDLE1BQU0sR0FBRyxFQUFFLENBQUMsRUFDNUNBLE1BQU0sR0FBRyxFQUNUQyxRQUFRLEVBQ1JDLEtBQUssR0FBRztBQUFBLGNBRVhDLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsa0JBQ2pCLE1BQU07QUFBQSxvQkFDSkMsT0FBTztBQUFBLHNCQUNMO0FBQUEsd0JBQ0VDLEtBQUs7QUFBQSx3QkFDTDlELE9BQ0U7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVTtBQUFBLDRCQUNWLFNBQVMsTUFDUCtELHNCQUFzQlYsY0FBY0UsR0FBRztBQUFBLDRCQUN4QztBQUFBO0FBQUEsMEJBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQU9BO0FBQUEsc0JBRUo7QUFBQSxzQkFDQTtBQUFBLHdCQUNFTyxLQUFLO0FBQUEsd0JBQ0w5RCxPQUNFO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVU7QUFBQSw0QkFDVixTQUFTLE1BQ1BnRSxzQkFBc0JYLGNBQWNFLEdBQUc7QUFBQSw0QkFDeEM7QUFBQTtBQUFBLDBCQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFPQTtBQUFBLHNCQUVKO0FBQUEsb0JBQUM7QUFBQSxrQkFFTDtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFFVixpQ0FBQyxZQUFTLFdBQVUsZUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQTtBQUFBLGdCQWxDakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBbUNBLEtBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUNBO0FBQUEsWUFFSjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBRUFuQyw2QkFBcUIrQixxQkFBcUI7QUFBQSxNQUM1QyxTQUFTYyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLHNDQUFzQ0EsTUFBTXpCLE9BQU87QUFBQSxNQUNuRSxVQUFDO0FBQ0NSLHFCQUFhLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFDQWUsc0JBQWtCO0FBQUEsRUFDcEIsR0FBRyxDQUFDZCxhQUFhLENBQUM7QUFFbEIsUUFBTWtDLGVBQWVBLENBQUN0QixNQUFNO0FBQzFCLFVBQU0sRUFBRXVCLE1BQU1yRSxNQUFNLElBQUk4QyxFQUFFQztBQUUxQnRCLHdCQUFvQixDQUFDNkMsY0FBYztBQUFBLE1BQ2pDLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0QsSUFBSSxHQUFHckU7QUFBQUEsSUFDVixFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU11RSxvQkFBb0JBLENBQUN6QixNQUFNO0FBQy9CLFVBQU0sRUFBRXVCLE1BQU1yRSxNQUFNLElBQUk4QyxFQUFFQztBQUMxQlYsOEJBQTBCLENBQUNpQyxjQUFjO0FBQUEsTUFDdkMsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRCxJQUFJLEdBQUdyRTtBQUFBQSxJQUNWLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTXdFLGVBQWUsT0FBTzFCLE1BQU07QUFDaENBLE1BQUUyQixlQUFlO0FBRWpCLFFBQUk7QUFDRixZQUFNbkYsSUFBSW9GLEtBQUt4RSxVQUFVQyxRQUFRcUIsa0JBQWtCO0FBQUEsUUFDakRtRCxTQUFTO0FBQUEsVUFDUCxnQkFBZ0I7QUFBQSxRQUNsQjtBQUFBLE1BQ0YsQ0FBQztBQUVEeEMsdUJBQWlCLENBQUN5QyxTQUFTQSxPQUFPLENBQUM7QUFDbkNyQyxxQkFBZTtBQUFBLFFBQ2JHLE1BQU07QUFBQSxRQUNORCxTQUFTO0FBQUEsUUFDVEQsWUFBWTtBQUFBLE1BQ2QsQ0FBQztBQUVEVCxtQkFBYSxLQUFLO0FBRWxCTiwwQkFBb0I7QUFBQSxRQUNsQm9ELFdBQVc7QUFBQSxRQUNYbkQsV0FBVztBQUFBLFFBQ1hDLFdBQVc7QUFBQSxRQUNYQyxTQUFTO0FBQUEsUUFDVEMsYUFBYTtBQUFBLE1BQ2YsQ0FBQztBQUFBLElBQ0gsU0FBU3FDLE9BQU87QUFDZEMsY0FBUUQsTUFBTSwrQkFBK0JBLEtBQUs7QUFDbEQsVUFDRUEsTUFBTWpCLFlBQ05pQixNQUFNakIsU0FBU0UsUUFDZmUsTUFBTWpCLFNBQVNFLEtBQUtWLFNBQ3BCO0FBQ0FGLHVCQUFlO0FBQUEsVUFDYkcsTUFBTTtBQUFBLFVBQ05ELFNBQVMsR0FBR3lCLE9BQU9qQixVQUFVRSxNQUFNVixPQUFPO0FBQUEsVUFDMUNELFlBQVk7QUFBQSxRQUNkLENBQUM7QUFBQSxNQUNILE9BQU87QUFDTEQsdUJBQWU7QUFBQSxVQUNiRyxNQUFNO0FBQUEsVUFDTkQsU0FBUztBQUFBLFVBQ1RELFlBQVk7QUFBQSxRQUNkLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNc0MsVUFBVTtBQUFBLElBQ2QsRUFBRWYsS0FBSyxNQUFNZ0IsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRWhCLEtBQUssYUFBYWdCLFFBQVEsT0FBTztBQUFBLElBQ25DLEVBQUVoQixLQUFLLGFBQWFnQixRQUFRLHFCQUFxQjtBQUFBLElBQ2pELEVBQUVoQixLQUFLLGFBQWFnQixRQUFRLFlBQVk7QUFBQSxJQUN4QyxFQUFFaEIsS0FBSyxXQUFXZ0IsUUFBUSxVQUFVO0FBQUEsSUFDcEMsRUFBRWhCLEtBQUssZUFBZWdCLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUVoQixLQUFLLFVBQVVnQixRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFFBQU1kLHdCQUF3QixPQUFPZSxPQUFPO0FBQzFDLFFBQUk7QUFDRixZQUFNL0IsV0FBVyxNQUFNM0QsSUFBSTRELElBQUloRCxVQUFVRyxRQUFRMkUsRUFBRSxDQUFDO0FBQ3BEcEUsNkJBQXVCcUMsU0FBU0UsSUFBSTtBQUNwQ3BDLHlCQUFtQixJQUFJO0FBQUEsSUFDekIsU0FBU21ELE9BQU87QUFDZEMsY0FBUUQsTUFBTSx1Q0FBdUNBLEtBQUs7QUFBQSxJQUM1RDtBQUFBLEVBQ0Y7QUFFQSxRQUFNRix3QkFBd0IsT0FBT2dCLE9BQU87QUFDMUMsUUFBSTtBQUNGLFlBQU0vQixXQUFXLE1BQU0zRCxJQUFJNEQsSUFBSWhELFVBQVVHLFFBQVEyRSxFQUFFLENBQUM7QUFDcEQvRCxtQ0FBNkJnQyxVQUFVRSxJQUFJO0FBQzNDZCxnQ0FBMEI7QUFBQSxRQUN4QndDLFdBQVc1QixVQUFVRSxNQUFNMEIsV0FBV3JCLE9BQU9QLFVBQVVFLE1BQU0wQjtBQUFBQSxRQUM3RG5ELFdBQVd1QixVQUFVRSxNQUFNekI7QUFBQUEsUUFDM0JDLFdBQVdzQixVQUFVRSxNQUFNeEI7QUFBQUEsUUFDM0JDLFNBQVNxQixVQUFVRSxNQUFNdkI7QUFBQUEsUUFDekJDLGFBQWFvQixVQUFVRSxNQUFNdEI7QUFBQUEsTUFDL0IsQ0FBQztBQUNEVix5QkFBbUIsSUFBSTtBQUFBLElBQ3pCLFNBQVMrQyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sc0NBQXNDQSxLQUFLO0FBQUEsSUFDM0Q7QUFBQSxFQUNGO0FBRUEsUUFBTWUsMkJBQTJCLFlBQVk7QUFDM0MsUUFBSXRFLHFCQUFxQjtBQUN2QixVQUFJO0FBQ0YsY0FBTXJCLElBQUlrQixPQUFPTixVQUFVTSxPQUFPRyxvQkFBb0I2QyxHQUFHLENBQUM7QUFDMURqQix1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUNEUCx5QkFBaUIsQ0FBQ3lDLFNBQVNBLE9BQU8sQ0FBQztBQUNuQzdELDJCQUFtQixLQUFLO0FBQ3hCSCwrQkFBdUIsSUFBSTtBQUFBLE1BQzdCLFNBQVNzRCxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLGlDQUFpQ0EsS0FBSztBQUFBLE1BQ3REO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0IsZUFBZSxPQUFPcEMsTUFBTTtBQUNoQ0EsTUFBRTJCLGVBQWU7QUFDakIsUUFBSTtBQUNGLFlBQU1uRixJQUFJNkY7QUFBQUEsUUFDUmpGLFVBQVVLLE9BQU9TLDBCQUEwQndDLEdBQUc7QUFBQSxRQUM5Q3BCO0FBQUFBLE1BQ0Y7QUFDQWpCLHlCQUFtQixLQUFLO0FBQ3hCZ0IsdUJBQWlCLENBQUN5QyxTQUFTQSxPQUFPLENBQUM7QUFFbkNyQyxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUFTO0FBQUEsUUFDVEMsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0gsU0FBU3dCLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxpQ0FBaUNBLEtBQUs7QUFDcEQsVUFDRUEsTUFBTWpCLFlBQ05pQixNQUFNakIsU0FBU0UsUUFDZmUsTUFBTWpCLFNBQVNFLEtBQUtWLFNBQ3BCO0FBQ0FGLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVMsR0FBR3lCLE9BQU9qQixVQUFVRSxNQUFNVixPQUFPO0FBQUEsVUFDMUNDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNILE9BQU87QUFDTEgsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLG1DQUNFLGlDQUFDLFNBQ0M7QUFBQSwyQkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDZCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsNkJBQTZCRztBQUFBQSxVQUM3QixZQUFZO0FBQUE7QUFBQSxRQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUVtQjtBQUFBLE1BRW5CO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFNUCxZQUFZSTtBQUFBQSxVQUNsQixXQUFXSixZQUFZRTtBQUFBQSxVQUN2QixTQUFTRixZQUFZRztBQUFBQSxVQUNyQixTQUFTLE1BQ1BGLGVBQWUsQ0FBQ3FDLFVBQVUsRUFBRSxHQUFHQSxNQUFNcEMsWUFBWSxNQUFNLEVBQUU7QUFBQTtBQUFBLFFBTDdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1HO0FBQUEsTUFHSCx1QkFBQyxTQUFJLFdBQVUsaUNBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsdUJBQ2IsaUNBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBCQUF5Qiw2QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0Q7QUFBQSxVQUVwRDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNO0FBQ2JULDZCQUFhLElBQUk7QUFBQSxjQUNuQjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBQW1HO0FBQUE7QUFBQSxZQUovRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLGFBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsUUFDQ1gsbUJBQW1CZ0UsU0FBUyxLQUFLLENBQUNwRCxZQUNqQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUTtBQUFBLFlBQ1IsZUFBZWdDO0FBQUFBLFlBQ2YsTUFBTXBFLGFBQWF3QixtQkFBbUJ1QixVQUFVO0FBQUEsWUFDaEQ7QUFBQSxZQUNBLGlCQUFnQjtBQUFBLFlBQ2hCLGtCQUFpQjtBQUFBO0FBQUEsVUFObkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTXNDLElBR3RDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0EsU0FBU3ZCLGtCQUFrQmdFLFVBQVU7QUFBQSxZQUNyQyxNQUFLO0FBQUE7QUFBQSxVQUhQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUc0QjtBQUFBLFdBNUJoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBK0JBO0FBQUEsU0E5Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStDQTtBQUFBLElBR0EsdUJBQUMsU0FBTSxXQUFXdEQsV0FBVyxTQUFTLE1BQU1DLGFBQWEsS0FBSyxHQUM1RCxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsd0NBQXVDLGlDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVV5QyxjQUFjLFlBQVUsTUFDNUQ7QUFBQSwrQkFBQyxTQUNDO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLFNBQVE7QUFBQSxjQUFXO0FBQUE7QUFBQSxZQUZyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLE9BQU9oRCxrQkFBa0JFO0FBQUFBLGNBQ3pCLFVBQVUwQztBQUFBQSxjQUNWLElBQUc7QUFBQSxjQUNILGFBQVk7QUFBQSxjQUNaLFdBQVcscUNBQXFDdEUsVUFBVXVGLE1BQU07QUFBQTtBQUFBLFlBUGxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU82SjtBQUFBLGFBZC9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxRQUVBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBUTtBQUFBLGNBQVM7QUFBQTtBQUFBLFlBRm5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsTUFBSztBQUFBLGNBQ0wsT0FBTzdELGtCQUFrQkk7QUFBQUEsY0FDekIsVUFBVXdDO0FBQUFBLGNBQ1YsSUFBRztBQUFBLGNBQ0gsYUFBWTtBQUFBLGNBQ1osV0FBVyxxQ0FBcUN0RSxVQUFVdUYsTUFBTTtBQUFBO0FBQUEsWUFQbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTzZKO0FBQUEsYUFkL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdCQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixTQUFRO0FBQUEsY0FBVztBQUFBO0FBQUEsWUFGckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxhQUFZO0FBQUEsY0FDWixPQUFPN0Qsa0JBQWtCRyxhQUFhMkQ7QUFBQUEsY0FDdEMsVUFBVSxDQUFDdEYsVUFDVG9FLGFBQWEsRUFBRXJCLFFBQVEsRUFBRXNCLE1BQU0sYUFBYXJFLE1BQU0sRUFBRSxDQUFDO0FBQUEsY0FFdkQsT0FBTyxFQUFFdUYsT0FBTyxPQUFPO0FBQUEsY0FDdkIsU0FBU3hGO0FBQUFBO0FBQUFBLFlBUlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUTZCO0FBQUEsYUFmL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFFBSUEsdUJBQUMsU0FDQztBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixTQUFRO0FBQUEsY0FBYTtBQUFBO0FBQUEsWUFGdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxVQUNBO0FBQUEsWUFBQyxNQUFNO0FBQUEsWUFBTjtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsT0FBT3lCLGtCQUFrQks7QUFBQUEsY0FDekIsVUFBVXVDO0FBQUFBLGNBQ1YsSUFBRztBQUFBLGNBQ0gsYUFBWTtBQUFBLGNBQ1osTUFBTTtBQUFBLGNBQ04sV0FBVTtBQUFBO0FBQUEsWUFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPdUk7QUFBQSxhQWR6STtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUM2RjtBQUFBO0FBQUEsVUFIekc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQXBGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUZBO0FBQUEsU0F6RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBGQSxLQTNGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEZBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV2xEO0FBQUFBLFFBQ1gsU0FBUyxNQUFNQyxtQkFBbUIsS0FBSztBQUFBLFFBRXZDLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMsb0NBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVUrRCxjQUFjLFlBQVUsTUFDNUQ7QUFBQSxtQ0FBQyxTQUNDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBWTtBQUFBO0FBQUEsZ0JBRnRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU85Qyx3QkFBd0JWO0FBQUFBLGtCQUMvQixVQUFVNkM7QUFBQUEsa0JBQ1YsSUFBRztBQUFBLGtCQUNILGFBQVk7QUFBQSxrQkFDWjtBQUFBLGtCQUNBLFdBQVcscUNBQXFDekUsVUFBVXVGLE1BQU07QUFBQTtBQUFBLGdCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRNko7QUFBQSxpQkFmL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxZQUVBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFVO0FBQUE7QUFBQSxnQkFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsT0FBT2pELHdCQUF3QlI7QUFBQUEsa0JBQy9CLFVBQVUyQztBQUFBQSxrQkFDVixJQUFHO0FBQUEsa0JBQ0gsYUFBWTtBQUFBLGtCQUNaLFdBQVcscUNBQXFDekUsVUFBVXVGLE1BQU07QUFBQTtBQUFBLGdCQVBsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPNko7QUFBQSxpQkFkL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxZQUVBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFZO0FBQUE7QUFBQSxnQkFGdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxhQUFZO0FBQUEsa0JBQ1osT0FBT2pELHdCQUF3QlQsYUFBYTJEO0FBQUFBLGtCQUM1QyxVQUFVLENBQUN0RixVQUNUdUUsa0JBQWtCO0FBQUEsb0JBQ2hCeEIsUUFBUSxFQUFFc0IsTUFBTSxhQUFhckUsTUFBTTtBQUFBLGtCQUNyQyxDQUFDO0FBQUEsa0JBRUgsT0FBTyxFQUFFdUYsT0FBTyxPQUFPO0FBQUEsa0JBQ3ZCLFNBQVN4RjtBQUFBQTtBQUFBQSxnQkFWWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FVNkI7QUFBQSxpQkFqQi9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbUJBO0FBQUEsWUFJQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBYztBQUFBO0FBQUEsZ0JBRnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDLE1BQU07QUFBQSxnQkFBTjtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFPcUMsd0JBQXdCUDtBQUFBQSxrQkFDL0IsVUFBVTBDO0FBQUFBLGtCQUNWLElBQUc7QUFBQSxrQkFDSCxhQUFZO0FBQUEsa0JBQ1osTUFBTTtBQUFBLGtCQUNOLFdBQVU7QUFBQTtBQUFBLGdCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU91STtBQUFBLGlCQWR6STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDNkY7QUFBQTtBQUFBLGNBSHpHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBdkZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0ZBO0FBQUEsYUE1RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZGQTtBQUFBO0FBQUEsTUFqR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBa0dBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV3pEO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JDLDZCQUFtQixLQUFLO0FBQ3hCSCxpQ0FBdUIsSUFBSTtBQUFBLFFBQzdCO0FBQUEsUUFFQSxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLG9DQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQ0QsdUJBQ0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFVBQVUsQ0FBQ21DLE1BQU07QUFDZkEsa0JBQUUyQixlQUFlO0FBQ2pCUSx5Q0FBeUI7QUFBQSxjQUMzQjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVY7QUFBQSx1Q0FBQyxTQUNDO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFNBQVE7QUFBQSxzQkFBVTtBQUFBO0FBQUEsd0JBRUw7QUFBQSx3QkFDYix1QkFBQyxVQUFLLFdBQVUsMEJBQ2J0RSwrQkFBcUJlLGFBRHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSx3QkFBUTtBQUFBLHdCQUFJO0FBQUE7QUFBQTtBQUFBLG9CQVBkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFTQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxJQUFHO0FBQUEsc0JBQ0gsYUFBWTtBQUFBLHNCQUNaO0FBQUEsc0JBQ0EsV0FBVyxxQ0FBcUM1QixVQUFVdUYsTUFBTTtBQUFBO0FBQUEsb0JBTGxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLNko7QUFBQSxxQkFoQi9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0JBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDeUY7QUFBQTtBQUFBLGtCQUhyRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQTtBQUFBO0FBQUEsWUFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBaUNBO0FBQUEsYUF0Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdDQTtBQUFBO0FBQUEsTUEvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZ0RBO0FBQUEsT0F2U0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdTQSxLQXpTRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMFNBO0FBRUo7QUFBRTNFLEdBN2pCSUQsY0FBWTtBQUFBK0UsS0FBWi9FO0FBOGpCTixlQUFlQTtBQUFhLElBQUErRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwiU2lkZWJhciIsIk5hdmJhciIsIkNpcmN1bGFyTG9hZGVyIiwiTW9kYWwiLCJhcGkiLCJJbnB1dCIsIkRyb3Bkb3duIiwiU2VsZWN0IiwiSW9NZE1vcmUiLCJEYXRhVGFibGUiLCJmaWx0ZXJPcHRpb24iLCJDdXN0b21BbGVydERpYWxvZyIsImZpZWxkU2l6ZSIsIkFSRUFfVFlQRV9PUFRJT05TIiwidmFsdWUiLCJsYWJlbCIsIkVORFBPSU5UUyIsImNyZWF0ZSIsImdldEFsbCIsImdldEJ5SWQiLCJpZCIsInVwZGF0ZSIsImRlbGV0ZSIsIkN1c3RvbWVyQXJlYSIsIl9zIiwiY3VycmVudEN1c3RvbWVyQXJlYSIsInNldEN1cnJlbnRDdXN0b21lckFyZWEiLCJ1c2VTdGF0ZSIsInNob3dNb2RhbERlbGV0ZSIsInNldFNob3dNb2RhbERlbGV0ZSIsImN1cnJlbnRVcGRhdGVDdXN0b21lckFyZWEiLCJzZXRDdXJyZW50VXBkYXRlQ3VzdG9tZXJBcmVhIiwic2hvd01vZGFsVXBkYXRlIiwic2V0U2hvd01vZGFsVXBkYXRlIiwidGFibGVDdXN0b21lckFyZWEiLCJzZXRUYWJsZUN1c3RvbWVyQXJlYSIsImN1c3RvbWVyQXJlYUxpc3QiLCJzZXRDdXN0b21lckFyZWFMaXN0IiwiY3VzdG9tZXJBcmVhRGF0YSIsInNldEN1c3RvbWVyQXJlYURhdGEiLCJhcmVhX25hbWUiLCJhcmVhX3R5cGUiLCJwaW5jb2RlIiwiZGVzY3JpcHRpb24iLCJzaG93TW9kYWwiLCJzZXRTaG93TW9kYWwiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJyZWxvYWRUcmlnZ2VyIiwic2V0UmVsb2FkVHJpZ2dlciIsInVwZGF0ZUN1c3RvbWVyQXJlYURhdGEiLCJzZXRVcGRhdGVDdXN0b21lckFyZWFEYXRhIiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwidHlwZSIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwiR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciIsImUiLCJ0YXJnZXQiLCJmZXRjaEN1c3RvbWVyQXJlYSIsInJlc3BvbnNlIiwiZ2V0IiwiZGF0YSIsImN1c3RvbWVyQXJlYVRhYmxlRGF0YSIsIm1hcCIsImN1c3RvbWVyQXJlYSIsImluZGV4IiwiX2lkIiwiY3JlYXRlZEF0Iiwic3BsaXQiLCJyZXZlcnNlIiwiam9pbiIsImFjdGlvbiIsIml0ZW1zIiwia2V5IiwiaGFuZGxlVXBkYXRlTW9kYWxPcGVuIiwiaGFuZGxlRGVsZXRlTW9kYWxPcGVuIiwiZXJyb3IiLCJjb25zb2xlIiwiaGFuZGxlQ2hhbmdlIiwibmFtZSIsInByZXZEYXRhIiwiaGFuZGxlSW5wdXRDaGFuZ2UiLCJoYW5kbGVTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsInBvc3QiLCJoZWFkZXJzIiwicHJldiIsImJyYW5jaF9pZCIsImNvbHVtbnMiLCJoZWFkZXIiLCJJZCIsImhhbmRsZURlbGV0ZUN1c3RvbWVyQXJlYSIsImhhbmRsZVVwZGF0ZSIsInB1dCIsImxlbmd0aCIsImhlaWdodCIsInVuZGVmaW5lZCIsIndpZHRoIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ3VzdG9tZXJBcmVhLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgeyBJbnB1dCwgRHJvcGRvd24sIFNlbGVjdCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IElvTWRNb3JlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0RGlhbG9nIGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydERpYWxvZ1wiO1xyXG5pbXBvcnQgeyBmaWVsZFNpemUgfSBmcm9tIFwiLi4vZGF0YS9maWVsZFNpemVcIjtcclxuXHJcbi8vIE5PVEU6IGFyZWFfdHlwZSBvcHRpb25zIGFyZSBhIGd1ZXNzIGJhc2VkIG9uIHRoZSBzY2hlbWEgZmllbGQgbmFtZS5cclxuLy8gUmVwbGFjZSB3aXRoIHRoZSBhY3R1YWwgZW51bSB2YWx1ZXMgdXNlZCBieSBjcmVhdGVDdXN0b21lckFyZWFTY2hlbWEgKHpvZCkgb24gdGhlIGJhY2tlbmQuXHJcbmNvbnN0IEFSRUFfVFlQRV9PUFRJT05TID0gW1xyXG4gIHsgdmFsdWU6IFwiVmlsbGFnZVwiLCBsYWJlbDogXCJWaWxsYWdlXCIgfSxcclxuICB7IHZhbHVlOiBcIlRvd25cIiwgbGFiZWw6IFwiVG93blwiIH0sXHJcbiAgeyB2YWx1ZTogXCJDaXR5XCIsIGxhYmVsOiBcIkNpdHlcIiB9LFxyXG4gIHsgdmFsdWU6IFwiV2FyZFwiLCBsYWJlbDogXCJXYXJkXCIgfSxcclxuICB7IHZhbHVlOiBcIkxheW91dFwiLCBsYWJlbDogXCJMYXlvdXRcIiB9LFxyXG4gIHsgdmFsdWU6IFwiTG9jYWxpdHlcIiwgbGFiZWw6IFwiTG9jYWxpdHlcIiB9LFxyXG4gIHsgdmFsdWU6IFwiWm9uZVwiLCBsYWJlbDogXCJab25lXCIgfSxcclxuICB7IHZhbHVlOiBcIk90aGVyXCIsIGxhYmVsOiBcIk90aGVyXCIgfSxcclxuXTtcclxuXHJcbi8vIE5PVEU6IGVuZHBvaW50IHBhdGhzIGJlbG93IGZvbGxvdyB0aGUgXCJjdXN0b21lci1hcmVhXCIgbmFtaW5nIGNvbnZlbnRpb24gaW1wbGllZCBieVxyXG4vLyBleHBvcnRzLmNyZWF0ZUN1c3RvbWVyQXJlYS4gT25seSB0aGUgY3JlYXRlIGVuZHBvaW50IHdhcyBnaXZlbjsgdmVyaWZ5IHRoZVxyXG4vLyBnZXQtYWxsIC8gZ2V0LWJ5LWlkIC8gdXBkYXRlIC8gZGVsZXRlIHJvdXRlcyBhZ2FpbnN0IHlvdXIgYWN0dWFsIHJvdXRlciBmaWxlLlxyXG5jb25zdCBFTkRQT0lOVFMgPSB7XHJcbiAgY3JlYXRlOiBcIi92MS9hZG1pbi9jdXN0b21lci1hcmVhL1wiLFxyXG4gIGdldEFsbDogXCIvdjEvYWRtaW4vY3VzdG9tZXItYXJlYS9cIixcclxuICBnZXRCeUlkOiAoaWQpID0+IGAvdjEvYWRtaW4vL2N1c3RvbWVyLWFyZWEvJHtpZH1gLFxyXG4gIHVwZGF0ZTogKGlkKSA9PiBgL3YxL2FkbWluLy9jdXN0b21lci1hcmVhLyR7aWR9YCxcclxuICBkZWxldGU6IChpZCkgPT4gYC92MS9hZG1pbi8vY3VzdG9tZXItYXJlYS8ke2lkfWAsXHJcbn07XHJcblxyXG5jb25zdCBDdXN0b21lckFyZWEgPSAoKSA9PiB7XHJcblxyXG5cclxuICBjb25zdCBbY3VycmVudEN1c3RvbWVyQXJlYSwgc2V0Q3VycmVudEN1c3RvbWVyQXJlYV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc2hvd01vZGFsRGVsZXRlLCBzZXRTaG93TW9kYWxEZWxldGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50VXBkYXRlQ3VzdG9tZXJBcmVhLCBzZXRDdXJyZW50VXBkYXRlQ3VzdG9tZXJBcmVhXSA9XHJcbiAgICB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc2hvd01vZGFsVXBkYXRlLCBzZXRTaG93TW9kYWxVcGRhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFt0YWJsZUN1c3RvbWVyQXJlYSwgc2V0VGFibGVDdXN0b21lckFyZWFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtjdXN0b21lckFyZWFMaXN0LCBzZXRDdXN0b21lckFyZWFMaXN0XSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbY3VzdG9tZXJBcmVhRGF0YSwgc2V0Q3VzdG9tZXJBcmVhRGF0YV0gPSB1c2VTdGF0ZSh7XHJcblxyXG4gICAgYXJlYV9uYW1lOiBcIlwiLFxyXG4gICAgYXJlYV90eXBlOiBcIlwiLFxyXG4gICAgcGluY29kZTogXCJcIixcclxuICAgIGRlc2NyaXB0aW9uOiBcIlwiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcmVsb2FkVHJpZ2dlciwgc2V0UmVsb2FkVHJpZ2dlcl0gPSB1c2VTdGF0ZSgwKTtcclxuXHJcbiAgY29uc3QgW3VwZGF0ZUN1c3RvbWVyQXJlYURhdGEsIHNldFVwZGF0ZUN1c3RvbWVyQXJlYURhdGFdID0gdXNlU3RhdGUoe1xyXG5cclxuICAgIGFyZWFfbmFtZTogXCJcIixcclxuICAgIGFyZWFfdHlwZTogXCJcIixcclxuICAgIHBpbmNvZGU6IFwiXCIsXHJcbiAgICBkZXNjcmlwdGlvbjogXCJcIixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFNlYXJjaFRleHQodmFsdWUpO1xyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEN1c3RvbWVyQXJlYSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KEVORFBPSU5UUy5nZXRBbGwpO1xyXG4gICAgICAgIHNldEN1c3RvbWVyQXJlYUxpc3QocmVzcG9uc2U/LmRhdGE/LmRhdGEpO1xyXG4gICAgICAgIGNvbnN0IGN1c3RvbWVyQXJlYVRhYmxlRGF0YSA9IHJlc3BvbnNlPy5kYXRhPy5kYXRhLm1hcChcclxuICAgICAgICAgIChjdXN0b21lckFyZWEsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgX2lkOiBjdXN0b21lckFyZWE/Ll9pZCxcclxuICAgICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICAgIGFyZWFfbmFtZTogY3VzdG9tZXJBcmVhPy5hcmVhX25hbWUsXHJcbiAgICAgICAgICAgICAgYXJlYV90eXBlOiBjdXN0b21lckFyZWE/LmFyZWFfdHlwZSxcclxuICAgICAgICAgICAgICBwaW5jb2RlOiBjdXN0b21lckFyZWE/LnBpbmNvZGUsXHJcbiAgICAgICAgICAgICAgZGVzY3JpcHRpb246IGN1c3RvbWVyQXJlYT8uZGVzY3JpcHRpb24sXHJcbiAgICAgICAgICAgICAgY3JlYXRlZEF0OiBjdXN0b21lckFyZWEuY3JlYXRlZEF0Py5zcGxpdChcIlRcIilbMF1cclxuICAgICAgICAgICAgICAgIC5zcGxpdChcIi1cIilcclxuICAgICAgICAgICAgICAgIC5yZXZlcnNlKClcclxuICAgICAgICAgICAgICAgIC5qb2luKFwiLVwiKSxcclxuXHJcbiAgICAgICAgICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgICAgICAgICAgdHJpZ2dlcj17W1wiY2xpY2tcIl19XHJcbiAgICAgICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZVVwZGF0ZU1vZGFsT3BlbihjdXN0b21lckFyZWE/Ll9pZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFZGl0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZURlbGV0ZU1vZGFsT3BlbihjdXN0b21lckFyZWE/Ll9pZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgc2V0VGFibGVDdXN0b21lckFyZWEoY3VzdG9tZXJBcmVhVGFibGVEYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgY3VzdG9tZXIgYXJlYSBkYXRhOlwiLCBlcnJvci5tZXNzYWdlKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hDdXN0b21lckFyZWEoKTtcclxuICB9LCBbcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcblxyXG4gICAgc2V0Q3VzdG9tZXJBcmVhRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUlucHV0Q2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0VXBkYXRlQ3VzdG9tZXJBcmVhRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYXBpLnBvc3QoRU5EUE9JTlRTLmNyZWF0ZSwgY3VzdG9tZXJBcmVhRGF0YSwge1xyXG4gICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgbWVzc2FnZTogXCJDdXN0b21lciBBcmVhIEFkZGVkIFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuXHJcbiAgICAgIHNldEN1c3RvbWVyQXJlYURhdGEoe1xyXG4gICAgICAgIGJyYW5jaF9pZDogXCJcIixcclxuICAgICAgICBhcmVhX25hbWU6IFwiXCIsXHJcbiAgICAgICAgYXJlYV90eXBlOiBcIlwiLFxyXG4gICAgICAgIHBpbmNvZGU6IFwiXCIsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IFwiXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGFkZGluZyBjdXN0b21lciBhcmVhOlwiLCBlcnJvcik7XHJcbiAgICAgIGlmIChcclxuICAgICAgICBlcnJvci5yZXNwb25zZSAmJlxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlLmRhdGEgJiZcclxuICAgICAgICBlcnJvci5yZXNwb25zZS5kYXRhLm1lc3NhZ2VcclxuICAgICAgKSB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgICAgbWVzc2FnZTogYCR7ZXJyb3I/LnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlfWAsXHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiQW4gdW5leHBlY3RlZCBlcnJvciBvY2N1cnJlZC4gUGxlYXNlIHRyeSBhZ2Fpbi5cIixcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJjcmVhdGVkQXRcIiwgaGVhZGVyOiBcIkRhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYXJlYV9uYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBBcmVhIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYXJlYV90eXBlXCIsIGhlYWRlcjogXCJBcmVhIFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGluY29kZVwiLCBoZWFkZXI6IFwiUGluY29kZVwiIH0sXHJcbiAgICB7IGtleTogXCJkZXNjcmlwdGlvblwiLCBoZWFkZXI6IFwiRGVzY3JpcHRpb25cIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZU1vZGFsT3BlbiA9IGFzeW5jIChJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KEVORFBPSU5UUy5nZXRCeUlkKElkKSk7XHJcbiAgICAgIHNldEN1cnJlbnRDdXN0b21lckFyZWEocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFNob3dNb2RhbERlbGV0ZSh0cnVlKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBDdXN0b21lciBhcmVhIERhdGEgOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxPcGVuID0gYXN5bmMgKElkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoRU5EUE9JTlRTLmdldEJ5SWQoSWQpKTtcclxuICAgICAgc2V0Q3VycmVudFVwZGF0ZUN1c3RvbWVyQXJlYShyZXNwb25zZT8uZGF0YSk7XHJcbiAgICAgIHNldFVwZGF0ZUN1c3RvbWVyQXJlYURhdGEoe1xyXG4gICAgICAgIGJyYW5jaF9pZDogcmVzcG9uc2U/LmRhdGE/LmJyYW5jaF9pZD8uX2lkIHx8IHJlc3BvbnNlPy5kYXRhPy5icmFuY2hfaWQsXHJcbiAgICAgICAgYXJlYV9uYW1lOiByZXNwb25zZT8uZGF0YT8uYXJlYV9uYW1lLFxyXG4gICAgICAgIGFyZWFfdHlwZTogcmVzcG9uc2U/LmRhdGE/LmFyZWFfdHlwZSxcclxuICAgICAgICBwaW5jb2RlOiByZXNwb25zZT8uZGF0YT8ucGluY29kZSxcclxuICAgICAgICBkZXNjcmlwdGlvbjogcmVzcG9uc2U/LmRhdGE/LmRlc2NyaXB0aW9uLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGN1c3RvbWVyIGFyZWEgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUN1c3RvbWVyQXJlYSA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmIChjdXJyZW50Q3VzdG9tZXJBcmVhKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLmRlbGV0ZShFTkRQT0lOVFMuZGVsZXRlKGN1cnJlbnRDdXN0b21lckFyZWEuX2lkKSk7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiQ3VzdG9tZXIgQXJlYSBkZWxldGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgc2V0Q3VycmVudEN1c3RvbWVyQXJlYShudWxsKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZGVsZXRpbmcgQ3VzdG9tZXIgQXJlYTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGFwaS5wdXQoXHJcbiAgICAgICAgRU5EUE9JTlRTLnVwZGF0ZShjdXJyZW50VXBkYXRlQ3VzdG9tZXJBcmVhLl9pZCksXHJcbiAgICAgICAgdXBkYXRlQ3VzdG9tZXJBcmVhRGF0YVxyXG4gICAgICApO1xyXG4gICAgICBzZXRTaG93TW9kYWxVcGRhdGUoZmFsc2UpO1xyXG4gICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcblxyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkN1c3RvbWVyIEFyZWEgVXBkYXRlZCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgQ3VzdG9tZXIgQXJlYTpcIiwgZXJyb3IpO1xyXG4gICAgICBpZiAoXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2UgJiZcclxuICAgICAgICBlcnJvci5yZXNwb25zZS5kYXRhICYmXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlXHJcbiAgICAgICkge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBgJHtlcnJvcj8ucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2V9YCxcclxuICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJBbiB1bmV4cGVjdGVkIGVycm9yIG9jY3VycmVkLiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e0dsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbiAgICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT5cclxuICAgICAgICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03IG92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOCBtaW4tdy1tYXhcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+Q3VzdG9tZXIgQXJlYTwvaDE+XHJcblxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC00IGJnLWJsdWUtOTUwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLWJsdWUtODAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgKyBBZGQgQ3VzdG9tZXIgQXJlYVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7dGFibGVDdXN0b21lckFyZWE/Lmxlbmd0aCA+IDAgJiYgIWlzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICBjYXRjaGVyPVwiX2lkXCJcclxuICAgICAgICAgICAgICAgIHVwZGF0ZUhhbmRsZXI9e2hhbmRsZVVwZGF0ZU1vZGFsT3Blbn1cclxuICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbih0YWJsZUN1c3RvbWVyQXJlYSwgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiQ3VzdG9tZXIgQXJlYVwiXHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiQ3VzdG9tZXIgQXJlYS5jc3ZcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgIGZhaWx1cmU9e3RhYmxlQ3VzdG9tZXJBcmVhLmxlbmd0aCA8PSAwfVxyXG4gICAgICAgICAgICAgICAgZGF0YT1cIiBDdXN0b21lciBBcmVhIERhdGFcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIEFkZCBDdXN0b21lciBBcmVhICovfVxyXG4gICAgICAgIDxNb2RhbCBpc1Zpc2libGU9e3Nob3dNb2RhbH0gb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsKGZhbHNlKX0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgQWRkIEN1c3RvbWVyIEFyZWFcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gbm9WYWxpZGF0ZT5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImFyZWFfbmFtZVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEN1c3RvbWVyIEFyZWEgTmFtZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJhcmVhX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VzdG9tZXJBcmVhRGF0YT8uYXJlYV9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBpZD1cImFyZWFfbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEN1c3RvbWVyIEFyZWEgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBQaW5jb2RlXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VzdG9tZXJBcmVhRGF0YT8ucGluY29kZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgaWQ9XCJwaW5jb2RlXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgUGluY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImFyZWFfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEFyZWEgVHlwZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgQXJlYSBUeXBlXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1c3RvbWVyQXJlYURhdGE/LmFyZWFfdHlwZSB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlQ2hhbmdlKHsgdGFyZ2V0OiB7IG5hbWU6IFwiYXJlYV90eXBlXCIsIHZhbHVlIH0gfSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICAgICAgICAgICAgb3B0aW9ucz17QVJFQV9UWVBFX09QVElPTlN9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcblxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGVzY3JpcHRpb25cIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBEZXNjcmlwdGlvblxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dC5UZXh0QXJlYVxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiZGVzY3JpcHRpb25cIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VzdG9tZXJBcmVhRGF0YT8uZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwiZGVzY3JpcHRpb25cIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIGEgRGVzY3JpcHRpb25cIlxyXG4gICAgICAgICAgICAgICAgICByb3dzPXszfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXgganVzdGlmeS1lbmRcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS80IHRleHQtd2hpdGUgYmctYmx1ZS03MDAgaG92ZXI6YmctYmx1ZS04MDAgYm9yZGVyLTIgYm9yZGVyLWJsYWNrXHJcbiAgICAgICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLWJsdWUtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFNhdmUgQ3VzdG9tZXIgQXJlYVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICAgIHsvKiBVcGRhdGUgQ3VzdG9tZXIgQXJlYSAqL31cclxuICAgICAgICA8TW9kYWxcclxuICAgICAgICAgIGlzVmlzaWJsZT17c2hvd01vZGFsVXBkYXRlfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgVXBkYXRlIEN1c3RvbWVyIEFyZWFcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVVwZGF0ZX0gbm9WYWxpZGF0ZT5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInVhcmVhX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBDdXN0b21lciBBcmVhIE5hbWVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiYXJlYV9uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUN1c3RvbWVyQXJlYURhdGE/LmFyZWFfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBpZD1cInVhcmVhX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBDdXN0b21lciBBcmVhIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJ1cGluY29kZVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFBpbmNvZGVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwicGluY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVDdXN0b21lckFyZWFEYXRhPy5waW5jb2RlfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwidXBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBQaW5jb2RlXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwidWFyZWFfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEFyZWEgVHlwZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgQXJlYSBUeXBlXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUN1c3RvbWVyQXJlYURhdGE/LmFyZWFfdHlwZSB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlSW5wdXRDaGFuZ2Uoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0OiB7IG5hbWU6IFwiYXJlYV90eXBlXCIsIHZhbHVlIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICAgICAgICAgICAgb3B0aW9ucz17QVJFQV9UWVBFX09QVElPTlN9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcblxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwidWRlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgRGVzY3JpcHRpb25cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXQuVGV4dEFyZWFcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cImRlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUN1c3RvbWVyQXJlYURhdGE/LmRlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwidWRlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBhIERlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgcm93cz17M31cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvNCB0ZXh0LXdoaXRlIGJnLWJsdWUtNzAwIGhvdmVyOmJnLWJsdWUtODAwIGJvcmRlci0yIGJvcmRlci1ibGFja1xyXG4gICAgICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBVcGRhdGVcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgICB7LyogRGVsZXRlIEN1c3RvbWVyIEFyZWEgKi99XHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbERlbGV0ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0Q3VycmVudEN1c3RvbWVyQXJlYShudWxsKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgIERlbGV0ZSBDdXN0b21lciBBcmVhXHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIHtjdXJyZW50Q3VzdG9tZXJBcmVhICYmIChcclxuICAgICAgICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgICAgICAgb25TdWJtaXQ9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICAgICAgaGFuZGxlRGVsZXRlQ3VzdG9tZXJBcmVhKCk7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3BhY2UteS02XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImFyZWFOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFBsZWFzZSBlbnRlcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnkgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudEN1c3RvbWVyQXJlYT8uYXJlYV9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgdG8gY29uZmlybSBkZWxldGlvbi5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiYXJlYU5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEN1c3RvbWVyIEFyZWEgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC13aGl0ZSBiZy1yZWQtNzAwIGhvdmVyOmJnLXJlZC04MDBcclxuICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuZXhwb3J0IGRlZmF1bHQgQ3VzdG9tZXJBcmVhOyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9DdXN0b21lckFyZWEuanN4In0=