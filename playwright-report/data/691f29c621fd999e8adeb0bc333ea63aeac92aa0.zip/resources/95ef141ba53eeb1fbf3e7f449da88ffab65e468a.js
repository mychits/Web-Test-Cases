import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Daybook.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import api from "/src/instance/TokenInstance.js";
import Modal from "/src/components/modals/Modal.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import {
  Select,
  Dropdown,
  Input,
  Tag,
  Card,
  Statistic,
  Row,
  Col,
  Empty,
  Typography,
  Divider,
  Spin
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
const { Text, Title } = Typography;
import Navbar from "/src/components/layouts/Navbar.jsx";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import {
  ArrowUpOutlined,
  ArrowDownOutlined,
  WalletOutlined,
  GlobalOutlined,
  LinkOutlined,
  SafetyCertificateOutlined,
  BankOutlined,
  CreditCardOutlined,
  ThunderboltOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import { FaIndianRupeeSign } from "/node_modules/.vite/deps/react-icons_fa6.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import filterOption from "/src/helpers/filterOption.js";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
const Daybook = () => {
  _s();
  const [groups, setGroups] = useState([]);
  const [TableDaybook, setTableDaybook] = useState([]);
  const [selectedAuctionGroupId, setSelectedAuctionGroupId] = useState("");
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [filteredAuction, setFilteredAuction] = useState([]);
  const todayString = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const [selectedDate, setSelectedDate] = useState(todayString);
  const [selectedFromDate, setSelectedFromDate] = useState(todayString);
  const [selectedToDate, setSelectedToDate] = useState(todayString);
  const [showFilterField, setShowFilterField] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedPaymentMode, setSelectedPaymentMode] = useState([]);
  const [selectedPaymentFor, setSelectedPaymentFor] = useState([]);
  const [selectedCustomers, setSelectedCustomers] = useState("");
  const [selectedAccountType, setSelectedAccountType] = useState("");
  const [collectionAgent, setCollectionAgent] = useState("");
  const [collectionAdmin, setCollectionAdmin] = useState("");
  const [agents, setAgents] = useState([]);
  const [admins, setAdmins] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [selectedLabel, setSelectedLabel] = useState("Today");
  const [showAllPaymentModes, setShowAllPaymentModes] = useState(false);
  const [selectedTransactionType, setSelectedTransactionType] = useState("All");
  const [totals, setTotals] = useState({ in: 0, out: 0, net: 0 });
  const [modeTotals, setModeTotals] = useState({
    cash: 0,
    online: 0,
    link: 0,
    autopay: 0
  });
  const [overviewLoading, setOverviewLoading] = useState(true);
  const [categoryLoading, setCategoryLoading] = useState(true);
  const [modeLoading, setModeLoading] = useState(true);
  const onGlobalSearchChangeHandler = (e) => setSearchText(e.target.value);
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (user?.admin_access_right_id?.access_permissions?.edit_payment) {
      setShowAllPaymentModes(
        user.admin_access_right_id.access_permissions.edit_payment === "true"
      );
    }
  }, []);
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [usersRes, groupsRes, agentsRes, adminsRes] = await Promise.all(
          [
            api.get("/user/get-user"),
            api.get("/group/get-group-admin"),
            api.get("/employee"),
            api.get("/admin/get-sub-admins")
          ]
        );
        setFilteredUsers(usersRes.data);
        setGroups(groupsRes.data);
        setAgents(
          agentsRes.data.employee.map((e) => ({
            ...e,
            full_name: e.name,
            selected_type: "agent_type"
          }))
        );
        setAdmins(
          adminsRes.data.map((a) => ({
            ...a,
            full_name: a.name,
            selected_type: "admin_type"
          }))
        );
      } catch (e) {
        console.error(e);
      }
    };
    fetchData();
  }, []);
  const groupOptions = [
    { value: "Today", label: "Today" },
    { value: "Yesterday", label: "Yesterday" },
    { value: "ThisMonth", label: "This Month" },
    { value: "LastMonth", label: "Last Month" },
    { value: "ThisYear", label: "This Year" },
    { value: "Custom", label: "Custom" }
  ];
  const handleSelectFilter = (value) => {
    setSelectedLabel(value);
    setShowFilterField(false);
    const today = /* @__PURE__ */ new Date();
    const formatDate = (date) => date.toLocaleDateString("en-CA");
    if (value === "Today") {
      const formatted = formatDate(today);
      setSelectedFromDate(formatted);
      setSelectedToDate(formatted);
    } else if (value === "Yesterday") {
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      const formatted = formatDate(yesterday);
      setSelectedFromDate(formatted);
      setSelectedToDate(formatted);
    } else if (value === "ThisMonth") {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      setSelectedFromDate(formatDate(start));
      setSelectedToDate(formatDate(end));
    } else if (value === "LastMonth") {
      const start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      const end = new Date(today.getFullYear(), today.getMonth(), 0);
      setSelectedFromDate(formatDate(start));
      setSelectedToDate(formatDate(end));
    } else if (value === "ThisYear") {
      const start = new Date(today.getFullYear(), 0, 1);
      const end = new Date(today.getFullYear(), 11, 31);
      setSelectedFromDate(formatDate(start));
      setSelectedToDate(formatDate(end));
    } else if (value === "Custom") {
      setShowFilterField(true);
    }
  };
  let paymentModes = [...selectedPaymentMode];
  if (paymentModes.includes("online") && !paymentModes.includes("cheque")) {
    paymentModes.push("cheque");
  }
  useEffect(
    () => {
      const abortController = new AbortController();
      const fetchPayments = async () => {
        try {
          setIsLoading(true);
          setOverviewLoading(true);
          setCategoryLoading(true);
          setModeLoading(true);
          const response = await api.get(`/payment/day-book`, {
            params: {
              from_date: selectedFromDate,
              to_date: selectedToDate,
              groupId: selectedAuctionGroupId,
              userId: selectedCustomers,
              // pay_type: selectedPaymentMode,
              pay_type: paymentModes,
              account_type: selectedAccountType,
              collected_by: collectionAgent,
              admin_type: collectionAdmin,
              pay_for: selectedPaymentFor
            },
            signal: abortController.signal
          });
          if (response.data) {
            let tin = 0, tout = 0;
            let cash = 0;
            let online = 0;
            let link = 0;
            let autopay = 0;
            const formattedData = response.data.map((item, index) => {
              const amt = Number(item.amount || 0);
              if (item.type === "IN") tin += amt;
              else
                tout += Math.abs(amt);
              return {
                _id: item._id,
                id: index + 1,
                type: /* @__PURE__ */ jsxDEV(Tag, { color: item?.type === "IN" ? "green" : "volcano", children: item?.type ?? "Unknown" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                  lineNumber: 233,
                  columnNumber: 15
                }, this),
                type_raw: item?.type,
                group: item?.group_id?.group_name || item?.pay_for || "N/A",
                name: item?.user_id?.full_name || "N/A",
                phoneNumber: item?.user_id?.phone_number || "N/A",
                // ticket: item?.ticket || "-",
                ticket: item?.loan?.loan_id ?? item?.pigme?.pigme_id ?? item?.ticket,
                receipt: item?.receipt_no || "-",
                amount: /* @__PURE__ */ jsxDEV(
                  "span",
                  {
                    className: item?.type === "IN" ? "text-green-600 font-bold" : "text-red-600 font-bold",
                    children: [
                      "₹ ",
                      Math.abs(amt).toLocaleString("en-IN")
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                    lineNumber: 246,
                    columnNumber: 15
                  },
                  this
                ),
                amount_raw: amt,
                pay_date: item.pay_date,
                category: item.pay_for ? item.pay_for : "Chit",
                transaction_date: item.createdAt?.split("T")?.[0],
                mode: item?.pay_type,
                account_type: item?.account_type,
                payment_type: item?.payment_type,
                collection_time: item?.collection_time,
                collected_by: item?.collected_by?.name || item?.admin_type?.admin_name || "Super Admin",
                action: /* @__PURE__ */ jsxDEV(
                  Link,
                  {
                    target: "_blank",
                    to: `/print/${item._id}`,
                    className: "text-blue-600",
                    children: "Print"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                    lineNumber: 269,
                    columnNumber: 15
                  },
                  this
                )
              };
            });
            let chit = 0, loan = 0, pigme = 0, registration = 0;
            response.data.forEach((item) => {
              if (item.type !== "IN") return;
              const amt = Number(item.amount || 0);
              const pf = (item.pay_for || "Chit").toLowerCase();
              if (pf.includes("loan")) loan += amt;
              else if (pf.includes("pigme")) pigme += amt;
              else if (pf.includes("reg")) registration += amt;
              else
                chit += amt;
            });
            response.data.forEach((item) => {
              const amt = Number(item.amount || 0);
              if (item.type !== "IN") return;
              const mode = (item.pay_type || "").toLowerCase();
              if (mode === "autopay" || mode === "online/autopay" || mode.includes("autopay")) {
                autopay += amt;
              } else if (mode === "cash") {
                cash += amt;
              } else if (mode === "online") {
                online += amt;
              } else if (mode.includes("link")) {
                link += amt;
              }
            });
            setCategoryTotals({
              chit,
              loan,
              pigme,
              registration
            });
            setTotals({ in: tin, out: tout, net: tin - tout });
            setModeTotals({
              cash,
              online,
              link,
              autopay
            });
            setFilteredAuction(response.data);
            const finalTable = selectedTransactionType === "All" ? formattedData : formattedData.filter(
              (i) => i?.category === selectedTransactionType
            );
            setTableDaybook(finalTable);
          }
        } catch (error) {
          setTableDaybook([]);
        } finally {
          setIsLoading(false);
          setOverviewLoading(false);
          setCategoryLoading(false);
          setModeLoading(false);
        }
      };
      fetchPayments();
      return () => abortController.abort();
    },
    [
      selectedAuctionGroupId,
      selectedToDate,
      selectedFromDate,
      selectedPaymentMode,
      selectedCustomers,
      selectedAccountType,
      collectionAgent,
      collectionAdmin,
      selectedPaymentFor,
      selectedTransactionType
    ]
  );
  const [categoryTotals, setCategoryTotals] = useState({
    chit: 0,
    loan: 0,
    pigme: 0,
    registration: 0
  });
  const columns = [
    { key: "id", header: "SL" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "payment_type", header: "Payment Type" },
    { key: "pay_date", header: "Payment Date" },
    {
      key: "type",
      header: "Type"
    },
    {
      key: "category",
      header: "Category"
    },
    { key: "group", header: "Group/Reason" },
    { key: "name", header: "Customer" },
    { key: "phoneNumber", header: "Phone Number" },
    { key: "ticket", header: "Ticket" },
    { key: "receipt", header: "Receipt" },
    {
      key: "amount",
      header: "Amount"
    },
    { key: "mode", header: "Mode" },
    { key: "collected_by", header: "Collected By" },
    { key: "collection_time", header: "Collection Time" },
    { key: "action", header: "Action" }
  ];
  const exportCols = [
    { key: "id", header: "SL" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "payment_type", header: "Payment Type" },
    { key: "pay_date", header: "Payment Date" },
    {
      key: "type_raw",
      header: "Type"
    },
    { key: "group", header: "Group/Reason" },
    { key: "name", header: "Customer" },
    { key: "phoneNumber", header: "Phone Number" },
    { key: "ticket", header: "Ticket" },
    { key: "receipt", header: "Receipt" },
    {
      key: "amount_raw",
      header: "Amount"
    },
    { key: "mode", header: "Mode" },
    {
      key: "category",
      header: "Category"
    },
    { key: "collected_by", header: "Collected By" },
    { key: "collection_time", header: "Collection Time" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "relative flex flex-col [height:calc(100vh-100px)] ", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
        lineNumber: 440,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-8 bg-slate-50 min-h-screen", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold text-slate-800", children: "Daybook Report" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
          lineNumber: 447,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-slate-500", children: "Comprehensive view of daily collections and disbursements" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
          lineNumber: 448,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
        lineNumber: 446,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-md border p-6 mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "Filter Option" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
            lineNumber: 467,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              showSearch: true,
              popupMatchSelectWidth: false,
              onChange: handleSelectFilter,
              value: selectedLabel,
              placeholder: "Search Or Select Filter",
              filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
              className: "w-full h-11",
              children: groupOptions.map(
                (time) => /* @__PURE__ */ jsxDEV(Select.Option, { value: time.value, children: time.label }, time.value, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                  lineNumber: 485,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
              lineNumber: 470,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
          lineNumber: 466,
          columnNumber: 13
        }, this),
        showFilterField && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "From Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
              lineNumber: 495,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                value: selectedFromDate,
                onChange: (e) => setSelectedFromDate(e.target.value),
                className: "w-full h-11 border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                lineNumber: 498,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
            lineNumber: 494,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "To Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
              lineNumber: 506,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                value: selectedToDate,
                onChange: (e) => setSelectedToDate(e.target.value),
                className: "w-full h-11 border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                lineNumber: 509,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
            lineNumber: 505,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
          lineNumber: 493,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-bold text-slate-500", children: "GROUP" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
            lineNumber: 520,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full h-10",
              showSearch: true,
              value: selectedAuctionGroupId,
              onChange: setSelectedAuctionGroupId,
              placeholder: "Select Group",
              filterOption: (input, option) => option?.children?.toString().toLowerCase().includes(input.toLowerCase()),
              children: [
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Groups" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                  lineNumber: 534,
                  columnNumber: 17
                }, this),
                groups.map(
                  (g) => /* @__PURE__ */ jsxDEV(Select.Option, { value: g._id, children: g.group_name }, g._id, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                    lineNumber: 536,
                    columnNumber: 17
                  }, this)
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
              lineNumber: 521,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
          lineNumber: 519,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-bold text-slate-500", children: "CUSTOMER" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
            lineNumber: 544,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full h-10",
              showSearch: true,
              value: selectedCustomers,
              onChange: setSelectedCustomers,
              placeholder: "Select Customer",
              filterOption: (input, option) => option?.children?.toString().toLowerCase().includes(input.toLowerCase()),
              children: [
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                  lineNumber: 560,
                  columnNumber: 17
                }, this),
                filteredUsers.map(
                  (u) => /* @__PURE__ */ jsxDEV(Select.Option, { value: u?._id, children: [
                    u?.full_name,
                    " - ",
                    u?.phone_number
                  ] }, u._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                    lineNumber: 562,
                    columnNumber: 17
                  }, this)
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
              lineNumber: 547,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
          lineNumber: 543,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-bold text-slate-500", children: "PAYMENT FOR" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
            lineNumber: 570,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              mode: "multiple",
              className: "w-full min-h-10",
              value: selectedPaymentFor,
              onChange: setSelectedPaymentFor,
              placeholder: "Chit, Loan, etc.",
              children: [
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "Chit", children: "Chit" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                  lineNumber: 580,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "Pigme", children: "Pigme" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                  lineNumber: 581,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "Loan", children: "Loan" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                  lineNumber: 582,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "Registration", children: "Registration Fee" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                  lineNumber: 583,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
              lineNumber: 573,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
          lineNumber: 569,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-bold text-slate-500", children: "PAYMENT MODE" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
            lineNumber: 590,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              mode: "multiple",
              className: "w-full min-h-10",
              value: selectedPaymentMode,
              onChange: setSelectedPaymentMode,
              options: [
                { label: "Cash", value: "cash" },
                { label: "Online", value: "online" },
                { label: "Online/Autopay", value: "online/autoPay" },
                { label: "Online/Payment Link", value: "Payment Link" },
                { label: "Cheque", value: "cheque" }
              ],
              placeholder: "Cash, Online, etc."
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
              lineNumber: 593,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
          lineNumber: 589,
          columnNumber: 13
        }, this),
        showAllPaymentModes && /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-bold text-slate-500", children: "ACCOUNT TYPE" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
            lineNumber: 611,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full h-10",
              value: selectedAccountType,
              onChange: setSelectedAccountType,
              options: [
                { label: "All", value: "" },
                { label: "Suspense", value: "suspense" },
                { label: "Credit", value: "credit" }
              ]
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
              lineNumber: 614,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
          lineNumber: 610,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-slate-700", children: "Collection Employee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
            lineNumber: 628,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              showSearch: true,
              placeholder: "Select employee",
              popupMatchSelectWidth: false,
              onChange: (selection) => {
                const [id, type] = selection.split("|") || [];
                if (type === "admin_type") {
                  setCollectionAdmin(id);
                  setCollectionAgent("");
                } else if (type === "agent_type") {
                  setCollectionAgent(id);
                  setCollectionAdmin("");
                } else {
                  setCollectionAdmin("");
                  setCollectionAgent("");
                }
              },
              filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
              className: "w-full",
              style: { height: "44px" },
              children: [
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Employees" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                  lineNumber: 657,
                  columnNumber: 17
                }, this),
                [...new Set(agents), ...new Set(admins)].map(
                  (dt) => /* @__PURE__ */ jsxDEV(
                    Select.Option,
                    {
                      value: `${dt._id}|${dt.selected_type}`,
                      children: [
                        dt.selected_type === "admin_type" ? "Admin | " : "Employee | ",
                        dt.full_name,
                        " | ",
                        dt.phone_number
                      ]
                    },
                    dt?._id,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                      lineNumber: 659,
                      columnNumber: 17
                    },
                    this
                  )
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
              lineNumber: 631,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
          lineNumber: 627,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
        lineNumber: 455,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
        lineNumber: 454,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-6 bg-gray-50 rounded-2xl", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
          /* @__PURE__ */ jsxDEV(Title, { level: 4, className: "!mb-4 text-gray-700", children: "Financial Overview" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
            lineNumber: 859,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Spin, { spinning: overviewLoading, size: "large", children: /* @__PURE__ */ jsxDEV(Row, { gutter: [20, 20], children: [
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, md: 12, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-md hover:shadow-lg transition-all duration-300 border-none rounded-xl bg-gradient-to-br from-white to-green-50/30 overflow-hidden relative", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 left-0 w-1.5 h-full bg-emerald-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                lineNumber: 866,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Statistic,
                {
                  title: /* @__PURE__ */ jsxDEV(
                    Text,
                    {
                      strong: true,
                      className: "text-gray-500 uppercase tracking-wider text-xs",
                      children: "Total IN (Collections)"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                      lineNumber: 869,
                      columnNumber: 23
                    },
                    this
                  ),
                  value: totals.in,
                  precision: 2,
                  prefix: /* @__PURE__ */ jsxDEV(ArrowUpOutlined, { className: "text-emerald-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                    lineNumber: 878,
                    columnNumber: 31
                  }, this),
                  valueStyle: {
                    color: "#065f46",
                    fontWeight: "700",
                    fontSize: "1.8rem"
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                  lineNumber: 867,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-2 py-1 px-2 bg-emerald-100/50 rounded inline-block", children: /* @__PURE__ */ jsxDEV(Text, { className: "text-xs font-medium text-emerald-800 italic", children: numberToIndianWords(totals.in || 0) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                lineNumber: 886,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                lineNumber: 885,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
              lineNumber: 865,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
              lineNumber: 864,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, md: 12, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-md hover:shadow-lg transition-all duration-300 border-none rounded-xl bg-gradient-to-br from-white to-red-50/30 overflow-hidden relative", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 left-0 w-1.5 h-full bg-rose-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                lineNumber: 894,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Statistic,
                {
                  title: /* @__PURE__ */ jsxDEV(
                    Text,
                    {
                      strong: true,
                      className: "text-gray-500 uppercase tracking-wider text-xs",
                      children: "Total OUT (Payouts)"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                      lineNumber: 897,
                      columnNumber: 23
                    },
                    this
                  ),
                  value: totals.out,
                  precision: 2,
                  prefix: /* @__PURE__ */ jsxDEV(ArrowDownOutlined, { className: "text-rose-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                    lineNumber: 906,
                    columnNumber: 31
                  }, this),
                  valueStyle: {
                    color: "#9f1239",
                    fontWeight: "700",
                    fontSize: "1.8rem"
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                  lineNumber: 895,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-2 py-1 px-2 bg-rose-100/50 rounded inline-block", children: /* @__PURE__ */ jsxDEV(Text, { className: "text-xs font-medium text-rose-800 italic", children: numberToIndianWords(totals.out || 0) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                lineNumber: 914,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                lineNumber: 913,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
              lineNumber: 893,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
              lineNumber: 892,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
            lineNumber: 863,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
            lineNumber: 862,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
          lineNumber: 858,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Divider, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
          lineNumber: 924,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
          /* @__PURE__ */ jsxDEV(Title, { level: 4, className: "!mb-4 text-gray-700", children: "Category Breakdown" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
            lineNumber: 928,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Spin, { spinning: categoryLoading, size: "large", children: /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], children: [
            {
              title: "Chit Collections",
              val: categoryTotals.chit,
              color: "#6366f1",
              bg: "indigo",
              icon: /* @__PURE__ */ jsxDEV(BankOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                lineNumber: 939,
                columnNumber: 25
              }, this)
            },
            {
              title: "Loan Collections",
              val: categoryTotals.loan,
              color: "#f59e0b",
              bg: "orange",
              icon: "₹"
            },
            {
              title: "Pigme Collections",
              val: categoryTotals.pigme,
              color: "#0d9488",
              bg: "teal",
              icon: /* @__PURE__ */ jsxDEV(WalletOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                lineNumber: 953,
                columnNumber: 25
              }, this)
            },
            {
              title: "Registration Fees",
              val: categoryTotals.registration,
              color: "#db2777",
              bg: "pink",
              icon: /* @__PURE__ */ jsxDEV(SafetyCertificateOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                lineNumber: 960,
                columnNumber: 25
              }, this)
            }
          ].map(
            (item, idx) => /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 6, children: /* @__PURE__ */ jsxDEV(
              Card,
              {
                size: "small",
                className: "hover:-translate-y-1 transition-transform duration-300 shadow-md border-gray-100 rounded-lg ",
                children: [
                  /* @__PURE__ */ jsxDEV(
                    Statistic,
                    {
                      title: /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400 font-medium", children: item.title }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                        lineNumber: 970,
                        columnNumber: 23
                      }, this),
                      value: item.val,
                      precision: 2,
                      prefix: /* @__PURE__ */ jsxDEV("span", { style: { color: item.color, marginRight: 4 }, children: item.icon }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                        lineNumber: 977,
                        columnNumber: 23
                      }, this),
                      valueStyle: {
                        color: item.color,
                        fontSize: "1.25rem",
                        fontWeight: "600"
                      }
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                      lineNumber: 968,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "mt-1", children: /* @__PURE__ */ jsxDEV(
                    Text,
                    {
                      type: "secondary",
                      className: "text-[10px] uppercase font-mono leading-none",
                      children: numberToIndianWords(item.val || 0)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                      lineNumber: 988,
                      columnNumber: 25
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                    lineNumber: 987,
                    columnNumber: 23
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                lineNumber: 964,
                columnNumber: 21
              },
              this
            ) }, idx, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
              lineNumber: 963,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
            lineNumber: 932,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
            lineNumber: 931,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
          lineNumber: 927,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
          /* @__PURE__ */ jsxDEV(Title, { level: 4, className: "!mb-4 text-gray-700", children: "Payment Modes" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
            lineNumber: 1005,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Spin, { spinning: modeLoading, size: "large", children: /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], children: [
            {
              title: "Cash",
              val: modeTotals.cash,
              color: "#16a34a",
              icon: /* @__PURE__ */ jsxDEV(WalletOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                lineNumber: 1017,
                columnNumber: 25
              }, this)
            },
            {
              title: "Online",
              val: modeTotals.online,
              color: "#2563eb",
              icon: /* @__PURE__ */ jsxDEV(GlobalOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                lineNumber: 1023,
                columnNumber: 25
              }, this)
            },
            {
              title: "Payment Link ",
              val: modeTotals.link,
              color: "#7c3aed",
              icon: /* @__PURE__ */ jsxDEV(LinkOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                lineNumber: 1029,
                columnNumber: 25
              }, this)
            },
            {
              title: "AutoPay",
              val: modeTotals.autopay,
              color: "#7c3aed",
              icon: /* @__PURE__ */ jsxDEV(ThunderboltOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                lineNumber: 1035,
                columnNumber: 25
              }, this)
            }
          ].map(
            (mode, idx) => /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, lg: 6, children: /* @__PURE__ */ jsxDEV(Card, { className: "bg-white border-none rounded-xl shadow-lg", children: [
              /* @__PURE__ */ jsxDEV(
                Statistic,
                {
                  title: /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: [
                    mode.title,
                    " Collection"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                    lineNumber: 1044,
                    columnNumber: 23
                  }, this),
                  value: mode.val,
                  precision: 2,
                  valueStyle: { color: "#000", fontWeight: "bold" },
                  prefix: /* @__PURE__ */ jsxDEV("span", { style: { color: mode.color }, children: mode.icon }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                    lineNumber: 1052,
                    columnNumber: 23
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                  lineNumber: 1042,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(Text, { className: "text-gray-900 text-[11px] font-mono italic", children: numberToIndianWords(mode.val || 0) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
                lineNumber: 1055,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
              lineNumber: 1041,
              columnNumber: 21
            }, this) }, idx, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
              lineNumber: 1039,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
            lineNumber: 1009,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
            lineNumber: 1008,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
          lineNumber: 1004,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
        lineNumber: 856,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-md border p-4 min-h-[450px]", children: isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center min-h-[350px]", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
        lineNumber: 1069,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
        lineNumber: 1068,
        columnNumber: 11
      }, this) : TableDaybook?.length <= 0 ? /* @__PURE__ */ jsxDEV(Empty, { description: "Daybook Data is not found" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
        lineNumber: 1072,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: filterOption(TableDaybook, searchText),
          columns,
          exportCols,
          exportedFileName: "Daybook",
          exportedPdfName: `Daybook`,
          printHeaderKeys: [
            "Total IN (Collections)",
            "Total OUT (Payouts)",
            "Chit Collections",
            "Loan Collections",
            "Pigme Collections",
            "Registration Fees",
            "Cash Collection",
            "Online Collection",
            "Payment Link",
            "AutoPay"
          ],
          printHeaderValues: [
            totals.in,
            totals.out,
            categoryTotals.chit,
            categoryTotals.loan,
            categoryTotals.pigme,
            categoryTotals.registration,
            modeTotals.cash,
            modeTotals.online,
            modeTotals.link,
            modeTotals.autopay
          ]
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
          lineNumber: 1074,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
        lineNumber: 1066,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
      lineNumber: 444,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx",
    lineNumber: 439,
    columnNumber: 5
  }, this);
};
_s(Daybook, "A4cbHCgcEihkzGbHFDMqD4sJmBA=");
_c = Daybook;
export default Daybook;
var _c;
$RefreshReg$(_c, "Daybook");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Daybook.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd09nQixTQW9RRixVQXBRRTsyQkF4T2hCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLG9CQUFvQjtBQUMzQjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxNQUFNLEVBQUVDLE1BQU1DLE1BQU0sSUFBSUo7QUFDeEIsT0FBT0ssWUFBWTtBQUNuQixTQUFTQyxnQkFBZ0I7QUFDekI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0MseUJBQXlCO0FBQ2xDLFNBQVNDLFlBQVk7QUFDckIsT0FBT0Msa0JBQWtCO0FBQ3pCLFNBQVNDLDJCQUEyQjtBQUVwQyxNQUFNQyxVQUFVQSxNQUFNO0FBQUFDLEtBQUE7QUFDcEIsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUlyQyxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDc0MsY0FBY0MsZUFBZSxJQUFJdkMsU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQ3dDLHdCQUF3QkMseUJBQXlCLElBQUl6QyxTQUFTLEVBQUU7QUFDdkUsUUFBTSxDQUFDMEMsZUFBZUMsZ0JBQWdCLElBQUkzQyxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDNEMsaUJBQWlCQyxrQkFBa0IsSUFBSTdDLFNBQVMsRUFBRTtBQUN6RCxRQUFNOEMsZUFBYyxvQkFBSUMsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDekQsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUluRCxTQUFTOEMsV0FBVztBQUM1RCxRQUFNLENBQUNNLGtCQUFrQkMsbUJBQW1CLElBQUlyRCxTQUFTOEMsV0FBVztBQUNwRSxRQUFNLENBQUNRLGdCQUFnQkMsaUJBQWlCLElBQUl2RCxTQUFTOEMsV0FBVztBQUVoRSxRQUFNLENBQUNVLGlCQUFpQkMsa0JBQWtCLElBQUl6RCxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDMEQsV0FBV0MsWUFBWSxJQUFJM0QsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzRELHFCQUFxQkMsc0JBQXNCLElBQUk3RCxTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDOEQsb0JBQW9CQyxxQkFBcUIsSUFBSS9ELFNBQVMsRUFBRTtBQUMvRCxRQUFNLENBQUNnRSxtQkFBbUJDLG9CQUFvQixJQUFJakUsU0FBUyxFQUFFO0FBQzdELFFBQU0sQ0FBQ2tFLHFCQUFxQkMsc0JBQXNCLElBQUluRSxTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDb0UsaUJBQWlCQyxrQkFBa0IsSUFBSXJFLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUNzRSxpQkFBaUJDLGtCQUFrQixJQUFJdkUsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ3dFLFFBQVFDLFNBQVMsSUFBSXpFLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUMwRSxRQUFRQyxTQUFTLElBQUkzRSxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDNEUsWUFBWUMsYUFBYSxJQUFJN0UsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQzhFLGVBQWVDLGdCQUFnQixJQUFJL0UsU0FBUyxPQUFPO0FBQzFELFFBQU0sQ0FBQ2dGLHFCQUFxQkMsc0JBQXNCLElBQUlqRixTQUFTLEtBQUs7QUFHcEUsUUFBTSxDQUFDa0YseUJBQXlCQywwQkFBMEIsSUFBSW5GLFNBQVMsS0FBSztBQUM1RSxRQUFNLENBQUNvRixRQUFRQyxTQUFTLElBQUlyRixTQUFTLEVBQUVzRixJQUFJLEdBQUdDLEtBQUssR0FBR0MsS0FBSyxFQUFFLENBQUM7QUFDOUQsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUkxRixTQUFTO0FBQUEsSUFDM0MyRixNQUFNO0FBQUEsSUFDTkMsUUFBUTtBQUFBLElBQ1JDLE1BQU07QUFBQSxJQUNOQyxTQUFTO0FBQUEsRUFDWCxDQUFDO0FBR0QsUUFBTSxDQUFDQyxpQkFBaUJDLGtCQUFrQixJQUFJaEcsU0FBUyxJQUFJO0FBQzNELFFBQU0sQ0FBQ2lHLGlCQUFpQkMsa0JBQWtCLElBQUlsRyxTQUFTLElBQUk7QUFDM0QsUUFBTSxDQUFDbUcsYUFBYUMsY0FBYyxJQUFJcEcsU0FBUyxJQUFJO0FBRW5ELFFBQU1xRyw4QkFBOEJBLENBQUNDLE1BQU16QixjQUFjeUIsRUFBRUMsT0FBT0MsS0FBSztBQUV2RXpHLFlBQVUsTUFBTTtBQUNkLFVBQU0wRyxPQUFPQyxLQUFLQyxNQUFNQyxhQUFhQyxRQUFRLE1BQU0sQ0FBQztBQUNwRCxRQUFJSixNQUFNSyx1QkFBdUJDLG9CQUFvQkMsY0FBYztBQUNqRS9CO0FBQUFBLFFBQ0V3QixLQUFLSyxzQkFBc0JDLG1CQUFtQkMsaUJBQWlCO0FBQUEsTUFDakU7QUFBQSxJQUNGO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTGpILFlBQVUsTUFBTTtBQUNkLFVBQU1rSCxZQUFZLFlBQVk7QUFDNUIsVUFBSTtBQUNGLGNBQU0sQ0FBQ0MsVUFBVUMsV0FBV0MsV0FBV0MsU0FBUyxJQUFJLE1BQU1DLFFBQVFDO0FBQUFBLFVBQUk7QUFBQSxZQUNwRXRILElBQUl1SCxJQUFJLGdCQUFnQjtBQUFBLFlBQ3hCdkgsSUFBSXVILElBQUksd0JBQXdCO0FBQUEsWUFDaEN2SCxJQUFJdUgsSUFBSSxXQUFXO0FBQUEsWUFDbkJ2SCxJQUFJdUgsSUFBSSx1QkFBdUI7QUFBQSxVQUFDO0FBQUEsUUFDakM7QUFDRDdFLHlCQUFpQnVFLFNBQVNPLElBQUk7QUFDOUJwRixrQkFBVThFLFVBQVVNLElBQUk7QUFDeEJoRDtBQUFBQSxVQUNFMkMsVUFBVUssS0FBS0MsU0FBU0MsSUFBSSxDQUFDckIsT0FBTztBQUFBLFlBQ2xDLEdBQUdBO0FBQUFBLFlBQ0hzQixXQUFXdEIsRUFBRXVCO0FBQUFBLFlBQ2JDLGVBQWU7QUFBQSxVQUNqQixFQUFFO0FBQUEsUUFDSjtBQUNBbkQ7QUFBQUEsVUFDRTBDLFVBQVVJLEtBQUtFLElBQUksQ0FBQ0ksT0FBTztBQUFBLFlBQ3pCLEdBQUdBO0FBQUFBLFlBQ0hILFdBQVdHLEVBQUVGO0FBQUFBLFlBQ2JDLGVBQWU7QUFBQSxVQUNqQixFQUFFO0FBQUEsUUFDSjtBQUFBLE1BQ0YsU0FBU3hCLEdBQUc7QUFDVjBCLGdCQUFRQyxNQUFNM0IsQ0FBQztBQUFBLE1BQ2pCO0FBQUEsSUFDRjtBQUNBVyxjQUFVO0FBQUEsRUFDWixHQUFHLEVBQUU7QUFjTCxRQUFNaUIsZUFBZTtBQUFBLElBQ25CLEVBQUUxQixPQUFPLFNBQVMyQixPQUFPLFFBQVE7QUFBQSxJQUNqQyxFQUFFM0IsT0FBTyxhQUFhMkIsT0FBTyxZQUFZO0FBQUEsSUFDekMsRUFBRTNCLE9BQU8sYUFBYTJCLE9BQU8sYUFBYTtBQUFBLElBQzFDLEVBQUUzQixPQUFPLGFBQWEyQixPQUFPLGFBQWE7QUFBQSxJQUMxQyxFQUFFM0IsT0FBTyxZQUFZMkIsT0FBTyxZQUFZO0FBQUEsSUFDeEMsRUFBRTNCLE9BQU8sVUFBVTJCLE9BQU8sU0FBUztBQUFBLEVBQUM7QUFHdEMsUUFBTUMscUJBQXFCQSxDQUFDNUIsVUFBVTtBQUNwQ3pCLHFCQUFpQnlCLEtBQUs7QUFFdEIvQyx1QkFBbUIsS0FBSztBQUV4QixVQUFNNEUsUUFBUSxvQkFBSXRGLEtBQUs7QUFDdkIsVUFBTXVGLGFBQWFBLENBQUNDLFNBQVNBLEtBQUtDLG1CQUFtQixPQUFPO0FBRTVELFFBQUloQyxVQUFVLFNBQVM7QUFDckIsWUFBTWlDLFlBQVlILFdBQVdELEtBQUs7QUFDbENoRiwwQkFBb0JvRixTQUFTO0FBQzdCbEYsd0JBQWtCa0YsU0FBUztBQUFBLElBQzdCLFdBQVdqQyxVQUFVLGFBQWE7QUFDaEMsWUFBTWtDLFlBQVksSUFBSTNGLEtBQUtzRixLQUFLO0FBQ2hDSyxnQkFBVUMsUUFBUUQsVUFBVUUsUUFBUSxJQUFJLENBQUM7QUFDekMsWUFBTUgsWUFBWUgsV0FBV0ksU0FBUztBQUN0Q3JGLDBCQUFvQm9GLFNBQVM7QUFDN0JsRix3QkFBa0JrRixTQUFTO0FBQUEsSUFDN0IsV0FBV2pDLFVBQVUsYUFBYTtBQUNoQyxZQUFNcUMsUUFBUSxJQUFJOUYsS0FBS3NGLE1BQU1TLFlBQVksR0FBR1QsTUFBTVUsU0FBUyxHQUFHLENBQUM7QUFDL0QsWUFBTUMsTUFBTSxJQUFJakcsS0FBS3NGLE1BQU1TLFlBQVksR0FBR1QsTUFBTVUsU0FBUyxJQUFJLEdBQUcsQ0FBQztBQUNqRTFGLDBCQUFvQmlGLFdBQVdPLEtBQUssQ0FBQztBQUNyQ3RGLHdCQUFrQitFLFdBQVdVLEdBQUcsQ0FBQztBQUFBLElBQ25DLFdBQVd4QyxVQUFVLGFBQWE7QUFDaEMsWUFBTXFDLFFBQVEsSUFBSTlGLEtBQUtzRixNQUFNUyxZQUFZLEdBQUdULE1BQU1VLFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDbkUsWUFBTUMsTUFBTSxJQUFJakcsS0FBS3NGLE1BQU1TLFlBQVksR0FBR1QsTUFBTVUsU0FBUyxHQUFHLENBQUM7QUFDN0QxRiwwQkFBb0JpRixXQUFXTyxLQUFLLENBQUM7QUFDckN0Rix3QkFBa0IrRSxXQUFXVSxHQUFHLENBQUM7QUFBQSxJQUNuQyxXQUFXeEMsVUFBVSxZQUFZO0FBQy9CLFlBQU1xQyxRQUFRLElBQUk5RixLQUFLc0YsTUFBTVMsWUFBWSxHQUFHLEdBQUcsQ0FBQztBQUNoRCxZQUFNRSxNQUFNLElBQUlqRyxLQUFLc0YsTUFBTVMsWUFBWSxHQUFHLElBQUksRUFBRTtBQUNoRHpGLDBCQUFvQmlGLFdBQVdPLEtBQUssQ0FBQztBQUNyQ3RGLHdCQUFrQitFLFdBQVdVLEdBQUcsQ0FBQztBQUFBLElBQ25DLFdBQVd4QyxVQUFVLFVBQVU7QUFDN0IvQyx5QkFBbUIsSUFBSTtBQUFBLElBQ3pCO0FBQUEsRUFDRjtBQUVBLE1BQUl3RixlQUFlLENBQUMsR0FBR3JGLG1CQUFtQjtBQUUxQyxNQUNFcUYsYUFBYUMsU0FBUyxRQUFRLEtBQzlCLENBQUNELGFBQWFDLFNBQVMsUUFBUSxHQUMvQjtBQUNBRCxpQkFBYUUsS0FBSyxRQUFRO0FBQUEsRUFDNUI7QUFFQXBKO0FBQUFBLElBQVUsTUFBTTtBQUNkLFlBQU1xSixrQkFBa0IsSUFBSUMsZ0JBQWdCO0FBQzVDLFlBQU1DLGdCQUFnQixZQUFZO0FBQ2hDLFlBQUk7QUFDRjNGLHVCQUFhLElBQUk7QUFDakJxQyw2QkFBbUIsSUFBSTtBQUN2QkUsNkJBQW1CLElBQUk7QUFDdkJFLHlCQUFlLElBQUk7QUFDbkIsZ0JBQU1tRCxXQUFXLE1BQU10SixJQUFJdUgsSUFBSSxxQkFBcUI7QUFBQSxZQUNsRGdDLFFBQVE7QUFBQSxjQUNOQyxXQUFXckc7QUFBQUEsY0FDWHNHLFNBQVNwRztBQUFBQSxjQUNUcUcsU0FBU25IO0FBQUFBLGNBQ1RvSCxRQUFRNUY7QUFBQUE7QUFBQUEsY0FFUjZGLFVBQVVaO0FBQUFBLGNBQ1ZhLGNBQWM1RjtBQUFBQSxjQUNkNkYsY0FBYzNGO0FBQUFBLGNBQ2Q0RixZQUFZMUY7QUFBQUEsY0FDWjJGLFNBQVNuRztBQUFBQSxZQUNYO0FBQUEsWUFDQW9HLFFBQVFkLGdCQUFnQmM7QUFBQUEsVUFDMUIsQ0FBQztBQUVELGNBQUlYLFNBQVM5QixNQUFNO0FBQ2pCLGdCQUFJMEMsTUFBTSxHQUNSQyxPQUFPO0FBRVQsZ0JBQUl6RSxPQUFPO0FBQ1gsZ0JBQUlDLFNBQVM7QUFDYixnQkFBSUMsT0FBTztBQUNYLGdCQUFJQyxVQUFVO0FBRWQsa0JBQU11RSxnQkFBZ0JkLFNBQVM5QixLQUFLRSxJQUFJLENBQUMyQyxNQUFNQyxVQUFVO0FBQ3ZELG9CQUFNQyxNQUFNQyxPQUFPSCxLQUFLSSxVQUFVLENBQUM7QUFDbkMsa0JBQUlKLEtBQUtLLFNBQVMsS0FBTVIsUUFBT0s7QUFBQUE7QUFDMUJKLHdCQUFRUSxLQUFLQyxJQUFJTCxHQUFHO0FBRXpCLHFCQUFPO0FBQUEsZ0JBQ0xNLEtBQUtSLEtBQUtRO0FBQUFBLGdCQUNWQyxJQUFJUixRQUFRO0FBQUEsZ0JBQ1pJLE1BQ0UsdUJBQUMsT0FBSSxPQUFPTCxNQUFNSyxTQUFTLE9BQU8sVUFBVSxXQUN6Q0wsZ0JBQU1LLFFBQVEsYUFEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVGSyxVQUFVVixNQUFNSztBQUFBQSxnQkFDaEJNLE9BQU9YLE1BQU1ZLFVBQVVDLGNBQWNiLE1BQU1MLFdBQVc7QUFBQSxnQkFDdERwQyxNQUFNeUMsTUFBTWMsU0FBU3hELGFBQWE7QUFBQSxnQkFDbEN5RCxhQUFhZixNQUFNYyxTQUFTRSxnQkFBZ0I7QUFBQTtBQUFBLGdCQUU1Q0MsUUFDRWpCLE1BQU1rQixNQUFNQyxXQUFXbkIsTUFBTW9CLE9BQU9DLFlBQVlyQixNQUFNaUI7QUFBQUEsZ0JBQ3hESyxTQUFTdEIsTUFBTXVCLGNBQWM7QUFBQSxnQkFDN0JuQixRQUNFO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQ0VKLE1BQU1LLFNBQVMsT0FDWCw2QkFDQTtBQUFBLG9CQUNMO0FBQUE7QUFBQSxzQkFFRUMsS0FBS0MsSUFBSUwsR0FBRyxFQUFFc0IsZUFBZSxPQUFPO0FBQUE7QUFBQTtBQUFBLGtCQVB6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUUE7QUFBQSxnQkFFRkMsWUFBWXZCO0FBQUFBLGdCQUNad0IsVUFBVTFCLEtBQUswQjtBQUFBQSxnQkFDZkMsVUFBVTNCLEtBQUtMLFVBQVVLLEtBQUtMLFVBQVU7QUFBQSxnQkFDeENpQyxrQkFBa0I1QixLQUFLNkIsV0FBV2xKLE1BQU0sR0FBRyxJQUFJLENBQUM7QUFBQSxnQkFDaERtSixNQUFNOUIsTUFBTVQ7QUFBQUEsZ0JBQ1pDLGNBQWNRLE1BQU1SO0FBQUFBLGdCQUNwQnVDLGNBQWMvQixNQUFNK0I7QUFBQUEsZ0JBQ3BCQyxpQkFBaUJoQyxNQUFNZ0M7QUFBQUEsZ0JBQ3ZCdkMsY0FDRU8sTUFBTVAsY0FBY2xDLFFBQ3BCeUMsTUFBTU4sWUFBWXVDLGNBQ2xCO0FBQUEsZ0JBQ0ZDLFFBQ0U7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsUUFBTztBQUFBLG9CQUNQLElBQUksVUFBVWxDLEtBQUtRLEdBQUc7QUFBQSxvQkFDdEIsV0FBVTtBQUFBLG9CQUFlO0FBQUE7QUFBQSxrQkFIM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsY0FFSjtBQUFBLFlBQ0YsQ0FBQztBQUVELGdCQUFJMkIsT0FBTyxHQUNUakIsT0FBTyxHQUNQRSxRQUFRLEdBQ1JnQixlQUFlO0FBRWpCbkQscUJBQVM5QixLQUFLa0YsUUFBUSxDQUFDckMsU0FBUztBQUM5QixrQkFBSUEsS0FBS0ssU0FBUyxLQUFNO0FBRXhCLG9CQUFNSCxNQUFNQyxPQUFPSCxLQUFLSSxVQUFVLENBQUM7QUFDbkMsb0JBQU1rQyxNQUFNdEMsS0FBS0wsV0FBVyxRQUFRNEMsWUFBWTtBQUVoRCxrQkFBSUQsR0FBRzFELFNBQVMsTUFBTSxFQUFHc0MsU0FBUWhCO0FBQUFBLHVCQUN4Qm9DLEdBQUcxRCxTQUFTLE9BQU8sRUFBR3dDLFVBQVNsQjtBQUFBQSx1QkFDL0JvQyxHQUFHMUQsU0FBUyxLQUFLLEVBQUd3RCxpQkFBZ0JsQztBQUFBQTtBQUN4Q2lDLHdCQUFRakM7QUFBQUEsWUFDZixDQUFDO0FBRURqQixxQkFBUzlCLEtBQUtrRixRQUFRLENBQUNyQyxTQUFTO0FBQzlCLG9CQUFNRSxNQUFNQyxPQUFPSCxLQUFLSSxVQUFVLENBQUM7QUFFbkMsa0JBQUlKLEtBQUtLLFNBQVMsS0FBTTtBQUV4QixvQkFBTXlCLFFBQVE5QixLQUFLVCxZQUFZLElBQUlnRCxZQUFZO0FBRS9DLGtCQUFJVCxTQUFTLGFBQWFBLFNBQVMsb0JBQW9CQSxLQUFLbEQsU0FBUyxTQUFTLEdBQUc7QUFDL0VwRCwyQkFBVzBFO0FBQUFBLGNBQ2IsV0FDUzRCLFNBQVMsUUFBUTtBQUN4QnpHLHdCQUFRNkU7QUFBQUEsY0FDVixXQUNTNEIsU0FBUyxVQUFVO0FBQzFCeEcsMEJBQVU0RTtBQUFBQSxjQUNaLFdBQ1M0QixLQUFLbEQsU0FBUyxNQUFNLEdBQUc7QUFDOUJyRCx3QkFBUTJFO0FBQUFBLGNBQ1Y7QUFBQSxZQUNGLENBQUM7QUFVRHNDLDhCQUFrQjtBQUFBLGNBQ2hCTDtBQUFBQSxjQUNBakI7QUFBQUEsY0FDQUU7QUFBQUEsY0FDQWdCO0FBQUFBLFlBQ0YsQ0FBQztBQUVEckgsc0JBQVUsRUFBRUMsSUFBSTZFLEtBQUs1RSxLQUFLNkUsTUFBTTVFLEtBQUsyRSxNQUFNQyxLQUFLLENBQUM7QUFDakQxRSwwQkFBYztBQUFBLGNBQ1pDO0FBQUFBLGNBQ0FDO0FBQUFBLGNBQ0FDO0FBQUFBLGNBQ0FDO0FBQUFBLFlBQ0YsQ0FBQztBQUNEakQsK0JBQW1CMEcsU0FBUzlCLElBQUk7QUFHaEMsa0JBQU1zRixhQUNKN0gsNEJBQTRCLFFBQ3hCbUYsZ0JBQ0FBLGNBQWMyQztBQUFBQSxjQUNkLENBQUNDLE1BQU1BLEdBQUdoQixhQUFhL0c7QUFBQUEsWUFDekI7QUFFSjNDLDRCQUFnQndLLFVBQVU7QUFBQSxVQUM1QjtBQUFBLFFBQ0YsU0FBUzlFLE9BQU87QUFDZDFGLDBCQUFnQixFQUFFO0FBQUEsUUFDcEIsVUFBQztBQUNDb0IsdUJBQWEsS0FBSztBQUNsQnFDLDZCQUFtQixLQUFLO0FBQ3hCRSw2QkFBbUIsS0FBSztBQUN4QkUseUJBQWUsS0FBSztBQUFBLFFBQ3RCO0FBQUEsTUFDRjtBQUVBa0Qsb0JBQWM7QUFDZCxhQUFPLE1BQU1GLGdCQUFnQjhELE1BQU07QUFBQSxJQUNyQztBQUFBLElBQUc7QUFBQSxNQUNEMUs7QUFBQUEsTUFDQWM7QUFBQUEsTUFDQUY7QUFBQUEsTUFDQVE7QUFBQUEsTUFDQUk7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQVI7QUFBQUEsTUFDQW9CO0FBQUFBLElBQXVCO0FBQUEsRUFDeEI7QUFFRCxRQUFNLENBQUNpSSxnQkFBZ0JMLGlCQUFpQixJQUFJOU0sU0FBUztBQUFBLElBQ25EeU0sTUFBTTtBQUFBLElBQ05qQixNQUFNO0FBQUEsSUFDTkUsT0FBTztBQUFBLElBQ1BnQixjQUFjO0FBQUEsRUFDaEIsQ0FBQztBQUVELFFBQU1VLFVBQVU7QUFBQSxJQUNkLEVBQUVDLEtBQUssTUFBTUMsUUFBUSxLQUFLO0FBQUEsSUFDMUIsRUFBRUQsS0FBSyxvQkFBb0JDLFFBQVEsbUJBQW1CO0FBQUEsSUFDdEQsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVELEtBQUssWUFBWUMsUUFBUSxlQUFlO0FBQUEsSUFDMUM7QUFBQSxNQUNFRCxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBO0FBQUEsTUFDRUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQSxFQUFFRCxLQUFLLFNBQVNDLFFBQVEsZUFBZTtBQUFBLElBQ3ZDLEVBQUVELEtBQUssUUFBUUMsUUFBUSxXQUFXO0FBQUEsSUFDbEMsRUFBRUQsS0FBSyxlQUFlQyxRQUFRLGVBQWU7QUFBQSxJQUM3QyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVELEtBQUssV0FBV0MsUUFBUSxVQUFVO0FBQUEsSUFDcEM7QUFBQSxNQUNFRCxLQUFLO0FBQUEsTUFDTEMsUUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBLEVBQUVELEtBQUssUUFBUUMsUUFBUSxPQUFPO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVELEtBQUssbUJBQW1CQyxRQUFRLGtCQUFrQjtBQUFBLElBQ3BELEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUVyQyxRQUFNQyxhQUFhO0FBQUEsSUFDakIsRUFBRUYsS0FBSyxNQUFNQyxRQUFRLEtBQUs7QUFBQSxJQUMxQixFQUFFRCxLQUFLLG9CQUFvQkMsUUFBUSxtQkFBbUI7QUFBQSxJQUN0RCxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRUQsS0FBSyxZQUFZQyxRQUFRLGVBQWU7QUFBQSxJQUMxQztBQUFBLE1BQ0VELEtBQUs7QUFBQSxNQUNMQyxRQUFRO0FBQUEsSUFDVjtBQUFBLElBQ0EsRUFBRUQsS0FBSyxTQUFTQyxRQUFRLGVBQWU7QUFBQSxJQUN2QyxFQUFFRCxLQUFLLFFBQVFDLFFBQVEsV0FBVztBQUFBLElBQ2xDLEVBQUVELEtBQUssZUFBZUMsUUFBUSxlQUFlO0FBQUEsSUFDN0MsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFRCxLQUFLLFdBQVdDLFFBQVEsVUFBVTtBQUFBLElBQ3BDO0FBQUEsTUFDRUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQSxFQUFFRCxLQUFLLFFBQVFDLFFBQVEsT0FBTztBQUFBLElBQzlCO0FBQUEsTUFDRUQsS0FBSztBQUFBLE1BQ0xDLFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQSxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRUQsS0FBSyxtQkFBbUJDLFFBQVEsa0JBQWtCO0FBQUEsRUFBQztBQUd2RCxTQUNFLHVCQUFDLFNBQUksV0FBVSxzREFDYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsWUFBWTtBQUFBO0FBQUEsTUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFbUI7QUFBQSxJQUVuQix1QkFBQyxTQUFJLFdBQVUsMENBRWI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxxQ0FBb0MsOEJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0U7QUFBQSxRQUNoRSx1QkFBQyxPQUFFLFdBQVUsa0JBQWlCLHlFQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLGlEQUNiLGlDQUFDLFNBQUksV0FBVSx3REFXYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDJDQUEwQyw2QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDO0FBQUEsY0FDQSx1QkFBdUI7QUFBQSxjQUN2QixVQUFVbEY7QUFBQUEsY0FDVixPQUFPdEQ7QUFBQUEsY0FDUCxhQUFZO0FBQUEsY0FDWixjQUFjLENBQUMwSSxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUZCxZQUFZLEVBQ1ozRCxTQUFTc0UsTUFBTVgsWUFBWSxDQUFDO0FBQUEsY0FFakMsV0FBVTtBQUFBLGNBRVQzRSx1QkFBYVA7QUFBQUEsZ0JBQUksQ0FBQ2lHLFNBQ2pCLHVCQUFDLE9BQU8sUUFBUCxFQUErQixPQUFPQSxLQUFLcEgsT0FDekNvSCxlQUFLekYsU0FEWXlGLEtBQUtwSCxPQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRDtBQUFBO0FBQUEsWUFsQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBbUJBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBRUNoRCxtQkFDQyxtQ0FDRTtBQUFBLGlDQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDJDQUEwQyx5QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT0o7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDa0QsTUFBTWpELG9CQUFvQmlELEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxnQkFDbkQsV0FBVTtBQUFBO0FBQUEsY0FKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJNko7QUFBQSxlQVIvSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSwyQ0FBMEMsdUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU9sRDtBQUFBQSxnQkFDUCxVQUFVLENBQUNnRCxNQUFNL0Msa0JBQWtCK0MsRUFBRUMsT0FBT0MsS0FBSztBQUFBLGdCQUNqRCxXQUFVO0FBQUE7QUFBQSxjQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUk2SjtBQUFBLGVBUi9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxhQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUJBO0FBQUEsUUFHRix1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxvQ0FBbUMscUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlEO0FBQUEsVUFDekQ7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWO0FBQUEsY0FDQSxPQUFPaEU7QUFBQUEsY0FDUCxVQUFVQztBQUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaLGNBQWMsQ0FBQytLLE9BQU9DLFdBQ3BCQSxRQUFRQyxVQUNKQyxTQUFTLEVBQ1ZkLFlBQVksRUFDWjNELFNBQVNzRSxNQUFNWCxZQUFZLENBQUM7QUFBQSxjQUdqQztBQUFBLHVDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRywwQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0M7QUFBQSxnQkFDakN6SyxPQUFPdUY7QUFBQUEsa0JBQUksQ0FBQ2tHLE1BQ1gsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU9BLEVBQUUvQyxLQUNqQytDLFlBQUUxQyxjQURlMEMsRUFBRS9DLEtBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDRDtBQUFBO0FBQUE7QUFBQSxZQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFtQkE7QUFBQSxhQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxvQ0FBbUMsd0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVjtBQUFBLGNBQ0EsT0FBTzlHO0FBQUFBLGNBQ1AsVUFBVUM7QUFBQUEsY0FDVixhQUFZO0FBQUEsY0FDWixjQUFjLENBQUN1SixPQUFPQyxXQUNwQkEsUUFBUUMsVUFDSkMsU0FBUyxFQUNWZCxZQUFZLEVBQ1ozRCxTQUFTc0UsTUFBTVgsWUFBWSxDQUFDO0FBQUEsY0FHakM7QUFBQSx1Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsNkJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFDO0FBQUEsZ0JBQ3BDbkssY0FBY2lGO0FBQUFBLGtCQUFJLENBQUNtRyxNQUNsQix1QkFBQyxPQUFPLFFBQVAsRUFBMEIsT0FBT0EsR0FBR2hELEtBQ2xDZ0Q7QUFBQUEsdUJBQUdsRztBQUFBQSxvQkFBVTtBQUFBLG9CQUFJa0csR0FBR3hDO0FBQUFBLHVCQURId0MsRUFBRWhELEtBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDRDtBQUFBO0FBQUE7QUFBQSxZQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFtQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxvQ0FBbUMsMkJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixPQUFPaEg7QUFBQUEsY0FDUCxVQUFVQztBQUFBQSxjQUNWLGFBQVk7QUFBQSxjQUVaO0FBQUEsdUNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxRQUFPLG9CQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLGdCQUNoQyx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFNBQVEscUJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtDO0FBQUEsZ0JBQ2xDLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sUUFBTyxvQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxnQkFDaEMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxnQkFBZSxnQ0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBO0FBQUE7QUFBQSxZQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWFBO0FBQUEsYUFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsb0NBQW1DLDRCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsT0FBT0g7QUFBQUEsY0FDUCxVQUFVQztBQUFBQSxjQUNWLFNBQVM7QUFBQSxnQkFDUCxFQUFFc0UsT0FBTyxRQUFRM0IsT0FBTyxPQUFPO0FBQUEsZ0JBQy9CLEVBQUUyQixPQUFPLFVBQVUzQixPQUFPLFNBQVM7QUFBQSxnQkFDbkMsRUFBRTJCLE9BQU8sa0JBQWtCM0IsT0FBTyxpQkFBaUI7QUFBQSxnQkFDbkQsRUFBRTJCLE9BQU8sdUJBQXVCM0IsT0FBTyxlQUFlO0FBQUEsZ0JBQ3RELEVBQUUyQixPQUFPLFVBQVUzQixPQUFPLFNBQVM7QUFBQSxjQUFDO0FBQUEsY0FFdEMsYUFBWTtBQUFBO0FBQUEsWUFaZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFZa0M7QUFBQSxhQWhCcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtCQTtBQUFBLFFBRUN4Qix1QkFDQyx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxvQ0FBbUMsNEJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixPQUFPZDtBQUFBQSxjQUNQLFVBQVVDO0FBQUFBLGNBQ1YsU0FBUztBQUFBLGdCQUNQLEVBQUVnRSxPQUFPLE9BQU8zQixPQUFPLEdBQUc7QUFBQSxnQkFDMUIsRUFBRTJCLE9BQU8sWUFBWTNCLE9BQU8sV0FBVztBQUFBLGdCQUN2QyxFQUFFMkIsT0FBTyxVQUFVM0IsT0FBTyxTQUFTO0FBQUEsY0FBQztBQUFBO0FBQUEsWUFQeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUk7QUFBQSxhQVpOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFFBR0YsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsNENBQTJDLG1DQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0M7QUFBQSxjQUNBLGFBQVk7QUFBQSxjQUNaLHVCQUF1QjtBQUFBLGNBQ3ZCLFVBQVUsQ0FBQ3VILGNBQWM7QUFDdkIsc0JBQU0sQ0FBQ2hELElBQUlKLElBQUksSUFBSW9ELFVBQVU5SyxNQUFNLEdBQUcsS0FBSztBQUMzQyxvQkFBSTBILFNBQVMsY0FBYztBQUN6QnBHLHFDQUFtQndHLEVBQUU7QUFDckIxRyxxQ0FBbUIsRUFBRTtBQUFBLGdCQUN2QixXQUFXc0csU0FBUyxjQUFjO0FBQ2hDdEcscUNBQW1CMEcsRUFBRTtBQUNyQnhHLHFDQUFtQixFQUFFO0FBQUEsZ0JBQ3ZCLE9BQU87QUFDTEEscUNBQW1CLEVBQUU7QUFDckJGLHFDQUFtQixFQUFFO0FBQUEsZ0JBQ3ZCO0FBQUEsY0FDRjtBQUFBLGNBQ0EsY0FBYyxDQUFDbUosT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pDLFNBQVMsRUFDVGQsWUFBWSxFQUNaM0QsU0FBU3NFLE1BQU1YLFlBQVksQ0FBQztBQUFBLGNBRWpDLFdBQVU7QUFBQSxjQUNWLE9BQU8sRUFBRW1CLFFBQVEsT0FBTztBQUFBLGNBRXhCO0FBQUEsdUNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxJQUFHLDZCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxQztBQUFBLGdCQUNwQyxDQUFDLEdBQUcsSUFBSUMsSUFBSXpKLE1BQU0sR0FBRyxHQUFHLElBQUl5SixJQUFJdkosTUFBTSxDQUFDLEVBQUVpRDtBQUFBQSxrQkFBSSxDQUFDdUcsT0FDN0M7QUFBQSxvQkFBQyxPQUFPO0FBQUEsb0JBQVA7QUFBQSxzQkFFQyxPQUFPLEdBQUdBLEdBQUdwRCxHQUFHLElBQUlvRCxHQUFHcEcsYUFBYTtBQUFBLHNCQUVuQ29HO0FBQUFBLDJCQUFHcEcsa0JBQWtCLGVBQ2xCLGFBQ0E7QUFBQSx3QkFDSG9HLEdBQUd0RztBQUFBQSx3QkFBVTtBQUFBLHdCQUFJc0csR0FBRzVDO0FBQUFBO0FBQUFBO0FBQUFBLG9CQU5oQjRDLElBQUlwRDtBQUFBQSxvQkFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVFBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBO0FBQUEsWUFyQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBc0NBO0FBQUEsYUExQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJDQTtBQUFBLFdBdk5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzT0EsS0F2T0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdPQTtBQUFBLE1BMEtBLHVCQUFDLFNBQUksV0FBVSw4QkFFYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsaUNBQUMsU0FBTSxPQUFPLEdBQUcsV0FBVSx1QkFBc0Isa0NBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFFBQUssVUFBVS9FLGlCQUFpQixNQUFLLFNBQ3BDLGlDQUFDLE9BQUksUUFBUSxDQUFDLElBQUksRUFBRSxHQUNsQjtBQUFBLG1DQUFDLE9BQUksSUFBSSxJQUFJLElBQUksSUFDZixpQ0FBQyxRQUFLLFdBQVUscUpBQ2Q7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsdURBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0U7QUFBQSxjQUNsRTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUNFO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDO0FBQUEsc0JBQ0EsV0FBVTtBQUFBLHNCQUFnRDtBQUFBO0FBQUEsb0JBRjVEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLQTtBQUFBLGtCQUVGLE9BQU9YLE9BQU9FO0FBQUFBLGtCQUNkLFdBQVc7QUFBQSxrQkFDWCxRQUFRLHVCQUFDLG1CQUFnQixXQUFVLHNCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QztBQUFBLGtCQUNyRCxZQUFZO0FBQUEsb0JBQ1Y2SSxPQUFPO0FBQUEsb0JBQ1BDLFlBQVk7QUFBQSxvQkFDWkMsVUFBVTtBQUFBLGtCQUNaO0FBQUE7QUFBQSxnQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZ0JJO0FBQUEsY0FFSix1QkFBQyxTQUFJLFdBQVUseURBQ2IsaUNBQUMsUUFBSyxXQUFVLCtDQUNicE0sOEJBQW9CbUQsT0FBT0UsTUFBTSxDQUFDLEtBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsaUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeUJBLEtBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkJBO0FBQUEsWUFDQSx1QkFBQyxPQUFJLElBQUksSUFBSSxJQUFJLElBQ2YsaUNBQUMsUUFBSyxXQUFVLG1KQUNkO0FBQUEscUNBQUMsU0FBSSxXQUFVLG9EQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStEO0FBQUEsY0FDL0Q7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FDRTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQztBQUFBLHNCQUNBLFdBQVU7QUFBQSxzQkFBZ0Q7QUFBQTtBQUFBLG9CQUY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxrQkFFRixPQUFPRixPQUFPRztBQUFBQSxrQkFDZCxXQUFXO0FBQUEsa0JBQ1gsUUFBUSx1QkFBQyxxQkFBa0IsV0FBVSxtQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEM7QUFBQSxrQkFDcEQsWUFBWTtBQUFBLG9CQUNWNEksT0FBTztBQUFBLG9CQUNQQyxZQUFZO0FBQUEsb0JBQ1pDLFVBQVU7QUFBQSxrQkFDWjtBQUFBO0FBQUEsZ0JBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWdCSTtBQUFBLGNBRUosdUJBQUMsU0FBSSxXQUFVLHNEQUNiLGlDQUFDLFFBQUssV0FBVSw0Q0FDYnBNLDhCQUFvQm1ELE9BQU9HLE9BQU8sQ0FBQyxLQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGlCQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlCQSxLQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJCQTtBQUFBLGVBeERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeURBLEtBMURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMkRBO0FBQUEsYUEvREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdFQTtBQUFBLFFBRUEsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVE7QUFBQSxRQUdSLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsaUNBQUMsU0FBTSxPQUFPLEdBQUcsV0FBVSx1QkFBc0Isa0NBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFFBQUssVUFBVVUsaUJBQWlCLE1BQUssU0FDcEMsaUNBQUMsT0FBSSxRQUFRLENBQUMsSUFBSSxFQUFFLEdBQ2pCO0FBQUEsWUFDQztBQUFBLGNBQ0VxSSxPQUFPO0FBQUEsY0FDUEMsS0FBS3BCLGVBQWVWO0FBQUFBLGNBQ3BCMEIsT0FBTztBQUFBLGNBQ1BLLElBQUk7QUFBQSxjQUNKQyxNQUFNLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWE7QUFBQSxZQUNyQjtBQUFBLFlBQ0E7QUFBQSxjQUNFSCxPQUFPO0FBQUEsY0FDUEMsS0FBS3BCLGVBQWUzQjtBQUFBQSxjQUNwQjJDLE9BQU87QUFBQSxjQUNQSyxJQUFJO0FBQUEsY0FDSkMsTUFBTTtBQUFBLFlBQ1I7QUFBQSxZQUNBO0FBQUEsY0FDRUgsT0FBTztBQUFBLGNBQ1BDLEtBQUtwQixlQUFlekI7QUFBQUEsY0FDcEJ5QyxPQUFPO0FBQUEsY0FDUEssSUFBSTtBQUFBLGNBQ0pDLE1BQU0sdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZTtBQUFBLFlBQ3ZCO0FBQUEsWUFDQTtBQUFBLGNBQ0VILE9BQU87QUFBQSxjQUNQQyxLQUFLcEIsZUFBZVQ7QUFBQUEsY0FDcEJ5QixPQUFPO0FBQUEsY0FDUEssSUFBSTtBQUFBLGNBQ0pDLE1BQU0sdUJBQUMsK0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEI7QUFBQSxZQUNsQztBQUFBLFVBQUMsRUFDRDlHO0FBQUFBLFlBQUksQ0FBQzJDLE1BQU1vRSxRQUNYLHVCQUFDLE9BQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEdBQ3ZCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFFVjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQ0UsdUJBQUMsVUFBSyxXQUFVLDZCQUNicEUsZUFBS2dFLFNBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUVGLE9BQU9oRSxLQUFLaUU7QUFBQUEsc0JBQ1osV0FBVztBQUFBLHNCQUNYLFFBQ0UsdUJBQUMsVUFBSyxPQUFPLEVBQUVKLE9BQU83RCxLQUFLNkQsT0FBT1EsYUFBYSxFQUFFLEdBQzlDckUsZUFBS21FLFFBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUVGLFlBQVk7QUFBQSx3QkFDVk4sT0FBTzdELEtBQUs2RDtBQUFBQSx3QkFDWkUsVUFBVTtBQUFBLHdCQUNWRCxZQUFZO0FBQUEsc0JBQ2Q7QUFBQTtBQUFBLG9CQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBaUJJO0FBQUEsa0JBRUosdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFdBQVU7QUFBQSxzQkFFVG5NLDhCQUFvQnFJLEtBQUtpRSxPQUFPLENBQUM7QUFBQTtBQUFBLG9CQUpwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU9BO0FBQUE7QUFBQTtBQUFBLGNBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQStCQSxLQWhDK0JHLEtBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUNBO0FBQUEsVUFDRCxLQWpFSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtFQSxLQW5FRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9FQTtBQUFBLGFBeEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5RUE7QUFBQSxRQUlBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsaUNBQUMsU0FBTSxPQUFPLEdBQUcsV0FBVSx1QkFBc0IsNkJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFFBQUssVUFBVXZJLGFBQWEsTUFBSyxTQUNoQyxpQ0FBQyxPQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsR0FFakI7QUFBQSxZQUVDO0FBQUEsY0FDRW1JLE9BQU87QUFBQSxjQUNQQyxLQUFLOUksV0FBV0U7QUFBQUEsY0FDaEJ3SSxPQUFPO0FBQUEsY0FDUE0sTUFBTSx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFlO0FBQUEsWUFDdkI7QUFBQSxZQUNBO0FBQUEsY0FDRUgsT0FBTztBQUFBLGNBQ1BDLEtBQUs5SSxXQUFXRztBQUFBQSxjQUNoQnVJLE9BQU87QUFBQSxjQUNQTSxNQUFNLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWU7QUFBQSxZQUN2QjtBQUFBLFlBQ0E7QUFBQSxjQUNFSCxPQUFPO0FBQUEsY0FDUEMsS0FBSzlJLFdBQVdJO0FBQUFBLGNBQ2hCc0ksT0FBTztBQUFBLGNBQ1BNLE1BQU0sdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBYTtBQUFBLFlBQ3JCO0FBQUEsWUFDQTtBQUFBLGNBQ0VILE9BQU87QUFBQSxjQUNQQyxLQUFLOUksV0FBV0s7QUFBQUEsY0FDaEJxSSxPQUFPO0FBQUEsY0FDUE0sTUFBTSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQjtBQUFBLFlBQzVCO0FBQUEsVUFBQyxFQUVEOUc7QUFBQUEsWUFBSSxDQUFDeUUsTUFBTXNDLFFBQ1gsdUJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksR0FFdkIsaUNBQUMsUUFBSyxXQUFVLDZDQUNkO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FDRSx1QkFBQyxVQUFLLFdBQVUsaUJBQ2J0QztBQUFBQSx5QkFBS2tDO0FBQUFBLG9CQUFNO0FBQUEsdUJBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUVGLE9BQU9sQyxLQUFLbUM7QUFBQUEsa0JBQ1osV0FBVztBQUFBLGtCQUNYLFlBQVksRUFBRUosT0FBTyxRQUFRQyxZQUFZLE9BQU87QUFBQSxrQkFDaEQsUUFDRSx1QkFBQyxVQUFLLE9BQU8sRUFBRUQsT0FBTy9CLEtBQUsrQixNQUFNLEdBQUkvQixlQUFLcUMsUUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0M7QUFBQTtBQUFBLGdCQVZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FXRztBQUFBLGNBRUgsdUJBQUMsUUFBSyxXQUFVLDhDQUNieE0sOEJBQW9CbUssS0FBS21DLE9BQU8sQ0FBQyxLQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBLEtBbkIrQkcsS0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQkE7QUFBQSxVQUNELEtBbkRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0RBLEtBckRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0RBO0FBQUEsYUExREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJEQTtBQUFBLFdBL01GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnTkE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSwwREFDWmhMLHNCQUNDLHVCQUFDLFNBQUksV0FBVSxrREFDYixpQ0FBQyxrQkFBZSxXQUFTLFFBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUIsS0FEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLElBQ0VwQixjQUFjc00sVUFBVSxJQUMxQix1QkFBQyxTQUFNLGFBQVksK0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEMsSUFFOUM7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU01TSxhQUFhTSxjQUFjc0MsVUFBVTtBQUFBLFVBQzNDO0FBQUEsVUFDQTtBQUFBLFVBQ0Esa0JBQWtCO0FBQUEsVUFDbEIsaUJBQWlCO0FBQUEsVUFDakIsaUJBQWlCO0FBQUEsWUFDZjtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQVM7QUFBQSxVQUVYLG1CQUFtQjtBQUFBLFlBQ2pCUSxPQUFPRTtBQUFBQSxZQUNQRixPQUFPRztBQUFBQSxZQUNQNEgsZUFBZVY7QUFBQUEsWUFDZlUsZUFBZTNCO0FBQUFBLFlBQ2YyQixlQUFlekI7QUFBQUEsWUFDZnlCLGVBQWVUO0FBQUFBLFlBQ2ZqSCxXQUFXRTtBQUFBQSxZQUNYRixXQUFXRztBQUFBQSxZQUNYSCxXQUFXSTtBQUFBQSxZQUNYSixXQUFXSztBQUFBQSxVQUFPO0FBQUE7QUFBQSxRQTVCdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BNkJJLEtBckNSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3Q0E7QUFBQSxTQXRwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVwQkE7QUFBQSxPQTVwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZwQkE7QUFFSjtBQUFFM0QsR0E5aUNJRCxTQUFPO0FBQUEyTSxLQUFQM007QUFnakNOLGVBQWVBO0FBQVEsSUFBQTJNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsImFwaSIsIk1vZGFsIiwiRGF0YVRhYmxlIiwiQ2lyY3VsYXJMb2FkZXIiLCJTZWxlY3QiLCJEcm9wZG93biIsIklucHV0IiwiVGFnIiwiQ2FyZCIsIlN0YXRpc3RpYyIsIlJvdyIsIkNvbCIsIkVtcHR5IiwiVHlwb2dyYXBoeSIsIkRpdmlkZXIiLCJTcGluIiwiVGV4dCIsIlRpdGxlIiwiTmF2YmFyIiwiSW9NZE1vcmUiLCJBcnJvd1VwT3V0bGluZWQiLCJBcnJvd0Rvd25PdXRsaW5lZCIsIldhbGxldE91dGxpbmVkIiwiR2xvYmFsT3V0bGluZWQiLCJMaW5rT3V0bGluZWQiLCJTYWZldHlDZXJ0aWZpY2F0ZU91dGxpbmVkIiwiQmFua091dGxpbmVkIiwiQ3JlZGl0Q2FyZE91dGxpbmVkIiwiVGh1bmRlcmJvbHRPdXRsaW5lZCIsIkZhSW5kaWFuUnVwZWVTaWduIiwiTGluayIsImZpbHRlck9wdGlvbiIsIm51bWJlclRvSW5kaWFuV29yZHMiLCJEYXlib29rIiwiX3MiLCJncm91cHMiLCJzZXRHcm91cHMiLCJUYWJsZURheWJvb2siLCJzZXRUYWJsZURheWJvb2siLCJzZWxlY3RlZEF1Y3Rpb25Hcm91cElkIiwic2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCIsImZpbHRlcmVkVXNlcnMiLCJzZXRGaWx0ZXJlZFVzZXJzIiwiZmlsdGVyZWRBdWN0aW9uIiwic2V0RmlsdGVyZWRBdWN0aW9uIiwidG9kYXlTdHJpbmciLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsInNlbGVjdGVkRGF0ZSIsInNldFNlbGVjdGVkRGF0ZSIsInNlbGVjdGVkRnJvbURhdGUiLCJzZXRTZWxlY3RlZEZyb21EYXRlIiwic2VsZWN0ZWRUb0RhdGUiLCJzZXRTZWxlY3RlZFRvRGF0ZSIsInNob3dGaWx0ZXJGaWVsZCIsInNldFNob3dGaWx0ZXJGaWVsZCIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsInNlbGVjdGVkUGF5bWVudE1vZGUiLCJzZXRTZWxlY3RlZFBheW1lbnRNb2RlIiwic2VsZWN0ZWRQYXltZW50Rm9yIiwic2V0U2VsZWN0ZWRQYXltZW50Rm9yIiwic2VsZWN0ZWRDdXN0b21lcnMiLCJzZXRTZWxlY3RlZEN1c3RvbWVycyIsInNlbGVjdGVkQWNjb3VudFR5cGUiLCJzZXRTZWxlY3RlZEFjY291bnRUeXBlIiwiY29sbGVjdGlvbkFnZW50Iiwic2V0Q29sbGVjdGlvbkFnZW50IiwiY29sbGVjdGlvbkFkbWluIiwic2V0Q29sbGVjdGlvbkFkbWluIiwiYWdlbnRzIiwic2V0QWdlbnRzIiwiYWRtaW5zIiwic2V0QWRtaW5zIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJzZWxlY3RlZExhYmVsIiwic2V0U2VsZWN0ZWRMYWJlbCIsInNob3dBbGxQYXltZW50TW9kZXMiLCJzZXRTaG93QWxsUGF5bWVudE1vZGVzIiwic2VsZWN0ZWRUcmFuc2FjdGlvblR5cGUiLCJzZXRTZWxlY3RlZFRyYW5zYWN0aW9uVHlwZSIsInRvdGFscyIsInNldFRvdGFscyIsImluIiwib3V0IiwibmV0IiwibW9kZVRvdGFscyIsInNldE1vZGVUb3RhbHMiLCJjYXNoIiwib25saW5lIiwibGluayIsImF1dG9wYXkiLCJvdmVydmlld0xvYWRpbmciLCJzZXRPdmVydmlld0xvYWRpbmciLCJjYXRlZ29yeUxvYWRpbmciLCJzZXRDYXRlZ29yeUxvYWRpbmciLCJtb2RlTG9hZGluZyIsInNldE1vZGVMb2FkaW5nIiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInRhcmdldCIsInZhbHVlIiwidXNlciIsIkpTT04iLCJwYXJzZSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJhZG1pbl9hY2Nlc3NfcmlnaHRfaWQiLCJhY2Nlc3NfcGVybWlzc2lvbnMiLCJlZGl0X3BheW1lbnQiLCJmZXRjaERhdGEiLCJ1c2Vyc1JlcyIsImdyb3Vwc1JlcyIsImFnZW50c1JlcyIsImFkbWluc1JlcyIsIlByb21pc2UiLCJhbGwiLCJnZXQiLCJkYXRhIiwiZW1wbG95ZWUiLCJtYXAiLCJmdWxsX25hbWUiLCJuYW1lIiwic2VsZWN0ZWRfdHlwZSIsImEiLCJjb25zb2xlIiwiZXJyb3IiLCJncm91cE9wdGlvbnMiLCJsYWJlbCIsImhhbmRsZVNlbGVjdEZpbHRlciIsInRvZGF5IiwiZm9ybWF0RGF0ZSIsImRhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJmb3JtYXR0ZWQiLCJ5ZXN0ZXJkYXkiLCJzZXREYXRlIiwiZ2V0RGF0ZSIsInN0YXJ0IiwiZ2V0RnVsbFllYXIiLCJnZXRNb250aCIsImVuZCIsInBheW1lbnRNb2RlcyIsImluY2x1ZGVzIiwicHVzaCIsImFib3J0Q29udHJvbGxlciIsIkFib3J0Q29udHJvbGxlciIsImZldGNoUGF5bWVudHMiLCJyZXNwb25zZSIsInBhcmFtcyIsImZyb21fZGF0ZSIsInRvX2RhdGUiLCJncm91cElkIiwidXNlcklkIiwicGF5X3R5cGUiLCJhY2NvdW50X3R5cGUiLCJjb2xsZWN0ZWRfYnkiLCJhZG1pbl90eXBlIiwicGF5X2ZvciIsInNpZ25hbCIsInRpbiIsInRvdXQiLCJmb3JtYXR0ZWREYXRhIiwiaXRlbSIsImluZGV4IiwiYW10IiwiTnVtYmVyIiwiYW1vdW50IiwidHlwZSIsIk1hdGgiLCJhYnMiLCJfaWQiLCJpZCIsInR5cGVfcmF3IiwiZ3JvdXAiLCJncm91cF9pZCIsImdyb3VwX25hbWUiLCJ1c2VyX2lkIiwicGhvbmVOdW1iZXIiLCJwaG9uZV9udW1iZXIiLCJ0aWNrZXQiLCJsb2FuIiwibG9hbl9pZCIsInBpZ21lIiwicGlnbWVfaWQiLCJyZWNlaXB0IiwicmVjZWlwdF9ubyIsInRvTG9jYWxlU3RyaW5nIiwiYW1vdW50X3JhdyIsInBheV9kYXRlIiwiY2F0ZWdvcnkiLCJ0cmFuc2FjdGlvbl9kYXRlIiwiY3JlYXRlZEF0IiwibW9kZSIsInBheW1lbnRfdHlwZSIsImNvbGxlY3Rpb25fdGltZSIsImFkbWluX25hbWUiLCJhY3Rpb24iLCJjaGl0IiwicmVnaXN0cmF0aW9uIiwiZm9yRWFjaCIsInBmIiwidG9Mb3dlckNhc2UiLCJzZXRDYXRlZ29yeVRvdGFscyIsImZpbmFsVGFibGUiLCJmaWx0ZXIiLCJpIiwiYWJvcnQiLCJjYXRlZ29yeVRvdGFscyIsImNvbHVtbnMiLCJrZXkiLCJoZWFkZXIiLCJleHBvcnRDb2xzIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvU3RyaW5nIiwidGltZSIsImciLCJ1Iiwic2VsZWN0aW9uIiwiaGVpZ2h0IiwiU2V0IiwiZHQiLCJjb2xvciIsImZvbnRXZWlnaHQiLCJmb250U2l6ZSIsInRpdGxlIiwidmFsIiwiYmciLCJpY29uIiwiaWR4IiwibWFyZ2luUmlnaHQiLCJsZW5ndGgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJEYXlib29rLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7XHJcbiAgU2VsZWN0LFxyXG4gIERyb3Bkb3duLFxyXG4gIElucHV0LFxyXG4gIFRhZyxcclxuICBDYXJkLFxyXG4gIFN0YXRpc3RpYyxcclxuICBSb3csXHJcbiAgQ29sLFxyXG4gIEVtcHR5LFxyXG4gIFR5cG9ncmFwaHksXHJcbiAgRGl2aWRlcixcclxuICBTcGluLFxyXG59IGZyb20gXCJhbnRkXCI7XHJcbmNvbnN0IHsgVGV4dCwgVGl0bGUgfSA9IFR5cG9ncmFwaHk7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IHtcclxuICBBcnJvd1VwT3V0bGluZWQsXHJcbiAgQXJyb3dEb3duT3V0bGluZWQsXHJcbiAgV2FsbGV0T3V0bGluZWQsXHJcbiAgR2xvYmFsT3V0bGluZWQsXHJcbiAgTGlua091dGxpbmVkLFxyXG4gIFNhZmV0eUNlcnRpZmljYXRlT3V0bGluZWQsXHJcbiAgQmFua091dGxpbmVkLFxyXG4gIENyZWRpdENhcmRPdXRsaW5lZCxcclxuICBUaHVuZGVyYm9sdE91dGxpbmVkLFxyXG59IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5pbXBvcnQgeyBGYUluZGlhblJ1cGVlU2lnbiB9IGZyb20gXCJyZWFjdC1pY29ucy9mYTZcIjtcclxuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcbmltcG9ydCB7IG51bWJlclRvSW5kaWFuV29yZHMgfSBmcm9tIFwiLi4vaGVscGVycy9udW1iZXJUb0luZGlhbldvcmRzXCI7XHJcblxyXG5jb25zdCBEYXlib29rID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtncm91cHMsIHNldEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW1RhYmxlRGF5Ym9vaywgc2V0VGFibGVEYXlib29rXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCwgc2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZmlsdGVyZWRVc2Vycywgc2V0RmlsdGVyZWRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkQXVjdGlvbiwgc2V0RmlsdGVyZWRBdWN0aW9uXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCB0b2RheVN0cmluZyA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcbiAgY29uc3QgW3NlbGVjdGVkRGF0ZSwgc2V0U2VsZWN0ZWREYXRlXSA9IHVzZVN0YXRlKHRvZGF5U3RyaW5nKTtcclxuICBjb25zdCBbc2VsZWN0ZWRGcm9tRGF0ZSwgc2V0U2VsZWN0ZWRGcm9tRGF0ZV0gPSB1c2VTdGF0ZSh0b2RheVN0cmluZyk7XHJcbiAgY29uc3QgW3NlbGVjdGVkVG9EYXRlLCBzZXRTZWxlY3RlZFRvRGF0ZV0gPSB1c2VTdGF0ZSh0b2RheVN0cmluZyk7XHJcblxyXG4gIGNvbnN0IFtzaG93RmlsdGVyRmllbGQsIHNldFNob3dGaWx0ZXJGaWVsZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VsZWN0ZWRQYXltZW50TW9kZSwgc2V0U2VsZWN0ZWRQYXltZW50TW9kZV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkUGF5bWVudEZvciwgc2V0U2VsZWN0ZWRQYXltZW50Rm9yXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0ZWRDdXN0b21lcnMsIHNldFNlbGVjdGVkQ3VzdG9tZXJzXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEFjY291bnRUeXBlLCBzZXRTZWxlY3RlZEFjY291bnRUeXBlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtjb2xsZWN0aW9uQWdlbnQsIHNldENvbGxlY3Rpb25BZ2VudF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbY29sbGVjdGlvbkFkbWluLCBzZXRDb2xsZWN0aW9uQWRtaW5dID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYWRtaW5zLCBzZXRBZG1pbnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZExhYmVsLCBzZXRTZWxlY3RlZExhYmVsXSA9IHVzZVN0YXRlKFwiVG9kYXlcIik7XHJcbiAgY29uc3QgW3Nob3dBbGxQYXltZW50TW9kZXMsIHNldFNob3dBbGxQYXltZW50TW9kZXNdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAvLyBOZXcgU3RhdGVzIGZvciBJTi9PVVRcclxuICBjb25zdCBbc2VsZWN0ZWRUcmFuc2FjdGlvblR5cGUsIHNldFNlbGVjdGVkVHJhbnNhY3Rpb25UeXBlXSA9IHVzZVN0YXRlKFwiQWxsXCIpO1xyXG4gIGNvbnN0IFt0b3RhbHMsIHNldFRvdGFsc10gPSB1c2VTdGF0ZSh7IGluOiAwLCBvdXQ6IDAsIG5ldDogMCB9KTtcclxuICBjb25zdCBbbW9kZVRvdGFscywgc2V0TW9kZVRvdGFsc10gPSB1c2VTdGF0ZSh7XHJcbiAgICBjYXNoOiAwLFxyXG4gICAgb25saW5lOiAwLFxyXG4gICAgbGluazogMCxcclxuICAgIGF1dG9wYXk6IDAsXHJcbiAgfSk7XHJcblxyXG5cclxuICBjb25zdCBbb3ZlcnZpZXdMb2FkaW5nLCBzZXRPdmVydmlld0xvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW2NhdGVnb3J5TG9hZGluZywgc2V0Q2F0ZWdvcnlMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFttb2RlTG9hZGluZywgc2V0TW9kZUxvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcblxyXG4gIGNvbnN0IG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiBzZXRTZWFyY2hUZXh0KGUudGFyZ2V0LnZhbHVlKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHVzZXIgPSBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKSk7XHJcbiAgICBpZiAodXNlcj8uYWRtaW5fYWNjZXNzX3JpZ2h0X2lkPy5hY2Nlc3NfcGVybWlzc2lvbnM/LmVkaXRfcGF5bWVudCkge1xyXG4gICAgICBzZXRTaG93QWxsUGF5bWVudE1vZGVzKFxyXG4gICAgICAgIHVzZXIuYWRtaW5fYWNjZXNzX3JpZ2h0X2lkLmFjY2Vzc19wZXJtaXNzaW9ucy5lZGl0X3BheW1lbnQgPT09IFwidHJ1ZVwiLFxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoRGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCBbdXNlcnNSZXMsIGdyb3Vwc1JlcywgYWdlbnRzUmVzLCBhZG1pbnNSZXNdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgICAgYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpLFxyXG4gICAgICAgICAgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIiksXHJcbiAgICAgICAgICBhcGkuZ2V0KFwiL2VtcGxveWVlXCIpLFxyXG4gICAgICAgICAgYXBpLmdldChcIi9hZG1pbi9nZXQtc3ViLWFkbWluc1wiKSxcclxuICAgICAgICBdKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKHVzZXJzUmVzLmRhdGEpO1xyXG4gICAgICAgIHNldEdyb3Vwcyhncm91cHNSZXMuZGF0YSk7XHJcbiAgICAgICAgc2V0QWdlbnRzKFxyXG4gICAgICAgICAgYWdlbnRzUmVzLmRhdGEuZW1wbG95ZWUubWFwKChlKSA9PiAoe1xyXG4gICAgICAgICAgICAuLi5lLFxyXG4gICAgICAgICAgICBmdWxsX25hbWU6IGUubmFtZSxcclxuICAgICAgICAgICAgc2VsZWN0ZWRfdHlwZTogXCJhZ2VudF90eXBlXCIsXHJcbiAgICAgICAgICB9KSksXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXRBZG1pbnMoXHJcbiAgICAgICAgICBhZG1pbnNSZXMuZGF0YS5tYXAoKGEpID0+ICh7XHJcbiAgICAgICAgICAgIC4uLmEsXHJcbiAgICAgICAgICAgIGZ1bGxfbmFtZTogYS5uYW1lLFxyXG4gICAgICAgICAgICBzZWxlY3RlZF90eXBlOiBcImFkbWluX3R5cGVcIixcclxuICAgICAgICAgIH0pKSxcclxuICAgICAgICApO1xyXG4gICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoRGF0YSgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8gY29uc3QgaGFuZGxlU2VsZWN0RmlsdGVyID0gKHZhbHVlKSA9PiB7XHJcbiAgLy8gICBzZXRTZWxlY3RlZExhYmVsKHZhbHVlKTtcclxuICAvLyAgIHNldFNob3dGaWx0ZXJGaWVsZCh2YWx1ZSA9PT0gXCJDdXN0b21cIik7XHJcbiAgLy8gICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgLy8gICBjb25zdCBmbXQgPSAoZCkgPT4gZC50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcclxuICAvLyAgIGlmICh2YWx1ZSA9PT0gXCJUb2RheVwiKSBzZXRTZWxlY3RlZERhdGUoZm10KHRvZGF5KSk7XHJcbiAgLy8gICBlbHNlIGlmICh2YWx1ZSA9PT0gXCJZZXN0ZXJkYXlcIilcclxuICAvLyAgICAgc2V0U2VsZWN0ZWREYXRlKGZtdChuZXcgRGF0ZSh0b2RheS5zZXREYXRlKHRvZGF5LmdldERhdGUoKSAtIDEpKSkpO1xyXG4gIC8vICAgZWxzZSBpZiAodmFsdWUgPT09IFwiVHdvZGF5c2Fnb1wiKVxyXG4gIC8vICAgICBzZXRTZWxlY3RlZERhdGUoZm10KG5ldyBEYXRlKHRvZGF5LnNldERhdGUodG9kYXkuZ2V0RGF0ZSgpIC0gMikpKSk7XHJcbiAgLy8gfTtcclxuXHJcbiAgY29uc3QgZ3JvdXBPcHRpb25zID0gW1xyXG4gICAgeyB2YWx1ZTogXCJUb2RheVwiLCBsYWJlbDogXCJUb2RheVwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIlllc3RlcmRheVwiLCBsYWJlbDogXCJZZXN0ZXJkYXlcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJUaGlzTW9udGhcIiwgbGFiZWw6IFwiVGhpcyBNb250aFwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIkxhc3RNb250aFwiLCBsYWJlbDogXCJMYXN0IE1vbnRoXCIgfSxcclxuICAgIHsgdmFsdWU6IFwiVGhpc1llYXJcIiwgbGFiZWw6IFwiVGhpcyBZZWFyXCIgfSxcclxuICAgIHsgdmFsdWU6IFwiQ3VzdG9tXCIsIGxhYmVsOiBcIkN1c3RvbVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU2VsZWN0RmlsdGVyID0gKHZhbHVlKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZExhYmVsKHZhbHVlKTtcclxuICAgIC8vY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRTaG93RmlsdGVyRmllbGQoZmFsc2UpO1xyXG5cclxuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICAgIGNvbnN0IGZvcm1hdERhdGUgPSAoZGF0ZSkgPT4gZGF0ZS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1DQVwiKTtcclxuXHJcbiAgICBpZiAodmFsdWUgPT09IFwiVG9kYXlcIikge1xyXG4gICAgICBjb25zdCBmb3JtYXR0ZWQgPSBmb3JtYXREYXRlKHRvZGF5KTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXR0ZWQpO1xyXG4gICAgICBzZXRTZWxlY3RlZFRvRGF0ZShmb3JtYXR0ZWQpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJZZXN0ZXJkYXlcIikge1xyXG4gICAgICBjb25zdCB5ZXN0ZXJkYXkgPSBuZXcgRGF0ZSh0b2RheSk7XHJcbiAgICAgIHllc3RlcmRheS5zZXREYXRlKHllc3RlcmRheS5nZXREYXRlKCkgLSAxKTtcclxuICAgICAgY29uc3QgZm9ybWF0dGVkID0gZm9ybWF0RGF0ZSh5ZXN0ZXJkYXkpO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdHRlZCk7XHJcbiAgICAgIHNldFNlbGVjdGVkVG9EYXRlKGZvcm1hdHRlZCk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNNb250aFwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgKyAxLCAwKTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkVG9EYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkxhc3RNb250aFwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSAtIDEsIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAwKTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkVG9EYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNZZWFyXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAwLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMTEsIDMxKTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkVG9EYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkN1c3RvbVwiKSB7XHJcbiAgICAgIHNldFNob3dGaWx0ZXJGaWVsZCh0cnVlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBsZXQgcGF5bWVudE1vZGVzID0gWy4uLnNlbGVjdGVkUGF5bWVudE1vZGVdO1xyXG5cclxuICBpZiAoXHJcbiAgICBwYXltZW50TW9kZXMuaW5jbHVkZXMoXCJvbmxpbmVcIikgJiZcclxuICAgICFwYXltZW50TW9kZXMuaW5jbHVkZXMoXCJjaGVxdWVcIilcclxuICApIHtcclxuICAgIHBheW1lbnRNb2Rlcy5wdXNoKFwiY2hlcXVlXCIpO1xyXG4gIH1cclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGFib3J0Q29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcclxuICAgIGNvbnN0IGZldGNoUGF5bWVudHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIHNldE92ZXJ2aWV3TG9hZGluZyh0cnVlKTtcclxuICAgICAgICBzZXRDYXRlZ29yeUxvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgc2V0TW9kZUxvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvcGF5bWVudC9kYXktYm9va2AsIHtcclxuICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICBmcm9tX2RhdGU6IHNlbGVjdGVkRnJvbURhdGUsXHJcbiAgICAgICAgICAgIHRvX2RhdGU6IHNlbGVjdGVkVG9EYXRlLFxyXG4gICAgICAgICAgICBncm91cElkOiBzZWxlY3RlZEF1Y3Rpb25Hcm91cElkLFxyXG4gICAgICAgICAgICB1c2VySWQ6IHNlbGVjdGVkQ3VzdG9tZXJzLFxyXG4gICAgICAgICAgICAvLyBwYXlfdHlwZTogc2VsZWN0ZWRQYXltZW50TW9kZSxcclxuICAgICAgICAgICAgcGF5X3R5cGU6IHBheW1lbnRNb2RlcyxcclxuICAgICAgICAgICAgYWNjb3VudF90eXBlOiBzZWxlY3RlZEFjY291bnRUeXBlLFxyXG4gICAgICAgICAgICBjb2xsZWN0ZWRfYnk6IGNvbGxlY3Rpb25BZ2VudCxcclxuICAgICAgICAgICAgYWRtaW5fdHlwZTogY29sbGVjdGlvbkFkbWluLFxyXG4gICAgICAgICAgICBwYXlfZm9yOiBzZWxlY3RlZFBheW1lbnRGb3IsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgc2lnbmFsOiBhYm9ydENvbnRyb2xsZXIuc2lnbmFsLFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSkge1xyXG4gICAgICAgICAgbGV0IHRpbiA9IDAsXHJcbiAgICAgICAgICAgIHRvdXQgPSAwO1xyXG5cclxuICAgICAgICAgIGxldCBjYXNoID0gMDtcclxuICAgICAgICAgIGxldCBvbmxpbmUgPSAwO1xyXG4gICAgICAgICAgbGV0IGxpbmsgPSAwO1xyXG4gICAgICAgICAgbGV0IGF1dG9wYXkgPSAwO1xyXG5cclxuICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLm1hcCgoaXRlbSwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgY29uc3QgYW10ID0gTnVtYmVyKGl0ZW0uYW1vdW50IHx8IDApO1xyXG4gICAgICAgICAgICBpZiAoaXRlbS50eXBlID09PSBcIklOXCIpIHRpbiArPSBhbXQ7XHJcbiAgICAgICAgICAgIGVsc2UgdG91dCArPSBNYXRoLmFicyhhbXQpO1xyXG5cclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICBfaWQ6IGl0ZW0uX2lkLFxyXG4gICAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgdHlwZTogKFxyXG4gICAgICAgICAgICAgICAgPFRhZyBjb2xvcj17aXRlbT8udHlwZSA9PT0gXCJJTlwiID8gXCJncmVlblwiIDogXCJ2b2xjYW5vXCJ9PlxyXG4gICAgICAgICAgICAgICAgICB7aXRlbT8udHlwZSA/PyBcIlVua25vd25cIn1cclxuICAgICAgICAgICAgICAgIDwvVGFnPlxyXG4gICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgdHlwZV9yYXc6IGl0ZW0/LnR5cGUsXHJcbiAgICAgICAgICAgICAgZ3JvdXA6IGl0ZW0/Lmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IGl0ZW0/LnBheV9mb3IgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICBuYW1lOiBpdGVtPy51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICBwaG9uZU51bWJlcjogaXRlbT8udXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgLy8gdGlja2V0OiBpdGVtPy50aWNrZXQgfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgdGlja2V0OlxyXG4gICAgICAgICAgICAgICAgaXRlbT8ubG9hbj8ubG9hbl9pZCA/PyBpdGVtPy5waWdtZT8ucGlnbWVfaWQgPz8gaXRlbT8udGlja2V0LFxyXG4gICAgICAgICAgICAgIHJlY2VpcHQ6IGl0ZW0/LnJlY2VpcHRfbm8gfHwgXCItXCIsXHJcbiAgICAgICAgICAgICAgYW1vdW50OiAoXHJcbiAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e1xyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW0/LnR5cGUgPT09IFwiSU5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcInRleHQtZ3JlZW4tNjAwIGZvbnQtYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1yZWQtNjAwIGZvbnQtYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAg4oK5IHtNYXRoLmFicyhhbXQpLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICBhbW91bnRfcmF3OiBhbXQsXHJcbiAgICAgICAgICAgICAgcGF5X2RhdGU6IGl0ZW0ucGF5X2RhdGUsXHJcbiAgICAgICAgICAgICAgY2F0ZWdvcnk6IGl0ZW0ucGF5X2ZvciA/IGl0ZW0ucGF5X2ZvciA6IFwiQ2hpdFwiLFxyXG4gICAgICAgICAgICAgIHRyYW5zYWN0aW9uX2RhdGU6IGl0ZW0uY3JlYXRlZEF0Py5zcGxpdChcIlRcIik/LlswXSxcclxuICAgICAgICAgICAgICBtb2RlOiBpdGVtPy5wYXlfdHlwZSxcclxuICAgICAgICAgICAgICBhY2NvdW50X3R5cGU6IGl0ZW0/LmFjY291bnRfdHlwZSxcclxuICAgICAgICAgICAgICBwYXltZW50X3R5cGU6IGl0ZW0/LnBheW1lbnRfdHlwZSxcclxuICAgICAgICAgICAgICBjb2xsZWN0aW9uX3RpbWU6IGl0ZW0/LmNvbGxlY3Rpb25fdGltZSxcclxuICAgICAgICAgICAgICBjb2xsZWN0ZWRfYnk6XHJcbiAgICAgICAgICAgICAgICBpdGVtPy5jb2xsZWN0ZWRfYnk/Lm5hbWUgfHxcclxuICAgICAgICAgICAgICAgIGl0ZW0/LmFkbWluX3R5cGU/LmFkbWluX25hbWUgfHxcclxuICAgICAgICAgICAgICAgIFwiU3VwZXIgQWRtaW5cIixcclxuICAgICAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICAgIHRvPXtgL3ByaW50LyR7aXRlbS5faWR9YH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFByaW50XHJcbiAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIGxldCBjaGl0ID0gMCxcclxuICAgICAgICAgICAgbG9hbiA9IDAsXHJcbiAgICAgICAgICAgIHBpZ21lID0gMCxcclxuICAgICAgICAgICAgcmVnaXN0cmF0aW9uID0gMDtcclxuXHJcbiAgICAgICAgICByZXNwb25zZS5kYXRhLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgICAgICAgaWYgKGl0ZW0udHlwZSAhPT0gXCJJTlwiKSByZXR1cm47IC8vIG9ubHkgY29sbGVjdGlvbnNcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IGFtdCA9IE51bWJlcihpdGVtLmFtb3VudCB8fCAwKTtcclxuICAgICAgICAgICAgY29uc3QgcGYgPSAoaXRlbS5wYXlfZm9yIHx8IFwiQ2hpdFwiKS50b0xvd2VyQ2FzZSgpO1xyXG5cclxuICAgICAgICAgICAgaWYgKHBmLmluY2x1ZGVzKFwibG9hblwiKSkgbG9hbiArPSBhbXQ7XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKHBmLmluY2x1ZGVzKFwicGlnbWVcIikpIHBpZ21lICs9IGFtdDtcclxuICAgICAgICAgICAgZWxzZSBpZiAocGYuaW5jbHVkZXMoXCJyZWdcIikpIHJlZ2lzdHJhdGlvbiArPSBhbXQ7XHJcbiAgICAgICAgICAgIGVsc2UgY2hpdCArPSBhbXQ7XHJcbiAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICByZXNwb25zZS5kYXRhLmZvckVhY2goKGl0ZW0pID0+IHtcclxuICAgICAgICAgICAgY29uc3QgYW10ID0gTnVtYmVyKGl0ZW0uYW1vdW50IHx8IDApO1xyXG5cclxuICAgICAgICAgICAgaWYgKGl0ZW0udHlwZSAhPT0gXCJJTlwiKSByZXR1cm47XHJcblxyXG4gICAgICAgICAgICBjb25zdCBtb2RlID0gKGl0ZW0ucGF5X3R5cGUgfHwgXCJcIikudG9Mb3dlckNhc2UoKTtcclxuXHJcbiAgICAgICAgICAgIGlmIChtb2RlID09PSBcImF1dG9wYXlcIiB8fCBtb2RlID09PSBcIm9ubGluZS9hdXRvcGF5XCIgfHwgbW9kZS5pbmNsdWRlcyhcImF1dG9wYXlcIikpIHtcclxuICAgICAgICAgICAgICBhdXRvcGF5ICs9IGFtdDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIGlmIChtb2RlID09PSBcImNhc2hcIikge1xyXG4gICAgICAgICAgICAgIGNhc2ggKz0gYW10O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKG1vZGUgPT09IFwib25saW5lXCIpIHtcclxuICAgICAgICAgICAgICBvbmxpbmUgKz0gYW10O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYgKG1vZGUuaW5jbHVkZXMoXCJsaW5rXCIpKSB7XHJcbiAgICAgICAgICAgICAgbGluayArPSBhbXQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIC8vICAgaWYgKG1vZGUgPT09IFwiY2FzaFwiKSBjYXNoICs9IGFtdDtcclxuICAgICAgICAgIC8vICAgZWxzZSBpZiAobW9kZSA9PT0gXCJvbmxpbmVcIikgb25saW5lICs9IGFtdDtcclxuXHJcbiAgICAgICAgICAvLyAgIGVsc2UgaWYgKG1vZGUuaW5jbHVkZXMoXCJsaW5rXCIpKSBsaW5rICs9IGFtdDsgXHJcblxyXG4gICAgICAgICAgLy8gICBlbHNlIGlmIChtb2RlLmluY2x1ZGVzKFwiYXV0b1BheVwiKSkgYXV0b3BheSArPSBhbXQ7XHJcbiAgICAgICAgICAvLyB9KTtcclxuXHJcbiAgICAgICAgICBzZXRDYXRlZ29yeVRvdGFscyh7XHJcbiAgICAgICAgICAgIGNoaXQsXHJcbiAgICAgICAgICAgIGxvYW4sXHJcbiAgICAgICAgICAgIHBpZ21lLFxyXG4gICAgICAgICAgICByZWdpc3RyYXRpb24sXHJcbiAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICBzZXRUb3RhbHMoeyBpbjogdGluLCBvdXQ6IHRvdXQsIG5ldDogdGluIC0gdG91dCB9KTtcclxuICAgICAgICAgIHNldE1vZGVUb3RhbHMoe1xyXG4gICAgICAgICAgICBjYXNoLFxyXG4gICAgICAgICAgICBvbmxpbmUsXHJcbiAgICAgICAgICAgIGxpbmssXHJcbiAgICAgICAgICAgIGF1dG9wYXksXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihyZXNwb25zZS5kYXRhKTtcclxuXHJcblxyXG4gICAgICAgICAgY29uc3QgZmluYWxUYWJsZSA9XHJcbiAgICAgICAgICAgIHNlbGVjdGVkVHJhbnNhY3Rpb25UeXBlID09PSBcIkFsbFwiXHJcbiAgICAgICAgICAgICAgPyBmb3JtYXR0ZWREYXRhXHJcbiAgICAgICAgICAgICAgOiBmb3JtYXR0ZWREYXRhLmZpbHRlcihcclxuICAgICAgICAgICAgICAgIChpKSA9PiBpPy5jYXRlZ29yeSA9PT0gc2VsZWN0ZWRUcmFuc2FjdGlvblR5cGUsXHJcbiAgICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICBzZXRUYWJsZURheWJvb2soZmluYWxUYWJsZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIHNldFRhYmxlRGF5Ym9vayhbXSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICBzZXRPdmVydmlld0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgIHNldENhdGVnb3J5TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgc2V0TW9kZUxvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoUGF5bWVudHMoKTtcclxuICAgIHJldHVybiAoKSA9PiBhYm9ydENvbnRyb2xsZXIuYWJvcnQoKTtcclxuICB9LCBbXHJcbiAgICBzZWxlY3RlZEF1Y3Rpb25Hcm91cElkLFxyXG4gICAgc2VsZWN0ZWRUb0RhdGUsXHJcbiAgICBzZWxlY3RlZEZyb21EYXRlLFxyXG4gICAgc2VsZWN0ZWRQYXltZW50TW9kZSxcclxuICAgIHNlbGVjdGVkQ3VzdG9tZXJzLFxyXG4gICAgc2VsZWN0ZWRBY2NvdW50VHlwZSxcclxuICAgIGNvbGxlY3Rpb25BZ2VudCxcclxuICAgIGNvbGxlY3Rpb25BZG1pbixcclxuICAgIHNlbGVjdGVkUGF5bWVudEZvcixcclxuICAgIHNlbGVjdGVkVHJhbnNhY3Rpb25UeXBlLFxyXG4gIF0pO1xyXG5cclxuICBjb25zdCBbY2F0ZWdvcnlUb3RhbHMsIHNldENhdGVnb3J5VG90YWxzXSA9IHVzZVN0YXRlKHtcclxuICAgIGNoaXQ6IDAsXHJcbiAgICBsb2FuOiAwLFxyXG4gICAgcGlnbWU6IDAsXHJcbiAgICByZWdpc3RyYXRpb246IDAsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0xcIiB9LFxyXG4gICAgeyBrZXk6IFwidHJhbnNhY3Rpb25fZGF0ZVwiLCBoZWFkZXI6IFwiVHJhbnNhY3Rpb24gRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJwYXltZW50X3R5cGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJwYXlfZGF0ZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBEYXRlXCIgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcInR5cGVcIixcclxuICAgICAgaGVhZGVyOiBcIlR5cGVcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJjYXRlZ29yeVwiLFxyXG4gICAgICBoZWFkZXI6IFwiQ2F0ZWdvcnlcIixcclxuICAgIH0sXHJcbiAgICB7IGtleTogXCJncm91cFwiLCBoZWFkZXI6IFwiR3JvdXAvUmVhc29uXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lTnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVjZWlwdFwiLCBoZWFkZXI6IFwiUmVjZWlwdFwiIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJhbW91bnRcIixcclxuICAgICAgaGVhZGVyOiBcIkFtb3VudFwiLFxyXG4gICAgfSxcclxuICAgIHsga2V5OiBcIm1vZGVcIiwgaGVhZGVyOiBcIk1vZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY29sbGVjdGVkX2J5XCIsIGhlYWRlcjogXCJDb2xsZWN0ZWQgQnlcIiB9LFxyXG4gICAgeyBrZXk6IFwiY29sbGVjdGlvbl90aW1lXCIsIGhlYWRlcjogXCJDb2xsZWN0aW9uIFRpbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcbiAgY29uc3QgZXhwb3J0Q29scyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTFwiIH0sXHJcbiAgICB7IGtleTogXCJ0cmFuc2FjdGlvbl9kYXRlXCIsIGhlYWRlcjogXCJUcmFuc2FjdGlvbiBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcInBheW1lbnRfdHlwZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcInBheV9kYXRlXCIsIGhlYWRlcjogXCJQYXltZW50IERhdGVcIiB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwidHlwZV9yYXdcIixcclxuICAgICAgaGVhZGVyOiBcIlR5cGVcIixcclxuICAgIH0sXHJcbiAgICB7IGtleTogXCJncm91cFwiLCBoZWFkZXI6IFwiR3JvdXAvUmVhc29uXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lTnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVjZWlwdFwiLCBoZWFkZXI6IFwiUmVjZWlwdFwiIH0sXHJcbiAgICB7XHJcbiAgICAgIGtleTogXCJhbW91bnRfcmF3XCIsXHJcbiAgICAgIGhlYWRlcjogXCJBbW91bnRcIixcclxuICAgIH0sXHJcbiAgICB7IGtleTogXCJtb2RlXCIsIGhlYWRlcjogXCJNb2RlXCIgfSxcclxuICAgIHtcclxuICAgICAga2V5OiBcImNhdGVnb3J5XCIsXHJcbiAgICAgIGhlYWRlcjogXCJDYXRlZ29yeVwiLFxyXG4gICAgfSxcclxuICAgIHsga2V5OiBcImNvbGxlY3RlZF9ieVwiLCBoZWFkZXI6IFwiQ29sbGVjdGVkIEJ5XCIgfSxcclxuICAgIHsga2V5OiBcImNvbGxlY3Rpb25fdGltZVwiLCBoZWFkZXI6IFwiQ29sbGVjdGlvbiBUaW1lXCIgfSxcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGZsZXgtY29sIFtoZWlnaHQ6Y2FsYygxMDB2aC0xMDBweCldIFwiPlxyXG4gICAgICA8TmF2YmFyXHJcbiAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXtvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbiAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgLz5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC04IGJnLXNsYXRlLTUwIG1pbi1oLXNjcmVlblwiPlxyXG4gICAgICAgIHsvKiBQcm9mZXNzaW9uYWwgSGVhZGVyICYgU3VtbWFyeSBEYXNoYm9hcmQgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XHJcbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwXCI+RGF5Ym9vayBSZXBvcnQ8L2gxPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgQ29tcHJlaGVuc2l2ZSB2aWV3IG9mIGRhaWx5IGNvbGxlY3Rpb25zIGFuZCBkaXNidXJzZW1lbnRzXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBFeGlzdGluZyBGaWx0ZXJzIENhcmQgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1tZCBib3JkZXIgcC02IG1iLTZcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNFwiPlxyXG4gICAgICAgICAgICB7LyogTmV3IElOL09VVCBGaWx0ZXIgKi99XHJcbiAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMFwiPlRSQU5TQUNUSU9OIFRZUEU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3QgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTBcIiB2YWx1ZT17c2VsZWN0ZWRUcmFuc2FjdGlvblR5cGV9IG9uQ2hhbmdlPXtzZXRTZWxlY3RlZFRyYW5zYWN0aW9uVHlwZX0+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIkFsbFwiPkFsbCAoSU4gJiBPVVQpPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJJTlwiPlBheW1lbnQgSU4gT25seTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiT1VUXCI+UGF5bWVudCBPVVQgT25seTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgPC9kaXY+ICovfVxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICBGaWx0ZXIgT3B0aW9uXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVNlbGVjdEZpbHRlcn1cclxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZExhYmVsfVxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggT3IgU2VsZWN0IEZpbHRlclwiXHJcbiAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge2dyb3VwT3B0aW9ucy5tYXAoKHRpbWUpID0+IChcclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt0aW1lLnZhbHVlfSB2YWx1ZT17dGltZS52YWx1ZX0+XHJcbiAgICAgICAgICAgICAgICAgICAge3RpbWUubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHtzaG93RmlsdGVyRmllbGQgJiYgKFxyXG4gICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgRnJvbSBEYXRlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRGcm9tRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkRnJvbURhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTExIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgdHJhbnNpdGlvbi1hbGwgb3V0bGluZS1ub25lXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFRvIERhdGVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFRvRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkVG9EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWluZGlnby01MDAgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IHRyYW5zaXRpb24tYWxsIG91dGxpbmUtbm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwXCI+R1JPVVA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEwXCJcclxuICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEF1Y3Rpb25Hcm91cElkfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFNlbGVjdGVkQXVjdGlvbkdyb3VwSWR9XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBHcm91cFwiXHJcbiAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICBvcHRpb24/LmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgPy50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPkFsbCBHcm91cHM8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2cuX2lkfSB2YWx1ZT17Zy5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtnLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICBDVVNUT01FUlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTBcIlxyXG4gICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQ3VzdG9tZXJzfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFNlbGVjdGVkQ3VzdG9tZXJzfVxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgb3B0aW9uPy5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgID8udG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGwgQ3VzdG9tZXJzPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAge2ZpbHRlcmVkVXNlcnMubWFwKCh1KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dS5faWR9IHZhbHVlPXt1Py5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgIHt1Py5mdWxsX25hbWV9IC0ge3U/LnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDBcIj5cclxuICAgICAgICAgICAgICAgIFBBWU1FTlQgRk9SXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBtb2RlPVwibXVsdGlwbGVcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1pbi1oLTEwXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFBheW1lbnRGb3J9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRQYXltZW50Rm9yfVxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJDaGl0LCBMb2FuLCBldGMuXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIkNoaXRcIj5DaGl0PC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJQaWdtZVwiPlBpZ21lPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJMb2FuXCI+TG9hbjwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiUmVnaXN0cmF0aW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgIFJlZ2lzdHJhdGlvbiBGZWVcclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgUEFZTUVOVCBNT0RFXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBtb2RlPVwibXVsdGlwbGVcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1pbi1oLTEwXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFBheW1lbnRNb2RlfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFNlbGVjdGVkUGF5bWVudE1vZGV9XHJcbiAgICAgICAgICAgICAgICBvcHRpb25zPXtbXHJcbiAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiQ2FzaFwiLCB2YWx1ZTogXCJjYXNoXCIgfSxcclxuICAgICAgICAgICAgICAgICAgeyBsYWJlbDogXCJPbmxpbmVcIiwgdmFsdWU6IFwib25saW5lXCIgfSxcclxuICAgICAgICAgICAgICAgICAgeyBsYWJlbDogXCJPbmxpbmUvQXV0b3BheVwiLCB2YWx1ZTogXCJvbmxpbmUvYXV0b1BheVwiIH0sXHJcbiAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiT25saW5lL1BheW1lbnQgTGlua1wiLCB2YWx1ZTogXCJQYXltZW50IExpbmtcIiB9LFxyXG4gICAgICAgICAgICAgICAgICB7IGxhYmVsOiBcIkNoZXF1ZVwiLCB2YWx1ZTogXCJjaGVxdWVcIiB9LFxyXG4gICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQ2FzaCwgT25saW5lLCBldGMuXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHtzaG93QWxsUGF5bWVudE1vZGVzICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEFDQ09VTlQgVFlQRVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTBcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRBY2NvdW50VHlwZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFNlbGVjdGVkQWNjb3VudFR5cGV9XHJcbiAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e1tcclxuICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiBcIkFsbFwiLCB2YWx1ZTogXCJcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiU3VzcGVuc2VcIiwgdmFsdWU6IFwic3VzcGVuc2VcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiQ3JlZGl0XCIsIHZhbHVlOiBcImNyZWRpdFwiIH0sXHJcbiAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgQ29sbGVjdGlvbiBFbXBsb3llZVxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgZW1wbG95ZWVcIlxyXG4gICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoc2VsZWN0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IFtpZCwgdHlwZV0gPSBzZWxlY3Rpb24uc3BsaXQoXCJ8XCIpIHx8IFtdO1xyXG4gICAgICAgICAgICAgICAgICBpZiAodHlwZSA9PT0gXCJhZG1pbl90eXBlXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRDb2xsZWN0aW9uQWRtaW4oaWQpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldENvbGxlY3Rpb25BZ2VudChcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmICh0eXBlID09PSBcImFnZW50X3R5cGVcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldENvbGxlY3Rpb25BZ2VudChpZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0Q29sbGVjdGlvbkFkbWluKFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldENvbGxlY3Rpb25BZG1pbihcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRDb2xsZWN0aW9uQWdlbnQoXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgaGVpZ2h0OiBcIjQ0cHhcIiB9fVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiXCI+QWxsIEVtcGxveWVlczwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgIHtbLi4ubmV3IFNldChhZ2VudHMpLCAuLi5uZXcgU2V0KGFkbWlucyldLm1hcCgoZHQpID0+IChcclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb25cclxuICAgICAgICAgICAgICAgICAgICBrZXk9e2R0Py5faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Ake2R0Ll9pZH18JHtkdC5zZWxlY3RlZF90eXBlfWB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7ZHQuc2VsZWN0ZWRfdHlwZSA9PT0gXCJhZG1pbl90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJBZG1pbiB8IFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiRW1wbG95ZWUgfCBcIn1cclxuICAgICAgICAgICAgICAgICAgICB7ZHQuZnVsbF9uYW1lfSB8IHtkdC5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgVE9UQUwgRElTUExBWUVEXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtMTAgcHgtMyBmbGV4IGl0ZW1zLWNlbnRlciBiZy1ibHVlLTUwIGJvcmRlciBib3JkZXItYmx1ZS0yMDAgcm91bmRlZCB0ZXh0LWJsdWUtNzAwIGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAg4oK5IHt0b3RhbHM/Lm5ldC50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtbW9ubyAke3RvdGFscz8ubmV0IDwgMCA/IFwidGV4dC1yZWQtNzAwXCIgOiBcInRleHQtZ3JlZW4tNzAwXCJ9YH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyh0b3RhbHM/Lm5ldCB8fCAwKX1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PiAqL31cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIHsvKiA8Um93IGd1dHRlcj17WzE2LCAxNl19IGNsYXNzTmFtZT1cIm1iLThcIj5cclxuICAgICAgICAgIDxDb2wgeHM9ezI0fSBtZD17OH0+XHJcbiAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1zbSBib3JkZXItbC00IGJvcmRlci1ncmVlbi01MDBcIj5cclxuICAgICAgICAgICAgICA8U3RhdGlzdGljXHJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIlRvdGFsIElOIChDb2xsZWN0aW9ucylcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3RvdGFscy5pbn1cclxuICAgICAgICAgICAgICAgIHByZWNpc2lvbj17Mn1cclxuICAgICAgICAgICAgICAgIHByZWZpeD17XHJcbiAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPEFycm93VXBPdXRsaW5lZCAvPuKCuVxyXG4gICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHZhbHVlU3R5bGU9e3sgY29sb3I6IFwiIzA1OTY2OVwiIH19XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMCBwbC0zYH0+XHJcbiAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHModG90YWxzLmluIHx8IDApfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgIDxDb2wgeHM9ezI0fSBtZD17OH0+XHJcbiAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1zbSBib3JkZXItbC00IGJvcmRlci1yZWQtNTAwXCI+XHJcbiAgICAgICAgICAgICAgPFN0YXRpc3RpY1xyXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJUb3RhbCBPVVQgKFBheW91dHMpXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXt0b3RhbHMub3V0fVxyXG4gICAgICAgICAgICAgICAgcHJlY2lzaW9uPXsyfVxyXG4gICAgICAgICAgICAgICAgcHJlZml4PXtcclxuICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICA8QXJyb3dEb3duT3V0bGluZWQgLz4g4oK5XHJcbiAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdmFsdWVTdHlsZT17eyBjb2xvcjogXCIjZGMyNjI2XCIgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtc20gZm9udC1tb25vIHRleHQtcmVkLTcwMCBwbC0zYH0+XHJcbiAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHModG90YWxzLm91dCB8fCAwKX1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICA8Q29sIHhzPXsyNH0gbWQ9ezh9PlxyXG4gICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3ctc20gYm9yZGVyLWwtNCBib3JkZXItaW5kaWdvLTUwMFwiPlxyXG4gICAgICAgICAgICAgIDxTdGF0aXN0aWNcclxuICAgICAgICAgICAgICAgIHRpdGxlPVwiQ2hpdCBDb2xsZWN0aW9uc1wiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Y2F0ZWdvcnlUb3RhbHMuY2hpdH1cclxuICAgICAgICAgICAgICAgIHByZWNpc2lvbj17Mn1cclxuICAgICAgICAgICAgICAgIHByZWZpeD17XHJcbiAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPEFycm93RG93bk91dGxpbmVkIC8+IOKCuVxyXG4gICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHZhbHVlU3R5bGU9e3sgY29sb3I6IFwiIzRmNDZlNVwiIH19XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWluZGlnby03MDAgcGwtM2B9PlxyXG4gICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGNhdGVnb3J5VG90YWxzLmNoaXQgfHwgMCl9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgIDwvUm93PlxyXG4gICAgICAgIDxSb3cgZ3V0dGVyPXtbMTYsIDE2XX0gY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgICAgPENvbCB4cz17MjR9IG1kPXs4fT5cclxuICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwic2hhZG93LXNtIGJvcmRlci1sLTQgYm9yZGVyLW9yYW5nZS01MDBcIj5cclxuICAgICAgICAgICAgICA8U3RhdGlzdGljXHJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIkxvYW4gQ29sbGVjdGlvbnNcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2NhdGVnb3J5VG90YWxzLmxvYW59XHJcbiAgICAgICAgICAgICAgICBwcmVjaXNpb249ezJ9XHJcbiAgICAgICAgICAgICAgICBwcmVmaXg9e1xyXG4gICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgIDxBcnJvd1VwT3V0bGluZWQgLz7igrlcclxuICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB2YWx1ZVN0eWxlPXt7IGNvbG9yOiBcIiNkOTc3MDZcIiB9fVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC1zbSBmb250LW1vbm8gdGV4dC1vcmFuZ2UtNzAwIHBsLTNgfT5cclxuICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhjYXRlZ29yeVRvdGFscy5sb2FuIHx8IDApfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgIDxDb2wgeHM9ezI0fSBtZD17OH0+XHJcbiAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1zbSBib3JkZXItbC00IGJvcmRlci1ncmVlbi04MDBcIj5cclxuICAgICAgICAgICAgICA8U3RhdGlzdGljXHJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIlBpZ21lIENvbGxlY3Rpb25zXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtjYXRlZ29yeVRvdGFscy5waWdtZX1cclxuICAgICAgICAgICAgICAgIHByZWNpc2lvbj17Mn1cclxuICAgICAgICAgICAgICAgIHByZWZpeD17XHJcbiAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPEFycm93RG93bk91dGxpbmVkIC8+IOKCuVxyXG4gICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHZhbHVlU3R5bGU9e3sgY29sb3I6IFwiIzBkOTQ4OFwiIH19XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTgwMCBwbC0zYH0+XHJcbiAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoY2F0ZWdvcnlUb3RhbHMucGlnbWUgfHwgMCl9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgPENvbCB4cz17MjR9IG1kPXs4fT5cclxuICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwic2hhZG93LXNtIGJvcmRlci1sLTQgYm9yZGVyLXBpbmstNTAwXCI+XHJcbiAgICAgICAgICAgICAgPFN0YXRpc3RpY1xyXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJSZWdpc3RyYXRpb24gRmVlc1wiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Y2F0ZWdvcnlUb3RhbHMucmVnaXN0cmF0aW9ufVxyXG4gICAgICAgICAgICAgICAgcHJlY2lzaW9uPXsyfVxyXG4gICAgICAgICAgICAgICAgcHJlZml4PXtcclxuICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICA8QXJyb3dEb3duT3V0bGluZWQgLz4g4oK5XHJcbiAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdmFsdWVTdHlsZT17eyBjb2xvcjogXCIjZGIyNzc3XCIgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtc20gZm9udC1tb25vIHRleHQtcGluay03MDAgcGwtM2B9PlxyXG4gICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGNhdGVnb3J5VG90YWxzLnJlZ2lzdHJhdGlvbiB8fCAwKX1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgPFJvdyBndXR0ZXI9e1sxNiwgMTZdfSBjbGFzc05hbWU9XCJtYi04XCI+XHJcbiAgICAgICAgICA8Q29sIHhzPXsyNH0gbWQ9ezh9PlxyXG4gICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3ctc20gYm9yZGVyLWwtNCBib3JkZXItZ3JlZW4tNTAwXCI+XHJcbiAgICAgICAgICAgICAgPFN0YXRpc3RpY1xyXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJDYXNoIENvbGxlY3Rpb25cIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e21vZGVUb3RhbHMuY2FzaH1cclxuICAgICAgICAgICAgICAgIHByZWNpc2lvbj17Mn1cclxuICAgICAgICAgICAgICAgIHByZWZpeD17XHJcbiAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPEFycm93VXBPdXRsaW5lZCAvPuKCuVxyXG4gICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHZhbHVlU3R5bGU9e3sgY29sb3I6IFwiIzE1ODAzZFwiIH19XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMCBwbC0zYH0+XHJcbiAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMobW9kZVRvdGFscy5jYXNoIHx8IDApfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgIDxDb2wgeHM9ezI0fSBtZD17OH0+XHJcbiAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1zbSBib3JkZXItbC00IGJvcmRlci1ibHVlLTgwMFwiPlxyXG4gICAgICAgICAgICAgIDxTdGF0aXN0aWNcclxuICAgICAgICAgICAgICAgIHRpdGxlPVwiT25saW5lIENvbGxlY3Rpb25cIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e21vZGVUb3RhbHMub25saW5lfVxyXG4gICAgICAgICAgICAgICAgcHJlY2lzaW9uPXsyfVxyXG4gICAgICAgICAgICAgICAgcHJlZml4PXtcclxuICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICA8QXJyb3dEb3duT3V0bGluZWQgLz4g4oK5XHJcbiAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdmFsdWVTdHlsZT17eyBjb2xvcjogXCIjMjU2M2ViXCIgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtc20gZm9udC1tb25vIHRleHQtYmx1ZS04MDAgcGwtM2B9PlxyXG4gICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKG1vZGVUb3RhbHMub25saW5lIHx8IDApfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgIDxDb2wgeHM9ezI0fSBtZD17OH0+XHJcbiAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1zbSBib3JkZXItbC00IGJvcmRlci1wdXJwbGUtNTAwXCI+XHJcbiAgICAgICAgICAgICAgPFN0YXRpc3RpY1xyXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJQYXltZW50IExpbmsgQ29sbGVjdGlvblwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17bW9kZVRvdGFscy5saW5rfVxyXG4gICAgICAgICAgICAgICAgcHJlY2lzaW9uPXsyfVxyXG4gICAgICAgICAgICAgICAgcHJlZml4PXtcclxuICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICA8QXJyb3dEb3duT3V0bGluZWQgLz4g4oK5XHJcbiAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdmFsdWVTdHlsZT17eyBjb2xvcjogXCIjN2MzYWVkXCIgfX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtc20gZm9udC1tb25vIHRleHQtcHVycGxlLTcwMCBwbC0zYH0+XHJcbiAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMobW9kZVRvdGFscy5saW5rIHx8IDApfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L0NvbD5cclxuICAgICAgICA8L1Jvdz4gKi99XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IGJnLWdyYXktNTAgcm91bmRlZC0yeGxcIj5cclxuICAgICAgICAgIHsvKiBTRUNUSU9OOiBPdmVydmlldyAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICA8VGl0bGUgbGV2ZWw9ezR9IGNsYXNzTmFtZT1cIiFtYi00IHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICBGaW5hbmNpYWwgT3ZlcnZpZXdcclxuICAgICAgICAgICAgPC9UaXRsZT5cclxuICAgICAgICAgICAgPFNwaW4gc3Bpbm5pbmc9e292ZXJ2aWV3TG9hZGluZ30gc2l6ZT1cImxhcmdlXCI+XHJcbiAgICAgICAgICAgICAgPFJvdyBndXR0ZXI9e1syMCwgMjBdfT5cclxuICAgICAgICAgICAgICAgIDxDb2wgeHM9ezI0fSBtZD17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBib3JkZXItbm9uZSByb3VuZGVkLXhsIGJnLWdyYWRpZW50LXRvLWJyIGZyb20td2hpdGUgdG8tZ3JlZW4tNTAvMzAgb3ZlcmZsb3ctaGlkZGVuIHJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMCBsZWZ0LTAgdy0xLjUgaC1mdWxsIGJnLWVtZXJhbGQtNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8U3RhdGlzdGljXHJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb25nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC14c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBJTiAoQ29sbGVjdGlvbnMpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0b3RhbHMuaW59XHJcbiAgICAgICAgICAgICAgICAgICAgICBwcmVjaXNpb249ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwcmVmaXg9ezxBcnJvd1VwT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTUwMFwiIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWVTdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCIjMDY1ZjQ2XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IFwiNzAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcIjEuOHJlbVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBweS0xIHB4LTIgYmctZW1lcmFsZC0xMDAvNTAgcm91bmRlZCBpbmxpbmUtYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxUZXh0IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1lbWVyYWxkLTgwMCBpdGFsaWNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHModG90YWxzLmluIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICAgIDxDb2wgeHM9ezI0fSBtZD17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBib3JkZXItbm9uZSByb3VuZGVkLXhsIGJnLWdyYWRpZW50LXRvLWJyIGZyb20td2hpdGUgdG8tcmVkLTUwLzMwIG92ZXJmbG93LWhpZGRlbiByZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgbGVmdC0wIHctMS41IGgtZnVsbCBiZy1yb3NlLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPFN0YXRpc3RpY1xyXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8VGV4dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9uZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQteHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgT1VUIChQYXlvdXRzKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dG90YWxzLm91dH1cclxuICAgICAgICAgICAgICAgICAgICAgIHByZWNpc2lvbj17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgIHByZWZpeD17PEFycm93RG93bk91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIiAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlU3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiIzlmMTIzOVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiBcIjcwMFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogXCIxLjhyZW1cIixcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgcHktMSBweC0yIGJnLXJvc2UtMTAwLzUwIHJvdW5kZWQgaW5saW5lLWJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8VGV4dCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtcm9zZS04MDAgaXRhbGljXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKHRvdGFscy5vdXQgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgIDwvUm93PlxyXG4gICAgICAgICAgICA8L1NwaW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8RGl2aWRlciAvPlxyXG5cclxuICAgICAgICAgIHsvKiBTRUNUSU9OOiBDYXRlZ29yaWVzICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICAgIDxUaXRsZSBsZXZlbD17NH0gY2xhc3NOYW1lPVwiIW1iLTQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgIENhdGVnb3J5IEJyZWFrZG93blxyXG4gICAgICAgICAgICA8L1RpdGxlPlxyXG4gICAgICAgICAgICA8U3BpbiBzcGlubmluZz17Y2F0ZWdvcnlMb2FkaW5nfSBzaXplPVwibGFyZ2VcIj5cclxuICAgICAgICAgICAgICA8Um93IGd1dHRlcj17WzE2LCAxNl19PlxyXG4gICAgICAgICAgICAgICAge1tcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIkNoaXQgQ29sbGVjdGlvbnNcIixcclxuICAgICAgICAgICAgICAgICAgICB2YWw6IGNhdGVnb3J5VG90YWxzLmNoaXQsXHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiIzYzNjZmMVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGJnOiBcImluZGlnb1wiLFxyXG4gICAgICAgICAgICAgICAgICAgIGljb246IDxCYW5rT3V0bGluZWQgLz4sXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCJMb2FuIENvbGxlY3Rpb25zXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsOiBjYXRlZ29yeVRvdGFscy5sb2FuLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcIiNmNTllMGJcIixcclxuICAgICAgICAgICAgICAgICAgICBiZzogXCJvcmFuZ2VcIixcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiBcIuKCuVwiLFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiUGlnbWUgQ29sbGVjdGlvbnNcIixcclxuICAgICAgICAgICAgICAgICAgICB2YWw6IGNhdGVnb3J5VG90YWxzLnBpZ21lLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcIiMwZDk0ODhcIixcclxuICAgICAgICAgICAgICAgICAgICBiZzogXCJ0ZWFsXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbjogPFdhbGxldE91dGxpbmVkIC8+LFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiUmVnaXN0cmF0aW9uIEZlZXNcIixcclxuICAgICAgICAgICAgICAgICAgICB2YWw6IGNhdGVnb3J5VG90YWxzLnJlZ2lzdHJhdGlvbixcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCIjZGIyNzc3XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgYmc6IFwicGlua1wiLFxyXG4gICAgICAgICAgICAgICAgICAgIGljb246IDxTYWZldHlDZXJ0aWZpY2F0ZU91dGxpbmVkIC8+LFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgXS5tYXAoKGl0ZW0sIGlkeCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8Q29sIHhzPXsyNH0gc209ezEyfSBtZD17Nn0ga2V5PXtpZHh9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxDYXJkXHJcbiAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaG92ZXI6LXRyYW5zbGF0ZS15LTEgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwIHNoYWRvdy1tZCBib3JkZXItZ3JheS0xMDAgcm91bmRlZC1sZyBcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTdGF0aXN0aWNcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17aXRlbS52YWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHByZWNpc2lvbj17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcHJlZml4PXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogaXRlbS5jb2xvciwgbWFyZ2luUmlnaHQ6IDQgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5pY29ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZVN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IGl0ZW0uY29sb3IsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMS4yNXJlbVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IFwiNjAwXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtbW9ubyBsZWFkaW5nLW5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoaXRlbS52YWwgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgPC9TcGluPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuICAgICAgICAgIHsvKiBTRUNUSU9OOiBQYXltZW50IE1vZGVzICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICAgIDxUaXRsZSBsZXZlbD17NH0gY2xhc3NOYW1lPVwiIW1iLTQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgIFBheW1lbnQgTW9kZXNcclxuICAgICAgICAgICAgPC9UaXRsZT5cclxuICAgICAgICAgICAgPFNwaW4gc3Bpbm5pbmc9e21vZGVMb2FkaW5nfSBzaXplPVwibGFyZ2VcIj5cclxuICAgICAgICAgICAgICA8Um93IGd1dHRlcj17WzE2LCAxNl19PlxyXG5cclxuICAgICAgICAgICAgICAgIHtbXHJcblxyXG4gICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiQ2FzaFwiLFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbDogbW9kZVRvdGFscy5jYXNoLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcIiMxNmEzNGFcIixcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiA8V2FsbGV0T3V0bGluZWQgLz4sXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCJPbmxpbmVcIixcclxuICAgICAgICAgICAgICAgICAgICB2YWw6IG1vZGVUb3RhbHMub25saW5lLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcIiMyNTYzZWJcIixcclxuICAgICAgICAgICAgICAgICAgICBpY29uOiA8R2xvYmFsT3V0bGluZWQgLz4sXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCJQYXltZW50IExpbmsgXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsOiBtb2RlVG90YWxzLmxpbmssXHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiIzdjM2FlZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGljb246IDxMaW5rT3V0bGluZWQgLz4sXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCJBdXRvUGF5XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsOiBtb2RlVG90YWxzLmF1dG9wYXksXHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiIzdjM2FlZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGljb246IDxUaHVuZGVyYm9sdE91dGxpbmVkIC8+LFxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG5cclxuICAgICAgICAgICAgICAgIF0ubWFwKChtb2RlLCBpZHgpID0+IChcclxuICAgICAgICAgICAgICAgICAgPENvbCB4cz17MjR9IHNtPXsxMn0gbGc9ezZ9IGtleT17aWR4fT5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyLW5vbmUgcm91bmRlZC14bCBzaGFkb3ctbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTdGF0aXN0aWNcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHttb2RlLnRpdGxlfSBDb2xsZWN0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXttb2RlLnZhbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcHJlY2lzaW9uPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZVN0eWxlPXt7IGNvbG9yOiBcIiMwMDBcIiwgZm9udFdlaWdodDogXCJib2xkXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcHJlZml4PXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBjb2xvcjogbW9kZS5jb2xvciB9fT57bW9kZS5pY29ufTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxUZXh0IGNsYXNzTmFtZT1cInRleHQtZ3JheS05MDAgdGV4dC1bMTFweF0gZm9udC1tb25vIGl0YWxpY1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyhtb2RlLnZhbCB8fCAwKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9Sb3c+XHJcbiAgICAgICAgICAgIDwvU3Bpbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LW1kIGJvcmRlciBwLTQgbWluLWgtWzQ1MHB4XVwiPlxyXG4gICAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtaW4taC1bMzUwcHhdXCI+XHJcbiAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGlzTG9hZGluZyAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkgOiBUYWJsZURheWJvb2s/Lmxlbmd0aCA8PSAwID8gKFxyXG4gICAgICAgICAgICA8RW1wdHkgZGVzY3JpcHRpb249XCJEYXlib29rIERhdGEgaXMgbm90IGZvdW5kXCIgLz5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJPcHRpb24oVGFibGVEYXlib29rLCBzZWFyY2hUZXh0KX1cclxuICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgIGV4cG9ydENvbHM9e2V4cG9ydENvbHN9XHJcbiAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17XCJEYXlib29rXCJ9XHJcbiAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPXtgRGF5Ym9va2B9XHJcbiAgICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtbXHJcbiAgICAgICAgICAgICAgICBcIlRvdGFsIElOIChDb2xsZWN0aW9ucylcIixcclxuICAgICAgICAgICAgICAgIFwiVG90YWwgT1VUIChQYXlvdXRzKVwiLFxyXG4gICAgICAgICAgICAgICAgXCJDaGl0IENvbGxlY3Rpb25zXCIsXHJcbiAgICAgICAgICAgICAgICBcIkxvYW4gQ29sbGVjdGlvbnNcIixcclxuICAgICAgICAgICAgICAgIFwiUGlnbWUgQ29sbGVjdGlvbnNcIixcclxuICAgICAgICAgICAgICAgIFwiUmVnaXN0cmF0aW9uIEZlZXNcIixcclxuICAgICAgICAgICAgICAgIFwiQ2FzaCBDb2xsZWN0aW9uXCIsXHJcbiAgICAgICAgICAgICAgICBcIk9ubGluZSBDb2xsZWN0aW9uXCIsXHJcbiAgICAgICAgICAgICAgICBcIlBheW1lbnQgTGlua1wiLFxyXG4gICAgICAgICAgICAgICAgXCJBdXRvUGF5XCIsXHJcbiAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICBwcmludEhlYWRlclZhbHVlcz17W1xyXG4gICAgICAgICAgICAgICAgdG90YWxzLmluLFxyXG4gICAgICAgICAgICAgICAgdG90YWxzLm91dCxcclxuICAgICAgICAgICAgICAgIGNhdGVnb3J5VG90YWxzLmNoaXQsXHJcbiAgICAgICAgICAgICAgICBjYXRlZ29yeVRvdGFscy5sb2FuLFxyXG4gICAgICAgICAgICAgICAgY2F0ZWdvcnlUb3RhbHMucGlnbWUsXHJcbiAgICAgICAgICAgICAgICBjYXRlZ29yeVRvdGFscy5yZWdpc3RyYXRpb24sXHJcbiAgICAgICAgICAgICAgICBtb2RlVG90YWxzLmNhc2gsXHJcbiAgICAgICAgICAgICAgICBtb2RlVG90YWxzLm9ubGluZSxcclxuICAgICAgICAgICAgICAgIG1vZGVUb3RhbHMubGluayxcclxuICAgICAgICAgICAgICAgIG1vZGVUb3RhbHMuYXV0b3BheSxcclxuICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgRGF5Ym9vaztcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0RheWJvb2suanN4In0=