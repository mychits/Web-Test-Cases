import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Marketing.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const Fragment = __vite__cjsImport3_react["Fragment"]; const useRef = __vite__cjsImport3_react["useRef"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { FaFacebookSquare } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { AiOutlinePlus, AiOutlineMinus } from "/node_modules/.vite/deps/react-icons_ai.js?v=819e0a34";
import { LiaSmsSolid } from "/node_modules/.vite/deps/react-icons_lia.js?v=819e0a34";
import { NavLink, Outlet, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import {
  FaWhatsapp,
  FaChevronDown,
  FaChevronRight,
  FaExternalLinkAlt,
  FaSpinner
} from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { MdEmail } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { RiMoneyRupeeCircleLine } from "/node_modules/.vite/deps/react-icons_ri.js?v=819e0a34";
const mainMenus = [
  {
    key: "whatsapp",
    title: "Whatsapp Marketing",
    icon: /* @__PURE__ */ jsxDEV(FaWhatsapp, { size: 20 }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
      lineNumber: 493,
      columnNumber: 9
    }, this),
    color: "#25D366",
    subMenus: [
      {
        title: "Login",
        link: "https://app.interakt.ai/login",
        newTab: true,
        description: "Access your Interakt dashboard"
      },
      {
        title: "Due Message",
        subMenus: [
          {
            title: "Due",
            link: "/marketing/due-message",
            description: "Send due payment reminders"
          },
          {
            title: "Overdue",
            link: "/marketing/over-due-message",
            description: "Notify about overdue payments"
          }
        ]
      },
      {
        title: "Lead Whatsapp Message",
        subMenus: [
          {
            title: "Welcome Message",
            link: "/marketing/lead-welcome-message",
            description: "Send welcome messages to new leads"
          },
          {
            title: "ReferredBy Message",
            link: "/marketing/lead-referredby-message",
            description: "Notify leads about referrals"
          }
        ]
      },
      {
        title: "Customer Whatsapp Message",
        subMenus: [
          {
            title: "Welcome Message",
            link: "/marketing/customer-welcome-message",
            description: "Welcome new customers"
          },
          {
            title: "ChitPlan Message",
            link: "/marketing/customer-chitplan-message",
            description: "Send chit plan information"
          }
        ]
      },
      {
        title: "Auction Message",
        subMenus: [
          {
            title: "Auction Intimation",
            link: "/marketing/auction-intimation-message",
            description: "Notify about upcoming auctions"
          },
          {
            title: "Bid Winner",
            link: "/marketing/bid-winner",
            description: "Notify auction winners"
          },
          {
            title: "Bid Status",
            link: "/marketing/bid-status",
            description: "Update bid status"
          },
          {
            title: "Winner Documents",
            link: "/marketing/winner-document",
            description: "Request documents from winners"
          },
          {
            title: "Auction Info",
            link: "/marketing/auction-info",
            description: "Provide auction details"
          },
          {
            title: "Terms & Conditions",
            link: "/marketing/auction-terms-condition",
            description: "Share auction terms"
          }
        ]
      },
      {
        title: "Promotion",
        subMenus: [
          {
            title: "Promo",
            link: "/marketing/what-promo",
            description: "Send promotional messages"
          }
        ]
      }
    ]
  },
  {
    key: "email",
    title: "Email Marketing",
    icon: /* @__PURE__ */ jsxDEV(MdEmail, { size: 20 }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
      lineNumber: 597,
      columnNumber: 9
    }, this),
    color: "#EA4335",
    subMenus: [
      {
        title: "Due Email",
        subMenus: [
          {
            title: "Due",
            link: "/marketing/due-email",
            description: "Send due payment emails"
          },
          {
            title: "Overdue",
            link: "/marketing/over-due-email",
            description: "Send overdue payment emails"
          }
        ]
      }
    ]
  },
  {
    key: "payment",
    title: "Payment Links",
    icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleLine, { size: 20 }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
      lineNumber: 620,
      columnNumber: 9
    }, this),
    color: "#00C853",
    subMenus: [
      {
        title: "Payment Link",
        link: "/marketing/payment-link",
        description: "Generate payment links"
      }
    ]
  }
];
const Marketing = () => {
  _s();
  const [activeMenu, setActiveMenu] = useState(mainMenus[0]);
  const [openSection, setOpenSection] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const location = useLocation();
  useEffect(() => {
    const currentPath = location.pathname;
    const matchedMenu = mainMenus.find((menu) => {
      return menu.subMenus.some((section) => {
        if (section.link === currentPath) return true;
        if (section.subMenus) {
          return section.subMenus.some((subItem) => subItem.link === currentPath);
        }
        return false;
      });
    });
    if (matchedMenu) {
      setActiveMenu(matchedMenu);
    }
  }, [location.pathname]);
  const handleMenuClick = (menu) => {
    setActiveMenu(menu);
    setOpenSection(null);
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 300);
  };
  const handleSectionToggle = (index) => {
    setOpenSection(openSection === index ? null : index);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row min-h-screen bg-gray-50", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
      lineNumber: 670,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-1 flex-col md:flex-row", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-64 bg-white border-r border-gray-200 shadow-sm p-4 mt-16 ", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-800 mb-4 mr-10 mt-10", children: "Marketing Tools" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
          lineNumber: 675,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("nav", { className: "space-y-1", children: mainMenus.map(
          (menu) => /* @__PURE__ */ jsxDEV(
            "div",
            {
              onClick: () => handleMenuClick(menu),
              className: `flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-all duration-200 ${activeMenu.key === menu.key ? "bg-gradient-to-r from-violet-50 to-indigo-50 text-violet-700 shadow-sm border-l-4 border-violet-500" : "hover:bg-gray-50 text-gray-700 hover:text-gray-900"}`,
              style: {
                borderLeftColor: activeMenu.key === menu.key ? menu.color : void 0
              },
              children: [
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `p-2 rounded-md ${activeMenu.key === menu.key ? "bg-white shadow-sm" : "bg-gray-100"}`,
                    style: { color: activeMenu.key === menu.key ? menu.color : void 0 },
                    children: menu.icon
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                    lineNumber: 690,
                    columnNumber: 17
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: menu.title }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                  lineNumber: 698,
                  columnNumber: 17
                }, this)
              ]
            },
            menu.key,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
              lineNumber: 678,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
          lineNumber: 676,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
        lineNumber: 674,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-4 md:p-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-6 mt-16", children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-gray-800 flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: "p-2 rounded-lg ",
                  style: { backgroundColor: `${activeMenu.color}20`, color: activeMenu.color },
                  children: activeMenu.icon
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                  lineNumber: 709,
                  columnNumber: 17
                },
                this
              ),
              activeMenu.title
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
              lineNumber: 708,
              columnNumber: 15
            }, this),
            isLoading && /* @__PURE__ */ jsxDEV(FaSpinner, { className: "animate-spin text-violet-500" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
              lineNumber: 717,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
            lineNumber: 707,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4", children: activeMenu.subMenus.map(
            (section, index) => /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: "border border-gray-200 rounded-xl overflow-hidden transition-all duration-200 hover:shadow-md",
                children: [
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      onClick: () => section.subMenus && handleSectionToggle(index),
                      className: `p-4 bg-gradient-to-r from-gray-50 to-white cursor-pointer ${section.subMenus ? "hover:from-gray-100 hover:to-gray-50" : ""}`,
                      children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                          /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-gray-800", children: section.title }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                            lineNumber: 733,
                            columnNumber: 23
                          }, this),
                          section.subMenus && /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 transition-transform duration-200", children: openSection === index ? /* @__PURE__ */ jsxDEV(FaChevronDown, {}, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                            lineNumber: 736,
                            columnNumber: 52
                          }, this) : /* @__PURE__ */ jsxDEV(FaChevronRight, {}, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                            lineNumber: 736,
                            columnNumber: 72
                          }, this) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                            lineNumber: 735,
                            columnNumber: 21
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                          lineNumber: 732,
                          columnNumber: 21
                        }, this),
                        section.description && /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600 mt-1", children: section.description }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                          lineNumber: 741,
                          columnNumber: 19
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                      lineNumber: 726,
                      columnNumber: 19
                    },
                    this
                  ),
                  openSection === index && section.subMenus && /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-gray-50 border-t border-gray-200", children: /* @__PURE__ */ jsxDEV("ul", { className: "space-y-1", children: section.subMenus.map(
                    (item, idx) => /* @__PURE__ */ jsxDEV("li", { children: [
                      /* @__PURE__ */ jsxDEV(
                        NavLink,
                        {
                          to: item.link,
                          target: item.newTab ? "_blank" : "_self",
                          className: ({ isActive }) => `flex items-center justify-between p-3 rounded-lg transition-all duration-200 ${isActive ? "bg-violet-50 text-violet-700 font-medium" : "hover:bg-white text-gray-700"}`,
                          children: [
                            /* @__PURE__ */ jsxDEV("span", { children: item.title }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                              lineNumber: 762,
                              columnNumber: 31
                            }, this),
                            item.newTab && /* @__PURE__ */ jsxDEV(FaExternalLinkAlt, { className: "text-xs text-gray-400" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                              lineNumber: 763,
                              columnNumber: 47
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                          lineNumber: 751,
                          columnNumber: 29
                        },
                        this
                      ),
                      item.description && /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 px-3 pb-2", children: item.description }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                        lineNumber: 766,
                        columnNumber: 23
                      }, this)
                    ] }, idx, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                      lineNumber: 750,
                      columnNumber: 21
                    }, this)
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                    lineNumber: 748,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                    lineNumber: 747,
                    columnNumber: 17
                  }, this),
                  section.link && /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-gray-50 border-t border-gray-200", children: /* @__PURE__ */ jsxDEV(
                    NavLink,
                    {
                      to: section.link,
                      target: section.newTab ? "_blank" : "_self",
                      className: ({ isActive }) => `flex items-center justify-between p-3 rounded-lg transition-all duration-200 ${isActive ? "bg-violet-50 text-violet-700 font-medium" : "hover:bg-white text-gray-700"}`,
                      children: [
                        /* @__PURE__ */ jsxDEV("span", { children: "Open" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                          lineNumber: 788,
                          columnNumber: 25
                        }, this),
                        section.newTab && /* @__PURE__ */ jsxDEV(FaExternalLinkAlt, { className: "text-xs text-gray-400" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                          lineNumber: 789,
                          columnNumber: 44
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                      lineNumber: 777,
                      columnNumber: 23
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                    lineNumber: 776,
                    columnNumber: 17
                  }, this)
                ]
              },
              index,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
                lineNumber: 722,
                columnNumber: 15
              },
              this
            )
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
            lineNumber: 720,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
          lineNumber: 706,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm border border-gray-100 p-6", children: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
          lineNumber: 799,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
          lineNumber: 798,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
        lineNumber: 705,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
      lineNumber: 672,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx",
    lineNumber: 669,
    columnNumber: 5
  }, this);
};
_s(Marketing, "7AIh5JkJ4zHoE7cp8f9mlbfBU3U=", false, function() {
  return [useLocation];
});
_c = Marketing;
export default Marketing;
var _c;
$RefreshReg$(_c, "Marketing");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Marketing.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNGVVOzJCQTVlVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLFNBQVNBLFVBQVVDLFVBQVVDLFFBQU9DLGlCQUFpQjtBQUNyRCxPQUFPQyxhQUFhO0FBR3BCLFNBQVNDLHdCQUF3QjtBQUVqQyxTQUFTQyxlQUFlQyxzQkFBc0I7QUFDOUMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLFNBQVNDLFFBQVFDLG1CQUFtQjtBQW9kN0M7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyw4QkFBOEI7QUFHdkMsTUFBTUMsWUFBWTtBQUFBLEVBQ2hCO0FBQUEsSUFDRUMsS0FBSztBQUFBLElBQ0xDLE9BQU87QUFBQSxJQUNQQyxNQUFNLHVCQUFDLGNBQVcsTUFBTSxNQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFCO0FBQUEsSUFDM0JDLE9BQU87QUFBQSxJQUNQQyxVQUFVO0FBQUEsTUFDUjtBQUFBLFFBQ0VILE9BQU87QUFBQSxRQUNQSSxNQUFNO0FBQUEsUUFDTkMsUUFBUTtBQUFBLFFBQ1JDLGFBQWE7QUFBQSxNQUNmO0FBQUEsTUFDQTtBQUFBLFFBQ0VOLE9BQU87QUFBQSxRQUNQRyxVQUFVO0FBQUEsVUFDUjtBQUFBLFlBQ0VILE9BQU87QUFBQSxZQUNQSSxNQUFNO0FBQUEsWUFDTkUsYUFBYTtBQUFBLFVBQ2Y7QUFBQSxVQUNBO0FBQUEsWUFDRU4sT0FBTztBQUFBLFlBQ1BJLE1BQU07QUFBQSxZQUNORSxhQUFhO0FBQUEsVUFDZjtBQUFBLFFBQUM7QUFBQSxNQUVMO0FBQUEsTUFDQTtBQUFBLFFBQ0VOLE9BQU87QUFBQSxRQUNQRyxVQUFVO0FBQUEsVUFDUjtBQUFBLFlBQ0VILE9BQU87QUFBQSxZQUNQSSxNQUFNO0FBQUEsWUFDTkUsYUFBYTtBQUFBLFVBQ2Y7QUFBQSxVQUNBO0FBQUEsWUFDRU4sT0FBTztBQUFBLFlBQ1BJLE1BQU07QUFBQSxZQUNORSxhQUFhO0FBQUEsVUFDZjtBQUFBLFFBQUM7QUFBQSxNQUVMO0FBQUEsTUFDQTtBQUFBLFFBQ0VOLE9BQU87QUFBQSxRQUNQRyxVQUFVO0FBQUEsVUFDUjtBQUFBLFlBQ0VILE9BQU87QUFBQSxZQUNQSSxNQUFNO0FBQUEsWUFDTkUsYUFBYTtBQUFBLFVBQ2Y7QUFBQSxVQUNBO0FBQUEsWUFDRU4sT0FBTztBQUFBLFlBQ1BJLE1BQU07QUFBQSxZQUNORSxhQUFhO0FBQUEsVUFDZjtBQUFBLFFBQUM7QUFBQSxNQUVMO0FBQUEsTUFDQTtBQUFBLFFBQ0VOLE9BQU87QUFBQSxRQUNQRyxVQUFVO0FBQUEsVUFDUjtBQUFBLFlBQ0VILE9BQU87QUFBQSxZQUNQSSxNQUFNO0FBQUEsWUFDTkUsYUFBYTtBQUFBLFVBQ2Y7QUFBQSxVQUNBO0FBQUEsWUFDRU4sT0FBTztBQUFBLFlBQ1BJLE1BQU07QUFBQSxZQUNORSxhQUFhO0FBQUEsVUFDZjtBQUFBLFVBQ0E7QUFBQSxZQUNFTixPQUFPO0FBQUEsWUFDUEksTUFBTTtBQUFBLFlBQ05FLGFBQWE7QUFBQSxVQUNmO0FBQUEsVUFDQTtBQUFBLFlBQ0VOLE9BQU87QUFBQSxZQUNQSSxNQUFNO0FBQUEsWUFDTkUsYUFBYTtBQUFBLFVBQ2Y7QUFBQSxVQUNBO0FBQUEsWUFDRU4sT0FBTztBQUFBLFlBQ1BJLE1BQU07QUFBQSxZQUNORSxhQUFhO0FBQUEsVUFDZjtBQUFBLFVBQ0E7QUFBQSxZQUNFTixPQUFPO0FBQUEsWUFDUEksTUFBTTtBQUFBLFlBQ05FLGFBQWE7QUFBQSxVQUNmO0FBQUEsUUFBQztBQUFBLE1BRUw7QUFBQSxNQUNBO0FBQUEsUUFDRU4sT0FBTztBQUFBLFFBQ1BHLFVBQVU7QUFBQSxVQUNSO0FBQUEsWUFDRUgsT0FBTztBQUFBLFlBQ1BJLE1BQU07QUFBQSxZQUNORSxhQUFhO0FBQUEsVUFDZjtBQUFBLFFBQUM7QUFBQSxNQUVMO0FBQUEsSUFBQztBQUFBLEVBRUw7QUFBQSxFQUNBO0FBQUEsSUFDRVAsS0FBSztBQUFBLElBQ0xDLE9BQU87QUFBQSxJQUNQQyxNQUFNLHVCQUFDLFdBQVEsTUFBTSxNQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0I7QUFBQSxJQUN4QkMsT0FBTztBQUFBLElBQ1BDLFVBQVU7QUFBQSxNQUNSO0FBQUEsUUFDRUgsT0FBTztBQUFBLFFBQ1BHLFVBQVU7QUFBQSxVQUNSO0FBQUEsWUFDRUgsT0FBTztBQUFBLFlBQ1BJLE1BQU07QUFBQSxZQUNORSxhQUFhO0FBQUEsVUFDZjtBQUFBLFVBQ0E7QUFBQSxZQUNFTixPQUFPO0FBQUEsWUFDUEksTUFBTTtBQUFBLFlBQ05FLGFBQWE7QUFBQSxVQUNmO0FBQUEsUUFBQztBQUFBLE1BRUw7QUFBQSxJQUFDO0FBQUEsRUFFTDtBQUFBLEVBQ0E7QUFBQSxJQUNFUCxLQUFLO0FBQUEsSUFDTEMsT0FBTztBQUFBLElBQ1BDLE1BQU0sdUJBQUMsMEJBQXVCLE1BQU0sTUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpQztBQUFBLElBQ3ZDQyxPQUFPO0FBQUEsSUFDUEMsVUFBVTtBQUFBLE1BQ1I7QUFBQSxRQUNFSCxPQUFPO0FBQUEsUUFDUEksTUFBTTtBQUFBLFFBQ05FLGFBQWE7QUFBQSxNQUNmO0FBQUEsSUFBQztBQUFBLEVBRUw7QUFBQztBQUdILE1BQU1DLFlBQVlBLE1BQU07QUFBQUMsS0FBQTtBQUN0QixRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSS9CLFNBQVNtQixVQUFVLENBQUMsQ0FBQztBQUN6RCxRQUFNLENBQUNhLGFBQWFDLGNBQWMsSUFBSWpDLFNBQVMsSUFBSTtBQUNuRCxRQUFNLENBQUNrQyxXQUFXQyxZQUFZLElBQUluQyxTQUFTLEtBQUs7QUFDaEQsUUFBTW9DLFdBQVd6QixZQUFZO0FBRzdCUixZQUFVLE1BQU07QUFDZCxVQUFNa0MsY0FBY0QsU0FBU0U7QUFDN0IsVUFBTUMsY0FBY3BCLFVBQVVxQixLQUFLLENBQUFDLFNBQVE7QUFDekMsYUFBT0EsS0FBS2pCLFNBQVNrQixLQUFLLENBQUFDLFlBQVc7QUFDbkMsWUFBSUEsUUFBUWxCLFNBQVNZLFlBQWEsUUFBTztBQUN6QyxZQUFJTSxRQUFRbkIsVUFBVTtBQUNwQixpQkFBT21CLFFBQVFuQixTQUFTa0IsS0FBSyxDQUFBRSxZQUFXQSxRQUFRbkIsU0FBU1ksV0FBVztBQUFBLFFBQ3RFO0FBQ0EsZUFBTztBQUFBLE1BQ1QsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUVELFFBQUlFLGFBQWE7QUFDZlIsb0JBQWNRLFdBQVc7QUFBQSxJQUMzQjtBQUFBLEVBQ0YsR0FBRyxDQUFDSCxTQUFTRSxRQUFRLENBQUM7QUFFdEIsUUFBTU8sa0JBQWtCQSxDQUFDSixTQUFTO0FBQ2hDVixrQkFBY1UsSUFBSTtBQUNsQlIsbUJBQWUsSUFBSTtBQUNuQkUsaUJBQWEsSUFBSTtBQUVqQlcsZUFBVyxNQUFNWCxhQUFhLEtBQUssR0FBRyxHQUFHO0FBQUEsRUFDM0M7QUFFQSxRQUFNWSxzQkFBc0JBLENBQUNDLFVBQVU7QUFDckNmLG1CQUFlRCxnQkFBZ0JnQixRQUFRLE9BQU9BLEtBQUs7QUFBQSxFQUNyRDtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHFEQUNiO0FBQUEsMkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVE7QUFBQSxJQUVSLHVCQUFDLFNBQUksV0FBVSxvQ0FFYjtBQUFBLDZCQUFDLFNBQUksV0FBVSx5RUFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSx3REFBdUQsK0JBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0Y7QUFBQSxRQUNwRix1QkFBQyxTQUFJLFdBQVUsYUFDWjdCLG9CQUFVOEI7QUFBQUEsVUFBSSxDQUFDUixTQUNkO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxTQUFTLE1BQU1JLGdCQUFnQkosSUFBSTtBQUFBLGNBQ25DLFdBQVcscUZBQ1RYLFdBQVdWLFFBQVFxQixLQUFLckIsTUFDcEIsd0dBQ0Esb0RBQW9EO0FBQUEsY0FFMUQsT0FBTztBQUFBLGdCQUNMOEIsaUJBQWlCcEIsV0FBV1YsUUFBUXFCLEtBQUtyQixNQUFNcUIsS0FBS2xCLFFBQVE0QjtBQUFBQSxjQUM5RDtBQUFBLGNBRUE7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFXLGtCQUNUckIsV0FBV1YsUUFBUXFCLEtBQUtyQixNQUFNLHVCQUF1QixhQUFhO0FBQUEsb0JBRXBFLE9BQU8sRUFBRUcsT0FBT08sV0FBV1YsUUFBUXFCLEtBQUtyQixNQUFNcUIsS0FBS2xCLFFBQVE0QixPQUFVO0FBQUEsb0JBRXBFVixlQUFLbkI7QUFBQUE7QUFBQUEsa0JBTlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BO0FBQUEsZ0JBQ0EsdUJBQUMsVUFBSyxXQUFVLGVBQWVtQixlQUFLcEIsU0FBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEM7QUFBQTtBQUFBO0FBQUEsWUFuQnJDb0IsS0FBS3JCO0FBQUFBLFlBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXFCQTtBQUFBLFFBQ0QsS0F4Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlCQTtBQUFBLFdBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0QkE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSw0REFDWjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixPQUFPLEVBQUVnQyxpQkFBaUIsR0FBR3RCLFdBQVdQLEtBQUssTUFBTUEsT0FBT08sV0FBV1AsTUFBTTtBQUFBLGtCQUUxRU8scUJBQVdSO0FBQUFBO0FBQUFBLGdCQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQ1EsV0FBV1Q7QUFBQUEsaUJBUGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBQ0NhLGFBQWEsdUJBQUMsYUFBVSxXQUFVLGtDQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRDtBQUFBLGVBVm5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSx3REFDWkoscUJBQVdOLFNBQVN5QjtBQUFBQSxZQUFJLENBQUNOLFNBQVNLLFVBQ2pDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsV0FBVTtBQUFBLGdCQUVWO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsU0FBUyxNQUFNTCxRQUFRbkIsWUFBWXVCLG9CQUFvQkMsS0FBSztBQUFBLHNCQUM1RCxXQUFXLDZEQUNUTCxRQUFRbkIsV0FBVyx5Q0FBeUMsRUFBRTtBQUFBLHNCQUdoRTtBQUFBLCtDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLGlEQUFDLFFBQUcsV0FBVSwrQkFBK0JtQixrQkFBUXRCLFNBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQTJEO0FBQUEsMEJBQzFEc0IsUUFBUW5CLFlBQ1AsdUJBQUMsVUFBSyxXQUFVLG1EQUNiUSwwQkFBZ0JnQixRQUFRLHVCQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWMsSUFBTSx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFlLEtBRDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSw2QkFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQU9BO0FBQUEsd0JBQ0NMLFFBQVFoQixlQUNQLHVCQUFDLE9BQUUsV0FBVSw4QkFBOEJnQixrQkFBUWhCLGVBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQStEO0FBQUE7QUFBQTtBQUFBLG9CQWZuRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBaUJBO0FBQUEsa0JBR0NLLGdCQUFnQmdCLFNBQVNMLFFBQVFuQixZQUNoQyx1QkFBQyxTQUFJLFdBQVUsMkNBQ2IsaUNBQUMsUUFBRyxXQUFVLGFBQ1htQixrQkFBUW5CLFNBQVN5QjtBQUFBQSxvQkFBSSxDQUFDSSxNQUFNQyxRQUMzQix1QkFBQyxRQUNDO0FBQUE7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsSUFBSUQsS0FBSzVCO0FBQUFBLDBCQUNULFFBQVE0QixLQUFLM0IsU0FBUyxXQUFXO0FBQUEsMEJBQ2pDLFdBQVcsQ0FBQyxFQUFFNkIsU0FBUyxNQUNyQixnRkFDRUEsV0FDSSw2Q0FDQSw4QkFBOEI7QUFBQSwwQkFJdEM7QUFBQSxtREFBQyxVQUFNRixlQUFLaEMsU0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFrQjtBQUFBLDRCQUNqQmdDLEtBQUszQixVQUFVLHVCQUFDLHFCQUFrQixXQUFVLDJCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFvRDtBQUFBO0FBQUE7QUFBQSx3QkFadEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQWFBO0FBQUEsc0JBQ0MyQixLQUFLMUIsZUFDSix1QkFBQyxPQUFFLFdBQVUsbUNBQW1DMEIsZUFBSzFCLGVBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlFO0FBQUEseUJBaEI1RDJCLEtBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFrQkE7QUFBQSxrQkFDRCxLQXJCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXNCQSxLQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXdCQTtBQUFBLGtCQUlEWCxRQUFRbEIsUUFDUCx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsSUFBSWtCLFFBQVFsQjtBQUFBQSxzQkFDWixRQUFRa0IsUUFBUWpCLFNBQVMsV0FBVztBQUFBLHNCQUNwQyxXQUFXLENBQUMsRUFBRTZCLFNBQVMsTUFDckIsZ0ZBQ0VBLFdBQ0ksNkNBQ0EsOEJBQThCO0FBQUEsc0JBSXRDO0FBQUEsK0NBQUMsVUFBSyxvQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFVO0FBQUEsd0JBQ1RaLFFBQVFqQixVQUFVLHVCQUFDLHFCQUFrQixXQUFVLDJCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFvRDtBQUFBO0FBQUE7QUFBQSxvQkFaekU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQWFBLEtBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFlQTtBQUFBO0FBQUE7QUFBQSxjQXBFR3NCO0FBQUFBLGNBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXVFQTtBQUFBLFVBQ0QsS0ExRUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyRUE7QUFBQSxhQXpGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMEZBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsNERBQ2IsaUNBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQU8sS0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQS9GRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0dBO0FBQUEsU0FqSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtJQTtBQUFBLE9BcklGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzSUE7QUFFSjtBQUFFbkIsR0E3S0lELFdBQVM7QUFBQSxVQUlJakIsV0FBVztBQUFBO0FBQUE2QyxLQUp4QjVCO0FBb0xOLGVBQWVBO0FBQVUsSUFBQTRCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkZyYWdtZW50IiwidXNlUmVmIiwidXNlRWZmZWN0IiwiU2lkZWJhciIsIkZhRmFjZWJvb2tTcXVhcmUiLCJBaU91dGxpbmVQbHVzIiwiQWlPdXRsaW5lTWludXMiLCJMaWFTbXNTb2xpZCIsIk5hdkxpbmsiLCJPdXRsZXQiLCJ1c2VMb2NhdGlvbiIsIkZhV2hhdHNhcHAiLCJGYUNoZXZyb25Eb3duIiwiRmFDaGV2cm9uUmlnaHQiLCJGYUV4dGVybmFsTGlua0FsdCIsIkZhU3Bpbm5lciIsIk1kRW1haWwiLCJSaU1vbmV5UnVwZWVDaXJjbGVMaW5lIiwibWFpbk1lbnVzIiwia2V5IiwidGl0bGUiLCJpY29uIiwiY29sb3IiLCJzdWJNZW51cyIsImxpbmsiLCJuZXdUYWIiLCJkZXNjcmlwdGlvbiIsIk1hcmtldGluZyIsIl9zIiwiYWN0aXZlTWVudSIsInNldEFjdGl2ZU1lbnUiLCJvcGVuU2VjdGlvbiIsInNldE9wZW5TZWN0aW9uIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwibG9jYXRpb24iLCJjdXJyZW50UGF0aCIsInBhdGhuYW1lIiwibWF0Y2hlZE1lbnUiLCJmaW5kIiwibWVudSIsInNvbWUiLCJzZWN0aW9uIiwic3ViSXRlbSIsImhhbmRsZU1lbnVDbGljayIsInNldFRpbWVvdXQiLCJoYW5kbGVTZWN0aW9uVG9nZ2xlIiwiaW5kZXgiLCJtYXAiLCJib3JkZXJMZWZ0Q29sb3IiLCJ1bmRlZmluZWQiLCJiYWNrZ3JvdW5kQ29sb3IiLCJpdGVtIiwiaWR4IiwiaXNBY3RpdmUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJNYXJrZXRpbmcuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIGltcG9ydCB7IE5hdkxpbmssIE91dGxldCB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IHVzZVN0YXRlLCBGcmFnbWVudCwgdXNlUmVmLHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuLy8gaW1wb3J0IHsgRmFXaGF0c2FwcCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG4vLyBpbXBvcnQgeyBSaU1vbmV5UnVwZWVDaXJjbGVMaW5lIH0gZnJvbSBcInJlYWN0LWljb25zL3JpXCI7XHJcbmltcG9ydCB7IEZhRmFjZWJvb2tTcXVhcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuLy8gaW1wb3J0IHsgTWRFbWFpbCB9IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5pbXBvcnQgeyBBaU91dGxpbmVQbHVzLCBBaU91dGxpbmVNaW51cyB9IGZyb20gXCJyZWFjdC1pY29ucy9haVwiO1xyXG5pbXBvcnQgeyBMaWFTbXNTb2xpZCB9IGZyb20gXCJyZWFjdC1pY29ucy9saWFcIjtcclxuaW1wb3J0IHsgTmF2TGluaywgT3V0bGV0LCB1c2VMb2NhdGlvbiB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcblxyXG5cclxuLy8gY29uc3QgbWFpbk1lbnVzID0gW1xyXG4vLyAgIHtcclxuLy8gICAgIGtleTogXCIjbWFpbi0xXCIsXHJcbi8vICAgICB0aXRsZTogXCJXaGF0c2FwcCBNYXJrZXRpbmdcIixcclxuLy8gICAgIGljb246IDxGYVdoYXRzYXBwIHNpemU9ezIwfSAvPixcclxuLy8gICAgIHN1Yk1lbnVzOiBbXHJcbi8vICAgICAgIHtcclxuLy8gICAgICAgICBrZXk6IFwiIzFcIixcclxuLy8gICAgICAgICB0aXRsZTogXCJMb2dpblwiLFxyXG4vLyAgICAgICAgIGxpbms6IFwiaHR0cHM6Ly9hcHAuaW50ZXJha3QuYWkvbG9naW5cIixcclxuLy8gICAgICAgICBpY29uOiA8RmFXaGF0c2FwcCBzaXplPXsyMH0gLz4sXHJcbi8vICAgICAgICAgbmV3VGFiOiB0cnVlLFxyXG4vLyAgICAgICB9LFxyXG5cclxuLy8gICAgICAge1xyXG4vLyAgICAgICAgIGtleTogXCIjbWFpbi00XCIsXHJcbi8vICAgICAgICAgdGl0bGU6IFwiRHVlIE1lc3NhZ2VcIixcclxuLy8gICAgICAgICBpY29uOiA8RmFXaGF0c2FwcCBzaXplPXsyMH0gLz4sXHJcbi8vICAgICAgICAgc3ViTWVudXM6IFtcclxuLy8gICAgICAgICAgIHtcclxuLy8gICAgICAgICAgICAga2V5OiBcIiM0XCIsXHJcbi8vICAgICAgICAgICAgIHRpdGxlOiBcIkR1ZVwiLFxyXG4vLyAgICAgICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvZHVlLW1lc3NhZ2VcIixcclxuLy8gICAgICAgICAgICAgaWNvbjogPFJpTW9uZXlSdXBlZUNpcmNsZUxpbmUgc2l6ZT17MjB9IC8+LFxyXG4vLyAgICAgICAgICAgfSxcclxuLy8gICAgICAgICAgIHtcclxuLy8gICAgICAgICAgICAga2V5OiBcIiM2XCIsXHJcbi8vICAgICAgICAgICAgIHRpdGxlOiBcIk92ZXIgRHVlXCIsXHJcbi8vICAgICAgICAgICAgIGxpbms6IFwiL21hcmtldGluZy9vdmVyLWR1ZS1tZXNzYWdlXCIsXHJcbi8vICAgICAgICAgICAgIGljb246IDxSaU1vbmV5UnVwZWVDaXJjbGVMaW5lIHNpemU9ezI4fSAvPixcclxuLy8gICAgICAgICAgIH0sXHJcbi8vICAgICAgICAgXSxcclxuLy8gICAgICAgfSxcclxuLy8gICAgICAge1xyXG4vLyAgICAgICAgIGtleTogXCIjbWFpbi02XCIsXHJcbi8vICAgICAgICAgdGl0bGU6IFwiQXVjdGlvbiBNZXNzYWdlXCIsXHJcbi8vICAgICAgICAgaWNvbjogPEZhV2hhdHNhcHAgc2l6ZT17MjB9IC8+LFxyXG4vLyAgICAgICAgIHN1Yk1lbnVzOiBbXHJcbi8vICAgICAgICAgICB7XHJcbi8vICAgICAgICAga2V5OiBcIiM1XCIsXHJcbi8vICAgICAgICAgdGl0bGU6IFwiQXVjdGlvbiBJbnRpbWF0aW9uIE1lc3NhZ2VcIixcclxuLy8gICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvYXVjdGlvbi1pbnRpbWF0aW9uLW1lc3NhZ2VcIixcclxuLy8gICAgICAgICBpY29uOiA8UmlNb25leVJ1cGVlQ2lyY2xlTGluZSBzaXplPXsyOH0gLz4sXHJcbi8vICAgICAgIH0sXHJcblxyXG4vLyAgICAgICB7XHJcbi8vICAgICAgICAga2V5OiBcIiMxMlwiLFxyXG4vLyAgICAgICAgIHRpdGxlOiBcIkJpZCBXaW5uZXJcIixcclxuLy8gICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvYmlkLXdpbm5lclwiLFxyXG4vLyAgICAgICAgIGljb246IDxSaU1vbmV5UnVwZWVDaXJjbGVMaW5lIHNpemU9ezI4fSAvPixcclxuLy8gICAgICAgfSxcclxuLy8gICAgICAgICBdLFxyXG4vLyAgICAgICB9LFxyXG4vLyAgICAgICB7XHJcbi8vICAgICAgICAga2V5OiBcIiNtYWluLTVcIixcclxuLy8gICAgICAgICB0aXRsZTogXCJQcm9tb1wiLFxyXG4vLyAgICAgICAgIGljb246IDxGYVdoYXRzYXBwIHNpemU9ezIwfSAvPixcclxuLy8gICAgICAgICBzdWJNZW51czogW1xyXG4vLyAgICAgICAgICAge1xyXG4vLyAgICAgICAgIGtleTogXCIjMTFcIixcclxuLy8gICAgICAgICB0aXRsZTogXCJQcm9tb1wiLFxyXG4vLyAgICAgICAgIGxpbms6IFwiL21hcmtldGluZy93aGF0LXByb21vXCIsXHJcbi8vICAgICAgICAgaWNvbjogPEZhV2hhdHNhcHAgc2l6ZT17MjB9IC8+LFxyXG4vLyAgICAgICB9LFxyXG4vLyAgICAgICAgICAge1xyXG4vLyAgICAgICAgIGtleTogXCIjMTFcIixcclxuLy8gICAgICAgICB0aXRsZTogXCJDdXN0b21lciBwcm9tb1wiLFxyXG4vLyAgICAgICAgIGxpbms6IFwiL21hcmtldGluZy93aGF0LWN1c3RvbWVyLXByb21vXCIsXHJcbi8vICAgICAgICAgaWNvbjogPEZhV2hhdHNhcHAgc2l6ZT17MjB9IC8+LFxyXG4vLyAgICAgICB9LFxyXG4vLyAgICAgICAgIF0sXHJcbi8vICAgICAgIH0sXHJcbi8vICAgICBdLFxyXG4vLyAgIH0sXHJcbi8vICAge1xyXG4vLyAgICAga2V5OiBcIiNtYWluLTJcIixcclxuLy8gICAgIHRpdGxlOiBcIkVtYWlsIE1hcmtldGluZ1wiLFxyXG4vLyAgICAgaWNvbjogPE1kRW1haWwgc2l6ZT17MjB9IC8+LFxyXG4vLyAgICAgc3ViTWVudXM6IFtcclxuLy8gICAgICAge1xyXG4vLyAgICAgICAgIGtleTogXCIjN1wiLFxyXG4vLyAgICAgICAgIHRpdGxlOiBcIiBEdWUgRW1haWwgXCIsXHJcbi8vICAgICAgICAgbGluazogXCIvbWFya2V0aW5nL2R1ZS1lbWFpbFwiLFxyXG4vLyAgICAgICAgIGljb246IDxSaU1vbmV5UnVwZWVDaXJjbGVMaW5lIHNpemU9ezIwfSAvPixcclxuLy8gICAgICAgfSxcclxuLy8gICAgICAge1xyXG4vLyAgICAgICAgIGtleTogXCIjOFwiLFxyXG4vLyAgICAgICAgIHRpdGxlOiBcIk92ZXIgRHVlIEVtYWlsXCIsXHJcbi8vICAgICAgICAgbGluazogXCIvbWFya2V0aW5nL292ZXItZHVlLWVtYWlsXCIsXHJcbi8vICAgICAgICAgaWNvbjogPFJpTW9uZXlSdXBlZUNpcmNsZUxpbmUgc2l6ZT17MjB9IC8+LFxyXG4vLyAgICAgICB9LFxyXG4vLyAgICAgXSxcclxuLy8gICB9LFxyXG4vLyAgIHtcclxuLy8gICAgIGtleTogXCIjbWFpbi0zXCIsXHJcbi8vICAgICB0aXRsZTogXCJTTVMgTWFya2V0aW5nXCIsXHJcbi8vICAgICBpY29uOiA8TGlhU21zU29saWQgc2l6ZT17MjB9IC8+LFxyXG4vLyAgICAgc3ViTWVudXM6IFtcclxuLy8gICAgICAge1xyXG4vLyAgICAgICAgIGtleTogXCIjOVwiLFxyXG4vLyAgICAgICAgIHRpdGxlOiBcIiBEdWUgU01TIE1lc3NhZ2UgXCIsXHJcbi8vICAgICAgICAgbGluazogXCIvbWFya2V0aW5nL2R1ZS1zbXNcIixcclxuLy8gICAgICAgICBpY29uOiA8UmlNb25leVJ1cGVlQ2lyY2xlTGluZSBzaXplPXsyMH0gLz4sXHJcbi8vICAgICAgIH0sXHJcbi8vICAgICAgIHtcclxuLy8gICAgICAgICBrZXk6IFwiIzEwXCIsXHJcbi8vICAgICAgICAgdGl0bGU6IFwiT3ZlciBEdWUgU01TIE1lc3NhZ2VcIixcclxuLy8gICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvb3Zlci1kdWUtc21zXCIsXHJcbi8vICAgICAgICAgaWNvbjogPFJpTW9uZXlSdXBlZUNpcmNsZUxpbmUgc2l6ZT17Mjh9IC8+LFxyXG4vLyAgICAgICB9LFxyXG4vLyAgICAgXSxcclxuLy8gICB9LFxyXG4vLyBdO1xyXG5cclxuLy8gY29uc3QgTWFya2V0aW5nID0gKCkgPT4ge1xyXG4vLyAgIGNvbnN0IFtvcGVuTWVudUluZGV4LCBzZXRPcGVuTWVudUluZGV4XSA9IHVzZVN0YXRlKG51bGwpO1xyXG5cclxuLy8gICBjb25zdCB0b2dnbGVNZW51ID0gKGluZGV4KSA9PiB7XHJcbi8vICAgICBzZXRPcGVuTWVudUluZGV4KChwcmV2SW5kZXgpID0+IChwcmV2SW5kZXggPT09IGluZGV4ID8gbnVsbCA6IGluZGV4KSk7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgcmV0dXJuIChcclxuLy8gICAgIDxkaXYgY2xhc3NOYW1lPVwidy1zY3JlZW4gZmxleCBtdC0yMFwiPlxyXG4vLyAgICAgICA8U2lkZWJhciAvPlxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtc2NyZWVuXCI+XHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LVszMDBweF0gYmctZ3JheS01MCBtaW4taC1zY3JlZW4gcC00IHNwYWNlLXktNFwiPlxyXG4vLyAgICAgICAgICAge21haW5NZW51cy5tYXAoKG1lbnUsIGluZGV4KSA9PiB7XHJcbi8vICAgICAgICAgICAgIGNvbnN0IGlzT3BlbiA9IG9wZW5NZW51SW5kZXggPT09IGluZGV4O1xyXG4vLyAgICAgICAgICAgICByZXR1cm4gKFxyXG4vLyAgICAgICAgICAgICAgIDxGcmFnbWVudCBrZXk9e21lbnUua2V5fT5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlTWVudShpbmRleCl9XHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXZpb2xldC05MDAgcHgtMiBweS0yIGN1cnNvci1wb2ludGVyIGhvdmVyOm9wYWNpdHktODAgcm91bmRlZC1tZCB0cmFuc2l0aW9uXCJcclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAge21lbnUuaWNvbn1cclxuLy8gICAgICAgICAgICAgICAgICAge21lbnUudGl0bGV9XHJcbi8vICAgICAgICAgICAgICAgICAgIHttZW51LnN1Yk1lbnVzICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC1hdXRvXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB7aXNPcGVuID8gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8QWlPdXRsaW5lTWludXMgY2xhc3NOYW1lPVwidGV4dC1zbVwiIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8QWlPdXRsaW5lUGx1cyBjbGFzc05hbWU9XCJ0ZXh0LXNtXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICApfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgey8qIFN1Ym1lbnVzICovfVxyXG4vLyAgICAgICAgICAgICAgICAge2lzT3BlbiAmJiBtZW51LnN1Yk1lbnVzICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cIm1sLTUgbXQtMiBzcGFjZS15LTFcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7bWVudS5zdWJNZW51cy5tYXAoKHN1Ym1lbnUpID0+IChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e3N1Ym1lbnUua2V5fT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPE5hdkxpbmtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17c3VibWVudS5saW5rfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD17c3VibWVudS5uZXdUYWIgPyBcIl9ibGFua1wiIDogXCJfc2VsZlwifVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBwLTIgcm91bmRlZC1tZCB0cmFuc2l0aW9uIGZvbnQtbWVkaXVtICR7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1Ym1lbnUucmVkID8gXCJ0ZXh0LXJlZC03MDBcIiA6IFwidGV4dC12aW9sZXQtOTUwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gJHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNBY3RpdmVcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctdmlvbGV0LTEwMCBib3JkZXItbC00IGJvcmRlci12aW9sZXQtNDAwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiaG92ZXI6YmctZ3JheS0yMDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWBcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB7c3VibWVudS5pY29ufVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdWJtZW51LnRpdGxlfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8L05hdkxpbms+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L2xpPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4vLyAgICAgICAgICAgICAgICAgICA8L3VsPlxyXG4vLyAgICAgICAgICAgICAgICAgKX1cclxuLy8gICAgICAgICAgICAgICA8L0ZyYWdtZW50PlxyXG4vLyAgICAgICAgICAgICApO1xyXG4vLyAgICAgICAgICAgfSl9XHJcbi8vICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGJnLXdoaXRlIHAtNlwiPlxyXG4vLyAgICAgICAgICAgPE91dGxldCAvPlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgIDwvZGl2PlxyXG4vLyAgICk7XHJcbi8vIH07XHJcbi8vIGNvbnN0IG1haW5NZW51cyA9IFtcclxuLy8gICB7XHJcbi8vICAgICBrZXk6IFwiI21haW4tMVwiLFxyXG4vLyAgICAgdGl0bGU6IFwiV2hhdHNhcHAgTWFya2V0aW5nXCIsXHJcbi8vICAgICBpY29uOiA8RmFXaGF0c2FwcCBzaXplPXsyMH0gLz4sXHJcbi8vICAgICBzdWJNZW51czogW1xyXG4vLyAgICAgICB7XHJcbi8vICAgICAgICAga2V5OiBcIiMxXCIsXHJcbi8vICAgICAgICAgdGl0bGU6IFwiTG9naW5cIixcclxuLy8gICAgICAgICBsaW5rOiBcImh0dHBzOi8vYXBwLmludGVyYWt0LmFpL2xvZ2luXCIsXHJcbi8vICAgICAgICAgaWNvbjogPEZhV2hhdHNhcHAgc2l6ZT17MjB9IC8+LFxyXG4vLyAgICAgICAgIG5ld1RhYjogdHJ1ZSxcclxuLy8gICAgICAgfSxcclxuLy8gICAgICAge1xyXG4vLyAgICAgICAgIGtleTogXCIjbWFpbi00XCIsXHJcbi8vICAgICAgICAgdGl0bGU6IFwiRHVlIE1lc3NhZ2VcIixcclxuLy8gICAgICAgICBpY29uOiA8RmFXaGF0c2FwcCBzaXplPXsyMH0gLz4sXHJcbi8vICAgICAgICAgc3ViTWVudXM6IFtcclxuLy8gICAgICAgICAgIHtcclxuLy8gICAgICAgICAgICAga2V5OiBcIiM0XCIsXHJcbi8vICAgICAgICAgICAgIHRpdGxlOiBcIkR1ZVwiLFxyXG4vLyAgICAgICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvZHVlLW1lc3NhZ2VcIixcclxuLy8gICAgICAgICAgICAgaWNvbjogPFJpTW9uZXlSdXBlZUNpcmNsZUxpbmUgc2l6ZT17MjJ9IC8+LFxyXG4vLyAgICAgICAgICAgfSxcclxuLy8gICAgICAgICAgIHtcclxuLy8gICAgICAgICAgICAga2V5OiBcIiM2XCIsXHJcbi8vICAgICAgICAgICAgIHRpdGxlOiBcIk92ZXJkdWVcIixcclxuLy8gICAgICAgICAgICAgbGluazogXCIvbWFya2V0aW5nL292ZXItZHVlLW1lc3NhZ2VcIixcclxuLy8gICAgICAgICAgICAgaWNvbjogPFJpTW9uZXlSdXBlZUNpcmNsZUxpbmUgc2l6ZT17MjJ9IC8+LFxyXG4vLyAgICAgICAgICAgfSxcclxuLy8gICAgICAgICAgICxcclxuICAgICAgICAgXHJcbiAgICAgICAgICBcclxuLy8gICAgICAgICBdLFxyXG4vLyAgICAgICB9LFxyXG4vLyAgICAgICAge1xyXG4vLyAgICAgICAgIGtleTogXCIjbWFpbi03XCIsXHJcbi8vICAgICAgICAgdGl0bGU6IFwiTGVhZCBXaGF0c2FwcCBNZXNzYWdlXCIsXHJcbi8vICAgICAgICAgaWNvbjogPEZhV2hhdHNhcHAgc2l6ZT17MjB9IC8+LFxyXG4vLyAgICAgICAgIHN1Yk1lbnVzOiBbXHJcbi8vICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgIGtleTogXCIjMjBcIixcclxuLy8gICAgICAgICAgICAgdGl0bGU6IFwiV2VsY29tZSBNZXNzYWdlXCIsXHJcbi8vICAgICAgICAgICAgIGxpbms6IFwiL21hcmtldGluZy9sZWFkLXdlbGNvbWUtbWVzc2FnZVwiLFxyXG4vLyAgICAgICAgICAgICBpY29uOiA8UmlNb25leVJ1cGVlQ2lyY2xlTGluZSBzaXplPXsyMn0gLz4sXHJcbi8vICAgICAgICAgICB9LFxyXG4vLyAgICAgICAgICAge1xyXG4vLyAgICAgICAgICAgICBrZXk6IFwiIzIxXCIsXHJcbi8vICAgICAgICAgICAgIHRpdGxlOiBcIlJlZmVycmVkQnkgTWVzc2FnZVwiLFxyXG4vLyAgICAgICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvbGVhZC1yZWZlcnJlZGJ5LW1lc3NhZ2VcIixcclxuLy8gICAgICAgICAgICAgaWNvbjogPFJpTW9uZXlSdXBlZUNpcmNsZUxpbmUgc2l6ZT17MjJ9IC8+LFxyXG4vLyAgICAgICAgICAgfSxcclxuLy8gICAgICAgICAgICxcclxuICAgICAgICAgXHJcbiAgICAgICAgICBcclxuLy8gICAgICAgICBdLFxyXG4vLyAgICAgICB9LFxyXG4vLyAgICAgICAge1xyXG4vLyAgICAgICAgIGtleTogXCIjbWFpbi04XCIsXHJcbi8vICAgICAgICAgdGl0bGU6IFwiQ3VzdG9tZXIgV2hhdHNhcHAgTWVzc2FnZVwiLFxyXG4vLyAgICAgICAgIGljb246IDxGYVdoYXRzYXBwIHNpemU9ezIwfSAvPixcclxuLy8gICAgICAgICBzdWJNZW51czogW1xyXG4vLyAgICAgICAgICAge1xyXG4vLyAgICAgICAgICAgICBrZXk6IFwiIzIwXCIsXHJcbi8vICAgICAgICAgICAgIHRpdGxlOiBcIldlbGNvbWUgTWVzc2FnZVwiLFxyXG4vLyAgICAgICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvY3VzdG9tZXItd2VsY29tZS1tZXNzYWdlXCIsXHJcbi8vICAgICAgICAgICAgIGljb246IDxSaU1vbmV5UnVwZWVDaXJjbGVMaW5lIHNpemU9ezIyfSAvPixcclxuLy8gICAgICAgICAgIH0sXHJcbi8vICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgIGtleTogXCIjMjFcIixcclxuLy8gICAgICAgICAgICAgdGl0bGU6IFwiQ2hpdFBsYW4gTWVzc2FnZVwiLFxyXG4vLyAgICAgICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvY3VzdG9tZXItY2hpdHBsYW4tbWVzc2FnZVwiLFxyXG4vLyAgICAgICAgICAgICBpY29uOiA8UmlNb25leVJ1cGVlQ2lyY2xlTGluZSBzaXplPXsyMn0gLz4sXHJcbi8vICAgICAgICAgICB9LFxyXG4vLyAgICAgICAgICAgLFxyXG4gICAgICAgICBcclxuICAgICAgICAgIFxyXG4vLyAgICAgICAgIF0sXHJcbi8vICAgICAgIH0sXHJcbi8vICAgICAgIHtcclxuLy8gICAgICAgICBrZXk6IFwiI21haW4tNlwiLFxyXG4vLyAgICAgICAgIHRpdGxlOiBcIkF1Y3Rpb24gTWVzc2FnZVwiLFxyXG4vLyAgICAgICAgIGljb246IDxGYVdoYXRzYXBwIHNpemU9ezIwfSAvPixcclxuLy8gICAgICAgICBzdWJNZW51czogW1xyXG4vLyAgICAgICAgICAge1xyXG4vLyAgICAgICAgICAgICBrZXk6IFwiIzVcIixcclxuLy8gICAgICAgICAgICAgdGl0bGU6IFwiQXVjdGlvbiBJbnRpbWF0aW9uIE1lc3NhZ2VcIixcclxuLy8gICAgICAgICAgICAgbGluazogXCIvbWFya2V0aW5nL2F1Y3Rpb24taW50aW1hdGlvbi1tZXNzYWdlXCIsXHJcbi8vICAgICAgICAgICAgIGljb246IDxSaU1vbmV5UnVwZWVDaXJjbGVMaW5lIHNpemU9ezIyfSAvPixcclxuLy8gICAgICAgICAgIH0sXHJcbi8vICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgIGtleTogXCIjMTJcIixcclxuLy8gICAgICAgICAgICAgdGl0bGU6IFwiQmlkIFdpbm5lclwiLFxyXG4vLyAgICAgICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvYmlkLXdpbm5lclwiLFxyXG4vLyAgICAgICAgICAgICBpY29uOiA8UmlNb25leVJ1cGVlQ2lyY2xlTGluZSBzaXplPXsyMn0gLz4sXHJcbi8vICAgICAgICAgICB9LFxyXG4vLyAgICAgICAgICAge1xyXG4vLyAgICAgICAgICAgICBrZXk6IFwiIzE4XCIsXHJcbi8vICAgICAgICAgICAgIHRpdGxlOiBcIkF1Y3Rpb24gQmlkIHN0YXR1c1wiLFxyXG4vLyAgICAgICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvYmlkLXN0YXR1c1wiLFxyXG4vLyAgICAgICAgICAgICBpY29uOiA8UmlNb25leVJ1cGVlQ2lyY2xlTGluZSBzaXplPXsyMn0gLz4sXHJcbi8vICAgICAgICAgICB9LFxyXG4vLyAgICAgICAgICAge1xyXG4vLyAgICAgICAgICAgICBrZXk6IFwiIzE5XCIsXHJcbi8vICAgICAgICAgICAgIHRpdGxlOiBcIkJpZCBXaW5uZXIgRG9jdW1lbnQgTGlzdFwiLFxyXG4vLyAgICAgICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvd2lubmVyLWRvY3VtZW50XCIsXHJcbi8vICAgICAgICAgICAgIGljb246IDxSaU1vbmV5UnVwZWVDaXJjbGVMaW5lIHNpemU9ezIyfSAvPixcclxuLy8gICAgICAgICAgIH0sXHJcbi8vICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgIGtleTogXCIjMjBcIixcclxuLy8gICAgICAgICAgICAgdGl0bGU6IFwiQXVjdGlvbiBpbmZvcm1hdGlvblwiLFxyXG4vLyAgICAgICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvYXVjdGlvbi1pbmZvXCIsXHJcbi8vICAgICAgICAgICAgIGljb246IDxSaU1vbmV5UnVwZWVDaXJjbGVMaW5lIHNpemU9ezIyfSAvPixcclxuLy8gICAgICAgICAgIH0sXHJcbi8vICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgIGtleTogXCIjMjFcIixcclxuLy8gICAgICAgICAgICAgdGl0bGU6IFwiQXVjdGlvbiBUZXJtcyBhbmQgQ29uZGl0aW9uXCIsXHJcbi8vICAgICAgICAgICAgIGxpbms6IFwiL21hcmtldGluZy9hdWN0aW9uLXRlcm1zLWNvbmRpdGlvblwiLFxyXG4vLyAgICAgICAgICAgICBpY29uOiA8UmlNb25leVJ1cGVlQ2lyY2xlTGluZSBzaXplPXsyMn0gLz4sXHJcbi8vICAgICAgICAgICB9LFxyXG5cclxuLy8gICAgICAgICBdLFxyXG4vLyAgICAgICB9LFxyXG4vLyAgICAgICB7XHJcbi8vICAgICAgICAga2V5OiBcIiNtYWluLTVcIixcclxuLy8gICAgICAgICB0aXRsZTogXCJQcm9tb3Rpb25cIixcclxuLy8gICAgICAgICBpY29uOiA8RmFXaGF0c2FwcCBzaXplPXsyMH0gLz4sXHJcbi8vICAgICAgICAgc3ViTWVudXM6IFtcclxuLy8gICAgICAgICAgIHtcclxuLy8gICAgICAgICAgICAga2V5OiBcIiMxMVwiLFxyXG4vLyAgICAgICAgICAgICB0aXRsZTogXCJQcm9tb1wiLFxyXG4vLyAgICAgICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvd2hhdC1wcm9tb1wiLFxyXG4vLyAgICAgICAgICAgICBpY29uOiA8RmFXaGF0c2FwcCBzaXplPXsyMH0gLz4sXHJcbi8vICAgICAgICAgICB9LFxyXG4vLyAgICAgICAgICAgLy8ge1xyXG4vLyAgICAgICAgICAgLy8gICBrZXk6IFwiIzExXCIsXHJcbi8vICAgICAgICAgICAvLyAgIHRpdGxlOiBcIkN1c3RvbWVyIFByb21vXCIsXHJcbi8vICAgICAgICAgICAvLyAgIGxpbms6IFwiL21hcmtldGluZy93aGF0LWN1c3RvbWVyLXByb21vXCIsXHJcbi8vICAgICAgICAgICAvLyAgIGljb246IDxGYVdoYXRzYXBwIHNpemU9ezIwfSAvPixcclxuLy8gICAgICAgICAgIC8vICAgRXhhbXBsZSBvZiBzdWItc3VibWVudVxyXG4vLyAgICAgICAgICAgLy8gICBzdWJNZW51czogW1xyXG4vLyAgICAgICAgICAgLy8gICAgIHtcclxuLy8gICAgICAgICAgIC8vICAgICAgIGtleTogXCIjMTEtMVwiLFxyXG4vLyAgICAgICAgICAgLy8gICAgICAgdGl0bGU6IFwiU3BlY2lhbCBQcm9tb1wiLFxyXG4vLyAgICAgICAgICAgLy8gICAgICAgbGluazogXCIvbWFya2V0aW5nL3NwZWNpYWwtcHJvbW9cIixcclxuLy8gICAgICAgICAgIC8vICAgICAgIGljb246IDxGYVdoYXRzYXBwIHNpemU9ezE4fSAvPixcclxuLy8gICAgICAgICAgIC8vICAgICB9LFxyXG4vLyAgICAgICAgICAgLy8gICAgIHtcclxuLy8gICAgICAgICAgIC8vICAgICAgIGtleTogXCIjMTEtMlwiLFxyXG4vLyAgICAgICAgICAgLy8gICAgICAgdGl0bGU6IFwiRmVzdGl2YWwgUHJvbW9cIixcclxuLy8gICAgICAgICAgIC8vICAgICAgIGxpbms6IFwiL21hcmtldGluZy9mZXN0aXZhbC1wcm9tb1wiLFxyXG4vLyAgICAgICAgICAgLy8gICAgICAgaWNvbjogPEZhV2hhdHNhcHAgc2l6ZT17MTh9IC8+LFxyXG4vLyAgICAgICAgICAgLy8gICAgIH0sXHJcbi8vICAgICAgICAgICAvLyAgIF0sXHJcbi8vICAgICAgICAgICAvLyB9LFxyXG4vLyAgICAgICAgIF0sXHJcbi8vICAgICAgIH0sXHJcbi8vICAgICBdLFxyXG4vLyAgIH0sXHJcbi8vICAge1xyXG4vLyAgICAga2V5OiBcIiNtYWluLTJcIixcclxuLy8gICAgIHRpdGxlOiBcIkVtYWlsIE1hcmtldGluZ1wiLFxyXG4vLyAgICAgaWNvbjogPE1kRW1haWwgc2l6ZT17MjB9IC8+LFxyXG4vLyAgICAgc3ViTWVudXM6IFtcclxuLy8gICAgICAge1xyXG4vLyAgICAgICAgIGtleTogXCIjbWFpbi0xMFwiLFxyXG4vLyAgICAgICAgIHRpdGxlOiBcIkR1ZSBFbWFpbFwiLFxyXG4vLyAgICAgICAgIGljb246IDxNZEVtYWlsIHNpemU9ezIwfSAvPixcclxuLy8gICAgICAgICBzdWJNZW51czogW1xyXG4vLyAgICAgICAgICAge1xyXG4vLyAgICAgICAgICAgICBrZXk6IFwiIzE1XCIsXHJcbi8vICAgICAgICAgICAgIHRpdGxlOiBcIkR1ZVwiLFxyXG4vLyAgICAgICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvZHVlLWVtYWlsXCIsXHJcbi8vICAgICAgICAgICAgIGljb246IDxSaU1vbmV5UnVwZWVDaXJjbGVMaW5lIHNpemU9ezIyfSAvPixcclxuLy8gICAgICAgICAgIH0sXHJcbi8vICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgIGtleTogXCIjMTZcIixcclxuLy8gICAgICAgICAgICAgdGl0bGU6IFwiT3ZlcmR1ZVwiLFxyXG4vLyAgICAgICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvb3Zlci1kdWUtZW1haWxcIixcclxuLy8gICAgICAgICAgICAgaWNvbjogPFJpTW9uZXlSdXBlZUNpcmNsZUxpbmUgc2l6ZT17MjJ9IC8+LFxyXG4vLyAgICAgICAgICAgfSxcclxuLy8gICAgICAgICBdLFxyXG4vLyAgICAgICB9LFxyXG4gICAgICBcclxuLy8gICAgIF0sXHJcbi8vICAgfSxcclxuICBcclxuLy8gICB7XHJcbi8vICAgICBrZXk6IFwiI21haW4tM1wiLFxyXG4vLyAgICAgdGl0bGU6IFwiUGF5bWVudCBMaW5rc1wiLFxyXG4vLyAgICAgaWNvbjogPFJpTW9uZXlSdXBlZUNpcmNsZUxpbmUgc2l6ZT17MjB9IC8+LFxyXG4vLyAgICAgc3ViTWVudXM6IFtcclxuLy8gICAgICAgIHtcclxuLy8gICAgICAgICAgICAga2V5OiBcIiM3XCIsXHJcbi8vICAgICAgICAgICAgIHRpdGxlOiBcIlBheW1lbnQgTGlua1wiLFxyXG4vLyAgICAgICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvcGF5bWVudC1saW5rXCIsXHJcbi8vICAgICAgICAgICAgIGljb246IDxSaU1vbmV5UnVwZWVDaXJjbGVMaW5lIHNpemU9ezIyfSAvPixcclxuLy8gICAgICAgICAgIH0sXHJcbiAgICAgIFxyXG4vLyAgICAgXSxcclxuLy8gICB9LFxyXG4vLyBdO1xyXG5cclxuLy8gY29uc3QgTWFya2V0aW5nID0gKCkgPT4ge1xyXG4vLyAgIGNvbnN0IFtvcGVuTWVudSwgc2V0T3Blbk1lbnVdID0gdXNlU3RhdGUoe30pO1xyXG5cclxuLy8gICBjb25zdCB0b2dnbGVNZW51ID0gKG1lbnVLZXkpID0+IHtcclxuLy8gICAgIHNldE9wZW5NZW51KChwcmV2KSA9PiAoe1xyXG4vLyAgICAgICAuLi5wcmV2LFxyXG4vLyAgICAgICBbbWVudUtleV06ICFwcmV2W21lbnVLZXldLFxyXG4vLyAgICAgfSkpO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8vIOKchSBSZWN1cnNpdmUgbWVudSByZW5kZXJpbmcgZnVuY3Rpb25cclxuLy8gICBjb25zdCByZW5kZXJNZW51ID0gKG1lbnVzLCBsZXZlbCA9IDApID0+IHtcclxuLy8gICAgIHJldHVybiAoXHJcbi8vICAgICAgIDx1bCBjbGFzc05hbWU9e2xldmVsID4gMCA/IFwibWwtNSBtdC0yIHNwYWNlLXktMVwiIDogXCJcIn0+XHJcbi8vICAgICAgICAge21lbnVzLm1hcCgobWVudSkgPT4ge1xyXG4vLyAgICAgICAgICAgY29uc3QgaGFzU3ViTWVudSA9IG1lbnUuc3ViTWVudXMgJiYgbWVudS5zdWJNZW51cy5sZW5ndGggPiAwO1xyXG4vLyAgICAgICAgICAgY29uc3QgaXNPcGVuID0gb3Blbk1lbnVbbWVudS5rZXldO1xyXG5cclxuLy8gICAgICAgICAgIHJldHVybiAoXHJcbi8vICAgICAgICAgICAgIDxGcmFnbWVudCBrZXk9e21lbnUua2V5fT5cclxuLy8gICAgICAgICAgICAgICA8bGk+XHJcbi8vICAgICAgICAgICAgICAgICB7bWVudS5saW5rID8gKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8TmF2TGlua1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIHRvPXttZW51Lmxpbmt9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PXttZW51Lm5ld1RhYiA/IFwiX2JsYW5rXCIgOiBcIl9zZWxmXCJ9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgYGZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHAtMiByb3VuZGVkLW1kIHRyYW5zaXRpb24gZm9udC1tZWRpdW0gY3Vyc29yLXBvaW50ZXIgXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAke2lzQWN0aXZlID8gXCJiZy12aW9sZXQtNTAwIHRleHQtd2hpdGVcIiA6IFwiaG92ZXI6YmctZ3JheS0yMDAgdGV4dC12aW9sZXQtOTUwXCJ9YFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHttZW51Lmljb259XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e21lbnUudGl0bGV9PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L05hdkxpbms+XHJcbi8vICAgICAgICAgICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbi8vICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFzU3ViTWVudSAmJiB0b2dnbGVNZW51KG1lbnUua2V5KX1cclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBwLTIgcm91bmRlZC1tZCB0cmFuc2l0aW9uIGZvbnQtbWVkaXVtIGN1cnNvci1wb2ludGVyIFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICR7aXNPcGVuID8gXCJiZy1ncmF5LTEwMCB0ZXh0LXZpb2xldC05NTBcIiA6IFwiaG92ZXI6YmctZ3JheS0yMDAgdGV4dC12aW9sZXQtOTUwXCJ9YH1cclxuLy8gICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHttZW51Lmljb259XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e21lbnUudGl0bGV9PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtoYXNTdWJNZW51ICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLWF1dG9cIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAge2lzT3BlbiA/IDxBaU91dGxpbmVNaW51cyAvPiA6IDxBaU91dGxpbmVQbHVzIC8+fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgKX1cclxuXHJcbi8vICAgICAgICAgICAgICAgICB7aGFzU3ViTWVudSAmJiBpc09wZW4gJiYgcmVuZGVyTWVudShtZW51LnN1Yk1lbnVzLCBsZXZlbCArIDEpfVxyXG4vLyAgICAgICAgICAgICAgIDwvbGk+XHJcbi8vICAgICAgICAgICAgIDwvRnJhZ21lbnQ+XHJcbi8vICAgICAgICAgICApO1xyXG4vLyAgICAgICAgIH0pfVxyXG4vLyAgICAgICA8L3VsPlxyXG4vLyAgICAgKTtcclxuLy8gICB9O1xyXG5cclxuLy8gICByZXR1cm4gKFxyXG4vLyAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LXNjcmVlbiBmbGV4IG10LTIwXCI+XHJcbi8vICAgICAgIDxTaWRlYmFyIC8+XHJcbi8vICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4taC1zY3JlZW5cIj5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctWzMwMHB4XSBiZy1ncmF5LTUwIG1pbi1oLXNjcmVlbiBwLTQgc3BhY2UteS00XCI+XHJcbi8vICAgICAgICAgICB7cmVuZGVyTWVudShtYWluTWVudXMpfVxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBiZy13aGl0ZSBwLTZcIj5cclxuLy8gICAgICAgICAgIDxPdXRsZXQgLz5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICA8L2Rpdj5cclxuLy8gICApO1xyXG4vLyB9O1xyXG5cclxuXHJcblxyXG4vLyBpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG4vLyBpbXBvcnQgeyBOYXZMaW5rLCBPdXRsZXQsIHVzZUxvY2F0aW9uIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHtcclxuICBGYVdoYXRzYXBwLFxyXG4gIEZhQ2hldnJvbkRvd24sXHJcbiAgRmFDaGV2cm9uUmlnaHQsXHJcbiAgRmFFeHRlcm5hbExpbmtBbHQsXHJcbiAgRmFTcGlubmVyXHJcbn0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IE1kRW1haWwgfSBmcm9tIFwicmVhY3QtaWNvbnMvbWRcIjtcclxuaW1wb3J0IHsgUmlNb25leVJ1cGVlQ2lyY2xlTGluZSB9IGZyb20gXCJyZWFjdC1pY29ucy9yaVwiO1xyXG4vLyBpbXBvcnQgU2lkZWJhciBmcm9tIFwiLi9TaWRlYmFyXCI7XHJcblxyXG5jb25zdCBtYWluTWVudXMgPSBbXHJcbiAge1xyXG4gICAga2V5OiBcIndoYXRzYXBwXCIsXHJcbiAgICB0aXRsZTogXCJXaGF0c2FwcCBNYXJrZXRpbmdcIixcclxuICAgIGljb246IDxGYVdoYXRzYXBwIHNpemU9ezIwfSAvPixcclxuICAgIGNvbG9yOiBcIiMyNUQzNjZcIixcclxuICAgIHN1Yk1lbnVzOiBbXHJcbiAgICAgIHtcclxuICAgICAgICB0aXRsZTogXCJMb2dpblwiLFxyXG4gICAgICAgIGxpbms6IFwiaHR0cHM6Ly9hcHAuaW50ZXJha3QuYWkvbG9naW5cIixcclxuICAgICAgICBuZXdUYWI6IHRydWUsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IFwiQWNjZXNzIHlvdXIgSW50ZXJha3QgZGFzaGJvYXJkXCJcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgIHRpdGxlOiBcIkR1ZSBNZXNzYWdlXCIsXHJcbiAgICAgICAgc3ViTWVudXM6IFtcclxuICAgICAgICAgIHsgXHJcbiAgICAgICAgICAgIHRpdGxlOiBcIkR1ZVwiLCBcclxuICAgICAgICAgICAgbGluazogXCIvbWFya2V0aW5nL2R1ZS1tZXNzYWdlXCIsXHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlNlbmQgZHVlIHBheW1lbnQgcmVtaW5kZXJzXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7IFxyXG4gICAgICAgICAgICB0aXRsZTogXCJPdmVyZHVlXCIsIFxyXG4gICAgICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvb3Zlci1kdWUtbWVzc2FnZVwiLFxyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJOb3RpZnkgYWJvdXQgb3ZlcmR1ZSBwYXltZW50c1wiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIF0sXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICB0aXRsZTogXCJMZWFkIFdoYXRzYXBwIE1lc3NhZ2VcIixcclxuICAgICAgICBzdWJNZW51czogW1xyXG4gICAgICAgICAgeyBcclxuICAgICAgICAgICAgdGl0bGU6IFwiV2VsY29tZSBNZXNzYWdlXCIsIFxyXG4gICAgICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvbGVhZC13ZWxjb21lLW1lc3NhZ2VcIixcclxuICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiU2VuZCB3ZWxjb21lIG1lc3NhZ2VzIHRvIG5ldyBsZWFkc1wiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgeyBcclxuICAgICAgICAgICAgdGl0bGU6IFwiUmVmZXJyZWRCeSBNZXNzYWdlXCIsIFxyXG4gICAgICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvbGVhZC1yZWZlcnJlZGJ5LW1lc3NhZ2VcIixcclxuICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiTm90aWZ5IGxlYWRzIGFib3V0IHJlZmVycmFsc1wiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIF0sXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICB0aXRsZTogXCJDdXN0b21lciBXaGF0c2FwcCBNZXNzYWdlXCIsXHJcbiAgICAgICAgc3ViTWVudXM6IFtcclxuICAgICAgICAgIHsgXHJcbiAgICAgICAgICAgIHRpdGxlOiBcIldlbGNvbWUgTWVzc2FnZVwiLCBcclxuICAgICAgICAgICAgbGluazogXCIvbWFya2V0aW5nL2N1c3RvbWVyLXdlbGNvbWUtbWVzc2FnZVwiLFxyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJXZWxjb21lIG5ldyBjdXN0b21lcnNcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHsgXHJcbiAgICAgICAgICAgIHRpdGxlOiBcIkNoaXRQbGFuIE1lc3NhZ2VcIiwgXHJcbiAgICAgICAgICAgIGxpbms6IFwiL21hcmtldGluZy9jdXN0b21lci1jaGl0cGxhbi1tZXNzYWdlXCIsXHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlNlbmQgY2hpdCBwbGFuIGluZm9ybWF0aW9uXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgXSxcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgIHRpdGxlOiBcIkF1Y3Rpb24gTWVzc2FnZVwiLFxyXG4gICAgICAgIHN1Yk1lbnVzOiBbXHJcbiAgICAgICAgICB7IFxyXG4gICAgICAgICAgICB0aXRsZTogXCJBdWN0aW9uIEludGltYXRpb25cIiwgXHJcbiAgICAgICAgICAgIGxpbms6IFwiL21hcmtldGluZy9hdWN0aW9uLWludGltYXRpb24tbWVzc2FnZVwiLFxyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJOb3RpZnkgYWJvdXQgdXBjb21pbmcgYXVjdGlvbnNcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHsgXHJcbiAgICAgICAgICAgIHRpdGxlOiBcIkJpZCBXaW5uZXJcIiwgXHJcbiAgICAgICAgICAgIGxpbms6IFwiL21hcmtldGluZy9iaWQtd2lubmVyXCIsXHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIk5vdGlmeSBhdWN0aW9uIHdpbm5lcnNcIlxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHsgXHJcbiAgICAgICAgICAgIHRpdGxlOiBcIkJpZCBTdGF0dXNcIiwgXHJcbiAgICAgICAgICAgIGxpbms6IFwiL21hcmtldGluZy9iaWQtc3RhdHVzXCIsXHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlVwZGF0ZSBiaWQgc3RhdHVzXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7IFxyXG4gICAgICAgICAgICB0aXRsZTogXCJXaW5uZXIgRG9jdW1lbnRzXCIsIFxyXG4gICAgICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvd2lubmVyLWRvY3VtZW50XCIsXHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlJlcXVlc3QgZG9jdW1lbnRzIGZyb20gd2lubmVyc1wiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgeyBcclxuICAgICAgICAgICAgdGl0bGU6IFwiQXVjdGlvbiBJbmZvXCIsIFxyXG4gICAgICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvYXVjdGlvbi1pbmZvXCIsXHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlByb3ZpZGUgYXVjdGlvbiBkZXRhaWxzXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7IFxyXG4gICAgICAgICAgICB0aXRsZTogXCJUZXJtcyAmIENvbmRpdGlvbnNcIiwgXHJcbiAgICAgICAgICAgIGxpbms6IFwiL21hcmtldGluZy9hdWN0aW9uLXRlcm1zLWNvbmRpdGlvblwiLFxyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJTaGFyZSBhdWN0aW9uIHRlcm1zXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgXSxcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgIHRpdGxlOiBcIlByb21vdGlvblwiLFxyXG4gICAgICAgIHN1Yk1lbnVzOiBbXHJcbiAgICAgICAgICB7IFxyXG4gICAgICAgICAgICB0aXRsZTogXCJQcm9tb1wiLCBcclxuICAgICAgICAgICAgbGluazogXCIvbWFya2V0aW5nL3doYXQtcHJvbW9cIixcclxuICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiU2VuZCBwcm9tb3Rpb25hbCBtZXNzYWdlc1wiXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIF0sXHJcbiAgICAgIH0sXHJcbiAgICBdLFxyXG4gIH0sXHJcbiAge1xyXG4gICAga2V5OiBcImVtYWlsXCIsXHJcbiAgICB0aXRsZTogXCJFbWFpbCBNYXJrZXRpbmdcIixcclxuICAgIGljb246IDxNZEVtYWlsIHNpemU9ezIwfSAvPixcclxuICAgIGNvbG9yOiBcIiNFQTQzMzVcIixcclxuICAgIHN1Yk1lbnVzOiBbXHJcbiAgICAgIHtcclxuICAgICAgICB0aXRsZTogXCJEdWUgRW1haWxcIixcclxuICAgICAgICBzdWJNZW51czogW1xyXG4gICAgICAgICAgeyBcclxuICAgICAgICAgICAgdGl0bGU6IFwiRHVlXCIsIFxyXG4gICAgICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvZHVlLWVtYWlsXCIsXHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlNlbmQgZHVlIHBheW1lbnQgZW1haWxzXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7IFxyXG4gICAgICAgICAgICB0aXRsZTogXCJPdmVyZHVlXCIsIFxyXG4gICAgICAgICAgICBsaW5rOiBcIi9tYXJrZXRpbmcvb3Zlci1kdWUtZW1haWxcIixcclxuICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiU2VuZCBvdmVyZHVlIHBheW1lbnQgZW1haWxzXCJcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgXSxcclxuICAgICAgfSxcclxuICAgIF0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBrZXk6IFwicGF5bWVudFwiLFxyXG4gICAgdGl0bGU6IFwiUGF5bWVudCBMaW5rc1wiLFxyXG4gICAgaWNvbjogPFJpTW9uZXlSdXBlZUNpcmNsZUxpbmUgc2l6ZT17MjB9IC8+LFxyXG4gICAgY29sb3I6IFwiIzAwQzg1M1wiLFxyXG4gICAgc3ViTWVudXM6IFtcclxuICAgICAgeyBcclxuICAgICAgICB0aXRsZTogXCJQYXltZW50IExpbmtcIiwgXHJcbiAgICAgICAgbGluazogXCIvbWFya2V0aW5nL3BheW1lbnQtbGlua1wiLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkdlbmVyYXRlIHBheW1lbnQgbGlua3NcIlxyXG4gICAgICB9LFxyXG4gICAgXSxcclxuICB9LFxyXG5dO1xyXG5cclxuY29uc3QgTWFya2V0aW5nID0gKCkgPT4ge1xyXG4gIGNvbnN0IFthY3RpdmVNZW51LCBzZXRBY3RpdmVNZW51XSA9IHVzZVN0YXRlKG1haW5NZW51c1swXSk7XHJcbiAgY29uc3QgW29wZW5TZWN0aW9uLCBzZXRPcGVuU2VjdGlvbl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuXHJcbiAgLy8gU2V0IGluaXRpYWwgYWN0aXZlIG1lbnUgYmFzZWQgb24gY3VycmVudCBwYXRoXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGN1cnJlbnRQYXRoID0gbG9jYXRpb24ucGF0aG5hbWU7XHJcbiAgICBjb25zdCBtYXRjaGVkTWVudSA9IG1haW5NZW51cy5maW5kKG1lbnUgPT4ge1xyXG4gICAgICByZXR1cm4gbWVudS5zdWJNZW51cy5zb21lKHNlY3Rpb24gPT4ge1xyXG4gICAgICAgIGlmIChzZWN0aW9uLmxpbmsgPT09IGN1cnJlbnRQYXRoKSByZXR1cm4gdHJ1ZTtcclxuICAgICAgICBpZiAoc2VjdGlvbi5zdWJNZW51cykge1xyXG4gICAgICAgICAgcmV0dXJuIHNlY3Rpb24uc3ViTWVudXMuc29tZShzdWJJdGVtID0+IHN1Ykl0ZW0ubGluayA9PT0gY3VycmVudFBhdGgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgICBcclxuICAgIGlmIChtYXRjaGVkTWVudSkge1xyXG4gICAgICBzZXRBY3RpdmVNZW51KG1hdGNoZWRNZW51KTtcclxuICAgIH1cclxuICB9LCBbbG9jYXRpb24ucGF0aG5hbWVdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlTWVudUNsaWNrID0gKG1lbnUpID0+IHtcclxuICAgIHNldEFjdGl2ZU1lbnUobWVudSk7XHJcbiAgICBzZXRPcGVuU2VjdGlvbihudWxsKTtcclxuICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgIC8vIFNpbXVsYXRlIGxvYWRpbmdcclxuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0SXNMb2FkaW5nKGZhbHNlKSwgMzAwKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTZWN0aW9uVG9nZ2xlID0gKGluZGV4KSA9PiB7XHJcbiAgICBzZXRPcGVuU2VjdGlvbihvcGVuU2VjdGlvbiA9PT0gaW5kZXggPyBudWxsIDogaW5kZXgpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cgbWluLWgtc2NyZWVuIGJnLWdyYXktNTBcIj5cclxuICAgICAgPFNpZGViYXIgLz5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LTEgZmxleC1jb2wgbWQ6ZmxleC1yb3dcIj5cclxuICAgICAgICB7LyogTEVGVCDigJMgTUFJTiBNRU5VICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1kOnctNjQgYmctd2hpdGUgYm9yZGVyLXIgYm9yZGVyLWdyYXktMjAwIHNoYWRvdy1zbSBwLTQgbXQtMTYgXCI+XHJcbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbWItNCBtci0xMCBtdC0xMFwiPk1hcmtldGluZyBUb29sczwvaDI+XHJcbiAgICAgICAgICA8bmF2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgICB7bWFpbk1lbnVzLm1hcCgobWVudSkgPT4gKFxyXG4gICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgIGtleT17bWVudS5rZXl9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVNZW51Q2xpY2sobWVudSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBwLTMgcm91bmRlZC1sZyBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgJHtcclxuICAgICAgICAgICAgICAgICAgYWN0aXZlTWVudS5rZXkgPT09IG1lbnUua2V5XHJcbiAgICAgICAgICAgICAgICAgICAgPyBcImJnLWdyYWRpZW50LXRvLXIgZnJvbS12aW9sZXQtNTAgdG8taW5kaWdvLTUwIHRleHQtdmlvbGV0LTcwMCBzaGFkb3ctc20gYm9yZGVyLWwtNCBib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcImhvdmVyOmJnLWdyYXktNTAgdGV4dC1ncmF5LTcwMCBob3Zlcjp0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgYm9yZGVyTGVmdENvbG9yOiBhY3RpdmVNZW51LmtleSA9PT0gbWVudS5rZXkgPyBtZW51LmNvbG9yIDogdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXYgXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMiByb3VuZGVkLW1kICR7XHJcbiAgICAgICAgICAgICAgICAgICAgYWN0aXZlTWVudS5rZXkgPT09IG1lbnUua2V5ID8gXCJiZy13aGl0ZSBzaGFkb3ctc21cIiA6IFwiYmctZ3JheS0xMDBcIlxyXG4gICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgY29sb3I6IGFjdGl2ZU1lbnUua2V5ID09PSBtZW51LmtleSA/IG1lbnUuY29sb3IgOiB1bmRlZmluZWQgfX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge21lbnUuaWNvbn1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj57bWVudS50aXRsZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9uYXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBSSUdIVCDigJMgU1VCIE1FTlUgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgcC00IG1kOnAtNlwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMTAwIHAtNiBtYi02XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTYgbXQtMTZcIj5cclxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiByb3VuZGVkLWxnIFwiXHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogYCR7YWN0aXZlTWVudS5jb2xvcn0yMGAsIGNvbG9yOiBhY3RpdmVNZW51LmNvbG9yIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHthY3RpdmVNZW51Lmljb259XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIHthY3RpdmVNZW51LnRpdGxlfVxyXG4gICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAge2lzTG9hZGluZyAmJiA8RmFTcGlubmVyIGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiB0ZXh0LXZpb2xldC01MDBcIiAvPn1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICB7YWN0aXZlTWVudS5zdWJNZW51cy5tYXAoKHNlY3Rpb24sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC14bCBvdmVyZmxvdy1oaWRkZW4gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIGhvdmVyOnNoYWRvdy1tZFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZWN0aW9uLnN1Yk1lbnVzICYmIGhhbmRsZVNlY3Rpb25Ub2dnbGUoaW5kZXgpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtNCBiZy1ncmFkaWVudC10by1yIGZyb20tZ3JheS01MCB0by13aGl0ZSBjdXJzb3ItcG9pbnRlciAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2VjdGlvbi5zdWJNZW51cyA/IFwiaG92ZXI6ZnJvbS1ncmF5LTEwMCBob3Zlcjp0by1ncmF5LTUwXCIgOiBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPntzZWN0aW9uLnRpdGxlfTwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c2VjdGlvbi5zdWJNZW51cyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge29wZW5TZWN0aW9uID09PSBpbmRleCA/IDxGYUNoZXZyb25Eb3duIC8+IDogPEZhQ2hldnJvblJpZ2h0IC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIHtzZWN0aW9uLmRlc2NyaXB0aW9uICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMCBtdC0xXCI+e3NlY3Rpb24uZGVzY3JpcHRpb259PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIDNSRCBMRVZFTCAqL31cclxuICAgICAgICAgICAgICAgICAge29wZW5TZWN0aW9uID09PSBpbmRleCAmJiBzZWN0aW9uLnN1Yk1lbnVzICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1ncmF5LTUwIGJvcmRlci10IGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c2VjdGlvbi5zdWJNZW51cy5tYXAoKGl0ZW0sIGlkeCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2lkeH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TmF2TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17aXRlbS5saW5rfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9e2l0ZW0ubmV3VGFiID8gXCJfYmxhbmtcIiA6IFwiX3NlbGZcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtMyByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNBY3RpdmUgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy12aW9sZXQtNTAgdGV4dC12aW9sZXQtNzAwIGZvbnQtbWVkaXVtXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJob3ZlcjpiZy13aGl0ZSB0ZXh0LWdyYXktNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntpdGVtLnRpdGxlfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ubmV3VGFiICYmIDxGYUV4dGVybmFsTGlua0FsdCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS00MDBcIiAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTmF2TGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmRlc2NyaXB0aW9uICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIHB4LTMgcGItMlwiPntpdGVtLmRlc2NyaXB0aW9ufTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIERpcmVjdCBMaW5rICovfVxyXG4gICAgICAgICAgICAgICAgICB7c2VjdGlvbi5saW5rICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1ncmF5LTUwIGJvcmRlci10IGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPE5hdkxpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdG89e3NlY3Rpb24ubGlua31cclxuICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PXtzZWN0aW9uLm5ld1RhYiA/IFwiX2JsYW5rXCIgOiBcIl9zZWxmXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT4gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTMgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctdmlvbGV0LTUwIHRleHQtdmlvbGV0LTcwMCBmb250LW1lZGl1bVwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiaG92ZXI6Ymctd2hpdGUgdGV4dC1ncmF5LTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfWBcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5PcGVuPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c2VjdGlvbi5uZXdUYWIgJiYgPEZhRXh0ZXJuYWxMaW5rQWx0IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTQwMFwiIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9OYXZMaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMTAwIHAtNlwiPlxyXG4gICAgICAgICAgICA8T3V0bGV0IC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG5leHBvcnQgZGVmYXVsdCBNYXJrZXRpbmc7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9NYXJrZXRpbmcuanN4In0=