import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AdditionalSalary.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Dropdown, Drawer, Modal, Empty, Alert } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import BackdropBlurLoader from "/src/components/loaders/BackdropBlurLoader.jsx";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import { FiCalendar, FiCreditCard, FiHash, FiFileText } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { FaRupeeSign } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { GrStatusGood } from "/node_modules/.vite/deps/react-icons_gr.js?v=819e0a34";
import { form, s } from "/node_modules/.vite/deps/framer-motion_client.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { RiMoneyRupeeCircleFill } from "/node_modules/.vite/deps/react-icons_ri.js?v=819e0a34";
import { m } from "/node_modules/.vite/deps/framer-motion.js?v=819e0a34";
import { MdOutlineMan } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
import { User } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
const AdditionalSalary = () => {
  _s();
  const [employees, setEmployees] = useState([]);
  const [tablePayments, setTablePayments] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [searchText, setSearchText] = useState("");
  const [openBackdropLoader, setOpenBackdropLoader] = useState(false);
  const [editId, setEditId] = useState(null);
  const [totalCount, setTotalCount] = useState({ pending: 0, completed: 0 });
  const tabs = ["Pending", "Completed"];
  const [activeTab, setActiveTab] = useState(tabs[0]);
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const initialForm = {
    employee_id: "",
    pay_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
    month: null,
    year: null,
    pay_type: "cash",
    paid_date: today,
    transaction_id: "",
    cheque_id: "",
    amount: 0,
    note: "",
    status: ""
  };
  const [formData, setFormData] = useState(initialForm);
  const [errors, setErrors] = useState({});
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "",
    type: "info",
    noReload: true
  });
  useEffect(() => {
    if (alertConfig.visibility) {
      const timer = setTimeout(() => {
        setAlertConfig((prev) => ({ ...prev, visibility: false }));
      }, 3e3);
      return () => clearTimeout(timer);
    }
  }, [alertConfig.visibility]);
  useEffect(() => {
    fetchEmployees();
    fetchAdvanceHistory();
  }, [activeTab]);
  useEffect(() => {
    fetchTotalCounts();
  }, [reloadTrigger]);
  const fetchTotalCounts = async () => {
    try {
      const [pendingRes, completedRes] = await Promise.all(
        [
          api.get(`additional-salary-payment-out?status=Pending`),
          api.get(`additional-salary-payment-out?status=Completed`)
        ]
      );
      setTotalCount({
        pending: pendingRes.data.data?.length || 0,
        completed: completedRes.data.data?.length || 0
      });
    } catch (error) {
      console.error("Error fetching counts:", error);
      setTotalCount({ pending: 0, completed: 0 });
    }
  };
  const fetchEmployees = async () => {
    const res = await api.get("/employee");
    if (res.data.status) setEmployees(res.data.employee);
  };
  const fetchAdvanceHistory = async () => {
    try {
      let status = activeTab === "Pending" ? "Pending" : "Completed";
      setIsLoading(true);
      const response = await api.get(`/additional-salary-payment-out?status=${status}`);
      const formatted = response.data.data?.map((item, index) => ({
        ...item,
        id: index + 1,
        pay_date: item?.pay_date.split("T")[0] || "N/A",
        salary_month: item?.salary_month,
        salary_year: item?.salary_year,
        payable_amount: item?.payable_amount,
        remarks: item?.remarks || "N/A",
        employeeName: item.employee_id?.name || "N/A",
        action: /* @__PURE__ */ jsxDEV(
          Dropdown,
          {
            menu: {
              items: [
                { key: "1", label: "Edit", onClick: () => handleEdit(item) },
                {
                  key: "2",
                  label: /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "Delete" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 132,
                    columnNumber: 22
                  }, this),
                  onClick: () => showDeleteConfirm(item._id)
                }
              ]
            },
            trigger: ["click"],
            children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "cursor-pointer text-xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
              lineNumber: 139,
              columnNumber: 25
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
            lineNumber: 126,
            columnNumber: 9
          },
          this
        )
      }));
      setTablePayments(formatted);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };
  const showDeleteConfirm = (id) => {
    Modal.confirm({
      title: "Are you sure you want to delete this record?",
      content: "This action cannot be undone.",
      okText: "Yes, Delete",
      okType: "danger",
      cancelText: "No",
      onOk() {
        handleDelete(id);
      }
    });
  };
  const handleEdit = (item) => {
    const employeeId = typeof item.employee_id === "object" ? item.employee_id._id : item.employee_id;
    setEditId(item._id);
    setFormData({
      employee_id: employeeId,
      pay_date: item.pay_date,
      paid_date: item.pay_date ? item.pay_date.split("T")[0] : "",
      month: item.salary_month,
      year: item.salary_year,
      pay_type: item.pay_type,
      transaction_id: item.transaction_id || "",
      amount: item.amount,
      note: item.remarks || "",
      status: item.status
    });
    setShowModal(true);
  };
  const handleDelete = async (id) => {
    try {
      setOpenBackdropLoader(true);
      await api.delete(`/additional-salary-payment-out/${id}`);
      setAlertConfig({
        visibility: true,
        message: "Data Deleted Successfully!",
        type: "success",
        noReload: true
      });
      fetchAdvanceHistory();
    } catch (error) {
      setAlertConfig({
        visibility: true,
        message: "Delete failed",
        type: "error",
        noReload: true
      });
    } finally {
      setOpenBackdropLoader(false);
      setReloadTrigger((prev) => prev + 1);
    }
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    const payload = {
      ...editId ? {} : { employee_id: formData.employee_id },
      salary_month: formData.month,
      salary_year: Number(formData.year),
      payable_amount: Number(formData.amount || 0),
      amount: Number(formData.amount || 0),
      pay_type: formData.pay_type,
      transaction_id: formData.transaction_id,
      cheque_id: formData.cheque_id,
      remarks: formData.note,
      pay_date: formData.paid_date,
      status: editId ? formData.status : "Completed"
    };
    try {
      setOpenBackdropLoader(true);
      if (editId) {
        await api.put(`/additional-salary-payment-out/${editId}`, payload);
      } else {
        await api.post("/additional-salary-payment-out/", payload);
      }
      closeDrawer();
      fetchAdvanceHistory();
    } catch (error) {
      console.log(error);
    } finally {
      setOpenBackdropLoader(false);
      setReloadTrigger((prev) => prev + 1);
    }
  };
  const validateForm = () => {
    const errs = {};
    if (!formData.employee_id) errs.employee = "Required";
    if (!formData.amount || formData.amount <= 0)
      errs.amount = "Enter valid amount";
    if (!formData.pay_date) errs.pay_date = "Required";
    if (!formData.month) errs.month = "Required";
    if (formData.pay_type !== "cash") {
      if (!formData.transaction_id) errs.transaction_id = "Required";
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };
  const closeDrawer = () => {
    setShowModal(false);
    setEditId(null);
    setFormData(initialForm);
    setErrors({});
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    // { key: "pay_date", header: "Paid Date" },
    { key: "employeeName", header: "Employee" },
    { key: "salary_month", header: "Month" },
    { key: "salary_year", header: "Year" },
    { key: "payable_amount", header: activeTab === "Completed" ? "Paid Amount" : "Payable Amount" },
    { key: "pay_type", header: "Payment Mode" },
    { key: "transaction_id", header: "Transaction ID" },
    { key: "remarks", header: "Remarks" },
    { key: "action", header: "Action" }
  ];
  const NAV_LINKS = [
    {
      to: "/payment-menu/payment-in-out-menu/pay-out-menu/salary-payment",
      icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
        lineNumber: 287,
        columnNumber: 11
      }, this),
      label: "Salary payment"
    },
    {
      to: "/staff-menu/employee-menu/salary-management",
      icon: /* @__PURE__ */ jsxDEV(MdOutlineMan, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
        lineNumber: 292,
        columnNumber: 11
      }, this),
      label: "Salary management"
    },
    {
      to: "/payment-menu/payment-in-out-menu/pay-in-menu/advance-payment-in",
      icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
        lineNumber: 297,
        columnNumber: 11
      }, this),
      label: "Advance repayment"
    },
    {
      to: "/payment-menu/payment-in-out-menu/pay-out-menu/salary-incentive",
      icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
        lineNumber: 302,
        columnNumber: 11
      }, this),
      label: "Salary incentive"
    },
    {
      to: "/staff-menu/employee-menu/employee-statement",
      icon: /* @__PURE__ */ jsxDEV(User, { size: 16 }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
        lineNumber: 307,
        columnNumber: 11
      }, this),
      label: "Salary Ledger"
    }
  ];
  const totalPayableSum = useMemo(() => {
    return tablePayments.reduce(
      (sum, item) => sum + (Number(item.payable_amount) || 0),
      0
    );
  }, [tablePayments]);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    openBackdropLoader && /* @__PURE__ */ jsxDEV(BackdropBlurLoader, { title: "Processing..." }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
      lineNumber: 321,
      columnNumber: 36
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20 min-h-screen", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
        lineNumber: 324,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 px-6", children: [
        /* @__PURE__ */ jsxDEV(Navbar, { onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value), visibility: true }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
          lineNumber: 326,
          columnNumber: 21
        }, this),
        alertConfig.visibility && /* @__PURE__ */ jsxDEV("div", { className: "fixed top-5 left-1/2 -translate-x-1/2 z-[1000] w-full max-w-md px-4", children: /* @__PURE__ */ jsxDEV(
          Alert,
          {
            message: alertConfig.message,
            type: alertConfig.type,
            showIcon: true,
            closable: true,
            onClose: () => setAlertConfig({ ...alertConfig, visibility: false })
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
            lineNumber: 330,
            columnNumber: 29
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
          lineNumber: 329,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-3", children: [
          /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
            lineNumber: 340,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold mb-4", children: "Additional Salary" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
            lineNumber: 341,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("section", { className: "mb-6", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-widest text-gray-400 mb-3", children: "Quick navigator" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
              lineNumber: 344,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: NAV_LINKS.map(
                (link) => /* @__PURE__ */ jsxDEV(
                  Link,
                  {
                    to: link.to,
                    className: "flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-600 hover:border-blue-400 hover:text-blue-600 hover:bg-blue-50 transition-all",
                    children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-blue-500", children: link.icon }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                        lineNumber: 358,
                        columnNumber: 45
                      }, this),
                      link.label
                    ]
                  },
                  link.to,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 353,
                    columnNumber: 19
                  },
                  this
                )
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                lineNumber: 351,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-100 border border-blue-300 rounded-xl px-5 py-2 shadow-sm flex items-center gap-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-blue-900 font-medium", children: "Pending Payments:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 368,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-blue-900 font-bold", children: tablePayments.length }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 371,
                    columnNumber: 41
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                  lineNumber: 367,
                  columnNumber: 37
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "h-5 w-px bg-blue-300" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                  lineNumber: 376,
                  columnNumber: 37
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-blue-900 font-medium", children: "Total Payable:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 379,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-blue-900 font-bold", children: [
                    "₹",
                    totalPayableSum.toLocaleString("en-IN")
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 382,
                    columnNumber: 41
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                  lineNumber: 378,
                  columnNumber: 37
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                lineNumber: 365,
                columnNumber: 33
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
              lineNumber: 348,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
            lineNumber: 343,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setEditId(null);
                setFormData(initialForm);
                setShowModal(true);
              },
              className: "bg-blue-950 text-white px-4 py-2 rounded hover:bg-blue-900 transition-colors mt-2",
              children: "+ Add Additional Salary"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
              lineNumber: 392,
              columnNumber: 29
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
            lineNumber: 391,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
          lineNumber: 339,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex border-b border-gray-200 mb-6 ", children: tabs.map(
          (tab) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: `px-4 py-2 font-medium ${activeTab === tab ? "border-b-2 border-blue-600 text-blue-600" : "text-gray-600"}`,
              onClick: () => setActiveTab(tab),
              children: tab === "Pending" ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                " Pending  ",
                /* @__PURE__ */ jsxDEV("span", { className: " bg-orange-500 text-white  text-[12px] px-2 py-0.5 rounded-full", children: totalCount?.pending }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                  lineNumber: 415,
                  columnNumber: 66
                }, this),
                " "
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                lineNumber: 415,
                columnNumber: 54
              }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
                "Completed   ",
                /* @__PURE__ */ jsxDEV("span", { className: " bg-green-500 text-white  text-[12px] px-2 py-0.5 rounded-full", children: totalCount?.completed }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                  lineNumber: 417,
                  columnNumber: 61
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                lineNumber: 417,
                columnNumber: 47
              }, this)
            },
            tab,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
              lineNumber: 407,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
          lineNumber: 405,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          activeTab === "Pending" && /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: isLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
            lineNumber: 431,
            columnNumber: 15
          }, this) : tablePayments.length <= 0 ? /* @__PURE__ */ jsxDEV(Empty, { description: "No Additional Salary Data Found" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
            lineNumber: 433,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: tablePayments.filter(
                (item) => item.employeeName?.toLowerCase().includes(searchText.toLowerCase())
              ),
              columns
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
              lineNumber: 435,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
            lineNumber: 427,
            columnNumber: 13
          }, this),
          activeTab === "Completed" && /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
              lineNumber: 448,
              columnNumber: 33
            }, this),
            isLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
              lineNumber: 463,
              columnNumber: 15
            }, this) : tablePayments.length <= 0 ? /* @__PURE__ */ jsxDEV(Empty, { description: "No Additional Salary Data Found" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
              lineNumber: 465,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV(
              DataTable,
              {
                data: tablePayments.filter(
                  (item) => item.employeeName?.toLowerCase().includes(searchText.toLowerCase())
                ),
                columns
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                lineNumber: 467,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
            lineNumber: 447,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
          lineNumber: 425,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(
          Drawer,
          {
            title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "text-blue-600" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                lineNumber: 485,
                columnNumber: 37
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                lineNumber: 484,
                columnNumber: 33
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: editId ? "Edit Additional Salary" : "New Additional Salary" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                lineNumber: 487,
                columnNumber: 33
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
              lineNumber: 483,
              columnNumber: 13
            }, this),
            open: showModal,
            onClose: closeDrawer,
            width: 480,
            children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-6 p-1", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                  "Employee ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 500,
                    columnNumber: 46
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                  lineNumber: 499,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    showSearch: true,
                    size: "large",
                    className: "w-full",
                    placeholder: "Search and select employee",
                    value: formData.employee_id || void 0,
                    optionFilterProp: "label",
                    filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
                    onChange: (val) => setFormData({ ...formData, employee_id: val }),
                    children: employees.map(
                      (emp) => /* @__PURE__ */ jsxDEV(
                        Select.Option,
                        {
                          value: emp._id,
                          label: `${emp.name} ${emp.employeeCode}`,
                          children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                            /* @__PURE__ */ jsxDEV("div", { className: "w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-xs font-medium text-blue-700", children: emp.name.charAt(0).toUpperCase() }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                              lineNumber: 523,
                              columnNumber: 49
                            }, this),
                            emp.name,
                            " | ",
                            emp.employeeCode ? emp.employeeCode : emp.unique_code
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                            lineNumber: 522,
                            columnNumber: 45
                          }, this)
                        },
                        emp._id,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                          lineNumber: 517,
                          columnNumber: 19
                        },
                        this
                      )
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 502,
                    columnNumber: 33
                  },
                  this
                ),
                errors.employee && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1 flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-1 bg-red-500 rounded-full" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 533,
                    columnNumber: 41
                  }, this),
                  errors.employee
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                  lineNumber: 532,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                lineNumber: 498,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                  /* @__PURE__ */ jsxDEV(FiCalendar, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 543,
                    columnNumber: 37
                  }, this),
                  "Month & Year"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                  lineNumber: 542,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV(
                      "select",
                      {
                        className: "w-full border border-gray-300 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500",
                        value: formData.month || "",
                        onChange: (e) => setFormData({ ...formData, month: e.target.value }),
                        disabled: editId ? true : false,
                        children: [
                          /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Month" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                            lineNumber: 559,
                            columnNumber: 45
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "January", children: "January" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                            lineNumber: 560,
                            columnNumber: 45
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "February", children: "February" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                            lineNumber: 561,
                            columnNumber: 45
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "March", children: "March" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                            lineNumber: 562,
                            columnNumber: 45
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "April", children: "April" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                            lineNumber: 563,
                            columnNumber: 45
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "May", children: "May" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                            lineNumber: 564,
                            columnNumber: 45
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "June", children: "June" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                            lineNumber: 565,
                            columnNumber: 45
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "July", children: "July" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                            lineNumber: 566,
                            columnNumber: 45
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "August", children: "August" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                            lineNumber: 567,
                            columnNumber: 45
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "September", children: "September" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                            lineNumber: 568,
                            columnNumber: 45
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "October", children: "October" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                            lineNumber: 569,
                            columnNumber: 45
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "November", children: "November" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                            lineNumber: 570,
                            columnNumber: 45
                          }, this),
                          /* @__PURE__ */ jsxDEV("option", { value: "December", children: "December" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                            lineNumber: 571,
                            columnNumber: 45
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                        lineNumber: 551,
                        columnNumber: 41
                      },
                      this
                    ),
                    errors.month && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1 flex items-center gap-1", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-1 bg-red-500 rounded-full" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                        lineNumber: 575,
                        columnNumber: 49
                      }, this),
                      errors.month
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                      lineNumber: 574,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 550,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV(
                      "select",
                      {
                        className: "w-full border border-gray-300 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500",
                        value: formData.year || 0,
                        onChange: (e) => setFormData({ ...formData, year: Number(e.target.value) }),
                        disabled: editId ? true : false,
                        children: [
                          /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Year" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                            lineNumber: 590,
                            columnNumber: 45
                          }, this),
                          Array.from({ length: 10 }, (_, i) => {
                            const year = (/* @__PURE__ */ new Date()).getFullYear() - 5 + i;
                            return /* @__PURE__ */ jsxDEV("option", { value: year, children: year }, year, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                              lineNumber: 594,
                              columnNumber: 27
                            }, this);
                          })
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                        lineNumber: 582,
                        columnNumber: 41
                      },
                      this
                    ),
                    errors.year && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1 flex items-center gap-1", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-1 bg-red-500 rounded-full" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                        lineNumber: 602,
                        columnNumber: 49
                      }, this),
                      errors.year
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                      lineNumber: 601,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 581,
                    columnNumber: 37
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                  lineNumber: 547,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                lineNumber: 541,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                  /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 613,
                    columnNumber: 37
                  }, this),
                  "Amount ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 614,
                    columnNumber: 44
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                  lineNumber: 612,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-medium", children: "₹" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 617,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "number",
                      step: "0.01",
                      className: "w-full border border-gray-300 rounded-lg pl-8 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition",
                      placeholder: "0.00",
                      value: formData.amount,
                      onChange: (e) => setFormData({ ...formData, amount: e.target.value })
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                      lineNumber: 620,
                      columnNumber: 37
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                  lineNumber: 616,
                  columnNumber: 33
                }, this),
                errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-1 bg-red-500 rounded-full" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 640,
                    columnNumber: 41
                  }, this),
                  errors.amount
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                  lineNumber: 639,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                lineNumber: 611,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                  /* @__PURE__ */ jsxDEV(FiCalendar, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 650,
                    columnNumber: 37
                  }, this),
                  "Payment Date"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                  lineNumber: 649,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "relative", children: /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition",
                    value: formData.paid_date,
                    onChange: (e) => setFormData({ ...formData, paid_date: e.target.value })
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 654,
                    columnNumber: 37
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                  lineNumber: 653,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                lineNumber: 648,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                  /* @__PURE__ */ jsxDEV(FiCreditCard, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 668,
                    columnNumber: 37
                  }, this),
                  "Payment Mode"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                  lineNumber: 667,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    size: "large",
                    className: "w-full",
                    value: formData.pay_type,
                    onChange: (val) => setFormData({ ...formData, pay_type: val }),
                    children: [
                      /* @__PURE__ */ jsxDEV(Select.Option, { value: "cash", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: "Cash" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                        lineNumber: 678,
                        columnNumber: 41
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                        lineNumber: 677,
                        columnNumber: 37
                      }, this),
                      /* @__PURE__ */ jsxDEV(Select.Option, { value: "online", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: "Online/UPI" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                        lineNumber: 681,
                        columnNumber: 41
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                        lineNumber: 680,
                        columnNumber: 37
                      }, this),
                      /* @__PURE__ */ jsxDEV(Select.Option, { value: "cheque", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: "Cheque" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                        lineNumber: 684,
                        columnNumber: 41
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                        lineNumber: 683,
                        columnNumber: 37
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 671,
                    columnNumber: 33
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                lineNumber: 666,
                columnNumber: 29
              }, this),
              formData.pay_type !== "cash" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 animate-fadeIn", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                  /* @__PURE__ */ jsxDEV(FiHash, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 693,
                    columnNumber: 41
                  }, this),
                  formData.pay_type === "cheque" ? "Cheque Number" : "Transaction ID"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                  lineNumber: 692,
                  columnNumber: 37
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition",
                    placeholder: formData.pay_type === "cheque" ? "Enter cheque number" : "Enter transaction/UPI ID",
                    value: formData.transaction_id,
                    onChange: (e) => setFormData({ ...formData, transaction_id: e.target.value })
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 698,
                    columnNumber: 37
                  },
                  this
                ),
                errors.transaction_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-1 bg-red-500 rounded-full" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 713,
                    columnNumber: 45
                  }, this),
                  errors.transaction_id
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                  lineNumber: 712,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                lineNumber: 691,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                  /* @__PURE__ */ jsxDEV(FiFileText, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 724,
                    columnNumber: 37
                  }, this),
                  "Note (Optional)"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                  lineNumber: 723,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "textarea",
                  {
                    rows: 3,
                    className: "w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition resize-none",
                    placeholder: "Add any remarks or reference...",
                    value: formData.note,
                    onChange: (e) => setFormData({ ...formData, note: e.target.value })
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 727,
                    columnNumber: 33
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                lineNumber: 722,
                columnNumber: 29
              }, this),
              editId && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 text-sm font-medium text-gray-700", children: [
                  /* @__PURE__ */ jsxDEV(GrStatusGood, { className: "w-4 h-4 text-gray-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 741,
                    columnNumber: 37
                  }, this),
                  "Status"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                  lineNumber: 740,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    size: "large",
                    className: "w-full",
                    value: formData?.status,
                    onChange: (val) => setFormData({ ...formData, status: val }),
                    children: [
                      /* @__PURE__ */ jsxDEV(Select.Option, { value: "Pending", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: "Pending" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                        lineNumber: 751,
                        columnNumber: 41
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                        lineNumber: 750,
                        columnNumber: 37
                      }, this),
                      /* @__PURE__ */ jsxDEV(Select.Option, { value: "Completed", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: "Completed" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                        lineNumber: 754,
                        columnNumber: 41
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                        lineNumber: 753,
                        columnNumber: 37
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                    lineNumber: 744,
                    columnNumber: 33
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                lineNumber: 739,
                columnNumber: 40
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "pt-4 border-t border-gray-200", children: /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "submit",
                  className: "w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-3 rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all duration-200 font-semibold shadow-md hover:shadow-lg transform hover:-translate-y-0.5 flex items-center justify-center gap-2",
                  children: editId ? "Update Additional Salary" : "Save Additional Salary"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                  lineNumber: 762,
                  columnNumber: 33
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
                lineNumber: 761,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
              lineNumber: 496,
              columnNumber: 25
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
            lineNumber: 481,
            columnNumber: 21
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
        lineNumber: 325,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
      lineNumber: 323,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx",
    lineNumber: 320,
    columnNumber: 5
  }, this);
};
_s(AdditionalSalary, "/Ejus3HMPSCWmue2ySilyEJw7PQ=");
_c = AdditionalSalary;
export default AdditionalSalary;
var _c;
$RefreshReg$(_c, "AdditionalSalary");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdditionalSalary.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUkyQyxTQTJSVSxVQTNSVjsyQkFuSTNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsU0FBU0MsZ0JBQWdCO0FBQzdDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLFFBQVFDLFVBQVVDLFFBQVFDLE9BQU9DLE9BQU9DLGFBQWE7QUFDOUQsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLHdCQUF3QjtBQUMvQixTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MsWUFBWUMsY0FBY0MsUUFBUUMsa0JBQWtCO0FBQzdELFNBQVNDLG1CQUFtQjtBQUM1QixPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLE1BQU1DLFNBQVM7QUFDeEIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyw4QkFBOEI7QUFDdkMsU0FBU0MsU0FBUztBQUNsQixTQUFTQyxvQkFBb0I7QUFDN0IsT0FBT0MsZ0JBQWdCO0FBQ3ZCLFNBQVNDLFlBQVk7QUFFckIsTUFBTUMsbUJBQW1CQSxNQUFNO0FBQUFDLEtBQUE7QUFDM0IsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlqQyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDa0MsZUFBZUMsZ0JBQWdCLElBQUluQyxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDb0MsV0FBV0MsWUFBWSxJQUFJckMsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3NDLFdBQVdDLFlBQVksSUFBSXZDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUN3QyxlQUFlQyxnQkFBZ0IsSUFBSXpDLFNBQVMsQ0FBQztBQUNwRCxRQUFNLENBQUMwQyxZQUFZQyxhQUFhLElBQUkzQyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDNEMsb0JBQW9CQyxxQkFBcUIsSUFBSTdDLFNBQVMsS0FBSztBQUNsRSxRQUFNLENBQUM4QyxRQUFRQyxTQUFTLElBQUkvQyxTQUFTLElBQUk7QUFDekMsUUFBTSxDQUFDZ0QsWUFBWUMsYUFBYSxJQUFJakQsU0FBUyxFQUFFa0QsU0FBUyxHQUFHQyxXQUFXLEVBQUUsQ0FBQztBQUN6RSxRQUFNQyxPQUFPLENBQUMsV0FBVyxXQUFXO0FBRXBDLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJdEQsU0FBU29ELEtBQUssQ0FBQyxDQUFDO0FBRWxELFFBQU1HLFNBQVEsb0JBQUlDLEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBRW5ELFFBQU1DLGNBQWM7QUFBQSxJQUNoQkMsYUFBYTtBQUFBLElBQ2JDLFdBQVUsb0JBQUlMLEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsSUFDL0NJLE9BQU87QUFBQSxJQUNQQyxNQUFNO0FBQUEsSUFDTkMsVUFBVTtBQUFBLElBQ1ZDLFdBQVdWO0FBQUFBLElBQ1hXLGdCQUFnQjtBQUFBLElBQ2hCQyxXQUFXO0FBQUEsSUFDWEMsUUFBUTtBQUFBLElBQ1JDLE1BQU07QUFBQSxJQUNOQyxRQUFRO0FBQUEsRUFDWjtBQUVBLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJeEUsU0FBUzJELFdBQVc7QUFDcEQsUUFBTSxDQUFDYyxRQUFRQyxTQUFTLElBQUkxRSxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUMyRSxhQUFhQyxjQUFjLElBQUk1RSxTQUFTO0FBQUEsSUFDM0M2RSxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxJQUNOQyxVQUFVO0FBQUEsRUFDZCxDQUFDO0FBR0RsRixZQUFVLE1BQU07QUFDWixRQUFJNkUsWUFBWUUsWUFBWTtBQUN4QixZQUFNSSxRQUFRQyxXQUFXLE1BQU07QUFDM0JOLHVCQUFlLENBQUNPLFVBQVUsRUFBRSxHQUFHQSxNQUFNTixZQUFZLE1BQU0sRUFBRTtBQUFBLE1BQzdELEdBQUcsR0FBSTtBQUNQLGFBQU8sTUFBTU8sYUFBYUgsS0FBSztBQUFBLElBQ25DO0FBQUEsRUFDSixHQUFHLENBQUNOLFlBQVlFLFVBQVUsQ0FBQztBQUUzQi9FLFlBQVUsTUFBTTtBQUNadUYsbUJBQWU7QUFDZkMsd0JBQW9CO0FBQUEsRUFFeEIsR0FBRyxDQUFDakMsU0FBUyxDQUFDO0FBQ2R2RCxZQUFVLE1BQU07QUFDWnlGLHFCQUFpQjtBQUFBLEVBQ3JCLEdBQUcsQ0FBQy9DLGFBQWEsQ0FBQztBQUVsQixRQUFNK0MsbUJBQW1CLFlBQVk7QUFDakMsUUFBSTtBQUNBLFlBQU0sQ0FBQ0MsWUFBWUMsWUFBWSxJQUFJLE1BQU1DLFFBQVFDO0FBQUFBLFFBQUk7QUFBQSxVQUNqRHpGLElBQUkwRixJQUFJLDhDQUE4QztBQUFBLFVBQ3REMUYsSUFBSTBGLElBQUksZ0RBQWdEO0FBQUEsUUFBQztBQUFBLE1BQzVEO0FBRUQzQyxvQkFBYztBQUFBLFFBQ1ZDLFNBQVNzQyxXQUFXSyxLQUFLQSxNQUFNQyxVQUFVO0FBQUEsUUFDekMzQyxXQUFXc0MsYUFBYUksS0FBS0EsTUFBTUMsVUFBVTtBQUFBLE1BQ2pELENBQUM7QUFBQSxJQUNMLFNBQVNDLE9BQU87QUFDWkMsY0FBUUQsTUFBTSwwQkFBMEJBLEtBQUs7QUFDN0M5QyxvQkFBYyxFQUFFQyxTQUFTLEdBQUdDLFdBQVcsRUFBRSxDQUFDO0FBQUEsSUFDOUM7QUFBQSxFQUNKO0FBRUEsUUFBTWtDLGlCQUFpQixZQUFZO0FBQy9CLFVBQU1ZLE1BQU0sTUFBTS9GLElBQUkwRixJQUFJLFdBQVc7QUFDckMsUUFBSUssSUFBSUosS0FBS3ZCLE9BQVFyQyxjQUFhZ0UsSUFBSUosS0FBS0ssUUFBUTtBQUFBLEVBQ3ZEO0FBRUEsUUFBTVosc0JBQXNCLFlBQVk7QUFDcEMsUUFBSTtBQUNBLFVBQUloQixTQUFTakIsY0FBYyxZQUFZLFlBQVk7QUFDbkRkLG1CQUFhLElBQUk7QUFDakIsWUFBTTRELFdBQVcsTUFBTWpHLElBQUkwRixJQUFJLHlDQUF5Q3RCLE1BQU0sRUFBRTtBQUVoRixZQUFNOEIsWUFBWUQsU0FBU04sS0FBS0EsTUFBTVEsSUFBSSxDQUFDQyxNQUFNQyxXQUFXO0FBQUEsUUFDeEQsR0FBR0Q7QUFBQUEsUUFDSEUsSUFBSUQsUUFBUTtBQUFBLFFBQ1oxQyxVQUFVeUMsTUFBTXpDLFNBQVNILE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBSztBQUFBLFFBTzFDK0MsY0FBY0gsTUFBTUc7QUFBQUEsUUFDcEJDLGFBQWFKLE1BQU1JO0FBQUFBLFFBQ25CQyxnQkFBZ0JMLE1BQU1LO0FBQUFBLFFBQ3RCQyxTQUFTTixNQUFNTSxXQUFXO0FBQUEsUUFDMUJDLGNBQWNQLEtBQUsxQyxhQUFha0QsUUFBUTtBQUFBLFFBQ3hDQyxRQUNJO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxNQUFNO0FBQUEsY0FDRkMsT0FBTztBQUFBLGdCQUNILEVBQUVDLEtBQUssS0FBS0MsT0FBTyxRQUFRQyxTQUFTQSxNQUFNQyxXQUFXZCxJQUFJLEVBQUU7QUFBQSxnQkFDM0Q7QUFBQSxrQkFDSVcsS0FBSztBQUFBLGtCQUNMQyxPQUFPLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxzQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcUM7QUFBQSxrQkFDNUNDLFNBQVNBLE1BQU1FLGtCQUFrQmYsS0FBS2dCLEdBQUc7QUFBQSxnQkFDN0M7QUFBQSxjQUFDO0FBQUEsWUFFVDtBQUFBLFlBQ0EsU0FBUyxDQUFDLE9BQU87QUFBQSxZQUVqQixpQ0FBQyxZQUFTLFdBQVUsNEJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRDO0FBQUE7QUFBQSxVQWJoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFjQTtBQUFBLE1BRVIsRUFBRTtBQUNGbkYsdUJBQWlCaUUsU0FBUztBQUFBLElBQzlCLFNBQVNtQixLQUFLO0FBQ1Z2QixjQUFRRCxNQUFNd0IsR0FBRztBQUFBLElBQ3JCLFVBQUM7QUFDR2hGLG1CQUFhLEtBQUs7QUFBQSxJQUN0QjtBQUFBLEVBQ0o7QUFFQSxRQUFNOEUsb0JBQW9CQSxDQUFDYixPQUFPO0FBQzlCL0YsVUFBTStHLFFBQVE7QUFBQSxNQUNWQyxPQUFPO0FBQUEsTUFDUEMsU0FBUztBQUFBLE1BQ1RDLFFBQVE7QUFBQSxNQUNSQyxRQUFRO0FBQUEsTUFDUkMsWUFBWTtBQUFBLE1BQ1pDLE9BQU87QUFDSEMscUJBQWF2QixFQUFFO0FBQUEsTUFDbkI7QUFBQSxJQUNKLENBQUM7QUFBQSxFQUNMO0FBQ0EsUUFBTVksYUFBYUEsQ0FBQ2QsU0FBUztBQUV6QixVQUFNMEIsYUFDRixPQUFPMUIsS0FBSzFDLGdCQUFnQixXQUN0QjBDLEtBQUsxQyxZQUFZMEQsTUFDakJoQixLQUFLMUM7QUFDZmIsY0FBVXVELEtBQUtnQixHQUFHO0FBQ2xCOUMsZ0JBQVk7QUFBQSxNQUNSWixhQUFhb0U7QUFBQUEsTUFDYm5FLFVBQVV5QyxLQUFLekM7QUFBQUEsTUFDZkksV0FBV3FDLEtBQUt6QyxXQUFXeUMsS0FBS3pDLFNBQVNILE1BQU0sR0FBRyxFQUFFLENBQUMsSUFBSTtBQUFBLE1BQ3pESSxPQUFPd0MsS0FBS0c7QUFBQUEsTUFDWjFDLE1BQU11QyxLQUFLSTtBQUFBQSxNQUNYMUMsVUFBVXNDLEtBQUt0QztBQUFBQSxNQUNmRSxnQkFBZ0JvQyxLQUFLcEMsa0JBQWtCO0FBQUEsTUFDdkNFLFFBQVFrQyxLQUFLbEM7QUFBQUEsTUFDYkMsTUFBTWlDLEtBQUtNLFdBQVc7QUFBQSxNQUN0QnRDLFFBQVFnQyxLQUFLaEM7QUFBQUEsSUFDakIsQ0FBQztBQUNEakMsaUJBQWEsSUFBSTtBQUFBLEVBQ3JCO0FBRUEsUUFBTTBGLGVBQWUsT0FBT3ZCLE9BQU87QUFDL0IsUUFBSTtBQUNBM0QsNEJBQXNCLElBQUk7QUFDMUIsWUFBTTNDLElBQUkrSCxPQUFPLGtDQUFrQ3pCLEVBQUUsRUFBRTtBQUN2RDVCLHFCQUFlO0FBQUEsUUFDWEMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsUUFDTkMsVUFBVTtBQUFBLE1BQ2QsQ0FBQztBQUNETSwwQkFBb0I7QUFBQSxJQUN4QixTQUFTUyxPQUFPO0FBQ1puQixxQkFBZTtBQUFBLFFBQ1hDLFlBQVk7QUFBQSxRQUNaQyxTQUFTO0FBQUEsUUFDVEMsTUFBTTtBQUFBLFFBQ05DLFVBQVU7QUFBQSxNQUNkLENBQUM7QUFBQSxJQUNMLFVBQUM7QUFDR25DLDRCQUFzQixLQUFLO0FBQzNCSix1QkFBaUIsQ0FBQzBDLFNBQVNBLE9BQU8sQ0FBQztBQUFBLElBQ3ZDO0FBQUEsRUFDSjtBQUVBLFFBQU0rQyxlQUFlLE9BQU9DLE1BQU07QUFDOUJBLE1BQUVDLGVBQWU7QUFFakIsUUFBSSxDQUFDQyxhQUFhLEVBQUc7QUFHckIsVUFBTUMsVUFBVTtBQUFBLE1BQ1osR0FBSXhGLFNBQVMsQ0FBQyxJQUFJLEVBQUVjLGFBQWFXLFNBQVNYLFlBQVk7QUFBQSxNQUN0RDZDLGNBQWNsQyxTQUFTVDtBQUFBQSxNQUN2QjRDLGFBQWE2QixPQUFPaEUsU0FBU1IsSUFBSTtBQUFBLE1BQ2pDNEMsZ0JBQWdCNEIsT0FBT2hFLFNBQVNILFVBQVUsQ0FBQztBQUFBLE1BQzNDQSxRQUFRbUUsT0FBT2hFLFNBQVNILFVBQVUsQ0FBQztBQUFBLE1BQ25DSixVQUFVTyxTQUFTUDtBQUFBQSxNQUNuQkUsZ0JBQWdCSyxTQUFTTDtBQUFBQSxNQUN6QkMsV0FBV0ksU0FBU0o7QUFBQUEsTUFDcEJ5QyxTQUFTckMsU0FBU0Y7QUFBQUEsTUFDbEJSLFVBQVVVLFNBQVNOO0FBQUFBLE1BQ25CSyxRQUFReEIsU0FBU3lCLFNBQVNELFNBQVM7QUFBQSxJQUN2QztBQUVBLFFBQUk7QUFDQXpCLDRCQUFzQixJQUFJO0FBRTFCLFVBQUlDLFFBQVE7QUFDUixjQUFNNUMsSUFBSXNJLElBQUksa0NBQWtDMUYsTUFBTSxJQUFJd0YsT0FBTztBQUFBLE1BQ3JFLE9BQU87QUFDSCxjQUFNcEksSUFBSXVJLEtBQUssbUNBQW1DSCxPQUFPO0FBQUEsTUFDN0Q7QUFFQUksa0JBQVk7QUFDWnBELDBCQUFvQjtBQUFBLElBQ3hCLFNBQVNTLE9BQU87QUFDWkMsY0FBUTJDLElBQUk1QyxLQUFLO0FBQUEsSUFDckIsVUFBQztBQUNHbEQsNEJBQXNCLEtBQUs7QUFDM0JKLHVCQUFpQixDQUFBMEMsU0FBUUEsT0FBTyxDQUFDO0FBQUEsSUFDckM7QUFBQSxFQUNKO0FBRUEsUUFBTWtELGVBQWVBLE1BQU07QUFDdkIsVUFBTU8sT0FBTyxDQUFDO0FBQ2QsUUFBSSxDQUFDckUsU0FBU1gsWUFBYWdGLE1BQUsxQyxXQUFXO0FBQzNDLFFBQUksQ0FBQzNCLFNBQVNILFVBQVVHLFNBQVNILFVBQVU7QUFDdkN3RSxXQUFLeEUsU0FBUztBQUNsQixRQUFJLENBQUNHLFNBQVNWLFNBQVUrRSxNQUFLL0UsV0FBVztBQUN4QyxRQUFJLENBQUNVLFNBQVNULE1BQU84RSxNQUFLOUUsUUFBUTtBQUNsQyxRQUFJUyxTQUFTUCxhQUFhLFFBQVE7QUFDOUIsVUFBSSxDQUFDTyxTQUFTTCxlQUFnQjBFLE1BQUsxRSxpQkFBaUI7QUFBQSxJQUN4RDtBQUNBUSxjQUFVa0UsSUFBSTtBQUNkLFdBQU9DLE9BQU9DLEtBQUtGLElBQUksRUFBRTlDLFdBQVc7QUFBQSxFQUN4QztBQUVBLFFBQU00QyxjQUFjQSxNQUFNO0FBQ3RCckcsaUJBQWEsS0FBSztBQUNsQlUsY0FBVSxJQUFJO0FBQ2R5QixnQkFBWWIsV0FBVztBQUN2QmUsY0FBVSxDQUFDLENBQUM7QUFBQSxFQUNoQjtBQUdBLFFBQU1xRSxVQUFVO0FBQUEsSUFDWixFQUFFOUIsS0FBSyxNQUFNK0IsUUFBUSxTQUFTO0FBQUE7QUFBQSxJQUU5QixFQUFFL0IsS0FBSyxnQkFBZ0IrQixRQUFRLFdBQVc7QUFBQSxJQUMxQyxFQUFFL0IsS0FBSyxnQkFBZ0IrQixRQUFRLFFBQVE7QUFBQSxJQUN2QyxFQUFFL0IsS0FBSyxlQUFlK0IsUUFBUSxPQUFPO0FBQUEsSUFDckMsRUFBRS9CLEtBQUssa0JBQWtCK0IsUUFBUTNGLGNBQWMsY0FBYyxnQkFBZ0IsaUJBQWlCO0FBQUEsSUFDOUYsRUFBRTRELEtBQUssWUFBWStCLFFBQVEsZUFBZTtBQUFBLElBQzFDLEVBQUUvQixLQUFLLGtCQUFrQitCLFFBQVEsaUJBQWlCO0FBQUEsSUFDbEQsRUFBRS9CLEtBQUssV0FBVytCLFFBQVEsVUFBVTtBQUFBLElBQ3BDLEVBQUUvQixLQUFLLFVBQVUrQixRQUFRLFNBQVM7QUFBQSxFQUFDO0FBSXZDLFFBQU1DLFlBQVk7QUFBQSxJQUNkO0FBQUEsTUFDSUMsSUFBSTtBQUFBLE1BQ0pDLE1BQU0sdUJBQUMsMEJBQXVCLE1BQU0sTUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQ3ZDakMsT0FBTztBQUFBLElBQ1g7QUFBQSxJQUNBO0FBQUEsTUFDSWdDLElBQUk7QUFBQSxNQUNKQyxNQUFNLHVCQUFDLGdCQUFhLE1BQU0sTUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1QjtBQUFBLE1BQzdCakMsT0FBTztBQUFBLElBQ1g7QUFBQSxJQUNBO0FBQUEsTUFDSWdDLElBQUk7QUFBQSxNQUNKQyxNQUFNLHVCQUFDLDBCQUF1QixNQUFNLE1BQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUN2Q2pDLE9BQU87QUFBQSxJQUNYO0FBQUEsSUFDQTtBQUFBLE1BQ0lnQyxJQUFJO0FBQUEsTUFDSkMsTUFBTSx1QkFBQywwQkFBdUIsTUFBTSxNQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDO0FBQUEsTUFDdkNqQyxPQUFPO0FBQUEsSUFDWDtBQUFBLElBQ0E7QUFBQSxNQUNJZ0MsSUFBSTtBQUFBLE1BQ0pDLE1BQU0sdUJBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlO0FBQUEsTUFDckJqQyxPQUFPO0FBQUEsSUFDWDtBQUFBLEVBQUM7QUFHTCxRQUFNa0Msa0JBQWtCckosUUFBUSxNQUFNO0FBQ2xDLFdBQU9tQyxjQUFjbUg7QUFBQUEsTUFDakIsQ0FBQ0MsS0FBS2hELFNBQVNnRCxPQUFPZixPQUFPakMsS0FBS0ssY0FBYyxLQUFLO0FBQUEsTUFDckQ7QUFBQSxJQUNKO0FBQUEsRUFDSixHQUFHLENBQUN6RSxhQUFhLENBQUM7QUFFbEIsU0FDSSxtQ0FDS1U7QUFBQUEsMEJBQXNCLHVCQUFDLHNCQUFtQixPQUFNLG1CQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlDO0FBQUEsSUFFaEUsdUJBQUMsU0FBSSxXQUFVLDJCQUNYO0FBQUEsNkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUNSLHVCQUFDLFNBQUksV0FBVSxlQUNYO0FBQUEsK0JBQUMsVUFBTyw2QkFBNkIsQ0FBQ3VGLE1BQU14RixjQUFjd0YsRUFBRW9CLE9BQU9DLEtBQUssR0FBRyxZQUFZLFFBQXZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEY7QUFBQSxRQUUzRjdFLFlBQVlFLGNBQ1QsdUJBQUMsU0FBSSxXQUFVLHVFQUNYO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxTQUFTRixZQUFZRztBQUFBQSxZQUNyQixNQUFNSCxZQUFZSTtBQUFBQSxZQUNsQjtBQUFBLFlBQ0E7QUFBQSxZQUNBLFNBQVMsTUFBTUgsZUFBZSxFQUFFLEdBQUdELGFBQWFFLFlBQVksTUFBTSxDQUFDO0FBQUE7QUFBQSxVQUx2RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLeUUsS0FON0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFFSix1QkFBQyxTQUFJLFdBQVUsUUFDWDtBQUFBLGlDQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVc7QUFBQSxVQUNYLHVCQUFDLFFBQUcsV0FBVSwrQkFBOEIsaUNBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZEO0FBQUEsVUFFN0QsdUJBQUMsYUFBUSxXQUFVLFFBQ2Y7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsc0VBQXFFLCtCQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUscURBR1g7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsd0JBQ1ZvRSxvQkFBVTVDO0FBQUFBLGdCQUFJLENBQUNvRCxTQUNaO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUVHLElBQUlBLEtBQUtQO0FBQUFBLG9CQUNULFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLFVBQUssV0FBVSxpQkFBaUJPLGVBQUtOLFFBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTJDO0FBQUEsc0JBQzFDTSxLQUFLdkM7QUFBQUE7QUFBQUE7QUFBQUEsa0JBTER1QyxLQUFLUDtBQUFBQSxrQkFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BO0FBQUEsY0FDSCxLQVZMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSw2RkFFWDtBQUFBLHVDQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBLHlDQUFDLFVBQUssV0FBVSw2QkFBNEIsaUNBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxVQUFLLFdBQVUsMkJBQ1hoSCx3QkFBYzRELFVBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsZ0JBRUEsdUJBQUMsVUFBSyxXQUFVLDBCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1QztBQUFBLGdCQUV2Qyx1QkFBQyxTQUFJLFdBQVUsMkJBQ1g7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsNkJBQTRCLDhCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsVUFBSyxXQUFVLDJCQUEwQjtBQUFBO0FBQUEsb0JBQ3BDc0QsZ0JBQWdCTSxlQUFlLE9BQU87QUFBQSx1QkFENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxtQkFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFzQkE7QUFBQSxpQkF2Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5Q0E7QUFBQSxlQTlDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQStDQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLG9CQUNYO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxTQUFTLE1BQU07QUFDWDNHLDBCQUFVLElBQUk7QUFDZHlCLDRCQUFZYixXQUFXO0FBQ3ZCdEIsNkJBQWEsSUFBSTtBQUFBLGNBQ3JCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FBbUY7QUFBQTtBQUFBLFlBTmpHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBLEtBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLGFBL0RKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnRUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSx1Q0FDVmUsZUFBS2lEO0FBQUFBLFVBQUksQ0FBQ3NELFFBQ1A7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVHLFdBQVcseUJBQXlCdEcsY0FBY3NHLE1BQzVDLDZDQUNBLGVBQWU7QUFBQSxjQUVyQixTQUFTLE1BQU1yRyxhQUFhcUcsR0FBRztBQUFBLGNBRTlCQSxrQkFBUSxZQUFZLG1DQUFFO0FBQUE7QUFBQSxnQkFBVSx1QkFBQyxVQUFLLFdBQVUsbUVBQzVDM0csc0JBQVlFLFdBRGdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRWpDO0FBQUEsZ0JBQU87QUFBQSxtQkFGYztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUViLElBQU0sbUNBQUU7QUFBQTtBQUFBLGdCQUFZLHVCQUFDLFVBQUssV0FBVSxrRUFDdkNGLHNCQUFZRyxhQURXO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRTVCO0FBQUEsbUJBRmM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFUDtBQUFBO0FBQUEsWUFYRndHO0FBQUFBLFlBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWFBO0FBQUEsUUFDSCxLQWhCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsUUFHQSx1QkFBQyxTQUNJdEc7QUFBQUEsd0JBQWMsYUFDWCx1QkFBQyxTQUFJLFdBQVUsaUJBR1ZmLHNCQUNHLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWUsSUFDZkosY0FBYzRELFVBQVUsSUFDeEIsdUJBQUMsU0FBTSxhQUFZLHFDQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRCxJQUVwRDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csTUFBTTVELGNBQWMwSDtBQUFBQSxnQkFBTyxDQUFDdEQsU0FDeEJBLEtBQUtPLGNBQ0NnRCxZQUFZLEVBQ2JDLFNBQVNwSCxXQUFXbUgsWUFBWSxDQUFDO0FBQUEsY0FDMUM7QUFBQSxjQUNBO0FBQUE7QUFBQSxZQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1xQixLQWQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQTtBQUFBLFVBRUh4RyxjQUFjLGVBQ1gsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDRDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWUE7QUFBQSxZQUVDZixZQUNHLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWUsSUFDZkosY0FBYzRELFVBQVUsSUFDeEIsdUJBQUMsU0FBTSxhQUFZLHFDQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRCxJQUVwRDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE1BQU01RCxjQUFjMEg7QUFBQUEsa0JBQU8sQ0FBQ3RELFNBQ3hCQSxLQUFLTyxjQUNDZ0QsWUFBWSxFQUNiQyxTQUFTcEgsV0FBV21ILFlBQVksQ0FBQztBQUFBLGdCQUMxQztBQUFBLGdCQUNBO0FBQUE7QUFBQSxjQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1xQjtBQUFBLGVBMUI3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZCQTtBQUFBLGFBbkRSO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxREE7QUFBQSxRQUdBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxPQUNJLHVCQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBLHFDQUFDLFNBQUksV0FBVSxtRUFDWCxpQ0FBQyxlQUFZLFdBQVUsbUJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNDLEtBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFVBQUssV0FBVSx5QkFDWC9HLG1CQUFTLDJCQUEyQiwyQkFEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUVKLE1BQU1WO0FBQUFBLFlBQ04sU0FBU3NHO0FBQUFBLFlBQ1QsT0FBTztBQUFBLFlBRVAsaUNBQUMsVUFBSyxVQUFVUixjQUFjLFdBQVUsaUJBRXBDO0FBQUEscUNBQUMsU0FBSSxXQUFVLGFBQ1g7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsNkRBQTREO0FBQUE7QUFBQSxrQkFDaEUsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBLHFCQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0c7QUFBQSxvQkFDQSxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLGFBQVk7QUFBQSxvQkFDWixPQUFPM0QsU0FBU1gsZUFBZW1HO0FBQUFBLG9CQUMvQixrQkFBaUI7QUFBQSxvQkFDakIsY0FBYyxDQUFDQyxPQUFPQyxXQUNsQkEsUUFBUS9DLE9BQU8yQyxZQUFZLEVBQUVDLFNBQVNFLE1BQU1ILFlBQVksQ0FBQztBQUFBLG9CQUU3RCxVQUFVLENBQUNLLFFBQ1AxRixZQUFZLEVBQUUsR0FBR0QsVUFBVVgsYUFBYXNHLElBQUksQ0FBQztBQUFBLG9CQUdoRGxJLG9CQUFVcUU7QUFBQUEsc0JBQUksQ0FBQzhELFFBQ1o7QUFBQSx3QkFBQyxPQUFPO0FBQUEsd0JBQVA7QUFBQSwwQkFFRyxPQUFPQSxJQUFJN0M7QUFBQUEsMEJBQ1gsT0FBTyxHQUFHNkMsSUFBSXJELElBQUksSUFBSXFELElBQUlDLFlBQVk7QUFBQSwwQkFFdEMsaUNBQUMsU0FBSSxXQUFVLDJCQUNYO0FBQUEsbURBQUMsU0FBSSxXQUFVLHVHQUNWRCxjQUFJckQsS0FBS3VELE9BQU8sQ0FBQyxFQUFFQyxZQUFZLEtBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQSw0QkFDQ0gsSUFBSXJEO0FBQUFBLDRCQUFLO0FBQUEsNEJBQUlxRCxJQUFJQyxlQUFlRCxJQUFJQyxlQUFlRCxJQUFJSTtBQUFBQSwrQkFKNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FLQTtBQUFBO0FBQUEsd0JBVEtKLElBQUk3QztBQUFBQSx3QkFEYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQVdBO0FBQUEsb0JBQ0g7QUFBQTtBQUFBLGtCQTNCTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBNEJBO0FBQUEsZ0JBQ0M3QyxPQUFPeUIsWUFDSix1QkFBQyxPQUFFLFdBQVUscURBQ1Q7QUFBQSx5Q0FBQyxVQUFLLFdBQVUscUNBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtEO0FBQUEsa0JBQ2pEekIsT0FBT3lCO0FBQUFBLHFCQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxtQkFyQ1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF1Q0E7QUFBQSxjQUlBLHVCQUFDLFNBQUksV0FBVSxhQUNYO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDZEQUNiO0FBQUEseUNBQUMsY0FBVyxXQUFVLDJCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QztBQUFBLGtCQUFHO0FBQUEscUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsMEJBR1g7QUFBQSx5Q0FBQyxTQUNHO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0csV0FBVTtBQUFBLHdCQUNWLE9BQU8zQixTQUFTVCxTQUFTO0FBQUEsd0JBQ3pCLFVBQVUsQ0FBQ3FFLE1BQ1AzRCxZQUFZLEVBQUUsR0FBR0QsVUFBVVQsT0FBT3FFLEVBQUVvQixPQUFPQyxNQUFNLENBQUM7QUFBQSx3QkFFdEQsVUFBVTFHLFNBQVMsT0FBTztBQUFBLHdCQUUxQjtBQUFBLGlEQUFDLFlBQU8sT0FBTSxJQUFHLDRCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUE2QjtBQUFBLDBCQUM3Qix1QkFBQyxZQUFPLE9BQU0sV0FBVSx1QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBK0I7QUFBQSwwQkFDL0IsdUJBQUMsWUFBTyxPQUFNLFlBQVcsd0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWlDO0FBQUEsMEJBQ2pDLHVCQUFDLFlBQU8sT0FBTSxTQUFRLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUEyQjtBQUFBLDBCQUMzQix1QkFBQyxZQUFPLE9BQU0sU0FBUSxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBMkI7QUFBQSwwQkFDM0IsdUJBQUMsWUFBTyxPQUFNLE9BQU0sbUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQXVCO0FBQUEsMEJBQ3ZCLHVCQUFDLFlBQU8sT0FBTSxRQUFPLG9CQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUF5QjtBQUFBLDBCQUN6Qix1QkFBQyxZQUFPLE9BQU0sUUFBTyxvQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBeUI7QUFBQSwwQkFDekIsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQTZCO0FBQUEsMEJBQzdCLHVCQUFDLFlBQU8sT0FBTSxhQUFZLHlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFtQztBQUFBLDBCQUNuQyx1QkFBQyxZQUFPLE9BQU0sV0FBVSx1QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBK0I7QUFBQSwwQkFDL0IsdUJBQUMsWUFBTyxPQUFNLFlBQVcsd0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWlDO0FBQUEsMEJBQ2pDLHVCQUFDLFlBQU8sT0FBTSxZQUFXLHdCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFpQztBQUFBO0FBQUE7QUFBQSxzQkFwQnJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFxQkE7QUFBQSxvQkFDQzJCLE9BQU9YLFNBQ0osdUJBQUMsT0FBRSxXQUFVLHFEQUNUO0FBQUEsNkNBQUMsVUFBSyxXQUFVLHFDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFrRDtBQUFBLHNCQUNqRFcsT0FBT1g7QUFBQUEseUJBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLHVCQTNCUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQTZCQTtBQUFBLGtCQUVBLHVCQUFDLFNBQ0c7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDRyxXQUFVO0FBQUEsd0JBQ1YsT0FBT1MsU0FBU1IsUUFBUTtBQUFBLHdCQUN4QixVQUFVLENBQUNvRSxNQUNQM0QsWUFBWSxFQUFFLEdBQUdELFVBQVVSLE1BQU13RSxPQUFPSixFQUFFb0IsT0FBT0MsS0FBSyxFQUFFLENBQUM7QUFBQSx3QkFFN0QsVUFBVTFHLFNBQVMsT0FBTztBQUFBLHdCQUUxQjtBQUFBLGlEQUFDLFlBQU8sT0FBTSxJQUFHLDJCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUE0QjtBQUFBLDBCQUMzQjBILE1BQU1DLEtBQUssRUFBRTNFLFFBQVEsR0FBRyxHQUFHLENBQUM0RSxHQUFHQyxNQUFNO0FBQ2xDLGtDQUFNNUcsUUFBTyxvQkFBSVAsS0FBSyxHQUFFb0gsWUFBWSxJQUFJLElBQUlEO0FBQzVDLG1DQUNJLHVCQUFDLFlBQWtCLE9BQU81RyxNQUNyQkEsa0JBRFFBLE1BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FFQTtBQUFBLDBCQUVSLENBQUM7QUFBQTtBQUFBO0FBQUEsc0JBaEJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFpQkE7QUFBQSxvQkFDQ1UsT0FBT1YsUUFDSix1QkFBQyxPQUFFLFdBQVUscURBQ1Q7QUFBQSw2Q0FBQyxVQUFLLFdBQVUscUNBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWtEO0FBQUEsc0JBQ2pEVSxPQUFPVjtBQUFBQSx5QkFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsdUJBdkJSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBeUJBO0FBQUEscUJBM0RKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBNERBO0FBQUEsbUJBbEVKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbUVBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsYUFDWDtBQUFBLHVDQUFDLFdBQU0sV0FBVSw2REFDYjtBQUFBLHlDQUFDLGVBQVksV0FBVSwyQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEM7QUFBQSxrQkFBRztBQUFBLGtCQUMxQyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEscUJBRjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsWUFDWDtBQUFBLHlDQUFDLFVBQUssV0FBVSxzRUFBcUUsaUJBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDRyxNQUFLO0FBQUEsc0JBQ0wsTUFBSztBQUFBLHNCQUNMLFdBQVU7QUFBQSxzQkFDVixhQUFZO0FBQUEsc0JBQ1osT0FBT1EsU0FBU0g7QUFBQUEsc0JBQ2hCLFVBQVUsQ0FBQytELE1BQ1AzRCxZQUFZLEVBQUUsR0FBR0QsVUFBVUgsUUFBUStELEVBQUVvQixPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLG9CQVAzRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBUUs7QUFBQSxxQkFaVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWNBO0FBQUEsZ0JBUUMvRSxPQUFPTCxVQUNKLHVCQUFDLE9BQUUsV0FBVSxnREFDVDtBQUFBLHlDQUFDLFVBQUssV0FBVSxxQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0Q7QUFBQSxrQkFDakRLLE9BQU9MO0FBQUFBLHFCQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxtQkEvQlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQ0E7QUFBQSxjQUlBLHVCQUFDLFNBQUksV0FBVSxhQUNYO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDZEQUNiO0FBQUEseUNBQUMsY0FBVyxXQUFVLDJCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QztBQUFBLGtCQUFHO0FBQUEscUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsWUFDWDtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLE9BQU9HLFNBQVNOO0FBQUFBLG9CQUNoQixVQUFVLENBQUNrRSxNQUNQM0QsWUFBWSxFQUFFLEdBQUdELFVBQVVOLFdBQVdrRSxFQUFFb0IsT0FBT0MsTUFBTSxDQUFDO0FBQUE7QUFBQSxrQkFMOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1LLEtBUFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFTQTtBQUFBLG1CQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZUE7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSxhQUNYO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDZEQUNiO0FBQUEseUNBQUMsZ0JBQWEsV0FBVSwyQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0M7QUFBQSxrQkFBRztBQUFBLHFCQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0csTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDVixPQUFPakYsU0FBU1A7QUFBQUEsb0JBQ2hCLFVBQVUsQ0FBQ2tHLFFBQVExRixZQUFZLEVBQUUsR0FBR0QsVUFBVVAsVUFBVWtHLElBQUksQ0FBQztBQUFBLG9CQUU3RDtBQUFBLDZDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sUUFDakIsaUNBQUMsU0FBSSxXQUFVLDJCQUEwQixvQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkMsS0FEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sVUFDakIsaUNBQUMsU0FBSSxXQUFVLDJCQUEwQiwwQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBbUQsS0FEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sVUFDakIsaUNBQUMsU0FBSSxXQUFVLDJCQUEwQixzQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBK0MsS0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBO0FBQUE7QUFBQSxrQkFkSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBZUE7QUFBQSxtQkFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxQkE7QUFBQSxjQUdDM0YsU0FBU1AsYUFBYSxVQUNuQix1QkFBQyxTQUFJLFdBQVUsNEJBQ1g7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsNkRBQ2I7QUFBQSx5Q0FBQyxVQUFPLFdBQVUsMkJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlDO0FBQUEsa0JBQ3hDTyxTQUFTUCxhQUFhLFdBQ2pCLGtCQUNBO0FBQUEscUJBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNHLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQ1YsYUFDSU8sU0FBU1AsYUFBYSxXQUNoQix3QkFDQTtBQUFBLG9CQUVWLE9BQU9PLFNBQVNMO0FBQUFBLG9CQUNoQixVQUFVLENBQUNpRSxNQUNQM0QsWUFBWSxFQUFFLEdBQUdELFVBQVVMLGdCQUFnQmlFLEVBQUVvQixPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLGtCQVZuRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBV0s7QUFBQSxnQkFFSi9FLE9BQU9QLGtCQUNKLHVCQUFDLE9BQUUsV0FBVSxnREFDVDtBQUFBLHlDQUFDLFVBQUssV0FBVSxxQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0Q7QUFBQSxrQkFDakRPLE9BQU9QO0FBQUFBLHFCQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxtQkF4QlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkEwQkE7QUFBQSxjQUtKLHVCQUFDLFNBQUksV0FBVSxhQUNYO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDZEQUNiO0FBQUEseUNBQUMsY0FBVyxXQUFVLDJCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QztBQUFBLGtCQUFHO0FBQUEscUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxNQUFNO0FBQUEsb0JBQ04sV0FBVTtBQUFBLG9CQUNWLGFBQVk7QUFBQSxvQkFDWixPQUFPSyxTQUFTRjtBQUFBQSxvQkFDaEIsVUFBVSxDQUFDOEQsTUFDUDNELFlBQVksRUFBRSxHQUFHRCxVQUFVRixNQUFNOEQsRUFBRW9CLE9BQU9DLE1BQU0sQ0FBQztBQUFBO0FBQUEsa0JBTnpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPSztBQUFBLG1CQVpUO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxjQUdDMUcsVUFBVSx1QkFBQyxTQUFJLFdBQVUsYUFDdEI7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsNkRBQ2I7QUFBQSx5Q0FBQyxnQkFBYSxXQUFVLDJCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQztBQUFBLGtCQUFHO0FBQUEscUJBRHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLE9BQU95QixVQUFVRDtBQUFBQSxvQkFDakIsVUFBVSxDQUFDNEYsUUFBUTFGLFlBQVksRUFBRSxHQUFHRCxVQUFVRCxRQUFRNEYsSUFBSSxDQUFDO0FBQUEsb0JBRTNEO0FBQUEsNkNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxXQUNqQixpQ0FBQyxTQUFJLFdBQVUsMkJBQTBCLHVCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnRCxLQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxhQUNqQixpQ0FBQyxTQUFJLFdBQVUsMkJBQTBCLHlCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFrRCxLQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUE7QUFBQTtBQUFBLGtCQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFZQTtBQUFBLG1CQWpCTztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWtCWDtBQUFBLGNBSUEsdUJBQUMsU0FBSSxXQUFVLGlDQUNYO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBRVRwSCxtQkFBUyw2QkFBNkI7QUFBQTtBQUFBLGdCQUozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQSxLQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxpQkFoUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpUkE7QUFBQTtBQUFBLFVBaFNKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWlTQTtBQUFBLFdBN2JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4YkE7QUFBQSxTQWhjSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaWNBO0FBQUEsT0FwY0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFjQTtBQUVSO0FBQUVmLEdBL3VCSUQsa0JBQWdCO0FBQUErSSxLQUFoQi9JO0FBaXZCTixlQUFlQTtBQUFpQixJQUFBK0k7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJhcGkiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydCIsIk5hdmJhciIsIlNlbGVjdCIsIkRyb3Bkb3duIiwiRHJhd2VyIiwiTW9kYWwiLCJFbXB0eSIsIkFsZXJ0IiwiSW9NZE1vcmUiLCJCYWNrZHJvcEJsdXJMb2FkZXIiLCJudW1iZXJUb0luZGlhbldvcmRzIiwiRmlDYWxlbmRhciIsIkZpQ3JlZGl0Q2FyZCIsIkZpSGFzaCIsIkZpRmlsZVRleHQiLCJGYVJ1cGVlU2lnbiIsIkNpcmN1bGFyTG9hZGVyIiwiR3JTdGF0dXNHb29kIiwiZm9ybSIsInMiLCJMaW5rIiwiUmlNb25leVJ1cGVlQ2lyY2xlRmlsbCIsIm0iLCJNZE91dGxpbmVNYW4iLCJCcmVhZGNydW1iIiwiVXNlciIsIkFkZGl0aW9uYWxTYWxhcnkiLCJfcyIsImVtcGxveWVlcyIsInNldEVtcGxveWVlcyIsInRhYmxlUGF5bWVudHMiLCJzZXRUYWJsZVBheW1lbnRzIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsIm9wZW5CYWNrZHJvcExvYWRlciIsInNldE9wZW5CYWNrZHJvcExvYWRlciIsImVkaXRJZCIsInNldEVkaXRJZCIsInRvdGFsQ291bnQiLCJzZXRUb3RhbENvdW50IiwicGVuZGluZyIsImNvbXBsZXRlZCIsInRhYnMiLCJhY3RpdmVUYWIiLCJzZXRBY3RpdmVUYWIiLCJ0b2RheSIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNwbGl0IiwiaW5pdGlhbEZvcm0iLCJlbXBsb3llZV9pZCIsInBheV9kYXRlIiwibW9udGgiLCJ5ZWFyIiwicGF5X3R5cGUiLCJwYWlkX2RhdGUiLCJ0cmFuc2FjdGlvbl9pZCIsImNoZXF1ZV9pZCIsImFtb3VudCIsIm5vdGUiLCJzdGF0dXMiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwidHlwZSIsIm5vUmVsb2FkIiwidGltZXIiLCJzZXRUaW1lb3V0IiwicHJldiIsImNsZWFyVGltZW91dCIsImZldGNoRW1wbG95ZWVzIiwiZmV0Y2hBZHZhbmNlSGlzdG9yeSIsImZldGNoVG90YWxDb3VudHMiLCJwZW5kaW5nUmVzIiwiY29tcGxldGVkUmVzIiwiUHJvbWlzZSIsImFsbCIsImdldCIsImRhdGEiLCJsZW5ndGgiLCJlcnJvciIsImNvbnNvbGUiLCJyZXMiLCJlbXBsb3llZSIsInJlc3BvbnNlIiwiZm9ybWF0dGVkIiwibWFwIiwiaXRlbSIsImluZGV4IiwiaWQiLCJzYWxhcnlfbW9udGgiLCJzYWxhcnlfeWVhciIsInBheWFibGVfYW1vdW50IiwicmVtYXJrcyIsImVtcGxveWVlTmFtZSIsIm5hbWUiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImxhYmVsIiwib25DbGljayIsImhhbmRsZUVkaXQiLCJzaG93RGVsZXRlQ29uZmlybSIsIl9pZCIsImVyciIsImNvbmZpcm0iLCJ0aXRsZSIsImNvbnRlbnQiLCJva1RleHQiLCJva1R5cGUiLCJjYW5jZWxUZXh0Iiwib25PayIsImhhbmRsZURlbGV0ZSIsImVtcGxveWVlSWQiLCJkZWxldGUiLCJoYW5kbGVTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJ2YWxpZGF0ZUZvcm0iLCJwYXlsb2FkIiwiTnVtYmVyIiwicHV0IiwicG9zdCIsImNsb3NlRHJhd2VyIiwibG9nIiwiZXJycyIsIk9iamVjdCIsImtleXMiLCJjb2x1bW5zIiwiaGVhZGVyIiwiTkFWX0xJTktTIiwidG8iLCJpY29uIiwidG90YWxQYXlhYmxlU3VtIiwicmVkdWNlIiwic3VtIiwidGFyZ2V0IiwidmFsdWUiLCJsaW5rIiwidG9Mb2NhbGVTdHJpbmciLCJ0YWIiLCJmaWx0ZXIiLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwidW5kZWZpbmVkIiwiaW5wdXQiLCJvcHRpb24iLCJ2YWwiLCJlbXAiLCJlbXBsb3llZUNvZGUiLCJjaGFyQXQiLCJ0b1VwcGVyQ2FzZSIsInVuaXF1ZV9jb2RlIiwiQXJyYXkiLCJmcm9tIiwiXyIsImkiLCJnZXRGdWxsWWVhciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFkZGl0aW9uYWxTYWxhcnkuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlTWVtbywgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0XCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IHsgU2VsZWN0LCBEcm9wZG93biwgRHJhd2VyLCBNb2RhbCwgRW1wdHksIEFsZXJ0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IEJhY2tkcm9wQmx1ckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0JhY2tkcm9wQmx1ckxvYWRlclwiO1xyXG5pbXBvcnQgeyBudW1iZXJUb0luZGlhbldvcmRzIH0gZnJvbSBcIi4uL2hlbHBlcnMvbnVtYmVyVG9JbmRpYW5Xb3Jkc1wiO1xyXG5pbXBvcnQgeyBGaUNhbGVuZGFyLCBGaUNyZWRpdENhcmQsIEZpSGFzaCwgRmlGaWxlVGV4dCB9IGZyb20gXCJyZWFjdC1pY29ucy9maVwiO1xyXG5pbXBvcnQgeyBGYVJ1cGVlU2lnbiB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgeyBHclN0YXR1c0dvb2QgfSBmcm9tIFwicmVhY3QtaWNvbnMvZ3JcIjtcclxuaW1wb3J0IHsgZm9ybSwgcyB9IGZyb20gXCJmcmFtZXItbW90aW9uL2NsaWVudFwiO1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgUmlNb25leVJ1cGVlQ2lyY2xlRmlsbCB9IGZyb20gXCJyZWFjdC1pY29ucy9yaVwiO1xyXG5pbXBvcnQgeyBtIH0gZnJvbSBcImZyYW1lci1tb3Rpb25cIjtcclxuaW1wb3J0IHsgTWRPdXRsaW5lTWFuIH0gZnJvbSBcInJlYWN0LWljb25zL21kXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuaW1wb3J0IHsgVXNlciB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuXHJcbmNvbnN0IEFkZGl0aW9uYWxTYWxhcnkgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW3RhYmxlUGF5bWVudHMsIHNldFRhYmxlUGF5bWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW3Nob3dNb2RhbCwgc2V0U2hvd01vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbcmVsb2FkVHJpZ2dlciwgc2V0UmVsb2FkVHJpZ2dlcl0gPSB1c2VTdGF0ZSgwKTtcclxuICAgIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW29wZW5CYWNrZHJvcExvYWRlciwgc2V0T3BlbkJhY2tkcm9wTG9hZGVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtlZGl0SWQsIHNldEVkaXRJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICAgIGNvbnN0IFt0b3RhbENvdW50LCBzZXRUb3RhbENvdW50XSA9IHVzZVN0YXRlKHsgcGVuZGluZzogMCwgY29tcGxldGVkOiAwIH0pXHJcbiAgICBjb25zdCB0YWJzID0gW1wiUGVuZGluZ1wiLCBcIkNvbXBsZXRlZFwiXTtcclxuXHJcbiAgICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGUodGFic1swXSk7XHJcblxyXG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdO1xyXG5cclxuICAgIGNvbnN0IGluaXRpYWxGb3JtID0ge1xyXG4gICAgICAgIGVtcGxveWVlX2lkOiBcIlwiLFxyXG4gICAgICAgIHBheV9kYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICAgIG1vbnRoOiBudWxsLFxyXG4gICAgICAgIHllYXI6IG51bGwsXHJcbiAgICAgICAgcGF5X3R5cGU6IFwiY2FzaFwiLFxyXG4gICAgICAgIHBhaWRfZGF0ZTogdG9kYXksXHJcbiAgICAgICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICAgICAgY2hlcXVlX2lkOiBcIlwiLFxyXG4gICAgICAgIGFtb3VudDogMCxcclxuICAgICAgICBub3RlOiBcIlwiLFxyXG4gICAgICAgIHN0YXR1czogXCJcIlxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKGluaXRpYWxGb3JtKTtcclxuICAgIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgICAgICBtZXNzYWdlOiBcIlwiLFxyXG4gICAgICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gICAgICAgIG5vUmVsb2FkOiB0cnVlLFxyXG4gICAgfSk7XHJcblxyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgaWYgKGFsZXJ0Q29uZmlnLnZpc2liaWxpdHkpIHtcclxuICAgICAgICAgICAgY29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSk7XHJcbiAgICAgICAgICAgIH0sIDMwMDApO1xyXG4gICAgICAgICAgICByZXR1cm4gKCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVyKTtcclxuICAgICAgICB9XHJcbiAgICB9LCBbYWxlcnRDb25maWcudmlzaWJpbGl0eV0pO1xyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgZmV0Y2hFbXBsb3llZXMoKTtcclxuICAgICAgICBmZXRjaEFkdmFuY2VIaXN0b3J5KCk7XHJcblxyXG4gICAgfSwgW2FjdGl2ZVRhYl0pO1xyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBmZXRjaFRvdGFsQ291bnRzKClcclxuICAgIH0sIFtyZWxvYWRUcmlnZ2VyXSlcclxuXHJcbiAgICBjb25zdCBmZXRjaFRvdGFsQ291bnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IFtwZW5kaW5nUmVzLCBjb21wbGV0ZWRSZXNdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgICAgICAgICAgYXBpLmdldChgYWRkaXRpb25hbC1zYWxhcnktcGF5bWVudC1vdXQ/c3RhdHVzPVBlbmRpbmdgKSxcclxuICAgICAgICAgICAgICAgIGFwaS5nZXQoYGFkZGl0aW9uYWwtc2FsYXJ5LXBheW1lbnQtb3V0P3N0YXR1cz1Db21wbGV0ZWRgKVxyXG4gICAgICAgICAgICBdKTtcclxuXHJcbiAgICAgICAgICAgIHNldFRvdGFsQ291bnQoe1xyXG4gICAgICAgICAgICAgICAgcGVuZGluZzogcGVuZGluZ1Jlcy5kYXRhLmRhdGE/Lmxlbmd0aCB8fCAwLFxyXG4gICAgICAgICAgICAgICAgY29tcGxldGVkOiBjb21wbGV0ZWRSZXMuZGF0YS5kYXRhPy5sZW5ndGggfHwgMCxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGNvdW50czpcIiwgZXJyb3IpO1xyXG4gICAgICAgICAgICBzZXRUb3RhbENvdW50KHsgcGVuZGluZzogMCwgY29tcGxldGVkOiAwIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi9lbXBsb3llZVwiKTtcclxuICAgICAgICBpZiAocmVzLmRhdGEuc3RhdHVzKSBzZXRFbXBsb3llZXMocmVzLmRhdGEuZW1wbG95ZWUpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBmZXRjaEFkdmFuY2VIaXN0b3J5ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGxldCBzdGF0dXMgPSBhY3RpdmVUYWIgPT09IFwiUGVuZGluZ1wiID8gXCJQZW5kaW5nXCIgOiBcIkNvbXBsZXRlZFwiO1xyXG4gICAgICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL2FkZGl0aW9uYWwtc2FsYXJ5LXBheW1lbnQtb3V0P3N0YXR1cz0ke3N0YXR1c31gKTtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IHJlc3BvbnNlLmRhdGEuZGF0YT8ubWFwKChpdGVtLCBpbmRleCkgPT4gKHtcclxuICAgICAgICAgICAgICAgIC4uLml0ZW0sXHJcbiAgICAgICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICAgICAgcGF5X2RhdGU6IGl0ZW0/LnBheV9kYXRlLnNwbGl0KFwiVFwiKVswXSB8fCBcIk4vQVwiXHJcbiAgICAgICAgICAgICAgICAvLyA/IG5ldyBEYXRlKGl0ZW0/LnBheV9kYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1HQlwiLCB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgZGF5OiBcIm51bWVyaWNcIixcclxuICAgICAgICAgICAgICAgIC8vICAgICBtb250aDogXCJsb25nXCIsXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgeWVhcjogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICAgICAgICAvLyB9KVxyXG4gICAgICAgICAgICAgICAgLFxyXG4gICAgICAgICAgICAgICAgc2FsYXJ5X21vbnRoOiBpdGVtPy5zYWxhcnlfbW9udGgsXHJcbiAgICAgICAgICAgICAgICBzYWxhcnlfeWVhcjogaXRlbT8uc2FsYXJ5X3llYXIsXHJcbiAgICAgICAgICAgICAgICBwYXlhYmxlX2Ftb3VudDogaXRlbT8ucGF5YWJsZV9hbW91bnQsXHJcbiAgICAgICAgICAgICAgICByZW1hcmtzOiBpdGVtPy5yZW1hcmtzIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgICBlbXBsb3llZU5hbWU6IGl0ZW0uZW1wbG95ZWVfaWQ/Lm5hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiBcIjFcIiwgbGFiZWw6IFwiRWRpdFwiLCBvbkNsaWNrOiAoKSA9PiBoYW5kbGVFZGl0KGl0ZW0pIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+RGVsZXRlPC9zcGFuPixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljazogKCkgPT4gc2hvd0RlbGV0ZUNvbmZpcm0oaXRlbS5faWQpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciB0ZXh0LXhsXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICBzZXRUYWJsZVBheW1lbnRzKGZvcm1hdHRlZCk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgY29uc3Qgc2hvd0RlbGV0ZUNvbmZpcm0gPSAoaWQpID0+IHtcclxuICAgICAgICBNb2RhbC5jb25maXJtKHtcclxuICAgICAgICAgICAgdGl0bGU6IFwiQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSB0aGlzIHJlY29yZD9cIixcclxuICAgICAgICAgICAgY29udGVudDogXCJUaGlzIGFjdGlvbiBjYW5ub3QgYmUgdW5kb25lLlwiLFxyXG4gICAgICAgICAgICBva1RleHQ6IFwiWWVzLCBEZWxldGVcIixcclxuICAgICAgICAgICAgb2tUeXBlOiBcImRhbmdlclwiLFxyXG4gICAgICAgICAgICBjYW5jZWxUZXh0OiBcIk5vXCIsXHJcbiAgICAgICAgICAgIG9uT2soKSB7XHJcbiAgICAgICAgICAgICAgICBoYW5kbGVEZWxldGUoaWQpO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuICAgIGNvbnN0IGhhbmRsZUVkaXQgPSAoaXRlbSkgPT4ge1xyXG5cclxuICAgICAgICBjb25zdCBlbXBsb3llZUlkID1cclxuICAgICAgICAgICAgdHlwZW9mIGl0ZW0uZW1wbG95ZWVfaWQgPT09IFwib2JqZWN0XCJcclxuICAgICAgICAgICAgICAgID8gaXRlbS5lbXBsb3llZV9pZC5faWRcclxuICAgICAgICAgICAgICAgIDogaXRlbS5lbXBsb3llZV9pZDtcclxuICAgICAgICBzZXRFZGl0SWQoaXRlbS5faWQpO1xyXG4gICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgZW1wbG95ZWVfaWQ6IGVtcGxveWVlSWQsXHJcbiAgICAgICAgICAgIHBheV9kYXRlOiBpdGVtLnBheV9kYXRlLFxyXG4gICAgICAgICAgICBwYWlkX2RhdGU6IGl0ZW0ucGF5X2RhdGUgPyBpdGVtLnBheV9kYXRlLnNwbGl0KFwiVFwiKVswXSA6IFwiXCIsXHJcbiAgICAgICAgICAgIG1vbnRoOiBpdGVtLnNhbGFyeV9tb250aCxcclxuICAgICAgICAgICAgeWVhcjogaXRlbS5zYWxhcnlfeWVhcixcclxuICAgICAgICAgICAgcGF5X3R5cGU6IGl0ZW0ucGF5X3R5cGUsXHJcbiAgICAgICAgICAgIHRyYW5zYWN0aW9uX2lkOiBpdGVtLnRyYW5zYWN0aW9uX2lkIHx8IFwiXCIsXHJcbiAgICAgICAgICAgIGFtb3VudDogaXRlbS5hbW91bnQsXHJcbiAgICAgICAgICAgIG5vdGU6IGl0ZW0ucmVtYXJrcyB8fCBcIlwiLFxyXG4gICAgICAgICAgICBzdGF0dXM6IGl0ZW0uc3RhdHVzLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldFNob3dNb2RhbCh0cnVlKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlRGVsZXRlID0gYXN5bmMgKGlkKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgc2V0T3BlbkJhY2tkcm9wTG9hZGVyKHRydWUpO1xyXG4gICAgICAgICAgICBhd2FpdCBhcGkuZGVsZXRlKGAvYWRkaXRpb25hbC1zYWxhcnktcGF5bWVudC1vdXQvJHtpZH1gKTtcclxuICAgICAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiRGF0YSBEZWxldGVkIFN1Y2Nlc3NmdWxseSFcIixcclxuICAgICAgICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgICAgICAgICAgbm9SZWxvYWQ6IHRydWUsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBmZXRjaEFkdmFuY2VIaXN0b3J5KCk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiRGVsZXRlIGZhaWxlZFwiLFxyXG4gICAgICAgICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgICAgICAgICAgbm9SZWxvYWQ6IHRydWUsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgICAgIHNldE9wZW5CYWNrZHJvcExvYWRlcihmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cclxuICAgICAgICBpZiAoIXZhbGlkYXRlRm9ybSgpKSByZXR1cm47XHJcblxyXG5cclxuICAgICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgICAgICAuLi4oZWRpdElkID8ge30gOiB7IGVtcGxveWVlX2lkOiBmb3JtRGF0YS5lbXBsb3llZV9pZCB9KSxcclxuICAgICAgICAgICAgc2FsYXJ5X21vbnRoOiBmb3JtRGF0YS5tb250aCxcclxuICAgICAgICAgICAgc2FsYXJ5X3llYXI6IE51bWJlcihmb3JtRGF0YS55ZWFyKSxcclxuICAgICAgICAgICAgcGF5YWJsZV9hbW91bnQ6IE51bWJlcihmb3JtRGF0YS5hbW91bnQgfHwgMCksXHJcbiAgICAgICAgICAgIGFtb3VudDogTnVtYmVyKGZvcm1EYXRhLmFtb3VudCB8fCAwKSxcclxuICAgICAgICAgICAgcGF5X3R5cGU6IGZvcm1EYXRhLnBheV90eXBlLFxyXG4gICAgICAgICAgICB0cmFuc2FjdGlvbl9pZDogZm9ybURhdGEudHJhbnNhY3Rpb25faWQsXHJcbiAgICAgICAgICAgIGNoZXF1ZV9pZDogZm9ybURhdGEuY2hlcXVlX2lkLFxyXG4gICAgICAgICAgICByZW1hcmtzOiBmb3JtRGF0YS5ub3RlLFxyXG4gICAgICAgICAgICBwYXlfZGF0ZTogZm9ybURhdGEucGFpZF9kYXRlLFxyXG4gICAgICAgICAgICBzdGF0dXM6IGVkaXRJZCA/IGZvcm1EYXRhLnN0YXR1cyA6IFwiQ29tcGxldGVkXCJcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBzZXRPcGVuQmFja2Ryb3BMb2FkZXIodHJ1ZSk7XHJcblxyXG4gICAgICAgICAgICBpZiAoZWRpdElkKSB7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBhcGkucHV0KGAvYWRkaXRpb25hbC1zYWxhcnktcGF5bWVudC1vdXQvJHtlZGl0SWR9YCwgcGF5bG9hZCk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBhcGkucG9zdChcIi9hZGRpdGlvbmFsLXNhbGFyeS1wYXltZW50LW91dC9cIiwgcGF5bG9hZCk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGNsb3NlRHJhd2VyKCk7XHJcbiAgICAgICAgICAgIGZldGNoQWR2YW5jZUhpc3RvcnkoKTtcclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAgICAgc2V0T3BlbkJhY2tkcm9wTG9hZGVyKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcihwcmV2ID0+IHByZXYgKyAxKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IHZhbGlkYXRlRm9ybSA9ICgpID0+IHtcclxuICAgICAgICBjb25zdCBlcnJzID0ge307XHJcbiAgICAgICAgaWYgKCFmb3JtRGF0YS5lbXBsb3llZV9pZCkgZXJycy5lbXBsb3llZSA9IFwiUmVxdWlyZWRcIjtcclxuICAgICAgICBpZiAoIWZvcm1EYXRhLmFtb3VudCB8fCBmb3JtRGF0YS5hbW91bnQgPD0gMClcclxuICAgICAgICAgICAgZXJycy5hbW91bnQgPSBcIkVudGVyIHZhbGlkIGFtb3VudFwiO1xyXG4gICAgICAgIGlmICghZm9ybURhdGEucGF5X2RhdGUpIGVycnMucGF5X2RhdGUgPSBcIlJlcXVpcmVkXCI7XHJcbiAgICAgICAgaWYgKCFmb3JtRGF0YS5tb250aCkgZXJycy5tb250aCA9IFwiUmVxdWlyZWRcIjtcclxuICAgICAgICBpZiAoZm9ybURhdGEucGF5X3R5cGUgIT09IFwiY2FzaFwiKSB7XHJcbiAgICAgICAgICAgIGlmICghZm9ybURhdGEudHJhbnNhY3Rpb25faWQpIGVycnMudHJhbnNhY3Rpb25faWQgPSBcIlJlcXVpcmVkXCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHNldEVycm9ycyhlcnJzKTtcclxuICAgICAgICByZXR1cm4gT2JqZWN0LmtleXMoZXJycykubGVuZ3RoID09PSAwO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBjbG9zZURyYXdlciA9ICgpID0+IHtcclxuICAgICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgIHNldEVkaXRJZChudWxsKTtcclxuICAgICAgICBzZXRGb3JtRGF0YShpbml0aWFsRm9ybSk7XHJcbiAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgIH07XHJcblxyXG5cclxuICAgIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICAgICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICAgICAgLy8geyBrZXk6IFwicGF5X2RhdGVcIiwgaGVhZGVyOiBcIlBhaWQgRGF0ZVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiZW1wbG95ZWVOYW1lXCIsIGhlYWRlcjogXCJFbXBsb3llZVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwic2FsYXJ5X21vbnRoXCIsIGhlYWRlcjogXCJNb250aFwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwic2FsYXJ5X3llYXJcIiwgaGVhZGVyOiBcIlllYXJcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcInBheWFibGVfYW1vdW50XCIsIGhlYWRlcjogYWN0aXZlVGFiID09PSBcIkNvbXBsZXRlZFwiID8gXCJQYWlkIEFtb3VudFwiIDogXCJQYXlhYmxlIEFtb3VudFwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwicGF5X3R5cGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgTW9kZVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwidHJhbnNhY3Rpb25faWRcIiwgaGVhZGVyOiBcIlRyYW5zYWN0aW9uIElEXCIgfSxcclxuICAgICAgICB7IGtleTogXCJyZW1hcmtzXCIsIGhlYWRlcjogXCJSZW1hcmtzXCIgfSxcclxuICAgICAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgICBdO1xyXG5cclxuICAgIC8vIFF1aWNrIG5hdmlnYXRvciBsaW5rIGRhdGFcclxuICAgIGNvbnN0IE5BVl9MSU5LUyA9IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIHRvOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktb3V0LW1lbnUvc2FsYXJ5LXBheW1lbnRcIixcclxuICAgICAgICAgICAgaWNvbjogPFJpTW9uZXlSdXBlZUNpcmNsZUZpbGwgc2l6ZT17MTZ9IC8+LFxyXG4gICAgICAgICAgICBsYWJlbDogXCJTYWxhcnkgcGF5bWVudFwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICB0bzogXCIvc3RhZmYtbWVudS9lbXBsb3llZS1tZW51L3NhbGFyeS1tYW5hZ2VtZW50XCIsXHJcbiAgICAgICAgICAgIGljb246IDxNZE91dGxpbmVNYW4gc2l6ZT17MTZ9IC8+LFxyXG4gICAgICAgICAgICBsYWJlbDogXCJTYWxhcnkgbWFuYWdlbWVudFwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICB0bzogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LWluLW1lbnUvYWR2YW5jZS1wYXltZW50LWluXCIsXHJcbiAgICAgICAgICAgIGljb246IDxSaU1vbmV5UnVwZWVDaXJjbGVGaWxsIHNpemU9ezE2fSAvPixcclxuICAgICAgICAgICAgbGFiZWw6IFwiQWR2YW5jZSByZXBheW1lbnRcIixcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgdG86IFwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9zYWxhcnktaW5jZW50aXZlXCIsXHJcbiAgICAgICAgICAgIGljb246IDxSaU1vbmV5UnVwZWVDaXJjbGVGaWxsIHNpemU9ezE2fSAvPixcclxuICAgICAgICAgICAgbGFiZWw6IFwiU2FsYXJ5IGluY2VudGl2ZVwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICB0bzogXCIvc3RhZmYtbWVudS9lbXBsb3llZS1tZW51L2VtcGxveWVlLXN0YXRlbWVudFwiLFxyXG4gICAgICAgICAgICBpY29uOiA8VXNlciBzaXplPXsxNn0gLz4sXHJcbiAgICAgICAgICAgIGxhYmVsOiBcIlNhbGFyeSBMZWRnZXJcIixcclxuICAgICAgICB9LFxyXG4gICAgXTtcclxuXHJcbiAgICBjb25zdCB0b3RhbFBheWFibGVTdW0gPSB1c2VNZW1vKCgpID0+IHtcclxuICAgICAgICByZXR1cm4gdGFibGVQYXltZW50cy5yZWR1Y2UoXHJcbiAgICAgICAgICAgIChzdW0sIGl0ZW0pID0+IHN1bSArIChOdW1iZXIoaXRlbS5wYXlhYmxlX2Ftb3VudCkgfHwgMCksXHJcbiAgICAgICAgICAgIDAsXHJcbiAgICAgICAgKTtcclxuICAgIH0sIFt0YWJsZVBheW1lbnRzXSk7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgICB7b3BlbkJhY2tkcm9wTG9hZGVyICYmIDxCYWNrZHJvcEJsdXJMb2FkZXIgdGl0bGU9XCJQcm9jZXNzaW5nLi4uXCIgLz59XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjAgbWluLWgtc2NyZWVuXCI+XHJcbiAgICAgICAgICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgcHgtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxOYXZiYXIgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXsoZSkgPT4gc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSl9IHZpc2liaWxpdHk9e3RydWV9IC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHthbGVydENvbmZpZy52aXNpYmlsaXR5ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCB0b3AtNSBsZWZ0LTEvMiAtdHJhbnNsYXRlLXgtMS8yIHotWzEwMDBdIHctZnVsbCBtYXgtdy1tZCBweC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QWxlcnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd0ljb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbG9zYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEFsZXJ0Q29uZmlnKHsgLi4uYWxlcnRDb25maWcsIHZpc2liaWxpdHk6IGZhbHNlIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbWItNFwiPkFkZGl0aW9uYWwgU2FsYXJ5PC9oMT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIOKUgOKUgCBRdWljayBOYXZpZ2F0b3Ig4pSA4pSAICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LWdyYXktNDAwIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBRdWljayBuYXZpZ2F0b3JcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFF1aWNrIExpbmtzICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge05BVl9MSU5LUy5tYXAoKGxpbmspID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtsaW5rLnRvfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPXtsaW5rLnRvfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMiBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgdGV4dC1zbSB0ZXh0LWdyYXktNjAwIGhvdmVyOmJvcmRlci1ibHVlLTQwMCBob3Zlcjp0ZXh0LWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAgdHJhbnNpdGlvbi1hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDBcIj57bGluay5pY29ufTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bGluay5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBTdW1tYXJ5IENhcmQgUmlnaHQgRW5kICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS0xMDAgYm9yZGVyIGJvcmRlci1ibHVlLTMwMCByb3VuZGVkLXhsIHB4LTUgcHktMiBzaGFkb3ctc20gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTZcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmx1ZS05MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQZW5kaW5nIFBheW1lbnRzOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ibHVlLTkwMCBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGFibGVQYXltZW50cy5sZW5ndGh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaC01IHctcHggYmctYmx1ZS0zMDBcIj48L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtOTAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgUGF5YWJsZTpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmx1ZS05MDAgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e3RvdGFsUGF5YWJsZVN1bS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VjdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRFZGl0SWQobnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKGluaXRpYWxGb3JtKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYmx1ZS05NTAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZCBob3ZlcjpiZy1ibHVlLTkwMCB0cmFuc2l0aW9uLWNvbG9ycyBtdC0yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICArIEFkZCBBZGRpdGlvbmFsIFNhbGFyeVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBUYWIgQnV0dG9ucyAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwIG1iLTYgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt0YWJzLm1hcCgodGFiKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXt0YWJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIGZvbnQtbWVkaXVtICR7YWN0aXZlVGFiID09PSB0YWJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci1iLTIgYm9yZGVyLWJsdWUtNjAwIHRleHQtYmx1ZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1ncmF5LTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYih0YWIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0YWIgPT09IFwiUGVuZGluZ1wiID8gPD4gUGVuZGluZyAgPHNwYW4gY2xhc3NOYW1lPVwiIGJnLW9yYW5nZS01MDAgdGV4dC13aGl0ZSAgdGV4dC1bMTJweF0gcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0b3RhbENvdW50Py5wZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj4gPC8+IDogPD5Db21wbGV0ZWQgICA8c3BhbiBjbGFzc05hbWU9XCIgYmctZ3JlZW4tNTAwIHRleHQtd2hpdGUgIHRleHQtWzEycHhdIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dG90YWxDb3VudD8uY29tcGxldGVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj48Lz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBUYWIgQ29udGVudCAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSBcIlBlbmRpbmdcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiB0YWJsZVBheW1lbnRzLmxlbmd0aCA8PSAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RW1wdHkgZGVzY3JpcHRpb249XCJObyBBZGRpdGlvbmFsIFNhbGFyeSBEYXRhIEZvdW5kXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhPXt0YWJsZVBheW1lbnRzLmZpbHRlcigoaXRlbSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLmVtcGxveWVlTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/LnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKHNlYXJjaFRleHQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVRhYiA9PT0gXCJDb21wbGV0ZWRcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPkVtcGxveWVlIEFkdmFuY2UgUmVwYXltZW50PC9oMT4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0RWRpdElkKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoaW5pdGlhbEZvcm0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYmx1ZS05NTAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICArIEFkZCBBZHZhbmNlXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IHRhYmxlUGF5bWVudHMubGVuZ3RoIDw9IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxFbXB0eSBkZXNjcmlwdGlvbj1cIk5vIEFkZGl0aW9uYWwgU2FsYXJ5IERhdGEgRm91bmRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE9e3RhYmxlUGF5bWVudHMuZmlsdGVyKChpdGVtKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0uZW1wbG95ZWVOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8udG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoc2VhcmNoVGV4dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogRHJhd2VyIEZvcm0gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPERyYXdlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IGJnLWJsdWUtMTAwIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhUnVwZWVTaWduIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZWRpdElkID8gXCJFZGl0IEFkZGl0aW9uYWwgU2FsYXJ5XCIgOiBcIk5ldyBBZGRpdGlvbmFsIFNhbGFyeVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wZW49e3Nob3dNb2RhbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbG9zZT17Y2xvc2VEcmF3ZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoPXs0ODB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJzcGFjZS15LTYgcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogRW1wbG95ZWUgU2VsZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVtcGxveWVlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggYW5kIHNlbGVjdCBlbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5lbXBsb3llZV9pZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJsYWJlbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24/LmxhYmVsPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBlbXBsb3llZV9pZDogdmFsIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlbXBsb3llZXMubWFwKChlbXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtlbXAuX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbXAuX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPXtgJHtlbXAubmFtZX0gJHtlbXAuZW1wbG95ZWVDb2RlfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNiBoLTYgYmctYmx1ZS0xMDAgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ibHVlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2VtcC5uYW1lLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2VtcC5uYW1lfSB8IHtlbXAuZW1wbG95ZWVDb2RlID8gZW1wLmVtcGxveWVlQ29kZSA6IGVtcC51bmlxdWVfY29kZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5lbXBsb3llZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTEgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMSBoLTEgYmctcmVkLTUwMCByb3VuZGVkLWZ1bGxcIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmVtcGxveWVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQWRkaXRpb25hbCBzYWxhcnkgTW9udGggJiBZZWFyICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGaUNhbGVuZGFyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE1vbnRoICYgWWVhclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIE1vbnRoICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtMyBweS0yLjUgdGV4dC1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5tb250aCB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgbW9udGg6IGUudGFyZ2V0LnZhbHVlIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtlZGl0SWQgPyB0cnVlIDogZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBNb250aDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJKYW51YXJ5XCI+SmFudWFyeTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJGZWJydWFyeVwiPkZlYnJ1YXJ5PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk1hcmNoXCI+TWFyY2g8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQXByaWxcIj5BcHJpbDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNYXlcIj5NYXk8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiSnVuZVwiPkp1bmU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiSnVseVwiPkp1bHk8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQXVndXN0XCI+QXVndXN0PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlNlcHRlbWJlclwiPlNlcHRlbWJlcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJPY3RvYmVyXCI+T2N0b2Jlcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJOb3ZlbWJlclwiPk5vdmVtYmVyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkRlY2VtYmVyXCI+RGVjZW1iZXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5tb250aCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEgaC0xIGJnLXJlZC01MDAgcm91bmRlZC1mdWxsXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLm1vbnRofVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogWWVhciAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHB4LTMgcHktMi41IHRleHQtc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEueWVhciB8fCAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgeWVhcjogTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZWRpdElkID8gdHJ1ZSA6IGZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgWWVhcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtBcnJheS5mcm9tKHsgbGVuZ3RoOiAxMCB9LCAoXywgaSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB5ZWFyID0gbmV3IERhdGUoKS5nZXRGdWxsWWVhcigpIC0gNSArIGk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17eWVhcn0gdmFsdWU9e3llYXJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt5ZWFyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMueWVhciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEgaC0xIGJnLXJlZC01MDAgcm91bmRlZC1mdWxsXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnllYXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQW1vdW50ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVJ1cGVlU2lnbiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBbW91bnQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC00IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LWdyYXktNTAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBwbC04IHByLTQgcHktMi41IHRleHQtc20gZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMC4wMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIGFtb3VudDogZS50YXJnZXQudmFsdWUgfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Lyoge2Zvcm1EYXRhLmFtb3VudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS01MCBib3JkZXIgYm9yZGVyLWJsdWUtMjAwIHJvdW5kZWQtbGcgcHgtMyBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNzAwIHRleHQteHMgZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3Jkcyhmb3JtRGF0YS5hbW91bnQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFtb3VudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEgaC0xIGJnLXJlZC01MDAgcm91bmRlZC1mdWxsXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5hbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBQYXltZW50IERhdGUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpQ2FsZW5kYXIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSB0ZXh0LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGFpZF9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIHBhaWRfZGF0ZTogZS50YXJnZXQudmFsdWUgfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBQYXltZW50IE1vZGUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpQ3JlZGl0Q2FyZCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IE1vZGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBheV90eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgcGF5X3R5cGU6IHZhbCB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiY2FzaFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPkNhc2g8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIm9ubGluZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPk9ubGluZS9VUEk8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cImNoZXF1ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPkNoZXF1ZTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogVHJhbnNhY3Rpb24vQ2hlcXVlIElEICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLnBheV90eXBlICE9PSBcImNhc2hcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgYW5pbWF0ZS1mYWRlSW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpSGFzaCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZ3JheS01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLnBheV90eXBlID09PSBcImNoZXF1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIkNoZXF1ZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJUcmFuc2FjdGlvbiBJRFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtNCBweS0yLjUgdGV4dC1zbSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLnBheV90eXBlID09PSBcImNoZXF1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJFbnRlciBjaGVxdWUgbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIkVudGVyIHRyYW5zYWN0aW9uL1VQSSBJRFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEudHJhbnNhY3Rpb25faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgdHJhbnNhY3Rpb25faWQ6IGUudGFyZ2V0LnZhbHVlIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMudHJhbnNhY3Rpb25faWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEgaC0xIGJnLXJlZC01MDAgcm91bmRlZC1mdWxsXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMudHJhbnNhY3Rpb25faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Lyog8J+RhyBOb3RlIEZpZWxkIChPcHRpb25hbCkgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpRmlsZVRleHQgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWdyYXktNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTm90ZSAoT3B0aW9uYWwpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93cz17M31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIuNSB0ZXh0LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgdHJhbnNpdGlvbiByZXNpemUtbm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQWRkIGFueSByZW1hcmtzIG9yIHJlZmVyZW5jZS4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ub3RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBub3RlOiBlLnRhcmdldC52YWx1ZSB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBTdGF0dXMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZWRpdElkICYmIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8R3JTdGF0dXNHb29kIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFN0YXR1c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LnN0YXR1c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIHN0YXR1czogdmFsIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJQZW5kaW5nXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+UGVuZGluZzwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiQ29tcGxldGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+Q29tcGxldGVkPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2Pn1cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFN1Ym1pdCBCdXR0b24gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB0by1ibHVlLTcwMCB0ZXh0LXdoaXRlIHB5LTMgcm91bmRlZC1sZyBob3Zlcjpmcm9tLWJsdWUtNzAwIGhvdmVyOnRvLWJsdWUtODAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBmb250LXNlbWlib2xkIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgdHJhbnNmb3JtIGhvdmVyOi10cmFuc2xhdGUteS0wLjUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2VkaXRJZCA/IFwiVXBkYXRlIEFkZGl0aW9uYWwgU2FsYXJ5XCIgOiBcIlNhdmUgQWRkaXRpb25hbCBTYWxhcnlcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9EcmF3ZXI+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC8+XHJcbiAgICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQWRkaXRpb25hbFNhbGFyeTsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvQWRkaXRpb25hbFNhbGFyeS5qc3gifQ==