import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Plans.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { Dropdown, Select, Tooltip } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
import { InfoCircleOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
const Plans = () => {
  _s();
  const [plans, setPlans] = useState([]);
  const [tablePlans, setTablePlans] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentPlan, setCurrentPlan] = useState(null);
  const [currentUpdatePlan, setCurrentUpdatePlan] = useState(null);
  const [searchText, setSearchText] = useState("");
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [formData, setFormData] = useState({
    plan_id: "",
    plan_name: "",
    plan_type: "PERIODIC",
    plan_currency: "INR",
    plan_recurring_amount: "",
    plan_max_amount: "",
    plan_max_cycles: "",
    plan_intervals: "",
    plan_interval_type: "MONTH",
    plan_note: "Chit"
  });
  const [errors, setErrors] = useState({});
  const onGlobalSearchChangeHandler = (e) => {
    setSearchText(e.target.value);
  };
  useEffect(() => {
    const fetchPlans = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/cashfree-subscription/plans");
        const plansData = response.data?.data || response.data || [];
        setPlans(plansData);
        const formattedData = plansData.map((plan, index) => ({
          _id: plan._id,
          id: index + 1,
          plan_id: plan.plan_id,
          plan_name: plan.plan_name,
          plan_type: plan.plan_type,
          plan_currency: plan.plan_currency,
          plan_recurring_amount: plan.plan_recurring_amount,
          plan_max_amount: plan.plan_max_amount,
          plan_max_cycles: plan.plan_max_cycles,
          plan_intervals: plan.plan_intervals,
          plan_interval_type: plan.plan_interval_type,
          plan_note: plan.plan_note,
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              menu: {
                items: [
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-red-600",
                        onClick: () => handleDeleteModalOpen(plan._id),
                        children: "Delete"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                        lineNumber: 85,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                lineNumber: 97,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
              lineNumber: 79,
              columnNumber: 15
            },
            this
          ) }, plan._id, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
            lineNumber: 78,
            columnNumber: 11
          }, this)
        }));
        setTablePlans(formattedData);
      } catch (error) {
        console.error("Error fetching plans:", error);
        setAlertConfig({
          visibility: true,
          message: "Failed to fetch plans",
          type: "error"
        });
      } finally {
        setIsLoading(false);
      }
    };
    fetchPlans();
  }, [reloadTrigger]);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };
  const handleAntDSelect = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => ({ ...prev, [field]: "" }));
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };
  const handleAntInputDSelect = (field, value) => {
    setUpdateFormData((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => ({ ...prev, [field]: "" }));
  };
  const validateForm = (type) => {
    const newErrors = {};
    const data = formData;
    if (!data.plan_id) newErrors.plan_id = "Plan ID is required";
    if (!data.plan_name) newErrors.plan_name = "Plan Name is required";
    if (!data.plan_recurring_amount || data.plan_recurring_amount <= 0) {
      newErrors.plan_recurring_amount = "Recurring amount must be positive";
    }
    if (!data.plan_max_amount || data.plan_max_amount <= 0) {
      newErrors.plan_max_amount = "Max amount must be positive";
    }
    if (!data.plan_intervals || data.plan_intervals <= 0) {
      newErrors.plan_intervals = "Intervals must be positive";
    }
    if (!data.plan_interval_type) {
      newErrors.plan_interval_type = "Interval type is required";
    }
    if (!data.plan_note) {
      newErrors.plan_note = "Plan note is required";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm("addPlan");
    if (!isValid) return;
    try {
      const {
        plan_max_cycles,
        ...restFormData
      } = formData;
      const payload = {
        ...restFormData,
        plan_recurring_amount: Number(formData.plan_recurring_amount),
        plan_max_amount: Number(formData.plan_max_amount),
        plan_intervals: Number(formData.plan_intervals)
      };
      if (plan_max_cycles !== "" && plan_max_cycles !== null) {
        payload.plan_max_cycles = Number(plan_max_cycles);
      }
      const response = await api.post("/cashfree-subscription/plans", payload);
      if (response.status >= 400) throw new Error("Failed to add plan");
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        visibility: true,
        message: "Plan added successfully",
        type: "success"
      });
      setShowModal(false);
      setFormData({
        plan_id: "",
        plan_name: "",
        plan_type: "PERIODIC",
        plan_currency: "INR",
        plan_recurring_amount: "",
        plan_max_amount: "",
        plan_max_cycles: "",
        plan_intervals: "",
        plan_interval_type: "MONTH",
        plan_note: "Chit"
      });
    } catch (error) {
      console.error("Error adding plan:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to add plan",
        type: "error"
      });
    }
  };
  const handleDeleteModalOpen = async (planId) => {
    try {
      const response = await api.get(`/cashfree-subscription/plans/${planId}`);
      setCurrentPlan(response.data?.data || response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching plan for delete:", error);
    }
  };
  const handleUpdateModalOpen = async (planId) => {
    try {
      const response = await api.get(`/cashfree-subscription/plans/${planId}`);
      const planData = response.data?.data || response.data;
      setCurrentUpdatePlan(planData);
      setUpdateFormData({
        plan_id: planData.plan_id || "",
        plan_name: planData.plan_name || "",
        plan_type: planData.plan_type || "PERIODIC",
        plan_currency: planData.plan_currency || "INR",
        plan_recurring_amount: planData.plan_recurring_amount || "",
        plan_max_amount: planData.plan_max_amount || "",
        plan_max_cycles: planData.plan_max_cycles || "",
        plan_intervals: planData.plan_intervals || "",
        plan_interval_type: planData.plan_interval_type || "MONTH",
        plan_note: planData.plan_note || ""
      });
      setShowModalUpdate(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching plan for update:", error);
    }
  };
  const handleDeletePlan = async () => {
    if (currentPlan) {
      try {
        await api.delete(`/cashfree-subscription/plans/${currentPlan._id}`);
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          message: "Plan deleted successfully",
          type: "success",
          visibility: true
        });
        setShowModalDelete(false);
        setCurrentPlan(null);
      } catch (error) {
        console.error("Error deleting plan:", error);
        setAlertConfig({
          message: "Failed to delete plan",
          type: "error",
          visibility: true
        });
      }
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    const isValid = validateForm("updatePlan");
    if (!isValid) return;
    try {
      const payload = {
        ...updateFormData,
        plan_recurring_amount: Number(updateFormData.plan_recurring_amount),
        plan_max_amount: Number(updateFormData.plan_max_amount),
        plan_max_cycles: Number(updateFormData.plan_max_cycles),
        plan_intervals: Number(updateFormData.plan_intervals)
      };
      await api.patch(`/cashfree-subscription/plans/${currentUpdatePlan._id}`, payload);
      setShowModalUpdate(false);
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        message: "Plan updated successfully",
        type: "success",
        visibility: true
      });
    } catch (error) {
      console.error("Error updating plan:", error);
      setAlertConfig({
        message: "Failed to update plan",
        type: "error",
        visibility: true
      });
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "plan_id", header: "Plan ID" },
    { key: "plan_name", header: "Plan Name" },
    { key: "plan_type", header: "Type" },
    { key: "plan_currency", header: "Currency" },
    { key: "plan_recurring_amount", header: "Recurring Amount" },
    { key: "plan_max_amount", header: "Max Amount" },
    { key: "plan_max_cycles", header: "Max Cycles" },
    { key: "plan_intervals", header: "Intervals" },
    { key: "plan_interval_type", header: "Interval Type" },
    { key: "plan_note", header: "Note" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        visibility: true,
        onGlobalSearchChangeHandler
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
        lineNumber: 340,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
        lineNumber: 344,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
        lineNumber: 353,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Subscription Plans" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
            lineNumber: 357,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowModal(true);
                setErrors({});
              },
              className: "ml-4 bg-blue-950 text-white px-4 py-2 rounded shadow-md hover:bg-blue-800 transition duration-200",
              children: "+ Add Plan"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
              lineNumber: 358,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
          lineNumber: 356,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
          lineNumber: 355,
          columnNumber: 13
        }, this),
        tablePlans?.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            catcher: "_id",
            updateHandler: handleUpdateModalOpen,
            data: filterOption(tablePlans, searchText),
            columns,
            exportedPdfName: "SubscriptionPlans",
            exportedFileName: "SubscriptionPlans.csv"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
            lineNumber: 371,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            data: "Plans",
            failure: tablePlans?.length <= 0
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
            lineNumber: 380,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
        lineNumber: 354,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
      lineNumber: 352,
      columnNumber: 9
    }, this),
    "```jsx",
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-6 text-left bg-white rounded-2xl max-h-[90vh] overflow-y-auto", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6 border-b pb-4", children: /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-bold text-gray-800", children: "Create Subscription Plan" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
          lineNumber: 398,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: "Add new recurring subscription plan" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
          lineNumber: 401,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
        lineNumber: 397,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
        lineNumber: 396,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-5", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: [
              "Plan ID ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                lineNumber: 415,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
              lineNumber: 414,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                name: "plan_id",
                value: formData.plan_id,
                onChange: handleChange,
                placeholder: "MCF-PL-{{NUMBER}}-{{AMOUNT}}",
                className: "w-full rounded-xl border border-gray-300 bg-gray-50 px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                lineNumber: 418,
                columnNumber: 19
              },
              this
            ),
            errors.plan_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.plan_id }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
              lineNumber: 428,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
            lineNumber: 413,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: [
              "Plan Name ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                lineNumber: 437,
                columnNumber: 31
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
              lineNumber: 436,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                name: "plan_name",
                value: formData.plan_name,
                onChange: handleChange,
                placeholder: "Gold Monthly Plan",
                className: "w-full rounded-xl border border-gray-300 bg-gray-50 px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                lineNumber: 440,
                columnNumber: 19
              },
              this
            ),
            errors.plan_name && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.plan_name }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
              lineNumber: 450,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
            lineNumber: 435,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "mb-2 text-sm font-semibold text-gray-700 inline-flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "Recurring Amount (₹)" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                lineNumber: 459,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Tooltip,
                {
                  title: "Amount that customer needs to pay repeatedly for each cycle.",
                  placement: "top",
                  children: /* @__PURE__ */ jsxDEV(InfoCircleOutlined, { className: "text-blue-500 cursor-pointer hover:text-blue-700 transition text-sm" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                    lineNumber: 465,
                    columnNumber: 23
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                  lineNumber: 461,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
              lineNumber: 458,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "number",
                name: "plan_recurring_amount",
                value: formData.plan_recurring_amount,
                onChange: handleChange,
                placeholder: "500",
                className: "w-full rounded-xl border border-gray-300 bg-gray-50 px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                lineNumber: 469,
                columnNumber: 19
              },
              this
            ),
            errors.plan_recurring_amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.plan_recurring_amount }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
              lineNumber: 479,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
            lineNumber: 457,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "mb-2 text-sm font-semibold text-gray-700 inline-flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "Max Amount (₹)" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                lineNumber: 488,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Tooltip,
                {
                  title: "Maximum total amount allowed under this subscription plan.",
                  placement: "top",
                  children: /* @__PURE__ */ jsxDEV(InfoCircleOutlined, { className: "text-blue-500 cursor-pointer hover:text-blue-700 transition text-sm" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                    lineNumber: 494,
                    columnNumber: 23
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                  lineNumber: 490,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
              lineNumber: 487,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "number",
                name: "plan_max_amount",
                value: formData.plan_max_amount,
                onChange: handleChange,
                placeholder: "10000",
                className: "w-full rounded-xl border border-gray-300 bg-gray-50 px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                lineNumber: 498,
                columnNumber: 19
              },
              this
            ),
            errors.plan_max_amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.plan_max_amount }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
              lineNumber: 508,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
            lineNumber: 486,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "mb-2 text-sm font-semibold text-gray-700 inline-flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { children: "Max Cycles (Optional)" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                lineNumber: 517,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Tooltip,
                {
                  title: "Maximum number of cycles for this subscription plan.",
                  placement: "top",
                  children: /* @__PURE__ */ jsxDEV(InfoCircleOutlined, { className: "text-blue-500 cursor-pointer hover:text-blue-700 transition text-sm" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                    lineNumber: 523,
                    columnNumber: 23
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                  lineNumber: 519,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
              lineNumber: 516,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "number",
                name: "plan_max_cycles",
                value: formData.plan_max_cycles,
                onChange: handleChange,
                placeholder: "12",
                className: "w-full rounded-xl border border-gray-300 bg-gray-50 px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                lineNumber: 527,
                columnNumber: 19
              },
              this
            ),
            errors.plan_max_cycles && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.plan_max_cycles }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
              lineNumber: 537,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
            lineNumber: 515,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "mb-2 text-sm font-semibold text-gray-700 inline-flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { children: " Intervals" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                lineNumber: 546,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Tooltip,
                {
                  title: "Total number of Intervals for this subscription plan.",
                  placement: "top",
                  children: /* @__PURE__ */ jsxDEV(InfoCircleOutlined, { className: "text-blue-500 cursor-pointer hover:text-blue-700 transition text-sm" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                    lineNumber: 552,
                    columnNumber: 23
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                  lineNumber: 548,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
              lineNumber: 545,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "number",
                name: "plan_intervals",
                value: formData.plan_intervals,
                onChange: handleChange,
                placeholder: "1",
                className: "w-full rounded-xl border border-gray-300 bg-gray-50 px-4 py-3 text-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                lineNumber: 556,
                columnNumber: 19
              },
              this
            ),
            errors.plan_intervals && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.plan_intervals }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
              lineNumber: 566,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
            lineNumber: 544,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Interval Type" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
              lineNumber: 574,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: "w-full custom-select",
                value: formData.plan_interval_type,
                onChange: (value) => handleAntDSelect("plan_interval_type", value),
                size: "large",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "DAY", children: "Daily" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                    lineNumber: 583,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "WEEK", children: "Weekly" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                    lineNumber: 584,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "MONTH", children: "Monthly" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                    lineNumber: 585,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "YEAR", children: "Yearly" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                    lineNumber: 586,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                lineNumber: 577,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
            lineNumber: 573,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Plan Category" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
              lineNumber: 592,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: "w-full custom-select",
                value: formData.plan_note,
                onChange: (value) => handleAntDSelect("plan_note", value),
                size: "large",
                children: ["Chit", "Loan", "Pigmy"].map(
                  (note) => /* @__PURE__ */ jsxDEV(Select.Option, { value: note, children: note }, note, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                    lineNumber: 605,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                lineNumber: 596,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
            lineNumber: 591,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
          lineNumber: 410,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("input", { type: "hidden", name: "plan_type", value: "PERIODIC" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
          lineNumber: 615,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("input", { type: "hidden", name: "plan_currency", value: "INR" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
          lineNumber: 616,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3 mt-8", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => setShowModal(false),
              className: "px-5 py-2.5 rounded-xl border border-gray-300 text-gray-700 hover:bg-gray-100 transition",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
              lineNumber: 621,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              className: "px-6 py-2.5 rounded-xl bg-blue-900 text-white font-medium hover:bg-blue-800 transition shadow-lg",
              children: "Save Plan"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
              lineNumber: 629,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
          lineNumber: 619,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
        lineNumber: 407,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
      lineNumber: 393,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
      lineNumber: 392,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentPlan(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Plan" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
            lineNumber: 649,
            columnNumber: 13
          }, this),
          currentPlan && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeletePlan();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "planNameConfirm",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentPlan.plan_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                          lineNumber: 664,
                          columnNumber: 21
                        }, this),
                        " ",
                        "to confirm deletion.",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                          lineNumber: 668,
                          columnNumber: 21
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                      lineNumber: 659,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      id: "planNameConfirm",
                      placeholder: "Enter the plan name",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                      lineNumber: 670,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                  lineNumber: 658,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
                    lineNumber: 678,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
              lineNumber: 651,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
          lineNumber: 648,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
        lineNumber: 641,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
    lineNumber: 339,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx",
    lineNumber: 338,
    columnNumber: 5
  }, this);
};
_s(Plans, "BUjHYcJydAeNxKqyZIdoKDQ+8bA=");
_c = Plans;
export default Plans;
var _c;
$RefreshReg$(_c, "Plans");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Plans.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0Z3QixTQTZQcEIsVUE3UG9COzJCQXBGeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQSxTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyx1QkFBdUI7QUFDOUIsU0FBU0MsVUFBVUMsUUFBUUMsZUFBZTtBQUMxQyxTQUFTQyxnQkFBZ0I7QUFDekIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQywwQkFBMEI7QUFFbkMsTUFBTUMsUUFBUUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2xCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJbEIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ21CLFlBQVlDLGFBQWEsSUFBSXBCLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNxQixXQUFXQyxZQUFZLElBQUl0QixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDdUIsaUJBQWlCQyxrQkFBa0IsSUFBSXhCLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUN5QixpQkFBaUJDLGtCQUFrQixJQUFJMUIsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQzJCLGFBQWFDLGNBQWMsSUFBSTVCLFNBQVMsSUFBSTtBQUNuRCxRQUFNLENBQUM2QixtQkFBbUJDLG9CQUFvQixJQUFJOUIsU0FBUyxJQUFJO0FBQy9ELFFBQU0sQ0FBQytCLFlBQVlDLGFBQWEsSUFBSWhDLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNpQyxlQUFlQyxnQkFBZ0IsSUFBSWxDLFNBQVMsQ0FBQztBQUNwRCxRQUFNLENBQUNtQyxXQUFXQyxZQUFZLElBQUlwQyxTQUFTLEtBQUs7QUFFaEQsUUFBTSxDQUFDcUMsYUFBYUMsY0FBYyxJQUFJdEMsU0FBUztBQUFBLElBQzdDdUMsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBR0QsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUkzQyxTQUFTO0FBQUEsSUFDdkM0QyxTQUFTO0FBQUEsSUFDVEMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxJQUNYQyxlQUFlO0FBQUEsSUFDZkMsdUJBQXVCO0FBQUEsSUFDdkJDLGlCQUFpQjtBQUFBLElBQ2pCQyxpQkFBaUI7QUFBQSxJQUNqQkMsZ0JBQWdCO0FBQUEsSUFDaEJDLG9CQUFvQjtBQUFBLElBQ3BCQyxXQUFXO0FBQUEsRUFDYixDQUFDO0FBR0QsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUl2RCxTQUFTLENBQUMsQ0FBQztBQUd2QyxRQUFNd0QsOEJBQThCQSxDQUFDQyxNQUFNO0FBQ3pDekIsa0JBQWN5QixFQUFFQyxPQUFPQyxLQUFLO0FBQUEsRUFDOUI7QUFHQTVELFlBQVUsTUFBTTtBQUNkLFVBQU02RCxhQUFhLFlBQVk7QUFDN0IsVUFBSTtBQUNGeEIscUJBQWEsSUFBSTtBQUNqQixjQUFNeUIsV0FBVyxNQUFNMUQsSUFBSTJELElBQUksOEJBQThCO0FBQzdELGNBQU1DLFlBQVlGLFNBQVNHLE1BQU1BLFFBQVFILFNBQVNHLFFBQVE7QUFDMUQ5QyxpQkFBUzZDLFNBQVM7QUFDbEIsY0FBTUUsZ0JBQWdCRixVQUFVRyxJQUFJLENBQUNDLE1BQU1DLFdBQVc7QUFBQSxVQUNwREMsS0FBS0YsS0FBS0U7QUFBQUEsVUFDVkMsSUFBSUYsUUFBUTtBQUFBLFVBQ1p4QixTQUFTdUIsS0FBS3ZCO0FBQUFBLFVBQ2RDLFdBQVdzQixLQUFLdEI7QUFBQUEsVUFDaEJDLFdBQVdxQixLQUFLckI7QUFBQUEsVUFDaEJDLGVBQWVvQixLQUFLcEI7QUFBQUEsVUFDcEJDLHVCQUF1Qm1CLEtBQUtuQjtBQUFBQSxVQUM1QkMsaUJBQWlCa0IsS0FBS2xCO0FBQUFBLFVBQ3RCQyxpQkFBaUJpQixLQUFLakI7QUFBQUEsVUFDdEJDLGdCQUFnQmdCLEtBQUtoQjtBQUFBQSxVQUNyQkMsb0JBQW9CZSxLQUFLZjtBQUFBQSxVQUN6QkMsV0FBV2MsS0FBS2Q7QUFBQUEsVUFDaEJrQixRQUNFLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTTtBQUFBLGdCQUNKQyxPQUFPO0FBQUEsa0JBQ0w7QUFBQSxvQkFDRUMsS0FBSztBQUFBLG9CQUNMQyxPQUNFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFTLE1BQU1DLHNCQUFzQlIsS0FBS0UsR0FBRztBQUFBLHdCQUFFO0FBQUE7QUFBQSxzQkFGakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsa0JBRUo7QUFBQSxnQkFBQztBQUFBLGNBRUw7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUVWLGlDQUFDLFlBQVMsV0FBVSxlQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQjtBQUFBO0FBQUEsWUFsQmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQW1CQSxLQXBCOENGLEtBQUtFLEtBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUJBO0FBQUEsUUFFSixFQUFFO0FBQ0ZqRCxzQkFBYzZDLGFBQWE7QUFBQSxNQUM3QixTQUFTVyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLHlCQUF5QkEsS0FBSztBQUM1Q3RDLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSCxVQUFDO0FBQ0NMLHFCQUFhLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFDQXdCLGVBQVc7QUFBQSxFQUNiLEdBQUcsQ0FBQzNCLGFBQWEsQ0FBQztBQUdsQixRQUFNNkMsZUFBZUEsQ0FBQ3JCLE1BQU07QUFDMUIsVUFBTSxFQUFFc0IsTUFBTXBCLE1BQU0sSUFBSUYsRUFBRUM7QUFDMUJmLGdCQUFZLENBQUNxQyxVQUFVLEVBQUUsR0FBR0EsTUFBTSxDQUFDRCxJQUFJLEdBQUdwQixNQUFNLEVBQUU7QUFDbERKLGNBQVUsQ0FBQ3lCLFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUNELElBQUksR0FBRyxHQUFHLEVBQUU7QUFBQSxFQUMvQztBQUdBLFFBQU1FLG1CQUFtQkEsQ0FBQ0MsT0FBT3ZCLFVBQVU7QUFDekNoQixnQkFBWSxDQUFDcUMsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0UsS0FBSyxHQUFHdkIsTUFBTSxFQUFFO0FBQ25ESixjQUFVLENBQUN5QixVQUFVLEVBQUUsR0FBR0EsTUFBTSxDQUFDRSxLQUFLLEdBQUcsR0FBRyxFQUFFO0FBQUEsRUFDaEQ7QUFHQSxRQUFNQyxvQkFBb0JBLENBQUMxQixNQUFNO0FBQy9CLFVBQU0sRUFBRXNCLE1BQU1wQixNQUFNLElBQUlGLEVBQUVDO0FBQzFCMEIsc0JBQWtCLENBQUNKLFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUNELElBQUksR0FBR3BCLE1BQU0sRUFBRTtBQUN4REosY0FBVSxDQUFDeUIsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0QsSUFBSSxHQUFHLEdBQUcsRUFBRTtBQUFBLEVBQy9DO0FBR0EsUUFBTU0sd0JBQXdCQSxDQUFDSCxPQUFPdkIsVUFBVTtBQUM5Q3lCLHNCQUFrQixDQUFDSixVQUFVLEVBQUUsR0FBR0EsTUFBTSxDQUFDRSxLQUFLLEdBQUd2QixNQUFNLEVBQUU7QUFDekRKLGNBQVUsQ0FBQ3lCLFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUNFLEtBQUssR0FBRyxHQUFHLEVBQUU7QUFBQSxFQUNoRDtBQUdBLFFBQU1JLGVBQWVBLENBQUM3QyxTQUFTO0FBQzdCLFVBQU04QyxZQUFZLENBQUM7QUFDbkIsVUFBTXZCLE9BQU90QjtBQUViLFFBQUksQ0FBQ3NCLEtBQUtwQixRQUFTMkMsV0FBVTNDLFVBQVU7QUFDdkMsUUFBSSxDQUFDb0IsS0FBS25CLFVBQVcwQyxXQUFVMUMsWUFBWTtBQUMzQyxRQUFJLENBQUNtQixLQUFLaEIseUJBQXlCZ0IsS0FBS2hCLHlCQUF5QixHQUFHO0FBQ2xFdUMsZ0JBQVV2Qyx3QkFBd0I7QUFBQSxJQUNwQztBQUNBLFFBQUksQ0FBQ2dCLEtBQUtmLG1CQUFtQmUsS0FBS2YsbUJBQW1CLEdBQUc7QUFDdERzQyxnQkFBVXRDLGtCQUFrQjtBQUFBLElBQzlCO0FBSUEsUUFBSSxDQUFDZSxLQUFLYixrQkFBa0JhLEtBQUtiLGtCQUFrQixHQUFHO0FBQ3BEb0MsZ0JBQVVwQyxpQkFBaUI7QUFBQSxJQUM3QjtBQUNBLFFBQUksQ0FBQ2EsS0FBS1osb0JBQW9CO0FBQzVCbUMsZ0JBQVVuQyxxQkFBcUI7QUFBQSxJQUNqQztBQUNBLFFBQUksQ0FBQ1ksS0FBS1gsV0FBVztBQUNuQmtDLGdCQUFVbEMsWUFBWTtBQUFBLElBQ3hCO0FBRUFFLGNBQVVnQyxTQUFTO0FBQ25CLFdBQU9DLE9BQU9DLEtBQUtGLFNBQVMsRUFBRUcsV0FBVztBQUFBLEVBQzNDO0FBR0EsUUFBTUMsZUFBZSxPQUFPbEMsTUFBTTtBQUNoQ0EsTUFBRW1DLGVBQWU7QUFDakIsVUFBTUMsVUFBVVAsYUFBYSxTQUFTO0FBQ3RDLFFBQUksQ0FBQ08sUUFBUztBQUVkLFFBQUk7QUFDRixZQUFNO0FBQUEsUUFDSjNDO0FBQUFBLFFBQ0EsR0FBRzRDO0FBQUFBLE1BQ0wsSUFBSXBEO0FBRUosWUFBTXFELFVBQVU7QUFBQSxRQUNkLEdBQUdEO0FBQUFBLFFBQ0g5Qyx1QkFBdUJnRCxPQUFPdEQsU0FBU00scUJBQXFCO0FBQUEsUUFDNURDLGlCQUFpQitDLE9BQU90RCxTQUFTTyxlQUFlO0FBQUEsUUFDaERFLGdCQUFnQjZDLE9BQU90RCxTQUFTUyxjQUFjO0FBQUEsTUFDaEQ7QUFHQSxVQUFJRCxvQkFBb0IsTUFBTUEsb0JBQW9CLE1BQU07QUFDdEQ2QyxnQkFBUTdDLGtCQUFrQjhDLE9BQU85QyxlQUFlO0FBQUEsTUFDbEQ7QUFFQSxZQUFNVyxXQUFXLE1BQU0xRCxJQUFJOEYsS0FBSyxnQ0FBZ0NGLE9BQU87QUFDdkUsVUFBSWxDLFNBQVNxQyxVQUFVLElBQUssT0FBTSxJQUFJQyxNQUFNLG9CQUFvQjtBQUNoRWpFLHVCQUFpQixDQUFDOEMsU0FBU0EsT0FBTyxDQUFDO0FBQ25DMUMscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFDRG5CLG1CQUFhLEtBQUs7QUFFbEJxQixrQkFBWTtBQUFBLFFBQ1ZDLFNBQVM7QUFBQSxRQUNUQyxXQUFXO0FBQUEsUUFDWEMsV0FBVztBQUFBLFFBQ1hDLGVBQWU7QUFBQSxRQUNmQyx1QkFBdUI7QUFBQSxRQUN2QkMsaUJBQWlCO0FBQUEsUUFDakJDLGlCQUFpQjtBQUFBLFFBQ2pCQyxnQkFBZ0I7QUFBQSxRQUNoQkMsb0JBQW9CO0FBQUEsUUFDcEJDLFdBQVc7QUFBQSxNQUNiLENBQUM7QUFBQSxJQUNILFNBQVN1QixPQUFPO0FBQ2RDLGNBQVFELE1BQU0sc0JBQXNCQSxLQUFLO0FBQ3pDdEMscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBU29DLE1BQU1mLFVBQVVHLE1BQU14QixXQUFXO0FBQUEsUUFDMUNDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUdBLFFBQU1rQyx3QkFBd0IsT0FBT3lCLFdBQVc7QUFDOUMsUUFBSTtBQUNGLFlBQU12QyxXQUFXLE1BQU0xRCxJQUFJMkQsSUFBSSxnQ0FBZ0NzQyxNQUFNLEVBQUU7QUFDdkV4RSxxQkFBZWlDLFNBQVNHLE1BQU1BLFFBQVFILFNBQVNHLElBQUk7QUFDbkR4Qyx5QkFBbUIsSUFBSTtBQUFBLElBQ3pCLFNBQVNvRCxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sbUNBQW1DQSxLQUFLO0FBQUEsSUFDeEQ7QUFBQSxFQUNGO0FBR0EsUUFBTXlCLHdCQUF3QixPQUFPRCxXQUFXO0FBQzlDLFFBQUk7QUFDRixZQUFNdkMsV0FBVyxNQUFNMUQsSUFBSTJELElBQUksZ0NBQWdDc0MsTUFBTSxFQUFFO0FBQ3ZFLFlBQU1FLFdBQVd6QyxTQUFTRyxNQUFNQSxRQUFRSCxTQUFTRztBQUNqRGxDLDJCQUFxQndFLFFBQVE7QUFDN0JsQix3QkFBa0I7QUFBQSxRQUNoQnhDLFNBQVMwRCxTQUFTMUQsV0FBVztBQUFBLFFBQzdCQyxXQUFXeUQsU0FBU3pELGFBQWE7QUFBQSxRQUNqQ0MsV0FBV3dELFNBQVN4RCxhQUFhO0FBQUEsUUFDakNDLGVBQWV1RCxTQUFTdkQsaUJBQWlCO0FBQUEsUUFDekNDLHVCQUF1QnNELFNBQVN0RCx5QkFBeUI7QUFBQSxRQUN6REMsaUJBQWlCcUQsU0FBU3JELG1CQUFtQjtBQUFBLFFBQzdDQyxpQkFBaUJvRCxTQUFTcEQsbUJBQW1CO0FBQUEsUUFDN0NDLGdCQUFnQm1ELFNBQVNuRCxrQkFBa0I7QUFBQSxRQUMzQ0Msb0JBQW9Ca0QsU0FBU2xELHNCQUFzQjtBQUFBLFFBQ25EQyxXQUFXaUQsU0FBU2pELGFBQWE7QUFBQSxNQUNuQyxDQUFDO0FBQ0QzQix5QkFBbUIsSUFBSTtBQUN2QjZCLGdCQUFVLENBQUMsQ0FBQztBQUFBLElBQ2QsU0FBU3FCLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxtQ0FBbUNBLEtBQUs7QUFBQSxJQUN4RDtBQUFBLEVBQ0Y7QUFHQSxRQUFNMkIsbUJBQW1CLFlBQVk7QUFDbkMsUUFBSTVFLGFBQWE7QUFDZixVQUFJO0FBQ0YsY0FBTXhCLElBQUlxRyxPQUFPLGdDQUFnQzdFLFlBQVkwQyxHQUFHLEVBQUU7QUFDbEVuQyx5QkFBaUIsQ0FBQzhDLFNBQVNBLE9BQU8sQ0FBQztBQUNuQzFDLHVCQUFlO0FBQUEsVUFDYkUsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxVQUNORixZQUFZO0FBQUEsUUFDZCxDQUFDO0FBQ0RmLDJCQUFtQixLQUFLO0FBQ3hCSSx1QkFBZSxJQUFJO0FBQUEsTUFDckIsU0FBU2dELE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sd0JBQXdCQSxLQUFLO0FBQzNDdEMsdUJBQWU7QUFBQSxVQUNiRSxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFVBQ05GLFlBQVk7QUFBQSxRQUNkLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFHQSxRQUFNa0UsZUFBZSxPQUFPaEQsTUFBTTtBQUNoQ0EsTUFBRW1DLGVBQWU7QUFDakIsVUFBTUMsVUFBVVAsYUFBYSxZQUFZO0FBQ3pDLFFBQUksQ0FBQ08sUUFBUztBQUVkLFFBQUk7QUFDRixZQUFNRSxVQUFVO0FBQUEsUUFDZCxHQUFHVztBQUFBQSxRQUNIMUQsdUJBQXVCZ0QsT0FBT1UsZUFBZTFELHFCQUFxQjtBQUFBLFFBQ2xFQyxpQkFBaUIrQyxPQUFPVSxlQUFlekQsZUFBZTtBQUFBLFFBQ3REQyxpQkFBaUI4QyxPQUFPVSxlQUFleEQsZUFBZTtBQUFBLFFBQ3REQyxnQkFBZ0I2QyxPQUFPVSxlQUFldkQsY0FBYztBQUFBLE1BQ3REO0FBQ0EsWUFBTWhELElBQUl3RyxNQUFNLGdDQUFnQzlFLGtCQUFrQndDLEdBQUcsSUFBSTBCLE9BQU87QUFDaEZyRSx5QkFBbUIsS0FBSztBQUN4QlEsdUJBQWlCLENBQUM4QyxTQUFTQSxPQUFPLENBQUM7QUFDbkMxQyxxQkFBZTtBQUFBLFFBQ2JFLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsUUFDTkYsWUFBWTtBQUFBLE1BQ2QsQ0FBQztBQUFBLElBQ0gsU0FBU3FDLE9BQU87QUFDZEMsY0FBUUQsTUFBTSx3QkFBd0JBLEtBQUs7QUFDM0N0QyxxQkFBZTtBQUFBLFFBQ2JFLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsUUFDTkYsWUFBWTtBQUFBLE1BQ2QsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBR0EsUUFBTXFFLFVBQVU7QUFBQSxJQUNkLEVBQUVuQyxLQUFLLE1BQU1vQyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFcEMsS0FBSyxXQUFXb0MsUUFBUSxVQUFVO0FBQUEsSUFDcEMsRUFBRXBDLEtBQUssYUFBYW9DLFFBQVEsWUFBWTtBQUFBLElBQ3hDLEVBQUVwQyxLQUFLLGFBQWFvQyxRQUFRLE9BQU87QUFBQSxJQUNuQyxFQUFFcEMsS0FBSyxpQkFBaUJvQyxRQUFRLFdBQVc7QUFBQSxJQUMzQyxFQUFFcEMsS0FBSyx5QkFBeUJvQyxRQUFRLG1CQUFtQjtBQUFBLElBQzNELEVBQUVwQyxLQUFLLG1CQUFtQm9DLFFBQVEsYUFBYTtBQUFBLElBQy9DLEVBQUVwQyxLQUFLLG1CQUFtQm9DLFFBQVEsYUFBYTtBQUFBLElBQy9DLEVBQUVwQyxLQUFLLGtCQUFrQm9DLFFBQVEsWUFBWTtBQUFBLElBQzdDLEVBQUVwQyxLQUFLLHNCQUFzQm9DLFFBQVEsZ0JBQWdCO0FBQUEsSUFDckQsRUFBRXBDLEtBQUssYUFBYW9DLFFBQVEsT0FBTztBQUFBLElBQ25DLEVBQUVwQyxLQUFLLFVBQVVvQyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFNBQ0UsbUNBQ0UsaUNBQUMsU0FDQztBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxZQUFZO0FBQUEsUUFDWjtBQUFBO0FBQUEsTUFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFMkQ7QUFBQSxJQUUzRDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTXhFLFlBQVlJO0FBQUFBLFFBQ2xCLFdBQVdKLFlBQVlFO0FBQUFBLFFBQ3ZCLFNBQVNGLFlBQVlHO0FBQUFBLFFBQ3JCLFNBQVMsTUFDUEYsZUFBZSxDQUFDMEMsVUFBVSxFQUFFLEdBQUdBLE1BQU16QyxZQUFZLE1BQU0sRUFBRTtBQUFBO0FBQUEsTUFMN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUc7QUFBQSxJQUVILHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsNkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUNSLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxhQUNiLGlDQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSwwQkFBeUIsa0NBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlEO0FBQUEsVUFDekQ7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTTtBQUNiakIsNkJBQWEsSUFBSTtBQUNqQmlDLDBCQUFVLENBQUMsQ0FBQztBQUFBLGNBQ2Q7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUFtRztBQUFBO0FBQUEsWUFML0c7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUE7QUFBQSxhQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQSxLQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBRUNwQyxZQUFZdUUsU0FBUyxLQUFLLENBQUN2RCxZQUMxQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUTtBQUFBLFlBQ1IsZUFBZWtFO0FBQUFBLFlBQ2YsTUFBTTFGLGFBQWFRLFlBQVlZLFVBQVU7QUFBQSxZQUN6QztBQUFBLFlBQ0EsaUJBQWdCO0FBQUEsWUFDaEIsa0JBQWlCO0FBQUE7QUFBQSxVQU5uQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNMEMsSUFHMUM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxNQUFLO0FBQUEsWUFDTCxTQUFTWixZQUFZdUUsVUFBVTtBQUFBO0FBQUEsVUFIakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR21DO0FBQUEsV0E3QnZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQ0E7QUFBQSxTQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUNBO0FBQUEsSUFFc0I7QUFBQSxJQUd0Qix1QkFBQyxTQUFNLFdBQVdyRSxXQUFXLFNBQVMsTUFBTUMsYUFBYSxLQUFLLEdBQzVELGlDQUFDLFNBQUksV0FBVSx5RUFHYjtBQUFBLDZCQUFDLFNBQUksV0FBVSx3REFDYixpQ0FBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLG9DQUFtQyx3Q0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLG1EQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRUEsdUJBQUMsVUFBSyxVQUFVcUUsY0FBYyxZQUFVLE1BR3RDO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHlDQUdiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLGNBQ3hELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxpQkFEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9qRCxTQUFTRTtBQUFBQSxnQkFDaEIsVUFBVWtDO0FBQUFBLGdCQUNWLGFBQVk7QUFBQSxnQkFDWixXQUFVO0FBQUE7QUFBQSxjQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1rSztBQUFBLFlBR2pLeEIsT0FBT1YsV0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZVLGlCQUFPVixXQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLFVBR0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLGNBQ3RELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxpQkFENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9GLFNBQVNHO0FBQUFBLGdCQUNoQixVQUFVaUM7QUFBQUEsZ0JBQ1YsYUFBWTtBQUFBLGdCQUNaLFdBQVU7QUFBQTtBQUFBLGNBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTWtLO0FBQUEsWUFHakt4QixPQUFPVCxhQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVlMsaUJBQU9ULGFBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsVUFHQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDJFQUNmO0FBQUEscUNBQUMsVUFBSyxvQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQjtBQUFBLGNBRTFCO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU07QUFBQSxrQkFDTixXQUFVO0FBQUEsa0JBRVYsaUNBQUMsc0JBQW1CLFdBQVUseUVBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW1HO0FBQUE7QUFBQSxnQkFKckc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxpQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsWUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsT0FBT0gsU0FBU007QUFBQUEsZ0JBQ2hCLFVBQVU4QjtBQUFBQSxnQkFDVixhQUFZO0FBQUEsZ0JBQ1osV0FBVTtBQUFBO0FBQUEsY0FOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNa0s7QUFBQSxZQUdqS3hCLE9BQU9OLHlCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVk0saUJBQU9OLHlCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBCQTtBQUFBLFVBR0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSwyRUFDZjtBQUFBLHFDQUFDLFVBQUssOEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0I7QUFBQSxjQUVwQjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFNO0FBQUEsa0JBQ04sV0FBVTtBQUFBLGtCQUVWLGlDQUFDLHNCQUFtQixXQUFVLHlFQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtRztBQUFBO0FBQUEsZ0JBSnJHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsaUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLFlBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9OLFNBQVNPO0FBQUFBLGdCQUNoQixVQUFVNkI7QUFBQUEsZ0JBQ1YsYUFBWTtBQUFBLGdCQUNaLFdBQVU7QUFBQTtBQUFBLGNBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTWtLO0FBQUEsWUFHakt4QixPQUFPTCxtQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZLLGlCQUFPTCxtQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUF4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwQkE7QUFBQSxVQUdBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsMkVBQ2Y7QUFBQSxxQ0FBQyxVQUFLLHFDQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJCO0FBQUEsY0FFM0I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTTtBQUFBLGtCQUNOLFdBQVU7QUFBQSxrQkFFVixpQ0FBQyxzQkFBbUIsV0FBVSx5RUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUc7QUFBQTtBQUFBLGdCQUpyRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGlCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxZQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPUCxTQUFTUTtBQUFBQSxnQkFDaEIsVUFBVTRCO0FBQUFBLGdCQUNWLGFBQVk7QUFBQSxnQkFDWixXQUFVO0FBQUE7QUFBQSxjQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1rSztBQUFBLFlBR2pLeEIsT0FBT0osbUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWSSxpQkFBT0osbUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBeEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMEJBO0FBQUEsVUFHQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDJFQUNmO0FBQUEscUNBQUMsVUFBSywwQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQjtBQUFBLGNBRWhCO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU07QUFBQSxrQkFDTixXQUFVO0FBQUEsa0JBRVYsaUNBQUMsc0JBQW1CLFdBQVUseUVBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW1HO0FBQUE7QUFBQSxnQkFKckc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxpQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsWUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsT0FBT1IsU0FBU1M7QUFBQUEsZ0JBQ2hCLFVBQVUyQjtBQUFBQSxnQkFDVixhQUFZO0FBQUEsZ0JBQ1osV0FBVTtBQUFBO0FBQUEsY0FOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNa0s7QUFBQSxZQUdqS3hCLE9BQU9ILGtCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVkcsaUJBQU9ILGtCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBCQTtBQUFBLFVBR0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxrREFBaUQsNkJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE9BQU9ULFNBQVNVO0FBQUFBLGdCQUNoQixVQUFVLENBQUNPLFVBQVVzQixpQkFBaUIsc0JBQXNCdEIsS0FBSztBQUFBLGdCQUNqRSxNQUFLO0FBQUEsZ0JBRUw7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLE9BQU0scUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEsa0JBQ2hDLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sUUFBTyxzQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0M7QUFBQSxrQkFDbEMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxTQUFRLHVCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvQztBQUFBLGtCQUNwQyx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFFBQU8sc0JBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtDO0FBQUE7QUFBQTtBQUFBLGNBVHBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBO0FBQUEsZUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsVUFHQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtEQUFpRCw2QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsT0FBT2pCLFNBQVNXO0FBQUFBLGdCQUNoQixVQUFVLENBQUNNLFVBQ1RzQixpQkFBaUIsYUFBYXRCLEtBQUs7QUFBQSxnQkFFckMsTUFBSztBQUFBLGdCQUVKLFdBQUMsUUFBUSxRQUFRLE9BQU8sRUFBRU87QUFBQUEsa0JBQUksQ0FBQzRDLFNBQzlCLHVCQUFDLE9BQU8sUUFBUCxFQUF5QixPQUFPQSxNQUM5QkEsa0JBRGlCQSxNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBLGNBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBYUE7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLGFBeE1GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwTUE7QUFBQSxRQUdBLHVCQUFDLFdBQU0sTUFBSyxVQUFTLE1BQUssYUFBWSxPQUFNLGNBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Q7QUFBQSxRQUN0RCx1QkFBQyxXQUFNLE1BQUssVUFBUyxNQUFLLGlCQUFnQixPQUFNLFNBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUQ7QUFBQSxRQUdyRCx1QkFBQyxTQUFJLFdBQVUsK0JBRWI7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNeEYsYUFBYSxLQUFLO0FBQUEsY0FDakMsV0FBVTtBQUFBLGNBQTBGO0FBQUE7QUFBQSxZQUh0RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNQTtBQUFBLFVBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUFrRztBQUFBO0FBQUEsWUFGOUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxXQXBPRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcU9BO0FBQUEsU0FuUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9QQSxLQXJQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc1BBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV0M7QUFBQUEsUUFDWCxTQUFTLE1BQU07QUFDYkMsNkJBQW1CLEtBQUs7QUFDeEJJLHlCQUFlLElBQUk7QUFBQSxRQUNyQjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QywyQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0U7QUFBQSxVQUMvREQsZUFDQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsVUFBVSxDQUFDOEIsTUFBTTtBQUNmQSxrQkFBRW1DLGVBQWU7QUFDakJXLGlDQUFpQjtBQUFBLGNBQ25CO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFNBQ0M7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFpQjtBQUFBO0FBQUEsd0JBRVo7QUFBQSx3QkFDYix1QkFBQyxVQUFLLFdBQVUsMEJBQ2I1RSxzQkFBWWtCLGFBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHdCQUFRO0FBQUEsd0JBQUk7QUFBQSx3QkFDUztBQUFBLHdCQUNyQix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWdDO0FBQUE7QUFBQTtBQUFBLG9CQVRsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBVUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWjtBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLdUk7QUFBQSxxQkFqQnpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBbUJBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFBMEo7QUFBQTtBQUFBLGtCQUZ0SztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQTtBQUFBO0FBQUEsWUFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBaUNBO0FBQUEsYUFwQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNDQTtBQUFBO0FBQUEsTUE3Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBOENBO0FBQUEsT0E1VkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZWQSxLQTlWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK1ZBO0FBRUo7QUFBRTdCLEdBbnFCSUQsT0FBSztBQUFBZ0csS0FBTGhHO0FBcXFCTixlQUFlQTtBQUFNLElBQUFnRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJTaWRlYmFyIiwiTW9kYWwiLCJhcGkiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydERpYWxvZyIsIkRyb3Bkb3duIiwiU2VsZWN0IiwiVG9vbHRpcCIsIklvTWRNb3JlIiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwiQ2lyY3VsYXJMb2FkZXIiLCJmaWVsZFNpemUiLCJJbmZvQ2lyY2xlT3V0bGluZWQiLCJQbGFucyIsIl9zIiwicGxhbnMiLCJzZXRQbGFucyIsInRhYmxlUGxhbnMiLCJzZXRUYWJsZVBsYW5zIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwic2hvd01vZGFsRGVsZXRlIiwic2V0U2hvd01vZGFsRGVsZXRlIiwic2hvd01vZGFsVXBkYXRlIiwic2V0U2hvd01vZGFsVXBkYXRlIiwiY3VycmVudFBsYW4iLCJzZXRDdXJyZW50UGxhbiIsImN1cnJlbnRVcGRhdGVQbGFuIiwic2V0Q3VycmVudFVwZGF0ZVBsYW4iLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsInJlbG9hZFRyaWdnZXIiLCJzZXRSZWxvYWRUcmlnZ2VyIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwidHlwZSIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJwbGFuX2lkIiwicGxhbl9uYW1lIiwicGxhbl90eXBlIiwicGxhbl9jdXJyZW5jeSIsInBsYW5fcmVjdXJyaW5nX2Ftb3VudCIsInBsYW5fbWF4X2Ftb3VudCIsInBsYW5fbWF4X2N5Y2xlcyIsInBsYW5faW50ZXJ2YWxzIiwicGxhbl9pbnRlcnZhbF90eXBlIiwicGxhbl9ub3RlIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInRhcmdldCIsInZhbHVlIiwiZmV0Y2hQbGFucyIsInJlc3BvbnNlIiwiZ2V0IiwicGxhbnNEYXRhIiwiZGF0YSIsImZvcm1hdHRlZERhdGEiLCJtYXAiLCJwbGFuIiwiaW5kZXgiLCJfaWQiLCJpZCIsImFjdGlvbiIsIml0ZW1zIiwia2V5IiwibGFiZWwiLCJoYW5kbGVEZWxldGVNb2RhbE9wZW4iLCJlcnJvciIsImNvbnNvbGUiLCJoYW5kbGVDaGFuZ2UiLCJuYW1lIiwicHJldiIsImhhbmRsZUFudERTZWxlY3QiLCJmaWVsZCIsImhhbmRsZUlucHV0Q2hhbmdlIiwic2V0VXBkYXRlRm9ybURhdGEiLCJoYW5kbGVBbnRJbnB1dERTZWxlY3QiLCJ2YWxpZGF0ZUZvcm0iLCJuZXdFcnJvcnMiLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJpc1ZhbGlkIiwicmVzdEZvcm1EYXRhIiwicGF5bG9hZCIsIk51bWJlciIsInBvc3QiLCJzdGF0dXMiLCJFcnJvciIsInBsYW5JZCIsImhhbmRsZVVwZGF0ZU1vZGFsT3BlbiIsInBsYW5EYXRhIiwiaGFuZGxlRGVsZXRlUGxhbiIsImRlbGV0ZSIsImhhbmRsZVVwZGF0ZSIsInVwZGF0ZUZvcm1EYXRhIiwicGF0Y2giLCJjb2x1bW5zIiwiaGVhZGVyIiwibm90ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlBsYW5zLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCB7IERyb3Bkb3duLCBTZWxlY3QsIFRvb2x0aXAgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IGZpZWxkU2l6ZSB9IGZyb20gXCIuLi9kYXRhL2ZpZWxkU2l6ZVwiO1xyXG5pbXBvcnQgeyBJbmZvQ2lyY2xlT3V0bGluZWQgfSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuXHJcbmNvbnN0IFBsYW5zID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtwbGFucywgc2V0UGxhbnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt0YWJsZVBsYW5zLCBzZXRUYWJsZVBsYW5zXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2hvd01vZGFsLCBzZXRTaG93TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWxEZWxldGUsIHNldFNob3dNb2RhbERlbGV0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbFVwZGF0ZSwgc2V0U2hvd01vZGFsVXBkYXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudFBsYW4sIHNldEN1cnJlbnRQbGFuXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtjdXJyZW50VXBkYXRlUGxhbiwgc2V0Q3VycmVudFVwZGF0ZVBsYW5dID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3JlbG9hZFRyaWdnZXIsIHNldFJlbG9hZFRyaWdnZXJdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuXHJcbiAgLy8gRm9ybSBzdGF0ZSBmb3IgY3JlYXRlXHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBwbGFuX2lkOiBcIlwiLFxyXG4gICAgcGxhbl9uYW1lOiBcIlwiLFxyXG4gICAgcGxhbl90eXBlOiBcIlBFUklPRElDXCIsXHJcbiAgICBwbGFuX2N1cnJlbmN5OiBcIklOUlwiLFxyXG4gICAgcGxhbl9yZWN1cnJpbmdfYW1vdW50OiBcIlwiLFxyXG4gICAgcGxhbl9tYXhfYW1vdW50OiBcIlwiLFxyXG4gICAgcGxhbl9tYXhfY3ljbGVzOiBcIlwiLFxyXG4gICAgcGxhbl9pbnRlcnZhbHM6IFwiXCIsXHJcbiAgICBwbGFuX2ludGVydmFsX3R5cGU6IFwiTU9OVEhcIixcclxuICAgIHBsYW5fbm90ZTogXCJDaGl0XCIsXHJcbiAgfSk7XHJcblxyXG5cclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG5cclxuICAvLyBHbG9iYWwgc2VhcmNoIGhhbmRsZXJcclxuICBjb25zdCBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gRmV0Y2ggYWxsIHBsYW5zXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoUGxhbnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9jYXNoZnJlZS1zdWJzY3JpcHRpb24vcGxhbnNcIik7XHJcbiAgICAgICAgY29uc3QgcGxhbnNEYXRhID0gcmVzcG9uc2UuZGF0YT8uZGF0YSB8fCByZXNwb25zZS5kYXRhIHx8IFtdO1xyXG4gICAgICAgIHNldFBsYW5zKHBsYW5zRGF0YSk7XHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHBsYW5zRGF0YS5tYXAoKHBsYW4sIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgX2lkOiBwbGFuLl9pZCxcclxuICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICBwbGFuX2lkOiBwbGFuLnBsYW5faWQsXHJcbiAgICAgICAgICBwbGFuX25hbWU6IHBsYW4ucGxhbl9uYW1lLFxyXG4gICAgICAgICAgcGxhbl90eXBlOiBwbGFuLnBsYW5fdHlwZSxcclxuICAgICAgICAgIHBsYW5fY3VycmVuY3k6IHBsYW4ucGxhbl9jdXJyZW5jeSxcclxuICAgICAgICAgIHBsYW5fcmVjdXJyaW5nX2Ftb3VudDogcGxhbi5wbGFuX3JlY3VycmluZ19hbW91bnQsXHJcbiAgICAgICAgICBwbGFuX21heF9hbW91bnQ6IHBsYW4ucGxhbl9tYXhfYW1vdW50LFxyXG4gICAgICAgICAgcGxhbl9tYXhfY3ljbGVzOiBwbGFuLnBsYW5fbWF4X2N5Y2xlcyxcclxuICAgICAgICAgIHBsYW5faW50ZXJ2YWxzOiBwbGFuLnBsYW5faW50ZXJ2YWxzLFxyXG4gICAgICAgICAgcGxhbl9pbnRlcnZhbF90eXBlOiBwbGFuLnBsYW5faW50ZXJ2YWxfdHlwZSxcclxuICAgICAgICAgIHBsYW5fbm90ZTogcGxhbi5wbGFuX25vdGUsXHJcbiAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGdhcC0yXCIga2V5PXtwbGFuLl9pZH0+XHJcbiAgICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZU1vZGFsT3BlbihwbGFuLl9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApLFxyXG4gICAgICAgIH0pKTtcclxuICAgICAgICBzZXRUYWJsZVBsYW5zKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBwbGFuczpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBmZXRjaCBwbGFuc1wiLFxyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaFBsYW5zKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgLy8gSGFuZGxlIGlucHV0IGNoYW5nZSBmb3IgY3JlYXRlIGZvcm1cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHsgLi4ucHJldiwgW25hbWVdOiB2YWx1ZSB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIFtuYW1lXTogXCJcIiB9KSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gSGFuZGxlIEFudCBEZXNpZ24gU2VsZWN0IGZvciBjcmVhdGUgZm9ybVxyXG4gIGNvbnN0IGhhbmRsZUFudERTZWxlY3QgPSAoZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHsgLi4ucHJldiwgW2ZpZWxkXTogdmFsdWUgfSkpO1xyXG4gICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbZmllbGRdOiBcIlwiIH0pKTtcclxuICB9O1xyXG5cclxuICAvLyBIYW5kbGUgaW5wdXQgY2hhbmdlIGZvciB1cGRhdGUgZm9ybVxyXG4gIGNvbnN0IGhhbmRsZUlucHV0Q2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXYpID0+ICh7IC4uLnByZXYsIFtuYW1lXTogdmFsdWUgfSkpO1xyXG4gICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbbmFtZV06IFwiXCIgfSkpO1xyXG4gIH07XHJcblxyXG4gIC8vIEhhbmRsZSBBbnQgRGVzaWduIFNlbGVjdCBmb3IgdXBkYXRlIGZvcm1cclxuICBjb25zdCBoYW5kbGVBbnRJbnB1dERTZWxlY3QgPSAoZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldikgPT4gKHsgLi4ucHJldiwgW2ZpZWxkXTogdmFsdWUgfSkpO1xyXG4gICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbZmllbGRdOiBcIlwiIH0pKTtcclxuICB9O1xyXG5cclxuICAvLyBWYWxpZGF0aW9uXHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKHR5cGUpID0+IHtcclxuICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG4gICAgY29uc3QgZGF0YSA9IGZvcm1EYXRhO1xyXG5cclxuICAgIGlmICghZGF0YS5wbGFuX2lkKSBuZXdFcnJvcnMucGxhbl9pZCA9IFwiUGxhbiBJRCBpcyByZXF1aXJlZFwiO1xyXG4gICAgaWYgKCFkYXRhLnBsYW5fbmFtZSkgbmV3RXJyb3JzLnBsYW5fbmFtZSA9IFwiUGxhbiBOYW1lIGlzIHJlcXVpcmVkXCI7XHJcbiAgICBpZiAoIWRhdGEucGxhbl9yZWN1cnJpbmdfYW1vdW50IHx8IGRhdGEucGxhbl9yZWN1cnJpbmdfYW1vdW50IDw9IDApIHtcclxuICAgICAgbmV3RXJyb3JzLnBsYW5fcmVjdXJyaW5nX2Ftb3VudCA9IFwiUmVjdXJyaW5nIGFtb3VudCBtdXN0IGJlIHBvc2l0aXZlXCI7XHJcbiAgICB9XHJcbiAgICBpZiAoIWRhdGEucGxhbl9tYXhfYW1vdW50IHx8IGRhdGEucGxhbl9tYXhfYW1vdW50IDw9IDApIHtcclxuICAgICAgbmV3RXJyb3JzLnBsYW5fbWF4X2Ftb3VudCA9IFwiTWF4IGFtb3VudCBtdXN0IGJlIHBvc2l0aXZlXCI7XHJcbiAgICB9XHJcbiAgICAvLyBpZiAoIWRhdGEucGxhbl9tYXhfY3ljbGVzIHx8IGRhdGEucGxhbl9tYXhfY3ljbGVzIDw9IDApIHtcclxuICAgIC8vICAgbmV3RXJyb3JzLnBsYW5fbWF4X2N5Y2xlcyA9IFwiTWF4IGN5Y2xlcyBtdXN0IGJlIHBvc2l0aXZlXCI7XHJcbiAgICAvLyB9XHJcbiAgICBpZiAoIWRhdGEucGxhbl9pbnRlcnZhbHMgfHwgZGF0YS5wbGFuX2ludGVydmFscyA8PSAwKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5wbGFuX2ludGVydmFscyA9IFwiSW50ZXJ2YWxzIG11c3QgYmUgcG9zaXRpdmVcIjtcclxuICAgIH1cclxuICAgIGlmICghZGF0YS5wbGFuX2ludGVydmFsX3R5cGUpIHtcclxuICAgICAgbmV3RXJyb3JzLnBsYW5faW50ZXJ2YWxfdHlwZSA9IFwiSW50ZXJ2YWwgdHlwZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFkYXRhLnBsYW5fbm90ZSkge1xyXG4gICAgICBuZXdFcnJvcnMucGxhbl9ub3RlID0gXCJQbGFuIG5vdGUgaXMgcmVxdWlyZWRcIjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICAvLyBDcmVhdGUgcGxhblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBjb25zdCBpc1ZhbGlkID0gdmFsaWRhdGVGb3JtKFwiYWRkUGxhblwiKTtcclxuICAgIGlmICghaXNWYWxpZCkgcmV0dXJuO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHtcclxuICAgICAgICBwbGFuX21heF9jeWNsZXMsXHJcbiAgICAgICAgLi4ucmVzdEZvcm1EYXRhXHJcbiAgICAgIH0gPSBmb3JtRGF0YTtcclxuXHJcbiAgICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgLi4ucmVzdEZvcm1EYXRhLFxyXG4gICAgICAgIHBsYW5fcmVjdXJyaW5nX2Ftb3VudDogTnVtYmVyKGZvcm1EYXRhLnBsYW5fcmVjdXJyaW5nX2Ftb3VudCksXHJcbiAgICAgICAgcGxhbl9tYXhfYW1vdW50OiBOdW1iZXIoZm9ybURhdGEucGxhbl9tYXhfYW1vdW50KSxcclxuICAgICAgICBwbGFuX2ludGVydmFsczogTnVtYmVyKGZvcm1EYXRhLnBsYW5faW50ZXJ2YWxzKSxcclxuICAgICAgfTtcclxuXHJcbiAgICAgIC8vIG9ubHkgYWRkIGlmIHVzZXIgZW50ZXJlZCB2YWx1ZVxyXG4gICAgICBpZiAocGxhbl9tYXhfY3ljbGVzICE9PSBcIlwiICYmIHBsYW5fbWF4X2N5Y2xlcyAhPT0gbnVsbCkge1xyXG4gICAgICAgIHBheWxvYWQucGxhbl9tYXhfY3ljbGVzID0gTnVtYmVyKHBsYW5fbWF4X2N5Y2xlcyk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoXCIvY2FzaGZyZWUtc3Vic2NyaXB0aW9uL3BsYW5zXCIsIHBheWxvYWQpO1xyXG4gICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID49IDQwMCkgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGFkZCBwbGFuXCIpO1xyXG4gICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiUGxhbiBhZGRlZCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbiAgICAgIC8vIFJlc2V0IGZvcm1cclxuICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgIHBsYW5faWQ6IFwiXCIsXHJcbiAgICAgICAgcGxhbl9uYW1lOiBcIlwiLFxyXG4gICAgICAgIHBsYW5fdHlwZTogXCJQRVJJT0RJQ1wiLFxyXG4gICAgICAgIHBsYW5fY3VycmVuY3k6IFwiSU5SXCIsXHJcbiAgICAgICAgcGxhbl9yZWN1cnJpbmdfYW1vdW50OiBcIlwiLFxyXG4gICAgICAgIHBsYW5fbWF4X2Ftb3VudDogXCJcIixcclxuICAgICAgICBwbGFuX21heF9jeWNsZXM6IFwiXCIsXHJcbiAgICAgICAgcGxhbl9pbnRlcnZhbHM6IFwiXCIsXHJcbiAgICAgICAgcGxhbl9pbnRlcnZhbF90eXBlOiBcIk1PTlRIXCIsXHJcbiAgICAgICAgcGxhbl9ub3RlOiBcIkNoaXRcIixcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWRkaW5nIHBsYW46XCIsIGVycm9yKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gYWRkIHBsYW5cIixcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIE9wZW4gZGVsZXRlIG1vZGFsXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlTW9kYWxPcGVuID0gYXN5bmMgKHBsYW5JZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvY2FzaGZyZWUtc3Vic2NyaXB0aW9uL3BsYW5zLyR7cGxhbklkfWApO1xyXG4gICAgICBzZXRDdXJyZW50UGxhbihyZXNwb25zZS5kYXRhPy5kYXRhIHx8IHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICBzZXRTaG93TW9kYWxEZWxldGUodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcGxhbiBmb3IgZGVsZXRlOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gT3BlbiB1cGRhdGUgbW9kYWxcclxuICBjb25zdCBoYW5kbGVVcGRhdGVNb2RhbE9wZW4gPSBhc3luYyAocGxhbklkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9jYXNoZnJlZS1zdWJzY3JpcHRpb24vcGxhbnMvJHtwbGFuSWR9YCk7XHJcbiAgICAgIGNvbnN0IHBsYW5EYXRhID0gcmVzcG9uc2UuZGF0YT8uZGF0YSB8fCByZXNwb25zZS5kYXRhO1xyXG4gICAgICBzZXRDdXJyZW50VXBkYXRlUGxhbihwbGFuRGF0YSk7XHJcbiAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICBwbGFuX2lkOiBwbGFuRGF0YS5wbGFuX2lkIHx8IFwiXCIsXHJcbiAgICAgICAgcGxhbl9uYW1lOiBwbGFuRGF0YS5wbGFuX25hbWUgfHwgXCJcIixcclxuICAgICAgICBwbGFuX3R5cGU6IHBsYW5EYXRhLnBsYW5fdHlwZSB8fCBcIlBFUklPRElDXCIsXHJcbiAgICAgICAgcGxhbl9jdXJyZW5jeTogcGxhbkRhdGEucGxhbl9jdXJyZW5jeSB8fCBcIklOUlwiLFxyXG4gICAgICAgIHBsYW5fcmVjdXJyaW5nX2Ftb3VudDogcGxhbkRhdGEucGxhbl9yZWN1cnJpbmdfYW1vdW50IHx8IFwiXCIsXHJcbiAgICAgICAgcGxhbl9tYXhfYW1vdW50OiBwbGFuRGF0YS5wbGFuX21heF9hbW91bnQgfHwgXCJcIixcclxuICAgICAgICBwbGFuX21heF9jeWNsZXM6IHBsYW5EYXRhLnBsYW5fbWF4X2N5Y2xlcyB8fCBcIlwiLFxyXG4gICAgICAgIHBsYW5faW50ZXJ2YWxzOiBwbGFuRGF0YS5wbGFuX2ludGVydmFscyB8fCBcIlwiLFxyXG4gICAgICAgIHBsYW5faW50ZXJ2YWxfdHlwZTogcGxhbkRhdGEucGxhbl9pbnRlcnZhbF90eXBlIHx8IFwiTU9OVEhcIixcclxuICAgICAgICBwbGFuX25vdGU6IHBsYW5EYXRhLnBsYW5fbm90ZSB8fCBcIlwiLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKHRydWUpO1xyXG4gICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHBsYW4gZm9yIHVwZGF0ZTpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIERlbGV0ZSBwbGFuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlUGxhbiA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmIChjdXJyZW50UGxhbikge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGF3YWl0IGFwaS5kZWxldGUoYC9jYXNoZnJlZS1zdWJzY3JpcHRpb24vcGxhbnMvJHtjdXJyZW50UGxhbi5faWR9YCk7XHJcbiAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiUGxhbiBkZWxldGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgc2V0Q3VycmVudFBsYW4obnVsbCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIHBsYW46XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBkZWxldGUgcGxhblwiLFxyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIFVwZGF0ZSBwbGFuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGNvbnN0IGlzVmFsaWQgPSB2YWxpZGF0ZUZvcm0oXCJ1cGRhdGVQbGFuXCIpO1xyXG4gICAgaWYgKCFpc1ZhbGlkKSByZXR1cm47XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcGF5bG9hZCA9IHtcclxuICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICBwbGFuX3JlY3VycmluZ19hbW91bnQ6IE51bWJlcih1cGRhdGVGb3JtRGF0YS5wbGFuX3JlY3VycmluZ19hbW91bnQpLFxyXG4gICAgICAgIHBsYW5fbWF4X2Ftb3VudDogTnVtYmVyKHVwZGF0ZUZvcm1EYXRhLnBsYW5fbWF4X2Ftb3VudCksXHJcbiAgICAgICAgcGxhbl9tYXhfY3ljbGVzOiBOdW1iZXIodXBkYXRlRm9ybURhdGEucGxhbl9tYXhfY3ljbGVzKSxcclxuICAgICAgICBwbGFuX2ludGVydmFsczogTnVtYmVyKHVwZGF0ZUZvcm1EYXRhLnBsYW5faW50ZXJ2YWxzKSxcclxuICAgICAgfTtcclxuICAgICAgYXdhaXQgYXBpLnBhdGNoKGAvY2FzaGZyZWUtc3Vic2NyaXB0aW9uL3BsYW5zLyR7Y3VycmVudFVwZGF0ZVBsYW4uX2lkfWAsIHBheWxvYWQpO1xyXG4gICAgICBzZXRTaG93TW9kYWxVcGRhdGUoZmFsc2UpO1xyXG4gICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICBtZXNzYWdlOiBcIlBsYW4gdXBkYXRlZCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBwbGFuOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byB1cGRhdGUgcGxhblwiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBUYWJsZSBjb2x1bW5zXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwicGxhbl9pZFwiLCBoZWFkZXI6IFwiUGxhbiBJRFwiIH0sXHJcbiAgICB7IGtleTogXCJwbGFuX25hbWVcIiwgaGVhZGVyOiBcIlBsYW4gTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwbGFuX3R5cGVcIiwgaGVhZGVyOiBcIlR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGxhbl9jdXJyZW5jeVwiLCBoZWFkZXI6IFwiQ3VycmVuY3lcIiB9LFxyXG4gICAgeyBrZXk6IFwicGxhbl9yZWN1cnJpbmdfYW1vdW50XCIsIGhlYWRlcjogXCJSZWN1cnJpbmcgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcInBsYW5fbWF4X2Ftb3VudFwiLCBoZWFkZXI6IFwiTWF4IEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJwbGFuX21heF9jeWNsZXNcIiwgaGVhZGVyOiBcIk1heCBDeWNsZXNcIiB9LFxyXG4gICAgeyBrZXk6IFwicGxhbl9pbnRlcnZhbHNcIiwgaGVhZGVyOiBcIkludGVydmFsc1wiIH0sXHJcbiAgICB7IGtleTogXCJwbGFuX2ludGVydmFsX3R5cGVcIiwgaGVhZGVyOiBcIkludGVydmFsIFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGxhbl9ub3RlXCIsIGhlYWRlcjogXCJOb3RlXCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGRpdj5cclxuICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXtvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbiAgICAgICAgLz5cclxuICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbiAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT5cclxuICAgICAgICAgICAgc2V0QWxlcnRDb25maWcoKHByZXYpID0+ICh7IC4uLnByZXYsIHZpc2liaWxpdHk6IGZhbHNlIH0pKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi04XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPlN1YnNjcmlwdGlvbiBQbGFuczwvaDE+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtNCBiZy1ibHVlLTk1MCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy1ibHVlLTgwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICsgQWRkIFBsYW5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHt0YWJsZVBsYW5zPy5sZW5ndGggPiAwICYmICFpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgY2F0Y2hlcj1cIl9pZFwiXHJcbiAgICAgICAgICAgICAgICB1cGRhdGVIYW5kbGVyPXtoYW5kbGVVcGRhdGVNb2RhbE9wZW59XHJcbiAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJPcHRpb24odGFibGVQbGFucywgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiU3Vic2NyaXB0aW9uUGxhbnNcIlxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIlN1YnNjcmlwdGlvblBsYW5zLmNzdlwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICAgIGlzTG9hZGluZz17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgZGF0YT1cIlBsYW5zXCJcclxuICAgICAgICAgICAgICAgIGZhaWx1cmU9e3RhYmxlUGxhbnM/Lmxlbmd0aCA8PSAwfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIEFkZCBQbGFuIE1vZGFsICovfVxyXG4gICAgICAgIGBgYGpzeFxyXG4gICAgICAgIHsvKiBBZGQgUGxhbiBNb2RhbCAqL31cclxuICAgICAgICA8TW9kYWwgaXNWaXNpYmxlPXtzaG93TW9kYWx9IG9uQ2xvc2U9eygpID0+IHNldFNob3dNb2RhbChmYWxzZSl9PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTYgdGV4dC1sZWZ0IGJnLXdoaXRlIHJvdW5kZWQtMnhsIG1heC1oLVs5MHZoXSBvdmVyZmxvdy15LWF1dG9cIj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBIZWFkZXIgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTYgYm9yZGVyLWIgcGItNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgQ3JlYXRlIFN1YnNjcmlwdGlvbiBQbGFuXHJcbiAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgQWRkIG5ldyByZWN1cnJpbmcgc3Vic2NyaXB0aW9uIHBsYW5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBub1ZhbGlkYXRlPlxyXG5cclxuICAgICAgICAgICAgICB7LyogR3JpZCBMYXlvdXQgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC01XCI+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFBsYW4gSUQgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFBsYW4gSUQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGxhbl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBsYW5faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk1DRi1QTC17e05VTUJFUn19LXt7QU1PVU5UfX1cIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctZ3JheS01MCBweC00IHB5LTMgdGV4dC1zbSBvdXRsaW5lLW5vbmUgdHJhbnNpdGlvbiBmb2N1czpib3JkZXItYmx1ZS01MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wbGFuX2lkICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBsYW5faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFBsYW4gTmFtZSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUGxhbiBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBsYW5fbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBsYW5fbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiR29sZCBNb250aGx5IFBsYW5cIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctZ3JheS01MCBweC00IHB5LTMgdGV4dC1zbSBvdXRsaW5lLW5vbmUgdHJhbnNpdGlvbiBmb2N1czpib3JkZXItYmx1ZS01MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wbGFuX25hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGxhbl9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBSZWN1cnJpbmcgQW1vdW50ICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+UmVjdXJyaW5nIEFtb3VudCAo4oK5KTwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPFRvb2x0aXBcclxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQW1vdW50IHRoYXQgY3VzdG9tZXIgbmVlZHMgdG8gcGF5IHJlcGVhdGVkbHkgZm9yIGVhY2ggY3ljbGUuXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cInRvcFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEluZm9DaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNTAwIGN1cnNvci1wb2ludGVyIGhvdmVyOnRleHQtYmx1ZS03MDAgdHJhbnNpdGlvbiB0ZXh0LXNtXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L1Rvb2x0aXA+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGxhbl9yZWN1cnJpbmdfYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGxhbl9yZWN1cnJpbmdfYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCI1MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctZ3JheS01MCBweC00IHB5LTMgdGV4dC1zbSBvdXRsaW5lLW5vbmUgdHJhbnNpdGlvbiBmb2N1czpib3JkZXItYmx1ZS01MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wbGFuX3JlY3VycmluZ19hbW91bnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGxhbl9yZWN1cnJpbmdfYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBNYXggQW1vdW50ICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+TWF4IEFtb3VudCAo4oK5KTwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPFRvb2x0aXBcclxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiTWF4aW11bSB0b3RhbCBhbW91bnQgYWxsb3dlZCB1bmRlciB0aGlzIHN1YnNjcmlwdGlvbiBwbGFuLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJ0b3BcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbmZvQ2lyY2xlT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTUwMCBjdXJzb3ItcG9pbnRlciBob3Zlcjp0ZXh0LWJsdWUtNzAwIHRyYW5zaXRpb24gdGV4dC1zbVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Ub29sdGlwPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBsYW5fbWF4X2Ftb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBsYW5fbWF4X2Ftb3VudH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMTAwMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgYmctZ3JheS01MCBweC00IHB5LTMgdGV4dC1zbSBvdXRsaW5lLW5vbmUgdHJhbnNpdGlvbiBmb2N1czpib3JkZXItYmx1ZS01MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wbGFuX21heF9hbW91bnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGxhbl9tYXhfYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBNYXggQ3ljbGVzICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+TWF4IEN5Y2xlcyAoT3B0aW9uYWwpPC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8VG9vbHRpcFxyXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJNYXhpbXVtIG51bWJlciBvZiBjeWNsZXMgZm9yIHRoaXMgc3Vic2NyaXB0aW9uIHBsYW4uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cInRvcFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEluZm9DaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNTAwIGN1cnNvci1wb2ludGVyIGhvdmVyOnRleHQtYmx1ZS03MDAgdHJhbnNpdGlvbiB0ZXh0LXNtXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L1Rvb2x0aXA+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGxhbl9tYXhfY3ljbGVzXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGxhbl9tYXhfY3ljbGVzfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIxMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy1ncmF5LTUwIHB4LTQgcHktMyB0ZXh0LXNtIG91dGxpbmUtbm9uZSB0cmFuc2l0aW9uIGZvY3VzOmJvcmRlci1ibHVlLTUwMCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBsYW5fbWF4X2N5Y2xlcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wbGFuX21heF9jeWNsZXN9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIEludGVydmFscyAqL31cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPiBJbnRlcnZhbHM8L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxUb29sdGlwXHJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlRvdGFsIG51bWJlciBvZiBJbnRlcnZhbHMgZm9yIHRoaXMgc3Vic2NyaXB0aW9uIHBsYW4uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cInRvcFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEluZm9DaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNTAwIGN1cnNvci1wb2ludGVyIGhvdmVyOnRleHQtYmx1ZS03MDAgdHJhbnNpdGlvbiB0ZXh0LXNtXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L1Rvb2x0aXA+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGxhbl9pbnRlcnZhbHNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5wbGFuX2ludGVydmFsc31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBiZy1ncmF5LTUwIHB4LTQgcHktMyB0ZXh0LXNtIG91dGxpbmUtbm9uZSB0cmFuc2l0aW9uIGZvY3VzOmJvcmRlci1ibHVlLTUwMCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBsYW5faW50ZXJ2YWxzICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBsYW5faW50ZXJ2YWxzfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBJbnRlcnZhbCBUeXBlICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBJbnRlcnZhbCBUeXBlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgY3VzdG9tLXNlbGVjdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBsYW5faW50ZXJ2YWxfdHlwZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwicGxhbl9pbnRlcnZhbF90eXBlXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJEQVlcIj5EYWlseTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIldFRUtcIj5XZWVrbHk8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJNT05USFwiPk1vbnRobHk8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJZRUFSXCI+WWVhcmx5PC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBQbGFuIE5vdGUgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFBsYW4gQ2F0ZWdvcnlcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgY3VzdG9tLXNlbGVjdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBsYW5fbm90ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcInBsYW5fbm90ZVwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtbXCJDaGl0XCIsIFwiTG9hblwiLCBcIlBpZ215XCJdLm1hcCgobm90ZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtub3RlfSB2YWx1ZT17bm90ZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtub3RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIEhpZGRlbiBGaWVsZHMgKi99XHJcbiAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJoaWRkZW5cIiBuYW1lPVwicGxhbl90eXBlXCIgdmFsdWU9XCJQRVJJT0RJQ1wiIC8+XHJcbiAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJoaWRkZW5cIiBuYW1lPVwicGxhbl9jdXJyZW5jeVwiIHZhbHVlPVwiSU5SXCIgLz5cclxuXHJcbiAgICAgICAgICAgICAgey8qIEJ1dHRvbnMgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zIG10LThcIj5cclxuXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TW9kYWwoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC01IHB5LTIuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTcwMCBob3ZlcjpiZy1ncmF5LTEwMCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC02IHB5LTIuNSByb3VuZGVkLXhsIGJnLWJsdWUtOTAwIHRleHQtd2hpdGUgZm9udC1tZWRpdW0gaG92ZXI6YmctYmx1ZS04MDAgdHJhbnNpdGlvbiBzaGFkb3ctbGdcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBTYXZlIFBsYW5cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgICB7LyogRGVsZXRlIFBsYW4gTW9kYWwgKi99XHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbERlbGV0ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0Q3VycmVudFBsYW4obnVsbCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5EZWxldGUgUGxhbjwvaDM+XHJcbiAgICAgICAgICAgIHtjdXJyZW50UGxhbiAmJiAoXHJcbiAgICAgICAgICAgICAgPGZvcm1cclxuICAgICAgICAgICAgICAgIG9uU3VibWl0PXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICAgICAgICAgIGhhbmRsZURlbGV0ZVBsYW4oKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzcGFjZS15LTZcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwicGxhbk5hbWVDb25maXJtXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFBsZWFzZSBlbnRlcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnkgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudFBsYW4ucGxhbl9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgdG8gY29uZmlybSBkZWxldGlvbi57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwicGxhbk5hbWVDb25maXJtXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBwbGFuIG5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXdoaXRlIGJnLXJlZC03MDAgaG92ZXI6YmctcmVkLTgwMCBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctYmx1ZS0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQbGFuczsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvUGxhbnMuanN4In0=