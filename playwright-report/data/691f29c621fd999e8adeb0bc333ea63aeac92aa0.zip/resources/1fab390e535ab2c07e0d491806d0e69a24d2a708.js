import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CustomerDocuments.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport4_react["useEffect"];
import { Select, Spin, Modal, Progress, Image, Tooltip, message } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { useNavigate, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import api from "/src/instance/TokenInstance.js";
import companyLogo from "/src/assets/images/mychits.png?import";
import html2canvas from "/node_modules/.vite/deps/html2canvas.js?v=819e0a34";
import jsPDF from "/node_modules/.vite/deps/jspdf.js?v=819e0a34";
import {
  IoEye,
  IoDocument,
  IoClose,
  IoDownload,
  IoPerson,
  IoCall,
  IoMail,
  IoLocation,
  IoDocumentText,
  IoWallet,
  IoBusiness,
  IoCard,
  IoCalendar,
  IoCheckmarkCircle,
  IoTimeOutline,
  IoPrintOutline,
  IoShareOutline
} from "/node_modules/.vite/deps/react-icons_io5.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const REQUIRED_DOCUMENTS = [
  { key: "user_profile_photo", label: "Photo" },
  { key: "user_adharcard_front_photo", label: "Aadhar Card (Front)" },
  { key: "user_adharcard_back_photo", label: "Aadhar Card (Back)" },
  { key: "user_pancard_photo", label: "PAN Card" },
  { key: "user_cheque_leaf", label: "Cheque Leaf" },
  { key: "bank_statement_month", label: "Bank Statement - Month 1" },
  { key: "bank_passbook_photo", label: "Passbook Photo" },
  { key: "business_document_proof", label: "Business Proof" },
  { key: "user_salary_slip", label: "Salary Slip" },
  {
    key: "user_nominee_adharcard_front_photo",
    label: "Nominee Aadhar (Front)"
  },
  { key: "user_nominee_adharcard_back_photo", label: "Nominee Aadhar (Back)" },
  { key: "user_nominee_pancard_photo", label: "Nominee PAN Card" }
];
const calculatePercentageFromUserDoc = (userDoc) => {
  if (!userDoc) return 0;
  let uploadedCount = 0;
  REQUIRED_DOCUMENTS.forEach((doc) => {
    if (userDoc[doc.key]) {
      uploadedCount++;
    }
  });
  const percentage = uploadedCount / REQUIRED_DOCUMENTS.length * 100;
  return Math.round(percentage);
};
const InfoItem = ({ label, value, fullWidth = false, icon: Icon }) => /* @__PURE__ */ jsxDEV("div", { className: `${fullWidth ? "col-span-full" : ""} bg-gray-50 rounded-lg p-3 hover:bg-gray-100 transition-colors`, children: [
  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
    Icon && /* @__PURE__ */ jsxDEV(Icon, { className: "w-4 h-4 text-blue-500" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
      lineNumber: 68,
      columnNumber: 16
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 font-medium uppercase tracking-wider", children: label }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
      lineNumber: 69,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
    lineNumber: 67,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-900 font-medium mt-1 break-words", children: value && value !== "N/A" && value !== "undefined" && value !== "null" ? value : "N/A" }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
    lineNumber: 71,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
  lineNumber: 66,
  columnNumber: 1
}, this);
_c = InfoItem;
const formatDate = (dateString) => {
  if (!dateString) return "N/A";
  try {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric"
    });
  } catch {
    return "N/A";
  }
};
const DocumentUploadField = ({
  label,
  required,
  onChange,
  file,
  preview,
  existingUrl,
  onPreview,
  onDelete,
  formatBytes
}) => {
  const inputId = `file-${label.replace(/\s/g, "-")}-${Math.random().toString(36).substr(2, 9)}`;
  const isImage = file && file.type?.startsWith("image/");
  const hasExistingDoc = existingUrl && !file;
  const isExistingImage = hasExistingDoc && existingUrl?.match(/\.(jpeg|jpg|gif|png|webp)$/i);
  return /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-200 rounded-lg p-3 bg-white hover:shadow-md transition-shadow", children: [
    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: [
      label,
      " ",
      required && /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
        lineNumber: 113,
        columnNumber: 30
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
      lineNumber: 112,
      columnNumber: 7
    }, this),
    !file && !hasExistingDoc ? /* @__PURE__ */ jsxDEV("div", { className: "border-2 border-dashed border-gray-300 rounded-md p-4 flex flex-col items-center justify-center text-center hover:bg-gray-50 transition-colors", children: [
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "file",
          accept: "image/*,.pdf",
          onChange,
          className: "hidden",
          id: inputId
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 118,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "label",
        {
          htmlFor: inputId,
          className: "cursor-pointer text-blue-600 hover:text-blue-700 font-medium text-sm",
          children: "Click to Upload"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 125,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: "JPG, PNG or PDF (Max 5MB)" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
        lineNumber: 131,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
      lineNumber: 117,
      columnNumber: 7
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between bg-gray-50 p-2 rounded border border-gray-200", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center flex-1 overflow-hidden", children: file ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        isImage && preview ? /* @__PURE__ */ jsxDEV(
          "img",
          {
            src: preview,
            alt: label,
            className: "w-12 h-12 rounded object-cover mr-3 cursor-pointer hover:opacity-80 transition-opacity",
            onClick: () => onPreview(preview, label)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 141,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded bg-gray-200 mr-3 flex items-center justify-center text-gray-500", children: /* @__PURE__ */ jsxDEV(IoDocument, { className: "text-2xl" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 149,
          columnNumber: 21
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 148,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col min-w-0", children: [
          /* @__PURE__ */ jsxDEV(
            "p",
            {
              className: "text-sm font-medium text-gray-900 truncate",
              title: file.name,
              children: file.name
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 153,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: formatBytes(file.size) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 159,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-green-600 mt-1", children: "New file (will replace existing)" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 162,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 152,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
        lineNumber: 139,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
        isExistingImage ? /* @__PURE__ */ jsxDEV(
          "img",
          {
            src: existingUrl,
            alt: label,
            className: "w-12 h-12 rounded object-cover mr-3 cursor-pointer hover:opacity-80 transition-opacity",
            onClick: () => onPreview(existingUrl, label)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 170,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded bg-gray-200 mr-3 flex items-center justify-center text-gray-500", children: /* @__PURE__ */ jsxDEV(IoDocument, { className: "text-2xl" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 178,
          columnNumber: 21
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 177,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col min-w-0", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-green-700 truncate", children: "✓ Already uploaded" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 182,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: 'Click "View" to see document' }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 185,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => onPreview(existingUrl, label),
              className: "text-xs text-blue-600 hover:text-blue-800 mt-1 text-left flex items-center gap-1",
              children: [
                /* @__PURE__ */ jsxDEV(IoEye, { className: "text-sm" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 193,
                  columnNumber: 21
                }, this),
                "View existing document"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 188,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 181,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
        lineNumber: 168,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
        lineNumber: 137,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: onDelete,
          className: "ml-2 text-gray-400 hover:text-red-500 transition-colors p-1",
          title: file ? "Remove file" : "Remove existing document (will be deleted on upload)",
          children: /* @__PURE__ */ jsxDEV(IoClose, { className: "text-xl" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 211,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 201,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
      lineNumber: 136,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
    lineNumber: 111,
    columnNumber: 5
  }, this);
};
_c2 = DocumentUploadField;
function CustomerDocuments() {
  _s();
  const navigate = useNavigate();
  const location = useLocation();
  const [searchText, setSearchText] = useState("");
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [toast, setToast] = useState({ show: false, message: "", type: "" });
  const [previewImage, setPreviewImage] = useState(null);
  const [previewTitle, setPreviewTitle] = useState("");
  const [initializing, setInitializing] = useState(true);
  const [existingDocuments, setExistingDocuments] = useState(null);
  const [fetchingDocuments, setFetchingDocuments] = useState(false);
  const [otherDocuments, setOtherDocuments] = useState([]);
  const [showGuarantor, setShowGuarantor] = useState(false);
  const [guarantorData, setGuarantorData] = useState({
    name: "",
    phoneNumber: "",
    email: "",
    address: "",
    aadharFront: null,
    panCard: null,
    photo: null
  });
  const [guarantorPreviews, setGuarantorPreviews] = useState({
    aadharFront: null,
    panCard: null,
    photo: null
  });
  const [existingGuarantorUrls, setExistingGuarantorUrls] = useState(null);
  const [fullCustomerDetails, setFullCustomerDetails] = useState(null);
  const [loadingDetails, setLoadingDetails] = useState(false);
  const [isCustomerDetailsOpen, setIsCustomerDetailsOpen] = useState(true);
  const [replacedDocuments, setReplacedDocuments] = useState({});
  const [formData, setFormData] = useState({
    user_profile_photo: null,
    user_adharcard_front_photo: null,
    user_adharcard_back_photo: null,
    user_pancard_photo: null,
    user_cheque_leaf: null,
    bank_statement_month: null,
    bank_passbook_photo: null,
    business_document_proof: null,
    user_salary_slip: null,
    nominee: {
      name: "",
      phoneNumber: "",
      user_nominee_adharcard_front_photo: null,
      user_nominee_adharcard_back_photo: null,
      user_nominee_pancard_photo: null
    }
  });
  const [filePreviews, setFilePreviews] = useState({
    user_profile_photo: null,
    user_adharcard_front_photo: null,
    user_adharcard_back_photo: null,
    user_pancard_photo: null,
    user_cheque_leaf: null,
    bank_statement_month: null,
    bank_passbook_photo: null,
    business_document_proof: null,
    user_salary_slip: null,
    user_nominee_adharcard_front_photo: null,
    user_nominee_adharcard_back_photo: null,
    user_nominee_pancard_photo: null
  });
  const [existingDocumentUrls, setExistingDocumentUrls] = useState({
    user_profile_photo: null,
    user_adharcard_front_photo: null,
    user_adharcard_back_photo: null,
    user_pancard_photo: null,
    user_cheque_leaf: null,
    bank_statement_month: null,
    bank_passbook_photo: null,
    business_document_proof: null,
    user_salary_slip: null,
    user_nominee_adharcard_front_photo: null,
    user_nominee_adharcard_back_photo: null,
    user_nominee_pancard_photo: null
  });
  const formatBytes = (bytes, decimals = 2) => {
    if (!+bytes) return "0 Bytes";
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
  };
  const showToast = (message2, type = "success") => {
    setToast({ show: true, message: message2, type });
    setTimeout(() => {
      setToast({ show: false, message: "", type: "" });
    }, 3e3);
  };
  const handleDownloadPDF = async () => {
    const element = document.getElementById("customer-profile-print");
    if (!element) {
      message.error("Profile not found to download");
      return;
    }
    const hideMsg = message.loading("Generating PDF...", 0);
    try {
      const clone = element.cloneNode(true);
      const actionButtons = clone.querySelectorAll(".hide-in-print");
      actionButtons.forEach((btn) => btn.remove());
      const sections = clone.querySelectorAll(".border-b, .border-gray-200");
      sections.forEach((section) => {
        section.style.pageBreakInside = "avoid";
        section.style.breakInside = "avoid";
      });
      const tempContainer = document.createElement("div");
      tempContainer.style.position = "fixed";
      tempContainer.style.left = "-9999px";
      tempContainer.style.top = "0";
      tempContainer.style.width = "900px";
      tempContainer.style.background = "white";
      tempContainer.style.padding = "10px";
      tempContainer.style.zIndex = "-9999";
      tempContainer.appendChild(clone);
      document.body.appendChild(tempContainer);
      await new Promise((resolve) => setTimeout(resolve, 1e3));
      const canvas = await html2canvas(tempContainer, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: "#ffffff",
        logging: false,
        width: 900,
        height: tempContainer.scrollHeight,
        onclone: function(doc) {
          const images = doc.querySelectorAll("img");
          return Promise.all(Array.from(images).map((img) => {
            if (img.complete) return;
            return new Promise((resolve) => {
              img.onload = resolve;
              img.onerror = resolve;
            });
          }));
        }
      });
      document.body.removeChild(tempContainer);
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF({
        orientation: "portrait",
        unit: "mm",
        format: "a4"
      });
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const imgHeight = canvas.height * pdfWidth / canvas.width;
      const pageHeight = pdf.internal.pageSize.getHeight();
      const totalPages = Math.ceil(imgHeight / pageHeight);
      for (let i = 0; i < totalPages; i++) {
        if (i > 0) {
          pdf.addPage();
        }
        const yOffset = -i * pageHeight;
        pdf.addImage(imgData, "PNG", 0, yOffset, pdfWidth, imgHeight);
      }
      const fileName = `Customer_Profile_${fullCustomerDetails?.customer_id || "profile"}_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.pdf`;
      pdf.save(fileName);
      message.destroy();
      message.success("PDF downloaded successfully!");
    } catch (error) {
      console.error("Error generating PDF:", error);
      message.destroy();
      message.error("Failed to generate PDF. Please try again.");
    }
  };
  const fetchUserDocuments = async (userId) => {
    setFetchingDocuments(true);
    try {
      const response = await api.get(`/v1/admin/user-documents/${userId}`);
      if (response.data && response.data.data) {
        let documentsData = response.data.data;
        if (Array.isArray(documentsData) && documentsData.length > 0) {
          documentsData = documentsData[0];
        }
        setExistingDocuments(documentsData);
        setFullCustomerDetails(documentsData);
        const existingUrls = {};
        REQUIRED_DOCUMENTS.forEach((doc) => {
          if (documentsData[doc.key]) {
            existingUrls[doc.key] = documentsData[doc.key];
          }
        });
        setExistingDocumentUrls(existingUrls);
        if (documentsData.other_documents_name || documentsData.other_documents_photo) {
          setOtherDocuments(
            [
              {
                id: Date.now().toString(),
                name: documentsData.other_documents_name || "",
                file: null,
                preview: null,
                existingUrl: documentsData.other_documents_photo || null,
                existingName: documentsData.other_documents_name || ""
              }
            ]
          );
        } else {
          setOtherDocuments([]);
        }
        if (documentsData.nominee_name) {
          setFormData((prev) => ({
            ...prev,
            nominee: {
              ...prev.nominee,
              name: documentsData.nominee_name || "",
              phoneNumber: documentsData.nominee_phone || ""
            }
          }));
        }
        return documentsData;
      } else {
        setExistingDocuments(null);
        setFullCustomerDetails(null);
        return null;
      }
    } catch (error) {
      console.error("Error fetching existing documents:", error);
      setExistingDocuments(null);
      setFullCustomerDetails(null);
      return null;
    } finally {
      setFetchingDocuments(false);
    }
  };
  const fetchCustomers = async () => {
    setLoading(true);
    try {
      const response = await api.get("/user/get-user");
      let allUsers = [];
      if (response.data.users) {
        allUsers = response.data.users;
      } else if (response.data.data) {
        allUsers = response.data.data;
      } else if (Array.isArray(response.data)) {
        allUsers = response.data;
      } else {
        allUsers = [];
      }
      const formattedCustomers = allUsers.map((user) => ({
        _id: user._id,
        name: user.full_name || user.name || "Unknown",
        email: user.email || "",
        phone: user.phone_number || user.phone || "",
        customer_id: user.customer_id || "",
        address: user.address || "-",
        pincode: user.pincode || "-",
        adhaar_no: user.adhaar_no || "",
        pan_no: user.pan_no || "",
        approval_status: user.approval_status || "",
        track_source: user.track_source || "",
        referral_type: user.referral_type || "",
        referred_agent: user.referred_agent || "",
        referred_customer: user.referred_customer || "",
        joining_date: user.joining_date || "",
        alternate_number: user.alternate_number || "",
        bank_IFSC_code: user.bank_IFSC_code || "",
        bank_account_number: user.bank_account_number || "",
        bank_branch_name: user.bank_branch_name || "",
        bank_name: user.bank_name || "",
        dateofbirth: user.dateofbirth || "",
        district: user.district || "",
        father_name: user.father_name || "",
        gender: user.gender || "",
        marital_status: user.marital_status || "",
        nationality: user.nationality || "",
        nominee_dateofbirth: user.nominee_dateofbirth || "",
        nominee_name: user.nominee_name || "",
        nominee_phone_number: user.nominee_phone_number || "",
        nominee_relationship: user.nominee_relationship || "",
        referral_name: user.referral_name || "",
        registration_date: user.registration_date || "",
        state: user.state || "",
        taluk: user.taluk || "",
        title: user.title || "",
        collection_area: user?.collection_area?.route_name || "",
        referred_employee: user?.referred_employee?.name || "",
        percentage: user.percentage || "",
        label: `${user.full_name || user.name || "Unknown"} - ${user.phone_number || user.phone || "No Phone"}`,
        value: user._id
      }));
      setCustomers(formattedCustomers);
      await checkUrlParamsAndSelectCustomer(formattedCustomers);
      if (formattedCustomers.length === 0) {
        showToast("No customers found", "error");
      }
    } catch (error) {
      console.error("Error fetching customers:", error);
      showToast("Failed to fetch customers", "error");
    } finally {
      setLoading(false);
      setInitializing(false);
    }
  };
  const checkUrlParamsAndSelectCustomer = async (customersList) => {
    const params = new URLSearchParams(location.search);
    const userId = params.get("userId");
    const auctionId = params.get("auctionId");
    if (userId && customersList.length > 0) {
      const customer = customersList.find((c) => c._id === userId);
      if (customer) {
        setSelectedCustomer(customer);
        await fetchUserDocuments(userId);
        setTimeout(() => {
          setShowUploadModal(true);
        }, 500);
      } else {
        showToast("Customer not found", "error");
      }
    }
  };
  const documentPercentage = existingDocuments ? calculatePercentageFromUserDoc(existingDocuments) : 0;
  useEffect(() => {
    fetchCustomers();
  }, []);
  useEffect(() => {
    if (customers.length > 0) {
      checkUrlParamsAndSelectCustomer(customers);
    }
  }, [location.search, customers.length]);
  const handleCustomerSelect = async (customerId) => {
    const selected = customers.find((c) => c._id === customerId);
    if (selected) {
      setSelectedCustomer(selected);
      setLoadingDetails(true);
      try {
        const documents = await fetchUserDocuments(customerId);
        if (documents) {
          setFullCustomerDetails({
            ...selected,
            ...documents
          });
        } else {
          setFullCustomerDetails({
            ...selected,
            full_name: selected.name,
            phone_number: selected.phone,
            email: selected.email,
            customer_id: selected.customer_id
          });
        }
      } catch (error) {
        console.error("Error fetching customer details:", error);
        setFullCustomerDetails({
          ...selected,
          full_name: selected.name,
          phone_number: selected.phone,
          email: selected.email,
          customer_id: selected.customer_id
        });
      } finally {
        setLoadingDetails(false);
        setShowUploadModal(true);
      }
    }
  };
  const handleFileChange = (e, field) => {
    const file = e.target.files[0];
    if (file) {
      const previewUrl = URL.createObjectURL(file);
      if (field === "nominee_adharcard_front") {
        setFormData((prev) => ({
          ...prev,
          nominee: {
            ...prev.nominee,
            user_nominee_adharcard_front_photo: file
          }
        }));
        setFilePreviews((prev) => ({
          ...prev,
          user_nominee_adharcard_front_photo: previewUrl
        }));
        setReplacedDocuments((prev) => ({
          ...prev,
          user_nominee_adharcard_front_photo: true
        }));
      } else if (field === "nominee_adharcard_back") {
        setFormData((prev) => ({
          ...prev,
          nominee: {
            ...prev.nominee,
            user_nominee_adharcard_back_photo: file
          }
        }));
        setFilePreviews((prev) => ({
          ...prev,
          user_nominee_adharcard_back_photo: previewUrl
        }));
        setReplacedDocuments((prev) => ({
          ...prev,
          user_nominee_adharcard_back_photo: true
        }));
      } else if (field === "nominee_pancard") {
        setFormData((prev) => ({
          ...prev,
          nominee: {
            ...prev.nominee,
            user_nominee_pancard_photo: file
          }
        }));
        setFilePreviews((prev) => ({
          ...prev,
          user_nominee_pancard_photo: previewUrl
        }));
        setReplacedDocuments((prev) => ({
          ...prev,
          user_nominee_pancard_photo: true
        }));
      } else {
        setFormData((prev) => ({
          ...prev,
          [field]: file
        }));
        setFilePreviews((prev) => ({ ...prev, [field]: previewUrl }));
        setReplacedDocuments((prev) => ({ ...prev, [field]: true }));
      }
    }
  };
  const handleFileRemove = (field) => {
    if (field === "nominee_adharcard_front") {
      setFormData((prev) => ({
        ...prev,
        nominee: {
          ...prev.nominee,
          user_nominee_adharcard_front_photo: null
        }
      }));
      setFilePreviews((prev) => ({
        ...prev,
        user_nominee_adharcard_front_photo: null
      }));
      setReplacedDocuments((prev) => ({
        ...prev,
        user_nominee_adharcard_front_photo: false
      }));
    } else if (field === "nominee_adharcard_back") {
      setFormData((prev) => ({
        ...prev,
        nominee: {
          ...prev.nominee,
          user_nominee_adharcard_back_photo: null
        }
      }));
      setFilePreviews((prev) => ({
        ...prev,
        user_nominee_adharcard_back_photo: null
      }));
      setReplacedDocuments((prev) => ({
        ...prev,
        user_nominee_adharcard_back_photo: false
      }));
    } else if (field === "nominee_pancard") {
      setFormData((prev) => ({
        ...prev,
        nominee: {
          ...prev.nominee,
          user_nominee_pancard_photo: null
        }
      }));
      setFilePreviews((prev) => ({
        ...prev,
        user_nominee_pancard_photo: null
      }));
      setReplacedDocuments((prev) => ({
        ...prev,
        user_nominee_pancard_photo: false
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        [field]: null
      }));
      setFilePreviews((prev) => ({ ...prev, [field]: null }));
      setReplacedDocuments((prev) => ({ ...prev, [field]: false }));
    }
  };
  const handlePreview = (imageUrl, title) => {
    setPreviewImage(imageUrl);
    setPreviewTitle(title);
  };
  const handleCancelPreview = () => {
    setPreviewImage(null);
    setPreviewTitle("");
  };
  const handleNomineeTextChange = (e, field) => {
    setFormData({
      ...formData,
      nominee: {
        ...formData.nominee,
        [field]: e.target.value
      }
    });
  };
  const addOtherDocument = () => {
    if (otherDocuments.length >= 1) {
      message.warning("You can only add one other document");
      return;
    }
    const newId = Date.now().toString();
    setOtherDocuments(
      [
        ...otherDocuments,
        {
          id: newId,
          name: "",
          file: null,
          preview: null,
          existingUrl: null,
          existingName: null
        }
      ]
    );
  };
  const removeOtherDocument = (id) => {
    const docToRemove = otherDocuments.find((doc) => doc.id === id);
    if (docToRemove?.preview) {
      URL.revokeObjectURL(docToRemove.preview);
    }
    setOtherDocuments(otherDocuments.filter((doc) => doc.id !== id));
  };
  const updateOtherDocumentName = (id, name) => {
    setOtherDocuments(
      otherDocuments.map((doc) => doc.id === id ? { ...doc, name } : doc)
    );
  };
  const handleOtherDocumentFileChange = (e, id) => {
    const file = e.target.files[0];
    if (file) {
      const previewUrl = URL.createObjectURL(file);
      setOtherDocuments(
        otherDocuments.map(
          (doc) => doc.id === id ? {
            ...doc,
            file,
            preview: previewUrl,
            existingUrl: null,
            existingName: null
          } : doc
        )
      );
    }
  };
  const removeOtherDocumentFile = (id) => {
    const docToUpdate = otherDocuments.find((doc) => doc.id === id);
    if (docToUpdate?.preview) {
      URL.revokeObjectURL(docToUpdate.preview);
    }
    setOtherDocuments(
      otherDocuments.map(
        (doc) => doc.id === id ? { ...doc, file: null, preview: null } : doc
      )
    );
  };
  const handleGuarantorFileChange = (e, field) => {
    const file = e.target.files[0];
    if (file) {
      const previewUrl = URL.createObjectURL(file);
      setGuarantorData((prev) => ({ ...prev, [field]: file }));
      setGuarantorPreviews((prev) => ({ ...prev, [field]: previewUrl }));
    }
  };
  const handleGuarantorFileRemove = (field) => {
    if (guarantorPreviews[field]) {
      URL.revokeObjectURL(guarantorPreviews[field]);
    }
    setGuarantorData((prev) => ({ ...prev, [field]: null }));
    setGuarantorPreviews((prev) => ({ ...prev, [field]: null }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    setUploading(true);
    try {
      const uploadFormData = new FormData();
      uploadFormData.append("user_id", selectedCustomer._id);
      if (formData.nominee.name) {
        uploadFormData.append("nominee_name", formData.nominee.name);
      }
      if (formData.nominee.phoneNumber) {
        uploadFormData.append("nominee_phone", formData.nominee.phoneNumber);
      }
      const fileFields = [
        "user_profile_photo",
        "user_adharcard_front_photo",
        "user_adharcard_back_photo",
        "user_pancard_photo",
        "user_cheque_leaf",
        "bank_statement_month",
        "bank_passbook_photo",
        "business_document_proof",
        "user_salary_slip"
      ];
      fileFields.forEach((field) => {
        if (formData[field]) {
          uploadFormData.append(field, formData[field]);
        }
      });
      const nomineeFields = [
        {
          key: "user_nominee_adharcard_front_photo",
          value: formData.nominee.user_nominee_adharcard_front_photo
        },
        {
          key: "user_nominee_adharcard_back_photo",
          value: formData.nominee.user_nominee_adharcard_back_photo
        },
        {
          key: "user_nominee_pancard_photo",
          value: formData.nominee.user_nominee_pancard_photo
        }
      ];
      nomineeFields.forEach((field) => {
        if (field.value) {
          uploadFormData.append(field.key, field.value);
        }
      });
      if (otherDocuments.length > 0) {
        const otherDoc = otherDocuments[0];
        if (otherDoc.name && otherDoc.name.trim()) {
          uploadFormData.append("other_documents_name", otherDoc.name.trim());
        }
        if (otherDoc.file) {
          uploadFormData.append("other_documents_photo", otherDoc.file);
        }
      }
      const response = await api.post(
        "/v1/admin/user-documents",
        uploadFormData,
        {
          headers: {
            "Content-Type": "multipart/form-data"
          }
        }
      );
      if (response.data.success) {
        message.success(existingDocuments ? "Documents updated successfully!" : "Documents uploaded successfully!");
        await fetchUserDocuments(selectedCustomer._id);
        setTimeout(() => {
          setShowUploadModal(false);
          resetForm();
        }, 1500);
      }
    } catch (error) {
      console.error("Error uploading documents:", error);
      message.error(
        error.response?.data?.message || "Failed to upload documents"
      );
    } finally {
      setUploading(false);
    }
  };
  const resetForm = () => {
    Object.values(filePreviews).forEach((preview) => {
      if (preview) URL.revokeObjectURL(preview);
    });
    otherDocuments.forEach((doc) => {
      if (doc.preview) URL.revokeObjectURL(doc.preview);
    });
    Object.values(guarantorPreviews).forEach((preview) => {
      if (preview) URL.revokeObjectURL(preview);
    });
    setFormData({
      user_profile_photo: null,
      user_adharcard_front_photo: null,
      user_adharcard_back_photo: null,
      user_pancard_photo: null,
      user_cheque_leaf: null,
      bank_statement_month: null,
      bank_passbook_photo: null,
      business_document_proof: null,
      user_salary_slip: null,
      nominee: {
        name: existingDocuments?.nominee_name || "",
        phoneNumber: existingDocuments?.nominee_phone || "",
        user_nominee_adharcard_front_photo: null,
        user_nominee_adharcard_back_photo: null,
        user_nominee_pancard_photo: null
      }
    });
    setFilePreviews({
      user_profile_photo: null,
      user_adharcard_front_photo: null,
      user_adharcard_back_photo: null,
      user_pancard_photo: null,
      user_cheque_leaf: null,
      bank_statement_month: null,
      bank_passbook_photo: null,
      business_document_proof: null,
      user_salary_slip: null,
      user_nominee_adharcard_front_photo: null,
      user_nominee_adharcard_back_photo: null,
      user_nominee_pancard_photo: null
    });
    if (existingDocuments?.other_documents_name || existingDocuments?.other_documents_photo) {
      setOtherDocuments(
        [
          {
            id: Date.now().toString(),
            name: existingDocuments.other_documents_name || "",
            file: null,
            preview: null,
            existingUrl: existingDocuments.other_documents_photo || null,
            existingName: existingDocuments.other_documents_name || ""
          }
        ]
      );
    } else {
      setOtherDocuments([]);
    }
    setShowGuarantor(false);
    setGuarantorData({
      name: "",
      phoneNumber: "",
      email: "",
      address: "",
      aadharFront: null,
      panCard: null,
      photo: null
    });
    setGuarantorPreviews({
      aadharFront: null,
      panCard: null,
      photo: null
    });
    setReplacedDocuments({});
  };
  const onGlobalSearchChangeHandler = (e) => {
    setSearchText(e.target.value);
  };
  const getUploadedDocuments = () => {
    if (!existingDocuments) return [];
    const documents = [];
    REQUIRED_DOCUMENTS.forEach((doc) => {
      if (existingDocuments[doc.key]) {
        documents.push({
          key: doc.key,
          label: doc.label,
          url: existingDocuments[doc.key],
          isImage: existingDocuments[doc.key]?.match(
            /\.(jpeg|jpg|gif|png|webp)$/i
          )
        });
      }
    });
    if (existingDocuments.other_documents_photo) {
      documents.push({
        key: "other_documents_photo",
        label: existingDocuments.other_documents_name || "Other Document",
        url: existingDocuments.other_documents_photo,
        isImage: existingDocuments.other_documents_photo?.match(
          /\.(jpeg|jpg|gif|png|webp)$/i
        )
      });
    }
    return documents;
  };
  const uploadedDocuments = getUploadedDocuments();
  if (initializing) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 1079,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
        lineNumber: 1083,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 flex justify-center items-center", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
        lineNumber: 1085,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
        lineNumber: 1084,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
      lineNumber: 1078,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { children: [
    toast.show && /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: `fixed top-20 right-4 z-50 px-4 py-3 rounded-lg shadow-lg ${toast.type === "success" ? "bg-green-500" : "bg-red-500"} text-white animate-slide-in`,
        children: toast.message
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
        lineNumber: 1095,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        open: previewImage !== null,
        title: previewTitle,
        footer: null,
        onCancel: handleCancelPreview,
        width: "auto",
        style: { maxWidth: "90vw" },
        children: /* @__PURE__ */ jsxDEV("img", { alt: previewTitle, style: { width: "100%" }, src: previewImage }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 1113,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
        lineNumber: 1105,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 1117,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
        lineNumber: 1121,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 1124,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold text-gray-900", children: "Customer Document Upload" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1127,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: "Search and select a customer to upload documents" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1130,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 1126,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 1125,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 rounded-3xl border p-8", children: /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-lg text-gray-700 text-center font-semibold mb-4", children: "Select Customer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1140,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center", children: /* @__PURE__ */ jsxDEV(
            Select,
            {
              showSearch: true,
              placeholder: "Search or Select Customer by Name or Phone",
              onChange: handleCustomerSelect,
              loading,
              notFoundContent: loading ? /* @__PURE__ */ jsxDEV(Spin, { size: "small" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1150,
                columnNumber: 31
              }, this) : "No customers found",
              filterOption: (input, option) => {
                const label = option?.label?.toString().toLowerCase() || "";
                return label.includes(input.toLowerCase());
              },
              style: { width: "100%", maxWidth: "600px", height: "50px" },
              size: "large",
              value: selectedCustomer?._id || void 0,
              options: customers.map((customer) => ({
                value: customer._id,
                label: `${customer.name} - ${customer.phone}`
              }))
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1144,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1143,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 1139,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 1138,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 1137,
          columnNumber: 11
        }, this),
        selectedCustomer && /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-200 shadow-sm p-6 mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start flex-wrap gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-blue-600 font-semibold mb-1", children: "Selected Customer:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1177,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-bold text-gray-800", children: selectedCustomer.name }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1180,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-2 space-y-1", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Email:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1185,
                    columnNumber: 25
                  }, this),
                  " ",
                  selectedCustomer.email || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 1184,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Phone:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1188,
                    columnNumber: 25
                  }, this),
                  " ",
                  selectedCustomer.phone || "N/A"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 1187,
                  columnNumber: 23
                }, this),
                selectedCustomer.customer_id && /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Customer ID:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1192,
                    columnNumber: 27
                  }, this),
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-blue-600", children: selectedCustomer.customer_id }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1192,
                    columnNumber: 77
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 1191,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1183,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1176,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: [
              existingDocuments && /* @__PURE__ */ jsxDEV("div", { className: "mb-4 p-3 bg-white rounded-lg shadow-sm min-w-[200px]", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-700", children: "Document Status:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1201,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: `text-sm font-semibold ${documentPercentage === 100 ? "text-green-600" : documentPercentage >= 70 ? "text-yellow-600" : "text-red-600"}`, children: [
                    documentPercentage,
                    "% Complete"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1204,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 1200,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Progress,
                  {
                    percent: documentPercentage,
                    strokeColor: documentPercentage === 100 ? "#52c41a" : documentPercentage >= 70 ? "#faad14" : "#ff4d4f",
                    size: "small"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1212,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2 mt-3", children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => setShowViewModal(true),
                      className: "px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-all duration-300 flex items-center gap-2 text-sm flex-1 justify-center",
                      children: [
                        /* @__PURE__ */ jsxDEV(IoEye, {}, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1223,
                          columnNumber: 29
                        }, this),
                        " View (",
                        uploadedDocuments.length,
                        ")"
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1219,
                      columnNumber: 27
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => setShowUploadModal(true),
                      className: "px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all duration-300 flex items-center gap-2 text-sm flex-1 justify-center",
                      children: existingDocuments ? "Update" : "Upload"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1225,
                      columnNumber: 27
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 1218,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1199,
                columnNumber: 19
              }, this),
              !existingDocuments && /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => setShowUploadModal(true),
                  className: "px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all duration-300 shadow-md hover:shadow-lg font-semibold",
                  children: "Upload Documents"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 1235,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1197,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1175,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1174,
            columnNumber: 15
          }, this),
          loadingDetails ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-8", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1249,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1248,
            columnNumber: 13
          }, this) : fullCustomerDetails ? /* @__PURE__ */ jsxDEV(
            "div",
            {
              id: "customer-profile-print",
              className: "bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden max-w-4xl mx-auto",
              children: [
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "bg-gradient-to-r from-blue-600 to-blue-700 px-4 py-3 cursor-pointer hover:from-blue-700 hover:to-blue-800 transition-colors duration-200",
                    onClick: () => setIsCustomerDetailsOpen(!isCustomerDetailsOpen),
                    children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center backdrop-blur-sm flex-shrink-0", children: /* @__PURE__ */ jsxDEV(
                          "img",
                          {
                            src: companyLogo,
                            alt: "MYCHITS CHIT",
                            className: "w-8 h-8 object-contain",
                            onError: (e) => {
                              e.target.onerror = null;
                              e.target.src = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgdmlld0JveD0iMCAwIDQwIDQwIj48cmVjdCB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIGZpbGw9IiNmZmZmZmYiIG9wYWNpdHk9IjAuMiIgcng9IjYiLz48dGV4dCB4PSI4IiB5PSIyNiIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjE4IiBmaWxsPSIjZmZmZmZmIj5NQzwvdGV4dD48L3N2Zz4=";
                            }
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                            lineNumber: 1266,
                            columnNumber: 27
                          },
                          this
                        ) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1265,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { children: [
                          /* @__PURE__ */ jsxDEV("h3", { className: "text-white font-semibold text-base flex items-center gap-2", children: [
                            /* @__PURE__ */ jsxDEV("span", { children: "MYCHITS CHIT" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                              lineNumber: 1279,
                              columnNumber: 29
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { className: "text-blue-200 text-[10px] font-normal", children: "™" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                              lineNumber: 1280,
                              columnNumber: 29
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                            lineNumber: 1278,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV("p", { className: "text-blue-100 text-xs", children: [
                            fullCustomerDetails.full_name || fullCustomerDetails.name || "Customer",
                            fullCustomerDetails.customer_id && ` • ID: ${fullCustomerDetails.customer_id}`
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                            lineNumber: 1282,
                            columnNumber: 27
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1277,
                          columnNumber: 25
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1263,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 hide-in-print", children: [
                        /* @__PURE__ */ jsxDEV(
                          "button",
                          {
                            className: "text-white hover:bg-white/10 rounded-lg p-1.5 transition-all duration-200",
                            onClick: (e) => {
                              e.stopPropagation();
                              handleDownloadPDF();
                            },
                            title: "Download PDF",
                            children: /* @__PURE__ */ jsxDEV(IoDownload, { className: "w-4 h-4" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                              lineNumber: 1300,
                              columnNumber: 27
                            }, this)
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                            lineNumber: 1292,
                            columnNumber: 25
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          "button",
                          {
                            className: "text-white hover:bg-white/10 rounded-full p-1 transition-all duration-200 ml-1",
                            onClick: (e) => {
                              e.stopPropagation();
                              setIsCustomerDetailsOpen(!isCustomerDetailsOpen);
                            },
                            children: /* @__PURE__ */ jsxDEV(
                              "svg",
                              {
                                className: `w-5 h-5 transition-transform duration-300 ${isCustomerDetailsOpen ? "rotate-180" : ""}`,
                                fill: "none",
                                stroke: "currentColor",
                                viewBox: "0 0 24 24",
                                children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M19 9l-7 7-7-7" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                                  lineNumber: 1317,
                                  columnNumber: 29
                                }, this)
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                                lineNumber: 1311,
                                columnNumber: 27
                              },
                              this
                            )
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                            lineNumber: 1304,
                            columnNumber: 25
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1290,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1261,
                      columnNumber: 21
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1257,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: `transition-all duration-300 overflow-hidden ${isCustomerDetailsOpen ? "max-h-[5000px] opacity-100" : "max-h-0 opacity-0"}`, children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-200", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 px-4 py-2 border-b border-gray-200", children: /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-semibold text-gray-700 flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxDEV(IoPerson, { className: "text-blue-600" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1331,
                        columnNumber: 27
                      }, this),
                      "Personal Information"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1330,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1329,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-x-8 gap-y-2", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Title:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1338,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.title || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1339,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1337,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Full Name:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1342,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800 font-medium", children: fullCustomerDetails.full_name || fullCustomerDetails.name || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1343,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1341,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Father's Name:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1346,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.father_name || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1347,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1345,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Date of Birth:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1350,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: formatDate(fullCustomerDetails.dateofbirth) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1351,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1349,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Gender:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1354,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.gender || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1355,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1353,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Marital Status:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1358,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.marital_status || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1359,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1357,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 col-span-2 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Nationality:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1362,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.nationality || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1363,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1361,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1336,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1335,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1328,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-200", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 px-4 py-2 border-b border-gray-200", children: /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-semibold text-gray-700 flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxDEV(IoCall, { className: "text-green-600" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1373,
                        columnNumber: 27
                      }, this),
                      "Contact Information"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1372,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1371,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-x-8 gap-y-2", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Email:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1380,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-blue-600", children: /* @__PURE__ */ jsxDEV("a", { href: `mailto:${fullCustomerDetails.email}`, className: "hover:underline", children: fullCustomerDetails.email || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1382,
                          columnNumber: 31
                        }, this) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1381,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1379,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Phone:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1388,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.phone_number || fullCustomerDetails.phone || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1389,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1387,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 col-span-2 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Alternate Phone:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1392,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.alternate_number || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1393,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1391,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1378,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1377,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1370,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-200", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 px-4 py-2 border-b border-gray-200", children: /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-semibold text-gray-700 flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxDEV(IoLocation, { className: "text-purple-600" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1403,
                        columnNumber: 27
                      }, this),
                      "Address Details"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1402,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1401,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-x-8 gap-y-2", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50 col-span-2", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Address:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1410,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.address || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1411,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1409,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Village:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1414,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.village || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1415,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1413,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Taluk:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1418,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.taluk || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1419,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1417,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "District:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1422,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.district || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1423,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1421,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "State:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1426,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.state || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1427,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1425,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Pincode:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1430,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.pincode || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1431,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1429,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1408,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1407,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1400,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-200", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 px-4 py-2 border-b border-gray-200", children: /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-semibold text-gray-700 flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxDEV(IoDocumentText, { className: "text-amber-600" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1441,
                        columnNumber: 27
                      }, this),
                      "Identification"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1440,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1439,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-x-8 gap-y-2", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Aadhar Number:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1448,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.adhaar_no || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1449,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1447,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "PAN Number:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1452,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.pan_no || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1453,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1451,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1446,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1445,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1438,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-200", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 px-4 py-2 border-b border-gray-200", children: /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-semibold text-gray-700 flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxDEV(IoWallet, { className: "text-cyan-600" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1463,
                        columnNumber: 27
                      }, this),
                      "Bank Details"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1462,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1461,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-x-8 gap-y-2", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Bank Name:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1470,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.bank_name || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1471,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1469,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Branch:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1474,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.bank_branch_name || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1475,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1473,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Account Number:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1478,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.bank_account_number || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1479,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1477,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "IFSC Code:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1482,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.bank_IFSC_code || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1483,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1481,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1468,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1467,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1460,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-200", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 px-4 py-2 border-b border-gray-200", children: /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-semibold text-gray-700 flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxDEV(IoPerson, { className: "text-rose-600" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1493,
                        columnNumber: 27
                      }, this),
                      "Nominee Information"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1492,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1491,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-x-8 gap-y-2", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Nominee Name:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1500,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.nominee_name || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1501,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1499,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Relationship:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1504,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.nominee_relationship || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1505,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1503,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Phone:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1508,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.nominee_phone_number || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1509,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1507,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Date of Birth:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1512,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: formatDate(fullCustomerDetails.nominee_dateofbirth) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1513,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1511,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1498,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1497,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1490,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 px-4 py-2 border-b border-gray-200", children: /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-semibold text-gray-700 flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxDEV(IoDocumentText, { className: "text-gray-600" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1523,
                        columnNumber: 27
                      }, this),
                      "Additional Information"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1522,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1521,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-x-8 gap-y-2", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Referral Name:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1530,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.referred_employee || fullCustomerDetails.referral_name || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1531,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1529,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Collection Area:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1534,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: typeof fullCustomerDetails.collection_area === "object" ? fullCustomerDetails.collection_area?.route_name : fullCustomerDetails.collection_area || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1535,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1533,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Collection Executive:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1542,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: fullCustomerDetails.collection_executive || "—" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1543,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1541,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Document Progress:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1546,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800 flex items-center gap-2", children: [
                          /* @__PURE__ */ jsxDEV("span", { children: [
                            fullCustomerDetails.percentage || 0,
                            "%"
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                            lineNumber: 1548,
                            columnNumber: 31
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { className: "w-24 bg-gray-200 rounded-full h-1.5", children: /* @__PURE__ */ jsxDEV(
                            "div",
                            {
                              className: `h-1.5 rounded-full transition-all duration-500 ${(fullCustomerDetails.percentage || 0) >= 80 ? "bg-green-500" : (fullCustomerDetails.percentage || 0) >= 50 ? "bg-yellow-500" : "bg-red-500"}`,
                              style: { width: `${fullCustomerDetails.percentage || 0}%` }
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                              lineNumber: 1550,
                              columnNumber: 33
                            },
                            this
                          ) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                            lineNumber: 1549,
                            columnNumber: 31
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1547,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1545,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Status:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1562,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm", children: /* @__PURE__ */ jsxDEV("span", { className: `px-3 py-1 rounded-full text-xs font-medium ${fullCustomerDetails.approval_status === "true" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"}`, children: fullCustomerDetails.approval_status === "true" ? "✅ Verified" : "⏳ Pending" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1564,
                          columnNumber: 31
                        }, this) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1563,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1561,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex py-1.5 border-b border-gray-50", children: [
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-500 w-32 font-medium", children: "Customer Since:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1574,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-800", children: formatDate(fullCustomerDetails.createdAt) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1575,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1573,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1528,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1527,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1520,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 px-6 py-3 border-t border-gray-200 text-center", children: /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: [
                    "Generated on ",
                    (/* @__PURE__ */ new Date()).toLocaleDateString(),
                    " • Customer Profile"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1583,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1582,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 1325,
                  columnNumber: 19
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1252,
              columnNumber: 13
            },
            this
          ) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-8 text-gray-500 bg-white rounded-xl shadow-md border border-gray-200 max-w-4xl mx-auto", children: [
            /* @__PURE__ */ jsxDEV(IoDocumentText, { className: "text-6xl text-gray-300 mx-auto mb-4" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1589,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: "No additional details available for this customer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1590,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm mt-2", children: "Please upload documents to see complete profile" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1591,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1588,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 1172,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-8 bg-gray-50 rounded-lg p-6", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium text-gray-900 mb-3", children: "Instructions:" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1599,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("ul", { className: "list-disc list-inside space-y-2 text-gray-600", children: [
            /* @__PURE__ */ jsxDEV("li", { children: "Search for a customer by typing their name or phone number" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1603,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: "Select the customer from the dropdown" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1604,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: 'Click on "Upload Documents" button to proceed' }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1605,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: "Existing documents will be shown with preview" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1606,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: "Click on any existing document to view it" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1607,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: "Upload new documents to replace existing ones" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1608,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: "Click on the preview image to see larger view" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1609,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: "All fields marked with * are mandatory" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1610,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: "Supported file formats: Images (JPG, PNG) and PDF" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1611,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("li", { children: "Maximum file size: 5MB per file" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1612,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1602,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 1598,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
        lineNumber: 1123,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
      lineNumber: 1116,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        open: showViewModal,
        onCancel: () => setShowViewModal(false),
        footer: null,
        width: 1e3,
        centered: true,
        className: "document-modal",
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pr-6", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-gray-800", children: "Uploaded Documents" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1629,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: [
              "Customer:",
              " ",
              /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700", children: selectedCustomer?.name }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1634,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1632,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1628,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 text-blue-700 px-4 py-2 rounded-xl text-sm font-medium", children: [
            "Total: ",
            uploadedDocuments.length
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1639,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 1627,
          columnNumber: 9
        }, this),
        children: /* @__PURE__ */ jsxDEV("div", { className: "max-h-[75vh] overflow-y-auto pr-1", children: uploadedDocuments.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center py-20", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-24 h-24 rounded-full bg-gray-100 flex items-center justify-center mb-4", children: /* @__PURE__ */ jsxDEV(IoDocument, { className: "text-5xl text-gray-400" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1649,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1648,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-700", children: "No Documents Found" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1651,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm mt-1", children: "No uploaded documents are available for this customer." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1652,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 1647,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5", children: uploadedDocuments.map(
          (doc, index) => /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "group bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300",
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: "relative bg-gray-100 h-52 overflow-hidden", children: doc.isImage ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  /* @__PURE__ */ jsxDEV(
                    "img",
                    {
                      src: doc.url,
                      alt: doc.label,
                      className: "w-full h-full object-cover cursor-pointer group-hover:scale-105 transition-transform duration-300",
                      onClick: () => handlePreview(doc.url, doc.label)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1666,
                      columnNumber: 25
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-all duration-300 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => handlePreview(doc.url, doc.label),
                      className: "opacity-0 group-hover:opacity-100 transition-all duration-300 bg-white text-gray-800 px-4 py-2 rounded-xl flex items-center gap-2 shadow-lg",
                      children: [
                        /* @__PURE__ */ jsxDEV(IoEye, { className: "text-lg" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1677,
                          columnNumber: 29
                        }, this),
                        "View"
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1673,
                      columnNumber: 27
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1672,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 1665,
                  columnNumber: 17
                }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center h-full", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-20 h-20 rounded-2xl bg-red-50 flex items-center justify-center mb-3", children: /* @__PURE__ */ jsxDEV(IoDocument, { className: "text-5xl text-red-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1685,
                    columnNumber: 27
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1684,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 font-medium", children: "PDF Document" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1687,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 1683,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 1663,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 line-clamp-1", children: doc.label }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1694,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1 break-all line-clamp-1", children: doc.url.substring(doc.url.lastIndexOf("/") + 1) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1695,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1693,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV(Tooltip, { title: "Preview Document", children: /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        onClick: () => handlePreview(doc.url, doc.label),
                        className: "w-10 h-10 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-600 flex items-center justify-center transition-all",
                        children: /* @__PURE__ */ jsxDEV(IoEye, { className: "text-lg" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1705,
                          columnNumber: 29
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1701,
                        columnNumber: 27
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1700,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(Tooltip, { title: "Download Document", children: /* @__PURE__ */ jsxDEV(
                      "a",
                      {
                        href: doc.url,
                        download: true,
                        target: "_blank",
                        rel: "noopener noreferrer",
                        className: "w-10 h-10 rounded-xl bg-green-50 hover:bg-green-100 text-green-600 flex items-center justify-center transition-all",
                        children: /* @__PURE__ */ jsxDEV(IoDownload, { className: "text-lg" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                          lineNumber: 1716,
                          columnNumber: 29
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                        lineNumber: 1709,
                        columnNumber: 27
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1708,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1699,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 1692,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 1691,
                  columnNumber: 19
                }, this)
              ]
            },
            index,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1659,
              columnNumber: 13
            },
            this
          )
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 1657,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 1645,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
        lineNumber: 1619,
        columnNumber: 7
      },
      this
    ),
    showUploadModal && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 overflow-y-auto", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg w-full max-w-5xl m-4 max-h-[90vh] overflow-y-auto", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "sticky top-0 bg-white border-b px-6 py-4 flex justify-between items-center", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold", children: "Upload Documents" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1735,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: [
            "Customer:",
            " ",
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: selectedCustomer?.name }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1738,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1736,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-blue-600 mt-1", children: "💡 Tip: Click on any existing document to view it. Upload new files to replace them." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1740,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 1734,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => {
              setShowUploadModal(false);
              resetForm();
            },
            className: "text-gray-500 hover:text-gray-700 text-2xl",
            children: "×"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1744,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
        lineNumber: 1733,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "p-6 space-y-6", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium mb-4 text-gray-900 border-b pb-2", children: "Customer Documents" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1758,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxDEV(
              DocumentUploadField,
              {
                label: "Photo",
                required: true,
                file: formData.user_profile_photo,
                preview: filePreviews.user_profile_photo,
                existingUrl: existingDocumentUrls.user_profile_photo,
                onPreview: handlePreview,
                onChange: (e) => handleFileChange(e, "user_profile_photo"),
                onDelete: () => handleFileRemove("user_profile_photo"),
                formatBytes
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1762,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              DocumentUploadField,
              {
                label: "PAN Card",
                required: true,
                file: formData.user_pancard_photo,
                preview: filePreviews.user_pancard_photo,
                existingUrl: existingDocumentUrls.user_pancard_photo,
                onPreview: handlePreview,
                onChange: (e) => handleFileChange(e, "user_pancard_photo"),
                onDelete: () => handleFileRemove("user_pancard_photo"),
                formatBytes
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1773,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              DocumentUploadField,
              {
                label: "Aadhar Card (Front)",
                required: true,
                file: formData.user_adharcard_front_photo,
                preview: filePreviews.user_adharcard_front_photo,
                existingUrl: existingDocumentUrls.user_adharcard_front_photo,
                onPreview: handlePreview,
                onChange: (e) => handleFileChange(e, "user_adharcard_front_photo"),
                onDelete: () => handleFileRemove("user_adharcard_front_photo"),
                formatBytes
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1784,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              DocumentUploadField,
              {
                label: "Aadhar Card (Back)",
                required: true,
                file: formData.user_adharcard_back_photo,
                preview: filePreviews.user_adharcard_back_photo,
                existingUrl: existingDocumentUrls.user_adharcard_back_photo,
                onPreview: handlePreview,
                onChange: (e) => handleFileChange(e, "user_adharcard_back_photo"),
                onDelete: () => handleFileRemove("user_adharcard_back_photo"),
                formatBytes
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1795,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              DocumentUploadField,
              {
                label: "Bank Passbook Photo",
                required: true,
                file: formData.bank_passbook_photo,
                preview: filePreviews.bank_passbook_photo,
                existingUrl: existingDocumentUrls.bank_passbook_photo,
                onPreview: handlePreview,
                onChange: (e) => handleFileChange(e, "bank_passbook_photo"),
                onDelete: () => handleFileRemove("bank_passbook_photo"),
                formatBytes
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1806,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              DocumentUploadField,
              {
                label: "Bank Statement - Month 1",
                required: true,
                file: formData.bank_statement_month,
                preview: filePreviews.bank_statement_month,
                existingUrl: existingDocumentUrls.bank_statement_month,
                onPreview: handlePreview,
                onChange: (e) => handleFileChange(e, "bank_statement_month"),
                onDelete: () => handleFileRemove("bank_statement_month"),
                formatBytes
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1817,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              DocumentUploadField,
              {
                label: "Cheque Leaf",
                required: true,
                file: formData.user_cheque_leaf,
                preview: filePreviews.user_cheque_leaf,
                existingUrl: existingDocumentUrls.user_cheque_leaf,
                onPreview: handlePreview,
                onChange: (e) => handleFileChange(e, "user_cheque_leaf"),
                onDelete: () => handleFileRemove("user_cheque_leaf"),
                formatBytes
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1828,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              DocumentUploadField,
              {
                label: "Business Proof",
                required: true,
                file: formData.business_document_proof,
                preview: filePreviews.business_document_proof,
                existingUrl: existingDocumentUrls.business_document_proof,
                onPreview: handlePreview,
                onChange: (e) => handleFileChange(e, "business_document_proof"),
                onDelete: () => handleFileRemove("business_document_proof"),
                formatBytes
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1839,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              DocumentUploadField,
              {
                label: "Salary Slip",
                required: true,
                file: formData.user_salary_slip,
                preview: filePreviews.user_salary_slip,
                existingUrl: existingDocumentUrls.user_salary_slip,
                onPreview: handlePreview,
                onChange: (e) => handleFileChange(e, "user_salary_slip"),
                onDelete: () => handleFileRemove("user_salary_slip"),
                formatBytes
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1850,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1761,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 1757,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4 border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium text-gray-900", children: "Other Document (Optional)" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1867,
              columnNumber: 19
            }, this),
            otherDocuments.length === 0 && /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: addOtherDocument,
                className: "px-3 py-1 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors text-sm flex items-center gap-1",
                children: [
                  /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M12 4v16m8-8H4" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1877,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1876,
                    columnNumber: 23
                  }, this),
                  "Add Document"
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1871,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1866,
            columnNumber: 17
          }, this),
          otherDocuments.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-8 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300", children: [
            /* @__PURE__ */ jsxDEV("svg", { className: "w-12 h-12 mx-auto text-gray-400", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1887,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1886,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 mt-2", children: "No other document added" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1889,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: addOtherDocument,
                className: "mt-2 text-blue-600 hover:text-blue-700 text-sm font-medium",
                children: "+ Add a document"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1890,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1885,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: otherDocuments.map(
            (doc) => /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-200 rounded-lg p-4 bg-gray-50", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start mb-3", children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "font-medium text-gray-800", children: "Other Document" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 1903,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => removeOtherDocument(doc.id),
                    className: "text-red-500 hover:text-red-700",
                    children: /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1910,
                      columnNumber: 31
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1909,
                      columnNumber: 29
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1904,
                    columnNumber: 27
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1902,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Document Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1916,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      value: doc.name,
                      onChange: (e) => updateOtherDocumentName(doc.id, e.target.value),
                      className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
                      placeholder: "e.g., Income Tax Return, Property Document, etc."
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                      lineNumber: 1919,
                      columnNumber: 29
                    },
                    this
                  ),
                  doc.existingName && !doc.name && /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-green-600 mt-1", children: [
                    "Currently: ",
                    doc.existingName
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1927,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 1915,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
                  DocumentUploadField,
                  {
                    label: "Document File",
                    file: doc.file,
                    preview: doc.preview,
                    existingUrl: doc.existingUrl,
                    onPreview: handlePreview,
                    onChange: (e) => handleOtherDocumentFileChange(e, doc.id),
                    onDelete: () => removeOtherDocumentFile(doc.id),
                    formatBytes
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 1931,
                    columnNumber: 29
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 1930,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1914,
                columnNumber: 25
              }, this)
            ] }, doc.id, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1901,
              columnNumber: 17
            }, this)
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1899,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 1865,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium mb-4 text-gray-900 border-b pb-2", children: "Nominee Details" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1951,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Nominee Name" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1956,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: formData.nominee.name,
                  onChange: (e) => handleNomineeTextChange(e, "name"),
                  className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
                  placeholder: "Enter nominee name"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 1959,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1955,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Phone Number" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1968,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "tel",
                  value: formData.nominee.phoneNumber,
                  onChange: (e) => handleNomineeTextChange(e, "phoneNumber"),
                  className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
                  placeholder: "Enter phone number"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 1971,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 1967,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              DocumentUploadField,
              {
                label: "Nominee Aadhar (Front)",
                required: true,
                file: formData.nominee.user_nominee_adharcard_front_photo,
                preview: filePreviews.user_nominee_adharcard_front_photo,
                existingUrl: existingDocumentUrls.user_nominee_adharcard_front_photo,
                onPreview: handlePreview,
                onChange: (e) => handleFileChange(e, "nominee_adharcard_front"),
                onDelete: () => handleFileRemove("nominee_adharcard_front"),
                formatBytes
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1979,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              DocumentUploadField,
              {
                label: "Nominee Aadhar (Back)",
                required: true,
                file: formData.nominee.user_nominee_adharcard_back_photo,
                preview: filePreviews.user_nominee_adharcard_back_photo,
                existingUrl: existingDocumentUrls.user_nominee_adharcard_back_photo,
                onPreview: handlePreview,
                onChange: (e) => handleFileChange(e, "nominee_adharcard_back"),
                onDelete: () => handleFileRemove("nominee_adharcard_back"),
                formatBytes
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 1990,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              DocumentUploadField,
              {
                label: "Nominee PAN Card",
                required: true,
                file: formData.nominee.user_nominee_pancard_photo,
                preview: filePreviews.user_nominee_pancard_photo,
                existingUrl: existingDocumentUrls.user_nominee_pancard_photo,
                onPreview: handlePreview,
                onChange: (e) => handleFileChange(e, "nominee_pancard"),
                onDelete: () => handleFileRemove("nominee_pancard"),
                formatBytes
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 2001,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 1954,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 1950,
          columnNumber: 15
        }, this),
        showGuarantor && /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4 border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium text-gray-900", children: "Guarantor Details" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 2019,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setShowGuarantor(false),
                className: "text-red-500 hover:text-red-700 text-sm flex items-center gap-1",
                children: [
                  /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 2026,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 2025,
                    columnNumber: 23
                  }, this),
                  "Remove Guarantor"
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 2020,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 2018,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: [
                "Guarantor Name ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 2034,
                  columnNumber: 40
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 2033,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: guarantorData.name,
                  onChange: (e) => setGuarantorData({ ...guarantorData, name: e.target.value }),
                  className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
                  placeholder: "Enter guarantor name"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 2036,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 2032,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: [
                "Phone Number ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 2046,
                  columnNumber: 38
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 2045,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "tel",
                  value: guarantorData.phoneNumber,
                  onChange: (e) => setGuarantorData({ ...guarantorData, phoneNumber: e.target.value }),
                  className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
                  placeholder: "Enter phone number"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 2048,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 2044,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Email (Optional)" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 2057,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "email",
                  value: guarantorData.email,
                  onChange: (e) => setGuarantorData({ ...guarantorData, email: e.target.value }),
                  className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
                  placeholder: "Enter email address"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 2060,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 2056,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Address (Optional)" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 2069,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: guarantorData.address,
                  onChange: (e) => setGuarantorData({ ...guarantorData, address: e.target.value }),
                  className: "w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",
                  placeholder: "Enter address"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 2072,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 2068,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              DocumentUploadField,
              {
                label: "Guarantor Aadhar Card",
                file: guarantorData.aadharFront,
                preview: guarantorPreviews.aadharFront,
                existingUrl: existingGuarantorUrls?.aadharFront,
                onPreview: handlePreview,
                onChange: (e) => handleGuarantorFileChange(e, "aadharFront"),
                onDelete: () => handleGuarantorFileRemove("aadharFront"),
                formatBytes
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 2080,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              DocumentUploadField,
              {
                label: "Guarantor PAN Card",
                file: guarantorData.panCard,
                preview: guarantorPreviews.panCard,
                existingUrl: existingGuarantorUrls?.panCard,
                onPreview: handlePreview,
                onChange: (e) => handleGuarantorFileChange(e, "panCard"),
                onDelete: () => handleGuarantorFileRemove("panCard"),
                formatBytes
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 2090,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              DocumentUploadField,
              {
                label: "Guarantor Photo",
                file: guarantorData.photo,
                preview: guarantorPreviews.photo,
                existingUrl: existingGuarantorUrls?.photo,
                onPreview: handlePreview,
                onChange: (e) => handleGuarantorFileChange(e, "photo"),
                onDelete: () => handleGuarantorFileRemove("photo"),
                formatBytes
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 2100,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 2031,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 2017,
          columnNumber: 13
        }, this),
        !showGuarantor && /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "button",
            onClick: () => setShowGuarantor(true),
            className: "px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors flex items-center gap-2",
            children: [
              /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 2123,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 2122,
                columnNumber: 21
              }, this),
              "+ Add Guarantor"
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
            lineNumber: 2117,
            columnNumber: 19
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 2116,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "sticky bottom-0 bg-white border-t pt-4 flex justify-end space-x-3", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: () => {
                setShowUploadModal(false);
                resetForm();
              },
              className: "px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 transition-colors",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 2132,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              disabled: uploading,
              className: "px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors",
              children: uploading ? /* @__PURE__ */ jsxDEV("span", { className: "flex items-center", children: [
                /* @__PURE__ */ jsxDEV("svg", { className: "animate-spin -ml-1 mr-2 h-4 w-4 text-white", fill: "none", viewBox: "0 0 24 24", children: [
                  /* @__PURE__ */ jsxDEV("circle", { className: "opacity-25", cx: "12", cy: "12", r: "10", stroke: "currentColor", strokeWidth: "4" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 2150,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("path", { className: "opacity-75", fill: "currentColor", d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                    lineNumber: 2151,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                  lineNumber: 2149,
                  columnNumber: 23
                }, this),
                "Uploading..."
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
                lineNumber: 2148,
                columnNumber: 17
              }, this) : "Upload Documents"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
              lineNumber: 2142,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
          lineNumber: 2131,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
        lineNumber: 1755,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
      lineNumber: 1732,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
      lineNumber: 1731,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx",
    lineNumber: 1092,
    columnNumber: 5
  }, this);
}
_s(CustomerDocuments, "jsmj1snYhlb4g6b+XRvWIX14Z4o=", false, function() {
  return [useNavigate, useLocation];
});
_c3 = CustomerDocuments;
export default CustomerDocuments;
var _c, _c2, _c3;
$RefreshReg$(_c, "InfoItem");
$RefreshReg$(_c2, "DocumentUploadField");
$RefreshReg$(_c3, "CustomerDocuments");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerDocuments.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUVlLFNBdUVELFVBdkVDOzJCQW5FZjtBQUFnQkEsTUFBUSxjQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3ZDLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxRQUFRQyxNQUFNQyxPQUFPQyxVQUFVQyxPQUFPQyxTQUFTQyxlQUFlO0FBQ3ZFLFNBQVNDLGFBQWFDLG1CQUFtQjtBQUN6QyxPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxXQUFXO0FBQ2xCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLE9BQU9DLGdCQUFnQjtBQUl2QixNQUFNQyxxQkFBcUI7QUFBQSxFQUN6QixFQUFFQyxLQUFLLHNCQUFzQkMsT0FBTyxRQUFRO0FBQUEsRUFDNUMsRUFBRUQsS0FBSyw4QkFBOEJDLE9BQU8sc0JBQXNCO0FBQUEsRUFDbEUsRUFBRUQsS0FBSyw2QkFBNkJDLE9BQU8scUJBQXFCO0FBQUEsRUFDaEUsRUFBRUQsS0FBSyxzQkFBc0JDLE9BQU8sV0FBVztBQUFBLEVBQy9DLEVBQUVELEtBQUssb0JBQW9CQyxPQUFPLGNBQWM7QUFBQSxFQUNoRCxFQUFFRCxLQUFLLHdCQUF3QkMsT0FBTywyQkFBMkI7QUFBQSxFQUNqRSxFQUFFRCxLQUFLLHVCQUF1QkMsT0FBTyxpQkFBaUI7QUFBQSxFQUN0RCxFQUFFRCxLQUFLLDJCQUEyQkMsT0FBTyxpQkFBaUI7QUFBQSxFQUMxRCxFQUFFRCxLQUFLLG9CQUFvQkMsT0FBTyxjQUFjO0FBQUEsRUFDaEQ7QUFBQSxJQUNFRCxLQUFLO0FBQUEsSUFDTEMsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLEVBQUVELEtBQUsscUNBQXFDQyxPQUFPLHdCQUF3QjtBQUFBLEVBQzNFLEVBQUVELEtBQUssOEJBQThCQyxPQUFPLG1CQUFtQjtBQUFDO0FBR2xFLE1BQU1DLGlDQUFpQ0EsQ0FBQ0MsWUFBWTtBQUNsRCxNQUFJLENBQUNBLFFBQVMsUUFBTztBQUNyQixNQUFJQyxnQkFBZ0I7QUFDcEJMLHFCQUFtQk0sUUFBUSxDQUFDQyxRQUFRO0FBQ2xDLFFBQUlILFFBQVFHLElBQUlOLEdBQUcsR0FBRztBQUNwQkk7QUFBQUEsSUFDRjtBQUFBLEVBQ0YsQ0FBQztBQUNELFFBQU1HLGFBQWNILGdCQUFnQkwsbUJBQW1CUyxTQUFVO0FBQ2pFLFNBQU9DLEtBQUtDLE1BQU1ILFVBQVU7QUFDOUI7QUFFQSxNQUFNSSxXQUFXQSxDQUFDLEVBQUVWLE9BQU9XLE9BQU9DLFlBQVksT0FBT0MsTUFBTUMsS0FBSyxNQUM5RCx1QkFBQyxTQUFJLFdBQVcsR0FBR0YsWUFBWSxrQkFBa0IsRUFBRSxrRUFDakQ7QUFBQSx5QkFBQyxTQUFJLFdBQVUsMkJBQ1pFO0FBQUFBLFlBQVEsdUJBQUMsUUFBSyxXQUFVLDJCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVDO0FBQUEsSUFDaEQsdUJBQUMsT0FBRSxXQUFVLDhEQUE4RGQsbUJBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUY7QUFBQSxPQUZuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBR0E7QUFBQSxFQUNBLHVCQUFDLE9BQUUsV0FBVSxzREFDVlcsbUJBQVNBLFVBQVUsU0FBU0EsVUFBVSxlQUFlQSxVQUFVLFNBQVNBLFFBQVEsU0FEbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBQUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BUUE7QUFHRkksS0FaTUw7QUFhTixNQUFNTSxhQUFhQSxDQUFDQyxlQUFlO0FBQ2pDLE1BQUksQ0FBQ0EsV0FBWSxRQUFPO0FBQ3hCLE1BQUk7QUFDRixVQUFNQyxPQUFPLElBQUlDLEtBQUtGLFVBQVU7QUFDaEMsV0FBT0MsS0FBS0UsbUJBQW1CLFNBQVM7QUFBQSxNQUN0Q0MsS0FBSztBQUFBLE1BQ0xDLE9BQU87QUFBQSxNQUNQQyxNQUFNO0FBQUEsSUFDUixDQUFDO0FBQUEsRUFDSCxRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUdBLE1BQU1DLHNCQUFzQkEsQ0FBQztBQUFBLEVBQzNCeEI7QUFBQUEsRUFDQXlCO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFBTTtBQUNKLFFBQU1DLFVBQVUsUUFBUWpDLE1BQU1rQyxRQUFRLE9BQU8sR0FBRyxDQUFDLElBQUkxQixLQUFLMkIsT0FBTyxFQUFFQyxTQUFTLEVBQUUsRUFBRUMsT0FBTyxHQUFHLENBQUMsQ0FBQztBQUM1RixRQUFNQyxVQUFVWCxRQUFRQSxLQUFLWSxNQUFNQyxXQUFXLFFBQVE7QUFDdEQsUUFBTUMsaUJBQWlCWixlQUFlLENBQUNGO0FBQ3ZDLFFBQU1lLGtCQUNKRCxrQkFBa0JaLGFBQWFjLE1BQU0sNkJBQTZCO0FBRXBFLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLG9GQUNiO0FBQUEsMkJBQUMsV0FBTSxXQUFVLGdEQUNkM0M7QUFBQUE7QUFBQUEsTUFBTTtBQUFBLE1BQUV5QixZQUFZLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnQztBQUFBLFNBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUMsQ0FBQ0UsUUFBUSxDQUFDYyxpQkFDVCx1QkFBQyxTQUFJLFdBQVUsa0pBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsUUFBTztBQUFBLFVBQ1A7QUFBQSxVQUNBLFdBQVU7QUFBQSxVQUNWLElBQUlSO0FBQUFBO0FBQUFBLFFBTE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS2M7QUFBQSxNQUVkO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTQTtBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUFzRTtBQUFBO0FBQUEsUUFGbEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0E7QUFBQSxNQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIseUNBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsbUZBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsNENBQ1pOLGlCQUNDLG1DQUNHVztBQUFBQSxtQkFBV1YsVUFDVjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsS0FBS0E7QUFBQUEsWUFDTCxLQUFLNUI7QUFBQUEsWUFDTCxXQUFVO0FBQUEsWUFDVixTQUFTLE1BQU04QixVQUFVRixTQUFTNUIsS0FBSztBQUFBO0FBQUEsVUFKekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSTJDLElBRzNDLHVCQUFDLFNBQUksV0FBVSxxRkFDYixpQ0FBQyxjQUFXLFdBQVUsY0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQyxLQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVGLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixPQUFPMkIsS0FBS2lCO0FBQUFBLGNBRVhqQixlQUFLaUI7QUFBQUE7QUFBQUEsWUFKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLHlCQUNWWixzQkFBWUwsS0FBS2tCLElBQUksS0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLCtCQUE4QixnREFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsV0ExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJCQSxJQUVBLG1DQUNHSDtBQUFBQSwwQkFDQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsS0FBS2I7QUFBQUEsWUFDTCxLQUFLN0I7QUFBQUEsWUFDTCxXQUFVO0FBQUEsWUFDVixTQUFTLE1BQU04QixVQUFVRCxhQUFhN0IsS0FBSztBQUFBO0FBQUEsVUFKN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSStDLElBRy9DLHVCQUFDLFNBQUksV0FBVSxxRkFDYixpQ0FBQyxjQUFXLFdBQVUsY0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQyxLQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVGLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLGlDQUFDLE9BQUUsV0FBVSwrQ0FBOEMsa0NBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSx5QkFBd0IsNENBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTLE1BQU04QixVQUFVRCxhQUFhN0IsS0FBSztBQUFBLGNBQzNDLFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsU0FBTSxXQUFVLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBCO0FBQUEsZ0JBQUc7QUFBQTtBQUFBO0FBQUEsWUFML0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxhQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFdBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2QkEsS0E1REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThEQTtBQUFBLE1BRUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQVMrQjtBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUNWLE9BQ0VKLE9BQ0ksZ0JBQ0E7QUFBQSxVQUdOLGlDQUFDLFdBQVEsV0FBVSxhQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QjtBQUFBO0FBQUEsUUFWOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BV0E7QUFBQSxTQTVFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkVBO0FBQUEsT0F0R0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdHQTtBQUVKO0FBQUVtQixNQTVISXRCO0FBOEhOLFNBQVN1QixvQkFBb0I7QUFBQUMsS0FBQTtBQUMzQixRQUFNQyxXQUFXOUUsWUFBWTtBQUM3QixRQUFNK0UsV0FBVzlFLFlBQVk7QUFDN0IsUUFBTSxDQUFDK0UsWUFBWUMsYUFBYSxJQUFJMUYsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQzJGLFdBQVdDLFlBQVksSUFBSTVGLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUM2RixTQUFTQyxVQUFVLElBQUk5RixTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDK0Ysa0JBQWtCQyxtQkFBbUIsSUFBSWhHLFNBQVMsSUFBSTtBQUM3RCxRQUFNLENBQUNpRyxpQkFBaUJDLGtCQUFrQixJQUFJbEcsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ21HLGVBQWVDLGdCQUFnQixJQUFJcEcsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQ3FHLFdBQVdDLFlBQVksSUFBSXRHLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUN1RyxPQUFPQyxRQUFRLElBQUl4RyxTQUFTLEVBQUV5RyxNQUFNLE9BQU9qRyxTQUFTLElBQUlxRSxNQUFNLEdBQUcsQ0FBQztBQUN6RSxRQUFNLENBQUM2QixjQUFjQyxlQUFlLElBQUkzRyxTQUFTLElBQUk7QUFDckQsUUFBTSxDQUFDNEcsY0FBY0MsZUFBZSxJQUFJN0csU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQzhHLGNBQWNDLGVBQWUsSUFBSS9HLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUNnSCxtQkFBbUJDLG9CQUFvQixJQUFJakgsU0FBUyxJQUFJO0FBQy9ELFFBQU0sQ0FBQ2tILG1CQUFtQkMsb0JBQW9CLElBQUluSCxTQUFTLEtBQUs7QUFDaEUsUUFBTSxDQUFDb0gsZ0JBQWdCQyxpQkFBaUIsSUFBSXJILFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNzSCxlQUFlQyxnQkFBZ0IsSUFBSXZILFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUN3SCxlQUFlQyxnQkFBZ0IsSUFBSXpILFNBQVM7QUFBQSxJQUNqRGtGLE1BQU07QUFBQSxJQUNOd0MsYUFBYTtBQUFBLElBQ2JDLE9BQU87QUFBQSxJQUNQQyxTQUFTO0FBQUEsSUFDVEMsYUFBYTtBQUFBLElBQ2JDLFNBQVM7QUFBQSxJQUNUQyxPQUFPO0FBQUEsRUFDVCxDQUFDO0FBQ0QsUUFBTSxDQUFDQyxtQkFBbUJDLG9CQUFvQixJQUFJakksU0FBUztBQUFBLElBQ3pENkgsYUFBYTtBQUFBLElBQ2JDLFNBQVM7QUFBQSxJQUNUQyxPQUFPO0FBQUEsRUFDVCxDQUFDO0FBQ0QsUUFBTSxDQUFDRyx1QkFBdUJDLHdCQUF3QixJQUFJbkksU0FBUyxJQUFJO0FBQ3ZFLFFBQU0sQ0FBQ29JLHFCQUFxQkMsc0JBQXNCLElBQUlySSxTQUFTLElBQUk7QUFDbkUsUUFBTSxDQUFDc0ksZ0JBQWdCQyxpQkFBaUIsSUFBSXZJLFNBQVMsS0FBSztBQUMxRCxRQUFNLENBQUN3SSx1QkFBdUJDLHdCQUF3QixJQUFJekksU0FBUyxJQUFJO0FBQ3ZFLFFBQU0sQ0FBQzBJLG1CQUFtQkMsb0JBQW9CLElBQUkzSSxTQUFTLENBQUMsQ0FBQztBQUU3RCxRQUFNLENBQUM0SSxVQUFVQyxXQUFXLElBQUk3SSxTQUFTO0FBQUEsSUFDdkM4SSxvQkFBb0I7QUFBQSxJQUNwQkMsNEJBQTRCO0FBQUEsSUFDNUJDLDJCQUEyQjtBQUFBLElBQzNCQyxvQkFBb0I7QUFBQSxJQUNwQkMsa0JBQWtCO0FBQUEsSUFDbEJDLHNCQUFzQjtBQUFBLElBQ3RCQyxxQkFBcUI7QUFBQSxJQUNyQkMseUJBQXlCO0FBQUEsSUFDekJDLGtCQUFrQjtBQUFBLElBQ2xCQyxTQUFTO0FBQUEsTUFDUHJFLE1BQU07QUFBQSxNQUNOd0MsYUFBYTtBQUFBLE1BQ2I4QixvQ0FBb0M7QUFBQSxNQUNwQ0MsbUNBQW1DO0FBQUEsTUFDbkNDLDRCQUE0QjtBQUFBLElBQzlCO0FBQUEsRUFDRixDQUFDO0FBRUQsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUk1SixTQUFTO0FBQUEsSUFDL0M4SSxvQkFBb0I7QUFBQSxJQUNwQkMsNEJBQTRCO0FBQUEsSUFDNUJDLDJCQUEyQjtBQUFBLElBQzNCQyxvQkFBb0I7QUFBQSxJQUNwQkMsa0JBQWtCO0FBQUEsSUFDbEJDLHNCQUFzQjtBQUFBLElBQ3RCQyxxQkFBcUI7QUFBQSxJQUNyQkMseUJBQXlCO0FBQUEsSUFDekJDLGtCQUFrQjtBQUFBLElBQ2xCRSxvQ0FBb0M7QUFBQSxJQUNwQ0MsbUNBQW1DO0FBQUEsSUFDbkNDLDRCQUE0QjtBQUFBLEVBQzlCLENBQUM7QUFFRCxRQUFNLENBQUNHLHNCQUFzQkMsdUJBQXVCLElBQUk5SixTQUFTO0FBQUEsSUFDL0Q4SSxvQkFBb0I7QUFBQSxJQUNwQkMsNEJBQTRCO0FBQUEsSUFDNUJDLDJCQUEyQjtBQUFBLElBQzNCQyxvQkFBb0I7QUFBQSxJQUNwQkMsa0JBQWtCO0FBQUEsSUFDbEJDLHNCQUFzQjtBQUFBLElBQ3RCQyxxQkFBcUI7QUFBQSxJQUNyQkMseUJBQXlCO0FBQUEsSUFDekJDLGtCQUFrQjtBQUFBLElBQ2xCRSxvQ0FBb0M7QUFBQSxJQUNwQ0MsbUNBQW1DO0FBQUEsSUFDbkNDLDRCQUE0QjtBQUFBLEVBQzlCLENBQUM7QUFFRCxRQUFNcEYsY0FBY0EsQ0FBQ3lGLE9BQU9DLFdBQVcsTUFBTTtBQUMzQyxRQUFJLENBQUMsQ0FBQ0QsTUFBTyxRQUFPO0FBQ3BCLFVBQU1FLElBQUk7QUFDVixVQUFNQyxLQUFLRixXQUFXLElBQUksSUFBSUE7QUFDOUIsVUFBTUcsUUFBUSxDQUFDLFNBQVMsTUFBTSxNQUFNLElBQUk7QUFDeEMsVUFBTUMsSUFBSXRILEtBQUt1SCxNQUFNdkgsS0FBS3dILElBQUlQLEtBQUssSUFBSWpILEtBQUt3SCxJQUFJTCxDQUFDLENBQUM7QUFDbEQsV0FBTyxHQUFHTSxZQUFZUixRQUFRakgsS0FBSzBILElBQUlQLEdBQUdHLENBQUMsR0FBR0ssUUFBUVAsRUFBRSxDQUFDLENBQUMsSUFBSUMsTUFBTUMsQ0FBQyxDQUFDO0FBQUEsRUFDeEU7QUFFQSxRQUFNTSxZQUFZQSxDQUFDbEssVUFBU3FFLE9BQU8sY0FBYztBQUMvQzJCLGFBQVMsRUFBRUMsTUFBTSxNQUFNakcsbUJBQVNxRSxLQUFLLENBQUM7QUFDdEM4RixlQUFXLE1BQU07QUFDZm5FLGVBQVMsRUFBRUMsTUFBTSxPQUFPakcsU0FBUyxJQUFJcUUsTUFBTSxHQUFHLENBQUM7QUFBQSxJQUNqRCxHQUFHLEdBQUk7QUFBQSxFQUNUO0FBR0YsUUFBTStGLG9CQUFvQixZQUFZO0FBQ3BDLFVBQU1DLFVBQVVDLFNBQVNDLGVBQWUsd0JBQXdCO0FBQ2hFLFFBQUksQ0FBQ0YsU0FBUztBQUNackssY0FBUXdLLE1BQU0sK0JBQStCO0FBQzdDO0FBQUEsSUFDRjtBQUVBLFVBQU1DLFVBQVV6SyxRQUFRcUYsUUFBUSxxQkFBcUIsQ0FBQztBQUV0RCxRQUFJO0FBRUYsWUFBTXFGLFFBQVFMLFFBQVFNLFVBQVUsSUFBSTtBQUdwQyxZQUFNQyxnQkFBZ0JGLE1BQU1HLGlCQUFpQixnQkFBZ0I7QUFDN0RELG9CQUFjMUksUUFBUSxDQUFBNEksUUFBT0EsSUFBSUMsT0FBTyxDQUFDO0FBR3pDLFlBQU1DLFdBQVdOLE1BQU1HLGlCQUFpQiw2QkFBNkI7QUFDckVHLGVBQVM5SSxRQUFRLENBQUErSSxZQUFXO0FBQzFCQSxnQkFBUUMsTUFBTUMsa0JBQWtCO0FBQ2hDRixnQkFBUUMsTUFBTUUsY0FBYztBQUFBLE1BQzlCLENBQUM7QUFHRCxZQUFNQyxnQkFBZ0JmLFNBQVNnQixjQUFjLEtBQUs7QUFDbERELG9CQUFjSCxNQUFNSyxXQUFXO0FBQy9CRixvQkFBY0gsTUFBTU0sT0FBTztBQUMzQkgsb0JBQWNILE1BQU1PLE1BQU07QUFDMUJKLG9CQUFjSCxNQUFNUSxRQUFRO0FBQzVCTCxvQkFBY0gsTUFBTVMsYUFBYTtBQUNqQ04sb0JBQWNILE1BQU1VLFVBQVU7QUFDOUJQLG9CQUFjSCxNQUFNVyxTQUFTO0FBRzdCUixvQkFBY1MsWUFBWXBCLEtBQUs7QUFDL0JKLGVBQVN5QixLQUFLRCxZQUFZVCxhQUFhO0FBR3ZDLFlBQU0sSUFBSVcsUUFBUSxDQUFBQyxZQUFXOUIsV0FBVzhCLFNBQVMsR0FBSSxDQUFDO0FBR3RELFlBQU1DLFNBQVMsTUFBTTFMLFlBQVk2SyxlQUFlO0FBQUEsUUFDOUNjLE9BQU87QUFBQSxRQUNQQyxTQUFTO0FBQUEsUUFDVEMsWUFBWTtBQUFBLFFBQ1pDLGlCQUFpQjtBQUFBLFFBQ2pCQyxTQUFTO0FBQUEsUUFDVGIsT0FBTztBQUFBLFFBQ1BjLFFBQVFuQixjQUFjb0I7QUFBQUEsUUFDdEJDLFNBQVMsU0FBU3ZLLEtBQUs7QUFDckIsZ0JBQU13SyxTQUFTeEssSUFBSTBJLGlCQUFpQixLQUFLO0FBQ3pDLGlCQUFPbUIsUUFBUVksSUFBSUMsTUFBTUMsS0FBS0gsTUFBTSxFQUFFSSxJQUFJLENBQUFDLFFBQU87QUFDL0MsZ0JBQUlBLElBQUlDLFNBQVU7QUFDbEIsbUJBQU8sSUFBSWpCLFFBQVEsQ0FBQUMsWUFBVztBQUM1QmUsa0JBQUlFLFNBQVNqQjtBQUNiZSxrQkFBSUcsVUFBVWxCO0FBQUFBLFlBQ2hCLENBQUM7QUFBQSxVQUNILENBQUMsQ0FBQztBQUFBLFFBQ0o7QUFBQSxNQUNGLENBQUM7QUFHRDNCLGVBQVN5QixLQUFLcUIsWUFBWS9CLGFBQWE7QUFHdkMsWUFBTWdDLFVBQVVuQixPQUFPb0IsVUFBVSxXQUFXO0FBQzVDLFlBQU1DLE1BQU0sSUFBSTlNLE1BQU07QUFBQSxRQUNwQitNLGFBQWE7QUFBQSxRQUNiQyxNQUFNO0FBQUEsUUFDTkMsUUFBUTtBQUFBLE1BQ1YsQ0FBQztBQUVELFlBQU1DLFdBQVdKLElBQUlLLFNBQVNDLFNBQVNDLFNBQVM7QUFDaEQsWUFBTUMsWUFBYTdCLE9BQU9NLFNBQVNtQixXQUFZekIsT0FBT1I7QUFDdEQsWUFBTXNDLGFBQWFULElBQUlLLFNBQVNDLFNBQVNJLFVBQVU7QUFHbkQsWUFBTUMsYUFBYTVMLEtBQUs2TCxLQUFLSixZQUFZQyxVQUFVO0FBR25ELGVBQVNwRSxJQUFJLEdBQUdBLElBQUlzRSxZQUFZdEUsS0FBSztBQUNuQyxZQUFJQSxJQUFJLEdBQUc7QUFDVDJELGNBQUlhLFFBQVE7QUFBQSxRQUNkO0FBR0EsY0FBTUMsVUFBVSxDQUFDekUsSUFBSW9FO0FBR3JCVCxZQUFJZSxTQUFTakIsU0FBUyxPQUFPLEdBQUdnQixTQUFTVixVQUFVSSxTQUFTO0FBQUEsTUFDOUQ7QUFHQSxZQUFNUSxXQUFXLG9CQUFvQjNHLHFCQUFxQjRHLGVBQWUsU0FBUyxLQUFJLG9CQUFJdkwsS0FBSyxHQUFFd0wsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDNUhuQixVQUFJb0IsS0FBS0osUUFBUTtBQUVqQnZPLGNBQVE0TyxRQUFRO0FBQ2hCNU8sY0FBUTZPLFFBQVEsOEJBQThCO0FBQUEsSUFDaEQsU0FBU3JFLE9BQU87QUFDZHNFLGNBQVF0RSxNQUFNLHlCQUF5QkEsS0FBSztBQUM1Q3hLLGNBQVE0TyxRQUFRO0FBQ2hCNU8sY0FBUXdLLE1BQU0sMkNBQTJDO0FBQUEsSUFDM0Q7QUFBQSxFQUNGO0FBRUUsUUFBTXVFLHFCQUFxQixPQUFPQyxXQUFXO0FBQzNDckkseUJBQXFCLElBQUk7QUFDekIsUUFBSTtBQUNGLFlBQU1zSSxXQUFXLE1BQU0zTyxJQUFJNE8sSUFBSSw0QkFBNEJGLE1BQU0sRUFBRTtBQUNuRSxVQUFJQyxTQUFTRSxRQUFRRixTQUFTRSxLQUFLQSxNQUFNO0FBQ3ZDLFlBQUlDLGdCQUFnQkgsU0FBU0UsS0FBS0E7QUFDbEMsWUFBSXRDLE1BQU13QyxRQUFRRCxhQUFhLEtBQUtBLGNBQWMvTSxTQUFTLEdBQUc7QUFDNUQrTSwwQkFBZ0JBLGNBQWMsQ0FBQztBQUFBLFFBQ2pDO0FBQ0EzSSw2QkFBcUIySSxhQUFhO0FBQ2xDdkgsK0JBQXVCdUgsYUFBYTtBQUVwQyxjQUFNRSxlQUFlLENBQUM7QUFDdEIxTiwyQkFBbUJNLFFBQVEsQ0FBQ0MsUUFBUTtBQUNsQyxjQUFJaU4sY0FBY2pOLElBQUlOLEdBQUcsR0FBRztBQUMxQnlOLHlCQUFhbk4sSUFBSU4sR0FBRyxJQUFJdU4sY0FBY2pOLElBQUlOLEdBQUc7QUFBQSxVQUMvQztBQUFBLFFBQ0YsQ0FBQztBQUNEeUgsZ0NBQXdCZ0csWUFBWTtBQUVwQyxZQUNFRixjQUFjRyx3QkFDZEgsY0FBY0ksdUJBQ2Q7QUFDQTNJO0FBQUFBLFlBQWtCO0FBQUEsY0FDaEI7QUFBQSxnQkFDRTRJLElBQUl4TSxLQUFLeU0sSUFBSSxFQUFFeEwsU0FBUztBQUFBLGdCQUN4QlEsTUFBTTBLLGNBQWNHLHdCQUF3QjtBQUFBLGdCQUM1QzlMLE1BQU07QUFBQSxnQkFDTkMsU0FBUztBQUFBLGdCQUNUQyxhQUFheUwsY0FBY0kseUJBQXlCO0FBQUEsZ0JBQ3BERyxjQUFjUCxjQUFjRyx3QkFBd0I7QUFBQSxjQUN0RDtBQUFBLFlBQUM7QUFBQSxVQUNGO0FBQUEsUUFDSCxPQUFPO0FBQ0wxSSw0QkFBa0IsRUFBRTtBQUFBLFFBQ3RCO0FBRUEsWUFBSXVJLGNBQWNRLGNBQWM7QUFDOUJ2SCxzQkFBWSxDQUFDd0gsVUFBVTtBQUFBLFlBQ3JCLEdBQUdBO0FBQUFBLFlBQ0g5RyxTQUFTO0FBQUEsY0FDUCxHQUFHOEcsS0FBSzlHO0FBQUFBLGNBQ1JyRSxNQUFNMEssY0FBY1EsZ0JBQWdCO0FBQUEsY0FDcEMxSSxhQUFha0ksY0FBY1UsaUJBQWlCO0FBQUEsWUFDOUM7QUFBQSxVQUNGLEVBQUU7QUFBQSxRQUNKO0FBRUEsZUFBT1Y7QUFBQUEsTUFDVCxPQUFPO0FBQ0wzSSw2QkFBcUIsSUFBSTtBQUN6Qm9CLCtCQUF1QixJQUFJO0FBQzNCLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRixTQUFTMkMsT0FBTztBQUNkc0UsY0FBUXRFLE1BQU0sc0NBQXNDQSxLQUFLO0FBQ3pEL0QsMkJBQXFCLElBQUk7QUFDekJvQiw2QkFBdUIsSUFBSTtBQUMzQixhQUFPO0FBQUEsSUFDVCxVQUFDO0FBQ0NsQiwyQkFBcUIsS0FBSztBQUFBLElBQzVCO0FBQUEsRUFDRjtBQUVBLFFBQU1vSixpQkFBaUIsWUFBWTtBQUNqQ3pLLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDRixZQUFNMkosV0FBVyxNQUFNM08sSUFBSTRPLElBQUksZ0JBQWdCO0FBQy9DLFVBQUljLFdBQVc7QUFDZixVQUFJZixTQUFTRSxLQUFLYyxPQUFPO0FBQ3ZCRCxtQkFBV2YsU0FBU0UsS0FBS2M7QUFBQUEsTUFDM0IsV0FBV2hCLFNBQVNFLEtBQUtBLE1BQU07QUFDN0JhLG1CQUFXZixTQUFTRSxLQUFLQTtBQUFBQSxNQUMzQixXQUFXdEMsTUFBTXdDLFFBQVFKLFNBQVNFLElBQUksR0FBRztBQUN2Q2EsbUJBQVdmLFNBQVNFO0FBQUFBLE1BQ3RCLE9BQU87QUFDTGEsbUJBQVc7QUFBQSxNQUNiO0FBRUEsWUFBTUUscUJBQXFCRixTQUFTakQsSUFBSSxDQUFDb0QsVUFBVTtBQUFBLFFBQ2pEQyxLQUFLRCxLQUFLQztBQUFBQSxRQUNWMUwsTUFBTXlMLEtBQUtFLGFBQWFGLEtBQUt6TCxRQUFRO0FBQUEsUUFDckN5QyxPQUFPZ0osS0FBS2hKLFNBQVM7QUFBQSxRQUNyQm1KLE9BQU9ILEtBQUtJLGdCQUFnQkosS0FBS0csU0FBUztBQUFBLFFBQzFDOUIsYUFBYTJCLEtBQUszQixlQUFlO0FBQUEsUUFDakNwSCxTQUFRK0ksS0FBSy9JLFdBQVc7QUFBQSxRQUN4Qm9KLFNBQVFMLEtBQUtLLFdBQVc7QUFBQSxRQUN4QkMsV0FBVU4sS0FBS00sYUFBYTtBQUFBLFFBQzVCQyxRQUFPUCxLQUFLTyxVQUFVO0FBQUEsUUFDdEJDLGlCQUFnQlIsS0FBS1EsbUJBQW1CO0FBQUEsUUFDeENDLGNBQWFULEtBQUtTLGdCQUFnQjtBQUFBLFFBQ2xDQyxlQUFjVixLQUFLVSxpQkFBaUI7QUFBQSxRQUNwQ0MsZ0JBQWVYLEtBQUtXLGtCQUFrQjtBQUFBLFFBQ3RDQyxtQkFBa0JaLEtBQUtZLHFCQUFxQjtBQUFBLFFBQzVDQyxjQUFhYixLQUFLYSxnQkFBaUI7QUFBQSxRQUNuQ0Msa0JBQWlCZCxLQUFLYyxvQkFBb0I7QUFBQSxRQUMxQ0MsZ0JBQWVmLEtBQUtlLGtCQUFrQjtBQUFBLFFBQ3RDQyxxQkFBb0JoQixLQUFLZ0IsdUJBQXVCO0FBQUEsUUFDaERDLGtCQUFpQmpCLEtBQUtpQixvQkFBb0I7QUFBQSxRQUMxQ0MsV0FBVWxCLEtBQUtrQixhQUFhO0FBQUEsUUFDNUJDLGFBQVluQixLQUFLbUIsZUFBZTtBQUFBLFFBQ2hDQyxVQUFTcEIsS0FBS29CLFlBQVk7QUFBQSxRQUMxQkMsYUFBWXJCLEtBQUtxQixlQUFlO0FBQUEsUUFDaENDLFFBQU90QixLQUFLc0IsVUFBVTtBQUFBLFFBQ3RCQyxnQkFBZXZCLEtBQUt1QixrQkFBa0I7QUFBQSxRQUN0Q0MsYUFBWXhCLEtBQUt3QixlQUFlO0FBQUEsUUFDaENDLHFCQUFvQnpCLEtBQUt5Qix1QkFBdUI7QUFBQSxRQUNoRGhDLGNBQWFPLEtBQUtQLGdCQUFnQjtBQUFBLFFBQ2xDaUMsc0JBQXFCMUIsS0FBSzBCLHdCQUF3QjtBQUFBLFFBQ2xEQyxzQkFBcUIzQixLQUFLMkIsd0JBQXdCO0FBQUEsUUFDbERDLGVBQWM1QixLQUFLNEIsaUJBQWlCO0FBQUEsUUFDcENDLG1CQUFrQjdCLEtBQUs2QixxQkFBcUI7QUFBQSxRQUM1Q0MsT0FBTTlCLEtBQUs4QixTQUFTO0FBQUEsUUFDcEJDLE9BQU0vQixLQUFLK0IsU0FBUztBQUFBLFFBQ3BCQyxPQUFNaEMsS0FBS2dDLFNBQVM7QUFBQSxRQUNwQkMsaUJBQWdCakMsTUFBTWlDLGlCQUFpQkMsY0FBYztBQUFBLFFBQ3JEQyxtQkFBa0JuQyxNQUFNbUMsbUJBQW1CNU4sUUFBUTtBQUFBLFFBQ25EdEMsWUFBVytOLEtBQUsvTixjQUFjO0FBQUEsUUFDOUJOLE9BQU8sR0FBR3FPLEtBQUtFLGFBQWFGLEtBQUt6TCxRQUFRLFNBQVMsTUFBTXlMLEtBQUtJLGdCQUFnQkosS0FBS0csU0FBUyxVQUFVO0FBQUEsUUFDckc3TixPQUFPME4sS0FBS0M7QUFBQUEsTUFDZCxFQUFFO0FBRUZoTCxtQkFBYThLLGtCQUFrQjtBQUMvQixZQUFNcUMsZ0NBQWdDckMsa0JBQWtCO0FBRXhELFVBQUlBLG1CQUFtQjdOLFdBQVcsR0FBRztBQUNuQzZILGtCQUFVLHNCQUFzQixPQUFPO0FBQUEsTUFDekM7QUFBQSxJQUNGLFNBQVNNLE9BQU87QUFDZHNFLGNBQVF0RSxNQUFNLDZCQUE2QkEsS0FBSztBQUNoRE4sZ0JBQVUsNkJBQTZCLE9BQU87QUFBQSxJQUNoRCxVQUFDO0FBQ0M1RSxpQkFBVyxLQUFLO0FBQ2hCaUIsc0JBQWdCLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNZ00sa0NBQWtDLE9BQU9DLGtCQUFrQjtBQUMvRCxVQUFNQyxTQUFTLElBQUlDLGdCQUFnQjFOLFNBQVMyTixNQUFNO0FBQ2xELFVBQU0zRCxTQUFTeUQsT0FBT3ZELElBQUksUUFBUTtBQUNsQyxVQUFNMEQsWUFBWUgsT0FBT3ZELElBQUksV0FBVztBQUV4QyxRQUFJRixVQUFVd0QsY0FBY25RLFNBQVMsR0FBRztBQUN0QyxZQUFNd1EsV0FBV0wsY0FBY00sS0FBSyxDQUFDQyxNQUFNQSxFQUFFM0MsUUFBUXBCLE1BQU07QUFDM0QsVUFBSTZELFVBQVU7QUFDWnJOLDRCQUFvQnFOLFFBQVE7QUFDNUIsY0FBTTlELG1CQUFtQkMsTUFBTTtBQUMvQjdFLG1CQUFXLE1BQU07QUFDZnpFLDZCQUFtQixJQUFJO0FBQUEsUUFDekIsR0FBRyxHQUFHO0FBQUEsTUFDUixPQUFPO0FBQ0x3RSxrQkFBVSxzQkFBc0IsT0FBTztBQUFBLE1BQ3pDO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNOEkscUJBQXFCeE0sb0JBQ3ZCekUsK0JBQStCeUUsaUJBQWlCLElBQ2hEO0FBRUovRyxZQUFVLE1BQU07QUFDZHNRLG1CQUFlO0FBQUEsRUFDakIsR0FBRyxFQUFFO0FBRUx0USxZQUFVLE1BQU07QUFDZCxRQUFJMEYsVUFBVTlDLFNBQVMsR0FBRztBQUN4QmtRLHNDQUFnQ3BOLFNBQVM7QUFBQSxJQUMzQztBQUFBLEVBQ0YsR0FBRyxDQUFDSCxTQUFTMk4sUUFBUXhOLFVBQVU5QyxNQUFNLENBQUM7QUFFdEMsUUFBTTRRLHVCQUF1QixPQUFPQyxlQUFlO0FBQ2pELFVBQU1DLFdBQVdoTyxVQUFVMk4sS0FBSyxDQUFDQyxNQUFNQSxFQUFFM0MsUUFBUThDLFVBQVU7QUFDM0QsUUFBSUMsVUFBVTtBQUNaM04sMEJBQW9CMk4sUUFBUTtBQUM1QnBMLHdCQUFrQixJQUFJO0FBQ3RCLFVBQUk7QUFDRixjQUFNcUwsWUFBWSxNQUFNckUsbUJBQW1CbUUsVUFBVTtBQUNyRCxZQUFJRSxXQUFXO0FBQ2J2TCxpQ0FBdUI7QUFBQSxZQUNyQixHQUFHc0w7QUFBQUEsWUFDSCxHQUFHQztBQUFBQSxVQUNMLENBQUM7QUFBQSxRQUNILE9BQU87QUFDTHZMLGlDQUF1QjtBQUFBLFlBQ3JCLEdBQUdzTDtBQUFBQSxZQUNIOUMsV0FBVzhDLFNBQVN6TztBQUFBQSxZQUNwQjZMLGNBQWM0QyxTQUFTN0M7QUFBQUEsWUFDdkJuSixPQUFPZ00sU0FBU2hNO0FBQUFBLFlBQ2hCcUgsYUFBYTJFLFNBQVMzRTtBQUFBQSxVQUN4QixDQUFDO0FBQUEsUUFDSDtBQUFBLE1BQ0YsU0FBU2hFLE9BQU87QUFDZHNFLGdCQUFRdEUsTUFBTSxvQ0FBb0NBLEtBQUs7QUFDdkQzQywrQkFBdUI7QUFBQSxVQUNyQixHQUFHc0w7QUFBQUEsVUFDSDlDLFdBQVc4QyxTQUFTek87QUFBQUEsVUFDcEI2TCxjQUFjNEMsU0FBUzdDO0FBQUFBLFVBQ3ZCbkosT0FBT2dNLFNBQVNoTTtBQUFBQSxVQUNoQnFILGFBQWEyRSxTQUFTM0U7QUFBQUEsUUFDeEIsQ0FBQztBQUFBLE1BQ0gsVUFBQztBQUNDekcsMEJBQWtCLEtBQUs7QUFDdkJyQywyQkFBbUIsSUFBSTtBQUFBLE1BQ3pCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNMk4sbUJBQW1CQSxDQUFDQyxHQUFHQyxVQUFVO0FBQ3JDLFVBQU05UCxPQUFPNlAsRUFBRUUsT0FBT0MsTUFBTSxDQUFDO0FBQzdCLFFBQUloUSxNQUFNO0FBQ1IsWUFBTWlRLGFBQWFDLElBQUlDLGdCQUFnQm5RLElBQUk7QUFFM0MsVUFBSThQLFVBQVUsMkJBQTJCO0FBQ3ZDbEwsb0JBQVksQ0FBQ3dILFVBQVU7QUFBQSxVQUNyQixHQUFHQTtBQUFBQSxVQUNIOUcsU0FBUztBQUFBLFlBQ1AsR0FBRzhHLEtBQUs5RztBQUFBQSxZQUNSQyxvQ0FBb0N2RjtBQUFBQSxVQUN0QztBQUFBLFFBQ0YsRUFBRTtBQUNGMkYsd0JBQWdCLENBQUN5RyxVQUFVO0FBQUEsVUFDekIsR0FBR0E7QUFBQUEsVUFDSDdHLG9DQUFvQzBLO0FBQUFBLFFBQ3RDLEVBQUU7QUFDRnZMLDZCQUFxQixDQUFDMEgsVUFBVTtBQUFBLFVBQzlCLEdBQUdBO0FBQUFBLFVBQ0g3RyxvQ0FBb0M7QUFBQSxRQUN0QyxFQUFFO0FBQUEsTUFDSixXQUFXdUssVUFBVSwwQkFBMEI7QUFDN0NsTCxvQkFBWSxDQUFDd0gsVUFBVTtBQUFBLFVBQ3JCLEdBQUdBO0FBQUFBLFVBQ0g5RyxTQUFTO0FBQUEsWUFDUCxHQUFHOEcsS0FBSzlHO0FBQUFBLFlBQ1JFLG1DQUFtQ3hGO0FBQUFBLFVBQ3JDO0FBQUEsUUFDRixFQUFFO0FBQ0YyRix3QkFBZ0IsQ0FBQ3lHLFVBQVU7QUFBQSxVQUN6QixHQUFHQTtBQUFBQSxVQUNINUcsbUNBQW1DeUs7QUFBQUEsUUFDckMsRUFBRTtBQUNGdkwsNkJBQXFCLENBQUMwSCxVQUFVO0FBQUEsVUFDOUIsR0FBR0E7QUFBQUEsVUFDSDVHLG1DQUFtQztBQUFBLFFBQ3JDLEVBQUU7QUFBQSxNQUNKLFdBQVdzSyxVQUFVLG1CQUFtQjtBQUN0Q2xMLG9CQUFZLENBQUN3SCxVQUFVO0FBQUEsVUFDckIsR0FBR0E7QUFBQUEsVUFDSDlHLFNBQVM7QUFBQSxZQUNQLEdBQUc4RyxLQUFLOUc7QUFBQUEsWUFDUkcsNEJBQTRCekY7QUFBQUEsVUFDOUI7QUFBQSxRQUNGLEVBQUU7QUFDRjJGLHdCQUFnQixDQUFDeUcsVUFBVTtBQUFBLFVBQ3pCLEdBQUdBO0FBQUFBLFVBQ0gzRyw0QkFBNEJ3SztBQUFBQSxRQUM5QixFQUFFO0FBQ0Z2TCw2QkFBcUIsQ0FBQzBILFVBQVU7QUFBQSxVQUM5QixHQUFHQTtBQUFBQSxVQUNIM0csNEJBQTRCO0FBQUEsUUFDOUIsRUFBRTtBQUFBLE1BQ0osT0FBTztBQUNMYixvQkFBWSxDQUFDd0gsVUFBVTtBQUFBLFVBQ3JCLEdBQUdBO0FBQUFBLFVBQ0gsQ0FBQzBELEtBQUssR0FBRzlQO0FBQUFBLFFBQ1gsRUFBRTtBQUNGMkYsd0JBQWdCLENBQUN5RyxVQUFVLEVBQUUsR0FBR0EsTUFBTSxDQUFDMEQsS0FBSyxHQUFHRyxXQUFXLEVBQUU7QUFDNUR2TCw2QkFBcUIsQ0FBQzBILFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUMwRCxLQUFLLEdBQUcsS0FBSyxFQUFFO0FBQUEsTUFDN0Q7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU1NLG1CQUFtQkEsQ0FBQ04sVUFBVTtBQUNsQyxRQUFJQSxVQUFVLDJCQUEyQjtBQUN2Q2xMLGtCQUFZLENBQUN3SCxVQUFVO0FBQUEsUUFDckIsR0FBR0E7QUFBQUEsUUFDSDlHLFNBQVM7QUFBQSxVQUNQLEdBQUc4RyxLQUFLOUc7QUFBQUEsVUFDUkMsb0NBQW9DO0FBQUEsUUFDdEM7QUFBQSxNQUNGLEVBQUU7QUFDRkksc0JBQWdCLENBQUN5RyxVQUFVO0FBQUEsUUFDekIsR0FBR0E7QUFBQUEsUUFDSDdHLG9DQUFvQztBQUFBLE1BQ3RDLEVBQUU7QUFDRmIsMkJBQXFCLENBQUMwSCxVQUFVO0FBQUEsUUFDOUIsR0FBR0E7QUFBQUEsUUFDSDdHLG9DQUFvQztBQUFBLE1BQ3RDLEVBQUU7QUFBQSxJQUNKLFdBQVd1SyxVQUFVLDBCQUEwQjtBQUM3Q2xMLGtCQUFZLENBQUN3SCxVQUFVO0FBQUEsUUFDckIsR0FBR0E7QUFBQUEsUUFDSDlHLFNBQVM7QUFBQSxVQUNQLEdBQUc4RyxLQUFLOUc7QUFBQUEsVUFDUkUsbUNBQW1DO0FBQUEsUUFDckM7QUFBQSxNQUNGLEVBQUU7QUFDRkcsc0JBQWdCLENBQUN5RyxVQUFVO0FBQUEsUUFDekIsR0FBR0E7QUFBQUEsUUFDSDVHLG1DQUFtQztBQUFBLE1BQ3JDLEVBQUU7QUFDRmQsMkJBQXFCLENBQUMwSCxVQUFVO0FBQUEsUUFDOUIsR0FBR0E7QUFBQUEsUUFDSDVHLG1DQUFtQztBQUFBLE1BQ3JDLEVBQUU7QUFBQSxJQUNKLFdBQVdzSyxVQUFVLG1CQUFtQjtBQUN0Q2xMLGtCQUFZLENBQUN3SCxVQUFVO0FBQUEsUUFDckIsR0FBR0E7QUFBQUEsUUFDSDlHLFNBQVM7QUFBQSxVQUNQLEdBQUc4RyxLQUFLOUc7QUFBQUEsVUFDUkcsNEJBQTRCO0FBQUEsUUFDOUI7QUFBQSxNQUNGLEVBQUU7QUFDRkUsc0JBQWdCLENBQUN5RyxVQUFVO0FBQUEsUUFDekIsR0FBR0E7QUFBQUEsUUFDSDNHLDRCQUE0QjtBQUFBLE1BQzlCLEVBQUU7QUFDRmYsMkJBQXFCLENBQUMwSCxVQUFVO0FBQUEsUUFDOUIsR0FBR0E7QUFBQUEsUUFDSDNHLDRCQUE0QjtBQUFBLE1BQzlCLEVBQUU7QUFBQSxJQUNKLE9BQU87QUFDTGIsa0JBQVksQ0FBQ3dILFVBQVU7QUFBQSxRQUNyQixHQUFHQTtBQUFBQSxRQUNILENBQUMwRCxLQUFLLEdBQUc7QUFBQSxNQUNYLEVBQUU7QUFDRm5LLHNCQUFnQixDQUFDeUcsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQzBELEtBQUssR0FBRyxLQUFLLEVBQUU7QUFDdERwTCwyQkFBcUIsQ0FBQzBILFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUMwRCxLQUFLLEdBQUcsTUFBTSxFQUFFO0FBQUEsSUFDOUQ7QUFBQSxFQUNGO0FBRUEsUUFBTU8sZ0JBQWdCQSxDQUFDQyxVQUFVNUIsVUFBVTtBQUN6Q2hNLG9CQUFnQjROLFFBQVE7QUFDeEIxTixvQkFBZ0I4TCxLQUFLO0FBQUEsRUFDdkI7QUFFQSxRQUFNNkIsc0JBQXNCQSxNQUFNO0FBQ2hDN04sb0JBQWdCLElBQUk7QUFDcEJFLG9CQUFnQixFQUFFO0FBQUEsRUFDcEI7QUFFQSxRQUFNNE4sMEJBQTBCQSxDQUFDWCxHQUFHQyxVQUFVO0FBQzVDbEwsZ0JBQVk7QUFBQSxNQUNWLEdBQUdEO0FBQUFBLE1BQ0hXLFNBQVM7QUFBQSxRQUNQLEdBQUdYLFNBQVNXO0FBQUFBLFFBQ1osQ0FBQ3dLLEtBQUssR0FBR0QsRUFBRUUsT0FBTy9RO0FBQUFBLE1BQ3BCO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU15UixtQkFBbUJBLE1BQU07QUFDN0IsUUFBSXROLGVBQWV2RSxVQUFVLEdBQUc7QUFDOUJyQyxjQUFRbVUsUUFBUSxxQ0FBcUM7QUFDckQ7QUFBQSxJQUNGO0FBRUEsVUFBTUMsUUFBUW5SLEtBQUt5TSxJQUFJLEVBQUV4TCxTQUFTO0FBQ2xDMkM7QUFBQUEsTUFBa0I7QUFBQSxRQUNoQixHQUFHRDtBQUFBQSxRQUNIO0FBQUEsVUFDRTZJLElBQUkyRTtBQUFBQSxVQUNKMVAsTUFBTTtBQUFBLFVBQ05qQixNQUFNO0FBQUEsVUFDTkMsU0FBUztBQUFBLFVBQ1RDLGFBQWE7QUFBQSxVQUNiZ00sY0FBYztBQUFBLFFBQ2hCO0FBQUEsTUFBQztBQUFBLElBQ0Y7QUFBQSxFQUNIO0FBRUEsUUFBTTBFLHNCQUFzQkEsQ0FBQzVFLE9BQU87QUFDbEMsVUFBTTZFLGNBQWMxTixlQUFla00sS0FBSyxDQUFDM1EsUUFBUUEsSUFBSXNOLE9BQU9BLEVBQUU7QUFDOUQsUUFBSTZFLGFBQWE1USxTQUFTO0FBQ3hCaVEsVUFBSVksZ0JBQWdCRCxZQUFZNVEsT0FBTztBQUFBLElBQ3pDO0FBQ0FtRCxzQkFBa0JELGVBQWU0TixPQUFPLENBQUNyUyxRQUFRQSxJQUFJc04sT0FBT0EsRUFBRSxDQUFDO0FBQUEsRUFDakU7QUFFQSxRQUFNZ0YsMEJBQTBCQSxDQUFDaEYsSUFBSS9LLFNBQVM7QUFDNUNtQztBQUFBQSxNQUNFRCxlQUFlbUcsSUFBSSxDQUFDNUssUUFBU0EsSUFBSXNOLE9BQU9BLEtBQUssRUFBRSxHQUFHdE4sS0FBS3VDLEtBQUssSUFBSXZDLEdBQUk7QUFBQSxJQUN0RTtBQUFBLEVBQ0Y7QUFFQSxRQUFNdVMsZ0NBQWdDQSxDQUFDcEIsR0FBRzdELE9BQU87QUFDL0MsVUFBTWhNLE9BQU82UCxFQUFFRSxPQUFPQyxNQUFNLENBQUM7QUFDN0IsUUFBSWhRLE1BQU07QUFDUixZQUFNaVEsYUFBYUMsSUFBSUMsZ0JBQWdCblEsSUFBSTtBQUMzQ29EO0FBQUFBLFFBQ0VELGVBQWVtRztBQUFBQSxVQUFJLENBQUM1SyxRQUNsQkEsSUFBSXNOLE9BQU9BLEtBQ1A7QUFBQSxZQUNFLEdBQUd0TjtBQUFBQSxZQUNIc0I7QUFBQUEsWUFDQUMsU0FBU2dRO0FBQUFBLFlBQ1QvUCxhQUFhO0FBQUEsWUFDYmdNLGNBQWM7QUFBQSxVQUNoQixJQUNBeE47QUFBQUEsUUFDTjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU13UywwQkFBMEJBLENBQUNsRixPQUFPO0FBQ3RDLFVBQU1tRixjQUFjaE8sZUFBZWtNLEtBQUssQ0FBQzNRLFFBQVFBLElBQUlzTixPQUFPQSxFQUFFO0FBQzlELFFBQUltRixhQUFhbFIsU0FBUztBQUN4QmlRLFVBQUlZLGdCQUFnQkssWUFBWWxSLE9BQU87QUFBQSxJQUN6QztBQUNBbUQ7QUFBQUEsTUFDRUQsZUFBZW1HO0FBQUFBLFFBQUksQ0FBQzVLLFFBQ2xCQSxJQUFJc04sT0FBT0EsS0FBSyxFQUFFLEdBQUd0TixLQUFLc0IsTUFBTSxNQUFNQyxTQUFTLEtBQUssSUFBSXZCO0FBQUFBLE1BQzFEO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNMFMsNEJBQTRCQSxDQUFDdkIsR0FBR0MsVUFBVTtBQUM5QyxVQUFNOVAsT0FBTzZQLEVBQUVFLE9BQU9DLE1BQU0sQ0FBQztBQUM3QixRQUFJaFEsTUFBTTtBQUNSLFlBQU1pUSxhQUFhQyxJQUFJQyxnQkFBZ0JuUSxJQUFJO0FBQzNDd0QsdUJBQWlCLENBQUM0SSxVQUFVLEVBQUUsR0FBR0EsTUFBTSxDQUFDMEQsS0FBSyxHQUFHOVAsS0FBSyxFQUFFO0FBQ3ZEZ0UsMkJBQXFCLENBQUNvSSxVQUFVLEVBQUUsR0FBR0EsTUFBTSxDQUFDMEQsS0FBSyxHQUFHRyxXQUFXLEVBQUU7QUFBQSxJQUNuRTtBQUFBLEVBQ0Y7QUFFQSxRQUFNb0IsNEJBQTRCQSxDQUFDdkIsVUFBVTtBQUMzQyxRQUFJL0wsa0JBQWtCK0wsS0FBSyxHQUFHO0FBQzVCSSxVQUFJWSxnQkFBZ0IvTSxrQkFBa0IrTCxLQUFLLENBQUM7QUFBQSxJQUM5QztBQUNBdE0scUJBQWlCLENBQUM0SSxVQUFVLEVBQUUsR0FBR0EsTUFBTSxDQUFDMEQsS0FBSyxHQUFHLEtBQUssRUFBRTtBQUN2RDlMLHlCQUFxQixDQUFDb0ksVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQzBELEtBQUssR0FBRyxLQUFLLEVBQUU7QUFBQSxFQUM3RDtBQUVBLFFBQU13QixlQUFlLE9BQU96QixNQUFNO0FBQ2hDQSxNQUFFMEIsZUFBZTtBQUNqQmxQLGlCQUFhLElBQUk7QUFFakIsUUFBSTtBQUNGLFlBQU1tUCxpQkFBaUIsSUFBSUMsU0FBUztBQUNwQ0QscUJBQWVFLE9BQU8sV0FBVzVQLGlCQUFpQjZLLEdBQUc7QUFFckQsVUFBSWhJLFNBQVNXLFFBQVFyRSxNQUFNO0FBQ3pCdVEsdUJBQWVFLE9BQU8sZ0JBQWdCL00sU0FBU1csUUFBUXJFLElBQUk7QUFBQSxNQUM3RDtBQUNBLFVBQUkwRCxTQUFTVyxRQUFRN0IsYUFBYTtBQUNoQytOLHVCQUFlRSxPQUFPLGlCQUFpQi9NLFNBQVNXLFFBQVE3QixXQUFXO0FBQUEsTUFDckU7QUFFQSxZQUFNa08sYUFBYTtBQUFBLFFBQ2pCO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUFrQjtBQUdwQkEsaUJBQVdsVCxRQUFRLENBQUNxUixVQUFVO0FBQzVCLFlBQUluTCxTQUFTbUwsS0FBSyxHQUFHO0FBQ25CMEIseUJBQWVFLE9BQU81QixPQUFPbkwsU0FBU21MLEtBQUssQ0FBQztBQUFBLFFBQzlDO0FBQUEsTUFDRixDQUFDO0FBRUQsWUFBTThCLGdCQUFnQjtBQUFBLFFBQ3BCO0FBQUEsVUFDRXhULEtBQUs7QUFBQSxVQUNMWSxPQUFPMkYsU0FBU1csUUFBUUM7QUFBQUEsUUFDMUI7QUFBQSxRQUNBO0FBQUEsVUFDRW5ILEtBQUs7QUFBQSxVQUNMWSxPQUFPMkYsU0FBU1csUUFBUUU7QUFBQUEsUUFDMUI7QUFBQSxRQUNBO0FBQUEsVUFDRXBILEtBQUs7QUFBQSxVQUNMWSxPQUFPMkYsU0FBU1csUUFBUUc7QUFBQUEsUUFDMUI7QUFBQSxNQUFDO0FBR0htTSxvQkFBY25ULFFBQVEsQ0FBQ3FSLFVBQVU7QUFDL0IsWUFBSUEsTUFBTTlRLE9BQU87QUFDZndTLHlCQUFlRSxPQUFPNUIsTUFBTTFSLEtBQUswUixNQUFNOVEsS0FBSztBQUFBLFFBQzlDO0FBQUEsTUFDRixDQUFDO0FBRUQsVUFBSW1FLGVBQWV2RSxTQUFTLEdBQUc7QUFDN0IsY0FBTWlULFdBQVcxTyxlQUFlLENBQUM7QUFDakMsWUFBSTBPLFNBQVM1USxRQUFRNFEsU0FBUzVRLEtBQUs2USxLQUFLLEdBQUc7QUFDekNOLHlCQUFlRSxPQUFPLHdCQUF3QkcsU0FBUzVRLEtBQUs2USxLQUFLLENBQUM7QUFBQSxRQUNwRTtBQUNBLFlBQUlELFNBQVM3UixNQUFNO0FBQ2pCd1IseUJBQWVFLE9BQU8seUJBQXlCRyxTQUFTN1IsSUFBSTtBQUFBLFFBQzlEO0FBQUEsTUFDRjtBQUVBLFlBQU13TCxXQUFXLE1BQU0zTyxJQUFJa1Y7QUFBQUEsUUFDekI7QUFBQSxRQUNBUDtBQUFBQSxRQUNBO0FBQUEsVUFDRVEsU0FBUztBQUFBLFlBQ1AsZ0JBQWdCO0FBQUEsVUFDbEI7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUVBLFVBQUl4RyxTQUFTRSxLQUFLTixTQUFTO0FBQ3pCN08sZ0JBQVE2TyxRQUFRckksb0JBQW9CLG9DQUFvQyxrQ0FBa0M7QUFDMUcsY0FBTXVJLG1CQUFtQnhKLGlCQUFpQjZLLEdBQUc7QUFDN0NqRyxtQkFBVyxNQUFNO0FBQ2Z6RSw2QkFBbUIsS0FBSztBQUN4QmdRLG9CQUFVO0FBQUEsUUFDWixHQUFHLElBQUk7QUFBQSxNQUNUO0FBQUEsSUFDRixTQUFTbEwsT0FBTztBQUNkc0UsY0FBUXRFLE1BQU0sOEJBQThCQSxLQUFLO0FBQ2pEeEssY0FBUXdLO0FBQUFBLFFBQ05BLE1BQU15RSxVQUFVRSxNQUFNblAsV0FBVztBQUFBLE1BQ25DO0FBQUEsSUFDRixVQUFDO0FBQ0M4RixtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUEsUUFBTTRQLFlBQVlBLE1BQU07QUFDdEJDLFdBQU9DLE9BQU96TSxZQUFZLEVBQUVqSCxRQUFRLENBQUN3QixZQUFZO0FBQy9DLFVBQUlBLFFBQVNpUSxLQUFJWSxnQkFBZ0I3USxPQUFPO0FBQUEsSUFDMUMsQ0FBQztBQUVEa0QsbUJBQWUxRSxRQUFRLENBQUNDLFFBQVE7QUFDOUIsVUFBSUEsSUFBSXVCLFFBQVNpUSxLQUFJWSxnQkFBZ0JwUyxJQUFJdUIsT0FBTztBQUFBLElBQ2xELENBQUM7QUFFRGlTLFdBQU9DLE9BQU9wTyxpQkFBaUIsRUFBRXRGLFFBQVEsQ0FBQ3dCLFlBQVk7QUFDcEQsVUFBSUEsUUFBU2lRLEtBQUlZLGdCQUFnQjdRLE9BQU87QUFBQSxJQUMxQyxDQUFDO0FBRUQyRSxnQkFBWTtBQUFBLE1BQ1ZDLG9CQUFvQjtBQUFBLE1BQ3BCQyw0QkFBNEI7QUFBQSxNQUM1QkMsMkJBQTJCO0FBQUEsTUFDM0JDLG9CQUFvQjtBQUFBLE1BQ3BCQyxrQkFBa0I7QUFBQSxNQUNsQkMsc0JBQXNCO0FBQUEsTUFDdEJDLHFCQUFxQjtBQUFBLE1BQ3JCQyx5QkFBeUI7QUFBQSxNQUN6QkMsa0JBQWtCO0FBQUEsTUFDbEJDLFNBQVM7QUFBQSxRQUNQckUsTUFBTThCLG1CQUFtQm9KLGdCQUFnQjtBQUFBLFFBQ3pDMUksYUFBYVYsbUJBQW1Cc0osaUJBQWlCO0FBQUEsUUFDakQ5RyxvQ0FBb0M7QUFBQSxRQUNwQ0MsbUNBQW1DO0FBQUEsUUFDbkNDLDRCQUE0QjtBQUFBLE1BQzlCO0FBQUEsSUFDRixDQUFDO0FBRURFLG9CQUFnQjtBQUFBLE1BQ2RkLG9CQUFvQjtBQUFBLE1BQ3BCQyw0QkFBNEI7QUFBQSxNQUM1QkMsMkJBQTJCO0FBQUEsTUFDM0JDLG9CQUFvQjtBQUFBLE1BQ3BCQyxrQkFBa0I7QUFBQSxNQUNsQkMsc0JBQXNCO0FBQUEsTUFDdEJDLHFCQUFxQjtBQUFBLE1BQ3JCQyx5QkFBeUI7QUFBQSxNQUN6QkMsa0JBQWtCO0FBQUEsTUFDbEJFLG9DQUFvQztBQUFBLE1BQ3BDQyxtQ0FBbUM7QUFBQSxNQUNuQ0MsNEJBQTRCO0FBQUEsSUFDOUIsQ0FBQztBQUVELFFBQ0UxQyxtQkFBbUIrSSx3QkFDbkIvSSxtQkFBbUJnSix1QkFDbkI7QUFDQTNJO0FBQUFBLFFBQWtCO0FBQUEsVUFDaEI7QUFBQSxZQUNFNEksSUFBSXhNLEtBQUt5TSxJQUFJLEVBQUV4TCxTQUFTO0FBQUEsWUFDeEJRLE1BQU04QixrQkFBa0IrSSx3QkFBd0I7QUFBQSxZQUNoRDlMLE1BQU07QUFBQSxZQUNOQyxTQUFTO0FBQUEsWUFDVEMsYUFBYTZDLGtCQUFrQmdKLHlCQUF5QjtBQUFBLFlBQ3hERyxjQUFjbkosa0JBQWtCK0ksd0JBQXdCO0FBQUEsVUFDMUQ7QUFBQSxRQUFDO0FBQUEsTUFDRjtBQUFBLElBQ0gsT0FBTztBQUNMMUksd0JBQWtCLEVBQUU7QUFBQSxJQUN0QjtBQUVBRSxxQkFBaUIsS0FBSztBQUN0QkUscUJBQWlCO0FBQUEsTUFDZnZDLE1BQU07QUFBQSxNQUNOd0MsYUFBYTtBQUFBLE1BQ2JDLE9BQU87QUFBQSxNQUNQQyxTQUFTO0FBQUEsTUFDVEMsYUFBYTtBQUFBLE1BQ2JDLFNBQVM7QUFBQSxNQUNUQyxPQUFPO0FBQUEsSUFDVCxDQUFDO0FBQ0RFLHlCQUFxQjtBQUFBLE1BQ25CSixhQUFhO0FBQUEsTUFDYkMsU0FBUztBQUFBLE1BQ1RDLE9BQU87QUFBQSxJQUNULENBQUM7QUFFRFkseUJBQXFCLENBQUMsQ0FBQztBQUFBLEVBQ3pCO0FBRUEsUUFBTTBOLDhCQUE4QkEsQ0FBQ3ZDLE1BQU07QUFDekNwTyxrQkFBY29PLEVBQUVFLE9BQU8vUSxLQUFLO0FBQUEsRUFDOUI7QUFFQSxRQUFNcVQsdUJBQXVCQSxNQUFNO0FBQ2pDLFFBQUksQ0FBQ3RQLGtCQUFtQixRQUFPO0FBQy9CLFVBQU00TSxZQUFZO0FBRWxCeFIsdUJBQW1CTSxRQUFRLENBQUNDLFFBQVE7QUFDbEMsVUFBSXFFLGtCQUFrQnJFLElBQUlOLEdBQUcsR0FBRztBQUM5QnVSLGtCQUFVMkMsS0FBSztBQUFBLFVBQ2JsVSxLQUFLTSxJQUFJTjtBQUFBQSxVQUNUQyxPQUFPSyxJQUFJTDtBQUFBQSxVQUNYa1UsS0FBS3hQLGtCQUFrQnJFLElBQUlOLEdBQUc7QUFBQSxVQUM5QnVDLFNBQVNvQyxrQkFBa0JyRSxJQUFJTixHQUFHLEdBQUc0QztBQUFBQSxZQUNuQztBQUFBLFVBQ0Y7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixDQUFDO0FBRUQsUUFBSStCLGtCQUFrQmdKLHVCQUF1QjtBQUMzQzRELGdCQUFVMkMsS0FBSztBQUFBLFFBQ2JsVSxLQUFLO0FBQUEsUUFDTEMsT0FBTzBFLGtCQUFrQitJLHdCQUF3QjtBQUFBLFFBQ2pEeUcsS0FBS3hQLGtCQUFrQmdKO0FBQUFBLFFBQ3ZCcEwsU0FBU29DLGtCQUFrQmdKLHVCQUF1Qi9LO0FBQUFBLFVBQ2hEO0FBQUEsUUFDRjtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0g7QUFFQSxXQUFPMk87QUFBQUEsRUFDVDtBQUVBLFFBQU02QyxvQkFBb0JILHFCQUFxQjtBQUUvQyxNQUFJeFAsY0FBYztBQUNoQixXQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDO0FBQUEsVUFDQSxZQUFZO0FBQUE7QUFBQSxRQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUVtQjtBQUFBLE1BRW5CLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUix1QkFBQyxTQUFJLFdBQVUsa0RBQ2IsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsRUFFSjtBQUVBLFNBQ0UsdUJBQUMsU0FFRVA7QUFBQUEsVUFBTUUsUUFDTDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVyw0REFDVEYsTUFBTTFCLFNBQVMsWUFBWSxpQkFBaUIsWUFBWTtBQUFBLFFBR3pEMEIsZ0JBQU0vRjtBQUFBQTtBQUFBQSxNQUxUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1BO0FBQUEsSUFJRjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTWtHLGlCQUFpQjtBQUFBLFFBQ3ZCLE9BQU9FO0FBQUFBLFFBQ1AsUUFBUTtBQUFBLFFBQ1IsVUFBVTROO0FBQUFBLFFBQ1YsT0FBTTtBQUFBLFFBQ04sT0FBTyxFQUFFa0MsVUFBVSxPQUFPO0FBQUEsUUFFMUIsaUNBQUMsU0FBSSxLQUFLOVAsY0FBYyxPQUFPLEVBQUVzRixPQUFPLE9BQU8sR0FBRyxLQUFLeEYsZ0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0U7QUFBQTtBQUFBLE1BUnRFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVNBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0EsWUFBWTtBQUFBO0FBQUEsUUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFbUI7QUFBQSxNQUVuQix1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BRVIsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFXO0FBQUEsUUFDWCx1QkFBQyxTQUFJLFdBQVUsMENBQ2IsaUNBQUMsU0FDQztBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMsd0NBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsZ0VBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiLGlDQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDhEQUE2RCwrQkFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQztBQUFBLGNBQ0EsYUFBWTtBQUFBLGNBQ1osVUFBVStNO0FBQUFBLGNBQ1Y7QUFBQSxjQUNBLGlCQUNFNU4sVUFBVSx1QkFBQyxRQUFLLE1BQUssV0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrQixJQUFNO0FBQUEsY0FFcEMsY0FBYyxDQUFDOFEsT0FBT0MsV0FBVztBQUMvQixzQkFBTXRVLFFBQ0pzVSxRQUFRdFUsT0FBT29DLFNBQVMsRUFBRW1TLFlBQVksS0FBSztBQUM3Qyx1QkFBT3ZVLE1BQU13VSxTQUFTSCxNQUFNRSxZQUFZLENBQUM7QUFBQSxjQUMzQztBQUFBLGNBQ0EsT0FBTyxFQUFFM0ssT0FBTyxRQUFRd0ssVUFBVSxTQUFTMUosUUFBUSxPQUFPO0FBQUEsY0FDMUQsTUFBSztBQUFBLGNBQ0wsT0FBT2pILGtCQUFrQjZLLE9BQU9tRztBQUFBQSxjQUNoQyxTQUFTcFIsVUFBVTRILElBQUksQ0FBQzhGLGNBQWM7QUFBQSxnQkFDcENwUSxPQUFPb1EsU0FBU3pDO0FBQUFBLGdCQUNoQnRPLE9BQU8sR0FBRytRLFNBQVNuTyxJQUFJLE1BQU1tTyxTQUFTdkMsS0FBSztBQUFBLGNBQzdDLEVBQUU7QUFBQTtBQUFBLFlBbkJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQW1CTSxLQXBCUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBLGFBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyQkEsS0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZCQSxLQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0JBO0FBQUEsUUFHQy9LLG9CQUNDLHVCQUFDLFNBQUksV0FBVSxRQUViO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG1HQUNiLGlDQUFDLFNBQUksV0FBVSxvREFDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsNENBQTJDLGtDQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsb0NBQ1hBLDJCQUFpQmIsUUFEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsdUNBQUMsT0FBRSxXQUFVLHlCQUNYO0FBQUEseUNBQUMsVUFBSyxXQUFVLGVBQWMsc0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9DO0FBQUEsa0JBQU87QUFBQSxrQkFBRWEsaUJBQWlCNEIsU0FBUztBQUFBLHFCQUR6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsT0FBRSxXQUFVLHlCQUNYO0FBQUEseUNBQUMsVUFBSyxXQUFVLGVBQWMsc0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW9DO0FBQUEsa0JBQU87QUFBQSxrQkFBRTVCLGlCQUFpQitLLFNBQVM7QUFBQSxxQkFEekU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNDL0ssaUJBQWlCaUosZUFDaEIsdUJBQUMsT0FBRSxXQUFVLHlCQUNYO0FBQUEseUNBQUMsVUFBSyxXQUFVLGVBQWMsNEJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTBDO0FBQUEsa0JBQU87QUFBQSxrQkFBQyx1QkFBQyxVQUFLLFdBQVUsK0JBQStCakosMkJBQWlCaUosZUFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEU7QUFBQSxxQkFEaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWUE7QUFBQSxpQkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQkE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNaaEk7QUFBQUEsbUNBQ0MsdUJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLHFDQUFvQyxnQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFVBQUssV0FBVyx5QkFDZndNLHVCQUF1QixNQUFNLG1CQUM3QkEsc0JBQXNCLEtBQUssb0JBQzNCLGNBQWMsSUFFYkE7QUFBQUE7QUFBQUEsb0JBQW1CO0FBQUEsdUJBTHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTUE7QUFBQSxxQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVdBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsU0FBU0E7QUFBQUEsb0JBQ1QsYUFBYUEsdUJBQXVCLE1BQU0sWUFDL0JBLHNCQUFzQixLQUFLLFlBQVk7QUFBQSxvQkFDbEQsTUFBSztBQUFBO0FBQUEsa0JBSlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUljO0FBQUEsZ0JBRWQsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsU0FBUyxNQUFNcE4saUJBQWlCLElBQUk7QUFBQSxzQkFDcEMsV0FBVTtBQUFBLHNCQUVWO0FBQUEsK0NBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFNO0FBQUEsd0JBQUc7QUFBQSx3QkFBUXFRLGtCQUFrQjVUO0FBQUFBLHdCQUFPO0FBQUE7QUFBQTtBQUFBLG9CQUo1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxTQUFTLE1BQU1xRCxtQkFBbUIsSUFBSTtBQUFBLHNCQUN0QyxXQUFVO0FBQUEsc0JBRVRjLDhCQUFvQixXQUFXO0FBQUE7QUFBQSxvQkFKbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEscUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFhQTtBQUFBLG1CQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlDQTtBQUFBLGNBRUQsQ0FBQ0EscUJBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUyxNQUFNZCxtQkFBbUIsSUFBSTtBQUFBLGtCQUN0QyxXQUFVO0FBQUEsa0JBQW1JO0FBQUE7QUFBQSxnQkFGL0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxpQkEzQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE2Q0E7QUFBQSxlQW5FRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9FQSxLQXJFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNFQTtBQUFBLFVBR0NvQyxpQkFDQyx1QkFBQyxTQUFJLFdBQVUsNEJBQ2IsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZSxLQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLElBQ0VGLHNCQUNGO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxJQUFHO0FBQUEsY0FDSCxXQUFVO0FBQUEsY0FHVjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFTLE1BQU1LLHlCQUF5QixDQUFDRCxxQkFBcUI7QUFBQSxvQkFFOUQsaUNBQUMsU0FBSSxXQUFVLHFDQUViO0FBQUEsNkNBQUMsU0FBSSxXQUFVLDJCQUViO0FBQUEsK0NBQUMsU0FBSSxXQUFVLG9HQUNiO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLEtBQUt6SDtBQUFBQSw0QkFDTCxLQUFJO0FBQUEsNEJBQ0osV0FBVTtBQUFBLDRCQUNWLFNBQVMsQ0FBQytTLE1BQU07QUFDZEEsZ0NBQUVFLE9BQU9yRyxVQUFVO0FBQ25CbUcsZ0NBQUVFLE9BQU9nRCxNQUFNO0FBQUEsNEJBQ2pCO0FBQUE7QUFBQSwwQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBT0ksS0FSTjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQVVBO0FBQUEsd0JBRUEsdUJBQUMsU0FDQztBQUFBLGlEQUFDLFFBQUcsV0FBVSw4REFDWjtBQUFBLG1EQUFDLFVBQUssNEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBa0I7QUFBQSw0QkFDbEIsdUJBQUMsVUFBSyxXQUFVLHlDQUF3QyxpQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBeUQ7QUFBQSwrQkFGM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FHQTtBQUFBLDBCQUNBLHVCQUFDLE9BQUUsV0FBVSx5QkFDVjVPO0FBQUFBLGdEQUFvQnlJLGFBQWF6SSxvQkFBb0JsRCxRQUFRO0FBQUEsNEJBQzdEa0Qsb0JBQW9CNEcsZUFBZSxVQUFVNUcsb0JBQW9CNEcsV0FBVztBQUFBLCtCQUYvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUdBO0FBQUEsNkJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFTQTtBQUFBLDJCQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQXdCQTtBQUFBLHNCQUdBLHVCQUFDLFNBQUksV0FBVSx5Q0FFYjtBQUFBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVU7QUFBQSw0QkFDVixTQUFTLENBQUM4RSxNQUFNO0FBQ2RBLGdDQUFFbUQsZ0JBQWdCO0FBQ2xCck0sZ0RBQWtCO0FBQUEsNEJBQ3BCO0FBQUEsNEJBQ0EsT0FBTTtBQUFBLDRCQUVOLGlDQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUErQjtBQUFBO0FBQUEsMEJBUmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFTQTtBQUFBLHdCQUdBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVU7QUFBQSw0QkFDVixTQUFTLENBQUNrSixNQUFNO0FBQ2RBLGdDQUFFbUQsZ0JBQWdCO0FBQ2xCeE8sdURBQXlCLENBQUNELHFCQUFxQjtBQUFBLDRCQUNqRDtBQUFBLDRCQUVBO0FBQUEsOEJBQUM7QUFBQTtBQUFBLGdDQUNDLFdBQVcsNkNBQTZDQSx3QkFBd0IsZUFBZSxFQUFFO0FBQUEsZ0NBQ2pHLE1BQUs7QUFBQSxnQ0FDTCxRQUFPO0FBQUEsZ0NBQ1AsU0FBUTtBQUFBLGdDQUVSLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBYSxHQUFHLEdBQUUsb0JBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBQXFGO0FBQUE7QUFBQSw4QkFOdkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQU9BO0FBQUE7QUFBQSwwQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBZUE7QUFBQSwyQkE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkE4QkE7QUFBQSx5QkEzREY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkE0REE7QUFBQTtBQUFBLGtCQWhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBaUVBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFXLCtDQUErQ0Esd0JBQXdCLCtCQUErQixtQkFBbUIsSUFHdkk7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsaURBQ2IsaUNBQUMsUUFBRyxXQUFVLCtEQUNaO0FBQUEsNkNBQUMsWUFBUyxXQUFVLG1CQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFtQztBQUFBLHNCQUFHO0FBQUEseUJBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLE9BQ2IsaUNBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEsNkNBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDBDQUF5QyxzQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBK0Q7QUFBQSx3QkFDL0QsdUJBQUMsVUFBSyxXQUFVLHlCQUF5QkosOEJBQW9CdUssU0FBUyxPQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUEwRTtBQUFBLDJCQUY1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDBDQUF5QywwQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBbUU7QUFBQSx3QkFDbkUsdUJBQUMsVUFBSyxXQUFVLHFDQUFxQ3ZLLDhCQUFvQnlJLGFBQWF6SSxvQkFBb0JsRCxRQUFRLE9BQWxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXNIO0FBQUEsMkJBRnhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBR0E7QUFBQSxzQkFDQSx1QkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSwrQ0FBQyxVQUFLLFdBQVUsMENBQXlDLDhCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUF1RTtBQUFBLHdCQUN2RSx1QkFBQyxVQUFLLFdBQVUseUJBQXlCa0QsOEJBQW9CNEosZUFBZSxPQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFnRjtBQUFBLDJCQUZsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDBDQUF5Qyw4QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBdUU7QUFBQSx3QkFDdkUsdUJBQUMsVUFBSyxXQUFVLHlCQUF5QjFPLHFCQUFXOEUsb0JBQW9CMEosV0FBVyxLQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFxRjtBQUFBLDJCQUZ2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDBDQUF5Qyx1QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBZ0U7QUFBQSx3QkFDaEUsdUJBQUMsVUFBSyxXQUFVLHlCQUF5QjFKLDhCQUFvQjZKLFVBQVUsT0FBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBMkU7QUFBQSwyQkFGN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLCtDQUFDLFVBQUssV0FBVSwwQ0FBeUMsK0JBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXdFO0FBQUEsd0JBQ3hFLHVCQUFDLFVBQUssV0FBVSx5QkFBeUI3Siw4QkFBb0I4SixrQkFBa0IsT0FBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBbUY7QUFBQSwyQkFGckY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksV0FBVSxrREFDYjtBQUFBLCtDQUFDLFVBQUssV0FBVSwwQ0FBeUMsNEJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXFFO0FBQUEsd0JBQ3JFLHVCQUFDLFVBQUssV0FBVSx5QkFBeUI5Siw4QkFBb0IrSixlQUFlLE9BQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWdGO0FBQUEsMkJBRmxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBR0E7QUFBQSx5QkE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkE2QkEsS0E5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkErQkE7QUFBQSx1QkF0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF1Q0E7QUFBQSxrQkFHQSx1QkFBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsaURBQ2IsaUNBQUMsUUFBRyxXQUFVLCtEQUNaO0FBQUEsNkNBQUMsVUFBTyxXQUFVLG9CQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFrQztBQUFBLHNCQUFHO0FBQUEseUJBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLE9BQ2IsaUNBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEsNkNBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDBDQUF5QyxzQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBK0Q7QUFBQSx3QkFDL0QsdUJBQUMsVUFBSyxXQUFVLHlCQUNkLGlDQUFDLE9BQUUsTUFBTSxVQUFVL0osb0JBQW9CVCxLQUFLLElBQUksV0FBVSxtQkFDdkRTLDhCQUFvQlQsU0FBUyxPQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFJQTtBQUFBLDJCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBT0E7QUFBQSxzQkFDQSx1QkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSwrQ0FBQyxVQUFLLFdBQVUsMENBQXlDLHNCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUErRDtBQUFBLHdCQUMvRCx1QkFBQyxVQUFLLFdBQVUseUJBQXlCUyw4QkFBb0IySSxnQkFBZ0IzSSxvQkFBb0IwSSxTQUFTLE9BQTFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQThHO0FBQUEsMkJBRmhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBR0E7QUFBQSxzQkFDQSx1QkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSwrQ0FBQyxVQUFLLFdBQVUsMENBQXlDLGdDQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUF5RTtBQUFBLHdCQUN6RSx1QkFBQyxVQUFLLFdBQVUseUJBQXlCMUksOEJBQW9CcUosb0JBQW9CLE9BQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXFGO0FBQUEsMkJBRnZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBR0E7QUFBQSx5QkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFtQkE7QUFBQSx1QkExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkEyQkE7QUFBQSxrQkFHQSx1QkFBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsaURBQ2IsaUNBQUMsUUFBRyxXQUFVLCtEQUNaO0FBQUEsNkNBQUMsY0FBVyxXQUFVLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF1QztBQUFBLHNCQUFHO0FBQUEseUJBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLE9BQ2IsaUNBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEsNkNBQUMsU0FBSSxXQUFVLGtEQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDBDQUF5Qyx3QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBaUU7QUFBQSx3QkFDakUsdUJBQUMsVUFBSyxXQUFVLHlCQUF5QnJKLDhCQUFvQlIsV0FBVyxPQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE0RTtBQUFBLDJCQUY5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDBDQUF5Qyx3QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBaUU7QUFBQSx3QkFDakUsdUJBQUMsVUFBSyxXQUFVLHlCQUF5QlEsOEJBQW9COE8sV0FBVyxPQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE0RTtBQUFBLDJCQUY5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDBDQUF5QyxzQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBK0Q7QUFBQSx3QkFDL0QsdUJBQUMsVUFBSyxXQUFVLHlCQUF5QjlPLDhCQUFvQnNLLFNBQVMsT0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBMEU7QUFBQSwyQkFGNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLCtDQUFDLFVBQUssV0FBVSwwQ0FBeUMseUJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWtFO0FBQUEsd0JBQ2xFLHVCQUFDLFVBQUssV0FBVSx5QkFBeUJ0Syw4QkFBb0IySixZQUFZLE9BQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTZFO0FBQUEsMkJBRi9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBR0E7QUFBQSxzQkFDQSx1QkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSwrQ0FBQyxVQUFLLFdBQVUsMENBQXlDLHNCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUErRDtBQUFBLHdCQUMvRCx1QkFBQyxVQUFLLFdBQVUseUJBQXlCM0osOEJBQW9CcUssU0FBUyxPQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUEwRTtBQUFBLDJCQUY1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDBDQUF5Qyx3QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBaUU7QUFBQSx3QkFDakUsdUJBQUMsVUFBSyxXQUFVLHlCQUF5QnJLLDhCQUFvQjRJLFdBQVcsT0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBNEU7QUFBQSwyQkFGOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQTtBQUFBLHlCQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQXlCQSxLQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQTJCQTtBQUFBLHVCQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQW1DQTtBQUFBLGtCQUdBLHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSxpREFDYixpQ0FBQyxRQUFHLFdBQVUsK0RBQ1o7QUFBQSw2Q0FBQyxrQkFBZSxXQUFVLG9CQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEwQztBQUFBLHNCQUFHO0FBQUEseUJBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLE9BQ2IsaUNBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEsNkNBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDBDQUF5Qyw4QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBdUU7QUFBQSx3QkFDdkUsdUJBQUMsVUFBSyxXQUFVLHlCQUF5QjVJLDhCQUFvQjZJLGFBQWEsT0FBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBOEU7QUFBQSwyQkFGaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLCtDQUFDLFVBQUssV0FBVSwwQ0FBeUMsMkJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQW9FO0FBQUEsd0JBQ3BFLHVCQUFDLFVBQUssV0FBVSx5QkFBeUI3SSw4QkFBb0I4SSxVQUFVLE9BQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTJFO0FBQUEsMkJBRjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBR0E7QUFBQSx5QkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFXQTtBQUFBLHVCQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQW1CQTtBQUFBLGtCQUdBLHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSxpREFDYixpQ0FBQyxRQUFHLFdBQVUsK0RBQ1o7QUFBQSw2Q0FBQyxZQUFTLFdBQVUsbUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQW1DO0FBQUEsc0JBQUc7QUFBQSx5QkFEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBS0E7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsT0FDYixpQ0FBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSw2Q0FBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSwrQ0FBQyxVQUFLLFdBQVUsMENBQXlDLDBCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFtRTtBQUFBLHdCQUNuRSx1QkFBQyxVQUFLLFdBQVUseUJBQXlCOUksOEJBQW9CeUosYUFBYSxPQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE4RTtBQUFBLDJCQUZoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDBDQUF5Qyx1QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBZ0U7QUFBQSx3QkFDaEUsdUJBQUMsVUFBSyxXQUFVLHlCQUF5QnpKLDhCQUFvQndKLG9CQUFvQixPQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFxRjtBQUFBLDJCQUZ2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDBDQUF5QywrQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBd0U7QUFBQSx3QkFDeEUsdUJBQUMsVUFBSyxXQUFVLHlCQUF5QnhKLDhCQUFvQnVKLHVCQUF1QixPQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUF3RjtBQUFBLDJCQUYxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDBDQUF5QywwQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBbUU7QUFBQSx3QkFDbkUsdUJBQUMsVUFBSyxXQUFVLHlCQUF5QnZKLDhCQUFvQnNKLGtCQUFrQixPQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFtRjtBQUFBLDJCQUZyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEseUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBaUJBLEtBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBbUJBO0FBQUEsdUJBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBMkJBO0FBQUEsa0JBR0EsdUJBQUMsU0FBSSxXQUFVLDRCQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLGlEQUNiLGlDQUFDLFFBQUcsV0FBVSwrREFDWjtBQUFBLDZDQUFDLFlBQVMsV0FBVSxtQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBbUM7QUFBQSxzQkFBRztBQUFBLHlCQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFLQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSxPQUNiLGlDQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLDZDQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLCtDQUFDLFVBQUssV0FBVSwwQ0FBeUMsNkJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXNFO0FBQUEsd0JBQ3RFLHVCQUFDLFVBQUssV0FBVSx5QkFBeUJ0Siw4QkFBb0JnSSxnQkFBZ0IsT0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBaUY7QUFBQSwyQkFGbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLCtDQUFDLFVBQUssV0FBVSwwQ0FBeUMsNkJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXNFO0FBQUEsd0JBQ3RFLHVCQUFDLFVBQUssV0FBVSx5QkFBeUJoSSw4QkFBb0JrSyx3QkFBd0IsT0FBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBeUY7QUFBQSwyQkFGM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLCtDQUFDLFVBQUssV0FBVSwwQ0FBeUMsc0JBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQStEO0FBQUEsd0JBQy9ELHVCQUFDLFVBQUssV0FBVSx5QkFBeUJsSyw4QkFBb0JpSyx3QkFBd0IsT0FBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBeUY7QUFBQSwyQkFGM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLCtDQUFDLFVBQUssV0FBVSwwQ0FBeUMsOEJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQXVFO0FBQUEsd0JBQ3ZFLHVCQUFDLFVBQUssV0FBVSx5QkFBeUIvTyxxQkFBVzhFLG9CQUFvQmdLLG1CQUFtQixLQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE2RjtBQUFBLDJCQUYvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEseUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBaUJBLEtBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBbUJBO0FBQUEsdUJBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBMkJBO0FBQUEsa0JBR0EsdUJBQUMsU0FDQztBQUFBLDJDQUFDLFNBQUksV0FBVSxpREFDYixpQ0FBQyxRQUFHLFdBQVUsK0RBQ1o7QUFBQSw2Q0FBQyxrQkFBZSxXQUFVLG1CQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5QztBQUFBLHNCQUFHO0FBQUEseUJBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLE9BQ2IsaUNBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEsNkNBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDBDQUF5Qyw4QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBdUU7QUFBQSx3QkFDdkUsdUJBQUMsVUFBSyxXQUFVLHlCQUF5QmhLLDhCQUFvQjBLLHFCQUFxQjFLLG9CQUFvQm1LLGlCQUFpQixPQUF2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUEySDtBQUFBLDJCQUY3SDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDBDQUF5QyxnQ0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBeUU7QUFBQSx3QkFDekUsdUJBQUMsVUFBSyxXQUFVLHlCQUNiLGlCQUFPbkssb0JBQW9Cd0ssb0JBQW9CLFdBQzVDeEssb0JBQW9Cd0ssaUJBQWlCQyxhQUNyQ3pLLG9CQUFvQndLLG1CQUFtQixPQUg3QztBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUlBO0FBQUEsMkJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFPQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLCtDQUFDLFVBQUssV0FBVSwwQ0FBeUMscUNBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQThFO0FBQUEsd0JBQzlFLHVCQUFDLFVBQUssV0FBVSx5QkFBeUJ4Syw4QkFBb0IrTyx3QkFBd0IsT0FBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBeUY7QUFBQSwyQkFGM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLCtDQUFDLFVBQUssV0FBVSwwQ0FBeUMsa0NBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTJFO0FBQUEsd0JBQzNFLHVCQUFDLFVBQUssV0FBVSxpREFDZDtBQUFBLGlEQUFDLFVBQU0vTztBQUFBQSxnREFBb0J4RixjQUFjO0FBQUEsNEJBQUU7QUFBQSwrQkFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBNEM7QUFBQSwwQkFDNUMsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLFdBQVcsbURBQ1J3RixvQkFBb0J4RixjQUFjLE1BQU0sS0FBSyxrQkFDN0N3RixvQkFBb0J4RixjQUFjLE1BQU0sS0FBSyxrQkFDOUMsWUFBWTtBQUFBLDhCQUVkLE9BQU8sRUFBRXNKLE9BQU8sR0FBRzlELG9CQUFvQnhGLGNBQWMsQ0FBQyxJQUFJO0FBQUE7QUFBQSw0QkFONUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQU9DLEtBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FTQTtBQUFBLDZCQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBWUE7QUFBQSwyQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQWVBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDBDQUF5Qyx1QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBZ0U7QUFBQSx3QkFDaEUsdUJBQUMsVUFBSyxXQUFVLFdBQ2QsaUNBQUMsVUFBSyxXQUFXLDhDQUNmd0Ysb0JBQW9CK0ksb0JBQW9CLFNBQ3BDLGdDQUNBLCtCQUErQixJQUVsQy9JLDhCQUFvQitJLG9CQUFvQixTQUFTLGVBQWUsZUFMbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBUUE7QUFBQSwyQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQVdBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsK0NBQUMsVUFBSyxXQUFVLDBDQUF5QywrQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBd0U7QUFBQSx3QkFDeEUsdUJBQUMsVUFBSyxXQUFVLHlCQUF5QjdOLHFCQUFXOEUsb0JBQW9CZ1AsU0FBUyxLQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFtRjtBQUFBLDJCQUZyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEseUJBaERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBaURBLEtBbERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBbURBO0FBQUEsdUJBMURGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBMkRBO0FBQUEsa0JBR0EsdUJBQUMsU0FBSSxXQUFVLDZEQUNiLGlDQUFDLE9BQUUsV0FBVSx5QkFBd0I7QUFBQTtBQUFBLHFCQUFjLG9CQUFJM1QsS0FBSyxHQUFFQyxtQkFBbUI7QUFBQSxvQkFBRTtBQUFBLHVCQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzRyxLQUR4RztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBblFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBb1FBO0FBQUE7QUFBQTtBQUFBLFlBN1VGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQThVQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx5R0FDYjtBQUFBLG1DQUFDLGtCQUFlLFdBQVUseUNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStEO0FBQUEsWUFDL0QsdUJBQUMsT0FBRSxpRUFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRDtBQUFBLFlBQ3BELHVCQUFDLE9BQUUsV0FBVSxnQkFBZSwrREFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkU7QUFBQSxlQUg3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsYUFwYUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNhQTtBQUFBLFFBSUYsdUJBQUMsU0FBSSxXQUFVLGtDQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBDQUF5Qyw2QkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsUUFBRyxXQUFVLGlEQUNaO0FBQUEsbUNBQUMsUUFBRywwRUFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RDtBQUFBLFlBQzlELHVCQUFDLFFBQUcscURBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUM7QUFBQSxZQUN6Qyx1QkFBQyxRQUFHLDZEQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlEO0FBQUEsWUFDakQsdUJBQUMsUUFBRyw2REFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRDtBQUFBLFlBQ2pELHVCQUFDLFFBQUcseURBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkM7QUFBQSxZQUM3Qyx1QkFBQyxRQUFHLDZEQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlEO0FBQUEsWUFDakQsdUJBQUMsUUFBRyw2REFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRDtBQUFBLFlBQ2pELHVCQUFDLFFBQUcsc0RBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEM7QUFBQSxZQUMxQyx1QkFBQyxRQUFHLGlFQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFEO0FBQUEsWUFDckQsdUJBQUMsUUFBRywrQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQztBQUFBLGVBVnJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxhQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxXQTNlRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNGVBO0FBQUEsU0FuZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9mQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU15QztBQUFBQSxRQUNOLFVBQVUsTUFBTUMsaUJBQWlCLEtBQUs7QUFBQSxRQUN0QyxRQUFRO0FBQUEsUUFDUixPQUFPO0FBQUEsUUFDUDtBQUFBLFFBQ0EsV0FBVTtBQUFBLFFBQ1YsT0FDRSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsUUFBRyxXQUFVLG9DQUFtQyxrQ0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QjtBQUFBO0FBQUEsY0FDOUI7QUFBQSxjQUNWLHVCQUFDLFVBQUssV0FBVSw2QkFDYkwsNEJBQWtCYixRQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLGVBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHFFQUFvRTtBQUFBO0FBQUEsWUFDekV1UixrQkFBa0I1VDtBQUFBQSxlQUQ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxRQUdGLGlDQUFDLFNBQUksV0FBVSxxQ0FDWjRULDRCQUFrQjVULFdBQVcsSUFDNUIsdUJBQUMsU0FBSSxXQUFVLG1EQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDRFQUNiLGlDQUFDLGNBQVcsV0FBVSw0QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEMsS0FEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsUUFBRyxXQUFVLHVDQUFzQyxrQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0U7QUFBQSxVQUN0RSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLHNFQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ1o0VCw0QkFBa0JsSjtBQUFBQSxVQUFJLENBQUM1SyxLQUFLMFUsVUFDM0I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDZDQUNaMVUsY0FBSWlDLFVBQ0gsbUNBQ0U7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxLQUFLakMsSUFBSTZUO0FBQUFBLHNCQUNULEtBQUs3VCxJQUFJTDtBQUFBQSxzQkFDVCxXQUFVO0FBQUEsc0JBQ1YsU0FBUyxNQUFNZ1MsY0FBYzNSLElBQUk2VCxLQUFLN1QsSUFBSUwsS0FBSztBQUFBO0FBQUEsb0JBSmpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJbUQ7QUFBQSxrQkFFbkQsdUJBQUMsU0FBSSxXQUFVLG9IQUNiO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFNBQVMsTUFBTWdTLGNBQWMzUixJQUFJNlQsS0FBSzdULElBQUlMLEtBQUs7QUFBQSxzQkFDL0MsV0FBVTtBQUFBLHNCQUVWO0FBQUEsK0NBQUMsU0FBTSxXQUFVLGFBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTBCO0FBQUEsd0JBQUc7QUFBQTtBQUFBO0FBQUEsb0JBSi9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUUE7QUFBQSxxQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWdCQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxvREFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSx5RUFDYixpQ0FBQyxjQUFXLFdBQVUsMkJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZDLEtBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsNkJBQTRCLDRCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxRDtBQUFBLHFCQUp2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBLEtBekJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBMkJBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLE9BQ2IsaUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEseUNBQUMsU0FDQztBQUFBLDJDQUFDLFFBQUcsV0FBVSw0Q0FBNENLLGNBQUlMLFNBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9FO0FBQUEsb0JBQ3BFLHVCQUFDLE9BQUUsV0FBVSxxREFDVkssY0FBSTZULElBQUljLFVBQVUzVSxJQUFJNlQsSUFBSWUsWUFBWSxHQUFHLElBQUksQ0FBQyxLQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDJDQUFDLFdBQVEsT0FBTSxvQkFDYjtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxTQUFTLE1BQU1qRCxjQUFjM1IsSUFBSTZULEtBQUs3VCxJQUFJTCxLQUFLO0FBQUEsd0JBQy9DLFdBQVU7QUFBQSx3QkFFVixpQ0FBQyxTQUFNLFdBQVUsYUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBMEI7QUFBQTtBQUFBLHNCQUo1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU9BO0FBQUEsb0JBQ0EsdUJBQUMsV0FBUSxPQUFNLHFCQUNiO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQU1LLElBQUk2VDtBQUFBQSx3QkFDVjtBQUFBLHdCQUNBLFFBQU87QUFBQSx3QkFDUCxLQUFJO0FBQUEsd0JBQ0osV0FBVTtBQUFBLHdCQUVWLGlDQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUErQjtBQUFBO0FBQUEsc0JBUGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBVUE7QUFBQSx1QkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFvQkE7QUFBQSxxQkEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE0QkEsS0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE4QkE7QUFBQTtBQUFBO0FBQUEsWUE3REthO0FBQUFBLFlBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQStEQTtBQUFBLFFBQ0QsS0FsRUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1FQSxLQS9FSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUZBO0FBQUE7QUFBQSxNQTNHRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUE0R0E7QUFBQSxJQUdDcFIsbUJBQ0MsdUJBQUMsU0FBSSxXQUFVLDhGQUNiLGlDQUFDLFNBQUksV0FBVSx5RUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSw4RUFDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxRQUFHLFdBQVUseUJBQXdCLGdDQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRDtBQUFBLFVBQ3RELHVCQUFDLE9BQUUsV0FBVSw4QkFBNkI7QUFBQTtBQUFBLFlBQzlCO0FBQUEsWUFDVix1QkFBQyxVQUFLLFdBQVUsZUFBZUYsNEJBQWtCYixRQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRDtBQUFBLGVBRnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsb0dBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTTtBQUNiZ0IsaUNBQW1CLEtBQUs7QUFDeEJnUSx3QkFBVTtBQUFBLFlBQ1o7QUFBQSxZQUNBLFdBQVU7QUFBQSxZQUE0QztBQUFBO0FBQUEsVUFMeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUE7QUFBQSxXQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0JBO0FBQUEsTUFFQSx1QkFBQyxVQUFLLFVBQVVYLGNBQWMsV0FBVSxpQkFFdEM7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdEQUF1RCxrQ0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFNO0FBQUEsZ0JBQ047QUFBQSxnQkFDQSxNQUFNM00sU0FBU0U7QUFBQUEsZ0JBQ2YsU0FBU2EsYUFBYWI7QUFBQUEsZ0JBQ3RCLGFBQWFlLHFCQUFxQmY7QUFBQUEsZ0JBQ2xDLFdBQVd3TDtBQUFBQSxnQkFDWCxVQUFVLENBQUNSLE1BQU1ELGlCQUFpQkMsR0FBRyxvQkFBb0I7QUFBQSxnQkFDekQsVUFBVSxNQUFNTyxpQkFBaUIsb0JBQW9CO0FBQUEsZ0JBQ3JEO0FBQUE7QUFBQSxjQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVMyQjtBQUFBLFlBRTNCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTTtBQUFBLGdCQUNOO0FBQUEsZ0JBQ0EsTUFBTXpMLFNBQVNLO0FBQUFBLGdCQUNmLFNBQVNVLGFBQWFWO0FBQUFBLGdCQUN0QixhQUFhWSxxQkFBcUJaO0FBQUFBLGdCQUNsQyxXQUFXcUw7QUFBQUEsZ0JBQ1gsVUFBVSxDQUFDUixNQUFNRCxpQkFBaUJDLEdBQUcsb0JBQW9CO0FBQUEsZ0JBQ3pELFVBQVUsTUFBTU8saUJBQWlCLG9CQUFvQjtBQUFBLGdCQUNyRDtBQUFBO0FBQUEsY0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFTMkI7QUFBQSxZQUUzQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU07QUFBQSxnQkFDTjtBQUFBLGdCQUNBLE1BQU16TCxTQUFTRztBQUFBQSxnQkFDZixTQUFTWSxhQUFhWjtBQUFBQSxnQkFDdEIsYUFBYWMscUJBQXFCZDtBQUFBQSxnQkFDbEMsV0FBV3VMO0FBQUFBLGdCQUNYLFVBQVUsQ0FBQ1IsTUFBTUQsaUJBQWlCQyxHQUFHLDRCQUE0QjtBQUFBLGdCQUNqRSxVQUFVLE1BQU1PLGlCQUFpQiw0QkFBNEI7QUFBQSxnQkFDN0Q7QUFBQTtBQUFBLGNBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUzJCO0FBQUEsWUFFM0I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFNO0FBQUEsZ0JBQ047QUFBQSxnQkFDQSxNQUFNekwsU0FBU0k7QUFBQUEsZ0JBQ2YsU0FBU1csYUFBYVg7QUFBQUEsZ0JBQ3RCLGFBQWFhLHFCQUFxQmI7QUFBQUEsZ0JBQ2xDLFdBQVdzTDtBQUFBQSxnQkFDWCxVQUFVLENBQUNSLE1BQU1ELGlCQUFpQkMsR0FBRywyQkFBMkI7QUFBQSxnQkFDaEUsVUFBVSxNQUFNTyxpQkFBaUIsMkJBQTJCO0FBQUEsZ0JBQzVEO0FBQUE7QUFBQSxjQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVMyQjtBQUFBLFlBRTNCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTTtBQUFBLGdCQUNOO0FBQUEsZ0JBQ0EsTUFBTXpMLFNBQVNRO0FBQUFBLGdCQUNmLFNBQVNPLGFBQWFQO0FBQUFBLGdCQUN0QixhQUFhUyxxQkFBcUJUO0FBQUFBLGdCQUNsQyxXQUFXa0w7QUFBQUEsZ0JBQ1gsVUFBVSxDQUFDUixNQUFNRCxpQkFBaUJDLEdBQUcscUJBQXFCO0FBQUEsZ0JBQzFELFVBQVUsTUFBTU8saUJBQWlCLHFCQUFxQjtBQUFBLGdCQUN0RDtBQUFBO0FBQUEsY0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFTMkI7QUFBQSxZQUUzQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU07QUFBQSxnQkFDTjtBQUFBLGdCQUNBLE1BQU16TCxTQUFTTztBQUFBQSxnQkFDZixTQUFTUSxhQUFhUjtBQUFBQSxnQkFDdEIsYUFBYVUscUJBQXFCVjtBQUFBQSxnQkFDbEMsV0FBV21MO0FBQUFBLGdCQUNYLFVBQVUsQ0FBQ1IsTUFBTUQsaUJBQWlCQyxHQUFHLHNCQUFzQjtBQUFBLGdCQUMzRCxVQUFVLE1BQU1PLGlCQUFpQixzQkFBc0I7QUFBQSxnQkFDdkQ7QUFBQTtBQUFBLGNBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUzJCO0FBQUEsWUFFM0I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFNO0FBQUEsZ0JBQ047QUFBQSxnQkFDQSxNQUFNekwsU0FBU007QUFBQUEsZ0JBQ2YsU0FBU1MsYUFBYVQ7QUFBQUEsZ0JBQ3RCLGFBQWFXLHFCQUFxQlg7QUFBQUEsZ0JBQ2xDLFdBQVdvTDtBQUFBQSxnQkFDWCxVQUFVLENBQUNSLE1BQU1ELGlCQUFpQkMsR0FBRyxrQkFBa0I7QUFBQSxnQkFDdkQsVUFBVSxNQUFNTyxpQkFBaUIsa0JBQWtCO0FBQUEsZ0JBQ25EO0FBQUE7QUFBQSxjQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVMyQjtBQUFBLFlBRTNCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTTtBQUFBLGdCQUNOO0FBQUEsZ0JBQ0EsTUFBTXpMLFNBQVNTO0FBQUFBLGdCQUNmLFNBQVNNLGFBQWFOO0FBQUFBLGdCQUN0QixhQUFhUSxxQkFBcUJSO0FBQUFBLGdCQUNsQyxXQUFXaUw7QUFBQUEsZ0JBQ1gsVUFBVSxDQUFDUixNQUFNRCxpQkFBaUJDLEdBQUcseUJBQXlCO0FBQUEsZ0JBQzlELFVBQVUsTUFBTU8saUJBQWlCLHlCQUF5QjtBQUFBLGdCQUMxRDtBQUFBO0FBQUEsY0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFTMkI7QUFBQSxZQUUzQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU07QUFBQSxnQkFDTjtBQUFBLGdCQUNBLE1BQU16TCxTQUFTVTtBQUFBQSxnQkFDZixTQUFTSyxhQUFhTDtBQUFBQSxnQkFDdEIsYUFBYU8scUJBQXFCUDtBQUFBQSxnQkFDbEMsV0FBV2dMO0FBQUFBLGdCQUNYLFVBQVUsQ0FBQ1IsTUFBTUQsaUJBQWlCQyxHQUFHLGtCQUFrQjtBQUFBLGdCQUN2RCxVQUFVLE1BQU1PLGlCQUFpQixrQkFBa0I7QUFBQSxnQkFDbkQ7QUFBQTtBQUFBLGNBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUzJCO0FBQUEsZUFsRzdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0dBO0FBQUEsYUF4R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlHQTtBQUFBLFFBR0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFNBQUksV0FBVSx3REFDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSxxQ0FBb0MseUNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNDak4sZUFBZXZFLFdBQVcsS0FDekI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUzZSO0FBQUFBLGdCQUNULFdBQVU7QUFBQSxnQkFFVjtBQUFBLHlDQUFDLFNBQUksV0FBVSxXQUFVLE1BQUssUUFBTyxRQUFPLGdCQUFlLFNBQVEsYUFDakUsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxhQUFhLEdBQUcsR0FBRSxvQkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcUYsS0FEdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUFNO0FBQUE7QUFBQTtBQUFBLGNBUFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU0E7QUFBQSxlQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBO0FBQUEsVUFFQ3ROLGVBQWV2RSxXQUFXLElBQ3pCLHVCQUFDLFNBQUksV0FBVSxpRkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxtQ0FBa0MsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUN6RixpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQWEsR0FBRyxHQUFFLDBIQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyTCxLQUQ3TDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsc0JBQXFCLHVDQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5RDtBQUFBLFlBQ3pEO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVM2UjtBQUFBQSxnQkFDVCxXQUFVO0FBQUEsZ0JBQTREO0FBQUE7QUFBQSxjQUh4RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLGVBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNadE4seUJBQWVtRztBQUFBQSxZQUFJLENBQUM1SyxRQUNuQix1QkFBQyxTQUFpQixXQUFVLG9EQUMxQjtBQUFBLHFDQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSw2QkFBNEIsOEJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdEO0FBQUEsZ0JBQ3hEO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTLE1BQU1rUyxvQkFBb0JsUyxJQUFJc04sRUFBRTtBQUFBLG9CQUN6QyxXQUFVO0FBQUEsb0JBRVYsaUNBQUMsU0FBSSxXQUFVLFdBQVUsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUNqRSxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQWEsR0FBRyxHQUFFLGtJQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtTSxLQURyTTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUE7QUFBQSxrQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUUE7QUFBQSxtQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVdBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSx1Q0FBQyxTQUNDO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQyw2QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxPQUFPdE4sSUFBSXVDO0FBQUFBLHNCQUNYLFVBQVUsQ0FBQzRPLE1BQU1tQix3QkFBd0J0UyxJQUFJc04sSUFBSTZELEVBQUVFLE9BQU8vUSxLQUFLO0FBQUEsc0JBQy9ELFdBQVU7QUFBQSxzQkFDVixhQUFZO0FBQUE7QUFBQSxvQkFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS2dFO0FBQUEsa0JBRS9ETixJQUFJd04sZ0JBQWdCLENBQUN4TixJQUFJdUMsUUFDeEIsdUJBQUMsT0FBRSxXQUFVLCtCQUE4QjtBQUFBO0FBQUEsb0JBQVl2QyxJQUFJd047QUFBQUEsdUJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdFO0FBQUEscUJBWjVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBY0E7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQU07QUFBQSxvQkFDTixNQUFNeE4sSUFBSXNCO0FBQUFBLG9CQUNWLFNBQVN0QixJQUFJdUI7QUFBQUEsb0JBQ2IsYUFBYXZCLElBQUl3QjtBQUFBQSxvQkFDakIsV0FBV21RO0FBQUFBLG9CQUNYLFVBQVUsQ0FBQ1IsTUFBTW9CLDhCQUE4QnBCLEdBQUduUixJQUFJc04sRUFBRTtBQUFBLG9CQUN4RCxVQUFVLE1BQU1rRix3QkFBd0J4UyxJQUFJc04sRUFBRTtBQUFBLG9CQUM5QztBQUFBO0FBQUEsa0JBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVEyQixLQVQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVdBO0FBQUEsbUJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNEJBO0FBQUEsaUJBekNRdE4sSUFBSXNOLElBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQ0E7QUFBQSxVQUNELEtBN0NIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBOENBO0FBQUEsYUFoRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtGQTtBQUFBLFFBR0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFFBQUcsV0FBVSx3REFBdUQsK0JBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT3JILFNBQVNXLFFBQVFyRTtBQUFBQSxrQkFDeEIsVUFBVSxDQUFDNE8sTUFBTVcsd0JBQXdCWCxHQUFHLE1BQU07QUFBQSxrQkFDbEQsV0FBVTtBQUFBLGtCQUNWLGFBQVk7QUFBQTtBQUFBLGdCQUxkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtrQztBQUFBLGlCQVRwQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVdBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU9sTCxTQUFTVyxRQUFRN0I7QUFBQUEsa0JBQ3hCLFVBQVUsQ0FBQ29NLE1BQU1XLHdCQUF3QlgsR0FBRyxhQUFhO0FBQUEsa0JBQ3pELFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUE7QUFBQSxnQkFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLa0M7QUFBQSxpQkFUcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFNO0FBQUEsZ0JBQ047QUFBQSxnQkFDQSxNQUFNbEwsU0FBU1csUUFBUUM7QUFBQUEsZ0JBQ3ZCLFNBQVNHLGFBQWFIO0FBQUFBLGdCQUN0QixhQUFhSyxxQkFBcUJMO0FBQUFBLGdCQUNsQyxXQUFXOEs7QUFBQUEsZ0JBQ1gsVUFBVSxDQUFDUixNQUFNRCxpQkFBaUJDLEdBQUcseUJBQXlCO0FBQUEsZ0JBQzlELFVBQVUsTUFBTU8saUJBQWlCLHlCQUF5QjtBQUFBLGdCQUMxRDtBQUFBO0FBQUEsY0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFTMkI7QUFBQSxZQUUzQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU07QUFBQSxnQkFDTjtBQUFBLGdCQUNBLE1BQU16TCxTQUFTVyxRQUFRRTtBQUFBQSxnQkFDdkIsU0FBU0UsYUFBYUY7QUFBQUEsZ0JBQ3RCLGFBQWFJLHFCQUFxQko7QUFBQUEsZ0JBQ2xDLFdBQVc2SztBQUFBQSxnQkFDWCxVQUFVLENBQUNSLE1BQU1ELGlCQUFpQkMsR0FBRyx3QkFBd0I7QUFBQSxnQkFDN0QsVUFBVSxNQUFNTyxpQkFBaUIsd0JBQXdCO0FBQUEsZ0JBQ3pEO0FBQUE7QUFBQSxjQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVMyQjtBQUFBLFlBRTNCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTTtBQUFBLGdCQUNOO0FBQUEsZ0JBQ0EsTUFBTXpMLFNBQVNXLFFBQVFHO0FBQUFBLGdCQUN2QixTQUFTQyxhQUFhRDtBQUFBQSxnQkFDdEIsYUFBYUcscUJBQXFCSDtBQUFBQSxnQkFDbEMsV0FBVzRLO0FBQUFBLGdCQUNYLFVBQVUsQ0FBQ1IsTUFBTUQsaUJBQWlCQyxHQUFHLGlCQUFpQjtBQUFBLGdCQUN0RCxVQUFVLE1BQU1PLGlCQUFpQixpQkFBaUI7QUFBQSxnQkFDbEQ7QUFBQTtBQUFBLGNBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUzJCO0FBQUEsZUF4RDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMERBO0FBQUEsYUE5REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStEQTtBQUFBLFFBR0MvTSxpQkFDQyx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLHFDQUFvQyxpQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUU7QUFBQSxZQUNuRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU1DLGlCQUFpQixLQUFLO0FBQUEsZ0JBQ3JDLFdBQVU7QUFBQSxnQkFFVjtBQUFBLHlDQUFDLFNBQUksV0FBVSxXQUFVLE1BQUssUUFBTyxRQUFPLGdCQUFlLFNBQVEsYUFDakUsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxhQUFhLEdBQUcsR0FBRSxrSUFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbU0sS0FEck07QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUFNO0FBQUE7QUFBQTtBQUFBLGNBUFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU0E7QUFBQSxlQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxnQkFDL0MsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT0MsY0FBY3RDO0FBQUFBLGtCQUNyQixVQUFVLENBQUM0TyxNQUFNck0saUJBQWlCLEVBQUUsR0FBR0QsZUFBZXRDLE1BQU00TyxFQUFFRSxPQUFPL1EsTUFBTSxDQUFDO0FBQUEsa0JBQzVFLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUE7QUFBQSxnQkFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLb0M7QUFBQSxpQkFUdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGdCQUNqRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFPdUUsY0FBY0U7QUFBQUEsa0JBQ3JCLFVBQVUsQ0FBQ29NLE1BQU1yTSxpQkFBaUIsRUFBRSxHQUFHRCxlQUFlRSxhQUFhb00sRUFBRUUsT0FBTy9RLE1BQU0sQ0FBQztBQUFBLGtCQUNuRixXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBO0FBQUEsZ0JBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS2tDO0FBQUEsaUJBVHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLGdDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT3VFLGNBQWNHO0FBQUFBLGtCQUNyQixVQUFVLENBQUNtTSxNQUFNck0saUJBQWlCLEVBQUUsR0FBR0QsZUFBZUcsT0FBT21NLEVBQUVFLE9BQU8vUSxNQUFNLENBQUM7QUFBQSxrQkFDN0UsV0FBVTtBQUFBLGtCQUNWLGFBQVk7QUFBQTtBQUFBLGdCQUxkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUttQztBQUFBLGlCQVRyQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVdBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyxrQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU91RSxjQUFjSTtBQUFBQSxrQkFDckIsVUFBVSxDQUFDa00sTUFBTXJNLGlCQUFpQixFQUFFLEdBQUdELGVBQWVJLFNBQVNrTSxFQUFFRSxPQUFPL1EsTUFBTSxDQUFDO0FBQUEsa0JBQy9FLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUE7QUFBQSxnQkFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLNkI7QUFBQSxpQkFUL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFNO0FBQUEsZ0JBQ04sTUFBTXVFLGNBQWNLO0FBQUFBLGdCQUNwQixTQUFTRyxrQkFBa0JIO0FBQUFBLGdCQUMzQixhQUFhSyx1QkFBdUJMO0FBQUFBLGdCQUNwQyxXQUFXeU07QUFBQUEsZ0JBQ1gsVUFBVSxDQUFDUixNQUFNdUIsMEJBQTBCdkIsR0FBRyxhQUFhO0FBQUEsZ0JBQzNELFVBQVUsTUFBTXdCLDBCQUEwQixhQUFhO0FBQUEsZ0JBQ3ZEO0FBQUE7QUFBQSxjQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVEyQjtBQUFBLFlBRTNCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTTtBQUFBLGdCQUNOLE1BQU05TixjQUFjTTtBQUFBQSxnQkFDcEIsU0FBU0Usa0JBQWtCRjtBQUFBQSxnQkFDM0IsYUFBYUksdUJBQXVCSjtBQUFBQSxnQkFDcEMsV0FBV3dNO0FBQUFBLGdCQUNYLFVBQVUsQ0FBQ1IsTUFBTXVCLDBCQUEwQnZCLEdBQUcsU0FBUztBQUFBLGdCQUN2RCxVQUFVLE1BQU13QiwwQkFBMEIsU0FBUztBQUFBLGdCQUNuRDtBQUFBO0FBQUEsY0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRMkI7QUFBQSxZQUUzQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU07QUFBQSxnQkFDTixNQUFNOU4sY0FBY087QUFBQUEsZ0JBQ3BCLFNBQVNDLGtCQUFrQkQ7QUFBQUEsZ0JBQzNCLGFBQWFHLHVCQUF1Qkg7QUFBQUEsZ0JBQ3BDLFdBQVd1TTtBQUFBQSxnQkFDWCxVQUFVLENBQUNSLE1BQU11QiwwQkFBMEJ2QixHQUFHLE9BQU87QUFBQSxnQkFDckQsVUFBVSxNQUFNd0IsMEJBQTBCLE9BQU87QUFBQSxnQkFDakQ7QUFBQTtBQUFBLGNBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUTJCO0FBQUEsZUE3RTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0VBO0FBQUEsYUE3RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThGQTtBQUFBLFFBSUQsQ0FBQ2hPLGlCQUNBLHVCQUFDLFNBQUksV0FBVSxvQkFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBUyxNQUFNQyxpQkFBaUIsSUFBSTtBQUFBLFlBQ3BDLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsU0FBSSxXQUFVLFdBQVUsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUNqRSxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQWEsR0FBRyxHQUFFLDBGQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEySixLQUQ3SjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FBTTtBQUFBO0FBQUE7QUFBQSxVQVBSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFJRix1QkFBQyxTQUFJLFdBQVUscUVBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsU0FBUyxNQUFNO0FBQ2JyQixtQ0FBbUIsS0FBSztBQUN4QmdRLDBCQUFVO0FBQUEsY0FDWjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBQThGO0FBQUE7QUFBQSxZQU4xRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFTQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFVBQVU3UDtBQUFBQSxjQUNWLFdBQVU7QUFBQSxjQUVUQSxzQkFDQyx1QkFBQyxVQUFLLFdBQVUscUJBQ2Q7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsOENBQTZDLE1BQUssUUFBTyxTQUFRLGFBQzlFO0FBQUEseUNBQUMsWUFBTyxXQUFVLGNBQWEsSUFBRyxNQUFLLElBQUcsTUFBSyxHQUFFLE1BQUssUUFBTyxnQkFBZSxhQUFZLE9BQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTRGO0FBQUEsa0JBQzVGLHVCQUFDLFVBQUssV0FBVSxjQUFhLE1BQUssZ0JBQWUsR0FBRSxxSEFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcUs7QUFBQSxxQkFGdks7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUFNO0FBQUEsbUJBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFNQSxJQUVBO0FBQUE7QUFBQSxZQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWdCQTtBQUFBLGFBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0QkE7QUFBQSxXQXBaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcVpBO0FBQUEsU0E1YUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZhQSxLQTlhRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK2FBO0FBQUEsT0E5aUNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnakNBO0FBRUo7QUFBQ2YsR0EzNURRRCxtQkFBaUI7QUFBQSxVQUNQNUUsYUFDQUMsV0FBVztBQUFBO0FBQUE4VyxNQUZyQm5TO0FBNjVEVCxlQUFlQTtBQUFrQixJQUFBaEMsSUFBQStCLEtBQUFvUztBQUFBQyxhQUFBcFUsSUFBQTtBQUFBb1UsYUFBQXJTLEtBQUE7QUFBQXFTLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsIlNlbGVjdCIsIlNwaW4iLCJNb2RhbCIsIlByb2dyZXNzIiwiSW1hZ2UiLCJUb29sdGlwIiwibWVzc2FnZSIsInVzZU5hdmlnYXRlIiwidXNlTG9jYXRpb24iLCJOYXZiYXIiLCJTaWRlYmFyIiwiQ2lyY3VsYXJMb2FkZXIiLCJhcGkiLCJjb21wYW55TG9nbyIsImh0bWwyY2FudmFzIiwianNQREYiLCJJb0V5ZSIsIklvRG9jdW1lbnQiLCJJb0Nsb3NlIiwiSW9Eb3dubG9hZCIsIklvUGVyc29uIiwiSW9DYWxsIiwiSW9NYWlsIiwiSW9Mb2NhdGlvbiIsIklvRG9jdW1lbnRUZXh0IiwiSW9XYWxsZXQiLCJJb0J1c2luZXNzIiwiSW9DYXJkIiwiSW9DYWxlbmRhciIsIklvQ2hlY2ttYXJrQ2lyY2xlIiwiSW9UaW1lT3V0bGluZSIsIklvUHJpbnRPdXRsaW5lIiwiSW9TaGFyZU91dGxpbmUiLCJCcmVhZGNydW1iIiwiUkVRVUlSRURfRE9DVU1FTlRTIiwia2V5IiwibGFiZWwiLCJjYWxjdWxhdGVQZXJjZW50YWdlRnJvbVVzZXJEb2MiLCJ1c2VyRG9jIiwidXBsb2FkZWRDb3VudCIsImZvckVhY2giLCJkb2MiLCJwZXJjZW50YWdlIiwibGVuZ3RoIiwiTWF0aCIsInJvdW5kIiwiSW5mb0l0ZW0iLCJ2YWx1ZSIsImZ1bGxXaWR0aCIsImljb24iLCJJY29uIiwiX2MiLCJmb3JtYXREYXRlIiwiZGF0ZVN0cmluZyIsImRhdGUiLCJEYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiZGF5IiwibW9udGgiLCJ5ZWFyIiwiRG9jdW1lbnRVcGxvYWRGaWVsZCIsInJlcXVpcmVkIiwib25DaGFuZ2UiLCJmaWxlIiwicHJldmlldyIsImV4aXN0aW5nVXJsIiwib25QcmV2aWV3Iiwib25EZWxldGUiLCJmb3JtYXRCeXRlcyIsImlucHV0SWQiLCJyZXBsYWNlIiwicmFuZG9tIiwidG9TdHJpbmciLCJzdWJzdHIiLCJpc0ltYWdlIiwidHlwZSIsInN0YXJ0c1dpdGgiLCJoYXNFeGlzdGluZ0RvYyIsImlzRXhpc3RpbmdJbWFnZSIsIm1hdGNoIiwibmFtZSIsInNpemUiLCJfYzIiLCJDdXN0b21lckRvY3VtZW50cyIsIl9zIiwibmF2aWdhdGUiLCJsb2NhdGlvbiIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwiY3VzdG9tZXJzIiwic2V0Q3VzdG9tZXJzIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzZWxlY3RlZEN1c3RvbWVyIiwic2V0U2VsZWN0ZWRDdXN0b21lciIsInNob3dVcGxvYWRNb2RhbCIsInNldFNob3dVcGxvYWRNb2RhbCIsInNob3dWaWV3TW9kYWwiLCJzZXRTaG93Vmlld01vZGFsIiwidXBsb2FkaW5nIiwic2V0VXBsb2FkaW5nIiwidG9hc3QiLCJzZXRUb2FzdCIsInNob3ciLCJwcmV2aWV3SW1hZ2UiLCJzZXRQcmV2aWV3SW1hZ2UiLCJwcmV2aWV3VGl0bGUiLCJzZXRQcmV2aWV3VGl0bGUiLCJpbml0aWFsaXppbmciLCJzZXRJbml0aWFsaXppbmciLCJleGlzdGluZ0RvY3VtZW50cyIsInNldEV4aXN0aW5nRG9jdW1lbnRzIiwiZmV0Y2hpbmdEb2N1bWVudHMiLCJzZXRGZXRjaGluZ0RvY3VtZW50cyIsIm90aGVyRG9jdW1lbnRzIiwic2V0T3RoZXJEb2N1bWVudHMiLCJzaG93R3VhcmFudG9yIiwic2V0U2hvd0d1YXJhbnRvciIsImd1YXJhbnRvckRhdGEiLCJzZXRHdWFyYW50b3JEYXRhIiwicGhvbmVOdW1iZXIiLCJlbWFpbCIsImFkZHJlc3MiLCJhYWRoYXJGcm9udCIsInBhbkNhcmQiLCJwaG90byIsImd1YXJhbnRvclByZXZpZXdzIiwic2V0R3VhcmFudG9yUHJldmlld3MiLCJleGlzdGluZ0d1YXJhbnRvclVybHMiLCJzZXRFeGlzdGluZ0d1YXJhbnRvclVybHMiLCJmdWxsQ3VzdG9tZXJEZXRhaWxzIiwic2V0RnVsbEN1c3RvbWVyRGV0YWlscyIsImxvYWRpbmdEZXRhaWxzIiwic2V0TG9hZGluZ0RldGFpbHMiLCJpc0N1c3RvbWVyRGV0YWlsc09wZW4iLCJzZXRJc0N1c3RvbWVyRGV0YWlsc09wZW4iLCJyZXBsYWNlZERvY3VtZW50cyIsInNldFJlcGxhY2VkRG9jdW1lbnRzIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInVzZXJfcHJvZmlsZV9waG90byIsInVzZXJfYWRoYXJjYXJkX2Zyb250X3Bob3RvIiwidXNlcl9hZGhhcmNhcmRfYmFja19waG90byIsInVzZXJfcGFuY2FyZF9waG90byIsInVzZXJfY2hlcXVlX2xlYWYiLCJiYW5rX3N0YXRlbWVudF9tb250aCIsImJhbmtfcGFzc2Jvb2tfcGhvdG8iLCJidXNpbmVzc19kb2N1bWVudF9wcm9vZiIsInVzZXJfc2FsYXJ5X3NsaXAiLCJub21pbmVlIiwidXNlcl9ub21pbmVlX2FkaGFyY2FyZF9mcm9udF9waG90byIsInVzZXJfbm9taW5lZV9hZGhhcmNhcmRfYmFja19waG90byIsInVzZXJfbm9taW5lZV9wYW5jYXJkX3Bob3RvIiwiZmlsZVByZXZpZXdzIiwic2V0RmlsZVByZXZpZXdzIiwiZXhpc3RpbmdEb2N1bWVudFVybHMiLCJzZXRFeGlzdGluZ0RvY3VtZW50VXJscyIsImJ5dGVzIiwiZGVjaW1hbHMiLCJrIiwiZG0iLCJzaXplcyIsImkiLCJmbG9vciIsImxvZyIsInBhcnNlRmxvYXQiLCJwb3ciLCJ0b0ZpeGVkIiwic2hvd1RvYXN0Iiwic2V0VGltZW91dCIsImhhbmRsZURvd25sb2FkUERGIiwiZWxlbWVudCIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJlcnJvciIsImhpZGVNc2ciLCJjbG9uZSIsImNsb25lTm9kZSIsImFjdGlvbkJ1dHRvbnMiLCJxdWVyeVNlbGVjdG9yQWxsIiwiYnRuIiwicmVtb3ZlIiwic2VjdGlvbnMiLCJzZWN0aW9uIiwic3R5bGUiLCJwYWdlQnJlYWtJbnNpZGUiLCJicmVha0luc2lkZSIsInRlbXBDb250YWluZXIiLCJjcmVhdGVFbGVtZW50IiwicG9zaXRpb24iLCJsZWZ0IiwidG9wIiwid2lkdGgiLCJiYWNrZ3JvdW5kIiwicGFkZGluZyIsInpJbmRleCIsImFwcGVuZENoaWxkIiwiYm9keSIsIlByb21pc2UiLCJyZXNvbHZlIiwiY2FudmFzIiwic2NhbGUiLCJ1c2VDT1JTIiwiYWxsb3dUYWludCIsImJhY2tncm91bmRDb2xvciIsImxvZ2dpbmciLCJoZWlnaHQiLCJzY3JvbGxIZWlnaHQiLCJvbmNsb25lIiwiaW1hZ2VzIiwiYWxsIiwiQXJyYXkiLCJmcm9tIiwibWFwIiwiaW1nIiwiY29tcGxldGUiLCJvbmxvYWQiLCJvbmVycm9yIiwicmVtb3ZlQ2hpbGQiLCJpbWdEYXRhIiwidG9EYXRhVVJMIiwicGRmIiwib3JpZW50YXRpb24iLCJ1bml0IiwiZm9ybWF0IiwicGRmV2lkdGgiLCJpbnRlcm5hbCIsInBhZ2VTaXplIiwiZ2V0V2lkdGgiLCJpbWdIZWlnaHQiLCJwYWdlSGVpZ2h0IiwiZ2V0SGVpZ2h0IiwidG90YWxQYWdlcyIsImNlaWwiLCJhZGRQYWdlIiwieU9mZnNldCIsImFkZEltYWdlIiwiZmlsZU5hbWUiLCJjdXN0b21lcl9pZCIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJzYXZlIiwiZGVzdHJveSIsInN1Y2Nlc3MiLCJjb25zb2xlIiwiZmV0Y2hVc2VyRG9jdW1lbnRzIiwidXNlcklkIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwiZG9jdW1lbnRzRGF0YSIsImlzQXJyYXkiLCJleGlzdGluZ1VybHMiLCJvdGhlcl9kb2N1bWVudHNfbmFtZSIsIm90aGVyX2RvY3VtZW50c19waG90byIsImlkIiwibm93IiwiZXhpc3RpbmdOYW1lIiwibm9taW5lZV9uYW1lIiwicHJldiIsIm5vbWluZWVfcGhvbmUiLCJmZXRjaEN1c3RvbWVycyIsImFsbFVzZXJzIiwidXNlcnMiLCJmb3JtYXR0ZWRDdXN0b21lcnMiLCJ1c2VyIiwiX2lkIiwiZnVsbF9uYW1lIiwicGhvbmUiLCJwaG9uZV9udW1iZXIiLCJwaW5jb2RlIiwiYWRoYWFyX25vIiwicGFuX25vIiwiYXBwcm92YWxfc3RhdHVzIiwidHJhY2tfc291cmNlIiwicmVmZXJyYWxfdHlwZSIsInJlZmVycmVkX2FnZW50IiwicmVmZXJyZWRfY3VzdG9tZXIiLCJqb2luaW5nX2RhdGUiLCJhbHRlcm5hdGVfbnVtYmVyIiwiYmFua19JRlNDX2NvZGUiLCJiYW5rX2FjY291bnRfbnVtYmVyIiwiYmFua19icmFuY2hfbmFtZSIsImJhbmtfbmFtZSIsImRhdGVvZmJpcnRoIiwiZGlzdHJpY3QiLCJmYXRoZXJfbmFtZSIsImdlbmRlciIsIm1hcml0YWxfc3RhdHVzIiwibmF0aW9uYWxpdHkiLCJub21pbmVlX2RhdGVvZmJpcnRoIiwibm9taW5lZV9waG9uZV9udW1iZXIiLCJub21pbmVlX3JlbGF0aW9uc2hpcCIsInJlZmVycmFsX25hbWUiLCJyZWdpc3RyYXRpb25fZGF0ZSIsInN0YXRlIiwidGFsdWsiLCJ0aXRsZSIsImNvbGxlY3Rpb25fYXJlYSIsInJvdXRlX25hbWUiLCJyZWZlcnJlZF9lbXBsb3llZSIsImNoZWNrVXJsUGFyYW1zQW5kU2VsZWN0Q3VzdG9tZXIiLCJjdXN0b21lcnNMaXN0IiwicGFyYW1zIiwiVVJMU2VhcmNoUGFyYW1zIiwic2VhcmNoIiwiYXVjdGlvbklkIiwiY3VzdG9tZXIiLCJmaW5kIiwiYyIsImRvY3VtZW50UGVyY2VudGFnZSIsImhhbmRsZUN1c3RvbWVyU2VsZWN0IiwiY3VzdG9tZXJJZCIsInNlbGVjdGVkIiwiZG9jdW1lbnRzIiwiaGFuZGxlRmlsZUNoYW5nZSIsImUiLCJmaWVsZCIsInRhcmdldCIsImZpbGVzIiwicHJldmlld1VybCIsIlVSTCIsImNyZWF0ZU9iamVjdFVSTCIsImhhbmRsZUZpbGVSZW1vdmUiLCJoYW5kbGVQcmV2aWV3IiwiaW1hZ2VVcmwiLCJoYW5kbGVDYW5jZWxQcmV2aWV3IiwiaGFuZGxlTm9taW5lZVRleHRDaGFuZ2UiLCJhZGRPdGhlckRvY3VtZW50Iiwid2FybmluZyIsIm5ld0lkIiwicmVtb3ZlT3RoZXJEb2N1bWVudCIsImRvY1RvUmVtb3ZlIiwicmV2b2tlT2JqZWN0VVJMIiwiZmlsdGVyIiwidXBkYXRlT3RoZXJEb2N1bWVudE5hbWUiLCJoYW5kbGVPdGhlckRvY3VtZW50RmlsZUNoYW5nZSIsInJlbW92ZU90aGVyRG9jdW1lbnRGaWxlIiwiZG9jVG9VcGRhdGUiLCJoYW5kbGVHdWFyYW50b3JGaWxlQ2hhbmdlIiwiaGFuZGxlR3VhcmFudG9yRmlsZVJlbW92ZSIsImhhbmRsZVN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwidXBsb2FkRm9ybURhdGEiLCJGb3JtRGF0YSIsImFwcGVuZCIsImZpbGVGaWVsZHMiLCJub21pbmVlRmllbGRzIiwib3RoZXJEb2MiLCJ0cmltIiwicG9zdCIsImhlYWRlcnMiLCJyZXNldEZvcm0iLCJPYmplY3QiLCJ2YWx1ZXMiLCJvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIiLCJnZXRVcGxvYWRlZERvY3VtZW50cyIsInB1c2giLCJ1cmwiLCJ1cGxvYWRlZERvY3VtZW50cyIsIm1heFdpZHRoIiwiaW5wdXQiLCJvcHRpb24iLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwidW5kZWZpbmVkIiwic3JjIiwic3RvcFByb3BhZ2F0aW9uIiwidmlsbGFnZSIsImNvbGxlY3Rpb25fZXhlY3V0aXZlIiwiY3JlYXRlZEF0IiwiaW5kZXgiLCJzdWJzdHJpbmciLCJsYXN0SW5kZXhPZiIsIl9jMyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDdXN0b21lckRvY3VtZW50cy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBTZWxlY3QsIFNwaW4sIE1vZGFsLCBQcm9ncmVzcywgSW1hZ2UsIFRvb2x0aXAsIG1lc3NhZ2UgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSwgdXNlTG9jYXRpb24gfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBjb21wYW55TG9nbyBmcm9tICcuLi9hc3NldHMvaW1hZ2VzL215Y2hpdHMucG5nJztcclxuaW1wb3J0IGh0bWwyY2FudmFzIGZyb20gJ2h0bWwyY2FudmFzJztcclxuaW1wb3J0IGpzUERGIGZyb20gJ2pzcGRmJztcclxuaW1wb3J0IHsgXHJcbiAgSW9FeWUsIFxyXG4gIElvRG9jdW1lbnQsIFxyXG4gIElvQ2xvc2UsIFxyXG4gIElvRG93bmxvYWQsXHJcbiAgSW9QZXJzb24sXHJcbiAgSW9DYWxsLFxyXG4gIElvTWFpbCxcclxuICBJb0xvY2F0aW9uLFxyXG4gIElvRG9jdW1lbnRUZXh0LFxyXG4gIElvV2FsbGV0LFxyXG4gIElvQnVzaW5lc3MsXHJcbiAgSW9DYXJkLFxyXG4gIElvQ2FsZW5kYXIsXHJcbiAgSW9DaGVja21hcmtDaXJjbGUsXHJcbiAgSW9UaW1lT3V0bGluZSxcclxuICBJb1ByaW50T3V0bGluZSxcclxuICBJb1NoYXJlT3V0bGluZVxyXG59IGZyb20gXCJyZWFjdC1pY29ucy9pbzVcIjtcclxuaW1wb3J0IEJyZWFkY3J1bWIgZnJvbSBcIi4uL2hlbHBlcnMvQnJlYWRjcnVtYlwiO1xyXG5cclxuXHJcbi8vIFJlcXVpcmVkIGRvY3VtZW50cyBsaXN0IGZvciBwZXJjZW50YWdlIGNhbGN1bGF0aW9uXHJcbmNvbnN0IFJFUVVJUkVEX0RPQ1VNRU5UUyA9IFtcclxuICB7IGtleTogXCJ1c2VyX3Byb2ZpbGVfcGhvdG9cIiwgbGFiZWw6IFwiUGhvdG9cIiB9LFxyXG4gIHsga2V5OiBcInVzZXJfYWRoYXJjYXJkX2Zyb250X3Bob3RvXCIsIGxhYmVsOiBcIkFhZGhhciBDYXJkIChGcm9udClcIiB9LFxyXG4gIHsga2V5OiBcInVzZXJfYWRoYXJjYXJkX2JhY2tfcGhvdG9cIiwgbGFiZWw6IFwiQWFkaGFyIENhcmQgKEJhY2spXCIgfSxcclxuICB7IGtleTogXCJ1c2VyX3BhbmNhcmRfcGhvdG9cIiwgbGFiZWw6IFwiUEFOIENhcmRcIiB9LFxyXG4gIHsga2V5OiBcInVzZXJfY2hlcXVlX2xlYWZcIiwgbGFiZWw6IFwiQ2hlcXVlIExlYWZcIiB9LFxyXG4gIHsga2V5OiBcImJhbmtfc3RhdGVtZW50X21vbnRoXCIsIGxhYmVsOiBcIkJhbmsgU3RhdGVtZW50IC0gTW9udGggMVwiIH0sXHJcbiAgeyBrZXk6IFwiYmFua19wYXNzYm9va19waG90b1wiLCBsYWJlbDogXCJQYXNzYm9vayBQaG90b1wiIH0sXHJcbiAgeyBrZXk6IFwiYnVzaW5lc3NfZG9jdW1lbnRfcHJvb2ZcIiwgbGFiZWw6IFwiQnVzaW5lc3MgUHJvb2ZcIiB9LFxyXG4gIHsga2V5OiBcInVzZXJfc2FsYXJ5X3NsaXBcIiwgbGFiZWw6IFwiU2FsYXJ5IFNsaXBcIiB9LFxyXG4gIHtcclxuICAgIGtleTogXCJ1c2VyX25vbWluZWVfYWRoYXJjYXJkX2Zyb250X3Bob3RvXCIsXHJcbiAgICBsYWJlbDogXCJOb21pbmVlIEFhZGhhciAoRnJvbnQpXCIsXHJcbiAgfSxcclxuICB7IGtleTogXCJ1c2VyX25vbWluZWVfYWRoYXJjYXJkX2JhY2tfcGhvdG9cIiwgbGFiZWw6IFwiTm9taW5lZSBBYWRoYXIgKEJhY2spXCIgfSxcclxuICB7IGtleTogXCJ1c2VyX25vbWluZWVfcGFuY2FyZF9waG90b1wiLCBsYWJlbDogXCJOb21pbmVlIFBBTiBDYXJkXCIgfSxcclxuXTtcclxuXHJcbmNvbnN0IGNhbGN1bGF0ZVBlcmNlbnRhZ2VGcm9tVXNlckRvYyA9ICh1c2VyRG9jKSA9PiB7XHJcbiAgaWYgKCF1c2VyRG9jKSByZXR1cm4gMDtcclxuICBsZXQgdXBsb2FkZWRDb3VudCA9IDA7XHJcbiAgUkVRVUlSRURfRE9DVU1FTlRTLmZvckVhY2goKGRvYykgPT4ge1xyXG4gICAgaWYgKHVzZXJEb2NbZG9jLmtleV0pIHtcclxuICAgICAgdXBsb2FkZWRDb3VudCsrO1xyXG4gICAgfVxyXG4gIH0pO1xyXG4gIGNvbnN0IHBlcmNlbnRhZ2UgPSAodXBsb2FkZWRDb3VudCAvIFJFUVVJUkVEX0RPQ1VNRU5UUy5sZW5ndGgpICogMTAwO1xyXG4gIHJldHVybiBNYXRoLnJvdW5kKHBlcmNlbnRhZ2UpO1xyXG59O1xyXG5cclxuY29uc3QgSW5mb0l0ZW0gPSAoeyBsYWJlbCwgdmFsdWUsIGZ1bGxXaWR0aCA9IGZhbHNlLCBpY29uOiBJY29uIH0pID0+IChcclxuICA8ZGl2IGNsYXNzTmFtZT17YCR7ZnVsbFdpZHRoID8gXCJjb2wtc3Bhbi1mdWxsXCIgOiBcIlwifSBiZy1ncmF5LTUwIHJvdW5kZWQtbGcgcC0zIGhvdmVyOmJnLWdyYXktMTAwIHRyYW5zaXRpb24tY29sb3JzYH0+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgIHtJY29uICYmIDxJY29uIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ibHVlLTUwMFwiIC8+fVxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+e2xhYmVsfTwvcD5cclxuICAgIDwvZGl2PlxyXG4gICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktOTAwIGZvbnQtbWVkaXVtIG10LTEgYnJlYWstd29yZHNcIj5cclxuICAgICAge3ZhbHVlICYmIHZhbHVlICE9PSAnTi9BJyAmJiB2YWx1ZSAhPT0gJ3VuZGVmaW5lZCcgJiYgdmFsdWUgIT09ICdudWxsJyA/IHZhbHVlIDogJ04vQSd9XHJcbiAgICA8L3A+XHJcbiAgPC9kaXY+XHJcbik7XHJcblxyXG4vLyBGb3JtYXQgZGF0ZSBoZWxwZXJcclxuY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlU3RyaW5nKSA9PiB7XHJcbiAgaWYgKCFkYXRlU3RyaW5nKSByZXR1cm4gJ04vQSc7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZShkYXRlU3RyaW5nKTtcclxuICAgIHJldHVybiBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZygnZW4tSU4nLCB7XHJcbiAgICAgIGRheTogJzItZGlnaXQnLFxyXG4gICAgICBtb250aDogJzItZGlnaXQnLFxyXG4gICAgICB5ZWFyOiAnbnVtZXJpYydcclxuICAgIH0pO1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgcmV0dXJuICdOL0EnO1xyXG4gIH1cclxufTtcclxuXHJcbi8vIERvY3VtZW50IFVwbG9hZCBGaWVsZCBDb21wb25lbnRcclxuY29uc3QgRG9jdW1lbnRVcGxvYWRGaWVsZCA9ICh7XHJcbiAgbGFiZWwsXHJcbiAgcmVxdWlyZWQsXHJcbiAgb25DaGFuZ2UsXHJcbiAgZmlsZSxcclxuICBwcmV2aWV3LFxyXG4gIGV4aXN0aW5nVXJsLFxyXG4gIG9uUHJldmlldyxcclxuICBvbkRlbGV0ZSxcclxuICBmb3JtYXRCeXRlcyxcclxufSkgPT4ge1xyXG4gIGNvbnN0IGlucHV0SWQgPSBgZmlsZS0ke2xhYmVsLnJlcGxhY2UoL1xccy9nLCBcIi1cIil9LSR7TWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc3Vic3RyKDIsIDkpfWA7XHJcbiAgY29uc3QgaXNJbWFnZSA9IGZpbGUgJiYgZmlsZS50eXBlPy5zdGFydHNXaXRoKFwiaW1hZ2UvXCIpO1xyXG4gIGNvbnN0IGhhc0V4aXN0aW5nRG9jID0gZXhpc3RpbmdVcmwgJiYgIWZpbGU7XHJcbiAgY29uc3QgaXNFeGlzdGluZ0ltYWdlID1cclxuICAgIGhhc0V4aXN0aW5nRG9jICYmIGV4aXN0aW5nVXJsPy5tYXRjaCgvXFwuKGpwZWd8anBnfGdpZnxwbmd8d2VicCkkL2kpO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgcC0zIGJnLXdoaXRlIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLXNoYWRvd1wiPlxyXG4gICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICB7bGFiZWx9IHtyZXF1aXJlZCAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPn1cclxuICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgIHshZmlsZSAmJiAhaGFzRXhpc3RpbmdEb2MgPyAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHAtNCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LWNlbnRlciBob3ZlcjpiZy1ncmF5LTUwIHRyYW5zaXRpb24tY29sb3JzXCI+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qLC5wZGZcIlxyXG4gICAgICAgICAgICBvbkNoYW5nZT17b25DaGFuZ2V9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXHJcbiAgICAgICAgICAgIGlkPXtpbnB1dElkfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICBodG1sRm9yPXtpbnB1dElkfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciB0ZXh0LWJsdWUtNjAwIGhvdmVyOnRleHQtYmx1ZS03MDAgZm9udC1tZWRpdW0gdGV4dC1zbVwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIENsaWNrIHRvIFVwbG9hZFxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgIEpQRywgUE5HIG9yIFBERiAoTWF4IDVNQilcclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSA6IChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBiZy1ncmF5LTUwIHAtMiByb3VuZGVkIGJvcmRlciBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZmxleC0xIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICB7ZmlsZSA/IChcclxuICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAge2lzSW1hZ2UgJiYgcHJldmlldyA/IChcclxuICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgIHNyYz17cHJldmlld31cclxuICAgICAgICAgICAgICAgICAgICBhbHQ9e2xhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkIG9iamVjdC1jb3ZlciBtci0zIGN1cnNvci1wb2ludGVyIGhvdmVyOm9wYWNpdHktODAgdHJhbnNpdGlvbi1vcGFjaXR5XCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblByZXZpZXcocHJldmlldywgbGFiZWwpfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgcm91bmRlZCBiZy1ncmF5LTIwMCBtci0zIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8SW9Eb2N1bWVudCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBtaW4tdy0wXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwIHRydW5jYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICB0aXRsZT17ZmlsZS5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2ZpbGUubmFtZX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0Qnl0ZXMoZmlsZS5zaXplKX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JlZW4tNjAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBOZXcgZmlsZSAod2lsbCByZXBsYWNlIGV4aXN0aW5nKVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAge2lzRXhpc3RpbmdJbWFnZSA/IChcclxuICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgIHNyYz17ZXhpc3RpbmdVcmx9XHJcbiAgICAgICAgICAgICAgICAgICAgYWx0PXtsYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgcm91bmRlZCBvYmplY3QtY292ZXIgbXItMyBjdXJzb3ItcG9pbnRlciBob3ZlcjpvcGFjaXR5LTgwIHRyYW5zaXRpb24tb3BhY2l0eVwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25QcmV2aWV3KGV4aXN0aW5nVXJsLCBsYWJlbCl9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkIGJnLWdyYXktMjAwIG1yLTMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJb0RvY3VtZW50IGNsYXNzTmFtZT1cInRleHQtMnhsXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1pbi13LTBcIj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyZWVuLTcwMCB0cnVuY2F0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIOKckyBBbHJlYWR5IHVwbG9hZGVkXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQ2xpY2sgXCJWaWV3XCIgdG8gc2VlIGRvY3VtZW50XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uUHJldmlldyhleGlzdGluZ1VybCwgbGFiZWwpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ibHVlLTYwMCBob3Zlcjp0ZXh0LWJsdWUtODAwIG10LTEgdGV4dC1sZWZ0IGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJb0V5ZSBjbGFzc05hbWU9XCJ0ZXh0LXNtXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICBWaWV3IGV4aXN0aW5nIGRvY3VtZW50XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkRlbGV0ZX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtMiB0ZXh0LWdyYXktNDAwIGhvdmVyOnRleHQtcmVkLTUwMCB0cmFuc2l0aW9uLWNvbG9ycyBwLTFcIlxyXG4gICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgZmlsZVxyXG4gICAgICAgICAgICAgICAgPyBcIlJlbW92ZSBmaWxlXCJcclxuICAgICAgICAgICAgICAgIDogXCJSZW1vdmUgZXhpc3RpbmcgZG9jdW1lbnQgKHdpbGwgYmUgZGVsZXRlZCBvbiB1cGxvYWQpXCJcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8SW9DbG9zZSBjbGFzc05hbWU9XCJ0ZXh0LXhsXCIgLz5cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmZ1bmN0aW9uIEN1c3RvbWVyRG9jdW1lbnRzKCkge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2N1c3RvbWVycywgc2V0Q3VzdG9tZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkQ3VzdG9tZXIsIHNldFNlbGVjdGVkQ3VzdG9tZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3Nob3dVcGxvYWRNb2RhbCwgc2V0U2hvd1VwbG9hZE1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd1ZpZXdNb2RhbCwgc2V0U2hvd1ZpZXdNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3VwbG9hZGluZywgc2V0VXBsb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdG9hc3QsIHNldFRvYXN0XSA9IHVzZVN0YXRlKHsgc2hvdzogZmFsc2UsIG1lc3NhZ2U6IFwiXCIsIHR5cGU6IFwiXCIgfSk7XHJcbiAgY29uc3QgW3ByZXZpZXdJbWFnZSwgc2V0UHJldmlld0ltYWdlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtwcmV2aWV3VGl0bGUsIHNldFByZXZpZXdUaXRsZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbaW5pdGlhbGl6aW5nLCBzZXRJbml0aWFsaXppbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW2V4aXN0aW5nRG9jdW1lbnRzLCBzZXRFeGlzdGluZ0RvY3VtZW50c10gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZmV0Y2hpbmdEb2N1bWVudHMsIHNldEZldGNoaW5nRG9jdW1lbnRzXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbb3RoZXJEb2N1bWVudHMsIHNldE90aGVyRG9jdW1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2hvd0d1YXJhbnRvciwgc2V0U2hvd0d1YXJhbnRvcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2d1YXJhbnRvckRhdGEsIHNldEd1YXJhbnRvckRhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgbmFtZTogXCJcIixcclxuICAgIHBob25lTnVtYmVyOiBcIlwiLFxyXG4gICAgZW1haWw6IFwiXCIsXHJcbiAgICBhZGRyZXNzOiBcIlwiLFxyXG4gICAgYWFkaGFyRnJvbnQ6IG51bGwsXHJcbiAgICBwYW5DYXJkOiBudWxsLFxyXG4gICAgcGhvdG86IG51bGwsXHJcbiAgfSk7XHJcbiAgY29uc3QgW2d1YXJhbnRvclByZXZpZXdzLCBzZXRHdWFyYW50b3JQcmV2aWV3c10gPSB1c2VTdGF0ZSh7XHJcbiAgICBhYWRoYXJGcm9udDogbnVsbCxcclxuICAgIHBhbkNhcmQ6IG51bGwsXHJcbiAgICBwaG90bzogbnVsbCxcclxuICB9KTtcclxuICBjb25zdCBbZXhpc3RpbmdHdWFyYW50b3JVcmxzLCBzZXRFeGlzdGluZ0d1YXJhbnRvclVybHNdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2Z1bGxDdXN0b21lckRldGFpbHMsIHNldEZ1bGxDdXN0b21lckRldGFpbHNdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2xvYWRpbmdEZXRhaWxzLCBzZXRMb2FkaW5nRGV0YWlsc10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lzQ3VzdG9tZXJEZXRhaWxzT3Blbiwgc2V0SXNDdXN0b21lckRldGFpbHNPcGVuXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtyZXBsYWNlZERvY3VtZW50cywgc2V0UmVwbGFjZWREb2N1bWVudHNdID0gdXNlU3RhdGUoe30pO1xyXG5cclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIHVzZXJfcHJvZmlsZV9waG90bzogbnVsbCxcclxuICAgIHVzZXJfYWRoYXJjYXJkX2Zyb250X3Bob3RvOiBudWxsLFxyXG4gICAgdXNlcl9hZGhhcmNhcmRfYmFja19waG90bzogbnVsbCxcclxuICAgIHVzZXJfcGFuY2FyZF9waG90bzogbnVsbCxcclxuICAgIHVzZXJfY2hlcXVlX2xlYWY6IG51bGwsXHJcbiAgICBiYW5rX3N0YXRlbWVudF9tb250aDogbnVsbCxcclxuICAgIGJhbmtfcGFzc2Jvb2tfcGhvdG86IG51bGwsXHJcbiAgICBidXNpbmVzc19kb2N1bWVudF9wcm9vZjogbnVsbCxcclxuICAgIHVzZXJfc2FsYXJ5X3NsaXA6IG51bGwsXHJcbiAgICBub21pbmVlOiB7XHJcbiAgICAgIG5hbWU6IFwiXCIsXHJcbiAgICAgIHBob25lTnVtYmVyOiBcIlwiLFxyXG4gICAgICB1c2VyX25vbWluZWVfYWRoYXJjYXJkX2Zyb250X3Bob3RvOiBudWxsLFxyXG4gICAgICB1c2VyX25vbWluZWVfYWRoYXJjYXJkX2JhY2tfcGhvdG86IG51bGwsXHJcbiAgICAgIHVzZXJfbm9taW5lZV9wYW5jYXJkX3Bob3RvOiBudWxsLFxyXG4gICAgfSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW2ZpbGVQcmV2aWV3cywgc2V0RmlsZVByZXZpZXdzXSA9IHVzZVN0YXRlKHtcclxuICAgIHVzZXJfcHJvZmlsZV9waG90bzogbnVsbCxcclxuICAgIHVzZXJfYWRoYXJjYXJkX2Zyb250X3Bob3RvOiBudWxsLFxyXG4gICAgdXNlcl9hZGhhcmNhcmRfYmFja19waG90bzogbnVsbCxcclxuICAgIHVzZXJfcGFuY2FyZF9waG90bzogbnVsbCxcclxuICAgIHVzZXJfY2hlcXVlX2xlYWY6IG51bGwsXHJcbiAgICBiYW5rX3N0YXRlbWVudF9tb250aDogbnVsbCxcclxuICAgIGJhbmtfcGFzc2Jvb2tfcGhvdG86IG51bGwsXHJcbiAgICBidXNpbmVzc19kb2N1bWVudF9wcm9vZjogbnVsbCxcclxuICAgIHVzZXJfc2FsYXJ5X3NsaXA6IG51bGwsXHJcbiAgICB1c2VyX25vbWluZWVfYWRoYXJjYXJkX2Zyb250X3Bob3RvOiBudWxsLFxyXG4gICAgdXNlcl9ub21pbmVlX2FkaGFyY2FyZF9iYWNrX3Bob3RvOiBudWxsLFxyXG4gICAgdXNlcl9ub21pbmVlX3BhbmNhcmRfcGhvdG86IG51bGwsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtleGlzdGluZ0RvY3VtZW50VXJscywgc2V0RXhpc3RpbmdEb2N1bWVudFVybHNdID0gdXNlU3RhdGUoe1xyXG4gICAgdXNlcl9wcm9maWxlX3Bob3RvOiBudWxsLFxyXG4gICAgdXNlcl9hZGhhcmNhcmRfZnJvbnRfcGhvdG86IG51bGwsXHJcbiAgICB1c2VyX2FkaGFyY2FyZF9iYWNrX3Bob3RvOiBudWxsLFxyXG4gICAgdXNlcl9wYW5jYXJkX3Bob3RvOiBudWxsLFxyXG4gICAgdXNlcl9jaGVxdWVfbGVhZjogbnVsbCxcclxuICAgIGJhbmtfc3RhdGVtZW50X21vbnRoOiBudWxsLFxyXG4gICAgYmFua19wYXNzYm9va19waG90bzogbnVsbCxcclxuICAgIGJ1c2luZXNzX2RvY3VtZW50X3Byb29mOiBudWxsLFxyXG4gICAgdXNlcl9zYWxhcnlfc2xpcDogbnVsbCxcclxuICAgIHVzZXJfbm9taW5lZV9hZGhhcmNhcmRfZnJvbnRfcGhvdG86IG51bGwsXHJcbiAgICB1c2VyX25vbWluZWVfYWRoYXJjYXJkX2JhY2tfcGhvdG86IG51bGwsXHJcbiAgICB1c2VyX25vbWluZWVfcGFuY2FyZF9waG90bzogbnVsbCxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgZm9ybWF0Qnl0ZXMgPSAoYnl0ZXMsIGRlY2ltYWxzID0gMikgPT4ge1xyXG4gICAgaWYgKCErYnl0ZXMpIHJldHVybiBcIjAgQnl0ZXNcIjtcclxuICAgIGNvbnN0IGsgPSAxMDI0O1xyXG4gICAgY29uc3QgZG0gPSBkZWNpbWFscyA8IDAgPyAwIDogZGVjaW1hbHM7XHJcbiAgICBjb25zdCBzaXplcyA9IFtcIkJ5dGVzXCIsIFwiS0JcIiwgXCJNQlwiLCBcIkdCXCJdO1xyXG4gICAgY29uc3QgaSA9IE1hdGguZmxvb3IoTWF0aC5sb2coYnl0ZXMpIC8gTWF0aC5sb2coaykpO1xyXG4gICAgcmV0dXJuIGAke3BhcnNlRmxvYXQoKGJ5dGVzIC8gTWF0aC5wb3coaywgaSkpLnRvRml4ZWQoZG0pKX0gJHtzaXplc1tpXX1gO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHNob3dUb2FzdCA9IChtZXNzYWdlLCB0eXBlID0gXCJzdWNjZXNzXCIpID0+IHtcclxuICAgIHNldFRvYXN0KHsgc2hvdzogdHJ1ZSwgbWVzc2FnZSwgdHlwZSB9KTtcclxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICBzZXRUb2FzdCh7IHNob3c6IGZhbHNlLCBtZXNzYWdlOiBcIlwiLCB0eXBlOiBcIlwiIH0pO1xyXG4gICAgfSwgMzAwMCk7XHJcbiAgfTtcclxuXHJcbiAgLy8gRG93bmxvYWQgYXMgUERGIHVzaW5nIGh0bWwyY2FudmFzIGFuZCBqc1BERlxyXG5jb25zdCBoYW5kbGVEb3dubG9hZFBERiA9IGFzeW5jICgpID0+IHtcclxuICBjb25zdCBlbGVtZW50ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2N1c3RvbWVyLXByb2ZpbGUtcHJpbnQnKTtcclxuICBpZiAoIWVsZW1lbnQpIHtcclxuICAgIG1lc3NhZ2UuZXJyb3IoJ1Byb2ZpbGUgbm90IGZvdW5kIHRvIGRvd25sb2FkJyk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG5cclxuICBjb25zdCBoaWRlTXNnID0gbWVzc2FnZS5sb2FkaW5nKCdHZW5lcmF0aW5nIFBERi4uLicsIDApO1xyXG5cclxuICB0cnkge1xyXG4gICAgLy8gQ3JlYXRlIGEgY2xvbmUgb2YgdGhlIGVsZW1lbnQgZm9yIFBERiBnZW5lcmF0aW9uXHJcbiAgICBjb25zdCBjbG9uZSA9IGVsZW1lbnQuY2xvbmVOb2RlKHRydWUpO1xyXG4gICAgXHJcbiAgICAvLyBSZW1vdmUgYWN0aW9uIGJ1dHRvbnMgZnJvbSBjbG9uZVxyXG4gICAgY29uc3QgYWN0aW9uQnV0dG9ucyA9IGNsb25lLnF1ZXJ5U2VsZWN0b3JBbGwoJy5oaWRlLWluLXByaW50Jyk7XHJcbiAgICBhY3Rpb25CdXR0b25zLmZvckVhY2goYnRuID0+IGJ0bi5yZW1vdmUoKSk7XHJcbiAgICBcclxuICAgIC8vIEdldCBhbGwgc2VjdGlvbiBlbGVtZW50cyBhbmQgYWRkIHBhZ2UtYnJlYWstaW5zaWRlOiBhdm9pZFxyXG4gICAgY29uc3Qgc2VjdGlvbnMgPSBjbG9uZS5xdWVyeVNlbGVjdG9yQWxsKCcuYm9yZGVyLWIsIC5ib3JkZXItZ3JheS0yMDAnKTtcclxuICAgIHNlY3Rpb25zLmZvckVhY2goc2VjdGlvbiA9PiB7XHJcbiAgICAgIHNlY3Rpb24uc3R5bGUucGFnZUJyZWFrSW5zaWRlID0gJ2F2b2lkJztcclxuICAgICAgc2VjdGlvbi5zdHlsZS5icmVha0luc2lkZSA9ICdhdm9pZCc7XHJcbiAgICB9KTtcclxuICAgIFxyXG4gICAgLy8gQ3JlYXRlIGEgdGVtcG9yYXJ5IGNvbnRhaW5lciB3aXRoIHByb3BlciBzdHlsaW5nXHJcbiAgICBjb25zdCB0ZW1wQ29udGFpbmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICB0ZW1wQ29udGFpbmVyLnN0eWxlLnBvc2l0aW9uID0gJ2ZpeGVkJztcclxuICAgIHRlbXBDb250YWluZXIuc3R5bGUubGVmdCA9ICctOTk5OXB4JztcclxuICAgIHRlbXBDb250YWluZXIuc3R5bGUudG9wID0gJzAnO1xyXG4gICAgdGVtcENvbnRhaW5lci5zdHlsZS53aWR0aCA9ICc5MDBweCc7XHJcbiAgICB0ZW1wQ29udGFpbmVyLnN0eWxlLmJhY2tncm91bmQgPSAnd2hpdGUnO1xyXG4gICAgdGVtcENvbnRhaW5lci5zdHlsZS5wYWRkaW5nID0gJzEwcHgnO1xyXG4gICAgdGVtcENvbnRhaW5lci5zdHlsZS56SW5kZXggPSAnLTk5OTknO1xyXG4gICAgXHJcbiAgICAvLyBBZGQgdGhlIGNsb25lIHRvIHRlbXBvcmFyeSBjb250YWluZXJcclxuICAgIHRlbXBDb250YWluZXIuYXBwZW5kQ2hpbGQoY2xvbmUpO1xyXG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZCh0ZW1wQ29udGFpbmVyKTtcclxuICAgIFxyXG4gICAgLy8gV2FpdCBmb3IgaW1hZ2VzIHRvIGxvYWRcclxuICAgIGF3YWl0IG5ldyBQcm9taXNlKHJlc29sdmUgPT4gc2V0VGltZW91dChyZXNvbHZlLCAxMDAwKSk7XHJcbiAgICBcclxuICAgIC8vIENhcHR1cmUgdGhlIGNvbnRlbnRcclxuICAgIGNvbnN0IGNhbnZhcyA9IGF3YWl0IGh0bWwyY2FudmFzKHRlbXBDb250YWluZXIsIHtcclxuICAgICAgc2NhbGU6IDIsXHJcbiAgICAgIHVzZUNPUlM6IHRydWUsXHJcbiAgICAgIGFsbG93VGFpbnQ6IHRydWUsXHJcbiAgICAgIGJhY2tncm91bmRDb2xvcjogJyNmZmZmZmYnLFxyXG4gICAgICBsb2dnaW5nOiBmYWxzZSxcclxuICAgICAgd2lkdGg6IDkwMCxcclxuICAgICAgaGVpZ2h0OiB0ZW1wQ29udGFpbmVyLnNjcm9sbEhlaWdodCxcclxuICAgICAgb25jbG9uZTogZnVuY3Rpb24oZG9jKSB7XHJcbiAgICAgICAgY29uc3QgaW1hZ2VzID0gZG9jLnF1ZXJ5U2VsZWN0b3JBbGwoJ2ltZycpO1xyXG4gICAgICAgIHJldHVybiBQcm9taXNlLmFsbChBcnJheS5mcm9tKGltYWdlcykubWFwKGltZyA9PiB7XHJcbiAgICAgICAgICBpZiAoaW1nLmNvbXBsZXRlKSByZXR1cm47XHJcbiAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UocmVzb2x2ZSA9PiB7XHJcbiAgICAgICAgICAgIGltZy5vbmxvYWQgPSByZXNvbHZlO1xyXG4gICAgICAgICAgICBpbWcub25lcnJvciA9IHJlc29sdmU7XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9KSk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gICAgXHJcbiAgICAvLyBSZW1vdmUgdGVtcG9yYXJ5IGNvbnRhaW5lclxyXG4gICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZCh0ZW1wQ29udGFpbmVyKTtcclxuICAgIFxyXG4gICAgLy8gQ3JlYXRlIFBERiB3aXRoIGJldHRlciBwYWdlIGhhbmRsaW5nXHJcbiAgICBjb25zdCBpbWdEYXRhID0gY2FudmFzLnRvRGF0YVVSTCgnaW1hZ2UvcG5nJyk7XHJcbiAgICBjb25zdCBwZGYgPSBuZXcganNQREYoe1xyXG4gICAgICBvcmllbnRhdGlvbjogJ3BvcnRyYWl0JyxcclxuICAgICAgdW5pdDogJ21tJyxcclxuICAgICAgZm9ybWF0OiAnYTQnXHJcbiAgICB9KTtcclxuICAgIFxyXG4gICAgY29uc3QgcGRmV2lkdGggPSBwZGYuaW50ZXJuYWwucGFnZVNpemUuZ2V0V2lkdGgoKTtcclxuICAgIGNvbnN0IGltZ0hlaWdodCA9IChjYW52YXMuaGVpZ2h0ICogcGRmV2lkdGgpIC8gY2FudmFzLndpZHRoO1xyXG4gICAgY29uc3QgcGFnZUhlaWdodCA9IHBkZi5pbnRlcm5hbC5wYWdlU2l6ZS5nZXRIZWlnaHQoKTtcclxuICAgIFxyXG4gICAgLy8gQ2FsY3VsYXRlIGhvdyBtYW55IHBhZ2VzIG5lZWRlZFxyXG4gICAgY29uc3QgdG90YWxQYWdlcyA9IE1hdGguY2VpbChpbWdIZWlnaHQgLyBwYWdlSGVpZ2h0KTtcclxuICAgIFxyXG4gICAgLy8gRm9yIGVhY2ggcGFnZSwgY2FsY3VsYXRlIHRoZSBwb3J0aW9uIG9mIHRoZSBpbWFnZSB0byBzaG93XHJcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRvdGFsUGFnZXM7IGkrKykge1xyXG4gICAgICBpZiAoaSA+IDApIHtcclxuICAgICAgICBwZGYuYWRkUGFnZSgpO1xyXG4gICAgICB9XHJcbiAgICAgIFxyXG4gICAgICAvLyBDYWxjdWxhdGUgdGhlIHkgcG9zaXRpb24gZm9yIHRoaXMgcGFnZVxyXG4gICAgICBjb25zdCB5T2Zmc2V0ID0gLWkgKiBwYWdlSGVpZ2h0O1xyXG4gICAgICBcclxuICAgICAgLy8gQWRkIHRoZSBpbWFnZSB3aXRoIHRoZSBvZmZzZXRcclxuICAgICAgcGRmLmFkZEltYWdlKGltZ0RhdGEsICdQTkcnLCAwLCB5T2Zmc2V0LCBwZGZXaWR0aCwgaW1nSGVpZ2h0KTtcclxuICAgIH1cclxuICAgIFxyXG4gICAgLy8gU2F2ZSBQREZcclxuICAgIGNvbnN0IGZpbGVOYW1lID0gYEN1c3RvbWVyX1Byb2ZpbGVfJHtmdWxsQ3VzdG9tZXJEZXRhaWxzPy5jdXN0b21lcl9pZCB8fCAncHJvZmlsZSd9XyR7bmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KCdUJylbMF19LnBkZmA7XHJcbiAgICBwZGYuc2F2ZShmaWxlTmFtZSk7XHJcbiAgICBcclxuICAgIG1lc3NhZ2UuZGVzdHJveSgpO1xyXG4gICAgbWVzc2FnZS5zdWNjZXNzKCdQREYgZG93bmxvYWRlZCBzdWNjZXNzZnVsbHkhJyk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGdlbmVyYXRpbmcgUERGOicsIGVycm9yKTtcclxuICAgIG1lc3NhZ2UuZGVzdHJveSgpO1xyXG4gICAgbWVzc2FnZS5lcnJvcignRmFpbGVkIHRvIGdlbmVyYXRlIFBERi4gUGxlYXNlIHRyeSBhZ2Fpbi4nKTtcclxuICB9XHJcbn07XHJcblxyXG4gIGNvbnN0IGZldGNoVXNlckRvY3VtZW50cyA9IGFzeW5jICh1c2VySWQpID0+IHtcclxuICAgIHNldEZldGNoaW5nRG9jdW1lbnRzKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvdjEvYWRtaW4vdXNlci1kb2N1bWVudHMvJHt1c2VySWR9YCk7XHJcbiAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEuZGF0YSkge1xyXG4gICAgICAgIGxldCBkb2N1bWVudHNEYXRhID0gcmVzcG9uc2UuZGF0YS5kYXRhO1xyXG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KGRvY3VtZW50c0RhdGEpICYmIGRvY3VtZW50c0RhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgZG9jdW1lbnRzRGF0YSA9IGRvY3VtZW50c0RhdGFbMF07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHNldEV4aXN0aW5nRG9jdW1lbnRzKGRvY3VtZW50c0RhdGEpO1xyXG4gICAgICAgIHNldEZ1bGxDdXN0b21lckRldGFpbHMoZG9jdW1lbnRzRGF0YSk7XHJcblxyXG4gICAgICAgIGNvbnN0IGV4aXN0aW5nVXJscyA9IHt9O1xyXG4gICAgICAgIFJFUVVJUkVEX0RPQ1VNRU5UUy5mb3JFYWNoKChkb2MpID0+IHtcclxuICAgICAgICAgIGlmIChkb2N1bWVudHNEYXRhW2RvYy5rZXldKSB7XHJcbiAgICAgICAgICAgIGV4aXN0aW5nVXJsc1tkb2Mua2V5XSA9IGRvY3VtZW50c0RhdGFbZG9jLmtleV07XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2V0RXhpc3RpbmdEb2N1bWVudFVybHMoZXhpc3RpbmdVcmxzKTtcclxuXHJcbiAgICAgICAgaWYgKFxyXG4gICAgICAgICAgZG9jdW1lbnRzRGF0YS5vdGhlcl9kb2N1bWVudHNfbmFtZSB8fFxyXG4gICAgICAgICAgZG9jdW1lbnRzRGF0YS5vdGhlcl9kb2N1bWVudHNfcGhvdG9cclxuICAgICAgICApIHtcclxuICAgICAgICAgIHNldE90aGVyRG9jdW1lbnRzKFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIGlkOiBEYXRlLm5vdygpLnRvU3RyaW5nKCksXHJcbiAgICAgICAgICAgICAgbmFtZTogZG9jdW1lbnRzRGF0YS5vdGhlcl9kb2N1bWVudHNfbmFtZSB8fCBcIlwiLFxyXG4gICAgICAgICAgICAgIGZpbGU6IG51bGwsXHJcbiAgICAgICAgICAgICAgcHJldmlldzogbnVsbCxcclxuICAgICAgICAgICAgICBleGlzdGluZ1VybDogZG9jdW1lbnRzRGF0YS5vdGhlcl9kb2N1bWVudHNfcGhvdG8gfHwgbnVsbCxcclxuICAgICAgICAgICAgICBleGlzdGluZ05hbWU6IGRvY3VtZW50c0RhdGEub3RoZXJfZG9jdW1lbnRzX25hbWUgfHwgXCJcIixcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgIF0pO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRPdGhlckRvY3VtZW50cyhbXSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoZG9jdW1lbnRzRGF0YS5ub21pbmVlX25hbWUpIHtcclxuICAgICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICBub21pbmVlOiB7XHJcbiAgICAgICAgICAgICAgLi4ucHJldi5ub21pbmVlLFxyXG4gICAgICAgICAgICAgIG5hbWU6IGRvY3VtZW50c0RhdGEubm9taW5lZV9uYW1lIHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgcGhvbmVOdW1iZXI6IGRvY3VtZW50c0RhdGEubm9taW5lZV9waG9uZSB8fCBcIlwiLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfSkpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGRvY3VtZW50c0RhdGE7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0RXhpc3RpbmdEb2N1bWVudHMobnVsbCk7XHJcbiAgICAgICAgc2V0RnVsbEN1c3RvbWVyRGV0YWlscyhudWxsKTtcclxuICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGV4aXN0aW5nIGRvY3VtZW50czpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRFeGlzdGluZ0RvY3VtZW50cyhudWxsKTtcclxuICAgICAgc2V0RnVsbEN1c3RvbWVyRGV0YWlscyhudWxsKTtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRGZXRjaGluZ0RvY3VtZW50cyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hDdXN0b21lcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgIGxldCBhbGxVc2VycyA9IFtdO1xyXG4gICAgICBpZiAocmVzcG9uc2UuZGF0YS51c2Vycykge1xyXG4gICAgICAgIGFsbFVzZXJzID0gcmVzcG9uc2UuZGF0YS51c2VycztcclxuICAgICAgfSBlbHNlIGlmIChyZXNwb25zZS5kYXRhLmRhdGEpIHtcclxuICAgICAgICBhbGxVc2VycyA9IHJlc3BvbnNlLmRhdGEuZGF0YTtcclxuICAgICAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KHJlc3BvbnNlLmRhdGEpKSB7XHJcbiAgICAgICAgYWxsVXNlcnMgPSByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGFsbFVzZXJzID0gW107XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZEN1c3RvbWVycyA9IGFsbFVzZXJzLm1hcCgodXNlcikgPT4gKHtcclxuICAgICAgICBfaWQ6IHVzZXIuX2lkLFxyXG4gICAgICAgIG5hbWU6IHVzZXIuZnVsbF9uYW1lIHx8IHVzZXIubmFtZSB8fCBcIlVua25vd25cIixcclxuICAgICAgICBlbWFpbDogdXNlci5lbWFpbCB8fCBcIlwiLFxyXG4gICAgICAgIHBob25lOiB1c2VyLnBob25lX251bWJlciB8fCB1c2VyLnBob25lIHx8IFwiXCIsXHJcbiAgICAgICAgY3VzdG9tZXJfaWQ6IHVzZXIuY3VzdG9tZXJfaWQgfHwgXCJcIixcclxuICAgICAgICBhZGRyZXNzOnVzZXIuYWRkcmVzcyB8fCBcIi1cIixcclxuICAgICAgICBwaW5jb2RlOnVzZXIucGluY29kZSB8fCBcIi1cIixcclxuICAgICAgICBhZGhhYXJfbm86dXNlci5hZGhhYXJfbm8gfHwgXCJcIixcclxuICAgICAgICBwYW5fbm86dXNlci5wYW5fbm8gfHwgXCJcIixcclxuICAgICAgICBhcHByb3ZhbF9zdGF0dXM6dXNlci5hcHByb3ZhbF9zdGF0dXMgfHwgXCJcIixcclxuICAgICAgICB0cmFja19zb3VyY2U6dXNlci50cmFja19zb3VyY2UgfHwgXCJcIixcclxuICAgICAgICByZWZlcnJhbF90eXBlOnVzZXIucmVmZXJyYWxfdHlwZSB8fCBcIlwiLFxyXG4gICAgICAgIHJlZmVycmVkX2FnZW50OnVzZXIucmVmZXJyZWRfYWdlbnQgfHwgXCJcIixcclxuICAgICAgICByZWZlcnJlZF9jdXN0b21lcjp1c2VyLnJlZmVycmVkX2N1c3RvbWVyIHx8IFwiXCIsXHJcbiAgICAgICAgam9pbmluZ19kYXRlOnVzZXIuam9pbmluZ19kYXRlICB8fCBcIlwiLFxyXG4gICAgICAgIGFsdGVybmF0ZV9udW1iZXI6dXNlci5hbHRlcm5hdGVfbnVtYmVyIHx8IFwiXCIsXHJcbiAgICAgICAgYmFua19JRlNDX2NvZGU6dXNlci5iYW5rX0lGU0NfY29kZSB8fCBcIlwiLFxyXG4gICAgICAgIGJhbmtfYWNjb3VudF9udW1iZXI6dXNlci5iYW5rX2FjY291bnRfbnVtYmVyIHx8IFwiXCIsXHJcbiAgICAgICAgYmFua19icmFuY2hfbmFtZTp1c2VyLmJhbmtfYnJhbmNoX25hbWUgfHwgXCJcIixcclxuICAgICAgICBiYW5rX25hbWU6dXNlci5iYW5rX25hbWUgfHwgXCJcIixcclxuICAgICAgICBkYXRlb2ZiaXJ0aDp1c2VyLmRhdGVvZmJpcnRoIHx8IFwiXCIsXHJcbiAgICAgICAgZGlzdHJpY3Q6dXNlci5kaXN0cmljdCB8fCBcIlwiLFxyXG4gICAgICAgIGZhdGhlcl9uYW1lOnVzZXIuZmF0aGVyX25hbWUgfHwgXCJcIixcclxuICAgICAgICBnZW5kZXI6dXNlci5nZW5kZXIgfHwgXCJcIixcclxuICAgICAgICBtYXJpdGFsX3N0YXR1czp1c2VyLm1hcml0YWxfc3RhdHVzIHx8IFwiXCIsXHJcbiAgICAgICAgbmF0aW9uYWxpdHk6dXNlci5uYXRpb25hbGl0eSB8fCBcIlwiLFxyXG4gICAgICAgIG5vbWluZWVfZGF0ZW9mYmlydGg6dXNlci5ub21pbmVlX2RhdGVvZmJpcnRoIHx8IFwiXCIsXHJcbiAgICAgICAgbm9taW5lZV9uYW1lOnVzZXIubm9taW5lZV9uYW1lIHx8IFwiXCIsXHJcbiAgICAgICAgbm9taW5lZV9waG9uZV9udW1iZXI6dXNlci5ub21pbmVlX3Bob25lX251bWJlciB8fCBcIlwiLFxyXG4gICAgICAgIG5vbWluZWVfcmVsYXRpb25zaGlwOnVzZXIubm9taW5lZV9yZWxhdGlvbnNoaXAgfHwgXCJcIixcclxuICAgICAgICByZWZlcnJhbF9uYW1lOnVzZXIucmVmZXJyYWxfbmFtZSB8fCBcIlwiLFxyXG4gICAgICAgIHJlZ2lzdHJhdGlvbl9kYXRlOnVzZXIucmVnaXN0cmF0aW9uX2RhdGUgfHwgXCJcIixcclxuICAgICAgICBzdGF0ZTp1c2VyLnN0YXRlIHx8IFwiXCIsXHJcbiAgICAgICAgdGFsdWs6dXNlci50YWx1ayB8fCBcIlwiLFxyXG4gICAgICAgIHRpdGxlOnVzZXIudGl0bGUgfHwgXCJcIixcclxuICAgICAgICBjb2xsZWN0aW9uX2FyZWE6dXNlcj8uY29sbGVjdGlvbl9hcmVhPy5yb3V0ZV9uYW1lIHx8IFwiXCIsXHJcbiAgICAgICAgcmVmZXJyZWRfZW1wbG95ZWU6dXNlcj8ucmVmZXJyZWRfZW1wbG95ZWU/Lm5hbWUgfHwgXCJcIixcclxuICAgICAgICBwZXJjZW50YWdlOnVzZXIucGVyY2VudGFnZSB8fCBcIlwiLFxyXG4gICAgICAgIGxhYmVsOiBgJHt1c2VyLmZ1bGxfbmFtZSB8fCB1c2VyLm5hbWUgfHwgXCJVbmtub3duXCJ9IC0gJHt1c2VyLnBob25lX251bWJlciB8fCB1c2VyLnBob25lIHx8IFwiTm8gUGhvbmVcIn1gLFxyXG4gICAgICAgIHZhbHVlOiB1c2VyLl9pZCxcclxuICAgICAgfSkpO1xyXG5cclxuICAgICAgc2V0Q3VzdG9tZXJzKGZvcm1hdHRlZEN1c3RvbWVycyk7XHJcbiAgICAgIGF3YWl0IGNoZWNrVXJsUGFyYW1zQW5kU2VsZWN0Q3VzdG9tZXIoZm9ybWF0dGVkQ3VzdG9tZXJzKTtcclxuXHJcbiAgICAgIGlmIChmb3JtYXR0ZWRDdXN0b21lcnMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgc2hvd1RvYXN0KFwiTm8gY3VzdG9tZXJzIGZvdW5kXCIsIFwiZXJyb3JcIik7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBjdXN0b21lcnM6XCIsIGVycm9yKTtcclxuICAgICAgc2hvd1RvYXN0KFwiRmFpbGVkIHRvIGZldGNoIGN1c3RvbWVyc1wiLCBcImVycm9yXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIHNldEluaXRpYWxpemluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY2hlY2tVcmxQYXJhbXNBbmRTZWxlY3RDdXN0b21lciA9IGFzeW5jIChjdXN0b21lcnNMaXN0KSA9PiB7XHJcbiAgICBjb25zdCBwYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKGxvY2F0aW9uLnNlYXJjaCk7XHJcbiAgICBjb25zdCB1c2VySWQgPSBwYXJhbXMuZ2V0KFwidXNlcklkXCIpO1xyXG4gICAgY29uc3QgYXVjdGlvbklkID0gcGFyYW1zLmdldChcImF1Y3Rpb25JZFwiKTtcclxuXHJcbiAgICBpZiAodXNlcklkICYmIGN1c3RvbWVyc0xpc3QubGVuZ3RoID4gMCkge1xyXG4gICAgICBjb25zdCBjdXN0b21lciA9IGN1c3RvbWVyc0xpc3QuZmluZCgoYykgPT4gYy5faWQgPT09IHVzZXJJZCk7XHJcbiAgICAgIGlmIChjdXN0b21lcikge1xyXG4gICAgICAgIHNldFNlbGVjdGVkQ3VzdG9tZXIoY3VzdG9tZXIpO1xyXG4gICAgICAgIGF3YWl0IGZldGNoVXNlckRvY3VtZW50cyh1c2VySWQpO1xyXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgc2V0U2hvd1VwbG9hZE1vZGFsKHRydWUpO1xyXG4gICAgICAgIH0sIDUwMCk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2hvd1RvYXN0KFwiQ3VzdG9tZXIgbm90IGZvdW5kXCIsIFwiZXJyb3JcIik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBkb2N1bWVudFBlcmNlbnRhZ2UgPSBleGlzdGluZ0RvY3VtZW50c1xyXG4gICAgPyBjYWxjdWxhdGVQZXJjZW50YWdlRnJvbVVzZXJEb2MoZXhpc3RpbmdEb2N1bWVudHMpXHJcbiAgICA6IDA7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaEN1c3RvbWVycygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChjdXN0b21lcnMubGVuZ3RoID4gMCkge1xyXG4gICAgICBjaGVja1VybFBhcmFtc0FuZFNlbGVjdEN1c3RvbWVyKGN1c3RvbWVycyk7XHJcbiAgICB9XHJcbiAgfSwgW2xvY2F0aW9uLnNlYXJjaCwgY3VzdG9tZXJzLmxlbmd0aF0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVDdXN0b21lclNlbGVjdCA9IGFzeW5jIChjdXN0b21lcklkKSA9PiB7XHJcbiAgICBjb25zdCBzZWxlY3RlZCA9IGN1c3RvbWVycy5maW5kKChjKSA9PiBjLl9pZCA9PT0gY3VzdG9tZXJJZCk7XHJcbiAgICBpZiAoc2VsZWN0ZWQpIHtcclxuICAgICAgc2V0U2VsZWN0ZWRDdXN0b21lcihzZWxlY3RlZCk7XHJcbiAgICAgIHNldExvYWRpbmdEZXRhaWxzKHRydWUpO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IGRvY3VtZW50cyA9IGF3YWl0IGZldGNoVXNlckRvY3VtZW50cyhjdXN0b21lcklkKTtcclxuICAgICAgICBpZiAoZG9jdW1lbnRzKSB7XHJcbiAgICAgICAgICBzZXRGdWxsQ3VzdG9tZXJEZXRhaWxzKHtcclxuICAgICAgICAgICAgLi4uc2VsZWN0ZWQsXHJcbiAgICAgICAgICAgIC4uLmRvY3VtZW50c1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldEZ1bGxDdXN0b21lckRldGFpbHMoe1xyXG4gICAgICAgICAgICAuLi5zZWxlY3RlZCxcclxuICAgICAgICAgICAgZnVsbF9uYW1lOiBzZWxlY3RlZC5uYW1lLFxyXG4gICAgICAgICAgICBwaG9uZV9udW1iZXI6IHNlbGVjdGVkLnBob25lLFxyXG4gICAgICAgICAgICBlbWFpbDogc2VsZWN0ZWQuZW1haWwsXHJcbiAgICAgICAgICAgIGN1c3RvbWVyX2lkOiBzZWxlY3RlZC5jdXN0b21lcl9pZFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBjdXN0b21lciBkZXRhaWxzOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0RnVsbEN1c3RvbWVyRGV0YWlscyh7XHJcbiAgICAgICAgICAuLi5zZWxlY3RlZCxcclxuICAgICAgICAgIGZ1bGxfbmFtZTogc2VsZWN0ZWQubmFtZSxcclxuICAgICAgICAgIHBob25lX251bWJlcjogc2VsZWN0ZWQucGhvbmUsXHJcbiAgICAgICAgICBlbWFpbDogc2VsZWN0ZWQuZW1haWwsXHJcbiAgICAgICAgICBjdXN0b21lcl9pZDogc2VsZWN0ZWQuY3VzdG9tZXJfaWRcclxuICAgICAgICB9KTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRMb2FkaW5nRGV0YWlscyhmYWxzZSk7XHJcbiAgICAgICAgc2V0U2hvd1VwbG9hZE1vZGFsKHRydWUpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRmlsZUNoYW5nZSA9IChlLCBmaWVsZCkgPT4ge1xyXG4gICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzWzBdO1xyXG4gICAgaWYgKGZpbGUpIHtcclxuICAgICAgY29uc3QgcHJldmlld1VybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoZmlsZSk7XHJcblxyXG4gICAgICBpZiAoZmllbGQgPT09IFwibm9taW5lZV9hZGhhcmNhcmRfZnJvbnRcIikge1xyXG4gICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgIG5vbWluZWU6IHtcclxuICAgICAgICAgICAgLi4ucHJldi5ub21pbmVlLFxyXG4gICAgICAgICAgICB1c2VyX25vbWluZWVfYWRoYXJjYXJkX2Zyb250X3Bob3RvOiBmaWxlLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgc2V0RmlsZVByZXZpZXdzKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgIHVzZXJfbm9taW5lZV9hZGhhcmNhcmRfZnJvbnRfcGhvdG86IHByZXZpZXdVcmwsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldFJlcGxhY2VkRG9jdW1lbnRzKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgIHVzZXJfbm9taW5lZV9hZGhhcmNhcmRfZnJvbnRfcGhvdG86IHRydWUsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICB9IGVsc2UgaWYgKGZpZWxkID09PSBcIm5vbWluZWVfYWRoYXJjYXJkX2JhY2tcIikge1xyXG4gICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgIG5vbWluZWU6IHtcclxuICAgICAgICAgICAgLi4ucHJldi5ub21pbmVlLFxyXG4gICAgICAgICAgICB1c2VyX25vbWluZWVfYWRoYXJjYXJkX2JhY2tfcGhvdG86IGZpbGUsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0pKTtcclxuICAgICAgICBzZXRGaWxlUHJldmlld3MoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgdXNlcl9ub21pbmVlX2FkaGFyY2FyZF9iYWNrX3Bob3RvOiBwcmV2aWV3VXJsLFxyXG4gICAgICAgIH0pKTtcclxuICAgICAgICBzZXRSZXBsYWNlZERvY3VtZW50cygocHJldikgPT4gKHtcclxuICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICB1c2VyX25vbWluZWVfYWRoYXJjYXJkX2JhY2tfcGhvdG86IHRydWUsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICB9IGVsc2UgaWYgKGZpZWxkID09PSBcIm5vbWluZWVfcGFuY2FyZFwiKSB7XHJcbiAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgbm9taW5lZToge1xyXG4gICAgICAgICAgICAuLi5wcmV2Lm5vbWluZWUsXHJcbiAgICAgICAgICAgIHVzZXJfbm9taW5lZV9wYW5jYXJkX3Bob3RvOiBmaWxlLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgc2V0RmlsZVByZXZpZXdzKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgIHVzZXJfbm9taW5lZV9wYW5jYXJkX3Bob3RvOiBwcmV2aWV3VXJsLFxyXG4gICAgICAgIH0pKTtcclxuICAgICAgICBzZXRSZXBsYWNlZERvY3VtZW50cygocHJldikgPT4gKHtcclxuICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICB1c2VyX25vbWluZWVfcGFuY2FyZF9waG90bzogdHJ1ZSxcclxuICAgICAgICB9KSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgW2ZpZWxkXTogZmlsZSxcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgc2V0RmlsZVByZXZpZXdzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbZmllbGRdOiBwcmV2aWV3VXJsIH0pKTtcclxuICAgICAgICBzZXRSZXBsYWNlZERvY3VtZW50cygocHJldikgPT4gKHsgLi4ucHJldiwgW2ZpZWxkXTogdHJ1ZSB9KSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVGaWxlUmVtb3ZlID0gKGZpZWxkKSA9PiB7XHJcbiAgICBpZiAoZmllbGQgPT09IFwibm9taW5lZV9hZGhhcmNhcmRfZnJvbnRcIikge1xyXG4gICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIG5vbWluZWU6IHtcclxuICAgICAgICAgIC4uLnByZXYubm9taW5lZSxcclxuICAgICAgICAgIHVzZXJfbm9taW5lZV9hZGhhcmNhcmRfZnJvbnRfcGhvdG86IG51bGwsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSkpO1xyXG4gICAgICBzZXRGaWxlUHJldmlld3MoKHByZXYpID0+ICh7XHJcbiAgICAgICAgLi4ucHJldixcclxuICAgICAgICB1c2VyX25vbWluZWVfYWRoYXJjYXJkX2Zyb250X3Bob3RvOiBudWxsLFxyXG4gICAgICB9KSk7XHJcbiAgICAgIHNldFJlcGxhY2VkRG9jdW1lbnRzKChwcmV2KSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgdXNlcl9ub21pbmVlX2FkaGFyY2FyZF9mcm9udF9waG90bzogZmFsc2UsXHJcbiAgICAgIH0pKTtcclxuICAgIH0gZWxzZSBpZiAoZmllbGQgPT09IFwibm9taW5lZV9hZGhhcmNhcmRfYmFja1wiKSB7XHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgbm9taW5lZToge1xyXG4gICAgICAgICAgLi4ucHJldi5ub21pbmVlLFxyXG4gICAgICAgICAgdXNlcl9ub21pbmVlX2FkaGFyY2FyZF9iYWNrX3Bob3RvOiBudWxsLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pKTtcclxuICAgICAgc2V0RmlsZVByZXZpZXdzKChwcmV2KSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgdXNlcl9ub21pbmVlX2FkaGFyY2FyZF9iYWNrX3Bob3RvOiBudWxsLFxyXG4gICAgICB9KSk7XHJcbiAgICAgIHNldFJlcGxhY2VkRG9jdW1lbnRzKChwcmV2KSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgdXNlcl9ub21pbmVlX2FkaGFyY2FyZF9iYWNrX3Bob3RvOiBmYWxzZSxcclxuICAgICAgfSkpO1xyXG4gICAgfSBlbHNlIGlmIChmaWVsZCA9PT0gXCJub21pbmVlX3BhbmNhcmRcIikge1xyXG4gICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIG5vbWluZWU6IHtcclxuICAgICAgICAgIC4uLnByZXYubm9taW5lZSxcclxuICAgICAgICAgIHVzZXJfbm9taW5lZV9wYW5jYXJkX3Bob3RvOiBudWxsLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pKTtcclxuICAgICAgc2V0RmlsZVByZXZpZXdzKChwcmV2KSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgdXNlcl9ub21pbmVlX3BhbmNhcmRfcGhvdG86IG51bGwsXHJcbiAgICAgIH0pKTtcclxuICAgICAgc2V0UmVwbGFjZWREb2N1bWVudHMoKHByZXYpID0+ICh7XHJcbiAgICAgICAgLi4ucHJldixcclxuICAgICAgICB1c2VyX25vbWluZWVfcGFuY2FyZF9waG90bzogZmFsc2UsXHJcbiAgICAgIH0pKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgW2ZpZWxkXTogbnVsbCxcclxuICAgICAgfSkpO1xyXG4gICAgICBzZXRGaWxlUHJldmlld3MoKHByZXYpID0+ICh7IC4uLnByZXYsIFtmaWVsZF06IG51bGwgfSkpO1xyXG4gICAgICBzZXRSZXBsYWNlZERvY3VtZW50cygocHJldikgPT4gKHsgLi4ucHJldiwgW2ZpZWxkXTogZmFsc2UgfSkpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVByZXZpZXcgPSAoaW1hZ2VVcmwsIHRpdGxlKSA9PiB7XHJcbiAgICBzZXRQcmV2aWV3SW1hZ2UoaW1hZ2VVcmwpO1xyXG4gICAgc2V0UHJldmlld1RpdGxlKHRpdGxlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDYW5jZWxQcmV2aWV3ID0gKCkgPT4ge1xyXG4gICAgc2V0UHJldmlld0ltYWdlKG51bGwpO1xyXG4gICAgc2V0UHJldmlld1RpdGxlKFwiXCIpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZU5vbWluZWVUZXh0Q2hhbmdlID0gKGUsIGZpZWxkKSA9PiB7XHJcbiAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICBub21pbmVlOiB7XHJcbiAgICAgICAgLi4uZm9ybURhdGEubm9taW5lZSxcclxuICAgICAgICBbZmllbGRdOiBlLnRhcmdldC52YWx1ZSxcclxuICAgICAgfSxcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGFkZE90aGVyRG9jdW1lbnQgPSAoKSA9PiB7XHJcbiAgICBpZiAob3RoZXJEb2N1bWVudHMubGVuZ3RoID49IDEpIHtcclxuICAgICAgbWVzc2FnZS53YXJuaW5nKFwiWW91IGNhbiBvbmx5IGFkZCBvbmUgb3RoZXIgZG9jdW1lbnRcIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBuZXdJZCA9IERhdGUubm93KCkudG9TdHJpbmcoKTtcclxuICAgIHNldE90aGVyRG9jdW1lbnRzKFtcclxuICAgICAgLi4ub3RoZXJEb2N1bWVudHMsXHJcbiAgICAgIHtcclxuICAgICAgICBpZDogbmV3SWQsXHJcbiAgICAgICAgbmFtZTogXCJcIixcclxuICAgICAgICBmaWxlOiBudWxsLFxyXG4gICAgICAgIHByZXZpZXc6IG51bGwsXHJcbiAgICAgICAgZXhpc3RpbmdVcmw6IG51bGwsXHJcbiAgICAgICAgZXhpc3RpbmdOYW1lOiBudWxsLFxyXG4gICAgICB9LFxyXG4gICAgXSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgcmVtb3ZlT3RoZXJEb2N1bWVudCA9IChpZCkgPT4ge1xyXG4gICAgY29uc3QgZG9jVG9SZW1vdmUgPSBvdGhlckRvY3VtZW50cy5maW5kKChkb2MpID0+IGRvYy5pZCA9PT0gaWQpO1xyXG4gICAgaWYgKGRvY1RvUmVtb3ZlPy5wcmV2aWV3KSB7XHJcbiAgICAgIFVSTC5yZXZva2VPYmplY3RVUkwoZG9jVG9SZW1vdmUucHJldmlldyk7XHJcbiAgICB9XHJcbiAgICBzZXRPdGhlckRvY3VtZW50cyhvdGhlckRvY3VtZW50cy5maWx0ZXIoKGRvYykgPT4gZG9jLmlkICE9PSBpZCkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHVwZGF0ZU90aGVyRG9jdW1lbnROYW1lID0gKGlkLCBuYW1lKSA9PiB7XHJcbiAgICBzZXRPdGhlckRvY3VtZW50cyhcclxuICAgICAgb3RoZXJEb2N1bWVudHMubWFwKChkb2MpID0+IChkb2MuaWQgPT09IGlkID8geyAuLi5kb2MsIG5hbWUgfSA6IGRvYykpLFxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVPdGhlckRvY3VtZW50RmlsZUNoYW5nZSA9IChlLCBpZCkgPT4ge1xyXG4gICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzWzBdO1xyXG4gICAgaWYgKGZpbGUpIHtcclxuICAgICAgY29uc3QgcHJldmlld1VybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoZmlsZSk7XHJcbiAgICAgIHNldE90aGVyRG9jdW1lbnRzKFxyXG4gICAgICAgIG90aGVyRG9jdW1lbnRzLm1hcCgoZG9jKSA9PlxyXG4gICAgICAgICAgZG9jLmlkID09PSBpZFxyXG4gICAgICAgICAgICA/IHtcclxuICAgICAgICAgICAgICAgIC4uLmRvYyxcclxuICAgICAgICAgICAgICAgIGZpbGUsXHJcbiAgICAgICAgICAgICAgICBwcmV2aWV3OiBwcmV2aWV3VXJsLFxyXG4gICAgICAgICAgICAgICAgZXhpc3RpbmdVcmw6IG51bGwsXHJcbiAgICAgICAgICAgICAgICBleGlzdGluZ05hbWU6IG51bGwsXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICA6IGRvYyxcclxuICAgICAgICApLFxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHJlbW92ZU90aGVyRG9jdW1lbnRGaWxlID0gKGlkKSA9PiB7XHJcbiAgICBjb25zdCBkb2NUb1VwZGF0ZSA9IG90aGVyRG9jdW1lbnRzLmZpbmQoKGRvYykgPT4gZG9jLmlkID09PSBpZCk7XHJcbiAgICBpZiAoZG9jVG9VcGRhdGU/LnByZXZpZXcpIHtcclxuICAgICAgVVJMLnJldm9rZU9iamVjdFVSTChkb2NUb1VwZGF0ZS5wcmV2aWV3KTtcclxuICAgIH1cclxuICAgIHNldE90aGVyRG9jdW1lbnRzKFxyXG4gICAgICBvdGhlckRvY3VtZW50cy5tYXAoKGRvYykgPT5cclxuICAgICAgICBkb2MuaWQgPT09IGlkID8geyAuLi5kb2MsIGZpbGU6IG51bGwsIHByZXZpZXc6IG51bGwgfSA6IGRvYyxcclxuICAgICAgKSxcclxuICAgICk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3VhcmFudG9yRmlsZUNoYW5nZSA9IChlLCBmaWVsZCkgPT4ge1xyXG4gICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzWzBdO1xyXG4gICAgaWYgKGZpbGUpIHtcclxuICAgICAgY29uc3QgcHJldmlld1VybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoZmlsZSk7XHJcbiAgICAgIHNldEd1YXJhbnRvckRhdGEoKHByZXYpID0+ICh7IC4uLnByZXYsIFtmaWVsZF06IGZpbGUgfSkpO1xyXG4gICAgICBzZXRHdWFyYW50b3JQcmV2aWV3cygocHJldikgPT4gKHsgLi4ucHJldiwgW2ZpZWxkXTogcHJldmlld1VybCB9KSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3VhcmFudG9yRmlsZVJlbW92ZSA9IChmaWVsZCkgPT4ge1xyXG4gICAgaWYgKGd1YXJhbnRvclByZXZpZXdzW2ZpZWxkXSkge1xyXG4gICAgICBVUkwucmV2b2tlT2JqZWN0VVJMKGd1YXJhbnRvclByZXZpZXdzW2ZpZWxkXSk7XHJcbiAgICB9XHJcbiAgICBzZXRHdWFyYW50b3JEYXRhKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbZmllbGRdOiBudWxsIH0pKTtcclxuICAgIHNldEd1YXJhbnRvclByZXZpZXdzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbZmllbGRdOiBudWxsIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgc2V0VXBsb2FkaW5nKHRydWUpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHVwbG9hZEZvcm1EYXRhID0gbmV3IEZvcm1EYXRhKCk7XHJcbiAgICAgIHVwbG9hZEZvcm1EYXRhLmFwcGVuZChcInVzZXJfaWRcIiwgc2VsZWN0ZWRDdXN0b21lci5faWQpO1xyXG5cclxuICAgICAgaWYgKGZvcm1EYXRhLm5vbWluZWUubmFtZSkge1xyXG4gICAgICAgIHVwbG9hZEZvcm1EYXRhLmFwcGVuZChcIm5vbWluZWVfbmFtZVwiLCBmb3JtRGF0YS5ub21pbmVlLm5hbWUpO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChmb3JtRGF0YS5ub21pbmVlLnBob25lTnVtYmVyKSB7XHJcbiAgICAgICAgdXBsb2FkRm9ybURhdGEuYXBwZW5kKFwibm9taW5lZV9waG9uZVwiLCBmb3JtRGF0YS5ub21pbmVlLnBob25lTnVtYmVyKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgZmlsZUZpZWxkcyA9IFtcclxuICAgICAgICBcInVzZXJfcHJvZmlsZV9waG90b1wiLFxyXG4gICAgICAgIFwidXNlcl9hZGhhcmNhcmRfZnJvbnRfcGhvdG9cIixcclxuICAgICAgICBcInVzZXJfYWRoYXJjYXJkX2JhY2tfcGhvdG9cIixcclxuICAgICAgICBcInVzZXJfcGFuY2FyZF9waG90b1wiLFxyXG4gICAgICAgIFwidXNlcl9jaGVxdWVfbGVhZlwiLFxyXG4gICAgICAgIFwiYmFua19zdGF0ZW1lbnRfbW9udGhcIixcclxuICAgICAgICBcImJhbmtfcGFzc2Jvb2tfcGhvdG9cIixcclxuICAgICAgICBcImJ1c2luZXNzX2RvY3VtZW50X3Byb29mXCIsXHJcbiAgICAgICAgXCJ1c2VyX3NhbGFyeV9zbGlwXCIsXHJcbiAgICAgIF07XHJcblxyXG4gICAgICBmaWxlRmllbGRzLmZvckVhY2goKGZpZWxkKSA9PiB7XHJcbiAgICAgICAgaWYgKGZvcm1EYXRhW2ZpZWxkXSkge1xyXG4gICAgICAgICAgdXBsb2FkRm9ybURhdGEuYXBwZW5kKGZpZWxkLCBmb3JtRGF0YVtmaWVsZF0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCBub21pbmVlRmllbGRzID0gW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGtleTogXCJ1c2VyX25vbWluZWVfYWRoYXJjYXJkX2Zyb250X3Bob3RvXCIsXHJcbiAgICAgICAgICB2YWx1ZTogZm9ybURhdGEubm9taW5lZS51c2VyX25vbWluZWVfYWRoYXJjYXJkX2Zyb250X3Bob3RvLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAga2V5OiBcInVzZXJfbm9taW5lZV9hZGhhcmNhcmRfYmFja19waG90b1wiLFxyXG4gICAgICAgICAgdmFsdWU6IGZvcm1EYXRhLm5vbWluZWUudXNlcl9ub21pbmVlX2FkaGFyY2FyZF9iYWNrX3Bob3RvLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAga2V5OiBcInVzZXJfbm9taW5lZV9wYW5jYXJkX3Bob3RvXCIsXHJcbiAgICAgICAgICB2YWx1ZTogZm9ybURhdGEubm9taW5lZS51c2VyX25vbWluZWVfcGFuY2FyZF9waG90byxcclxuICAgICAgICB9LFxyXG4gICAgICBdO1xyXG5cclxuICAgICAgbm9taW5lZUZpZWxkcy5mb3JFYWNoKChmaWVsZCkgPT4ge1xyXG4gICAgICAgIGlmIChmaWVsZC52YWx1ZSkge1xyXG4gICAgICAgICAgdXBsb2FkRm9ybURhdGEuYXBwZW5kKGZpZWxkLmtleSwgZmllbGQudmFsdWUpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcblxyXG4gICAgICBpZiAob3RoZXJEb2N1bWVudHMubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIGNvbnN0IG90aGVyRG9jID0gb3RoZXJEb2N1bWVudHNbMF07XHJcbiAgICAgICAgaWYgKG90aGVyRG9jLm5hbWUgJiYgb3RoZXJEb2MubmFtZS50cmltKCkpIHtcclxuICAgICAgICAgIHVwbG9hZEZvcm1EYXRhLmFwcGVuZChcIm90aGVyX2RvY3VtZW50c19uYW1lXCIsIG90aGVyRG9jLm5hbWUudHJpbSgpKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKG90aGVyRG9jLmZpbGUpIHtcclxuICAgICAgICAgIHVwbG9hZEZvcm1EYXRhLmFwcGVuZChcIm90aGVyX2RvY3VtZW50c19waG90b1wiLCBvdGhlckRvYy5maWxlKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoXHJcbiAgICAgICAgXCIvdjEvYWRtaW4vdXNlci1kb2N1bWVudHNcIixcclxuICAgICAgICB1cGxvYWRGb3JtRGF0YSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwibXVsdGlwYXJ0L2Zvcm0tZGF0YVwiLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9LFxyXG4gICAgICApO1xyXG5cclxuICAgICAgaWYgKHJlc3BvbnNlLmRhdGEuc3VjY2Vzcykge1xyXG4gICAgICAgIG1lc3NhZ2Uuc3VjY2VzcyhleGlzdGluZ0RvY3VtZW50cyA/IFwiRG9jdW1lbnRzIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5IVwiIDogXCJEb2N1bWVudHMgdXBsb2FkZWQgc3VjY2Vzc2Z1bGx5IVwiKTtcclxuICAgICAgICBhd2FpdCBmZXRjaFVzZXJEb2N1bWVudHMoc2VsZWN0ZWRDdXN0b21lci5faWQpO1xyXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgc2V0U2hvd1VwbG9hZE1vZGFsKGZhbHNlKTtcclxuICAgICAgICAgIHJlc2V0Rm9ybSgpO1xyXG4gICAgICAgIH0sIDE1MDApO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBsb2FkaW5nIGRvY3VtZW50czpcIiwgZXJyb3IpO1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIHVwbG9hZCBkb2N1bWVudHNcIixcclxuICAgICAgKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldFVwbG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgcmVzZXRGb3JtID0gKCkgPT4ge1xyXG4gICAgT2JqZWN0LnZhbHVlcyhmaWxlUHJldmlld3MpLmZvckVhY2goKHByZXZpZXcpID0+IHtcclxuICAgICAgaWYgKHByZXZpZXcpIFVSTC5yZXZva2VPYmplY3RVUkwocHJldmlldyk7XHJcbiAgICB9KTtcclxuXHJcbiAgICBvdGhlckRvY3VtZW50cy5mb3JFYWNoKChkb2MpID0+IHtcclxuICAgICAgaWYgKGRvYy5wcmV2aWV3KSBVUkwucmV2b2tlT2JqZWN0VVJMKGRvYy5wcmV2aWV3KTtcclxuICAgIH0pO1xyXG5cclxuICAgIE9iamVjdC52YWx1ZXMoZ3VhcmFudG9yUHJldmlld3MpLmZvckVhY2goKHByZXZpZXcpID0+IHtcclxuICAgICAgaWYgKHByZXZpZXcpIFVSTC5yZXZva2VPYmplY3RVUkwocHJldmlldyk7XHJcbiAgICB9KTtcclxuXHJcbiAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgIHVzZXJfcHJvZmlsZV9waG90bzogbnVsbCxcclxuICAgICAgdXNlcl9hZGhhcmNhcmRfZnJvbnRfcGhvdG86IG51bGwsXHJcbiAgICAgIHVzZXJfYWRoYXJjYXJkX2JhY2tfcGhvdG86IG51bGwsXHJcbiAgICAgIHVzZXJfcGFuY2FyZF9waG90bzogbnVsbCxcclxuICAgICAgdXNlcl9jaGVxdWVfbGVhZjogbnVsbCxcclxuICAgICAgYmFua19zdGF0ZW1lbnRfbW9udGg6IG51bGwsXHJcbiAgICAgIGJhbmtfcGFzc2Jvb2tfcGhvdG86IG51bGwsXHJcbiAgICAgIGJ1c2luZXNzX2RvY3VtZW50X3Byb29mOiBudWxsLFxyXG4gICAgICB1c2VyX3NhbGFyeV9zbGlwOiBudWxsLFxyXG4gICAgICBub21pbmVlOiB7XHJcbiAgICAgICAgbmFtZTogZXhpc3RpbmdEb2N1bWVudHM/Lm5vbWluZWVfbmFtZSB8fCBcIlwiLFxyXG4gICAgICAgIHBob25lTnVtYmVyOiBleGlzdGluZ0RvY3VtZW50cz8ubm9taW5lZV9waG9uZSB8fCBcIlwiLFxyXG4gICAgICAgIHVzZXJfbm9taW5lZV9hZGhhcmNhcmRfZnJvbnRfcGhvdG86IG51bGwsXHJcbiAgICAgICAgdXNlcl9ub21pbmVlX2FkaGFyY2FyZF9iYWNrX3Bob3RvOiBudWxsLFxyXG4gICAgICAgIHVzZXJfbm9taW5lZV9wYW5jYXJkX3Bob3RvOiBudWxsLFxyXG4gICAgICB9LFxyXG4gICAgfSk7XHJcblxyXG4gICAgc2V0RmlsZVByZXZpZXdzKHtcclxuICAgICAgdXNlcl9wcm9maWxlX3Bob3RvOiBudWxsLFxyXG4gICAgICB1c2VyX2FkaGFyY2FyZF9mcm9udF9waG90bzogbnVsbCxcclxuICAgICAgdXNlcl9hZGhhcmNhcmRfYmFja19waG90bzogbnVsbCxcclxuICAgICAgdXNlcl9wYW5jYXJkX3Bob3RvOiBudWxsLFxyXG4gICAgICB1c2VyX2NoZXF1ZV9sZWFmOiBudWxsLFxyXG4gICAgICBiYW5rX3N0YXRlbWVudF9tb250aDogbnVsbCxcclxuICAgICAgYmFua19wYXNzYm9va19waG90bzogbnVsbCxcclxuICAgICAgYnVzaW5lc3NfZG9jdW1lbnRfcHJvb2Y6IG51bGwsXHJcbiAgICAgIHVzZXJfc2FsYXJ5X3NsaXA6IG51bGwsXHJcbiAgICAgIHVzZXJfbm9taW5lZV9hZGhhcmNhcmRfZnJvbnRfcGhvdG86IG51bGwsXHJcbiAgICAgIHVzZXJfbm9taW5lZV9hZGhhcmNhcmRfYmFja19waG90bzogbnVsbCxcclxuICAgICAgdXNlcl9ub21pbmVlX3BhbmNhcmRfcGhvdG86IG51bGwsXHJcbiAgICB9KTtcclxuXHJcbiAgICBpZiAoXHJcbiAgICAgIGV4aXN0aW5nRG9jdW1lbnRzPy5vdGhlcl9kb2N1bWVudHNfbmFtZSB8fFxyXG4gICAgICBleGlzdGluZ0RvY3VtZW50cz8ub3RoZXJfZG9jdW1lbnRzX3Bob3RvXHJcbiAgICApIHtcclxuICAgICAgc2V0T3RoZXJEb2N1bWVudHMoW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgIGlkOiBEYXRlLm5vdygpLnRvU3RyaW5nKCksXHJcbiAgICAgICAgICBuYW1lOiBleGlzdGluZ0RvY3VtZW50cy5vdGhlcl9kb2N1bWVudHNfbmFtZSB8fCBcIlwiLFxyXG4gICAgICAgICAgZmlsZTogbnVsbCxcclxuICAgICAgICAgIHByZXZpZXc6IG51bGwsXHJcbiAgICAgICAgICBleGlzdGluZ1VybDogZXhpc3RpbmdEb2N1bWVudHMub3RoZXJfZG9jdW1lbnRzX3Bob3RvIHx8IG51bGwsXHJcbiAgICAgICAgICBleGlzdGluZ05hbWU6IGV4aXN0aW5nRG9jdW1lbnRzLm90aGVyX2RvY3VtZW50c19uYW1lIHx8IFwiXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgXSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRPdGhlckRvY3VtZW50cyhbXSk7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0U2hvd0d1YXJhbnRvcihmYWxzZSk7XHJcbiAgICBzZXRHdWFyYW50b3JEYXRhKHtcclxuICAgICAgbmFtZTogXCJcIixcclxuICAgICAgcGhvbmVOdW1iZXI6IFwiXCIsXHJcbiAgICAgIGVtYWlsOiBcIlwiLFxyXG4gICAgICBhZGRyZXNzOiBcIlwiLFxyXG4gICAgICBhYWRoYXJGcm9udDogbnVsbCxcclxuICAgICAgcGFuQ2FyZDogbnVsbCxcclxuICAgICAgcGhvdG86IG51bGwsXHJcbiAgICB9KTtcclxuICAgIHNldEd1YXJhbnRvclByZXZpZXdzKHtcclxuICAgICAgYWFkaGFyRnJvbnQ6IG51bGwsXHJcbiAgICAgIHBhbkNhcmQ6IG51bGwsXHJcbiAgICAgIHBob3RvOiBudWxsLFxyXG4gICAgfSk7XHJcblxyXG4gICAgc2V0UmVwbGFjZWREb2N1bWVudHMoe30pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbiAgICBzZXRTZWFyY2hUZXh0KGUudGFyZ2V0LnZhbHVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBnZXRVcGxvYWRlZERvY3VtZW50cyA9ICgpID0+IHtcclxuICAgIGlmICghZXhpc3RpbmdEb2N1bWVudHMpIHJldHVybiBbXTtcclxuICAgIGNvbnN0IGRvY3VtZW50cyA9IFtdO1xyXG5cclxuICAgIFJFUVVJUkVEX0RPQ1VNRU5UUy5mb3JFYWNoKChkb2MpID0+IHtcclxuICAgICAgaWYgKGV4aXN0aW5nRG9jdW1lbnRzW2RvYy5rZXldKSB7XHJcbiAgICAgICAgZG9jdW1lbnRzLnB1c2goe1xyXG4gICAgICAgICAga2V5OiBkb2Mua2V5LFxyXG4gICAgICAgICAgbGFiZWw6IGRvYy5sYWJlbCxcclxuICAgICAgICAgIHVybDogZXhpc3RpbmdEb2N1bWVudHNbZG9jLmtleV0sXHJcbiAgICAgICAgICBpc0ltYWdlOiBleGlzdGluZ0RvY3VtZW50c1tkb2Mua2V5XT8ubWF0Y2goXHJcbiAgICAgICAgICAgIC9cXC4oanBlZ3xqcGd8Z2lmfHBuZ3x3ZWJwKSQvaSxcclxuICAgICAgICAgICksXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIGlmIChleGlzdGluZ0RvY3VtZW50cy5vdGhlcl9kb2N1bWVudHNfcGhvdG8pIHtcclxuICAgICAgZG9jdW1lbnRzLnB1c2goe1xyXG4gICAgICAgIGtleTogXCJvdGhlcl9kb2N1bWVudHNfcGhvdG9cIixcclxuICAgICAgICBsYWJlbDogZXhpc3RpbmdEb2N1bWVudHMub3RoZXJfZG9jdW1lbnRzX25hbWUgfHwgXCJPdGhlciBEb2N1bWVudFwiLFxyXG4gICAgICAgIHVybDogZXhpc3RpbmdEb2N1bWVudHMub3RoZXJfZG9jdW1lbnRzX3Bob3RvLFxyXG4gICAgICAgIGlzSW1hZ2U6IGV4aXN0aW5nRG9jdW1lbnRzLm90aGVyX2RvY3VtZW50c19waG90bz8ubWF0Y2goXHJcbiAgICAgICAgICAvXFwuKGpwZWd8anBnfGdpZnxwbmd8d2VicCkkL2ksXHJcbiAgICAgICAgKSxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGRvY3VtZW50cztcclxuICB9O1xyXG5cclxuICBjb25zdCB1cGxvYWRlZERvY3VtZW50cyA9IGdldFVwbG9hZGVkRG9jdW1lbnRzKCk7XHJcblxyXG4gIGlmIChpbml0aWFsaXppbmcpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03IGZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIHsvKiBUb2FzdCBOb3RpZmljYXRpb24gKi99XHJcbiAgICAgIHt0b2FzdC5zaG93ICYmIChcclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICBjbGFzc05hbWU9e2BmaXhlZCB0b3AtMjAgcmlnaHQtNCB6LTUwIHB4LTQgcHktMyByb3VuZGVkLWxnIHNoYWRvdy1sZyAke1xyXG4gICAgICAgICAgICB0b2FzdC50eXBlID09PSBcInN1Y2Nlc3NcIiA/IFwiYmctZ3JlZW4tNTAwXCIgOiBcImJnLXJlZC01MDBcIlxyXG4gICAgICAgICAgfSB0ZXh0LXdoaXRlIGFuaW1hdGUtc2xpZGUtaW5gfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHt0b2FzdC5tZXNzYWdlfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAgey8qIEltYWdlIFByZXZpZXcgTW9kYWwgKi99XHJcbiAgICAgIDxNb2RhbFxyXG4gICAgICAgIG9wZW49e3ByZXZpZXdJbWFnZSAhPT0gbnVsbH1cclxuICAgICAgICB0aXRsZT17cHJldmlld1RpdGxlfVxyXG4gICAgICAgIGZvb3Rlcj17bnVsbH1cclxuICAgICAgICBvbkNhbmNlbD17aGFuZGxlQ2FuY2VsUHJldmlld31cclxuICAgICAgICB3aWR0aD1cImF1dG9cIlxyXG4gICAgICAgIHN0eWxlPXt7IG1heFdpZHRoOiBcIjkwdndcIiB9fVxyXG4gICAgICA+XHJcbiAgICAgICAgPGltZyBhbHQ9e3ByZXZpZXdUaXRsZX0gc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19IHNyYz17cHJldmlld0ltYWdlfSAvPlxyXG4gICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXtvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbiAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgICA8QnJlYWRjcnVtYi8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi02XCI+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgQ3VzdG9tZXIgRG9jdW1lbnQgVXBsb2FkXHJcbiAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgU2VhcmNoIGFuZCBzZWxlY3QgYSBjdXN0b21lciB0byB1cGxvYWQgZG9jdW1lbnRzXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBTZWFyY2ggU2VjdGlvbiAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtNTAgcm91bmRlZC0zeGwgYm9yZGVyIHAtOFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtbGcgdGV4dC1ncmF5LTcwMCB0ZXh0LWNlbnRlciBmb250LXNlbWlib2xkIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgU2VsZWN0IEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggb3IgU2VsZWN0IEN1c3RvbWVyIGJ5IE5hbWUgb3IgUGhvbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDdXN0b21lclNlbGVjdH1cclxuICAgICAgICAgICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgIG5vdEZvdW5kQ29udGVudD17XHJcbiAgICAgICAgICAgICAgICAgICAgICBsb2FkaW5nID8gPFNwaW4gc2l6ZT1cInNtYWxsXCIgLz4gOiBcIk5vIGN1c3RvbWVycyBmb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGxhYmVsID1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uPy5sYWJlbD8udG9TdHJpbmcoKS50b0xvd2VyQ2FzZSgpIHx8IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbGFiZWwuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIsIG1heFdpZHRoOiBcIjYwMHB4XCIsIGhlaWdodDogXCI1MHB4XCIgfX1cclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEN1c3RvbWVyPy5faWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e2N1c3RvbWVycy5tYXAoKGN1c3RvbWVyKSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IGN1c3RvbWVyLl9pZCxcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBgJHtjdXN0b21lci5uYW1lfSAtICR7Y3VzdG9tZXIucGhvbmV9YCxcclxuICAgICAgICAgICAgICAgICAgICB9KSl9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogU2VsZWN0ZWQgQ3VzdG9tZXIgQ2FyZCB3aXRoIEZ1bGwgRGV0YWlscyAqL31cclxuICAgICAgICAgIHtzZWxlY3RlZEN1c3RvbWVyICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02XCI+XHJcbiAgICAgICAgICAgICAgey8qIEhlYWRlciBDYXJkICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNTAgdG8taW5kaWdvLTUwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ibHVlLTIwMCBzaGFkb3ctc20gcC02IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgZmxleC13cmFwIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWJsdWUtNjAwIGZvbnQtc2VtaWJvbGQgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2VsZWN0ZWQgQ3VzdG9tZXI6XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkQ3VzdG9tZXIubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBzcGFjZS15LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPkVtYWlsOjwvc3Bhbj4ge3NlbGVjdGVkQ3VzdG9tZXIuZW1haWwgfHwgJ04vQSd9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj5QaG9uZTo8L3NwYW4+IHtzZWxlY3RlZEN1c3RvbWVyLnBob25lIHx8ICdOL0EnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkQ3VzdG9tZXIuY3VzdG9tZXJfaWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPkN1c3RvbWVyIElEOjwvc3Bhbj4gPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWJsdWUtNjAwXCI+e3NlbGVjdGVkQ3VzdG9tZXIuY3VzdG9tZXJfaWR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2V4aXN0aW5nRG9jdW1lbnRzICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBwLTMgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gbWluLXctWzIwMHB4XVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBEb2N1bWVudCBTdGF0dXM6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtc20gZm9udC1zZW1pYm9sZCAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnRQZXJjZW50YWdlID09PSAxMDAgPyBcInRleHQtZ3JlZW4tNjAwXCIgOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnRQZXJjZW50YWdlID49IDcwID8gXCJ0ZXh0LXllbGxvdy02MDBcIiA6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcInRleHQtcmVkLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2RvY3VtZW50UGVyY2VudGFnZX0lIENvbXBsZXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFByb2dyZXNzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGVyY2VudD17ZG9jdW1lbnRQZXJjZW50YWdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUNvbG9yPXtkb2N1bWVudFBlcmNlbnRhZ2UgPT09IDEwMCA/IFwiIzUyYzQxYVwiIDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRvY3VtZW50UGVyY2VudGFnZSA+PSA3MCA/IFwiI2ZhYWQxNFwiIDogXCIjZmY0ZDRmXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMiBtdC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1ZpZXdNb2RhbCh0cnVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1ncmVlbi02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIGhvdmVyOmJnLWdyZWVuLTcwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbSBmbGV4LTEganVzdGlmeS1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJb0V5ZSAvPiBWaWV3ICh7dXBsb2FkZWREb2N1bWVudHMubGVuZ3RofSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93VXBsb2FkTW9kYWwodHJ1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctYmx1ZS02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIGhvdmVyOmJnLWJsdWUtNzAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIGZsZXgtMSBqdXN0aWZ5LWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2V4aXN0aW5nRG9jdW1lbnRzID8gXCJVcGRhdGVcIiA6IFwiVXBsb2FkXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICB7IWV4aXN0aW5nRG9jdW1lbnRzICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1VwbG9hZE1vZGFsKHRydWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC02IHB5LTMgYmctYmx1ZS02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIGhvdmVyOmJnLWJsdWUtNzAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBVcGxvYWQgRG9jdW1lbnRzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogRnVsbCBDdXN0b21lciBEZXRhaWxzICovfVxyXG4gICAgICAgICAgICAgIHtsb2FkaW5nRGV0YWlscyA/IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBweS04XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSA6IGZ1bGxDdXN0b21lckRldGFpbHMgPyAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IFxyXG4gICAgICAgICAgICAgICAgICBpZD1cImN1c3RvbWVyLXByb2ZpbGUtcHJpbnRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1tZCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIG92ZXJmbG93LWhpZGRlbiBtYXgtdy00eGwgbXgtYXV0b1wiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB0by1ibHVlLTcwMCBweC00IHB5LTMgY3Vyc29yLXBvaW50ZXIgaG92ZXI6ZnJvbS1ibHVlLTcwMCBob3Zlcjp0by1ibHVlLTgwMCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzQ3VzdG9tZXJEZXRhaWxzT3BlbighaXNDdXN0b21lckRldGFpbHNPcGVuKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogTGVmdCBzaWRlIC0gTG9nbyBhbmQgQ3VzdG9tZXIgSW5mbyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIENvbXBhbnkgTG9nbyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgYmctd2hpdGUvMTAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiYWNrZHJvcC1ibHVyLXNtIGZsZXgtc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtjb21wYW55TG9nb31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD1cIk1ZQ0hJVFMgQ0hJVFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTggaC04IG9iamVjdC1jb250YWluXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uRXJyb3I9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0Lm9uZXJyb3IgPSBudWxsO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlLnRhcmdldC5zcmMgPSAnZGF0YTppbWFnZS9zdmcreG1sO2Jhc2U2NCxQSE4yWnlCNGJXeHVjejBpYUhSMGNEb3ZMM2QzZHk1M015NXZjbWN2TWpBd01DOXpkbWNpSUhkcFpIUm9QU0kwTUNJZ2FHVnBaMmgwUFNJME1DSWdkbWxsZDBKdmVEMGlNQ0F3SURRd0lEUXdJajQ4Y21WamRDQjNhV1IwYUQwaU5EQWlJR2hsYVdkb2REMGlOREFpSUdacGJHdzlJaU5tWm1abVptWWlJRzl3WVdOcGRIazlJakF1TWlJZ2NuZzlJallpTHo0OGRHVjRkQ0I0UFNJNElpQjVQU0l5TmlJZ1ptOXVkQzFtWVcxcGJIazlJa0Z5YVdGc0lpQm1iMjUwTFhOcGVtVTlJakU0SWlCbWFXeHNQU0lqWm1abVptWm1JajVOUXp3dmRHVjRkRDQ4TDNOMlp6ND0nO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgZm9udC1zZW1pYm9sZCB0ZXh0LWJhc2UgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPk1ZQ0hJVFMgQ0hJVDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmx1ZS0yMDAgdGV4dC1bMTBweF0gZm9udC1ub3JtYWxcIj7ihKI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtMTAwIHRleHQteHNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmdWxsQ3VzdG9tZXJEZXRhaWxzLmZ1bGxfbmFtZSB8fCBmdWxsQ3VzdG9tZXJEZXRhaWxzLm5hbWUgfHwgJ0N1c3RvbWVyJ30gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZnVsbEN1c3RvbWVyRGV0YWlscy5jdXN0b21lcl9pZCAmJiBgIOKAoiBJRDogJHtmdWxsQ3VzdG9tZXJEZXRhaWxzLmN1c3RvbWVyX2lkfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBSaWdodCBzaWRlIC0gT25seSBEb3dubG9hZCBCdXR0b24gYW5kIFRvZ2dsZSBBcnJvdyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgaGlkZS1pbi1wcmludFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogRG93bmxvYWQgUERGIEJ1dHRvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIGhvdmVyOmJnLXdoaXRlLzEwIHJvdW5kZWQtbGcgcC0xLjUgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZURvd25sb2FkUERGKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkRvd25sb2FkIFBERlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8SW9Eb3dubG9hZCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogVG9nZ2xlIEFycm93ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgaG92ZXI6Ymctd2hpdGUvMTAgcm91bmRlZC1mdWxsIHAtMSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgbWwtMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRJc0N1c3RvbWVyRGV0YWlsc09wZW4oIWlzQ3VzdG9tZXJEZXRhaWxzT3Blbik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LTUgaC01IHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTMwMCAke2lzQ3VzdG9tZXJEZXRhaWxzT3BlbiA/ICdyb3RhdGUtMTgwJyA6ICcnfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9ezJ9IGQ9XCJNMTkgOWwtNyA3LTctN1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIENvbGxhcHNpYmxlIENvbnRlbnQgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIG92ZXJmbG93LWhpZGRlbiAke2lzQ3VzdG9tZXJEZXRhaWxzT3BlbiA/ICdtYXgtaC1bNTAwMHB4XSBvcGFjaXR5LTEwMCcgOiAnbWF4LWgtMCBvcGFjaXR5LTAnfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBQZXJzb25hbCBJbmZvcm1hdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHB4LTQgcHktMiBib3JkZXItYiBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPElvUGVyc29uIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFBlcnNvbmFsIEluZm9ybWF0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAteC04IGdhcC15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggcHktMS41IGJvcmRlci1iIGJvcmRlci1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgdy0zMiBmb250LW1lZGl1bVwiPlRpdGxlOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTgwMFwiPntmdWxsQ3VzdG9tZXJEZXRhaWxzLnRpdGxlIHx8ICfigJQnfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggcHktMS41IGJvcmRlci1iIGJvcmRlci1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgdy0zMiBmb250LW1lZGl1bVwiPkZ1bGwgTmFtZTo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS04MDAgZm9udC1tZWRpdW1cIj57ZnVsbEN1c3RvbWVyRGV0YWlscy5mdWxsX25hbWUgfHwgZnVsbEN1c3RvbWVyRGV0YWlscy5uYW1lIHx8ICfigJQnfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggcHktMS41IGJvcmRlci1iIGJvcmRlci1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgdy0zMiBmb250LW1lZGl1bVwiPkZhdGhlcidzIE5hbWU6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktODAwXCI+e2Z1bGxDdXN0b21lckRldGFpbHMuZmF0aGVyX25hbWUgfHwgJ+KAlCd9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBweS0xLjUgYm9yZGVyLWIgYm9yZGVyLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCB3LTMyIGZvbnQtbWVkaXVtXCI+RGF0ZSBvZiBCaXJ0aDo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS04MDBcIj57Zm9ybWF0RGF0ZShmdWxsQ3VzdG9tZXJEZXRhaWxzLmRhdGVvZmJpcnRoKX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHB5LTEuNSBib3JkZXItYiBib3JkZXItZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHctMzIgZm9udC1tZWRpdW1cIj5HZW5kZXI6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktODAwXCI+e2Z1bGxDdXN0b21lckRldGFpbHMuZ2VuZGVyIHx8ICfigJQnfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggcHktMS41IGJvcmRlci1iIGJvcmRlci1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgdy0zMiBmb250LW1lZGl1bVwiPk1hcml0YWwgU3RhdHVzOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTgwMFwiPntmdWxsQ3VzdG9tZXJEZXRhaWxzLm1hcml0YWxfc3RhdHVzIHx8ICfigJQnfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggcHktMS41IGNvbC1zcGFuLTIgYm9yZGVyLWIgYm9yZGVyLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCB3LTMyIGZvbnQtbWVkaXVtXCI+TmF0aW9uYWxpdHk6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktODAwXCI+e2Z1bGxDdXN0b21lckRldGFpbHMubmF0aW9uYWxpdHkgfHwgJ+KAlCd9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogQ29udGFjdCBJbmZvcm1hdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHB4LTQgcHktMiBib3JkZXItYiBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPElvQ2FsbCBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQ29udGFjdCBJbmZvcm1hdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLXgtOCBnYXAteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHB5LTEuNSBib3JkZXItYiBib3JkZXItZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHctMzIgZm9udC1tZWRpdW1cIj5FbWFpbDo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtYmx1ZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj17YG1haWx0bzoke2Z1bGxDdXN0b21lckRldGFpbHMuZW1haWx9YH0gY2xhc3NOYW1lPVwiaG92ZXI6dW5kZXJsaW5lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Z1bGxDdXN0b21lckRldGFpbHMuZW1haWwgfHwgJ+KAlCd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggcHktMS41IGJvcmRlci1iIGJvcmRlci1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgdy0zMiBmb250LW1lZGl1bVwiPlBob25lOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTgwMFwiPntmdWxsQ3VzdG9tZXJEZXRhaWxzLnBob25lX251bWJlciB8fCBmdWxsQ3VzdG9tZXJEZXRhaWxzLnBob25lIHx8ICfigJQnfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggcHktMS41IGNvbC1zcGFuLTIgYm9yZGVyLWIgYm9yZGVyLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCB3LTMyIGZvbnQtbWVkaXVtXCI+QWx0ZXJuYXRlIFBob25lOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTgwMFwiPntmdWxsQ3VzdG9tZXJEZXRhaWxzLmFsdGVybmF0ZV9udW1iZXIgfHwgJ+KAlCd9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogQWRkcmVzcyBJbmZvcm1hdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHB4LTQgcHktMiBib3JkZXItYiBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPElvTG9jYXRpb24gY2xhc3NOYW1lPVwidGV4dC1wdXJwbGUtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBBZGRyZXNzIERldGFpbHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC14LTggZ2FwLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBweS0xLjUgYm9yZGVyLWIgYm9yZGVyLWdyYXktNTAgY29sLXNwYW4tMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHctMzIgZm9udC1tZWRpdW1cIj5BZGRyZXNzOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTgwMFwiPntmdWxsQ3VzdG9tZXJEZXRhaWxzLmFkZHJlc3MgfHwgJ+KAlCd9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBweS0xLjUgYm9yZGVyLWIgYm9yZGVyLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCB3LTMyIGZvbnQtbWVkaXVtXCI+VmlsbGFnZTo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS04MDBcIj57ZnVsbEN1c3RvbWVyRGV0YWlscy52aWxsYWdlIHx8ICfigJQnfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggcHktMS41IGJvcmRlci1iIGJvcmRlci1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgdy0zMiBmb250LW1lZGl1bVwiPlRhbHVrOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTgwMFwiPntmdWxsQ3VzdG9tZXJEZXRhaWxzLnRhbHVrIHx8ICfigJQnfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggcHktMS41IGJvcmRlci1iIGJvcmRlci1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgdy0zMiBmb250LW1lZGl1bVwiPkRpc3RyaWN0Ojwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTgwMFwiPntmdWxsQ3VzdG9tZXJEZXRhaWxzLmRpc3RyaWN0IHx8ICfigJQnfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggcHktMS41IGJvcmRlci1iIGJvcmRlci1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgdy0zMiBmb250LW1lZGl1bVwiPlN0YXRlOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTgwMFwiPntmdWxsQ3VzdG9tZXJEZXRhaWxzLnN0YXRlIHx8ICfigJQnfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggcHktMS41IGJvcmRlci1iIGJvcmRlci1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgdy0zMiBmb250LW1lZGl1bVwiPlBpbmNvZGU6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktODAwXCI+e2Z1bGxDdXN0b21lckRldGFpbHMucGluY29kZSB8fCAn4oCUJ308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBJZGVudGlmaWNhdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHB4LTQgcHktMiBib3JkZXItYiBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPElvRG9jdW1lbnRUZXh0IGNsYXNzTmFtZT1cInRleHQtYW1iZXItNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBJZGVudGlmaWNhdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLXgtOCBnYXAteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHB5LTEuNSBib3JkZXItYiBib3JkZXItZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHctMzIgZm9udC1tZWRpdW1cIj5BYWRoYXIgTnVtYmVyOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTgwMFwiPntmdWxsQ3VzdG9tZXJEZXRhaWxzLmFkaGFhcl9ubyB8fCAn4oCUJ308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHB5LTEuNSBib3JkZXItYiBib3JkZXItZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHctMzIgZm9udC1tZWRpdW1cIj5QQU4gTnVtYmVyOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTgwMFwiPntmdWxsQ3VzdG9tZXJEZXRhaWxzLnBhbl9ubyB8fCAn4oCUJ308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBCYW5rIERldGFpbHMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBweC00IHB5LTIgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxJb1dhbGxldCBjbGFzc05hbWU9XCJ0ZXh0LWN5YW4tNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBCYW5rIERldGFpbHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC14LTggZ2FwLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBweS0xLjUgYm9yZGVyLWIgYm9yZGVyLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCB3LTMyIGZvbnQtbWVkaXVtXCI+QmFuayBOYW1lOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTgwMFwiPntmdWxsQ3VzdG9tZXJEZXRhaWxzLmJhbmtfbmFtZSB8fCAn4oCUJ308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHB5LTEuNSBib3JkZXItYiBib3JkZXItZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHctMzIgZm9udC1tZWRpdW1cIj5CcmFuY2g6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktODAwXCI+e2Z1bGxDdXN0b21lckRldGFpbHMuYmFua19icmFuY2hfbmFtZSB8fCAn4oCUJ308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHB5LTEuNSBib3JkZXItYiBib3JkZXItZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHctMzIgZm9udC1tZWRpdW1cIj5BY2NvdW50IE51bWJlcjo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS04MDBcIj57ZnVsbEN1c3RvbWVyRGV0YWlscy5iYW5rX2FjY291bnRfbnVtYmVyIHx8ICfigJQnfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggcHktMS41IGJvcmRlci1iIGJvcmRlci1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgdy0zMiBmb250LW1lZGl1bVwiPklGU0MgQ29kZTo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS04MDBcIj57ZnVsbEN1c3RvbWVyRGV0YWlscy5iYW5rX0lGU0NfY29kZSB8fCAn4oCUJ308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBOb21pbmVlIEluZm9ybWF0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcHgtNCBweS0yIGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8SW9QZXJzb24gY2xhc3NOYW1lPVwidGV4dC1yb3NlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTm9taW5lZSBJbmZvcm1hdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLXgtOCBnYXAteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHB5LTEuNSBib3JkZXItYiBib3JkZXItZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHctMzIgZm9udC1tZWRpdW1cIj5Ob21pbmVlIE5hbWU6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktODAwXCI+e2Z1bGxDdXN0b21lckRldGFpbHMubm9taW5lZV9uYW1lIHx8ICfigJQnfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggcHktMS41IGJvcmRlci1iIGJvcmRlci1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgdy0zMiBmb250LW1lZGl1bVwiPlJlbGF0aW9uc2hpcDo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS04MDBcIj57ZnVsbEN1c3RvbWVyRGV0YWlscy5ub21pbmVlX3JlbGF0aW9uc2hpcCB8fCAn4oCUJ308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHB5LTEuNSBib3JkZXItYiBib3JkZXItZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHctMzIgZm9udC1tZWRpdW1cIj5QaG9uZTo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS04MDBcIj57ZnVsbEN1c3RvbWVyRGV0YWlscy5ub21pbmVlX3Bob25lX251bWJlciB8fCAn4oCUJ308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHB5LTEuNSBib3JkZXItYiBib3JkZXItZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHctMzIgZm9udC1tZWRpdW1cIj5EYXRlIG9mIEJpcnRoOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTgwMFwiPntmb3JtYXREYXRlKGZ1bGxDdXN0b21lckRldGFpbHMubm9taW5lZV9kYXRlb2ZiaXJ0aCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogQWRkaXRpb25hbCBJbmZvcm1hdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHB4LTQgcHktMiBib3JkZXItYiBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPElvRG9jdW1lbnRUZXh0IGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEFkZGl0aW9uYWwgSW5mb3JtYXRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC14LTggZ2FwLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBweS0xLjUgYm9yZGVyLWIgYm9yZGVyLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCB3LTMyIGZvbnQtbWVkaXVtXCI+UmVmZXJyYWwgTmFtZTo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS04MDBcIj57ZnVsbEN1c3RvbWVyRGV0YWlscy5yZWZlcnJlZF9lbXBsb3llZSB8fCBmdWxsQ3VzdG9tZXJEZXRhaWxzLnJlZmVycmFsX25hbWUgfHwgJ+KAlCd9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBweS0xLjUgYm9yZGVyLWIgYm9yZGVyLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCB3LTMyIGZvbnQtbWVkaXVtXCI+Q29sbGVjdGlvbiBBcmVhOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dHlwZW9mIGZ1bGxDdXN0b21lckRldGFpbHMuY29sbGVjdGlvbl9hcmVhID09PSAnb2JqZWN0JyBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGZ1bGxDdXN0b21lckRldGFpbHMuY29sbGVjdGlvbl9hcmVhPy5yb3V0ZV9uYW1lIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogZnVsbEN1c3RvbWVyRGV0YWlscy5jb2xsZWN0aW9uX2FyZWEgfHwgJ+KAlCd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHB5LTEuNSBib3JkZXItYiBib3JkZXItZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHctMzIgZm9udC1tZWRpdW1cIj5Db2xsZWN0aW9uIEV4ZWN1dGl2ZTo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS04MDBcIj57ZnVsbEN1c3RvbWVyRGV0YWlscy5jb2xsZWN0aW9uX2V4ZWN1dGl2ZSB8fCAn4oCUJ308L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHB5LTEuNSBib3JkZXItYiBib3JkZXItZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHctMzIgZm9udC1tZWRpdW1cIj5Eb2N1bWVudCBQcm9ncmVzczo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS04MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2Z1bGxDdXN0b21lckRldGFpbHMucGVyY2VudGFnZSB8fCAwfSU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0yNCBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgaC0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaC0xLjUgcm91bmRlZC1mdWxsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTUwMCAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZnVsbEN1c3RvbWVyRGV0YWlscy5wZXJjZW50YWdlIHx8IDApID49IDgwID8gJ2JnLWdyZWVuLTUwMCcgOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZnVsbEN1c3RvbWVyRGV0YWlscy5wZXJjZW50YWdlIHx8IDApID49IDUwID8gJ2JnLXllbGxvdy01MDAnIDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2JnLXJlZC01MDAnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBgJHtmdWxsQ3VzdG9tZXJEZXRhaWxzLnBlcmNlbnRhZ2UgfHwgMH0lYCB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHB5LTEuNSBib3JkZXItYiBib3JkZXItZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHctMzIgZm9udC1tZWRpdW1cIj5TdGF0dXM6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0zIHB5LTEgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1tZWRpdW0gJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmdWxsQ3VzdG9tZXJEZXRhaWxzLmFwcHJvdmFsX3N0YXR1cyA9PT0gJ3RydWUnIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tNzAwJyBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXllbGxvdy0xMDAgdGV4dC15ZWxsb3ctNzAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Z1bGxDdXN0b21lckRldGFpbHMuYXBwcm92YWxfc3RhdHVzID09PSAndHJ1ZScgPyAn4pyFIFZlcmlmaWVkJyA6ICfij7MgUGVuZGluZyd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggcHktMS41IGJvcmRlci1iIGJvcmRlci1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgdy0zMiBmb250LW1lZGl1bVwiPkN1c3RvbWVyIFNpbmNlOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTgwMFwiPntmb3JtYXREYXRlKGZ1bGxDdXN0b21lckRldGFpbHMuY3JlYXRlZEF0KX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBGb290ZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHB4LTYgcHktMyBib3JkZXItdCBib3JkZXItZ3JheS0yMDAgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPkdlbmVyYXRlZCBvbiB7bmV3IERhdGUoKS50b0xvY2FsZURhdGVTdHJpbmcoKX0g4oCiIEN1c3RvbWVyIFByb2ZpbGU8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktOCB0ZXh0LWdyYXktNTAwIGJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LW1kIGJvcmRlciBib3JkZXItZ3JheS0yMDAgbWF4LXctNHhsIG14LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgPElvRG9jdW1lbnRUZXh0IGNsYXNzTmFtZT1cInRleHQtNnhsIHRleHQtZ3JheS0zMDAgbXgtYXV0byBtYi00XCIgLz5cclxuICAgICAgICAgICAgICAgICAgPHA+Tm8gYWRkaXRpb25hbCBkZXRhaWxzIGF2YWlsYWJsZSBmb3IgdGhpcyBjdXN0b21lcjwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBtdC0yXCI+UGxlYXNlIHVwbG9hZCBkb2N1bWVudHMgdG8gc2VlIGNvbXBsZXRlIHByb2ZpbGU8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgey8qIEluc3RydWN0aW9ucyAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtOCBiZy1ncmF5LTUwIHJvdW5kZWQtbGcgcC02XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDAgbWItM1wiPlxyXG4gICAgICAgICAgICAgIEluc3RydWN0aW9uczpcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImxpc3QtZGlzYyBsaXN0LWluc2lkZSBzcGFjZS15LTIgdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgIDxsaT5TZWFyY2ggZm9yIGEgY3VzdG9tZXIgYnkgdHlwaW5nIHRoZWlyIG5hbWUgb3IgcGhvbmUgbnVtYmVyPC9saT5cclxuICAgICAgICAgICAgICA8bGk+U2VsZWN0IHRoZSBjdXN0b21lciBmcm9tIHRoZSBkcm9wZG93bjwvbGk+XHJcbiAgICAgICAgICAgICAgPGxpPkNsaWNrIG9uIFwiVXBsb2FkIERvY3VtZW50c1wiIGJ1dHRvbiB0byBwcm9jZWVkPC9saT5cclxuICAgICAgICAgICAgICA8bGk+RXhpc3RpbmcgZG9jdW1lbnRzIHdpbGwgYmUgc2hvd24gd2l0aCBwcmV2aWV3PC9saT5cclxuICAgICAgICAgICAgICA8bGk+Q2xpY2sgb24gYW55IGV4aXN0aW5nIGRvY3VtZW50IHRvIHZpZXcgaXQ8L2xpPlxyXG4gICAgICAgICAgICAgIDxsaT5VcGxvYWQgbmV3IGRvY3VtZW50cyB0byByZXBsYWNlIGV4aXN0aW5nIG9uZXM8L2xpPlxyXG4gICAgICAgICAgICAgIDxsaT5DbGljayBvbiB0aGUgcHJldmlldyBpbWFnZSB0byBzZWUgbGFyZ2VyIHZpZXc8L2xpPlxyXG4gICAgICAgICAgICAgIDxsaT5BbGwgZmllbGRzIG1hcmtlZCB3aXRoICogYXJlIG1hbmRhdG9yeTwvbGk+XHJcbiAgICAgICAgICAgICAgPGxpPlN1cHBvcnRlZCBmaWxlIGZvcm1hdHM6IEltYWdlcyAoSlBHLCBQTkcpIGFuZCBQREY8L2xpPlxyXG4gICAgICAgICAgICAgIDxsaT5NYXhpbXVtIGZpbGUgc2l6ZTogNU1CIHBlciBmaWxlPC9saT5cclxuICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBWaWV3IERvY3VtZW50cyBNb2RhbCAqL31cclxuICAgICAgPE1vZGFsXHJcbiAgICAgICAgb3Blbj17c2hvd1ZpZXdNb2RhbH1cclxuICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0U2hvd1ZpZXdNb2RhbChmYWxzZSl9XHJcbiAgICAgICAgZm9vdGVyPXtudWxsfVxyXG4gICAgICAgIHdpZHRoPXsxMDAwfVxyXG4gICAgICAgIGNlbnRlcmVkXHJcbiAgICAgICAgY2xhc3NOYW1lPVwiZG9jdW1lbnQtbW9kYWxcIlxyXG4gICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHByLTZcIj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgIFVwbG9hZGVkIERvY3VtZW50c1xyXG4gICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgIEN1c3RvbWVyOntcIiBcIn1cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAge3NlbGVjdGVkQ3VzdG9tZXI/Lm5hbWV9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ibHVlLTUwIHRleHQtYmx1ZS03MDAgcHgtNCBweS0yIHJvdW5kZWQteGwgdGV4dC1zbSBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgIFRvdGFsOiB7dXBsb2FkZWREb2N1bWVudHMubGVuZ3RofVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIH1cclxuICAgICAgPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LWgtWzc1dmhdIG92ZXJmbG93LXktYXV0byBwci0xXCI+XHJcbiAgICAgICAgICB7dXBsb2FkZWREb2N1bWVudHMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB5LTIwXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTI0IGgtMjQgcm91bmRlZC1mdWxsIGJnLWdyYXktMTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgIDxJb0RvY3VtZW50IGNsYXNzTmFtZT1cInRleHQtNXhsIHRleHQtZ3JheS00MDBcIiAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPk5vIERvY3VtZW50cyBGb3VuZDwvaDM+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgIE5vIHVwbG9hZGVkIGRvY3VtZW50cyBhcmUgYXZhaWxhYmxlIGZvciB0aGlzIGN1c3RvbWVyLlxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgeGw6Z3JpZC1jb2xzLTMgZ2FwLTVcIj5cclxuICAgICAgICAgICAgICB7dXBsb2FkZWREb2N1bWVudHMubWFwKChkb2MsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC0yeGwgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3cteGwgaG92ZXI6LXRyYW5zbGF0ZS15LTEgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBiZy1ncmF5LTEwMCBoLTUyIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtkb2MuaXNJbWFnZSA/IChcclxuICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2RvYy51cmx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXtkb2MubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXIgY3Vyc29yLXBvaW50ZXIgZ3JvdXAtaG92ZXI6c2NhbGUtMTA1IHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTMwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUHJldmlldyhkb2MudXJsLCBkb2MubGFiZWwpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctYmxhY2svMCBncm91cC1ob3ZlcjpiZy1ibGFjay80MCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVQcmV2aWV3KGRvYy51cmwsIGRvYy5sYWJlbCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGJnLXdoaXRlIHRleHQtZ3JheS04MDAgcHgtNCBweS0yIHJvdW5kZWQteGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgc2hhZG93LWxnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW9FeWUgY2xhc3NOYW1lPVwidGV4dC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBWaWV3XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgaC1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0yMCBoLTIwIHJvdW5kZWQtMnhsIGJnLXJlZC01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPElvRG9jdW1lbnQgY2xhc3NOYW1lPVwidGV4dC01eGwgdGV4dC1yZWQtNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgZm9udC1tZWRpdW1cIj5QREYgRG9jdW1lbnQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGxpbmUtY2xhbXAtMVwiPntkb2MubGFiZWx9PC9oND5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTEgYnJlYWstYWxsIGxpbmUtY2xhbXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtkb2MudXJsLnN1YnN0cmluZyhkb2MudXJsLmxhc3RJbmRleE9mKFwiL1wiKSArIDEpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRvb2x0aXAgdGl0bGU9XCJQcmV2aWV3IERvY3VtZW50XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUHJldmlldyhkb2MudXJsLCBkb2MubGFiZWwpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgYmctYmx1ZS01MCBob3ZlcjpiZy1ibHVlLTEwMCB0ZXh0LWJsdWUtNjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24tYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW9FeWUgY2xhc3NOYW1lPVwidGV4dC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvVG9vbHRpcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRvb2x0aXAgdGl0bGU9XCJEb3dubG9hZCBEb2N1bWVudFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBocmVmPXtkb2MudXJsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZG93bmxvYWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLXhsIGJnLWdyZWVuLTUwIGhvdmVyOmJnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTYwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPElvRG93bmxvYWQgY2xhc3NOYW1lPVwidGV4dC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1Rvb2x0aXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgey8qIFVwbG9hZCBNb2RhbCAqL31cclxuICAgICAge3Nob3dVcGxvYWRNb2RhbCAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrIGJnLW9wYWNpdHktNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgei01MCBvdmVyZmxvdy15LWF1dG9cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyB3LWZ1bGwgbWF4LXctNXhsIG0tNCBtYXgtaC1bOTB2aF0gb3ZlcmZsb3cteS1hdXRvXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RpY2t5IHRvcC0wIGJnLXdoaXRlIGJvcmRlci1iIHB4LTYgcHktNCBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZFwiPlVwbG9hZCBEb2N1bWVudHM8L2gyPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgQ3VzdG9tZXI6e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPntzZWxlY3RlZEN1c3RvbWVyPy5uYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ibHVlLTYwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIPCfkqEgVGlwOiBDbGljayBvbiBhbnkgZXhpc3RpbmcgZG9jdW1lbnQgdG8gdmlldyBpdC4gVXBsb2FkIG5ldyBmaWxlcyB0byByZXBsYWNlIHRoZW0uXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBzZXRTaG93VXBsb2FkTW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICByZXNldEZvcm0oKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS03MDAgdGV4dC0yeGxcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIMOXXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gY2xhc3NOYW1lPVwicC02IHNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgICAgIHsvKiBVc2VyIERvY3VtZW50cyBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSBtYi00IHRleHQtZ3JheS05MDAgYm9yZGVyLWIgcGItMlwiPlxyXG4gICAgICAgICAgICAgICAgICBDdXN0b21lciBEb2N1bWVudHNcclxuICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPERvY3VtZW50VXBsb2FkRmllbGRcclxuICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlBob3RvXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGU9e2Zvcm1EYXRhLnVzZXJfcHJvZmlsZV9waG90b31cclxuICAgICAgICAgICAgICAgICAgICBwcmV2aWV3PXtmaWxlUHJldmlld3MudXNlcl9wcm9maWxlX3Bob3RvfVxyXG4gICAgICAgICAgICAgICAgICAgIGV4aXN0aW5nVXJsPXtleGlzdGluZ0RvY3VtZW50VXJscy51c2VyX3Byb2ZpbGVfcGhvdG99XHJcbiAgICAgICAgICAgICAgICAgICAgb25QcmV2aWV3PXtoYW5kbGVQcmV2aWV3fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmlsZUNoYW5nZShlLCBcInVzZXJfcHJvZmlsZV9waG90b1wiKX1cclxuICAgICAgICAgICAgICAgICAgICBvbkRlbGV0ZT17KCkgPT4gaGFuZGxlRmlsZVJlbW92ZShcInVzZXJfcHJvZmlsZV9waG90b1wiKX1cclxuICAgICAgICAgICAgICAgICAgICBmb3JtYXRCeXRlcz17Zm9ybWF0Qnl0ZXN9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxEb2N1bWVudFVwbG9hZEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJQQU4gQ2FyZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBmaWxlPXtmb3JtRGF0YS51c2VyX3BhbmNhcmRfcGhvdG99XHJcbiAgICAgICAgICAgICAgICAgICAgcHJldmlldz17ZmlsZVByZXZpZXdzLnVzZXJfcGFuY2FyZF9waG90b31cclxuICAgICAgICAgICAgICAgICAgICBleGlzdGluZ1VybD17ZXhpc3RpbmdEb2N1bWVudFVybHMudXNlcl9wYW5jYXJkX3Bob3RvfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uUHJldmlldz17aGFuZGxlUHJldmlld31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUZpbGVDaGFuZ2UoZSwgXCJ1c2VyX3BhbmNhcmRfcGhvdG9cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgb25EZWxldGU9eygpID0+IGhhbmRsZUZpbGVSZW1vdmUoXCJ1c2VyX3BhbmNhcmRfcGhvdG9cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgZm9ybWF0Qnl0ZXM9e2Zvcm1hdEJ5dGVzfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8RG9jdW1lbnRVcGxvYWRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiQWFkaGFyIENhcmQgKEZyb250KVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBmaWxlPXtmb3JtRGF0YS51c2VyX2FkaGFyY2FyZF9mcm9udF9waG90b31cclxuICAgICAgICAgICAgICAgICAgICBwcmV2aWV3PXtmaWxlUHJldmlld3MudXNlcl9hZGhhcmNhcmRfZnJvbnRfcGhvdG99XHJcbiAgICAgICAgICAgICAgICAgICAgZXhpc3RpbmdVcmw9e2V4aXN0aW5nRG9jdW1lbnRVcmxzLnVzZXJfYWRoYXJjYXJkX2Zyb250X3Bob3RvfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uUHJldmlldz17aGFuZGxlUHJldmlld31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUZpbGVDaGFuZ2UoZSwgXCJ1c2VyX2FkaGFyY2FyZF9mcm9udF9waG90b1wiKX1cclxuICAgICAgICAgICAgICAgICAgICBvbkRlbGV0ZT17KCkgPT4gaGFuZGxlRmlsZVJlbW92ZShcInVzZXJfYWRoYXJjYXJkX2Zyb250X3Bob3RvXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgIGZvcm1hdEJ5dGVzPXtmb3JtYXRCeXRlc31cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPERvY3VtZW50VXBsb2FkRmllbGRcclxuICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkFhZGhhciBDYXJkIChCYWNrKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBmaWxlPXtmb3JtRGF0YS51c2VyX2FkaGFyY2FyZF9iYWNrX3Bob3RvfVxyXG4gICAgICAgICAgICAgICAgICAgIHByZXZpZXc9e2ZpbGVQcmV2aWV3cy51c2VyX2FkaGFyY2FyZF9iYWNrX3Bob3RvfVxyXG4gICAgICAgICAgICAgICAgICAgIGV4aXN0aW5nVXJsPXtleGlzdGluZ0RvY3VtZW50VXJscy51c2VyX2FkaGFyY2FyZF9iYWNrX3Bob3RvfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uUHJldmlldz17aGFuZGxlUHJldmlld31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUZpbGVDaGFuZ2UoZSwgXCJ1c2VyX2FkaGFyY2FyZF9iYWNrX3Bob3RvXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uRGVsZXRlPXsoKSA9PiBoYW5kbGVGaWxlUmVtb3ZlKFwidXNlcl9hZGhhcmNhcmRfYmFja19waG90b1wiKX1cclxuICAgICAgICAgICAgICAgICAgICBmb3JtYXRCeXRlcz17Zm9ybWF0Qnl0ZXN9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxEb2N1bWVudFVwbG9hZEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJCYW5rIFBhc3Nib29rIFBob3RvXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGU9e2Zvcm1EYXRhLmJhbmtfcGFzc2Jvb2tfcGhvdG99XHJcbiAgICAgICAgICAgICAgICAgICAgcHJldmlldz17ZmlsZVByZXZpZXdzLmJhbmtfcGFzc2Jvb2tfcGhvdG99XHJcbiAgICAgICAgICAgICAgICAgICAgZXhpc3RpbmdVcmw9e2V4aXN0aW5nRG9jdW1lbnRVcmxzLmJhbmtfcGFzc2Jvb2tfcGhvdG99XHJcbiAgICAgICAgICAgICAgICAgICAgb25QcmV2aWV3PXtoYW5kbGVQcmV2aWV3fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmlsZUNoYW5nZShlLCBcImJhbmtfcGFzc2Jvb2tfcGhvdG9cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgb25EZWxldGU9eygpID0+IGhhbmRsZUZpbGVSZW1vdmUoXCJiYW5rX3Bhc3Nib29rX3Bob3RvXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgIGZvcm1hdEJ5dGVzPXtmb3JtYXRCeXRlc31cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPERvY3VtZW50VXBsb2FkRmllbGRcclxuICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkJhbmsgU3RhdGVtZW50IC0gTW9udGggMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBmaWxlPXtmb3JtRGF0YS5iYW5rX3N0YXRlbWVudF9tb250aH1cclxuICAgICAgICAgICAgICAgICAgICBwcmV2aWV3PXtmaWxlUHJldmlld3MuYmFua19zdGF0ZW1lbnRfbW9udGh9XHJcbiAgICAgICAgICAgICAgICAgICAgZXhpc3RpbmdVcmw9e2V4aXN0aW5nRG9jdW1lbnRVcmxzLmJhbmtfc3RhdGVtZW50X21vbnRofVxyXG4gICAgICAgICAgICAgICAgICAgIG9uUHJldmlldz17aGFuZGxlUHJldmlld31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUZpbGVDaGFuZ2UoZSwgXCJiYW5rX3N0YXRlbWVudF9tb250aFwiKX1cclxuICAgICAgICAgICAgICAgICAgICBvbkRlbGV0ZT17KCkgPT4gaGFuZGxlRmlsZVJlbW92ZShcImJhbmtfc3RhdGVtZW50X21vbnRoXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgIGZvcm1hdEJ5dGVzPXtmb3JtYXRCeXRlc31cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPERvY3VtZW50VXBsb2FkRmllbGRcclxuICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkNoZXF1ZSBMZWFmXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGU9e2Zvcm1EYXRhLnVzZXJfY2hlcXVlX2xlYWZ9XHJcbiAgICAgICAgICAgICAgICAgICAgcHJldmlldz17ZmlsZVByZXZpZXdzLnVzZXJfY2hlcXVlX2xlYWZ9XHJcbiAgICAgICAgICAgICAgICAgICAgZXhpc3RpbmdVcmw9e2V4aXN0aW5nRG9jdW1lbnRVcmxzLnVzZXJfY2hlcXVlX2xlYWZ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25QcmV2aWV3PXtoYW5kbGVQcmV2aWV3fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmlsZUNoYW5nZShlLCBcInVzZXJfY2hlcXVlX2xlYWZcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgb25EZWxldGU9eygpID0+IGhhbmRsZUZpbGVSZW1vdmUoXCJ1c2VyX2NoZXF1ZV9sZWFmXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgIGZvcm1hdEJ5dGVzPXtmb3JtYXRCeXRlc31cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPERvY3VtZW50VXBsb2FkRmllbGRcclxuICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkJ1c2luZXNzIFByb29mXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGU9e2Zvcm1EYXRhLmJ1c2luZXNzX2RvY3VtZW50X3Byb29mfVxyXG4gICAgICAgICAgICAgICAgICAgIHByZXZpZXc9e2ZpbGVQcmV2aWV3cy5idXNpbmVzc19kb2N1bWVudF9wcm9vZn1cclxuICAgICAgICAgICAgICAgICAgICBleGlzdGluZ1VybD17ZXhpc3RpbmdEb2N1bWVudFVybHMuYnVzaW5lc3NfZG9jdW1lbnRfcHJvb2Z9XHJcbiAgICAgICAgICAgICAgICAgICAgb25QcmV2aWV3PXtoYW5kbGVQcmV2aWV3fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmlsZUNoYW5nZShlLCBcImJ1c2luZXNzX2RvY3VtZW50X3Byb29mXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uRGVsZXRlPXsoKSA9PiBoYW5kbGVGaWxlUmVtb3ZlKFwiYnVzaW5lc3NfZG9jdW1lbnRfcHJvb2ZcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgZm9ybWF0Qnl0ZXM9e2Zvcm1hdEJ5dGVzfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8RG9jdW1lbnRVcGxvYWRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiU2FsYXJ5IFNsaXBcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsZT17Zm9ybURhdGEudXNlcl9zYWxhcnlfc2xpcH1cclxuICAgICAgICAgICAgICAgICAgICBwcmV2aWV3PXtmaWxlUHJldmlld3MudXNlcl9zYWxhcnlfc2xpcH1cclxuICAgICAgICAgICAgICAgICAgICBleGlzdGluZ1VybD17ZXhpc3RpbmdEb2N1bWVudFVybHMudXNlcl9zYWxhcnlfc2xpcH1cclxuICAgICAgICAgICAgICAgICAgICBvblByZXZpZXc9e2hhbmRsZVByZXZpZXd9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVGaWxlQ2hhbmdlKGUsIFwidXNlcl9zYWxhcnlfc2xpcFwiKX1cclxuICAgICAgICAgICAgICAgICAgICBvbkRlbGV0ZT17KCkgPT4gaGFuZGxlRmlsZVJlbW92ZShcInVzZXJfc2FsYXJ5X3NsaXBcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgZm9ybWF0Qnl0ZXM9e2Zvcm1hdEJ5dGVzfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBPdGhlciBEb2N1bWVudHMgU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNCBib3JkZXItYiBwYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBPdGhlciBEb2N1bWVudCAoT3B0aW9uYWwpXHJcbiAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgIHtvdGhlckRvY3VtZW50cy5sZW5ndGggPT09IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17YWRkT3RoZXJEb2N1bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMSBiZy1ncmVlbi02MDAgdGV4dC13aGl0ZSByb3VuZGVkLW1kIGhvdmVyOmJnLWdyZWVuLTcwMCB0cmFuc2l0aW9uLWNvbG9ycyB0ZXh0LXNtIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNCBoLTRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPXsyfSBkPVwiTTEyIDR2MTZtOC04SDRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICBBZGQgRG9jdW1lbnRcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHtvdGhlckRvY3VtZW50cy5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktOCBiZy1ncmF5LTUwIHJvdW5kZWQtbGcgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItZ3JheS0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctMTIgaC0xMiBteC1hdXRvIHRleHQtZ3JheS00MDBcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD17Mn0gZD1cIk05IDEyaDZtLTYgNGg2bTIgNUg3YTIgMiAwIDAxLTItMlY1YTIgMiAwIDAxMi0yaDUuNTg2YTEgMSAwIDAxLjcwNy4yOTNsNS40MTQgNS40MTRhMSAxIDAgMDEuMjkzLjcwN1YxOWEyIDIgMCAwMS0yIDJ6XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIG10LTJcIj5ObyBvdGhlciBkb2N1bWVudCBhZGRlZDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2FkZE90aGVyRG9jdW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0yIHRleHQtYmx1ZS02MDAgaG92ZXI6dGV4dC1ibHVlLTcwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICArIEFkZCBhIGRvY3VtZW50XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICB7b3RoZXJEb2N1bWVudHMubWFwKChkb2MpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtkb2MuaWR9IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBwLTQgYmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPk90aGVyIERvY3VtZW50PC9oND5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlbW92ZU90aGVyRG9jdW1lbnQoZG9jLmlkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBob3Zlcjp0ZXh0LXJlZC03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy01IGgtNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9ezJ9IGQ9XCJNMTkgN2wtLjg2NyAxMi4xNDJBMiAyIDAgMDExNi4xMzggMjFINy44NjJhMiAyIDAgMDEtMS45OTUtMS44NThMNSA3bTUgNHY2bTQtNnY2bTEtMTBWNGExIDEgMCAwMC0xLTFoLTRhMSAxIDAgMDAtMSAxdjNNNCA3aDE2XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEb2N1bWVudCBOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2RvYy5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHVwZGF0ZU90aGVyRG9jdW1lbnROYW1lKGRvYy5pZCwgZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4sIEluY29tZSBUYXggUmV0dXJuLCBQcm9wZXJ0eSBEb2N1bWVudCwgZXRjLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2RvYy5leGlzdGluZ05hbWUgJiYgIWRvYy5uYW1lICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyZWVuLTYwMCBtdC0xXCI+Q3VycmVudGx5OiB7ZG9jLmV4aXN0aW5nTmFtZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RG9jdW1lbnRVcGxvYWRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkRvY3VtZW50IEZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxlPXtkb2MuZmlsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJldmlldz17ZG9jLnByZXZpZXd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4aXN0aW5nVXJsPXtkb2MuZXhpc3RpbmdVcmx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uUHJldmlldz17aGFuZGxlUHJldmlld31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVPdGhlckRvY3VtZW50RmlsZUNoYW5nZShlLCBkb2MuaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkRlbGV0ZT17KCkgPT4gcmVtb3ZlT3RoZXJEb2N1bWVudEZpbGUoZG9jLmlkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybWF0Qnl0ZXM9e2Zvcm1hdEJ5dGVzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogTm9taW5lZSBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSBtYi00IHRleHQtZ3JheS05MDAgYm9yZGVyLWIgcGItMlwiPlxyXG4gICAgICAgICAgICAgICAgICBOb21pbmVlIERldGFpbHNcclxuICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIE5vbWluZWUgTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubm9taW5lZS5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVOb21pbmVlVGV4dENoYW5nZShlLCBcIm5hbWVcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBub21pbmVlIG5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUGhvbmUgTnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm5vbWluZWUucGhvbmVOdW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZU5vbWluZWVUZXh0Q2hhbmdlKGUsIFwicGhvbmVOdW1iZXJcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1tZCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBwaG9uZSBudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8RG9jdW1lbnRVcGxvYWRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiTm9taW5lZSBBYWRoYXIgKEZyb250KVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBmaWxlPXtmb3JtRGF0YS5ub21pbmVlLnVzZXJfbm9taW5lZV9hZGhhcmNhcmRfZnJvbnRfcGhvdG99XHJcbiAgICAgICAgICAgICAgICAgICAgcHJldmlldz17ZmlsZVByZXZpZXdzLnVzZXJfbm9taW5lZV9hZGhhcmNhcmRfZnJvbnRfcGhvdG99XHJcbiAgICAgICAgICAgICAgICAgICAgZXhpc3RpbmdVcmw9e2V4aXN0aW5nRG9jdW1lbnRVcmxzLnVzZXJfbm9taW5lZV9hZGhhcmNhcmRfZnJvbnRfcGhvdG99XHJcbiAgICAgICAgICAgICAgICAgICAgb25QcmV2aWV3PXtoYW5kbGVQcmV2aWV3fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmlsZUNoYW5nZShlLCBcIm5vbWluZWVfYWRoYXJjYXJkX2Zyb250XCIpfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uRGVsZXRlPXsoKSA9PiBoYW5kbGVGaWxlUmVtb3ZlKFwibm9taW5lZV9hZGhhcmNhcmRfZnJvbnRcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgZm9ybWF0Qnl0ZXM9e2Zvcm1hdEJ5dGVzfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8RG9jdW1lbnRVcGxvYWRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiTm9taW5lZSBBYWRoYXIgKEJhY2spXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGU9e2Zvcm1EYXRhLm5vbWluZWUudXNlcl9ub21pbmVlX2FkaGFyY2FyZF9iYWNrX3Bob3RvfVxyXG4gICAgICAgICAgICAgICAgICAgIHByZXZpZXc9e2ZpbGVQcmV2aWV3cy51c2VyX25vbWluZWVfYWRoYXJjYXJkX2JhY2tfcGhvdG99XHJcbiAgICAgICAgICAgICAgICAgICAgZXhpc3RpbmdVcmw9e2V4aXN0aW5nRG9jdW1lbnRVcmxzLnVzZXJfbm9taW5lZV9hZGhhcmNhcmRfYmFja19waG90b31cclxuICAgICAgICAgICAgICAgICAgICBvblByZXZpZXc9e2hhbmRsZVByZXZpZXd9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVGaWxlQ2hhbmdlKGUsIFwibm9taW5lZV9hZGhhcmNhcmRfYmFja1wiKX1cclxuICAgICAgICAgICAgICAgICAgICBvbkRlbGV0ZT17KCkgPT4gaGFuZGxlRmlsZVJlbW92ZShcIm5vbWluZWVfYWRoYXJjYXJkX2JhY2tcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgZm9ybWF0Qnl0ZXM9e2Zvcm1hdEJ5dGVzfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8RG9jdW1lbnRVcGxvYWRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiTm9taW5lZSBQQU4gQ2FyZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBmaWxlPXtmb3JtRGF0YS5ub21pbmVlLnVzZXJfbm9taW5lZV9wYW5jYXJkX3Bob3RvfVxyXG4gICAgICAgICAgICAgICAgICAgIHByZXZpZXc9e2ZpbGVQcmV2aWV3cy51c2VyX25vbWluZWVfcGFuY2FyZF9waG90b31cclxuICAgICAgICAgICAgICAgICAgICBleGlzdGluZ1VybD17ZXhpc3RpbmdEb2N1bWVudFVybHMudXNlcl9ub21pbmVlX3BhbmNhcmRfcGhvdG99XHJcbiAgICAgICAgICAgICAgICAgICAgb25QcmV2aWV3PXtoYW5kbGVQcmV2aWV3fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmlsZUNoYW5nZShlLCBcIm5vbWluZWVfcGFuY2FyZFwiKX1cclxuICAgICAgICAgICAgICAgICAgICBvbkRlbGV0ZT17KCkgPT4gaGFuZGxlRmlsZVJlbW92ZShcIm5vbWluZWVfcGFuY2FyZFwiKX1cclxuICAgICAgICAgICAgICAgICAgICBmb3JtYXRCeXRlcz17Zm9ybWF0Qnl0ZXN9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIEd1YXJhbnRvciBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgIHtzaG93R3VhcmFudG9yICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTQgYm9yZGVyLWIgcGItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5HdWFyYW50b3IgRGV0YWlsczwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93R3VhcmFudG9yKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBob3Zlcjp0ZXh0LXJlZC03MDAgdGV4dC1zbSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD17Mn0gZD1cIk0xOSA3bC0uODY3IDEyLjE0MkEyIDIgMCAwMTE2LjEzOCAyMUg3Ljg2MmEyIDIgMCAwMS0xLjk5NS0xLjg1OEw1IDdtNSA0djZtNC02djZtMS0xMFY0YTEgMSAwIDAwLTEtMWgtNGExIDEgMCAwMC0xIDF2M000IDdoMTZcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICBSZW1vdmUgR3VhcmFudG9yXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEd1YXJhbnRvciBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2d1YXJhbnRvckRhdGEubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRHdWFyYW50b3JEYXRhKHsgLi4uZ3VhcmFudG9yRGF0YSwgbmFtZTogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgZ3VhcmFudG9yIG5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFBob25lIE51bWJlciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGVsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2d1YXJhbnRvckRhdGEucGhvbmVOdW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0R3VhcmFudG9yRGF0YSh7IC4uLmd1YXJhbnRvckRhdGEsIHBob25lTnVtYmVyOiBlLnRhcmdldC52YWx1ZSB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBwaG9uZSBudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEVtYWlsIChPcHRpb25hbClcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2d1YXJhbnRvckRhdGEuZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0R3VhcmFudG9yRGF0YSh7IC4uLmd1YXJhbnRvckRhdGEsIGVtYWlsOiBlLnRhcmdldC52YWx1ZSB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBlbWFpbCBhZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBZGRyZXNzIChPcHRpb25hbClcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3VhcmFudG9yRGF0YS5hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEd1YXJhbnRvckRhdGEoeyAuLi5ndWFyYW50b3JEYXRhLCBhZGRyZXNzOiBlLnRhcmdldC52YWx1ZSB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbWQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBhZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPERvY3VtZW50VXBsb2FkRmllbGRcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiR3VhcmFudG9yIEFhZGhhciBDYXJkXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbGU9e2d1YXJhbnRvckRhdGEuYWFkaGFyRnJvbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwcmV2aWV3PXtndWFyYW50b3JQcmV2aWV3cy5hYWRoYXJGcm9udH1cclxuICAgICAgICAgICAgICAgICAgICAgIGV4aXN0aW5nVXJsPXtleGlzdGluZ0d1YXJhbnRvclVybHM/LmFhZGhhckZyb250fVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25QcmV2aWV3PXtoYW5kbGVQcmV2aWV3fVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVHdWFyYW50b3JGaWxlQ2hhbmdlKGUsIFwiYWFkaGFyRnJvbnRcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkRlbGV0ZT17KCkgPT4gaGFuZGxlR3VhcmFudG9yRmlsZVJlbW92ZShcImFhZGhhckZyb250XCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgZm9ybWF0Qnl0ZXM9e2Zvcm1hdEJ5dGVzfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPERvY3VtZW50VXBsb2FkRmllbGRcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiR3VhcmFudG9yIFBBTiBDYXJkXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbGU9e2d1YXJhbnRvckRhdGEucGFuQ2FyZH1cclxuICAgICAgICAgICAgICAgICAgICAgIHByZXZpZXc9e2d1YXJhbnRvclByZXZpZXdzLnBhbkNhcmR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBleGlzdGluZ1VybD17ZXhpc3RpbmdHdWFyYW50b3JVcmxzPy5wYW5DYXJkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25QcmV2aWV3PXtoYW5kbGVQcmV2aWV3fVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVHdWFyYW50b3JGaWxlQ2hhbmdlKGUsIFwicGFuQ2FyZFwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uRGVsZXRlPXsoKSA9PiBoYW5kbGVHdWFyYW50b3JGaWxlUmVtb3ZlKFwicGFuQ2FyZFwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGZvcm1hdEJ5dGVzPXtmb3JtYXRCeXRlc31cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxEb2N1bWVudFVwbG9hZEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkd1YXJhbnRvciBQaG90b1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWxlPXtndWFyYW50b3JEYXRhLnBob3RvfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcHJldmlldz17Z3VhcmFudG9yUHJldmlld3MucGhvdG99XHJcbiAgICAgICAgICAgICAgICAgICAgICBleGlzdGluZ1VybD17ZXhpc3RpbmdHdWFyYW50b3JVcmxzPy5waG90b31cclxuICAgICAgICAgICAgICAgICAgICAgIG9uUHJldmlldz17aGFuZGxlUHJldmlld31cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlR3VhcmFudG9yRmlsZUNoYW5nZShlLCBcInBob3RvXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25EZWxldGU9eygpID0+IGhhbmRsZUd1YXJhbnRvckZpbGVSZW1vdmUoXCJwaG90b1wiKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGZvcm1hdEJ5dGVzPXtmb3JtYXRCeXRlc31cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBBZGQgR3VhcmFudG9yIEJ1dHRvbiAqL31cclxuICAgICAgICAgICAgICB7IXNob3dHdWFyYW50b3IgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93R3VhcmFudG9yKHRydWUpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1wdXJwbGUtNjAwIHRleHQtd2hpdGUgcm91bmRlZC1tZCBob3ZlcjpiZy1wdXJwbGUtNzAwIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy01IGgtNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPXsyfSBkPVwiTTE4IDl2M20wIDB2M20wLTNoM20tMyAwaC0zbS0yLTVhNCA0IDAgMTEtOCAwIDQgNCAwIDAxOCAwek0zIDIwYTYgNiAwIDAxMTIgMHYxSDN2LTF6XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICArIEFkZCBHdWFyYW50b3JcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICB7LyogRm9ybSBBY3Rpb25zICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RpY2t5IGJvdHRvbS0wIGJnLXdoaXRlIGJvcmRlci10IHB0LTQgZmxleCBqdXN0aWZ5LWVuZCBzcGFjZS14LTNcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRTaG93VXBsb2FkTW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJlc2V0Rm9ybSgpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLW1kIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS01MCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17dXBsb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctYmx1ZS02MDAgdGV4dC13aGl0ZSByb3VuZGVkLW1kIGhvdmVyOmJnLWJsdWUtNzAwIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge3VwbG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gLW1sLTEgbXItMiBoLTQgdy00IHRleHQtd2hpdGVcIiBmaWxsPVwibm9uZVwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGNpcmNsZSBjbGFzc05hbWU9XCJvcGFjaXR5LTI1XCIgY3g9XCIxMlwiIGN5PVwiMTJcIiByPVwiMTBcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjRcIj48L2NpcmNsZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggY2xhc3NOYW1lPVwib3BhY2l0eS03NVwiIGZpbGw9XCJjdXJyZW50Q29sb3JcIiBkPVwiTTQgMTJhOCA4IDAgMDE4LThWMEM1LjM3MyAwIDAgNS4zNzMgMCAxMmg0em0yIDUuMjkxQTcuOTYyIDcuOTYyIDAgMDE0IDEySDBjMCAzLjA0MiAxLjEzNSA1LjgyNCAzIDcuOTM4bDMtMi42NDd6XCI+PC9wYXRoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICBVcGxvYWRpbmcuLi5cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgXCJVcGxvYWQgRG9jdW1lbnRzXCJcclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEN1c3RvbWVyRG9jdW1lbnRzOyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9DdXN0b21lckRvY3VtZW50cy5qc3gifQ==