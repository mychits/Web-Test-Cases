import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/modals/Modal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/Modal.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { IoMdClose } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
const Modal = ({
  isVisible,
  onClose,
  children,
  borderColor = "primary",
  showCloseButton = true
}) => {
  _s();
  const [isDragging, setIsDragging] = useState(false);
  useEffect(() => {
    if (!isVisible) return;
    const originalOverflow = document.body.style.overflow;
    const originalPaddingRight = document.body.style.paddingRight;
    document.body.style.overflow = "hidden";
    const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
    if (scrollbarWidth > 0) {
      document.body.style.paddingRight = `${scrollbarWidth}px`;
    }
    return () => {
      document.body.style.overflow = originalOverflow;
      document.body.style.paddingRight = originalPaddingRight;
    };
  }, [isVisible]);
  const handleClose = (e) => {
    if (e.target.id === "modal-wrapper" && !isDragging) {
      onClose();
    }
  };
  const handleDragStart = () => {
    setIsDragging(true);
  };
  const handleDragEnd = () => {
    setTimeout(() => {
      setIsDragging(false);
    }, 100);
  };
  const borderClasses = {
    primary: "border-primary",
    red: "border-red-500",
    green: "border-green-500",
    blue: "border-blue-500",
    yellow: "border-yellow-500",
    purple: "border-purple-500"
  };
  if (!isVisible) return null;
  return /* @__PURE__ */ jsxDEV(
    "div",
    {
      id: "modal-wrapper",
      className: "fixed inset-0 bg-black/80 backdrop-blur-sm flex justify-center items-center z-50 p-4",
      onClick: handleClose,
      children: /* @__PURE__ */ jsxDEV(
        "div",
        {
          onMouseDown: handleDragStart,
          onMouseUp: handleDragEnd,
          onTouchStart: handleDragStart,
          onTouchEnd: handleDragEnd,
          className: "w-full md:w-1/2 max-h-[calc(100vh-5rem)] flex flex-col relative overflow-hidden",
          children: [
            showCloseButton && /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                className: "absolute top-3 right-3 z-20 text-gray-700 text-2xl hover:text-red-500 transition-colors",
                onClick: onClose,
                children: /* @__PURE__ */ jsxDEV(IoMdClose, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/Modal.jsx",
                  lineNumber: 83,
                  columnNumber: 13
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/Modal.jsx",
                lineNumber: 78,
                columnNumber: 9
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `bg-white border-4 ${borderClasses[borderColor] || "border-primary"} rounded-xl overflow-y-auto p-2 [&::-webkit-scrollbar]:hidden [scrollbar-width:none]`,
                children
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/Modal.jsx",
                lineNumber: 87,
                columnNumber: 9
              },
              this
            )
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/Modal.jsx",
          lineNumber: 70,
          columnNumber: 7
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/Modal.jsx",
      lineNumber: 65,
      columnNumber: 5
    },
    this
  );
};
_s(Modal, "zjq2sSup4GXUtmqwnFzGU3LD3go=");
_c = Modal;
export default Modal;
var _c;
$RefreshReg$(_c, "Modal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/Modal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/Modal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0ZZOzJCQWxGWjtBQUFvQkEsb0JBQWdCLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDM0MsU0FBU0MsaUJBQWlCO0FBRTFCLE1BQU1DLFFBQVFBLENBQUM7QUFBQSxFQUNiQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxjQUFjO0FBQUEsRUFDZEMsa0JBQWtCO0FBQ3BCLE1BQU07QUFBQUMsS0FBQTtBQUNKLFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJVixTQUFTLEtBQUs7QUFFbERXLFlBQVUsTUFBTTtBQUNkLFFBQUksQ0FBQ1IsVUFBVztBQUVoQixVQUFNUyxtQkFBbUJDLFNBQVNDLEtBQUtDLE1BQU1DO0FBQzdDLFVBQU1DLHVCQUF1QkosU0FBU0MsS0FBS0MsTUFBTUc7QUFFakRMLGFBQVNDLEtBQUtDLE1BQU1DLFdBQVc7QUFFL0IsVUFBTUcsaUJBQ0pDLE9BQU9DLGFBQWFSLFNBQVNTLGdCQUFnQkM7QUFFL0MsUUFBSUosaUJBQWlCLEdBQUc7QUFDdEJOLGVBQVNDLEtBQUtDLE1BQU1HLGVBQWUsR0FBR0MsY0FBYztBQUFBLElBQ3REO0FBRUEsV0FBTyxNQUFNO0FBQ1hOLGVBQVNDLEtBQUtDLE1BQU1DLFdBQVdKO0FBQy9CQyxlQUFTQyxLQUFLQyxNQUFNRyxlQUFlRDtBQUFBQSxJQUNyQztBQUFBLEVBQ0YsR0FBRyxDQUFDZCxTQUFTLENBQUM7QUFFZCxRQUFNcUIsY0FBY0EsQ0FBQ0MsTUFBTTtBQUN6QixRQUNFQSxFQUFFQyxPQUFPQyxPQUFPLG1CQUNoQixDQUFDbEIsWUFDRDtBQUNBTCxjQUFRO0FBQUEsSUFDVjtBQUFBLEVBQ0Y7QUFFQSxRQUFNd0Isa0JBQWtCQSxNQUFNO0FBQzVCbEIsa0JBQWMsSUFBSTtBQUFBLEVBQ3BCO0FBRUEsUUFBTW1CLGdCQUFnQkEsTUFBTTtBQUMxQkMsZUFBVyxNQUFNO0FBQ2ZwQixvQkFBYyxLQUFLO0FBQUEsSUFDckIsR0FBRyxHQUFHO0FBQUEsRUFDUjtBQUVBLFFBQU1xQixnQkFBZ0I7QUFBQSxJQUNwQkMsU0FBUztBQUFBLElBQ1RDLEtBQUs7QUFBQSxJQUNMQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ05DLFFBQVE7QUFBQSxJQUNSQyxRQUFRO0FBQUEsRUFDVjtBQUVBLE1BQUksQ0FBQ2xDLFVBQVcsUUFBTztBQUV2QixTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxJQUFHO0FBQUEsTUFDSCxXQUFVO0FBQUEsTUFDVixTQUFTcUI7QUFBQUEsTUFFVDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsYUFBYUk7QUFBQUEsVUFDYixXQUFXQztBQUFBQSxVQUNYLGNBQWNEO0FBQUFBLFVBQ2QsWUFBWUM7QUFBQUEsVUFDWixXQUFVO0FBQUEsVUFFVHRCO0FBQUFBLCtCQUNDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixTQUFTSDtBQUFBQSxnQkFFVCxpQ0FBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxZQUdGO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVyxxQkFDVDJCLGNBQWN6QixXQUFXLEtBQUssZ0JBQWdCO0FBQUEsZ0JBRy9DRDtBQUFBQTtBQUFBQSxjQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUE7QUFBQTtBQUFBLFFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXdCQTtBQUFBO0FBQUEsSUE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBOEJBO0FBRUo7QUFBRUcsR0E3RklOLE9BQUs7QUFBQW9DLEtBQUxwQztBQStGTixlQUFlQTtBQUFNLElBQUFvQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJJb01kQ2xvc2UiLCJNb2RhbCIsImlzVmlzaWJsZSIsIm9uQ2xvc2UiLCJjaGlsZHJlbiIsImJvcmRlckNvbG9yIiwic2hvd0Nsb3NlQnV0dG9uIiwiX3MiLCJpc0RyYWdnaW5nIiwic2V0SXNEcmFnZ2luZyIsInVzZUVmZmVjdCIsIm9yaWdpbmFsT3ZlcmZsb3ciLCJkb2N1bWVudCIsImJvZHkiLCJzdHlsZSIsIm92ZXJmbG93Iiwib3JpZ2luYWxQYWRkaW5nUmlnaHQiLCJwYWRkaW5nUmlnaHQiLCJzY3JvbGxiYXJXaWR0aCIsIndpbmRvdyIsImlubmVyV2lkdGgiLCJkb2N1bWVudEVsZW1lbnQiLCJjbGllbnRXaWR0aCIsImhhbmRsZUNsb3NlIiwiZSIsInRhcmdldCIsImlkIiwiaGFuZGxlRHJhZ1N0YXJ0IiwiaGFuZGxlRHJhZ0VuZCIsInNldFRpbWVvdXQiLCJib3JkZXJDbGFzc2VzIiwicHJpbWFyeSIsInJlZCIsImdyZWVuIiwiYmx1ZSIsInllbGxvdyIsInB1cnBsZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIk1vZGFsLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IElvTWRDbG9zZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5cclxuY29uc3QgTW9kYWwgPSAoe1xyXG4gIGlzVmlzaWJsZSxcclxuICBvbkNsb3NlLFxyXG4gIGNoaWxkcmVuLFxyXG4gIGJvcmRlckNvbG9yID0gXCJwcmltYXJ5XCIsXHJcbiAgc2hvd0Nsb3NlQnV0dG9uID0gdHJ1ZSxcclxufSkgPT4ge1xyXG4gIGNvbnN0IFtpc0RyYWdnaW5nLCBzZXRJc0RyYWdnaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghaXNWaXNpYmxlKSByZXR1cm47XHJcblxyXG4gICAgY29uc3Qgb3JpZ2luYWxPdmVyZmxvdyA9IGRvY3VtZW50LmJvZHkuc3R5bGUub3ZlcmZsb3c7XHJcbiAgICBjb25zdCBvcmlnaW5hbFBhZGRpbmdSaWdodCA9IGRvY3VtZW50LmJvZHkuc3R5bGUucGFkZGluZ1JpZ2h0O1xyXG5cclxuICAgIGRvY3VtZW50LmJvZHkuc3R5bGUub3ZlcmZsb3cgPSBcImhpZGRlblwiO1xyXG5cclxuICAgIGNvbnN0IHNjcm9sbGJhcldpZHRoID1cclxuICAgICAgd2luZG93LmlubmVyV2lkdGggLSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xpZW50V2lkdGg7XHJcblxyXG4gICAgaWYgKHNjcm9sbGJhcldpZHRoID4gMCkge1xyXG4gICAgICBkb2N1bWVudC5ib2R5LnN0eWxlLnBhZGRpbmdSaWdodCA9IGAke3Njcm9sbGJhcldpZHRofXB4YDtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICBkb2N1bWVudC5ib2R5LnN0eWxlLm92ZXJmbG93ID0gb3JpZ2luYWxPdmVyZmxvdztcclxuICAgICAgZG9jdW1lbnQuYm9keS5zdHlsZS5wYWRkaW5nUmlnaHQgPSBvcmlnaW5hbFBhZGRpbmdSaWdodDtcclxuICAgIH07XHJcbiAgfSwgW2lzVmlzaWJsZV0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVDbG9zZSA9IChlKSA9PiB7XHJcbiAgICBpZiAoXHJcbiAgICAgIGUudGFyZ2V0LmlkID09PSBcIm1vZGFsLXdyYXBwZXJcIiAmJlxyXG4gICAgICAhaXNEcmFnZ2luZ1xyXG4gICAgKSB7XHJcbiAgICAgIG9uQ2xvc2UoKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEcmFnU3RhcnQgPSAoKSA9PiB7XHJcbiAgICBzZXRJc0RyYWdnaW5nKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURyYWdFbmQgPSAoKSA9PiB7XHJcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgc2V0SXNEcmFnZ2luZyhmYWxzZSk7XHJcbiAgICB9LCAxMDApO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGJvcmRlckNsYXNzZXMgPSB7XHJcbiAgICBwcmltYXJ5OiBcImJvcmRlci1wcmltYXJ5XCIsXHJcbiAgICByZWQ6IFwiYm9yZGVyLXJlZC01MDBcIixcclxuICAgIGdyZWVuOiBcImJvcmRlci1ncmVlbi01MDBcIixcclxuICAgIGJsdWU6IFwiYm9yZGVyLWJsdWUtNTAwXCIsXHJcbiAgICB5ZWxsb3c6IFwiYm9yZGVyLXllbGxvdy01MDBcIixcclxuICAgIHB1cnBsZTogXCJib3JkZXItcHVycGxlLTUwMFwiLFxyXG4gIH07XHJcblxyXG4gIGlmICghaXNWaXNpYmxlKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXZcclxuICAgICAgaWQ9XCJtb2RhbC13cmFwcGVyXCJcclxuICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjay84MCBiYWNrZHJvcC1ibHVyLXNtIGZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHotNTAgcC00XCJcclxuICAgICAgb25DbGljaz17aGFuZGxlQ2xvc2V9XHJcbiAgICA+XHJcbiAgICAgIDxkaXZcclxuICAgICAgICBvbk1vdXNlRG93bj17aGFuZGxlRHJhZ1N0YXJ0fVxyXG4gICAgICAgIG9uTW91c2VVcD17aGFuZGxlRHJhZ0VuZH1cclxuICAgICAgICBvblRvdWNoU3RhcnQ9e2hhbmRsZURyYWdTdGFydH1cclxuICAgICAgICBvblRvdWNoRW5kPXtoYW5kbGVEcmFnRW5kfVxyXG4gICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtZDp3LTEvMiBtYXgtaC1bY2FsYygxMDB2aC01cmVtKV0gZmxleCBmbGV4LWNvbCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIlxyXG4gICAgICA+XHJcbiAgICAgICAge3Nob3dDbG9zZUJ1dHRvbiAmJiAoXHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMyByaWdodC0zIHotMjAgdGV4dC1ncmF5LTcwMCB0ZXh0LTJ4bCBob3Zlcjp0ZXh0LXJlZC01MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8SW9NZENsb3NlIC8+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICBjbGFzc05hbWU9e2BiZy13aGl0ZSBib3JkZXItNCAke1xyXG4gICAgICAgICAgICBib3JkZXJDbGFzc2VzW2JvcmRlckNvbG9yXSB8fCBcImJvcmRlci1wcmltYXJ5XCJcclxuICAgICAgICAgIH0gcm91bmRlZC14bCBvdmVyZmxvdy15LWF1dG8gcC0yIFsmOjotd2Via2l0LXNjcm9sbGJhcl06aGlkZGVuIFtzY3JvbGxiYXItd2lkdGg6bm9uZV1gfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTW9kYWw7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsLmpzeCJ9