import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CustomerChitPlanWhatsappMessage.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select, Input } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { notification } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { FaUsers, FaCheckCircle } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const CustomerChitPlanWhatsappMessage = () => {
  _s();
  const [searchText, setSearchText] = useState("");
  const [usersData, setUsersData] = useState([]);
  const [groupFilter, setGroupFilter] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [activeUserData, setActiveUserData] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [selectAll, setSelectAll] = useState(false);
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedLabel, setSelectedLabel] = useState("All");
  const [notifier, contextHolder] = notification.useNotification();
  const groupOptions = [
    ...new Set(
      usersData.filter(
        (u) => u.groupName !== void 0 && u.groupName !== "" && u.groupName !== "   "
      ).map((u) => u.groupName)
    )
  ];
  const normalizeDate = (date) => {
    if (!date) return "";
    return new Date(date).toLocaleDateString("en-CA");
  };
  const filteredUsers = useMemo(
    () => {
      const filtered = usersData.filter((u) => {
        const matchGroup = groupFilter ? u.groupName === groupFilter : true;
        const enrollmentDate = normalizeDate(u.enrollmentDate);
        const matchFromDate = fromDate ? enrollmentDate >= fromDate : true;
        const matchToDate = toDate ? enrollmentDate <= toDate : true;
        const filterEnrollDate = selectedDate ? normalizeDate(u.enrollDate) === selectedDate : true;
        return matchGroup && matchFromDate && matchToDate && filterEnrollDate;
      });
      return filtered.map((user, index) => {
        const isSelected = !!activeUserData[user._id]?.info?.status;
        return {
          ...user,
          sl_no: index + 1,
          checkBoxs: /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "checkbox",
              checked: isSelected,
              onChange: (e) => {
                setActiveUserData((prev) => ({
                  ...prev,
                  [user._id]: {
                    info: {
                      status: e.target.checked,
                      userPhone: user.userPhone,
                      groupName: user.groupName,
                      groupValue: user.groupValue,
                      groupMembers: user.groupMembers,
                      monthlyInstallment: user.monthlyInstallment,
                      userName: user.userName
                    }
                  }
                }));
              }
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
              lineNumber: 511,
              columnNumber: 9
            },
            this
          ),
          isSelected
        };
      });
    },
    [
      usersData,
      groupFilter,
      fromDate,
      toDate,
      searchText,
      activeUserData,
      selectedDate
    ]
  );
  const handleSelectFilter = (value) => {
    setSelectedLabel(value);
    const today = /* @__PURE__ */ new Date();
    const formatDate = (d) => d.toLocaleDateString("en-CA");
    if (value === "Today") {
      setSelectedDate(formatDate(today));
      setFromDate("");
      setToDate("");
    } else if (value === "Yesterday") {
      const y = new Date(today);
      y.setDate(y.getDate() - 1);
      setSelectedDate(formatDate(y));
      setFromDate("");
      setToDate("");
    } else if (value === "TwoDaysAgo") {
      const t = new Date(today);
      t.setDate(t.getDate() - 2);
      setSelectedDate(formatDate(t));
      setFromDate("");
      setToDate("");
    } else if (value === "ThisWeek") {
      const day = today.getDay();
      const diffToMonday = day === 0 ? 6 : day - 1;
      const monday = new Date(today);
      monday.setDate(today.getDate() - diffToMonday);
      const sunday = new Date(monday);
      sunday.setDate(monday.getDate() + 6);
      setFromDate(formatDate(monday));
      setToDate(formatDate(sunday));
      setSelectedDate("");
    } else if (value === "LastWeek") {
      const day = today.getDay();
      const diffToMonday = day === 0 ? 6 : day - 1;
      const thisMonday = new Date(today);
      thisMonday.setDate(today.getDate() - diffToMonday);
      const lastMonday = new Date(thisMonday);
      lastMonday.setDate(thisMonday.getDate() - 7);
      const lastSunday = new Date(lastMonday);
      lastSunday.setDate(lastMonday.getDate() + 6);
      setFromDate(formatDate(lastMonday));
      setToDate(formatDate(lastSunday));
      setSelectedDate("");
    } else if (value === "ThisMonth") {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      setFromDate(formatDate(start));
      setToDate(formatDate(end));
      setSelectedDate("");
    } else if (value === "LastMonth") {
      const start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      const end = new Date(today.getFullYear(), today.getMonth(), 0);
      setFromDate(formatDate(start));
      setToDate(formatDate(end));
      setSelectedDate("");
    } else if (value === "ThisYear") {
      const start = new Date(today.getFullYear(), 0, 1);
      const end = new Date(today.getFullYear(), 11, 31);
      setFromDate(formatDate(start));
      setToDate(formatDate(end));
      setSelectedDate("");
    } else if (value === "All") {
      const start = new Date(2e3, 0, 1);
      setFromDate(formatDate(start));
      setToDate(formatDate(today));
      setSelectedDate("");
    }
  };
  useEffect(() => {
    handleSelectFilter("All");
  }, []);
  const visibleSelectedCount = useMemo(() => {
    return filteredUsers.filter((u) => u.isSelected).length;
  }, [filteredUsers]);
  const fetchData = async () => {
    try {
      setIsLoading(true);
      const { data } = await api.get("/enroll/get-enroll");
      const tempActive = {};
      const usersList = data.map((user) => {
        const id = user._id;
        const userName = user?.user_id?.full_name;
        const userPhone = user?.user_id?.phone_number;
        const groupName = user?.group_id?.group_name;
        const groupValue = user?.group_id?.group_value;
        const groupMembers = user?.group_id?.group_members;
        const monthlyInstallment = user?.group_id?.monthlyInstallment;
        const enrollDate = user?.createdAt?.split("T")[0];
        const enrollmentDate = user?.group_id?.createdAt ? user.group_id.createdAt.split("T")[0] : enrollDate;
        tempActive[id] = { info: { status: false } };
        return {
          _id: id,
          userName,
          userPhone,
          groupName,
          groupValue,
          groupMembers,
          monthlyInstallment,
          enrollDate,
          enrollmentDate
        };
      });
      setUsersData(usersList);
      setActiveUserData(tempActive);
    } catch (err) {
      console.error("Error fetching data:", err);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);
  const sendWhatsapp = async () => {
    const key = "updatable";
    try {
      notifier.open({
        key,
        message: "Sending Messages via WhatsApp...",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
      const receivers = {};
      filteredUsers.forEach((user) => {
        if (user.isSelected && activeUserData[user._id]) {
          receivers[user._id] = activeUserData[user._id];
        }
      });
      await api.post("/whatsapp/customer-welcome-message", { receivers });
      const updatedActive = { ...activeUserData };
      filteredUsers.forEach((u) => {
        if (u.isSelected) delete updatedActive[u._id];
      });
      setActiveUserData(updatedActive);
      notifier.open({
        key,
        message: "WhatsApp Messages Sent Successfully!",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
    } catch (err) {
      notifier.open({
        key,
        message: "Failed to Send WhatsApp",
        description: err.message || "Something went wrong",
        className: "bg-red-300 rounded-lg font-bold",
        duration: 2
      });
    }
  };
  useEffect(() => {
    const allChecked = filteredUsers.length > 0 && filteredUsers.every((u) => activeUserData[u._id]?.info?.status);
    setSelectAll(allChecked);
  }, [filteredUsers, activeUserData]);
  const Auctioncolumns = [
    { key: "sl_no", header: "SL. NO" },
    { key: "checkBoxs", header: "Select" },
    { key: "userName", header: "Name" },
    { key: "userPhone", header: "Phone" },
    { key: "enrollDate", header: "Joined On" },
    { key: "groupName", header: "Group" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
        lineNumber: 734,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
      lineNumber: 738,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
        lineNumber: 741,
        columnNumber: 16
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-center mb-6 mt-2", children: "Customer Chit Plan Message" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
        lineNumber: 742,
        columnNumber: 13
      }, this),
      contextHolder,
      isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-green-600" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
        lineNumber: 748,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
        lineNumber: 747,
        columnNumber: 11
      }, this) : /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-6 mt-8 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Total Customers" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                lineNumber: 755,
                columnNumber: 7
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-violet-700", children: filteredUsers.length }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                lineNumber: 756,
                columnNumber: 7
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
              lineNumber: 754,
              columnNumber: 5
            }, this),
            /* @__PURE__ */ jsxDEV(FaUsers, { className: "text-violet-600 text-4xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
              lineNumber: 760,
              columnNumber: 5
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
            lineNumber: 753,
            columnNumber: 3
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Selected Customers" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                lineNumber: 765,
                columnNumber: 7
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-green-700", children: visibleSelectedCount }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                lineNumber: 766,
                columnNumber: 7
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
              lineNumber: 764,
              columnNumber: 5
            }, this),
            /* @__PURE__ */ jsxDEV(FaCheckCircle, { className: "text-green-600 text-4xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
              lineNumber: 770,
              columnNumber: 5
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
            lineNumber: 763,
            columnNumber: 3
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
          lineNumber: 752,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-end gap-6 mb-8 border-b border-gray-200 pb-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-full" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
              lineNumber: 778,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Select Group" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                lineNumber: 780,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  style: { width: 200 },
                  allowClear: true,
                  placeholder: "--All Groups--",
                  onChange: (v) => setGroupFilter(v),
                  value: groupFilter || void 0,
                  children: groupOptions.map(
                    (g) => /* @__PURE__ */ jsxDEV(Select.Option, { value: g, children: g }, g, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                      lineNumber: 791,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                  lineNumber: 783,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
              lineNumber: 779,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Date Filter" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                lineNumber: 800,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  className: "border p-2 rounded text-sm",
                  value: selectedLabel,
                  onChange: (e) => handleSelectFilter(e.target.value),
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "Today", children: "Today" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                      lineNumber: 808,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "Yesterday", children: "Yesterday" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                      lineNumber: 809,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "TwoDaysAgo", children: "Two Days Ago" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                      lineNumber: 810,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "ThisWeek", children: "This Week" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                      lineNumber: 811,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "LastWeek", children: "Last Week" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                      lineNumber: 812,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "ThisMonth", children: "This Month" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                      lineNumber: 813,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "LastMonth", children: "Last Month" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                      lineNumber: 814,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "ThisYear", children: "This Year" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                      lineNumber: 815,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "All", children: "All" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                      lineNumber: 816,
                      columnNumber: 23
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                  lineNumber: 803,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
              lineNumber: 799,
              columnNumber: 19
            }, this),
            selectedLabel && /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                lineNumber: 823,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "date",
                  value: selectedDate,
                  onChange: (e) => setSelectedDate(e.target.value),
                  className: "border rounded px-3 py-1 text-sm"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                  lineNumber: 824,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
              lineNumber: 822,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mt-5", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  className: "w-4 h-4 mr-2",
                  checked: selectAll,
                  onChange: (e) => {
                    const checked = e.target.checked;
                    setSelectAll(checked);
                    const updated = { ...activeUserData };
                    filteredUsers.forEach((user) => {
                      updated[user._id] = {
                        info: {
                          status: checked,
                          userPhone: user.userPhone,
                          groupName: user.groupName,
                          userName: user.userName,
                          groupValue: user.groupValue,
                          groupMembers: user.groupMembers,
                          monthlyInstallment: user.monthlyInstallment
                        }
                      };
                    });
                    setActiveUserData(updated);
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                  lineNumber: 835,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium", children: "Select All" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                lineNumber: 859,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
              lineNumber: 834,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
            lineNumber: 776,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mb-4", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: sendWhatsapp,
              className: "relative bg-green-600 text-white px-5 py-2 rounded shadow-md hover:bg-green-700 transition duration-200 flex items-center",
              children: [
                visibleSelectedCount > 0 && /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "min-w-6 h-6 absolute -right-3 -top-2 shadow-lg hover:bg-red-600 bg-red-400 rounded-full text-white flex items-center justify-center text-xs",
                    title: `Message will be sent to ${visibleSelectedCount} customers`,
                    children: /* @__PURE__ */ jsxDEV("span", { children: visibleSelectedCount }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                      lineNumber: 874,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                    lineNumber: 870,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "mr-2", size: 20 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
                  lineNumber: 877,
                  columnNumber: 21
                }, this),
                "WhatsApp"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
              lineNumber: 865,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
            lineNumber: 864,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: filteredUsers,
              columns: Auctioncolumns,
              catcher: "_id",
              exportedPdfName: "Customer Chit Plan",
              printHeaderKeys: ["Group"],
              printHeaderValues: [groupFilter],
              exportedFileName: "CustomerChitPlan.csv"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
              lineNumber: 883,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
          lineNumber: 774,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
        lineNumber: 751,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
      lineNumber: 740,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
    lineNumber: 733,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx",
    lineNumber: 732,
    columnNumber: 5
  }, this);
};
_s(CustomerChitPlanWhatsappMessage, "4vKr4CnRhZmD7LsqdDqt4s2aHOo=", false, function() {
  return [notification.useNotification];
});
_c = CustomerChitPlanWhatsappMessage;
export default CustomerChitPlanWhatsappMessage;
var _c;
$RefreshReg$(_c, "CustomerChitPlanWhatsappMessage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerChitPlanWhatsappMessage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOGZVOzJCQTlmVjtBQUFnQkEsTUFBV0MsY0FBVUMsT0FBTyxzQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzRCxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLFFBQVFDLGFBQWE7QUFDOUIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG9CQUFvQjtBQUM3QixPQUFPQyxhQUFhO0FBQ3BCLFNBQVNDLFNBQVNDLHFCQUFxQjtBQUN2QyxPQUFPQyxnQkFBZ0I7QUFnY3ZCLE1BQU1DLGtDQUFrQ0EsTUFBTTtBQUFBQyxLQUFBO0FBQzVDLFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJbEIsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ21CLFdBQVdDLFlBQVksSUFBSXBCLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNxQixhQUFhQyxjQUFjLElBQUl0QixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDdUIsVUFBVUMsV0FBVyxJQUFJeEIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ3lCLFFBQVFDLFNBQVMsSUFBSTFCLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUMyQixnQkFBZ0JDLGlCQUFpQixJQUFJNUIsU0FBUyxDQUFDLENBQUM7QUFDdkQsUUFBTSxDQUFDNkIsV0FBV0MsWUFBWSxJQUFJOUIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQytCLFdBQVdDLFlBQVksSUFBSWhDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNpQyxjQUFjQyxlQUFlLElBQUlsQyxTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDbUMsZUFBZUMsZ0JBQWdCLElBQUlwQyxTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDcUMsVUFBVUMsYUFBYSxJQUFJNUIsYUFBYTZCLGdCQUFnQjtBQUUvRCxRQUFNQyxlQUFlO0FBQUEsSUFDbkIsR0FBRyxJQUFJQztBQUFBQSxNQUNMdEIsVUFDR3VCO0FBQUFBLFFBQ0MsQ0FBQ0MsTUFDQ0EsRUFBRUMsY0FBY0MsVUFDaEJGLEVBQUVDLGNBQWMsTUFDaEJELEVBQUVDLGNBQWM7QUFBQSxNQUNwQixFQUNDRSxJQUFJLENBQUNILE1BQU1BLEVBQUVDLFNBQVM7QUFBQSxJQUMzQjtBQUFBLEVBQUM7QUFJSCxRQUFNRyxnQkFBZ0JBLENBQUNDLFNBQVM7QUFDOUIsUUFBSSxDQUFDQSxLQUFNLFFBQU87QUFDbEIsV0FBTyxJQUFJQyxLQUFLRCxJQUFJLEVBQUVFLG1CQUFtQixPQUFPO0FBQUEsRUFDbEQ7QUFHQSxRQUFNQyxnQkFBZ0JsRDtBQUFBQSxJQUFRLE1BQU07QUFDbEMsWUFBTW1ELFdBQVdqQyxVQUFVdUIsT0FBTyxDQUFDQyxNQUFNO0FBQ3ZDLGNBQU1VLGFBQWFoQyxjQUFjc0IsRUFBRUMsY0FBY3ZCLGNBQWM7QUFDL0QsY0FBTWlDLGlCQUFpQlAsY0FBY0osRUFBRVcsY0FBYztBQUNyRCxjQUFNQyxnQkFBZ0JoQyxXQUFXK0Isa0JBQWtCL0IsV0FBVztBQUM5RCxjQUFNaUMsY0FBYy9CLFNBQVM2QixrQkFBa0I3QixTQUFTO0FBQ3hELGNBQU1nQyxtQkFBbUJ4QixlQUNyQmMsY0FBY0osRUFBRWUsVUFBVSxNQUFNekIsZUFDaEM7QUFDSixlQUFPb0IsY0FBY0UsaUJBQWlCQyxlQUFlQztBQUFBQSxNQUN2RCxDQUFDO0FBRUQsYUFBT0wsU0FBU04sSUFBSSxDQUFDYSxNQUFNQyxVQUFVO0FBQ25DLGNBQU1DLGFBQWEsQ0FBQyxDQUFDbEMsZUFBZWdDLEtBQUtHLEdBQUcsR0FBR0MsTUFBTUM7QUFDckQsZUFBTztBQUFBLFVBQ0wsR0FBR0w7QUFBQUEsVUFDSE0sT0FBT0wsUUFBUTtBQUFBLFVBQ2ZNLFdBQ0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFNBQVNMO0FBQUFBLGNBQ1QsVUFBVSxDQUFDTSxNQUFNO0FBQ2Z2QyxrQ0FBa0IsQ0FBQ3dDLFVBQVU7QUFBQSxrQkFDM0IsR0FBR0E7QUFBQUEsa0JBQ0gsQ0FBQ1QsS0FBS0csR0FBRyxHQUFHO0FBQUEsb0JBQ1ZDLE1BQU07QUFBQSxzQkFDSkMsUUFBUUcsRUFBRUUsT0FBT0M7QUFBQUEsc0JBQ2pCQyxXQUFXWixLQUFLWTtBQUFBQSxzQkFDaEIzQixXQUFXZSxLQUFLZjtBQUFBQSxzQkFDaEI0QixZQUFZYixLQUFLYTtBQUFBQSxzQkFDakJDLGNBQWNkLEtBQUtjO0FBQUFBLHNCQUNuQkMsb0JBQW9CZixLQUFLZTtBQUFBQSxzQkFDekJDLFVBQVVoQixLQUFLZ0I7QUFBQUEsb0JBQ2pCO0FBQUEsa0JBQ0Y7QUFBQSxnQkFDRixFQUFFO0FBQUEsY0FDSjtBQUFBO0FBQUEsWUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBa0JJO0FBQUEsVUFHTmQ7QUFBQUEsUUFDRjtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0g7QUFBQSxJQUFHO0FBQUEsTUFDRDFDO0FBQUFBLE1BQ0FFO0FBQUFBLE1BQ0FFO0FBQUFBLE1BQ0FFO0FBQUFBLE1BQ0FSO0FBQUFBLE1BQ0FVO0FBQUFBLE1BQ0FNO0FBQUFBLElBQVk7QUFBQSxFQUNiO0FBR0QsUUFBTTJDLHFCQUFxQkEsQ0FBQ0MsVUFBVTtBQUNwQ3pDLHFCQUFpQnlDLEtBQUs7QUFDdEIsVUFBTUMsUUFBUSxvQkFBSTdCLEtBQUs7QUFDdkIsVUFBTThCLGFBQWFBLENBQUNDLE1BQU1BLEVBQUU5QixtQkFBbUIsT0FBTztBQUV0RCxRQUFJMkIsVUFBVSxTQUFTO0FBQ3JCM0Msc0JBQWdCNkMsV0FBV0QsS0FBSyxDQUFDO0FBQ2pDdEQsa0JBQVksRUFBRTtBQUNkRSxnQkFBVSxFQUFFO0FBQUEsSUFDZCxXQUFXbUQsVUFBVSxhQUFhO0FBQ2hDLFlBQU1JLElBQUksSUFBSWhDLEtBQUs2QixLQUFLO0FBQ3hCRyxRQUFFQyxRQUFRRCxFQUFFRSxRQUFRLElBQUksQ0FBQztBQUN6QmpELHNCQUFnQjZDLFdBQVdFLENBQUMsQ0FBQztBQUM3QnpELGtCQUFZLEVBQUU7QUFDZEUsZ0JBQVUsRUFBRTtBQUFBLElBQ2QsV0FBV21ELFVBQVUsY0FBYztBQUNqQyxZQUFNTyxJQUFJLElBQUluQyxLQUFLNkIsS0FBSztBQUN4Qk0sUUFBRUYsUUFBUUUsRUFBRUQsUUFBUSxJQUFJLENBQUM7QUFDekJqRCxzQkFBZ0I2QyxXQUFXSyxDQUFDLENBQUM7QUFDN0I1RCxrQkFBWSxFQUFFO0FBQ2RFLGdCQUFVLEVBQUU7QUFBQSxJQUNkLFdBQVdtRCxVQUFVLFlBQVk7QUFDL0IsWUFBTVEsTUFBTVAsTUFBTVEsT0FBTztBQUN6QixZQUFNQyxlQUFlRixRQUFRLElBQUksSUFBSUEsTUFBTTtBQUMzQyxZQUFNRyxTQUFTLElBQUl2QyxLQUFLNkIsS0FBSztBQUM3QlUsYUFBT04sUUFBUUosTUFBTUssUUFBUSxJQUFJSSxZQUFZO0FBQzdDLFlBQU1FLFNBQVMsSUFBSXhDLEtBQUt1QyxNQUFNO0FBQzlCQyxhQUFPUCxRQUFRTSxPQUFPTCxRQUFRLElBQUksQ0FBQztBQUNuQzNELGtCQUFZdUQsV0FBV1MsTUFBTSxDQUFDO0FBQzlCOUQsZ0JBQVVxRCxXQUFXVSxNQUFNLENBQUM7QUFDNUJ2RCxzQkFBZ0IsRUFBRTtBQUFBLElBQ3BCLFdBQVcyQyxVQUFVLFlBQVk7QUFDL0IsWUFBTVEsTUFBTVAsTUFBTVEsT0FBTztBQUN6QixZQUFNQyxlQUFlRixRQUFRLElBQUksSUFBSUEsTUFBTTtBQUMzQyxZQUFNSyxhQUFhLElBQUl6QyxLQUFLNkIsS0FBSztBQUNqQ1ksaUJBQVdSLFFBQVFKLE1BQU1LLFFBQVEsSUFBSUksWUFBWTtBQUNqRCxZQUFNSSxhQUFhLElBQUkxQyxLQUFLeUMsVUFBVTtBQUN0Q0MsaUJBQVdULFFBQVFRLFdBQVdQLFFBQVEsSUFBSSxDQUFDO0FBQzNDLFlBQU1TLGFBQWEsSUFBSTNDLEtBQUswQyxVQUFVO0FBQ3RDQyxpQkFBV1YsUUFBUVMsV0FBV1IsUUFBUSxJQUFJLENBQUM7QUFDM0MzRCxrQkFBWXVELFdBQVdZLFVBQVUsQ0FBQztBQUNsQ2pFLGdCQUFVcUQsV0FBV2EsVUFBVSxDQUFDO0FBQ2hDMUQsc0JBQWdCLEVBQUU7QUFBQSxJQUNwQixXQUFXMkMsVUFBVSxhQUFhO0FBQ2hDLFlBQU1nQixRQUFRLElBQUk1QyxLQUFLNkIsTUFBTWdCLFlBQVksR0FBR2hCLE1BQU1pQixTQUFTLEdBQUcsQ0FBQztBQUMvRCxZQUFNQyxNQUFNLElBQUkvQyxLQUFLNkIsTUFBTWdCLFlBQVksR0FBR2hCLE1BQU1pQixTQUFTLElBQUksR0FBRyxDQUFDO0FBQ2pFdkUsa0JBQVl1RCxXQUFXYyxLQUFLLENBQUM7QUFDN0JuRSxnQkFBVXFELFdBQVdpQixHQUFHLENBQUM7QUFDekI5RCxzQkFBZ0IsRUFBRTtBQUFBLElBQ3BCLFdBQVcyQyxVQUFVLGFBQWE7QUFDaEMsWUFBTWdCLFFBQVEsSUFBSTVDLEtBQUs2QixNQUFNZ0IsWUFBWSxHQUFHaEIsTUFBTWlCLFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDbkUsWUFBTUMsTUFBTSxJQUFJL0MsS0FBSzZCLE1BQU1nQixZQUFZLEdBQUdoQixNQUFNaUIsU0FBUyxHQUFHLENBQUM7QUFDN0R2RSxrQkFBWXVELFdBQVdjLEtBQUssQ0FBQztBQUM3Qm5FLGdCQUFVcUQsV0FBV2lCLEdBQUcsQ0FBQztBQUN6QjlELHNCQUFnQixFQUFFO0FBQUEsSUFDcEIsV0FBVzJDLFVBQVUsWUFBWTtBQUMvQixZQUFNZ0IsUUFBUSxJQUFJNUMsS0FBSzZCLE1BQU1nQixZQUFZLEdBQUcsR0FBRyxDQUFDO0FBQ2hELFlBQU1FLE1BQU0sSUFBSS9DLEtBQUs2QixNQUFNZ0IsWUFBWSxHQUFHLElBQUksRUFBRTtBQUNoRHRFLGtCQUFZdUQsV0FBV2MsS0FBSyxDQUFDO0FBQzdCbkUsZ0JBQVVxRCxXQUFXaUIsR0FBRyxDQUFDO0FBQ3pCOUQsc0JBQWdCLEVBQUU7QUFBQSxJQUNwQixXQUFXMkMsVUFBVSxPQUFPO0FBQzFCLFlBQU1nQixRQUFRLElBQUk1QyxLQUFLLEtBQU0sR0FBRyxDQUFDO0FBQ2pDekIsa0JBQVl1RCxXQUFXYyxLQUFLLENBQUM7QUFDN0JuRSxnQkFBVXFELFdBQVdELEtBQUssQ0FBQztBQUMzQjVDLHNCQUFnQixFQUFFO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUFuQyxZQUFVLE1BQU07QUFDZDZFLHVCQUFtQixLQUFLO0FBQUEsRUFDMUIsR0FBRyxFQUFFO0FBR0wsUUFBTXFCLHVCQUF1QmhHLFFBQVEsTUFBTTtBQUN6QyxXQUFPa0QsY0FBY1QsT0FBTyxDQUFDQyxNQUFNQSxFQUFFa0IsVUFBVSxFQUFFcUM7QUFBQUEsRUFDbkQsR0FBRyxDQUFDL0MsYUFBYSxDQUFDO0FBR2xCLFFBQU1nRCxZQUFZLFlBQVk7QUFDNUIsUUFBSTtBQUNGckUsbUJBQWEsSUFBSTtBQUNqQixZQUFNLEVBQUVzRSxLQUFLLElBQUksTUFBTWxHLElBQUltRyxJQUFJLG9CQUFvQjtBQUNuRCxZQUFNQyxhQUFhLENBQUM7QUFDcEIsWUFBTUMsWUFBWUgsS0FBS3RELElBQUksQ0FBQ2EsU0FBUztBQUNuQyxjQUFNNkMsS0FBSzdDLEtBQUtHO0FBQ2hCLGNBQU1hLFdBQVdoQixNQUFNOEMsU0FBU0M7QUFDaEMsY0FBTW5DLFlBQVlaLE1BQU04QyxTQUFTRTtBQUNqQyxjQUFNL0QsWUFBWWUsTUFBTWlELFVBQVVDO0FBQ2xDLGNBQU1yQyxhQUFhYixNQUFNaUQsVUFBVUU7QUFDbkMsY0FBTXJDLGVBQWVkLE1BQU1pRCxVQUFVRztBQUNyQyxjQUFNckMscUJBQXFCZixNQUFNaUQsVUFBVWxDO0FBQzNDLGNBQU1oQixhQUFhQyxNQUFNcUQsV0FBV0MsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNoRCxjQUFNM0QsaUJBQWlCSyxNQUFNaUQsVUFBVUksWUFDbkNyRCxLQUFLaUQsU0FBU0ksVUFBVUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUNwQ3ZEO0FBRUo0QyxtQkFBV0UsRUFBRSxJQUFJLEVBQUV6QyxNQUFNLEVBQUVDLFFBQVEsTUFBTSxFQUFFO0FBQzNDLGVBQU87QUFBQSxVQUNMRixLQUFLMEM7QUFBQUEsVUFDTDdCO0FBQUFBLFVBQ0FKO0FBQUFBLFVBQ0EzQjtBQUFBQSxVQUNBNEI7QUFBQUEsVUFDQUM7QUFBQUEsVUFDQUM7QUFBQUEsVUFDQWhCO0FBQUFBLFVBQ0FKO0FBQUFBLFFBQ0Y7QUFBQSxNQUNGLENBQUM7QUFFRGxDLG1CQUFhbUYsU0FBUztBQUN0QjNFLHdCQUFrQjBFLFVBQVU7QUFBQSxJQUM5QixTQUFTWSxLQUFLO0FBQ1pDLGNBQVFDLE1BQU0sd0JBQXdCRixHQUFHO0FBQUEsSUFDM0MsVUFBQztBQUNDcEYsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBL0IsWUFBVSxNQUFNO0FBQ2RvRyxjQUFVO0FBQUEsRUFDWixHQUFHLEVBQUU7QUFHTCxRQUFNa0IsZUFBZSxZQUFZO0FBQy9CLFVBQU1DLE1BQU07QUFDWixRQUFJO0FBQ0ZqRixlQUFTa0YsS0FBSztBQUFBLFFBQ1pEO0FBQUFBLFFBQ0FFLFNBQVM7QUFBQSxRQUNUQyxXQUFXO0FBQUEsUUFDWEMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUVELFlBQU1DLFlBQVksQ0FBQztBQUNuQnhFLG9CQUFjeUUsUUFBUSxDQUFDakUsU0FBUztBQUM5QixZQUFJQSxLQUFLRSxjQUFjbEMsZUFBZWdDLEtBQUtHLEdBQUcsR0FBRztBQUMvQzZELG9CQUFVaEUsS0FBS0csR0FBRyxJQUFJbkMsZUFBZWdDLEtBQUtHLEdBQUc7QUFBQSxRQUMvQztBQUFBLE1BQ0YsQ0FBQztBQUVELFlBQU01RCxJQUFJMkgsS0FBSyxzQ0FBc0MsRUFBRUYsVUFBVSxDQUFDO0FBRWxFLFlBQU1HLGdCQUFnQixFQUFFLEdBQUduRyxlQUFlO0FBQzFDd0Isb0JBQWN5RSxRQUFRLENBQUNqRixNQUFNO0FBQzNCLFlBQUlBLEVBQUVrQixXQUFZLFFBQU9pRSxjQUFjbkYsRUFBRW1CLEdBQUc7QUFBQSxNQUM5QyxDQUFDO0FBQ0RsQyx3QkFBa0JrRyxhQUFhO0FBRS9CekYsZUFBU2tGLEtBQUs7QUFBQSxRQUNaRDtBQUFBQSxRQUNBRSxTQUFTO0FBQUEsUUFDVEMsV0FBVztBQUFBLFFBQ1hDLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFBQSxJQUNILFNBQVNSLEtBQUs7QUFDWjdFLGVBQVNrRixLQUFLO0FBQUEsUUFDWkQ7QUFBQUEsUUFDQUUsU0FBUztBQUFBLFFBQ1RPLGFBQWFiLElBQUlNLFdBQVc7QUFBQSxRQUM1QkMsV0FBVztBQUFBLFFBQ1hDLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUdBM0gsWUFBVSxNQUFNO0FBQ2QsVUFBTWlJLGFBQ0o3RSxjQUFjK0MsU0FBUyxLQUN2Qi9DLGNBQWM4RSxNQUFNLENBQUN0RixNQUFNaEIsZUFBZWdCLEVBQUVtQixHQUFHLEdBQUdDLE1BQU1DLE1BQU07QUFDaEVoQyxpQkFBYWdHLFVBQVU7QUFBQSxFQUN6QixHQUFHLENBQUM3RSxlQUFleEIsY0FBYyxDQUFDO0FBR2xDLFFBQU11RyxpQkFBaUI7QUFBQSxJQUNyQixFQUFFWixLQUFLLFNBQVNhLFFBQVEsU0FBUztBQUFBLElBQ2pDLEVBQUViLEtBQUssYUFBYWEsUUFBUSxTQUFTO0FBQUEsSUFDckMsRUFBRWIsS0FBSyxZQUFZYSxRQUFRLE9BQU87QUFBQSxJQUNsQyxFQUFFYixLQUFLLGFBQWFhLFFBQVEsUUFBUTtBQUFBLElBQ3BDLEVBQUViLEtBQUssY0FBY2EsUUFBUSxZQUFZO0FBQUEsSUFDekMsRUFBRWIsS0FBSyxhQUFhYSxRQUFRLFFBQVE7QUFBQSxFQUFDO0FBR3ZDLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLFVBQ2IsaUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsNkJBQTZCLENBQUNoRSxNQUFNakQsY0FBY2lELEVBQUVFLE9BQU9RLEtBQUs7QUFBQSxRQUNoRSxZQUFZO0FBQUE7QUFBQSxNQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUVtQjtBQUFBLElBRW5CLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFRO0FBQUEsSUFFTix1QkFBQyxTQUFJLFdBQVUsaUJBQ1Y7QUFBQSw2QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVc7QUFBQSxNQUNkLHVCQUFDLFFBQUcsV0FBVSw0Q0FBMkMsMENBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0N2QztBQUFBQSxNQUNEVCxZQUNGLHVCQUFDLFNBQUksV0FBVSxVQUNiLGlDQUFDLGtCQUFlLE9BQU0sb0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0MsS0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLElBRUUsdUJBQUMsU0FDQztBQUFBLCtCQUFDLFNBQUksV0FBVSxtREFDM0I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUseUVBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsT0FBRSxXQUFVLHlCQUF3QiwrQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0Q7QUFBQSxjQUNwRCx1QkFBQyxPQUFFLFdBQVUsc0NBQ1ZzQix3QkFBYytDLFVBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQSx1QkFBQyxXQUFRLFdBQVUsOEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZDO0FBQUEsZUFQL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLHdFQUNiO0FBQUEsbUNBQUMsU0FDQztBQUFBLHFDQUFDLE9BQUUsV0FBVSx5QkFBd0Isa0NBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVEO0FBQUEsY0FDdkQsdUJBQUMsT0FBRSxXQUFVLHFDQUNWRCxrQ0FESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsaUJBQWMsV0FBVSw2QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0Q7QUFBQSxlQVBwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsYUFuQlk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9CZDtBQUFBLFFBRWMsdUJBQUMsU0FBSSxXQUFVLFVBRWI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUscUVBRWI7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3QjtBQUFBLFlBQ3hCLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsa0NBQWlDLDRCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPLEVBQUVtQyxPQUFPLElBQUk7QUFBQSxrQkFDcEI7QUFBQSxrQkFDQSxhQUFZO0FBQUEsa0JBQ1osVUFBVSxDQUFDQyxNQUFNL0csZUFBZStHLENBQUM7QUFBQSxrQkFDakMsT0FBT2hILGVBQWV3QjtBQUFBQSxrQkFFckJMLHVCQUFhTTtBQUFBQSxvQkFBSSxDQUFDd0YsTUFDakIsdUJBQUMsT0FBTyxRQUFQLEVBQXNCLE9BQU9BLEdBQzNCQSxlQURpQkEsR0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFYSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FZQTtBQUFBLGlCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLFlBR0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxrQ0FBaUMsMkJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixPQUFPbkc7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDZ0MsTUFBTVMsbUJBQW1CVCxFQUFFRSxPQUFPUSxLQUFLO0FBQUEsa0JBRWxEO0FBQUEsMkNBQUMsWUFBTyxPQUFNLFNBQVEscUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJCO0FBQUEsb0JBQzNCLHVCQUFDLFlBQU8sT0FBTSxhQUFZLHlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtQztBQUFBLG9CQUNuQyx1QkFBQyxZQUFPLE9BQU0sY0FBYSw0QkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUM7QUFBQSxvQkFDdkMsdUJBQUMsWUFBTyxPQUFNLFlBQVcseUJBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtDO0FBQUEsb0JBQ2xDLHVCQUFDLFlBQU8sT0FBTSxZQUFXLHlCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFrQztBQUFBLG9CQUNsQyx1QkFBQyxZQUFPLE9BQU0sYUFBWSwwQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0M7QUFBQSxvQkFDcEMsdUJBQUMsWUFBTyxPQUFNLGFBQVksMEJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9DO0FBQUEsb0JBQ3BDLHVCQUFDLFlBQU8sT0FBTSxZQUFXLHlCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFrQztBQUFBLG9CQUNsQyx1QkFBQyxZQUFPLE9BQU0sT0FBTSxtQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUI7QUFBQTtBQUFBO0FBQUEsZ0JBYnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWNBO0FBQUEsaUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbUJBO0FBQUEsWUFHQzFDLGlCQUNDLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsa0NBQWlDLG9CQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRDtBQUFBLGNBQ3REO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFPRjtBQUFBQSxrQkFDUCxVQUFVLENBQUNrQyxNQUFNakMsZ0JBQWdCaUMsRUFBRUUsT0FBT1EsS0FBSztBQUFBLGtCQUMvQyxXQUFVO0FBQUE7QUFBQSxnQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJOEM7QUFBQSxpQkFOaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLFlBSUYsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixTQUFTOUM7QUFBQUEsa0JBQ1QsVUFBVSxDQUFDb0MsTUFBTTtBQUNmLDBCQUFNRyxVQUFVSCxFQUFFRSxPQUFPQztBQUN6QnRDLGlDQUFhc0MsT0FBTztBQUNwQiwwQkFBTWlFLFVBQVUsRUFBRSxHQUFHNUcsZUFBZTtBQUNwQ3dCLGtDQUFjeUUsUUFBUSxDQUFDakUsU0FBUztBQUM5QjRFLDhCQUFRNUUsS0FBS0csR0FBRyxJQUFJO0FBQUEsd0JBQ2xCQyxNQUFNO0FBQUEsMEJBQ0pDLFFBQVFNO0FBQUFBLDBCQUNSQyxXQUFXWixLQUFLWTtBQUFBQSwwQkFDaEIzQixXQUFXZSxLQUFLZjtBQUFBQSwwQkFDaEIrQixVQUFVaEIsS0FBS2dCO0FBQUFBLDBCQUNmSCxZQUFZYixLQUFLYTtBQUFBQSwwQkFDakJDLGNBQWNkLEtBQUtjO0FBQUFBLDBCQUNuQkMsb0JBQW9CZixLQUFLZTtBQUFBQSx3QkFDM0I7QUFBQSxzQkFDRjtBQUFBLG9CQUNGLENBQUM7QUFDRDlDLHNDQUFrQjJHLE9BQU87QUFBQSxrQkFDM0I7QUFBQTtBQUFBLGdCQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FzQkk7QUFBQSxjQUVKLHVCQUFDLFdBQU0sV0FBVSx1QkFBc0IsMEJBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlEO0FBQUEsaUJBekJuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBCQTtBQUFBLGVBcEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUZBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVNsQjtBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUVUcEI7QUFBQUEsdUNBQXVCLEtBQ3RCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixPQUFPLDJCQUEyQkEsb0JBQW9CO0FBQUEsb0JBRXRELGlDQUFDLFVBQU1BLGtDQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTRCO0FBQUE7QUFBQSxrQkFKOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBRUYsdUJBQUMsY0FBVyxXQUFVLFFBQU8sTUFBTSxNQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzQztBQUFBLGdCQUFHO0FBQUE7QUFBQTtBQUFBLFlBWjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxVQUdBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNOUM7QUFBQUEsY0FDTixTQUFTK0U7QUFBQUEsY0FDVCxTQUFRO0FBQUEsY0FDUixpQkFBZ0I7QUFBQSxjQUNoQixpQkFBaUIsQ0FBQyxPQUFPO0FBQUEsY0FDekIsbUJBQW1CLENBQUM3RyxXQUFXO0FBQUEsY0FDL0Isa0JBQWlCO0FBQUE7QUFBQSxZQVBuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPeUM7QUFBQSxhQXBIM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNIQTtBQUFBLFdBN0lGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4SUE7QUFBQSxTQXpKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkpBO0FBQUEsT0FsS0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9LQSxLQXJLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0tBO0FBRUo7QUFBRUwsR0F4YklELGlDQUErQjtBQUFBLFVBV0RMLGFBQWE2QixlQUFlO0FBQUE7QUFBQWlHLEtBWDFEekg7QUEwYk4sZUFBZUE7QUFBZ0MsSUFBQXlIO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInVzZU1lbW8iLCJhcGkiLCJEYXRhVGFibGUiLCJDaXJjdWxhckxvYWRlciIsIlNlbGVjdCIsIklucHV0IiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwiRmFXaGF0c2FwcCIsIm5vdGlmaWNhdGlvbiIsIlNpZGViYXIiLCJGYVVzZXJzIiwiRmFDaGVja0NpcmNsZSIsIkJyZWFkY3J1bWIiLCJDdXN0b21lckNoaXRQbGFuV2hhdHNhcHBNZXNzYWdlIiwiX3MiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsInVzZXJzRGF0YSIsInNldFVzZXJzRGF0YSIsImdyb3VwRmlsdGVyIiwic2V0R3JvdXBGaWx0ZXIiLCJmcm9tRGF0ZSIsInNldEZyb21EYXRlIiwidG9EYXRlIiwic2V0VG9EYXRlIiwiYWN0aXZlVXNlckRhdGEiLCJzZXRBY3RpdmVVc2VyRGF0YSIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsInNlbGVjdEFsbCIsInNldFNlbGVjdEFsbCIsInNlbGVjdGVkRGF0ZSIsInNldFNlbGVjdGVkRGF0ZSIsInNlbGVjdGVkTGFiZWwiLCJzZXRTZWxlY3RlZExhYmVsIiwibm90aWZpZXIiLCJjb250ZXh0SG9sZGVyIiwidXNlTm90aWZpY2F0aW9uIiwiZ3JvdXBPcHRpb25zIiwiU2V0IiwiZmlsdGVyIiwidSIsImdyb3VwTmFtZSIsInVuZGVmaW5lZCIsIm1hcCIsIm5vcm1hbGl6ZURhdGUiLCJkYXRlIiwiRGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImZpbHRlcmVkVXNlcnMiLCJmaWx0ZXJlZCIsIm1hdGNoR3JvdXAiLCJlbnJvbGxtZW50RGF0ZSIsIm1hdGNoRnJvbURhdGUiLCJtYXRjaFRvRGF0ZSIsImZpbHRlckVucm9sbERhdGUiLCJlbnJvbGxEYXRlIiwidXNlciIsImluZGV4IiwiaXNTZWxlY3RlZCIsIl9pZCIsImluZm8iLCJzdGF0dXMiLCJzbF9ubyIsImNoZWNrQm94cyIsImUiLCJwcmV2IiwidGFyZ2V0IiwiY2hlY2tlZCIsInVzZXJQaG9uZSIsImdyb3VwVmFsdWUiLCJncm91cE1lbWJlcnMiLCJtb250aGx5SW5zdGFsbG1lbnQiLCJ1c2VyTmFtZSIsImhhbmRsZVNlbGVjdEZpbHRlciIsInZhbHVlIiwidG9kYXkiLCJmb3JtYXREYXRlIiwiZCIsInkiLCJzZXREYXRlIiwiZ2V0RGF0ZSIsInQiLCJkYXkiLCJnZXREYXkiLCJkaWZmVG9Nb25kYXkiLCJtb25kYXkiLCJzdW5kYXkiLCJ0aGlzTW9uZGF5IiwibGFzdE1vbmRheSIsImxhc3RTdW5kYXkiLCJzdGFydCIsImdldEZ1bGxZZWFyIiwiZ2V0TW9udGgiLCJlbmQiLCJ2aXNpYmxlU2VsZWN0ZWRDb3VudCIsImxlbmd0aCIsImZldGNoRGF0YSIsImRhdGEiLCJnZXQiLCJ0ZW1wQWN0aXZlIiwidXNlcnNMaXN0IiwiaWQiLCJ1c2VyX2lkIiwiZnVsbF9uYW1lIiwicGhvbmVfbnVtYmVyIiwiZ3JvdXBfaWQiLCJncm91cF9uYW1lIiwiZ3JvdXBfdmFsdWUiLCJncm91cF9tZW1iZXJzIiwiY3JlYXRlZEF0Iiwic3BsaXQiLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJzZW5kV2hhdHNhcHAiLCJrZXkiLCJvcGVuIiwibWVzc2FnZSIsImNsYXNzTmFtZSIsImR1cmF0aW9uIiwicmVjZWl2ZXJzIiwiZm9yRWFjaCIsInBvc3QiLCJ1cGRhdGVkQWN0aXZlIiwiZGVzY3JpcHRpb24iLCJhbGxDaGVja2VkIiwiZXZlcnkiLCJBdWN0aW9uY29sdW1ucyIsImhlYWRlciIsIndpZHRoIiwidiIsImciLCJ1cGRhdGVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ3VzdG9tZXJDaGl0UGxhbldoYXRzYXBwTWVzc2FnZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZU1lbW8gfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgSW5wdXQgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcbmltcG9ydCB7IEZhV2hhdHNhcHAgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IHsgbm90aWZpY2F0aW9uIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCB7IEZhVXNlcnMsIEZhQ2hlY2tDaXJjbGUgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IEJyZWFkY3J1bWIgZnJvbSBcIi4uL2hlbHBlcnMvQnJlYWRjcnVtYlwiO1xyXG5cclxuLy8gY29uc3QgQ3VzdG9tZXJDaGl0UGxhbldoYXRzYXBwTWVzc2FnZSA9ICgpID0+IHtcclxuLy8gICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbdXNlcnNEYXRhLCBzZXRVc2Vyc0RhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtncm91cEZpbHRlciwgc2V0R3JvdXBGaWx0ZXJdID0gdXNlU3RhdGUoXCJcIik7XHJcbi8vICAgY29uc3QgW2Zyb21EYXRlLCBzZXRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbdG9EYXRlLCBzZXRUb0RhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbi8vICAgY29uc3QgW2FjdGl2ZVVzZXJEYXRhLCBzZXRBY3RpdmVVc2VyRGF0YV0gPSB1c2VTdGF0ZSh7fSk7XHJcbi8vICAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbdG90YWxVc2Vycywgc2V0VG90YWxVc2Vyc10gPSB1c2VTdGF0ZSgwKTtcclxuLy8gICBjb25zdCBbbm90aWZpZXIsIGNvbnRleHRIb2xkZXJdID0gbm90aWZpY2F0aW9uLnVzZU5vdGlmaWNhdGlvbigpO1xyXG4vLyAgIGNvbnN0IFtzZWxlY3RBbGwsIHNldFNlbGVjdEFsbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbi8vICAgY29uc3QgW2F1Y3Rpb25EYXRhLCBzZXRBdWN0aW9uRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4vLyAgIGNvbnN0IHRvZGF5U3RyaW5nID0gdG9kYXkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcbi8vICAgY29uc3QgW3NlbGVjdGVkRGF0ZSwgc2V0U2VsZWN0ZWREYXRlXSA9IHVzZVN0YXRlKHRvZGF5U3RyaW5nKTtcclxuLy8gICBjb25zdCBbc2VsZWN0ZWRMYWJlbCwgc2V0U2VsZWN0ZWRMYWJlbF0gPSB1c2VTdGF0ZShcIkFsbFwiKTtcclxuLy8gICAvL2NvbnN0IGdyb3VwT3B0aW9ucyA9IFsuLi5uZXcgU2V0KHVzZXJzRGF0YS5tYXAoKHUpID0+IHUuZ3JvdXBOYW1lKSldO1xyXG4vLyAgIGNvbnN0IGdyb3VwT3B0aW9ucyA9IFtcclxuLy8gICAgIC4uLm5ldyBTZXQoXHJcbi8vICAgICAgIHVzZXJzRGF0YVxyXG4vLyAgICAgICAgIC5maWx0ZXIoXHJcbi8vICAgICAgICAgICAodSkgPT5cclxuLy8gICAgICAgICAgICAgdS5ncm91cE5hbWUgIT09IHVuZGVmaW5lZCAmJlxyXG4vLyAgICAgICAgICAgICB1Lmdyb3VwTmFtZSAhPT0gXCJcIiAmJlxyXG4vLyAgICAgICAgICAgICB1Lmdyb3VwTmFtZSAhPT0gXCIgICBcIlxyXG4vLyAgICAgICAgIClcclxuLy8gICAgICAgICAubWFwKCh1KSA9PiB1Lmdyb3VwTmFtZSlcclxuLy8gICAgICksXHJcbi8vICAgXTtcclxuLy8gICBjb25zdCBmaWx0ZXJlZFVzZXJzID0gdXNlTWVtbygoKSA9PiB7XHJcbi8vICAgICBjb25zdCBmaWx0ZXJlZCA9IHVzZXJzRGF0YS5maWx0ZXIoKHUpID0+IHtcclxuLy8gICAgICAgY29uc3QgbWF0Y2hHcm91cCA9IGdyb3VwRmlsdGVyID8gdS5ncm91cE5hbWUgPT09IGdyb3VwRmlsdGVyIDogdHJ1ZTtcclxuLy8gICAgICAgY29uc3QgZW5yb2xsbWVudERhdGUgPSBuZXcgRGF0ZSh1LmVucm9sbG1lbnREYXRlKTtcclxuLy8gICAgICAgY29uc3QgZmlsdGVyRW5yb2xsRGF0ZSA9IHNlbGVjdGVkRGF0ZSA9PT0gdS5lbnJvbGxEYXRlO1xyXG4vLyAgICAgICBjb25zdCBtYXRjaEZyb21EYXRlID0gZnJvbURhdGVcclxuLy8gICAgICAgICA/IGVucm9sbG1lbnREYXRlID49IG5ldyBEYXRlKGZyb21EYXRlKVxyXG4vLyAgICAgICAgIDogdHJ1ZTtcclxuLy8gICAgICAgY29uc3QgbWF0Y2hUb0RhdGUgPSB0b0RhdGUgPyBlbnJvbGxtZW50RGF0ZSA8PSBuZXcgRGF0ZSh0b0RhdGUpIDogdHJ1ZTtcclxuLy8gICAgICAgcmV0dXJuIG1hdGNoR3JvdXAgJiYgbWF0Y2hGcm9tRGF0ZSAmJiBtYXRjaFRvRGF0ZSAmJiBmaWx0ZXJFbnJvbGxEYXRlO1xyXG4vLyAgICAgfSk7XHJcblxyXG4vLyAgICAgcmV0dXJuIGZpbHRlcmVkLm1hcCgodXNlciwgaW5kZXgpID0+IHtcclxuLy8gICAgICAgY29uc3QgaXNTZWxlY3RlZCA9ICEhYWN0aXZlVXNlckRhdGFbdXNlci5faWRdPy5pbmZvPy5zdGF0dXM7XHJcblxyXG4vLyAgICAgICByZXR1cm4ge1xyXG4vLyAgICAgICAgIC4uLnVzZXIsXHJcbi8vICAgICAgICAgc2xfbm86IGluZGV4ICsgMSxcclxuLy8gICAgICAgICBjaGVja0JveHM6IChcclxuLy8gICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4vLyAgICAgICAgICAgICBjaGVja2VkPXtpc1NlbGVjdGVkfVxyXG4vLyAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuLy8gICAgICAgICAgICAgICBzZXRBY3RpdmVVc2VyRGF0YSgocHJldikgPT4gKHtcclxuLy8gICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbi8vICAgICAgICAgICAgICAgICBbdXNlci5faWRdOiB7XHJcbi8vICAgICAgICAgICAgICAgICAgIGluZm86IHtcclxuLy8gICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgdXNlclBob25lOiB1c2VyLnVzZXJQaG9uZSxcclxuLy8gICAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIGdyb3VwVmFsdWU6IHVzZXIuZ3JvdXBWYWx1ZSxcclxuLy8gICAgICAgICAgICAgICAgICAgICBncm91cE1lbWJlcnM6IHVzZXIuZ3JvdXBNZW1iZXJzLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgIG1vbnRobHlJbnN0YWxsbWVudDogdXNlci5tb250aGx5SW5zdGFsbG1lbnQsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgdXNlck5hbWU6IHVzZXIudXNlck5hbWUsXHJcbi8vICAgICAgICAgICAgICAgICAgIH0sXHJcbi8vICAgICAgICAgICAgICAgICB9LFxyXG4vLyAgICAgICAgICAgICAgIH0pKTtcclxuLy8gICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgKSxcclxuLy8gICAgICAgICBpc1NlbGVjdGVkLFxyXG4vLyAgICAgICB9O1xyXG4vLyAgICAgfSk7XHJcbi8vICAgfSwgW1xyXG4vLyAgICAgdXNlcnNEYXRhLFxyXG4vLyAgICAgZ3JvdXBGaWx0ZXIsXHJcbi8vICAgICBmcm9tRGF0ZSxcclxuLy8gICAgIHRvRGF0ZSxcclxuLy8gICAgIHNlYXJjaFRleHQsXHJcbi8vICAgICBhY3RpdmVVc2VyRGF0YSxcclxuLy8gICAgIHNlYXJjaFRleHQsXHJcbi8vICAgICBzZWxlY3RlZERhdGUsXHJcbi8vICAgXSk7XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZVNlbGVjdEZpbHRlciA9ICh2YWx1ZSkgPT4ge1xyXG4vLyAgICAgc2V0U2VsZWN0ZWRMYWJlbCh2YWx1ZSk7XHJcblxyXG4vLyAgICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4vLyAgICAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlKSA9PiBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUNBXCIpO1xyXG5cclxuLy8gICAgIGlmICh2YWx1ZSA9PT0gXCJUb2RheVwiKSB7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlKHRvZGF5KSk7XHJcbi8vICAgICAgIHNldEZyb21EYXRlKFwiXCIpO1xyXG4vLyAgICAgICBzZXRUb0RhdGUoXCJcIik7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlllc3RlcmRheVwiKSB7XHJcbi8vICAgICAgIGNvbnN0IHllc3RlcmRheSA9IG5ldyBEYXRlKHRvZGF5KTtcclxuLy8gICAgICAgeWVzdGVyZGF5LnNldERhdGUoeWVzdGVyZGF5LmdldERhdGUoKSAtIDEpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZSh5ZXN0ZXJkYXkpKTtcclxuLy8gICAgICAgc2V0RnJvbURhdGUoXCJcIik7XHJcbi8vICAgICAgIHNldFRvRGF0ZShcIlwiKTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVHdvRGF5c0Fnb1wiKSB7XHJcbi8vICAgICAgIGNvbnN0IHR3b0RheXNBZ28gPSBuZXcgRGF0ZSh0b2RheSk7XHJcbi8vICAgICAgIHR3b0RheXNBZ28uc2V0RGF0ZSh0d29EYXlzQWdvLmdldERhdGUoKSAtIDIpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZSh0d29EYXlzQWdvKSk7XHJcbi8vICAgICAgIHNldEZyb21EYXRlKFwiXCIpO1xyXG4vLyAgICAgICBzZXRUb0RhdGUoXCJcIik7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNXZWVrXCIpIHtcclxuLy8gICAgICAgY29uc3QgZGF5ID0gdG9kYXkuZ2V0RGF5KCk7IC8vIFN1bmRheT0wLCBNb25kYXk9MSwgLi4uXHJcbi8vICAgICAgIGNvbnN0IGRpZmZUb01vbmRheSA9IGRheSA9PT0gMCA/IDYgOiBkYXkgLSAxOyAvLyBhZGp1c3QgaWYgdG9kYXkgaXMgU3VuZGF5XHJcbi8vICAgICAgIGNvbnN0IG1vbmRheSA9IG5ldyBEYXRlKHRvZGF5KTtcclxuLy8gICAgICAgbW9uZGF5LnNldERhdGUodG9kYXkuZ2V0RGF0ZSgpIC0gZGlmZlRvTW9uZGF5KTtcclxuLy8gICAgICAgY29uc3Qgc3VuZGF5ID0gbmV3IERhdGUobW9uZGF5KTtcclxuLy8gICAgICAgc3VuZGF5LnNldERhdGUobW9uZGF5LmdldERhdGUoKSArIDYpO1xyXG4vLyAgICAgICBzZXRGcm9tRGF0ZShmb3JtYXREYXRlKG1vbmRheSkpO1xyXG4vLyAgICAgICBzZXRUb0RhdGUoZm9ybWF0RGF0ZShzdW5kYXkpKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWREYXRlKFwiXCIpO1xyXG4vLyAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJMYXN0V2Vla1wiKSB7XHJcbi8vICAgICAgIGNvbnN0IGRheSA9IHRvZGF5LmdldERheSgpO1xyXG4vLyAgICAgICBjb25zdCBkaWZmVG9Nb25kYXkgPSBkYXkgPT09IDAgPyA2IDogZGF5IC0gMTtcclxuLy8gICAgICAgY29uc3QgdGhpc01vbmRheSA9IG5ldyBEYXRlKHRvZGF5KTtcclxuLy8gICAgICAgdGhpc01vbmRheS5zZXREYXRlKHRvZGF5LmdldERhdGUoKSAtIGRpZmZUb01vbmRheSk7XHJcbi8vICAgICAgIGNvbnN0IGxhc3RNb25kYXkgPSBuZXcgRGF0ZSh0aGlzTW9uZGF5KTtcclxuLy8gICAgICAgbGFzdE1vbmRheS5zZXREYXRlKHRoaXNNb25kYXkuZ2V0RGF0ZSgpIC0gNyk7XHJcbi8vICAgICAgIGNvbnN0IGxhc3RTdW5kYXkgPSBuZXcgRGF0ZShsYXN0TW9uZGF5KTtcclxuLy8gICAgICAgbGFzdFN1bmRheS5zZXREYXRlKGxhc3RNb25kYXkuZ2V0RGF0ZSgpICsgNik7XHJcbi8vICAgICAgIHNldEZyb21EYXRlKGZvcm1hdERhdGUobGFzdE1vbmRheSkpO1xyXG4vLyAgICAgICBzZXRUb0RhdGUoZm9ybWF0RGF0ZShsYXN0U3VuZGF5KSk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRGF0ZShcIlwiKTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc01vbnRoXCIpIHtcclxuLy8gICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAxKTtcclxuLy8gICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSArIDEsIDApO1xyXG4vLyAgICAgICBzZXRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbi8vICAgICAgIHNldFRvRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZERhdGUoXCJcIik7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkxhc3RNb250aFwiKSB7XHJcbi8vICAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSAtIDEsIDEpO1xyXG4vLyAgICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAwKTtcclxuLy8gICAgICAgc2V0RnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4vLyAgICAgICBzZXRUb0RhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWREYXRlKFwiXCIpO1xyXG4vLyAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzWWVhclwiKSB7XHJcbi8vICAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMCwgMSk7XHJcbi8vICAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDExLCAzMSk7XHJcbi8vICAgICAgIHNldEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuLy8gICAgICAgc2V0VG9EYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRGF0ZShcIlwiKTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiQWxsXCIpIHtcclxuLy8gICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSgyMDAwLCAwLCAxKTtcclxuLy8gICAgICAgY29uc3QgZW5kID0gdG9kYXk7XHJcbi8vICAgICAgIHNldEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuLy8gICAgICAgc2V0VG9EYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRGF0ZShcIlwiKTtcclxuLy8gICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiQ3VzdG9tXCIpIHtcclxuLy8gICAgICAgLy8gdXNlciBzZWxlY3RzIG1hbnVhbGx5IOKGkiBkb27igJl0IG92ZXJyaWRlXHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGhhbmRsZVNlbGVjdEZpbHRlcihcIkFsbFwiKTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIGNvbnN0IHZpc2libGVTZWxlY3RlZENvdW50ID0gdXNlTWVtbygoKSA9PiB7XHJcbi8vICAgICByZXR1cm4gZmlsdGVyZWRVc2Vycy5maWx0ZXIoKHVzZXIpID0+IHVzZXIuaXNTZWxlY3RlZCkubGVuZ3RoO1xyXG4vLyAgIH0sIFtmaWx0ZXJlZFVzZXJzXSk7XHJcblxyXG4vLyAgIGNvbnN0IHNlbmRXaGF0c2FwcCA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgIGNvbnN0IGtleSA9IFwidXBkYXRhYmxlXCI7XHJcbi8vICAgICB0cnkge1xyXG4vLyAgICAgICBub3RpZmllci5vcGVuKHtcclxuLy8gICAgICAgICBrZXksXHJcbi8vICAgICAgICAgbWVzc2FnZTogXCJTZW5kaW5nIE1lc3NhZ2VzIFZpYSBXaGF0c2FwcC4uXCIsXHJcbi8vICAgICAgICAgZGVzY3JpcHRpb246IFwiUHJvY2Vzc2luZy4uLlwiLFxyXG4vLyAgICAgICAgIGNsYXNzTmFtZTogXCJiZy1ncmVlbi0zMDAgcm91bmRlZC1sZyBmb250LWJvbGRcIixcclxuLy8gICAgICAgICBkdXJhdGlvbjogMixcclxuLy8gICAgICAgfSk7XHJcblxyXG4vLyAgICAgICBjb25zdCB2aXNpYmxlQWN0aXZlVXNlcnMgPSB7fTtcclxuLy8gICAgICAgZmlsdGVyZWRVc2Vycy5mb3JFYWNoKCh1c2VyKSA9PiB7XHJcbi8vICAgICAgICAgaWYgKHVzZXIuaXNTZWxlY3RlZCAmJiBhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF0pIHtcclxuLy8gICAgICAgICAgIHZpc2libGVBY3RpdmVVc2Vyc1t1c2VyLl9pZF0gPSBhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF07XHJcbi8vICAgICAgICAgfVxyXG4vLyAgICAgICB9KTtcclxuXHJcbi8vICAgICAgIGNvbnN0IHRlc3QgPSBhd2FpdCBhcGkucG9zdChcIi93aGF0c2FwcC9jdXN0b21lci13ZWxjb21lLW1lc3NhZ2VcIiwge1xyXG4vLyAgICAgICAgIHJlY2VpdmVyczogdmlzaWJsZUFjdGl2ZVVzZXJzLFxyXG4vLyAgICAgICB9KTtcclxuLy8gICAgICAgLy9jb25zb2xlLmluZm8odGVzdCwgXCJoZ2hnZmdoZ2ZmXCIpO1xyXG5cclxuLy8gICAgICAgY29uc3QgbmV3QWN0aXZlVXNlckRhdGEgPSB7IC4uLmFjdGl2ZVVzZXJEYXRhIH07XHJcbi8vICAgICAgIGZpbHRlcmVkVXNlcnMuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4vLyAgICAgICAgIGlmICh1c2VyLmlzU2VsZWN0ZWQpIHtcclxuLy8gICAgICAgICAgIGRlbGV0ZSBuZXdBY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF07XHJcbi8vICAgICAgICAgfVxyXG4vLyAgICAgICB9KTtcclxuLy8gICAgICAgc2V0QWN0aXZlVXNlckRhdGEobmV3QWN0aXZlVXNlckRhdGEpO1xyXG5cclxuLy8gICAgICAgbm90aWZpZXIub3Blbih7XHJcbi8vICAgICAgICAga2V5LFxyXG4vLyAgICAgICAgIG1lc3NhZ2U6IFwiV2hhdHNhcHAgTWVzc2FnZXMgSGFzIEJlZW4gU2VudCBTdWNjZXNzZnVsbHlcIixcclxuLy8gICAgICAgICBkZXNjcmlwdGlvbjogXCJTdWNjZXNzXCIsXHJcbi8vICAgICAgICAgY2xhc3NOYW1lOiBcImJnLWdyZWVuLTMwMCByb3VuZGVkLWxnIGZvbnQtYm9sZFwiLFxyXG4vLyAgICAgICAgIGR1cmF0aW9uOiAyLFxyXG4vLyAgICAgICB9KTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycikge1xyXG4vLyAgICAgICBub3RpZmllci5vcGVuKHtcclxuLy8gICAgICAgICBrZXksXHJcbi8vICAgICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gU2VuZCBXaGF0c2FwcFwiLFxyXG4vLyAgICAgICAgIGRlc2NyaXB0aW9uOiBlcnIubWVzc2FnZSB8fCBcIlNvbWV0aGluZyB3ZW50IHdyb25nXCIsXHJcbi8vICAgICAgICAgY2xhc3NOYW1lOiBcImJnLXJlZC0zMDAgcm91bmRlZC1sZyBmb250LWJvbGRcIixcclxuLy8gICAgICAgICBkdXJhdGlvbjogMixcclxuLy8gICAgICAgfSk7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgLy8gQXV0b21hdGljYWxseSB1cGRhdGUgc2VsZWN0QWxsIGJhc2VkIG9uIGZpbHRlcmVkVXNlcnNcclxuLy8gICAgIGNvbnN0IGFsbENoZWNrZWQgPVxyXG4vLyAgICAgICBmaWx0ZXJlZFVzZXJzLmxlbmd0aCA+IDAgJiZcclxuLy8gICAgICAgZmlsdGVyZWRVc2Vycy5ldmVyeSgodXNlcikgPT4gYWN0aXZlVXNlckRhdGFbdXNlci5faWRdPy5pbmZvPy5zdGF0dXMpO1xyXG4vLyAgICAgc2V0U2VsZWN0QWxsKGFsbENoZWNrZWQpO1xyXG4vLyAgIH0sIFtmaWx0ZXJlZFVzZXJzLCBhY3RpdmVVc2VyRGF0YV0pO1xyXG5cclxuLy8gICBjb25zdCBmZXRjaERhdGEgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICB0cnkge1xyXG4vLyAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbi8vICAgICAgIGNvbnN0IHJlcG9ydFJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9lbnJvbGwvZ2V0LWVucm9sbFwiKTtcclxuLy8gICAgICAgY29uc29sZS5pbmZvKHJlcG9ydFJlc3BvbnNlLmRhdGEsIFwiamhmc2dqaGRmc2RoZ1wiKTtcclxuXHJcbi8vICAgICAgIGNvbnN0IHVzZXJzTGlzdCA9IFtdO1xyXG4vLyAgICAgICBjb25zdCB0ZW1wQWN0aXZlID0ge307XHJcbi8vICAgICAgIGNvbnN0IGRhdGEgPSByZXBvcnRSZXNwb25zZS5kYXRhPy5tYXAoKHVzZXIsIGluZGV4KSA9PiB7XHJcbi8vICAgICAgICAgY29uc3QgaWQgPSB1c2VyLl9pZDtcclxuLy8gICAgICAgICAvLyAgY29uc3QgZ3JvdXBJZCA9IGxlYWQ/Lmdyb3VwX2lkO1xyXG4vLyAgICAgICAgIGNvbnN0IHVzZXJOYW1lID0gdXNlcj8udXNlcl9pZD8uZnVsbF9uYW1lO1xyXG4vLyAgICAgICAgIGNvbnN0IHVzZXJQaG9uZSA9IHVzZXI/LnVzZXJfaWQ/LnBob25lX251bWJlcjtcclxuLy8gICAgICAgICBjb25zdCBncm91cE5hbWUgPSB1c2VyPy5ncm91cF9pZD8uZ3JvdXBfbmFtZTtcclxuLy8gICAgICAgICBjb25zdCBncm91cFZhbHVlID0gdXNlcj8uZ3JvdXBfaWQ/Lmdyb3VwX3ZhbHVlO1xyXG4vLyAgICAgICAgIGNvbnN0IGdyb3VwTWVtYmVycyA9IHVzZXI/Lmdyb3VwX2lkPy5ncm91cF9tZW1iZXJzO1xyXG4vLyAgICAgICAgIGNvbnN0IG1vbnRobHlJbnN0YWxsbWVudCA9IHVzZXI/Lmdyb3VwX2lkPy5tb250aGx5SW5zdGFsbG1lbnQ7XHJcbi8vICAgICAgICAgY29uc3QgZW5yb2xsRGF0ZSA9IHVzZXI/LmNyZWF0ZWRBdC5zcGxpdChcIlRcIilbMF07XHJcblxyXG4vLyAgICAgICAgIHRlbXBBY3RpdmVbaWRdID0ge1xyXG4vLyAgICAgICAgICAgaW5mbzoge1xyXG4vLyAgICAgICAgICAgICBzdGF0dXM6IGZhbHNlLFxyXG4vLyAgICAgICAgICAgfSxcclxuLy8gICAgICAgICB9O1xyXG5cclxuLy8gICAgICAgICBjb25zdCB0ZW1wVXNyID0ge1xyXG4vLyAgICAgICAgICAgX2lkOiBpZCxcclxuLy8gICAgICAgICAgIHVzZXJOYW1lLFxyXG4vLyAgICAgICAgICAgdXNlclBob25lLFxyXG4vLyAgICAgICAgICAgZ3JvdXBOYW1lLFxyXG4vLyAgICAgICAgICAgLy8gZ3JvdXBJZCxcclxuLy8gICAgICAgICAgIGVucm9sbG1lbnREYXRlOiB1c2VyPy5ncm91cF9pZD8uY3JlYXRlZEF0LnNwbGl0KFwiVFwiKVswXSxcclxuLy8gICAgICAgICAgIGVucm9sbERhdGUsXHJcbi8vICAgICAgICAgICBncm91cFZhbHVlLFxyXG4vLyAgICAgICAgICAgZ3JvdXBNZW1iZXJzLFxyXG4vLyAgICAgICAgICAgbW9udGhseUluc3RhbGxtZW50LFxyXG4vLyAgICAgICAgICAgLy8gbGVhZGVucm9sbERhdGUsXHJcbi8vICAgICAgICAgfTtcclxuLy8gICAgICAgICB1c2Vyc0xpc3QucHVzaCh0ZW1wVXNyKTtcclxuXHJcbi8vICAgICAgICAgcmV0dXJuIHtcclxuLy8gICAgICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuLy8gICAgICAgICAgIGdyb3VwTmFtZSxcclxuLy8gICAgICAgICAgIHVzZXJOYW1lLFxyXG4vLyAgICAgICAgICAgdXNlclBob25lLFxyXG4vLyAgICAgICAgICAgZ3JvdXBWYWx1ZSxcclxuLy8gICAgICAgICAgIGdyb3VwTWVtYmVycyxcclxuLy8gICAgICAgICAgIG1vbnRobHlJbnN0YWxsbWVudCxcclxuLy8gICAgICAgICAgIC8vICBncm91cElkLFxyXG4vLyAgICAgICAgICAgLy8gIHJlZmVycmVkQnk6IHVzZXI/LmxlYWRfYWdlbnQ/Lm5hbWUsXHJcbi8vICAgICAgICAgICBlbnJvbGxEYXRlLFxyXG4vLyAgICAgICAgIH07XHJcbi8vICAgICAgIH0pO1xyXG4vLyAgICAgICAvLyBjb25zb2xlLmluZm8oZGF0YSwgXCJqa2duc2RrZ2pzYm5nXCIpO1xyXG5cclxuLy8gICAgICAgc2V0QXVjdGlvbkRhdGEoZGF0YSk7XHJcbi8vICAgICAgIHNldFVzZXJzRGF0YSh1c2Vyc0xpc3QpOyAvLyDinIUgdXBkYXRlIHVzZXJzRGF0YSBmb3IgZmlsdGVyaW5nICsgY2hlY2tib3hlc1xyXG4vLyAgICAgICBzZXRBY3RpdmVVc2VyRGF0YSh0ZW1wQWN0aXZlKTtcclxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBkYXRhOlwiLCBlcnJvcik7XHJcbi8vICAgICB9IGZpbmFsbHkge1xyXG4vLyAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBmZXRjaERhdGEoKTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIGNvbnN0IEF1Y3Rpb25jb2x1bW5zID0gW1xyXG4vLyAgICAgeyBrZXk6IFwic2xfbm9cIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbi8vICAgICB7IGtleTogXCJjaGVja0JveHNcIiwgaGVhZGVyOiBcIlNlbGVjdCBVc2VyXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInVzZXJOYW1lXCIsIGhlYWRlcjogXCJOYW1lXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInVzZXJQaG9uZVwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImVucm9sbERhdGVcIiwgaGVhZGVyOiBcIkpvaW5lZCBvblwiIH0sXHJcbi8vICAgICAvLyB7IGtleTogXCJjdXN0b21lcklkXCIsIGhlYWRlcjogXCJDdXN0b21lciBJZFwiIH0sXHJcbi8vICAgICB7IGtleTogXCJncm91cE5hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4vLyAgICAgLy8gIHtrZXk6IFwicGF5bWVudHNUaWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwifSxcclxuLy8gICBdO1xyXG5cclxuLy8gICByZXR1cm4gKFxyXG4vLyAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LXNjcmVlblwiPlxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMzBcIj5cclxuLy8gICAgICAgICA8TmF2YmFyXHJcbi8vICAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9eyhlKSA9PiBzZXRTZWFyY2hUZXh0KGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbi8vICAgICAgICAgLz5cclxuLy8gICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuLy8gICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGNvbG9yPVwidGV4dC1ncmVlbi02MDBcIiAvPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgKSA6IChcclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4vLyAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtY2VudGVyXCI+XHJcbi8vICAgICAgICAgICAgICAgQ3VzdG9tZXIgV2VsY29tZSBNZXNzYWdlXHJcbi8vICAgICAgICAgICAgIDwvaDE+XHJcbi8vICAgICAgICAgICAgIHtjb250ZXh0SG9sZGVyfVxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4vLyAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LXN0YXJ0IGJvcmRlci1iIGJvcmRlci1ncmF5LTMwMCBtYi00XCI+PC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTQgbWItNlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IEdyb3VwXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogMjAwIH19XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIi0tQWxsIGdyb3Vwcy0tXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldEdyb3VwRmlsdGVyKHZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cEZpbHRlciB8fCB1bmRlZmluZWR9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXcteHMgaC0xMSBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHtncm91cE9wdGlvbnMubWFwKChncm91cCkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwfSB2YWx1ZT17Z3JvdXB9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNwYWNlLXktMiBtYi01XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+U2VsZWN0IERhdGUgRmlsdGVyPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcC0yIHJvdW5kZWQgdGV4dC1zbVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRMYWJlbH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlU2VsZWN0RmlsdGVyKGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVG9kYXlcIj5Ub2RheTwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlllc3RlcmRheVwiPlllc3RlcmRheTwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlR3b0RheXNBZ29cIj5Ud28gRGF5cyBBZ288L29wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUaGlzV2Vla1wiPlRoaXMgV2Vlazwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkxhc3RXZWVrXCI+TGFzdCBXZWVrPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVGhpc01vbnRoXCI+VGhpcyBNb250aDwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkxhc3RNb250aFwiPkxhc3QgTW9udGg8L29wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUaGlzWWVhclwiPlRoaXMgWWVhcjwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkFsbFwiPkFsbDwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkN1c3RvbVwiPkN1c3RvbTwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZExhYmVsICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5EYXRlPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZERhdGV9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkRGF0ZShlLnRhcmdldD8udmFsdWU/LnNwbGl0KFwiVFwiKVswXSk7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC00IHB5LTIgc2hhZG93LXNtIG91dGxpbmUtbm9uZSB3LWZ1bGwgbWF4LXcteHNcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi01XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgQWxsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC00IHctNCBoLTQgbWItM1wiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtzZWxlY3RBbGx9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY2hlY2tlZCA9IGUudGFyZ2V0LmNoZWNrZWQ7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdEFsbChjaGVja2VkKTsgLy8gU2V0IGdsb2JhbCBjaGVja2JveCBzdGF0ZVxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdXBkYXRlZERhdGEgPSB7IC4uLmFjdGl2ZVVzZXJEYXRhIH07XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAvLyBMb29wIHRocm91Z2ggYWxsIGZpbHRlcmVkIHVzZXJzIGFuZCBhcHBseSB0aGUgc2VsZWN0aW9uXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcmVkVXNlcnMuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZWREYXRhW3VzZXIuX2lkXSA9IHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZm86IHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBjaGVja2VkLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyUGhvbmU6IHVzZXIudXNlclBob25lLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyTmFtZTogdXNlci51c2VyTmFtZSxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXBWYWx1ZTogdXNlci5ncm91cFZhbHVlLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cE1lbWJlcnM6IHVzZXIuZ3JvdXBNZW1iZXJzLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb250aGx5SW5zdGFsbG1lbnQ6IHVzZXIubW9udGhseUluc3RhbGxtZW50LFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBncm91cElkOiB1c2VyLmdyb3VwSWQ/Ll9pZCB8fCB1c2VyLmdyb3VwSWQsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vICB1c2VySWQ6IHVzZXIudXNlcklkLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKHVwZGF0ZWREYXRhKTtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBtYi00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtzZW5kV2hhdHNhcHB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgYmctZ3JlZW4tNjAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLWdyZWVuLTcwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMCBmbGV4IGl0ZW1zLWNlbnRlclwiXHJcbi8vICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICB7dmlzaWJsZVNlbGVjdGVkQ291bnQgPiAwICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWluLXctNiBoLTYgYWJzb2x1dGUgLXJpZ2h0LTMgLXRvcC0yIHNoYWRvdy1sZyBob3ZlcjpiZy1yZWQtNjAwIGJnLXJlZC00MDAgcm91bmRlZC1mdWxsIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC14c1wiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtgTWVzc2FnZSB3aWxsIGJlIHNlbnQgdG8gdG90YWwgJHt2aXNpYmxlU2VsZWN0ZWRDb3VudH0gY3VzdG9tZXJzYH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3Zpc2libGVTZWxlY3RlZENvdW50fTwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPEZhV2hhdHNhcHAgY2xhc3NOYW1lPVwibXItMlwiIHNpemU9ezIwfSAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIFdoYXRzQXBwXHJcbi8vICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbi8vICAgICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlcmVkVXNlcnN9XHJcbi8vICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e0F1Y3Rpb25jb2x1bW5zfVxyXG4vLyAgICAgICAgICAgICAgICAgICBjYXRjaGVyPVwiX2lkXCJcclxuLy8gICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiQmlkIFdpbm5lclwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1wiR3JvdXAgTmFtZVwiXX1cclxuLy8gICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJWYWx1ZXM9e1tncm91cEZpbHRlcl19XHJcbi8vICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BCaWQgV2lubmVyLmNzdmB9XHJcbi8vICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICl9XHJcbi8vICAgICAgIDwvZGl2PlxyXG4vLyAgICAgPC9kaXY+XHJcbi8vICAgKTtcclxuLy8gfTtcclxuXHJcbmNvbnN0IEN1c3RvbWVyQ2hpdFBsYW5XaGF0c2FwcE1lc3NhZ2UgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3VzZXJzRGF0YSwgc2V0VXNlcnNEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZ3JvdXBGaWx0ZXIsIHNldEdyb3VwRmlsdGVyXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtmcm9tRGF0ZSwgc2V0RnJvbURhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3RvRGF0ZSwgc2V0VG9EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFthY3RpdmVVc2VyRGF0YSwgc2V0QWN0aXZlVXNlckRhdGFdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlbGVjdEFsbCwgc2V0U2VsZWN0QWxsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VsZWN0ZWREYXRlLCBzZXRTZWxlY3RlZERhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkTGFiZWwsIHNldFNlbGVjdGVkTGFiZWxdID0gdXNlU3RhdGUoXCJBbGxcIik7XHJcbiAgY29uc3QgW25vdGlmaWVyLCBjb250ZXh0SG9sZGVyXSA9IG5vdGlmaWNhdGlvbi51c2VOb3RpZmljYXRpb24oKTtcclxuXHJcbiAgY29uc3QgZ3JvdXBPcHRpb25zID0gW1xyXG4gICAgLi4ubmV3IFNldChcclxuICAgICAgdXNlcnNEYXRhXHJcbiAgICAgICAgLmZpbHRlcihcclxuICAgICAgICAgICh1KSA9PlxyXG4gICAgICAgICAgICB1Lmdyb3VwTmFtZSAhPT0gdW5kZWZpbmVkICYmXHJcbiAgICAgICAgICAgIHUuZ3JvdXBOYW1lICE9PSBcIlwiICYmXHJcbiAgICAgICAgICAgIHUuZ3JvdXBOYW1lICE9PSBcIiAgIFwiXHJcbiAgICAgICAgKVxyXG4gICAgICAgIC5tYXAoKHUpID0+IHUuZ3JvdXBOYW1lKVxyXG4gICAgKSxcclxuICBdO1xyXG5cclxuICAvKiog8J+UuSBOb3JtYWxpemVkIERhdGUgVXRpbGl0eSAqL1xyXG4gIGNvbnN0IG5vcm1hbGl6ZURhdGUgPSAoZGF0ZSkgPT4ge1xyXG4gICAgaWYgKCFkYXRlKSByZXR1cm4gXCJcIjtcclxuICAgIHJldHVybiBuZXcgRGF0ZShkYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1DQVwiKTtcclxuICB9O1xyXG5cclxuICAvKiog8J+UuSBGaWx0ZXIgVXNlcnMgKi9cclxuICBjb25zdCBmaWx0ZXJlZFVzZXJzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBmaWx0ZXJlZCA9IHVzZXJzRGF0YS5maWx0ZXIoKHUpID0+IHtcclxuICAgICAgY29uc3QgbWF0Y2hHcm91cCA9IGdyb3VwRmlsdGVyID8gdS5ncm91cE5hbWUgPT09IGdyb3VwRmlsdGVyIDogdHJ1ZTtcclxuICAgICAgY29uc3QgZW5yb2xsbWVudERhdGUgPSBub3JtYWxpemVEYXRlKHUuZW5yb2xsbWVudERhdGUpO1xyXG4gICAgICBjb25zdCBtYXRjaEZyb21EYXRlID0gZnJvbURhdGUgPyBlbnJvbGxtZW50RGF0ZSA+PSBmcm9tRGF0ZSA6IHRydWU7XHJcbiAgICAgIGNvbnN0IG1hdGNoVG9EYXRlID0gdG9EYXRlID8gZW5yb2xsbWVudERhdGUgPD0gdG9EYXRlIDogdHJ1ZTtcclxuICAgICAgY29uc3QgZmlsdGVyRW5yb2xsRGF0ZSA9IHNlbGVjdGVkRGF0ZVxyXG4gICAgICAgID8gbm9ybWFsaXplRGF0ZSh1LmVucm9sbERhdGUpID09PSBzZWxlY3RlZERhdGVcclxuICAgICAgICA6IHRydWU7XHJcbiAgICAgIHJldHVybiBtYXRjaEdyb3VwICYmIG1hdGNoRnJvbURhdGUgJiYgbWF0Y2hUb0RhdGUgJiYgZmlsdGVyRW5yb2xsRGF0ZTtcclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBmaWx0ZXJlZC5tYXAoKHVzZXIsIGluZGV4KSA9PiB7XHJcbiAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSAhIWFjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXT8uaW5mbz8uc3RhdHVzO1xyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLnVzZXIsXHJcbiAgICAgICAgc2xfbm86IGluZGV4ICsgMSxcclxuICAgICAgICBjaGVja0JveHM6IChcclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICBjaGVja2VkPXtpc1NlbGVjdGVkfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICBzZXRBY3RpdmVVc2VyRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICBbdXNlci5faWRdOiB7XHJcbiAgICAgICAgICAgICAgICAgIGluZm86IHtcclxuICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlclBob25lOiB1c2VyLnVzZXJQaG9uZSxcclxuICAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIGdyb3VwVmFsdWU6IHVzZXIuZ3JvdXBWYWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICBncm91cE1lbWJlcnM6IHVzZXIuZ3JvdXBNZW1iZXJzLFxyXG4gICAgICAgICAgICAgICAgICAgIG1vbnRobHlJbnN0YWxsbWVudDogdXNlci5tb250aGx5SW5zdGFsbG1lbnQsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlck5hbWU6IHVzZXIudXNlck5hbWUsXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKSxcclxuICAgICAgICBpc1NlbGVjdGVkLFxyXG4gICAgICB9O1xyXG4gICAgfSk7XHJcbiAgfSwgW1xyXG4gICAgdXNlcnNEYXRhLFxyXG4gICAgZ3JvdXBGaWx0ZXIsXHJcbiAgICBmcm9tRGF0ZSxcclxuICAgIHRvRGF0ZSxcclxuICAgIHNlYXJjaFRleHQsXHJcbiAgICBhY3RpdmVVc2VyRGF0YSxcclxuICAgIHNlbGVjdGVkRGF0ZSxcclxuICBdKTtcclxuXHJcbiAgLyoqIPCflLkgSGFuZGxlIFByZWRlZmluZWQgRGF0ZSBGaWx0ZXJzICovXHJcbiAgY29uc3QgaGFuZGxlU2VsZWN0RmlsdGVyID0gKHZhbHVlKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZExhYmVsKHZhbHVlKTtcclxuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICAgIGNvbnN0IGZvcm1hdERhdGUgPSAoZCkgPT4gZC50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1DQVwiKTtcclxuXHJcbiAgICBpZiAodmFsdWUgPT09IFwiVG9kYXlcIikge1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZSh0b2RheSkpO1xyXG4gICAgICBzZXRGcm9tRGF0ZShcIlwiKTtcclxuICAgICAgc2V0VG9EYXRlKFwiXCIpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJZZXN0ZXJkYXlcIikge1xyXG4gICAgICBjb25zdCB5ID0gbmV3IERhdGUodG9kYXkpO1xyXG4gICAgICB5LnNldERhdGUoeS5nZXREYXRlKCkgLSAxKTtcclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKGZvcm1hdERhdGUoeSkpO1xyXG4gICAgICBzZXRGcm9tRGF0ZShcIlwiKTtcclxuICAgICAgc2V0VG9EYXRlKFwiXCIpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUd29EYXlzQWdvXCIpIHtcclxuICAgICAgY29uc3QgdCA9IG5ldyBEYXRlKHRvZGF5KTtcclxuICAgICAgdC5zZXREYXRlKHQuZ2V0RGF0ZSgpIC0gMik7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlKHQpKTtcclxuICAgICAgc2V0RnJvbURhdGUoXCJcIik7XHJcbiAgICAgIHNldFRvRGF0ZShcIlwiKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc1dlZWtcIikge1xyXG4gICAgICBjb25zdCBkYXkgPSB0b2RheS5nZXREYXkoKTtcclxuICAgICAgY29uc3QgZGlmZlRvTW9uZGF5ID0gZGF5ID09PSAwID8gNiA6IGRheSAtIDE7XHJcbiAgICAgIGNvbnN0IG1vbmRheSA9IG5ldyBEYXRlKHRvZGF5KTtcclxuICAgICAgbW9uZGF5LnNldERhdGUodG9kYXkuZ2V0RGF0ZSgpIC0gZGlmZlRvTW9uZGF5KTtcclxuICAgICAgY29uc3Qgc3VuZGF5ID0gbmV3IERhdGUobW9uZGF5KTtcclxuICAgICAgc3VuZGF5LnNldERhdGUobW9uZGF5LmdldERhdGUoKSArIDYpO1xyXG4gICAgICBzZXRGcm9tRGF0ZShmb3JtYXREYXRlKG1vbmRheSkpO1xyXG4gICAgICBzZXRUb0RhdGUoZm9ybWF0RGF0ZShzdW5kYXkpKTtcclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKFwiXCIpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJMYXN0V2Vla1wiKSB7XHJcbiAgICAgIGNvbnN0IGRheSA9IHRvZGF5LmdldERheSgpO1xyXG4gICAgICBjb25zdCBkaWZmVG9Nb25kYXkgPSBkYXkgPT09IDAgPyA2IDogZGF5IC0gMTtcclxuICAgICAgY29uc3QgdGhpc01vbmRheSA9IG5ldyBEYXRlKHRvZGF5KTtcclxuICAgICAgdGhpc01vbmRheS5zZXREYXRlKHRvZGF5LmdldERhdGUoKSAtIGRpZmZUb01vbmRheSk7XHJcbiAgICAgIGNvbnN0IGxhc3RNb25kYXkgPSBuZXcgRGF0ZSh0aGlzTW9uZGF5KTtcclxuICAgICAgbGFzdE1vbmRheS5zZXREYXRlKHRoaXNNb25kYXkuZ2V0RGF0ZSgpIC0gNyk7XHJcbiAgICAgIGNvbnN0IGxhc3RTdW5kYXkgPSBuZXcgRGF0ZShsYXN0TW9uZGF5KTtcclxuICAgICAgbGFzdFN1bmRheS5zZXREYXRlKGxhc3RNb25kYXkuZ2V0RGF0ZSgpICsgNik7XHJcbiAgICAgIHNldEZyb21EYXRlKGZvcm1hdERhdGUobGFzdE1vbmRheSkpO1xyXG4gICAgICBzZXRUb0RhdGUoZm9ybWF0RGF0ZShsYXN0U3VuZGF5KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShcIlwiKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc01vbnRoXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSArIDEsIDApO1xyXG4gICAgICBzZXRGcm9tRGF0ZShmb3JtYXREYXRlKHN0YXJ0KSk7XHJcbiAgICAgIHNldFRvRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoXCJcIik7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkxhc3RNb250aFwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSAtIDEsIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAwKTtcclxuICAgICAgc2V0RnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4gICAgICBzZXRUb0RhdGUoZm9ybWF0RGF0ZShlbmQpKTtcclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKFwiXCIpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzWWVhclwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMCwgMSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDExLCAzMSk7XHJcbiAgICAgIHNldEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnQpKTtcclxuICAgICAgc2V0VG9EYXRlKGZvcm1hdERhdGUoZW5kKSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShcIlwiKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiQWxsXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSgyMDAwLCAwLCAxKTtcclxuICAgICAgc2V0RnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4gICAgICBzZXRUb0RhdGUoZm9ybWF0RGF0ZSh0b2RheSkpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoXCJcIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGhhbmRsZVNlbGVjdEZpbHRlcihcIkFsbFwiKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIC8qKiDwn5S5IFZpc2libGUgU2VsZWN0ZWQgQ291bnQgKi9cclxuICBjb25zdCB2aXNpYmxlU2VsZWN0ZWRDb3VudCA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGZpbHRlcmVkVXNlcnMuZmlsdGVyKCh1KSA9PiB1LmlzU2VsZWN0ZWQpLmxlbmd0aDtcclxuICB9LCBbZmlsdGVyZWRVc2Vyc10pO1xyXG5cclxuICAvKiog8J+UuSBGZXRjaCBEYXRhICovXHJcbiAgY29uc3QgZmV0Y2hEYXRhID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGFwaS5nZXQoXCIvZW5yb2xsL2dldC1lbnJvbGxcIik7XHJcbiAgICAgIGNvbnN0IHRlbXBBY3RpdmUgPSB7fTtcclxuICAgICAgY29uc3QgdXNlcnNMaXN0ID0gZGF0YS5tYXAoKHVzZXIpID0+IHtcclxuICAgICAgICBjb25zdCBpZCA9IHVzZXIuX2lkO1xyXG4gICAgICAgIGNvbnN0IHVzZXJOYW1lID0gdXNlcj8udXNlcl9pZD8uZnVsbF9uYW1lO1xyXG4gICAgICAgIGNvbnN0IHVzZXJQaG9uZSA9IHVzZXI/LnVzZXJfaWQ/LnBob25lX251bWJlcjtcclxuICAgICAgICBjb25zdCBncm91cE5hbWUgPSB1c2VyPy5ncm91cF9pZD8uZ3JvdXBfbmFtZTtcclxuICAgICAgICBjb25zdCBncm91cFZhbHVlID0gdXNlcj8uZ3JvdXBfaWQ/Lmdyb3VwX3ZhbHVlO1xyXG4gICAgICAgIGNvbnN0IGdyb3VwTWVtYmVycyA9IHVzZXI/Lmdyb3VwX2lkPy5ncm91cF9tZW1iZXJzO1xyXG4gICAgICAgIGNvbnN0IG1vbnRobHlJbnN0YWxsbWVudCA9IHVzZXI/Lmdyb3VwX2lkPy5tb250aGx5SW5zdGFsbG1lbnQ7XHJcbiAgICAgICAgY29uc3QgZW5yb2xsRGF0ZSA9IHVzZXI/LmNyZWF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdO1xyXG4gICAgICAgIGNvbnN0IGVucm9sbG1lbnREYXRlID0gdXNlcj8uZ3JvdXBfaWQ/LmNyZWF0ZWRBdFxyXG4gICAgICAgICAgPyB1c2VyLmdyb3VwX2lkLmNyZWF0ZWRBdC5zcGxpdChcIlRcIilbMF1cclxuICAgICAgICAgIDogZW5yb2xsRGF0ZTtcclxuXHJcbiAgICAgICAgdGVtcEFjdGl2ZVtpZF0gPSB7IGluZm86IHsgc3RhdHVzOiBmYWxzZSB9IH07XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIF9pZDogaWQsXHJcbiAgICAgICAgICB1c2VyTmFtZSxcclxuICAgICAgICAgIHVzZXJQaG9uZSxcclxuICAgICAgICAgIGdyb3VwTmFtZSxcclxuICAgICAgICAgIGdyb3VwVmFsdWUsXHJcbiAgICAgICAgICBncm91cE1lbWJlcnMsXHJcbiAgICAgICAgICBtb250aGx5SW5zdGFsbG1lbnQsXHJcbiAgICAgICAgICBlbnJvbGxEYXRlLFxyXG4gICAgICAgICAgZW5yb2xsbWVudERhdGUsXHJcbiAgICAgICAgfTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBzZXRVc2Vyc0RhdGEodXNlcnNMaXN0KTtcclxuICAgICAgc2V0QWN0aXZlVXNlckRhdGEodGVtcEFjdGl2ZSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGRhdGE6XCIsIGVycik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaERhdGEoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIC8qKiDwn5S5IFNlbmQgV2hhdHNBcHAgTWVzc2FnZXMgKi9cclxuICBjb25zdCBzZW5kV2hhdHNhcHAgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBjb25zdCBrZXkgPSBcInVwZGF0YWJsZVwiO1xyXG4gICAgdHJ5IHtcclxuICAgICAgbm90aWZpZXIub3Blbih7XHJcbiAgICAgICAga2V5LFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiU2VuZGluZyBNZXNzYWdlcyB2aWEgV2hhdHNBcHAuLi5cIixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYmctZ3JlZW4tMzAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbiAgICAgICAgZHVyYXRpb246IDIsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgcmVjZWl2ZXJzID0ge307XHJcbiAgICAgIGZpbHRlcmVkVXNlcnMuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4gICAgICAgIGlmICh1c2VyLmlzU2VsZWN0ZWQgJiYgYWN0aXZlVXNlckRhdGFbdXNlci5faWRdKSB7XHJcbiAgICAgICAgICByZWNlaXZlcnNbdXNlci5faWRdID0gYWN0aXZlVXNlckRhdGFbdXNlci5faWRdO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcblxyXG4gICAgICBhd2FpdCBhcGkucG9zdChcIi93aGF0c2FwcC9jdXN0b21lci13ZWxjb21lLW1lc3NhZ2VcIiwgeyByZWNlaXZlcnMgfSk7XHJcblxyXG4gICAgICBjb25zdCB1cGRhdGVkQWN0aXZlID0geyAuLi5hY3RpdmVVc2VyRGF0YSB9O1xyXG4gICAgICBmaWx0ZXJlZFVzZXJzLmZvckVhY2goKHUpID0+IHtcclxuICAgICAgICBpZiAodS5pc1NlbGVjdGVkKSBkZWxldGUgdXBkYXRlZEFjdGl2ZVt1Ll9pZF07XHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRBY3RpdmVVc2VyRGF0YSh1cGRhdGVkQWN0aXZlKTtcclxuXHJcbiAgICAgIG5vdGlmaWVyLm9wZW4oe1xyXG4gICAgICAgIGtleSxcclxuICAgICAgICBtZXNzYWdlOiBcIldoYXRzQXBwIE1lc3NhZ2VzIFNlbnQgU3VjY2Vzc2Z1bGx5IVwiLFxyXG4gICAgICAgIGNsYXNzTmFtZTogXCJiZy1ncmVlbi0zMDAgcm91bmRlZC1sZyBmb250LWJvbGRcIixcclxuICAgICAgICBkdXJhdGlvbjogMixcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgbm90aWZpZXIub3Blbih7XHJcbiAgICAgICAga2V5LFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIFNlbmQgV2hhdHNBcHBcIixcclxuICAgICAgICBkZXNjcmlwdGlvbjogZXJyLm1lc3NhZ2UgfHwgXCJTb21ldGhpbmcgd2VudCB3cm9uZ1wiLFxyXG4gICAgICAgIGNsYXNzTmFtZTogXCJiZy1yZWQtMzAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbiAgICAgICAgZHVyYXRpb246IDIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8qKiDwn5S5IFN5bmMgU2VsZWN0IEFsbCAqL1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBhbGxDaGVja2VkID1cclxuICAgICAgZmlsdGVyZWRVc2Vycy5sZW5ndGggPiAwICYmXHJcbiAgICAgIGZpbHRlcmVkVXNlcnMuZXZlcnkoKHUpID0+IGFjdGl2ZVVzZXJEYXRhW3UuX2lkXT8uaW5mbz8uc3RhdHVzKTtcclxuICAgIHNldFNlbGVjdEFsbChhbGxDaGVja2VkKTtcclxuICB9LCBbZmlsdGVyZWRVc2VycywgYWN0aXZlVXNlckRhdGFdKTtcclxuXHJcbiAgLyoqIPCflLkgVGFibGUgQ29sdW1ucyAqL1xyXG4gIGNvbnN0IEF1Y3Rpb25jb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwic2xfbm9cIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJjaGVja0JveHNcIiwgaGVhZGVyOiBcIlNlbGVjdFwiIH0sXHJcbiAgICB7IGtleTogXCJ1c2VyTmFtZVwiLCBoZWFkZXI6IFwiTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJ1c2VyUGhvbmVcIiwgaGVhZGVyOiBcIlBob25lXCIgfSxcclxuICAgIHsga2V5OiBcImVucm9sbERhdGVcIiwgaGVhZGVyOiBcIkpvaW5lZCBPblwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cE5hbWVcIiwgaGVhZGVyOiBcIkdyb3VwXCIgfSxcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXsoZSkgPT4gc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICBcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtY2VudGVyIG1iLTYgbXQtMlwiPlxyXG4gICAgICAgICAgICAgIEN1c3RvbWVyIENoaXQgUGxhbiBNZXNzYWdlXHJcbiAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgIHtjb250ZXh0SG9sZGVyfVxyXG4gICAgICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgY29sb3I9XCJ0ZXh0LWdyZWVuLTYwMFwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtNiBtdC04IG1iLTZcIj5cclxuICA8ZGl2IGNsYXNzTmFtZT1cImJnLXZpb2xldC0xMDAgcm91bmRlZC14bCBwLTYgc2hhZG93IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgPGRpdj5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+VG90YWwgQ3VzdG9tZXJzPC9wPlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC12aW9sZXQtNzAwXCI+XHJcbiAgICAgICAge2ZpbHRlcmVkVXNlcnMubGVuZ3RofVxyXG4gICAgICA8L3A+XHJcbiAgICA8L2Rpdj5cclxuICAgIDxGYVVzZXJzIGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTYwMCB0ZXh0LTR4bFwiIC8+XHJcbiAgPC9kaXY+XHJcblxyXG4gIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JlZW4tMTAwIHJvdW5kZWQteGwgcC02IHNoYWRvdyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgIDxkaXY+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlNlbGVjdGVkIEN1c3RvbWVyczwvcD5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtZ3JlZW4tNzAwXCI+XHJcbiAgICAgICAge3Zpc2libGVTZWxlY3RlZENvdW50fVxyXG4gICAgICA8L3A+XHJcbiAgICA8L2Rpdj5cclxuICAgIDxGYUNoZWNrQ2lyY2xlIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwIHRleHQtNHhsXCIgLz5cclxuICA8L2Rpdj5cclxuPC9kaXY+XHJcbiAgICAgICAgICAgICAgey8qIPCflLkgRmlsdGVycyAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtZW5kIGdhcC02IG1iLTggYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwIHBiLTRcIj5cclxuICAgICAgICAgICAgICAgICAgey8qIEdyb3VwIEZpbHRlciAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgR3JvdXBcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiAyMDAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiLS1BbGwgR3JvdXBzLS1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2KSA9PiBzZXRHcm91cEZpbHRlcih2KX1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cEZpbHRlciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2dyb3VwT3B0aW9ucy5tYXAoKGcpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtnfSB2YWx1ZT17Z30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2d9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBEYXRlIFJhbmdlIEZpbHRlciAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBEYXRlIEZpbHRlclxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiByb3VuZGVkIHRleHQtc21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkTGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZVNlbGVjdEZpbHRlcihlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlRvZGF5XCI+VG9kYXk8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJZZXN0ZXJkYXlcIj5ZZXN0ZXJkYXk8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUd29EYXlzQWdvXCI+VHdvIERheXMgQWdvPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVGhpc1dlZWtcIj5UaGlzIFdlZWs8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJMYXN0V2Vla1wiPkxhc3QgV2Vlazwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlRoaXNNb250aFwiPlRoaXMgTW9udGg8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJMYXN0TW9udGhcIj5MYXN0IE1vbnRoPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiVGhpc1llYXJcIj5UaGlzIFllYXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJBbGxcIj5BbGw8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogRGF0ZSBQaWNrZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZExhYmVsICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gbWItMVwiPkRhdGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZERhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcm91bmRlZCBweC0zIHB5LTEgdGV4dC1zbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIFNlbGVjdCBBbGwgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgbXQtNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTQgbXItMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtzZWxlY3RBbGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY2hlY2tlZCA9IGUudGFyZ2V0LmNoZWNrZWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdEFsbChjaGVja2VkKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdXBkYXRlZCA9IHsgLi4uYWN0aXZlVXNlckRhdGEgfTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyZWRVc2Vycy5mb3JFYWNoKCh1c2VyKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlZFt1c2VyLl9pZF0gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmZvOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czogY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXNlclBob25lOiB1c2VyLnVzZXJQaG9uZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXBOYW1lOiB1c2VyLmdyb3VwTmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXNlck5hbWU6IHVzZXIudXNlck5hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwVmFsdWU6IHVzZXIuZ3JvdXBWYWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXBNZW1iZXJzOiB1c2VyLmdyb3VwTWVtYmVycyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9udGhseUluc3RhbGxtZW50OiB1c2VyLm1vbnRobHlJbnN0YWxsbWVudCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKHVwZGF0ZWQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+U2VsZWN0IEFsbDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIPCflLkgU2VuZCBCdXR0b24gKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17c2VuZFdoYXRzYXBwfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLWdyZWVuLTYwMCB0ZXh0LXdoaXRlIHB4LTUgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy1ncmVlbi03MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDAgZmxleCBpdGVtcy1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3Zpc2libGVTZWxlY3RlZENvdW50ID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1pbi13LTYgaC02IGFic29sdXRlIC1yaWdodC0zIC10b3AtMiBzaGFkb3ctbGcgaG92ZXI6YmctcmVkLTYwMCBiZy1yZWQtNDAwIHJvdW5kZWQtZnVsbCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQteHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17YE1lc3NhZ2Ugd2lsbCBiZSBzZW50IHRvICR7dmlzaWJsZVNlbGVjdGVkQ291bnR9IGN1c3RvbWVyc2B9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt2aXNpYmxlU2VsZWN0ZWRDb3VudH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDxGYVdoYXRzYXBwIGNsYXNzTmFtZT1cIm1yLTJcIiBzaXplPXsyMH0gLz5cclxuICAgICAgICAgICAgICAgICAgICBXaGF0c0FwcFxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiDwn5S5IERhdGEgVGFibGUgKi99XHJcbiAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlcmVkVXNlcnN9XHJcbiAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e0F1Y3Rpb25jb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICBjYXRjaGVyPVwiX2lkXCJcclxuICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiQ3VzdG9tZXIgQ2hpdCBQbGFuXCJcclxuICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtbXCJHcm91cFwiXX1cclxuICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJWYWx1ZXM9e1tncm91cEZpbHRlcl19XHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJDdXN0b21lckNoaXRQbGFuLmNzdlwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICBcclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ3VzdG9tZXJDaGl0UGxhbldoYXRzYXBwTWVzc2FnZTtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0N1c3RvbWVyQ2hpdFBsYW5XaGF0c2FwcE1lc3NhZ2UuanN4In0=