import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/TransactionHistory.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select, DatePicker, Tag, Empty, Tooltip, Dropdown } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { FaHistory, FaEye, FaExchangeAlt } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import __vite__cjsImport9_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport9_dayjs.__esModule ? __vite__cjsImport9_dayjs.default : __vite__cjsImport9_dayjs;
import Navbar from "/src/components/layouts/Navbar.jsx";
import CustomerAcknowledgementPrint from "/src/components/printFormats/CustomerAcknowledgementPrint.jsx";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
const { RangePicker } = DatePicker;
const TransactionHistoryPage = () => {
  _s();
  const [transactions, setTransactions] = useState([]);
  const [groups, setGroups] = useState([]);
  const [users, setUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [filters, setFilters] = useState({
    group_id: "",
    user_id: "",
    transaction_type: "",
    startDate: "",
    endDate: ""
  });
  const [overview, setOverview] = useState({
    totalCount: 0,
    totalAmount: 0
  });
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "transaction_id", header: "Acknowledgement ID" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "full_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    // { key: "transaction_type", header: "Transaction Type" },
    { key: "group_name", header: "Group/Pigmy/Loan" },
    { key: "tickets", header: "Tickets/Pigmy-Id/Loan-Id" },
    { key: "reason", header: "Reason" },
    // { key: "closure_type", header: "Closure Type" },
    { key: "gross_amount", header: "Gross Amount" },
    { key: "service_charge", header: "Service Charge" },
    { key: "gst_amount", header: "GST Amount" },
    { key: "interest_amount", header: "Interest Amount" },
    { key: "amount", header: "Net Amount" },
    // { key: "enroll_code", header: "Enrollment Code" },
    // { key: "payment_type", header: "Payment Type" },
    // { key: "pigme_id", header: "Pigmy ID" },
    // { key: "request_status", header: "Request Status" },
    { key: "admin_name", header: "Processed By" },
    // { key: "remarks", header: "Remarks" },
    { key: "action", header: "Action" }
  ];
  const fetchInitialData = async () => {
    try {
      const [groupRes, userRes] = await Promise.all(
        [
          api.get("/group/get-group-admin"),
          api.get("user/verified")
        ]
      );
      setGroups(groupRes.data || []);
      setUsers(userRes.data?.data || []);
    } catch (error) {
      console.error("Error fetching initial data", error);
    }
  };
  const fetchTransactions = async () => {
    setIsLoading(true);
    try {
      const params = {};
      if (filters.group_id) params.group_id = filters.group_id;
      if (filters.user_id) params.user_id = filters.user_id;
      if (filters.transaction_type) {
        params.transaction_type = filters.transaction_type;
      }
      if (filters.startDate) params.startDate = filters.startDate;
      if (filters.endDate) params.endDate = filters.endDate;
      const response = await api.get(
        "/v1/admin/transaction-history/",
        { params }
      );
      if (response.data && response.data.data) {
        const formattedData = response.data.data.map((item, index) => {
          const customer = item.enroll_id?.user_id || item.pigme_id?.customer || {};
          const group = item.group_id || item.group || {};
          const formattedTransactionId = item.transaction_id ? item.transaction_id.replace("MCF-TRN-", "MCF-ACK-") : "-";
          const transactionAmount = Number(item.amount) || 0;
          return {
            id: index + 1,
            transaction_id: formattedTransactionId,
            full_name: customer.full_name || "-",
            phone_number: customer.phone_number || "-",
            transaction_type: item.transaction_type || "-",
            reason: /* @__PURE__ */ jsxDEV("span", { className: "text-blue-800 font-semibold ml-1", children: [
              item.reason || "-",
              item.pigme_id?.closure_type && /* @__PURE__ */ jsxDEV("span", { children: [
                "(",
                item.pigme_id.closure_type,
                ")"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
                lineNumber: 114,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
              lineNumber: 111,
              columnNumber: 13
            }, this),
            gross_amount: Number(item.gross_amount) || 0,
            amount: /* @__PURE__ */ jsxDEV("span", { className: "text-gray-900 font-semibold", children: transactionAmount }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
              lineNumber: 123,
              columnNumber: 13
            }, this),
            interest_amount: item.interest_amount !== void 0 && item.interest_amount !== null ? Number(item.interest_amount).toFixed(1) : "0",
            service_charge: Number(item.service_charge) || 0,
            gst_amount: Number(item.gst_amount) || 0,
            remarks: item.remarks || "-",
            transaction_date: item.transaction_date ? new Date(item.transaction_date).toLocaleDateString("en-IN") : "-",
            group_name: group.group_name ? group.group_name : item.pigme_id ? "Pigmy" : item.loan_id ? "Loan" : "-",
            tickets: item.enroll_id?.tickets || item.pigme_id?.pigme_id || item.loan_id?.loan_id || "-",
            enroll_code: item.enroll_id?.enroll_code || "-",
            payment_type: item.enroll_id?.payment_type || "-",
            request_status: item.pigme_id?.request_status || "-",
            admin_name: item.admin_id?.name || item.admin_id?.admin_name || "-",
            diff_group_value: item.enroll_id?.diff_group_value || "-",
            action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center gap-2", children: /* @__PURE__ */ jsxDEV(
              Dropdown,
              {
                trigger: ["click"],
                placement: "bottomRight",
                menu: {
                  items: [
                    {
                      key: "1",
                      label: /* @__PURE__ */ jsxDEV("div", { className: "text-blue-600 cursor-pointer", children: /* @__PURE__ */ jsxDEV(
                        CustomerAcknowledgementPrint,
                        {
                          item: {
                            transaction_id: formattedTransactionId,
                            full_name: customer.full_name || "-",
                            phone_number: customer.phone_number || "-",
                            transaction_type: item.transaction_type || "-",
                            reason: item.reason || "",
                            gross_amount: Number(item.gross_amount) || 0,
                            amount: transactionAmount,
                            interest_amount: Number(item.interest_amount) || 0,
                            service_charge: Number(item.service_charge) || 0,
                            gst_amount: Number(item.gst_amount) || 0,
                            remarks: item.remarks || "-",
                            transaction_date: item.transaction_date ? new Date(
                              item.transaction_date
                            ).toLocaleDateString("en-IN") : "-",
                            group_name: group.group_name || (item.pigme_id ? "Pigmy" : item.loan_id ? "Loan" : "-"),
                            tickets: item.enroll_id?.tickets || item.pigme_id?.pigme_id || item.loan_id?.loan_id || "-",
                            enroll_code: item.enroll_id?.enroll_code || "-",
                            payment_type: item.enroll_id?.payment_type || "-",
                            pigme_id: item.pigme_id?.pigme_id || "-",
                            request_status: item.pigme_id?.request_status || "-",
                            closure_type: item.pigme_id?.closure_type || "-",
                            admin_name: item.admin_id?.name || item.admin_id?.admin_name || "-"
                          }
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
                          lineNumber: 183,
                          columnNumber: 29
                        },
                        this
                      ) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
                        lineNumber: 182,
                        columnNumber: 21
                      }, this)
                    },
                    {
                      key: "2",
                      label: /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: "text-gray-700 cursor-pointer",
                          onClick: () => handleCopyTransaction(
                            item,
                            customer,
                            group
                          ),
                          children: "Copy Transaction"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
                          lineNumber: 270,
                          columnNumber: 21
                        },
                        this
                      )
                    }
                  ]
                },
                children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-xl cursor-pointer" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
                  lineNumber: 287,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
                lineNumber: 174,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
              lineNumber: 173,
              columnNumber: 13
            }, this)
          };
        });
        setTransactions(formattedData);
        setOverview({
          totalCount: formattedData.length,
          totalAmount: response.data.data.reduce(
            (acc, curr) => acc + (Number(curr.amount) || 0),
            0
          )
        });
      } else {
        setTransactions([]);
        setOverview({
          totalCount: 0,
          totalAmount: 0
        });
      }
    } catch (error) {
      setTransactions([]);
      setOverview({
        totalCount: 0,
        totalAmount: 0
      });
      console.error(
        "Error fetching transactions:",
        error
      );
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchInitialData();
  }, []);
  useEffect(() => {
    fetchTransactions();
  }, [filters]);
  const onDateRangeChange = (dates) => {
    if (dates) {
      setFilters((prev) => ({
        ...prev,
        startDate: dates[0].format("YYYY-MM-DD"),
        endDate: dates[1].format("YYYY-MM-DD")
      }));
    } else {
      setFilters((prev) => ({ ...prev, startDate: "", endDate: "" }));
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 bg-gray-50 min-h-screen", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold flex items-center gap-2", children: [
      /* @__PURE__ */ jsxDEV(FaHistory, { className: "text-blue-900" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
        lineNumber: 354,
        columnNumber: 11
      }, this),
      " Transaction History"
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
      lineNumber: 353,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
      lineNumber: 352,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-5 mb-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-xl p-5 shadow-md", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm opacity-90 font-medium", children: "Total Transactions" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
          lineNumber: 361,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold mt-1", children: overview.totalCount }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
          lineNumber: 362,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
        lineNumber: 360,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-emerald-600 to-teal-700 text-white rounded-xl p-5 shadow-md", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm opacity-90 font-medium", children: "Volume Handled" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
          lineNumber: 365,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold mt-1", children: [
          "₹",
          overview.totalAmount.toLocaleString("en-IN")
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
          lineNumber: 366,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
        lineNumber: 364,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
      lineNumber: 359,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-sm mb-8 border border-gray-100", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-bold text-gray-500 uppercase", children: "Group" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
          lineNumber: 375,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            placeholder: "All Groups",
            className: "w-full h-10 mt-1",
            allowClear: true,
            onChange: (val) => setFilters((prev) => ({ ...prev, group_id: val })),
            children: groups.map(
              (g) => /* @__PURE__ */ jsxDEV(Select.Option, { value: g._id, children: g.group_name }, g._id, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
                lineNumber: 383,
                columnNumber: 15
              }, this)
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
            lineNumber: 376,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
        lineNumber: 374,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-bold text-gray-500 uppercase", children: "Customer" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
          lineNumber: 389,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            placeholder: "All Users",
            className: "w-full h-10 mt-1",
            allowClear: true,
            showSearch: true,
            filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
            onChange: (val) => setFilters((prev) => ({ ...prev, user_id: val })),
            children: users.map(
              (u) => /* @__PURE__ */ jsxDEV(Select.Option, { value: u._id, children: u.full_name }, u._id, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
                lineNumber: 399,
                columnNumber: 15
              }, this)
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
            lineNumber: 390,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
        lineNumber: 388,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-bold text-gray-500 uppercase", children: "Date Range" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
          lineNumber: 405,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(RangePicker, { className: "w-full h-10 mt-1", onChange: onDateRangeChange }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
          lineNumber: 406,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
        lineNumber: 404,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-bold text-gray-500 uppercase", children: "Type" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
          lineNumber: 410,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            placeholder: "All Types",
            className: "w-full h-10 mt-1",
            allowClear: true,
            onChange: (val) => setFilters((prev) => ({ ...prev, transaction_type: val })),
            children: [
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "credit", children: "Credit" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
                lineNumber: 417,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "debit", children: "Debit" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
                lineNumber: 418,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
            lineNumber: 411,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
        lineNumber: 409,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
      lineNumber: 372,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
      lineNumber: 371,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm p-4", children: isLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true, data: "Transactions" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
      lineNumber: 428,
      columnNumber: 9
    }, this) : transactions.length <= 0 ? /* @__PURE__ */ jsxDEV(Empty, { description: "No Transactions Found" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
      lineNumber: 430,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(
      DataTable,
      {
        data: transactions,
        columns,
        exportedPdfName: "Transaction_Report",
        exportedFileName: "Transaction_Report.csv"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
        lineNumber: 432,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
      lineNumber: 426,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx",
    lineNumber: 350,
    columnNumber: 5
  }, this);
};
_s(TransactionHistoryPage, "DnMJ7xjcBjP7go1XFONQmgYra04=");
_c = TransactionHistoryPage;
export default TransactionHistoryPage;
var _c;
$RefreshReg$(_c, "TransactionHistoryPage");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/TransactionHistory.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUhrQjsyQkFqSGxCO0FBQW9CQSxvQkFBZ0IsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzQyxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLFFBQVFDLFlBQVlDLEtBQUtDLE9BQU9DLFNBQVNDLGdCQUFnQjtBQUNsRSxTQUFTQyxXQUFXQyxPQUFPQyxxQkFBcUI7QUFDaEQsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGtDQUFrQztBQUN6QyxTQUFTQyxnQkFBZ0I7QUFFekIsTUFBTSxFQUFFQyxZQUFZLElBQUlaO0FBRXhCLE1BQU1hLHlCQUF5QkEsTUFBTTtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sQ0FBQ0MsY0FBY0MsZUFBZSxJQUFJckIsU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQ3NCLFFBQVFDLFNBQVMsSUFBSXZCLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUN3QixPQUFPQyxRQUFRLElBQUl6QixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDMEIsV0FBV0MsWUFBWSxJQUFJM0IsU0FBUyxLQUFLO0FBR2hELFFBQU0sQ0FBQzRCLFNBQVNDLFVBQVUsSUFBSTdCLFNBQVM7QUFBQSxJQUNyQzhCLFVBQVU7QUFBQSxJQUNWQyxTQUFTO0FBQUEsSUFDVEMsa0JBQWtCO0FBQUEsSUFDbEJDLFdBQVc7QUFBQSxJQUNYQyxTQUFTO0FBQUEsRUFDWCxDQUFDO0FBR0QsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUlwQyxTQUFTO0FBQUEsSUFDdkNxQyxZQUFZO0FBQUEsSUFDWkMsYUFBYTtBQUFBLEVBQ2YsQ0FBQztBQUVELFFBQU1DLFVBQVU7QUFBQSxJQUNkLEVBQUVDLEtBQUssTUFBTUMsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxrQkFBa0JDLFFBQVEscUJBQXFCO0FBQUEsSUFDdEQsRUFBRUQsS0FBSyxvQkFBb0JDLFFBQVEsbUJBQW1CO0FBQUEsSUFDdEQsRUFBRUQsS0FBSyxhQUFhQyxRQUFRLGdCQUFnQjtBQUFBLElBQzVDLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGVBQWU7QUFBQTtBQUFBLElBRTlDLEVBQUVELEtBQUssY0FBY0MsUUFBUSxtQkFBbUI7QUFBQSxJQUNoRCxFQUFFRCxLQUFLLFdBQVdDLFFBQVEsMkJBQTJCO0FBQUEsSUFDckQsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQTtBQUFBLElBRWxDLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFRCxLQUFLLGtCQUFrQkMsUUFBUSxpQkFBaUI7QUFBQSxJQUNsRCxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVELEtBQUssbUJBQW1CQyxRQUFRLGtCQUFrQjtBQUFBLElBQ3BELEVBQUVELEtBQUssVUFBVUMsUUFBUSxhQUFhO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUt0QyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsZUFBZTtBQUFBO0FBQUEsSUFFNUMsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFFBQU1DLG1CQUFtQixZQUFZO0FBQ25DLFFBQUk7QUFDRixZQUFNLENBQUNDLFVBQVVDLE9BQU8sSUFBSSxNQUFNQyxRQUFRQztBQUFBQSxRQUFJO0FBQUEsVUFDNUM3QyxJQUFJOEMsSUFBSSx3QkFBd0I7QUFBQSxVQUNoQzlDLElBQUk4QyxJQUFJLGVBQWU7QUFBQSxRQUFDO0FBQUEsTUFDekI7QUFDRHhCLGdCQUFVb0IsU0FBU0ssUUFBUSxFQUFFO0FBQzdCdkIsZUFBU21CLFFBQVFJLE1BQU1BLFFBQVEsRUFBRTtBQUFBLElBQ25DLFNBQVNDLE9BQU87QUFDZEMsY0FBUUQsTUFBTSwrQkFBK0JBLEtBQUs7QUFBQSxJQUNwRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNRSxvQkFBb0IsWUFBWTtBQUNwQ3hCLGlCQUFhLElBQUk7QUFFakIsUUFBSTtBQUNGLFlBQU15QixTQUFTLENBQUM7QUFFaEIsVUFBSXhCLFFBQVFFLFNBQVVzQixRQUFPdEIsV0FBV0YsUUFBUUU7QUFDaEQsVUFBSUYsUUFBUUcsUUFBU3FCLFFBQU9yQixVQUFVSCxRQUFRRztBQUM5QyxVQUFJSCxRQUFRSSxrQkFBa0I7QUFDNUJvQixlQUFPcEIsbUJBQW1CSixRQUFRSTtBQUFBQSxNQUNwQztBQUNBLFVBQUlKLFFBQVFLLFVBQVdtQixRQUFPbkIsWUFBWUwsUUFBUUs7QUFDbEQsVUFBSUwsUUFBUU0sUUFBU2tCLFFBQU9sQixVQUFVTixRQUFRTTtBQUU5QyxZQUFNbUIsV0FBVyxNQUFNcEQsSUFBSThDO0FBQUFBLFFBQ3pCO0FBQUEsUUFDQSxFQUFFSyxPQUFPO0FBQUEsTUFDWDtBQUVBLFVBQUlDLFNBQVNMLFFBQVFLLFNBQVNMLEtBQUtBLE1BQU07QUFDdkMsY0FBTU0sZ0JBQWdCRCxTQUFTTCxLQUFLQSxLQUFLTyxJQUFJLENBQUNDLE1BQU1DLFVBQVU7QUFDNUQsZ0JBQU1DLFdBQVdGLEtBQUtHLFdBQVc1QixXQUFXeUIsS0FBS0ksVUFBVUYsWUFBWSxDQUFDO0FBQ3hFLGdCQUFNRyxRQUFRTCxLQUFLMUIsWUFBWTBCLEtBQUtLLFNBQVMsQ0FBQztBQUU5QyxnQkFBTUMseUJBQXlCTixLQUFLTyxpQkFDaENQLEtBQUtPLGVBQWVDLFFBQVEsWUFBWSxVQUFVLElBQ2xEO0FBRUosZ0JBQU1DLG9CQUFvQkMsT0FBT1YsS0FBS1csTUFBTSxLQUFLO0FBRWpELGlCQUFPO0FBQUEsWUFDTEMsSUFBSVgsUUFBUTtBQUFBLFlBRVpNLGdCQUFnQkQ7QUFBQUEsWUFDaEJPLFdBQVdYLFNBQVNXLGFBQWE7QUFBQSxZQUNqQ0MsY0FBY1osU0FBU1ksZ0JBQWdCO0FBQUEsWUFDdkN0QyxrQkFBa0J3QixLQUFLeEIsb0JBQW9CO0FBQUEsWUFDM0N1QyxRQUNFLHVCQUFDLFVBQUssV0FBVSxvQ0FDYmY7QUFBQUEsbUJBQUtlLFVBQVU7QUFBQSxjQUNmZixLQUFLSSxVQUFVWSxnQkFDZCx1QkFBQyxVQUFNO0FBQUE7QUFBQSxnQkFDSGhCLEtBQUtJLFNBQVNZO0FBQUFBLGdCQUFhO0FBQUEsbUJBRC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFFRkMsY0FBY1AsT0FBT1YsS0FBS2lCLFlBQVksS0FBSztBQUFBLFlBRTNDTixRQUNFLHVCQUFDLFVBQUssV0FBVSwrQkFDYkYsK0JBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBR0ZTLGlCQUNFbEIsS0FBS2tCLG9CQUFvQkMsVUFDdkJuQixLQUFLa0Isb0JBQW9CLE9BQ3ZCUixPQUFPVixLQUFLa0IsZUFBZSxFQUFFRSxRQUFRLENBQUMsSUFDdEM7QUFBQSxZQUVOQyxnQkFBZ0JYLE9BQU9WLEtBQUtxQixjQUFjLEtBQUs7QUFBQSxZQUUvQ0MsWUFBWVosT0FBT1YsS0FBS3NCLFVBQVUsS0FBSztBQUFBLFlBRXZDQyxTQUFTdkIsS0FBS3VCLFdBQVc7QUFBQSxZQUV6QkMsa0JBQWtCeEIsS0FBS3dCLG1CQUNuQixJQUFJQyxLQUFLekIsS0FBS3dCLGdCQUFnQixFQUFFRSxtQkFBbUIsT0FBTyxJQUMxRDtBQUFBLFlBRUpDLFlBQVl0QixNQUFNc0IsYUFDZHRCLE1BQU1zQixhQUNOM0IsS0FBS0ksV0FDSCxVQUNBSixLQUFLNEIsVUFDSCxTQUNBO0FBQUEsWUFFUkMsU0FDRTdCLEtBQUtHLFdBQVcwQixXQUNoQjdCLEtBQUtJLFVBQVVBLFlBQ2ZKLEtBQUs0QixTQUFTQSxXQUNkO0FBQUEsWUFFRkUsYUFBYTlCLEtBQUtHLFdBQVcyQixlQUFlO0FBQUEsWUFFNUNDLGNBQWMvQixLQUFLRyxXQUFXNEIsZ0JBQWdCO0FBQUEsWUFFOUNDLGdCQUFnQmhDLEtBQUtJLFVBQVU0QixrQkFBa0I7QUFBQSxZQUVqREMsWUFDRWpDLEtBQUtrQyxVQUFVQyxRQUNmbkMsS0FBS2tDLFVBQVVELGNBQ2Y7QUFBQSxZQUVGRyxrQkFDRXBDLEtBQUtHLFdBQVdpQyxvQkFBb0I7QUFBQSxZQUV0Q0MsUUFDRSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLENBQUMsT0FBTztBQUFBLGdCQUNqQixXQUFVO0FBQUEsZ0JBQ1YsTUFBTTtBQUFBLGtCQUNKQyxPQUFPO0FBQUEsb0JBQ0w7QUFBQSxzQkFDRXRELEtBQUs7QUFBQSxzQkFDTHVELE9BQ0UsdUJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQU07QUFBQSw0QkFDSmhDLGdCQUNFRDtBQUFBQSw0QkFFRk8sV0FDRVgsU0FBU1csYUFBYTtBQUFBLDRCQUV4QkMsY0FDRVosU0FBU1ksZ0JBQWdCO0FBQUEsNEJBRTNCdEMsa0JBQ0V3QixLQUFLeEIsb0JBQW9CO0FBQUEsNEJBRTNCdUMsUUFBUWYsS0FBS2UsVUFBVTtBQUFBLDRCQUV2QkUsY0FDRVAsT0FBT1YsS0FBS2lCLFlBQVksS0FBSztBQUFBLDRCQUUvQk4sUUFBUUY7QUFBQUEsNEJBRVJTLGlCQUNFUixPQUFPVixLQUFLa0IsZUFBZSxLQUFLO0FBQUEsNEJBRWxDRyxnQkFDRVgsT0FBT1YsS0FBS3FCLGNBQWMsS0FBSztBQUFBLDRCQUVqQ0MsWUFDRVosT0FBT1YsS0FBS3NCLFVBQVUsS0FBSztBQUFBLDRCQUU3QkMsU0FDRXZCLEtBQUt1QixXQUFXO0FBQUEsNEJBRWxCQyxrQkFDRXhCLEtBQUt3QixtQkFDRCxJQUFJQztBQUFBQSw4QkFDSnpCLEtBQUt3QjtBQUFBQSw0QkFDUCxFQUFFRSxtQkFBbUIsT0FBTyxJQUMxQjtBQUFBLDRCQUVOQyxZQUNFdEIsTUFBTXNCLGVBQ0wzQixLQUFLSSxXQUNGLFVBQ0FKLEtBQUs0QixVQUNILFNBQ0E7QUFBQSw0QkFFUkMsU0FDRTdCLEtBQUtHLFdBQVcwQixXQUNoQjdCLEtBQUtJLFVBQVVBLFlBQ2ZKLEtBQUs0QixTQUFTQSxXQUNkO0FBQUEsNEJBRUZFLGFBQ0U5QixLQUFLRyxXQUFXMkIsZUFDaEI7QUFBQSw0QkFFRkMsY0FDRS9CLEtBQUtHLFdBQVc0QixnQkFDaEI7QUFBQSw0QkFFRjNCLFVBQ0VKLEtBQUtJLFVBQVVBLFlBQ2Y7QUFBQSw0QkFFRjRCLGdCQUNFaEMsS0FBS0ksVUFBVTRCLGtCQUNmO0FBQUEsNEJBRUZoQixjQUNFaEIsS0FBS0ksVUFBVVksZ0JBQ2Y7QUFBQSw0QkFFRmlCLFlBQ0VqQyxLQUFLa0MsVUFBVUMsUUFDZm5DLEtBQUtrQyxVQUFVRCxjQUNmO0FBQUEsMEJBQ0o7QUFBQTtBQUFBLHdCQTlFRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBOEVJLEtBL0VOO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBaUZBO0FBQUEsb0JBRUo7QUFBQSxvQkFFQTtBQUFBLHNCQUNFakQsS0FBSztBQUFBLHNCQUNMdUQsT0FDRTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFVO0FBQUEsMEJBQ1YsU0FBUyxNQUNQQztBQUFBQSw0QkFDRXhDO0FBQUFBLDRCQUNBRTtBQUFBQSw0QkFDQUc7QUFBQUEsMEJBQ0Y7QUFBQSwwQkFDRDtBQUFBO0FBQUEsd0JBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQVdBO0FBQUEsb0JBRUo7QUFBQSxrQkFBQztBQUFBLGdCQUVMO0FBQUEsZ0JBRUEsaUNBQUMsWUFBUyxXQUFVLDRCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0QztBQUFBO0FBQUEsY0FqSDlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWtIQSxLQW5IRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9IQTtBQUFBLFVBRUo7QUFBQSxRQUNGLENBQUM7QUFFRHhDLHdCQUFnQmlDLGFBQWE7QUFFN0JsQixvQkFBWTtBQUFBLFVBQ1ZDLFlBQVlpQixjQUFjMkM7QUFBQUEsVUFFMUIzRCxhQUFhZSxTQUFTTCxLQUFLQSxLQUFLa0Q7QUFBQUEsWUFDOUIsQ0FBQ0MsS0FBS0MsU0FBU0QsT0FBT2pDLE9BQU9rQyxLQUFLakMsTUFBTSxLQUFLO0FBQUEsWUFDN0M7QUFBQSxVQUNGO0FBQUEsUUFDRixDQUFDO0FBQUEsTUFDSCxPQUFPO0FBQ0w5Qyx3QkFBZ0IsRUFBRTtBQUVsQmUsb0JBQVk7QUFBQSxVQUNWQyxZQUFZO0FBQUEsVUFDWkMsYUFBYTtBQUFBLFFBQ2YsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLFNBQVNXLE9BQU87QUFDZDVCLHNCQUFnQixFQUFFO0FBRWxCZSxrQkFBWTtBQUFBLFFBQ1ZDLFlBQVk7QUFBQSxRQUNaQyxhQUFhO0FBQUEsTUFDZixDQUFDO0FBRURZLGNBQVFEO0FBQUFBLFFBQ047QUFBQSxRQUNBQTtBQUFBQSxNQUNGO0FBQUEsSUFDRixVQUFDO0FBQ0N0QixtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUEwRSxZQUFVLE1BQU07QUFDZDNELHFCQUFpQjtBQUFBLEVBQ25CLEdBQUcsRUFBRTtBQUVMMkQsWUFBVSxNQUFNO0FBQ2RsRCxzQkFBa0I7QUFBQSxFQUNwQixHQUFHLENBQUN2QixPQUFPLENBQUM7QUFFWixRQUFNMEUsb0JBQW9CQSxDQUFDQyxVQUFVO0FBQ25DLFFBQUlBLE9BQU87QUFDVDFFLGlCQUFXLENBQUEyRSxVQUFTO0FBQUEsUUFDbEIsR0FBR0E7QUFBQUEsUUFDSHZFLFdBQVdzRSxNQUFNLENBQUMsRUFBRUUsT0FBTyxZQUFZO0FBQUEsUUFDdkN2RSxTQUFTcUUsTUFBTSxDQUFDLEVBQUVFLE9BQU8sWUFBWTtBQUFBLE1BQ3ZDLEVBQUU7QUFBQSxJQUNKLE9BQU87QUFDTDVFLGlCQUFXLENBQUEyRSxVQUFTLEVBQUUsR0FBR0EsTUFBTXZFLFdBQVcsSUFBSUMsU0FBUyxHQUFHLEVBQUU7QUFBQSxJQUM5RDtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSx5Q0FFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSwwQ0FDYixpQ0FBQyxRQUFHLFdBQVUsOENBQ1o7QUFBQSw2QkFBQyxhQUFVLFdBQVUsbUJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0M7QUFBQSxNQUFHO0FBQUEsU0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsa0ZBQ2I7QUFBQSwrQkFBQyxPQUFFLFdBQVUsa0NBQWlDLGtDQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdFO0FBQUEsUUFDaEUsdUJBQUMsUUFBRyxXQUFVLDJCQUEyQkMsbUJBQVNFLGNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkQ7QUFBQSxXQUYvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxxRkFDYjtBQUFBLCtCQUFDLE9BQUUsV0FBVSxrQ0FBaUMsOEJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEQ7QUFBQSxRQUM1RCx1QkFBQyxRQUFHLFdBQVUsMkJBQTBCO0FBQUE7QUFBQSxVQUFFRixTQUFTRyxZQUFZb0UsZUFBZSxPQUFPO0FBQUEsYUFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RjtBQUFBLFdBRnpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsaUVBQ2IsaUNBQUMsU0FBSSxXQUFVLHdEQUViO0FBQUEsNkJBQUMsU0FDQztBQUFBLCtCQUFDLFdBQU0sV0FBVSw2Q0FBNEMscUJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0U7QUFBQSxRQUNsRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsYUFBWTtBQUFBLFlBQ1osV0FBVTtBQUFBLFlBQ1Y7QUFBQSxZQUNBLFVBQVUsQ0FBQ0MsUUFBUTlFLFdBQVcsQ0FBQTJFLFVBQVMsRUFBRSxHQUFHQSxNQUFNMUUsVUFBVTZFLElBQUksRUFBRTtBQUFBLFlBRWpFckYsaUJBQU9pQztBQUFBQSxjQUFJLENBQUFxRCxNQUNWLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPQSxFQUFFQyxLQUFNRCxZQUFFekIsY0FBeEJ5QixFQUFFQyxLQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1RDtBQUFBLFlBQ3hEO0FBQUE7QUFBQSxVQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBO0FBQUEsV0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxNQUVBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxXQUFNLFdBQVUsNkNBQTRDLHdCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFFO0FBQUEsUUFDckU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLGFBQVk7QUFBQSxZQUNaLFdBQVU7QUFBQSxZQUNWO0FBQUEsWUFDQTtBQUFBLFlBQ0EsY0FBYyxDQUFDQyxPQUFPQyxXQUFXQSxPQUFPQyxTQUFTQyxZQUFZLEVBQUVDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLFlBQzNGLFVBQVUsQ0FBQ04sUUFBUTlFLFdBQVcsQ0FBQTJFLFVBQVMsRUFBRSxHQUFHQSxNQUFNekUsU0FBUzRFLElBQUksRUFBRTtBQUFBLFlBRWhFbkYsZ0JBQU0rQjtBQUFBQSxjQUFJLENBQUE0RCxNQUNULHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPQSxFQUFFTixLQUFNTSxZQUFFOUMsYUFBeEI4QyxFQUFFTixLQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRDtBQUFBLFlBQ3ZEO0FBQUE7QUFBQSxVQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVdBO0FBQUEsV0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxNQUVBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxXQUFNLFdBQVUsNkNBQTRDLDBCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVFO0FBQUEsUUFDdkUsdUJBQUMsZUFBWSxXQUFVLG9CQUFtQixVQUFVUCxxQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRTtBQUFBLFdBRnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUEsdUJBQUMsU0FDQztBQUFBLCtCQUFDLFdBQU0sV0FBVSw2Q0FBNEMsb0JBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUU7QUFBQSxRQUNqRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsYUFBWTtBQUFBLFlBQ1osV0FBVTtBQUFBLFlBQ1Y7QUFBQSxZQUNBLFVBQVUsQ0FBQ0ssUUFBUTlFLFdBQVcsQ0FBQTJFLFVBQVMsRUFBRSxHQUFHQSxNQUFNeEUsa0JBQWtCMkUsSUFBSSxFQUFFO0FBQUEsWUFFMUU7QUFBQSxxQ0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFVBQVMsc0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9DO0FBQUEsY0FDcEMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxTQUFRLHFCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrQztBQUFBO0FBQUE7QUFBQSxVQVBwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFRQTtBQUFBLFdBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsU0FoREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtEQSxLQW5ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0RBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUscUNBQ1pqRixzQkFDQyx1QkFBQyxrQkFBZSxXQUFXLE1BQU0sTUFBSyxrQkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRCxJQUNsRE4sYUFBYTZFLFVBQVUsSUFDekIsdUJBQUMsU0FBTSxhQUFZLDJCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBDLElBRTFDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNN0U7QUFBQUEsUUFDTjtBQUFBLFFBQ0EsaUJBQWdCO0FBQUEsUUFDaEIsa0JBQWlCO0FBQUE7QUFBQSxNQUpuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJMkMsS0FWL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsT0F6RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBGQTtBQUVKO0FBQUVELEdBNWFJRCx3QkFBc0I7QUFBQWtHLEtBQXRCbEc7QUE4YU4sZUFBZUE7QUFBdUIsSUFBQWtHO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsImFwaSIsIkRhdGFUYWJsZSIsIkNpcmN1bGFyTG9hZGVyIiwiU2VsZWN0IiwiRGF0ZVBpY2tlciIsIlRhZyIsIkVtcHR5IiwiVG9vbHRpcCIsIkRyb3Bkb3duIiwiRmFIaXN0b3J5IiwiRmFFeWUiLCJGYUV4Y2hhbmdlQWx0IiwiZGF5anMiLCJOYXZiYXIiLCJDdXN0b21lckFja25vd2xlZGdlbWVudFByaW50IiwiSW9NZE1vcmUiLCJSYW5nZVBpY2tlciIsIlRyYW5zYWN0aW9uSGlzdG9yeVBhZ2UiLCJfcyIsInRyYW5zYWN0aW9ucyIsInNldFRyYW5zYWN0aW9ucyIsImdyb3VwcyIsInNldEdyb3VwcyIsInVzZXJzIiwic2V0VXNlcnMiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJmaWx0ZXJzIiwic2V0RmlsdGVycyIsImdyb3VwX2lkIiwidXNlcl9pZCIsInRyYW5zYWN0aW9uX3R5cGUiLCJzdGFydERhdGUiLCJlbmREYXRlIiwib3ZlcnZpZXciLCJzZXRPdmVydmlldyIsInRvdGFsQ291bnQiLCJ0b3RhbEFtb3VudCIsImNvbHVtbnMiLCJrZXkiLCJoZWFkZXIiLCJmZXRjaEluaXRpYWxEYXRhIiwiZ3JvdXBSZXMiLCJ1c2VyUmVzIiwiUHJvbWlzZSIsImFsbCIsImdldCIsImRhdGEiLCJlcnJvciIsImNvbnNvbGUiLCJmZXRjaFRyYW5zYWN0aW9ucyIsInBhcmFtcyIsInJlc3BvbnNlIiwiZm9ybWF0dGVkRGF0YSIsIm1hcCIsIml0ZW0iLCJpbmRleCIsImN1c3RvbWVyIiwiZW5yb2xsX2lkIiwicGlnbWVfaWQiLCJncm91cCIsImZvcm1hdHRlZFRyYW5zYWN0aW9uSWQiLCJ0cmFuc2FjdGlvbl9pZCIsInJlcGxhY2UiLCJ0cmFuc2FjdGlvbkFtb3VudCIsIk51bWJlciIsImFtb3VudCIsImlkIiwiZnVsbF9uYW1lIiwicGhvbmVfbnVtYmVyIiwicmVhc29uIiwiY2xvc3VyZV90eXBlIiwiZ3Jvc3NfYW1vdW50IiwiaW50ZXJlc3RfYW1vdW50IiwidW5kZWZpbmVkIiwidG9GaXhlZCIsInNlcnZpY2VfY2hhcmdlIiwiZ3N0X2Ftb3VudCIsInJlbWFya3MiLCJ0cmFuc2FjdGlvbl9kYXRlIiwiRGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImdyb3VwX25hbWUiLCJsb2FuX2lkIiwidGlja2V0cyIsImVucm9sbF9jb2RlIiwicGF5bWVudF90eXBlIiwicmVxdWVzdF9zdGF0dXMiLCJhZG1pbl9uYW1lIiwiYWRtaW5faWQiLCJuYW1lIiwiZGlmZl9ncm91cF92YWx1ZSIsImFjdGlvbiIsIml0ZW1zIiwibGFiZWwiLCJoYW5kbGVDb3B5VHJhbnNhY3Rpb24iLCJsZW5ndGgiLCJyZWR1Y2UiLCJhY2MiLCJjdXJyIiwidXNlRWZmZWN0Iiwib25EYXRlUmFuZ2VDaGFuZ2UiLCJkYXRlcyIsInByZXYiLCJmb3JtYXQiLCJ0b0xvY2FsZVN0cmluZyIsInZhbCIsImciLCJfaWQiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsInUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUcmFuc2FjdGlvbkhpc3RvcnkuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgRGF0ZVBpY2tlciwgVGFnLCBFbXB0eSwgVG9vbHRpcCwgRHJvcGRvd24gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBGYUhpc3RvcnksIEZhRXllLCBGYUV4Y2hhbmdlQWx0IH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCBkYXlqcyBmcm9tIFwiZGF5anNcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgQ3VzdG9tZXJBY2tub3dsZWRnZW1lbnRQcmludCBmcm9tIFwiLi4vY29tcG9uZW50cy9wcmludEZvcm1hdHMvQ3VzdG9tZXJBY2tub3dsZWRnZW1lbnRQcmludFwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5cclxuY29uc3QgeyBSYW5nZVBpY2tlciB9ID0gRGF0ZVBpY2tlcjtcclxuXHJcbmNvbnN0IFRyYW5zYWN0aW9uSGlzdG9yeVBhZ2UgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3RyYW5zYWN0aW9ucywgc2V0VHJhbnNhY3Rpb25zXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIC8vIEZpbHRlciBTdGF0ZVxyXG4gIGNvbnN0IFtmaWx0ZXJzLCBzZXRGaWx0ZXJzXSA9IHVzZVN0YXRlKHtcclxuICAgIGdyb3VwX2lkOiBcIlwiLFxyXG4gICAgdXNlcl9pZDogXCJcIixcclxuICAgIHRyYW5zYWN0aW9uX3R5cGU6IFwiXCIsXHJcbiAgICBzdGFydERhdGU6IFwiXCIsXHJcbiAgICBlbmREYXRlOiBcIlwiXHJcbiAgfSk7XHJcblxyXG4gIC8vIE92ZXJ2aWV3IFN0YXRlIChPcHRpb25hbDogaWYgeW91ciBBUEkgcmV0dXJucyBzdW1tYXJ5IGRhdGEpXHJcbiAgY29uc3QgW292ZXJ2aWV3LCBzZXRPdmVydmlld10gPSB1c2VTdGF0ZSh7XHJcbiAgICB0b3RhbENvdW50OiAwLFxyXG4gICAgdG90YWxBbW91bnQ6IDBcclxuICB9KTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwidHJhbnNhY3Rpb25faWRcIiwgaGVhZGVyOiBcIkFja25vd2xlZGdlbWVudCBJRFwiIH0sXHJcbiAgICB7IGtleTogXCJ0cmFuc2FjdGlvbl9kYXRlXCIsIGhlYWRlcjogXCJUcmFuc2FjdGlvbiBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImZ1bGxfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICAvLyB7IGtleTogXCJ0cmFuc2FjdGlvbl90eXBlXCIsIGhlYWRlcjogXCJUcmFuc2FjdGlvbiBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX25hbWVcIiwgaGVhZGVyOiBcIkdyb3VwL1BpZ215L0xvYW5cIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0c1wiLCBoZWFkZXI6IFwiVGlja2V0cy9QaWdteS1JZC9Mb2FuLUlkXCIgfSxcclxuICAgIHsga2V5OiBcInJlYXNvblwiLCBoZWFkZXI6IFwiUmVhc29uXCIgfSxcclxuICAgIC8vIHsga2V5OiBcImNsb3N1cmVfdHlwZVwiLCBoZWFkZXI6IFwiQ2xvc3VyZSBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3NzX2Ftb3VudFwiLCBoZWFkZXI6IFwiR3Jvc3MgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcInNlcnZpY2VfY2hhcmdlXCIsIGhlYWRlcjogXCJTZXJ2aWNlIENoYXJnZVwiIH0sXHJcbiAgICB7IGtleTogXCJnc3RfYW1vdW50XCIsIGhlYWRlcjogXCJHU1QgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcImludGVyZXN0X2Ftb3VudFwiLCBoZWFkZXI6IFwiSW50ZXJlc3QgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudFwiLCBoZWFkZXI6IFwiTmV0IEFtb3VudFwiIH0sXHJcbiAgICAvLyB7IGtleTogXCJlbnJvbGxfY29kZVwiLCBoZWFkZXI6IFwiRW5yb2xsbWVudCBDb2RlXCIgfSxcclxuICAgIC8vIHsga2V5OiBcInBheW1lbnRfdHlwZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBUeXBlXCIgfSxcclxuICAgIC8vIHsga2V5OiBcInBpZ21lX2lkXCIsIGhlYWRlcjogXCJQaWdteSBJRFwiIH0sXHJcbiAgICAvLyB7IGtleTogXCJyZXF1ZXN0X3N0YXR1c1wiLCBoZWFkZXI6IFwiUmVxdWVzdCBTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWRtaW5fbmFtZVwiLCBoZWFkZXI6IFwiUHJvY2Vzc2VkIEJ5XCIgfSxcclxuICAgIC8vIHsga2V5OiBcInJlbWFya3NcIiwgaGVhZGVyOiBcIlJlbWFya3NcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGZldGNoSW5pdGlhbERhdGEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBbZ3JvdXBSZXMsIHVzZXJSZXNdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgIGFwaS5nZXQoXCIvZ3JvdXAvZ2V0LWdyb3VwLWFkbWluXCIpLFxyXG4gICAgICAgIGFwaS5nZXQoXCJ1c2VyL3ZlcmlmaWVkXCIpXHJcbiAgICAgIF0pO1xyXG4gICAgICBzZXRHcm91cHMoZ3JvdXBSZXMuZGF0YSB8fCBbXSk7XHJcbiAgICAgIHNldFVzZXJzKHVzZXJSZXMuZGF0YT8uZGF0YSB8fCBbXSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgaW5pdGlhbCBkYXRhXCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaFRyYW5zYWN0aW9ucyA9IGFzeW5jICgpID0+IHtcclxuICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBwYXJhbXMgPSB7fTtcclxuXHJcbiAgICAgIGlmIChmaWx0ZXJzLmdyb3VwX2lkKSBwYXJhbXMuZ3JvdXBfaWQgPSBmaWx0ZXJzLmdyb3VwX2lkO1xyXG4gICAgICBpZiAoZmlsdGVycy51c2VyX2lkKSBwYXJhbXMudXNlcl9pZCA9IGZpbHRlcnMudXNlcl9pZDtcclxuICAgICAgaWYgKGZpbHRlcnMudHJhbnNhY3Rpb25fdHlwZSkge1xyXG4gICAgICAgIHBhcmFtcy50cmFuc2FjdGlvbl90eXBlID0gZmlsdGVycy50cmFuc2FjdGlvbl90eXBlO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChmaWx0ZXJzLnN0YXJ0RGF0ZSkgcGFyYW1zLnN0YXJ0RGF0ZSA9IGZpbHRlcnMuc3RhcnREYXRlO1xyXG4gICAgICBpZiAoZmlsdGVycy5lbmREYXRlKSBwYXJhbXMuZW5kRGF0ZSA9IGZpbHRlcnMuZW5kRGF0ZTtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBcIi92MS9hZG1pbi90cmFuc2FjdGlvbi1oaXN0b3J5L1wiLFxyXG4gICAgICAgIHsgcGFyYW1zIH1cclxuICAgICAgKTtcclxuXHJcbiAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEuZGF0YSkge1xyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLmRhdGEubWFwKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgY3VzdG9tZXIgPSBpdGVtLmVucm9sbF9pZD8udXNlcl9pZCB8fCBpdGVtLnBpZ21lX2lkPy5jdXN0b21lciB8fCB7fTtcclxuICAgICAgICAgIGNvbnN0IGdyb3VwID0gaXRlbS5ncm91cF9pZCB8fCBpdGVtLmdyb3VwIHx8IHt9O1xyXG5cclxuICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZFRyYW5zYWN0aW9uSWQgPSBpdGVtLnRyYW5zYWN0aW9uX2lkXHJcbiAgICAgICAgICAgID8gaXRlbS50cmFuc2FjdGlvbl9pZC5yZXBsYWNlKFwiTUNGLVRSTi1cIiwgXCJNQ0YtQUNLLVwiKVxyXG4gICAgICAgICAgICA6IFwiLVwiO1xyXG5cclxuICAgICAgICAgIGNvbnN0IHRyYW5zYWN0aW9uQW1vdW50ID0gTnVtYmVyKGl0ZW0uYW1vdW50KSB8fCAwO1xyXG5cclxuICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcblxyXG4gICAgICAgICAgICB0cmFuc2FjdGlvbl9pZDogZm9ybWF0dGVkVHJhbnNhY3Rpb25JZCxcclxuICAgICAgICAgICAgZnVsbF9uYW1lOiBjdXN0b21lci5mdWxsX25hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICAgIHBob25lX251bWJlcjogY3VzdG9tZXIucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICB0cmFuc2FjdGlvbl90eXBlOiBpdGVtLnRyYW5zYWN0aW9uX3R5cGUgfHwgXCItXCIsXHJcbiAgICAgICAgICAgIHJlYXNvbjogKFxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmx1ZS04MDAgZm9udC1zZW1pYm9sZCBtbC0xXCI+XHJcbiAgICAgICAgICAgICAgICB7aXRlbS5yZWFzb24gfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICB7aXRlbS5waWdtZV9pZD8uY2xvc3VyZV90eXBlICYmIChcclxuICAgICAgICAgICAgICAgICAgPHNwYW4gPlxyXG4gICAgICAgICAgICAgICAgICAgICh7aXRlbS5waWdtZV9pZC5jbG9zdXJlX3R5cGV9KVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgZ3Jvc3NfYW1vdW50OiBOdW1iZXIoaXRlbS5ncm9zc19hbW91bnQpIHx8IDAsXHJcblxyXG4gICAgICAgICAgICBhbW91bnQ6IChcclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktOTAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgIHt0cmFuc2FjdGlvbkFtb3VudH1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICksXHJcblxyXG4gICAgICAgICAgICBpbnRlcmVzdF9hbW91bnQ6XHJcbiAgICAgICAgICAgICAgaXRlbS5pbnRlcmVzdF9hbW91bnQgIT09IHVuZGVmaW5lZCAmJlxyXG4gICAgICAgICAgICAgICAgaXRlbS5pbnRlcmVzdF9hbW91bnQgIT09IG51bGxcclxuICAgICAgICAgICAgICAgID8gTnVtYmVyKGl0ZW0uaW50ZXJlc3RfYW1vdW50KS50b0ZpeGVkKDEpXHJcbiAgICAgICAgICAgICAgICA6IFwiMFwiLFxyXG5cclxuICAgICAgICAgICAgc2VydmljZV9jaGFyZ2U6IE51bWJlcihpdGVtLnNlcnZpY2VfY2hhcmdlKSB8fCAwLFxyXG5cclxuICAgICAgICAgICAgZ3N0X2Ftb3VudDogTnVtYmVyKGl0ZW0uZ3N0X2Ftb3VudCkgfHwgMCxcclxuXHJcbiAgICAgICAgICAgIHJlbWFya3M6IGl0ZW0ucmVtYXJrcyB8fCBcIi1cIixcclxuXHJcbiAgICAgICAgICAgIHRyYW5zYWN0aW9uX2RhdGU6IGl0ZW0udHJhbnNhY3Rpb25fZGF0ZVxyXG4gICAgICAgICAgICAgID8gbmV3IERhdGUoaXRlbS50cmFuc2FjdGlvbl9kYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1JTlwiKVxyXG4gICAgICAgICAgICAgIDogXCItXCIsXHJcblxyXG4gICAgICAgICAgICBncm91cF9uYW1lOiBncm91cC5ncm91cF9uYW1lXHJcbiAgICAgICAgICAgICAgPyBncm91cC5ncm91cF9uYW1lXHJcbiAgICAgICAgICAgICAgOiBpdGVtLnBpZ21lX2lkXHJcbiAgICAgICAgICAgICAgICA/IFwiUGlnbXlcIlxyXG4gICAgICAgICAgICAgICAgOiBpdGVtLmxvYW5faWRcclxuICAgICAgICAgICAgICAgICAgPyBcIkxvYW5cIlxyXG4gICAgICAgICAgICAgICAgICA6IFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgdGlja2V0czpcclxuICAgICAgICAgICAgICBpdGVtLmVucm9sbF9pZD8udGlja2V0cyB8fFxyXG4gICAgICAgICAgICAgIGl0ZW0ucGlnbWVfaWQ/LnBpZ21lX2lkIHx8XHJcbiAgICAgICAgICAgICAgaXRlbS5sb2FuX2lkPy5sb2FuX2lkIHx8XHJcbiAgICAgICAgICAgICAgXCItXCIsXHJcblxyXG4gICAgICAgICAgICBlbnJvbGxfY29kZTogaXRlbS5lbnJvbGxfaWQ/LmVucm9sbF9jb2RlIHx8IFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgcGF5bWVudF90eXBlOiBpdGVtLmVucm9sbF9pZD8ucGF5bWVudF90eXBlIHx8IFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgcmVxdWVzdF9zdGF0dXM6IGl0ZW0ucGlnbWVfaWQ/LnJlcXVlc3Rfc3RhdHVzIHx8IFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgYWRtaW5fbmFtZTpcclxuICAgICAgICAgICAgICBpdGVtLmFkbWluX2lkPy5uYW1lIHx8XHJcbiAgICAgICAgICAgICAgaXRlbS5hZG1pbl9pZD8uYWRtaW5fbmFtZSB8fFxyXG4gICAgICAgICAgICAgIFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgZGlmZl9ncm91cF92YWx1ZTpcclxuICAgICAgICAgICAgICBpdGVtLmVucm9sbF9pZD8uZGlmZl9ncm91cF92YWx1ZSB8fCBcIi1cIixcclxuXHJcbiAgICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tUmlnaHRcIlxyXG4gICAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDdXN0b21lckFja25vd2xlZGdlbWVudFByaW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW09e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvbl9pZDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1hdHRlZFRyYW5zYWN0aW9uSWQsXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZ1bGxfbmFtZTpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1c3RvbWVyLmZ1bGxfbmFtZSB8fCBcIi1cIixcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGhvbmVfbnVtYmVyOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VzdG9tZXIucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvbl90eXBlOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS50cmFuc2FjdGlvbl90eXBlIHx8IFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFzb246IGl0ZW0ucmVhc29uIHx8IFwiXCIsXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3NzX2Ftb3VudDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE51bWJlcihpdGVtLmdyb3NzX2Ftb3VudCkgfHwgMCxcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYW1vdW50OiB0cmFuc2FjdGlvbkFtb3VudCxcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW50ZXJlc3RfYW1vdW50OlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTnVtYmVyKGl0ZW0uaW50ZXJlc3RfYW1vdW50KSB8fCAwLFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXJ2aWNlX2NoYXJnZTpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE51bWJlcihpdGVtLnNlcnZpY2VfY2hhcmdlKSB8fCAwLFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnc3RfYW1vdW50OlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTnVtYmVyKGl0ZW0uZ3N0X2Ftb3VudCkgfHwgMCxcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVtYXJrczpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucmVtYXJrcyB8fCBcIi1cIixcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNhY3Rpb25fZGF0ZTpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0udHJhbnNhY3Rpb25fZGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0udHJhbnNhY3Rpb25fZGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUlOXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCItXCIsXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwX25hbWU6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cC5ncm91cF9uYW1lIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoaXRlbS5waWdtZV9pZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiUGlnbXlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGl0ZW0ubG9hbl9pZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJMb2FuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiLVwiKSxcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGlja2V0czpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0uZW5yb2xsX2lkPy50aWNrZXRzIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnBpZ21lX2lkPy5waWdtZV9pZCB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5sb2FuX2lkPy5sb2FuX2lkIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIi1cIixcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZW5yb2xsX2NvZGU6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLmVucm9sbF9pZD8uZW5yb2xsX2NvZGUgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXltZW50X3R5cGU6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLmVucm9sbF9pZD8ucGF5bWVudF90eXBlIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIi1cIixcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGlnbWVfaWQ6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnBpZ21lX2lkPy5waWdtZV9pZCB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCItXCIsXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVlc3Rfc3RhdHVzOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5waWdtZV9pZD8ucmVxdWVzdF9zdGF0dXMgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbG9zdXJlX3R5cGU6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLnBpZ21lX2lkPy5jbG9zdXJlX3R5cGUgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiLVwiLFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZG1pbl9uYW1lOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5hZG1pbl9pZD8ubmFtZSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5hZG1pbl9pZD8uYWRtaW5fbmFtZSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCItXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMCBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVDb3B5VHJhbnNhY3Rpb24oXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXN0b21lcixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ29weSBUcmFuc2FjdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC14bCBjdXJzb3ItcG9pbnRlclwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApLFxyXG4gICAgICAgICAgfTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgc2V0VHJhbnNhY3Rpb25zKGZvcm1hdHRlZERhdGEpO1xyXG5cclxuICAgICAgICBzZXRPdmVydmlldyh7XHJcbiAgICAgICAgICB0b3RhbENvdW50OiBmb3JtYXR0ZWREYXRhLmxlbmd0aCxcclxuXHJcbiAgICAgICAgICB0b3RhbEFtb3VudDogcmVzcG9uc2UuZGF0YS5kYXRhLnJlZHVjZShcclxuICAgICAgICAgICAgKGFjYywgY3VycikgPT4gYWNjICsgKE51bWJlcihjdXJyLmFtb3VudCkgfHwgMCksXHJcbiAgICAgICAgICAgIDBcclxuICAgICAgICAgICksXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0VHJhbnNhY3Rpb25zKFtdKTtcclxuXHJcbiAgICAgICAgc2V0T3ZlcnZpZXcoe1xyXG4gICAgICAgICAgdG90YWxDb3VudDogMCxcclxuICAgICAgICAgIHRvdGFsQW1vdW50OiAwLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzZXRUcmFuc2FjdGlvbnMoW10pO1xyXG5cclxuICAgICAgc2V0T3ZlcnZpZXcoe1xyXG4gICAgICAgIHRvdGFsQ291bnQ6IDAsXHJcbiAgICAgICAgdG90YWxBbW91bnQ6IDAsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc29sZS5lcnJvcihcclxuICAgICAgICBcIkVycm9yIGZldGNoaW5nIHRyYW5zYWN0aW9uczpcIixcclxuICAgICAgICBlcnJvclxyXG4gICAgICApO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hJbml0aWFsRGF0YSgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoVHJhbnNhY3Rpb25zKCk7XHJcbiAgfSwgW2ZpbHRlcnNdKTtcclxuXHJcbiAgY29uc3Qgb25EYXRlUmFuZ2VDaGFuZ2UgPSAoZGF0ZXMpID0+IHtcclxuICAgIGlmIChkYXRlcykge1xyXG4gICAgICBzZXRGaWx0ZXJzKHByZXYgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIHN0YXJ0RGF0ZTogZGF0ZXNbMF0uZm9ybWF0KFwiWVlZWS1NTS1ERFwiKSxcclxuICAgICAgICBlbmREYXRlOiBkYXRlc1sxXS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpXHJcbiAgICAgIH0pKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEZpbHRlcnMocHJldiA9PiAoeyAuLi5wcmV2LCBzdGFydERhdGU6IFwiXCIsIGVuZERhdGU6IFwiXCIgfSkpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTcgYmctZ3JheS01MCBtaW4taC1zY3JlZW5cIj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTZcIj5cclxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICA8RmFIaXN0b3J5IGNsYXNzTmFtZT1cInRleHQtYmx1ZS05MDBcIiAvPiBUcmFuc2FjdGlvbiBIaXN0b3J5XHJcbiAgICAgICAgPC9oMT5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogPT09PT09PT09PT09PT09PT0gT1ZFUlZJRVcgQ0FSRFMgPT09PT09PT09PT09PT09PT0gKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNSBtYi04XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS02MDAgdG8tYmx1ZS03MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHAtNSBzaGFkb3ctbWRcIj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gb3BhY2l0eS05MCBmb250LW1lZGl1bVwiPlRvdGFsIFRyYW5zYWN0aW9uczwvcD5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgbXQtMVwiPntvdmVydmlldy50b3RhbENvdW50fTwvaDI+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tZW1lcmFsZC02MDAgdG8tdGVhbC03MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHAtNSBzaGFkb3ctbWRcIj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gb3BhY2l0eS05MCBmb250LW1lZGl1bVwiPlZvbHVtZSBIYW5kbGVkPC9wPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCBtdC0xXCI+4oK5e292ZXJ2aWV3LnRvdGFsQW1vdW50LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9PC9oMj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogPT09PT09PT09PT09PT09PT0gRklMVEVSIFNFQ1RJT04gPT09PT09PT09PT09PT09PT0gKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC02IHJvdW5kZWQteGwgc2hhZG93LXNtIG1iLTggYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNFwiPlxyXG5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPkdyb3VwPC9sYWJlbD5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQWxsIEdyb3Vwc1wiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTAgbXQtMVwiXHJcbiAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsKSA9PiBzZXRGaWx0ZXJzKHByZXYgPT4gKHsgLi4ucHJldiwgZ3JvdXBfaWQ6IHZhbCB9KSl9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7Z3JvdXBzLm1hcChnID0+IChcclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Zy5faWR9IHZhbHVlPXtnLl9pZH0+e2cuZ3JvdXBfbmFtZX08L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+Q3VzdG9tZXI8L2xhYmVsPlxyXG4gICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBbGwgVXNlcnNcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEwIG10LTFcIlxyXG4gICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT4gb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSl9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IHNldEZpbHRlcnMocHJldiA9PiAoeyAuLi5wcmV2LCB1c2VyX2lkOiB2YWwgfSkpfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge3VzZXJzLm1hcCh1ID0+IChcclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dS5faWR9IHZhbHVlPXt1Ll9pZH0+e3UuZnVsbF9uYW1lfTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5EYXRlIFJhbmdlPC9sYWJlbD5cclxuICAgICAgICAgICAgPFJhbmdlUGlja2VyIGNsYXNzTmFtZT1cInctZnVsbCBoLTEwIG10LTFcIiBvbkNoYW5nZT17b25EYXRlUmFuZ2VDaGFuZ2V9IC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5UeXBlPC9sYWJlbD5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQWxsIFR5cGVzXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMCBtdC0xXCJcclxuICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWwpID0+IHNldEZpbHRlcnMocHJldiA9PiAoeyAuLi5wcmV2LCB0cmFuc2FjdGlvbl90eXBlOiB2YWwgfSkpfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJjcmVkaXRcIj5DcmVkaXQ8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJkZWJpdFwiPkRlYml0PC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogPT09PT09PT09PT09PT09PT0gREFUQSBUQUJMRSA9PT09PT09PT09PT09PT09PSAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1zbSBwLTRcIj5cclxuICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGlzTG9hZGluZz17dHJ1ZX0gZGF0YT1cIlRyYW5zYWN0aW9uc1wiIC8+XHJcbiAgICAgICAgKSA6IHRyYW5zYWN0aW9ucy5sZW5ndGggPD0gMCA/IChcclxuICAgICAgICAgIDxFbXB0eSBkZXNjcmlwdGlvbj1cIk5vIFRyYW5zYWN0aW9ucyBGb3VuZFwiIC8+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgZGF0YT17dHJhbnNhY3Rpb25zfVxyXG4gICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJUcmFuc2FjdGlvbl9SZXBvcnRcIlxyXG4gICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiVHJhbnNhY3Rpb25fUmVwb3J0LmNzdlwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFRyYW5zYWN0aW9uSGlzdG9yeVBhZ2U7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1RyYW5zYWN0aW9uSGlzdG9yeS5qc3gifQ==