import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LoanPaymentOut.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { Input, Select, Dropdown, Popover, Button, message } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { showConfirm } from "/src/components/alerts/ShowConfirm.jsx";
import {
  CheckCircleOutlined,
  ClockCircleOutlined,
  CloseCircleOutlined,
  ExclamationCircleOutlined,
  QuestionCircleOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const INITIAL_PAYMENT_STATE = {
  payment_amount: "",
  payment_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
  payment_mode: null,
  transaction_id: "",
  service_charges: "",
  document_charges: "",
  daily_payment_amount: "",
  start_date: "",
  end_date: "",
  loan_id: "",
  cheque_number: "",
  note: ""
};
const LoanPaymentOut = () => {
  _s();
  const [rawLoans, setRawLoans] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [currentBorrower, setCurrentBorrower] = useState(null);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [paymentFormData, setPaymentFormData] = useState(INITIAL_PAYMENT_STATE);
  const [paymentErrors, setPaymentErrors] = useState({});
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "",
    type: "info"
  });
  const [thirdPartyEnable, setThirdPartyEnable] = useState({
    whatsapp: true
  });
  const [modifyPayment, setModifyPayment] = useState(false);
  const [modifyMinMaxPaymentDate, setModifyMinMaxPaymentDate] = useState(false);
  const [adminId, setAdminId] = useState("");
  const fetchApprovedLoans = useCallback(async () => {
    try {
      setIsLoading(true);
      const { data } = await api.get(
        "/v1/admin/loans/?approval_status=APPROVED"
      );
      setRawLoans(data?.data || []);
    } catch (error) {
      showAlert("Failed to fetch approved loans", "error");
    } finally {
      setIsLoading(false);
    }
  }, []);
  useEffect(() => {
    fetchApprovedLoans();
  }, [fetchApprovedLoans, reloadTrigger]);
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    const userAdminId = userObj?._id;
    setAdminId(userAdminId);
    if (userObj) {
      const adminAccessPermissions = userObj.admin_access_right_id?.access_permissions;
      if (adminAccessPermissions?.edit_payment === "true") {
        setModifyPayment(true);
      }
      if (adminAccessPermissions?.edit_limited_payment === "true") {
        setModifyPayment(true);
        setModifyMinMaxPaymentDate(true);
      }
    }
  }, []);
  const showAlert = (message2, type = "info") => {
    setAlertConfig({ visibility: true, message: message2, type });
  };
  const resetForm = () => {
    setPaymentFormData(INITIAL_PAYMENT_STATE);
    setPaymentErrors({});
    setShowPaymentModal(false);
    setCurrentBorrower(null);
  };
  const buildNoteString = (fd) => {
    const parts = [];
    if (fd.note?.trim()) parts.push(fd.note.trim());
    if (fd.payment_mode === "Bank Transfer") {
      if (fd.transaction_id) parts.push(`Txn: ${fd.transaction_id}`);
      if (fd.bank_name) parts.push(`Bank: ${fd.bank_name}`);
    }
    if (fd.payment_mode === "Cheque" && fd.cheque_number) {
      parts.push(`Chq: ${fd.cheque_number}`);
    } else if (fd.payment_mode === "Online" && fd.transaction_id) {
      parts.push(`Txn: ${fd.transaction_id}`);
    }
    return parts.join(" | ");
  };
  const handlePaymentOutModalOpen = async (loanId) => {
    try {
      const response = await api.get(`v1/admin/loans/${loanId}`);
      const data = response.data?.data;
      setCurrentBorrower(data || {});
      setPaymentFormData((prev) => ({
        ...prev,
        payment_amount: Number(data?.loan_amount || 0) - Number(data.service_charges || 0) - Number(data.document_charges || 0) || 0,
        service_charges: data.service_charges || "",
        document_charges: data.document_charges || "",
        daily_payment_amount: data.daily_payment_amount || "",
        start_date: data.start_date,
        end_date: data.end_date,
        loan_id: data.loan_id,
        payment_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
      }));
      setShowPaymentModal(true);
    } catch (error) {
      showAlert("Failed to fetch borrower details", "error");
    }
  };
  const validate = () => {
    const errors = {};
    if (!paymentFormData.payment_amount || paymentFormData.payment_amount <= 0)
      errors.payment_amount = "Required";
    if (!paymentFormData.payment_date) errors.payment_date = "Required";
    if (!paymentFormData.payment_mode) errors.payment_mode = "Required";
    if (paymentFormData.payment_mode === "Bank Transfer" && !paymentFormData.transaction_id)
      errors.transaction_id = "Transaction ID required";
    if (paymentFormData.payment_mode === "Cheque" && !paymentFormData.cheque_number)
      errors.cheque_number = "Cheque number required";
    if (paymentErrors.pay_date === "Online" && !paymentFormData.transaction_id)
      errors.transaction_id = "Transaction ID required";
    setPaymentErrors(errors);
    return Object.keys(errors).length === 0;
  };
  const handlePaymentOutSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    try {
      const payload = {
        loan: currentBorrower?._id || currentBorrower?._id,
        user_id: currentBorrower?.borrower?._id || currentBorrower?.user_id,
        pay_date: paymentFormData.payment_date,
        amount: paymentFormData.payment_amount.toString(),
        pay_type: paymentFormData.payment_mode,
        pay_for: "Loan",
        note: paymentFormData.note,
        transaction_id: paymentFormData.transaction_id,
        admin_type: adminId,
        ...thirdPartyEnable
      };
      await api.patch("/v1/admin/loans/completed", payload);
      showAlert("Payment processed successfully", "success");
      setReloadTrigger((p) => p + 1);
      resetForm();
    } catch (error) {
      showAlert(
        error.response?.data?.message || error.response?.data?.statusCode || "Transaction failed",
        "error"
      );
    }
  };
  const updateLoanStatus = async (loan, newStatus) => {
    showConfirm({
      title: `${newStatus} Loan Request`,
      content: `Are you sure you want to change the status of this loan to ${newStatus}?`,
      onConfirm: async () => {
        try {
          await api.patch("/v1/admin/loans/approval-status", {
            id: loan._id,
            approval_status: newStatus
          });
          message.success(`Loan status updated to ${newStatus} successfully`);
          setReloadTrigger((prev) => prev + 1);
        } catch (error) {
          console.error("Error updating loan status:", error);
          message.error("Failed to update loan status");
        }
      }
    });
  };
  const tableData = useMemo(() => {
    const statusOptions = [
      {
        label: "Accept",
        value: "ACCEPTED",
        icon: /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
          lineNumber: 233,
          columnNumber: 13
        }, this),
        className: "bg-green-700 text-white hover:bg-green-800"
      },
      {
        label: "Pending",
        value: "PENDING",
        icon: /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
          lineNumber: 239,
          columnNumber: 13
        }, this),
        className: "border-yellow-400 text-yellow-600 hover:bg-yellow-50"
      },
      {
        label: "Reject",
        value: "REJECTED",
        icon: /* @__PURE__ */ jsxDEV(CloseCircleOutlined, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
          lineNumber: 245,
          columnNumber: 13
        }, this),
        className: "border-red-400 text-red-600 hover:bg-red-50"
      },
      {
        label: "Unknown",
        value: "UNKNOWN",
        icon: /* @__PURE__ */ jsxDEV(QuestionCircleOutlined, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
          lineNumber: 251,
          columnNumber: 13
        }, this),
        className: "border-yellow-400 text-yellow-600 hover:bg-yellow-50"
      },
      {
        label: "Requested",
        value: "REQUESTED",
        icon: /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
          lineNumber: 257,
          columnNumber: 13
        }, this),
        className: "border-blue-400 text-blue-600 hover:bg-blue-50"
      }
    ];
    const popoverContent = (borrower) => /* @__PURE__ */ jsxDEV("div", { className: "w-40 bg-white rounded-lg shadow-md p-2 space-y-2", children: statusOptions.map(
      (opt) => /* @__PURE__ */ jsxDEV(
        Button,
        {
          icon: opt.icon,
          className: `flex items-center justify-start w-full ${opt.className}`,
          onClick: () => updateLoanStatus(borrower, opt.value),
          children: opt.label
        },
        opt.value,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
          lineNumber: 264,
          columnNumber: 7
        },
        this
      )
    ) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
      lineNumber: 262,
      columnNumber: 5
    }, this);
    const formatted = rawLoans.map((item, index) => ({
      ...item,
      sl_no: index + 1,
      borrower_name: item?.borrower?.full_name,
      service_charges: Number(item.service_charges || 0),
      document_charges: Number(item.document_charges || 0),
      approval_status: item.approval_status,
      total_payable: Number(item.loan_amount || 0) - Number(item.service_charges || 0) - Number(item.document_charges || 0),
      action: /* @__PURE__ */ jsxDEV(
        Dropdown,
        {
          menu: {
            items: [
              {
                key: "1",
                label: "Payment Out",
                onClick: () => handlePaymentOutModalOpen(item._id)
              },
              {
                key: "2",
                label: /* @__PURE__ */ jsxDEV(
                  Popover,
                  {
                    placement: "rightTop",
                    trigger: "hover",
                    content: popoverContent(item),
                    children: /* @__PURE__ */ jsxDEV("div", { className: "text-blue-600 cursor-pointer", children: "Update Status" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
                      lineNumber: 303,
                      columnNumber: 21
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
                    lineNumber: 298,
                    columnNumber: 13
                  },
                  this
                )
              }
            ]
          },
          trigger: ["click"],
          children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-xl cursor-pointer hover:text-blue-600 transition-colors" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
            lineNumber: 313,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
          lineNumber: 287,
          columnNumber: 7
        },
        this
      )
    }));
    return filterOption(formatted, searchText);
  }, [rawLoans, searchText]);
  const totalPayableSum = useMemo(() => {
    return tableData.reduce(
      (sum, item) => sum + (Number(item.total_payable) || 0),
      0
    );
  }, [tableData]);
  const columns = [
    { key: "sl_no", header: "SL" },
    { key: "loan_id", header: "Loan ID" },
    { key: "borrower_name", header: "Borrower" },
    { key: "loan_amount", header: "Principal" },
    { key: "total_payable", header: "Total Payable" },
    { key: "approval_status", header: "Approval Status" },
    { key: "action", header: "Action" }
  ];
  const commonInputClass = `bg-gray-50 border border-gray-300 ${fieldSize.height} text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`;
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gray-50", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        visibility: true,
        onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
        lineNumber: 340,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((p) => ({ ...p, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
        lineNumber: 344,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
        lineNumber: 352,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("main", { className: "flex-grow p-3", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
          lineNumber: 354,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-end mb-10", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-gray-800", children: "Loan Payment Out" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
              lineNumber: 357,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Disburse approved funds to borrowers" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
              lineNumber: 360,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
            lineNumber: 356,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end items-start gap-3 mb-1", children: /* @__PURE__ */ jsxDEV("div", { className: "  shadow-sm flex items-center justify-between gap-6", children: [
            /* @__PURE__ */ jsxDEV(
              Link,
              {
                to: "/other-service-menu/loan",
                className: "inline-flex items-center px-4 py-2 border border-blue-500 text-blue-600 rounded-lg\r\n      hover:bg-blue-50 hover:text-blue-700 hover:border-blue-600\r\n      transition-all duration-200 font-medium",
                children: "Other Service / Loans"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
                lineNumber: 367,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6 text-sm bg-blue-100 border border-blue-300 rounded-xl px-5 py-3 ", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-blue-900 font-medium", children: [
                "Pending Payments:",
                " ",
                /* @__PURE__ */ jsxDEV("span", { className: "font-bold", children: tableData.length }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
                  lineNumber: 379,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
                lineNumber: 377,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "w-px h-5 bg-blue-300" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
                lineNumber: 382,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-blue-900 font-medium", children: [
                "Total Payable:",
                " ",
                /* @__PURE__ */ jsxDEV("span", { className: "font-bold", children: [
                  "₹",
                  totalPayableSum.toLocaleString("en-IN")
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
                  lineNumber: 386,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
                lineNumber: 384,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
              lineNumber: 376,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
            lineNumber: 366,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
            lineNumber: 364,
            columnNumber: 16
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
          lineNumber: 355,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm border border-gray-100 p-4", children: isLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
          lineNumber: 398,
          columnNumber: 13
        }, this) : tableData.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-20 text-gray-400", children: "No pending payments found." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
          lineNumber: 400,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: tableData,
            columns,
            exportedFileName: "Loan_Payments"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
            lineNumber: 404,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
          lineNumber: 396,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
        lineNumber: 353,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
      lineNumber: 351,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showPaymentModal, onClose: resetForm, children: /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold mb-4 border-b pb-2", children: "Confirm Disbursement" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
        lineNumber: 416,
        columnNumber: 11
      }, this),
      currentBorrower && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4 mb-6 bg-gray-50 p-4 rounded-lg border border-dashed", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] uppercase text-gray-500 font-bold", children: "Borrower" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
            lineNumber: 423,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold", children: currentBorrower?.borrower?.full_name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
            lineNumber: 426,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
          lineNumber: 422,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] uppercase text-gray-500 font-bold", children: "Loan Amount" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
            lineNumber: 431,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-green-600", children: [
            "₹",
            currentBorrower?.loan_amount
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
            lineNumber: 434,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
          lineNumber: 430,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
        lineNumber: 421,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handlePaymentOutSubmit, className: "space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600", children: "Services Charges" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
              lineNumber: 444,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "text",
                value: paymentFormData.service_charges || 0,
                disabled: true,
                className: `${commonInputClass} disabled:text-gray-900 disabled:bg-gray-100`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
                lineNumber: 447,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
            lineNumber: 443,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600", children: "Documentation Charges" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
              lineNumber: 455,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "text",
                value: paymentFormData.document_charges || 0,
                disabled: true,
                className: `${commonInputClass} disabled:text-gray-900 disabled:bg-gray-100`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
                lineNumber: 458,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
            lineNumber: 454,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
          lineNumber: 442,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600", children: "Amount" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
              lineNumber: 469,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                value: paymentFormData?.payment_amount,
                onChange: (e) => setPaymentFormData((p) => ({
                  ...p,
                  payment_amount: e.target.value
                })),
                className: commonInputClass
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
                lineNumber: 472,
                columnNumber: 17
              },
              this
            ),
            paymentErrors.payment_amount && /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 text-[10px]", children: paymentErrors.payment_amount }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
              lineNumber: 484,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
            lineNumber: 468,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600", children: "Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
              lineNumber: 490,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "date",
                value: paymentFormData.payment_date,
                onChange: (e) => setPaymentFormData((p) => ({
                  ...p,
                  payment_date: e.target.value
                })),
                className: commonInputClass
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
                lineNumber: 493,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
            lineNumber: 489,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
          lineNumber: 467,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-semibold text-gray-600", children: "Payment Mode" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
            lineNumber: 508,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full mt-1",
              placeholder: "Select Mode",
              value: paymentFormData.payment_mode,
              onChange: (v) => setPaymentFormData((p) => ({ ...p, payment_mode: v })),
              children: [
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "Cash", children: "Cash" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
                  lineNumber: 519,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "Bank Transfer", children: "Bank Transfer" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
                  lineNumber: 520,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "Cheque", children: "Cheque" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
                  lineNumber: 523,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "Online", children: "Online" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
                  lineNumber: 524,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
              lineNumber: 511,
              columnNumber: 15
            },
            this
          ),
          paymentErrors.payment_mode && /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 text-[10px]", children: paymentErrors.payment_mode }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
            lineNumber: 527,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
          lineNumber: 507,
          columnNumber: 13
        }, this),
        paymentFormData.payment_mode === "Bank Transfer" && /* @__PURE__ */ jsxDEV("div", { className: "animate-fadeIn", children: /* @__PURE__ */ jsxDEV(
          Input,
          {
            placeholder: "Transaction ID *",
            value: paymentFormData.transaction_id,
            onChange: (e) => setPaymentFormData((p) => ({
              ...p,
              transaction_id: e.target.value
            })),
            className: `${commonInputClass} mb-2`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
            lineNumber: 535,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
          lineNumber: 534,
          columnNumber: 13
        }, this),
        paymentFormData.payment_mode === "Cheque" && /* @__PURE__ */ jsxDEV(
          Input,
          {
            placeholder: "Cheque Number *",
            value: paymentFormData.cheque_number,
            onChange: (e) => setPaymentFormData((p) => ({
              ...p,
              cheque_number: e.target.value
            })),
            className: commonInputClass
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
            lineNumber: 561,
            columnNumber: 13
          },
          this
        ),
        paymentFormData.payment_mode === "Online" && /* @__PURE__ */ jsxDEV(
          Input,
          {
            placeholder: "Transaction ID *",
            value: paymentFormData.transaction_id,
            onChange: (e) => setPaymentFormData((p) => ({
              ...p,
              transaction_id: e.target.value
            })),
            className: commonInputClass
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
            lineNumber: 575,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Input.TextArea,
          {
            placeholder: "Note (Internal record)",
            rows: 2,
            value: paymentFormData.note,
            onChange: (e) => setPaymentFormData((p) => ({ ...p, note: e.target.value }))
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
            lineNumber: 588,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-3", children: [
            /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "text-green-600 w-5 h-5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
              lineNumber: 599,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-gray-800", children: "Enable WhatsApp Sending" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
              lineNumber: 600,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
            lineNumber: 598,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "checkbox",
              checked: thirdPartyEnable.whatsapp,
              onChange: () => setThirdPartyEnable((prev) => ({
                ...prev,
                whatsapp: !prev.whatsapp
              })),
              className: "w-5 h-5 accent-green-600 cursor-pointer"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
              lineNumber: 602,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
          lineNumber: 597,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-2 pt-4", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "button",
              onClick: resetForm,
              className: "px-4 py-2 text-sm text-gray-500 hover:bg-gray-100 rounded",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
              lineNumber: 616,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              className: "px-6 py-2 text-sm bg-blue-600 text-white rounded font-bold hover:bg-blue-700 shadow-lg",
              children: "Confirm Disbursement"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
              lineNumber: 623,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
          lineNumber: 615,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
        lineNumber: 441,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
      lineNumber: 415,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
      lineNumber: 414,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx",
    lineNumber: 339,
    columnNumber: 5
  }, this);
};
_s(LoanPaymentOut, "wJtsQJaSlSJnYxlOVTGNbcvucKY=");
_c = LoanPaymentOut;
export default LoanPaymentOut;
var _c;
$RefreshReg$(_c, "LoanPaymentOut");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanPaymentOut.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd09jOzJCQXhPZDtBQUFvQkEsb0JBQW1CQyw2QkFBMEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDakUsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyx1QkFBdUI7QUFDOUIsU0FBU0MsT0FBT0MsUUFBUUMsVUFBVUMsU0FBU0MsUUFBUUMsZUFBZTtBQUNsRSxTQUFTQyxnQkFBZ0I7QUFDekIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxtQkFBbUI7QUFDNUI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsT0FBT0MsZ0JBQWdCO0FBRXZCLE1BQU1DLHdCQUF3QjtBQUFBLEVBQzVCQyxnQkFBZ0I7QUFBQSxFQUNoQkMsZUFBYyxvQkFBSUMsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxFQUNuREMsY0FBYztBQUFBLEVBQ2RDLGdCQUFnQjtBQUFBLEVBQ2hCQyxpQkFBaUI7QUFBQSxFQUNqQkMsa0JBQWtCO0FBQUEsRUFDbEJDLHNCQUFzQjtBQUFBLEVBQ3RCQyxZQUFZO0FBQUEsRUFDWkMsVUFBVTtBQUFBLEVBQ1ZDLFNBQVM7QUFBQSxFQUNUQyxlQUFlO0FBQUEsRUFDZkMsTUFBTTtBQUNSO0FBRUEsTUFBTUMsaUJBQWlCQSxNQUFNO0FBQUFDLEtBQUE7QUFDM0IsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUk5QyxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDK0MsWUFBWUMsYUFBYSxJQUFJaEQsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ2lELFdBQVdDLFlBQVksSUFBSWxELFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNtRCxrQkFBa0JDLG1CQUFtQixJQUFJcEQsU0FBUyxLQUFLO0FBQzlELFFBQU0sQ0FBQ3FELGlCQUFpQkMsa0JBQWtCLElBQUl0RCxTQUFTLElBQUk7QUFDM0QsUUFBTSxDQUFDdUQsZUFBZUMsZ0JBQWdCLElBQUl4RCxTQUFTLENBQUM7QUFDcEQsUUFBTSxDQUFDeUQsaUJBQWlCQyxrQkFBa0IsSUFBSTFELFNBQVMyQixxQkFBcUI7QUFDNUUsUUFBTSxDQUFDZ0MsZUFBZUMsZ0JBQWdCLElBQUk1RCxTQUFTLENBQUMsQ0FBQztBQUNyRCxRQUFNLENBQUM2RCxhQUFhQyxjQUFjLElBQUk5RCxTQUFTO0FBQUEsSUFDN0MrRCxZQUFZO0FBQUEsSUFDWm5ELFNBQVM7QUFBQSxJQUNUb0QsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNELFFBQU0sQ0FBQ0Msa0JBQWtCQyxtQkFBbUIsSUFBSWxFLFNBQVM7QUFBQSxJQUN2RG1FLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDRCxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJckUsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQ3NFLHlCQUF5QkMsMEJBQTBCLElBQUl2RSxTQUFTLEtBQUs7QUFDNUUsUUFBTSxDQUFDd0UsU0FBU0MsVUFBVSxJQUFJekUsU0FBUyxFQUFFO0FBQ3pDLFFBQU0wRSxxQkFBcUJ6RSxZQUFZLFlBQVk7QUFDakQsUUFBSTtBQUNGaUQsbUJBQWEsSUFBSTtBQUNqQixZQUFNLEVBQUV5QixLQUFLLElBQUksTUFBTXZFLElBQUl3RTtBQUFBQSxRQUN6QjtBQUFBLE1BQ0Y7QUFFQTlCLGtCQUFZNkIsTUFBTUEsUUFBUSxFQUFFO0FBQUEsSUFDOUIsU0FBU0UsT0FBTztBQUNkQyxnQkFBVSxrQ0FBa0MsT0FBTztBQUFBLElBQ3JELFVBQUM7QUFDQzVCLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUw2QixZQUFVLE1BQU07QUFDZEwsdUJBQW1CO0FBQUEsRUFDckIsR0FBRyxDQUFDQSxvQkFBb0JuQixhQUFhLENBQUM7QUFFdEN3QixZQUFVLE1BQU07QUFDZCxVQUFNQyxPQUFPQyxhQUFhQyxRQUFRLE1BQU07QUFDeEMsVUFBTUMsVUFBVUMsS0FBS0MsTUFBTUwsSUFBSTtBQUMvQixVQUFNTSxjQUFjSCxTQUFTSTtBQUM3QmQsZUFBV2EsV0FBVztBQUV0QixRQUFJSCxTQUFTO0FBQ1gsWUFBTUsseUJBQ0pMLFFBQVFNLHVCQUF1QkM7QUFFakMsVUFBSUYsd0JBQXdCRyxpQkFBaUIsUUFBUTtBQUNuRHRCLHlCQUFpQixJQUFJO0FBQUEsTUFDdkI7QUFFQSxVQUFJbUIsd0JBQXdCSSx5QkFBeUIsUUFBUTtBQUMzRHZCLHlCQUFpQixJQUFJO0FBQ3JCRSxtQ0FBMkIsSUFBSTtBQUFBLE1BQ2pDO0FBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTU8sWUFBWUEsQ0FBQ2xFLFVBQVNvRCxPQUFPLFdBQVc7QUFDNUNGLG1CQUFlLEVBQUVDLFlBQVksTUFBTW5ELG1CQUFTb0QsS0FBSyxDQUFDO0FBQUEsRUFDcEQ7QUFFQSxRQUFNNkIsWUFBWUEsTUFBTTtBQUN0Qm5DLHVCQUFtQi9CLHFCQUFxQjtBQUN4Q2lDLHFCQUFpQixDQUFDLENBQUM7QUFDbkJSLHdCQUFvQixLQUFLO0FBQ3pCRSx1QkFBbUIsSUFBSTtBQUFBLEVBQ3pCO0FBRUEsUUFBTXdDLGtCQUFrQkEsQ0FBQ0MsT0FBTztBQUM5QixVQUFNQyxRQUFRO0FBQ2QsUUFBSUQsR0FBR3JELE1BQU11RCxLQUFLLEVBQUdELE9BQU1FLEtBQUtILEdBQUdyRCxLQUFLdUQsS0FBSyxDQUFDO0FBQzlDLFFBQUlGLEdBQUc5RCxpQkFBaUIsaUJBQWlCO0FBQ3ZDLFVBQUk4RCxHQUFHN0QsZUFBZ0I4RCxPQUFNRSxLQUFLLFFBQVFILEdBQUc3RCxjQUFjLEVBQUU7QUFDN0QsVUFBSTZELEdBQUdJLFVBQVdILE9BQU1FLEtBQUssU0FBU0gsR0FBR0ksU0FBUyxFQUFFO0FBQUEsSUFDdEQ7QUFDQSxRQUFJSixHQUFHOUQsaUJBQWlCLFlBQVk4RCxHQUFHdEQsZUFBZTtBQUNwRHVELFlBQU1FLEtBQUssUUFBUUgsR0FBR3RELGFBQWEsRUFBRTtBQUFBLElBQ3ZDLFdBQVdzRCxHQUFHOUQsaUJBQWlCLFlBQVk4RCxHQUFHN0QsZ0JBQWdCO0FBQzVEOEQsWUFBTUUsS0FBSyxRQUFRSCxHQUFHN0QsY0FBYyxFQUFFO0FBQUEsSUFDeEM7QUFDQSxXQUFPOEQsTUFBTUksS0FBSyxLQUFLO0FBQUEsRUFDekI7QUFFQSxRQUFNQyw0QkFBNEIsT0FBT0MsV0FBVztBQUNsRCxRQUFJO0FBQ0YsWUFBTUMsV0FBVyxNQUFNbkcsSUFBSXdFLElBQUksa0JBQWtCMEIsTUFBTSxFQUFFO0FBQ3pELFlBQU0zQixPQUFPNEIsU0FBUzVCLE1BQU1BO0FBQzVCckIseUJBQW1CcUIsUUFBUSxDQUFDLENBQUM7QUFDN0JqQix5QkFBbUIsQ0FBQzhDLFVBQVU7QUFBQSxRQUM1QixHQUFHQTtBQUFBQSxRQUNINUUsZ0JBQ0U2RSxPQUFPOUIsTUFBTStCLGVBQWUsQ0FBQyxJQUM3QkQsT0FBTzlCLEtBQUt4QyxtQkFBbUIsQ0FBQyxJQUNoQ3NFLE9BQU85QixLQUFLdkMsb0JBQW9CLENBQUMsS0FBSztBQUFBLFFBQ3hDRCxpQkFBaUJ3QyxLQUFLeEMsbUJBQW1CO0FBQUEsUUFDekNDLGtCQUFrQnVDLEtBQUt2QyxvQkFBb0I7QUFBQSxRQUMzQ0Msc0JBQXNCc0MsS0FBS3RDLHdCQUF3QjtBQUFBLFFBQ25EQyxZQUFZcUMsS0FBS3JDO0FBQUFBLFFBQ2pCQyxVQUFVb0MsS0FBS3BDO0FBQUFBLFFBQ2ZDLFNBQVNtQyxLQUFLbkM7QUFBQUEsUUFFZFgsZUFBYyxvQkFBSUMsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxNQUNyRCxFQUFFO0FBQ0ZvQiwwQkFBb0IsSUFBSTtBQUFBLElBQzFCLFNBQVN5QixPQUFPO0FBQ2RDLGdCQUFVLG9DQUFvQyxPQUFPO0FBQUEsSUFDdkQ7QUFBQSxFQUNGO0FBRUEsUUFBTTZCLFdBQVdBLE1BQU07QUFDckIsVUFBTUMsU0FBUyxDQUFDO0FBQ2hCLFFBQUksQ0FBQ25ELGdCQUFnQjdCLGtCQUFrQjZCLGdCQUFnQjdCLGtCQUFrQjtBQUN2RWdGLGFBQU9oRixpQkFBaUI7QUFDMUIsUUFBSSxDQUFDNkIsZ0JBQWdCNUIsYUFBYytFLFFBQU8vRSxlQUFlO0FBQ3pELFFBQUksQ0FBQzRCLGdCQUFnQnhCLGFBQWMyRSxRQUFPM0UsZUFBZTtBQUV6RCxRQUNFd0IsZ0JBQWdCeEIsaUJBQWlCLG1CQUNqQyxDQUFDd0IsZ0JBQWdCdkI7QUFFakIwRSxhQUFPMUUsaUJBQWlCO0FBQzFCLFFBQ0V1QixnQkFBZ0J4QixpQkFBaUIsWUFDakMsQ0FBQ3dCLGdCQUFnQmhCO0FBRWpCbUUsYUFBT25FLGdCQUFnQjtBQUV6QixRQUFJa0IsY0FBY2tELGFBQWEsWUFBWSxDQUFDcEQsZ0JBQWdCdkI7QUFDMUQwRSxhQUFPMUUsaUJBQWlCO0FBRTFCMEIscUJBQWlCZ0QsTUFBTTtBQUN2QixXQUFPRSxPQUFPQyxLQUFLSCxNQUFNLEVBQUVJLFdBQVc7QUFBQSxFQUN4QztBQUVBLFFBQU1DLHlCQUF5QixPQUFPQyxNQUFNO0FBQzFDQSxNQUFFQyxlQUFlO0FBQ2pCLFFBQUksQ0FBQ1IsU0FBUyxFQUFHO0FBRWpCLFFBQUk7QUFDRixZQUFNUyxVQUFVO0FBQUEsUUFDZEMsTUFBTWhFLGlCQUFpQmtDLE9BQU9sQyxpQkFBaUJrQztBQUFBQSxRQUMvQytCLFNBQVNqRSxpQkFBaUJrRSxVQUFVaEMsT0FBT2xDLGlCQUFpQmlFO0FBQUFBLFFBQzVEVCxVQUFVcEQsZ0JBQWdCNUI7QUFBQUEsUUFDMUIyRixRQUFRL0QsZ0JBQWdCN0IsZUFBZTZGLFNBQVM7QUFBQSxRQUNoREMsVUFBVWpFLGdCQUFnQnhCO0FBQUFBLFFBQzFCMEYsU0FBUztBQUFBLFFBQ1RqRixNQUFNZSxnQkFBZ0JmO0FBQUFBLFFBQ3RCUixnQkFBZ0J1QixnQkFBZ0J2QjtBQUFBQSxRQUNoQzBGLFlBQVlwRDtBQUFBQSxRQUNaLEdBQUdQO0FBQUFBLE1BQ0w7QUFFQSxZQUFNN0QsSUFBSXlILE1BQU0sNkJBQTZCVCxPQUFPO0FBQ3BEdEMsZ0JBQVUsa0NBQWtDLFNBQVM7QUFDckR0Qix1QkFBaUIsQ0FBQ3NFLE1BQU1BLElBQUksQ0FBQztBQUM3QmpDLGdCQUFVO0FBQUEsSUFDWixTQUFTaEIsT0FBTztBQUNkQztBQUFBQSxRQUNFRCxNQUFNMEIsVUFBVTVCLE1BQU0vRCxXQUN0QmlFLE1BQU0wQixVQUFVNUIsTUFBTW9ELGNBQ3RCO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFFBQU1DLG1CQUFtQixPQUFPWCxNQUFNWSxjQUFjO0FBQ2xEN0csZ0JBQVk7QUFBQSxNQUNWOEcsT0FBTyxHQUFHRCxTQUFTO0FBQUEsTUFDbkJFLFNBQVMsOERBQThERixTQUFTO0FBQUEsTUFDaEZHLFdBQVcsWUFBWTtBQUNyQixZQUFJO0FBQ0YsZ0JBQU1oSSxJQUFJeUgsTUFBTSxtQ0FBbUM7QUFBQSxZQUNqRFEsSUFBSWhCLEtBQUs5QjtBQUFBQSxZQUNUK0MsaUJBQWlCTDtBQUFBQSxVQUNuQixDQUFDO0FBQ0RySCxrQkFBUTJILFFBQVEsMEJBQTBCTixTQUFTLGVBQWU7QUFDbEV6RSwyQkFBaUIsQ0FBQ2dELFNBQVNBLE9BQU8sQ0FBQztBQUFBLFFBQ3JDLFNBQVMzQixPQUFPO0FBQ2QyRCxrQkFBUTNELE1BQU0sK0JBQStCQSxLQUFLO0FBQ2xEakUsa0JBQVFpRSxNQUFNLDhCQUE4QjtBQUFBLFFBQzlDO0FBQUEsTUFDRjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNNEQsWUFBWUMsUUFBUSxNQUFNO0FBQzlCLFVBQU1DLGdCQUFnQjtBQUFBLE1BQ3BCO0FBQUEsUUFDRUMsT0FBTztBQUFBLFFBQ1BDLE9BQU87QUFBQSxRQUNQQyxNQUFNLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0I7QUFBQSxRQUMxQkMsV0FBVztBQUFBLE1BQ2I7QUFBQSxNQUNBO0FBQUEsUUFDRUgsT0FBTztBQUFBLFFBQ1BDLE9BQU87QUFBQSxRQUNQQyxNQUFNLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0I7QUFBQSxRQUMxQkMsV0FBVztBQUFBLE1BQ2I7QUFBQSxNQUNBO0FBQUEsUUFDRUgsT0FBTztBQUFBLFFBQ1BDLE9BQU87QUFBQSxRQUNQQyxNQUFNLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0I7QUFBQSxRQUMxQkMsV0FBVztBQUFBLE1BQ2I7QUFBQSxNQUNBO0FBQUEsUUFDRUgsT0FBTztBQUFBLFFBQ1BDLE9BQU87QUFBQSxRQUNQQyxNQUFNLHVCQUFDLDRCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUI7QUFBQSxRQUM3QkMsV0FBVztBQUFBLE1BQ2I7QUFBQSxNQUNBO0FBQUEsUUFDRUgsT0FBTztBQUFBLFFBQ1BDLE9BQU87QUFBQSxRQUNQQyxNQUFNLHVCQUFDLCtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEI7QUFBQSxRQUNoQ0MsV0FBVztBQUFBLE1BQ2I7QUFBQSxJQUFDO0FBRUgsVUFBTUMsaUJBQWlCQSxDQUFDekIsYUFDdEIsdUJBQUMsU0FBSSxXQUFVLG9EQUNab0Isd0JBQWNNO0FBQUFBLE1BQUksQ0FBQ0MsUUFDbEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDLE1BQU1BLElBQUlKO0FBQUFBLFVBQ1YsV0FBVywwQ0FBMENJLElBQUlILFNBQVM7QUFBQSxVQUNsRSxTQUFTLE1BQU1mLGlCQUFpQlQsVUFBVTJCLElBQUlMLEtBQUs7QUFBQSxVQUVsREssY0FBSU47QUFBQUE7QUFBQUEsUUFMQU0sSUFBSUw7QUFBQUEsUUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQSxJQUNELEtBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBRUYsVUFBTU0sWUFBWXRHLFNBQVNvRyxJQUFJLENBQUNHLE1BQU1DLFdBQVc7QUFBQSxNQUMvQyxHQUFHRDtBQUFBQSxNQUNIRSxPQUFPRCxRQUFRO0FBQUEsTUFDZkUsZUFBZUgsTUFBTTdCLFVBQVVpQztBQUFBQSxNQUMvQnJILGlCQUFpQnNFLE9BQU8yQyxLQUFLakgsbUJBQW1CLENBQUM7QUFBQSxNQUNqREMsa0JBQWtCcUUsT0FBTzJDLEtBQUtoSCxvQkFBb0IsQ0FBQztBQUFBLE1BQ25Ea0csaUJBQWlCYyxLQUFLZDtBQUFBQSxNQUN0Qm1CLGVBQ0VoRCxPQUFPMkMsS0FBSzFDLGVBQWUsQ0FBQyxJQUM1QkQsT0FBTzJDLEtBQUtqSCxtQkFBbUIsQ0FBQyxJQUNoQ3NFLE9BQU8yQyxLQUFLaEgsb0JBQW9CLENBQUM7QUFBQSxNQUNuQ3NILFFBQ0U7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU07QUFBQSxZQUNKQyxPQUFPO0FBQUEsY0FDTDtBQUFBLGdCQUNFQyxLQUFLO0FBQUEsZ0JBQ0xoQixPQUFPO0FBQUEsZ0JBQ1BpQixTQUFTQSxNQUFNeEQsMEJBQTBCK0MsS0FBSzdELEdBQUc7QUFBQSxjQUNuRDtBQUFBLGNBQ0E7QUFBQSxnQkFDRXFFLEtBQUs7QUFBQSxnQkFDTGhCLE9BQ0U7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFDUixTQUFTSSxlQUFlSSxJQUFJO0FBQUEsb0JBRTVCLGlDQUFDLFNBQUksV0FBVSxnQ0FBK0IsNkJBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQTtBQUFBLGtCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRQTtBQUFBLGNBRUo7QUFBQSxZQUFDO0FBQUEsVUFFTDtBQUFBLFVBQ0EsU0FBUyxDQUFDLE9BQU87QUFBQSxVQUVqQixpQ0FBQyxZQUFTLFdBQVUsa0VBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtGO0FBQUE7QUFBQSxRQTFCcEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BMkJBO0FBQUEsSUFFSixFQUFFO0FBQ0YsV0FBT3JJLGFBQWFvSSxXQUFXcEcsVUFBVTtBQUFBLEVBQzNDLEdBQUcsQ0FBQ0YsVUFBVUUsVUFBVSxDQUFDO0FBQ3pCLFFBQU0rRyxrQkFBa0JwQixRQUFRLE1BQU07QUFDcEMsV0FBT0QsVUFBVXNCO0FBQUFBLE1BQ2YsQ0FBQ0MsS0FBS1osU0FBU1ksT0FBT3ZELE9BQU8yQyxLQUFLSyxhQUFhLEtBQUs7QUFBQSxNQUNwRDtBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQUcsQ0FBQ2hCLFNBQVMsQ0FBQztBQUVkLFFBQU13QixVQUFVO0FBQUEsSUFDZCxFQUFFTCxLQUFLLFNBQVNNLFFBQVEsS0FBSztBQUFBLElBQzdCLEVBQUVOLEtBQUssV0FBV00sUUFBUSxVQUFVO0FBQUEsSUFDcEMsRUFBRU4sS0FBSyxpQkFBaUJNLFFBQVEsV0FBVztBQUFBLElBQzNDLEVBQUVOLEtBQUssZUFBZU0sUUFBUSxZQUFZO0FBQUEsSUFDMUMsRUFBRU4sS0FBSyxpQkFBaUJNLFFBQVEsZ0JBQWdCO0FBQUEsSUFDaEQsRUFBRU4sS0FBSyxtQkFBbUJNLFFBQVEsa0JBQWtCO0FBQUEsSUFDcEQsRUFBRU4sS0FBSyxVQUFVTSxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFFBQU1DLG1CQUFtQixxQ0FBcUNsSixVQUFVbUosTUFBTTtBQUU5RSxTQUNFLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxZQUFZO0FBQUEsUUFDWiw2QkFBNkIsQ0FBQ2xELE1BQU1sRSxjQUFja0UsRUFBRW1ELE9BQU94QixLQUFLO0FBQUE7QUFBQSxNQUZsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFb0U7QUFBQSxJQUVwRTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTWhGLFlBQVlHO0FBQUFBLFFBQ2xCLFdBQVdILFlBQVlFO0FBQUFBLFFBQ3ZCLFNBQVNGLFlBQVlqRDtBQUFBQSxRQUNyQixTQUFTLE1BQU1rRCxlQUFlLENBQUNnRSxPQUFPLEVBQUUsR0FBR0EsR0FBRy9ELFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxNQUpwRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJc0U7QUFBQSxJQUd0RSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDZCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUix1QkFBQyxVQUFLLFdBQVUsaUJBQ2Q7QUFBQSwrQkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVc7QUFBQSxRQUNYLHVCQUFDLFNBQUksV0FBVSx3Q0FDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsb0NBQW1DLGdDQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUseUJBQXdCLG9EQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFDRyx1QkFBQyxTQUFJLFdBQVUsMkNBRWxCLGlDQUFDLFNBQUksV0FBVSx1REFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsSUFBRztBQUFBLGdCQUNILFdBQVU7QUFBQSxnQkFFb0I7QUFBQTtBQUFBLGNBSmhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsNEZBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsNkJBQTRCO0FBQUE7QUFBQSxnQkFDeEI7QUFBQSxnQkFDbEIsdUJBQUMsVUFBSyxXQUFVLGFBQWEwRSxvQkFBVXpCLFVBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThDO0FBQUEsbUJBRmhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUVBLHVCQUFDLFVBQUssV0FBVSwwQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUM7QUFBQSxjQUV2Qyx1QkFBQyxVQUFLLFdBQVUsNkJBQTRCO0FBQUE7QUFBQSxnQkFDM0I7QUFBQSxnQkFDZix1QkFBQyxVQUFLLFdBQVUsYUFBWTtBQUFBO0FBQUEsa0JBQ3hCOEMsZ0JBQWdCUSxlQUFlLE9BQU87QUFBQSxxQkFEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxpQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWNBO0FBQUEsZUF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5QkEsS0EzQkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0Qkw7QUFBQSxhQXJDQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0NBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsNERBQ1pySCxzQkFDQyx1QkFBQyxrQkFBZSxXQUFXLFFBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0MsSUFDOUJ3RixVQUFVekIsV0FBVyxJQUN2Qix1QkFBQyxTQUFJLFdBQVUsbUNBQWtDLDBDQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBTXlCO0FBQUFBLFlBQ047QUFBQSxZQUNBLGtCQUFpQjtBQUFBO0FBQUEsVUFIbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR2tDLEtBWHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFdBekRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwREE7QUFBQSxTQTVERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNkRBO0FBQUEsSUFFQSx1QkFBQyxTQUFNLFdBQVd0RixrQkFBa0IsU0FBUzBDLFdBQzNDLGlDQUFDLFNBQUksV0FBVSxPQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHdDQUF1QyxvQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQ3hDLG1CQUNDLHVCQUFDLFNBQUksV0FBVSw4RUFDYjtBQUFBLCtCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsaURBQWdELHdCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUseUJBQ1ZBLDJCQUFpQmtFLFVBQVVpQyxhQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsaURBQWdELDJCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsb0NBQW1DO0FBQUE7QUFBQSxZQUM1Q25HLGlCQUFpQnFEO0FBQUFBLGVBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQkE7QUFBQSxNQUdGLHVCQUFDLFVBQUssVUFBVU8sd0JBQXdCLFdBQVUsYUFDaEQ7QUFBQSwrQkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLHVDQUFzQyxnQ0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT3hELGdCQUFnQnRCLG1CQUFtQjtBQUFBLGdCQUMxQztBQUFBLGdCQUNBLFdBQVcsR0FBR2dJLGdCQUFnQjtBQUFBO0FBQUEsY0FKaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSStFO0FBQUEsZUFSakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsdUNBQXNDLHFDQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPMUcsZ0JBQWdCckIsb0JBQW9CO0FBQUEsZ0JBQzNDO0FBQUEsZ0JBQ0EsV0FBVyxHQUFHK0gsZ0JBQWdCO0FBQUE7QUFBQSxjQUpoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJK0U7QUFBQSxlQVJqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsYUF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSx1Q0FBc0Msc0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU8xRyxpQkFBaUI3QjtBQUFBQSxnQkFDeEIsVUFBVSxDQUFDc0YsTUFDVHhELG1CQUFtQixDQUFDb0UsT0FBTztBQUFBLGtCQUN6QixHQUFHQTtBQUFBQSxrQkFDSGxHLGdCQUFnQnNGLEVBQUVtRCxPQUFPeEI7QUFBQUEsZ0JBQzNCLEVBQUU7QUFBQSxnQkFFSixXQUFXc0I7QUFBQUE7QUFBQUEsY0FUYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFTOEI7QUFBQSxZQUU3QnhHLGNBQWMvQixrQkFDYix1QkFBQyxVQUFLLFdBQVUsNEJBQ2IrQix3QkFBYy9CLGtCQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFsQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLHVDQUFzQyxvQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBTzZCLGdCQUFnQjVCO0FBQUFBLGdCQUN2QixVQUFVLENBQUNxRixNQUNUeEQsbUJBQW1CLENBQUNvRSxPQUFPO0FBQUEsa0JBQ3pCLEdBQUdBO0FBQUFBLGtCQUNIakcsY0FBY3FGLEVBQUVtRCxPQUFPeEI7QUFBQUEsZ0JBQ3pCLEVBQUU7QUFBQSxnQkFFSixXQUFXc0I7QUFBQUE7QUFBQUEsY0FUYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFTOEI7QUFBQSxlQWJoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsYUFyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNDQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSx1Q0FBc0MsNEJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixhQUFZO0FBQUEsY0FDWixPQUFPMUcsZ0JBQWdCeEI7QUFBQUEsY0FDdkIsVUFBVSxDQUFDc0ksTUFDVDdHLG1CQUFtQixDQUFDb0UsT0FBTyxFQUFFLEdBQUdBLEdBQUc3RixjQUFjc0ksRUFBRSxFQUFFO0FBQUEsY0FHdkQ7QUFBQSx1Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFFBQU8sb0JBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsZ0JBQ2hDLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0saUJBQWdCLDZCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxVQUFTLHNCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvQztBQUFBLGdCQUNwQyx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFVBQVMsc0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9DO0FBQUE7QUFBQTtBQUFBLFlBYnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWNBO0FBQUEsVUFDQzVHLGNBQWMxQixnQkFDYix1QkFBQyxVQUFLLFdBQVUsNEJBQ2IwQix3QkFBYzFCLGdCQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUF0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBRUN3QixnQkFBZ0J4QixpQkFBaUIsbUJBQ2hDLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsYUFBWTtBQUFBLFlBQ1osT0FBT3dCLGdCQUFnQnZCO0FBQUFBLFlBQ3ZCLFVBQVUsQ0FBQ2dGLE1BQ1R4RCxtQkFBbUIsQ0FBQ29FLE9BQU87QUFBQSxjQUN6QixHQUFHQTtBQUFBQSxjQUNINUYsZ0JBQWdCZ0YsRUFBRW1ELE9BQU94QjtBQUFBQSxZQUMzQixFQUFFO0FBQUEsWUFFSixXQUFXLEdBQUdzQixnQkFBZ0I7QUFBQTtBQUFBLFVBVGhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVN3QyxLQVYxQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUJBO0FBQUEsUUFHRDFHLGdCQUFnQnhCLGlCQUFpQixZQUNoQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsYUFBWTtBQUFBLFlBQ1osT0FBT3dCLGdCQUFnQmhCO0FBQUFBLFlBQ3ZCLFVBQVUsQ0FBQ3lFLE1BQ1R4RCxtQkFBbUIsQ0FBQ29FLE9BQU87QUFBQSxjQUN6QixHQUFHQTtBQUFBQSxjQUNIckYsZUFBZXlFLEVBQUVtRCxPQUFPeEI7QUFBQUEsWUFDMUIsRUFBRTtBQUFBLFlBRUosV0FBV3NCO0FBQUFBO0FBQUFBLFVBVGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUzhCO0FBQUEsUUFJL0IxRyxnQkFBZ0J4QixpQkFBaUIsWUFDaEM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLGFBQVk7QUFBQSxZQUNaLE9BQU93QixnQkFBZ0J2QjtBQUFBQSxZQUN2QixVQUFVLENBQUNnRixNQUNUeEQsbUJBQW1CLENBQUNvRSxPQUFPO0FBQUEsY0FDekIsR0FBR0E7QUFBQUEsY0FDSDVGLGdCQUFnQmdGLEVBQUVtRCxPQUFPeEI7QUFBQUEsWUFDM0IsRUFBRTtBQUFBLFlBRUosV0FBV3NCO0FBQUFBO0FBQUFBLFVBVGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUzhCO0FBQUEsUUFJaEM7QUFBQSxVQUFDLE1BQU07QUFBQSxVQUFOO0FBQUEsWUFDQyxhQUFZO0FBQUEsWUFDWixNQUFNO0FBQUEsWUFDTixPQUFPMUcsZ0JBQWdCZjtBQUFBQSxZQUN2QixVQUFVLENBQUN3RSxNQUNUeEQsbUJBQW1CLENBQUNvRSxPQUFPLEVBQUUsR0FBR0EsR0FBR3BGLE1BQU13RSxFQUFFbUQsT0FBT3hCLE1BQU0sRUFBRTtBQUFBO0FBQUEsVUFMOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUc7QUFBQSxRQUdILHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLG1DQUFDLGNBQVcsV0FBVSw0QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEM7QUFBQSxZQUM5Qyx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLHVDQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RDtBQUFBLGVBRnpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTNUUsaUJBQWlCRTtBQUFBQSxjQUMxQixVQUFVLE1BQ1JELG9CQUFvQixDQUFDc0MsVUFBVTtBQUFBLGdCQUM3QixHQUFHQTtBQUFBQSxnQkFDSHJDLFVBQVUsQ0FBQ3FDLEtBQUtyQztBQUFBQSxjQUNsQixFQUFFO0FBQUEsY0FFSixXQUFVO0FBQUE7QUFBQSxZQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNxRDtBQUFBLGFBZHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxTQUFTMEI7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FBMkQ7QUFBQTtBQUFBLFlBSHZFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQXdGO0FBQUE7QUFBQSxZQUZwRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsV0E1TEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZMQTtBQUFBLFNBdk5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3TkEsS0F6TkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBOQTtBQUFBLE9BclNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzU0E7QUFFSjtBQUFFakQsR0FubEJJRCxnQkFBYztBQUFBNkgsS0FBZDdIO0FBcWxCTixlQUFlQTtBQUFlLElBQUE2SDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VDYWxsYmFjayIsIlNpZGViYXIiLCJNb2RhbCIsImFwaSIsIkRhdGFUYWJsZSIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwiSW5wdXQiLCJTZWxlY3QiLCJEcm9wZG93biIsIlBvcG92ZXIiLCJCdXR0b24iLCJtZXNzYWdlIiwiSW9NZE1vcmUiLCJOYXZiYXIiLCJmaWx0ZXJPcHRpb24iLCJDaXJjdWxhckxvYWRlciIsImZpZWxkU2l6ZSIsIkZhV2hhdHNhcHAiLCJMaW5rIiwic2hvd0NvbmZpcm0iLCJDaGVja0NpcmNsZU91dGxpbmVkIiwiQ2xvY2tDaXJjbGVPdXRsaW5lZCIsIkNsb3NlQ2lyY2xlT3V0bGluZWQiLCJFeGNsYW1hdGlvbkNpcmNsZU91dGxpbmVkIiwiUXVlc3Rpb25DaXJjbGVPdXRsaW5lZCIsIkJyZWFkY3J1bWIiLCJJTklUSUFMX1BBWU1FTlRfU1RBVEUiLCJwYXltZW50X2Ftb3VudCIsInBheW1lbnRfZGF0ZSIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNwbGl0IiwicGF5bWVudF9tb2RlIiwidHJhbnNhY3Rpb25faWQiLCJzZXJ2aWNlX2NoYXJnZXMiLCJkb2N1bWVudF9jaGFyZ2VzIiwiZGFpbHlfcGF5bWVudF9hbW91bnQiLCJzdGFydF9kYXRlIiwiZW5kX2RhdGUiLCJsb2FuX2lkIiwiY2hlcXVlX251bWJlciIsIm5vdGUiLCJMb2FuUGF5bWVudE91dCIsIl9zIiwicmF3TG9hbnMiLCJzZXRSYXdMb2FucyIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwic2hvd1BheW1lbnRNb2RhbCIsInNldFNob3dQYXltZW50TW9kYWwiLCJjdXJyZW50Qm9ycm93ZXIiLCJzZXRDdXJyZW50Qm9ycm93ZXIiLCJyZWxvYWRUcmlnZ2VyIiwic2V0UmVsb2FkVHJpZ2dlciIsInBheW1lbnRGb3JtRGF0YSIsInNldFBheW1lbnRGb3JtRGF0YSIsInBheW1lbnRFcnJvcnMiLCJzZXRQYXltZW50RXJyb3JzIiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJ0eXBlIiwidGhpcmRQYXJ0eUVuYWJsZSIsInNldFRoaXJkUGFydHlFbmFibGUiLCJ3aGF0c2FwcCIsIm1vZGlmeVBheW1lbnQiLCJzZXRNb2RpZnlQYXltZW50IiwibW9kaWZ5TWluTWF4UGF5bWVudERhdGUiLCJzZXRNb2RpZnlNaW5NYXhQYXltZW50RGF0ZSIsImFkbWluSWQiLCJzZXRBZG1pbklkIiwiZmV0Y2hBcHByb3ZlZExvYW5zIiwiZGF0YSIsImdldCIsImVycm9yIiwic2hvd0FsZXJ0IiwidXNlRWZmZWN0IiwidXNlciIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJ1c2VyT2JqIiwiSlNPTiIsInBhcnNlIiwidXNlckFkbWluSWQiLCJfaWQiLCJhZG1pbkFjY2Vzc1Blcm1pc3Npb25zIiwiYWRtaW5fYWNjZXNzX3JpZ2h0X2lkIiwiYWNjZXNzX3Blcm1pc3Npb25zIiwiZWRpdF9wYXltZW50IiwiZWRpdF9saW1pdGVkX3BheW1lbnQiLCJyZXNldEZvcm0iLCJidWlsZE5vdGVTdHJpbmciLCJmZCIsInBhcnRzIiwidHJpbSIsInB1c2giLCJiYW5rX25hbWUiLCJqb2luIiwiaGFuZGxlUGF5bWVudE91dE1vZGFsT3BlbiIsImxvYW5JZCIsInJlc3BvbnNlIiwicHJldiIsIk51bWJlciIsImxvYW5fYW1vdW50IiwidmFsaWRhdGUiLCJlcnJvcnMiLCJwYXlfZGF0ZSIsIk9iamVjdCIsImtleXMiLCJsZW5ndGgiLCJoYW5kbGVQYXltZW50T3V0U3VibWl0IiwiZSIsInByZXZlbnREZWZhdWx0IiwicGF5bG9hZCIsImxvYW4iLCJ1c2VyX2lkIiwiYm9ycm93ZXIiLCJhbW91bnQiLCJ0b1N0cmluZyIsInBheV90eXBlIiwicGF5X2ZvciIsImFkbWluX3R5cGUiLCJwYXRjaCIsInAiLCJzdGF0dXNDb2RlIiwidXBkYXRlTG9hblN0YXR1cyIsIm5ld1N0YXR1cyIsInRpdGxlIiwiY29udGVudCIsIm9uQ29uZmlybSIsImlkIiwiYXBwcm92YWxfc3RhdHVzIiwic3VjY2VzcyIsImNvbnNvbGUiLCJ0YWJsZURhdGEiLCJ1c2VNZW1vIiwic3RhdHVzT3B0aW9ucyIsImxhYmVsIiwidmFsdWUiLCJpY29uIiwiY2xhc3NOYW1lIiwicG9wb3ZlckNvbnRlbnQiLCJtYXAiLCJvcHQiLCJmb3JtYXR0ZWQiLCJpdGVtIiwiaW5kZXgiLCJzbF9ubyIsImJvcnJvd2VyX25hbWUiLCJmdWxsX25hbWUiLCJ0b3RhbF9wYXlhYmxlIiwiYWN0aW9uIiwiaXRlbXMiLCJrZXkiLCJvbkNsaWNrIiwidG90YWxQYXlhYmxlU3VtIiwicmVkdWNlIiwic3VtIiwiY29sdW1ucyIsImhlYWRlciIsImNvbW1vbklucHV0Q2xhc3MiLCJoZWlnaHQiLCJ0YXJnZXQiLCJ0b0xvY2FsZVN0cmluZyIsInYiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJMb2FuUGF5bWVudE91dC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlTWVtbywgdXNlQ2FsbGJhY2sgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydERpYWxvZyBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2dcIjtcclxuaW1wb3J0IHsgSW5wdXQsIFNlbGVjdCwgRHJvcGRvd24sIFBvcG92ZXIsIEJ1dHRvbiwgbWVzc2FnZSB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IElvTWRNb3JlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgZmllbGRTaXplIH0gZnJvbSBcIi4uL2RhdGEvZmllbGRTaXplXCI7XHJcbmltcG9ydCB7IEZhV2hhdHNhcHAgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IHNob3dDb25maXJtIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL1Nob3dDb25maXJtXCI7XHJcbmltcG9ydCB7XHJcbiAgQ2hlY2tDaXJjbGVPdXRsaW5lZCxcclxuICBDbG9ja0NpcmNsZU91dGxpbmVkLFxyXG4gIENsb3NlQ2lyY2xlT3V0bGluZWQsXHJcbiAgRXhjbGFtYXRpb25DaXJjbGVPdXRsaW5lZCxcclxuICBRdWVzdGlvbkNpcmNsZU91dGxpbmVkLFxyXG59IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5pbXBvcnQgQnJlYWRjcnVtYiBmcm9tIFwiLi4vaGVscGVycy9CcmVhZGNydW1iXCI7XHJcblxyXG5jb25zdCBJTklUSUFMX1BBWU1FTlRfU1RBVEUgPSB7XHJcbiAgcGF5bWVudF9hbW91bnQ6IFwiXCIsXHJcbiAgcGF5bWVudF9kYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdLFxyXG4gIHBheW1lbnRfbW9kZTogbnVsbCxcclxuICB0cmFuc2FjdGlvbl9pZDogXCJcIixcclxuICBzZXJ2aWNlX2NoYXJnZXM6IFwiXCIsXHJcbiAgZG9jdW1lbnRfY2hhcmdlczogXCJcIixcclxuICBkYWlseV9wYXltZW50X2Ftb3VudDogXCJcIixcclxuICBzdGFydF9kYXRlOiBcIlwiLFxyXG4gIGVuZF9kYXRlOiBcIlwiLFxyXG4gIGxvYW5faWQ6IFwiXCIsXHJcbiAgY2hlcXVlX251bWJlcjogXCJcIixcclxuICBub3RlOiBcIlwiLFxyXG59O1xyXG5cclxuY29uc3QgTG9hblBheW1lbnRPdXQgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3Jhd0xvYW5zLCBzZXRSYXdMb2Fuc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd1BheW1lbnRNb2RhbCwgc2V0U2hvd1BheW1lbnRNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2N1cnJlbnRCb3Jyb3dlciwgc2V0Q3VycmVudEJvcnJvd2VyXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtyZWxvYWRUcmlnZ2VyLCBzZXRSZWxvYWRUcmlnZ2VyXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFtwYXltZW50Rm9ybURhdGEsIHNldFBheW1lbnRGb3JtRGF0YV0gPSB1c2VTdGF0ZShJTklUSUFMX1BBWU1FTlRfU1RBVEUpO1xyXG4gIGNvbnN0IFtwYXltZW50RXJyb3JzLCBzZXRQYXltZW50RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJcIixcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFt0aGlyZFBhcnR5RW5hYmxlLCBzZXRUaGlyZFBhcnR5RW5hYmxlXSA9IHVzZVN0YXRlKHtcclxuICAgIHdoYXRzYXBwOiB0cnVlLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFttb2RpZnlQYXltZW50LCBzZXRNb2RpZnlQYXltZW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbW9kaWZ5TWluTWF4UGF5bWVudERhdGUsIHNldE1vZGlmeU1pbk1heFBheW1lbnREYXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbYWRtaW5JZCwgc2V0QWRtaW5JZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBmZXRjaEFwcHJvdmVkTG9hbnMgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBcIi92MS9hZG1pbi9sb2Fucy8/YXBwcm92YWxfc3RhdHVzPUFQUFJPVkVEXCIsXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBzZXRSYXdMb2FucyhkYXRhPy5kYXRhIHx8IFtdKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNob3dBbGVydChcIkZhaWxlZCB0byBmZXRjaCBhcHByb3ZlZCBsb2Fuc1wiLCBcImVycm9yXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaEFwcHJvdmVkTG9hbnMoKTtcclxuICB9LCBbZmV0Y2hBcHByb3ZlZExvYW5zLCByZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB1c2VyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgY29uc3QgdXNlck9iaiA9IEpTT04ucGFyc2UodXNlcik7XHJcbiAgICBjb25zdCB1c2VyQWRtaW5JZCA9IHVzZXJPYmo/Ll9pZDtcclxuICAgIHNldEFkbWluSWQodXNlckFkbWluSWQpO1xyXG5cclxuICAgIGlmICh1c2VyT2JqKSB7XHJcbiAgICAgIGNvbnN0IGFkbWluQWNjZXNzUGVybWlzc2lvbnMgPVxyXG4gICAgICAgIHVzZXJPYmouYWRtaW5fYWNjZXNzX3JpZ2h0X2lkPy5hY2Nlc3NfcGVybWlzc2lvbnM7XHJcblxyXG4gICAgICBpZiAoYWRtaW5BY2Nlc3NQZXJtaXNzaW9ucz8uZWRpdF9wYXltZW50ID09PSBcInRydWVcIikge1xyXG4gICAgICAgIHNldE1vZGlmeVBheW1lbnQodHJ1ZSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChhZG1pbkFjY2Vzc1Blcm1pc3Npb25zPy5lZGl0X2xpbWl0ZWRfcGF5bWVudCA9PT0gXCJ0cnVlXCIpIHtcclxuICAgICAgICBzZXRNb2RpZnlQYXltZW50KHRydWUpO1xyXG4gICAgICAgIHNldE1vZGlmeU1pbk1heFBheW1lbnREYXRlKHRydWUpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBzaG93QWxlcnQgPSAobWVzc2FnZSwgdHlwZSA9IFwiaW5mb1wiKSA9PiB7XHJcbiAgICBzZXRBbGVydENvbmZpZyh7IHZpc2liaWxpdHk6IHRydWUsIG1lc3NhZ2UsIHR5cGUgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgcmVzZXRGb3JtID0gKCkgPT4ge1xyXG4gICAgc2V0UGF5bWVudEZvcm1EYXRhKElOSVRJQUxfUEFZTUVOVF9TVEFURSk7XHJcbiAgICBzZXRQYXltZW50RXJyb3JzKHt9KTtcclxuICAgIHNldFNob3dQYXltZW50TW9kYWwoZmFsc2UpO1xyXG4gICAgc2V0Q3VycmVudEJvcnJvd2VyKG51bGwpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGJ1aWxkTm90ZVN0cmluZyA9IChmZCkgPT4ge1xyXG4gICAgY29uc3QgcGFydHMgPSBbXTtcclxuICAgIGlmIChmZC5ub3RlPy50cmltKCkpIHBhcnRzLnB1c2goZmQubm90ZS50cmltKCkpO1xyXG4gICAgaWYgKGZkLnBheW1lbnRfbW9kZSA9PT0gXCJCYW5rIFRyYW5zZmVyXCIpIHtcclxuICAgICAgaWYgKGZkLnRyYW5zYWN0aW9uX2lkKSBwYXJ0cy5wdXNoKGBUeG46ICR7ZmQudHJhbnNhY3Rpb25faWR9YCk7XHJcbiAgICAgIGlmIChmZC5iYW5rX25hbWUpIHBhcnRzLnB1c2goYEJhbms6ICR7ZmQuYmFua19uYW1lfWApO1xyXG4gICAgfVxyXG4gICAgaWYgKGZkLnBheW1lbnRfbW9kZSA9PT0gXCJDaGVxdWVcIiAmJiBmZC5jaGVxdWVfbnVtYmVyKSB7XHJcbiAgICAgIHBhcnRzLnB1c2goYENocTogJHtmZC5jaGVxdWVfbnVtYmVyfWApO1xyXG4gICAgfSBlbHNlIGlmIChmZC5wYXltZW50X21vZGUgPT09IFwiT25saW5lXCIgJiYgZmQudHJhbnNhY3Rpb25faWQpIHtcclxuICAgICAgcGFydHMucHVzaChgVHhuOiAke2ZkLnRyYW5zYWN0aW9uX2lkfWApO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHBhcnRzLmpvaW4oXCIgfCBcIik7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUGF5bWVudE91dE1vZGFsT3BlbiA9IGFzeW5jIChsb2FuSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgdjEvYWRtaW4vbG9hbnMvJHtsb2FuSWR9YCk7XHJcbiAgICAgIGNvbnN0IGRhdGEgPSByZXNwb25zZS5kYXRhPy5kYXRhO1xyXG4gICAgICBzZXRDdXJyZW50Qm9ycm93ZXIoZGF0YSB8fCB7fSk7XHJcbiAgICAgIHNldFBheW1lbnRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIHBheW1lbnRfYW1vdW50OlxyXG4gICAgICAgICAgTnVtYmVyKGRhdGE/LmxvYW5fYW1vdW50IHx8IDApIC1cclxuICAgICAgICAgIE51bWJlcihkYXRhLnNlcnZpY2VfY2hhcmdlcyB8fCAwKSAtXHJcbiAgICAgICAgICBOdW1iZXIoZGF0YS5kb2N1bWVudF9jaGFyZ2VzIHx8IDApIHx8IDAsXHJcbiAgICAgICAgc2VydmljZV9jaGFyZ2VzOiBkYXRhLnNlcnZpY2VfY2hhcmdlcyB8fCBcIlwiLFxyXG4gICAgICAgIGRvY3VtZW50X2NoYXJnZXM6IGRhdGEuZG9jdW1lbnRfY2hhcmdlcyB8fCBcIlwiLFxyXG4gICAgICAgIGRhaWx5X3BheW1lbnRfYW1vdW50OiBkYXRhLmRhaWx5X3BheW1lbnRfYW1vdW50IHx8IFwiXCIsXHJcbiAgICAgICAgc3RhcnRfZGF0ZTogZGF0YS5zdGFydF9kYXRlLFxyXG4gICAgICAgIGVuZF9kYXRlOiBkYXRhLmVuZF9kYXRlLFxyXG4gICAgICAgIGxvYW5faWQ6IGRhdGEubG9hbl9pZCxcclxuXHJcbiAgICAgICAgcGF5bWVudF9kYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICB9KSk7XHJcbiAgICAgIHNldFNob3dQYXltZW50TW9kYWwodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzaG93QWxlcnQoXCJGYWlsZWQgdG8gZmV0Y2ggYm9ycm93ZXIgZGV0YWlsc1wiLCBcImVycm9yXCIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHZhbGlkYXRlID0gKCkgPT4ge1xyXG4gICAgY29uc3QgZXJyb3JzID0ge307XHJcbiAgICBpZiAoIXBheW1lbnRGb3JtRGF0YS5wYXltZW50X2Ftb3VudCB8fCBwYXltZW50Rm9ybURhdGEucGF5bWVudF9hbW91bnQgPD0gMClcclxuICAgICAgZXJyb3JzLnBheW1lbnRfYW1vdW50ID0gXCJSZXF1aXJlZFwiO1xyXG4gICAgaWYgKCFwYXltZW50Rm9ybURhdGEucGF5bWVudF9kYXRlKSBlcnJvcnMucGF5bWVudF9kYXRlID0gXCJSZXF1aXJlZFwiO1xyXG4gICAgaWYgKCFwYXltZW50Rm9ybURhdGEucGF5bWVudF9tb2RlKSBlcnJvcnMucGF5bWVudF9tb2RlID0gXCJSZXF1aXJlZFwiO1xyXG5cclxuICAgIGlmIChcclxuICAgICAgcGF5bWVudEZvcm1EYXRhLnBheW1lbnRfbW9kZSA9PT0gXCJCYW5rIFRyYW5zZmVyXCIgJiZcclxuICAgICAgIXBheW1lbnRGb3JtRGF0YS50cmFuc2FjdGlvbl9pZFxyXG4gICAgKVxyXG4gICAgICBlcnJvcnMudHJhbnNhY3Rpb25faWQgPSBcIlRyYW5zYWN0aW9uIElEIHJlcXVpcmVkXCI7XHJcbiAgICBpZiAoXHJcbiAgICAgIHBheW1lbnRGb3JtRGF0YS5wYXltZW50X21vZGUgPT09IFwiQ2hlcXVlXCIgJiZcclxuICAgICAgIXBheW1lbnRGb3JtRGF0YS5jaGVxdWVfbnVtYmVyXHJcbiAgICApXHJcbiAgICAgIGVycm9ycy5jaGVxdWVfbnVtYmVyID0gXCJDaGVxdWUgbnVtYmVyIHJlcXVpcmVkXCI7XHJcblxyXG4gICAgaWYgKHBheW1lbnRFcnJvcnMucGF5X2RhdGUgPT09IFwiT25saW5lXCIgJiYgIXBheW1lbnRGb3JtRGF0YS50cmFuc2FjdGlvbl9pZClcclxuICAgICAgZXJyb3JzLnRyYW5zYWN0aW9uX2lkID0gXCJUcmFuc2FjdGlvbiBJRCByZXF1aXJlZFwiO1xyXG5cclxuICAgIHNldFBheW1lbnRFcnJvcnMoZXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhlcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQYXltZW50T3V0U3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGlmICghdmFsaWRhdGUoKSkgcmV0dXJuO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgbG9hbjogY3VycmVudEJvcnJvd2VyPy5faWQgfHwgY3VycmVudEJvcnJvd2VyPy5faWQsXHJcbiAgICAgICAgdXNlcl9pZDogY3VycmVudEJvcnJvd2VyPy5ib3Jyb3dlcj8uX2lkIHx8IGN1cnJlbnRCb3Jyb3dlcj8udXNlcl9pZCxcclxuICAgICAgICBwYXlfZGF0ZTogcGF5bWVudEZvcm1EYXRhLnBheW1lbnRfZGF0ZSxcclxuICAgICAgICBhbW91bnQ6IHBheW1lbnRGb3JtRGF0YS5wYXltZW50X2Ftb3VudC50b1N0cmluZygpLFxyXG4gICAgICAgIHBheV90eXBlOiBwYXltZW50Rm9ybURhdGEucGF5bWVudF9tb2RlLFxyXG4gICAgICAgIHBheV9mb3I6IFwiTG9hblwiLFxyXG4gICAgICAgIG5vdGU6IHBheW1lbnRGb3JtRGF0YS5ub3RlLFxyXG4gICAgICAgIHRyYW5zYWN0aW9uX2lkOiBwYXltZW50Rm9ybURhdGEudHJhbnNhY3Rpb25faWQsXHJcbiAgICAgICAgYWRtaW5fdHlwZTogYWRtaW5JZCxcclxuICAgICAgICAuLi50aGlyZFBhcnR5RW5hYmxlLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgYXdhaXQgYXBpLnBhdGNoKFwiL3YxL2FkbWluL2xvYW5zL2NvbXBsZXRlZFwiLCBwYXlsb2FkKTtcclxuICAgICAgc2hvd0FsZXJ0KFwiUGF5bWVudCBwcm9jZXNzZWQgc3VjY2Vzc2Z1bGx5XCIsIFwic3VjY2Vzc1wiKTtcclxuICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocCkgPT4gcCArIDEpO1xyXG4gICAgICByZXNldEZvcm0oKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNob3dBbGVydChcclxuICAgICAgICBlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fFxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlPy5kYXRhPy5zdGF0dXNDb2RlIHx8XHJcbiAgICAgICAgXCJUcmFuc2FjdGlvbiBmYWlsZWRcIixcclxuICAgICAgICBcImVycm9yXCIsXHJcbiAgICAgICk7XHJcbiAgICB9XHJcbiAgfTtcclxuICBjb25zdCB1cGRhdGVMb2FuU3RhdHVzID0gYXN5bmMgKGxvYW4sIG5ld1N0YXR1cykgPT4ge1xyXG4gICAgc2hvd0NvbmZpcm0oe1xyXG4gICAgICB0aXRsZTogYCR7bmV3U3RhdHVzfSBMb2FuIFJlcXVlc3RgLFxyXG4gICAgICBjb250ZW50OiBgQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGNoYW5nZSB0aGUgc3RhdHVzIG9mIHRoaXMgbG9hbiB0byAke25ld1N0YXR1c30/YCxcclxuICAgICAgb25Db25maXJtOiBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGFwaS5wYXRjaChcIi92MS9hZG1pbi9sb2Fucy9hcHByb3ZhbC1zdGF0dXNcIiwge1xyXG4gICAgICAgICAgICBpZDogbG9hbi5faWQsXHJcbiAgICAgICAgICAgIGFwcHJvdmFsX3N0YXR1czogbmV3U3RhdHVzLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBtZXNzYWdlLnN1Y2Nlc3MoYExvYW4gc3RhdHVzIHVwZGF0ZWQgdG8gJHtuZXdTdGF0dXN9IHN1Y2Nlc3NmdWxseWApO1xyXG4gICAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgbG9hbiBzdGF0dXM6XCIsIGVycm9yKTtcclxuICAgICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gdXBkYXRlIGxvYW4gc3RhdHVzXCIpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHRhYmxlRGF0YSA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3Qgc3RhdHVzT3B0aW9ucyA9IFtcclxuICAgICAge1xyXG4gICAgICAgIGxhYmVsOiBcIkFjY2VwdFwiLFxyXG4gICAgICAgIHZhbHVlOiBcIkFDQ0VQVEVEXCIsXHJcbiAgICAgICAgaWNvbjogPENoZWNrQ2lyY2xlT3V0bGluZWQgLz4sXHJcbiAgICAgICAgY2xhc3NOYW1lOiBcImJnLWdyZWVuLTcwMCB0ZXh0LXdoaXRlIGhvdmVyOmJnLWdyZWVuLTgwMFwiLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgbGFiZWw6IFwiUGVuZGluZ1wiLFxyXG4gICAgICAgIHZhbHVlOiBcIlBFTkRJTkdcIixcclxuICAgICAgICBpY29uOiA8Q2xvY2tDaXJjbGVPdXRsaW5lZCAvPixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYm9yZGVyLXllbGxvdy00MDAgdGV4dC15ZWxsb3ctNjAwIGhvdmVyOmJnLXllbGxvdy01MFwiLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgbGFiZWw6IFwiUmVqZWN0XCIsXHJcbiAgICAgICAgdmFsdWU6IFwiUkVKRUNURURcIixcclxuICAgICAgICBpY29uOiA8Q2xvc2VDaXJjbGVPdXRsaW5lZCAvPixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYm9yZGVyLXJlZC00MDAgdGV4dC1yZWQtNjAwIGhvdmVyOmJnLXJlZC01MFwiLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgbGFiZWw6IFwiVW5rbm93blwiLFxyXG4gICAgICAgIHZhbHVlOiBcIlVOS05PV05cIixcclxuICAgICAgICBpY29uOiA8UXVlc3Rpb25DaXJjbGVPdXRsaW5lZCAvPixcclxuICAgICAgICBjbGFzc05hbWU6IFwiYm9yZGVyLXllbGxvdy00MDAgdGV4dC15ZWxsb3ctNjAwIGhvdmVyOmJnLXllbGxvdy01MFwiLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgbGFiZWw6IFwiUmVxdWVzdGVkXCIsXHJcbiAgICAgICAgdmFsdWU6IFwiUkVRVUVTVEVEXCIsXHJcbiAgICAgICAgaWNvbjogPEV4Y2xhbWF0aW9uQ2lyY2xlT3V0bGluZWQgLz4sXHJcbiAgICAgICAgY2xhc3NOYW1lOiBcImJvcmRlci1ibHVlLTQwMCB0ZXh0LWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTBcIixcclxuICAgICAgfSxcclxuICAgIF07XHJcbiAgICBjb25zdCBwb3BvdmVyQ29udGVudCA9IChib3Jyb3dlcikgPT4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNDAgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctbWQgcC0yIHNwYWNlLXktMlwiPlxyXG4gICAgICAgIHtzdGF0dXNPcHRpb25zLm1hcCgob3B0KSA9PiAoXHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIGtleT17b3B0LnZhbHVlfVxyXG4gICAgICAgICAgICBpY29uPXtvcHQuaWNvbn1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1zdGFydCB3LWZ1bGwgJHtvcHQuY2xhc3NOYW1lfWB9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZUxvYW5TdGF0dXMoYm9ycm93ZXIsIG9wdC52YWx1ZSl9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtvcHQubGFiZWx9XHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICApKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gICAgY29uc3QgZm9ybWF0dGVkID0gcmF3TG9hbnMubWFwKChpdGVtLCBpbmRleCkgPT4gKHtcclxuICAgICAgLi4uaXRlbSxcclxuICAgICAgc2xfbm86IGluZGV4ICsgMSxcclxuICAgICAgYm9ycm93ZXJfbmFtZTogaXRlbT8uYm9ycm93ZXI/LmZ1bGxfbmFtZSxcclxuICAgICAgc2VydmljZV9jaGFyZ2VzOiBOdW1iZXIoaXRlbS5zZXJ2aWNlX2NoYXJnZXMgfHwgMCksXHJcbiAgICAgIGRvY3VtZW50X2NoYXJnZXM6IE51bWJlcihpdGVtLmRvY3VtZW50X2NoYXJnZXMgfHwgMCksXHJcbiAgICAgIGFwcHJvdmFsX3N0YXR1czogaXRlbS5hcHByb3ZhbF9zdGF0dXMsXHJcbiAgICAgIHRvdGFsX3BheWFibGU6XHJcbiAgICAgICAgTnVtYmVyKGl0ZW0ubG9hbl9hbW91bnQgfHwgMCkgLVxyXG4gICAgICAgIE51bWJlcihpdGVtLnNlcnZpY2VfY2hhcmdlcyB8fCAwKSAtXHJcbiAgICAgICAgTnVtYmVyKGl0ZW0uZG9jdW1lbnRfY2hhcmdlcyB8fCAwKSxcclxuICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgIGxhYmVsOiBcIlBheW1lbnQgT3V0XCIsXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrOiAoKSA9PiBoYW5kbGVQYXltZW50T3V0TW9kYWxPcGVuKGl0ZW0uX2lkKSxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGtleTogXCIyXCIsXHJcbiAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICA8UG9wb3ZlclxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cInJpZ2h0VG9wXCJcclxuICAgICAgICAgICAgICAgICAgICB0cmlnZ2VyPVwiaG92ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRlbnQ9e3BvcG92ZXJDb250ZW50KGl0ZW0pfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBVcGRhdGUgU3RhdHVzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvUG9wb3Zlcj5cclxuICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgXSxcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC14bCBjdXJzb3ItcG9pbnRlciBob3Zlcjp0ZXh0LWJsdWUtNjAwIHRyYW5zaXRpb24tY29sb3JzXCIgLz5cclxuICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICApLFxyXG4gICAgfSkpO1xyXG4gICAgcmV0dXJuIGZpbHRlck9wdGlvbihmb3JtYXR0ZWQsIHNlYXJjaFRleHQpO1xyXG4gIH0sIFtyYXdMb2Fucywgc2VhcmNoVGV4dF0pO1xyXG4gIGNvbnN0IHRvdGFsUGF5YWJsZVN1bSA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIHRhYmxlRGF0YS5yZWR1Y2UoXHJcbiAgICAgIChzdW0sIGl0ZW0pID0+IHN1bSArIChOdW1iZXIoaXRlbS50b3RhbF9wYXlhYmxlKSB8fCAwKSxcclxuICAgICAgMCxcclxuICAgICk7XHJcbiAgfSwgW3RhYmxlRGF0YV0pO1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwic2xfbm9cIiwgaGVhZGVyOiBcIlNMXCIgfSxcclxuICAgIHsga2V5OiBcImxvYW5faWRcIiwgaGVhZGVyOiBcIkxvYW4gSURcIiB9LFxyXG4gICAgeyBrZXk6IFwiYm9ycm93ZXJfbmFtZVwiLCBoZWFkZXI6IFwiQm9ycm93ZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwibG9hbl9hbW91bnRcIiwgaGVhZGVyOiBcIlByaW5jaXBhbFwiIH0sXHJcbiAgICB7IGtleTogXCJ0b3RhbF9wYXlhYmxlXCIsIGhlYWRlcjogXCJUb3RhbCBQYXlhYmxlXCIgfSxcclxuICAgIHsga2V5OiBcImFwcHJvdmFsX3N0YXR1c1wiLCBoZWFkZXI6IFwiQXBwcm92YWwgU3RhdHVzXCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCBjb21tb25JbnB1dENsYXNzID0gYGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctZ3JheS01MFwiPlxyXG4gICAgICA8TmF2YmFyXHJcbiAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9eyhlKSA9PiBzZXRTZWFyY2hUZXh0KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgLz5cclxuICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbiAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbiAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRBbGVydENvbmZpZygocCkgPT4gKHsgLi4ucCwgdmlzaWJpbGl0eTogZmFsc2UgfSkpfVxyXG4gICAgICAvPlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICA8bWFpbiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC0zXCI+XHJcbiAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1lbmQgbWItMTBcIj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgIExvYW4gUGF5bWVudCBPdXRcclxuICAgICAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgRGlzYnVyc2UgYXBwcm92ZWQgZnVuZHMgdG8gYm9ycm93ZXJzXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGl0ZW1zLXN0YXJ0IGdhcC0zIG1iLTFcIj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiICBzaGFkb3ctc20gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC02XCI+XHJcbiAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgIHRvPVwiL290aGVyLXNlcnZpY2UtbWVudS9sb2FuXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ibHVlLTUwMCB0ZXh0LWJsdWUtNjAwIHJvdW5kZWQtbGdcclxuICAgICAgaG92ZXI6YmctYmx1ZS01MCBob3Zlcjp0ZXh0LWJsdWUtNzAwIGhvdmVyOmJvcmRlci1ibHVlLTYwMFxyXG4gICAgICB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgZm9udC1tZWRpdW1cIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIE90aGVyIFNlcnZpY2UgLyBMb2Fuc1xyXG4gICAgICAgICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNiB0ZXh0LXNtIGJnLWJsdWUtMTAwIGJvcmRlciBib3JkZXItYmx1ZS0zMDAgcm91bmRlZC14bCBweC01IHB5LTMgXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtOTAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgIFBlbmRpbmcgUGF5bWVudHM6e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGRcIj57dGFibGVEYXRhLmxlbmd0aH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy1weCBoLTUgYmctYmx1ZS0zMDBcIj48L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ibHVlLTkwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICBUb3RhbCBQYXlhYmxlOntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAg4oK5e3RvdGFsUGF5YWJsZVN1bS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICBcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBwLTRcIj5cclxuICAgICAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXt0cnVlfSAvPlxyXG4gICAgICAgICAgICApIDogdGFibGVEYXRhLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTIwIHRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAgICAgIE5vIHBlbmRpbmcgcGF5bWVudHMgZm91bmQuXHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgZGF0YT17dGFibGVEYXRhfVxyXG4gICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJMb2FuX1BheW1lbnRzXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9tYWluPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxNb2RhbCBpc1Zpc2libGU9e3Nob3dQYXltZW50TW9kYWx9IG9uQ2xvc2U9e3Jlc2V0Rm9ybX0+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTZcIj5cclxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCBtYi00IGJvcmRlci1iIHBiLTJcIj5cclxuICAgICAgICAgICAgQ29uZmlybSBEaXNidXJzZW1lbnRcclxuICAgICAgICAgIDwvaDM+XHJcblxyXG4gICAgICAgICAge2N1cnJlbnRCb3Jyb3dlciAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtNCBtYi02IGJnLWdyYXktNTAgcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1kYXNoZWRcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRleHQtZ3JheS01MDAgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgIEJvcnJvd2VyXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAge2N1cnJlbnRCb3Jyb3dlcj8uYm9ycm93ZXI/LmZ1bGxfbmFtZX1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRleHQtZ3JheS01MDAgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgIExvYW4gQW1vdW50XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICDigrl7Y3VycmVudEJvcnJvd2VyPy5sb2FuX2Ftb3VudH1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVQYXltZW50T3V0U3VibWl0fSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBTZXJ2aWNlcyBDaGFyZ2VzXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3BheW1lbnRGb3JtRGF0YS5zZXJ2aWNlX2NoYXJnZXMgfHwgMH1cclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHtjb21tb25JbnB1dENsYXNzfSBkaXNhYmxlZDp0ZXh0LWdyYXktOTAwIGRpc2FibGVkOmJnLWdyYXktMTAwYH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBEb2N1bWVudGF0aW9uIENoYXJnZXNcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17cGF5bWVudEZvcm1EYXRhLmRvY3VtZW50X2NoYXJnZXMgfHwgMH1cclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHtjb21tb25JbnB1dENsYXNzfSBkaXNhYmxlZDp0ZXh0LWdyYXktOTAwIGRpc2FibGVkOmJnLWdyYXktMTAwYH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBBbW91bnRcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXltZW50Rm9ybURhdGE/LnBheW1lbnRfYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0UGF5bWVudEZvcm1EYXRhKChwKSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgLi4ucCxcclxuICAgICAgICAgICAgICAgICAgICAgIHBheW1lbnRfYW1vdW50OiBlLnRhcmdldC52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICB9KSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NvbW1vbklucHV0Q2xhc3N9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAge3BheW1lbnRFcnJvcnMucGF5bWVudF9hbW91bnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1bMTBweF1cIj5cclxuICAgICAgICAgICAgICAgICAgICB7cGF5bWVudEVycm9ycy5wYXltZW50X2Ftb3VudH1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIERhdGVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17cGF5bWVudEZvcm1EYXRhLnBheW1lbnRfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHNldFBheW1lbnRGb3JtRGF0YSgocCkgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLnAsXHJcbiAgICAgICAgICAgICAgICAgICAgICBwYXltZW50X2RhdGU6IGUudGFyZ2V0LnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y29tbW9uSW5wdXRDbGFzc31cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgIFBheW1lbnQgTW9kZVxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG10LTFcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgTW9kZVwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17cGF5bWVudEZvcm1EYXRhLnBheW1lbnRfbW9kZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodikgPT5cclxuICAgICAgICAgICAgICAgICAgc2V0UGF5bWVudEZvcm1EYXRhKChwKSA9PiAoeyAuLi5wLCBwYXltZW50X21vZGU6IHYgfSkpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJDYXNoXCI+Q2FzaDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiQmFuayBUcmFuc2ZlclwiPlxyXG4gICAgICAgICAgICAgICAgICBCYW5rIFRyYW5zZmVyXHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIkNoZXF1ZVwiPkNoZXF1ZTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiT25saW5lXCI+T25saW5lPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIHtwYXltZW50RXJyb3JzLnBheW1lbnRfbW9kZSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1bMTBweF1cIj5cclxuICAgICAgICAgICAgICAgICAge3BheW1lbnRFcnJvcnMucGF5bWVudF9tb2RlfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAge3BheW1lbnRGb3JtRGF0YS5wYXltZW50X21vZGUgPT09IFwiQmFuayBUcmFuc2ZlclwiICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFuaW1hdGUtZmFkZUluXCI+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJUcmFuc2FjdGlvbiBJRCAqXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3BheW1lbnRGb3JtRGF0YS50cmFuc2FjdGlvbl9pZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHNldFBheW1lbnRGb3JtRGF0YSgocCkgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLnAsXHJcbiAgICAgICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvbl9pZDogZS50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHtjb21tb25JbnB1dENsYXNzfSBtYi0yYH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICB7LyogPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQmFuayBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3BheW1lbnRGb3JtRGF0YS5iYW5rX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBzZXRQYXltZW50Rm9ybURhdGEoKHApID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAuLi5wLFxyXG4gICAgICAgICAgICAgICAgICAgICAgYmFua19uYW1lOiBlLnRhcmdldC52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICB9KSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NvbW1vbklucHV0Q2xhc3N9XHJcbiAgICAgICAgICAgICAgICAvPiAqL31cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHtwYXltZW50Rm9ybURhdGEucGF5bWVudF9tb2RlID09PSBcIkNoZXF1ZVwiICYmIChcclxuICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQ2hlcXVlIE51bWJlciAqXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtwYXltZW50Rm9ybURhdGEuY2hlcXVlX251bWJlcn1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgc2V0UGF5bWVudEZvcm1EYXRhKChwKSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgIC4uLnAsXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlcXVlX251bWJlcjogZS50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjb21tb25JbnB1dENsYXNzfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7cGF5bWVudEZvcm1EYXRhLnBheW1lbnRfbW9kZSA9PT0gXCJPbmxpbmVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlRyYW5zYWN0aW9uIElEICpcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3BheW1lbnRGb3JtRGF0YS50cmFuc2FjdGlvbl9pZH1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgc2V0UGF5bWVudEZvcm1EYXRhKChwKSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgIC4uLnAsXHJcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNhY3Rpb25faWQ6IGUudGFyZ2V0LnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICB9KSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y29tbW9uSW5wdXRDbGFzc31cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgPElucHV0LlRleHRBcmVhXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOb3RlIChJbnRlcm5hbCByZWNvcmQpXCJcclxuICAgICAgICAgICAgICByb3dzPXsyfVxyXG4gICAgICAgICAgICAgIHZhbHVlPXtwYXltZW50Rm9ybURhdGEubm90ZX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICBzZXRQYXltZW50Rm9ybURhdGEoKHApID0+ICh7IC4uLnAsIG5vdGU6IGUudGFyZ2V0LnZhbHVlIH0pKVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cclxuICAgICAgICAgICAgICAgIDxGYVdoYXRzYXBwIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwIHctNSBoLTVcIiAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTgwMFwiPkVuYWJsZSBXaGF0c0FwcCBTZW5kaW5nPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3RoaXJkUGFydHlFbmFibGUud2hhdHNhcHB9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgc2V0VGhpcmRQYXJ0eUVuYWJsZSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgIHdoYXRzYXBwOiAhcHJldi53aGF0c2FwcCxcclxuICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01IGFjY2VudC1ncmVlbi02MDAgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0yIHB0LTRcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3Jlc2V0Rm9ybX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiB0ZXh0LXNtIHRleHQtZ3JheS01MDAgaG92ZXI6YmctZ3JheS0xMDAgcm91bmRlZFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC02IHB5LTIgdGV4dC1zbSBiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQgZm9udC1ib2xkIGhvdmVyOmJnLWJsdWUtNzAwIHNoYWRvdy1sZ1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ29uZmlybSBEaXNidXJzZW1lbnRcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvTW9kYWw+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTG9hblBheW1lbnRPdXQ7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9Mb2FuUGF5bWVudE91dC5qc3gifQ==