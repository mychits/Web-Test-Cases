import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LoanDocumentation.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport4_react["useEffect"]; const useState = __vite__cjsImport4_react["useState"]; const useMemo = __vite__cjsImport4_react["useMemo"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import api from "/src/instance/TokenInstance.js";
import {
  Dropdown,
  Popconfirm,
  message,
  Button,
  Modal,
  DatePicker,
  Progress
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import {
  IoFlash,
  IoDocumentText,
  IoCheckmarkCircle,
  IoEye,
  IoDocument,
  IoDownload,
  IoClose,
  IoWallet
} from "/node_modules/.vite/deps/react-icons_io5.js?v=819e0a34";
import filterOption from "/src/helpers/filterOption.js";
import ModalComponent from "/src/components/modals/Modal.jsx";
import { FaRupeeSign, FaFileContract } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { IoFlag } from "/node_modules/.vite/deps/react-icons_io5.js?v=819e0a34";
import __vite__cjsImport18_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport18_dayjs.__esModule ? __vite__cjsImport18_dayjs.default : __vite__cjsImport18_dayjs;
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const { RangePicker } = DatePicker;
const REQUIRED_LOAN_DOCUMENTS = [
  { key: "user_profile_photo", label: "Photo" },
  { key: "user_adharcard_front_photo", label: "Aadhar Card (Front)" },
  { key: "user_adharcard_back_photo", label: "Aadhar Card (Back)" },
  { key: "user_pancard_photo", label: "PAN Card" },
  { key: "user_cheque_leaf", label: "Cheque Leaf" },
  { key: "bank_statement_month", label: "Bank Statement" },
  { key: "bank_passbook_photo", label: "Passbook Photo" },
  { key: "business_document_proof", label: "Business Proof" },
  { key: "user_salary_slip", label: "Salary Slip" },
  { key: "user_nominee_adharcard_front_photo", label: "Nominee Aadhar (Front)" },
  { key: "user_nominee_adharcard_back_photo", label: "Nominee Aadhar (Back)" },
  { key: "user_nominee_pancard_photo", label: "Nominee PAN Card" }
];
function LoanDocumentation() {
  _s();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [activeTab, setActiveTab] = useState("pending");
  const [isLoading, setIsLoading] = useState(false);
  const [previewImage, setPreviewImage] = useState(null);
  const [previewTitle, setPreviewTitle] = useState("");
  const [allLoanDocuments, setAllLoanDocuments] = useState([]);
  const [pendingData, setPendingData] = useState([]);
  const [documentCollectionData, setDocumentCollectionData] = useState([]);
  const [documentVerificationData, setDocumentVerificationData] = useState([]);
  const [completedData, setCompletedData] = useState([]);
  const [filteredPending, setFilteredPending] = useState([]);
  const [filteredDocCollection, setFilteredDocCollection] = useState([]);
  const [filteredDocVerification, setFilteredDocVerification] = useState([]);
  const [filteredCompleted, setFilteredCompleted] = useState([]);
  const [dateRange, setDateRange] = useState([null, null]);
  const [activeUserData, setActiveUserData] = useState({});
  const [selectAll, setSelectAll] = useState(false);
  const [showDocumentModal, setShowDocumentModal] = useState(false);
  const [currentDocuments, setCurrentDocuments] = useState([]);
  const [currentLoanForDocs, setCurrentLoanForDocs] = useState(null);
  useEffect(() => {
    fetchAllLoanDocuments();
  }, []);
  const fetchAllLoanDocuments = async () => {
    setIsLoading(true);
    try {
      const response = await api.get("/v1/admin/loan-documents/");
      const loanDocs = response.data?.data || response.data || [];
      if (Array.isArray(loanDocs) && loanDocs.length > 0) {
        setAllLoanDocuments(loanDocs);
        processLoanDocuments(loanDocs);
      } else {
        setAllLoanDocuments([]);
        resetAllTabData();
      }
    } catch (error) {
      console.error("Error fetching loan documents:", error);
      message.error(error.response?.data?.message || "Failed to fetch loan documents");
      resetAllTabData();
    } finally {
      setIsLoading(false);
    }
  };
  const processLoanDocuments = async (loanDocs) => {
    const pending = [];
    const docCollection = [];
    const docVerification = [];
    const completed = [];
    const processPromises = loanDocs.map(async (loanDoc, idx) => {
      let documentPercentage = 0;
      let documents = [];
      if (loanDoc.status === "Document Collection") {
        const userId = loanDoc.user_id?._id || loanDoc.user_id || loanDoc.loanId?.user_id;
        if (userId) {
          try {
            const userDocsRes = await api.get(`/v1/admin/user-documents/${userId}`);
            if (userDocsRes.data && userDocsRes.data.data) {
              let userDoc = userDocsRes.data.data;
              if (Array.isArray(userDoc) && userDoc.length > 0) {
                userDoc = userDoc[0];
              }
              documents = transformUserDocumentsToArray(userDoc);
              documentPercentage = calculateDocumentPercentage(documents);
            }
          } catch (err) {
            console.error("Error fetching user documents:", err);
          }
        }
      }
      const baseData = {
        key: loanDoc._id,
        id: idx + 1,
        loan_id: loanDoc.loan_id?._id || "N/A",
        loan_code: loanDoc.loan_id?.loan_id || "N/A",
        customer_name: loanDoc.loan_id?.borrower?.full_name || "N/A",
        phone_number: loanDoc.loan_id?.borrower?.phone_number || "N/A",
        loan_amount: "N/A",
        status_raw: loanDoc.status,
        document_percentage: documentPercentage,
        documents,
        created_at: loanDoc.createdAt?.split("T")[0] || "N/A",
        updated_at: loanDoc.updatedAt?.split("T")[0] || "N/A",
        loan_data: loanDoc
        // keep full object for actions
      };
      switch (loanDoc.status) {
        case "Pending":
          pending.push({
            ...baseData,
            status: getStatusTag("Pending"),
            time: baseData.created_at,
            action: createActionDropdown(loanDoc, "Pending")
          });
          break;
        case "Document Collection":
          docCollection.push({
            ...baseData,
            status: getStatusTag("Document Collection", documentPercentage),
            time: baseData.updated_at,
            document: createDocumentViewButton(loanDoc, documents),
            action: createActionDropdown(loanDoc, "Document Collection")
          });
          break;
        case "Document Verification":
          docVerification.push({
            ...baseData,
            status: getStatusTag("Document Verification"),
            time: baseData.updated_at,
            document: createDocumentViewButton(loanDoc, documents),
            action: createActionDropdown(loanDoc, "Document Verification")
          });
          break;
        case "Completed":
          completed.push({
            ...baseData,
            status: getStatusTag("Completed"),
            time: baseData.updated_at,
            action: createActionDropdown(loanDoc, "Completed")
          });
          break;
        default:
          pending.push({
            ...baseData,
            status: getStatusTag("Pending"),
            time: baseData.created_at,
            action: createActionDropdown(loanDoc, "Pending")
          });
      }
    });
    await Promise.all(processPromises);
    setPendingData(pending);
    setFilteredPending(pending);
    setDocumentCollectionData(docCollection);
    setFilteredDocCollection(docCollection);
    setDocumentVerificationData(docVerification);
    setFilteredDocVerification(docVerification);
    setCompletedData(completed);
    setFilteredCompleted(completed);
    const tempActive = {};
    pending.forEach((item) => {
      tempActive[item.key] = {
        info: {
          status: false,
          loan_code: item.loan_code,
          name: item.customer_name
        }
      };
    });
    setActiveUserData(tempActive);
  };
  const createDocumentViewButton = (loanDoc, documents) => {
    return /* @__PURE__ */ jsxDEV(
      Button,
      {
        type: "link",
        icon: /* @__PURE__ */ jsxDEV(IoEye, { className: "text-lg" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 251,
          columnNumber: 15
        }, this),
        onClick: () => handleViewDocuments(loanDoc, documents),
        className: "text-emerald-600 hover:text-emerald-700",
        children: "View"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
        lineNumber: 249,
        columnNumber: 7
      },
      this
    );
  };
  const createActionDropdown = (loanDoc, status) => {
    const menuItems = [];
    switch (status) {
      case "Pending":
        menuItems.push({
          key: "1",
          label: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "text-violet-600",
              onClick: () => updateLoanDocumentStatus(loanDoc._id, "Document Collection"),
              children: "Start Document Collection"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 269,
              columnNumber: 11
            },
            this
          )
        });
        menuItems.push({
          key: "2",
          label: /* @__PURE__ */ jsxDEV(
            Popconfirm,
            {
              title: "Delete Loan Document",
              description: "Are you sure you want to delete this loan document?",
              onConfirm: () => handleDeleteLoanDocument(loanDoc._id),
              okText: "Yes",
              cancelText: "No",
              children: /* @__PURE__ */ jsxDEV("div", { className: "text-red-600", children: "Delete" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                lineNumber: 287,
                columnNumber: 29
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 280,
              columnNumber: 11
            },
            this
          )
        });
        break;
      case "Document Collection":
        menuItems.push({
          key: "1",
          label: /* @__PURE__ */ jsxDEV(
            "a",
            {
              onClick: () => {
                window.open(
                  `/legals-menu/user-document?userId=${loanDoc.user_id?._id || loanDoc.loanId?.user_id}&loanId=${loanDoc._id}`,
                  "_blank"
                );
              },
              className: "text-amber-600",
              children: "Upload Documents"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 297,
              columnNumber: 11
            },
            this
          )
        });
        menuItems.push({
          key: "2",
          label: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "text-violet-600",
              onClick: () => updateLoanDocumentStatus(loanDoc._id, "Document Verification"),
              children: "Move to Verification"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 313,
              columnNumber: 11
            },
            this
          )
        });
        menuItems.push({
          key: "3",
          label: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "text-emerald-600",
              onClick: () => updateLoanDocumentStatus(loanDoc._id, "Completed"),
              children: "Mark Completed"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 324,
              columnNumber: 11
            },
            this
          )
        });
        break;
      case "Document Verification":
        menuItems.push({
          key: "1",
          label: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: "text-emerald-600",
              onClick: () => updateLoanDocumentStatus(loanDoc._id, "Completed"),
              children: "Verification Completed"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 338,
              columnNumber: 11
            },
            this
          )
        });
        break;
      case "Completed":
        break;
    }
    return /* @__PURE__ */ jsxDEV(
      Dropdown,
      {
        menu: { items: menuItems },
        placement: "bottomLeft",
        trigger: ["click"],
        children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "cursor-pointer text-xl text-gray-600 hover:text-violet-600" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 359,
          columnNumber: 17
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
        lineNumber: 354,
        columnNumber: 7
      },
      this
    );
  };
  const getStatusTag = (status, percentage = null) => {
    const baseClass = "inline-flex items-center justify-center px-3 py-1 text-xs font-medium rounded-full whitespace-nowrap min-w-[120px]";
    switch (status) {
      case "Pending":
        return /* @__PURE__ */ jsxDEV("span", { className: `${baseClass} bg-slate-100 text-slate-600`, children: "Pending" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 372,
          columnNumber: 11
        }, this);
      case "Document Collection":
        return /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center gap-1", children: [
          /* @__PURE__ */ jsxDEV("span", { className: `${baseClass} bg-amber-100 text-amber-700`, children: "DOC Collection" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
            lineNumber: 380,
            columnNumber: 25
          }, this),
          percentage !== null && /* @__PURE__ */ jsxDEV(
            Progress,
            {
              type: "circle",
              percent: percentage,
              width: 40,
              strokeColor: percentage === 100 ? "#10b981" : percentage >= 70 ? "#f59e0b" : "#ef4444",
              format: (percent) => /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold", children: [
                percent,
                "%"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                lineNumber: 396,
                columnNumber: 15
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 384,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 379,
          columnNumber: 11
        }, this);
      case "Document Verification":
        return /* @__PURE__ */ jsxDEV("span", { className: `${baseClass} bg-violet-100 text-violet-700`, children: "DOC Verification" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 405,
          columnNumber: 11
        }, this);
      case "Completed":
        return /* @__PURE__ */ jsxDEV("span", { className: `${baseClass} bg-emerald-100 text-emerald-700`, children: "Completed" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 412,
          columnNumber: 11
        }, this);
      default:
        return /* @__PURE__ */ jsxDEV("span", { className: `${baseClass} bg-gray-100 text-gray-500`, children: status }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 419,
          columnNumber: 11
        }, this);
    }
  };
  const updateLoanDocumentStatus = async (loanDocId, newStatus) => {
    try {
      await api.patch(`/v1/admin/loan-documents/status/${loanDocId}`, {
        status: newStatus
      });
      message.success(`Status updated to ${newStatus}`);
      fetchAllLoanDocuments();
      setActiveUserData({});
      setSelectAll(false);
    } catch (error) {
      message.error(error.response?.data?.message || "Failed to update status");
    }
  };
  const handleDeleteLoanDocument = async (loanDocId) => {
    try {
      await api.delete(`/v1/admin/loan-documents/delete/${loanDocId}`);
      message.success("Loan document deleted successfully");
      fetchAllLoanDocuments();
    } catch (error) {
      message.error(error.response?.data?.message || "Failed to delete loan document");
    }
  };
  const handleViewDocuments = async (loanDoc, existingDocuments = null) => {
    try {
      let documents = existingDocuments;
      if (!documents || documents.length === 0) {
        const userId = loanDoc.loan_id?._id || loanDoc.user_id || loanDoc.loanId?.user_id;
        if (!userId) {
          message.error("Customer information not found");
          return;
        }
        const response = await api.get(`/v1/admin/user-documents/${userId}`);
        if (response.data && response.data.data) {
          let userDoc = response.data.data;
          if (Array.isArray(userDoc) && userDoc.length > 0) {
            userDoc = userDoc[0];
          }
          documents = transformUserDocumentsToArray(userDoc);
        } else {
          documents = [];
        }
      }
      setCurrentDocuments(documents);
      setCurrentLoanForDocs(loanDoc);
      setShowDocumentModal(true);
    } catch (error) {
      console.error("Error fetching documents:", error);
      message.error("Failed to fetch documents");
    }
  };
  const transformUserDocumentsToArray = (userDoc) => {
    if (!userDoc) return [];
    const documents = [];
    const docMappings = [
      { key: "user_profile_photo", label: "Photo", isImage: true },
      { key: "user_adharcard_front_photo", label: "Aadhar Card (Front)", isImage: true },
      { key: "user_adharcard_back_photo", label: "Aadhar Card (Back)", isImage: true },
      { key: "user_pancard_photo", label: "PAN Card", isImage: true },
      { key: "user_cheque_leaf", label: "Cheque Leaf", isImage: true },
      { key: "bank_statement_month", label: "Bank Statement", isImage: false },
      { key: "bank_passbook_photo", label: "Passbook Photo", isImage: true },
      { key: "business_document_proof", label: "Business Proof", isImage: false },
      { key: "user_salary_slip", label: "Salary Slip", isImage: false },
      { key: "user_nominee_adharcard_front_photo", label: "Nominee Aadhar (Front)", isImage: true },
      { key: "user_nominee_adharcard_back_photo", label: "Nominee Aadhar (Back)", isImage: true },
      { key: "user_nominee_pancard_photo", label: "Nominee PAN Card", isImage: true }
    ];
    docMappings.forEach((mapping) => {
      if (userDoc[mapping.key]) {
        documents.push({
          document_type: mapping.label,
          file_url: userDoc[mapping.key],
          description: `${mapping.label} document`,
          isImage: mapping.isImage
        });
      }
    });
    return documents;
  };
  const calculateDocumentPercentage = (documents) => {
    if (!documents || documents.length === 0) return 0;
    const uploadedDocs = documents.filter(
      (doc) => doc.file_url && doc.document_type !== "Document Reference"
    );
    const totalRequiredDocs = REQUIRED_LOAN_DOCUMENTS.length;
    const percentage = uploadedDocs.length / totalRequiredDocs * 100;
    return Math.round(percentage);
  };
  const handlePreview = (imageUrl, title) => {
    setPreviewImage(imageUrl);
    setPreviewTitle(title);
  };
  const handleCancelPreview = () => {
    setPreviewImage(null);
    setPreviewTitle("");
  };
  const handleDocumentAction = async (action) => {
    if (!currentLoanForDocs) return;
    try {
      let newStatus = "";
      switch (action) {
        case "verify":
          newStatus = "Document Verification";
          break;
        case "complete":
          newStatus = "Completed";
          break;
        case "pending":
          newStatus = "Pending";
          break;
        default:
          break;
      }
      if (newStatus) {
        await updateLoanDocumentStatus(currentLoanForDocs._id || currentLoanForDocs.key, newStatus);
      }
      setShowDocumentModal(false);
      setCurrentDocuments([]);
      setCurrentLoanForDocs(null);
    } catch (error) {
      console.error("Error updating document status:", error);
      message.error("Failed to update document status");
    }
  };
  const handleDateFilter = (dates) => {
    if (!dates || !dates[0] || !dates[1]) {
      setDateRange([null, null]);
      resetFilters();
      return;
    }
    setDateRange(dates);
    setFilteredPending(filterDataByDate(pendingData, dates));
    setFilteredDocCollection(filterDataByDate(documentCollectionData, dates));
    setFilteredDocVerification(filterDataByDate(documentVerificationData, dates));
    setFilteredCompleted(filterDataByDate(completedData, dates));
  };
  const filterDataByDate = (data, dates) => {
    if (!dates || !dates[0] || !dates[1]) return data;
    const [start, end] = dates;
    return data.filter((item) => {
      let itemDate = item.time || item.created_at;
      if (!itemDate) return true;
      if (typeof itemDate === "string" && itemDate.includes("T")) {
        itemDate = itemDate.split("T")[0];
      }
      const docDate = dayjs(itemDate);
      return docDate.isAfter(start.subtract(1, "day")) && docDate.isBefore(end.add(1, "day"));
    });
  };
  const resetFilters = () => {
    setFilteredPending(pendingData);
    setFilteredDocCollection(documentCollectionData);
    setFilteredDocVerification(documentVerificationData);
    setFilteredCompleted(completedData);
  };
  const resetAllTabData = () => {
    setPendingData([]);
    setFilteredPending([]);
    setDocumentCollectionData([]);
    setFilteredDocCollection([]);
    setDocumentVerificationData([]);
    setFilteredDocVerification([]);
    setCompletedData([]);
    setFilteredCompleted([]);
  };
  const handleBulkStatusUpdate = (newStatus) => {
    const selectedItems = filteredPending.filter(
      (item) => activeUserData[item.key]?.info?.status
    );
    if (selectedItems.length === 0) {
      message.warning("Please select loan documents to update");
      return;
    }
    Modal.confirm({
      title: `Bulk Update Confirmation`,
      content: `You are about to update status to "${newStatus}" for ${selectedItems.length} loan document(s). Are you sure?`,
      okText: "Yes, Update",
      cancelText: "No",
      onOk: async () => {
        try {
          await Promise.all(
            selectedItems.map(
              (item) => updateLoanDocumentStatus(item.key, newStatus)
            )
          );
          message.success(
            `${selectedItems.length} loan documents moved to ${newStatus}`
          );
        } catch (error) {
          message.error("Failed to update some loan documents");
        }
      }
    });
  };
  const handleBulkDelete = () => {
    const selectedItems = filteredPending.filter(
      (item) => activeUserData[item.key]?.info?.status
    );
    if (selectedItems.length === 0) {
      message.warning("Please select loan documents to delete");
      return;
    }
    Modal.confirm({
      title: `Delete Confirmation`,
      content: `Are you sure you want to delete ${selectedItems.length} loan document(s)? This action cannot be undone.`,
      okText: "Yes, Delete",
      okType: "danger",
      cancelText: "No",
      onOk: async () => {
        try {
          await Promise.all(
            selectedItems.map((item) => handleDeleteLoanDocument(item.key))
          );
          message.success(
            `${selectedItems.length} loan documents deleted successfully`
          );
        } catch (error) {
          message.error("Failed to delete some loan documents");
        }
      }
    });
  };
  const handleCheckboxChange = (item) => {
    setActiveUserData((prev) => ({
      ...prev,
      [item.key]: {
        info: {
          status: !prev[item.key]?.info?.status,
          loan_code: item.loan_code,
          name: item.customer_name
        }
      }
    }));
  };
  const handleSelectAllChange = (e) => {
    const checked = e.target.checked;
    setSelectAll(checked);
    const updated = { ...activeUserData };
    filteredPending.forEach((item) => {
      updated[item.key] = {
        info: {
          status: checked,
          loan_code: item.loan_code,
          name: item.customer_name
        }
      };
    });
    setActiveUserData(updated);
  };
  const selectedCount = useMemo(() => {
    return filteredPending.filter(
      (item) => activeUserData[item.key]?.info?.status
    ).length;
  }, [filteredPending, activeUserData]);
  useEffect(() => {
    const allChecked = filteredPending.length > 0 && filteredPending.every((item) => activeUserData[item.key]?.info?.status);
    setSelectAll(allChecked);
  }, [filteredPending, activeUserData]);
  const totalLoanAmount = filteredPending.reduce(
    (sum, item) => sum + (parseFloat(item.loan_amount) || 0),
    0
  );
  const formattedPendingData = useMemo(() => {
    return filteredPending.map((item) => ({
      ...item,
      checkbox: /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "checkbox",
          checked: activeUserData[item.key]?.info?.status || false,
          onChange: () => handleCheckboxChange(item),
          className: "w-4 h-4 cursor-pointer accent-violet-600"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 757,
          columnNumber: 7
        },
        this
      ),
      loan_amount: /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-emerald-700", children: [
        "₹",
        (parseFloat(item.loan_amount) || 0).toLocaleString("en-IN")
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
        lineNumber: 765,
        columnNumber: 7
      }, this)
    }));
  }, [filteredPending, activeUserData]);
  const onGlobalSearchChangeHandler = (e) => {
    setSearchText(e.target.value);
  };
  const pendingColumns = [
    { key: "checkbox", header: "Select" },
    { key: "id", header: "SL. NO" },
    { key: "loan_code", header: "Loan Code" },
    { key: "customer_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "loan_amount", header: "Loan Amount" },
    { key: "status", header: "Status" },
    { key: "time", header: "Created Date" },
    { key: "action", header: "Action" }
  ];
  const docCollectionColumns = [
    { key: "id", header: "SL. NO" },
    { key: "loan_code", header: "Loan Code" },
    { key: "customer_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "loan_amount", header: "Loan Amount" },
    { key: "status", header: "Status" },
    { key: "time", header: "Updated Date" },
    { key: "document", header: "Document" },
    { key: "action", header: "Action" }
  ];
  const docVerificationColumns = [
    { key: "id", header: "SL. NO" },
    { key: "loan_code", header: "Loan Code" },
    { key: "customer_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "loan_amount", header: "Loan Amount" },
    { key: "status", header: "Status" },
    { key: "time", header: "Updated Date" },
    { key: "document", header: "Document" },
    { key: "action", header: "Action" }
  ];
  const completedColumns = [
    { key: "id", header: "SL. NO" },
    { key: "loan_code", header: "Loan Code" },
    { key: "customer_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "loan_amount", header: "Loan Amount" },
    { key: "status", header: "Status" },
    { key: "time", header: "Completed Date" },
    { key: "action", header: "Action" }
  ];
  const tabs = [
    {
      id: "pending",
      label: "Pending",
      count: filteredPending.length,
      icon: /* @__PURE__ */ jsxDEV(IoWallet, { className: "text-slate-500" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
        lineNumber: 831,
        columnNumber: 11
      }, this)
    },
    {
      id: "document_collection",
      label: "Document Collection",
      count: filteredDocCollection.length,
      icon: /* @__PURE__ */ jsxDEV(IoDocumentText, { className: "text-amber-500" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
        lineNumber: 837,
        columnNumber: 11
      }, this)
    },
    {
      id: "document_verification",
      label: "Document Verification",
      count: filteredDocVerification.length,
      icon: /* @__PURE__ */ jsxDEV(IoCheckmarkCircle, { className: "text-violet-500" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
        lineNumber: 843,
        columnNumber: 11
      }, this)
    },
    {
      id: "completed",
      label: "Completed",
      count: filteredCompleted.length,
      icon: /* @__PURE__ */ jsxDEV(IoFlag, { className: "text-emerald-500" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
        lineNumber: 849,
        columnNumber: 11
      }, this)
    }
  ];
  const renderTabContent = () => {
    if (isLoading) {
      return /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center py-10", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
        lineNumber: 858,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
        lineNumber: 857,
        columnNumber: 9
      }, this);
    }
    switch (activeTab) {
      case "pending":
        return /* @__PURE__ */ jsxDEV(Fragment, { children: [
          selectedCount > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-violet-50 to-purple-50 border border-violet-200 rounded-lg shadow p-4 mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row justify-between items-center gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-600 text-white rounded-full h-10 w-10 flex items-center justify-center font-bold text-lg shadow-md", children: selectedCount }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                lineNumber: 871,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 text-lg", children: "Item(s) Selected" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                lineNumber: 874,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 870,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-3 justify-center", children: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "primary",
                  className: "bg-violet-600 hover:bg-violet-700 border-violet-600",
                  onClick: () => handleBulkStatusUpdate("Document Collection"),
                  children: "Start Document Collection"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                  lineNumber: 879,
                  columnNumber: 41
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  danger: true,
                  onClick: handleBulkDelete,
                  className: "hover:bg-red-600",
                  children: "Delete Selected"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                  lineNumber: 886,
                  columnNumber: 41
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 878,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
            lineNumber: 869,
            columnNumber: 33
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
            lineNumber: 868,
            columnNumber: 13
          }, this),
          filteredPending?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mb-4 p-3 bg-gray-50 rounded-lg flex items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "checkbox",
                className: "w-4 h-4 cursor-pointer accent-violet-600",
                checked: selectAll,
                onChange: handleSelectAllChange
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                lineNumber: 900,
                columnNumber: 33
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600", children: [
              selectAll ? "Deselect All" : "Select All",
              " (",
              filteredPending.length,
              " items)"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 906,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
            lineNumber: 899,
            columnNumber: 13
          }, this),
          loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center py-10", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
            lineNumber: 915,
            columnNumber: 33
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
            lineNumber: 914,
            columnNumber: 13
          }, this) : filteredPending?.length > 0 ? /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: filterOption(formattedPendingData, searchText),
              columns: pendingColumns,
              exportedFileName: "Loan_Pending.csv"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 918,
              columnNumber: 13
            },
            this
          ) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-10 text-gray-500", children: "No pending loan documents available." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
            lineNumber: 924,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 866,
          columnNumber: 11
        }, this);
      case "document_collection":
        return filteredDocCollection?.length > 0 ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: filterOption(filteredDocCollection, searchText),
            columns: docCollectionColumns,
            exportedFileName: "Loan_Document_Collection.csv"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
            lineNumber: 933,
            columnNumber: 9
          },
          this
        ) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-10 text-gray-500", children: "No records in Document Collection." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 939,
          columnNumber: 9
        }, this);
      case "document_verification":
        return filteredDocVerification?.length > 0 ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: filterOption(filteredDocVerification, searchText),
            columns: docVerificationColumns,
            exportedFileName: "Loan_Document_Verification.csv"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
            lineNumber: 946,
            columnNumber: 9
          },
          this
        ) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-10 text-gray-500", children: "No records in Document Verification." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 952,
          columnNumber: 9
        }, this);
      case "completed":
        return filteredCompleted?.length > 0 ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: filterOption(filteredCompleted, searchText),
            columns: completedColumns,
            exportedFileName: "Loan_Completed.csv"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
            lineNumber: 959,
            columnNumber: 9
          },
          this
        ) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-10 text-gray-500", children: "No completed records." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 965,
          columnNumber: 9
        }, this);
      default:
        return null;
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        open: previewImage !== null,
        title: previewTitle,
        footer: null,
        onCancel: handleCancelPreview,
        width: "auto",
        style: { maxWidth: "90vw" },
        children: /* @__PURE__ */ jsxDEV("img", { alt: previewTitle, style: { width: "100%" }, src: previewImage }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 985,
          columnNumber: 17
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
        lineNumber: 977,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 989,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
        lineNumber: 993,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 996,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold text-gray-900", children: "Loan Documentation Management" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 999,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: "Track and manage loan documentation processes" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 1002,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
            lineNumber: 998,
            columnNumber: 25
          }, this),
          activeTab === "pending" && /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-3 bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-xl shadow-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-emerald-600", children: /* @__PURE__ */ jsxDEV(FaFileContract, { className: "w-5 h-5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 1011,
              columnNumber: 41
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 1010,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-emerald-600 font-medium", children: "Total Loan Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                lineNumber: 1014,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-gray-900", children: [
                "₹",
                totalLoanAmount.toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                lineNumber: 1017,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 1013,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "h-10 border-l border-emerald-300" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 1021,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-violet-600 font-medium", children: "Pending Documents" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                lineNumber: 1023,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-violet-700", children: filteredPending.length }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                lineNumber: 1026,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 1022,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
            lineNumber: 1009,
            columnNumber: 33
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
            lineNumber: 1008,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 997,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-4 inline-block p-3 bg-white border border-gray-200 rounded-md shadow-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-600", children: "Date Filter:" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
            lineNumber: 1037,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(
            RangePicker,
            {
              onChange: handleDateFilter,
              format: "YYYY-MM-DD",
              placeholder: ["Start Date", "End Date"],
              className: "w-56",
              size: "small"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 1040,
              columnNumber: 29
            },
            this
          ),
          dateRange?.[0] && dateRange?.[1] && /* @__PURE__ */ jsxDEV(
            Button,
            {
              onClick: () => {
                setDateRange([null, null]);
                resetFilters();
              },
              size: "small",
              className: "text-violet-600 px-2",
              children: "Clear Filter"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 1048,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 1036,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 1035,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "border-b border-gray-200", children: /* @__PURE__ */ jsxDEV("nav", { className: "flex space-x-8", "aria-label": "Tabs", children: tabs.map(
          (tab) => /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setActiveTab(tab.id),
              className: `group inline-flex items-center py-4 px-1 border-b-2 font-medium text-sm ${activeTab === tab.id ? "border-violet-500 text-violet-600" : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"}`,
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "mr-2 text-lg", children: tab.icon }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                  lineNumber: 1074,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: tab.label }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                  lineNumber: 1075,
                  columnNumber: 41
                }, this),
                tab.count > 0 && /* @__PURE__ */ jsxDEV(
                  "span",
                  {
                    className: `ml-3 py-0.5 px-2 rounded-full text-xs font-medium ${activeTab === tab.id ? "bg-violet-100 text-violet-600" : "bg-gray-100 text-gray-600"}`,
                    children: tab.count
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                    lineNumber: 1077,
                    columnNumber: 19
                  },
                  this
                )
              ]
            },
            tab.id,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 1066,
              columnNumber: 17
            },
            this
          )
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 1064,
          columnNumber: 29
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 1063,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 1062,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: renderTabContent() }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 1092,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
        lineNumber: 995,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(
        ModalComponent,
        {
          isVisible: showDocumentModal,
          onClose: () => {
            setShowDocumentModal(false);
            setCurrentDocuments([]);
            setCurrentLoanForDocs(null);
          },
          width: "900px",
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "max-h-[70vh] overflow-y-auto space-y-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-100 rounded-xl p-4 shadow-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 text-sm", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 text-xs", children: "Customer Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                    lineNumber: 1109,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800", children: currentLoanForDocs?.loan_data?.user_id?.full_name || currentLoanForDocs?.loan_data?.loanId?.user_id?.full_name || "N/A" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                    lineNumber: 1110,
                    columnNumber: 37
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                  lineNumber: 1108,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 text-xs", children: "Phone Number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                    lineNumber: 1115,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800", children: currentLoanForDocs?.loan_data?.user_id?.phone_number || currentLoanForDocs?.loan_data?.loanId?.user_id?.phone_number || "N/A" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                    lineNumber: 1116,
                    columnNumber: 37
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                  lineNumber: 1114,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-500 text-xs", children: "Loan Code" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                    lineNumber: 1121,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800", children: currentLoanForDocs?.loan_data?.loanId?.loan_code || "N/A" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                    lineNumber: 1122,
                    columnNumber: 37
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                  lineNumber: 1120,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                lineNumber: 1107,
                columnNumber: 29
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                lineNumber: 1106,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-gray-200 rounded-xl p-4 shadow-sm", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-3", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-700", children: "Document Upload Progress" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                    lineNumber: 1131,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "span",
                    {
                      className: `text-sm font-semibold ${calculateDocumentPercentage(currentDocuments) === 100 ? "text-emerald-600" : calculateDocumentPercentage(currentDocuments) >= 70 ? "text-amber-600" : "text-red-600"}`,
                      children: [
                        calculateDocumentPercentage(currentDocuments),
                        "%"
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                      lineNumber: 1134,
                      columnNumber: 33
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                  lineNumber: 1130,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Progress,
                  {
                    percent: calculateDocumentPercentage(currentDocuments),
                    size: "small",
                    strokeColor: {
                      "0%": "#ef4444",
                      "70%": "#f59e0b",
                      "100%": "#10b981"
                    }
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                    lineNumber: 1145,
                    columnNumber: 29
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between mt-3 text-xs text-gray-600", children: [
                  /* @__PURE__ */ jsxDEV("span", { children: [
                    "Uploaded:",
                    " ",
                    currentDocuments.filter(
                      (doc) => doc.file_url && doc.document_type !== "Document Reference"
                    ).length,
                    " ",
                    "/ ",
                    REQUIRED_LOAN_DOCUMENTS.length
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                    lineNumber: 1155,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { children: [
                    "Remaining:",
                    " ",
                    REQUIRED_LOAN_DOCUMENTS.length - currentDocuments.filter(
                      (doc) => doc.file_url && doc.document_type !== "Document Reference"
                    ).length
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                    lineNumber: 1162,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                  lineNumber: 1154,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                lineNumber: 1129,
                columnNumber: 25
              }, this),
              currentDocuments.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: currentDocuments.map(
                (doc, index) => /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "border border-gray-200 rounded-xl p-4 hover:shadow-md transition bg-white",
                    children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start mb-2", children: [
                        /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 text-sm", children: doc.document_type }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                          lineNumber: 1180,
                          columnNumber: 45
                        }, this),
                        doc.file_url && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
                          /* @__PURE__ */ jsxDEV(
                            IoEye,
                            {
                              onClick: () => handlePreview(doc.file_url, doc.document_type),
                              className: "text-violet-600 cursor-pointer text-lg hover:scale-110 transition-transform"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                              lineNumber: 1185,
                              columnNumber: 53
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV(
                            "a",
                            {
                              href: doc.file_url,
                              target: "_blank",
                              rel: "noopener noreferrer",
                              children: /* @__PURE__ */ jsxDEV(IoDownload, { className: "text-emerald-600 text-lg hover:scale-110 transition-transform" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                                lineNumber: 1194,
                                columnNumber: 57
                              }, this)
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                              lineNumber: 1189,
                              columnNumber: 53
                            },
                            this
                          )
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                          lineNumber: 1184,
                          columnNumber: 19
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                        lineNumber: 1179,
                        columnNumber: 41
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-2 h-32 flex items-center justify-center", children: doc.isImage && doc.file_url ? /* @__PURE__ */ jsxDEV(
                        "img",
                        {
                          src: doc.file_url,
                          alt: doc.document_type,
                          className: "h-full object-contain cursor-pointer",
                          onClick: () => handlePreview(doc.file_url, doc.document_type)
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                          lineNumber: 1201,
                          columnNumber: 19
                        },
                        this
                      ) : doc.file_url ? /* @__PURE__ */ jsxDEV(IoDocument, { className: "text-gray-400 text-4xl" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                        lineNumber: 1208,
                        columnNumber: 19
                      }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-400", children: "No file uploaded" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                        lineNumber: 1210,
                        columnNumber: 19
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                        lineNumber: 1199,
                        columnNumber: 41
                      }, this)
                    ]
                  },
                  index,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                    lineNumber: 1175,
                    columnNumber: 15
                  },
                  this
                )
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                lineNumber: 1173,
                columnNumber: 13
              }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-10", children: [
                /* @__PURE__ */ jsxDEV(IoDocument, { className: "text-gray-400 text-5xl mx-auto mb-3" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                  lineNumber: 1220,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: "No documents uploaded for this loan." }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                  lineNumber: 1221,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                lineNumber: 1219,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 1105,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3 border-t pt-4 mt-4", children: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  onClick: () => handleDocumentAction("pending"),
                  className: "bg-slate-500 hover:bg-slate-600 text-white",
                  children: "Move to Pending"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                  lineNumber: 1229,
                  columnNumber: 25
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  onClick: () => handleDocumentAction("verify"),
                  type: "primary",
                  className: "bg-violet-600 hover:bg-violet-700",
                  disabled: calculateDocumentPercentage(currentDocuments) < 100,
                  children: [
                    "Move to Verification",
                    calculateDocumentPercentage(currentDocuments) < 100 && /* @__PURE__ */ jsxDEV("span", { className: "ml-2 text-xs opacity-75", children: [
                      "(",
                      calculateDocumentPercentage(currentDocuments),
                      "% complete)"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                      lineNumber: 1243,
                      columnNumber: 15
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                  lineNumber: 1235,
                  columnNumber: 25
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  onClick: () => handleDocumentAction("complete"),
                  className: "bg-emerald-600 text-white hover:bg-emerald-700",
                  children: "Mark Completed"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
                  lineNumber: 1248,
                  columnNumber: 25
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 1228,
              columnNumber: 21
            }, this),
            calculateDocumentPercentage(currentDocuments) < 100 && currentDocuments.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-3 text-center", children: /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-amber-600", children: [
              "⚠️ Please upload all required documents (",
              REQUIRED_LOAN_DOCUMENTS.length - currentDocuments.filter(
                (doc) => doc.file_url && doc.document_type !== "Document Reference"
              ).length,
              " ",
              "remaining) before verification"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 1258,
              columnNumber: 33
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
              lineNumber: 1257,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
          lineNumber: 1096,
          columnNumber: 17
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
      lineNumber: 988,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx",
    lineNumber: 976,
    columnNumber: 5
  }, this);
}
_s(LoanDocumentation, "Zvvos4+ztL/vZT4SYP3S0tuwDrg=", false, function() {
  return [useNavigate];
});
_c = LoanDocumentation;
export default LoanDocumentation;
var _c;
$RefreshReg$(_c, "LoanDocumentation");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/LoanDocumentation.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMFBzQixTQXVtQkYsVUF2bUJFOzJCQTFQdEI7QUFBa0IsTUFBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQSxXQUFXQyxVQUFVQyxlQUFlO0FBQzdDLFNBQVNDLG1CQUFtQjtBQUM1QixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsU0FBUztBQUNoQjtBQUFBLEVBQ0lDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0c7QUFDUCxTQUFTQyxnQkFBZ0I7QUFDekI7QUFBQSxFQUNJQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNHO0FBQ1AsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLG9CQUFvQjtBQUMzQixTQUFTQyxhQUFhQyxzQkFBc0I7QUFDNUMsU0FBU0MsY0FBYztBQUN2QixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLGdCQUFnQjtBQUV2QixNQUFNLEVBQUVDLFlBQVksSUFBSWxCO0FBR3hCLE1BQU1tQiwwQkFBMEI7QUFBQSxFQUM1QixFQUFFQyxLQUFLLHNCQUFzQkMsT0FBTyxRQUFRO0FBQUEsRUFDNUMsRUFBRUQsS0FBSyw4QkFBOEJDLE9BQU8sc0JBQXNCO0FBQUEsRUFDbEUsRUFBRUQsS0FBSyw2QkFBNkJDLE9BQU8scUJBQXFCO0FBQUEsRUFDaEUsRUFBRUQsS0FBSyxzQkFBc0JDLE9BQU8sV0FBVztBQUFBLEVBQy9DLEVBQUVELEtBQUssb0JBQW9CQyxPQUFPLGNBQWM7QUFBQSxFQUNoRCxFQUFFRCxLQUFLLHdCQUF3QkMsT0FBTyxpQkFBaUI7QUFBQSxFQUN2RCxFQUFFRCxLQUFLLHVCQUF1QkMsT0FBTyxpQkFBaUI7QUFBQSxFQUN0RCxFQUFFRCxLQUFLLDJCQUEyQkMsT0FBTyxpQkFBaUI7QUFBQSxFQUMxRCxFQUFFRCxLQUFLLG9CQUFvQkMsT0FBTyxjQUFjO0FBQUEsRUFDaEQsRUFBRUQsS0FBSyxzQ0FBc0NDLE9BQU8seUJBQXlCO0FBQUEsRUFDN0UsRUFBRUQsS0FBSyxxQ0FBcUNDLE9BQU8sd0JBQXdCO0FBQUEsRUFDM0UsRUFBRUQsS0FBSyw4QkFBOEJDLE9BQU8sbUJBQW1CO0FBQUM7QUFHcEUsU0FBU0Msb0JBQW9CO0FBQUFDLEtBQUE7QUFDekIsUUFBTUMsV0FBV25DLFlBQVk7QUFDN0IsUUFBTSxDQUFDb0MsU0FBU0MsVUFBVSxJQUFJdkMsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ3dDLFlBQVlDLGFBQWEsSUFBSXpDLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUMwQyxXQUFXQyxZQUFZLElBQUkzQyxTQUFTLFNBQVM7QUFDcEQsUUFBTSxDQUFDNEMsV0FBV0MsWUFBWSxJQUFJN0MsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzhDLGNBQWNDLGVBQWUsSUFBSS9DLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUNnRCxjQUFjQyxlQUFlLElBQUlqRCxTQUFTLEVBQUU7QUFHbkQsUUFBTSxDQUFDa0Qsa0JBQWtCQyxtQkFBbUIsSUFBSW5ELFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUNvRCxhQUFhQyxjQUFjLElBQUlyRCxTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDc0Qsd0JBQXdCQyx5QkFBeUIsSUFBSXZELFNBQVMsRUFBRTtBQUN2RSxRQUFNLENBQUN3RCwwQkFBMEJDLDJCQUEyQixJQUFJekQsU0FBUyxFQUFFO0FBQzNFLFFBQU0sQ0FBQzBELGVBQWVDLGdCQUFnQixJQUFJM0QsU0FBUyxFQUFFO0FBR3JELFFBQU0sQ0FBQzRELGlCQUFpQkMsa0JBQWtCLElBQUk3RCxTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDOEQsdUJBQXVCQyx3QkFBd0IsSUFBSS9ELFNBQVMsRUFBRTtBQUNyRSxRQUFNLENBQUNnRSx5QkFBeUJDLDBCQUEwQixJQUFJakUsU0FBUyxFQUFFO0FBQ3pFLFFBQU0sQ0FBQ2tFLG1CQUFtQkMsb0JBQW9CLElBQUluRSxTQUFTLEVBQUU7QUFHN0QsUUFBTSxDQUFDb0UsV0FBV0MsWUFBWSxJQUFJckUsU0FBUyxDQUFDLE1BQU0sSUFBSSxDQUFDO0FBR3ZELFFBQU0sQ0FBQ3NFLGdCQUFnQkMsaUJBQWlCLElBQUl2RSxTQUFTLENBQUMsQ0FBQztBQUN2RCxRQUFNLENBQUN3RSxXQUFXQyxZQUFZLElBQUl6RSxTQUFTLEtBQUs7QUFHaEQsUUFBTSxDQUFDMEUsbUJBQW1CQyxvQkFBb0IsSUFBSTNFLFNBQVMsS0FBSztBQUNoRSxRQUFNLENBQUM0RSxrQkFBa0JDLG1CQUFtQixJQUFJN0UsU0FBUyxFQUFFO0FBQzNELFFBQU0sQ0FBQzhFLG9CQUFvQkMscUJBQXFCLElBQUkvRSxTQUFTLElBQUk7QUFFakVELFlBQVUsTUFBTTtBQUNaaUYsMEJBQXNCO0FBQUEsRUFFMUIsR0FBRyxFQUFFO0FBR0wsUUFBTUEsd0JBQXdCLFlBQVk7QUFDdENuQyxpQkFBYSxJQUFJO0FBQ2pCLFFBQUk7QUFDQSxZQUFNb0MsV0FBVyxNQUFNMUUsSUFBSTJFLElBQUksMkJBQTJCO0FBQzFELFlBQU1DLFdBQVdGLFNBQVNHLE1BQU1BLFFBQVFILFNBQVNHLFFBQVE7QUFFekQsVUFBSUMsTUFBTUMsUUFBUUgsUUFBUSxLQUFLQSxTQUFTSSxTQUFTLEdBQUc7QUFDaERwQyw0QkFBb0JnQyxRQUFRO0FBQzVCSyw2QkFBcUJMLFFBQVE7QUFBQSxNQUNqQyxPQUFPO0FBQ0hoQyw0QkFBb0IsRUFBRTtBQUN0QnNDLHdCQUFnQjtBQUFBLE1BQ3BCO0FBQUEsSUFDSixTQUFTQyxPQUFPO0FBQ1pDLGNBQVFELE1BQU0sa0NBQWtDQSxLQUFLO0FBQ3JEaEYsY0FBUWdGLE1BQU1BLE1BQU1ULFVBQVVHLE1BQU0xRSxXQUFXLGdDQUFnQztBQUMvRStFLHNCQUFnQjtBQUFBLElBQ3BCLFVBQUM7QUFDRzVDLG1CQUFhLEtBQUs7QUFBQSxJQUN0QjtBQUFBLEVBQ0o7QUFlQSxRQUFNMkMsdUJBQXVCLE9BQU9MLGFBQWE7QUFDN0MsVUFBTVMsVUFBVTtBQUNoQixVQUFNQyxnQkFBZ0I7QUFDdEIsVUFBTUMsa0JBQWtCO0FBQ3hCLFVBQU1DLFlBQVk7QUFHbEIsVUFBTUMsa0JBQWtCYixTQUFTYyxJQUFJLE9BQU9DLFNBQVNDLFFBQVE7QUFDekQsVUFBSUMscUJBQXFCO0FBQ3pCLFVBQUlDLFlBQVk7QUFHaEIsVUFBSUgsUUFBUUksV0FBVyx1QkFBdUI7QUFDMUMsY0FBTUMsU0FBU0wsUUFBUU0sU0FBU0MsT0FBT1AsUUFBUU0sV0FBV04sUUFBUVEsUUFBUUY7QUFDMUUsWUFBSUQsUUFBUTtBQUNSLGNBQUk7QUFDQSxrQkFBTUksY0FBYyxNQUFNcEcsSUFBSTJFLElBQUksNEJBQTRCcUIsTUFBTSxFQUFFO0FBQ3RFLGdCQUFJSSxZQUFZdkIsUUFBUXVCLFlBQVl2QixLQUFLQSxNQUFNO0FBQzNDLGtCQUFJd0IsVUFBVUQsWUFBWXZCLEtBQUtBO0FBQy9CLGtCQUFJQyxNQUFNQyxRQUFRc0IsT0FBTyxLQUFLQSxRQUFRckIsU0FBUyxHQUFHO0FBQzlDcUIsMEJBQVVBLFFBQVEsQ0FBQztBQUFBLGNBQ3ZCO0FBQ0FQLDBCQUFZUSw4QkFBOEJELE9BQU87QUFDakRSLG1DQUFxQlUsNEJBQTRCVCxTQUFTO0FBQUEsWUFDOUQ7QUFBQSxVQUNKLFNBQVNVLEtBQUs7QUFDVnBCLG9CQUFRRCxNQUFNLGtDQUFrQ3FCLEdBQUc7QUFBQSxVQUN2RDtBQUFBLFFBQ0o7QUFBQSxNQUNKO0FBRUEsWUFBTUMsV0FBVztBQUFBLFFBQ2IvRSxLQUFLaUUsUUFBUU87QUFBQUEsUUFDYlEsSUFBSWQsTUFBTTtBQUFBLFFBQ1ZlLFNBQVNoQixRQUFRZ0IsU0FBU1QsT0FBTztBQUFBLFFBQ2pDVSxXQUFXakIsUUFBUWdCLFNBQVNBLFdBQVc7QUFBQSxRQUN2Q0UsZUFBZWxCLFFBQVFnQixTQUFTRyxVQUFVQyxhQUFhO0FBQUEsUUFDdkRDLGNBQWNyQixRQUFRZ0IsU0FBU0csVUFBVUUsZ0JBQWdCO0FBQUEsUUFDekRDLGFBQWE7QUFBQSxRQUNiQyxZQUFZdkIsUUFBUUk7QUFBQUEsUUFDcEJvQixxQkFBcUJ0QjtBQUFBQSxRQUNyQkM7QUFBQUEsUUFDQXNCLFlBQVl6QixRQUFRMEIsV0FBV0MsTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUFLO0FBQUEsUUFDaERDLFlBQVk1QixRQUFRNkIsV0FBV0YsTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUFLO0FBQUEsUUFDaERHLFdBQVc5QjtBQUFBQTtBQUFBQSxNQUNmO0FBRUEsY0FBUUEsUUFBUUksUUFBTTtBQUFBLFFBQ2xCLEtBQUs7QUFDRFYsa0JBQVFxQyxLQUFLO0FBQUEsWUFDVCxHQUFHakI7QUFBQUEsWUFDSFYsUUFBUTRCLGFBQWEsU0FBUztBQUFBLFlBQzlCQyxNQUFNbkIsU0FBU1c7QUFBQUEsWUFDZlMsUUFBUUMscUJBQXFCbkMsU0FBUyxTQUFTO0FBQUEsVUFDbkQsQ0FBQztBQUNEO0FBQUEsUUFDSixLQUFLO0FBQ0RMLHdCQUFjb0MsS0FBSztBQUFBLFlBQ2YsR0FBR2pCO0FBQUFBLFlBQ0hWLFFBQVE0QixhQUFhLHVCQUF1QjlCLGtCQUFrQjtBQUFBLFlBQzlEK0IsTUFBTW5CLFNBQVNjO0FBQUFBLFlBQ2ZRLFVBQVVDLHlCQUF5QnJDLFNBQVNHLFNBQVM7QUFBQSxZQUNyRCtCLFFBQVFDLHFCQUFxQm5DLFNBQVMscUJBQXFCO0FBQUEsVUFDL0QsQ0FBQztBQUNEO0FBQUEsUUFDSixLQUFLO0FBQ0RKLDBCQUFnQm1DLEtBQUs7QUFBQSxZQUNqQixHQUFHakI7QUFBQUEsWUFDSFYsUUFBUTRCLGFBQWEsdUJBQXVCO0FBQUEsWUFDNUNDLE1BQU1uQixTQUFTYztBQUFBQSxZQUNmUSxVQUFVQyx5QkFBeUJyQyxTQUFTRyxTQUFTO0FBQUEsWUFDckQrQixRQUFRQyxxQkFBcUJuQyxTQUFTLHVCQUF1QjtBQUFBLFVBQ2pFLENBQUM7QUFDRDtBQUFBLFFBQ0osS0FBSztBQUNESCxvQkFBVWtDLEtBQUs7QUFBQSxZQUNYLEdBQUdqQjtBQUFBQSxZQUNIVixRQUFRNEIsYUFBYSxXQUFXO0FBQUEsWUFDaENDLE1BQU1uQixTQUFTYztBQUFBQSxZQUNmTSxRQUFRQyxxQkFBcUJuQyxTQUFTLFdBQVc7QUFBQSxVQUNyRCxDQUFDO0FBQ0Q7QUFBQSxRQUNKO0FBQ0lOLGtCQUFRcUMsS0FBSztBQUFBLFlBQ1QsR0FBR2pCO0FBQUFBLFlBQ0hWLFFBQVE0QixhQUFhLFNBQVM7QUFBQSxZQUM5QkMsTUFBTW5CLFNBQVNXO0FBQUFBLFlBQ2ZTLFFBQVFDLHFCQUFxQm5DLFNBQVMsU0FBUztBQUFBLFVBQ25ELENBQUM7QUFBQSxNQUNUO0FBQUEsSUFDSixDQUFDO0FBRUQsVUFBTXNDLFFBQVFDLElBQUl6QyxlQUFlO0FBRWpDM0MsbUJBQWV1QyxPQUFPO0FBQ3RCL0IsdUJBQW1CK0IsT0FBTztBQUMxQnJDLDhCQUEwQnNDLGFBQWE7QUFDdkM5Qiw2QkFBeUI4QixhQUFhO0FBQ3RDcEMsZ0NBQTRCcUMsZUFBZTtBQUMzQzdCLCtCQUEyQjZCLGVBQWU7QUFDMUNuQyxxQkFBaUJvQyxTQUFTO0FBQzFCNUIseUJBQXFCNEIsU0FBUztBQUc5QixVQUFNMkMsYUFBYSxDQUFDO0FBQ3BCOUMsWUFBUStDLFFBQVEsQ0FBQ0MsU0FBUztBQUN0QkYsaUJBQVdFLEtBQUszRyxHQUFHLElBQUk7QUFBQSxRQUNuQjRHLE1BQU07QUFBQSxVQUNGdkMsUUFBUTtBQUFBLFVBQ1JhLFdBQVd5QixLQUFLekI7QUFBQUEsVUFDaEIyQixNQUFNRixLQUFLeEI7QUFBQUEsUUFDZjtBQUFBLE1BQ0o7QUFBQSxJQUNKLENBQUM7QUFDRDdDLHNCQUFrQm1FLFVBQVU7QUFBQSxFQUNoQztBQUdBLFFBQU1ILDJCQUEyQkEsQ0FBQ3JDLFNBQVNHLGNBQWM7QUFDckQsV0FDSTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csTUFBSztBQUFBLFFBQ0wsTUFBTSx1QkFBQyxTQUFNLFdBQVUsYUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQjtBQUFBLFFBQ2hDLFNBQVMsTUFBTTBDLG9CQUFvQjdDLFNBQVNHLFNBQVM7QUFBQSxRQUNyRCxXQUFVO0FBQUEsUUFBeUM7QUFBQTtBQUFBLE1BSnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9BO0FBQUEsRUFFUjtBQUdBLFFBQU1nQyx1QkFBdUJBLENBQUNuQyxTQUFTSSxXQUFXO0FBQzlDLFVBQU0wQyxZQUFZO0FBRWxCLFlBQVExQyxRQUFNO0FBQUEsTUFDVixLQUFLO0FBQ0QwQyxrQkFBVWYsS0FBSztBQUFBLFVBQ1hoRyxLQUFLO0FBQUEsVUFDTEMsT0FDSTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csV0FBVTtBQUFBLGNBQ1YsU0FBUyxNQUFNK0cseUJBQXlCL0MsUUFBUU8sS0FBSyxxQkFBcUI7QUFBQSxjQUFFO0FBQUE7QUFBQSxZQUZoRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFFBRVIsQ0FBQztBQUNEdUMsa0JBQVVmLEtBQUs7QUFBQSxVQUNYaEcsS0FBSztBQUFBLFVBQ0xDLE9BQ0k7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE9BQU07QUFBQSxjQUNOLGFBQVk7QUFBQSxjQUNaLFdBQVcsTUFBTWdILHlCQUF5QmhELFFBQVFPLEdBQUc7QUFBQSxjQUNyRCxRQUFPO0FBQUEsY0FDUCxZQUFXO0FBQUEsY0FFWCxpQ0FBQyxTQUFJLFdBQVUsZ0JBQWUsc0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9DO0FBQUE7QUFBQSxZQVB4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLFFBRVIsQ0FBQztBQUNEO0FBQUEsTUFFSixLQUFLO0FBQ0R1QyxrQkFBVWYsS0FBSztBQUFBLFVBQ1hoRyxLQUFLO0FBQUEsVUFDTEMsT0FDSTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csU0FBUyxNQUFNO0FBQ1hpSCx1QkFBT0M7QUFBQUEsa0JBQ0gscUNBQXFDbEQsUUFBUU0sU0FBU0MsT0FBT1AsUUFBUVEsUUFBUUYsT0FBTyxXQUFXTixRQUFRTyxHQUFHO0FBQUEsa0JBQzFHO0FBQUEsZ0JBQ0o7QUFBQSxjQUNKO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FBZ0I7QUFBQTtBQUFBLFlBUDlCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBO0FBQUEsUUFFUixDQUFDO0FBQ0R1QyxrQkFBVWYsS0FBSztBQUFBLFVBQ1hoRyxLQUFLO0FBQUEsVUFDTEMsT0FDSTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csV0FBVTtBQUFBLGNBQ1YsU0FBUyxNQUFNK0cseUJBQXlCL0MsUUFBUU8sS0FBSyx1QkFBdUI7QUFBQSxjQUFFO0FBQUE7QUFBQSxZQUZsRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFFBRVIsQ0FBQztBQUNEdUMsa0JBQVVmLEtBQUs7QUFBQSxVQUNYaEcsS0FBSztBQUFBLFVBQ0xDLE9BQ0k7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFdBQVU7QUFBQSxjQUNWLFNBQVMsTUFBTStHLHlCQUF5Qi9DLFFBQVFPLEtBQUssV0FBVztBQUFBLGNBQUU7QUFBQTtBQUFBLFlBRnRFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsUUFFUixDQUFDO0FBQ0Q7QUFBQSxNQUVKLEtBQUs7QUFDRHVDLGtCQUFVZixLQUFLO0FBQUEsVUFDWGhHLEtBQUs7QUFBQSxVQUNMQyxPQUNJO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxXQUFVO0FBQUEsY0FDVixTQUFTLE1BQU0rRyx5QkFBeUIvQyxRQUFRTyxLQUFLLFdBQVc7QUFBQSxjQUFFO0FBQUE7QUFBQSxZQUZ0RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFFBRVIsQ0FBQztBQUNEO0FBQUEsTUFFSixLQUFLO0FBRUQ7QUFBQSxJQUNSO0FBRUEsV0FDSTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csTUFBTSxFQUFFNEMsT0FBT0wsVUFBVTtBQUFBLFFBQ3pCLFdBQVU7QUFBQSxRQUNWLFNBQVMsQ0FBQyxPQUFPO0FBQUEsUUFFakIsaUNBQUMsWUFBUyxXQUFVLGdFQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdGO0FBQUE7QUFBQSxNQUxwRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNQTtBQUFBLEVBRVI7QUFHQSxRQUFNZCxlQUFlQSxDQUFDNUIsUUFBUWdELGFBQWEsU0FBUztBQUNoRCxVQUFNQyxZQUNGO0FBRUosWUFBUWpELFFBQU07QUFBQSxNQUNWLEtBQUs7QUFDRCxlQUNJLHVCQUFDLFVBQUssV0FBVyxHQUFHaUQsU0FBUyxnQ0FBZ0MsdUJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLE1BR1IsS0FBSztBQUNELGVBQ0ksdUJBQUMsU0FBSSxXQUFVLG9DQUNYO0FBQUEsaUNBQUMsVUFBSyxXQUFXLEdBQUdBLFNBQVMsZ0NBQWdDLDhCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQ0QsZUFBZSxRQUNaO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFLO0FBQUEsY0FDTCxTQUFTQTtBQUFBQSxjQUNULE9BQU87QUFBQSxjQUNQLGFBQ0lBLGVBQWUsTUFDVCxZQUNBQSxjQUFjLEtBQ1YsWUFDQTtBQUFBLGNBRWQsUUFBUSxDQUFDRSxZQUNMLHVCQUFDLFVBQUssV0FBVSxxQkFBcUJBO0FBQUFBO0FBQUFBLGdCQUFRO0FBQUEsbUJBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThDO0FBQUE7QUFBQSxZQVp0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFhTTtBQUFBLGFBbEJkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxQkE7QUFBQSxNQUdSLEtBQUs7QUFDRCxlQUNJLHVCQUFDLFVBQUssV0FBVyxHQUFHRCxTQUFTLGtDQUFrQyxnQ0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsTUFHUixLQUFLO0FBQ0QsZUFDSSx1QkFBQyxVQUFLLFdBQVcsR0FBR0EsU0FBUyxvQ0FBb0MseUJBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLE1BR1I7QUFDSSxlQUNJLHVCQUFDLFVBQUssV0FBVyxHQUFHQSxTQUFTLDhCQUN4QmpELG9CQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLElBRVo7QUFBQSxFQUNKO0FBR0EsUUFBTTJDLDJCQUEyQixPQUFPUSxXQUFXQyxjQUFjO0FBQzdELFFBQUk7QUFDQSxZQUFNbkosSUFBSW9KLE1BQU0sbUNBQW1DRixTQUFTLElBQUk7QUFBQSxRQUM1RG5ELFFBQVFvRDtBQUFBQSxNQUNaLENBQUM7QUFFRGhKLGNBQVFrSixRQUFRLHFCQUFxQkYsU0FBUyxFQUFFO0FBR2hEMUUsNEJBQXNCO0FBQ3RCVCx3QkFBa0IsQ0FBQyxDQUFDO0FBQ3BCRSxtQkFBYSxLQUFLO0FBQUEsSUFDdEIsU0FBU2lCLE9BQU87QUFDWmhGLGNBQVFnRixNQUFNQSxNQUFNVCxVQUFVRyxNQUFNMUUsV0FBVyx5QkFBeUI7QUFBQSxJQUM1RTtBQUFBLEVBQ0o7QUFHQSxRQUFNd0ksMkJBQTJCLE9BQU9PLGNBQWM7QUFDbEQsUUFBSTtBQUNBLFlBQU1sSixJQUFJc0osT0FBTyxtQ0FBbUNKLFNBQVMsRUFBRTtBQUMvRC9JLGNBQVFrSixRQUFRLG9DQUFvQztBQUNwRDVFLDRCQUFzQjtBQUFBLElBQzFCLFNBQVNVLE9BQU87QUFDWmhGLGNBQVFnRixNQUFNQSxNQUFNVCxVQUFVRyxNQUFNMUUsV0FBVyxnQ0FBZ0M7QUFBQSxJQUNuRjtBQUFBLEVBQ0o7QUFHQSxRQUFNcUksc0JBQXNCLE9BQU83QyxTQUFTNEQsb0JBQW9CLFNBQVM7QUFDckUsUUFBSTtBQUNBLFVBQUl6RCxZQUFZeUQ7QUFFaEIsVUFBSSxDQUFDekQsYUFBYUEsVUFBVWQsV0FBVyxHQUFHO0FBQ3RDLGNBQU1nQixTQUFTTCxRQUFRZ0IsU0FBU1QsT0FBT1AsUUFBUU0sV0FBV04sUUFBUVEsUUFBUUY7QUFFMUUsWUFBSSxDQUFDRCxRQUFRO0FBQ1Q3RixrQkFBUWdGLE1BQU0sZ0NBQWdDO0FBQzlDO0FBQUEsUUFDSjtBQUVBLGNBQU1ULFdBQVcsTUFBTTFFLElBQUkyRSxJQUFJLDRCQUE0QnFCLE1BQU0sRUFBRTtBQUVuRSxZQUFJdEIsU0FBU0csUUFBUUgsU0FBU0csS0FBS0EsTUFBTTtBQUNyQyxjQUFJd0IsVUFBVTNCLFNBQVNHLEtBQUtBO0FBQzVCLGNBQUlDLE1BQU1DLFFBQVFzQixPQUFPLEtBQUtBLFFBQVFyQixTQUFTLEdBQUc7QUFDOUNxQixzQkFBVUEsUUFBUSxDQUFDO0FBQUEsVUFDdkI7QUFDQVAsc0JBQVlRLDhCQUE4QkQsT0FBTztBQUFBLFFBQ3JELE9BQU87QUFDSFAsc0JBQVk7QUFBQSxRQUNoQjtBQUFBLE1BQ0o7QUFFQXhCLDBCQUFvQndCLFNBQVM7QUFDN0J0Qiw0QkFBc0JtQixPQUFPO0FBQzdCdkIsMkJBQXFCLElBQUk7QUFBQSxJQUM3QixTQUFTZSxPQUFPO0FBQ1pDLGNBQVFELE1BQU0sNkJBQTZCQSxLQUFLO0FBQ2hEaEYsY0FBUWdGLE1BQU0sMkJBQTJCO0FBQUEsSUFDN0M7QUFBQSxFQUNKO0FBR0EsUUFBTW1CLGdDQUFnQ0EsQ0FBQ0QsWUFBWTtBQUMvQyxRQUFJLENBQUNBLFFBQVMsUUFBTztBQUVyQixVQUFNUCxZQUFZO0FBRWxCLFVBQU0wRCxjQUFjO0FBQUEsTUFDaEIsRUFBRTlILEtBQUssc0JBQXNCQyxPQUFPLFNBQVM4SCxTQUFTLEtBQUs7QUFBQSxNQUMzRCxFQUFFL0gsS0FBSyw4QkFBOEJDLE9BQU8sdUJBQXVCOEgsU0FBUyxLQUFLO0FBQUEsTUFDakYsRUFBRS9ILEtBQUssNkJBQTZCQyxPQUFPLHNCQUFzQjhILFNBQVMsS0FBSztBQUFBLE1BQy9FLEVBQUUvSCxLQUFLLHNCQUFzQkMsT0FBTyxZQUFZOEgsU0FBUyxLQUFLO0FBQUEsTUFDOUQsRUFBRS9ILEtBQUssb0JBQW9CQyxPQUFPLGVBQWU4SCxTQUFTLEtBQUs7QUFBQSxNQUMvRCxFQUFFL0gsS0FBSyx3QkFBd0JDLE9BQU8sa0JBQWtCOEgsU0FBUyxNQUFNO0FBQUEsTUFDdkUsRUFBRS9ILEtBQUssdUJBQXVCQyxPQUFPLGtCQUFrQjhILFNBQVMsS0FBSztBQUFBLE1BQ3JFLEVBQUUvSCxLQUFLLDJCQUEyQkMsT0FBTyxrQkFBa0I4SCxTQUFTLE1BQU07QUFBQSxNQUMxRSxFQUFFL0gsS0FBSyxvQkFBb0JDLE9BQU8sZUFBZThILFNBQVMsTUFBTTtBQUFBLE1BQ2hFLEVBQUUvSCxLQUFLLHNDQUFzQ0MsT0FBTywwQkFBMEI4SCxTQUFTLEtBQUs7QUFBQSxNQUM1RixFQUFFL0gsS0FBSyxxQ0FBcUNDLE9BQU8seUJBQXlCOEgsU0FBUyxLQUFLO0FBQUEsTUFDMUYsRUFBRS9ILEtBQUssOEJBQThCQyxPQUFPLG9CQUFvQjhILFNBQVMsS0FBSztBQUFBLElBQUM7QUFHbkZELGdCQUFZcEIsUUFBUSxDQUFDc0IsWUFBWTtBQUM3QixVQUFJckQsUUFBUXFELFFBQVFoSSxHQUFHLEdBQUc7QUFDdEJvRSxrQkFBVTRCLEtBQUs7QUFBQSxVQUNYaUMsZUFBZUQsUUFBUS9IO0FBQUFBLFVBQ3ZCaUksVUFBVXZELFFBQVFxRCxRQUFRaEksR0FBRztBQUFBLFVBQzdCbUksYUFBYSxHQUFHSCxRQUFRL0gsS0FBSztBQUFBLFVBQzdCOEgsU0FBU0MsUUFBUUQ7QUFBQUEsUUFDckIsQ0FBQztBQUFBLE1BQ0w7QUFBQSxJQUNKLENBQUM7QUFFRCxXQUFPM0Q7QUFBQUEsRUFDWDtBQUdBLFFBQU1TLDhCQUE4QkEsQ0FBQ1QsY0FBYztBQUMvQyxRQUFJLENBQUNBLGFBQWFBLFVBQVVkLFdBQVcsRUFBRyxRQUFPO0FBRWpELFVBQU04RSxlQUFlaEUsVUFBVWlFO0FBQUFBLE1BQzNCLENBQUNDLFFBQVFBLElBQUlKLFlBQVlJLElBQUlMLGtCQUFrQjtBQUFBLElBQ25EO0FBQ0EsVUFBTU0sb0JBQW9CeEksd0JBQXdCdUQ7QUFDbEQsVUFBTStELGFBQWNlLGFBQWE5RSxTQUFTaUYsb0JBQXFCO0FBQy9ELFdBQU9DLEtBQUtDLE1BQU1wQixVQUFVO0FBQUEsRUFDaEM7QUFHQSxRQUFNcUIsZ0JBQWdCQSxDQUFDQyxVQUFVQyxVQUFVO0FBQ3ZDOUgsb0JBQWdCNkgsUUFBUTtBQUN4QjNILG9CQUFnQjRILEtBQUs7QUFBQSxFQUN6QjtBQUVBLFFBQU1DLHNCQUFzQkEsTUFBTTtBQUM5Qi9ILG9CQUFnQixJQUFJO0FBQ3BCRSxvQkFBZ0IsRUFBRTtBQUFBLEVBQ3RCO0FBR0EsUUFBTThILHVCQUF1QixPQUFPM0MsV0FBVztBQUMzQyxRQUFJLENBQUN0RCxtQkFBb0I7QUFFekIsUUFBSTtBQUNBLFVBQUk0RSxZQUFZO0FBQ2hCLGNBQVF0QixRQUFNO0FBQUEsUUFDVixLQUFLO0FBQ0RzQixzQkFBWTtBQUNaO0FBQUEsUUFDSixLQUFLO0FBQ0RBLHNCQUFZO0FBQ1o7QUFBQSxRQUNKLEtBQUs7QUFDREEsc0JBQVk7QUFDWjtBQUFBLFFBQ0o7QUFDSTtBQUFBLE1BQ1I7QUFFQSxVQUFJQSxXQUFXO0FBQ1gsY0FBTVQseUJBQXlCbkUsbUJBQW1CMkIsT0FBTzNCLG1CQUFtQjdDLEtBQUt5SCxTQUFTO0FBQUEsTUFDOUY7QUFFQS9FLDJCQUFxQixLQUFLO0FBQzFCRSwwQkFBb0IsRUFBRTtBQUN0QkUsNEJBQXNCLElBQUk7QUFBQSxJQUM5QixTQUFTVyxPQUFPO0FBQ1pDLGNBQVFELE1BQU0sbUNBQW1DQSxLQUFLO0FBQ3REaEYsY0FBUWdGLE1BQU0sa0NBQWtDO0FBQUEsSUFDcEQ7QUFBQSxFQUNKO0FBR0EsUUFBTXNGLG1CQUFtQkEsQ0FBQ0MsVUFBVTtBQUNoQyxRQUFJLENBQUNBLFNBQVMsQ0FBQ0EsTUFBTSxDQUFDLEtBQUssQ0FBQ0EsTUFBTSxDQUFDLEdBQUc7QUFDbEM1RyxtQkFBYSxDQUFDLE1BQU0sSUFBSSxDQUFDO0FBQ3pCNkcsbUJBQWE7QUFDYjtBQUFBLElBQ0o7QUFFQTdHLGlCQUFhNEcsS0FBSztBQUNsQnBILHVCQUFtQnNILGlCQUFpQi9ILGFBQWE2SCxLQUFLLENBQUM7QUFDdkRsSCw2QkFBeUJvSCxpQkFBaUI3SCx3QkFBd0IySCxLQUFLLENBQUM7QUFDeEVoSCwrQkFBMkJrSCxpQkFBaUIzSCwwQkFBMEJ5SCxLQUFLLENBQUM7QUFDNUU5Ryx5QkFBcUJnSCxpQkFBaUJ6SCxlQUFldUgsS0FBSyxDQUFDO0FBQUEsRUFDL0Q7QUFFQSxRQUFNRSxtQkFBbUJBLENBQUMvRixNQUFNNkYsVUFBVTtBQUN0QyxRQUFJLENBQUNBLFNBQVMsQ0FBQ0EsTUFBTSxDQUFDLEtBQUssQ0FBQ0EsTUFBTSxDQUFDLEVBQUcsUUFBTzdGO0FBRTdDLFVBQU0sQ0FBQ2dHLE9BQU9DLEdBQUcsSUFBSUo7QUFFckIsV0FBTzdGLEtBQUtrRixPQUFPLENBQUMxQixTQUFTO0FBQ3pCLFVBQUkwQyxXQUFXMUMsS0FBS1QsUUFBUVMsS0FBS2pCO0FBQ2pDLFVBQUksQ0FBQzJELFNBQVUsUUFBTztBQUV0QixVQUFJLE9BQU9BLGFBQWEsWUFBWUEsU0FBU0MsU0FBUyxHQUFHLEdBQUc7QUFDeERELG1CQUFXQSxTQUFTekQsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ3BDO0FBRUEsWUFBTTJELFVBQVUzSixNQUFNeUosUUFBUTtBQUM5QixhQUNJRSxRQUFRQyxRQUFRTCxNQUFNTSxTQUFTLEdBQUcsS0FBSyxDQUFDLEtBQ3hDRixRQUFRRyxTQUFTTixJQUFJTyxJQUFJLEdBQUcsS0FBSyxDQUFDO0FBQUEsSUFFMUMsQ0FBQztBQUFBLEVBQ0w7QUFFQSxRQUFNVixlQUFlQSxNQUFNO0FBQ3ZCckgsdUJBQW1CVCxXQUFXO0FBQzlCVyw2QkFBeUJULHNCQUFzQjtBQUMvQ1csK0JBQTJCVCx3QkFBd0I7QUFDbkRXLHlCQUFxQlQsYUFBYTtBQUFBLEVBQ3RDO0FBRUEsUUFBTStCLGtCQUFrQkEsTUFBTTtBQUMxQnBDLG1CQUFlLEVBQUU7QUFDakJRLHVCQUFtQixFQUFFO0FBQ3JCTiw4QkFBMEIsRUFBRTtBQUM1QlEsNkJBQXlCLEVBQUU7QUFDM0JOLGdDQUE0QixFQUFFO0FBQzlCUSwrQkFBMkIsRUFBRTtBQUM3Qk4scUJBQWlCLEVBQUU7QUFDbkJRLHlCQUFxQixFQUFFO0FBQUEsRUFDM0I7QUFHQSxRQUFNMEgseUJBQXlCQSxDQUFDbkMsY0FBYztBQUMxQyxVQUFNb0MsZ0JBQWdCbEksZ0JBQWdCMEc7QUFBQUEsTUFDbEMsQ0FBQzFCLFNBQVN0RSxlQUFlc0UsS0FBSzNHLEdBQUcsR0FBRzRHLE1BQU12QztBQUFBQSxJQUM5QztBQUVBLFFBQUl3RixjQUFjdkcsV0FBVyxHQUFHO0FBQzVCN0UsY0FBUXFMLFFBQVEsd0NBQXdDO0FBQ3hEO0FBQUEsSUFDSjtBQUVBbkwsVUFBTW9MLFFBQVE7QUFBQSxNQUNWbkIsT0FBTztBQUFBLE1BQ1BvQixTQUFTLHNDQUFzQ3ZDLFNBQVMsU0FBU29DLGNBQWN2RyxNQUFNO0FBQUEsTUFDckYyRyxRQUFRO0FBQUEsTUFDUkMsWUFBWTtBQUFBLE1BQ1pDLE1BQU0sWUFBWTtBQUNkLFlBQUk7QUFDQSxnQkFBTTVELFFBQVFDO0FBQUFBLFlBQ1ZxRCxjQUFjN0Y7QUFBQUEsY0FBSSxDQUFDMkMsU0FDZksseUJBQXlCTCxLQUFLM0csS0FBS3lILFNBQVM7QUFBQSxZQUNoRDtBQUFBLFVBQ0o7QUFDQWhKLGtCQUFRa0o7QUFBQUEsWUFDSixHQUFHa0MsY0FBY3ZHLE1BQU0sNEJBQTRCbUUsU0FBUztBQUFBLFVBQ2hFO0FBQUEsUUFDSixTQUFTaEUsT0FBTztBQUNaaEYsa0JBQVFnRixNQUFNLHNDQUFzQztBQUFBLFFBQ3hEO0FBQUEsTUFDSjtBQUFBLElBQ0osQ0FBQztBQUFBLEVBQ0w7QUFHQSxRQUFNMkcsbUJBQW1CQSxNQUFNO0FBQzNCLFVBQU1QLGdCQUFnQmxJLGdCQUFnQjBHO0FBQUFBLE1BQ2xDLENBQUMxQixTQUFTdEUsZUFBZXNFLEtBQUszRyxHQUFHLEdBQUc0RyxNQUFNdkM7QUFBQUEsSUFDOUM7QUFFQSxRQUFJd0YsY0FBY3ZHLFdBQVcsR0FBRztBQUM1QjdFLGNBQVFxTCxRQUFRLHdDQUF3QztBQUN4RDtBQUFBLElBQ0o7QUFFQW5MLFVBQU1vTCxRQUFRO0FBQUEsTUFDVm5CLE9BQU87QUFBQSxNQUNQb0IsU0FBUyxtQ0FBbUNILGNBQWN2RyxNQUFNO0FBQUEsTUFDaEUyRyxRQUFRO0FBQUEsTUFDUkksUUFBUTtBQUFBLE1BQ1JILFlBQVk7QUFBQSxNQUNaQyxNQUFNLFlBQVk7QUFDZCxZQUFJO0FBQ0EsZ0JBQU01RCxRQUFRQztBQUFBQSxZQUNWcUQsY0FBYzdGLElBQUksQ0FBQzJDLFNBQVNNLHlCQUF5Qk4sS0FBSzNHLEdBQUcsQ0FBQztBQUFBLFVBQ2xFO0FBQ0F2QixrQkFBUWtKO0FBQUFBLFlBQ0osR0FBR2tDLGNBQWN2RyxNQUFNO0FBQUEsVUFDM0I7QUFBQSxRQUNKLFNBQVNHLE9BQU87QUFDWmhGLGtCQUFRZ0YsTUFBTSxzQ0FBc0M7QUFBQSxRQUN4RDtBQUFBLE1BQ0o7QUFBQSxJQUNKLENBQUM7QUFBQSxFQUNMO0FBR0EsUUFBTTZHLHVCQUF1QkEsQ0FBQzNELFNBQVM7QUFDbkNyRSxzQkFBa0IsQ0FBQ2lJLFVBQVU7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNILENBQUM1RCxLQUFLM0csR0FBRyxHQUFHO0FBQUEsUUFDUjRHLE1BQU07QUFBQSxVQUNGdkMsUUFBUSxDQUFDa0csS0FBSzVELEtBQUszRyxHQUFHLEdBQUc0RyxNQUFNdkM7QUFBQUEsVUFDL0JhLFdBQVd5QixLQUFLekI7QUFBQUEsVUFDaEIyQixNQUFNRixLQUFLeEI7QUFBQUEsUUFDZjtBQUFBLE1BQ0o7QUFBQSxJQUNKLEVBQUU7QUFBQSxFQUNOO0FBR0EsUUFBTXFGLHdCQUF3QkEsQ0FBQ0MsTUFBTTtBQUNqQyxVQUFNQyxVQUFVRCxFQUFFRSxPQUFPRDtBQUN6QmxJLGlCQUFha0ksT0FBTztBQUNwQixVQUFNRSxVQUFVLEVBQUUsR0FBR3ZJLGVBQWU7QUFDcENWLG9CQUFnQitFLFFBQVEsQ0FBQ0MsU0FBUztBQUM5QmlFLGNBQVFqRSxLQUFLM0csR0FBRyxJQUFJO0FBQUEsUUFDaEI0RyxNQUFNO0FBQUEsVUFDRnZDLFFBQVFxRztBQUFBQSxVQUNSeEYsV0FBV3lCLEtBQUt6QjtBQUFBQSxVQUNoQjJCLE1BQU1GLEtBQUt4QjtBQUFBQSxRQUNmO0FBQUEsTUFDSjtBQUFBLElBQ0osQ0FBQztBQUNEN0Msc0JBQWtCc0ksT0FBTztBQUFBLEVBQzdCO0FBR0EsUUFBTUMsZ0JBQWdCN00sUUFBUSxNQUFNO0FBQ2hDLFdBQU8yRCxnQkFBZ0IwRztBQUFBQSxNQUNuQixDQUFDMUIsU0FBU3RFLGVBQWVzRSxLQUFLM0csR0FBRyxHQUFHNEcsTUFBTXZDO0FBQUFBLElBQzlDLEVBQUVmO0FBQUFBLEVBQ04sR0FBRyxDQUFDM0IsaUJBQWlCVSxjQUFjLENBQUM7QUFHcEN2RSxZQUFVLE1BQU07QUFDWixVQUFNZ04sYUFDRm5KLGdCQUFnQjJCLFNBQVMsS0FDekIzQixnQkFBZ0JvSixNQUFNLENBQUNwRSxTQUFTdEUsZUFBZXNFLEtBQUszRyxHQUFHLEdBQUc0RyxNQUFNdkMsTUFBTTtBQUMxRTdCLGlCQUFhc0ksVUFBVTtBQUFBLEVBQzNCLEdBQUcsQ0FBQ25KLGlCQUFpQlUsY0FBYyxDQUFDO0FBR3BDLFFBQU0ySSxrQkFBa0JySixnQkFBZ0JzSjtBQUFBQSxJQUNwQyxDQUFDQyxLQUFLdkUsU0FBU3VFLE9BQU9DLFdBQVd4RSxLQUFLcEIsV0FBVyxLQUFLO0FBQUEsSUFDdEQ7QUFBQSxFQUNKO0FBR0EsUUFBTTZGLHVCQUF1QnBOLFFBQVEsTUFBTTtBQUN2QyxXQUFPMkQsZ0JBQWdCcUMsSUFBSSxDQUFDMkMsVUFBVTtBQUFBLE1BQ2xDLEdBQUdBO0FBQUFBLE1BQ0gwRSxVQUNJO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxNQUFLO0FBQUEsVUFDTCxTQUFTaEosZUFBZXNFLEtBQUszRyxHQUFHLEdBQUc0RyxNQUFNdkMsVUFBVTtBQUFBLFVBQ25ELFVBQVUsTUFBTWlHLHFCQUFxQjNELElBQUk7QUFBQSxVQUN6QyxXQUFVO0FBQUE7QUFBQSxRQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUl3RDtBQUFBLE1BRzVEcEIsYUFDSSx1QkFBQyxVQUFLLFdBQVUsa0NBQWlDO0FBQUE7QUFBQSxTQUMxQzRGLFdBQVd4RSxLQUFLcEIsV0FBVyxLQUFLLEdBQUcrRixlQUFlLE9BQU87QUFBQSxXQURoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxJQUVSLEVBQUU7QUFBQSxFQUNOLEdBQUcsQ0FBQzNKLGlCQUFpQlUsY0FBYyxDQUFDO0FBR3BDLFFBQU1rSiw4QkFBOEJBLENBQUNkLE1BQU07QUFDdkNqSyxrQkFBY2lLLEVBQUVFLE9BQU9hLEtBQUs7QUFBQSxFQUNoQztBQUdBLFFBQU1DLGlCQUFpQjtBQUFBLElBQ25CLEVBQUV6TCxLQUFLLFlBQVkwTCxRQUFRLFNBQVM7QUFBQSxJQUNwQyxFQUFFMUwsS0FBSyxNQUFNMEwsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRTFMLEtBQUssYUFBYTBMLFFBQVEsWUFBWTtBQUFBLElBQ3hDLEVBQUUxTCxLQUFLLGlCQUFpQjBMLFFBQVEsZ0JBQWdCO0FBQUEsSUFDaEQsRUFBRTFMLEtBQUssZ0JBQWdCMEwsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRTFMLEtBQUssZUFBZTBMLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUUxTCxLQUFLLFVBQVUwTCxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFMUwsS0FBSyxRQUFRMEwsUUFBUSxlQUFlO0FBQUEsSUFDdEMsRUFBRTFMLEtBQUssVUFBVTBMLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHdkMsUUFBTUMsdUJBQXVCO0FBQUEsSUFDekIsRUFBRTNMLEtBQUssTUFBTTBMLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUUxTCxLQUFLLGFBQWEwTCxRQUFRLFlBQVk7QUFBQSxJQUN4QyxFQUFFMUwsS0FBSyxpQkFBaUIwTCxRQUFRLGdCQUFnQjtBQUFBLElBQ2hELEVBQUUxTCxLQUFLLGdCQUFnQjBMLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUUxTCxLQUFLLGVBQWUwTCxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFMUwsS0FBSyxVQUFVMEwsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRTFMLEtBQUssUUFBUTBMLFFBQVEsZUFBZTtBQUFBLElBQ3RDLEVBQUUxTCxLQUFLLFlBQVkwTCxRQUFRLFdBQVc7QUFBQSxJQUN0QyxFQUFFMUwsS0FBSyxVQUFVMEwsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUd2QyxRQUFNRSx5QkFBeUI7QUFBQSxJQUMzQixFQUFFNUwsS0FBSyxNQUFNMEwsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRTFMLEtBQUssYUFBYTBMLFFBQVEsWUFBWTtBQUFBLElBQ3hDLEVBQUUxTCxLQUFLLGlCQUFpQjBMLFFBQVEsZ0JBQWdCO0FBQUEsSUFDaEQsRUFBRTFMLEtBQUssZ0JBQWdCMEwsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRTFMLEtBQUssZUFBZTBMLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUUxTCxLQUFLLFVBQVUwTCxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFMUwsS0FBSyxRQUFRMEwsUUFBUSxlQUFlO0FBQUEsSUFDdEMsRUFBRTFMLEtBQUssWUFBWTBMLFFBQVEsV0FBVztBQUFBLElBQ3RDLEVBQUUxTCxLQUFLLFVBQVUwTCxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3ZDLFFBQU1HLG1CQUFtQjtBQUFBLElBQ3JCLEVBQUU3TCxLQUFLLE1BQU0wTCxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFMUwsS0FBSyxhQUFhMEwsUUFBUSxZQUFZO0FBQUEsSUFDeEMsRUFBRTFMLEtBQUssaUJBQWlCMEwsUUFBUSxnQkFBZ0I7QUFBQSxJQUNoRCxFQUFFMUwsS0FBSyxnQkFBZ0IwTCxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFMUwsS0FBSyxlQUFlMEwsUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRTFMLEtBQUssVUFBVTBMLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUUxTCxLQUFLLFFBQVEwTCxRQUFRLGlCQUFpQjtBQUFBLElBQ3hDLEVBQUUxTCxLQUFLLFVBQVUwTCxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBSXZDLFFBQU1JLE9BQU87QUFBQSxJQUNUO0FBQUEsTUFDSTlHLElBQUk7QUFBQSxNQUNKL0UsT0FBTztBQUFBLE1BQ1A4TCxPQUFPcEssZ0JBQWdCMkI7QUFBQUEsTUFDdkIwSSxNQUFNLHVCQUFDLFlBQVMsV0FBVSxvQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQztBQUFBLElBQzlDO0FBQUEsSUFDQTtBQUFBLE1BQ0loSCxJQUFJO0FBQUEsTUFDSi9FLE9BQU87QUFBQSxNQUNQOEwsT0FBT2xLLHNCQUFzQnlCO0FBQUFBLE1BQzdCMEksTUFBTSx1QkFBQyxrQkFBZSxXQUFVLG9CQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBDO0FBQUEsSUFDcEQ7QUFBQSxJQUNBO0FBQUEsTUFDSWhILElBQUk7QUFBQSxNQUNKL0UsT0FBTztBQUFBLE1BQ1A4TCxPQUFPaEssd0JBQXdCdUI7QUFBQUEsTUFDL0IwSSxNQUFNLHVCQUFDLHFCQUFrQixXQUFVLHFCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThDO0FBQUEsSUFDeEQ7QUFBQSxJQUNBO0FBQUEsTUFDSWhILElBQUk7QUFBQSxNQUNKL0UsT0FBTztBQUFBLE1BQ1A4TCxPQUFPOUosa0JBQWtCcUI7QUFBQUEsTUFDekIwSSxNQUFNLHVCQUFDLFVBQU8sV0FBVSxzQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQztBQUFBLElBQzlDO0FBQUEsRUFBQztBQUlMLFFBQU1DLG1CQUFtQkEsTUFBTTtBQUMzQixRQUFJdEwsV0FBVztBQUNYLGFBQ0ksdUJBQUMsU0FBSSxXQUFVLDBDQUNYLGlDQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZSxLQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxJQUVSO0FBRUEsWUFBUUYsV0FBUztBQUFBLE1BQ2IsS0FBSztBQUNELGVBQ0ksbUNBQ0tvSztBQUFBQSwwQkFBZ0IsS0FDYix1QkFBQyxTQUFJLFdBQVUsb0dBQ1gsaUNBQUMsU0FBSSxXQUFVLGdFQUNYO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDJCQUNYO0FBQUEscUNBQUMsU0FBSSxXQUFVLGdIQUNWQSwyQkFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLFdBQVUsdUNBQXNDLGdDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHVDQUNYO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixTQUFTLE1BQU1qQix1QkFBdUIscUJBQXFCO0FBQUEsa0JBQUU7QUFBQTtBQUFBLGdCQUhqRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0c7QUFBQSxrQkFDQSxTQUFTUTtBQUFBQSxrQkFDVCxXQUFVO0FBQUEsa0JBQWtCO0FBQUE7QUFBQSxnQkFIaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUE7QUFBQSxpQkFkSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWVBO0FBQUEsZUF4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5QkEsS0ExQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyQkE7QUFBQSxVQUdIekksaUJBQWlCMkIsU0FBUyxLQUN2Qix1QkFBQyxTQUFJLFdBQVUsMERBQ1g7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQ1YsU0FBU2Y7QUFBQUEsZ0JBQ1QsVUFBVWlJO0FBQUFBO0FBQUFBLGNBSmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSW9DO0FBQUEsWUFFcEMsdUJBQUMsVUFBSyxXQUFVLHlCQUNYakk7QUFBQUEsMEJBQVksaUJBQWlCO0FBQUEsY0FBYTtBQUFBLGNBQzFDWixnQkFBZ0IyQjtBQUFBQSxjQUFPO0FBQUEsaUJBRjVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUdIakQsVUFDRyx1QkFBQyxTQUFJLFdBQVUsMENBQ1gsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZSxLQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLElBQ0FzQixpQkFBaUIyQixTQUFTLElBQzFCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxNQUFNL0QsYUFBYTZMLHNCQUFzQjdLLFVBQVU7QUFBQSxjQUNuRCxTQUFTa0w7QUFBQUEsY0FDVCxrQkFBaUI7QUFBQTtBQUFBLFlBSHJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUd1QyxJQUd2Qyx1QkFBQyxTQUFJLFdBQVUsbUNBQWtDLG9EQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUE1RFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThEQTtBQUFBLE1BR1IsS0FBSztBQUNELGVBQU81Six1QkFBdUJ5QixTQUFTLElBQ25DO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDRyxNQUFNL0QsYUFBYXNDLHVCQUF1QnRCLFVBQVU7QUFBQSxZQUNwRCxTQUFTb0w7QUFBQUEsWUFDVCxrQkFBaUI7QUFBQTtBQUFBLFVBSHJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUdtRCxJQUduRCx1QkFBQyxTQUFJLFdBQVUsbUNBQWtDLGtEQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxNQUdSLEtBQUs7QUFDRCxlQUFPNUoseUJBQXlCdUIsU0FBUyxJQUNyQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csTUFBTS9ELGFBQWF3Qyx5QkFBeUJ4QixVQUFVO0FBQUEsWUFDdEQsU0FBU3FMO0FBQUFBLFlBQ1Qsa0JBQWlCO0FBQUE7QUFBQSxVQUhyQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHcUQsSUFHckQsdUJBQUMsU0FBSSxXQUFVLG1DQUFrQyxvREFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsTUFHUixLQUFLO0FBQ0QsZUFBTzNKLG1CQUFtQnFCLFNBQVMsSUFDL0I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQU0vRCxhQUFhMEMsbUJBQW1CMUIsVUFBVTtBQUFBLFlBQ2hELFNBQVNzTDtBQUFBQSxZQUNULGtCQUFpQjtBQUFBO0FBQUEsVUFIckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR3lDLElBR3pDLHVCQUFDLFNBQUksV0FBVSxtQ0FBa0MscUNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLE1BR1I7QUFDSSxlQUFPO0FBQUEsSUFDZjtBQUFBLEVBQ0o7QUFFQSxTQUNJLHVCQUFDLFNBQ0c7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0csTUFBTWhMLGlCQUFpQjtBQUFBLFFBQ3ZCLE9BQU9FO0FBQUFBLFFBQ1AsUUFBUTtBQUFBLFFBQ1IsVUFBVThIO0FBQUFBLFFBQ1YsT0FBTTtBQUFBLFFBQ04sT0FBTyxFQUFFcUQsVUFBVSxPQUFPO0FBQUEsUUFFMUIsaUNBQUMsU0FBSSxLQUFLbkwsY0FBYyxPQUFPLEVBQUVvTCxPQUFPLE9BQU8sR0FBRyxLQUFLdEwsZ0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0U7QUFBQTtBQUFBLE1BUnhFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVNBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsY0FDWDtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRztBQUFBLFVBQ0EsWUFBWTtBQUFBO0FBQUEsUUFGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRXFCO0FBQUEsTUFFckIsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUVSLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVztBQUFBLFFBQ1gsdUJBQUMsU0FBSSxXQUFVLDBDQUNYO0FBQUEsaUNBQUMsU0FDRztBQUFBLG1DQUFDLFFBQUcsV0FBVSx3Q0FBdUMsNkNBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsNkRBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUVDSixjQUFjLGFBQ1gsdUJBQUMsU0FBSSxXQUFVLHdHQUNYLGlDQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBLG1DQUFDLFNBQUksV0FBVSxvQkFDWCxpQ0FBQyxrQkFBZSxXQUFVLGFBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1DLEtBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQ0c7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsd0NBQXVDLGlDQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsbUNBQWtDO0FBQUE7QUFBQSxnQkFDekN1SyxnQkFBZ0JNLGVBQWUsT0FBTztBQUFBLG1CQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHNDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtEO0FBQUEsWUFDbEQsdUJBQUMsU0FDRztBQUFBLHFDQUFDLFVBQUssV0FBVSx1Q0FBc0MsaUNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSxxQ0FDUjNKLDBCQUFnQjJCLFVBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkEsS0F0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1QkE7QUFBQSxhQWxDUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0NBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsOEVBQ1gsaUNBQUMsU0FBSSxXQUFVLDJCQUNYO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFDQUFvQyw0QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLFVBQVV5RjtBQUFBQSxjQUNWLFFBQU87QUFBQSxjQUNQLGFBQWEsQ0FBQyxjQUFjLFVBQVU7QUFBQSxjQUN0QyxXQUFVO0FBQUEsY0FDVixNQUFLO0FBQUE7QUFBQSxZQUxUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtnQjtBQUFBLFVBRWY1RyxZQUFZLENBQUMsS0FBS0EsWUFBWSxDQUFDLEtBQzVCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDRyxTQUFTLE1BQU07QUFDWEMsNkJBQWEsQ0FBQyxNQUFNLElBQUksQ0FBQztBQUN6QjZHLDZCQUFhO0FBQUEsY0FDakI7QUFBQSxjQUNBLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUFzQjtBQUFBO0FBQUEsWUFOcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0E7QUFBQSxhQXJCUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUJBLEtBeEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5QkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxRQUNYLGlDQUFDLFNBQUksV0FBVSw0QkFDWCxpQ0FBQyxTQUFJLFdBQVUsa0JBQWlCLGNBQVcsUUFDdEM2QyxlQUFLOUg7QUFBQUEsVUFBSSxDQUFDb0ksUUFDUDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUcsU0FBUyxNQUFNMUwsYUFBYTBMLElBQUlwSCxFQUFFO0FBQUEsY0FDbEMsV0FBVywyRUFBMkV2RSxjQUFjMkwsSUFBSXBILEtBQ2xHLHNDQUNBLDRFQUE0RTtBQUFBLGNBR2xGO0FBQUEsdUNBQUMsVUFBSyxXQUFVLGdCQUFnQm9ILGNBQUlKLFFBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlDO0FBQUEsZ0JBQ3pDLHVCQUFDLFVBQU1JLGNBQUluTSxTQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlCO0FBQUEsZ0JBQ2hCbU0sSUFBSUwsUUFBUSxLQUNUO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNHLFdBQVcscURBQXFEdEwsY0FBYzJMLElBQUlwSCxLQUM1RSxrQ0FDQSwyQkFBMkI7QUFBQSxvQkFHaENvSCxjQUFJTDtBQUFBQTtBQUFBQSxrQkFOVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT0E7QUFBQTtBQUFBO0FBQUEsWUFqQkNLLElBQUlwSDtBQUFBQSxZQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFvQkE7QUFBQSxRQUNILEtBdkJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkEsS0F6Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBCQSxLQTNCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNEJBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsUUFBUWlILDJCQUFpQixLQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBDO0FBQUEsV0FqRzlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrR0E7QUFBQSxNQUdBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxXQUFXeEo7QUFBQUEsVUFDWCxTQUFTLE1BQU07QUFDWEMsaUNBQXFCLEtBQUs7QUFDMUJFLGdDQUFvQixFQUFFO0FBQ3RCRSxrQ0FBc0IsSUFBSTtBQUFBLFVBQzlCO0FBQUEsVUFDQSxPQUFNO0FBQUEsVUFFTjtBQUFBLG1DQUFDLFNBQUksV0FBVSwwQ0FDWDtBQUFBLHFDQUFDLFNBQUksV0FBVSxrR0FDWCxpQ0FBQyxTQUFJLFdBQVUsaURBQ1g7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSx5Q0FBQyxVQUFLLFdBQVUseUJBQXdCLDZCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxRDtBQUFBLGtCQUNyRCx1QkFBQyxVQUFLLFdBQVUsK0JBQ1hELDhCQUFvQmtELFdBQVd4QixTQUFTYyxhQUFheEMsb0JBQW9Ca0QsV0FBV3RCLFFBQVFGLFNBQVNjLGFBQWEsU0FEdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSx5Q0FBQyxVQUFLLFdBQVUseUJBQXdCLDRCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvRDtBQUFBLGtCQUNwRCx1QkFBQyxVQUFLLFdBQVUsK0JBQ1h4Qyw4QkFBb0JrRCxXQUFXeEIsU0FBU2UsZ0JBQWdCekMsb0JBQW9Ca0QsV0FBV3RCLFFBQVFGLFNBQVNlLGdCQUFnQixTQUQ3SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLHlDQUFDLFVBQUssV0FBVSx5QkFBd0IseUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlEO0FBQUEsa0JBQ2pELHVCQUFDLFVBQUssV0FBVSwrQkFDWHpDLDhCQUFvQmtELFdBQVd0QixRQUFRUyxhQUFhLFNBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsbUJBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbUJBLEtBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsNERBQ1g7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsMENBQ1g7QUFBQSx5Q0FBQyxVQUFLLFdBQVUscUNBQW9DLHdDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0csV0FBVyx5QkFBeUJMLDRCQUE0QmxDLGdCQUFnQixNQUFNLE1BQ2hGLHFCQUNBa0MsNEJBQTRCbEMsZ0JBQWdCLEtBQUssS0FDN0MsbUJBQ0EsY0FBYztBQUFBLHNCQUd2QmtDO0FBQUFBLG9EQUE0QmxDLGdCQUFnQjtBQUFBLHdCQUFFO0FBQUE7QUFBQTtBQUFBLG9CQVJuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBU0E7QUFBQSxxQkFiSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWNBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0csU0FBU2tDLDRCQUE0QmxDLGdCQUFnQjtBQUFBLG9CQUNyRCxNQUFLO0FBQUEsb0JBQ0wsYUFBYTtBQUFBLHNCQUNULE1BQU07QUFBQSxzQkFDTixPQUFPO0FBQUEsc0JBQ1AsUUFBUTtBQUFBLG9CQUNaO0FBQUE7QUFBQSxrQkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT007QUFBQSxnQkFFTix1QkFBQyxTQUFJLFdBQVUsbURBQ1g7QUFBQSx5Q0FBQyxVQUFLO0FBQUE7QUFBQSxvQkFDUTtBQUFBLG9CQUNUQSxpQkFBaUIwRjtBQUFBQSxzQkFDZCxDQUFDQyxRQUFRQSxJQUFJSixZQUFZSSxJQUFJTCxrQkFBa0I7QUFBQSxvQkFDbkQsRUFBRTNFO0FBQUFBLG9CQUFRO0FBQUEsb0JBQUk7QUFBQSxvQkFDWHZELHdCQUF3QnVEO0FBQUFBLHVCQUwvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU1BO0FBQUEsa0JBQ0EsdUJBQUMsVUFBSztBQUFBO0FBQUEsb0JBQ1M7QUFBQSxvQkFDVnZELHdCQUF3QnVELFNBQ3JCWCxpQkFBaUIwRjtBQUFBQSxzQkFDYixDQUFDQyxRQUFRQSxJQUFJSixZQUFZSSxJQUFJTCxrQkFBa0I7QUFBQSxvQkFDbkQsRUFBRTNFO0FBQUFBLHVCQUxWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTUE7QUFBQSxxQkFkSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWVBO0FBQUEsbUJBeENKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeUNBO0FBQUEsY0FFQ1gsaUJBQWlCVyxTQUFTLElBQ3ZCLHVCQUFDLFNBQUksV0FBVSx5Q0FDVlgsMkJBQWlCcUI7QUFBQUEsZ0JBQUksQ0FBQ3NFLEtBQUsrRCxVQUN4QjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFFRyxXQUFVO0FBQUEsb0JBRVY7QUFBQSw2Q0FBQyxTQUFJLFdBQVUseUNBQ1g7QUFBQSwrQ0FBQyxRQUFHLFdBQVUsdUNBQ1QvRCxjQUFJTCxpQkFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQ0NLLElBQUlKLFlBQ0QsdUJBQUMsU0FBSSxXQUFVLGNBQ1g7QUFBQTtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDRyxTQUFTLE1BQU1RLGNBQWNKLElBQUlKLFVBQVVJLElBQUlMLGFBQWE7QUFBQSw4QkFDNUQsV0FBVTtBQUFBO0FBQUEsNEJBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUUyRjtBQUFBLDBCQUUzRjtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDRyxNQUFNSyxJQUFJSjtBQUFBQSw4QkFDVixRQUFPO0FBQUEsOEJBQ1AsS0FBSTtBQUFBLDhCQUVKLGlDQUFDLGNBQVcsV0FBVSxtRUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBcUY7QUFBQTtBQUFBLDRCQUx6RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBTUE7QUFBQSw2QkFYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQVlBO0FBQUEsMkJBakJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBbUJBO0FBQUEsc0JBQ0EsdUJBQUMsU0FBSSxXQUFVLG1FQUNWSSxjQUFJUCxXQUFXTyxJQUFJSixXQUNoQjtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDRyxLQUFLSSxJQUFJSjtBQUFBQSwwQkFDVCxLQUFLSSxJQUFJTDtBQUFBQSwwQkFDVCxXQUFVO0FBQUEsMEJBQ1YsU0FBUyxNQUFNUyxjQUFjSixJQUFJSixVQUFVSSxJQUFJTCxhQUFhO0FBQUE7QUFBQSx3QkFKaEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUlrRSxJQUVsRUssSUFBSUosV0FDSix1QkFBQyxjQUFXLFdBQVUsNEJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQThDLElBRTlDLHVCQUFDLFVBQUssV0FBVSx5QkFBd0IsZ0NBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUEsS0FiUjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQWVBO0FBQUE7QUFBQTtBQUFBLGtCQXRDS21FO0FBQUFBLGtCQURUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBd0NBO0FBQUEsY0FDSCxLQTNDTDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTRDQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxxQkFDWDtBQUFBLHVDQUFDLGNBQVcsV0FBVSx5Q0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkQ7QUFBQSxnQkFDM0QsdUJBQUMsT0FBRSxXQUFVLGlCQUFnQixvREFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxpQkF2SFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5SEE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSw2Q0FDWDtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLFNBQVMsTUFBTXZELHFCQUFxQixTQUFTO0FBQUEsa0JBQzdDLFdBQVU7QUFBQSxrQkFBNEM7QUFBQTtBQUFBLGdCQUYxRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csU0FBUyxNQUFNQSxxQkFBcUIsUUFBUTtBQUFBLGtCQUM1QyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUNWLFVBQVVqRSw0QkFBNEJsQyxnQkFBZ0IsSUFBSTtBQUFBLGtCQUFJO0FBQUE7QUFBQSxvQkFHN0RrQyw0QkFBNEJsQyxnQkFBZ0IsSUFBSSxPQUM3Qyx1QkFBQyxVQUFLLFdBQVUsMkJBQTBCO0FBQUE7QUFBQSxzQkFDcENrQyw0QkFBNEJsQyxnQkFBZ0I7QUFBQSxzQkFBRTtBQUFBLHlCQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUE7QUFBQTtBQUFBLGdCQVZSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVlBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxTQUFTLE1BQU1tRyxxQkFBcUIsVUFBVTtBQUFBLGtCQUM5QyxXQUFVO0FBQUEsa0JBQWdEO0FBQUE7QUFBQSxnQkFGOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxpQkF6Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQkE7QUFBQSxZQUNDakUsNEJBQTRCbEMsZ0JBQWdCLElBQUksT0FDN0NBLGlCQUFpQlcsU0FBUyxLQUN0Qix1QkFBQyxTQUFJLFdBQVUsb0JBQ1gsaUNBQUMsVUFBSyxXQUFVLDBCQUF5QjtBQUFBO0FBQUEsY0FFcEN2RCx3QkFBd0J1RCxTQUNyQlgsaUJBQWlCMEY7QUFBQUEsZ0JBQ2IsQ0FBQ0MsUUFBUUEsSUFBSUosWUFBWUksSUFBSUwsa0JBQWtCO0FBQUEsY0FDbkQsRUFBRTNFO0FBQUFBLGNBQVE7QUFBQSxjQUFJO0FBQUEsaUJBTHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0EsS0FSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUE7QUFBQTtBQUFBLFFBMUtaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQTRLQTtBQUFBLFNBeFJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5UkE7QUFBQSxPQXJTSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc1NBO0FBRVI7QUFBQ25ELEdBbHNDUUQsbUJBQWlCO0FBQUEsVUFDTGpDLFdBQVc7QUFBQTtBQUFBcU8sS0FEdkJwTTtBQW9zQ1QsZUFBZUE7QUFBa0IsSUFBQW9NO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInVzZU1lbW8iLCJ1c2VOYXZpZ2F0ZSIsIk5hdmJhciIsIlNpZGViYXIiLCJEYXRhVGFibGUiLCJDaXJjdWxhckxvYWRlciIsImFwaSIsIkRyb3Bkb3duIiwiUG9wY29uZmlybSIsIm1lc3NhZ2UiLCJCdXR0b24iLCJNb2RhbCIsIkRhdGVQaWNrZXIiLCJQcm9ncmVzcyIsIklvTWRNb3JlIiwiSW9GbGFzaCIsIklvRG9jdW1lbnRUZXh0IiwiSW9DaGVja21hcmtDaXJjbGUiLCJJb0V5ZSIsIklvRG9jdW1lbnQiLCJJb0Rvd25sb2FkIiwiSW9DbG9zZSIsIklvV2FsbGV0IiwiZmlsdGVyT3B0aW9uIiwiTW9kYWxDb21wb25lbnQiLCJGYVJ1cGVlU2lnbiIsIkZhRmlsZUNvbnRyYWN0IiwiSW9GbGFnIiwiZGF5anMiLCJCcmVhZGNydW1iIiwiUmFuZ2VQaWNrZXIiLCJSRVFVSVJFRF9MT0FOX0RPQ1VNRU5UUyIsImtleSIsImxhYmVsIiwiTG9hbkRvY3VtZW50YXRpb24iLCJfcyIsIm5hdmlnYXRlIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsImFjdGl2ZVRhYiIsInNldEFjdGl2ZVRhYiIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsInByZXZpZXdJbWFnZSIsInNldFByZXZpZXdJbWFnZSIsInByZXZpZXdUaXRsZSIsInNldFByZXZpZXdUaXRsZSIsImFsbExvYW5Eb2N1bWVudHMiLCJzZXRBbGxMb2FuRG9jdW1lbnRzIiwicGVuZGluZ0RhdGEiLCJzZXRQZW5kaW5nRGF0YSIsImRvY3VtZW50Q29sbGVjdGlvbkRhdGEiLCJzZXREb2N1bWVudENvbGxlY3Rpb25EYXRhIiwiZG9jdW1lbnRWZXJpZmljYXRpb25EYXRhIiwic2V0RG9jdW1lbnRWZXJpZmljYXRpb25EYXRhIiwiY29tcGxldGVkRGF0YSIsInNldENvbXBsZXRlZERhdGEiLCJmaWx0ZXJlZFBlbmRpbmciLCJzZXRGaWx0ZXJlZFBlbmRpbmciLCJmaWx0ZXJlZERvY0NvbGxlY3Rpb24iLCJzZXRGaWx0ZXJlZERvY0NvbGxlY3Rpb24iLCJmaWx0ZXJlZERvY1ZlcmlmaWNhdGlvbiIsInNldEZpbHRlcmVkRG9jVmVyaWZpY2F0aW9uIiwiZmlsdGVyZWRDb21wbGV0ZWQiLCJzZXRGaWx0ZXJlZENvbXBsZXRlZCIsImRhdGVSYW5nZSIsInNldERhdGVSYW5nZSIsImFjdGl2ZVVzZXJEYXRhIiwic2V0QWN0aXZlVXNlckRhdGEiLCJzZWxlY3RBbGwiLCJzZXRTZWxlY3RBbGwiLCJzaG93RG9jdW1lbnRNb2RhbCIsInNldFNob3dEb2N1bWVudE1vZGFsIiwiY3VycmVudERvY3VtZW50cyIsInNldEN1cnJlbnREb2N1bWVudHMiLCJjdXJyZW50TG9hbkZvckRvY3MiLCJzZXRDdXJyZW50TG9hbkZvckRvY3MiLCJmZXRjaEFsbExvYW5Eb2N1bWVudHMiLCJyZXNwb25zZSIsImdldCIsImxvYW5Eb2NzIiwiZGF0YSIsIkFycmF5IiwiaXNBcnJheSIsImxlbmd0aCIsInByb2Nlc3NMb2FuRG9jdW1lbnRzIiwicmVzZXRBbGxUYWJEYXRhIiwiZXJyb3IiLCJjb25zb2xlIiwicGVuZGluZyIsImRvY0NvbGxlY3Rpb24iLCJkb2NWZXJpZmljYXRpb24iLCJjb21wbGV0ZWQiLCJwcm9jZXNzUHJvbWlzZXMiLCJtYXAiLCJsb2FuRG9jIiwiaWR4IiwiZG9jdW1lbnRQZXJjZW50YWdlIiwiZG9jdW1lbnRzIiwic3RhdHVzIiwidXNlcklkIiwidXNlcl9pZCIsIl9pZCIsImxvYW5JZCIsInVzZXJEb2NzUmVzIiwidXNlckRvYyIsInRyYW5zZm9ybVVzZXJEb2N1bWVudHNUb0FycmF5IiwiY2FsY3VsYXRlRG9jdW1lbnRQZXJjZW50YWdlIiwiZXJyIiwiYmFzZURhdGEiLCJpZCIsImxvYW5faWQiLCJsb2FuX2NvZGUiLCJjdXN0b21lcl9uYW1lIiwiYm9ycm93ZXIiLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJsb2FuX2Ftb3VudCIsInN0YXR1c19yYXciLCJkb2N1bWVudF9wZXJjZW50YWdlIiwiY3JlYXRlZF9hdCIsImNyZWF0ZWRBdCIsInNwbGl0IiwidXBkYXRlZF9hdCIsInVwZGF0ZWRBdCIsImxvYW5fZGF0YSIsInB1c2giLCJnZXRTdGF0dXNUYWciLCJ0aW1lIiwiYWN0aW9uIiwiY3JlYXRlQWN0aW9uRHJvcGRvd24iLCJkb2N1bWVudCIsImNyZWF0ZURvY3VtZW50Vmlld0J1dHRvbiIsIlByb21pc2UiLCJhbGwiLCJ0ZW1wQWN0aXZlIiwiZm9yRWFjaCIsIml0ZW0iLCJpbmZvIiwibmFtZSIsImhhbmRsZVZpZXdEb2N1bWVudHMiLCJtZW51SXRlbXMiLCJ1cGRhdGVMb2FuRG9jdW1lbnRTdGF0dXMiLCJoYW5kbGVEZWxldGVMb2FuRG9jdW1lbnQiLCJ3aW5kb3ciLCJvcGVuIiwiaXRlbXMiLCJwZXJjZW50YWdlIiwiYmFzZUNsYXNzIiwicGVyY2VudCIsImxvYW5Eb2NJZCIsIm5ld1N0YXR1cyIsInBhdGNoIiwic3VjY2VzcyIsImRlbGV0ZSIsImV4aXN0aW5nRG9jdW1lbnRzIiwiZG9jTWFwcGluZ3MiLCJpc0ltYWdlIiwibWFwcGluZyIsImRvY3VtZW50X3R5cGUiLCJmaWxlX3VybCIsImRlc2NyaXB0aW9uIiwidXBsb2FkZWREb2NzIiwiZmlsdGVyIiwiZG9jIiwidG90YWxSZXF1aXJlZERvY3MiLCJNYXRoIiwicm91bmQiLCJoYW5kbGVQcmV2aWV3IiwiaW1hZ2VVcmwiLCJ0aXRsZSIsImhhbmRsZUNhbmNlbFByZXZpZXciLCJoYW5kbGVEb2N1bWVudEFjdGlvbiIsImhhbmRsZURhdGVGaWx0ZXIiLCJkYXRlcyIsInJlc2V0RmlsdGVycyIsImZpbHRlckRhdGFCeURhdGUiLCJzdGFydCIsImVuZCIsIml0ZW1EYXRlIiwiaW5jbHVkZXMiLCJkb2NEYXRlIiwiaXNBZnRlciIsInN1YnRyYWN0IiwiaXNCZWZvcmUiLCJhZGQiLCJoYW5kbGVCdWxrU3RhdHVzVXBkYXRlIiwic2VsZWN0ZWRJdGVtcyIsIndhcm5pbmciLCJjb25maXJtIiwiY29udGVudCIsIm9rVGV4dCIsImNhbmNlbFRleHQiLCJvbk9rIiwiaGFuZGxlQnVsa0RlbGV0ZSIsIm9rVHlwZSIsImhhbmRsZUNoZWNrYm94Q2hhbmdlIiwicHJldiIsImhhbmRsZVNlbGVjdEFsbENoYW5nZSIsImUiLCJjaGVja2VkIiwidGFyZ2V0IiwidXBkYXRlZCIsInNlbGVjdGVkQ291bnQiLCJhbGxDaGVja2VkIiwiZXZlcnkiLCJ0b3RhbExvYW5BbW91bnQiLCJyZWR1Y2UiLCJzdW0iLCJwYXJzZUZsb2F0IiwiZm9ybWF0dGVkUGVuZGluZ0RhdGEiLCJjaGVja2JveCIsInRvTG9jYWxlU3RyaW5nIiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwidmFsdWUiLCJwZW5kaW5nQ29sdW1ucyIsImhlYWRlciIsImRvY0NvbGxlY3Rpb25Db2x1bW5zIiwiZG9jVmVyaWZpY2F0aW9uQ29sdW1ucyIsImNvbXBsZXRlZENvbHVtbnMiLCJ0YWJzIiwiY291bnQiLCJpY29uIiwicmVuZGVyVGFiQ29udGVudCIsIm1heFdpZHRoIiwid2lkdGgiLCJ0YWIiLCJpbmRleCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkxvYW5Eb2N1bWVudGF0aW9uLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZU1lbW8gfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IHtcclxuICAgIERyb3Bkb3duLFxyXG4gICAgUG9wY29uZmlybSxcclxuICAgIG1lc3NhZ2UsXHJcbiAgICBCdXR0b24sXHJcbiAgICBNb2RhbCxcclxuICAgIERhdGVQaWNrZXIsXHJcbiAgICBQcm9ncmVzcyxcclxufSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQge1xyXG4gICAgSW9GbGFzaCxcclxuICAgIElvRG9jdW1lbnRUZXh0LFxyXG4gICAgSW9DaGVja21hcmtDaXJjbGUsXHJcbiAgICBJb0V5ZSxcclxuICAgIElvRG9jdW1lbnQsXHJcbiAgICBJb0Rvd25sb2FkLFxyXG4gICAgSW9DbG9zZSxcclxuICAgIElvV2FsbGV0LFxyXG59IGZyb20gXCJyZWFjdC1pY29ucy9pbzVcIjtcclxuaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuaW1wb3J0IE1vZGFsQ29tcG9uZW50IGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgeyBGYVJ1cGVlU2lnbiwgRmFGaWxlQ29udHJhY3QgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IHsgSW9GbGFnIH0gZnJvbSBcInJlYWN0LWljb25zL2lvNVwiO1xyXG5pbXBvcnQgZGF5anMgZnJvbSBcImRheWpzXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuXHJcbmNvbnN0IHsgUmFuZ2VQaWNrZXIgfSA9IERhdGVQaWNrZXI7XHJcblxyXG4vLyBEb2N1bWVudCB0eXBlIG1hcHBpbmcgZm9yIHJlcXVpcmVkIGxvYW4gZG9jdW1lbnRzXHJcbmNvbnN0IFJFUVVJUkVEX0xPQU5fRE9DVU1FTlRTID0gW1xyXG4gICAgeyBrZXk6IFwidXNlcl9wcm9maWxlX3Bob3RvXCIsIGxhYmVsOiBcIlBob3RvXCIgfSxcclxuICAgIHsga2V5OiBcInVzZXJfYWRoYXJjYXJkX2Zyb250X3Bob3RvXCIsIGxhYmVsOiBcIkFhZGhhciBDYXJkIChGcm9udClcIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlcl9hZGhhcmNhcmRfYmFja19waG90b1wiLCBsYWJlbDogXCJBYWRoYXIgQ2FyZCAoQmFjaylcIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlcl9wYW5jYXJkX3Bob3RvXCIsIGxhYmVsOiBcIlBBTiBDYXJkXCIgfSxcclxuICAgIHsga2V5OiBcInVzZXJfY2hlcXVlX2xlYWZcIiwgbGFiZWw6IFwiQ2hlcXVlIExlYWZcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmFua19zdGF0ZW1lbnRfbW9udGhcIiwgbGFiZWw6IFwiQmFuayBTdGF0ZW1lbnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmFua19wYXNzYm9va19waG90b1wiLCBsYWJlbDogXCJQYXNzYm9vayBQaG90b1wiIH0sXHJcbiAgICB7IGtleTogXCJidXNpbmVzc19kb2N1bWVudF9wcm9vZlwiLCBsYWJlbDogXCJCdXNpbmVzcyBQcm9vZlwiIH0sXHJcbiAgICB7IGtleTogXCJ1c2VyX3NhbGFyeV9zbGlwXCIsIGxhYmVsOiBcIlNhbGFyeSBTbGlwXCIgfSxcclxuICAgIHsga2V5OiBcInVzZXJfbm9taW5lZV9hZGhhcmNhcmRfZnJvbnRfcGhvdG9cIiwgbGFiZWw6IFwiTm9taW5lZSBBYWRoYXIgKEZyb250KVwiIH0sXHJcbiAgICB7IGtleTogXCJ1c2VyX25vbWluZWVfYWRoYXJjYXJkX2JhY2tfcGhvdG9cIiwgbGFiZWw6IFwiTm9taW5lZSBBYWRoYXIgKEJhY2spXCIgfSxcclxuICAgIHsga2V5OiBcInVzZXJfbm9taW5lZV9wYW5jYXJkX3Bob3RvXCIsIGxhYmVsOiBcIk5vbWluZWUgUEFOIENhcmRcIiB9LFxyXG5dO1xyXG5cclxuZnVuY3Rpb24gTG9hbkRvY3VtZW50YXRpb24oKSB7XHJcbiAgICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbiAgICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZShcInBlbmRpbmdcIik7XHJcbiAgICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW3ByZXZpZXdJbWFnZSwgc2V0UHJldmlld0ltYWdlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gICAgY29uc3QgW3ByZXZpZXdUaXRsZSwgc2V0UHJldmlld1RpdGxlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICAgIC8vIERhdGEgc3RhdGVzIGZvciBkaWZmZXJlbnQgdGFic1xyXG4gICAgY29uc3QgW2FsbExvYW5Eb2N1bWVudHMsIHNldEFsbExvYW5Eb2N1bWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW3BlbmRpbmdEYXRhLCBzZXRQZW5kaW5nRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgICBjb25zdCBbZG9jdW1lbnRDb2xsZWN0aW9uRGF0YSwgc2V0RG9jdW1lbnRDb2xsZWN0aW9uRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgICBjb25zdCBbZG9jdW1lbnRWZXJpZmljYXRpb25EYXRhLCBzZXREb2N1bWVudFZlcmlmaWNhdGlvbkRhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW2NvbXBsZXRlZERhdGEsIHNldENvbXBsZXRlZERhdGFdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICAgIC8vIEZpbHRlcmVkIGRhdGEgc3RhdGVzXHJcbiAgICBjb25zdCBbZmlsdGVyZWRQZW5kaW5nLCBzZXRGaWx0ZXJlZFBlbmRpbmddID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW2ZpbHRlcmVkRG9jQ29sbGVjdGlvbiwgc2V0RmlsdGVyZWREb2NDb2xsZWN0aW9uXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFtmaWx0ZXJlZERvY1ZlcmlmaWNhdGlvbiwgc2V0RmlsdGVyZWREb2NWZXJpZmljYXRpb25dID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW2ZpbHRlcmVkQ29tcGxldGVkLCBzZXRGaWx0ZXJlZENvbXBsZXRlZF0gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4gICAgLy8gRGF0ZSBmaWx0ZXIgc3RhdGVzXHJcbiAgICBjb25zdCBbZGF0ZVJhbmdlLCBzZXREYXRlUmFuZ2VdID0gdXNlU3RhdGUoW251bGwsIG51bGxdKTtcclxuXHJcbiAgICAvLyBTZWxlY3Rpb24gc3RhdGVzXHJcbiAgICBjb25zdCBbYWN0aXZlVXNlckRhdGEsIHNldEFjdGl2ZVVzZXJEYXRhXSA9IHVzZVN0YXRlKHt9KTtcclxuICAgIGNvbnN0IFtzZWxlY3RBbGwsIHNldFNlbGVjdEFsbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gICAgLy8gRG9jdW1lbnQgbW9kYWwgc3RhdGVzXHJcbiAgICBjb25zdCBbc2hvd0RvY3VtZW50TW9kYWwsIHNldFNob3dEb2N1bWVudE1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtjdXJyZW50RG9jdW1lbnRzLCBzZXRDdXJyZW50RG9jdW1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFtjdXJyZW50TG9hbkZvckRvY3MsIHNldEN1cnJlbnRMb2FuRm9yRG9jc10gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGZldGNoQWxsTG9hbkRvY3VtZW50cygpO1xyXG4gICAgICAgIC8vIGZldGNoQXBwcm92ZWRMb2FucygpO1xyXG4gICAgfSwgW10pO1xyXG5cclxuICAgIC8vIEZldGNoIGFsbCBsb2FuIGRvY3VtZW50c1xyXG4gICAgY29uc3QgZmV0Y2hBbGxMb2FuRG9jdW1lbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdjEvYWRtaW4vbG9hbi1kb2N1bWVudHMvXCIpO1xyXG4gICAgICAgICAgICBjb25zdCBsb2FuRG9jcyA9IHJlc3BvbnNlLmRhdGE/LmRhdGEgfHwgcmVzcG9uc2UuZGF0YSB8fCBbXTtcclxuXHJcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGxvYW5Eb2NzKSAmJiBsb2FuRG9jcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICBzZXRBbGxMb2FuRG9jdW1lbnRzKGxvYW5Eb2NzKTtcclxuICAgICAgICAgICAgICAgIHByb2Nlc3NMb2FuRG9jdW1lbnRzKGxvYW5Eb2NzKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHNldEFsbExvYW5Eb2N1bWVudHMoW10pO1xyXG4gICAgICAgICAgICAgICAgcmVzZXRBbGxUYWJEYXRhKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgbG9hbiBkb2N1bWVudHM6XCIsIGVycm9yKTtcclxuICAgICAgICAgICAgbWVzc2FnZS5lcnJvcihlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBmZXRjaCBsb2FuIGRvY3VtZW50c1wiKTtcclxuICAgICAgICAgICAgcmVzZXRBbGxUYWJEYXRhKCk7XHJcbiAgICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIC8vIEZldGNoIGFwcHJvdmVkIGxvYW5zIChmb3IgY3JlYXRpbmcgbmV3IGxvYW4gZG9jdW1lbnRzKVxyXG4gICAgLy8gY29uc3QgZmV0Y2hBcHByb3ZlZExvYW5zID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgLy8gICAgIHRyeSB7XHJcbiAgICAvLyAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi92MS9hZG1pbi9sb2Fucy9sb2FuLWFwcHJvdmVkXCIpO1xyXG4gICAgLy8gICAgICAgICBjb25zdCBhcHByb3ZlZExvYW5zID0gcmVzcG9uc2UuZGF0YT8uZGF0YSB8fCByZXNwb25zZS5kYXRhIHx8IFtdO1xyXG4gICAgLy8gICAgICAgICAvLyBTdG9yZSBhcHByb3ZlZCBsb2FucyBkYXRhIGZvciByZWZlcmVuY2VcclxuICAgIC8vICAgICAgICAgY29uc29sZS5sb2coXCJBcHByb3ZlZCBsb2FuczpcIiwgYXBwcm92ZWRMb2Fucyk7XHJcbiAgICAvLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIC8vICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGFwcHJvdmVkIGxvYW5zOlwiLCBlcnJvcik7XHJcbiAgICAvLyAgICAgfVxyXG4gICAgLy8gfTtcclxuXHJcbiAgICAvLyBQcm9jZXNzIGxvYW4gZG9jdW1lbnRzIGludG8gZGlmZmVyZW50IHRhYnNcclxuICAgIGNvbnN0IHByb2Nlc3NMb2FuRG9jdW1lbnRzID0gYXN5bmMgKGxvYW5Eb2NzKSA9PiB7XHJcbiAgICAgICAgY29uc3QgcGVuZGluZyA9IFtdO1xyXG4gICAgICAgIGNvbnN0IGRvY0NvbGxlY3Rpb24gPSBbXTtcclxuICAgICAgICBjb25zdCBkb2NWZXJpZmljYXRpb24gPSBbXTtcclxuICAgICAgICBjb25zdCBjb21wbGV0ZWQgPSBbXTtcclxuXHJcbiAgICAgICAgLy8gUHJvY2VzcyBlYWNoIGxvYW4gZG9jdW1lbnQgd2l0aCBkb2N1bWVudCBwZXJjZW50YWdlIGNhbGN1bGF0aW9uXHJcbiAgICAgICAgY29uc3QgcHJvY2Vzc1Byb21pc2VzID0gbG9hbkRvY3MubWFwKGFzeW5jIChsb2FuRG9jLCBpZHgpID0+IHtcclxuICAgICAgICAgICAgbGV0IGRvY3VtZW50UGVyY2VudGFnZSA9IDA7XHJcbiAgICAgICAgICAgIGxldCBkb2N1bWVudHMgPSBbXTtcclxuXHJcbiAgICAgICAgICAgIC8vIENhbGN1bGF0ZSBkb2N1bWVudCBwZXJjZW50YWdlIGZvciBEb2N1bWVudCBDb2xsZWN0aW9uIHN0YXR1c1xyXG4gICAgICAgICAgICBpZiAobG9hbkRvYy5zdGF0dXMgPT09IFwiRG9jdW1lbnQgQ29sbGVjdGlvblwiKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCB1c2VySWQgPSBsb2FuRG9jLnVzZXJfaWQ/Ll9pZCB8fCBsb2FuRG9jLnVzZXJfaWQgfHwgbG9hbkRvYy5sb2FuSWQ/LnVzZXJfaWQ7XHJcbiAgICAgICAgICAgICAgICBpZiAodXNlcklkKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdXNlckRvY3NSZXMgPSBhd2FpdCBhcGkuZ2V0KGAvdjEvYWRtaW4vdXNlci1kb2N1bWVudHMvJHt1c2VySWR9YCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh1c2VyRG9jc1Jlcy5kYXRhICYmIHVzZXJEb2NzUmVzLmRhdGEuZGF0YSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHVzZXJEb2MgPSB1c2VyRG9jc1Jlcy5kYXRhLmRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheSh1c2VyRG9jKSAmJiB1c2VyRG9jLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyRG9jID0gdXNlckRvY1swXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRvY3VtZW50cyA9IHRyYW5zZm9ybVVzZXJEb2N1bWVudHNUb0FycmF5KHVzZXJEb2MpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnRQZXJjZW50YWdlID0gY2FsY3VsYXRlRG9jdW1lbnRQZXJjZW50YWdlKGRvY3VtZW50cyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHVzZXIgZG9jdW1lbnRzOlwiLCBlcnIpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgY29uc3QgYmFzZURhdGEgPSB7XHJcbiAgICAgICAgICAgICAgICBrZXk6IGxvYW5Eb2MuX2lkLFxyXG4gICAgICAgICAgICAgICAgaWQ6IGlkeCArIDEsXHJcbiAgICAgICAgICAgICAgICBsb2FuX2lkOiBsb2FuRG9jLmxvYW5faWQ/Ll9pZCB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICAgICAgbG9hbl9jb2RlOiBsb2FuRG9jLmxvYW5faWQ/LmxvYW5faWQgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICAgIGN1c3RvbWVyX25hbWU6IGxvYW5Eb2MubG9hbl9pZD8uYm9ycm93ZXI/LmZ1bGxfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBsb2FuRG9jLmxvYW5faWQ/LmJvcnJvd2VyPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICAgIGxvYW5fYW1vdW50OiBcIk4vQVwiLCBcclxuICAgICAgICAgICAgICAgIHN0YXR1c19yYXc6IGxvYW5Eb2Muc3RhdHVzLFxyXG4gICAgICAgICAgICAgICAgZG9jdW1lbnRfcGVyY2VudGFnZTogZG9jdW1lbnRQZXJjZW50YWdlLFxyXG4gICAgICAgICAgICAgICAgZG9jdW1lbnRzOiBkb2N1bWVudHMsXHJcbiAgICAgICAgICAgICAgICBjcmVhdGVkX2F0OiBsb2FuRG9jLmNyZWF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgICB1cGRhdGVkX2F0OiBsb2FuRG9jLnVwZGF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgICBsb2FuX2RhdGE6IGxvYW5Eb2MsIC8vIGtlZXAgZnVsbCBvYmplY3QgZm9yIGFjdGlvbnNcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIHN3aXRjaCAobG9hbkRvYy5zdGF0dXMpIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgXCJQZW5kaW5nXCI6XHJcbiAgICAgICAgICAgICAgICAgICAgcGVuZGluZy5wdXNoKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uYmFzZURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czogZ2V0U3RhdHVzVGFnKFwiUGVuZGluZ1wiKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGltZTogYmFzZURhdGEuY3JlYXRlZF9hdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uOiBjcmVhdGVBY3Rpb25Ecm9wZG93bihsb2FuRG9jLCBcIlBlbmRpbmdcIiksXHJcbiAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIFwiRG9jdW1lbnQgQ29sbGVjdGlvblwiOlxyXG4gICAgICAgICAgICAgICAgICAgIGRvY0NvbGxlY3Rpb24ucHVzaCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmJhc2VEYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IGdldFN0YXR1c1RhZyhcIkRvY3VtZW50IENvbGxlY3Rpb25cIiwgZG9jdW1lbnRQZXJjZW50YWdlKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGltZTogYmFzZURhdGEudXBkYXRlZF9hdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQ6IGNyZWF0ZURvY3VtZW50Vmlld0J1dHRvbihsb2FuRG9jLCBkb2N1bWVudHMpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb246IGNyZWF0ZUFjdGlvbkRyb3Bkb3duKGxvYW5Eb2MsIFwiRG9jdW1lbnQgQ29sbGVjdGlvblwiKSxcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgXCJEb2N1bWVudCBWZXJpZmljYXRpb25cIjpcclxuICAgICAgICAgICAgICAgICAgICBkb2NWZXJpZmljYXRpb24ucHVzaCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmJhc2VEYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IGdldFN0YXR1c1RhZyhcIkRvY3VtZW50IFZlcmlmaWNhdGlvblwiKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGltZTogYmFzZURhdGEudXBkYXRlZF9hdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQ6IGNyZWF0ZURvY3VtZW50Vmlld0J1dHRvbihsb2FuRG9jLCBkb2N1bWVudHMpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb246IGNyZWF0ZUFjdGlvbkRyb3Bkb3duKGxvYW5Eb2MsIFwiRG9jdW1lbnQgVmVyaWZpY2F0aW9uXCIpLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSBcIkNvbXBsZXRlZFwiOlxyXG4gICAgICAgICAgICAgICAgICAgIGNvbXBsZXRlZC5wdXNoKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uYmFzZURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czogZ2V0U3RhdHVzVGFnKFwiQ29tcGxldGVkXCIpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aW1lOiBiYXNlRGF0YS51cGRhdGVkX2F0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb246IGNyZWF0ZUFjdGlvbkRyb3Bkb3duKGxvYW5Eb2MsIFwiQ29tcGxldGVkXCIpLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICBwZW5kaW5nLnB1c2goe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5iYXNlRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiBnZXRTdGF0dXNUYWcoXCJQZW5kaW5nXCIpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aW1lOiBiYXNlRGF0YS5jcmVhdGVkX2F0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb246IGNyZWF0ZUFjdGlvbkRyb3Bkb3duKGxvYW5Eb2MsIFwiUGVuZGluZ1wiKSxcclxuICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBhd2FpdCBQcm9taXNlLmFsbChwcm9jZXNzUHJvbWlzZXMpO1xyXG5cclxuICAgICAgICBzZXRQZW5kaW5nRGF0YShwZW5kaW5nKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZFBlbmRpbmcocGVuZGluZyk7XHJcbiAgICAgICAgc2V0RG9jdW1lbnRDb2xsZWN0aW9uRGF0YShkb2NDb2xsZWN0aW9uKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZERvY0NvbGxlY3Rpb24oZG9jQ29sbGVjdGlvbik7XHJcbiAgICAgICAgc2V0RG9jdW1lbnRWZXJpZmljYXRpb25EYXRhKGRvY1ZlcmlmaWNhdGlvbik7XHJcbiAgICAgICAgc2V0RmlsdGVyZWREb2NWZXJpZmljYXRpb24oZG9jVmVyaWZpY2F0aW9uKTtcclxuICAgICAgICBzZXRDb21wbGV0ZWREYXRhKGNvbXBsZXRlZCk7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRDb21wbGV0ZWQoY29tcGxldGVkKTtcclxuXHJcbiAgICAgICAgLy8gSW5pdGlhbGl6ZSBzZWxlY3Rpb24gc3RhdGUgZm9yIHBlbmRpbmcgdGFiXHJcbiAgICAgICAgY29uc3QgdGVtcEFjdGl2ZSA9IHt9O1xyXG4gICAgICAgIHBlbmRpbmcuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgICB0ZW1wQWN0aXZlW2l0ZW0ua2V5XSA9IHtcclxuICAgICAgICAgICAgICAgIGluZm86IHtcclxuICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgICAgIGxvYW5fY29kZTogaXRlbS5sb2FuX2NvZGUsXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogaXRlbS5jdXN0b21lcl9uYW1lLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRBY3RpdmVVc2VyRGF0YSh0ZW1wQWN0aXZlKTtcclxuICAgIH07XHJcblxyXG4gICAgLy8gQ3JlYXRlIGRvY3VtZW50IHZpZXcgYnV0dG9uXHJcbiAgICBjb25zdCBjcmVhdGVEb2N1bWVudFZpZXdCdXR0b24gPSAobG9hbkRvYywgZG9jdW1lbnRzKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImxpbmtcIlxyXG4gICAgICAgICAgICAgICAgaWNvbj17PElvRXllIGNsYXNzTmFtZT1cInRleHQtbGdcIiAvPn1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVZpZXdEb2N1bWVudHMobG9hbkRvYywgZG9jdW1lbnRzKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC02MDAgaG92ZXI6dGV4dC1lbWVyYWxkLTcwMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFZpZXdcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgKTtcclxuICAgIH07XHJcblxyXG4gICAgLy8gQ3JlYXRlIGFjdGlvbiBkcm9wZG93biBiYXNlZCBvbiBzdGF0dXNcclxuICAgIGNvbnN0IGNyZWF0ZUFjdGlvbkRyb3Bkb3duID0gKGxvYW5Eb2MsIHN0YXR1cykgPT4ge1xyXG4gICAgICAgIGNvbnN0IG1lbnVJdGVtcyA9IFtdO1xyXG5cclxuICAgICAgICBzd2l0Y2ggKHN0YXR1cykge1xyXG4gICAgICAgICAgICBjYXNlIFwiUGVuZGluZ1wiOlxyXG4gICAgICAgICAgICAgICAgbWVudUl0ZW1zLnB1c2goe1xyXG4gICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZUxvYW5Eb2N1bWVudFN0YXR1cyhsb2FuRG9jLl9pZCwgXCJEb2N1bWVudCBDb2xsZWN0aW9uXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBTdGFydCBEb2N1bWVudCBDb2xsZWN0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgIG1lbnVJdGVtcy5wdXNoKHtcclxuICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxQb3Bjb25maXJtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkRlbGV0ZSBMb2FuIERvY3VtZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uPVwiQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSB0aGlzIGxvYW4gZG9jdW1lbnQ/XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29uZmlybT17KCkgPT4gaGFuZGxlRGVsZXRlTG9hbkRvY3VtZW50KGxvYW5Eb2MuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rVGV4dD1cIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYW5jZWxUZXh0PVwiTm9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiPkRlbGV0ZTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1BvcGNvbmZpcm0+XHJcbiAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgICBjYXNlIFwiRG9jdW1lbnQgQ29sbGVjdGlvblwiOlxyXG4gICAgICAgICAgICAgICAgbWVudUl0ZW1zLnB1c2goe1xyXG4gICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aW5kb3cub3BlbihcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYC9sZWdhbHMtbWVudS91c2VyLWRvY3VtZW50P3VzZXJJZD0ke2xvYW5Eb2MudXNlcl9pZD8uX2lkIHx8IGxvYW5Eb2MubG9hbklkPy51c2VyX2lkfSZsb2FuSWQ9JHtsb2FuRG9jLl9pZH1gLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIl9ibGFua1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1hbWJlci02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBVcGxvYWQgRG9jdW1lbnRzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICBtZW51SXRlbXMucHVzaCh7XHJcbiAgICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdXBkYXRlTG9hbkRvY3VtZW50U3RhdHVzKGxvYW5Eb2MuX2lkLCBcIkRvY3VtZW50IFZlcmlmaWNhdGlvblwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgTW92ZSB0byBWZXJpZmljYXRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgbWVudUl0ZW1zLnB1c2goe1xyXG4gICAgICAgICAgICAgICAgICAgIGtleTogXCIzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB1cGRhdGVMb2FuRG9jdW1lbnRTdGF0dXMobG9hbkRvYy5faWQsIFwiQ29tcGxldGVkXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBNYXJrIENvbXBsZXRlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGNhc2UgXCJEb2N1bWVudCBWZXJpZmljYXRpb25cIjpcclxuICAgICAgICAgICAgICAgIG1lbnVJdGVtcy5wdXNoKHtcclxuICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdXBkYXRlTG9hbkRvY3VtZW50U3RhdHVzKGxvYW5Eb2MuX2lkLCBcIkNvbXBsZXRlZFwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVmVyaWZpY2F0aW9uIENvbXBsZXRlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICAgIGNhc2UgXCJDb21wbGV0ZWRcIjpcclxuICAgICAgICAgICAgICAgIC8vIE5vIGFjdGlvbnMgZm9yIGNvbXBsZXRlZFxyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgIG1lbnU9e3sgaXRlbXM6IG1lbnVJdGVtcyB9fVxyXG4gICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyIHRleHQteGwgdGV4dC1ncmF5LTYwMCBob3Zlcjp0ZXh0LXZpb2xldC02MDBcIiAvPlxyXG4gICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICk7XHJcbiAgICB9O1xyXG5cclxuICAgIC8vIEdldCBzdGF0dXMgdGFnIHdpdGggY29sb3IgY29kaW5nXHJcbiAgICBjb25zdCBnZXRTdGF0dXNUYWcgPSAoc3RhdHVzLCBwZXJjZW50YWdlID0gbnVsbCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGJhc2VDbGFzcyA9XHJcbiAgICAgICAgICAgIFwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB4LTMgcHktMSB0ZXh0LXhzIGZvbnQtbWVkaXVtIHJvdW5kZWQtZnVsbCB3aGl0ZXNwYWNlLW5vd3JhcCBtaW4tdy1bMTIwcHhdXCI7XHJcblxyXG4gICAgICAgIHN3aXRjaCAoc3RhdHVzKSB7XHJcbiAgICAgICAgICAgIGNhc2UgXCJQZW5kaW5nXCI6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YCR7YmFzZUNsYXNzfSBiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS02MDBgfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUGVuZGluZ1xyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICBjYXNlIFwiRG9jdW1lbnQgQ29sbGVjdGlvblwiOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YCR7YmFzZUNsYXNzfSBiZy1hbWJlci0xMDAgdGV4dC1hbWJlci03MDBgfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIERPQyBDb2xsZWN0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3BlcmNlbnRhZ2UgIT09IG51bGwgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFByb2dyZXNzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNpcmNsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGVyY2VudD17cGVyY2VudGFnZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aWR0aD17NDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlQ29sb3I9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZXJjZW50YWdlID09PSAxMDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCIjMTBiOTgxXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogcGVyY2VudGFnZSA+PSA3MFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCIjZjU5ZTBiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiI2VmNDQ0NFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1hdD17KHBlcmNlbnQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGRcIj57cGVyY2VudH0lPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgIGNhc2UgXCJEb2N1bWVudCBWZXJpZmljYXRpb25cIjpcclxuICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgJHtiYXNlQ2xhc3N9IGJnLXZpb2xldC0xMDAgdGV4dC12aW9sZXQtNzAwYH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIERPQyBWZXJpZmljYXRpb25cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgY2FzZSBcIkNvbXBsZXRlZFwiOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Ake2Jhc2VDbGFzc30gYmctZW1lcmFsZC0xMDAgdGV4dC1lbWVyYWxkLTcwMGB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDb21wbGV0ZWRcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgJHtiYXNlQ2xhc3N9IGJnLWdyYXktMTAwIHRleHQtZ3JheS01MDBgfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3N0YXR1c31cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgLy8gVXBkYXRlIGxvYW4gZG9jdW1lbnQgc3RhdHVzXHJcbiAgICBjb25zdCB1cGRhdGVMb2FuRG9jdW1lbnRTdGF0dXMgPSBhc3luYyAobG9hbkRvY0lkLCBuZXdTdGF0dXMpID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBhd2FpdCBhcGkucGF0Y2goYC92MS9hZG1pbi9sb2FuLWRvY3VtZW50cy9zdGF0dXMvJHtsb2FuRG9jSWR9YCwge1xyXG4gICAgICAgICAgICAgICAgc3RhdHVzOiBuZXdTdGF0dXMsXHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgbWVzc2FnZS5zdWNjZXNzKGBTdGF0dXMgdXBkYXRlZCB0byAke25ld1N0YXR1c31gKTtcclxuXHJcbiAgICAgICAgICAgIC8vIFJlZnJlc2ggZGF0YVxyXG4gICAgICAgICAgICBmZXRjaEFsbExvYW5Eb2N1bWVudHMoKTtcclxuICAgICAgICAgICAgc2V0QWN0aXZlVXNlckRhdGEoe30pO1xyXG4gICAgICAgICAgICBzZXRTZWxlY3RBbGwoZmFsc2UpO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgIG1lc3NhZ2UuZXJyb3IoZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gdXBkYXRlIHN0YXR1c1wiKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIC8vIERlbGV0ZSBsb2FuIGRvY3VtZW50XHJcbiAgICBjb25zdCBoYW5kbGVEZWxldGVMb2FuRG9jdW1lbnQgPSBhc3luYyAobG9hbkRvY0lkKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgYXdhaXQgYXBpLmRlbGV0ZShgL3YxL2FkbWluL2xvYW4tZG9jdW1lbnRzL2RlbGV0ZS8ke2xvYW5Eb2NJZH1gKTtcclxuICAgICAgICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiTG9hbiBkb2N1bWVudCBkZWxldGVkIHN1Y2Nlc3NmdWxseVwiKTtcclxuICAgICAgICAgICAgZmV0Y2hBbGxMb2FuRG9jdW1lbnRzKCk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgbWVzc2FnZS5lcnJvcihlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBkZWxldGUgbG9hbiBkb2N1bWVudFwiKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIC8vIEhhbmRsZSB2aWV3IGRvY3VtZW50c1xyXG4gICAgY29uc3QgaGFuZGxlVmlld0RvY3VtZW50cyA9IGFzeW5jIChsb2FuRG9jLCBleGlzdGluZ0RvY3VtZW50cyA9IG51bGwpID0+IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBsZXQgZG9jdW1lbnRzID0gZXhpc3RpbmdEb2N1bWVudHM7XHJcblxyXG4gICAgICAgICAgICBpZiAoIWRvY3VtZW50cyB8fCBkb2N1bWVudHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCB1c2VySWQgPSBsb2FuRG9jLmxvYW5faWQ/Ll9pZCB8fCBsb2FuRG9jLnVzZXJfaWQgfHwgbG9hbkRvYy5sb2FuSWQ/LnVzZXJfaWQ7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKCF1c2VySWQpIHtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLmVycm9yKFwiQ3VzdG9tZXIgaW5mb3JtYXRpb24gbm90IGZvdW5kXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC92MS9hZG1pbi91c2VyLWRvY3VtZW50cy8ke3VzZXJJZH1gKTtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLmRhdGEpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgdXNlckRvYyA9IHJlc3BvbnNlLmRhdGEuZGF0YTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheSh1c2VyRG9jKSAmJiB1c2VyRG9jLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdXNlckRvYyA9IHVzZXJEb2NbMF07XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGRvY3VtZW50cyA9IHRyYW5zZm9ybVVzZXJEb2N1bWVudHNUb0FycmF5KHVzZXJEb2MpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBkb2N1bWVudHMgPSBbXTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgc2V0Q3VycmVudERvY3VtZW50cyhkb2N1bWVudHMpO1xyXG4gICAgICAgICAgICBzZXRDdXJyZW50TG9hbkZvckRvY3MobG9hbkRvYyk7XHJcbiAgICAgICAgICAgIHNldFNob3dEb2N1bWVudE1vZGFsKHRydWUpO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBkb2N1bWVudHM6XCIsIGVycm9yKTtcclxuICAgICAgICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBkb2N1bWVudHNcIik7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICAvLyBUcmFuc2Zvcm0gdXNlciBkb2N1bWVudHMgdG8gYXJyYXlcclxuICAgIGNvbnN0IHRyYW5zZm9ybVVzZXJEb2N1bWVudHNUb0FycmF5ID0gKHVzZXJEb2MpID0+IHtcclxuICAgICAgICBpZiAoIXVzZXJEb2MpIHJldHVybiBbXTtcclxuXHJcbiAgICAgICAgY29uc3QgZG9jdW1lbnRzID0gW107XHJcblxyXG4gICAgICAgIGNvbnN0IGRvY01hcHBpbmdzID0gW1xyXG4gICAgICAgICAgICB7IGtleTogXCJ1c2VyX3Byb2ZpbGVfcGhvdG9cIiwgbGFiZWw6IFwiUGhvdG9cIiwgaXNJbWFnZTogdHJ1ZSB9LFxyXG4gICAgICAgICAgICB7IGtleTogXCJ1c2VyX2FkaGFyY2FyZF9mcm9udF9waG90b1wiLCBsYWJlbDogXCJBYWRoYXIgQ2FyZCAoRnJvbnQpXCIsIGlzSW1hZ2U6IHRydWUgfSxcclxuICAgICAgICAgICAgeyBrZXk6IFwidXNlcl9hZGhhcmNhcmRfYmFja19waG90b1wiLCBsYWJlbDogXCJBYWRoYXIgQ2FyZCAoQmFjaylcIiwgaXNJbWFnZTogdHJ1ZSB9LFxyXG4gICAgICAgICAgICB7IGtleTogXCJ1c2VyX3BhbmNhcmRfcGhvdG9cIiwgbGFiZWw6IFwiUEFOIENhcmRcIiwgaXNJbWFnZTogdHJ1ZSB9LFxyXG4gICAgICAgICAgICB7IGtleTogXCJ1c2VyX2NoZXF1ZV9sZWFmXCIsIGxhYmVsOiBcIkNoZXF1ZSBMZWFmXCIsIGlzSW1hZ2U6IHRydWUgfSxcclxuICAgICAgICAgICAgeyBrZXk6IFwiYmFua19zdGF0ZW1lbnRfbW9udGhcIiwgbGFiZWw6IFwiQmFuayBTdGF0ZW1lbnRcIiwgaXNJbWFnZTogZmFsc2UgfSxcclxuICAgICAgICAgICAgeyBrZXk6IFwiYmFua19wYXNzYm9va19waG90b1wiLCBsYWJlbDogXCJQYXNzYm9vayBQaG90b1wiLCBpc0ltYWdlOiB0cnVlIH0sXHJcbiAgICAgICAgICAgIHsga2V5OiBcImJ1c2luZXNzX2RvY3VtZW50X3Byb29mXCIsIGxhYmVsOiBcIkJ1c2luZXNzIFByb29mXCIsIGlzSW1hZ2U6IGZhbHNlIH0sXHJcbiAgICAgICAgICAgIHsga2V5OiBcInVzZXJfc2FsYXJ5X3NsaXBcIiwgbGFiZWw6IFwiU2FsYXJ5IFNsaXBcIiwgaXNJbWFnZTogZmFsc2UgfSxcclxuICAgICAgICAgICAgeyBrZXk6IFwidXNlcl9ub21pbmVlX2FkaGFyY2FyZF9mcm9udF9waG90b1wiLCBsYWJlbDogXCJOb21pbmVlIEFhZGhhciAoRnJvbnQpXCIsIGlzSW1hZ2U6IHRydWUgfSxcclxuICAgICAgICAgICAgeyBrZXk6IFwidXNlcl9ub21pbmVlX2FkaGFyY2FyZF9iYWNrX3Bob3RvXCIsIGxhYmVsOiBcIk5vbWluZWUgQWFkaGFyIChCYWNrKVwiLCBpc0ltYWdlOiB0cnVlIH0sXHJcbiAgICAgICAgICAgIHsga2V5OiBcInVzZXJfbm9taW5lZV9wYW5jYXJkX3Bob3RvXCIsIGxhYmVsOiBcIk5vbWluZWUgUEFOIENhcmRcIiwgaXNJbWFnZTogdHJ1ZSB9LFxyXG4gICAgICAgIF07XHJcblxyXG4gICAgICAgIGRvY01hcHBpbmdzLmZvckVhY2goKG1hcHBpbmcpID0+IHtcclxuICAgICAgICAgICAgaWYgKHVzZXJEb2NbbWFwcGluZy5rZXldKSB7XHJcbiAgICAgICAgICAgICAgICBkb2N1bWVudHMucHVzaCh7XHJcbiAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnRfdHlwZTogbWFwcGluZy5sYWJlbCxcclxuICAgICAgICAgICAgICAgICAgICBmaWxlX3VybDogdXNlckRvY1ttYXBwaW5nLmtleV0sXHJcbiAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IGAke21hcHBpbmcubGFiZWx9IGRvY3VtZW50YCxcclxuICAgICAgICAgICAgICAgICAgICBpc0ltYWdlOiBtYXBwaW5nLmlzSW1hZ2UsXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gZG9jdW1lbnRzO1xyXG4gICAgfTtcclxuXHJcbiAgICAvLyBDYWxjdWxhdGUgZG9jdW1lbnQgdXBsb2FkIHBlcmNlbnRhZ2VcclxuICAgIGNvbnN0IGNhbGN1bGF0ZURvY3VtZW50UGVyY2VudGFnZSA9IChkb2N1bWVudHMpID0+IHtcclxuICAgICAgICBpZiAoIWRvY3VtZW50cyB8fCBkb2N1bWVudHMubGVuZ3RoID09PSAwKSByZXR1cm4gMDtcclxuXHJcbiAgICAgICAgY29uc3QgdXBsb2FkZWREb2NzID0gZG9jdW1lbnRzLmZpbHRlcihcclxuICAgICAgICAgICAgKGRvYykgPT4gZG9jLmZpbGVfdXJsICYmIGRvYy5kb2N1bWVudF90eXBlICE9PSBcIkRvY3VtZW50IFJlZmVyZW5jZVwiLFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgY29uc3QgdG90YWxSZXF1aXJlZERvY3MgPSBSRVFVSVJFRF9MT0FOX0RPQ1VNRU5UUy5sZW5ndGg7XHJcbiAgICAgICAgY29uc3QgcGVyY2VudGFnZSA9ICh1cGxvYWRlZERvY3MubGVuZ3RoIC8gdG90YWxSZXF1aXJlZERvY3MpICogMTAwO1xyXG4gICAgICAgIHJldHVybiBNYXRoLnJvdW5kKHBlcmNlbnRhZ2UpO1xyXG4gICAgfTtcclxuXHJcbiAgICAvLyBIYW5kbGUgZG9jdW1lbnQgcHJldmlld1xyXG4gICAgY29uc3QgaGFuZGxlUHJldmlldyA9IChpbWFnZVVybCwgdGl0bGUpID0+IHtcclxuICAgICAgICBzZXRQcmV2aWV3SW1hZ2UoaW1hZ2VVcmwpO1xyXG4gICAgICAgIHNldFByZXZpZXdUaXRsZSh0aXRsZSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUNhbmNlbFByZXZpZXcgPSAoKSA9PiB7XHJcbiAgICAgICAgc2V0UHJldmlld0ltYWdlKG51bGwpO1xyXG4gICAgICAgIHNldFByZXZpZXdUaXRsZShcIlwiKTtcclxuICAgIH07XHJcblxyXG4gICAgLy8gSGFuZGxlIGRvY3VtZW50IGFjdGlvbnMgZnJvbSBtb2RhbFxyXG4gICAgY29uc3QgaGFuZGxlRG9jdW1lbnRBY3Rpb24gPSBhc3luYyAoYWN0aW9uKSA9PiB7XHJcbiAgICAgICAgaWYgKCFjdXJyZW50TG9hbkZvckRvY3MpIHJldHVybjtcclxuXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgbGV0IG5ld1N0YXR1cyA9IFwiXCI7XHJcbiAgICAgICAgICAgIHN3aXRjaCAoYWN0aW9uKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIFwidmVyaWZ5XCI6XHJcbiAgICAgICAgICAgICAgICAgICAgbmV3U3RhdHVzID0gXCJEb2N1bWVudCBWZXJpZmljYXRpb25cIjtcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgXCJjb21wbGV0ZVwiOlxyXG4gICAgICAgICAgICAgICAgICAgIG5ld1N0YXR1cyA9IFwiQ29tcGxldGVkXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICBjYXNlIFwicGVuZGluZ1wiOlxyXG4gICAgICAgICAgICAgICAgICAgIG5ld1N0YXR1cyA9IFwiUGVuZGluZ1wiO1xyXG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKG5ld1N0YXR1cykge1xyXG4gICAgICAgICAgICAgICAgYXdhaXQgdXBkYXRlTG9hbkRvY3VtZW50U3RhdHVzKGN1cnJlbnRMb2FuRm9yRG9jcy5faWQgfHwgY3VycmVudExvYW5Gb3JEb2NzLmtleSwgbmV3U3RhdHVzKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgc2V0U2hvd0RvY3VtZW50TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgICBzZXRDdXJyZW50RG9jdW1lbnRzKFtdKTtcclxuICAgICAgICAgICAgc2V0Q3VycmVudExvYW5Gb3JEb2NzKG51bGwpO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBkb2N1bWVudCBzdGF0dXM6XCIsIGVycm9yKTtcclxuICAgICAgICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byB1cGRhdGUgZG9jdW1lbnQgc3RhdHVzXCIpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgLy8gRGF0ZSBmaWx0ZXIgaGFuZGxlclxyXG4gICAgY29uc3QgaGFuZGxlRGF0ZUZpbHRlciA9IChkYXRlcykgPT4ge1xyXG4gICAgICAgIGlmICghZGF0ZXMgfHwgIWRhdGVzWzBdIHx8ICFkYXRlc1sxXSkge1xyXG4gICAgICAgICAgICBzZXREYXRlUmFuZ2UoW251bGwsIG51bGxdKTtcclxuICAgICAgICAgICAgcmVzZXRGaWx0ZXJzKCk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHNldERhdGVSYW5nZShkYXRlcyk7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRQZW5kaW5nKGZpbHRlckRhdGFCeURhdGUocGVuZGluZ0RhdGEsIGRhdGVzKSk7XHJcbiAgICAgICAgc2V0RmlsdGVyZWREb2NDb2xsZWN0aW9uKGZpbHRlckRhdGFCeURhdGUoZG9jdW1lbnRDb2xsZWN0aW9uRGF0YSwgZGF0ZXMpKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZERvY1ZlcmlmaWNhdGlvbihmaWx0ZXJEYXRhQnlEYXRlKGRvY3VtZW50VmVyaWZpY2F0aW9uRGF0YSwgZGF0ZXMpKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZENvbXBsZXRlZChmaWx0ZXJEYXRhQnlEYXRlKGNvbXBsZXRlZERhdGEsIGRhdGVzKSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGZpbHRlckRhdGFCeURhdGUgPSAoZGF0YSwgZGF0ZXMpID0+IHtcclxuICAgICAgICBpZiAoIWRhdGVzIHx8ICFkYXRlc1swXSB8fCAhZGF0ZXNbMV0pIHJldHVybiBkYXRhO1xyXG5cclxuICAgICAgICBjb25zdCBbc3RhcnQsIGVuZF0gPSBkYXRlcztcclxuXHJcbiAgICAgICAgcmV0dXJuIGRhdGEuZmlsdGVyKChpdGVtKSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBpdGVtRGF0ZSA9IGl0ZW0udGltZSB8fCBpdGVtLmNyZWF0ZWRfYXQ7XHJcbiAgICAgICAgICAgIGlmICghaXRlbURhdGUpIHJldHVybiB0cnVlO1xyXG5cclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBpdGVtRGF0ZSA9PT0gXCJzdHJpbmdcIiAmJiBpdGVtRGF0ZS5pbmNsdWRlcyhcIlRcIikpIHtcclxuICAgICAgICAgICAgICAgIGl0ZW1EYXRlID0gaXRlbURhdGUuc3BsaXQoXCJUXCIpWzBdO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBjb25zdCBkb2NEYXRlID0gZGF5anMoaXRlbURhdGUpO1xyXG4gICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgZG9jRGF0ZS5pc0FmdGVyKHN0YXJ0LnN1YnRyYWN0KDEsIFwiZGF5XCIpKSAmJlxyXG4gICAgICAgICAgICAgICAgZG9jRGF0ZS5pc0JlZm9yZShlbmQuYWRkKDEsIFwiZGF5XCIpKVxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCByZXNldEZpbHRlcnMgPSAoKSA9PiB7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRQZW5kaW5nKHBlbmRpbmdEYXRhKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZERvY0NvbGxlY3Rpb24oZG9jdW1lbnRDb2xsZWN0aW9uRGF0YSk7XHJcbiAgICAgICAgc2V0RmlsdGVyZWREb2NWZXJpZmljYXRpb24oZG9jdW1lbnRWZXJpZmljYXRpb25EYXRhKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZENvbXBsZXRlZChjb21wbGV0ZWREYXRhKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgcmVzZXRBbGxUYWJEYXRhID0gKCkgPT4ge1xyXG4gICAgICAgIHNldFBlbmRpbmdEYXRhKFtdKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZFBlbmRpbmcoW10pO1xyXG4gICAgICAgIHNldERvY3VtZW50Q29sbGVjdGlvbkRhdGEoW10pO1xyXG4gICAgICAgIHNldEZpbHRlcmVkRG9jQ29sbGVjdGlvbihbXSk7XHJcbiAgICAgICAgc2V0RG9jdW1lbnRWZXJpZmljYXRpb25EYXRhKFtdKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZERvY1ZlcmlmaWNhdGlvbihbXSk7XHJcbiAgICAgICAgc2V0Q29tcGxldGVkRGF0YShbXSk7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRDb21wbGV0ZWQoW10pO1xyXG4gICAgfTtcclxuXHJcbiAgICAvLyBIYW5kbGUgYnVsayBzdGF0dXMgdXBkYXRlIGZvciBQZW5kaW5nIHRhYlxyXG4gICAgY29uc3QgaGFuZGxlQnVsa1N0YXR1c1VwZGF0ZSA9IChuZXdTdGF0dXMpID0+IHtcclxuICAgICAgICBjb25zdCBzZWxlY3RlZEl0ZW1zID0gZmlsdGVyZWRQZW5kaW5nLmZpbHRlcihcclxuICAgICAgICAgICAgKGl0ZW0pID0+IGFjdGl2ZVVzZXJEYXRhW2l0ZW0ua2V5XT8uaW5mbz8uc3RhdHVzLFxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIGlmIChzZWxlY3RlZEl0ZW1zLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgICAgICBtZXNzYWdlLndhcm5pbmcoXCJQbGVhc2Ugc2VsZWN0IGxvYW4gZG9jdW1lbnRzIHRvIHVwZGF0ZVwiKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgTW9kYWwuY29uZmlybSh7XHJcbiAgICAgICAgICAgIHRpdGxlOiBgQnVsayBVcGRhdGUgQ29uZmlybWF0aW9uYCxcclxuICAgICAgICAgICAgY29udGVudDogYFlvdSBhcmUgYWJvdXQgdG8gdXBkYXRlIHN0YXR1cyB0byBcIiR7bmV3U3RhdHVzfVwiIGZvciAke3NlbGVjdGVkSXRlbXMubGVuZ3RofSBsb2FuIGRvY3VtZW50KHMpLiBBcmUgeW91IHN1cmU/YCxcclxuICAgICAgICAgICAgb2tUZXh0OiBcIlllcywgVXBkYXRlXCIsXHJcbiAgICAgICAgICAgIGNhbmNlbFRleHQ6IFwiTm9cIixcclxuICAgICAgICAgICAgb25PazogYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgICAgICBhd2FpdCBQcm9taXNlLmFsbChcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRJdGVtcy5tYXAoKGl0ZW0pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVMb2FuRG9jdW1lbnRTdGF0dXMoaXRlbS5rZXksIG5ld1N0YXR1cyksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnN1Y2Nlc3MoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGAke3NlbGVjdGVkSXRlbXMubGVuZ3RofSBsb2FuIGRvY3VtZW50cyBtb3ZlZCB0byAke25ld1N0YXR1c31gLFxyXG4gICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gdXBkYXRlIHNvbWUgbG9hbiBkb2N1bWVudHNcIik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgfSk7XHJcbiAgICB9O1xyXG5cclxuICAgIC8vIEhhbmRsZSBidWxrIGRlbGV0ZVxyXG4gICAgY29uc3QgaGFuZGxlQnVsa0RlbGV0ZSA9ICgpID0+IHtcclxuICAgICAgICBjb25zdCBzZWxlY3RlZEl0ZW1zID0gZmlsdGVyZWRQZW5kaW5nLmZpbHRlcihcclxuICAgICAgICAgICAgKGl0ZW0pID0+IGFjdGl2ZVVzZXJEYXRhW2l0ZW0ua2V5XT8uaW5mbz8uc3RhdHVzLFxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIGlmIChzZWxlY3RlZEl0ZW1zLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgICAgICBtZXNzYWdlLndhcm5pbmcoXCJQbGVhc2Ugc2VsZWN0IGxvYW4gZG9jdW1lbnRzIHRvIGRlbGV0ZVwiKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgTW9kYWwuY29uZmlybSh7XHJcbiAgICAgICAgICAgIHRpdGxlOiBgRGVsZXRlIENvbmZpcm1hdGlvbmAsXHJcbiAgICAgICAgICAgIGNvbnRlbnQ6IGBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gZGVsZXRlICR7c2VsZWN0ZWRJdGVtcy5sZW5ndGh9IGxvYW4gZG9jdW1lbnQocyk/IFRoaXMgYWN0aW9uIGNhbm5vdCBiZSB1bmRvbmUuYCxcclxuICAgICAgICAgICAgb2tUZXh0OiBcIlllcywgRGVsZXRlXCIsXHJcbiAgICAgICAgICAgIG9rVHlwZTogXCJkYW5nZXJcIixcclxuICAgICAgICAgICAgY2FuY2VsVGV4dDogXCJOb1wiLFxyXG4gICAgICAgICAgICBvbk9rOiBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IFByb21pc2UuYWxsKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEl0ZW1zLm1hcCgoaXRlbSkgPT4gaGFuZGxlRGVsZXRlTG9hbkRvY3VtZW50KGl0ZW0ua2V5KSksXHJcbiAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLnN1Y2Nlc3MoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGAke3NlbGVjdGVkSXRlbXMubGVuZ3RofSBsb2FuIGRvY3VtZW50cyBkZWxldGVkIHN1Y2Nlc3NmdWxseWAsXHJcbiAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBkZWxldGUgc29tZSBsb2FuIGRvY3VtZW50c1wiKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICB9KTtcclxuICAgIH07XHJcblxyXG4gICAgLy8gSGFuZGxlIGNoZWNrYm94IGNoYW5nZVxyXG4gICAgY29uc3QgaGFuZGxlQ2hlY2tib3hDaGFuZ2UgPSAoaXRlbSkgPT4ge1xyXG4gICAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICBbaXRlbS5rZXldOiB7XHJcbiAgICAgICAgICAgICAgICBpbmZvOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiAhcHJldltpdGVtLmtleV0/LmluZm8/LnN0YXR1cyxcclxuICAgICAgICAgICAgICAgICAgICBsb2FuX2NvZGU6IGl0ZW0ubG9hbl9jb2RlLFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU6IGl0ZW0uY3VzdG9tZXJfbmFtZSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgfSkpO1xyXG4gICAgfTtcclxuXHJcbiAgICAvLyBIYW5kbGUgc2VsZWN0IGFsbFxyXG4gICAgY29uc3QgaGFuZGxlU2VsZWN0QWxsQ2hhbmdlID0gKGUpID0+IHtcclxuICAgICAgICBjb25zdCBjaGVja2VkID0gZS50YXJnZXQuY2hlY2tlZDtcclxuICAgICAgICBzZXRTZWxlY3RBbGwoY2hlY2tlZCk7XHJcbiAgICAgICAgY29uc3QgdXBkYXRlZCA9IHsgLi4uYWN0aXZlVXNlckRhdGEgfTtcclxuICAgICAgICBmaWx0ZXJlZFBlbmRpbmcuZm9yRWFjaCgoaXRlbSkgPT4ge1xyXG4gICAgICAgICAgICB1cGRhdGVkW2l0ZW0ua2V5XSA9IHtcclxuICAgICAgICAgICAgICAgIGluZm86IHtcclxuICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IGNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgbG9hbl9jb2RlOiBpdGVtLmxvYW5fY29kZSxcclxuICAgICAgICAgICAgICAgICAgICBuYW1lOiBpdGVtLmN1c3RvbWVyX25hbWUsXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKHVwZGF0ZWQpO1xyXG4gICAgfTtcclxuXHJcbiAgICAvLyBHZXQgc2VsZWN0ZWQgY291bnRcclxuICAgIGNvbnN0IHNlbGVjdGVkQ291bnQgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgICAgICByZXR1cm4gZmlsdGVyZWRQZW5kaW5nLmZpbHRlcihcclxuICAgICAgICAgICAgKGl0ZW0pID0+IGFjdGl2ZVVzZXJEYXRhW2l0ZW0ua2V5XT8uaW5mbz8uc3RhdHVzLFxyXG4gICAgICAgICkubGVuZ3RoO1xyXG4gICAgfSwgW2ZpbHRlcmVkUGVuZGluZywgYWN0aXZlVXNlckRhdGFdKTtcclxuXHJcbiAgICAvLyBVcGRhdGUgc2VsZWN0IGFsbCBzdGF0ZVxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBjb25zdCBhbGxDaGVja2VkID1cclxuICAgICAgICAgICAgZmlsdGVyZWRQZW5kaW5nLmxlbmd0aCA+IDAgJiZcclxuICAgICAgICAgICAgZmlsdGVyZWRQZW5kaW5nLmV2ZXJ5KChpdGVtKSA9PiBhY3RpdmVVc2VyRGF0YVtpdGVtLmtleV0/LmluZm8/LnN0YXR1cyk7XHJcbiAgICAgICAgc2V0U2VsZWN0QWxsKGFsbENoZWNrZWQpO1xyXG4gICAgfSwgW2ZpbHRlcmVkUGVuZGluZywgYWN0aXZlVXNlckRhdGFdKTtcclxuXHJcbiAgICAvLyBDYWxjdWxhdGUgc3RhdGlzdGljcyBmb3IgUGVuZGluZyB0YWJcclxuICAgIGNvbnN0IHRvdGFsTG9hbkFtb3VudCA9IGZpbHRlcmVkUGVuZGluZy5yZWR1Y2UoXHJcbiAgICAgICAgKHN1bSwgaXRlbSkgPT4gc3VtICsgKHBhcnNlRmxvYXQoaXRlbS5sb2FuX2Ftb3VudCkgfHwgMCksXHJcbiAgICAgICAgMCxcclxuICAgICk7XHJcblxyXG4gICAgLy8gRm9ybWF0IHBlbmRpbmcgZGF0YSBmb3IgRGF0YVRhYmxlXHJcbiAgICBjb25zdCBmb3JtYXR0ZWRQZW5kaW5nRGF0YSA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgICAgIHJldHVybiBmaWx0ZXJlZFBlbmRpbmcubWFwKChpdGVtKSA9PiAoe1xyXG4gICAgICAgICAgICAuLi5pdGVtLFxyXG4gICAgICAgICAgICBjaGVja2JveDogKFxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXthY3RpdmVVc2VyRGF0YVtpdGVtLmtleV0/LmluZm8/LnN0YXR1cyB8fCBmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gaGFuZGxlQ2hlY2tib3hDaGFuZ2UoaXRlbSl9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCBjdXJzb3ItcG9pbnRlciBhY2NlbnQtdmlvbGV0LTYwMFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApLFxyXG4gICAgICAgICAgICBsb2FuX2Ftb3VudDogKFxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWVtZXJhbGQtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAg4oK5eyhwYXJzZUZsb2F0KGl0ZW0ubG9hbl9hbW91bnQpIHx8IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgfSkpO1xyXG4gICAgfSwgW2ZpbHRlcmVkUGVuZGluZywgYWN0aXZlVXNlckRhdGFdKTtcclxuXHJcbiAgICAvLyBTZWFyY2ggaGFuZGxlclxyXG4gICAgY29uc3Qgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgICAgICBzZXRTZWFyY2hUZXh0KGUudGFyZ2V0LnZhbHVlKTtcclxuICAgIH07XHJcblxyXG4gICAgLy8gQ29sdW1uIGRlZmluaXRpb25zXHJcbiAgICBjb25zdCBwZW5kaW5nQ29sdW1ucyA9IFtcclxuICAgICAgICB7IGtleTogXCJjaGVja2JveFwiLCBoZWFkZXI6IFwiU2VsZWN0XCIgfSxcclxuICAgICAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgICAgICB7IGtleTogXCJsb2FuX2NvZGVcIiwgaGVhZGVyOiBcIkxvYW4gQ29kZVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiY3VzdG9tZXJfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcImxvYW5fYW1vdW50XCIsIGhlYWRlcjogXCJMb2FuIEFtb3VudFwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcInRpbWVcIiwgaGVhZGVyOiBcIkNyZWF0ZWQgRGF0ZVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gICAgXTtcclxuXHJcbiAgICBjb25zdCBkb2NDb2xsZWN0aW9uQ29sdW1ucyA9IFtcclxuICAgICAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgICAgICB7IGtleTogXCJsb2FuX2NvZGVcIiwgaGVhZGVyOiBcIkxvYW4gQ29kZVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiY3VzdG9tZXJfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcImxvYW5fYW1vdW50XCIsIGhlYWRlcjogXCJMb2FuIEFtb3VudFwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcInRpbWVcIiwgaGVhZGVyOiBcIlVwZGF0ZWQgRGF0ZVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiZG9jdW1lbnRcIiwgaGVhZGVyOiBcIkRvY3VtZW50XCIgfSxcclxuICAgICAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgICBdO1xyXG5cclxuICAgIGNvbnN0IGRvY1ZlcmlmaWNhdGlvbkNvbHVtbnMgPSBbXHJcbiAgICAgICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwibG9hbl9jb2RlXCIsIGhlYWRlcjogXCJMb2FuIENvZGVcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcImN1c3RvbWVyX25hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgICAgICB7IGtleTogXCJsb2FuX2Ftb3VudFwiLCBoZWFkZXI6IFwiTG9hbiBBbW91bnRcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcInN0YXR1c1wiLCBoZWFkZXI6IFwiU3RhdHVzXCIgfSxcclxuICAgICAgICB7IGtleTogXCJ0aW1lXCIsIGhlYWRlcjogXCJVcGRhdGVkIERhdGVcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcImRvY3VtZW50XCIsIGhlYWRlcjogXCJEb2N1bWVudFwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gICAgXTtcclxuXHJcbiAgICBjb25zdCBjb21wbGV0ZWRDb2x1bW5zID0gW1xyXG4gICAgICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgICAgIHsga2V5OiBcImxvYW5fY29kZVwiLCBoZWFkZXI6IFwiTG9hbiBDb2RlXCIgfSxcclxuICAgICAgICB7IGtleTogXCJjdXN0b21lcl9uYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgICAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwibG9hbl9hbW91bnRcIiwgaGVhZGVyOiBcIkxvYW4gQW1vdW50XCIgfSxcclxuICAgICAgICB7IGtleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwidGltZVwiLCBoZWFkZXI6IFwiQ29tcGxldGVkIERhdGVcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICAgIF07XHJcblxyXG4gICAgLy8gVGFicyBkZWZpbml0aW9uXHJcbiAgICBjb25zdCB0YWJzID0gW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgaWQ6IFwicGVuZGluZ1wiLFxyXG4gICAgICAgICAgICBsYWJlbDogXCJQZW5kaW5nXCIsXHJcbiAgICAgICAgICAgIGNvdW50OiBmaWx0ZXJlZFBlbmRpbmcubGVuZ3RoLFxyXG4gICAgICAgICAgICBpY29uOiA8SW9XYWxsZXQgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDBcIiAvPixcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgaWQ6IFwiZG9jdW1lbnRfY29sbGVjdGlvblwiLFxyXG4gICAgICAgICAgICBsYWJlbDogXCJEb2N1bWVudCBDb2xsZWN0aW9uXCIsXHJcbiAgICAgICAgICAgIGNvdW50OiBmaWx0ZXJlZERvY0NvbGxlY3Rpb24ubGVuZ3RoLFxyXG4gICAgICAgICAgICBpY29uOiA8SW9Eb2N1bWVudFRleHQgY2xhc3NOYW1lPVwidGV4dC1hbWJlci01MDBcIiAvPixcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgaWQ6IFwiZG9jdW1lbnRfdmVyaWZpY2F0aW9uXCIsXHJcbiAgICAgICAgICAgIGxhYmVsOiBcIkRvY3VtZW50IFZlcmlmaWNhdGlvblwiLFxyXG4gICAgICAgICAgICBjb3VudDogZmlsdGVyZWREb2NWZXJpZmljYXRpb24ubGVuZ3RoLFxyXG4gICAgICAgICAgICBpY29uOiA8SW9DaGVja21hcmtDaXJjbGUgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNTAwXCIgLz4sXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiBcImNvbXBsZXRlZFwiLFxyXG4gICAgICAgICAgICBsYWJlbDogXCJDb21wbGV0ZWRcIixcclxuICAgICAgICAgICAgY291bnQ6IGZpbHRlcmVkQ29tcGxldGVkLmxlbmd0aCxcclxuICAgICAgICAgICAgaWNvbjogPElvRmxhZyBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNTAwXCIgLz4sXHJcbiAgICAgICAgfSxcclxuICAgIF07XHJcblxyXG4gICAgLy8gUmVuZGVyIHRhYiBjb250ZW50XHJcbiAgICBjb25zdCByZW5kZXJUYWJDb250ZW50ID0gKCkgPT4ge1xyXG4gICAgICAgIGlmIChpc0xvYWRpbmcpIHtcclxuICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgcHktMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgc3dpdGNoIChhY3RpdmVUYWIpIHtcclxuICAgICAgICAgICAgY2FzZSBcInBlbmRpbmdcIjpcclxuICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkQ291bnQgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLXZpb2xldC01MCB0by1wdXJwbGUtNTAgYm9yZGVyIGJvcmRlci12aW9sZXQtMjAwIHJvdW5kZWQtbGcgc2hhZG93IHAtNCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy12aW9sZXQtNjAwIHRleHQtd2hpdGUgcm91bmRlZC1mdWxsIGgtMTAgdy0xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmb250LWJvbGQgdGV4dC1sZyBzaGFkb3ctbWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRDb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIHRleHQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBJdGVtKHMpIFNlbGVjdGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0zIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXZpb2xldC02MDAgaG92ZXI6YmctdmlvbGV0LTcwMCBib3JkZXItdmlvbGV0LTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQnVsa1N0YXR1c1VwZGF0ZShcIkRvY3VtZW50IENvbGxlY3Rpb25cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU3RhcnQgRG9jdW1lbnQgQ29sbGVjdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGFuZ2VyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQnVsa0RlbGV0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJob3ZlcjpiZy1yZWQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEZWxldGUgU2VsZWN0ZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkUGVuZGluZz8ubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgcC0zIGJnLWdyYXktNTAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IGN1cnNvci1wb2ludGVyIGFjY2VudC12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17c2VsZWN0QWxsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU2VsZWN0QWxsQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RBbGwgPyBcIkRlc2VsZWN0IEFsbFwiIDogXCJTZWxlY3QgQWxsXCJ9IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkUGVuZGluZy5sZW5ndGh9IGl0ZW1zKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHB5LTEwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IGZpbHRlcmVkUGVuZGluZz8ubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJPcHRpb24oZm9ybWF0dGVkUGVuZGluZ0RhdGEsIHNlYXJjaFRleHQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e3BlbmRpbmdDb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJMb2FuX1BlbmRpbmcuY3N2XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTEwIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBObyBwZW5kaW5nIGxvYW4gZG9jdW1lbnRzIGF2YWlsYWJsZS5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgIGNhc2UgXCJkb2N1bWVudF9jb2xsZWN0aW9uXCI6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmlsdGVyZWREb2NDb2xsZWN0aW9uPy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKGZpbHRlcmVkRG9jQ29sbGVjdGlvbiwgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2RvY0NvbGxlY3Rpb25Db2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiTG9hbl9Eb2N1bWVudF9Db2xsZWN0aW9uLmNzdlwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMCB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE5vIHJlY29yZHMgaW4gRG9jdW1lbnQgQ29sbGVjdGlvbi5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICBjYXNlIFwiZG9jdW1lbnRfdmVyaWZpY2F0aW9uXCI6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZmlsdGVyZWREb2NWZXJpZmljYXRpb24/Lmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJPcHRpb24oZmlsdGVyZWREb2NWZXJpZmljYXRpb24sIHNlYXJjaFRleHQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtkb2NWZXJpZmljYXRpb25Db2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiTG9hbl9Eb2N1bWVudF9WZXJpZmljYXRpb24uY3N2XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTEwIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTm8gcmVjb3JkcyBpbiBEb2N1bWVudCBWZXJpZmljYXRpb24uXHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgY2FzZSBcImNvbXBsZXRlZFwiOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZpbHRlcmVkQ29tcGxldGVkPy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKGZpbHRlcmVkQ29tcGxldGVkLCBzZWFyY2hUZXh0KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29tcGxldGVkQ29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIkxvYW5fQ29tcGxldGVkLmNzdlwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMCB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE5vIGNvbXBsZXRlZCByZWNvcmRzLlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICAgICAgICBvcGVuPXtwcmV2aWV3SW1hZ2UgIT09IG51bGx9XHJcbiAgICAgICAgICAgICAgICB0aXRsZT17cHJldmlld1RpdGxlfVxyXG4gICAgICAgICAgICAgICAgZm9vdGVyPXtudWxsfVxyXG4gICAgICAgICAgICAgICAgb25DYW5jZWw9e2hhbmRsZUNhbmNlbFByZXZpZXd9XHJcbiAgICAgICAgICAgICAgICB3aWR0aD1cImF1dG9cIlxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgbWF4V2lkdGg6IFwiOTB2d1wiIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxpbWcgYWx0PXtwcmV2aWV3VGl0bGV9IHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fSBzcmM9e3ByZXZpZXdJbWFnZX0gLz5cclxuICAgICAgICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgICAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPFNpZGViYXIgLz5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgICAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBMb2FuIERvY3VtZW50YXRpb24gTWFuYWdlbWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVHJhY2sgYW5kIG1hbmFnZSBsb2FuIGRvY3VtZW50YXRpb24gcHJvY2Vzc2VzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVRhYiA9PT0gXCJwZW5kaW5nXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC01IHB5LTMgYmctZ3JhZGllbnQtdG8tciBmcm9tLWVtZXJhbGQtNTAgdG8tdGVhbC01MCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwIHJvdW5kZWQteGwgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYUZpbGVDb250cmFjdCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZW1lcmFsZC02MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBMb2FuIEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXt0b3RhbExvYW5BbW91bnQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC0xMCBib3JkZXItbCBib3JkZXItZW1lcmFsZC0zMDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC12aW9sZXQtNjAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGVuZGluZyBEb2N1bWVudHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtdmlvbGV0LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZFBlbmRpbmcubGVuZ3RofVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgaW5saW5lLWJsb2NrIHAtMyBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbWQgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIERhdGUgRmlsdGVyOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFJhbmdlUGlja2VyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZURhdGVGaWx0ZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybWF0PVwiWVlZWS1NTS1ERFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e1tcIlN0YXJ0IERhdGVcIiwgXCJFbmQgRGF0ZVwiXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTU2XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtkYXRlUmFuZ2U/LlswXSAmJiBkYXRlUmFuZ2U/LlsxXSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXREYXRlUmFuZ2UoW251bGwsIG51bGxdKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc2V0RmlsdGVycygpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDAgcHgtMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDbGVhciBGaWx0ZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxuYXYgY2xhc3NOYW1lPVwiZmxleCBzcGFjZS14LThcIiBhcmlhLWxhYmVsPVwiVGFic1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0YWJzLm1hcCgodGFiKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17dGFiLmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKHRhYi5pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Bncm91cCBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHktNCBweC0xIGJvcmRlci1iLTIgZm9udC1tZWRpdW0gdGV4dC1zbSAke2FjdGl2ZVRhYiA9PT0gdGFiLmlkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci12aW9sZXQtNTAwIHRleHQtdmlvbGV0LTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci10cmFuc3BhcmVudCB0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS03MDAgaG92ZXI6Ym9yZGVyLWdyYXktMzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibXItMiB0ZXh0LWxnXCI+e3RhYi5pY29ufTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt0YWIubGFiZWx9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RhYi5jb3VudCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YG1sLTMgcHktMC41IHB4LTIgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1tZWRpdW0gJHthY3RpdmVUYWIgPT09IHRhYi5pZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLXZpb2xldC0xMDAgdGV4dC12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RhYi5jb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbmF2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02XCI+e3JlbmRlclRhYkNvbnRlbnQoKX08L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBEb2N1bWVudCBWaWV3IE1vZGFsICovfVxyXG4gICAgICAgICAgICAgICAgPE1vZGFsQ29tcG9uZW50XHJcbiAgICAgICAgICAgICAgICAgICAgaXNWaXNpYmxlPXtzaG93RG9jdW1lbnRNb2RhbH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dEb2N1bWVudE1vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q3VycmVudERvY3VtZW50cyhbXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEN1cnJlbnRMb2FuRm9yRG9jcyhudWxsKTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoPVwiOTAwcHhcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LWgtWzcwdmhdIG92ZXJmbG93LXktYXV0byBzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tZW1lcmFsZC01MCB0by10ZWFsLTUwIGJvcmRlciBib3JkZXItZW1lcmFsZC0xMDAgcm91bmRlZC14bCBwLTQgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTQgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQteHNcIj5DdXN0b21lciBOYW1lPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50TG9hbkZvckRvY3M/LmxvYW5fZGF0YT8udXNlcl9pZD8uZnVsbF9uYW1lIHx8IGN1cnJlbnRMb2FuRm9yRG9jcz8ubG9hbl9kYXRhPy5sb2FuSWQ/LnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC14c1wiPlBob25lIE51bWJlcjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudExvYW5Gb3JEb2NzPy5sb2FuX2RhdGE/LnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBjdXJyZW50TG9hbkZvckRvY3M/LmxvYW5fZGF0YT8ubG9hbklkPy51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQteHNcIj5Mb2FuIENvZGU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRMb2FuRm9yRG9jcz8ubG9hbl9kYXRhPy5sb2FuSWQ/LmxvYW5fY29kZSB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC14bCBwLTQgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIERvY3VtZW50IFVwbG9hZCBQcm9ncmVzc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgJHtjYWxjdWxhdGVEb2N1bWVudFBlcmNlbnRhZ2UoY3VycmVudERvY3VtZW50cykgPT09IDEwMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcInRleHQtZW1lcmFsZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBjYWxjdWxhdGVEb2N1bWVudFBlcmNlbnRhZ2UoY3VycmVudERvY3VtZW50cykgPj0gNzBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwidGV4dC1hbWJlci02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2FsY3VsYXRlRG9jdW1lbnRQZXJjZW50YWdlKGN1cnJlbnREb2N1bWVudHMpfSVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQcm9ncmVzc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlcmNlbnQ9e2NhbGN1bGF0ZURvY3VtZW50UGVyY2VudGFnZShjdXJyZW50RG9jdW1lbnRzKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUNvbG9yPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICcwJSc6ICcjZWY0NDQ0JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJzcwJSc6ICcjZjU5ZTBiJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJzEwMCUnOiAnIzEwYjk4MScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIG10LTMgdGV4dC14cyB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFVwbG9hZGVkOntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnREb2N1bWVudHMuZmlsdGVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGRvYykgPT4gZG9jLmZpbGVfdXJsICYmIGRvYy5kb2N1bWVudF90eXBlICE9PSBcIkRvY3VtZW50IFJlZmVyZW5jZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApLmxlbmd0aH17XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8ge1JFUVVJUkVEX0xPQU5fRE9DVU1FTlRTLmxlbmd0aH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJlbWFpbmluZzp7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtSRVFVSVJFRF9MT0FOX0RPQ1VNRU5UUy5sZW5ndGggLVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudERvY3VtZW50cy5maWx0ZXIoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGRvYykgPT4gZG9jLmZpbGVfdXJsICYmIGRvYy5kb2N1bWVudF90eXBlICE9PSBcIkRvY3VtZW50IFJlZmVyZW5jZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKS5sZW5ndGh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnREb2N1bWVudHMubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50RG9jdW1lbnRzLm1hcCgoZG9jLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2luZGV4fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLXhsIHAtNCBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbiBiZy13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZG9jLmRvY3VtZW50X3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZG9jLmZpbGVfdXJsICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW9FeWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVQcmV2aWV3KGRvYy5maWxlX3VybCwgZG9jLmRvY3VtZW50X3R5cGUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTYwMCBjdXJzb3ItcG9pbnRlciB0ZXh0LWxnIGhvdmVyOnNjYWxlLTExMCB0cmFuc2l0aW9uLXRyYW5zZm9ybVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBocmVmPXtkb2MuZmlsZV91cmx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW9Eb3dubG9hZCBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNjAwIHRleHQtbGcgaG92ZXI6c2NhbGUtMTEwIHRyYW5zaXRpb24tdHJhbnNmb3JtXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQtbGcgcC0yIGgtMzIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZG9jLmlzSW1hZ2UgJiYgZG9jLmZpbGVfdXJsID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2RvYy5maWxlX3VybH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD17ZG9jLmRvY3VtZW50X3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLWZ1bGwgb2JqZWN0LWNvbnRhaW4gY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUHJldmlldyhkb2MuZmlsZV91cmwsIGRvYy5kb2N1bWVudF90eXBlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogZG9jLmZpbGVfdXJsID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW9Eb2N1bWVudCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIHRleHQtNHhsXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vIGZpbGUgdXBsb2FkZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW9Eb2N1bWVudCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIHRleHQtNXhsIG14LWF1dG8gbWItM1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBObyBkb2N1bWVudHMgdXBsb2FkZWQgZm9yIHRoaXMgbG9hbi5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zIGJvcmRlci10IHB0LTQgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEb2N1bWVudEFjdGlvbihcInBlbmRpbmdcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MDAgaG92ZXI6Ymctc2xhdGUtNjAwIHRleHQtd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBNb3ZlIHRvIFBlbmRpbmdcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURvY3VtZW50QWN0aW9uKFwidmVyaWZ5XCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctdmlvbGV0LTYwMCBob3ZlcjpiZy12aW9sZXQtNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtjYWxjdWxhdGVEb2N1bWVudFBlcmNlbnRhZ2UoY3VycmVudERvY3VtZW50cykgPCAxMDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIE1vdmUgdG8gVmVyaWZpY2F0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2FsY3VsYXRlRG9jdW1lbnRQZXJjZW50YWdlKGN1cnJlbnREb2N1bWVudHMpIDwgMTAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIHRleHQteHMgb3BhY2l0eS03NVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoe2NhbGN1bGF0ZURvY3VtZW50UGVyY2VudGFnZShjdXJyZW50RG9jdW1lbnRzKX0lIGNvbXBsZXRlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEb2N1bWVudEFjdGlvbihcImNvbXBsZXRlXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZW1lcmFsZC02MDAgdGV4dC13aGl0ZSBob3ZlcjpiZy1lbWVyYWxkLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIE1hcmsgQ29tcGxldGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIHtjYWxjdWxhdGVEb2N1bWVudFBlcmNlbnRhZ2UoY3VycmVudERvY3VtZW50cykgPCAxMDAgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudERvY3VtZW50cy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1hbWJlci02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pqg77iPIFBsZWFzZSB1cGxvYWQgYWxsIHJlcXVpcmVkIGRvY3VtZW50cyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtSRVFVSVJFRF9MT0FOX0RPQ1VNRU5UUy5sZW5ndGggLVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudERvY3VtZW50cy5maWx0ZXIoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGRvYykgPT4gZG9jLmZpbGVfdXJsICYmIGRvYy5kb2N1bWVudF90eXBlICE9PSBcIkRvY3VtZW50IFJlZmVyZW5jZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKS5sZW5ndGh9e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZW1haW5pbmcpIGJlZm9yZSB2ZXJpZmljYXRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvTW9kYWxDb21wb25lbnQ+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTG9hbkRvY3VtZW50YXRpb247Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0xvYW5Eb2N1bWVudGF0aW9uLmpzeCJ9