import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/EmployeeRewardPoints.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import api from "/src/instance/TokenInstance.js";
import Navbar from "/src/components/layouts/Navbar.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import SettingSidebar from "/src/components/layouts/SettingSidebar.jsx";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { Search, Calendar, Award, TrendingUp, Star, Gift, Trophy, Users } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
const EmployeeRewardPoints = () => {
  _s();
  const [employees, setEmployees] = useState([]);
  const [empRewardsData, setEmpRewardsData] = useState([]);
  const [employeeId, setEmployeeId] = useState("");
  const todayString = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const [selectedLabel, setSelectedLabel] = useState("Today");
  const [selectedFromDate, setSelectedFromDate] = useState(todayString);
  const [selectedToDate, setSelectedToDate] = useState(todayString);
  const [fromDate, setFromDate] = useState("");
  const [showFilterField, setShowFilterField] = useState(false);
  const [toDate, setToDate] = useState("");
  const [rewardState, setRewardState] = useState({
    rewards: [],
    activeRewards: [],
    totalPointsAll: 0,
    totalAmountAll: 0,
    totalEmplyees: 0
  });
  const [selectedEmployee, setSelectedEmployee] = useState("all");
  const [rewardTable, setRewardTable] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [rewards, setRewards] = useState([]);
  const [summary, setSummary] = useState({
    reward_point_value: 0,
    loan_reward_points: 0,
    pigme_reward_points: 0,
    total_earned_amount: 0,
    total_redeemed_points: 0,
    total_earned_reward: 0,
    total_redeemed_amount: 0,
    balance_amount: 0,
    source_wise_amount: []
  });
  const [redeemPoints, setRedeemPoints] = useState("");
  const [redeemType, setRedeemType] = useState("Cash");
  const [redeemAmount, setRedeemAmount] = useState(0);
  const [redeemDesc, setRedeemDesc] = useState("");
  const groupOptions = [
    { value: "Today", label: "Today" },
    { value: "Yesterday", label: "Yesterday" },
    { value: "ThisMonth", label: "This Month" },
    { value: "LastMonth", label: "Last Month" },
    { value: "ThisYear", label: "This Year" },
    { value: "Custom", label: "Custom" }
  ];
  const fetchRewardSummary = async (empId) => {
    try {
      const res = await api.get(
        `/reward-points/employee-reward-points/${empId}`
      );
      if (res.data?.success) {
        setSummary(res.data);
      }
    } catch (err) {
      console.error("Failed to fetch reward summary", err);
    }
  };
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [employeeRes, empRewardsRes] = await Promise.all(
          [
            api.get("/agent/get-employee"),
            api.get(`/reward-points/rewards/top-employees?from_date=${selectedFromDate}&to_date=${selectedToDate}`)
          ]
        );
        console.log(empRewardsRes.data.count, "empRewardsRes");
        const rewardData = empRewardsRes.data?.data || [];
        const filtered = rewardData.filter(
          (item) => item.total_points > 0
        );
        const sorted = [...filtered].sort(
          (a, b) => b.total_points - a.total_points
        );
        const totalPoints = rewardData.reduce(
          (sum, item) => sum + item.total_points,
          0
        );
        const totalAmount = rewardData.reduce(
          (sum, item) => sum + item.total_amount,
          0
        );
        setRewardState({
          rewards: filtered,
          activeRewards: sorted,
          totalPointsAll: totalPoints,
          totalAmountAll: totalAmount,
          totalEmplyees: empRewardsRes.data?.count || 0
        });
        setEmployees(employeeRes.data.employee || []);
        setRewards([empRewardsRes.data?.data]);
      } catch (e) {
        console.error(e);
      }
    };
    fetchData();
    setIsLoading(false);
  }, [selectedFromDate, selectedToDate]);
  const fetchRewardPoints = async (empId) => {
    if (!empId) return;
    setIsLoading(true);
    try {
      const res = await api.get(`/reward-points/list/${empId}`);
      const formatted = res.data?.data?.map((reward, index) => {
        let referenceName = "-";
        if (reward?.group_id) {
          referenceName = reward?.group_id?.group_name;
        } else if (reward?.loan_id) {
          referenceName = reward.loan_id?.loan_id;
        } else if (reward?.pigme_id) {
          referenceName = reward.pigme_id?.pigme_id;
        }
        return {
          _id: reward?._id,
          slNo: index + 1,
          userName: reward?.user_id?.full_name || "-",
          userPhone: reward?.user_id?.phone_number || "-",
          groupName: referenceName,
          groupValue: reward?.group_id?.group_value,
          ticket: reward?.ticket || "-",
          sourceType: reward?.source_type || "-",
          rewardPoints: reward?.reward_points || 0,
          rewardAmount: reward?.rewarded_amount || 0,
          status: reward?.status || "N/A",
          remarks: reward?.remarks || "-"
        };
      });
      setRewardTable(formatted);
    } catch (err) {
      console.error("Failed to fetch reward list", err);
    } finally {
      setIsLoading(false);
    }
  };
  const createRewardPoints = async () => {
    if (!employeeId) return alert("Select employee");
    if (!fromDate || !toDate) return alert("Please select From Date and To Date");
    if (new Date(fromDate) > new Date(toDate)) {
      return alert("From Date cannot be after To Date");
    }
    setIsLoading(true);
    try {
      await api.post("/reward-points/employee-reward-points", {
        employee_id: employeeId,
        from_date: fromDate,
        // ✅
        to_date: toDate,
        // ✅
        remarks: ""
      });
      await fetchRewardSummary(employeeId);
      await fetchRewardPoints(employeeId);
    } catch (err) {
      alert(err.response?.data?.error || "Failed to create reward points");
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    if (redeemType === "Cash") {
      setRedeemAmount(
        Number(redeemPoints || 0) * summary.reward_point_value
      );
    } else {
      setRedeemAmount(0);
    }
  }, [redeemPoints, redeemType, summary.reward_point_value]);
  const redeemRewardPoints = async () => {
    if (!employeeId) return alert("Select employee");
    if (!redeemPoints) return alert("Enter reward points");
    setIsLoading(true);
    try {
      await api.post("/reward-points/employee-reward-points/redeem", {
        employee_id: employeeId,
        points_to_redeem: Number(redeemPoints),
        redemption_type: redeemType,
        description: redeemDesc
      });
      setRedeemPoints("");
      setRedeemDesc("");
      await fetchRewardSummary(employeeId);
      await fetchRewardPoints(employeeId);
    } catch (err) {
      alert(err.response?.data?.message || "Redeem failed");
    } finally {
      setIsLoading(false);
    }
  };
  const rewardColumns = [
    { key: "slNo", header: "Sl No" },
    { key: "userName", header: "Name" },
    { key: "userPhone", header: "Phone" },
    { key: "groupName", header: "Group / Loan / Pigmy " },
    { key: "groupValue", header: "Group Value" },
    { key: "ticket", header: "Ticket" },
    { key: "sourceType", header: "Type" },
    { key: "rewardPoints", header: "Points" },
    { key: "rewardAmount", header: "Amount" },
    { key: "status", header: "Status" },
    { key: "remarks", header: "Remarks" }
  ];
  const filteredRewards = selectedEmployee === "all" ? rewards : rewards.filter(
    (r) => r.employee_name === selectedEmployee
  );
  const handleSelectFilter = (value) => {
    setSelectedLabel(value);
    setShowFilterField(false);
    const today = /* @__PURE__ */ new Date();
    const formatDate = (date) => date.toLocaleDateString("en-CA");
    if (value === "Today") {
      const formatted = formatDate(today);
      setSelectedFromDate(formatted);
      setSelectedToDate(formatted);
    } else if (value === "Yesterday") {
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      const formatted = formatDate(yesterday);
      setSelectedFromDate(formatted);
      setSelectedToDate(formatted);
    } else if (value === "ThisMonth") {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      setSelectedFromDate(formatDate(start));
      setSelectedToDate(formatDate(end));
    } else if (value === "LastMonth") {
      const start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      const end = new Date(today.getFullYear(), today.getMonth(), 0);
      setSelectedFromDate(formatDate(start));
      setSelectedToDate(formatDate(end));
    } else if (value === "ThisYear") {
      const start = new Date(today.getFullYear(), 0, 1);
      const end = new Date(today.getFullYear(), 11, 31);
      setSelectedFromDate(formatDate(start));
      setSelectedToDate(formatDate(end));
    } else if (value === "Custom") {
      setShowFilterField(true);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
      lineNumber: 662,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
        lineNumber: 664,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold mb-4", children: "Employee Reward Points" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
          lineNumber: 667,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-8 mb-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-md p-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-700", children: "Total Employees" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 676,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(Users, { className: "h-8 w-8 text-blue-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 677,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 675,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-gray-800", children: rewardState?.totalEmplyees }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 679,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-2", children: "Across all department" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 680,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
            lineNumber: 674,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-md p-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-700", children: "Total Amount / Rewards" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 684,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(Award, { className: "h-8 w-8 text-blue-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 685,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 683,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-gray-800", children: rewardState?.totalAmountAll }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 687,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-2", children: "Across all employees" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 688,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
            lineNumber: 682,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-md p-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-700", children: "Total Points" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 693,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(Star, { className: "h-8 w-8 text-yellow-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 694,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 692,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-gray-800", children: rewardState?.totalPointsAll }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 696,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-2", children: "Points awarded in total" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 697,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
            lineNumber: 691,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-md p-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-700", children: "Top Performer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 702,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(Trophy, { className: "h-8 w-8 text-green-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 703,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 701,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-gray-800", children: rewardState?.activeRewards.length > 0 ? rewardState.activeRewards[0]?.employee_name : "N/A" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 705,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-2", children: rewardState?.activeRewards.length > 0 ? `${rewardState.activeRewards[0].total_points} points` : "No data available" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 708,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
            lineNumber: 700,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
          lineNumber: 673,
          columnNumber: 11
        }, this),
        isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-md p-12 text-center", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
            lineNumber: 717,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-gray-500", children: "Loading reward data..." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
            lineNumber: 718,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
          lineNumber: 716,
          columnNumber: 11
        }, this) : rewardState?.rewards?.length > 0 ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "relative mb-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-gradient-to-r from-indigo-100 via-blue-100 to-purple-100 rounded-3xl blur-xl opacity-40" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 725,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "relative bg-white/80 backdrop-blur-xl \r\n                  border border-gray-200 \r\n                  rounded-3xl shadow-lg \r\n                  p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-6 items-end", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-600", children: "Filter Option" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                  lineNumber: 736,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    showSearch: true,
                    popupMatchSelectWidth: false,
                    onChange: handleSelectFilter,
                    value: selectedLabel,
                    placeholder: "Search or Select Filter",
                    filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                    className: "w-full custom-select",
                    children: groupOptions.map(
                      (time) => /* @__PURE__ */ jsxDEV(Select.Option, { value: time.value, children: time.label }, time.value, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                        lineNumber: 755,
                        columnNumber: 23
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                    lineNumber: 740,
                    columnNumber: 23
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 735,
                columnNumber: 21
              }, this),
              showFilterField && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-600", children: "From Date" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                    lineNumber: 766,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "date",
                      value: selectedFromDate,
                      onChange: (e) => setSelectedFromDate(e.target.value),
                      className: "w-full h-10 bg-white \r\n                         border border-gray-300 \r\n                         rounded-xl px-4 \r\n                         focus:ring-2 focus:ring-indigo-500 \r\n                         focus:border-indigo-500 \r\n                         shadow-sm \r\n                         transition-all duration-300 \r\n                         hover:border-indigo-400"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                      lineNumber: 769,
                      columnNumber: 27
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                  lineNumber: 765,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-600", children: "To Date" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                    lineNumber: 786,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "date",
                      value: selectedToDate,
                      onChange: (e) => setSelectedToDate(e.target.value),
                      className: "w-full h-12 bg-white \r\n                         border border-gray-300 \r\n                         rounded-xl px-4 \r\n                         focus:ring-2 focus:ring-indigo-500 \r\n                         focus:border-indigo-500 \r\n                         shadow-sm \r\n                         transition-all duration-300 \r\n                         hover:border-indigo-400"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                      lineNumber: 789,
                      columnNumber: 27
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                  lineNumber: 785,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 764,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 732,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 727,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
            lineNumber: 722,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow-md overflow-hidden", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-2 bg-gray-50 border-b border-gray-200", children: /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold text-gray-800", children: "Employee Rewards Summary" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 811,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 810,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto mb-3", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Sl no" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                  lineNumber: 828,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Employee" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                  lineNumber: 829,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Department" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                  lineNumber: 830,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Points" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                  lineNumber: 831,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Rewards / Ammount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                  lineNumber: 832,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Trend" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                  lineNumber: 833,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 827,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 826,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: rewardState.activeRewards?.slice(0, 5)?.map(
                (employee, key) => /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-50 ", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0 h-6 w-6 rounded-full bg-blue-100 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("span", { className: "text-blue-600 font-medium", children: key + 1 }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                    lineNumber: 842,
                    columnNumber: 35
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                    lineNumber: 841,
                    columnNumber: 33
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                    lineNumber: 840,
                    columnNumber: 31
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                    lineNumber: 839,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap text-sm text-gray-500", children: employee.employee_name }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                    lineNumber: 846,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap text-sm text-gray-500", children: employee.department || "Sales" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                    lineNumber: 847,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: employee.total_points }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                      lineNumber: 850,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "ml-2 text-xs text-gray-500", children: "pts" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                      lineNumber: 851,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                    lineNumber: 849,
                    columnNumber: 31
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                    lineNumber: 848,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap text-sm text-gray-500", children: employee.total_amount }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                    lineNumber: 854,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap", children: [
                    employee.total_points > 2e3 && /* @__PURE__ */ jsxDEV("span", { className: "flex items-center text-sm text-green-600", children: [
                      /* @__PURE__ */ jsxDEV(TrendingUp, { className: "h-4 w-4 mr-1" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                        lineNumber: 858,
                        columnNumber: 35
                      }, this),
                      "Up"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                      lineNumber: 857,
                      columnNumber: 25
                    }, this),
                    employee.total_points < 2e3 && /* @__PURE__ */ jsxDEV("span", { className: "flex items-center text-sm text-red-600", children: [
                      /* @__PURE__ */ jsxDEV(TrendingUp, { className: "h-4 w-4 mr-1 rotate-180" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                        lineNumber: 864,
                        columnNumber: 35
                      }, this),
                      "Down"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                      lineNumber: 863,
                      columnNumber: 25
                    }, this),
                    employee.trend === "same" && /* @__PURE__ */ jsxDEV("span", { className: "flex items-center text-sm text-gray-600", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "h-4 w-4 mr-1 bg-gray-400 rounded-full" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                        lineNumber: 870,
                        columnNumber: 35
                      }, this),
                      "Same"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                      lineNumber: 869,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                    lineNumber: 855,
                    columnNumber: 29
                  }, this)
                ] }, employee.id, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                  lineNumber: 838,
                  columnNumber: 21
                }, this)
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 836,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 825,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 824,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
            lineNumber: 809,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-4 mb-6 items-end bg-white border border-gray-200 rounded-xl shadow-sm p-6 hover:shadow-md transition duration-300", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Employee" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 885,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  className: "border px-4 py-2 rounded w-64",
                  value: employeeId,
                  onChange: (e) => {
                    const empId = e.target.value;
                    setEmployeeId(empId);
                    setRewardTable([]);
                    if (empId) {
                      fetchRewardSummary(empId);
                      fetchRewardPoints(empId);
                    }
                  },
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Employee" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                      lineNumber: 899,
                      columnNumber: 23
                    }, this),
                    employees.map(
                      (emp) => /* @__PURE__ */ jsxDEV("option", { value: emp._id, children: emp.name }, emp._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                        lineNumber: 901,
                        columnNumber: 19
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                  lineNumber: 886,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 884,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "From Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 910,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  className: "border px-4 py-2 rounded",
                  value: fromDate,
                  onChange: (e) => setFromDate(e.target.value)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                  lineNumber: 911,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 909,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "To Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 921,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  className: "border px-4 py-2 rounded",
                  value: toDate,
                  onChange: (e) => setToDate(e.target.value)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                  lineNumber: 922,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 920,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: createRewardPoints,
                disabled: isLoading,
                className: `px-6 py-2 rounded ${isLoading ? "bg-gray-400 cursor-not-allowed" : "bg-blue-600 text-white hover:bg-blue-700"}`,
                children: isLoading ? "Processing..." : "Create Reward Points"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 931,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
            lineNumber: 881,
            columnNumber: 17
          }, this),
          employeeId && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-5 gap-4 mb-6", children: [
            /* @__PURE__ */ jsxDEV(SummaryCard, { label: "Earned Points", value: summary.total_earned_reward }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 945,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(SummaryCard, { label: "Redeemed Points", value: summary.total_redeemed_points }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 946,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(SummaryCard, { label: "Earned Amount", value: `₹ ${summary.total_earned_amount}` }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 947,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(SummaryCard, { label: "Redeemed Amount", value: `₹ ${summary.total_redeemed_amount}` }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 948,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
            lineNumber: 944,
            columnNumber: 13
          }, this),
          employeeId && /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-200 rounded-lg p-6 mb-6 bg-white shadow-sm", children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "font-semibold text-lg text-gray-800 mb-6 flex items-center", children: [
              /* @__PURE__ */ jsxDEV(Gift, { className: "mr-2 h-5 w-5 text-green-600" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 957,
                columnNumber: 23
              }, this),
              "Redeem Reward Points"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 956,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "absolute -top-2 left-3 bg-white px-1 text-xs font-medium text-gray-600", children: "Reward Points" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                  lineNumber: 963,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    placeholder: "Enter points",
                    className: "border border-gray-300 px-4 py-3 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 hover:border-gray-400",
                    value: redeemPoints,
                    onChange: (e) => setRedeemPoints(e.target.value)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                    lineNumber: 966,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 962,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "absolute -top-2 left-3 bg-white px-1 text-xs font-medium text-gray-600", children: "Redeem Type" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                  lineNumber: 976,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    className: "border border-gray-300 px-4 py-3 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 hover:border-gray-400 appearance-none bg-white",
                    value: redeemType,
                    onChange: (e) => setRedeemType(e.target.value),
                    style: {
                      backgroundImage: `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e")`,
                      backgroundPosition: "right 0.5rem center",
                      backgroundRepeat: "no-repeat",
                      backgroundSize: "1.5em 1.5em",
                      paddingRight: "2.5rem"
                    },
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "Cash", children: "Cash" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                        lineNumber: 991,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Gift", children: "Gift" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                        lineNumber: 992,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Other", children: "Other" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                        lineNumber: 993,
                        columnNumber: 27
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                    lineNumber: 979,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 975,
                columnNumber: 23
              }, this),
              redeemType === "Cash" && /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "absolute -top-2 left-3 bg-white px-1 text-xs font-medium text-gray-600", children: "Amount (₹)" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                  lineNumber: 999,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    disabled: true,
                    className: "border border-gray-200 px-4 py-3 rounded-lg w-full bg-gray-50 text-gray-700 font-medium cursor-not-allowed",
                    value: `₹ ${redeemAmount}`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                    lineNumber: 1002,
                    columnNumber: 27
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 998,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative lg:col-span-2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "absolute -top-2 left-3 bg-white px-1 text-xs font-medium text-gray-600", children: "Description" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                  lineNumber: 1011,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    placeholder: "Enter description for redemption",
                    className: "border border-gray-300 px-4 py-3 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 hover:border-gray-400",
                    value: redeemDesc,
                    onChange: (e) => setRedeemDesc(e.target.value)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                    lineNumber: 1014,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 1010,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 961,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: redeemRewardPoints,
                className: "bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white px-8 py-3 rounded-lg font-medium shadow-md hover:shadow-lg transform transition-all duration-200 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 flex items-center",
                children: [
                  /* @__PURE__ */ jsxDEV(Gift, { className: "mr-2 h-4 w-4" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                    lineNumber: 1029,
                    columnNumber: 25
                  }, this),
                  "Redeem Points"
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
                lineNumber: 1025,
                columnNumber: 23
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 1024,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
            lineNumber: 955,
            columnNumber: 13
          }, this),
          rewardTable.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(DataTable, { columns: rewardColumns, data: rewardTable }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
            lineNumber: 1038,
            columnNumber: 13
          }, this) : /* @__PURE__ */ jsxDEV(
            CircularLoader,
            {
              isLoading,
              data: "Employee Reward",
              failure: !isLoading && rewardTable.length === 0
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
              lineNumber: 1040,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
          lineNumber: 721,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
          lineNumber: 1050,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
        lineNumber: 666,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
      lineNumber: 663,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
    lineNumber: 661,
    columnNumber: 5
  }, this);
};
_s(EmployeeRewardPoints, "nVP0YaodlnPZK5wQgKXscRzY+Ew=");
_c = EmployeeRewardPoints;
const SummaryCard = ({ label, value }) => /* @__PURE__ */ jsxDEV("div", { className: "border rounded p-4 bg-white shadow-sm", children: [
  /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm", children: label }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
    lineNumber: 1061,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-semibold mt-1", children: value }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
    lineNumber: 1062,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx",
  lineNumber: 1060,
  columnNumber: 1
}, this);
_c2 = SummaryCard;
export default EmployeeRewardPoints;
var _c, _c2;
$RefreshReg$(_c, "EmployeeRewardPoints");
$RefreshReg$(_c2, "SummaryCard");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeRewardPoints.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcXBCTSxTQXNHZ0IsVUF0R2hCOzJCQXJwQk47QUFBbUJBLG9CQUFpQixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNDLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLG9CQUFvQjtBQUMzQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLFFBQVFDLFVBQVVDLE9BQU9DLFlBQVlDLE1BQU1DLE1BQU1DLFFBQVFDLGFBQWE7QUE4VS9FLE1BQU1DLHVCQUF1QkEsTUFBTTtBQUFBQyxLQUFBO0FBQ2pDLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJQyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDQyxnQkFBZ0JDLGlCQUFpQixJQUFJRixTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDRyxZQUFZQyxhQUFhLElBQUlKLFNBQVMsRUFBRTtBQUMvQyxRQUFNSyxlQUFjLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUN6RCxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJVixTQUFTLE9BQU87QUFDMUQsUUFBTSxDQUFDVyxrQkFBa0JDLG1CQUFtQixJQUFJWixTQUFTSyxXQUFXO0FBQ3BFLFFBQU0sQ0FBQ1EsZ0JBQWdCQyxpQkFBaUIsSUFBSWQsU0FBU0ssV0FBVztBQUVoRSxRQUFNLENBQUNVLFVBQVVDLFdBQVcsSUFBSWhCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNpQixpQkFBaUJDLGtCQUFrQixJQUFJbEIsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ21CLFFBQVFDLFNBQVMsSUFBSXBCLFNBQVMsRUFBRTtBQUV2QyxRQUFNLENBQUNxQixhQUFhQyxjQUFjLElBQUl0QixTQUFTO0FBQUEsSUFDN0N1QixTQUFTO0FBQUEsSUFDVEMsZUFBZTtBQUFBLElBQ2ZDLGdCQUFnQjtBQUFBLElBQ2hCQyxnQkFBZ0I7QUFBQSxJQUNoQkMsZUFBZTtBQUFBLEVBQ2pCLENBQUM7QUFDRCxRQUFNLENBQUNDLGtCQUFrQkMsbUJBQW1CLElBQUk3QixTQUFTLEtBQUs7QUFFOUQsUUFBTSxDQUFDOEIsYUFBYUMsY0FBYyxJQUFJL0IsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ2dDLFdBQVdDLFlBQVksSUFBSWpDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUN1QixTQUFTVyxVQUFVLElBQUlsQyxTQUFTLEVBQUU7QUFHekMsUUFBTSxDQUFDbUMsU0FBU0MsVUFBVSxJQUFJcEMsU0FBUztBQUFBLElBQ3JDcUMsb0JBQW9CO0FBQUEsSUFDcEJDLG9CQUFvQjtBQUFBLElBQ3BCQyxxQkFBcUI7QUFBQSxJQUNyQkMscUJBQXFCO0FBQUEsSUFDckJDLHVCQUF1QjtBQUFBLElBQ3ZCQyxxQkFBcUI7QUFBQSxJQUNyQkMsdUJBQXVCO0FBQUEsSUFDdkJDLGdCQUFnQjtBQUFBLElBQ2hCQyxvQkFBb0I7QUFBQSxFQUN0QixDQUFDO0FBR0QsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUkvQyxTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDZ0QsWUFBWUMsYUFBYSxJQUFJakQsU0FBUyxNQUFNO0FBQ25ELFFBQU0sQ0FBQ2tELGNBQWNDLGVBQWUsSUFBSW5ELFNBQVMsQ0FBQztBQUNsRCxRQUFNLENBQUNvRCxZQUFZQyxhQUFhLElBQUlyRCxTQUFTLEVBQUU7QUFHL0MsUUFBTXNELGVBQWU7QUFBQSxJQUNuQixFQUFFQyxPQUFPLFNBQVNDLE9BQU8sUUFBUTtBQUFBLElBQ2pDLEVBQUVELE9BQU8sYUFBYUMsT0FBTyxZQUFZO0FBQUEsSUFDekMsRUFBRUQsT0FBTyxhQUFhQyxPQUFPLGFBQWE7QUFBQSxJQUMxQyxFQUFFRCxPQUFPLGFBQWFDLE9BQU8sYUFBYTtBQUFBLElBQzFDLEVBQUVELE9BQU8sWUFBWUMsT0FBTyxZQUFZO0FBQUEsSUFDeEMsRUFBRUQsT0FBTyxVQUFVQyxPQUFPLFNBQVM7QUFBQSxFQUFDO0FBa0J0QyxRQUFNQyxxQkFBcUIsT0FBT0MsVUFBVTtBQUMxQyxRQUFJO0FBQ0YsWUFBTUMsTUFBTSxNQUFNOUUsSUFBSStFO0FBQUFBLFFBQ3BCLHlDQUF5Q0YsS0FBSztBQUFBLE1BQ2hEO0FBRUEsVUFBSUMsSUFBSUUsTUFBTUMsU0FBUztBQUNyQjFCLG1CQUFXdUIsSUFBSUUsSUFBSTtBQUFBLE1BQ3JCO0FBQUEsSUFDRixTQUFTRSxLQUFLO0FBQ1pDLGNBQVFDLE1BQU0sa0NBQWtDRixHQUFHO0FBQUEsSUFDckQ7QUFBQSxFQUNGO0FBZUFuRixZQUFVLE1BQU07QUFDZCxVQUFNc0YsWUFBWSxZQUFZO0FBQzVCLFVBQUk7QUFDRixjQUFNLENBQUNDLGFBQWFDLGFBQWEsSUFBSSxNQUFNQyxRQUFRQztBQUFBQSxVQUFJO0FBQUEsWUFDckR6RixJQUFJK0UsSUFBSSxxQkFBcUI7QUFBQSxZQUM3Qi9FLElBQUkrRSxJQUFJLGtEQUFrRGpELGdCQUFnQixZQUFZRSxjQUFjLEVBQUU7QUFBQSxVQUFDO0FBQUEsUUFDeEc7QUFDRG1ELGdCQUFRTyxJQUFJSCxjQUFjUCxLQUFLVyxPQUFPLGVBQWU7QUFFckQsY0FBTUMsYUFBYUwsY0FBY1AsTUFBTUEsUUFBUTtBQUcvQyxjQUFNYSxXQUFXRCxXQUFXRTtBQUFBQSxVQUMxQixDQUFDQyxTQUFTQSxLQUFLQyxlQUFlO0FBQUEsUUFDaEM7QUFHQSxjQUFNQyxTQUFTLENBQUMsR0FBR0osUUFBUSxFQUFFSztBQUFBQSxVQUMzQixDQUFDQyxHQUFHQyxNQUFNQSxFQUFFSixlQUFlRyxFQUFFSDtBQUFBQSxRQUMvQjtBQUdBLGNBQU1LLGNBQWNULFdBQVdVO0FBQUFBLFVBQzdCLENBQUNDLEtBQUtSLFNBQVNRLE1BQU1SLEtBQUtDO0FBQUFBLFVBQzFCO0FBQUEsUUFDRjtBQUVBLGNBQU1RLGNBQWNaLFdBQVdVO0FBQUFBLFVBQzdCLENBQUNDLEtBQUtSLFNBQVNRLE1BQU1SLEtBQUtVO0FBQUFBLFVBQzFCO0FBQUEsUUFDRjtBQUdBaEUsdUJBQWU7QUFBQSxVQUNiQyxTQUFTbUQ7QUFBQUEsVUFDVGxELGVBQWVzRDtBQUFBQSxVQUNmckQsZ0JBQWdCeUQ7QUFBQUEsVUFDaEJ4RCxnQkFBZ0IyRDtBQUFBQSxVQUNoQjFELGVBQWV5QyxjQUFjUCxNQUFNVyxTQUFTO0FBQUEsUUFDOUMsQ0FBQztBQUNEekUscUJBQWFvRSxZQUFZTixLQUFLMEIsWUFBWSxFQUFFO0FBQzVDckQsbUJBQVcsQ0FBQ2tDLGNBQWNQLE1BQU1BLElBQUksQ0FBTztBQUFBLE1BQzdDLFNBQVMyQixHQUFHO0FBQ1Z4QixnQkFBUUMsTUFBTXVCLENBQUM7QUFBQSxNQUNqQjtBQUFBLElBQ0Y7QUFDQXRCLGNBQVU7QUFDVmpDLGlCQUFhLEtBQUs7QUFBQSxFQUNwQixHQUFHLENBQUN0QixrQkFBaUJFLGNBQWMsQ0FBQztBQUVwQyxRQUFNNEUsb0JBQW9CLE9BQU8vQixVQUFVO0FBQ3pDLFFBQUksQ0FBQ0EsTUFBTztBQUVaekIsaUJBQWEsSUFBSTtBQUNqQixRQUFJO0FBQ0YsWUFBTTBCLE1BQU0sTUFBTTlFLElBQUkrRSxJQUFJLHVCQUF1QkYsS0FBSyxFQUFFO0FBRXhELFlBQU1nQyxZQUFZL0IsSUFBSUUsTUFBTUEsTUFBTThCLElBQUksQ0FBQ0MsUUFBUUMsVUFBVTtBQUN2RCxZQUFJQyxnQkFBZ0I7QUFFcEIsWUFBSUYsUUFBUUcsVUFBVTtBQUNwQkQsMEJBQWdCRixRQUFRRyxVQUFVQztBQUFBQSxRQUNwQyxXQUFXSixRQUFRSyxTQUFTO0FBQzFCSCwwQkFBZ0JGLE9BQU9LLFNBQVNBO0FBQUFBLFFBQ2xDLFdBQVdMLFFBQVFNLFVBQVU7QUFDM0JKLDBCQUFnQkYsT0FBT00sVUFBVUE7QUFBQUEsUUFDbkM7QUFFQSxlQUFPO0FBQUEsVUFDTEMsS0FBS1AsUUFBUU87QUFBQUEsVUFDYkMsTUFBTVAsUUFBUTtBQUFBLFVBQ2RRLFVBQVVULFFBQVFVLFNBQVNDLGFBQWE7QUFBQSxVQUN4Q0MsV0FBV1osUUFBUVUsU0FBU0csZ0JBQWdCO0FBQUEsVUFDNUNDLFdBQVdaO0FBQUFBLFVBQ1hhLFlBQVlmLFFBQVFHLFVBQVVhO0FBQUFBLFVBQzlCQyxRQUFRakIsUUFBUWlCLFVBQVU7QUFBQSxVQUMxQkMsWUFBWWxCLFFBQVFtQixlQUFlO0FBQUEsVUFDbkNDLGNBQWNwQixRQUFRcUIsaUJBQWlCO0FBQUEsVUFDdkNDLGNBQWN0QixRQUFRdUIsbUJBQW1CO0FBQUEsVUFDekNDLFFBQVF4QixRQUFRd0IsVUFBVTtBQUFBLFVBQzFCQyxTQUFTekIsUUFBUXlCLFdBQVc7QUFBQSxRQUM5QjtBQUFBLE1BQ0YsQ0FBQztBQUVEdEYscUJBQWUyRCxTQUFTO0FBQUEsSUFDMUIsU0FBUzNCLEtBQUs7QUFDWkMsY0FBUUMsTUFBTSwrQkFBK0JGLEdBQUc7QUFBQSxJQUNsRCxVQUFDO0FBQ0M5QixtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBR0EsUUFBTXFGLHFCQUFxQixZQUFZO0FBQ3JDLFFBQUksQ0FBQ25ILFdBQVksUUFBT29ILE1BQU0saUJBQWlCO0FBQy9DLFFBQUksQ0FBQ3hHLFlBQVksQ0FBQ0ksT0FBUSxRQUFPb0csTUFBTSxxQ0FBcUM7QUFHNUUsUUFBSSxJQUFJakgsS0FBS1MsUUFBUSxJQUFJLElBQUlULEtBQUthLE1BQU0sR0FBRztBQUN6QyxhQUFPb0csTUFBTSxtQ0FBbUM7QUFBQSxJQUNsRDtBQUVBdEYsaUJBQWEsSUFBSTtBQUNqQixRQUFJO0FBQ0YsWUFBTXBELElBQUkySSxLQUFLLHlDQUF5QztBQUFBLFFBQ3REQyxhQUFhdEg7QUFBQUEsUUFDYnVILFdBQVczRztBQUFBQTtBQUFBQSxRQUNYNEcsU0FBU3hHO0FBQUFBO0FBQUFBLFFBQ1RrRyxTQUFTO0FBQUEsTUFDWCxDQUFDO0FBRUQsWUFBTTVELG1CQUFtQnRELFVBQVU7QUFDbkMsWUFBTXNGLGtCQUFrQnRGLFVBQVU7QUFBQSxJQUtwQyxTQUFTNEQsS0FBSztBQUNad0QsWUFBTXhELElBQUk2RCxVQUFVL0QsTUFBTUksU0FBUyxnQ0FBZ0M7QUFBQSxJQUNyRSxVQUFDO0FBQ0NoQyxtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBR0FyRCxZQUFVLE1BQU07QUFDZCxRQUFJb0UsZUFBZSxRQUFRO0FBQ3pCRztBQUFBQSxRQUNFMEUsT0FBTy9FLGdCQUFnQixDQUFDLElBQUlYLFFBQVFFO0FBQUFBLE1BQ3RDO0FBQUEsSUFDRixPQUFPO0FBQ0xjLHNCQUFnQixDQUFDO0FBQUEsSUFDbkI7QUFBQSxFQUNGLEdBQUcsQ0FBQ0wsY0FBY0UsWUFBWWIsUUFBUUUsa0JBQWtCLENBQUM7QUFHekQsUUFBTXlGLHFCQUFxQixZQUFZO0FBQ3JDLFFBQUksQ0FBQzNILFdBQVksUUFBT29ILE1BQU0saUJBQWlCO0FBQy9DLFFBQUksQ0FBQ3pFLGFBQWMsUUFBT3lFLE1BQU0scUJBQXFCO0FBRXJEdEYsaUJBQWEsSUFBSTtBQUNqQixRQUFJO0FBQ0YsWUFBTXBELElBQUkySSxLQUFLLGdEQUFnRDtBQUFBLFFBQzdEQyxhQUFhdEg7QUFBQUEsUUFDYjRILGtCQUFrQkYsT0FBTy9FLFlBQVk7QUFBQSxRQUNyQ2tGLGlCQUFpQmhGO0FBQUFBLFFBQ2pCaUYsYUFBYTdFO0FBQUFBLE1BQ2YsQ0FBQztBQUVETCxzQkFBZ0IsRUFBRTtBQUNsQk0sb0JBQWMsRUFBRTtBQUVoQixZQUFNSSxtQkFBbUJ0RCxVQUFVO0FBQ25DLFlBQU1zRixrQkFBa0J0RixVQUFVO0FBQUEsSUFDcEMsU0FBUzRELEtBQUs7QUFDWndELFlBQU14RCxJQUFJNkQsVUFBVS9ELE1BQU1xRSxXQUFXLGVBQWU7QUFBQSxJQUN0RCxVQUFDO0FBQ0NqRyxtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUEsUUFBTWtHLGdCQUFnQjtBQUFBLElBQ3BCLEVBQUVDLEtBQUssUUFBUUMsUUFBUSxRQUFRO0FBQUEsSUFDL0IsRUFBRUQsS0FBSyxZQUFZQyxRQUFRLE9BQU87QUFBQSxJQUNsQyxFQUFFRCxLQUFLLGFBQWFDLFFBQVEsUUFBUTtBQUFBLElBQ3BDLEVBQUVELEtBQUssYUFBYUMsUUFBUSx3QkFBd0I7QUFBQSxJQUNwRCxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsY0FBYztBQUFBLElBQzNDLEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLE9BQU87QUFBQSxJQUNwQyxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxTQUFTO0FBQUEsSUFDeEMsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsU0FBUztBQUFBLElBQ3hDLEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLFVBQVU7QUFBQSxFQUFDO0FBSXZDLFFBQU1DLGtCQUNKMUcscUJBQXFCLFFBQ2pCTCxVQUNBQSxRQUFRb0Q7QUFBQUEsSUFDUixDQUFDNEQsTUFBTUEsRUFBRUMsa0JBQWtCNUc7QUFBQUEsRUFDN0I7QUFDSixRQUFNNkcscUJBQXFCQSxDQUFDbEYsVUFBVTtBQUNwQzdDLHFCQUFpQjZDLEtBQUs7QUFFdEJyQyx1QkFBbUIsS0FBSztBQUV4QixVQUFNd0gsUUFBUSxvQkFBSXBJLEtBQUs7QUFDdkIsVUFBTXFJLGFBQWFBLENBQUNDLFNBQVNBLEtBQUtDLG1CQUFtQixPQUFPO0FBRTVELFFBQUl0RixVQUFVLFNBQVM7QUFDckIsWUFBTW1DLFlBQVlpRCxXQUFXRCxLQUFLO0FBQ2xDOUgsMEJBQW9COEUsU0FBUztBQUM3QjVFLHdCQUFrQjRFLFNBQVM7QUFBQSxJQUM3QixXQUFXbkMsVUFBVSxhQUFhO0FBQ2hDLFlBQU11RixZQUFZLElBQUl4SSxLQUFLb0ksS0FBSztBQUNoQ0ksZ0JBQVVDLFFBQVFELFVBQVVFLFFBQVEsSUFBSSxDQUFDO0FBQ3pDLFlBQU10RCxZQUFZaUQsV0FBV0csU0FBUztBQUN0Q2xJLDBCQUFvQjhFLFNBQVM7QUFDN0I1RSx3QkFBa0I0RSxTQUFTO0FBQUEsSUFDN0IsV0FBV25DLFVBQVUsYUFBYTtBQUNoQyxZQUFNMEYsUUFBUSxJQUFJM0ksS0FBS29JLE1BQU1RLFlBQVksR0FBR1IsTUFBTVMsU0FBUyxHQUFHLENBQUM7QUFDL0QsWUFBTUMsTUFBTSxJQUFJOUksS0FBS29JLE1BQU1RLFlBQVksR0FBR1IsTUFBTVMsU0FBUyxJQUFJLEdBQUcsQ0FBQztBQUNqRXZJLDBCQUFvQitILFdBQVdNLEtBQUssQ0FBQztBQUNyQ25JLHdCQUFrQjZILFdBQVdTLEdBQUcsQ0FBQztBQUFBLElBQ25DLFdBQVc3RixVQUFVLGFBQWE7QUFDaEMsWUFBTTBGLFFBQVEsSUFBSTNJLEtBQUtvSSxNQUFNUSxZQUFZLEdBQUdSLE1BQU1TLFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDbkUsWUFBTUMsTUFBTSxJQUFJOUksS0FBS29JLE1BQU1RLFlBQVksR0FBR1IsTUFBTVMsU0FBUyxHQUFHLENBQUM7QUFDN0R2SSwwQkFBb0IrSCxXQUFXTSxLQUFLLENBQUM7QUFDckNuSSx3QkFBa0I2SCxXQUFXUyxHQUFHLENBQUM7QUFBQSxJQUNuQyxXQUFXN0YsVUFBVSxZQUFZO0FBQy9CLFlBQU0wRixRQUFRLElBQUkzSSxLQUFLb0ksTUFBTVEsWUFBWSxHQUFHLEdBQUcsQ0FBQztBQUNoRCxZQUFNRSxNQUFNLElBQUk5SSxLQUFLb0ksTUFBTVEsWUFBWSxHQUFHLElBQUksRUFBRTtBQUNoRHRJLDBCQUFvQitILFdBQVdNLEtBQUssQ0FBQztBQUNyQ25JLHdCQUFrQjZILFdBQVdTLEdBQUcsQ0FBQztBQUFBLElBQ25DLFdBQVc3RixVQUFVLFVBQVU7QUFDN0JyQyx5QkFBbUIsSUFBSTtBQUFBLElBQ3pCO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFVBQU8sWUFBVSxRQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtCO0FBQUEsSUFDbEIsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSw2QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BRVIsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLCtCQUE4QixzQ0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFJQSx1QkFBQyxTQUFJLFdBQVUsNEVBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsdUNBQXNDLCtCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRTtBQUFBLGNBQ25FLHVCQUFDLFNBQU0sV0FBVSwyQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0M7QUFBQSxpQkFGMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLG9DQUFvQ0csdUJBQWFNLGlCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0RTtBQUFBLFlBQzVFLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIscUNBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStEO0FBQUEsZUFOakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsUUFBRyxXQUFVLHVDQUFzQyxzQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEU7QUFBQSxjQUMxRSx1QkFBQyxTQUFNLFdBQVUsMkJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdDO0FBQUEsaUJBRjFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSxvQ0FBb0NOLHVCQUFhSyxrQkFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkU7QUFBQSxZQUM3RSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLG9DQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RDtBQUFBLGVBTmhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFFBQUcsV0FBVSx1Q0FBc0MsNEJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdFO0FBQUEsY0FDaEUsdUJBQUMsUUFBSyxXQUFVLDZCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QztBQUFBLGlCQUYzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsb0NBQW9DTCx1QkFBYUksa0JBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZFO0FBQUEsWUFDN0UsdUJBQUMsT0FBRSxXQUFVLDhCQUE2Qix1Q0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUU7QUFBQSxlQU5uRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsdUNBQXNDLDZCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRTtBQUFBLGNBQ2pFLHVCQUFDLFVBQU8sV0FBVSw0QkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEM7QUFBQSxpQkFGNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLG1DQUNWSix1QkFBYUcsY0FBYzZILFNBQVMsSUFBSWhJLFlBQVlHLGNBQWMsQ0FBQyxHQUFHZ0gsZ0JBQWdCLFNBRHpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFDVm5ILHVCQUFhRyxjQUFjNkgsU0FBUyxJQUFJLEdBQUdoSSxZQUFZRyxjQUFjLENBQUMsRUFBRXFELFlBQVksWUFBWSx1QkFEbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLGFBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1Q0E7QUFBQSxRQUdDN0MsWUFDQyx1QkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNEZBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0c7QUFBQSxVQUN4Ryx1QkFBQyxPQUFFLFdBQVUsc0JBQXFCLHNDQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBLGFBRjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQSxJQUNFWCxhQUFhRSxTQUFTOEgsU0FBUyxJQUNqQyxtQ0FDRTtBQUFBLGlDQUFDLFNBQUksV0FBVSxpQkFHYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxpSEFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2SDtBQUFBLFlBRTdILHVCQUFDLFNBQUksV0FBVSw0SkFLYixpQ0FBQyxTQUFJLFdBQVUsbURBR2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSw2Q0FBNEMsNkJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQztBQUFBLG9CQUNBLHVCQUF1QjtBQUFBLG9CQUN2QixVQUFVWjtBQUFBQSxvQkFDVixPQUFPaEk7QUFBQUEsb0JBQ1AsYUFBWTtBQUFBLG9CQUNaLGNBQWMsQ0FBQzZJLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1RDLFlBQVksRUFDWkMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsb0JBRWpDLFdBQVU7QUFBQSxvQkFFVHBHLHVCQUFhcUM7QUFBQUEsc0JBQUksQ0FBQ2lFLFNBQ2pCLHVCQUFDLE9BQU8sUUFBUCxFQUErQixPQUFPQSxLQUFLckcsT0FDekNxRyxlQUFLcEcsU0FEWW9HLEtBQUtyRyxPQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBLGtCQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBbUJBO0FBQUEsbUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeUJBO0FBQUEsY0FHQ3RDLG1CQUNDLG1DQUNFO0FBQUEsdUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsNkNBQTRDLHlCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE9BQU9OO0FBQUFBLHNCQUNQLFVBQVUsQ0FBQzZFLE1BQU01RSxvQkFBb0I0RSxFQUFFcUUsT0FBT3RHLEtBQUs7QUFBQSxzQkFDbkQsV0FBVTtBQUFBO0FBQUEsb0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVd1QjtBQUFBLHFCQWZ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlCQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLDZDQUE0Qyx1QkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxPQUFPMUM7QUFBQUEsc0JBQ1AsVUFBVSxDQUFDMkUsTUFBTTFFLGtCQUFrQjBFLEVBQUVxRSxPQUFPdEcsS0FBSztBQUFBLHNCQUNqRCxXQUFVO0FBQUE7QUFBQSxvQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBV3VCO0FBQUEscUJBZnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaUJBO0FBQUEsbUJBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdUNBO0FBQUEsaUJBdkVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEVBLEtBL0VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0ZBO0FBQUEsZUFyRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzRkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxpREFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxpREFDYixpQ0FBQyxRQUFHLFdBQVUsdUNBQXNDLHdDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0RSxLQUQ5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWFKO0FBQUEsWUFDTSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2IsaUNBQUMsV0FBTSxXQUFVLFVBQ2Y7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsY0FDZixpQ0FBQyxRQUNDO0FBQUEsdUNBQUMsUUFBRyxXQUFVLGtGQUFpRixxQkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0c7QUFBQSxnQkFDcEcsdUJBQUMsUUFBRyxXQUFVLGtGQUFpRix3QkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUc7QUFBQSxnQkFDdkcsdUJBQUMsUUFBRyxXQUFVLGtGQUFpRiwwQkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUc7QUFBQSxnQkFDekcsdUJBQUMsUUFBRyxXQUFVLGtGQUFpRixzQkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUc7QUFBQSxnQkFDckcsdUJBQUMsUUFBRyxXQUFVLGtGQUFpRixpQ0FBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0g7QUFBQSxnQkFDaEgsdUJBQUMsUUFBRyxXQUFVLGtGQUFpRixxQkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0c7QUFBQSxtQkFOdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxxQ0FDZGxDLHNCQUFZRyxlQUFlc0ksTUFBTSxHQUFHLENBQUMsR0FBR25FO0FBQUFBLGdCQUFJLENBQUNKLFVBQVU2QyxRQUN0RCx1QkFBQyxRQUFxQixXQUFVLHFCQUM5QjtBQUFBLHlDQUFDLFFBQUcsV0FBVSwrQkFDWixpQ0FBQyxTQUFJLFdBQVUscUJBQ2IsaUNBQUMsU0FBSSxXQUFVLG1GQUNiLGlDQUFDLFVBQUssV0FBVSw2QkFBNkJBLGdCQUFNLEtBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFELEtBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUlBLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSxxREFBcUQ3QyxtQkFBU2lELGlCQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwRjtBQUFBLGtCQUMxRix1QkFBQyxRQUFHLFdBQVUscURBQXFEakQsbUJBQVN3RSxjQUFjLFdBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtHO0FBQUEsa0JBQ2xHLHVCQUFDLFFBQUcsV0FBVSwrQkFDWixpQ0FBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUscUNBQXFDeEUsbUJBQVNWLGdCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUEyRTtBQUFBLG9CQUMzRSx1QkFBQyxVQUFLLFdBQVUsOEJBQTZCLG1CQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnRDtBQUFBLHVCQUZsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSxxREFBcURVLG1CQUFTRCxnQkFBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUY7QUFBQSxrQkFDekYsdUJBQUMsUUFBRyxXQUFVLCtCQUNYQztBQUFBQSw2QkFBU1YsZUFBZSxPQUN2Qix1QkFBQyxVQUFLLFdBQVUsNENBQ2Q7QUFBQSw2Q0FBQyxjQUFXLFdBQVUsa0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQW9DO0FBQUEsc0JBQUc7QUFBQSx5QkFEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLG9CQUVEVSxTQUFTVixlQUFlLE9BQ3ZCLHVCQUFDLFVBQUssV0FBVSwwQ0FDZDtBQUFBLDZDQUFDLGNBQVcsV0FBVSw2QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBK0M7QUFBQSxzQkFBRztBQUFBLHlCQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsb0JBRURVLFNBQVN5RSxVQUFVLFVBQ2xCLHVCQUFDLFVBQUssV0FBVSwyQ0FDZDtBQUFBLDZDQUFDLFNBQUksV0FBVSwyQ0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF1RDtBQUFBLHNCQUFNO0FBQUEseUJBRC9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSx1QkFqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFtQkE7QUFBQSxxQkFwQ096RSxTQUFTMEUsSUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFxQ0E7QUFBQSxjQUNELEtBeENIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeUNBO0FBQUEsaUJBcERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcURBLEtBdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdURBO0FBQUEsZUF0RUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1RUU7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx3SUFHYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsa0NBQWlDLHdCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRDtBQUFBLGNBQzFEO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixPQUFPOUo7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDcUYsTUFBTTtBQUNmLDBCQUFNOUIsUUFBUThCLEVBQUVxRSxPQUFPdEc7QUFDdkJuRCxrQ0FBY3NELEtBQUs7QUFDbkIzQixtQ0FBZSxFQUFFO0FBQ2pCLHdCQUFJMkIsT0FBTztBQUNURCx5Q0FBbUJDLEtBQUs7QUFDeEIrQix3Q0FBa0IvQixLQUFLO0FBQUEsb0JBQ3pCO0FBQUEsa0JBQ0Y7QUFBQSxrQkFFQTtBQUFBLDJDQUFDLFlBQU8sT0FBTSxJQUFHLCtCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQztBQUFBLG9CQUMvQjVELFVBQVU2RjtBQUFBQSxzQkFBSSxDQUFDdUUsUUFDZCx1QkFBQyxZQUFxQixPQUFPQSxJQUFJL0QsS0FDOUIrRCxjQUFJQyxRQURNRCxJQUFJL0QsS0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUE7QUFBQTtBQUFBLGdCQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FtQkE7QUFBQSxpQkFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFzQkE7QUFBQSxZQUdBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsa0NBQWlDLHlCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyRDtBQUFBLGNBQzNEO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsT0FBT3BGO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQ3lFLE1BQU14RSxZQUFZd0UsRUFBRXFFLE9BQU90RyxLQUFLO0FBQUE7QUFBQSxnQkFKN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSStDO0FBQUEsaUJBTmpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUdBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsa0NBQWlDLHVCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RDtBQUFBLGNBQ3pEO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsT0FBT3BDO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQ3FFLE1BQU1wRSxVQUFVb0UsRUFBRXFFLE9BQU90RyxLQUFLO0FBQUE7QUFBQSxnQkFKM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSTZDO0FBQUEsaUJBTi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUdBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUytEO0FBQUFBLGdCQUNULFVBQVV0RjtBQUFBQSxnQkFDVixXQUFXLHFCQUFxQkEsWUFDNUIsbUNBQ0EsMENBQTBDO0FBQUEsZ0JBRzdDQSxzQkFBWSxrQkFBa0I7QUFBQTtBQUFBLGNBUmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNBO0FBQUEsZUEzREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0REE7QUFBQSxVQUVDN0IsY0FDQyx1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxtQ0FBQyxlQUFZLE9BQU0saUJBQWdCLE9BQU9nQyxRQUFRTyx1QkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0U7QUFBQSxZQUN0RSx1QkFBQyxlQUFZLE9BQU0sbUJBQWtCLE9BQU9QLFFBQVFNLHlCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRTtBQUFBLFlBQzFFLHVCQUFDLGVBQVksT0FBTSxpQkFBZ0IsT0FBTyxLQUFLTixRQUFRSyxtQkFBbUIsTUFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkU7QUFBQSxZQUM3RSx1QkFBQyxlQUFZLE9BQU0sbUJBQWtCLE9BQU8sS0FBS0wsUUFBUVEscUJBQXFCLE1BQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlGO0FBQUEsZUFKbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBSUR4QyxjQUNDLHVCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSw4REFDWjtBQUFBLHFDQUFDLFFBQUssV0FBVSxpQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkM7QUFBQSxjQUFHO0FBQUEsaUJBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDBFQUF5RSw2QkFBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxhQUFZO0FBQUEsb0JBQ1osV0FBVTtBQUFBLG9CQUNWLE9BQU8yQztBQUFBQSxvQkFDUCxVQUFVLENBQUMwQyxNQUFNekMsZ0JBQWdCeUMsRUFBRXFFLE9BQU90RyxLQUFLO0FBQUE7QUFBQSxrQkFMakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUttRDtBQUFBLG1CQVRyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVdBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSwwRUFBeUUsMkJBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsT0FBT1A7QUFBQUEsb0JBQ1AsVUFBVSxDQUFDd0MsTUFBTXZDLGNBQWN1QyxFQUFFcUUsT0FBT3RHLEtBQUs7QUFBQSxvQkFDN0MsT0FBTztBQUFBLHNCQUNMNkcsaUJBQWlCO0FBQUEsc0JBQ2pCQyxvQkFBb0I7QUFBQSxzQkFDcEJDLGtCQUFrQjtBQUFBLHNCQUNsQkMsZ0JBQWdCO0FBQUEsc0JBQ2hCQyxjQUFjO0FBQUEsb0JBQ2hCO0FBQUEsb0JBRUE7QUFBQSw2Q0FBQyxZQUFPLE9BQU0sUUFBTyxvQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBeUI7QUFBQSxzQkFDekIsdUJBQUMsWUFBTyxPQUFNLFFBQU8sb0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXlCO0FBQUEsc0JBQ3pCLHVCQUFDLFlBQU8sT0FBTSxTQUFRLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEyQjtBQUFBO0FBQUE7QUFBQSxrQkFkN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWVBO0FBQUEsbUJBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBb0JBO0FBQUEsY0FFQ3hILGVBQWUsVUFDZCx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSwwRUFBeUUsMEJBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQztBQUFBLG9CQUNBLFdBQVU7QUFBQSxvQkFDVixPQUFPLEtBQUtFLFlBQVk7QUFBQTtBQUFBLGtCQUgxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRzZCO0FBQUEsbUJBUC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxjQUdGLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSwwRUFBeUUsMkJBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsYUFBWTtBQUFBLG9CQUNaLFdBQVU7QUFBQSxvQkFDVixPQUFPRTtBQUFBQSxvQkFDUCxVQUFVLENBQUNvQyxNQUFNbkMsY0FBY21DLEVBQUVxRSxPQUFPdEcsS0FBSztBQUFBO0FBQUEsa0JBTC9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLaUQ7QUFBQSxtQkFUbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFXQTtBQUFBLGlCQTVERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZEQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLG9CQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBU3VFO0FBQUFBLGdCQUNULFdBQVU7QUFBQSxnQkFFVjtBQUFBLHlDQUFDLFFBQUssV0FBVSxrQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEI7QUFBQSxrQkFBRztBQUFBO0FBQUE7QUFBQSxjQUpuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQTdFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQThFQTtBQUFBLFVBSURoRyxZQUFZdUgsU0FBUyxLQUFLLENBQUNySCxZQUMxQix1QkFBQyxhQUFVLFNBQVNtRyxlQUFlLE1BQU1yRyxlQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRCxJQUVyRDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0M7QUFBQSxjQUNBLE1BQUs7QUFBQSxjQUNMLFNBQVMsQ0FBQ0UsYUFBYUYsWUFBWXVILFdBQVc7QUFBQTtBQUFBLFlBSGhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUdrRDtBQUFBLGFBbFV4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdVVBLElBRUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFFO0FBQUEsV0FoWU47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1ZQTtBQUFBLFNBdFlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1WUE7QUFBQSxPQXpZRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMFlBO0FBRUo7QUFBQ3hKLEdBMXNCS0Qsc0JBQW9CO0FBQUE2SyxLQUFwQjdLO0FBNHNCTixNQUFNOEssY0FBY0EsQ0FBQyxFQUFFbEgsT0FBT0QsTUFBTSxNQUNsQyx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSx5QkFBQyxPQUFFLFdBQVUseUJBQXlCQyxtQkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE0QztBQUFBLEVBQzVDLHVCQUFDLE9BQUUsV0FBVSw4QkFBOEJELG1CQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWlEO0FBQUEsS0FGbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUdBO0FBQ0FvSCxNQUxJRDtBQWNOLGVBQWU5SztBQUFvQixJQUFBNkssSUFBQUU7QUFBQUMsYUFBQUgsSUFBQTtBQUFBRyxhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwiYXBpIiwiTmF2YmFyIiwiRGF0YVRhYmxlIiwiU2lkZWJhciIsIkNpcmN1bGFyTG9hZGVyIiwiU2V0dGluZ1NpZGViYXIiLCJTZWxlY3QiLCJTZWFyY2giLCJDYWxlbmRhciIsIkF3YXJkIiwiVHJlbmRpbmdVcCIsIlN0YXIiLCJHaWZ0IiwiVHJvcGh5IiwiVXNlcnMiLCJFbXBsb3llZVJld2FyZFBvaW50cyIsIl9zIiwiZW1wbG95ZWVzIiwic2V0RW1wbG95ZWVzIiwidXNlU3RhdGUiLCJlbXBSZXdhcmRzRGF0YSIsInNldEVtcFJld2FyZHNEYXRhIiwiZW1wbG95ZWVJZCIsInNldEVtcGxveWVlSWQiLCJ0b2RheVN0cmluZyIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNwbGl0Iiwic2VsZWN0ZWRMYWJlbCIsInNldFNlbGVjdGVkTGFiZWwiLCJzZWxlY3RlZEZyb21EYXRlIiwic2V0U2VsZWN0ZWRGcm9tRGF0ZSIsInNlbGVjdGVkVG9EYXRlIiwic2V0U2VsZWN0ZWRUb0RhdGUiLCJmcm9tRGF0ZSIsInNldEZyb21EYXRlIiwic2hvd0ZpbHRlckZpZWxkIiwic2V0U2hvd0ZpbHRlckZpZWxkIiwidG9EYXRlIiwic2V0VG9EYXRlIiwicmV3YXJkU3RhdGUiLCJzZXRSZXdhcmRTdGF0ZSIsInJld2FyZHMiLCJhY3RpdmVSZXdhcmRzIiwidG90YWxQb2ludHNBbGwiLCJ0b3RhbEFtb3VudEFsbCIsInRvdGFsRW1wbHllZXMiLCJzZWxlY3RlZEVtcGxveWVlIiwic2V0U2VsZWN0ZWRFbXBsb3llZSIsInJld2FyZFRhYmxlIiwic2V0UmV3YXJkVGFibGUiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJzZXRSZXdhcmRzIiwic3VtbWFyeSIsInNldFN1bW1hcnkiLCJyZXdhcmRfcG9pbnRfdmFsdWUiLCJsb2FuX3Jld2FyZF9wb2ludHMiLCJwaWdtZV9yZXdhcmRfcG9pbnRzIiwidG90YWxfZWFybmVkX2Ftb3VudCIsInRvdGFsX3JlZGVlbWVkX3BvaW50cyIsInRvdGFsX2Vhcm5lZF9yZXdhcmQiLCJ0b3RhbF9yZWRlZW1lZF9hbW91bnQiLCJiYWxhbmNlX2Ftb3VudCIsInNvdXJjZV93aXNlX2Ftb3VudCIsInJlZGVlbVBvaW50cyIsInNldFJlZGVlbVBvaW50cyIsInJlZGVlbVR5cGUiLCJzZXRSZWRlZW1UeXBlIiwicmVkZWVtQW1vdW50Iiwic2V0UmVkZWVtQW1vdW50IiwicmVkZWVtRGVzYyIsInNldFJlZGVlbURlc2MiLCJncm91cE9wdGlvbnMiLCJ2YWx1ZSIsImxhYmVsIiwiZmV0Y2hSZXdhcmRTdW1tYXJ5IiwiZW1wSWQiLCJyZXMiLCJnZXQiLCJkYXRhIiwic3VjY2VzcyIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImZldGNoRGF0YSIsImVtcGxveWVlUmVzIiwiZW1wUmV3YXJkc1JlcyIsIlByb21pc2UiLCJhbGwiLCJsb2ciLCJjb3VudCIsInJld2FyZERhdGEiLCJmaWx0ZXJlZCIsImZpbHRlciIsIml0ZW0iLCJ0b3RhbF9wb2ludHMiLCJzb3J0ZWQiLCJzb3J0IiwiYSIsImIiLCJ0b3RhbFBvaW50cyIsInJlZHVjZSIsInN1bSIsInRvdGFsQW1vdW50IiwidG90YWxfYW1vdW50IiwiZW1wbG95ZWUiLCJlIiwiZmV0Y2hSZXdhcmRQb2ludHMiLCJmb3JtYXR0ZWQiLCJtYXAiLCJyZXdhcmQiLCJpbmRleCIsInJlZmVyZW5jZU5hbWUiLCJncm91cF9pZCIsImdyb3VwX25hbWUiLCJsb2FuX2lkIiwicGlnbWVfaWQiLCJfaWQiLCJzbE5vIiwidXNlck5hbWUiLCJ1c2VyX2lkIiwiZnVsbF9uYW1lIiwidXNlclBob25lIiwicGhvbmVfbnVtYmVyIiwiZ3JvdXBOYW1lIiwiZ3JvdXBWYWx1ZSIsImdyb3VwX3ZhbHVlIiwidGlja2V0Iiwic291cmNlVHlwZSIsInNvdXJjZV90eXBlIiwicmV3YXJkUG9pbnRzIiwicmV3YXJkX3BvaW50cyIsInJld2FyZEFtb3VudCIsInJld2FyZGVkX2Ftb3VudCIsInN0YXR1cyIsInJlbWFya3MiLCJjcmVhdGVSZXdhcmRQb2ludHMiLCJhbGVydCIsInBvc3QiLCJlbXBsb3llZV9pZCIsImZyb21fZGF0ZSIsInRvX2RhdGUiLCJyZXNwb25zZSIsIk51bWJlciIsInJlZGVlbVJld2FyZFBvaW50cyIsInBvaW50c190b19yZWRlZW0iLCJyZWRlbXB0aW9uX3R5cGUiLCJkZXNjcmlwdGlvbiIsIm1lc3NhZ2UiLCJyZXdhcmRDb2x1bW5zIiwia2V5IiwiaGVhZGVyIiwiZmlsdGVyZWRSZXdhcmRzIiwiciIsImVtcGxveWVlX25hbWUiLCJoYW5kbGVTZWxlY3RGaWx0ZXIiLCJ0b2RheSIsImZvcm1hdERhdGUiLCJkYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwieWVzdGVyZGF5Iiwic2V0RGF0ZSIsImdldERhdGUiLCJzdGFydCIsImdldEZ1bGxZZWFyIiwiZ2V0TW9udGgiLCJlbmQiLCJsZW5ndGgiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidG9TdHJpbmciLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwidGltZSIsInRhcmdldCIsInNsaWNlIiwiZGVwYXJ0bWVudCIsInRyZW5kIiwiaWQiLCJlbXAiLCJuYW1lIiwiYmFja2dyb3VuZEltYWdlIiwiYmFja2dyb3VuZFBvc2l0aW9uIiwiYmFja2dyb3VuZFJlcGVhdCIsImJhY2tncm91bmRTaXplIiwicGFkZGluZ1JpZ2h0IiwiX2MiLCJTdW1tYXJ5Q2FyZCIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJFbXBsb3llZVJld2FyZFBvaW50cy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgYXBpIGZyb20gJy4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2UnO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gJy4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXInO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gJy4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGUnO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tICcuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhcic7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tICcuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXInO1xyXG5pbXBvcnQgU2V0dGluZ1NpZGViYXIgZnJvbSAnLi4vY29tcG9uZW50cy9sYXlvdXRzL1NldHRpbmdTaWRlYmFyJztcclxuaW1wb3J0IHsgU2VsZWN0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgU2VhcmNoLCBDYWxlbmRhciwgQXdhcmQsIFRyZW5kaW5nVXAsIFN0YXIsIEdpZnQsIFRyb3BoeSwgVXNlcnMgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xyXG5cclxuLy8gY29uc3QgRW1wbG95ZWVSZXdhcmRQb2ludHMgPSAoKSA9PiB7XHJcbi8vICAgY29uc3QgW2VtcGxveWVlcywgc2V0RW1wbG95ZWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbZW1wbG95ZWVJZCwgc2V0RW1wbG95ZWVJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbi8vICAgY29uc3QgW3Jld2FyZFRhYmxlLCBzZXRSZXdhcmRUYWJsZV0gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbi8vICAgLyogPT09PT09PT09PT09PT09PT0gU1VNTUFSWSBTVEFURVMgPT09PT09PT09PT09PT09PT0gKi9cclxuLy8gICBjb25zdCBbc3VtbWFyeSwgc2V0U3VtbWFyeV0gPSB1c2VTdGF0ZSh7XHJcbi8vICAgICByZXdhcmRfcG9pbnRfdmFsdWU6IDAsXHJcbi8vICAgICBsb2FuX3Jld2FyZF9wb2ludHM6IDAsXHJcbi8vICAgICBwaWdtZV9yZXdhcmRfcG9pbnRzOjAsXHJcbi8vICAgICB0b3RhbF9lYXJuZWRfYW1vdW50OiAwLFxyXG4vLyAgICAgdG90YWxfZWFybmVkX3Jld2FyZDogMCxcclxuLy8gICAgIHRvdGFsX3JlZGVlbWVkX2Ftb3VudDogMCxcclxuLy8gICAgIGJhbGFuY2VfYW1vdW50OiAwLFxyXG4vLyAgICAgc291cmNlX3dpc2VfYW1vdW50OiBbXSxcclxuLy8gICB9KTtcclxuXHJcbi8vICAgLyogPT09PT09PT09PT09PT09PT0gUkVERUVNIFNUQVRFUyA9PT09PT09PT09PT09PT09PSAqL1xyXG4vLyAgIGNvbnN0IFtyZWRlZW1Qb2ludHMsIHNldFJlZGVlbVBvaW50c10gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbcmVkZWVtVHlwZSwgc2V0UmVkZWVtVHlwZV0gPSB1c2VTdGF0ZShcIkNhc2hcIik7XHJcbi8vICAgY29uc3QgW3JlZGVlbUFtb3VudCwgc2V0UmVkZWVtQW1vdW50XSA9IHVzZVN0YXRlKDApO1xyXG4vLyAgIGNvbnN0IFtyZWRlZW1EZXNjLCBzZXRSZWRlZW1EZXNjXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuLy8gICAvKiA9PT09PT09PT09PT09PT09PSBGRVRDSCBFTVBMT1lFRVMgPT09PT09PT09PT09PT09PT0gKi9cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgZmV0Y2hFbXBsb3llZXMoKTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIGNvbnN0IGZldGNoRW1wbG95ZWVzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi9hZ2VudC9nZXQtZW1wbG95ZWVcIik7XHJcbi8vICAgICAgIHNldEVtcGxveWVlcyhyZXMuZGF0YT8uZW1wbG95ZWUgfHwgW10pO1xyXG4vLyAgICAgfSBjYXRjaCB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggZW1wbG95ZWVzXCIpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8qID09PT09PT09PT09PT09PT09IEZFVENIIFNVTU1BUlkgPT09PT09PT09PT09PT09PT0gKi9cclxuLy8gICBjb25zdCBmZXRjaFJld2FyZFN1bW1hcnkgPSBhc3luYyAoZW1wSWQpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXHJcbi8vICAgICAgICAgYC9yZXdhcmQtcG9pbnRzL2VtcGxveWVlLXJld2FyZC1wb2ludHMvJHtlbXBJZH1gXHJcbi8vICAgICAgICk7XHJcblxyXG4vLyAgICAgICBpZiAocmVzLmRhdGE/LnN1Y2Nlc3MpIHtcclxuLy8gICAgICAgICBzZXRTdW1tYXJ5KHJlcy5kYXRhKTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggcmV3YXJkIHN1bW1hcnlcIiwgZXJyKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICAvKiA9PT09PT09PT09PT09PT09PSBGRVRDSCBSRVdBUkQgTElTVCA9PT09PT09PT09PT09PT09PSAqL1xyXG4vLyAgIC8vIGNvbnN0IGZldGNoUmV3YXJkUG9pbnRzID0gYXN5bmMgKGVtcElkKSA9PiB7XHJcbi8vICAgLy8gICBpZiAoIWVtcElkKSByZXR1cm47XHJcblxyXG4vLyAgIC8vICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4vLyAgIC8vICAgdHJ5IHtcclxuLy8gICAvLyAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChgL3Jld2FyZC1wb2ludHMvbGlzdC8ke2VtcElkfWApO1xyXG5cclxuLy8gICAvLyAgICAgY29uc3QgZm9ybWF0dGVkID0gcmVzLmRhdGE/LmRhdGE/Lm1hcCgocmV3YXJkLCBpbmRleCkgPT4gKHtcclxuLy8gICAvLyAgICAgICBfaWQ6IHJld2FyZD8uX2lkLFxyXG4vLyAgIC8vICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuLy8gICAvLyAgICAgICB1c2VyTmFtZTogcmV3YXJkPy51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCItXCIsXHJcbi8vICAgLy8gICAgICAgdXNlclBob25lOiByZXdhcmQ/LnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIi1cIixcclxuLy8gICAvLyAgICAgICBncm91cE5hbWU6IHJld2FyZD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgIFwiLVwiLFxyXG4vLyAgIC8vICAgICAgIGdyb3VwVmFsdWU6IHJld2FyZD8uZ3JvdXBfaWQ/Lmdyb3VwX3ZhbHVlIHx8IFwiLVwiLFxyXG4vLyAgIC8vICAgICAgIHRpY2tldDogcmV3YXJkPy50aWNrZXQgfHwgXCItXCIsXHJcbi8vICAgLy8gICAgICAgc291cmNlVHlwZTogcmV3YXJkPy5zb3VyY2VfdHlwZSB8fCBcIi1cIixcclxuLy8gICAvLyAgICAgICByZXdhcmRQb2ludHM6IHJld2FyZD8ucmV3YXJkX3BvaW50cyB8fCAwLFxyXG4vLyAgIC8vICAgICAgIHJld2FyZEFtb3VudDogcmV3YXJkPy5yZXdhcmRlZF9hbW91bnQgfHwgMCxcclxuLy8gICAvLyAgICAgICBzdGF0dXM6IHJld2FyZD8uc3RhdHVzIHx8IFwiTi9BXCIsXHJcbi8vICAgLy8gICAgICAgcmVtYXJrczogcmV3YXJkPy5yZW1hcmtzIHx8IFwiLVwiLFxyXG4vLyAgIC8vICAgICB9KSk7XHJcblxyXG4vLyAgIC8vICAgICBzZXRSZXdhcmRUYWJsZShmb3JtYXR0ZWQpO1xyXG4vLyAgIC8vICAgfSBjYXRjaCAoZXJyKSB7XHJcbi8vICAgLy8gICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggcmV3YXJkIGxpc3RcIiwgZXJyKTtcclxuLy8gICAvLyAgIH0gZmluYWxseSB7XHJcbi8vICAgLy8gICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbi8vICAgLy8gICB9XHJcbi8vICAgLy8gfTtcclxuLy8gY29uc3QgZmV0Y2hSZXdhcmRQb2ludHMgPSBhc3luYyAoZW1wSWQpID0+IHtcclxuLy8gICBpZiAoIWVtcElkKSByZXR1cm47XHJcblxyXG4vLyAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuLy8gICB0cnkge1xyXG4vLyAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChgL3Jld2FyZC1wb2ludHMvbGlzdC8ke2VtcElkfWApO1xyXG5cclxuLy8gICAgIGNvbnN0IGZvcm1hdHRlZCA9IHJlcy5kYXRhPy5kYXRhPy5tYXAoKHJld2FyZCwgaW5kZXgpID0+IHtcclxuLy8gICAgICAgbGV0IHJlZmVyZW5jZU5hbWUgPSBcIi1cIjtcclxuLy8gICAgICAvLyBsZXQgcmVmZXJlbmNlVmFsdWUgPSBcIi1cIjtcclxuXHJcbi8vICAgICAgIC8vIOKchSBFTlJPTExNRU5UXHJcbi8vICAgICAgIGlmIChyZXdhcmQ/Lmdyb3VwX2lkKSB7XHJcbi8vICAgICAgICAgcmVmZXJlbmNlTmFtZSA9IHJld2FyZD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWU7XHJcbi8vICAgICAgIC8vICByZWZlcmVuY2VWYWx1ZSA9IHJld2FyZC5ncm91cF9pZC5ncm91cF92YWx1ZTtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgICAvLyDinIUgTE9BTlxyXG4vLyAgICAgICBlbHNlIGlmIChyZXdhcmQ/LmxvYW5faWQpIHtcclxuLy8gICAgICAgICByZWZlcmVuY2VOYW1lID0gcmV3YXJkLmxvYW5faWQ/LmxvYW5faWQ7IC8vIExOMThcclxuLy8gICAgICAgLy8gIHJlZmVyZW5jZVZhbHVlID0gcmV3YXJkLmxvYW5faWQubG9hbl9hbW91bnQ7XHJcbi8vICAgICAgIH1cclxuLy8gICAgICAgLy8g4pyFIFBJR01ZXHJcbi8vICAgICAgIGVsc2UgaWYgKHJld2FyZD8ucGlnbWVfaWQpIHtcclxuLy8gICAgICAgICByZWZlcmVuY2VOYW1lID0gcmV3YXJkLnBpZ21lX2lkPy5waWdtZV9pZDsgLy8gUEd4eFxyXG4vLyAgICAgICAgLy8gcmVmZXJlbmNlVmFsdWUgPSByZXdhcmQucGlnbXlfaWQubW9udGhseV9hbW91bnQ7XHJcbi8vICAgICAgIH1cclxuXHJcbi8vICAgICAgIHJldHVybiB7XHJcbi8vICAgICAgICAgX2lkOiByZXdhcmQ/Ll9pZCxcclxuLy8gICAgICAgICBzbE5vOiBpbmRleCArIDEsXHJcbi8vICAgICAgICAgdXNlck5hbWU6IHJld2FyZD8udXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4vLyAgICAgICAgIHVzZXJQaG9uZTogcmV3YXJkPy51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcbi8vICAgICAgICAgZ3JvdXBOYW1lOiByZWZlcmVuY2VOYW1lLFxyXG4vLyAgICAgICAgIGdyb3VwVmFsdWU6IHJld2FyZD8uZ3JvdXBfaWQ/Lmdyb3VwX3ZhbHVlLFxyXG4vLyAgICAgICAgIHRpY2tldDogcmV3YXJkPy50aWNrZXQgfHwgXCItXCIsXHJcbi8vICAgICAgICAgc291cmNlVHlwZTogcmV3YXJkPy5zb3VyY2VfdHlwZSB8fCBcIi1cIixcclxuLy8gICAgICAgICByZXdhcmRQb2ludHM6IHJld2FyZD8ucmV3YXJkX3BvaW50cyB8fCAwLFxyXG4vLyAgICAgICAgIHJld2FyZEFtb3VudDogcmV3YXJkPy5yZXdhcmRlZF9hbW91bnQgfHwgMCxcclxuLy8gICAgICAgICBzdGF0dXM6IHJld2FyZD8uc3RhdHVzIHx8IFwiTi9BXCIsXHJcbi8vICAgICAgICAgcmVtYXJrczogcmV3YXJkPy5yZW1hcmtzIHx8IFwiLVwiLFxyXG4vLyAgICAgICB9O1xyXG4vLyAgICAgfSk7XHJcblxyXG4vLyAgICAgc2V0UmV3YXJkVGFibGUoZm9ybWF0dGVkKTtcclxuLy8gICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggcmV3YXJkIGxpc3RcIiwgZXJyKTtcclxuLy8gICB9IGZpbmFsbHkge1xyXG4vLyAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuLy8gICB9XHJcbi8vIH07XHJcblxyXG4vLyAgIC8qID09PT09PT09PT09PT09PT09IENSRUFURSBSRVdBUkQgPT09PT09PT09PT09PT09PT0gKi9cclxuLy8gICBjb25zdCBjcmVhdGVSZXdhcmRQb2ludHMgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICBpZiAoIWVtcGxveWVlSWQpIHJldHVybiBhbGVydChcIlNlbGVjdCBlbXBsb3llZVwiKTtcclxuXHJcbi8vICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbi8vICAgICB0cnkge1xyXG4vLyAgICAgICBhd2FpdCBhcGkucG9zdChcIi9yZXdhcmQtcG9pbnRzL2VtcGxveWVlLXJld2FyZC1wb2ludHNcIiwge1xyXG4vLyAgICAgICAgIGVtcGxveWVlX2lkOiBlbXBsb3llZUlkLFxyXG4vLyAgICAgICB9KTtcclxuXHJcbi8vICAgICAgIGF3YWl0IGZldGNoUmV3YXJkU3VtbWFyeShlbXBsb3llZUlkKTtcclxuLy8gICAgICAgYXdhaXQgZmV0Y2hSZXdhcmRQb2ludHMoZW1wbG95ZWVJZCk7XHJcbi8vICAgICB9IGZpbmFsbHkge1xyXG4vLyAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIC8qID09PT09PT09PT09PT09PT09IEFVVE8gQ0FMQ1VMQVRFIEFNT1VOVCA9PT09PT09PT09PT09PT09PSAqL1xyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBpZiAocmVkZWVtVHlwZSA9PT0gXCJDYXNoXCIpIHtcclxuLy8gICAgICAgc2V0UmVkZWVtQW1vdW50KFxyXG4vLyAgICAgICAgIE51bWJlcihyZWRlZW1Qb2ludHMgfHwgMCkgKiBzdW1tYXJ5LnJld2FyZF9wb2ludF92YWx1ZVxyXG4vLyAgICAgICApO1xyXG4vLyAgICAgfSBlbHNlIHtcclxuLy8gICAgICAgc2V0UmVkZWVtQW1vdW50KDApO1xyXG4vLyAgICAgfVxyXG4vLyAgIH0sIFtyZWRlZW1Qb2ludHMsIHJlZGVlbVR5cGUsIHN1bW1hcnkucmV3YXJkX3BvaW50X3ZhbHVlXSk7XHJcblxyXG4vLyAgIC8qID09PT09PT09PT09PT09PT09IFJFREVFTSBQT0lOVFMgPT09PT09PT09PT09PT09PT0gKi9cclxuLy8gICBjb25zdCByZWRlZW1SZXdhcmRQb2ludHMgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICBpZiAoIWVtcGxveWVlSWQpIHJldHVybiBhbGVydChcIlNlbGVjdCBlbXBsb3llZVwiKTtcclxuLy8gICAgIGlmICghcmVkZWVtUG9pbnRzKSByZXR1cm4gYWxlcnQoXCJFbnRlciByZXdhcmQgcG9pbnRzXCIpO1xyXG5cclxuLy8gICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGF3YWl0IGFwaS5wb3N0KFwiL3Jld2FyZC1wb2ludHMvZW1wbG95ZWUtcmV3YXJkLXBvaW50cy9yZWRlZW1cIiwge1xyXG4vLyAgICAgICAgIGVtcGxveWVlX2lkOiBlbXBsb3llZUlkLFxyXG4vLyAgICAgICAgIHBvaW50c190b19yZWRlZW06IE51bWJlcihyZWRlZW1Qb2ludHMpLFxyXG4vLyAgICAgICAgIHJlZGVtcHRpb25fdHlwZTogcmVkZWVtVHlwZSxcclxuLy8gICAgICAgICBkZXNjcmlwdGlvbjogcmVkZWVtRGVzYyxcclxuLy8gICAgICAgfSk7XHJcblxyXG4vLyAgICAgICBzZXRSZWRlZW1Qb2ludHMoXCJcIik7XHJcbi8vICAgICAgIHNldFJlZGVlbURlc2MoXCJcIik7XHJcblxyXG4vLyAgICAgICBhd2FpdCBmZXRjaFJld2FyZFN1bW1hcnkoZW1wbG95ZWVJZCk7XHJcbi8vICAgICAgIGF3YWl0IGZldGNoUmV3YXJkUG9pbnRzKGVtcGxveWVlSWQpO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbi8vICAgICAgIGFsZXJ0KGVyci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIlJlZGVlbSBmYWlsZWRcIik7XHJcbi8vICAgICB9IGZpbmFsbHkge1xyXG4vLyAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IHJld2FyZENvbHVtbnMgPSBbXHJcbi8vICAgICB7IGtleTogXCJzbE5vXCIsIGhlYWRlcjogXCJTbCBOb1wiIH0sXHJcbi8vICAgICB7IGtleTogXCJ1c2VyTmFtZVwiLCBoZWFkZXI6IFwiTmFtZVwiIH0sXHJcbi8vICAgICB7IGtleTogXCJ1c2VyUGhvbmVcIiwgaGVhZGVyOiBcIlBob25lXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImdyb3VwTmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgLyBMb2FuIC8gUGlnbXkgXCIgfSxcclxuLy8gICAgIHsga2V5OiBcImdyb3VwVmFsdWVcIiwgaGVhZGVyOiBcIkdyb3VwIFZhbHVlXCIgfSxcclxuLy8gICAgIHsga2V5OiBcInRpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0XCIgfSxcclxuLy8gICAgIHsga2V5OiBcInNvdXJjZVR5cGVcIiwgaGVhZGVyOiBcIlR5cGVcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwicmV3YXJkUG9pbnRzXCIsIGhlYWRlcjogXCJQb2ludHNcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwicmV3YXJkQW1vdW50XCIsIGhlYWRlcjogXCJBbW91bnRcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4vLyAgICAgeyBrZXk6IFwicmVtYXJrc1wiLCBoZWFkZXI6IFwiUmVtYXJrc1wiIH0sXHJcbi8vICAgXTtcclxuXHJcbi8vICAgcmV0dXJuIChcclxuLy8gICAgIDxkaXY+XHJcbi8vICAgICAgIDxOYXZiYXIgdmlzaWJpbGl0eSAvPlxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuLy8gICAgICAgICA8U2V0dGluZ1NpZGViYXIgLz5cclxuXHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbi8vICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCBtYi02XCI+XHJcbi8vICAgICAgICAgICAgIEVtcGxveWVlIFJld2FyZCBQb2ludHNcclxuLy8gICAgICAgICAgIDwvaDE+XHJcblxyXG4vLyAgICAgICAgICAgey8qID09PT09PT09PT09PT09PT09IFNFTEVDVCBFTVBMT1lFRSA9PT09PT09PT09PT09PT09PSAqL31cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNCBtYi02XCI+XHJcbi8vICAgICAgICAgICAgIDxzZWxlY3RcclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcHgtNCBweS0yIHJvdW5kZWQgdy02NFwiXHJcbi8vICAgICAgICAgICAgICAgdmFsdWU9e2VtcGxveWVlSWR9XHJcbi8vICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgICBjb25zdCBlbXBJZCA9IGUudGFyZ2V0LnZhbHVlO1xyXG4vLyAgICAgICAgICAgICAgICAgc2V0RW1wbG95ZWVJZChlbXBJZCk7XHJcbi8vICAgICAgICAgICAgICAgICBzZXRSZXdhcmRUYWJsZShbXSk7XHJcbi8vICAgICAgICAgICAgICAgICBpZiAoZW1wSWQpIHtcclxuLy8gICAgICAgICAgICAgICAgICAgZmV0Y2hSZXdhcmRTdW1tYXJ5KGVtcElkKTtcclxuLy8gICAgICAgICAgICAgICAgICAgZmV0Y2hSZXdhcmRQb2ludHMoZW1wSWQpO1xyXG4vLyAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IEVtcGxveWVlPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGVtcCkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2VtcC5faWR9IHZhbHVlPXtlbXAuX2lkfT5cclxuLy8gICAgICAgICAgICAgICAgICAge2VtcC5uYW1lfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG5cclxuLy8gICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgIG9uQ2xpY2s9e2NyZWF0ZVJld2FyZFBvaW50c31cclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHB4LTYgcHktMiByb3VuZGVkXCJcclxuLy8gICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgIENyZWF0ZSBSZXdhcmQgUG9pbnRzXHJcbi8vICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgey8qID09PT09PT09PT09PT09PT09IFNVTU1BUlkgQ0FSRFMgPT09PT09PT09PT09PT09PT0gKi99XHJcbi8vICAgICAgICAgICB7ZW1wbG95ZWVJZCAmJiAoXHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtNSBnYXAtNCBtYi02XCI+XHJcbi8vICAgICAgICAgICAgICAgPFN1bW1hcnlDYXJkIGxhYmVsPVwiRWFybmVkIEFtb3VudFwiIHZhbHVlPXtg4oK5ICR7c3VtbWFyeS50b3RhbF9lYXJuZWRfYW1vdW50fWB9IC8+XHJcbi8vICAgICAgICAgICAgICAgPFN1bW1hcnlDYXJkIGxhYmVsPVwiRWFybmVkIFBvaW50c1wiIHZhbHVlPXtzdW1tYXJ5LnRvdGFsX2Vhcm5lZF9yZXdhcmR9IC8+XHJcbi8vICAgICAgICAgICAgICAgPFN1bW1hcnlDYXJkIGxhYmVsPVwiUmVkZWVtZWQgQW1vdW50XCIgdmFsdWU9e2DigrkgJHtzdW1tYXJ5LnRvdGFsX3JlZGVlbWVkX2Ftb3VudH1gfSAvPlxyXG4vLyAgICAgICAgICAgICAgIHsvKiA8U3VtbWFyeUNhcmQgbGFiZWw9XCJCYWxhbmNlIEFtb3VudFwiIHZhbHVlPXtg4oK5ICR7c3VtbWFyeS5iYWxhbmNlX2Ftb3VudH1gfSAvPiAqL31cclxuLy8gICAgICAgICAgICAgICA8U3VtbWFyeUNhcmQgbGFiZWw9XCJPbmUgQ2hpdCBSZXdhcmQgUG9pbnQgVmFsdWVcIiB2YWx1ZT17YOKCuSAke3N1bW1hcnkucmV3YXJkX3BvaW50X3ZhbHVlfWB9IC8+XHJcblxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICl9XHJcblxyXG4vLyAgICAgICAgICAgey8qID09PT09PT09PT09PT09PT09IFJFREVFTSBTRUNUSU9OID09PT09PT09PT09PT09PT09ICovfVxyXG4vLyAgICAgICAgICAge2VtcGxveWVlSWQgJiYgKFxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciByb3VuZGVkIHAtNCBtYi02XCI+XHJcbi8vICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgbWItNFwiPlJlZGVlbSBSZXdhcmQgUG9pbnRzPC9oMj5cclxuXHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy00IGdhcC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUmV3YXJkIFBvaW50c1wiXHJcbi8vICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTIgcm91bmRlZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbHVlPXtyZWRlZW1Qb2ludHN9XHJcbi8vICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UmVkZWVtUG9pbnRzKGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgIC8+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHJvdW5kZWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICB2YWx1ZT17cmVkZWVtVHlwZX1cclxuLy8gICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRSZWRlZW1UeXBlKGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNhc2hcIj5DYXNoPC9vcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJHaWZ0XCI+R2lmdDwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiT3RoZXJcIj5PdGhlcjwvb3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAge3JlZGVlbVR5cGUgPT09IFwiQ2FzaFwiICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHJvdW5kZWQgYmctZ3JheS0xMDBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtg4oK5ICR7cmVkZWVtQW1vdW50fWB9XHJcbi8vICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICApfVxyXG5cclxuLy8gICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGVzY3JpcHRpb25cIlxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHJvdW5kZWQgY29sLXNwYW4tMlwiXHJcbi8vICAgICAgICAgICAgICAgICAgIHZhbHVlPXtyZWRlZW1EZXNjfVxyXG4vLyAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJlZGVlbURlc2MoZS50YXJnZXQudmFsdWUpfVxyXG4vLyAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4vLyAgICAgICAgICAgICAgICAgb25DbGljaz17cmVkZWVtUmV3YXJkUG9pbnRzfVxyXG4vLyAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtNCBiZy1ncmVlbi02MDAgdGV4dC13aGl0ZSBweC02IHB5LTIgcm91bmRlZFwiXHJcbi8vICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgUmVkZWVtIFBvaW50c1xyXG4vLyAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICl9XHJcblxyXG4vLyAgICAgICAgICAgey8qID09PT09PT09PT09PT09PT09IFRBQkxFID09PT09PT09PT09PT09PT09ICovfVxyXG4vLyAgICAgICAgICAge3Jld2FyZFRhYmxlLmxlbmd0aCA+IDAgJiYgIWlzTG9hZGluZyA/IChcclxuLy8gICAgICAgICAgICAgPERhdGFUYWJsZSBjb2x1bW5zPXtyZXdhcmRDb2x1bW5zfSBkYXRhPXtyZXdhcmRUYWJsZX0gLz5cclxuLy8gICAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4vLyAgICAgICAgICAgICAgIGlzTG9hZGluZz17aXNMb2FkaW5nfVxyXG4vLyAgICAgICAgICAgICAgIGRhdGE9XCJFbXBsb3llZSBSZXdhcmRcIlxyXG4vLyAgICAgICAgICAgICAgIGZhaWx1cmU9eyFpc0xvYWRpbmcgJiYgcmV3YXJkVGFibGUubGVuZ3RoID09PSAwfVxyXG4vLyAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgKX1cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgPC9kaXY+XHJcbi8vICAgICA8L2Rpdj5cclxuLy8gICApO1xyXG4vLyB9O1xyXG5cclxuLy8gLyogPT09PT09PT09PT09PT09PT0gU1VNTUFSWSBDQVJEID09PT09PT09PT09PT09PT09ICovXHJcbi8vIGNvbnN0IFN1bW1hcnlDYXJkID0gKHsgbGFiZWwsIHZhbHVlIH0pID0+IChcclxuLy8gICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciByb3VuZGVkIHAtNCBiZy13aGl0ZSBzaGFkb3ctc21cIj5cclxuLy8gICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1zbVwiPntsYWJlbH08L3A+XHJcbi8vICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgbXQtMVwiPnt2YWx1ZX08L3A+XHJcbi8vICAgPC9kaXY+XHJcbi8vICk7XHJcblxyXG5cclxuY29uc3QgRW1wbG95ZWVSZXdhcmRQb2ludHMgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2VtcGxveWVlcywgc2V0RW1wbG95ZWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZW1wUmV3YXJkc0RhdGEsIHNldEVtcFJld2FyZHNEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZW1wbG95ZWVJZCwgc2V0RW1wbG95ZWVJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCB0b2RheVN0cmluZyA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcbiAgY29uc3QgW3NlbGVjdGVkTGFiZWwsIHNldFNlbGVjdGVkTGFiZWxdID0gdXNlU3RhdGUoXCJUb2RheVwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRGcm9tRGF0ZSwgc2V0U2VsZWN0ZWRGcm9tRGF0ZV0gPSB1c2VTdGF0ZSh0b2RheVN0cmluZyk7XHJcbiAgY29uc3QgW3NlbGVjdGVkVG9EYXRlLCBzZXRTZWxlY3RlZFRvRGF0ZV0gPSB1c2VTdGF0ZSh0b2RheVN0cmluZyk7XHJcbiAgLy8g4pyFIE5FVzogRGF0ZSByYW5nZSBzdGF0ZVxyXG4gIGNvbnN0IFtmcm9tRGF0ZSwgc2V0RnJvbURhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Nob3dGaWx0ZXJGaWVsZCwgc2V0U2hvd0ZpbHRlckZpZWxkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdG9EYXRlLCBzZXRUb0RhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgLy8gY29uc3RbdG90YWxFbXBseWVlcywgc2V0VG90YWxFbXBsb3llZXNdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW3Jld2FyZFN0YXRlLCBzZXRSZXdhcmRTdGF0ZV0gPSB1c2VTdGF0ZSh7XHJcbiAgICByZXdhcmRzOiBbXSxcclxuICAgIGFjdGl2ZVJld2FyZHM6IFtdLFxyXG4gICAgdG90YWxQb2ludHNBbGw6IDAsXHJcbiAgICB0b3RhbEFtb3VudEFsbDogMCxcclxuICAgIHRvdGFsRW1wbHllZXM6IDAsXHJcbiAgfSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkRW1wbG95ZWUsIHNldFNlbGVjdGVkRW1wbG95ZWVdID0gdXNlU3RhdGUoJ2FsbCcpO1xyXG5cclxuICBjb25zdCBbcmV3YXJkVGFibGUsIHNldFJld2FyZFRhYmxlXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtyZXdhcmRzLCBzZXRSZXdhcmRzXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbiAgLyogPT09PT09PT09PT09PT09PT0gU1VNTUFSWSBTVEFURVMgPT09PT09PT09PT09PT09PT0gKi9cclxuICBjb25zdCBbc3VtbWFyeSwgc2V0U3VtbWFyeV0gPSB1c2VTdGF0ZSh7XHJcbiAgICByZXdhcmRfcG9pbnRfdmFsdWU6IDAsXHJcbiAgICBsb2FuX3Jld2FyZF9wb2ludHM6IDAsXHJcbiAgICBwaWdtZV9yZXdhcmRfcG9pbnRzOiAwLFxyXG4gICAgdG90YWxfZWFybmVkX2Ftb3VudDogMCxcclxuICAgIHRvdGFsX3JlZGVlbWVkX3BvaW50czogMCxcclxuICAgIHRvdGFsX2Vhcm5lZF9yZXdhcmQ6IDAsXHJcbiAgICB0b3RhbF9yZWRlZW1lZF9hbW91bnQ6IDAsXHJcbiAgICBiYWxhbmNlX2Ftb3VudDogMCxcclxuICAgIHNvdXJjZV93aXNlX2Ftb3VudDogW10sXHJcbiAgfSk7XHJcblxyXG4gIC8qID09PT09PT09PT09PT09PT09IFJFREVFTSBTVEFURVMgPT09PT09PT09PT09PT09PT0gKi9cclxuICBjb25zdCBbcmVkZWVtUG9pbnRzLCBzZXRSZWRlZW1Qb2ludHNdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3JlZGVlbVR5cGUsIHNldFJlZGVlbVR5cGVdID0gdXNlU3RhdGUoXCJDYXNoXCIpO1xyXG4gIGNvbnN0IFtyZWRlZW1BbW91bnQsIHNldFJlZGVlbUFtb3VudF0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbcmVkZWVtRGVzYywgc2V0UmVkZWVtRGVzY10gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcblxyXG4gIGNvbnN0IGdyb3VwT3B0aW9ucyA9IFtcclxuICAgIHsgdmFsdWU6IFwiVG9kYXlcIiwgbGFiZWw6IFwiVG9kYXlcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJZZXN0ZXJkYXlcIiwgbGFiZWw6IFwiWWVzdGVyZGF5XCIgfSxcclxuICAgIHsgdmFsdWU6IFwiVGhpc01vbnRoXCIsIGxhYmVsOiBcIlRoaXMgTW9udGhcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCJMYXN0TW9udGhcIiwgbGFiZWw6IFwiTGFzdCBNb250aFwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIlRoaXNZZWFyXCIsIGxhYmVsOiBcIlRoaXMgWWVhclwiIH0sXHJcbiAgICB7IHZhbHVlOiBcIkN1c3RvbVwiLCBsYWJlbDogXCJDdXN0b21cIiB9LFxyXG4gIF07XHJcblxyXG4gIC8qID09PT09PT09PT09PT09PT09IEZFVENIIEVNUExPWUVFUyA9PT09PT09PT09PT09PT09PSAqL1xyXG4gIC8vIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgLy8gICBmZXRjaEVtcGxveWVlcygpO1xyXG4gIC8vIH0sIFtdKTtcclxuXHJcbiAgLy8gY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgLy8gICB0cnkge1xyXG4gIC8vICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2FnZW50L2dldC1lbXBsb3llZVwiKTtcclxuICAvLyAgICAgc2V0RW1wbG95ZWVzKHJlcy5kYXRhPy5lbXBsb3llZSB8fCBbXSk7XHJcbiAgLy8gICB9IGNhdGNoIHtcclxuICAvLyAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBlbXBsb3llZXNcIik7XHJcbiAgLy8gICB9XHJcbiAgLy8gfTtcclxuXHJcbiAgLyogPT09PT09PT09PT09PT09PT0gRkVUQ0ggU1VNTUFSWSA9PT09PT09PT09PT09PT09PSAqL1xyXG4gIGNvbnN0IGZldGNoUmV3YXJkU3VtbWFyeSA9IGFzeW5jIChlbXBJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL3Jld2FyZC1wb2ludHMvZW1wbG95ZWUtcmV3YXJkLXBvaW50cy8ke2VtcElkfWBcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGlmIChyZXMuZGF0YT8uc3VjY2Vzcykge1xyXG4gICAgICAgIHNldFN1bW1hcnkocmVzLmRhdGEpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCByZXdhcmQgc3VtbWFyeVwiLCBlcnIpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgLy8gdXNlRWZmZWN0KCgpID0+IHtcclxuICAvLyAgIC8vIFNpbXVsYXRlIEFQSSBjYWxsXHJcbiAgLy8gICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAvLyAgICAgc2V0UmV3YXJkcyhbXHJcbiAgLy8gICAgICAgeyBpZDogMSwgbmFtZTogJ0pvaG4gU21pdGgnLCBkZXBhcnRtZW50OiAnRW5naW5lZXJpbmcnLCBwb2ludHM6IDQ1MCwgcmV3YXJkczogMTIsIHRyZW5kOiAndXAnIH0sXHJcbiAgLy8gICAgICAgeyBpZDogMiwgbmFtZTogJ1NhcmFoIEpvaG5zb24nLCBkZXBhcnRtZW50OiAnTWFya2V0aW5nJywgcG9pbnRzOiAzODAsIHJld2FyZHM6IDksIHRyZW5kOiAndXAnIH0sXHJcbiAgLy8gICAgICAgeyBpZDogMywgbmFtZTogJ01pY2hhZWwgQ2hlbicsIGRlcGFydG1lbnQ6ICdEZXNpZ24nLCBwb2ludHM6IDMyMCwgcmV3YXJkczogNywgdHJlbmQ6ICdkb3duJyB9LFxyXG4gIC8vICAgICAgIHsgaWQ6IDQsIG5hbWU6ICdFbWlseSBSb2RyaWd1ZXonLCBkZXBhcnRtZW50OiAnU2FsZXMnLCBwb2ludHM6IDI5MCwgcmV3YXJkczogNiwgdHJlbmQ6ICd1cCcgfSxcclxuICAvLyAgICAgICB7IGlkOiA1LCBuYW1lOiAnRGF2aWQgS2ltJywgZGVwYXJ0bWVudDogJ0VuZ2luZWVyaW5nJywgcG9pbnRzOiAyNzAsIHJld2FyZHM6IDUsIHRyZW5kOiAnc2FtZScgfSxcclxuICAvLyAgICAgXSk7XHJcbiAgLy8gICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgLy8gICB9LCAxMDAwKTtcclxuICAvLyB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaERhdGEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgW2VtcGxveWVlUmVzLCBlbXBSZXdhcmRzUmVzXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICAgIGFwaS5nZXQoXCIvYWdlbnQvZ2V0LWVtcGxveWVlXCIpLFxyXG4gICAgICAgICAgYXBpLmdldChgL3Jld2FyZC1wb2ludHMvcmV3YXJkcy90b3AtZW1wbG95ZWVzP2Zyb21fZGF0ZT0ke3NlbGVjdGVkRnJvbURhdGV9JnRvX2RhdGU9JHtzZWxlY3RlZFRvRGF0ZX1gKSxcclxuICAgICAgICBdKTtcclxuICAgICAgICBjb25zb2xlLmxvZyhlbXBSZXdhcmRzUmVzLmRhdGEuY291bnQsIFwiZW1wUmV3YXJkc1Jlc1wiKTtcclxuICAgICAgICAvLyBzZXRUb3RhbEVtcGxveWVlcyhlbXBSZXdhcmRzUmVzLmRhdGEuY291bnQgfHwgMCk7XHJcbiAgICAgICAgY29uc3QgcmV3YXJkRGF0YSA9IGVtcFJld2FyZHNSZXMuZGF0YT8uZGF0YSB8fCBbXTtcclxuXHJcbiAgICAgICAgLy8gMe+4j+KDoyBSZW1vdmUgemVybyBwb2ludHNcclxuICAgICAgICBjb25zdCBmaWx0ZXJlZCA9IHJld2FyZERhdGEuZmlsdGVyKFxyXG4gICAgICAgICAgKGl0ZW0pID0+IGl0ZW0udG90YWxfcG9pbnRzID4gMFxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIC8vIDLvuI/ig6MgU29ydCBkZXNjZW5kaW5nXHJcbiAgICAgICAgY29uc3Qgc29ydGVkID0gWy4uLmZpbHRlcmVkXS5zb3J0KFxyXG4gICAgICAgICAgKGEsIGIpID0+IGIudG90YWxfcG9pbnRzIC0gYS50b3RhbF9wb2ludHNcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICAvLyAz77iP4oOjIENhbGN1bGF0ZSB0b3RhbHMgKGFsbCBkYXRhKVxyXG4gICAgICAgIGNvbnN0IHRvdGFsUG9pbnRzID0gcmV3YXJkRGF0YS5yZWR1Y2UoXHJcbiAgICAgICAgICAoc3VtLCBpdGVtKSA9PiBzdW0gKyBpdGVtLnRvdGFsX3BvaW50cyxcclxuICAgICAgICAgIDBcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICBjb25zdCB0b3RhbEFtb3VudCA9IHJld2FyZERhdGEucmVkdWNlKFxyXG4gICAgICAgICAgKHN1bSwgaXRlbSkgPT4gc3VtICsgaXRlbS50b3RhbF9hbW91bnQsXHJcbiAgICAgICAgICAwXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgLy8gNO+4j+KDoyBVcGRhdGUgc2luZ2xlIHN0YXRlXHJcbiAgICAgICAgc2V0UmV3YXJkU3RhdGUoe1xyXG4gICAgICAgICAgcmV3YXJkczogZmlsdGVyZWQsXHJcbiAgICAgICAgICBhY3RpdmVSZXdhcmRzOiBzb3J0ZWQsXHJcbiAgICAgICAgICB0b3RhbFBvaW50c0FsbDogdG90YWxQb2ludHMsXHJcbiAgICAgICAgICB0b3RhbEFtb3VudEFsbDogdG90YWxBbW91bnQsXHJcbiAgICAgICAgICB0b3RhbEVtcGx5ZWVzOiBlbXBSZXdhcmRzUmVzLmRhdGE/LmNvdW50IHx8IDAsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2V0RW1wbG95ZWVzKGVtcGxveWVlUmVzLmRhdGEuZW1wbG95ZWUgfHwgW10pO1xyXG4gICAgICAgIHNldFJld2FyZHMoW2VtcFJld2FyZHNSZXMuZGF0YT8uZGF0YV0gfHwgW10pO1xyXG4gICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoRGF0YSgpO1xyXG4gICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICB9LCBbc2VsZWN0ZWRGcm9tRGF0ZSxzZWxlY3RlZFRvRGF0ZV0pO1xyXG5cclxuICBjb25zdCBmZXRjaFJld2FyZFBvaW50cyA9IGFzeW5jIChlbXBJZCkgPT4ge1xyXG4gICAgaWYgKCFlbXBJZCkgcmV0dXJuO1xyXG5cclxuICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoYC9yZXdhcmQtcG9pbnRzL2xpc3QvJHtlbXBJZH1gKTtcclxuXHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IHJlcy5kYXRhPy5kYXRhPy5tYXAoKHJld2FyZCwgaW5kZXgpID0+IHtcclxuICAgICAgICBsZXQgcmVmZXJlbmNlTmFtZSA9IFwiLVwiO1xyXG5cclxuICAgICAgICBpZiAocmV3YXJkPy5ncm91cF9pZCkge1xyXG4gICAgICAgICAgcmVmZXJlbmNlTmFtZSA9IHJld2FyZD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWU7XHJcbiAgICAgICAgfSBlbHNlIGlmIChyZXdhcmQ/LmxvYW5faWQpIHtcclxuICAgICAgICAgIHJlZmVyZW5jZU5hbWUgPSByZXdhcmQubG9hbl9pZD8ubG9hbl9pZDtcclxuICAgICAgICB9IGVsc2UgaWYgKHJld2FyZD8ucGlnbWVfaWQpIHtcclxuICAgICAgICAgIHJlZmVyZW5jZU5hbWUgPSByZXdhcmQucGlnbWVfaWQ/LnBpZ21lX2lkO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIF9pZDogcmV3YXJkPy5faWQsXHJcbiAgICAgICAgICBzbE5vOiBpbmRleCArIDEsXHJcbiAgICAgICAgICB1c2VyTmFtZTogcmV3YXJkPy51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCItXCIsXHJcbiAgICAgICAgICB1c2VyUGhvbmU6IHJld2FyZD8udXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgICAgICAgZ3JvdXBOYW1lOiByZWZlcmVuY2VOYW1lLFxyXG4gICAgICAgICAgZ3JvdXBWYWx1ZTogcmV3YXJkPy5ncm91cF9pZD8uZ3JvdXBfdmFsdWUsXHJcbiAgICAgICAgICB0aWNrZXQ6IHJld2FyZD8udGlja2V0IHx8IFwiLVwiLFxyXG4gICAgICAgICAgc291cmNlVHlwZTogcmV3YXJkPy5zb3VyY2VfdHlwZSB8fCBcIi1cIixcclxuICAgICAgICAgIHJld2FyZFBvaW50czogcmV3YXJkPy5yZXdhcmRfcG9pbnRzIHx8IDAsXHJcbiAgICAgICAgICByZXdhcmRBbW91bnQ6IHJld2FyZD8ucmV3YXJkZWRfYW1vdW50IHx8IDAsXHJcbiAgICAgICAgICBzdGF0dXM6IHJld2FyZD8uc3RhdHVzIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICByZW1hcmtzOiByZXdhcmQ/LnJlbWFya3MgfHwgXCItXCIsXHJcbiAgICAgICAgfTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBzZXRSZXdhcmRUYWJsZShmb3JtYXR0ZWQpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggcmV3YXJkIGxpc3RcIiwgZXJyKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLyogPT09PT09PT09PT09PT09PT0gQ1JFQVRFIFJFV0FSRCBXSVRIIERBVEUgUkFOR0UgPT09PT09PT09PT09PT09PT0gKi9cclxuICBjb25zdCBjcmVhdGVSZXdhcmRQb2ludHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIWVtcGxveWVlSWQpIHJldHVybiBhbGVydChcIlNlbGVjdCBlbXBsb3llZVwiKTtcclxuICAgIGlmICghZnJvbURhdGUgfHwgIXRvRGF0ZSkgcmV0dXJuIGFsZXJ0KFwiUGxlYXNlIHNlbGVjdCBGcm9tIERhdGUgYW5kIFRvIERhdGVcIik7XHJcblxyXG4gICAgLy8gT3B0aW9uYWw6IFZhbGlkYXRlIGRhdGUgbG9naWMgKGZyb20gPD0gdG8pXHJcbiAgICBpZiAobmV3IERhdGUoZnJvbURhdGUpID4gbmV3IERhdGUodG9EYXRlKSkge1xyXG4gICAgICByZXR1cm4gYWxlcnQoXCJGcm9tIERhdGUgY2Fubm90IGJlIGFmdGVyIFRvIERhdGVcIik7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYXBpLnBvc3QoXCIvcmV3YXJkLXBvaW50cy9lbXBsb3llZS1yZXdhcmQtcG9pbnRzXCIsIHtcclxuICAgICAgICBlbXBsb3llZV9pZDogZW1wbG95ZWVJZCxcclxuICAgICAgICBmcm9tX2RhdGU6IGZyb21EYXRlLCAgIC8vIOKchVxyXG4gICAgICAgIHRvX2RhdGU6IHRvRGF0ZSwgICAgICAgLy8g4pyFXHJcbiAgICAgICAgcmVtYXJrczogXCJcIixcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBhd2FpdCBmZXRjaFJld2FyZFN1bW1hcnkoZW1wbG95ZWVJZCk7XHJcbiAgICAgIGF3YWl0IGZldGNoUmV3YXJkUG9pbnRzKGVtcGxveWVlSWQpO1xyXG5cclxuICAgICAgLy8gT3B0aW9uYWw6IENsZWFyIGRhdGVzIGFmdGVyIHN1Y2Nlc3NcclxuICAgICAgLy8gc2V0RnJvbURhdGUoXCJcIik7XHJcbiAgICAgIC8vIHNldFRvRGF0ZShcIlwiKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBhbGVydChlcnIucmVzcG9uc2U/LmRhdGE/LmVycm9yIHx8IFwiRmFpbGVkIHRvIGNyZWF0ZSByZXdhcmQgcG9pbnRzXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvKiA9PT09PT09PT09PT09PT09PSBBVVRPIENBTENVTEFURSBBTU9VTlQgPT09PT09PT09PT09PT09PT0gKi9cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHJlZGVlbVR5cGUgPT09IFwiQ2FzaFwiKSB7XHJcbiAgICAgIHNldFJlZGVlbUFtb3VudChcclxuICAgICAgICBOdW1iZXIocmVkZWVtUG9pbnRzIHx8IDApICogc3VtbWFyeS5yZXdhcmRfcG9pbnRfdmFsdWVcclxuICAgICAgKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldFJlZGVlbUFtb3VudCgwKTtcclxuICAgIH1cclxuICB9LCBbcmVkZWVtUG9pbnRzLCByZWRlZW1UeXBlLCBzdW1tYXJ5LnJld2FyZF9wb2ludF92YWx1ZV0pO1xyXG5cclxuICAvKiA9PT09PT09PT09PT09PT09PSBSRURFRU0gUE9JTlRTID09PT09PT09PT09PT09PT09ICovXHJcbiAgY29uc3QgcmVkZWVtUmV3YXJkUG9pbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFlbXBsb3llZUlkKSByZXR1cm4gYWxlcnQoXCJTZWxlY3QgZW1wbG95ZWVcIik7XHJcbiAgICBpZiAoIXJlZGVlbVBvaW50cykgcmV0dXJuIGFsZXJ0KFwiRW50ZXIgcmV3YXJkIHBvaW50c1wiKTtcclxuXHJcbiAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBhcGkucG9zdChcIi9yZXdhcmQtcG9pbnRzL2VtcGxveWVlLXJld2FyZC1wb2ludHMvcmVkZWVtXCIsIHtcclxuICAgICAgICBlbXBsb3llZV9pZDogZW1wbG95ZWVJZCxcclxuICAgICAgICBwb2ludHNfdG9fcmVkZWVtOiBOdW1iZXIocmVkZWVtUG9pbnRzKSxcclxuICAgICAgICByZWRlbXB0aW9uX3R5cGU6IHJlZGVlbVR5cGUsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IHJlZGVlbURlc2MsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc2V0UmVkZWVtUG9pbnRzKFwiXCIpO1xyXG4gICAgICBzZXRSZWRlZW1EZXNjKFwiXCIpO1xyXG5cclxuICAgICAgYXdhaXQgZmV0Y2hSZXdhcmRTdW1tYXJ5KGVtcGxveWVlSWQpO1xyXG4gICAgICBhd2FpdCBmZXRjaFJld2FyZFBvaW50cyhlbXBsb3llZUlkKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBhbGVydChlcnIucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJSZWRlZW0gZmFpbGVkXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCByZXdhcmRDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwic2xOb1wiLCBoZWFkZXI6IFwiU2wgTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlck5hbWVcIiwgaGVhZGVyOiBcIk5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlclBob25lXCIsIGhlYWRlcjogXCJQaG9uZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cE5hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIC8gTG9hbiAvIFBpZ215IFwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cFZhbHVlXCIsIGhlYWRlcjogXCJHcm91cCBWYWx1ZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwiIH0sXHJcbiAgICB7IGtleTogXCJzb3VyY2VUeXBlXCIsIGhlYWRlcjogXCJUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcInJld2FyZFBvaW50c1wiLCBoZWFkZXI6IFwiUG9pbnRzXCIgfSxcclxuICAgIHsga2V5OiBcInJld2FyZEFtb3VudFwiLCBoZWFkZXI6IFwiQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcInN0YXR1c1wiLCBoZWFkZXI6IFwiU3RhdHVzXCIgfSxcclxuICAgIHsga2V5OiBcInJlbWFya3NcIiwgaGVhZGVyOiBcIlJlbWFya3NcIiB9LFxyXG4gIF07XHJcblxyXG4gIC8vIEZpbHRlciByZXdhcmRzIGJhc2VkIG9uIHNlbGVjdGVkIGVtcGxveWVlXHJcbiAgY29uc3QgZmlsdGVyZWRSZXdhcmRzID1cclxuICAgIHNlbGVjdGVkRW1wbG95ZWUgPT09IFwiYWxsXCJcclxuICAgICAgPyByZXdhcmRzXHJcbiAgICAgIDogcmV3YXJkcy5maWx0ZXIoXHJcbiAgICAgICAgKHIpID0+IHIuZW1wbG95ZWVfbmFtZSA9PT0gc2VsZWN0ZWRFbXBsb3llZVxyXG4gICAgICApO1xyXG4gIGNvbnN0IGhhbmRsZVNlbGVjdEZpbHRlciA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRMYWJlbCh2YWx1ZSk7XHJcbiAgICAvL2NvbnN0IHsgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0U2hvd0ZpbHRlckZpZWxkKGZhbHNlKTtcclxuXHJcbiAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgICBjb25zdCBmb3JtYXREYXRlID0gKGRhdGUpID0+IGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tQ0FcIik7XHJcblxyXG4gICAgaWYgKHZhbHVlID09PSBcIlRvZGF5XCIpIHtcclxuICAgICAgY29uc3QgZm9ybWF0dGVkID0gZm9ybWF0RGF0ZSh0b2RheSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0dGVkKTtcclxuICAgICAgc2V0U2VsZWN0ZWRUb0RhdGUoZm9ybWF0dGVkKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiWWVzdGVyZGF5XCIpIHtcclxuICAgICAgY29uc3QgeWVzdGVyZGF5ID0gbmV3IERhdGUodG9kYXkpO1xyXG4gICAgICB5ZXN0ZXJkYXkuc2V0RGF0ZSh5ZXN0ZXJkYXkuZ2V0RGF0ZSgpIC0gMSk7XHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGZvcm1hdERhdGUoeWVzdGVyZGF5KTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXR0ZWQpO1xyXG4gICAgICBzZXRTZWxlY3RlZFRvRGF0ZShmb3JtYXR0ZWQpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzTW9udGhcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpICsgMSwgMCk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4gICAgICBzZXRTZWxlY3RlZFRvRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJMYXN0TW9udGhcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgLSAxLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMCk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4gICAgICBzZXRTZWxlY3RlZFRvRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJUaGlzWWVhclwiKSB7XHJcbiAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMCwgMSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDExLCAzMSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZm9ybWF0RGF0ZShzdGFydCkpO1xyXG4gICAgICBzZXRTZWxlY3RlZFRvRGF0ZShmb3JtYXREYXRlKGVuZCkpO1xyXG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJDdXN0b21cIikge1xyXG4gICAgICBzZXRTaG93RmlsdGVyRmllbGQodHJ1ZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxOYXZiYXIgdmlzaWJpbGl0eSAvPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgICA8U2lkZWJhciAvPlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIG1iLTRcIj5cclxuICAgICAgICAgICAgRW1wbG95ZWUgUmV3YXJkIFBvaW50c1xyXG4gICAgICAgICAgPC9oMT5cclxuXHJcbiAgICAgICAgICB7LyogPT09PT09PT09PT09PT09PT0gU0VMRUNUIEVNUExPWUVFICsgREFURSBGSUxURVJTID09PT09PT09PT09PT09PT09ICovfVxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCB4bDpncmlkLWNvbHMtNSBnYXAtOCBtYi0yXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctbWQgcC02XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+VG90YWwgRW1wbG95ZWVzPC9oMz5cclxuICAgICAgICAgICAgICAgIDxVc2VycyBjbGFzc05hbWU9XCJoLTggdy04IHRleHQtYmx1ZS01MDBcIiAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+e3Jld2FyZFN0YXRlPy50b3RhbEVtcGx5ZWVzfTwvcD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgbXQtMlwiPkFjcm9zcyBhbGwgZGVwYXJ0bWVudDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctbWQgcC02XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+VG90YWwgQW1vdW50IC8gUmV3YXJkczwvaDM+XHJcbiAgICAgICAgICAgICAgICA8QXdhcmQgY2xhc3NOYW1lPVwiaC04IHctOCB0ZXh0LWJsdWUtNTAwXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPntyZXdhcmRTdGF0ZT8udG90YWxBbW91bnRBbGx9PC9wPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBtdC0yXCI+QWNyb3NzIGFsbCBlbXBsb3llZXM8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1tZCBwLTZcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5Ub3RhbCBQb2ludHM8L2gzPlxyXG4gICAgICAgICAgICAgICAgPFN0YXIgY2xhc3NOYW1lPVwiaC04IHctOCB0ZXh0LXllbGxvdy01MDBcIiAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+e3Jld2FyZFN0YXRlPy50b3RhbFBvaW50c0FsbH08L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIG10LTJcIj5Qb2ludHMgYXdhcmRlZCBpbiB0b3RhbDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LW1kIHAtNlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlRvcCBQZXJmb3JtZXI8L2gzPlxyXG4gICAgICAgICAgICAgICAgPFRyb3BoeSBjbGFzc05hbWU9XCJoLTggdy04IHRleHQtZ3JlZW4tNTAwXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICB7cmV3YXJkU3RhdGU/LmFjdGl2ZVJld2FyZHMubGVuZ3RoID4gMCA/IHJld2FyZFN0YXRlLmFjdGl2ZVJld2FyZHNbMF0/LmVtcGxveWVlX25hbWUgOiAnTi9BJ31cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIG10LTJcIj5cclxuICAgICAgICAgICAgICAgIHtyZXdhcmRTdGF0ZT8uYWN0aXZlUmV3YXJkcy5sZW5ndGggPiAwID8gYCR7cmV3YXJkU3RhdGUuYWN0aXZlUmV3YXJkc1swXS50b3RhbF9wb2ludHN9IHBvaW50c2AgOiAnTm8gZGF0YSBhdmFpbGFibGUnfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogUmV3YXJkcyBUYWJsZSAqL31cclxuICAgICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctbWQgcC0xMiB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWJsb2NrIGFuaW1hdGUtc3BpbiByb3VuZGVkLWZ1bGwgaC0xMiB3LTEyIGJvcmRlci10LTIgYm9yZGVyLWItMiBib3JkZXItYmx1ZS01MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC00IHRleHQtZ3JheS01MDBcIj5Mb2FkaW5nIHJld2FyZCBkYXRhLi4uPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICkgOiByZXdhcmRTdGF0ZT8ucmV3YXJkcz8ubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG1iLTNcIj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogQmFja2dyb3VuZCBHbG93ICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1pbmRpZ28tMTAwIHZpYS1ibHVlLTEwMCB0by1wdXJwbGUtMTAwIHJvdW5kZWQtM3hsIGJsdXIteGwgb3BhY2l0eS00MFwiPjwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgYmctd2hpdGUvODAgYmFja2Ryb3AtYmx1ci14bCBcclxuICAgICAgICAgICAgICAgICAgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBcclxuICAgICAgICAgICAgICAgICAgcm91bmRlZC0zeGwgc2hhZG93LWxnIFxyXG4gICAgICAgICAgICAgICAgICBwLTZcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtNCBnYXAtNiBpdGVtcy1lbmRcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIEZpbHRlciBTZWxlY3QgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBGaWx0ZXIgT3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlU2VsZWN0RmlsdGVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRMYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggb3IgU2VsZWN0IEZpbHRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBjdXN0b20tc2VsZWN0XCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwT3B0aW9ucy5tYXAoKHRpbWUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3RpbWUudmFsdWV9IHZhbHVlPXt0aW1lLnZhbHVlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0aW1lLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIEZyb20gRGF0ZSAqL31cclxuICAgICAgICAgICAgICAgICAgICB7c2hvd0ZpbHRlckZpZWxkICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBGcm9tIERhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRnJvbURhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlbGVjdGVkRnJvbURhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTAgYmctd2hpdGUgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXIgYm9yZGVyLWdyYXktMzAwIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgcm91bmRlZC14bCBweC00IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgc2hhZG93LXNtIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgaG92ZXI6Ym9yZGVyLWluZGlnby00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIFRvIERhdGUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBUbyBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFRvRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWRUb0RhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTIgYmctd2hpdGUgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXIgYm9yZGVyLWdyYXktMzAwIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgcm91bmRlZC14bCBweC00IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgc2hhZG93LXNtIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgaG92ZXI6Ym9yZGVyLWluZGlnby00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1tZCBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS0yIGJnLWdyYXktNTAgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPkVtcGxveWVlIFJld2FyZHMgU3VtbWFyeTwvaDI+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PSBUQUJMRSA9PT09PT09PT09PT09PT09PSAqL31cclxuICAgICAgICAgICAgICB7Lyoge3Jld2FyZFRhYmxlLmxlbmd0aCA+IDAgJiYgIWlzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgIDxEYXRhVGFibGUgY29sdW1ucz17cmV3YXJkQ29sdW1uc30gZGF0YT17cmV3YXJkVGFibGV9IGV4cG9ydGVkRmlsZU5hbWU9XCJFbXBsb3llZSBSZXdhcmQgUG9pbnRzLmNzdlwiIGV4cG9ydGVkUGRmTmFtZT1cIkVtcGxveWVlIFJld2FyZCBQb2ludHNcIiAvPlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgIGRhdGE9XCJFbXBsb3llZSBSZXdhcmRcIlxyXG4gICAgICAgICAgICAgICAgICBmYWlsdXJlPXshaXNMb2FkaW5nICYmIHJld2FyZFRhYmxlLmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKX0gKi99XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0byBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC02IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5TbCBubzwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPkVtcGxveWVlPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNiBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+RGVwYXJ0bWVudDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlBvaW50czwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlJld2FyZHMgLyBBbW1vdW50PC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNiBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+VHJlbmQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3Jld2FyZFN0YXRlLmFjdGl2ZVJld2FyZHM/LnNsaWNlKDAsIDUpPy5tYXAoKGVtcGxveWVlLCBrZXkpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtlbXBsb3llZS5pZH0gY2xhc3NOYW1lPVwiaG92ZXI6YmctZ3JheS01MCBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMCBoLTYgdy02IHJvdW5kZWQtZnVsbCBiZy1ibHVlLTEwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMCBmb250LW1lZGl1bVwiPntrZXkgKyAxfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj57ZW1wbG95ZWUuZW1wbG95ZWVfbmFtZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj57ZW1wbG95ZWUuZGVwYXJ0bWVudCB8fCBcIlNhbGVzXCJ9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPntlbXBsb3llZS50b3RhbF9wb2ludHN9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgdGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+cHRzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwIHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPntlbXBsb3llZS50b3RhbF9hbW91bnR9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlLnRvdGFsX3BvaW50cyA+IDIwMDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHRleHQtc20gdGV4dC1ncmVlbi02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUcmVuZGluZ1VwIGNsYXNzTmFtZT1cImgtNCB3LTQgbXItMVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBVcFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlLnRvdGFsX3BvaW50cyA8IDIwMDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VHJlbmRpbmdVcCBjbGFzc05hbWU9XCJoLTQgdy00IG1yLTEgcm90YXRlLTE4MFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEb3duXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZW1wbG95ZWUudHJlbmQgPT09ICdzYW1lJyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtNCB3LTQgbXItMSBiZy1ncmF5LTQwMCByb3VuZGVkLWZ1bGxcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNhbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtNCBtYi02IGl0ZW1zLWVuZCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQteGwgc2hhZG93LXNtIHAtNiBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbiBkdXJhdGlvbi0zMDBcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBFbXBsb3llZSAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+RW1wbG95ZWU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBweC00IHB5LTIgcm91bmRlZCB3LTY0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbXBsb3llZUlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGVtcElkID0gZS50YXJnZXQudmFsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEVtcGxveWVlSWQoZW1wSWQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRSZXdhcmRUYWJsZShbXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChlbXBJZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZldGNoUmV3YXJkU3VtbWFyeShlbXBJZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZmV0Y2hSZXdhcmRQb2ludHMoZW1wSWQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgRW1wbG95ZWU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlbXBsb3llZXMubWFwKChlbXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2VtcC5faWR9IHZhbHVlPXtlbXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZW1wLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIEZyb20gRGF0ZSAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+RnJvbSBEYXRlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBweC00IHB5LTIgcm91bmRlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZnJvbURhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZyb21EYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBUbyBEYXRlICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5UbyBEYXRlPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBweC00IHB5LTIgcm91bmRlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dG9EYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUb0RhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIENyZWF0ZSBCdXR0b24gKi99XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtjcmVhdGVSZXdhcmRQb2ludHN9XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC02IHB5LTIgcm91bmRlZCAke2lzTG9hZGluZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWdyYXktNDAwIGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBob3ZlcjpiZy1ibHVlLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyBcIlByb2Nlc3NpbmcuLi5cIiA6IFwiQ3JlYXRlIFJld2FyZCBQb2ludHNcIn1cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PSBTVU1NQVJZIENBUkRTID09PT09PT09PT09PT09PT09ICovfVxyXG4gICAgICAgICAgICAgICAge2VtcGxveWVlSWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTUgZ2FwLTQgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTdW1tYXJ5Q2FyZCBsYWJlbD1cIkVhcm5lZCBQb2ludHNcIiB2YWx1ZT17c3VtbWFyeS50b3RhbF9lYXJuZWRfcmV3YXJkfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTdW1tYXJ5Q2FyZCBsYWJlbD1cIlJlZGVlbWVkIFBvaW50c1wiIHZhbHVlPXtzdW1tYXJ5LnRvdGFsX3JlZGVlbWVkX3BvaW50c30gLz5cclxuICAgICAgICAgICAgICAgICAgICA8U3VtbWFyeUNhcmQgbGFiZWw9XCJFYXJuZWQgQW1vdW50XCIgdmFsdWU9e2DigrkgJHtzdW1tYXJ5LnRvdGFsX2Vhcm5lZF9hbW91bnR9YH0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8U3VtbWFyeUNhcmQgbGFiZWw9XCJSZWRlZW1lZCBBbW91bnRcIiB2YWx1ZT17YOKCuSAke3N1bW1hcnkudG90YWxfcmVkZWVtZWRfYW1vdW50fWB9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIDxTdW1tYXJ5Q2FyZCBsYWJlbD1cIk9uZSBDaGl0IFJld2FyZCBQb2ludCBWYWx1ZVwiIHZhbHVlPXtg4oK5ICR7c3VtbWFyeS5yZXdhcmRfcG9pbnRfdmFsdWV9YH0gLz4gKi99XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogPT09PT09PT09PT09PT09PT0gUkVERUVNIFNFQ1RJT04gPT09PT09PT09PT09PT09PT0gKi99XHJcbiAgICAgICAgICAgICAgICB7ZW1wbG95ZWVJZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIHAtNiBtYi02IGJnLXdoaXRlIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtbGcgdGV4dC1ncmF5LTgwMCBtYi02IGZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8R2lmdCBjbGFzc05hbWU9XCJtci0yIGgtNSB3LTUgdGV4dC1ncmVlbi02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUmVkZWVtIFJld2FyZCBQb2ludHNcclxuICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTQgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXRvcC0yIGxlZnQtMyBiZy13aGl0ZSBweC0xIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFJld2FyZCBQb2ludHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBwb2ludHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcHgtNCBweS0zIHJvdW5kZWQtbGcgdy1mdWxsIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ncmVlbi01MDAgZm9jdXM6Ym9yZGVyLXRyYW5zcGFyZW50IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBob3Zlcjpib3JkZXItZ3JheS00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtyZWRlZW1Qb2ludHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRSZWRlZW1Qb2ludHMoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXRvcC0yIGxlZnQtMyBiZy13aGl0ZSBweC0xIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFJlZGVlbSBUeXBlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHB4LTQgcHktMyByb3VuZGVkLWxnIHctZnVsbCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZ3JlZW4tNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgaG92ZXI6Ym9yZGVyLWdyYXktNDAwIGFwcGVhcmFuY2Utbm9uZSBiZy13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3JlZGVlbVR5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRSZWRlZW1UeXBlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZEltYWdlOiBgdXJsKFwiZGF0YTppbWFnZS9zdmcreG1sLCUzY3N2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIGZpbGw9J25vbmUnIHZpZXdCb3g9JzAgMCAyMCAyMCclM2UlM2NwYXRoIHN0cm9rZT0nJTIzNmI3MjgwJyBzdHJva2UtbGluZWNhcD0ncm91bmQnIHN0cm9rZS1saW5lam9pbj0ncm91bmQnIHN0cm9rZS13aWR0aD0nMS41JyBkPSdNNiA4bDQgNCA0LTQnLyUzZSUzYy9zdmclM2VcIilgLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZFBvc2l0aW9uOiAncmlnaHQgMC41cmVtIGNlbnRlcicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kUmVwZWF0OiAnbm8tcmVwZWF0JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRTaXplOiAnMS41ZW0gMS41ZW0nLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFkZGluZ1JpZ2h0OiAnMi41cmVtJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQ2FzaFwiPkNhc2g8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiR2lmdFwiPkdpZnQ8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiT3RoZXJcIj5PdGhlcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHtyZWRlZW1UeXBlID09PSBcIkNhc2hcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXRvcC0yIGxlZnQtMyBiZy13aGl0ZSBweC0xIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQW1vdW50ICjigrkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMjAwIHB4LTQgcHktMyByb3VuZGVkLWxnIHctZnVsbCBiZy1ncmF5LTUwIHRleHQtZ3JheS03MDAgZm9udC1tZWRpdW0gY3Vyc29yLW5vdC1hbGxvd2VkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtg4oK5ICR7cmVkZWVtQW1vdW50fWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgbGc6Y29sLXNwYW4tMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXRvcC0yIGxlZnQtMyBiZy13aGl0ZSBweC0xIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIERlc2NyaXB0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIGRlc2NyaXB0aW9uIGZvciByZWRlbXB0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHB4LTQgcHktMyByb3VuZGVkLWxnIHctZnVsbCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctZ3JlZW4tNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgaG92ZXI6Ym9yZGVyLWdyYXktNDAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cmVkZWVtRGVzY31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFJlZGVlbURlc2MoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtyZWRlZW1SZXdhcmRQb2ludHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1ncmVlbi02MDAgdG8tZ3JlZW4tNzAwIGhvdmVyOmZyb20tZ3JlZW4tNzAwIGhvdmVyOnRvLWdyZWVuLTgwMCB0ZXh0LXdoaXRlIHB4LTggcHktMyByb3VuZGVkLWxnIGZvbnQtbWVkaXVtIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgdHJhbnNmb3JtIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBob3ZlcjpzY2FsZS0xMDUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWdyZWVuLTUwMCBmb2N1czpyaW5nLW9mZnNldC0yIGZsZXggaXRlbXMtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEdpZnQgY2xhc3NOYW1lPVwibXItMiBoLTQgdy00XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUmVkZWVtIFBvaW50c1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogPT09PT09PT09PT09PT09PT0gVEFCTEUgPT09PT09PT09PT09PT09PT0gKi99XHJcbiAgICAgICAgICAgICAgICB7cmV3YXJkVGFibGUubGVuZ3RoID4gMCAmJiAhaXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlIGNvbHVtbnM9e3Jld2FyZENvbHVtbnN9IGRhdGE9e3Jld2FyZFRhYmxlfSAvPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YT1cIkVtcGxveWVlIFJld2FyZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmFpbHVyZT17IWlzTG9hZGluZyAmJiByZXdhcmRUYWJsZS5sZW5ndGggPT09IDB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8PjwvPlxyXG4gICAgICAgICAgKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbmNvbnN0IFN1bW1hcnlDYXJkID0gKHsgbGFiZWwsIHZhbHVlIH0pID0+IChcclxuICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciByb3VuZGVkIHAtNCBiZy13aGl0ZSBzaGFkb3ctc21cIj5cclxuICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1zbVwiPntsYWJlbH08L3A+XHJcbiAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgbXQtMVwiPnt2YWx1ZX08L3A+XHJcbiAgPC9kaXY+XHJcbik7XHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgRW1wbG95ZWVSZXdhcmRQb2ludHNcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0VtcGxveWVlUmV3YXJkUG9pbnRzLmpzeCJ9