import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CommissionReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
const CommissionReport = () => {
  _s();
  const [employees, setEmployees] = useState([]);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState(null);
  const [tempFromDate, setTempFromDate] = useState();
  const [tempToDate, setTempToDate] = useState();
  const [selectedEmployeeDetails, setSelectedEmployeeDetails] = useState(null);
  const [employeeCustomerData, setEmployeeCustomerData] = useState([]);
  const [commissionTotalDetails, setCommissionTotalDetails] = useState({});
  const [loading, setLoading] = useState(false);
  const formatDate = (date) => date.toISOString().split("T")[0];
  const today = formatDate(/* @__PURE__ */ new Date());
  const [fromDate, setFromDate] = useState();
  const [toDate, setToDate] = useState();
  const [showCommissionModal, setShowCommissionModal] = useState(false);
  const [commissionForm, setCommissionForm] = useState({
    agent_id: "",
    pay_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
    amount: "",
    pay_type: "cash",
    transaction_id: "",
    note: "",
    pay_for: "commission",
    admin_type: ""
  });
  const [errors, setErrors] = useState({});
  const [adminId, setAdminId] = useState("");
  const [adminName, setAdminName] = useState("");
  const [targetData, setTargetData] = useState({
    target: 0,
    achieved: 0,
    remaining: 0,
    startDate: "",
    endDate: ""
  });
  const fetchEmployees = async () => {
    try {
      const res = await api.get("/agent/get-agent");
      setEmployees(res.data);
    } catch (err) {
      console.error("Error fetching employees:", err);
    }
  };
  const fetchCommissionReport = async (employeeId) => {
    if (!employeeId) return;
    setLoading(true);
    try {
      const res = await api.get(
        "/enroll/get-detailed-commission-per-month",
        {
          params: { agent_id: employeeId, from_date: fromDate, to_date: toDate }
        }
      );
      setEmployeeCustomerData(res.data?.commission_data);
      setCommissionTotalDetails(res.data?.summary);
    } catch (err) {
      console.error("Error fetching employee report:", err);
      setEmployeeCustomerData([]);
      setCommissionTotalDetails({});
    } finally {
      setLoading(false);
    }
  };
  const fetchTargetData = async (employeeId) => {
    try {
      const targetRes = await api.get("/target/get-targets", {
        params: { fromDate, toDate, agentId: employeeId }
      });
      const rawTargets = targetRes.data || [];
      const monthMap = {};
      rawTargets.forEach((t) => {
        if ((t.agentId?._id || t.agentId) !== employeeId) return;
        const date2 = new Date(t.startDate);
        const key = `${date2.getFullYear()}-${date2.getMonth()}`;
        if (!monthMap[key]) monthMap[key] = t.totalTarget || 0;
      });
      const defaultTarget = Object.values(monthMap)[0] || 0;
      let totalTarget = 0;
      const start = new Date(fromDate);
      const end = new Date(toDate);
      let date = new Date(start);
      while (date <= end) {
        const year = date.getFullYear();
        const month = date.getMonth();
        const key = `${year}-${month}`;
        const monthTarget = monthMap[key] ?? defaultTarget;
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const perDayTarget = monthTarget / daysInMonth;
        totalTarget += perDayTarget;
        date.setDate(date.getDate() + 1);
      }
      const { data: comm } = await api.get(
        "/enroll/get-detailed-commission-per-month",
        { params: { agent_id: employeeId, from_date: fromDate, to_date: toDate } }
      );
      let achieved = comm?.summary?.actual_business || 0;
      if (typeof achieved === "string") {
        achieved = Number(achieved.replace(/[^0-9.-]+/g, ""));
      }
      const remaining = Math.max(totalTarget - achieved, 0);
      const difference = totalTarget - achieved;
      const designation = rawTargets.find(
        (t) => (t.agentId?._id || t.agentId) === employeeId
      )?.agentId?.designation_id?.title || "N/A";
      const title = designation.toLowerCase();
      let incentiveAmount = 0;
      let incentivePercent = "0%";
      if (title === "business agent" && achieved <= totalTarget) {
        incentiveAmount = difference * 5e-3;
        incentivePercent = "0.5%";
      } else if (difference < 0) {
        incentiveAmount = Math.abs(difference) * 0.01;
        incentivePercent = "1%";
      }
      const startDate = rawTargets.reduce(
        (min, t) => t.startDate < min ? t.startDate : min,
        rawTargets[0]?.startDate || ""
      );
      const endDate = rawTargets.reduce(
        (max, t) => t.endDate > max ? t.endDate : max,
        rawTargets[0]?.endDate || ""
      );
      setTargetData({
        target: Math.round(totalTarget),
        achieved,
        remaining: Math.max(totalTarget - achieved, 0),
        difference,
        startDate: startDate?.split("T")[0] || "",
        endDate: endDate?.split("T")[0] || "",
        designation,
        incentiveAmount: `₹${incentiveAmount.toFixed(2)}`,
        incentivePercent
      });
    } catch (err) {
      console.error("Error fetching target data:", err);
      setTargetData({
        target: 0,
        achieved: 0,
        remaining: 0,
        difference: 0,
        startDate: "",
        endDate: "",
        designation: "-",
        incentiveAmount: "₹0.00",
        incentivePercent: "0%"
      });
    }
  };
  const fetchAllCommissionReport = async () => {
    setLoading(true);
    try {
      const res = await api.get("enroll/get-detailed-commission-all", {
        params: { from_date: fromDate, to_date: toDate }
      });
      setEmployeeCustomerData(res.data?.commission_data);
      setCommissionTotalDetails(res.data?.summary);
    } catch (err) {
      console.error("Error fetching all commission report:", err);
      setEmployeeCustomerData([]);
      setCommissionTotalDetails({});
    } finally {
      setLoading(false);
    }
  };
  const handleEmployeeChange = async (value) => {
    setSelectedEmployeeId(value);
    if (value === "ALL") {
      setSelectedEmployeeDetails(null);
      setTargetData({
        target: 0,
        achieved: 0,
        remaining: 0,
        startDate: "",
        endDate: "",
        designation: "",
        incentiveAmount: "₹0.00",
        incentivePercent: "0%"
      });
      fetchAllCommissionReport();
    } else {
      const selectedEmp = employees.find((emp) => emp._id === value);
      setSelectedEmployeeDetails(selectedEmp || null);
      await fetchCommissionReport(value);
    }
  };
  useEffect(() => {
    fetchEmployees();
  }, []);
  useEffect(() => {
    const todayDate = formatDate(/* @__PURE__ */ new Date());
    setTempFromDate();
    setTempToDate();
    setFromDate();
    setToDate();
  }, []);
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"));
    if (user) {
      setAdminId(user._id);
      setAdminName(user.name || "");
    }
  }, []);
  const handleCommissionChange = (e) => {
    const { name, value } = e.target;
    setCommissionForm((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };
  const validateForm = () => {
    const newErrors = {};
    if (!commissionForm.agent_id) newErrors.agent_id = "Please select an agent";
    if (!commissionForm.amount || isNaN(commissionForm.amount)) newErrors.amount = "Please enter a valid amount";
    if (commissionForm.pay_type === "online" && !commissionForm.transaction_id) newErrors.transaction_id = "Transaction ID is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleCommissionSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    try {
      const payload = { ...commissionForm, admin_type: adminId };
      await api.post("/payment-out/add-commission-payment", payload);
      alert("Commission Paid Successfully!");
      setShowCommissionModal(false);
    } catch (err) {
      alert("Failed to add payment.");
    }
  };
  const handlePayNow = () => {
    const actual = employeeCustomerData.reduce((sum, item) => {
      const payDate = new Date(item.start_date);
      const f = new Date(fromDate);
      const t = new Date(toDate);
      if (payDate >= f && payDate <= t) {
        const actual2 = parseFloat(
          (commissionTotalDetails?.total_actual || "0").toString().replace(/[^0-9.-]+/g, "")
        );
        return sum + val;
      }
      return sum;
    }, 0);
    const incentive = parseFloat(
      (targetData?.incentiveAmount || "0").replace(/[^0-9.-]+/g, "")
    );
    const total = actual + incentive;
    setCommissionForm({
      agent_id: selectedEmployeeId,
      pay_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
      amount: total.toFixed(2),
      pay_type: "cash",
      transaction_id: "",
      note: "",
      // ✅ Reset note here
      pay_for: "commission",
      admin_type: adminId
    });
    setErrors({});
    setShowCommissionModal(true);
  };
  useEffect(() => {
    if (selectedEmployeeId === "ALL") {
      fetchAllCommissionReport();
    } else if (selectedEmployeeId) {
      fetchCommissionReport(selectedEmployeeId);
    }
  }, [fromDate, toDate]);
  useEffect(() => {
    if (selectedEmployeeId && selectedEmployeeId !== "ALL") {
      fetchTargetData(selectedEmployeeId);
    }
  }, [employeeCustomerData, fromDate, toDate]);
  useEffect(() => {
    fetchEmployees();
  }, []);
  useEffect(() => {
    if (selectedEmployeeId === "ALL") {
      fetchAllCommissionReport();
    } else if (selectedEmployeeId) {
      fetchCommissionReport(selectedEmployeeId);
    }
  }, [fromDate, toDate]);
  const processedTableData = employeeCustomerData.map((item, index) => ({
    ...item
  }));
  const columns = [
    ...selectedEmployeeId === "ALL" ? [{ key: "agent_name", header: "Agent Name" }] : [],
    { key: "user_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "group_name", header: "Group Name" },
    { key: "group_value_digits", header: "Group Value" },
    { key: "commission_rate", header: "Commission Rate" },
    { key: "start_date", header: "Start Date" },
    { key: "estimated_commission_digits", header: "Estimated Commission" },
    { key: "actual_commission_digits", header: "Actual Commission" },
    { key: "total_paid_digits", header: "Total Paid" },
    { key: "required_installment_digits", header: "Required Installment" },
    { key: "commission_released", header: "Commission Released" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "w-screen min-h-screen", children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-30", children: [
    /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
      lineNumber: 371,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-center ", children: "Reports - Commission" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
        lineNumber: 373,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center w-full gap-4 bg-violet-50 p-2 w-30 h-40 rounded-3xl border   space-x-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-lg text-gray-500 text-center font-semibold mb-2", children: "Employee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 381,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              value: selectedEmployeeId || void 0,
              onChange: handleEmployeeChange,
              showSearch: true,
              popupMatchSelectWidth: false,
              placeholder: "Search or Select Employee",
              filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
              style: { height: "50px", width: "600px" },
              children: [
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "ALL", children: "All" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                  lineNumber: 398,
                  columnNumber: 21
                }, this),
                employees.map(
                  (emp) => /* @__PURE__ */ jsxDEV(Select.Option, { value: emp._id, children: [
                    emp.name,
                    " - ",
                    emp.phone_number
                  ] }, emp._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                    lineNumber: 400,
                    columnNumber: 21
                  }, this)
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 384,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
          lineNumber: 380,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            value: tempFromDate || "",
            max: today,
            onChange: (e) => {
              const newFrom = e.target.value;
              if (tempToDate && tempToDate < newFrom) setTempToDate(newFrom);
              setTempFromDate(newFrom);
            },
            className: "border border-gray-300 rounded px-4 mt-7 py-2 w-[200px]"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 407,
            columnNumber: 17
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            value: tempToDate || "",
            min: tempFromDate || "",
            max: today,
            onChange: (e) => setTempToDate(e.target.value),
            className: "border border-gray-300 rounded px-4 mt-7 py-2 w-[200px]"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 419,
            columnNumber: 17
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => {
              setFromDate(tempFromDate);
              setToDate(tempToDate);
            },
            disabled: !tempFromDate || !tempToDate,
            className: "bg-violet-600 hover:bg-violet-700 text-white font-semibold px-4 mt-7 py-2 rounded",
            children: "Filter"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 428,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
        lineNumber: 379,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
        lineNumber: 378,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
        lineNumber: 377,
        columnNumber: 11
      }, this),
      (selectedEmployeeId === "ALL" || selectedEmployeeDetails) && /* @__PURE__ */ jsxDEV("div", { className: "mb-8 bg-gray-50 rounded-md shadow-md p-6 space-y-4", children: [
        selectedEmployeeId !== "ALL" && selectedEmployeeDetails && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Name" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 450,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  value: selectedEmployeeDetails.name || "-",
                  readOnly: true,
                  className: "border border-gray-300 rounded px-4 py-2 bg-white"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                  lineNumber: 451,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 449,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Email" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 458,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  value: selectedEmployeeDetails.email || "-",
                  readOnly: true,
                  className: "border border-gray-300 rounded px-4 py-2 bg-white"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                  lineNumber: 459,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 457,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Phone Number" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 466,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  value: selectedEmployeeDetails.phone_number || "-",
                  readOnly: true,
                  className: "border border-gray-300 rounded px-4 py-2 bg-white"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                  lineNumber: 469,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 465,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 448,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Adhaar Number" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 479,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  value: selectedEmployeeDetails.adhaar_no || "-",
                  readOnly: true,
                  className: "border border-gray-300 rounded px-4 py-2 bg-white"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                  lineNumber: 482,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 478,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "PAN Number" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 489,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  value: selectedEmployeeDetails.pan_no || "-",
                  readOnly: true,
                  className: "border border-gray-300 rounded px-4 py-2 bg-white"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                  lineNumber: 492,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 488,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Pincode" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 499,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  value: selectedEmployeeDetails.pincode || "-",
                  readOnly: true,
                  className: "border border-gray-300 rounded px-4 py-2 bg-white"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                  lineNumber: 502,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 498,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 477,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Address" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 511,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: selectedEmployeeDetails.address || "-",
                readOnly: true,
                className: "border border-gray-300 rounded px-4 py-2 bg-white"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 512,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 510,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
          lineNumber: 447,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Actual Business" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 524,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: commissionTotalDetails?.actual_business || "-",
                readOnly: true,
                className: "border border-gray-300 rounded px-4 py-2 bg-white text-green-700 font-bold"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 527,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 523,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Actual Commission" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 535,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: commissionTotalDetails?.total_actual || "-",
                readOnly: true,
                className: "border border-gray-300 rounded px-4 py-2 bg-white  text-green-700 font-bold"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 538,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 534,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Gross Business" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 546,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: commissionTotalDetails?.expected_business || "-",
                readOnly: true,
                className: "border border-gray-300 rounded px-4 py-2 bg-white"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 549,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 545,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
          lineNumber: 522,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Gross Commission" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 560,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: commissionTotalDetails?.total_estimated || "-",
                readOnly: true,
                className: "border border-gray-300 rounded px-4 py-2 bg-white"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 563,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 559,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Total Customers" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 570,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: commissionTotalDetails?.total_customers || "-",
                readOnly: true,
                className: "border border-gray-300 rounded px-4 py-2 bg-white"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 573,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 569,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium mb-1", children: "Total Groups" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 580,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: commissionTotalDetails?.total_groups || "-",
                readOnly: true,
                className: "border border-gray-300 rounded px-4 py-2 bg-white"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 583,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 579,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
          lineNumber: 558,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
        lineNumber: 445,
        columnNumber: 11
      }, this),
      selectedEmployeeId && selectedEmployeeId !== "ALL" && fromDate && toDate && /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-100  p-4 rounded-lg shadow mb-6", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-bold text-yellow-800 mb-2", children: "Target Details" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
          lineNumber: 595,
          columnNumber: 15
        }, this),
        targetData.achieved >= targetData.target && /* @__PURE__ */ jsxDEV("div", { className: "text-green-800 font-semibold mb-3", children: "🎉 Target Achieved" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
          lineNumber: 600,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid md:grid-cols-3 gap-4 bg-gray-50 ", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block font-medium", children: "Target Set" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 607,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: `₹${targetData.target?.toLocaleString("en-IN")}`,
                readOnly: true,
                className: "border px-3 py-2 rounded w-full bg-gray-50 font-semibold"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 608,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 606,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block font-medium", children: "Achieved" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 615,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: `₹${targetData.achieved?.toLocaleString("en-IN")}`,
                readOnly: true,
                className: "border px-3 py-2 rounded w-full bg-gray-50 font-semibold"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 616,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 614,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block font-medium", children: "Remaining" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 623,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: `₹${targetData.remaining?.toLocaleString("en-IN")}`,
                readOnly: true,
                className: "border px-3 py-2 rounded w-full bg-gray-50 font-semibold"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 624,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 622,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
          lineNumber: 605,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid md:grid-cols-2 gap-4 mt-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block font-medium", children: "Incentive (%)" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 637,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: targetData.incentivePercent || "0%",
                readOnly: true,
                className: "border px-3 py-2 rounded w-full bg-gray-50 font-semibold"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 638,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 636,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block font-medium", children: "Incentive Amount" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 646,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                value: targetData.incentiveAmount || "₹0.00",
                readOnly: true,
                className: "border px-3 py-2 rounded w-full bg-gray-50 font-semibold"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 647,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 645,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block font-medium", children: "Total Payable " }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 655,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                readOnly: true,
                value: (() => {
                  const actual = parseFloat(
                    (commissionTotalDetails?.total_actual || "0").toString().replace(/[^0-9.-]+/g, "")
                  );
                  const incentive = parseFloat(
                    (targetData?.incentiveAmount || "0").replace(/[^0-9.-]+/g, "")
                  );
                  const total = incentive;
                  return `₹${total.toLocaleString("en-IN")}`;
                })(),
                className: "border px-3 py-2 rounded w-full bg-gray-50 text-green-700 font-bold"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 656,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 654,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mt-4", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: handlePayNow,
              className: "bg-green-600 text-white px-4 py-2 rounded shadow hover:bg-green-700",
              children: "Pay Now"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 676,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 675,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
          lineNumber: 634,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
        lineNumber: 594,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Modal, { isVisible: showCommissionModal, onClose: () => setShowCommissionModal(false), width: "max-w-md", children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 text-left", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900 border-b pb-2", children: "Add Commission Payment" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
          lineNumber: 690,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("form", { className: "space-y-4", onSubmit: handleCommissionSubmit, children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium", children: "Agent Name" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 693,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                readOnly: true,
                value: employees.find((emp) => emp._id === commissionForm.agent_id)?.name || "",
                className: "w-full border p-2 rounded bg-gray-100 font-semibold"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 694,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 692,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium", children: "Payment Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 705,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                name: "pay_date",
                value: commissionForm.pay_date,
                onChange: handleCommissionChange,
                className: "w-full border p-2 rounded"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 706,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 704,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium", children: "Total Payable Commission" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 715,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                readOnly: true,
                value: `₹${commissionForm.amount || "0.00"}`,
                className: "w-full border p-2 rounded bg-gray-100 text-green-700 font-semibold"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 716,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 714,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium", children: "Payment Mode" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 726,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                name: "pay_type",
                value: commissionForm.pay_type,
                onChange: handleCommissionChange,
                className: "w-full border p-2 rounded",
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "cash", children: "Cash" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                    lineNumber: 733,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "online", children: "Online" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                    lineNumber: 734,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "cheque", children: "Cheque" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                    lineNumber: 735,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "bank_transfer", children: "Bank Transfer" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                    lineNumber: 736,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 727,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 725,
            columnNumber: 17
          }, this),
          commissionForm.pay_type === "online" && /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium", children: "Transaction ID" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 742,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                name: "transaction_id",
                value: commissionForm.transaction_id,
                onChange: handleCommissionChange,
                className: "w-full border p-2 rounded"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 743,
                columnNumber: 21
              },
              this
            ),
            errors.transaction_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm", children: errors.transaction_id }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 750,
              columnNumber: 47
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 741,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium", children: "Note" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 755,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "textarea",
              {
                name: "note",
                value: commissionForm.note,
                onChange: handleCommissionChange,
                className: "w-full border p-2 rounded"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
                lineNumber: 756,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 754,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3 mt-4", children: [
            /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => setShowCommissionModal(false), className: "px-4 py-2 border rounded", children: "Cancel" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 765,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "px-4 py-2 bg-violet-600 text-white rounded", children: "Save Payment" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
              lineNumber: 768,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
            lineNumber: 764,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
          lineNumber: 691,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
        lineNumber: 689,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
        lineNumber: 688,
        columnNumber: 11
      }, this),
      loading ? /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
        lineNumber: 778,
        columnNumber: 11
      }, this) : employeeCustomerData.length > 0 ? /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: processedTableData,
          columns,
          exportedPdfName: `Commission Report`,
          printHeaderKeys: [
            "Name",
            "Phone Number",
            "From Date",
            "To Date",
            "Target Set",
            "Achieved",
            "Remaining",
            "Incentive (%)",
            "Incentive Amount",
            "Total Payable Commission",
            "Actual Business",
            "Actual Commission",
            "Gross Business",
            "Gross Commission",
            "Total Customers",
            "Total Groups"
          ],
          printHeaderValues: [
            selectedEmployeeId === "ALL" ? "All Employees" : selectedEmployeeDetails?.name || "-",
            selectedEmployeeId === "ALL" ? "-" : selectedEmployeeDetails?.phone_number || "-",
            tempFromDate || "-",
            tempToDate || "-",
            `₹${targetData?.target?.toLocaleString("en-IN") || "0"}`,
            `₹${targetData?.achieved?.toLocaleString("en-IN") || "0"}`,
            `₹${targetData?.remaining?.toLocaleString("en-IN") || "0"}`,
            targetData?.incentivePercent || "0%",
            targetData?.incentiveAmount || "₹0.00",
            (() => {
              const actual = parseFloat(
                (commissionTotalDetails?.total_actual || "0").toString().replace(/[^0-9.-]+/g, "")
              );
              const incentive = parseFloat(
                (targetData?.incentiveAmount || "0").toString().replace(/[^0-9.-]+/g, "")
              );
              const total = actual + incentive;
              return `₹${total.toLocaleString("en-IN")}`;
            })(),
            `₹${commissionTotalDetails?.actual_business?.toLocaleString("en-IN") || "0"}`,
            `₹${commissionTotalDetails?.total_actual?.toLocaleString("en-IN") || "0"}`,
            `₹${commissionTotalDetails?.expected_business?.toLocaleString("en-IN") || "0"}`,
            `₹${commissionTotalDetails?.total_estimated?.toLocaleString("en-IN") || "0"}`,
            commissionTotalDetails?.total_customers || "0",
            commissionTotalDetails?.total_groups || "0"
          ],
          exportedFileName: `CommissionReport-${selectedEmployeeDetails?.name || "all"}.csv`
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
          lineNumber: 787,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
        lineNumber: 780,
        columnNumber: 11
      }, this) : selectedEmployeeDetails?.name && /* @__PURE__ */ jsxDEV("p", { className: "text-center font-bold text-lg", children: "No Commission Data found." }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
        lineNumber: 841,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
      lineNumber: 372,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
    lineNumber: 370,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx",
    lineNumber: 369,
    columnNumber: 5
  }, this);
};
_s(CommissionReport, "+sM5mnHINFEjWkGeMT6iyW0nOEc=");
_c = CommissionReport;
export default CommissionReport;
var _c;
$RefreshReg$(_c, "CommissionReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CommissionReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa1hRLFNBNEVRLFVBNUVSOzJCQWxYUjtBQUFnQkEsTUFBV0MsY0FBUSxPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2xELFNBQVNDLGNBQWM7QUFDdkIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLFdBQVc7QUFHbEIsTUFBTUMsbUJBQW1CQSxNQUFNO0FBQUFDLEtBQUE7QUFDN0IsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlWLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNXLG9CQUFvQkMscUJBQXFCLElBQUlaLFNBQVMsSUFBSTtBQUVqRSxRQUFNLENBQUNhLGNBQWNDLGVBQWUsSUFBSWQsU0FBUztBQUNqRCxRQUFNLENBQUNlLFlBQVlDLGFBQWEsSUFBSWhCLFNBQVM7QUFFN0MsUUFBTSxDQUFDaUIseUJBQXlCQywwQkFBMEIsSUFBSWxCLFNBQVMsSUFBSTtBQUMzRSxRQUFNLENBQUNtQixzQkFBc0JDLHVCQUF1QixJQUFJcEIsU0FBUyxFQUFFO0FBQ25FLFFBQU0sQ0FBQ3FCLHdCQUF3QkMseUJBQXlCLElBQUl0QixTQUFTLENBQUMsQ0FBQztBQUN2RSxRQUFNLENBQUN1QixTQUFTQyxVQUFVLElBQUl4QixTQUFTLEtBQUs7QUFDNUMsUUFBTXlCLGFBQWFBLENBQUNDLFNBQVNBLEtBQUtDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUM1RCxRQUFNQyxRQUFRSixXQUFXLG9CQUFJSyxLQUFLLENBQUM7QUFDbkMsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUloQyxTQUFTO0FBQ3pDLFFBQU0sQ0FBQ2lDLFFBQVFDLFNBQVMsSUFBSWxDLFNBQVM7QUFDckMsUUFBTSxDQUFDbUMscUJBQXFCQyxzQkFBc0IsSUFBSXBDLFNBQVMsS0FBSztBQUNwRSxRQUFNLENBQUNxQyxnQkFBZ0JDLGlCQUFpQixJQUFJdEMsU0FBUztBQUFBLElBQ25EdUMsVUFBVTtBQUFBLElBQ1ZDLFdBQVUsb0JBQUlWLEtBQUssR0FBRUgsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsSUFDL0NhLFFBQVE7QUFBQSxJQUNSQyxVQUFVO0FBQUEsSUFDVkMsZ0JBQWdCO0FBQUEsSUFDaEJDLE1BQU07QUFBQSxJQUNOQyxTQUFTO0FBQUEsSUFDVEMsWUFBWTtBQUFBLEVBQ2QsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJaEQsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDaUQsU0FBU0MsVUFBVSxJQUFJbEQsU0FBUyxFQUFFO0FBQ3pDLFFBQU0sQ0FBQ21ELFdBQVdDLFlBQVksSUFBSXBELFNBQVMsRUFBRTtBQUU3QyxRQUFNLENBQUNxRCxZQUFZQyxhQUFhLElBQUl0RCxTQUFTO0FBQUEsSUFDM0N1RCxRQUFRO0FBQUEsSUFDUkMsVUFBVTtBQUFBLElBQ1ZDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsSUFDWEMsU0FBUztBQUFBLEVBQ1gsQ0FBQztBQUVELFFBQU1DLGlCQUFpQixZQUFZO0FBQ2pDLFFBQUk7QUFDRixZQUFNQyxNQUFNLE1BQU0zRCxJQUFJNEQsSUFBSSxrQkFBa0I7QUFDNUNwRCxtQkFBYW1ELElBQUlFLElBQUk7QUFBQSxJQUN2QixTQUFTQyxLQUFLO0FBQ1pDLGNBQVFDLE1BQU0sNkJBQTZCRixHQUFHO0FBQUEsSUFDaEQ7QUFBQSxFQUNGO0FBRUEsUUFBTUcsd0JBQXdCLE9BQU9DLGVBQWU7QUFDbEQsUUFBSSxDQUFDQSxXQUFZO0FBQ2pCNUMsZUFBVyxJQUFJO0FBQ2YsUUFBSTtBQUVGLFlBQU1xQyxNQUFNLE1BQU0zRCxJQUFJNEQ7QUFBQUEsUUFDcEI7QUFBQSxRQUNBO0FBQUEsVUFDRU8sUUFBUSxFQUFFOUIsVUFBVTZCLFlBQVlFLFdBQVd2QyxVQUFVd0MsU0FBU3RDLE9BQU87QUFBQSxRQUN2RTtBQUFBLE1BQ0Y7QUFDQWIsOEJBQXdCeUMsSUFBSUUsTUFBTVMsZUFBZTtBQUNqRGxELGdDQUEwQnVDLElBQUlFLE1BQU1VLE9BQU87QUFBQSxJQUM3QyxTQUFTVCxLQUFLO0FBQ1pDLGNBQVFDLE1BQU0sbUNBQW1DRixHQUFHO0FBQ3BENUMsOEJBQXdCLEVBQUU7QUFDMUJFLGdDQUEwQixDQUFDLENBQUM7QUFBQSxJQUM5QixVQUFDO0FBQ0NFLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNa0Qsa0JBQWtCLE9BQU9OLGVBQWU7QUFDNUMsUUFBSTtBQUNGLFlBQU1PLFlBQVksTUFBTXpFLElBQUk0RCxJQUFJLHVCQUF1QjtBQUFBLFFBQ3JETyxRQUFRLEVBQUV0QyxVQUFVRSxRQUFRMkMsU0FBU1IsV0FBVztBQUFBLE1BQ2xELENBQUM7QUFFRCxZQUFNUyxhQUFhRixVQUFVWixRQUFRO0FBR3JDLFlBQU1lLFdBQVcsQ0FBQztBQUNsQkQsaUJBQVdFLFFBQVEsQ0FBQ0MsTUFBTTtBQUN4QixhQUFLQSxFQUFFSixTQUFTSyxPQUFPRCxFQUFFSixhQUFhUixXQUFZO0FBQ2xELGNBQU0xQyxRQUFPLElBQUlJLEtBQUtrRCxFQUFFdEIsU0FBUztBQUNqQyxjQUFNd0IsTUFBTSxHQUFHeEQsTUFBS3lELFlBQVksQ0FBQyxJQUFJekQsTUFBSzBELFNBQVMsQ0FBQztBQUNwRCxZQUFJLENBQUNOLFNBQVNJLEdBQUcsRUFBR0osVUFBU0ksR0FBRyxJQUFJRixFQUFFSyxlQUFlO0FBQUEsTUFDdkQsQ0FBQztBQUdELFlBQU1DLGdCQUFnQkMsT0FBT0MsT0FBT1YsUUFBUSxFQUFFLENBQUMsS0FBSztBQUNwRCxVQUFJTyxjQUFjO0FBQ2xCLFlBQU1JLFFBQVEsSUFBSTNELEtBQUtDLFFBQVE7QUFDL0IsWUFBTTJELE1BQU0sSUFBSTVELEtBQUtHLE1BQU07QUFDM0IsVUFBSVAsT0FBTyxJQUFJSSxLQUFLMkQsS0FBSztBQUN6QixhQUFPL0QsUUFBUWdFLEtBQUs7QUFDbEIsY0FBTUMsT0FBT2pFLEtBQUt5RCxZQUFZO0FBQzlCLGNBQU1TLFFBQVFsRSxLQUFLMEQsU0FBUztBQUM1QixjQUFNRixNQUFNLEdBQUdTLElBQUksSUFBSUMsS0FBSztBQUM1QixjQUFNQyxjQUFjZixTQUFTSSxHQUFHLEtBQUtJO0FBQ3JDLGNBQU1RLGNBQWMsSUFBSWhFLEtBQUs2RCxNQUFNQyxRQUFRLEdBQUcsQ0FBQyxFQUFFRyxRQUFRO0FBQ3pELGNBQU1DLGVBQWVILGNBQWNDO0FBRW5DVCx1QkFBZVc7QUFDZnRFLGFBQUt1RSxRQUFRdkUsS0FBS3FFLFFBQVEsSUFBSSxDQUFDO0FBQUEsTUFDakM7QUFHQSxZQUFNLEVBQUVoQyxNQUFNbUMsS0FBSyxJQUFJLE1BQU1oRyxJQUFJNEQ7QUFBQUEsUUFDL0I7QUFBQSxRQUNBLEVBQUVPLFFBQVEsRUFBRTlCLFVBQVU2QixZQUFZRSxXQUFXdkMsVUFBVXdDLFNBQVN0QyxPQUFPLEVBQUU7QUFBQSxNQUMzRTtBQUVBLFVBQUl1QixXQUFXMEMsTUFBTXpCLFNBQVMwQixtQkFBbUI7QUFDakQsVUFBSSxPQUFPM0MsYUFBYSxVQUFVO0FBQ2hDQSxtQkFBVzRDLE9BQU81QyxTQUFTNkMsUUFBUSxjQUFjLEVBQUUsQ0FBQztBQUFBLE1BQ3REO0FBRUEsWUFBTTVDLFlBQVk2QyxLQUFLQyxJQUFJbEIsY0FBYzdCLFVBQVUsQ0FBQztBQUNwRCxZQUFNZ0QsYUFBYW5CLGNBQWM3QjtBQUdqQyxZQUFNaUQsY0FDSjVCLFdBQVc2QjtBQUFBQSxRQUNULENBQUMxQixPQUFPQSxFQUFFSixTQUFTSyxPQUFPRCxFQUFFSixhQUFhUjtBQUFBQSxNQUMzQyxHQUFHUSxTQUFTK0IsZ0JBQWdCQyxTQUFTO0FBQ3ZDLFlBQU1BLFFBQVFILFlBQVlJLFlBQVk7QUFFdEMsVUFBSUMsa0JBQWtCO0FBQ3RCLFVBQUlDLG1CQUFtQjtBQUV2QixVQUFJSCxVQUFVLG9CQUFvQnBELFlBQVk2QixhQUFhO0FBQ3pEeUIsMEJBQWtCTixhQUFhO0FBQy9CTywyQkFBbUI7QUFBQSxNQUNyQixXQUFXUCxhQUFhLEdBQUc7QUFDekJNLDBCQUFrQlIsS0FBS1UsSUFBSVIsVUFBVSxJQUFJO0FBQ3pDTywyQkFBbUI7QUFBQSxNQUNyQjtBQUdBLFlBQU1yRCxZQUFZbUIsV0FBV29DO0FBQUFBLFFBQzNCLENBQUNDLEtBQUtsQyxNQUFPQSxFQUFFdEIsWUFBWXdELE1BQU1sQyxFQUFFdEIsWUFBWXdEO0FBQUFBLFFBQy9DckMsV0FBVyxDQUFDLEdBQUduQixhQUFhO0FBQUEsTUFDOUI7QUFDQSxZQUFNQyxVQUFVa0IsV0FBV29DO0FBQUFBLFFBQ3pCLENBQUNWLEtBQUt2QixNQUFPQSxFQUFFckIsVUFBVTRDLE1BQU12QixFQUFFckIsVUFBVTRDO0FBQUFBLFFBQzNDMUIsV0FBVyxDQUFDLEdBQUdsQixXQUFXO0FBQUEsTUFDNUI7QUFHQUwsb0JBQWM7QUFBQSxRQUNaQyxRQUFRK0MsS0FBS2EsTUFBTTlCLFdBQVc7QUFBQSxRQUM5QjdCO0FBQUFBLFFBQ0FDLFdBQVc2QyxLQUFLQyxJQUFJbEIsY0FBYzdCLFVBQVUsQ0FBQztBQUFBLFFBQzdDZ0Q7QUFBQUEsUUFDQTlDLFdBQVdBLFdBQVc5QixNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUs7QUFBQSxRQUN2QytCLFNBQVNBLFNBQVMvQixNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUs7QUFBQSxRQUNuQzZFO0FBQUFBLFFBQ0FLLGlCQUFpQixJQUFJQSxnQkFBZ0JNLFFBQVEsQ0FBQyxDQUFDO0FBQUEsUUFDL0NMO0FBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0gsU0FBUy9DLEtBQUs7QUFDWkMsY0FBUUMsTUFBTSwrQkFBK0JGLEdBQUc7QUFDaERWLG9CQUFjO0FBQUEsUUFDWkMsUUFBUTtBQUFBLFFBQ1JDLFVBQVU7QUFBQSxRQUNWQyxXQUFXO0FBQUEsUUFDWCtDLFlBQVk7QUFBQSxRQUNaOUMsV0FBVztBQUFBLFFBQ1hDLFNBQVM7QUFBQSxRQUNUOEMsYUFBYTtBQUFBLFFBQ2JLLGlCQUFpQjtBQUFBLFFBQ2pCQyxrQkFBa0I7QUFBQSxNQUNwQixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFHQSxRQUFNTSwyQkFBMkIsWUFBWTtBQUMzQzdGLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDRixZQUFNcUMsTUFBTSxNQUFNM0QsSUFBSTRELElBQUksc0NBQXNDO0FBQUEsUUFDOURPLFFBQVEsRUFBRUMsV0FBV3ZDLFVBQVV3QyxTQUFTdEMsT0FBTztBQUFBLE1BQ2pELENBQUM7QUFDRGIsOEJBQXdCeUMsSUFBSUUsTUFBTVMsZUFBZTtBQUNqRGxELGdDQUEwQnVDLElBQUlFLE1BQU1VLE9BQU87QUFBQSxJQUM3QyxTQUFTVCxLQUFLO0FBQ1pDLGNBQVFDLE1BQU0seUNBQXlDRixHQUFHO0FBQzFENUMsOEJBQXdCLEVBQUU7QUFDMUJFLGdDQUEwQixDQUFDLENBQUM7QUFBQSxJQUM5QixVQUFDO0FBQ0NFLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNOEYsdUJBQXVCLE9BQU9DLFVBQVU7QUFDNUMzRywwQkFBc0IyRyxLQUFLO0FBRTNCLFFBQUlBLFVBQVUsT0FBTztBQUNuQnJHLGlDQUEyQixJQUFJO0FBQy9Cb0Msb0JBQWM7QUFBQSxRQUNaQyxRQUFRO0FBQUEsUUFDUkMsVUFBVTtBQUFBLFFBQ1ZDLFdBQVc7QUFBQSxRQUNYQyxXQUFXO0FBQUEsUUFDWEMsU0FBUztBQUFBLFFBQ1Q4QyxhQUFhO0FBQUEsUUFDYkssaUJBQWlCO0FBQUEsUUFDakJDLGtCQUFrQjtBQUFBLE1BQ3BCLENBQUM7QUFDRE0sK0JBQXlCO0FBQUEsSUFDM0IsT0FBTztBQUNMLFlBQU1HLGNBQWMvRyxVQUFVaUcsS0FBSyxDQUFDZSxRQUFRQSxJQUFJeEMsUUFBUXNDLEtBQUs7QUFDN0RyRyxpQ0FBMkJzRyxlQUFlLElBQUk7QUFDOUMsWUFBTXJELHNCQUFzQm9ELEtBQUs7QUFBQSxJQUVuQztBQUFBLEVBQ0Y7QUFHQXhILFlBQVUsTUFBTTtBQUNkNkQsbUJBQWU7QUFBQSxFQUNqQixHQUFHLEVBQUU7QUFFTDdELFlBQVUsTUFBTTtBQUNkLFVBQU0ySCxZQUFZakcsV0FBVyxvQkFBSUssS0FBSyxDQUFDO0FBQ3ZDaEIsb0JBQWdCO0FBQ2hCRSxrQkFBYztBQUNkZ0IsZ0JBQVk7QUFDWkUsY0FBVTtBQUFBLEVBQ1osR0FBRyxFQUFFO0FBRUxuQyxZQUFVLE1BQU07QUFDZCxVQUFNNEgsT0FBT0MsS0FBS0MsTUFBTUMsYUFBYUMsUUFBUSxNQUFNLENBQUM7QUFDcEQsUUFBSUosTUFBTTtBQUNSekUsaUJBQVd5RSxLQUFLMUMsR0FBRztBQUNuQjdCLG1CQUFhdUUsS0FBS0ssUUFBUSxFQUFFO0FBQUEsSUFDOUI7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFFBQU1DLHlCQUF5QkEsQ0FBQ0MsTUFBTTtBQUNwQyxVQUFNLEVBQUVGLE1BQU1ULE1BQU0sSUFBSVcsRUFBRTNFO0FBQzFCakIsc0JBQWtCLENBQUM2RixVQUFVLEVBQUUsR0FBR0EsTUFBTSxDQUFDSCxJQUFJLEdBQUdULE1BQU0sRUFBRTtBQUN4RHZFLGNBQVUsQ0FBQ21GLFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUNILElBQUksR0FBRyxHQUFHLEVBQUU7QUFBQSxFQUMvQztBQUVBLFFBQU1JLGVBQWVBLE1BQU07QUFDekIsVUFBTUMsWUFBWSxDQUFDO0FBQ25CLFFBQUksQ0FBQ2hHLGVBQWVFLFNBQVU4RixXQUFVOUYsV0FBVztBQUNuRCxRQUFJLENBQUNGLGVBQWVJLFVBQVU2RixNQUFNakcsZUFBZUksTUFBTSxFQUFHNEYsV0FBVTVGLFNBQVM7QUFDL0UsUUFBSUosZUFBZUssYUFBYSxZQUFZLENBQUNMLGVBQWVNLGVBQWdCMEYsV0FBVTFGLGlCQUFpQjtBQUN2R0ssY0FBVXFGLFNBQVM7QUFDbkIsV0FBTzlDLE9BQU9nRCxLQUFLRixTQUFTLEVBQUVHLFdBQVc7QUFBQSxFQUMzQztBQUVBLFFBQU1DLHlCQUF5QixPQUFPUCxNQUFNO0FBQzFDQSxNQUFFUSxlQUFlO0FBQ2pCLFFBQUksQ0FBQ04sYUFBYSxFQUFHO0FBQ3JCLFFBQUk7QUFDRixZQUFNTyxVQUFVLEVBQUUsR0FBR3RHLGdCQUFnQlMsWUFBWUcsUUFBUTtBQUN6RCxZQUFNL0MsSUFBSTBJLEtBQUssdUNBQXVDRCxPQUFPO0FBQzdERSxZQUFNLCtCQUErQjtBQUNyQ3pHLDZCQUF1QixLQUFLO0FBQUEsSUFDOUIsU0FBUzRCLEtBQUs7QUFDWjZFLFlBQU0sd0JBQXdCO0FBQUEsSUFDaEM7QUFBQSxFQUNGO0FBRUEsUUFBTUMsZUFBZUEsTUFBTTtBQUN6QixVQUFNQyxTQUFTNUgscUJBQXFCOEYsT0FBTyxDQUFDK0IsS0FBS0MsU0FBUztBQU94RCxZQUFNQyxVQUFVLElBQUlwSCxLQUFLbUgsS0FBS0UsVUFBVTtBQUN4QyxZQUFNQyxJQUFJLElBQUl0SCxLQUFLQyxRQUFRO0FBQzNCLFlBQU1pRCxJQUFJLElBQUlsRCxLQUFLRyxNQUFNO0FBQ3pCLFVBQUlpSCxXQUFXRSxLQUFLRixXQUFXbEUsR0FBRztBQUNoQyxjQUFNK0QsVUFBU007QUFBQUEsV0FDWmhJLHdCQUF3QmlJLGdCQUFnQixLQUFLQyxTQUFTLEVBQUVsRCxRQUFRLGNBQWMsRUFBRTtBQUFBLFFBR25GO0FBQ0EsZUFBTzJDLE1BQU1RO0FBQUFBLE1BQ2Y7QUFDQSxhQUFPUjtBQUFBQSxJQUNULEdBQUcsQ0FBQztBQUVKLFVBQU1TLFlBQVlKO0FBQUFBLE9BQ2ZoRyxZQUFZeUQsbUJBQW1CLEtBQUtULFFBQVEsY0FBYyxFQUFFO0FBQUEsSUFDL0Q7QUFFQSxVQUFNcUQsUUFBUVgsU0FBU1U7QUFFdkJuSCxzQkFBa0I7QUFBQSxNQUNoQkMsVUFBVTVCO0FBQUFBLE1BQ1Y2QixXQUFVLG9CQUFJVixLQUFLLEdBQUVILFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQy9DYSxRQUFRaUgsTUFBTXRDLFFBQVEsQ0FBQztBQUFBLE1BQ3ZCMUUsVUFBVTtBQUFBLE1BQ1ZDLGdCQUFnQjtBQUFBLE1BQ2hCQyxNQUFNO0FBQUE7QUFBQSxNQUNOQyxTQUFTO0FBQUEsTUFDVEMsWUFBWUc7QUFBQUEsSUFDZCxDQUFDO0FBRURELGNBQVUsQ0FBQyxDQUFDO0FBQ1paLDJCQUF1QixJQUFJO0FBQUEsRUFDN0I7QUFHQXJDLFlBQVUsTUFBTTtBQUNkLFFBQUlZLHVCQUF1QixPQUFPO0FBQ2hDMEcsK0JBQXlCO0FBQUEsSUFDM0IsV0FBVzFHLG9CQUFvQjtBQUM3QndELDRCQUFzQnhELGtCQUFrQjtBQUFBLElBQzFDO0FBQUEsRUFDRixHQUFHLENBQUNvQixVQUFVRSxNQUFNLENBQUM7QUFHckJsQyxZQUFVLE1BQU07QUFDZCxRQUFJWSxzQkFBc0JBLHVCQUF1QixPQUFPO0FBQ3REK0Qsc0JBQWdCL0Qsa0JBQWtCO0FBQUEsSUFDcEM7QUFBQSxFQUNGLEdBQUcsQ0FBQ1Esc0JBQXNCWSxVQUFVRSxNQUFNLENBQUM7QUFHM0NsQyxZQUFVLE1BQU07QUFDZDZELG1CQUFlO0FBQUEsRUFDakIsR0FBRyxFQUFFO0FBRUw3RCxZQUFVLE1BQU07QUFDZCxRQUFJWSx1QkFBdUIsT0FBTztBQUNoQzBHLCtCQUF5QjtBQUFBLElBQzNCLFdBQVcxRyxvQkFBb0I7QUFDN0J3RCw0QkFBc0J4RCxrQkFBa0I7QUFBQSxJQUMxQztBQUFBLEVBQ0YsR0FBRyxDQUFDb0IsVUFBVUUsTUFBTSxDQUFDO0FBRXJCLFFBQU0wSCxxQkFBcUJ4SSxxQkFBcUJ5SSxJQUFJLENBQUNYLE1BQU1ZLFdBQVc7QUFBQSxJQUNwRSxHQUFHWjtBQUFBQSxFQUNMLEVBQUU7QUFFRixRQUFNYSxVQUFVO0FBQUEsSUFDZCxHQUFJbkosdUJBQXVCLFFBQ3ZCLENBQUMsRUFBRXVFLEtBQUssY0FBYzZFLFFBQVEsYUFBYSxDQUFDLElBQzVDO0FBQUEsSUFDSixFQUFFN0UsS0FBSyxhQUFhNkUsUUFBUSxnQkFBZ0I7QUFBQSxJQUM1QyxFQUFFN0UsS0FBSyxnQkFBZ0I2RSxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFN0UsS0FBSyxjQUFjNkUsUUFBUSxhQUFhO0FBQUEsSUFDMUMsRUFBRTdFLEtBQUssc0JBQXNCNkUsUUFBUSxjQUFjO0FBQUEsSUFDbkQsRUFBRTdFLEtBQUssbUJBQW1CNkUsUUFBUSxrQkFBa0I7QUFBQSxJQUNwRCxFQUFFN0UsS0FBSyxjQUFjNkUsUUFBUSxhQUFhO0FBQUEsSUFDMUMsRUFBRTdFLEtBQUssK0JBQStCNkUsUUFBUSx1QkFBdUI7QUFBQSxJQUNyRSxFQUFFN0UsS0FBSyw0QkFBNEI2RSxRQUFRLG9CQUFvQjtBQUFBLElBQy9ELEVBQUU3RSxLQUFLLHFCQUFxQjZFLFFBQVEsYUFBYTtBQUFBLElBQ2pELEVBQUU3RSxLQUFLLCtCQUErQjZFLFFBQVEsdUJBQXVCO0FBQUEsSUFDckUsRUFBRTdFLEtBQUssdUJBQXVCNkUsUUFBUSxzQkFBc0I7QUFBQSxFQUFDO0FBRy9ELFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHlCQUNiLGlDQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsMkJBQUMsVUFBTyxZQUFZLFFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUI7QUFBQSxJQUN6Qix1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsbUNBQWtDLG9DQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiLGlDQUFDLFNBQUksV0FBVSxRQUNiLGlDQUFDLFNBQUksV0FBVSwyR0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDhEQUE2RCx3QkFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU9wSixzQkFBc0JxSjtBQUFBQSxjQUM3QixVQUFVMUM7QUFBQUEsY0FDVjtBQUFBLGNBQ0EsdUJBQXVCO0FBQUEsY0FDdkIsYUFBWTtBQUFBLGNBQ1osY0FBYyxDQUFDMkMsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0paLFNBQVMsRUFDVDFDLFlBQVksRUFDWnVELFNBQVNILE1BQU1wRCxZQUFZLENBQUM7QUFBQSxjQUVqQyxPQUFPLEVBQUV3RCxRQUFRLFFBQVFDLE9BQU8sUUFBUTtBQUFBLGNBRXhDO0FBQUEsdUNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxPQUFNLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4QjtBQUFBLGdCQUM3QjdKLFVBQVVtSjtBQUFBQSxrQkFBSSxDQUFDbkMsUUFDZCx1QkFBQyxPQUFPLFFBQVAsRUFBNEIsT0FBT0EsSUFBSXhDLEtBQ3JDd0M7QUFBQUEsd0JBQUlPO0FBQUFBLG9CQUFLO0FBQUEsb0JBQUlQLElBQUk4QztBQUFBQSx1QkFEQTlDLElBQUl4QyxLQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBO0FBQUEsWUFuQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBb0JBO0FBQUEsYUF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlCQTtBQUFBLFFBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE9BQU9wRSxnQkFBZ0I7QUFBQSxZQUN2QixLQUFLZ0I7QUFBQUEsWUFDTCxVQUFVLENBQUNxRyxNQUFNO0FBQ2Ysb0JBQU1zQyxVQUFVdEMsRUFBRTNFLE9BQU9nRTtBQUN6QixrQkFBSXhHLGNBQWNBLGFBQWF5SixRQUFTeEosZUFBY3dKLE9BQU87QUFDN0QxSiw4QkFBZ0IwSixPQUFPO0FBQUEsWUFDekI7QUFBQSxZQUNBLFdBQVU7QUFBQTtBQUFBLFVBVFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBU3FFO0FBQUEsUUFHckU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE9BQU96SixjQUFjO0FBQUEsWUFDckIsS0FBS0YsZ0JBQWdCO0FBQUEsWUFDckIsS0FBS2dCO0FBQUFBLFlBQ0wsVUFBVSxDQUFDcUcsTUFBTWxILGNBQWNrSCxFQUFFM0UsT0FBT2dFLEtBQUs7QUFBQSxZQUM3QyxXQUFVO0FBQUE7QUFBQSxVQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1xRTtBQUFBLFFBR3JFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU07QUFDYnZGLDBCQUFZbkIsWUFBWTtBQUN4QnFCLHdCQUFVbkIsVUFBVTtBQUFBLFlBQ3RCO0FBQUEsWUFDQSxVQUFVLENBQUNGLGdCQUFnQixDQUFDRTtBQUFBQSxZQUM1QixXQUFVO0FBQUEsWUFBbUY7QUFBQTtBQUFBLFVBTi9GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVNBO0FBQUEsV0ExREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTREQSxLQTdERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOERBLEtBL0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnRUE7QUFBQSxPQUdFSix1QkFBdUIsU0FBU00sNEJBQ2hDLHVCQUFDLFNBQUksV0FBVSxzREFDWk47QUFBQUEsK0JBQXVCLFNBQVNNLDJCQUMvQixtQ0FDRTtBQUFBLGlDQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLDRCQUEyQixvQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0Q7QUFBQSxjQUNoRDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPQSx3QkFBd0IrRyxRQUFRO0FBQUEsa0JBQ3ZDO0FBQUEsa0JBQ0EsV0FBVTtBQUFBO0FBQUEsZ0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRytEO0FBQUEsaUJBTGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSw0QkFBMkIscUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlEO0FBQUEsY0FDakQ7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTy9HLHdCQUF3QndKLFNBQVM7QUFBQSxrQkFDeEM7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FHK0Q7QUFBQSxpQkFMakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLDRCQUEyQiw0QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBT3hKLHdCQUF3QnNKLGdCQUFnQjtBQUFBLGtCQUMvQztBQUFBLGtCQUNBLFdBQVU7QUFBQTtBQUFBLGdCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUcrRDtBQUFBLGlCQVBqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsZUExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyQkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLDRCQUEyQiw2QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBT3RKLHdCQUF3QnlKLGFBQWE7QUFBQSxrQkFDNUM7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FHK0Q7QUFBQSxpQkFQakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLDRCQUEyQiwwQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBT3pKLHdCQUF3QjBKLFVBQVU7QUFBQSxrQkFDekM7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FHK0Q7QUFBQSxpQkFQakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLDRCQUEyQix1QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTzFKLHdCQUF3QjJKLFdBQVc7QUFBQSxrQkFDMUM7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FHK0Q7QUFBQSxpQkFQakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLGVBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0JBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsNEJBQTJCLHVCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRDtBQUFBLFlBQ25EO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTzNKLHdCQUF3QjRKLFdBQVc7QUFBQSxnQkFDMUM7QUFBQSxnQkFDQSxXQUFVO0FBQUE7QUFBQSxjQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUcrRDtBQUFBLGVBTGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxhQXRFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUVBO0FBQUEsUUFJRix1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSw0QkFBMkIsK0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBT3hKLHdCQUF3QjhFLG1CQUFtQjtBQUFBLGdCQUNsRDtBQUFBLGdCQUNBLFdBQVU7QUFBQTtBQUFBLGNBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBR3dGO0FBQUEsZUFQMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDRCQUEyQixpQ0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPOUUsd0JBQXdCaUksZ0JBQWdCO0FBQUEsZ0JBQy9DO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBO0FBQUEsY0FIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHeUY7QUFBQSxlQVAzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsNEJBQTJCLDhCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU9qSSx3QkFBd0J5SixxQkFBcUI7QUFBQSxnQkFDcEQ7QUFBQSxnQkFDQSxXQUFVO0FBQUE7QUFBQSxjQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUcrRDtBQUFBLGVBUGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxhQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0NBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSw0QkFBMkIsZ0NBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBT3pKLHdCQUF3QjBKLG1CQUFtQjtBQUFBLGdCQUNsRDtBQUFBLGdCQUNBLFdBQVU7QUFBQTtBQUFBLGNBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRytEO0FBQUEsZUFQakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDRCQUEyQiwrQkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPMUosd0JBQXdCMkosbUJBQW1CO0FBQUEsZ0JBQ2xEO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBO0FBQUEsY0FIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHK0Q7QUFBQSxlQVBqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsNEJBQTJCLDRCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU8zSix3QkFBd0I0SixnQkFBZ0I7QUFBQSxnQkFDL0M7QUFBQSxnQkFDQSxXQUFVO0FBQUE7QUFBQSxjQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUcrRDtBQUFBLGVBUGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxhQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0JBO0FBQUEsV0FoSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlKQTtBQUFBLE1BR0R0SyxzQkFBc0JBLHVCQUF1QixTQUFTb0IsWUFBWUUsVUFDakUsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDBDQUF5Qyw4QkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFQ29CLFdBQVdHLFlBQVlILFdBQVdFLFVBQ2pDLHVCQUFDLFNBQUksV0FBVSxxQ0FBb0Msa0NBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBR0YsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxxQkFBb0IsMEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStDO0FBQUEsWUFDL0M7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPLElBQUlGLFdBQVdFLFFBQVEySCxlQUFlLE9BQU8sQ0FBQztBQUFBLGdCQUNyRDtBQUFBLGdCQUNBLFdBQVU7QUFBQTtBQUFBLGNBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBR3NFO0FBQUEsZUFMeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxxQkFBb0Isd0JBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZDO0FBQUEsWUFDN0M7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPLElBQUk3SCxXQUFXRyxVQUFVMEgsZUFBZSxPQUFPLENBQUM7QUFBQSxnQkFDdkQ7QUFBQSxnQkFDQSxXQUFVO0FBQUE7QUFBQSxjQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUdzRTtBQUFBLGVBTHhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUscUJBQW9CLHlCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QztBQUFBLFlBQzlDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTyxJQUFJN0gsV0FBV0ksV0FBV3lILGVBQWUsT0FBTyxDQUFDO0FBQUEsZ0JBQ3hEO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBO0FBQUEsY0FIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHc0U7QUFBQSxlQUx4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlCQTtBQUFBLFFBSUEsdUJBQUMsU0FBSSxXQUFVLGtDQUViO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxxQkFBb0IsNkJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtEO0FBQUEsWUFDbEQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPN0gsV0FBVzBELG9CQUFvQjtBQUFBLGdCQUN0QztBQUFBLGdCQUNBLFdBQVU7QUFBQTtBQUFBLGNBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBR3NFO0FBQUEsZUFMeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxxQkFBb0IsZ0NBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFEO0FBQUEsWUFDckQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPMUQsV0FBV3lELG1CQUFtQjtBQUFBLGdCQUNyQztBQUFBLGdCQUNBLFdBQVU7QUFBQTtBQUFBLGNBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBR3NFO0FBQUEsZUFMeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxxQkFBb0IsOEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1EO0FBQUEsWUFDbkQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLFFBQVEsTUFBTTtBQUNaLHdCQUFNaUMsU0FBU007QUFBQUEscUJBQ1poSSx3QkFBd0JpSSxnQkFBZ0IsS0FBS0MsU0FBUyxFQUFFbEQsUUFBUSxjQUFjLEVBQUU7QUFBQSxrQkFDbkY7QUFFQSx3QkFBTW9ELFlBQVlKO0FBQUFBLHFCQUNmaEcsWUFBWXlELG1CQUFtQixLQUFLVCxRQUFRLGNBQWMsRUFBRTtBQUFBLGtCQUMvRDtBQUVBLHdCQUFNcUQsUUFBU0Q7QUFFZix5QkFBTyxJQUFJQyxNQUFNd0IsZUFBZSxPQUFPLENBQUM7QUFBQSxnQkFDMUMsR0FBRztBQUFBLGdCQUVILFdBQVU7QUFBQTtBQUFBLGNBaEJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWdCaUY7QUFBQSxlQWxCbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBU3BDO0FBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBQXFFO0FBQUE7QUFBQSxZQUZqRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxhQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0RBO0FBQUEsV0ExRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJGQTtBQUFBLE1BR0YsdUJBQUMsU0FBTSxXQUFXM0cscUJBQXFCLFNBQVMsTUFBTUMsdUJBQXVCLEtBQUssR0FBRyxPQUFNLFlBQ3pGLGlDQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxzREFBcUQsc0NBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUY7QUFBQSxRQUN6Rix1QkFBQyxVQUFLLFdBQVUsYUFBWSxVQUFVcUcsd0JBQ3BDO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSw2QkFBNEIsMEJBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVEO0FBQUEsWUFDdkQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0w7QUFBQSxnQkFDQSxPQUNFaEksVUFBVWlHLEtBQUssQ0FBQ2UsUUFBUUEsSUFBSXhDLFFBQVE1QyxlQUFlRSxRQUFRLEdBQUd5RixRQUFRO0FBQUEsZ0JBRXhFLFdBQVU7QUFBQTtBQUFBLGNBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTWlFO0FBQUEsZUFSbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSw2QkFBNEIsNEJBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlEO0FBQUEsWUFDekQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU8zRixlQUFlRztBQUFBQSxnQkFDdEIsVUFBVXlGO0FBQUFBLGdCQUNWLFdBQVU7QUFBQTtBQUFBLGNBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS3VDO0FBQUEsZUFQekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSw2QkFBNEIsd0NBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFFO0FBQUEsWUFDckU7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0w7QUFBQSxnQkFDQSxPQUFPLElBQUk1RixlQUFlSSxVQUFVLE1BQU07QUFBQSxnQkFDMUMsV0FBVTtBQUFBO0FBQUEsY0FKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJZ0Y7QUFBQSxlQU5sRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFHQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDZCQUE0Qiw0QkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUQ7QUFBQSxZQUN6RDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPSixlQUFlSztBQUFBQSxnQkFDdEIsVUFBVXVGO0FBQUFBLGdCQUNWLFdBQVU7QUFBQSxnQkFFVjtBQUFBLHlDQUFDLFlBQU8sT0FBTSxRQUFPLG9CQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5QjtBQUFBLGtCQUN6Qix1QkFBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkI7QUFBQSxrQkFDN0IsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZCO0FBQUEsa0JBQzdCLHVCQUFDLFlBQU8sT0FBTSxpQkFBZ0IsNkJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJDO0FBQUE7QUFBQTtBQUFBLGNBVDdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFFQzVGLGVBQWVLLGFBQWEsWUFDM0IsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSw2QkFBNEIsOEJBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJEO0FBQUEsWUFDM0Q7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9MLGVBQWVNO0FBQUFBLGdCQUN0QixVQUFVc0Y7QUFBQUEsZ0JBQ1YsV0FBVTtBQUFBO0FBQUEsY0FMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLdUM7QUFBQSxZQUV0Q2xGLE9BQU9KLGtCQUFrQix1QkFBQyxPQUFFLFdBQVUsd0JBQXdCSSxpQkFBT0osa0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJEO0FBQUEsZUFUdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBR0YsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSw2QkFBNEIsb0JBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlEO0FBQUEsWUFDakQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT04sZUFBZU87QUFBQUEsZ0JBQ3RCLFVBQVVxRjtBQUFBQSxnQkFDVixXQUFVO0FBQUE7QUFBQSxjQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUl1QztBQUFBLGVBTnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLG1DQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTTdGLHVCQUF1QixLQUFLLEdBQUcsV0FBVSw0QkFBMkIsc0JBQXpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsOENBQTZDLDRCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUFoRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlGQTtBQUFBLFdBbkZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvRkEsS0FyRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNGQTtBQUFBLE1BR0NiLFVBQ0MsdUJBQUMsa0JBQWUsV0FBVyxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdDLElBQzlCSixxQkFBcUJxSCxTQUFTLElBQ2hDLG1DQU9FO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDYixNQUFNbUI7QUFBQUEsVUFDTjtBQUFBLFVBQ0EsaUJBQWlCO0FBQUEsVUFDakIsaUJBQWlCO0FBQUEsWUFDZjtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQWM7QUFBQSxVQUVoQixtQkFBbUI7QUFBQSxZQUNqQmhKLHVCQUF1QixRQUFRLGtCQUFrQk0seUJBQXlCK0csUUFBUTtBQUFBLFlBQ2xGckgsdUJBQXVCLFFBQVEsTUFBTU0seUJBQXlCc0osZ0JBQWdCO0FBQUEsWUFDOUUxSixnQkFBZ0I7QUFBQSxZQUNoQkUsY0FBYztBQUFBLFlBQ2QsSUFBSXNDLFlBQVlFLFFBQVEySCxlQUFlLE9BQU8sS0FBSyxHQUFHO0FBQUEsWUFDdEQsSUFBSTdILFlBQVlHLFVBQVUwSCxlQUFlLE9BQU8sS0FBSyxHQUFHO0FBQUEsWUFDeEQsSUFBSTdILFlBQVlJLFdBQVd5SCxlQUFlLE9BQU8sS0FBSyxHQUFHO0FBQUEsWUFDekQ3SCxZQUFZMEQsb0JBQW9CO0FBQUEsWUFDaEMxRCxZQUFZeUQsbUJBQW1CO0FBQUEsYUFDOUIsTUFBTTtBQUNMLG9CQUFNaUMsU0FBU007QUFBQUEsaUJBQ1poSSx3QkFBd0JpSSxnQkFBZ0IsS0FBS0MsU0FBUyxFQUFFbEQsUUFBUSxjQUFjLEVBQUU7QUFBQSxjQUNuRjtBQUNBLG9CQUFNb0QsWUFBWUo7QUFBQUEsaUJBQ2ZoRyxZQUFZeUQsbUJBQW1CLEtBQUt5QyxTQUFTLEVBQUVsRCxRQUFRLGNBQWMsRUFBRTtBQUFBLGNBQzFFO0FBQ0Esb0JBQU1xRCxRQUFRWCxTQUFTVTtBQUN2QixxQkFBTyxJQUFJQyxNQUFNd0IsZUFBZSxPQUFPLENBQUM7QUFBQSxZQUMxQyxHQUFHO0FBQUEsWUFDSCxJQUFJN0osd0JBQXdCOEUsaUJBQWlCK0UsZUFBZSxPQUFPLEtBQUssR0FBRztBQUFBLFlBQzNFLElBQUk3Six3QkFBd0JpSSxjQUFjNEIsZUFBZSxPQUFPLEtBQUssR0FBRztBQUFBLFlBQ3hFLElBQUk3Six3QkFBd0J5SixtQkFBbUJJLGVBQWUsT0FBTyxLQUFLLEdBQUc7QUFBQSxZQUM3RSxJQUFJN0osd0JBQXdCMEosaUJBQWlCRyxlQUFlLE9BQU8sS0FBSyxHQUFHO0FBQUEsWUFDM0U3Six3QkFBd0IySixtQkFBbUI7QUFBQSxZQUMzQzNKLHdCQUF3QjRKLGdCQUFnQjtBQUFBLFVBQUc7QUFBQSxVQUU3QyxrQkFBa0Isb0JBQW9CaEsseUJBQXlCK0csUUFBUSxLQUFLO0FBQUE7QUFBQSxRQWpEaEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BaUR1RSxLQXhEekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBEQSxJQUVBL0cseUJBQXlCK0csUUFDdkIsdUJBQUMsT0FBRSxXQUFVLGlDQUFnQyx5Q0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0F2ZE47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBkQTtBQUFBLE9BNWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2ZEEsS0E5ZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStkQTtBQUVKO0FBQUV4SCxHQXgwQklELGtCQUFnQjtBQUFBNEssS0FBaEI1SztBQTAwQk4sZUFBZUE7QUFBaUIsSUFBQTRLO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlNlbGVjdCIsImFwaSIsIkRhdGFUYWJsZSIsIkNpcmN1bGFyTG9hZGVyIiwiTmF2YmFyIiwiTW9kYWwiLCJDb21taXNzaW9uUmVwb3J0IiwiX3MiLCJlbXBsb3llZXMiLCJzZXRFbXBsb3llZXMiLCJzZWxlY3RlZEVtcGxveWVlSWQiLCJzZXRTZWxlY3RlZEVtcGxveWVlSWQiLCJ0ZW1wRnJvbURhdGUiLCJzZXRUZW1wRnJvbURhdGUiLCJ0ZW1wVG9EYXRlIiwic2V0VGVtcFRvRGF0ZSIsInNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzIiwic2V0U2VsZWN0ZWRFbXBsb3llZURldGFpbHMiLCJlbXBsb3llZUN1c3RvbWVyRGF0YSIsInNldEVtcGxveWVlQ3VzdG9tZXJEYXRhIiwiY29tbWlzc2lvblRvdGFsRGV0YWlscyIsInNldENvbW1pc3Npb25Ub3RhbERldGFpbHMiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImZvcm1hdERhdGUiLCJkYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsInRvZGF5IiwiRGF0ZSIsImZyb21EYXRlIiwic2V0RnJvbURhdGUiLCJ0b0RhdGUiLCJzZXRUb0RhdGUiLCJzaG93Q29tbWlzc2lvbk1vZGFsIiwic2V0U2hvd0NvbW1pc3Npb25Nb2RhbCIsImNvbW1pc3Npb25Gb3JtIiwic2V0Q29tbWlzc2lvbkZvcm0iLCJhZ2VudF9pZCIsInBheV9kYXRlIiwiYW1vdW50IiwicGF5X3R5cGUiLCJ0cmFuc2FjdGlvbl9pZCIsIm5vdGUiLCJwYXlfZm9yIiwiYWRtaW5fdHlwZSIsImVycm9ycyIsInNldEVycm9ycyIsImFkbWluSWQiLCJzZXRBZG1pbklkIiwiYWRtaW5OYW1lIiwic2V0QWRtaW5OYW1lIiwidGFyZ2V0RGF0YSIsInNldFRhcmdldERhdGEiLCJ0YXJnZXQiLCJhY2hpZXZlZCIsInJlbWFpbmluZyIsInN0YXJ0RGF0ZSIsImVuZERhdGUiLCJmZXRjaEVtcGxveWVlcyIsInJlcyIsImdldCIsImRhdGEiLCJlcnIiLCJjb25zb2xlIiwiZXJyb3IiLCJmZXRjaENvbW1pc3Npb25SZXBvcnQiLCJlbXBsb3llZUlkIiwicGFyYW1zIiwiZnJvbV9kYXRlIiwidG9fZGF0ZSIsImNvbW1pc3Npb25fZGF0YSIsInN1bW1hcnkiLCJmZXRjaFRhcmdldERhdGEiLCJ0YXJnZXRSZXMiLCJhZ2VudElkIiwicmF3VGFyZ2V0cyIsIm1vbnRoTWFwIiwiZm9yRWFjaCIsInQiLCJfaWQiLCJrZXkiLCJnZXRGdWxsWWVhciIsImdldE1vbnRoIiwidG90YWxUYXJnZXQiLCJkZWZhdWx0VGFyZ2V0IiwiT2JqZWN0IiwidmFsdWVzIiwic3RhcnQiLCJlbmQiLCJ5ZWFyIiwibW9udGgiLCJtb250aFRhcmdldCIsImRheXNJbk1vbnRoIiwiZ2V0RGF0ZSIsInBlckRheVRhcmdldCIsInNldERhdGUiLCJjb21tIiwiYWN0dWFsX2J1c2luZXNzIiwiTnVtYmVyIiwicmVwbGFjZSIsIk1hdGgiLCJtYXgiLCJkaWZmZXJlbmNlIiwiZGVzaWduYXRpb24iLCJmaW5kIiwiZGVzaWduYXRpb25faWQiLCJ0aXRsZSIsInRvTG93ZXJDYXNlIiwiaW5jZW50aXZlQW1vdW50IiwiaW5jZW50aXZlUGVyY2VudCIsImFicyIsInJlZHVjZSIsIm1pbiIsInJvdW5kIiwidG9GaXhlZCIsImZldGNoQWxsQ29tbWlzc2lvblJlcG9ydCIsImhhbmRsZUVtcGxveWVlQ2hhbmdlIiwidmFsdWUiLCJzZWxlY3RlZEVtcCIsImVtcCIsInRvZGF5RGF0ZSIsInVzZXIiLCJKU09OIiwicGFyc2UiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwibmFtZSIsImhhbmRsZUNvbW1pc3Npb25DaGFuZ2UiLCJlIiwicHJldiIsInZhbGlkYXRlRm9ybSIsIm5ld0Vycm9ycyIsImlzTmFOIiwia2V5cyIsImxlbmd0aCIsImhhbmRsZUNvbW1pc3Npb25TdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsInBheWxvYWQiLCJwb3N0IiwiYWxlcnQiLCJoYW5kbGVQYXlOb3ciLCJhY3R1YWwiLCJzdW0iLCJpdGVtIiwicGF5RGF0ZSIsInN0YXJ0X2RhdGUiLCJmIiwicGFyc2VGbG9hdCIsInRvdGFsX2FjdHVhbCIsInRvU3RyaW5nIiwidmFsIiwiaW5jZW50aXZlIiwidG90YWwiLCJwcm9jZXNzZWRUYWJsZURhdGEiLCJtYXAiLCJpbmRleCIsImNvbHVtbnMiLCJoZWFkZXIiLCJ1bmRlZmluZWQiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwiaW5jbHVkZXMiLCJoZWlnaHQiLCJ3aWR0aCIsInBob25lX251bWJlciIsIm5ld0Zyb20iLCJlbWFpbCIsImFkaGFhcl9ubyIsInBhbl9ubyIsInBpbmNvZGUiLCJhZGRyZXNzIiwiZXhwZWN0ZWRfYnVzaW5lc3MiLCJ0b3RhbF9lc3RpbWF0ZWQiLCJ0b3RhbF9jdXN0b21lcnMiLCJ0b3RhbF9ncm91cHMiLCJ0b0xvY2FsZVN0cmluZyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkNvbW1pc3Npb25SZXBvcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IFNlbGVjdCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuXHJcblxyXG5jb25zdCBDb21taXNzaW9uUmVwb3J0ID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtlbXBsb3llZXMsIHNldEVtcGxveWVlc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkRW1wbG95ZWVJZCwgc2V0U2VsZWN0ZWRFbXBsb3llZUlkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIC8vZGF0ZSBmaWx0ZXJzXHJcbiAgY29uc3QgW3RlbXBGcm9tRGF0ZSwgc2V0VGVtcEZyb21EYXRlXSA9IHVzZVN0YXRlKCk7XHJcbiAgY29uc3QgW3RlbXBUb0RhdGUsIHNldFRlbXBUb0RhdGVdID0gdXNlU3RhdGUoKTtcclxuXHJcbiAgY29uc3QgW3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzLCBzZXRTZWxlY3RlZEVtcGxveWVlRGV0YWlsc10gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZW1wbG95ZWVDdXN0b21lckRhdGEsIHNldEVtcGxveWVlQ3VzdG9tZXJEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbY29tbWlzc2lvblRvdGFsRGV0YWlscywgc2V0Q29tbWlzc2lvblRvdGFsRGV0YWlsc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IGZvcm1hdERhdGUgPSAoZGF0ZSkgPT4gZGF0ZS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcclxuICBjb25zdCB0b2RheSA9IGZvcm1hdERhdGUobmV3IERhdGUoKSk7XHJcbiAgY29uc3QgW2Zyb21EYXRlLCBzZXRGcm9tRGF0ZV0gPSB1c2VTdGF0ZSgpO1xyXG4gIGNvbnN0IFt0b0RhdGUsIHNldFRvRGF0ZV0gPSB1c2VTdGF0ZSgpO1xyXG4gIGNvbnN0IFtzaG93Q29tbWlzc2lvbk1vZGFsLCBzZXRTaG93Q29tbWlzc2lvbk1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY29tbWlzc2lvbkZvcm0sIHNldENvbW1pc3Npb25Gb3JtXSA9IHVzZVN0YXRlKHtcclxuICAgIGFnZW50X2lkOiBcIlwiLFxyXG4gICAgcGF5X2RhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF0sXHJcbiAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICBwYXlfdHlwZTogXCJjYXNoXCIsXHJcbiAgICB0cmFuc2FjdGlvbl9pZDogXCJcIixcclxuICAgIG5vdGU6IFwiXCIsXHJcbiAgICBwYXlfZm9yOiBcImNvbW1pc3Npb25cIixcclxuICAgIGFkbWluX3R5cGU6IFwiXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbYWRtaW5JZCwgc2V0QWRtaW5JZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWRtaW5OYW1lLCBzZXRBZG1pbk5hbWVdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGNvbnN0IFt0YXJnZXREYXRhLCBzZXRUYXJnZXREYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIHRhcmdldDogMCxcclxuICAgIGFjaGlldmVkOiAwLFxyXG4gICAgcmVtYWluaW5nOiAwLFxyXG4gICAgc3RhcnREYXRlOiBcIlwiLFxyXG4gICAgZW5kRGF0ZTogXCJcIixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2FnZW50L2dldC1hZ2VudFwiKTtcclxuICAgICAgc2V0RW1wbG95ZWVzKHJlcy5kYXRhKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW1wbG95ZWVzOlwiLCBlcnIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoQ29tbWlzc2lvblJlcG9ydCA9IGFzeW5jIChlbXBsb3llZUlkKSA9PiB7XHJcbiAgICBpZiAoIWVtcGxveWVlSWQpIHJldHVybjtcclxuICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgIFxyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgICcvZW5yb2xsL2dldC1kZXRhaWxlZC1jb21taXNzaW9uLXBlci1tb250aCcsIFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIHBhcmFtczogeyBhZ2VudF9pZDogZW1wbG95ZWVJZCwgZnJvbV9kYXRlOiBmcm9tRGF0ZSwgdG9fZGF0ZTogdG9EYXRlIH0sIFxyXG4gICAgICAgIH1cclxuICAgICAgKTtcclxuICAgICAgc2V0RW1wbG95ZWVDdXN0b21lckRhdGEocmVzLmRhdGE/LmNvbW1pc3Npb25fZGF0YSk7XHJcbiAgICAgIHNldENvbW1pc3Npb25Ub3RhbERldGFpbHMocmVzLmRhdGE/LnN1bW1hcnkpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbXBsb3llZSByZXBvcnQ6XCIsIGVycik7XHJcbiAgICAgIHNldEVtcGxveWVlQ3VzdG9tZXJEYXRhKFtdKTtcclxuICAgICAgc2V0Q29tbWlzc2lvblRvdGFsRGV0YWlscyh7fSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaFRhcmdldERhdGEgPSBhc3luYyAoZW1wbG95ZWVJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgdGFyZ2V0UmVzID0gYXdhaXQgYXBpLmdldChcIi90YXJnZXQvZ2V0LXRhcmdldHNcIiwge1xyXG4gICAgICAgIHBhcmFtczogeyBmcm9tRGF0ZSwgdG9EYXRlLCBhZ2VudElkOiBlbXBsb3llZUlkIH0sXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgcmF3VGFyZ2V0cyA9IHRhcmdldFJlcy5kYXRhIHx8IFtdO1xyXG5cclxuICAgICBcclxuICAgICAgY29uc3QgbW9udGhNYXAgPSB7fTtcclxuICAgICAgcmF3VGFyZ2V0cy5mb3JFYWNoKCh0KSA9PiB7XHJcbiAgICAgICAgaWYgKCh0LmFnZW50SWQ/Ll9pZCB8fCB0LmFnZW50SWQpICE9PSBlbXBsb3llZUlkKSByZXR1cm47XHJcbiAgICAgICAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKHQuc3RhcnREYXRlKTtcclxuICAgICAgICBjb25zdCBrZXkgPSBgJHtkYXRlLmdldEZ1bGxZZWFyKCl9LSR7ZGF0ZS5nZXRNb250aCgpfWA7XHJcbiAgICAgICAgaWYgKCFtb250aE1hcFtrZXldKSBtb250aE1hcFtrZXldID0gdC50b3RhbFRhcmdldCB8fCAwO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIFxyXG4gICAgICBjb25zdCBkZWZhdWx0VGFyZ2V0ID0gT2JqZWN0LnZhbHVlcyhtb250aE1hcClbMF0gfHwgMDtcclxuICAgICAgbGV0IHRvdGFsVGFyZ2V0ID0gMDtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZShmcm9tRGF0ZSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvRGF0ZSk7XHJcbiAgICAgIGxldCBkYXRlID0gbmV3IERhdGUoc3RhcnQpO1xyXG4gICAgICB3aGlsZSAoZGF0ZSA8PSBlbmQpIHtcclxuICAgICAgICBjb25zdCB5ZWFyID0gZGF0ZS5nZXRGdWxsWWVhcigpO1xyXG4gICAgICAgIGNvbnN0IG1vbnRoID0gZGF0ZS5nZXRNb250aCgpO1xyXG4gICAgICAgIGNvbnN0IGtleSA9IGAke3llYXJ9LSR7bW9udGh9YDtcclxuICAgICAgICBjb25zdCBtb250aFRhcmdldCA9IG1vbnRoTWFwW2tleV0gPz8gZGVmYXVsdFRhcmdldDtcclxuICAgICAgICBjb25zdCBkYXlzSW5Nb250aCA9IG5ldyBEYXRlKHllYXIsIG1vbnRoICsgMSwgMCkuZ2V0RGF0ZSgpO1xyXG4gICAgICAgIGNvbnN0IHBlckRheVRhcmdldCA9IG1vbnRoVGFyZ2V0IC8gZGF5c0luTW9udGg7XHJcblxyXG4gICAgICAgIHRvdGFsVGFyZ2V0ICs9IHBlckRheVRhcmdldDtcclxuICAgICAgICBkYXRlLnNldERhdGUoZGF0ZS5nZXREYXRlKCkgKyAxKTtcclxuICAgICAgfVxyXG5cclxuICAgICBcclxuICAgICAgY29uc3QgeyBkYXRhOiBjb21tIH0gPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgICcvZW5yb2xsL2dldC1kZXRhaWxlZC1jb21taXNzaW9uLXBlci1tb250aCcsIFxyXG4gICAgICAgIHsgcGFyYW1zOiB7IGFnZW50X2lkOiBlbXBsb3llZUlkLCBmcm9tX2RhdGU6IGZyb21EYXRlLCB0b19kYXRlOiB0b0RhdGUgfSB9IFxyXG4gICAgICApO1xyXG5cclxuICAgICAgbGV0IGFjaGlldmVkID0gY29tbT8uc3VtbWFyeT8uYWN0dWFsX2J1c2luZXNzIHx8IDA7XHJcbiAgICAgIGlmICh0eXBlb2YgYWNoaWV2ZWQgPT09IFwic3RyaW5nXCIpIHtcclxuICAgICAgICBhY2hpZXZlZCA9IE51bWJlcihhY2hpZXZlZC5yZXBsYWNlKC9bXjAtOS4tXSsvZywgXCJcIikpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCByZW1haW5pbmcgPSBNYXRoLm1heCh0b3RhbFRhcmdldCAtIGFjaGlldmVkLCAwKTtcclxuICAgICAgY29uc3QgZGlmZmVyZW5jZSA9IHRvdGFsVGFyZ2V0IC0gYWNoaWV2ZWQ7XHJcblxyXG4gICAgICAvLyBTdGVwIDQ6IERlc2lnbmF0aW9uICYgaW5jZW50aXZlIGxvZ2ljXHJcbiAgICAgIGNvbnN0IGRlc2lnbmF0aW9uID1cclxuICAgICAgICByYXdUYXJnZXRzLmZpbmQoXHJcbiAgICAgICAgICAodCkgPT4gKHQuYWdlbnRJZD8uX2lkIHx8IHQuYWdlbnRJZCkgPT09IGVtcGxveWVlSWRcclxuICAgICAgICApPy5hZ2VudElkPy5kZXNpZ25hdGlvbl9pZD8udGl0bGUgfHwgXCJOL0FcIjtcclxuICAgICAgY29uc3QgdGl0bGUgPSBkZXNpZ25hdGlvbi50b0xvd2VyQ2FzZSgpO1xyXG5cclxuICAgICAgbGV0IGluY2VudGl2ZUFtb3VudCA9IDA7XHJcbiAgICAgIGxldCBpbmNlbnRpdmVQZXJjZW50ID0gXCIwJVwiO1xyXG5cclxuICAgICAgaWYgKHRpdGxlID09PSBcImJ1c2luZXNzIGFnZW50XCIgJiYgYWNoaWV2ZWQgPD0gdG90YWxUYXJnZXQpIHtcclxuICAgICAgICBpbmNlbnRpdmVBbW91bnQgPSBkaWZmZXJlbmNlICogMC4wMDU7XHJcbiAgICAgICAgaW5jZW50aXZlUGVyY2VudCA9IFwiMC41JVwiO1xyXG4gICAgICB9IGVsc2UgaWYgKGRpZmZlcmVuY2UgPCAwKSB7XHJcbiAgICAgICAgaW5jZW50aXZlQW1vdW50ID0gTWF0aC5hYnMoZGlmZmVyZW5jZSkgKiAwLjAxO1xyXG4gICAgICAgIGluY2VudGl2ZVBlcmNlbnQgPSBcIjElXCI7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIFN0ZXAgNTogU3RhcnQgYW5kIEVuZCBEYXRlc1xyXG4gICAgICBjb25zdCBzdGFydERhdGUgPSByYXdUYXJnZXRzLnJlZHVjZShcclxuICAgICAgICAobWluLCB0KSA9PiAodC5zdGFydERhdGUgPCBtaW4gPyB0LnN0YXJ0RGF0ZSA6IG1pbiksXHJcbiAgICAgICAgcmF3VGFyZ2V0c1swXT8uc3RhcnREYXRlIHx8IFwiXCJcclxuICAgICAgKTtcclxuICAgICAgY29uc3QgZW5kRGF0ZSA9IHJhd1RhcmdldHMucmVkdWNlKFxyXG4gICAgICAgIChtYXgsIHQpID0+ICh0LmVuZERhdGUgPiBtYXggPyB0LmVuZERhdGUgOiBtYXgpLFxyXG4gICAgICAgIHJhd1RhcmdldHNbMF0/LmVuZERhdGUgfHwgXCJcIlxyXG4gICAgICApO1xyXG5cclxuICAgICAgLy8gU3RlcCA2OiBTZXQgVUkgc3RhdGVcclxuICAgICAgc2V0VGFyZ2V0RGF0YSh7XHJcbiAgICAgICAgdGFyZ2V0OiBNYXRoLnJvdW5kKHRvdGFsVGFyZ2V0KSxcclxuICAgICAgICBhY2hpZXZlZCxcclxuICAgICAgICByZW1haW5pbmc6IE1hdGgubWF4KHRvdGFsVGFyZ2V0IC0gYWNoaWV2ZWQsIDApLFxyXG4gICAgICAgIGRpZmZlcmVuY2UsXHJcbiAgICAgICAgc3RhcnREYXRlOiBzdGFydERhdGU/LnNwbGl0KFwiVFwiKVswXSB8fCBcIlwiLFxyXG4gICAgICAgIGVuZERhdGU6IGVuZERhdGU/LnNwbGl0KFwiVFwiKVswXSB8fCBcIlwiLFxyXG4gICAgICAgIGRlc2lnbmF0aW9uLFxyXG4gICAgICAgIGluY2VudGl2ZUFtb3VudDogYOKCuSR7aW5jZW50aXZlQW1vdW50LnRvRml4ZWQoMil9YCxcclxuICAgICAgICBpbmNlbnRpdmVQZXJjZW50LFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdGFyZ2V0IGRhdGE6XCIsIGVycik7XHJcbiAgICAgIHNldFRhcmdldERhdGEoe1xyXG4gICAgICAgIHRhcmdldDogMCxcclxuICAgICAgICBhY2hpZXZlZDogMCxcclxuICAgICAgICByZW1haW5pbmc6IDAsXHJcbiAgICAgICAgZGlmZmVyZW5jZTogMCxcclxuICAgICAgICBzdGFydERhdGU6IFwiXCIsXHJcbiAgICAgICAgZW5kRGF0ZTogXCJcIixcclxuICAgICAgICBkZXNpZ25hdGlvbjogXCItXCIsXHJcbiAgICAgICAgaW5jZW50aXZlQW1vdW50OiBcIuKCuTAuMDBcIixcclxuICAgICAgICBpbmNlbnRpdmVQZXJjZW50OiBcIjAlXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG5cclxuICBjb25zdCBmZXRjaEFsbENvbW1pc3Npb25SZXBvcnQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcImVucm9sbC9nZXQtZGV0YWlsZWQtY29tbWlzc2lvbi1hbGxcIiwge1xyXG4gICAgICAgIHBhcmFtczogeyBmcm9tX2RhdGU6IGZyb21EYXRlLCB0b19kYXRlOiB0b0RhdGUgfSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldEVtcGxveWVlQ3VzdG9tZXJEYXRhKHJlcy5kYXRhPy5jb21taXNzaW9uX2RhdGEpO1xyXG4gICAgICBzZXRDb21taXNzaW9uVG90YWxEZXRhaWxzKHJlcy5kYXRhPy5zdW1tYXJ5KTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYWxsIGNvbW1pc3Npb24gcmVwb3J0OlwiLCBlcnIpO1xyXG4gICAgICBzZXRFbXBsb3llZUN1c3RvbWVyRGF0YShbXSk7XHJcbiAgICAgIHNldENvbW1pc3Npb25Ub3RhbERldGFpbHMoe30pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRW1wbG95ZWVDaGFuZ2UgPSBhc3luYyAodmFsdWUpID0+IHtcclxuICAgIHNldFNlbGVjdGVkRW1wbG95ZWVJZCh2YWx1ZSk7XHJcblxyXG4gICAgaWYgKHZhbHVlID09PSBcIkFMTFwiKSB7XHJcbiAgICAgIHNldFNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzKG51bGwpO1xyXG4gICAgICBzZXRUYXJnZXREYXRhKHtcclxuICAgICAgICB0YXJnZXQ6IDAsXHJcbiAgICAgICAgYWNoaWV2ZWQ6IDAsXHJcbiAgICAgICAgcmVtYWluaW5nOiAwLFxyXG4gICAgICAgIHN0YXJ0RGF0ZTogXCJcIixcclxuICAgICAgICBlbmREYXRlOiBcIlwiLFxyXG4gICAgICAgIGRlc2lnbmF0aW9uOiBcIlwiLFxyXG4gICAgICAgIGluY2VudGl2ZUFtb3VudDogXCLigrkwLjAwXCIsXHJcbiAgICAgICAgaW5jZW50aXZlUGVyY2VudDogXCIwJVwiLFxyXG4gICAgICB9KTtcclxuICAgICAgZmV0Y2hBbGxDb21taXNzaW9uUmVwb3J0KCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCBzZWxlY3RlZEVtcCA9IGVtcGxveWVlcy5maW5kKChlbXApID0+IGVtcC5faWQgPT09IHZhbHVlKTtcclxuICAgICAgc2V0U2VsZWN0ZWRFbXBsb3llZURldGFpbHMoc2VsZWN0ZWRFbXAgfHwgbnVsbCk7XHJcbiAgICAgIGF3YWl0IGZldGNoQ29tbWlzc2lvblJlcG9ydCh2YWx1ZSk7XHJcbiAgICAgIC8vIPCflKUgRG9uJ3QgY2FsbCBmZXRjaFRhcmdldERhdGEgaGVyZSDigJQgaXQncyBtb3ZlZCB0byB1c2VFZmZlY3RcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBmZXRjaCBlbXBsb3llZXMgb24gbW91bnRcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hFbXBsb3llZXMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB0b2RheURhdGUgPSBmb3JtYXREYXRlKG5ldyBEYXRlKCkpO1xyXG4gICAgc2V0VGVtcEZyb21EYXRlKCk7XHJcbiAgICBzZXRUZW1wVG9EYXRlKCk7XHJcbiAgICBzZXRGcm9tRGF0ZSgpO1xyXG4gICAgc2V0VG9EYXRlKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpKTtcclxuICAgIGlmICh1c2VyKSB7XHJcbiAgICAgIHNldEFkbWluSWQodXNlci5faWQpO1xyXG4gICAgICBzZXRBZG1pbk5hbWUodXNlci5uYW1lIHx8IFwiXCIpO1xyXG4gICAgfVxyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ29tbWlzc2lvbkNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldENvbW1pc3Npb25Gb3JtKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbbmFtZV06IHZhbHVlIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgW25hbWVdOiBcIlwiIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCB2YWxpZGF0ZUZvcm0gPSAoKSA9PiB7XHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuICAgIGlmICghY29tbWlzc2lvbkZvcm0uYWdlbnRfaWQpIG5ld0Vycm9ycy5hZ2VudF9pZCA9IFwiUGxlYXNlIHNlbGVjdCBhbiBhZ2VudFwiO1xyXG4gICAgaWYgKCFjb21taXNzaW9uRm9ybS5hbW91bnQgfHwgaXNOYU4oY29tbWlzc2lvbkZvcm0uYW1vdW50KSkgbmV3RXJyb3JzLmFtb3VudCA9IFwiUGxlYXNlIGVudGVyIGEgdmFsaWQgYW1vdW50XCI7XHJcbiAgICBpZiAoY29tbWlzc2lvbkZvcm0ucGF5X3R5cGUgPT09IFwib25saW5lXCIgJiYgIWNvbW1pc3Npb25Gb3JtLnRyYW5zYWN0aW9uX2lkKSBuZXdFcnJvcnMudHJhbnNhY3Rpb25faWQgPSBcIlRyYW5zYWN0aW9uIElEIGlzIHJlcXVpcmVkXCI7XHJcbiAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDb21taXNzaW9uU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGlmICghdmFsaWRhdGVGb3JtKCkpIHJldHVybjtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHBheWxvYWQgPSB7IC4uLmNvbW1pc3Npb25Gb3JtLCBhZG1pbl90eXBlOiBhZG1pbklkIH07XHJcbiAgICAgIGF3YWl0IGFwaS5wb3N0KFwiL3BheW1lbnQtb3V0L2FkZC1jb21taXNzaW9uLXBheW1lbnRcIiwgcGF5bG9hZCk7XHJcbiAgICAgIGFsZXJ0KFwiQ29tbWlzc2lvbiBQYWlkIFN1Y2Nlc3NmdWxseSFcIik7XHJcbiAgICAgIHNldFNob3dDb21taXNzaW9uTW9kYWwoZmFsc2UpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGFsZXJ0KFwiRmFpbGVkIHRvIGFkZCBwYXltZW50LlwiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQYXlOb3cgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBhY3R1YWwgPSBlbXBsb3llZUN1c3RvbWVyRGF0YS5yZWR1Y2UoKHN1bSwgaXRlbSkgPT4ge1xyXG4gICAgICAvLyBUaGUgYGl0ZW0uc3RhcnRfZGF0ZWAgaGVyZSBpcyBsaWtlbHkgaW5jb3JyZWN0IGlmIHlvdSB3YW50IHRvIHN1bSBiYXNlZCBvbiBwYXltZW50IGRhdGUuXHJcbiAgICAgIC8vIEFzc3VtaW5nIGBzdGFydF9kYXRlYCByZWZlcnMgdG8gdGhlIGVucm9sbG1lbnQncyBzdGFydCBkYXRlIGFuZCBub3QgcGF5bWVudCBkYXRlLlxyXG4gICAgICAvLyBJZiB5b3UgaGF2ZSBhICdwYXlfZGF0ZScgb3Igc2ltaWxhciBmaWVsZCBpbiBgZW1wbG95ZWVDdXN0b21lckRhdGFgLCB1c2UgdGhhdC5cclxuICAgICAgLy8gQmFzZWQgb24gdGhlIHByb21wdCwgaXQgc2VlbXMgeW91IHdhbnQgdG8gc3VtIGJhc2VkIG9uICdwYXlfZGF0ZScuXHJcbiAgICAgIC8vIElmIGBlbXBsb3llZUN1c3RvbWVyRGF0YWAgY29udGFpbnMgYSBgcGF5X2RhdGVgIGZvciBlYWNoIGl0ZW0sIHlvdSBzaG91bGQgdXNlIHRoYXQuXHJcbiAgICAgIC8vIE90aGVyd2lzZSwgdGhlIGN1cnJlbnQgbG9naWMgc3VtcyBjb21taXNzaW9uIGJhc2VkIG9uIHRoZSBlbnJvbGxtZW50IGBzdGFydF9kYXRlYC5cclxuICAgICAgY29uc3QgcGF5RGF0ZSA9IG5ldyBEYXRlKGl0ZW0uc3RhcnRfZGF0ZSk7IC8vIFRoaXMgc2hvdWxkIGlkZWFsbHkgYmUgYGl0ZW0ucGF5X2RhdGVgIGlmIGF2YWlsYWJsZS5cclxuICAgICAgY29uc3QgZiA9IG5ldyBEYXRlKGZyb21EYXRlKTtcclxuICAgICAgY29uc3QgdCA9IG5ldyBEYXRlKHRvRGF0ZSk7XHJcbiAgICAgIGlmIChwYXlEYXRlID49IGYgJiYgcGF5RGF0ZSA8PSB0KSB7XHJcbiAgICAgICAgY29uc3QgYWN0dWFsID0gcGFyc2VGbG9hdChcclxuICAgICAgICAgIChjb21taXNzaW9uVG90YWxEZXRhaWxzPy50b3RhbF9hY3R1YWwgfHwgXCIwXCIpLnRvU3RyaW5nKCkucmVwbGFjZSgvW14wLTkuLV0rL2csIFwiXCIpXHJcblxyXG5cclxuICAgICAgICApO1xyXG4gICAgICAgIHJldHVybiBzdW0gKyB2YWw7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHN1bTtcclxuICAgIH0sIDApO1xyXG5cclxuICAgIGNvbnN0IGluY2VudGl2ZSA9IHBhcnNlRmxvYXQoXHJcbiAgICAgICh0YXJnZXREYXRhPy5pbmNlbnRpdmVBbW91bnQgfHwgXCIwXCIpLnJlcGxhY2UoL1teMC05Li1dKy9nLCBcIlwiKVxyXG4gICAgKTtcclxuXHJcbiAgICBjb25zdCB0b3RhbCA9IGFjdHVhbCArIGluY2VudGl2ZTtcclxuXHJcbiAgICBzZXRDb21taXNzaW9uRm9ybSh7XHJcbiAgICAgIGFnZW50X2lkOiBzZWxlY3RlZEVtcGxveWVlSWQsXHJcbiAgICAgIHBheV9kYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICBhbW91bnQ6IHRvdGFsLnRvRml4ZWQoMiksXHJcbiAgICAgIHBheV90eXBlOiBcImNhc2hcIixcclxuICAgICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICAgIG5vdGU6IFwiXCIsIC8vIOKchSBSZXNldCBub3RlIGhlcmVcclxuICAgICAgcGF5X2ZvcjogXCJjb21taXNzaW9uXCIsXHJcbiAgICAgIGFkbWluX3R5cGU6IGFkbWluSWQsXHJcbiAgICB9KTtcclxuXHJcbiAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgc2V0U2hvd0NvbW1pc3Npb25Nb2RhbCh0cnVlKTtcclxuICB9O1xyXG5cclxuICAvLyByZS1mZXRjaCBjb21taXNzaW9uIGRhdGEgd2hlbiBmaWx0ZXJzIGNoYW5nZVxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoc2VsZWN0ZWRFbXBsb3llZUlkID09PSBcIkFMTFwiKSB7XHJcbiAgICAgIGZldGNoQWxsQ29tbWlzc2lvblJlcG9ydCgpO1xyXG4gICAgfSBlbHNlIGlmIChzZWxlY3RlZEVtcGxveWVlSWQpIHtcclxuICAgICAgZmV0Y2hDb21taXNzaW9uUmVwb3J0KHNlbGVjdGVkRW1wbG95ZWVJZCk7XHJcbiAgICB9XHJcbiAgfSwgW2Zyb21EYXRlLCB0b0RhdGVdKTtcclxuXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoc2VsZWN0ZWRFbXBsb3llZUlkICYmIHNlbGVjdGVkRW1wbG95ZWVJZCAhPT0gXCJBTExcIikge1xyXG4gICAgICBmZXRjaFRhcmdldERhdGEoc2VsZWN0ZWRFbXBsb3llZUlkKTtcclxuICAgIH1cclxuICB9LCBbZW1wbG95ZWVDdXN0b21lckRhdGEsIGZyb21EYXRlLCB0b0RhdGVdKTtcclxuXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaEVtcGxveWVlcygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChzZWxlY3RlZEVtcGxveWVlSWQgPT09IFwiQUxMXCIpIHtcclxuICAgICAgZmV0Y2hBbGxDb21taXNzaW9uUmVwb3J0KCk7XHJcbiAgICB9IGVsc2UgaWYgKHNlbGVjdGVkRW1wbG95ZWVJZCkge1xyXG4gICAgICBmZXRjaENvbW1pc3Npb25SZXBvcnQoc2VsZWN0ZWRFbXBsb3llZUlkKTtcclxuICAgIH1cclxuICB9LCBbZnJvbURhdGUsIHRvRGF0ZV0pO1xyXG5cclxuICBjb25zdCBwcm9jZXNzZWRUYWJsZURhdGEgPSBlbXBsb3llZUN1c3RvbWVyRGF0YS5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoe1xyXG4gICAgLi4uaXRlbSxcclxuICB9KSk7XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICAuLi4oc2VsZWN0ZWRFbXBsb3llZUlkID09PSBcIkFMTFwiXHJcbiAgICAgID8gW3sga2V5OiBcImFnZW50X25hbWVcIiwgaGVhZGVyOiBcIkFnZW50IE5hbWVcIiB9XVxyXG4gICAgICA6IFtdKSxcclxuICAgIHsga2V5OiBcInVzZXJfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX3ZhbHVlX2RpZ2l0c1wiLCBoZWFkZXI6IFwiR3JvdXAgVmFsdWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY29tbWlzc2lvbl9yYXRlXCIsIGhlYWRlcjogXCJDb21taXNzaW9uIFJhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhcnRfZGF0ZVwiLCBoZWFkZXI6IFwiU3RhcnQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJlc3RpbWF0ZWRfY29tbWlzc2lvbl9kaWdpdHNcIiwgaGVhZGVyOiBcIkVzdGltYXRlZCBDb21taXNzaW9uXCIgfSxcclxuICAgIHsga2V5OiBcImFjdHVhbF9jb21taXNzaW9uX2RpZ2l0c1wiLCBoZWFkZXI6IFwiQWN0dWFsIENvbW1pc3Npb25cIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxfcGFpZF9kaWdpdHNcIiwgaGVhZGVyOiBcIlRvdGFsIFBhaWRcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVxdWlyZWRfaW5zdGFsbG1lbnRfZGlnaXRzXCIsIGhlYWRlcjogXCJSZXF1aXJlZCBJbnN0YWxsbWVudFwiIH0sXHJcbiAgICB7IGtleTogXCJjb21taXNzaW9uX3JlbGVhc2VkXCIsIGhlYWRlcjogXCJDb21taXNzaW9uIFJlbGVhc2VkXCIgfSxcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJ3LXNjcmVlbiBtaW4taC1zY3JlZW5cIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTMwXCI+XHJcbiAgICAgICAgPE5hdmJhciB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWNlbnRlciBcIj5cclxuICAgICAgICAgICAgUmVwb3J0cyAtIENvbW1pc3Npb25cclxuICAgICAgICAgIDwvaDE+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLThcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciB3LWZ1bGwgZ2FwLTQgYmctdmlvbGV0LTUwIHAtMiB3LTMwIGgtNDAgcm91bmRlZC0zeGwgYm9yZGVyICAgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtbGcgdGV4dC1ncmF5LTUwMCB0ZXh0LWNlbnRlciBmb250LXNlbWlib2xkIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICBFbXBsb3llZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWVJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUVtcGxveWVlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIG9yIFNlbGVjdCBFbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgaGVpZ2h0OiBcIjUwcHhcIiwgd2lkdGg6IFwiNjAwcHhcIiB9fVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJBTExcIj5BbGw8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGVtcCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtlbXAuX2lkfSB2YWx1ZT17ZW1wLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlbXAubmFtZX0gLSB7ZW1wLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dGVtcEZyb21EYXRlIHx8IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgIG1heD17dG9kYXl9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG5ld0Zyb20gPSBlLnRhcmdldC52YWx1ZTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAodGVtcFRvRGF0ZSAmJiB0ZW1wVG9EYXRlIDwgbmV3RnJvbSkgc2V0VGVtcFRvRGF0ZShuZXdGcm9tKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRUZW1wRnJvbURhdGUobmV3RnJvbSk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC00IG10LTcgcHktMiB3LVsyMDBweF1cIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dGVtcFRvRGF0ZSB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICBtaW49e3RlbXBGcm9tRGF0ZSB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICBtYXg9e3RvZGF5fVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRlbXBUb0RhdGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNCBtdC03IHB5LTIgdy1bMjAwcHhdXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0RnJvbURhdGUodGVtcEZyb21EYXRlKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRUb0RhdGUodGVtcFRvRGF0ZSk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshdGVtcEZyb21EYXRlIHx8ICF0ZW1wVG9EYXRlfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy12aW9sZXQtNjAwIGhvdmVyOmJnLXZpb2xldC03MDAgdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHB4LTQgbXQtNyBweS0yIHJvdW5kZWRcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBGaWx0ZXJcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogRW1wbG95ZWUgSW5mbyAqL31cclxuICAgICAgICAgIHsoc2VsZWN0ZWRFbXBsb3llZUlkID09PSBcIkFMTFwiIHx8IHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzKSAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOCBiZy1ncmF5LTUwIHJvdW5kZWQtbWQgc2hhZG93LW1kIHAtNiBzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICB7c2VsZWN0ZWRFbXBsb3llZUlkICE9PSBcIkFMTFwiICYmIHNlbGVjdGVkRW1wbG95ZWVEZXRhaWxzICYmIChcclxuICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5OYW1lPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRFbXBsb3llZURldGFpbHMubmFtZSB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTQgcHktMiBiZy13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5FbWFpbDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzLmVtYWlsIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNCBweS0yIGJnLXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBQaG9uZSBOdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzLnBob25lX251bWJlciB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTQgcHktMiBiZy13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWRoYWFyIE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRFbXBsb3llZURldGFpbHMuYWRoYWFyX25vIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNCBweS0yIGJnLXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBQQU4gTnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEVtcGxveWVlRGV0YWlscy5wYW5fbm8gfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC00IHB5LTIgYmctd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFBpbmNvZGVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWVEZXRhaWxzLnBpbmNvZGUgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC00IHB5LTIgYmctd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+QWRkcmVzczwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRFbXBsb3llZURldGFpbHMuYWRkcmVzcyB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNCBweS0yIGJnLXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBTdW1tYXJ5IGFsd2F5cyBzaG93biAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEFjdHVhbCBCdXNpbmVzc1xyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y29tbWlzc2lvblRvdGFsRGV0YWlscz8uYWN0dWFsX2J1c2luZXNzIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTQgcHktMiBiZy13aGl0ZSB0ZXh0LWdyZWVuLTcwMCBmb250LWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQWN0dWFsIENvbW1pc3Npb25cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvbW1pc3Npb25Ub3RhbERldGFpbHM/LnRvdGFsX2FjdHVhbCB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC00IHB5LTIgYmctd2hpdGUgIHRleHQtZ3JlZW4tNzAwIGZvbnQtYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBHcm9zcyBCdXNpbmVzc1xyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y29tbWlzc2lvblRvdGFsRGV0YWlscz8uZXhwZWN0ZWRfYnVzaW5lc3MgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNCBweS0yIGJnLXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBHcm9zcyBDb21taXNzaW9uXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb21taXNzaW9uVG90YWxEZXRhaWxzPy50b3RhbF9lc3RpbWF0ZWQgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNCBweS0yIGJnLXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVG90YWwgQ3VzdG9tZXJzXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb21taXNzaW9uVG90YWxEZXRhaWxzPy50b3RhbF9jdXN0b21lcnMgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNCBweS0yIGJnLXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVG90YWwgR3JvdXBzXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb21taXNzaW9uVG90YWxEZXRhaWxzPy50b3RhbF9ncm91cHMgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNCBweS0yIGJnLXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAge3NlbGVjdGVkRW1wbG95ZWVJZCAmJiBzZWxlY3RlZEVtcGxveWVlSWQgIT09IFwiQUxMXCIgJiYgZnJvbURhdGUgJiYgdG9EYXRlICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTEwMCAgcC00IHJvdW5kZWQtbGcgc2hhZG93IG1iLTZcIj5cclxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC15ZWxsb3ctODAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIFRhcmdldCBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICAgICAge3RhcmdldERhdGEuYWNoaWV2ZWQgPj0gdGFyZ2V0RGF0YS50YXJnZXQgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTgwMCBmb250LXNlbWlib2xkIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAg8J+OiSBUYXJnZXQgQWNoaWV2ZWRcclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBtZDpncmlkLWNvbHMtMyBnYXAtNCBiZy1ncmF5LTUwIFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtbWVkaXVtXCI+VGFyZ2V0IFNldDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtg4oK5JHt0YXJnZXREYXRhLnRhcmdldD8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gfVxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMiByb3VuZGVkIHctZnVsbCBiZy1ncmF5LTUwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1tZWRpdW1cIj5BY2hpZXZlZDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtg4oK5JHt0YXJnZXREYXRhLmFjaGlldmVkPy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHJvdW5kZWQgdy1mdWxsIGJnLWdyYXktNTAgZm9udC1zZW1pYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LW1lZGl1bVwiPlJlbWFpbmluZzwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtg4oK5JHt0YXJnZXREYXRhLnJlbWFpbmluZz8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gfVxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMiByb3VuZGVkIHctZnVsbCBiZy1ncmF5LTUwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIG1kOmdyaWQtY29scy0yIGdhcC00IG10LTRcIj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1tZWRpdW1cIj5JbmNlbnRpdmUgKCUpPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RhcmdldERhdGEuaW5jZW50aXZlUGVyY2VudCB8fCBcIjAlXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgcHgtMyBweS0yIHJvdW5kZWQgdy1mdWxsIGJnLWdyYXktNTAgZm9udC1zZW1pYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1tZWRpdW1cIj5JbmNlbnRpdmUgQW1vdW50PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RhcmdldERhdGEuaW5jZW50aXZlQW1vdW50IHx8IFwi4oK5MC4wMFwifVxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIHB4LTMgcHktMiByb3VuZGVkIHctZnVsbCBiZy1ncmF5LTUwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtbWVkaXVtXCI+VG90YWwgUGF5YWJsZSA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXsoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgYWN0dWFsID0gcGFyc2VGbG9hdChcclxuICAgICAgICAgICAgICAgICAgICAgICAgKGNvbW1pc3Npb25Ub3RhbERldGFpbHM/LnRvdGFsX2FjdHVhbCB8fCBcIjBcIikudG9TdHJpbmcoKS5yZXBsYWNlKC9bXjAtOS4tXSsvZywgXCJcIilcclxuICAgICAgICAgICAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgaW5jZW50aXZlID0gcGFyc2VGbG9hdChcclxuICAgICAgICAgICAgICAgICAgICAgICAgKHRhcmdldERhdGE/LmluY2VudGl2ZUFtb3VudCB8fCBcIjBcIikucmVwbGFjZSgvW14wLTkuLV0rL2csIFwiXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRvdGFsID0gIGluY2VudGl2ZTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYOKCuSR7dG90YWwudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pKCl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBweC0zIHB5LTIgcm91bmRlZCB3LWZ1bGwgYmctZ3JheS01MCB0ZXh0LWdyZWVuLTcwMCBmb250LWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUGF5Tm93fVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyZWVuLTYwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdyBob3ZlcjpiZy1ncmVlbi03MDBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGF5IE5vd1xyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIDxNb2RhbCBpc1Zpc2libGU9e3Nob3dDb21taXNzaW9uTW9kYWx9IG9uQ2xvc2U9eygpID0+IHNldFNob3dDb21taXNzaW9uTW9kYWwoZmFsc2UpfSB3aWR0aD1cIm1heC13LW1kXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgYm9yZGVyLWIgcGItMlwiPkFkZCBDb21taXNzaW9uIFBheW1lbnQ8L2gzPlxyXG4gICAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNFwiIG9uU3VibWl0PXtoYW5kbGVDb21taXNzaW9uU3VibWl0fT5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+QWdlbnQgTmFtZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgIGVtcGxveWVlcy5maW5kKChlbXApID0+IGVtcC5faWQgPT09IGNvbW1pc3Npb25Gb3JtLmFnZW50X2lkKT8ubmFtZSB8fCBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgcC0yIHJvdW5kZWQgYmctZ3JheS0xMDAgZm9udC1zZW1pYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bVwiPlBheW1lbnQgRGF0ZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGF5X2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb21taXNzaW9uRm9ybS5wYXlfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ29tbWlzc2lvbkNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIHAtMiByb3VuZGVkXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW1cIj5Ub3RhbCBQYXlhYmxlIENvbW1pc3Npb248L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YOKCuSR7Y29tbWlzc2lvbkZvcm0uYW1vdW50IHx8IFwiMC4wMFwifWB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBwLTIgcm91bmRlZCBiZy1ncmF5LTEwMCB0ZXh0LWdyZWVuLTcwMCBmb250LXNlbWlib2xkXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bVwiPlBheW1lbnQgTW9kZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGF5X3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb21taXNzaW9uRm9ybS5wYXlfdHlwZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ29tbWlzc2lvbkNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIHAtMiByb3VuZGVkXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjYXNoXCI+Q2FzaDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJvbmxpbmVcIj5PbmxpbmU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY2hlcXVlXCI+Q2hlcXVlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImJhbmtfdHJhbnNmZXJcIj5CYW5rIFRyYW5zZmVyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAge2NvbW1pc3Npb25Gb3JtLnBheV90eXBlID09PSBcIm9ubGluZVwiICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bVwiPlRyYW5zYWN0aW9uIElEPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0cmFuc2FjdGlvbl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y29tbWlzc2lvbkZvcm0udHJhbnNhY3Rpb25faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ29tbWlzc2lvbkNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgcC0yIHJvdW5kZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy50cmFuc2FjdGlvbl9pZCAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbVwiPntlcnJvcnMudHJhbnNhY3Rpb25faWR9PC9wPn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+Tm90ZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJub3RlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y29tbWlzc2lvbkZvcm0ubm90ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ29tbWlzc2lvbkNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyIHAtMiByb3VuZGVkXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMyBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dDb21taXNzaW9uTW9kYWwoZmFsc2UpfSBjbGFzc05hbWU9XCJweC00IHB5LTIgYm9yZGVyIHJvdW5kZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy12aW9sZXQtNjAwIHRleHQtd2hpdGUgcm91bmRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFNhdmUgUGF5bWVudFxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgICAgIHsvKiBUYWJsZSBTZWN0aW9uICovfVxyXG4gICAgICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e3RydWV9IC8+XHJcbiAgICAgICAgICApIDogZW1wbG95ZWVDdXN0b21lckRhdGEubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICB7LyogPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgZGF0YT17cHJvY2Vzc2VkVGFibGVEYXRhfVxyXG4gICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BDb21taXNzaW9uUmVwb3J0LSR7c2VsZWN0ZWRFbXBsb3llZUlkIHx8IFwiYWxsXCJcclxuICAgICAgICAgICAgICAgICAgfS5jc3ZgfVxyXG4gICAgICAgICAgICAgIC8+ICovfVxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICBkYXRhPXtwcm9jZXNzZWRUYWJsZURhdGF9XHJcbiAgY29sdW1ucz17Y29sdW1uc31cclxuICBleHBvcnRlZFBkZk5hbWU9e2BDb21taXNzaW9uIFJlcG9ydGB9XHJcbiAgcHJpbnRIZWFkZXJLZXlzPXtbXHJcbiAgICBcIk5hbWVcIixcclxuICAgIFwiUGhvbmUgTnVtYmVyXCIsXHJcbiAgICBcIkZyb20gRGF0ZVwiLFxyXG4gICAgXCJUbyBEYXRlXCIsXHJcbiAgICBcIlRhcmdldCBTZXRcIixcclxuICAgIFwiQWNoaWV2ZWRcIixcclxuICAgIFwiUmVtYWluaW5nXCIsXHJcbiAgICBcIkluY2VudGl2ZSAoJSlcIixcclxuICAgIFwiSW5jZW50aXZlIEFtb3VudFwiLFxyXG4gICAgXCJUb3RhbCBQYXlhYmxlIENvbW1pc3Npb25cIixcclxuICAgIFwiQWN0dWFsIEJ1c2luZXNzXCIsXHJcbiAgICBcIkFjdHVhbCBDb21taXNzaW9uXCIsXHJcbiAgICBcIkdyb3NzIEJ1c2luZXNzXCIsXHJcbiAgICBcIkdyb3NzIENvbW1pc3Npb25cIixcclxuICAgIFwiVG90YWwgQ3VzdG9tZXJzXCIsXHJcbiAgICBcIlRvdGFsIEdyb3Vwc1wiXHJcbiAgXX1cclxuICBwcmludEhlYWRlclZhbHVlcz17W1xyXG4gICAgc2VsZWN0ZWRFbXBsb3llZUlkID09PSBcIkFMTFwiID8gXCJBbGwgRW1wbG95ZWVzXCIgOiBzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ubmFtZSB8fCBcIi1cIixcclxuICAgIHNlbGVjdGVkRW1wbG95ZWVJZCA9PT0gXCJBTExcIiA/IFwiLVwiIDogc2VsZWN0ZWRFbXBsb3llZURldGFpbHM/LnBob25lX251bWJlciB8fCBcIi1cIixcclxuICAgIHRlbXBGcm9tRGF0ZSB8fCBcIi1cIixcclxuICAgIHRlbXBUb0RhdGUgfHwgXCItXCIsXHJcbiAgICBg4oK5JHt0YXJnZXREYXRhPy50YXJnZXQ/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIikgfHwgXCIwXCJ9YCxcclxuICAgIGDigrkke3RhcmdldERhdGE/LmFjaGlldmVkPy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpIHx8IFwiMFwifWAsXHJcbiAgICBg4oK5JHt0YXJnZXREYXRhPy5yZW1haW5pbmc/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIikgfHwgXCIwXCJ9YCxcclxuICAgIHRhcmdldERhdGE/LmluY2VudGl2ZVBlcmNlbnQgfHwgXCIwJVwiLFxyXG4gICAgdGFyZ2V0RGF0YT8uaW5jZW50aXZlQW1vdW50IHx8IFwi4oK5MC4wMFwiLFxyXG4gICAgKCgpID0+IHtcclxuICAgICAgY29uc3QgYWN0dWFsID0gcGFyc2VGbG9hdChcclxuICAgICAgICAoY29tbWlzc2lvblRvdGFsRGV0YWlscz8udG90YWxfYWN0dWFsIHx8IFwiMFwiKS50b1N0cmluZygpLnJlcGxhY2UoL1teMC05Li1dKy9nLCBcIlwiKVxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCBpbmNlbnRpdmUgPSBwYXJzZUZsb2F0KFxyXG4gICAgICAgICh0YXJnZXREYXRhPy5pbmNlbnRpdmVBbW91bnQgfHwgXCIwXCIpLnRvU3RyaW5nKCkucmVwbGFjZSgvW14wLTkuLV0rL2csIFwiXCIpXHJcbiAgICAgICk7XHJcbiAgICAgIGNvbnN0IHRvdGFsID0gYWN0dWFsICsgaW5jZW50aXZlO1xyXG4gICAgICByZXR1cm4gYOKCuSR7dG90YWwudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gO1xyXG4gICAgfSkoKSxcclxuICAgIGDigrkke2NvbW1pc3Npb25Ub3RhbERldGFpbHM/LmFjdHVhbF9idXNpbmVzcz8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKSB8fCBcIjBcIn1gLFxyXG4gICAgYOKCuSR7Y29tbWlzc2lvblRvdGFsRGV0YWlscz8udG90YWxfYWN0dWFsPy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpIHx8IFwiMFwifWAsXHJcbiAgICBg4oK5JHtjb21taXNzaW9uVG90YWxEZXRhaWxzPy5leHBlY3RlZF9idXNpbmVzcz8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKSB8fCBcIjBcIn1gLFxyXG4gICAgYOKCuSR7Y29tbWlzc2lvblRvdGFsRGV0YWlscz8udG90YWxfZXN0aW1hdGVkPy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpIHx8IFwiMFwifWAsXHJcbiAgICBjb21taXNzaW9uVG90YWxEZXRhaWxzPy50b3RhbF9jdXN0b21lcnMgfHwgXCIwXCIsXHJcbiAgICBjb21taXNzaW9uVG90YWxEZXRhaWxzPy50b3RhbF9ncm91cHMgfHwgXCIwXCJcclxuICBdfVxyXG4gIGV4cG9ydGVkRmlsZU5hbWU9e2BDb21taXNzaW9uUmVwb3J0LSR7c2VsZWN0ZWRFbXBsb3llZURldGFpbHM/Lm5hbWUgfHwgXCJhbGxcIn0uY3N2YH1cclxuLz5cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICBzZWxlY3RlZEVtcGxveWVlRGV0YWlscz8ubmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgZm9udC1ib2xkIHRleHQtbGdcIj5cclxuICAgICAgICAgICAgICAgIE5vIENvbW1pc3Npb24gRGF0YSBmb3VuZC5cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIClcclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IENvbW1pc3Npb25SZXBvcnQ7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0NvbW1pc3Npb25SZXBvcnQuanN4In0=