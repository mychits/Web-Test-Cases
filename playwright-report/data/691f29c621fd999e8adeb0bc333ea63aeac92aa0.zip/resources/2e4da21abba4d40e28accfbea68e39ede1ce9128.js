import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/EmployeeStatement.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { Select, Tag, Space, Typography, Table, Button } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import {
  TeamOutlined,
  PlusCircleOutlined,
  MinusCircleOutlined,
  CreditCardOutlined,
  CheckCircleOutlined,
  CloseCircleOutlined,
  DownOutlined,
  UpOutlined,
  InfoCircleOutlined,
  ArrowUpOutlined,
  ArrowDownOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import { MdOutlineMan } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { RiMoneyRupeeCircleFill } from "/node_modules/.vite/deps/react-icons_ri.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import api from "/src/instance/TokenInstance.js";
import { FaRupeeSign } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
import { header } from "/node_modules/.vite/deps/framer-motion_client.js?v=819e0a34";
const { Text, Title } = Typography;
const ALERT_MESSAGES = {
  EMPLOYEE_FETCH_ERROR: "Failed to load employees",
  LEDGER_FETCH_ERROR: "Failed to load salary ledger"
};
const CURRENCY_FORMAT_OPTIONS = {
  style: "currency",
  currency: "INR",
  minimumFractionDigits: 0,
  maximumFractionDigits: 0
};
const formatCurrency = (amount) => {
  return amount?.toLocaleString("en-IN", CURRENCY_FORMAT_OPTIONS);
};
const getAchievementTag = (status) => {
  const isSuccess = status === "Met/Exceeded";
  return /* @__PURE__ */ jsxDEV(
    Tag,
    {
      color: isSuccess ? "green" : "red",
      icon: isSuccess ? /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
        lineNumber: 56,
        columnNumber: 25
      }, this) : /* @__PURE__ */ jsxDEV(CloseCircleOutlined, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
        lineNumber: 56,
        columnNumber: 51
      }, this),
      children: status
    },
    void 0,
    false,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
      lineNumber: 54,
      columnNumber: 5
    },
    this
  );
};
const formatLedgerData = (ledger) => {
  return ledger.map((item, index) => {
    const balance = item.financials?.current_running_balance ?? 0;
    const balanceColor = balance >= 0 ? "text-green-600" : "text-red-600";
    const advanceAmount = item.financials?.advance_amount || 0;
    const advanceCount = item.financials?.advance_count || 0;
    const advanceInAmount = item.financials?.advance_payment_in_amount || 0;
    const advanceDisplay = advanceCount > 1 ? `${formatCurrency(advanceAmount)}` : formatCurrency(advanceAmount);
    const monthlyBalance = Number(item.financials?.current_running_balance || 0) - Number(item.financials?.previous_balance || 0);
    return {
      id: index + 1,
      month: item.period,
      netPayable: formatCurrency(item.financials?.net_payable),
      paidAmount: formatCurrency(item.financials?.paid_amount),
      targetAmount: formatCurrency(item.business?.target),
      businessClosed: formatCurrency(item.business?.totalBusinessClosed),
      achievement: getAchievementTag(item.business?.achievement),
      incentiveEarned: formatCurrency(item.business?.incentive_earned),
      pigmyIncentives: formatCurrency(item.business?.pigmy_incentives),
      pigmyIncentivesRaw: item.business?.pigmy_incentives,
      loanIncentives: formatCurrency(item.business?.loan_incentives),
      paidChitIncentive: formatCurrency(item.financials?.paid_chit_incentive),
      paidLoanIncentive: formatCurrency(item.financials?.paid_loan_incentive),
      paidPigmyIncentive: formatCurrency(item.financials?.paid_pigmy_incentive),
      additionalPendingAmount: formatCurrency(
        item.financials?.additional_pending_amount
      ),
      additionalCompletedAmount: formatCurrency(
        item.financials?.additional_completed_amount
      ),
      loanIncentivesRaw: item.business?.loan_incentives,
      advance: advanceDisplay,
      advanceIn: advanceInAmount,
      balance: /* @__PURE__ */ jsxDEV("span", { className: balanceColor + " font-bold", children: formatCurrency(balance) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
        lineNumber: 104,
        columnNumber: 7
      }, this),
      netPayableRaw: item.financials?.net_payable,
      standardDeductions: formatCurrency(item.financials?.standard_deductions),
      advanceRaw: advanceAmount,
      advanceInRaw: advanceInAmount,
      advanceCount,
      grossSalary: formatCurrency(item.financials?.gross_salary),
      otherPayments: item.financials?.other_payments,
      paidAmountRaw: item.financials?.paid_amount,
      targetRaw: item.business?.target,
      businessClosedRaw: item.business?.totalBusinessClosed,
      achievementRaw: item.business?.achievement,
      incentiveRaw: item.business?.incentive_earned,
      balanceRaw: balance,
      details: item,
      monthlyBalance: formatCurrency(Math.abs(monthlyBalance))
    };
  });
};
const filterTableData = (data, searchText) => {
  if (!searchText) return data;
  const lowerSearchText = searchText.toLowerCase();
  return data.filter(
    (item) => Object.values(item).some(
      (val) => (typeof val === "string" || typeof val === "number") && val.toString().toLowerCase().includes(lowerSearchText)
    )
  );
};
const NAV_LINKS = [
  {
    to: "/payment-menu/payment-in-out-menu/pay-out-menu/salary-payment",
    icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { size: 16 }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
      lineNumber: 143,
      columnNumber: 9
    }, this),
    label: "Salary payment"
  },
  {
    to: "/staff-menu/employee-menu/salary-management",
    icon: /* @__PURE__ */ jsxDEV(MdOutlineMan, { size: 16 }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
      lineNumber: 148,
      columnNumber: 9
    }, this),
    label: "Salary management"
  },
  {
    to: "/payment-menu/payment-in-out-menu/pay-in-menu/advance-payment-in",
    icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { size: 16 }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
      lineNumber: 153,
      columnNumber: 9
    }, this),
    label: "Advance repayment"
  },
  {
    to: "/payment-menu/payment-in-out-menu/pay-out-menu/salary-incentive",
    icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { size: 16 }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
      lineNumber: 158,
      columnNumber: 9
    }, this),
    label: "Salary incentive"
  },
  {
    to: "/payment-menu/payment-in-out-menu/pay-out-menu/additional-salary",
    icon: /* @__PURE__ */ jsxDEV(RiMoneyRupeeCircleFill, { size: 16 }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
      lineNumber: 163,
      columnNumber: 9
    }, this),
    label: "Additional salary"
  }
];
const EmployeeStatement = () => {
  _s();
  const [employees, setEmployees] = useState([]);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [ledgerData, setLedgerData] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [overallNetPosition, setOverallNetPosition] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "",
    type: "info"
  });
  const [advanceDetails, setAdvanceDetails] = useState([]);
  const [showAdvanceDetails, setShowAdvanceDetails] = useState(false);
  const showAlert = (message, type = "error") => {
    setAlertConfig({ visibility: true, message, type });
  };
  const fetchEmployees = async () => {
    try {
      const response = await api.get("/employee");
      setEmployees(response.data?.employee || []);
    } catch (error) {
      showAlert(ALERT_MESSAGES.EMPLOYEE_FETCH_ERROR);
    }
  };
  const fetchLedgerData = async (employeeId) => {
    try {
      setIsLoading(true);
      const response = await api.get(`/employee/ledgernew/${employeeId}`);
      const ledger = response.data?.ledger || [];
      const advances = response.data?.advances || [];
      setOverallNetPosition(response.data?.overall_net_position);
      setTableData(formatLedgerData(ledger));
      setLedgerData(ledger);
      setAdvanceDetails(advances);
    } catch (error) {
      showAlert(ALERT_MESSAGES.LEDGER_FETCH_ERROR);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchEmployees();
  }, []);
  useEffect(() => {
    if (selectedEmployee) {
      fetchLedgerData(selectedEmployee);
    } else {
      setLedgerData([]);
      setTableData([]);
      setOverallNetPosition(null);
      setAdvanceDetails([]);
      setShowAdvanceDetails(false);
    }
  }, [selectedEmployee]);
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "month", header: "Month" },
    { key: "targetAmount", header: "Target" },
    { key: "businessClosed", header: "Business Closed" },
    { key: "achievement", header: "Achievement" },
    { key: "incentiveEarned", header: "Chit Incentive" },
    { key: "pigmyIncentives", header: "Pigmy Incentives" },
    { key: "loanIncentives", header: "Loan Incentives" },
    { key: "additionalPendingAmount", header: "Additional Salary" },
    { key: "grossSalary", header: "Gross Salary" },
    { key: "advance", header: "Advance" },
    { key: "advanceIn", header: "Advance Re-Payment" },
    { key: "standardDeductions", header: "Standard Deductions" },
    { key: "netPayable", header: "Net Payable" },
    { key: "paidChitIncentive", header: "Paid Chit Incentive" },
    { key: "paidPigmyIncentive", header: "Paid Pigmy Incentive" },
    { key: "paidLoanIncentive", header: "Paid Loan Incentive" },
    { key: "additionalCompletedAmount", header: "Paid Additional Salary" },
    { key: "paidAmount", header: "Paid Amount" },
    { key: "monthlyBalance", header: "Balance" },
    { key: "balance", header: "Running Balance" }
  ];
  const advanceColumns = [
    {
      title: "Date",
      dataIndex: "pay_date",
      key: "pay_date",
      render: (text) => new Date(text).toLocaleDateString()
    },
    {
      title: "Amount",
      dataIndex: "amount",
      key: "amount",
      render: (text) => formatCurrency(text)
    },
    {
      title: "Pay Type",
      dataIndex: "pay_type",
      key: "pay_type"
    },
    {
      title: "Transaction ID",
      dataIndex: "transaction_id",
      key: "transaction_id",
      render: (text) => text || "N/A"
    }
  ];
  const selectedEmployeeName = employees.find(
    (e) => e._id === selectedEmployee
  )?.name;
  const isPositive = overallNetPosition >= 0;
  const overview = ledgerData.reduce(
    (acc, item) => {
      acc.chitIncentive += Number(item.business?.incentive_earned || 0);
      acc.pigmyIncentive += Number(item.business?.pigmy_incentives || 0);
      acc.loanIncentive += Number(item.business?.loan_incentives || 0);
      acc.netPayable += Number(item.financials?.net_payable || 0);
      acc.paidChit += Number(item.financials?.paid_chit_incentive || 0);
      acc.paidPigmy += Number(item.financials?.paid_pigmy_incentive || 0);
      acc.paidLoan += Number(item.financials?.paid_loan_incentive || 0);
      return acc;
    },
    {
      chitIncentive: 0,
      pigmyIncentive: 0,
      loanIncentive: 0,
      netPayable: 0,
      paidChit: 0,
      paidPigmy: 0,
      paidLoan: 0
    }
  );
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        visibility: true,
        onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
        lineNumber: 316,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((p) => ({ ...p, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
        lineNumber: 320,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
        lineNumber: 328,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 overflow-x-hidden overflow-y-scroll bg-gray-50 min-h-screen", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
          lineNumber: 330,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row items-start sm:items-end gap-6 mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col w-full sm:w-72 ", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold flex items-center gap-2 text-gray-800 mb-4", children: [
            /* @__PURE__ */ jsxDEV(TeamOutlined, { className: "text-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
              lineNumber: 338,
              columnNumber: 17
            }, this),
            "Salary Ledger"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
            lineNumber: 337,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium text-gray-700 mb-1 ml-3", children: [
            "Select Employee ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
              lineNumber: 342,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
            lineNumber: 341,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              showSearch: true,
              size: "large",
              className: "w-full",
              placeholder: "Select employee",
              onChange: setSelectedEmployee,
              optionFilterProp: "label",
              filterOption: (input, option) => option.label.toLowerCase().includes(input.toLowerCase()),
              options: employees.map((emp) => ({
                value: emp._id,
                label: `${emp.name} (${emp.phone_number})`
              }))
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
              lineNumber: 345,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
          lineNumber: 336,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
          lineNumber: 333,
          columnNumber: 11
        }, this),
        selectedEmployee ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
          overallNetPosition !== null && /* @__PURE__ */ jsxDEV("div", { className: "mb-6 space-y-6", children: [
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `rounded-xl border-l-4 p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 ${isPositive ? "bg-green-50 border-green-500" : "bg-red-50 border-red-500"}`,
                children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-widest text-gray-500 mb-1", children: "Overall Net Position" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 376,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "p",
                      {
                        className: `text-3xl font-bold ${isPositive ? "text-green-700" : "text-red-700"}`,
                        children: formatCurrency(overallNetPosition)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                        lineNumber: 380,
                        columnNumber: 23
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "p",
                      {
                        className: `text-sm mt-1 font-medium flex items-center gap-1 ${isPositive ? "text-green-600" : "text-red-600"}`,
                        children: [
                          isPositive ? /* @__PURE__ */ jsxDEV(ArrowUpOutlined, {}, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                            lineNumber: 391,
                            columnNumber: 39
                          }, this) : /* @__PURE__ */ jsxDEV(ArrowDownOutlined, {}, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                            lineNumber: 391,
                            columnNumber: 61
                          }, this),
                          isPositive ? "Amount to be paid by company" : "Excess paid / advance due"
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                        lineNumber: 387,
                        columnNumber: 23
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                    lineNumber: 375,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-500", children: [
                    "Final closing balance across all periods for",
                    " ",
                    /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700", children: selectedEmployeeName }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 400,
                      columnNumber: 23
                    }, this),
                    "."
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                    lineNumber: 398,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                lineNumber: 369,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-6", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow border p-5", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-blue-700 mb-4", children: "Chit Incentive" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                  lineNumber: 412,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                    /* @__PURE__ */ jsxDEV("span", { children: "Total" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 418,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-blue-600", children: formatCurrency(overview.chitIncentive) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 419,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                    lineNumber: 417,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                    /* @__PURE__ */ jsxDEV("span", { children: "Paid" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 425,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-cyan-600", children: formatCurrency(overview.paidChit) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 426,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                    lineNumber: 424,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                    lineNumber: 431,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Remaining" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 434,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-orange-600", children: formatCurrency(
                      (overview.chitIncentive || 0) - (overview.paidChit || 0)
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 435,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                    lineNumber: 433,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                  lineNumber: 416,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                lineNumber: 411,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow border p-5", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-green-700 mb-4", children: "Pigmy Incentive" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                  lineNumber: 446,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                    /* @__PURE__ */ jsxDEV("span", { children: "Total" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 452,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-green-600", children: formatCurrency(overview.pigmyIncentive) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 453,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                    lineNumber: 451,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                    /* @__PURE__ */ jsxDEV("span", { children: "Paid" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 459,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-emerald-600", children: formatCurrency(overview.paidPigmy) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 460,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                    lineNumber: 458,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                    lineNumber: 465,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Remaining" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 468,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-orange-600", children: formatCurrency(
                      (overview.pigmyIncentive || 0) - (overview.paidPigmy || 0)
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 469,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                    lineNumber: 467,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                  lineNumber: 450,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                lineNumber: 445,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow border p-5", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-purple-700 mb-4", children: "Loan Incentive" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                  lineNumber: 480,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                    /* @__PURE__ */ jsxDEV("span", { children: "Total" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 486,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-purple-600", children: formatCurrency(overview.loanIncentive) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 487,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                    lineNumber: 485,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                    /* @__PURE__ */ jsxDEV("span", { children: "Paid" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 493,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-pink-600", children: formatCurrency(overview.paidLoan) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 494,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                    lineNumber: 492,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                    lineNumber: 499,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Remaining" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 502,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-orange-600", children: formatCurrency(
                      (overview.loanIncentive || 0) - (overview.paidLoan || 0)
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 503,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                    lineNumber: 501,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                  lineNumber: 484,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                lineNumber: 479,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
              lineNumber: 408,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
            lineNumber: 366,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("section", { className: "mb-6", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold uppercase tracking-widest text-gray-400 mb-3", children: "Quick navigator" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
              lineNumber: 518,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: NAV_LINKS.map(
              (link) => /* @__PURE__ */ jsxDEV(
                Link,
                {
                  to: link.to,
                  className: "flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-600 hover:border-blue-400 hover:text-blue-600 hover:bg-blue-50 transition-all",
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-blue-500", children: link.icon }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                      lineNumber: 528,
                      columnNumber: 23
                    }, this),
                    link.label
                  ]
                },
                link.to,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
                  lineNumber: 523,
                  columnNumber: 17
                },
                this
              )
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
              lineNumber: 521,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
            lineNumber: 517,
            columnNumber: 15
          }, this),
          tableData.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl border border-gray-200 overflow-hidden", children: /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: filterTableData(tableData, searchText),
              columns,
              exportedPdfName: `Salary Statement: ${selectedEmployeeName}`,
              exportedFileName: `Salary Statement ${selectedEmployeeName}`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
              lineNumber: 538,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
            lineNumber: 537,
            columnNumber: 13
          }, this) : /* @__PURE__ */ jsxDEV(
            CircularLoader,
            {
              isLoading,
              failure: tableData.length === 0 && !isLoading,
              data: "Ledger Data"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
              lineNumber: 546,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
          lineNumber: 364,
          columnNumber: 11
        }, this) : (
          /* ── Empty state ── */
          /* @__PURE__ */ jsxDEV("div", { className: "text-center py-24 bg-white rounded-2xl border-2 border-dashed border-gray-200", children: [
            /* @__PURE__ */ jsxDEV(TeamOutlined, { className: "text-5xl text-gray-300 mb-4 block" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
              lineNumber: 556,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Title, { level: 4, className: "text-gray-500", children: "No employee selected" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
              lineNumber: 557,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Text, { className: "text-gray-400", children: "Select an employee from the dropdown above to view their financial history." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
              lineNumber: 560,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
            lineNumber: 555,
            columnNumber: 11
          }, this)
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 flex items-center gap-2 bg-blue-50 border border-blue-100 rounded-lg px-4 py-3 text-sm text-blue-700", children: [
          /* @__PURE__ */ jsxDEV(InfoCircleOutlined, { className: "flex-shrink-0" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
            lineNumber: 569,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "Running balance:" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
              lineNumber: 571,
              columnNumber: 15
            }, this),
            " Positive (+) means company owes employee · Negative (−) means employee has taken excess / advance."
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
            lineNumber: 570,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
          lineNumber: 568,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
        lineNumber: 329,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
      lineNumber: 327,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx",
    lineNumber: 315,
    columnNumber: 5
  }, this);
};
_s(EmployeeStatement, "hLN1FoBTr6iEpJedzm+wLs38x4w=");
_c = EmployeeStatement;
export default EmployeeStatement;
var _c;
$RefreshReg$(_c, "EmployeeStatement");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeStatement.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUR3QixTQW9UWixVQXBUWTsyQkF2RHhCO0FBQW9CQSxvQkFBZ0IsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzQyxTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLFFBQVFDLEtBQUtDLE9BQU9DLFlBQVlDLE9BQU9DLGNBQWM7QUFDOUQ7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLDhCQUE4QjtBQUV2QyxPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsdUJBQXVCO0FBQzlCLE9BQU9DLFNBQVM7QUFFaEIsU0FBU0MsbUJBQW1CO0FBQzVCLE9BQU9DLGdCQUFnQjtBQUN2QixTQUFTQyxjQUFjO0FBRXZCLE1BQU0sRUFBRUMsTUFBTUMsTUFBTSxJQUFJMUI7QUFHeEIsTUFBTTJCLGlCQUFpQjtBQUFBLEVBQ3JCQyxzQkFBc0I7QUFBQSxFQUN0QkMsb0JBQW9CO0FBQ3RCO0FBRUEsTUFBTUMsMEJBQTBCO0FBQUEsRUFDOUJDLE9BQU87QUFBQSxFQUNQQyxVQUFVO0FBQUEsRUFDVkMsdUJBQXVCO0FBQUEsRUFDdkJDLHVCQUF1QjtBQUN6QjtBQUdBLE1BQU1DLGlCQUFpQkEsQ0FBQ0MsV0FBVztBQUNqQyxTQUFPQSxRQUFRQyxlQUFlLFNBQVNQLHVCQUF1QjtBQUNoRTtBQUVBLE1BQU1RLG9CQUFvQkEsQ0FBQ0MsV0FBVztBQUNwQyxRQUFNQyxZQUFZRCxXQUFXO0FBQzdCLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLE9BQU9DLFlBQVksVUFBVTtBQUFBLE1BQzdCLE1BQU1BLFlBQVksdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQixJQUFNLHVCQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0I7QUFBQSxNQUUvREQ7QUFBQUE7QUFBQUEsSUFKSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFLQTtBQUVKO0FBRUEsTUFBTUUsbUJBQW1CQSxDQUFDQyxXQUFXO0FBQ25DLFNBQU9BLE9BQU9DLElBQUksQ0FBQ0MsTUFBTUMsVUFBVTtBQUNqQyxVQUFNQyxVQUFVRixLQUFLRyxZQUFZQywyQkFBMkI7QUFDNUQsVUFBTUMsZUFBZUgsV0FBVyxJQUFJLG1CQUFtQjtBQUN2RCxVQUFNSSxnQkFBZ0JOLEtBQUtHLFlBQVlJLGtCQUFrQjtBQUN6RCxVQUFNQyxlQUFlUixLQUFLRyxZQUFZTSxpQkFBaUI7QUFDdkQsVUFBTUMsa0JBQWtCVixLQUFLRyxZQUFZUSw2QkFBNkI7QUFFdEUsVUFBTUMsaUJBQ0pKLGVBQWUsSUFDWCxHQUFHakIsZUFBZWUsYUFBYSxDQUFDLEtBQ2hDZixlQUFlZSxhQUFhO0FBQ2xDLFVBQU1PLGlCQUNKQyxPQUFPZCxLQUFLRyxZQUFZQywyQkFBMkIsQ0FBQyxJQUNwRFUsT0FBT2QsS0FBS0csWUFBWVksb0JBQW9CLENBQUM7QUFFL0MsV0FBTztBQUFBLE1BQ0xDLElBQUlmLFFBQVE7QUFBQSxNQUNaZ0IsT0FBT2pCLEtBQUtrQjtBQUFBQSxNQUNaQyxZQUFZNUIsZUFBZVMsS0FBS0csWUFBWWlCLFdBQVc7QUFBQSxNQUN2REMsWUFBWTlCLGVBQWVTLEtBQUtHLFlBQVltQixXQUFXO0FBQUEsTUFDdkRDLGNBQWNoQyxlQUFlUyxLQUFLd0IsVUFBVUMsTUFBTTtBQUFBLE1BQ2xEQyxnQkFBZ0JuQyxlQUFlUyxLQUFLd0IsVUFBVUcsbUJBQW1CO0FBQUEsTUFDakVDLGFBQWFsQyxrQkFBa0JNLEtBQUt3QixVQUFVSSxXQUFXO0FBQUEsTUFDekRDLGlCQUFpQnRDLGVBQWVTLEtBQUt3QixVQUFVTSxnQkFBZ0I7QUFBQSxNQUMvREMsaUJBQWlCeEMsZUFBZVMsS0FBS3dCLFVBQVVRLGdCQUFnQjtBQUFBLE1BQy9EQyxvQkFBb0JqQyxLQUFLd0IsVUFBVVE7QUFBQUEsTUFDbkNFLGdCQUFnQjNDLGVBQWVTLEtBQUt3QixVQUFVVyxlQUFlO0FBQUEsTUFDN0RDLG1CQUFtQjdDLGVBQWVTLEtBQUtHLFlBQVlrQyxtQkFBbUI7QUFBQSxNQUN0RUMsbUJBQW1CL0MsZUFBZVMsS0FBS0csWUFBWW9DLG1CQUFtQjtBQUFBLE1BQ3RFQyxvQkFBb0JqRCxlQUFlUyxLQUFLRyxZQUFZc0Msb0JBQW9CO0FBQUEsTUFDeEVDLHlCQUF5Qm5EO0FBQUFBLFFBQ3ZCUyxLQUFLRyxZQUFZd0M7QUFBQUEsTUFDbkI7QUFBQSxNQUNBQywyQkFBMkJyRDtBQUFBQSxRQUN6QlMsS0FBS0csWUFBWTBDO0FBQUFBLE1BQ25CO0FBQUEsTUFDQUMsbUJBQW1COUMsS0FBS3dCLFVBQVVXO0FBQUFBLE1BQ2xDWSxTQUFTbkM7QUFBQUEsTUFDVG9DLFdBQVd0QztBQUFBQSxNQUNYUixTQUNFLHVCQUFDLFVBQUssV0FBV0csZUFBZSxjQUM3QmQseUJBQWVXLE9BQU8sS0FEekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFRitDLGVBQWVqRCxLQUFLRyxZQUFZaUI7QUFBQUEsTUFDaEM4QixvQkFBb0IzRCxlQUFlUyxLQUFLRyxZQUFZZ0QsbUJBQW1CO0FBQUEsTUFDdkVDLFlBQVk5QztBQUFBQSxNQUNaK0MsY0FBYzNDO0FBQUFBLE1BQ2RGO0FBQUFBLE1BQ0E4QyxhQUFhL0QsZUFBZVMsS0FBS0csWUFBWW9ELFlBQVk7QUFBQSxNQUN6REMsZUFBZXhELEtBQUtHLFlBQVlzRDtBQUFBQSxNQUNoQ0MsZUFBZTFELEtBQUtHLFlBQVltQjtBQUFBQSxNQUNoQ3FDLFdBQVczRCxLQUFLd0IsVUFBVUM7QUFBQUEsTUFDMUJtQyxtQkFBbUI1RCxLQUFLd0IsVUFBVUc7QUFBQUEsTUFDbENrQyxnQkFBZ0I3RCxLQUFLd0IsVUFBVUk7QUFBQUEsTUFDL0JrQyxjQUFjOUQsS0FBS3dCLFVBQVVNO0FBQUFBLE1BQzdCaUMsWUFBWTdEO0FBQUFBLE1BQ1o4RCxTQUFTaEU7QUFBQUEsTUFDVGEsZ0JBQWdCdEIsZUFBZTBFLEtBQUtDLElBQUlyRCxjQUFjLENBQUM7QUFBQSxJQUN6RDtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBRUEsTUFBTXNELGtCQUFrQkEsQ0FBQ0MsTUFBTUMsZUFBZTtBQUM1QyxNQUFJLENBQUNBLFdBQVksUUFBT0Q7QUFDeEIsUUFBTUUsa0JBQWtCRCxXQUFXRSxZQUFZO0FBQy9DLFNBQU9ILEtBQUtJO0FBQUFBLElBQU8sQ0FBQ3hFLFNBQ2xCeUUsT0FBT0MsT0FBTzFFLElBQUksRUFBRTJFO0FBQUFBLE1BQ2xCLENBQUNDLFNBQ0UsT0FBT0EsUUFBUSxZQUFZLE9BQU9BLFFBQVEsYUFDM0NBLElBQUlDLFNBQVMsRUFBRU4sWUFBWSxFQUFFTyxTQUFTUixlQUFlO0FBQUEsSUFDekQ7QUFBQSxFQUNGO0FBQ0Y7QUFHQSxNQUFNUyxZQUFZO0FBQUEsRUFDaEI7QUFBQSxJQUNFQyxJQUFJO0FBQUEsSUFDSkMsTUFBTSx1QkFBQywwQkFBdUIsTUFBTSxNQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDO0FBQUEsSUFDdkNDLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFDQTtBQUFBLElBQ0VGLElBQUk7QUFBQSxJQUNKQyxNQUFNLHVCQUFDLGdCQUFhLE1BQU0sTUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF1QjtBQUFBLElBQzdCQyxPQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0E7QUFBQSxJQUNFRixJQUFJO0FBQUEsSUFDSkMsTUFBTSx1QkFBQywwQkFBdUIsTUFBTSxNQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDO0FBQUEsSUFDdkNDLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFDQTtBQUFBLElBQ0VGLElBQUk7QUFBQSxJQUNKQyxNQUFNLHVCQUFDLDBCQUF1QixNQUFNLE1BQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUM7QUFBQSxJQUN2Q0MsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBO0FBQUEsSUFDRUYsSUFBSTtBQUFBLElBQ0pDLE1BQU0sdUJBQUMsMEJBQXVCLE1BQU0sTUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpQztBQUFBLElBQ3ZDQyxPQUFPO0FBQUEsRUFDVDtBQUFDO0FBR0gsTUFBTUMsb0JBQW9CQSxNQUFNO0FBQUFDLEtBQUE7QUFDOUIsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUl2SSxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDd0ksa0JBQWtCQyxtQkFBbUIsSUFBSXpJLFNBQVMsSUFBSTtBQUM3RCxRQUFNLENBQUMwSSxZQUFZQyxhQUFhLElBQUkzSSxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDNEksV0FBV0MsWUFBWSxJQUFJN0ksU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQzhJLG9CQUFvQkMscUJBQXFCLElBQUkvSSxTQUFTLElBQUk7QUFDakUsUUFBTSxDQUFDZ0osV0FBV0MsWUFBWSxJQUFJakosU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3NILFlBQVk0QixhQUFhLElBQUlsSixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDbUosYUFBYUMsY0FBYyxJQUFJcEosU0FBUztBQUFBLElBQzdDcUosWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxnQkFBZ0JDLGlCQUFpQixJQUFJekosU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQzBKLG9CQUFvQkMscUJBQXFCLElBQUkzSixTQUFTLEtBQUs7QUFFbEUsUUFBTTRKLFlBQVlBLENBQUNOLFNBQVNDLE9BQU8sWUFBWTtBQUM3Q0gsbUJBQWUsRUFBRUMsWUFBWSxNQUFNQyxTQUFTQyxLQUFLLENBQUM7QUFBQSxFQUNwRDtBQUVBLFFBQU1NLGlCQUFpQixZQUFZO0FBQ2pDLFFBQUk7QUFDRixZQUFNQyxXQUFXLE1BQU1wSSxJQUFJcUksSUFBSSxXQUFXO0FBQzFDeEIsbUJBQWF1QixTQUFTekMsTUFBTTJDLFlBQVksRUFBRTtBQUFBLElBQzVDLFNBQVNDLE9BQU87QUFDZEwsZ0JBQVU1SCxlQUFlQyxvQkFBb0I7QUFBQSxJQUMvQztBQUFBLEVBQ0Y7QUFFQSxRQUFNaUksa0JBQWtCLE9BQU9DLGVBQWU7QUFDNUMsUUFBSTtBQUNGbEIsbUJBQWEsSUFBSTtBQUNqQixZQUFNYSxXQUFXLE1BQU1wSSxJQUFJcUksSUFBSSx1QkFBdUJJLFVBQVUsRUFBRTtBQUNsRSxZQUFNcEgsU0FBUytHLFNBQVN6QyxNQUFNdEUsVUFBVTtBQUN4QyxZQUFNcUgsV0FBV04sU0FBU3pDLE1BQU0rQyxZQUFZO0FBRTVDckIsNEJBQXNCZSxTQUFTekMsTUFBTWdELG9CQUFvQjtBQUN6RHhCLG1CQUFhL0YsaUJBQWlCQyxNQUFNLENBQUM7QUFDckM0RixvQkFBYzVGLE1BQU07QUFDcEIwRyx3QkFBa0JXLFFBQVE7QUFBQSxJQUM1QixTQUFTSCxPQUFPO0FBQ2RMLGdCQUFVNUgsZUFBZUUsa0JBQWtCO0FBQUEsSUFDN0MsVUFBQztBQUNDK0csbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBcUIsWUFBVSxNQUFNO0FBQ2RULG1CQUFlO0FBQUEsRUFDakIsR0FBRyxFQUFFO0FBRUxTLFlBQVUsTUFBTTtBQUNkLFFBQUk5QixrQkFBa0I7QUFDcEIwQixzQkFBZ0IxQixnQkFBZ0I7QUFBQSxJQUNsQyxPQUFPO0FBQ0xHLG9CQUFjLEVBQUU7QUFDaEJFLG1CQUFhLEVBQUU7QUFDZkUsNEJBQXNCLElBQUk7QUFDMUJVLHdCQUFrQixFQUFFO0FBQ3BCRSw0QkFBc0IsS0FBSztBQUFBLElBQzdCO0FBQUEsRUFDRixHQUFHLENBQUNuQixnQkFBZ0IsQ0FBQztBQUVyQixRQUFNK0IsVUFBVTtBQUFBLElBQ2QsRUFBRUMsS0FBSyxNQUFNM0ksUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRTJJLEtBQUssU0FBUzNJLFFBQVEsUUFBUTtBQUFBLElBQ2hDLEVBQUUySSxLQUFLLGdCQUFnQjNJLFFBQVEsU0FBUztBQUFBLElBQ3hDLEVBQUUySSxLQUFLLGtCQUFrQjNJLFFBQVEsa0JBQWtCO0FBQUEsSUFDbkQsRUFBRTJJLEtBQUssZUFBZTNJLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUUySSxLQUFLLG1CQUFtQjNJLFFBQVEsaUJBQWlCO0FBQUEsSUFDbkQsRUFBRTJJLEtBQUssbUJBQW1CM0ksUUFBUSxtQkFBbUI7QUFBQSxJQUNyRCxFQUFFMkksS0FBSyxrQkFBa0IzSSxRQUFRLGtCQUFrQjtBQUFBLElBQ25ELEVBQUUySSxLQUFLLDJCQUEyQjNJLFFBQVEsb0JBQW9CO0FBQUEsSUFDOUQsRUFBRTJJLEtBQUssZUFBZTNJLFFBQVEsZUFBZTtBQUFBLElBQzdDLEVBQUUySSxLQUFLLFdBQVczSSxRQUFRLFVBQVU7QUFBQSxJQUNwQyxFQUFFMkksS0FBSyxhQUFhM0ksUUFBUSxxQkFBcUI7QUFBQSxJQUNqRCxFQUFFMkksS0FBSyxzQkFBc0IzSSxRQUFRLHNCQUFzQjtBQUFBLElBQzNELEVBQUUySSxLQUFLLGNBQWMzSSxRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFMkksS0FBSyxxQkFBcUIzSSxRQUFRLHNCQUFzQjtBQUFBLElBQzFELEVBQUUySSxLQUFLLHNCQUFzQjNJLFFBQVEsdUJBQXVCO0FBQUEsSUFDNUQsRUFBRTJJLEtBQUsscUJBQXFCM0ksUUFBUSxzQkFBc0I7QUFBQSxJQUMxRCxFQUFFMkksS0FBSyw2QkFBNkIzSSxRQUFRLHlCQUF5QjtBQUFBLElBQ3JFLEVBQUUySSxLQUFLLGNBQWMzSSxRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFMkksS0FBSyxrQkFBa0IzSSxRQUFRLFVBQVU7QUFBQSxJQUMzQyxFQUFFMkksS0FBSyxXQUFXM0ksUUFBUSxrQkFBa0I7QUFBQSxFQUFDO0FBRy9DLFFBQU00SSxpQkFBaUI7QUFBQSxJQUNyQjtBQUFBLE1BQ0VDLE9BQU87QUFBQSxNQUNQQyxXQUFXO0FBQUEsTUFDWEgsS0FBSztBQUFBLE1BQ0xJLFFBQVFBLENBQUNDLFNBQVMsSUFBSUMsS0FBS0QsSUFBSSxFQUFFRSxtQkFBbUI7QUFBQSxJQUN0RDtBQUFBLElBQ0E7QUFBQSxNQUNFTCxPQUFPO0FBQUEsTUFDUEMsV0FBVztBQUFBLE1BQ1hILEtBQUs7QUFBQSxNQUNMSSxRQUFRQSxDQUFDQyxTQUFTckksZUFBZXFJLElBQUk7QUFBQSxJQUN2QztBQUFBLElBQ0E7QUFBQSxNQUNFSCxPQUFPO0FBQUEsTUFDUEMsV0FBVztBQUFBLE1BQ1hILEtBQUs7QUFBQSxJQUNQO0FBQUEsSUFDQTtBQUFBLE1BQ0VFLE9BQU87QUFBQSxNQUNQQyxXQUFXO0FBQUEsTUFDWEgsS0FBSztBQUFBLE1BQ0xJLFFBQVFBLENBQUNDLFNBQVNBLFFBQVE7QUFBQSxJQUM1QjtBQUFBLEVBQUM7QUFHSCxRQUFNRyx1QkFBdUIxQyxVQUFVMkM7QUFBQUEsSUFDckMsQ0FBQ0MsTUFBTUEsRUFBRUMsUUFBUTNDO0FBQUFBLEVBQ25CLEdBQUc0QztBQUVILFFBQU1DLGFBQWF2QyxzQkFBc0I7QUFDekMsUUFBTXdDLFdBQVc1QyxXQUFXNkM7QUFBQUEsSUFDMUIsQ0FBQ0MsS0FBS3ZJLFNBQVM7QUFDYnVJLFVBQUlDLGlCQUFpQjFILE9BQU9kLEtBQUt3QixVQUFVTSxvQkFBb0IsQ0FBQztBQUVoRXlHLFVBQUlFLGtCQUFrQjNILE9BQU9kLEtBQUt3QixVQUFVUSxvQkFBb0IsQ0FBQztBQUVqRXVHLFVBQUlHLGlCQUFpQjVILE9BQU9kLEtBQUt3QixVQUFVVyxtQkFBbUIsQ0FBQztBQUUvRG9HLFVBQUlwSCxjQUFjTCxPQUFPZCxLQUFLRyxZQUFZaUIsZUFBZSxDQUFDO0FBRTFEbUgsVUFBSUksWUFBWTdILE9BQU9kLEtBQUtHLFlBQVlrQyx1QkFBdUIsQ0FBQztBQUVoRWtHLFVBQUlLLGFBQWE5SCxPQUFPZCxLQUFLRyxZQUFZc0Msd0JBQXdCLENBQUM7QUFFbEU4RixVQUFJTSxZQUFZL0gsT0FBT2QsS0FBS0csWUFBWW9DLHVCQUF1QixDQUFDO0FBRWhFLGFBQU9nRztBQUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLE1BQ0VDLGVBQWU7QUFBQSxNQUNmQyxnQkFBZ0I7QUFBQSxNQUNoQkMsZUFBZTtBQUFBLE1BQ2Z2SCxZQUFZO0FBQUEsTUFDWndILFVBQVU7QUFBQSxNQUNWQyxXQUFXO0FBQUEsTUFDWEMsVUFBVTtBQUFBLElBQ1o7QUFBQSxFQUNGO0FBQ0EsU0FDRSx1QkFBQyxTQUNDO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFlBQVk7QUFBQSxRQUNaLDZCQUE2QixDQUFDWixNQUFNaEMsY0FBY2dDLEVBQUV4RyxPQUFPcUgsS0FBSztBQUFBO0FBQUEsTUFGbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRW9FO0FBQUEsSUFFcEU7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU01QyxZQUFZSTtBQUFBQSxRQUNsQixXQUFXSixZQUFZRTtBQUFBQSxRQUN2QixTQUFTRixZQUFZRztBQUFBQSxRQUNyQixTQUFTLE1BQU1GLGVBQWUsQ0FBQzRDLE9BQU8sRUFBRSxHQUFHQSxHQUFHM0MsWUFBWSxNQUFNLEVBQUU7QUFBQTtBQUFBLE1BSnBFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUlzRTtBQUFBLElBR3RFLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsNkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUNSLHVCQUFDLFNBQUksV0FBVSw2RUFDYjtBQUFBLCtCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVztBQUFBLFFBR1gsdUJBQUMsU0FBSSxXQUFVLGlFQUdiLGlDQUFDLFNBQUksV0FBVSxpQ0FDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSxvRUFDWjtBQUFBLG1DQUFDLGdCQUFhLFdBQVUsbUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVDO0FBQUEsWUFBRztBQUFBLGVBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSwrQ0FBOEM7QUFBQTtBQUFBLFlBQzdDLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQSxlQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0M7QUFBQSxjQUNBLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaLFVBQVVaO0FBQUFBLGNBQ1Ysa0JBQWlCO0FBQUEsY0FDakIsY0FBYyxDQUFDd0QsT0FBT0MsV0FDcEJBLE9BQU8vRCxNQUFNWCxZQUFZLEVBQUVPLFNBQVNrRSxNQUFNekUsWUFBWSxDQUFDO0FBQUEsY0FFekQsU0FBU2MsVUFBVXRGLElBQUksQ0FBQ21KLFNBQVM7QUFBQSxnQkFDL0JKLE9BQU9JLElBQUloQjtBQUFBQSxnQkFDWGhELE9BQU8sR0FBR2dFLElBQUlmLElBQUksS0FBS2UsSUFBSUMsWUFBWTtBQUFBLGNBQ3pDLEVBQUU7QUFBQTtBQUFBLFlBYko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBYU07QUFBQSxhQXRCUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBLEtBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0QkE7QUFBQSxRQUVDNUQsbUJBQ0MsbUNBQ0dNO0FBQUFBLGlDQUF1QixRQUN0Qix1QkFBQyxTQUFJLFdBQVUsa0JBR2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVcsZ0dBQWdHdUMsYUFDdkcsaUNBQ0EsMEJBQTBCO0FBQUEsZ0JBRzlCO0FBQUEseUNBQUMsU0FDQztBQUFBLDJDQUFDLE9BQUUsV0FBVSxzRUFBcUUsb0NBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFXLHNCQUFzQkEsYUFBYSxtQkFBbUIsY0FBYztBQUFBLHdCQUc5RTdJLHlCQUFlc0csa0JBQWtCO0FBQUE7QUFBQSxzQkFKcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsb0JBRUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVyxvREFBb0R1QyxhQUFhLG1CQUFtQixjQUFjO0FBQUEsd0JBRzVHQTtBQUFBQSx1Q0FBYSx1QkFBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFnQixJQUFNLHVCQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWtCO0FBQUEsMEJBQ3JEQSxhQUNHLGlDQUNBO0FBQUE7QUFBQTtBQUFBLHNCQVBOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFRQTtBQUFBLHVCQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXFCQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSx5QkFBd0I7QUFBQTtBQUFBLG9CQUNRO0FBQUEsb0JBQzdDLHVCQUFDLFVBQUssV0FBVSw2QkFDYkwsa0NBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUFPO0FBQUEsdUJBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBO0FBQUE7QUFBQSxjQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFvQ0E7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSx5Q0FHYjtBQUFBLHFDQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSw0Q0FBMkMsOEJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLDJDQUFDLFVBQUsscUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBVztBQUFBLG9CQUNYLHVCQUFDLFVBQUssV0FBVSwrQkFDYnhJLHlCQUFlOEksU0FBU0csYUFBYSxLQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLDJDQUFDLFVBQUssb0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBVTtBQUFBLG9CQUNWLHVCQUFDLFVBQUssV0FBVSwrQkFDYmpKLHlCQUFlOEksU0FBU00sUUFBUSxLQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGtCQUVBLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBRztBQUFBLGtCQUVILHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLDJDQUFDLFVBQUssV0FBVSxpQkFBZ0IseUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXlDO0FBQUEsb0JBQ3pDLHVCQUFDLFVBQUssV0FBVSw2QkFDYnBKO0FBQUFBLHVCQUNFOEksU0FBU0csaUJBQWlCLE1BQU1ILFNBQVNNLFlBQVk7QUFBQSxvQkFDeEQsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUlBO0FBQUEsdUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFPQTtBQUFBLHFCQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXlCQTtBQUFBLG1CQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQStCQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDZDQUE0QywrQkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsMkNBQUMsVUFBSyxxQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFXO0FBQUEsb0JBQ1gsdUJBQUMsVUFBSyxXQUFVLGdDQUNicEoseUJBQWU4SSxTQUFTSSxjQUFjLEtBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEsa0JBRUEsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsMkNBQUMsVUFBSyxvQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFVO0FBQUEsb0JBQ1YsdUJBQUMsVUFBSyxXQUFVLGtDQUNibEoseUJBQWU4SSxTQUFTTyxTQUFTLEtBRHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEsa0JBRUEsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFHO0FBQUEsa0JBRUgsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLGlCQUFnQix5QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBeUM7QUFBQSxvQkFDekMsdUJBQUMsVUFBSyxXQUFVLDZCQUNicko7QUFBQUEsdUJBQ0U4SSxTQUFTSSxrQkFBa0IsTUFBTUosU0FBU08sYUFBYTtBQUFBLG9CQUMxRCxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSUE7QUFBQSx1QkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU9BO0FBQUEscUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBeUJBO0FBQUEsbUJBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBK0JBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsOENBQTZDLDhCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSwyQ0FBQyxVQUFLLHFCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQVc7QUFBQSxvQkFDWCx1QkFBQyxVQUFLLFdBQVUsaUNBQ2JySix5QkFBZThJLFNBQVNLLGFBQWEsS0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSwyQ0FBQyxVQUFLLG9CQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQVU7QUFBQSxvQkFDVix1QkFBQyxVQUFLLFdBQVUsK0JBQ2JuSix5QkFBZThJLFNBQVNRLFFBQVEsS0FEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxrQkFFQSx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQUc7QUFBQSxrQkFFSCx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsaUJBQWdCLHlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF5QztBQUFBLG9CQUN6Qyx1QkFBQyxVQUFLLFdBQVUsNkJBQ2J0SjtBQUFBQSx1QkFDRThJLFNBQVNLLGlCQUFpQixNQUFNTCxTQUFTUSxZQUFZO0FBQUEsb0JBQ3hELEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFJQTtBQUFBLHVCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBT0E7QUFBQSxxQkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF5QkE7QUFBQSxtQkE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkErQkE7QUFBQSxpQkF0R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF3R0E7QUFBQSxlQWxKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1KQTtBQUFBLFVBSUYsdUJBQUMsYUFBUSxXQUFVLFFBQ2pCO0FBQUEsbUNBQUMsT0FBRSxXQUFVLHNFQUFxRSwrQkFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNaOUQsb0JBQVVoRjtBQUFBQSxjQUFJLENBQUNxSixTQUNkO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUVDLElBQUlBLEtBQUtwRTtBQUFBQSxrQkFDVCxXQUFVO0FBQUEsa0JBRVY7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsaUJBQWlCb0UsZUFBS25FLFFBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJDO0FBQUEsb0JBQzFDbUUsS0FBS2xFO0FBQUFBO0FBQUFBO0FBQUFBLGdCQUxEa0UsS0FBS3BFO0FBQUFBLGdCQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQTtBQUFBLFlBQ0QsS0FWSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVdBO0FBQUEsZUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLFVBR0NXLFVBQVUwRCxTQUFTLEtBQUssQ0FBQ3RELFlBQ3hCLHVCQUFDLFNBQUksV0FBVSw4REFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTTVCLGdCQUFnQndCLFdBQVd0QixVQUFVO0FBQUEsY0FDM0M7QUFBQSxjQUNBLGlCQUFpQixxQkFBcUIwRCxvQkFBb0I7QUFBQSxjQUMxRCxrQkFBa0Isb0JBQW9CQSxvQkFBb0I7QUFBQTtBQUFBLFlBSjVEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUkrRCxLQUxqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BLElBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDO0FBQUEsY0FDQSxTQUFTcEMsVUFBVTBELFdBQVcsS0FBSyxDQUFDdEQ7QUFBQUEsY0FDcEMsTUFBSztBQUFBO0FBQUEsWUFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFHb0I7QUFBQSxhQXpMeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRMQTtBQUFBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsaUZBQ2I7QUFBQSxtQ0FBQyxnQkFBYSxXQUFVLHVDQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRDtBQUFBLFlBQzNELHVCQUFDLFNBQU0sT0FBTyxHQUFHLFdBQVUsaUJBQWdCLG9DQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxRQUFLLFdBQVUsaUJBQWdCLDJGQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUE7QUFBQSxRQUlGLHVCQUFDLFNBQUksV0FBVSw2R0FDYjtBQUFBLGlDQUFDLHNCQUFtQixXQUFVLG1CQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QztBQUFBLFVBQzdDLHVCQUFDLFVBQ0M7QUFBQSxtQ0FBQyxZQUFPLGdDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdCO0FBQUEsWUFBUztBQUFBLGVBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFdBclBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzUEE7QUFBQSxTQXhQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeVBBO0FBQUEsT0FyUUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNRQTtBQUVKO0FBQUVYLEdBM1pJRCxtQkFBaUI7QUFBQW1FLEtBQWpCbkU7QUE2Wk4sZUFBZUE7QUFBa0IsSUFBQW1FO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkxpbmsiLCJTZWxlY3QiLCJUYWciLCJTcGFjZSIsIlR5cG9ncmFwaHkiLCJUYWJsZSIsIkJ1dHRvbiIsIlRlYW1PdXRsaW5lZCIsIlBsdXNDaXJjbGVPdXRsaW5lZCIsIk1pbnVzQ2lyY2xlT3V0bGluZWQiLCJDcmVkaXRDYXJkT3V0bGluZWQiLCJDaGVja0NpcmNsZU91dGxpbmVkIiwiQ2xvc2VDaXJjbGVPdXRsaW5lZCIsIkRvd25PdXRsaW5lZCIsIlVwT3V0bGluZWQiLCJJbmZvQ2lyY2xlT3V0bGluZWQiLCJBcnJvd1VwT3V0bGluZWQiLCJBcnJvd0Rvd25PdXRsaW5lZCIsIk1kT3V0bGluZU1hbiIsIlJpTW9uZXlSdXBlZUNpcmNsZUZpbGwiLCJTaWRlYmFyIiwiTmF2YmFyIiwiRGF0YVRhYmxlIiwiQ2lyY3VsYXJMb2FkZXIiLCJDdXN0b21BbGVydERpYWxvZyIsImFwaSIsIkZhUnVwZWVTaWduIiwiQnJlYWRjcnVtYiIsImhlYWRlciIsIlRleHQiLCJUaXRsZSIsIkFMRVJUX01FU1NBR0VTIiwiRU1QTE9ZRUVfRkVUQ0hfRVJST1IiLCJMRURHRVJfRkVUQ0hfRVJST1IiLCJDVVJSRU5DWV9GT1JNQVRfT1BUSU9OUyIsInN0eWxlIiwiY3VycmVuY3kiLCJtaW5pbXVtRnJhY3Rpb25EaWdpdHMiLCJtYXhpbXVtRnJhY3Rpb25EaWdpdHMiLCJmb3JtYXRDdXJyZW5jeSIsImFtb3VudCIsInRvTG9jYWxlU3RyaW5nIiwiZ2V0QWNoaWV2ZW1lbnRUYWciLCJzdGF0dXMiLCJpc1N1Y2Nlc3MiLCJmb3JtYXRMZWRnZXJEYXRhIiwibGVkZ2VyIiwibWFwIiwiaXRlbSIsImluZGV4IiwiYmFsYW5jZSIsImZpbmFuY2lhbHMiLCJjdXJyZW50X3J1bm5pbmdfYmFsYW5jZSIsImJhbGFuY2VDb2xvciIsImFkdmFuY2VBbW91bnQiLCJhZHZhbmNlX2Ftb3VudCIsImFkdmFuY2VDb3VudCIsImFkdmFuY2VfY291bnQiLCJhZHZhbmNlSW5BbW91bnQiLCJhZHZhbmNlX3BheW1lbnRfaW5fYW1vdW50IiwiYWR2YW5jZURpc3BsYXkiLCJtb250aGx5QmFsYW5jZSIsIk51bWJlciIsInByZXZpb3VzX2JhbGFuY2UiLCJpZCIsIm1vbnRoIiwicGVyaW9kIiwibmV0UGF5YWJsZSIsIm5ldF9wYXlhYmxlIiwicGFpZEFtb3VudCIsInBhaWRfYW1vdW50IiwidGFyZ2V0QW1vdW50IiwiYnVzaW5lc3MiLCJ0YXJnZXQiLCJidXNpbmVzc0Nsb3NlZCIsInRvdGFsQnVzaW5lc3NDbG9zZWQiLCJhY2hpZXZlbWVudCIsImluY2VudGl2ZUVhcm5lZCIsImluY2VudGl2ZV9lYXJuZWQiLCJwaWdteUluY2VudGl2ZXMiLCJwaWdteV9pbmNlbnRpdmVzIiwicGlnbXlJbmNlbnRpdmVzUmF3IiwibG9hbkluY2VudGl2ZXMiLCJsb2FuX2luY2VudGl2ZXMiLCJwYWlkQ2hpdEluY2VudGl2ZSIsInBhaWRfY2hpdF9pbmNlbnRpdmUiLCJwYWlkTG9hbkluY2VudGl2ZSIsInBhaWRfbG9hbl9pbmNlbnRpdmUiLCJwYWlkUGlnbXlJbmNlbnRpdmUiLCJwYWlkX3BpZ215X2luY2VudGl2ZSIsImFkZGl0aW9uYWxQZW5kaW5nQW1vdW50IiwiYWRkaXRpb25hbF9wZW5kaW5nX2Ftb3VudCIsImFkZGl0aW9uYWxDb21wbGV0ZWRBbW91bnQiLCJhZGRpdGlvbmFsX2NvbXBsZXRlZF9hbW91bnQiLCJsb2FuSW5jZW50aXZlc1JhdyIsImFkdmFuY2UiLCJhZHZhbmNlSW4iLCJuZXRQYXlhYmxlUmF3Iiwic3RhbmRhcmREZWR1Y3Rpb25zIiwic3RhbmRhcmRfZGVkdWN0aW9ucyIsImFkdmFuY2VSYXciLCJhZHZhbmNlSW5SYXciLCJncm9zc1NhbGFyeSIsImdyb3NzX3NhbGFyeSIsIm90aGVyUGF5bWVudHMiLCJvdGhlcl9wYXltZW50cyIsInBhaWRBbW91bnRSYXciLCJ0YXJnZXRSYXciLCJidXNpbmVzc0Nsb3NlZFJhdyIsImFjaGlldmVtZW50UmF3IiwiaW5jZW50aXZlUmF3IiwiYmFsYW5jZVJhdyIsImRldGFpbHMiLCJNYXRoIiwiYWJzIiwiZmlsdGVyVGFibGVEYXRhIiwiZGF0YSIsInNlYXJjaFRleHQiLCJsb3dlclNlYXJjaFRleHQiLCJ0b0xvd2VyQ2FzZSIsImZpbHRlciIsIk9iamVjdCIsInZhbHVlcyIsInNvbWUiLCJ2YWwiLCJ0b1N0cmluZyIsImluY2x1ZGVzIiwiTkFWX0xJTktTIiwidG8iLCJpY29uIiwibGFiZWwiLCJFbXBsb3llZVN0YXRlbWVudCIsIl9zIiwiZW1wbG95ZWVzIiwic2V0RW1wbG95ZWVzIiwic2VsZWN0ZWRFbXBsb3llZSIsInNldFNlbGVjdGVkRW1wbG95ZWUiLCJsZWRnZXJEYXRhIiwic2V0TGVkZ2VyRGF0YSIsInRhYmxlRGF0YSIsInNldFRhYmxlRGF0YSIsIm92ZXJhbGxOZXRQb3NpdGlvbiIsInNldE92ZXJhbGxOZXRQb3NpdGlvbiIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsInNldFNlYXJjaFRleHQiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwiYWR2YW5jZURldGFpbHMiLCJzZXRBZHZhbmNlRGV0YWlscyIsInNob3dBZHZhbmNlRGV0YWlscyIsInNldFNob3dBZHZhbmNlRGV0YWlscyIsInNob3dBbGVydCIsImZldGNoRW1wbG95ZWVzIiwicmVzcG9uc2UiLCJnZXQiLCJlbXBsb3llZSIsImVycm9yIiwiZmV0Y2hMZWRnZXJEYXRhIiwiZW1wbG95ZWVJZCIsImFkdmFuY2VzIiwib3ZlcmFsbF9uZXRfcG9zaXRpb24iLCJ1c2VFZmZlY3QiLCJjb2x1bW5zIiwia2V5IiwiYWR2YW5jZUNvbHVtbnMiLCJ0aXRsZSIsImRhdGFJbmRleCIsInJlbmRlciIsInRleHQiLCJEYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwic2VsZWN0ZWRFbXBsb3llZU5hbWUiLCJmaW5kIiwiZSIsIl9pZCIsIm5hbWUiLCJpc1Bvc2l0aXZlIiwib3ZlcnZpZXciLCJyZWR1Y2UiLCJhY2MiLCJjaGl0SW5jZW50aXZlIiwicGlnbXlJbmNlbnRpdmUiLCJsb2FuSW5jZW50aXZlIiwicGFpZENoaXQiLCJwYWlkUGlnbXkiLCJwYWlkTG9hbiIsInZhbHVlIiwicCIsImlucHV0Iiwib3B0aW9uIiwiZW1wIiwicGhvbmVfbnVtYmVyIiwibGluayIsImxlbmd0aCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkVtcGxveWVlU3RhdGVtZW50LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBTZWxlY3QsIFRhZywgU3BhY2UsIFR5cG9ncmFwaHksIFRhYmxlLCBCdXR0b24gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQge1xyXG4gIFRlYW1PdXRsaW5lZCxcclxuICBQbHVzQ2lyY2xlT3V0bGluZWQsXHJcbiAgTWludXNDaXJjbGVPdXRsaW5lZCxcclxuICBDcmVkaXRDYXJkT3V0bGluZWQsXHJcbiAgQ2hlY2tDaXJjbGVPdXRsaW5lZCxcclxuICBDbG9zZUNpcmNsZU91dGxpbmVkLFxyXG4gIERvd25PdXRsaW5lZCxcclxuICBVcE91dGxpbmVkLFxyXG4gIEluZm9DaXJjbGVPdXRsaW5lZCxcclxuICBBcnJvd1VwT3V0bGluZWQsXHJcbiAgQXJyb3dEb3duT3V0bGluZWQsXHJcbn0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcbmltcG9ydCB7IE1kT3V0bGluZU1hbiB9IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5pbXBvcnQgeyBSaU1vbmV5UnVwZWVDaXJjbGVGaWxsIH0gZnJvbSBcInJlYWN0LWljb25zL3JpXCI7XHJcblxyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydERpYWxvZyBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2dcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5cclxuaW1wb3J0IHsgRmFSdXBlZVNpZ24gfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IEJyZWFkY3J1bWIgZnJvbSBcIi4uL2hlbHBlcnMvQnJlYWRjcnVtYlwiO1xyXG5pbXBvcnQgeyBoZWFkZXIgfSBmcm9tIFwiZnJhbWVyLW1vdGlvbi9jbGllbnRcIjtcclxuXHJcbmNvbnN0IHsgVGV4dCwgVGl0bGUgfSA9IFR5cG9ncmFwaHk7XHJcblxyXG4vLyBDb25zdGFudHNcclxuY29uc3QgQUxFUlRfTUVTU0FHRVMgPSB7XHJcbiAgRU1QTE9ZRUVfRkVUQ0hfRVJST1I6IFwiRmFpbGVkIHRvIGxvYWQgZW1wbG95ZWVzXCIsXHJcbiAgTEVER0VSX0ZFVENIX0VSUk9SOiBcIkZhaWxlZCB0byBsb2FkIHNhbGFyeSBsZWRnZXJcIixcclxufTtcclxuXHJcbmNvbnN0IENVUlJFTkNZX0ZPUk1BVF9PUFRJT05TID0ge1xyXG4gIHN0eWxlOiBcImN1cnJlbmN5XCIsXHJcbiAgY3VycmVuY3k6IFwiSU5SXCIsXHJcbiAgbWluaW11bUZyYWN0aW9uRGlnaXRzOiAwLFxyXG4gIG1heGltdW1GcmFjdGlvbkRpZ2l0czogMCxcclxufTtcclxuXHJcbi8vIFV0aWxpdHkgRnVuY3Rpb25zXHJcbmNvbnN0IGZvcm1hdEN1cnJlbmN5ID0gKGFtb3VudCkgPT4ge1xyXG4gIHJldHVybiBhbW91bnQ/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIiwgQ1VSUkVOQ1lfRk9STUFUX09QVElPTlMpO1xyXG59O1xyXG5cclxuY29uc3QgZ2V0QWNoaWV2ZW1lbnRUYWcgPSAoc3RhdHVzKSA9PiB7XHJcbiAgY29uc3QgaXNTdWNjZXNzID0gc3RhdHVzID09PSBcIk1ldC9FeGNlZWRlZFwiO1xyXG4gIHJldHVybiAoXHJcbiAgICA8VGFnXHJcbiAgICAgIGNvbG9yPXtpc1N1Y2Nlc3MgPyBcImdyZWVuXCIgOiBcInJlZFwifVxyXG4gICAgICBpY29uPXtpc1N1Y2Nlc3MgPyA8Q2hlY2tDaXJjbGVPdXRsaW5lZCAvPiA6IDxDbG9zZUNpcmNsZU91dGxpbmVkIC8+fVxyXG4gICAgPlxyXG4gICAgICB7c3RhdHVzfVxyXG4gICAgPC9UYWc+XHJcbiAgKTtcclxufTtcclxuXHJcbmNvbnN0IGZvcm1hdExlZGdlckRhdGEgPSAobGVkZ2VyKSA9PiB7XHJcbiAgcmV0dXJuIGxlZGdlci5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XHJcbiAgICBjb25zdCBiYWxhbmNlID0gaXRlbS5maW5hbmNpYWxzPy5jdXJyZW50X3J1bm5pbmdfYmFsYW5jZSA/PyAwO1xyXG4gICAgY29uc3QgYmFsYW5jZUNvbG9yID0gYmFsYW5jZSA+PSAwID8gXCJ0ZXh0LWdyZWVuLTYwMFwiIDogXCJ0ZXh0LXJlZC02MDBcIjtcclxuICAgIGNvbnN0IGFkdmFuY2VBbW91bnQgPSBpdGVtLmZpbmFuY2lhbHM/LmFkdmFuY2VfYW1vdW50IHx8IDA7XHJcbiAgICBjb25zdCBhZHZhbmNlQ291bnQgPSBpdGVtLmZpbmFuY2lhbHM/LmFkdmFuY2VfY291bnQgfHwgMDtcclxuICAgIGNvbnN0IGFkdmFuY2VJbkFtb3VudCA9IGl0ZW0uZmluYW5jaWFscz8uYWR2YW5jZV9wYXltZW50X2luX2Ftb3VudCB8fCAwO1xyXG5cclxuICAgIGNvbnN0IGFkdmFuY2VEaXNwbGF5ID1cclxuICAgICAgYWR2YW5jZUNvdW50ID4gMVxyXG4gICAgICAgID8gYCR7Zm9ybWF0Q3VycmVuY3koYWR2YW5jZUFtb3VudCl9YFxyXG4gICAgICAgIDogZm9ybWF0Q3VycmVuY3koYWR2YW5jZUFtb3VudCk7XHJcbiAgICBjb25zdCBtb250aGx5QmFsYW5jZSA9XHJcbiAgICAgIE51bWJlcihpdGVtLmZpbmFuY2lhbHM/LmN1cnJlbnRfcnVubmluZ19iYWxhbmNlIHx8IDApIC1cclxuICAgICAgTnVtYmVyKGl0ZW0uZmluYW5jaWFscz8ucHJldmlvdXNfYmFsYW5jZSB8fCAwKTtcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICBtb250aDogaXRlbS5wZXJpb2QsXHJcbiAgICAgIG5ldFBheWFibGU6IGZvcm1hdEN1cnJlbmN5KGl0ZW0uZmluYW5jaWFscz8ubmV0X3BheWFibGUpLFxyXG4gICAgICBwYWlkQW1vdW50OiBmb3JtYXRDdXJyZW5jeShpdGVtLmZpbmFuY2lhbHM/LnBhaWRfYW1vdW50KSxcclxuICAgICAgdGFyZ2V0QW1vdW50OiBmb3JtYXRDdXJyZW5jeShpdGVtLmJ1c2luZXNzPy50YXJnZXQpLFxyXG4gICAgICBidXNpbmVzc0Nsb3NlZDogZm9ybWF0Q3VycmVuY3koaXRlbS5idXNpbmVzcz8udG90YWxCdXNpbmVzc0Nsb3NlZCksXHJcbiAgICAgIGFjaGlldmVtZW50OiBnZXRBY2hpZXZlbWVudFRhZyhpdGVtLmJ1c2luZXNzPy5hY2hpZXZlbWVudCksXHJcbiAgICAgIGluY2VudGl2ZUVhcm5lZDogZm9ybWF0Q3VycmVuY3koaXRlbS5idXNpbmVzcz8uaW5jZW50aXZlX2Vhcm5lZCksXHJcbiAgICAgIHBpZ215SW5jZW50aXZlczogZm9ybWF0Q3VycmVuY3koaXRlbS5idXNpbmVzcz8ucGlnbXlfaW5jZW50aXZlcyksXHJcbiAgICAgIHBpZ215SW5jZW50aXZlc1JhdzogaXRlbS5idXNpbmVzcz8ucGlnbXlfaW5jZW50aXZlcyxcclxuICAgICAgbG9hbkluY2VudGl2ZXM6IGZvcm1hdEN1cnJlbmN5KGl0ZW0uYnVzaW5lc3M/LmxvYW5faW5jZW50aXZlcyksXHJcbiAgICAgIHBhaWRDaGl0SW5jZW50aXZlOiBmb3JtYXRDdXJyZW5jeShpdGVtLmZpbmFuY2lhbHM/LnBhaWRfY2hpdF9pbmNlbnRpdmUpLFxyXG4gICAgICBwYWlkTG9hbkluY2VudGl2ZTogZm9ybWF0Q3VycmVuY3koaXRlbS5maW5hbmNpYWxzPy5wYWlkX2xvYW5faW5jZW50aXZlKSxcclxuICAgICAgcGFpZFBpZ215SW5jZW50aXZlOiBmb3JtYXRDdXJyZW5jeShpdGVtLmZpbmFuY2lhbHM/LnBhaWRfcGlnbXlfaW5jZW50aXZlKSxcclxuICAgICAgYWRkaXRpb25hbFBlbmRpbmdBbW91bnQ6IGZvcm1hdEN1cnJlbmN5KFxyXG4gICAgICAgIGl0ZW0uZmluYW5jaWFscz8uYWRkaXRpb25hbF9wZW5kaW5nX2Ftb3VudCxcclxuICAgICAgKSxcclxuICAgICAgYWRkaXRpb25hbENvbXBsZXRlZEFtb3VudDogZm9ybWF0Q3VycmVuY3koXHJcbiAgICAgICAgaXRlbS5maW5hbmNpYWxzPy5hZGRpdGlvbmFsX2NvbXBsZXRlZF9hbW91bnQsXHJcbiAgICAgICksXHJcbiAgICAgIGxvYW5JbmNlbnRpdmVzUmF3OiBpdGVtLmJ1c2luZXNzPy5sb2FuX2luY2VudGl2ZXMsXHJcbiAgICAgIGFkdmFuY2U6IGFkdmFuY2VEaXNwbGF5LFxyXG4gICAgICBhZHZhbmNlSW46IGFkdmFuY2VJbkFtb3VudCxcclxuICAgICAgYmFsYW5jZTogKFxyXG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YmFsYW5jZUNvbG9yICsgXCIgZm9udC1ib2xkXCJ9PlxyXG4gICAgICAgICAge2Zvcm1hdEN1cnJlbmN5KGJhbGFuY2UpfVxyXG4gICAgICAgIDwvc3Bhbj5cclxuICAgICAgKSxcclxuICAgICAgbmV0UGF5YWJsZVJhdzogaXRlbS5maW5hbmNpYWxzPy5uZXRfcGF5YWJsZSxcclxuICAgICAgc3RhbmRhcmREZWR1Y3Rpb25zOiBmb3JtYXRDdXJyZW5jeShpdGVtLmZpbmFuY2lhbHM/LnN0YW5kYXJkX2RlZHVjdGlvbnMpLFxyXG4gICAgICBhZHZhbmNlUmF3OiBhZHZhbmNlQW1vdW50LFxyXG4gICAgICBhZHZhbmNlSW5SYXc6IGFkdmFuY2VJbkFtb3VudCxcclxuICAgICAgYWR2YW5jZUNvdW50OiBhZHZhbmNlQ291bnQsXHJcbiAgICAgIGdyb3NzU2FsYXJ5OiBmb3JtYXRDdXJyZW5jeShpdGVtLmZpbmFuY2lhbHM/Lmdyb3NzX3NhbGFyeSksXHJcbiAgICAgIG90aGVyUGF5bWVudHM6IGl0ZW0uZmluYW5jaWFscz8ub3RoZXJfcGF5bWVudHMsXHJcbiAgICAgIHBhaWRBbW91bnRSYXc6IGl0ZW0uZmluYW5jaWFscz8ucGFpZF9hbW91bnQsXHJcbiAgICAgIHRhcmdldFJhdzogaXRlbS5idXNpbmVzcz8udGFyZ2V0LFxyXG4gICAgICBidXNpbmVzc0Nsb3NlZFJhdzogaXRlbS5idXNpbmVzcz8udG90YWxCdXNpbmVzc0Nsb3NlZCxcclxuICAgICAgYWNoaWV2ZW1lbnRSYXc6IGl0ZW0uYnVzaW5lc3M/LmFjaGlldmVtZW50LFxyXG4gICAgICBpbmNlbnRpdmVSYXc6IGl0ZW0uYnVzaW5lc3M/LmluY2VudGl2ZV9lYXJuZWQsXHJcbiAgICAgIGJhbGFuY2VSYXc6IGJhbGFuY2UsXHJcbiAgICAgIGRldGFpbHM6IGl0ZW0sXHJcbiAgICAgIG1vbnRobHlCYWxhbmNlOiBmb3JtYXRDdXJyZW5jeShNYXRoLmFicyhtb250aGx5QmFsYW5jZSkpLFxyXG4gICAgfTtcclxuICB9KTtcclxufTtcclxuXHJcbmNvbnN0IGZpbHRlclRhYmxlRGF0YSA9IChkYXRhLCBzZWFyY2hUZXh0KSA9PiB7XHJcbiAgaWYgKCFzZWFyY2hUZXh0KSByZXR1cm4gZGF0YTtcclxuICBjb25zdCBsb3dlclNlYXJjaFRleHQgPSBzZWFyY2hUZXh0LnRvTG93ZXJDYXNlKCk7XHJcbiAgcmV0dXJuIGRhdGEuZmlsdGVyKChpdGVtKSA9PlxyXG4gICAgT2JqZWN0LnZhbHVlcyhpdGVtKS5zb21lKFxyXG4gICAgICAodmFsKSA9PlxyXG4gICAgICAgICh0eXBlb2YgdmFsID09PSBcInN0cmluZ1wiIHx8IHR5cGVvZiB2YWwgPT09IFwibnVtYmVyXCIpICYmXHJcbiAgICAgICAgdmFsLnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhsb3dlclNlYXJjaFRleHQpLFxyXG4gICAgKSxcclxuICApO1xyXG59O1xyXG5cclxuLy8gUXVpY2sgbmF2aWdhdG9yIGxpbmsgZGF0YVxyXG5jb25zdCBOQVZfTElOS1MgPSBbXHJcbiAge1xyXG4gICAgdG86IFwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9zYWxhcnktcGF5bWVudFwiLFxyXG4gICAgaWNvbjogPFJpTW9uZXlSdXBlZUNpcmNsZUZpbGwgc2l6ZT17MTZ9IC8+LFxyXG4gICAgbGFiZWw6IFwiU2FsYXJ5IHBheW1lbnRcIixcclxuICB9LFxyXG4gIHtcclxuICAgIHRvOiBcIi9zdGFmZi1tZW51L2VtcGxveWVlLW1lbnUvc2FsYXJ5LW1hbmFnZW1lbnRcIixcclxuICAgIGljb246IDxNZE91dGxpbmVNYW4gc2l6ZT17MTZ9IC8+LFxyXG4gICAgbGFiZWw6IFwiU2FsYXJ5IG1hbmFnZW1lbnRcIixcclxuICB9LFxyXG4gIHtcclxuICAgIHRvOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktaW4tbWVudS9hZHZhbmNlLXBheW1lbnQtaW5cIixcclxuICAgIGljb246IDxSaU1vbmV5UnVwZWVDaXJjbGVGaWxsIHNpemU9ezE2fSAvPixcclxuICAgIGxhYmVsOiBcIkFkdmFuY2UgcmVwYXltZW50XCIsXHJcbiAgfSxcclxuICB7XHJcbiAgICB0bzogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LW91dC1tZW51L3NhbGFyeS1pbmNlbnRpdmVcIixcclxuICAgIGljb246IDxSaU1vbmV5UnVwZWVDaXJjbGVGaWxsIHNpemU9ezE2fSAvPixcclxuICAgIGxhYmVsOiBcIlNhbGFyeSBpbmNlbnRpdmVcIixcclxuICB9LFxyXG4gIHtcclxuICAgIHRvOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktb3V0LW1lbnUvYWRkaXRpb25hbC1zYWxhcnlcIixcclxuICAgIGljb246IDxSaU1vbmV5UnVwZWVDaXJjbGVGaWxsIHNpemU9ezE2fSAvPixcclxuICAgIGxhYmVsOiBcIkFkZGl0aW9uYWwgc2FsYXJ5XCIsXHJcbiAgfSxcclxuXTtcclxuXHJcbmNvbnN0IEVtcGxveWVlU3RhdGVtZW50ID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtlbXBsb3llZXMsIHNldEVtcGxveWVlc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkRW1wbG95ZWUsIHNldFNlbGVjdGVkRW1wbG95ZWVdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2xlZGdlckRhdGEsIHNldExlZGdlckRhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt0YWJsZURhdGEsIHNldFRhYmxlRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW292ZXJhbGxOZXRQb3NpdGlvbiwgc2V0T3ZlcmFsbE5ldFBvc2l0aW9uXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuICBjb25zdCBbYWR2YW5jZURldGFpbHMsIHNldEFkdmFuY2VEZXRhaWxzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2hvd0FkdmFuY2VEZXRhaWxzLCBzZXRTaG93QWR2YW5jZURldGFpbHNdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBzaG93QWxlcnQgPSAobWVzc2FnZSwgdHlwZSA9IFwiZXJyb3JcIikgPT4ge1xyXG4gICAgc2V0QWxlcnRDb25maWcoeyB2aXNpYmlsaXR5OiB0cnVlLCBtZXNzYWdlLCB0eXBlIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoRW1wbG95ZWVzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4gICAgICBzZXRFbXBsb3llZXMocmVzcG9uc2UuZGF0YT8uZW1wbG95ZWUgfHwgW10pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgc2hvd0FsZXJ0KEFMRVJUX01FU1NBR0VTLkVNUExPWUVFX0ZFVENIX0VSUk9SKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaExlZGdlckRhdGEgPSBhc3luYyAoZW1wbG95ZWVJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9lbXBsb3llZS9sZWRnZXJuZXcvJHtlbXBsb3llZUlkfWApO1xyXG4gICAgICBjb25zdCBsZWRnZXIgPSByZXNwb25zZS5kYXRhPy5sZWRnZXIgfHwgW107XHJcbiAgICAgIGNvbnN0IGFkdmFuY2VzID0gcmVzcG9uc2UuZGF0YT8uYWR2YW5jZXMgfHwgW107XHJcblxyXG4gICAgICBzZXRPdmVyYWxsTmV0UG9zaXRpb24ocmVzcG9uc2UuZGF0YT8ub3ZlcmFsbF9uZXRfcG9zaXRpb24pO1xyXG4gICAgICBzZXRUYWJsZURhdGEoZm9ybWF0TGVkZ2VyRGF0YShsZWRnZXIpKTtcclxuICAgICAgc2V0TGVkZ2VyRGF0YShsZWRnZXIpO1xyXG4gICAgICBzZXRBZHZhbmNlRGV0YWlscyhhZHZhbmNlcyk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzaG93QWxlcnQoQUxFUlRfTUVTU0FHRVMuTEVER0VSX0ZFVENIX0VSUk9SKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoRW1wbG95ZWVzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHNlbGVjdGVkRW1wbG95ZWUpIHtcclxuICAgICAgZmV0Y2hMZWRnZXJEYXRhKHNlbGVjdGVkRW1wbG95ZWUpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0TGVkZ2VyRGF0YShbXSk7XHJcbiAgICAgIHNldFRhYmxlRGF0YShbXSk7XHJcbiAgICAgIHNldE92ZXJhbGxOZXRQb3NpdGlvbihudWxsKTtcclxuICAgICAgc2V0QWR2YW5jZURldGFpbHMoW10pO1xyXG4gICAgICBzZXRTaG93QWR2YW5jZURldGFpbHMoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH0sIFtzZWxlY3RlZEVtcGxveWVlXSk7XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcIm1vbnRoXCIsIGhlYWRlcjogXCJNb250aFwiIH0sXHJcbiAgICB7IGtleTogXCJ0YXJnZXRBbW91bnRcIiwgaGVhZGVyOiBcIlRhcmdldFwiIH0sXHJcbiAgICB7IGtleTogXCJidXNpbmVzc0Nsb3NlZFwiLCBoZWFkZXI6IFwiQnVzaW5lc3MgQ2xvc2VkXCIgfSxcclxuICAgIHsga2V5OiBcImFjaGlldmVtZW50XCIsIGhlYWRlcjogXCJBY2hpZXZlbWVudFwiIH0sXHJcbiAgICB7IGtleTogXCJpbmNlbnRpdmVFYXJuZWRcIiwgaGVhZGVyOiBcIkNoaXQgSW5jZW50aXZlXCIgfSxcclxuICAgIHsga2V5OiBcInBpZ215SW5jZW50aXZlc1wiLCBoZWFkZXI6IFwiUGlnbXkgSW5jZW50aXZlc1wiIH0sXHJcbiAgICB7IGtleTogXCJsb2FuSW5jZW50aXZlc1wiLCBoZWFkZXI6IFwiTG9hbiBJbmNlbnRpdmVzXCIgfSxcclxuICAgIHsga2V5OiBcImFkZGl0aW9uYWxQZW5kaW5nQW1vdW50XCIsIGhlYWRlcjogXCJBZGRpdGlvbmFsIFNhbGFyeVwiIH0sXHJcbiAgICB7IGtleTogXCJncm9zc1NhbGFyeVwiLCBoZWFkZXI6IFwiR3Jvc3MgU2FsYXJ5XCIgfSxcclxuICAgIHsga2V5OiBcImFkdmFuY2VcIiwgaGVhZGVyOiBcIkFkdmFuY2VcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWR2YW5jZUluXCIsIGhlYWRlcjogXCJBZHZhbmNlIFJlLVBheW1lbnRcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhbmRhcmREZWR1Y3Rpb25zXCIsIGhlYWRlcjogXCJTdGFuZGFyZCBEZWR1Y3Rpb25zXCIgfSxcclxuICAgIHsga2V5OiBcIm5ldFBheWFibGVcIiwgaGVhZGVyOiBcIk5ldCBQYXlhYmxlXCIgfSxcclxuICAgIHsga2V5OiBcInBhaWRDaGl0SW5jZW50aXZlXCIsIGhlYWRlcjogXCJQYWlkIENoaXQgSW5jZW50aXZlXCIgfSxcclxuICAgIHsga2V5OiBcInBhaWRQaWdteUluY2VudGl2ZVwiLCBoZWFkZXI6IFwiUGFpZCBQaWdteSBJbmNlbnRpdmVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGFpZExvYW5JbmNlbnRpdmVcIiwgaGVhZGVyOiBcIlBhaWQgTG9hbiBJbmNlbnRpdmVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWRkaXRpb25hbENvbXBsZXRlZEFtb3VudFwiLCBoZWFkZXI6IFwiUGFpZCBBZGRpdGlvbmFsIFNhbGFyeVwiIH0sXHJcbiAgICB7IGtleTogXCJwYWlkQW1vdW50XCIsIGhlYWRlcjogXCJQYWlkIEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJtb250aGx5QmFsYW5jZVwiLCBoZWFkZXI6IFwiQmFsYW5jZVwiIH0sXHJcbiAgICB7IGtleTogXCJiYWxhbmNlXCIsIGhlYWRlcjogXCJSdW5uaW5nIEJhbGFuY2VcIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGFkdmFuY2VDb2x1bW5zID0gW1xyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJEYXRlXCIsXHJcbiAgICAgIGRhdGFJbmRleDogXCJwYXlfZGF0ZVwiLFxyXG4gICAgICBrZXk6IFwicGF5X2RhdGVcIixcclxuICAgICAgcmVuZGVyOiAodGV4dCkgPT4gbmV3IERhdGUodGV4dCkudG9Mb2NhbGVEYXRlU3RyaW5nKCksXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJBbW91bnRcIixcclxuICAgICAgZGF0YUluZGV4OiBcImFtb3VudFwiLFxyXG4gICAgICBrZXk6IFwiYW1vdW50XCIsXHJcbiAgICAgIHJlbmRlcjogKHRleHQpID0+IGZvcm1hdEN1cnJlbmN5KHRleHQpLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdGl0bGU6IFwiUGF5IFR5cGVcIixcclxuICAgICAgZGF0YUluZGV4OiBcInBheV90eXBlXCIsXHJcbiAgICAgIGtleTogXCJwYXlfdHlwZVwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdGl0bGU6IFwiVHJhbnNhY3Rpb24gSURcIixcclxuICAgICAgZGF0YUluZGV4OiBcInRyYW5zYWN0aW9uX2lkXCIsXHJcbiAgICAgIGtleTogXCJ0cmFuc2FjdGlvbl9pZFwiLFxyXG4gICAgICByZW5kZXI6ICh0ZXh0KSA9PiB0ZXh0IHx8IFwiTi9BXCIsXHJcbiAgICB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IHNlbGVjdGVkRW1wbG95ZWVOYW1lID0gZW1wbG95ZWVzLmZpbmQoXHJcbiAgICAoZSkgPT4gZS5faWQgPT09IHNlbGVjdGVkRW1wbG95ZWUsXHJcbiAgKT8ubmFtZTtcclxuXHJcbiAgY29uc3QgaXNQb3NpdGl2ZSA9IG92ZXJhbGxOZXRQb3NpdGlvbiA+PSAwO1xyXG4gIGNvbnN0IG92ZXJ2aWV3ID0gbGVkZ2VyRGF0YS5yZWR1Y2UoXHJcbiAgICAoYWNjLCBpdGVtKSA9PiB7XHJcbiAgICAgIGFjYy5jaGl0SW5jZW50aXZlICs9IE51bWJlcihpdGVtLmJ1c2luZXNzPy5pbmNlbnRpdmVfZWFybmVkIHx8IDApO1xyXG5cclxuICAgICAgYWNjLnBpZ215SW5jZW50aXZlICs9IE51bWJlcihpdGVtLmJ1c2luZXNzPy5waWdteV9pbmNlbnRpdmVzIHx8IDApO1xyXG5cclxuICAgICAgYWNjLmxvYW5JbmNlbnRpdmUgKz0gTnVtYmVyKGl0ZW0uYnVzaW5lc3M/LmxvYW5faW5jZW50aXZlcyB8fCAwKTtcclxuXHJcbiAgICAgIGFjYy5uZXRQYXlhYmxlICs9IE51bWJlcihpdGVtLmZpbmFuY2lhbHM/Lm5ldF9wYXlhYmxlIHx8IDApO1xyXG5cclxuICAgICAgYWNjLnBhaWRDaGl0ICs9IE51bWJlcihpdGVtLmZpbmFuY2lhbHM/LnBhaWRfY2hpdF9pbmNlbnRpdmUgfHwgMCk7XHJcblxyXG4gICAgICBhY2MucGFpZFBpZ215ICs9IE51bWJlcihpdGVtLmZpbmFuY2lhbHM/LnBhaWRfcGlnbXlfaW5jZW50aXZlIHx8IDApO1xyXG5cclxuICAgICAgYWNjLnBhaWRMb2FuICs9IE51bWJlcihpdGVtLmZpbmFuY2lhbHM/LnBhaWRfbG9hbl9pbmNlbnRpdmUgfHwgMCk7XHJcblxyXG4gICAgICByZXR1cm4gYWNjO1xyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgY2hpdEluY2VudGl2ZTogMCxcclxuICAgICAgcGlnbXlJbmNlbnRpdmU6IDAsXHJcbiAgICAgIGxvYW5JbmNlbnRpdmU6IDAsXHJcbiAgICAgIG5ldFBheWFibGU6IDAsXHJcbiAgICAgIHBhaWRDaGl0OiAwLFxyXG4gICAgICBwYWlkUGlnbXk6IDAsXHJcbiAgICAgIHBhaWRMb2FuOiAwLFxyXG4gICAgfVxyXG4gICk7XHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxOYXZiYXJcclxuICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17KGUpID0+IHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAvPlxyXG4gICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEFsZXJ0Q29uZmlnKChwKSA9PiAoeyAuLi5wLCB2aXNpYmlsaXR5OiBmYWxzZSB9KSl9XHJcbiAgICAgIC8+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtNyBvdmVyZmxvdy14LWhpZGRlbiBvdmVyZmxvdy15LXNjcm9sbCBiZy1ncmF5LTUwIG1pbi1oLXNjcmVlblwiPlxyXG4gICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuXHJcbiAgICAgICAgICB7LyogUGFnZSBIZWFkZXIgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgaXRlbXMtc3RhcnQgc206aXRlbXMtZW5kIGdhcC02IG1iLTZcIj5cclxuXHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgdy1mdWxsIHNtOnctNzIgXCI+XHJcbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LWdyYXktODAwIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgIDxUZWFtT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICBTYWxhcnkgTGVkZ2VyXHJcbiAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTEgbWwtM1wiPlxyXG4gICAgICAgICAgICAgICAgU2VsZWN0IEVtcGxveWVlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBlbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRFbXBsb3llZX1cclxuICAgICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJsYWJlbFwiXHJcbiAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICBvcHRpb24ubGFiZWwudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgb3B0aW9ucz17ZW1wbG95ZWVzLm1hcCgoZW1wKSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICB2YWx1ZTogZW1wLl9pZCxcclxuICAgICAgICAgICAgICAgICAgbGFiZWw6IGAke2VtcC5uYW1lfSAoJHtlbXAucGhvbmVfbnVtYmVyfSlgLFxyXG4gICAgICAgICAgICAgICAgfSkpfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAge3NlbGVjdGVkRW1wbG95ZWUgPyAoXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAge292ZXJhbGxOZXRQb3NpdGlvbiAhPT0gbnVsbCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgc3BhY2UteS02XCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogT3ZlcmFsbCBOZXQgUG9zaXRpb24gKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Byb3VuZGVkLXhsIGJvcmRlci1sLTQgcC01IGZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIHNtOmp1c3RpZnktYmV0d2VlbiBnYXAtNCAke2lzUG9zaXRpdmVcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmVlbi01MCBib3JkZXItZ3JlZW4tNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1yZWQtNTAgYm9yZGVyLXJlZC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgdGV4dC1ncmF5LTUwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE92ZXJhbGwgTmV0IFBvc2l0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPHBcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC0zeGwgZm9udC1ib2xkICR7aXNQb3NpdGl2ZSA/IFwidGV4dC1ncmVlbi03MDBcIiA6IFwidGV4dC1yZWQtNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEN1cnJlbmN5KG92ZXJhbGxOZXRQb3NpdGlvbil9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPHBcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC1zbSBtdC0xIGZvbnQtbWVkaXVtIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xICR7aXNQb3NpdGl2ZSA/IFwidGV4dC1ncmVlbi02MDBcIiA6IFwidGV4dC1yZWQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2lzUG9zaXRpdmUgPyA8QXJyb3dVcE91dGxpbmVkIC8+IDogPEFycm93RG93bk91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7aXNQb3NpdGl2ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJBbW91bnQgdG8gYmUgcGFpZCBieSBjb21wYW55XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiRXhjZXNzIHBhaWQgLyBhZHZhbmNlIGR1ZVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRmluYWwgY2xvc2luZyBiYWxhbmNlIGFjcm9zcyBhbGwgcGVyaW9kcyBmb3J7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZEVtcGxveWVlTmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIC5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogSW5jZW50aXZlIENhcmRzICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTZcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIENoaXQgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdyBib3JkZXIgcC01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtYmx1ZS03MDAgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDaGl0IEluY2VudGl2ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+VG90YWw8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWJsdWUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0Q3VycmVuY3kob3ZlcnZpZXcuY2hpdEluY2VudGl2ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5QYWlkPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1jeWFuLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEN1cnJlbmN5KG92ZXJ2aWV3LnBhaWRDaGl0KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGhyIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPlJlbWFpbmluZzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1vcmFuZ2UtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0Q3VycmVuY3koXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChvdmVydmlldy5jaGl0SW5jZW50aXZlIHx8IDApIC0gKG92ZXJ2aWV3LnBhaWRDaGl0IHx8IDApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIFBpZ215ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3cgYm9yZGVyIHAtNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyZWVuLTcwMCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFBpZ215IEluY2VudGl2ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+VG90YWw8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyZWVuLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEN1cnJlbmN5KG92ZXJ2aWV3LnBpZ215SW5jZW50aXZlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlBhaWQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWVtZXJhbGQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0Q3VycmVuY3kob3ZlcnZpZXcucGFpZFBpZ215KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGhyIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPlJlbWFpbmluZzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1vcmFuZ2UtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0Q3VycmVuY3koXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChvdmVydmlldy5waWdteUluY2VudGl2ZSB8fCAwKSAtIChvdmVydmlldy5wYWlkUGlnbXkgfHwgMClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogTG9hbiAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93IGJvcmRlciBwLTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1wdXJwbGUtNzAwIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTG9hbiBJbmNlbnRpdmVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlRvdGFsPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1wdXJwbGUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0Q3VycmVuY3kob3ZlcnZpZXcubG9hbkluY2VudGl2ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5QYWlkPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1waW5rLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEN1cnJlbmN5KG92ZXJ2aWV3LnBhaWRMb2FuKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGhyIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPlJlbWFpbmluZzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1vcmFuZ2UtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0Q3VycmVuY3koXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChvdmVydmlldy5sb2FuSW5jZW50aXZlIHx8IDApIC0gKG92ZXJ2aWV3LnBhaWRMb2FuIHx8IDApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgey8qIOKUgOKUgCBRdWljayBOYXZpZ2F0b3Ig4pSA4pSAICovfVxyXG4gICAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHRleHQtZ3JheS00MDAgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICBRdWljayBuYXZpZ2F0b3JcclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAge05BVl9MSU5LUy5tYXAoKGxpbmspID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtsaW5rLnRvfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdG89e2xpbmsudG99XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC00IHB5LTIgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIHRleHQtc20gdGV4dC1ncmF5LTYwMCBob3Zlcjpib3JkZXItYmx1ZS00MDAgaG92ZXI6dGV4dC1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTUwIHRyYW5zaXRpb24tYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNTAwXCI+e2xpbmsuaWNvbn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bGluay5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAgICAgICAgICB7Lyog4pSA4pSAIExlZGdlciBUYWJsZSDilIDilIAgKi99XHJcbiAgICAgICAgICAgICAge3RhYmxlRGF0YS5sZW5ndGggPiAwICYmICFpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlclRhYmxlRGF0YSh0YWJsZURhdGEsIHNlYXJjaFRleHQpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPXtgU2FsYXJ5IFN0YXRlbWVudDogJHtzZWxlY3RlZEVtcGxveWVlTmFtZX1gfVxyXG4gICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BTYWxhcnkgU3RhdGVtZW50ICR7c2VsZWN0ZWRFbXBsb3llZU5hbWV9YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgIGZhaWx1cmU9e3RhYmxlRGF0YS5sZW5ndGggPT09IDAgJiYgIWlzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgZGF0YT1cIkxlZGdlciBEYXRhXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAvKiDilIDilIAgRW1wdHkgc3RhdGUg4pSA4pSAICovXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMjQgYmctd2hpdGUgcm91bmRlZC0yeGwgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICA8VGVhbU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtNXhsIHRleHQtZ3JheS0zMDAgbWItNCBibG9ja1wiIC8+XHJcbiAgICAgICAgICAgICAgPFRpdGxlIGxldmVsPXs0fSBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICBObyBlbXBsb3llZSBzZWxlY3RlZFxyXG4gICAgICAgICAgICAgIDwvVGl0bGU+XHJcbiAgICAgICAgICAgICAgPFRleHQgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgU2VsZWN0IGFuIGVtcGxveWVlIGZyb20gdGhlIGRyb3Bkb3duIGFib3ZlIHRvIHZpZXcgdGhlaXJcclxuICAgICAgICAgICAgICAgIGZpbmFuY2lhbCBoaXN0b3J5LlxyXG4gICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHsvKiDilIDilIAgRm9vdGVyIGxlZ2VuZCDilIDilIAgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYmctYmx1ZS01MCBib3JkZXIgYm9yZGVyLWJsdWUtMTAwIHJvdW5kZWQtbGcgcHgtNCBweS0zIHRleHQtc20gdGV4dC1ibHVlLTcwMFwiPlxyXG4gICAgICAgICAgICA8SW5mb0NpcmNsZU91dGxpbmVkIGNsYXNzTmFtZT1cImZsZXgtc2hyaW5rLTBcIiAvPlxyXG4gICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICA8c3Ryb25nPlJ1bm5pbmcgYmFsYW5jZTo8L3N0cm9uZz4gUG9zaXRpdmUgKCspIG1lYW5zIGNvbXBhbnkgb3dlc1xyXG4gICAgICAgICAgICAgIGVtcGxveWVlIMK3IE5lZ2F0aXZlICjiiJIpIG1lYW5zIGVtcGxveWVlIGhhcyB0YWtlbiBleGNlc3MgLyBhZHZhbmNlLlxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgRW1wbG95ZWVTdGF0ZW1lbnQ7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0VtcGxveWVlU3RhdGVtZW50LmpzeCJ9