import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/UserReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useRef = __vite__cjsImport3_react["useRef"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import CustomerReportPrint from "/src/components/printFormats/CustomerReportPrint.js";
import { Dropdown, Select, Button, Modal, Tag, Table as AntTable } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { Link, useSearchParams } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { FiRefreshCcw, FiSearch } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { IoMdDownload } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { MdAccountBalanceWallet, MdGavel, MdPeople } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import Fuse from "/node_modules/.vite/deps/fuse__js.js?v=819e0a34";
import __vite__cjsImport17_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport17_dayjs.__esModule ? __vite__cjsImport17_dayjs.default : __vite__cjsImport17_dayjs;
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import {
  FiUser,
  FiBookOpen,
  FiFileText,
  FiRepeat,
  FiCreditCard
} from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { FaRupeeSign, FaExclamationCircle, FaEye } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import {
  EyeOutlined,
  ExclamationCircleOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
const UserReport = () => {
  _s();
  const [searchParams] = useSearchParams();
  const userId = searchParams.get("user_id");
  const [groups, setGroups] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [TableDaybook, setTableDaybook] = useState([]);
  const [TableAuctions, setTableAuctions] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState(userId ? userId : "");
  const [group, setGroup] = useState([]);
  const [commission, setCommission] = useState("");
  const [TableEnrolls, setTableEnrolls] = useState([]);
  const [TableEnrollsDate, setTableEnrollsDate] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [groupPaid, setGroupPaid] = useState("");
  const [groupToBePaid, setGroupToBePaid] = useState("");
  const [customerTransactions, setCustomerTransactions] = useState(null);
  const [accountDetails, setAccountDetails] = useState(null);
  const [accountDetailsLoading, setAccountDetailsLoading] = useState(false);
  const [fromDate, setFromDate] = useState(() => {
    const today2 = /* @__PURE__ */ new Date();
    return today2.toISOString().split("T")[0];
  });
  const [toDate, setToDate] = useState(() => {
    const today2 = /* @__PURE__ */ new Date();
    return today2.toISOString().split("T")[0];
  });
  const [totalAmount, setTotalAmount] = useState(0);
  const [groupPaidDate, setGroupPaidDate] = useState("");
  const [groupToBePaidDate, setGroupToBePaidDate] = useState("");
  const [detailsLoading, setDetailLoading] = useState(false);
  const [basicLoading, setBasicLoading] = useState(false);
  const [dateLoading, setDateLoading] = useState(false);
  const [EnrollGroupId, setEnrollGroupId] = useState({
    groupId: "",
    ticket: ""
  });
  const [registrationFee, setRegistrationFee] = useState({
    amount: 0,
    createdAt: null
  });
  const [visibleRows, setVisibleRows] = useState({
    row1: false,
    row2: false,
    row3: false,
    row4: false,
    row5: false,
    row6: false,
    row7: false,
    row8: false,
    row9: false
  });
  const [view, setView] = useState("list");
  const Input = ({ label, value }) => /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
    /* @__PURE__ */ jsxDEV("label", { className: "mb-1 text-sm font-medium text-gray-700", children: label }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
      lineNumber: 88,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      "input",
      {
        type: "text",
        placeholder: label,
        value: value || "",
        readOnly: true,
        className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
        lineNumber: 89,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
    lineNumber: 87,
    columnNumber: 3
  }, this);
  const [TotalToBepaid, setTotalToBePaid] = useState("");
  const [Totalpaid, setTotalPaid] = useState("");
  const [Totalprofit, setTotalProfit] = useState("");
  const isFetchingPenalty = useRef(false);
  const [NetTotalprofit, setNetTotalProfit] = useState("");
  const [selectedAuctionGroupId, setSelectedAuctionGroupId] = useState(
    userId ? userId : ""
  );
  const [selectedEnrollments, setSelectedEnrollments] = useState([]);
  const [groupInfo, setGroupInfo] = useState({});
  const [selectedFromDate, setSelectedFromDate] = useState("");
  const [selectedToDate, setSelectedToDate] = useState("");
  const [selectedPaymentMode, setSelectedPaymentMode] = useState("");
  const [selectedCustomers, setSelectedCustomers] = useState(
    userId ? userId : ""
  );
  const [payments, setPayments] = useState([]);
  const [availableTickets, setAvailableTickets] = useState([]);
  const [screenLoading, setScreenLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("groupDetails");
  const [searchText, setSearchText] = useState("");
  const [groupDetails, setGroupDetails] = useState(" ");
  const [loanCustomers, setLoanCustomers] = useState([]);
  const [pigmeCustomers, setPigmeCustomers] = useState([]);
  const [pigmeCustomerData, setPigmeCustomerData] = useState([]);
  const [pigmeId, setPigmeId] = useState("No");
  const [filteredPigmeData, setFilteredPigmeData] = useState([]);
  const [borrowersData, setBorrowersData] = useState([]);
  const [borrowerId, setBorrowerId] = useState("No");
  const [filteredBorrowerData, setFilteredBorrowerData] = useState([]);
  const [filteredDisbursement, setFilteredDisbursement] = useState([]);
  const [disbursementLoading, setDisbursementLoading] = useState(false);
  const [statementLoading, setStatementLoading] = useState(false);
  const [transactionsLoading, setTransactionsLoading] = useState(false);
  const [registrationAmount, setRegistrationAmount] = useState(null);
  const [registrationDate, setRegistrationDate] = useState(null);
  const [finalPaymentBalance, setFinalPaymentBalance] = useState(0);
  const [selectedLabel, setSelectedLabel] = useState("50");
  const [showFilterField, setShowFilterField] = useState(false);
  const today = /* @__PURE__ */ new Date();
  const todayString = today.toISOString().split("T")[0];
  const [penaltyData, setPenaltyData] = useState([]);
  const [penaltyLoading, setPenaltyLoading] = useState(false);
  const [breakdownModalVisible, setBreakdownModalVisible] = useState(false);
  const [selectedPenalty, setSelectedPenalty] = useState(null);
  const [bidRequestsData, setBidRequestsData] = useState(null);
  const [bidRequestsLoading, setBidRequestsLoading] = useState(false);
  const [bidRequestModalVisible, setBidRequestModalVisible] = useState(false);
  const [selectedBidRequest, setSelectedBidRequest] = useState(null);
  const [visitorData, setVisitorData] = useState(null);
  const [visitorLoading, setVisitorLoading] = useState(false);
  const [visitorModalVisible, setVisitorModalVisible] = useState(false);
  const [selectedVisitor, setSelectedVisitor] = useState(null);
  const [hideAccountType, setHideAccountType] = useState("");
  const [selectedAccountType, setSelectedAccountType] = useState("");
  const [selectedPaymentFor, setSelectedPaymentFor] = useState([]);
  const [showAllPaymentModes, setShowAllPaymentModes] = useState(false);
  const [transactionsTable, setTransactionsTable] = useState([]);
  const [totalTransactions, setTotalTransactons] = useState(10);
  const [totalTransactionAmount, setTotalTransactionAmount] = useState(0);
  const [enrollmentData, setEnrollmentData] = useState([]);
  const [activeEnrollmentData, setActiveEnrollmentData] = useState("");
  const [enrollmentDataLoading, setEnrollmentDataLoading] = useState(false);
  const [transferHistoryLoading, setTransferHistoryLoading] = useState(false);
  const [transferHistory, setTransferHistory] = useState([]);
  const [enrollmentId, setEnrollmentId] = useState("");
  const onGlobalSearchChangeHandler = (e) => {
    setSearchText(e.target.value);
  };
  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };
  const [formData, setFormData] = useState({
    group_id: "",
    user_id: "",
    ticket: "",
    receipt_no: "",
    pay_date: "",
    amount: "",
    pay_type: "cash",
    transaction_id: ""
  });
  const BasicLoanColumns = [
    { key: "id", header: "SL. NO" },
    { key: "pay_date", header: "Payment Date" },
    { key: "receipt_no", header: "Receipt No" },
    { key: "amount", header: "Amount" },
    { key: "pay_type", header: "Payment Type" },
    { key: "balance", header: "Balance" }
  ];
  const BasicPigmeColumns = [
    { key: "id", header: "SL. NO" },
    { key: "pay_date", header: "Payment Date" },
    { key: "receipt_no", header: "Receipt No" },
    { key: "amount", header: "Amount" },
    { key: "pay_type", header: "Payment Type" },
    { key: "balance", header: "Balance" }
  ];
  const DisbursementColumns = [
    { key: "id", header: "SL. NO" },
    { key: "pay_date", header: "Disbursed Date" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "group_name", header: "Group Name/ Loan ID" },
    { key: "ticket", header: "Ticket" },
    { key: "amount", header: "Amount" },
    { key: "receipt_no", header: "Receipt No" },
    { key: "pay_type", header: "Payment Type" },
    { key: "disbursement_type", header: "Disbursement Type" },
    { key: "disbursed_by", header: "Disbursed By" },
    { key: "balance", header: "Balance" }
  ];
  const TransferHistoryColumns = [
    { key: "id", header: "SL. NO" },
    { key: "transfer_code", header: "Group Change Code" },
    { key: "transfer_date", header: "Group Change Date" },
    { key: "from_customer", header: "From Customer" },
    { key: "from_group", header: "From Group" },
    { key: "from_ticket", header: "From Ticket" },
    { key: "to_customer", header: "To Customer" },
    { key: "to_group", header: "To Group" },
    { key: "to_ticket", header: "To Ticket" },
    { key: "transfer_amount", header: "Group Change Amount" },
    // { key: "deduction_amount", header: "Deduction" },
    { key: "net_transferred_amount", header: "Net Amount" },
    { key: "reason", header: "Reason" },
    { key: "admin", header: "Created By" }
  ];
  const TransactionsColumns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Paid Date" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "group", header: "Group Name" },
    { key: "category", header: "Category" },
    { key: "ticket", header: "Ticket" },
    { key: "receipt", header: "Receipt" },
    { key: "old_receipt_no", header: "Old Receipt" },
    { key: "amount", header: "Amount" },
    { key: "mode", header: "Payment Mode" },
    ...hideAccountType ? [{ key: "account_type", header: "Account Type" }] : [],
    { key: "collected_by", header: "Collected By" },
    { key: "collection_time", header: "Collection Time" },
    { key: "action", header: "Action" }
  ];
  useEffect(
    () => {
      const abortController = new AbortController();
      const fetchPayments = async () => {
        if (!selectedGroup) return;
        try {
          setTransactionsLoading(true);
          const queryParams = { userId: selectedGroup };
          if (selectedFromDate) queryParams.from_date = selectedFromDate;
          if (selectedToDate) queryParams.to_date = selectedToDate;
          if (totalTransactions)
            queryParams.totalTransactions = totalTransactions;
          if (selectedPaymentMode?.length)
            queryParams.pay_type = selectedPaymentMode;
          if (selectedAccountType) queryParams.account_type = selectedAccountType;
          if (selectedPaymentFor?.length)
            queryParams.pay_for = selectedPaymentFor;
          const response = await api.get(`/payment/customer/transactions`, {
            params: queryParams,
            signal: abortController.signal
          });
          if (response.data && response.data.length > 0) {
            const totalSum = response.data.reduce(
              (sum, item) => sum + Number(item.amount || 0),
              0
            );
            setTotalTransactionAmount(totalSum);
            const formattedData = response.data.map((item, index) => {
              return {
                _id: item._id,
                id: index + 1,
                group: item?.group_id?.group_name || item?.pay_for || "N/A",
                name: item?.user_id?.full_name || "Unknown Customer",
                category: item?.pay_for || "Chit",
                phone_number: item?.user_id?.phone_number || "N/A",
                ticket: item?.loan ? item.loan?.loan_id : item?.pigme ? item.pigme?.pigme_id : item?.ticket || "N/A",
                receipt: item?.receipt_no || "N/A",
                old_receipt_no: item?.old_receipt_no || "-",
                amount: item?.amount || 0,
                date: item.pay_date?.split("T")?.[0] || "N/A",
                transaction_date: item?.createdAt?.split("T")?.[0] || "N/A",
                mode: item?.pay_type || "N/A",
                account_type: item?.account_type || "-",
                collection_time: item?.collection_time || "-",
                collected_by: item?.collected_by?.name || item?.admin_type?.admin_name || "Super Admin",
                action: /* @__PURE__ */ jsxDEV(
                  Dropdown,
                  {
                    menu: {
                      items: [
                        {
                          key: "1",
                          label: /* @__PURE__ */ jsxDEV(
                            Link,
                            {
                              target: "_blank",
                              to: `/print/${item._id}`,
                              className: "text-blue-600",
                              children: "Print"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 316,
                              columnNumber: 21
                            },
                            this
                          )
                        }
                      ]
                    },
                    placement: "bottomLeft",
                    children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "cursor-pointer" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 329,
                      columnNumber: 19
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 310,
                    columnNumber: 15
                  },
                  this
                )
              };
            });
            setTransactionsTable(formattedData);
          } else {
            console.warn("No data returned for these filters:", queryParams);
            setTransactionsTable([]);
          }
        } catch (error) {
          if (error.name !== "AbortError") {
            setTransactionsTable([]);
            setTotalTransactionAmount(0);
          }
        } finally {
          setTransactionsLoading(false);
        }
      };
      fetchPayments();
      return () => abortController.abort();
    },
    [
      selectedFromDate,
      selectedToDate,
      selectedPaymentMode,
      selectedGroup,
      selectedAccountType,
      selectedPaymentFor,
      totalTransactions,
      showFilterField
    ]
  );
  useEffect(() => {
    const fetchRegistrationFee = async () => {
      if (activeTab === "basicReport" && selectedGroup && EnrollGroupId.groupId && EnrollGroupId.ticket && EnrollGroupId.groupId !== "Loan" && EnrollGroupId !== "Pigme") {
        try {
          setTableEnrolls([]);
          setGroupPaid("");
          setGroupToBePaid("");
          setRegistrationAmount(null);
          setRegistrationDate(null);
          setBasicLoading(true);
          setIsLoading(true);
          const response = await api.get(
            "/enroll/get-user-registration-fee-report",
            {
              params: {
                group_id: EnrollGroupId.groupId,
                ticket: EnrollGroupId.ticket,
                user_id: selectedGroup
              }
            }
          );
          const { payments: payments2 = [], registrationFees = [] } = response.data || {};
          setGroupPaid(payments2[0]?.groupPaidAmount || 0);
          setGroupToBePaid(payments2[0]?.totalToBePaidAmount || 0);
          let balance = 0;
          const formattedData = payments2.map((payment, index) => {
            balance += Number(payment.amount || 0);
            return {
              _id: payment._id,
              id: index + 1,
              date: formatPayDate(payment?.pay_date),
              amount: payment.amount,
              receipt: payment.receipt_no,
              old_receipt: payment.old_receipt_no,
              type: payment.pay_type,
              balance
            };
          });
          let totalRegAmount = 0;
          registrationFees.forEach((regFee, idx) => {
            formattedData.push({
              id: "-",
              date: regFee.createdAt ? new Date(regFee.createdAt).toLocaleDateString("en-GB") : "",
              amount: regFee.amount,
              receipt: regFee.receipt_no,
              old_receipt: "-",
              type: regFee.pay_for || "Reg Fee",
              balance: "-"
            });
            totalRegAmount += Number(regFee.amount || 0);
          });
          setRegistrationAmount(totalRegAmount);
          if (registrationFees.length > 0) {
            setRegistrationDate(
              registrationFees[0]?.createdAt ? new Date(registrationFees[0].createdAt).toLocaleDateString(
                "en-GB"
              ) : null
            );
          }
          if (formattedData.length > 0) {
            formattedData.push({
              id: "",
              date: "",
              amount: "",
              receipt: "",
              old_receipt: "",
              type: "TOTAL",
              balance
            });
            setFinalPaymentBalance(balance);
          } else {
            setFinalPaymentBalance(0);
          }
          setTableEnrolls(formattedData);
        } catch (error) {
          console.error("Error fetching registration fee and payments:", error);
          setTableEnrolls([]);
          setGroupPaid("");
          setGroupToBePaid("");
          setRegistrationAmount(null);
          setRegistrationDate(null);
        } finally {
          setBasicLoading(false);
          setIsLoading(false);
        }
      } else {
        setTableEnrolls([]);
        setGroupPaid("");
        setGroupToBePaid("");
        setRegistrationAmount(null);
        setRegistrationDate(null);
      }
    };
    fetchRegistrationFee();
  }, [activeTab, selectedGroup, EnrollGroupId.groupId, EnrollGroupId.ticket]);
  useEffect(() => {
    const fetchTransferHistory = async () => {
      try {
        setTransferHistoryLoading(true);
        const response = await api.get(
          `/v1/admin/enrolls/transfer-history/${selectedGroup}`
        );
        const data = response?.data?.data || [];
        const formattedData = data.map((item, index) => ({
          _id: item._id,
          id: index + 1,
          transfer_code: item.enroll_transfer_history_code,
          from_customer: item?.from_enrollment?.user_id?.full_name || "-",
          from_phone: item?.from_enrollment?.user_id?.phone_number || "-",
          from_group: item?.from_enrollment?.group_id?.group_name || "-",
          from_ticket: item?.from_enrollment?.tickets || "-",
          to_customer: item?.to_enrollment?.user_id?.full_name || "-",
          to_phone: item?.to_enrollment?.user_id?.phone_number || "-",
          to_group: item?.to_enrollment?.group_id?.group_name || "-",
          to_ticket: item?.to_enrollment?.tickets || "-",
          transfer_amount: item?.transfer_amount || 0,
          deduction_amount: item?.deduction_amount || 0,
          net_transferred_amount: item?.net_transferred_amount || 0,
          admin: item?.admin?.admin_name,
          reason: item?.reason || "-",
          transfer_date: formatPayDate(item?.transfer_date)
        }));
        setTransferHistory(formattedData);
      } catch (error) {
        console.error(
          "Error fetching transfer history:",
          error,
          error?.response?.data
        );
        setTransferHistory([]);
      } finally {
        setTransferHistoryLoading(false);
      }
    };
    if (activeTab === "transferHistory" && selectedGroup) {
      fetchTransferHistory();
    }
  }, [activeTab, selectedGroup]);
  useEffect(() => {
    const fetchAllLoanPaymentsbyId = async () => {
      setBorrowersData([]);
      setBasicLoading(true);
      try {
        const selectedLoan = loanCustomers?.overall_loan?.find(
          (loan) => loan?.loan_details?.loan?._id === EnrollGroupId.ticket
        );
        const loanId = selectedLoan?.loan_details?.loan?._id || EnrollGroupId.ticket;
        const response = await api.get(
          `/loan-payment/get-all-loan-payments/${loanId}`
        );
        if (response.data?.length > 0) {
          let balance = 0;
          const formattedData = response.data.map((loanPayment, index) => {
            balance += Number(loanPayment.amount);
            return {
              _id: loanPayment._id,
              id: index + 1,
              pay_date: formatPayDate(loanPayment?.pay_date),
              amount: loanPayment.amount,
              receipt_no: loanPayment.receipt_no,
              pay_type: loanPayment.pay_type,
              balance
            };
          });
          formattedData.push({
            _id: "",
            id: "",
            pay_date: "",
            receipt_no: "",
            amount: "",
            pay_type: "",
            balance
          });
          setBorrowersData(formattedData);
        } else {
          setBorrowersData([]);
        }
      } catch (error) {
        console.error("Error fetching loan payment data:", error);
        setBorrowersData([]);
      } finally {
        setBasicLoading(false);
      }
    };
    if (EnrollGroupId.groupId === "Loan" && EnrollGroupId.ticket)
      fetchAllLoanPaymentsbyId();
  }, [EnrollGroupId.ticket]);
  useEffect(() => {
    const fetchAllPigmePaymentsbyId = async () => {
      setPigmeCustomerData([]);
      setBasicLoading(true);
      try {
        const response = await api.get(
          `/pigme-payment/get-all-pigme-payments-by-id/${EnrollGroupId.ticket}`
        );
        if (response.data && response.data.length > 0) {
          let balance = 0;
          const formattedData = response.data.map((pigmePayment, index) => {
            balance += Number(pigmePayment.amount);
            return {
              _id: pigmePayment._id,
              id: index + 1,
              pay_date: formatPayDate(pigmePayment?.pay_date),
              amount: pigmePayment.amount,
              receipt_no: pigmePayment.receipt_no,
              pay_type: pigmePayment.pay_type,
              balance
            };
          });
          formattedData.push({
            _id: "",
            id: "",
            pay_date: "",
            receipt_no: "",
            amount: "",
            pay_type: "",
            balance
          });
          setPigmeCustomerData(formattedData);
        } else {
          setPigmeCustomerData([]);
        }
      } catch (error) {
        console.error("Error fetching pigme payment data:", error);
        setPigmeCustomerData([]);
      } finally {
        setBasicLoading(false);
      }
    };
    if (EnrollGroupId.groupId === "Pigme") fetchAllPigmePaymentsbyId();
  }, [EnrollGroupId.ticket]);
  useEffect(() => {
    const fetchGroupById = async () => {
      try {
        const response = await api.get(
          `/group/get-by-id-group/${EnrollGroupId.groupId}`
        );
        if (response.status >= 400) throw new Error("API ERROR");
        setGroupDetails(response.data);
      } catch (err) {
        console.log("Failed to fetch group details by ID:", err.message);
      }
    };
    if (EnrollGroupId.groupId !== "Loan" && EnrollGroupId.groupId !== "Pigme")
      fetchGroupById();
  }, [EnrollGroupId?.ticket]);
  useEffect(() => {
    setScreenLoading(true);
    const fetchGroups = async () => {
      setDetailLoading(true);
      try {
        const response = await api.get("/user/get-user");
        setGroups(response.data);
        setScreenLoading(false);
        setDetailLoading(false);
      } catch (error) {
        console.error("Error fetching group data:", error);
      } finally {
        setDetailLoading(false);
      }
    };
    fetchGroups();
  }, []);
  useEffect(() => {
    const fetchBorrower = async () => {
      try {
        setLoanCustomers([]);
        const response = await api.get(`/payment/loan/user/${selectedGroup}`);
        if (response.data) {
          const filteredBorrowerData2 = response.data?.overall_loan?.map(
            (loan, index) => ({
              sl_no: index + 1,
              loan: loan?.loan_details?.loan?.loan_id,
              start_date: loan?.loan_details?.loan?.start_date?.split("T")[0],
              end_date: loan?.loan_details?.loan?.end_date?.split("T")[0],
              loan_amount: loan?.loan_value,
              tenure: loan?.loan_details?.loan?.tenure,
              service_charge: loan?.loan_details?.loan?.service_charges,
              late_fee: loan?.loan_details?.loan?.extra_charges?.reduce(
                (sum, charge) => sum + Number(charge.amount || 0),
                0
              ) || 0,
              total_paid_amount: loan?.total_paid_amount,
              balance: loan?.balance
            })
          );
          setFilteredBorrowerData(filteredBorrowerData2);
        }
        setLoanCustomers(response.data);
        if (response.status >= 400) throw new Error("Failed to send message");
      } catch (err) {
        console.log("failed to fetch loan customers", err.message);
        setFilteredBorrowerData([]);
      }
    };
    setBorrowersData([]);
    setBorrowerId("No");
    fetchBorrower();
  }, [selectedGroup]);
  useEffect(() => {
    const fetchPigme = async () => {
      try {
        setPigmeCustomers([]);
        const response = await api.get(`/payment/pigme/user/${selectedGroup}`);
        if (response.data) {
          const filteredPigmeData2 = response.data?.overall_pigme?.map(
            (pigme, index) => ({
              sl_no: index + 1,
              pigme: pigme?.pigme_details?.pigme?.pigme_id,
              start_date: pigme?.pigme_details?.pigme?.start_date?.split("T")[0],
              duration: pigme?.pigme_details?.pigme?.duration,
              maturity_interest: pigme?.pigme_details?.pigme?.maturity_interest,
              total_deposited_amount: pigme?.total_deposited_amount
            })
          );
          setFilteredPigmeData(filteredPigmeData2);
        }
        setPigmeCustomers(response.data);
        if (response.status >= 400) throw new Error("Failed to send message");
      } catch (err) {
        console.log("failed to fetch Pigme customers", err.message);
        setFilteredPigmeData([]);
      }
    };
    setPigmeCustomerData([]);
    setPigmeId("No");
    fetchPigme();
  }, [selectedGroup]);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get(`/user/get-user-by-id/${selectedGroup}`);
        setGroup(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, [selectedGroup]);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/user/get-user");
        setFilteredUsers(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  useEffect(() => {
    const fetchDisbursement = async () => {
      try {
        setDisbursementLoading(true);
        const response = await api.get(
          `/payment-out/get-payment-out-report-daybook`,
          {
            params: {
              userId: selectedGroup
            }
          }
        );
        if (response.data) {
          const formattedData = response.data.map((payment, index) => {
            let balance = 0;
            balance += Number(payment.amount);
            return {
              _id: payment._id,
              id: index + 1,
              disbursement_type: payment.disbursement_type,
              // group_name: payment?.group_id?.group_name,
              group_name: payment?.pay_for === "loan" ? `${payment?.loan?.loan_id || ""}` : payment?.group_id?.group_name,
              pay_date: formatPayDate(payment?.pay_date),
              ticket: payment.ticket,
              transaction_date: formatPayDate(payment.createdAt),
              amount: payment.amount,
              receipt_no: payment.receipt_no,
              pay_type: payment.pay_type,
              disbursed_by: payment.admin_type?.name,
              balance
            };
          });
          setFilteredDisbursement(formattedData);
        } else {
          setFilteredDisbursement([]);
        }
      } catch (error) {
        console.error("Error fetching disbursement data", error, error.message);
        setFilteredDisbursement([]);
      } finally {
        setDisbursementLoading(false);
      }
    };
    if (selectedGroup) fetchDisbursement();
  }, [selectedGroup]);
  const handleGroupPayment = async (groupId) => {
    setSelectedAuctionGroupId(groupId);
    setSelectedGroup(groupId);
    handleGroupAuctionChange(groupId);
  };
  useEffect(() => {
    if (userId) {
      handleGroupPayment(userId);
    }
  }, []);
  const handleEnrollGroup = (event) => {
    const value = event.target.value;
    if (value) {
      const [groupId, ticket] = value.split("|");
      setEnrollGroupId({ groupId, ticket });
    } else {
      setEnrollGroupId({ groupId: "", ticket: "" });
      if (activeTab === "penalty") {
        setPenaltyData([]);
      }
    }
  };
  useEffect(() => {
    const fetchCustomerTransaction = async () => {
      try {
        if (!selectedAuctionGroupId) return;
        const response = await api.get(
          `/payment/users/${selectedAuctionGroupId}`
        );
        console.info(response.data.payments, "Fetched user transactions");
        setCustomerTransactions(response.data.payments);
      } catch (error) {
        console.error("Unable to fetch customer transaction details", error);
      }
    };
    fetchCustomerTransaction();
  }, [selectedAuctionGroupId]);
  useEffect(
    () => {
      const fetchPayments = async () => {
        try {
          const response = await api.get(`/payment/get-customer-history`, {
            params: {
              from_date: selectedFromDate,
              to_date: selectedToDate,
              groupId: selectedAuctionGroupId,
              userId: selectedCustomers,
              pay_type: selectedPaymentMode
            }
          });
          if (response.data && response.data.length > 0) {
            const paymentData = response.data;
            const totalAmount2 = paymentData.reduce(
              (sum, payment) => sum + Number(payment.amount || 0),
              0
            );
            setPayments(totalAmount2);
            const formattedData = response.data.map((group2, index) => ({
              id: index + 1,
              group: group2.group_id?.group_name,
              name: group2.user_id?.full_name,
              phone_number: group2?.user_id?.phone_number,
              ticket: group2?.ticket,
              amount: group2?.amount,
              mode: group2?.pay_type
            }));
            setTableDaybook(formattedData);
          }
        } catch (error) {
          console.error("Error fetching payment data:", error);
          setPayments(0);
        }
      };
      fetchPayments();
    },
    [
      selectedAuctionGroupId,
      selectedToDate,
      selectedFromDate,
      selectedPaymentMode,
      selectedCustomers
    ]
  );
  async function getActiveCustomerEnrollmentData() {
    try {
      setEnrollmentDataLoading(true);
      const response = await api.get(`/enroll/customers/${selectedGroup}`);
      const responseData = response?.data?.data ?? [];
      setEnrollmentData(responseData);
    } catch (error) {
      setEnrollmentData([]);
    } finally {
      setEnrollmentDataLoading(false);
    }
  }
  useEffect(() => {
    if (activeTab === "customerPaymentStatement")
      getActiveCustomerEnrollmentData();
  }, [activeTab, selectedGroup]);
  const fetchAccountDetails = async (userId2) => {
    if (!userId2) return;
    try {
      setAccountDetailsLoading(true);
      const response = await api.get(
        `/v1/admin/user-accounts/${userId2}/ledger`
      );
      console.info(response, "checking transaction");
      if (response?.data?.status) {
        setAccountDetails(response.data.data);
      } else {
        setAccountDetails(null);
      }
    } catch (error) {
      console.error("Error fetching account details:", error);
      setAccountDetails(null);
    } finally {
      setAccountDetailsLoading(false);
    }
  };
  useEffect(() => {
    if (selectedGroup && activeTab === "accountDeails") {
      fetchAccountDetails(selectedGroup);
    }
  }, [selectedGroup, activeTab]);
  const filteredLedgerData = selectedGroup ? accountDetails?.useraccounts?.filter((item) => item._id === selectedGroup) : accountDetails?.useraccounts || [];
  const fetchCustomerPenalty = async (groupId, ticket) => {
    if (!selectedGroup || !groupId || !ticket) {
      setPenaltyData([]);
      return;
    }
    if (isFetchingPenalty.current) {
      return;
    }
    try {
      isFetchingPenalty.current = true;
      setPenaltyLoading(true);
      const response = await api.get(
        `/penalty-management/customer-penalty/${selectedGroup}/${groupId}/${ticket}`
      );
      if (response.data?.success && response.data?.data) {
        const data = response.data.data;
        const formattedPenalty = {
          enrollmentId: data.enrollmentId || groupId,
          groupName: data.group?.group_name || data.groupName || "N/A",
          ticket,
          customerName: data.user?.full_name || data.customerName || group?.full_name || "N/A",
          customerPhone: data.user?.phone_number || data.customerPhone || group?.phone_number || "N/A",
          totalExpected: data.summary?.totalExpected || 0,
          totalPaid: data.summary?.totalPaid || 0,
          totalPenalty: data.summary?.totalPenalty || 0,
          totalLateFee: data.summary?.totalLateFee || 0,
          vcPenalty: data.summary?.vcPenalty || 0,
          grandTotalDue: data.summary?.totalDue || 0,
          balanceWithoutPenalty: data.summary?.currentBalance || 0,
          currentBalance: data.summary?.currentBalance || 0,
          cycles: data.penalties?.map((p) => ({
            cycle_no: p.cycle_no,
            due_date: p.due_date,
            expected: p.expected,
            paid: p.paid,
            balance: p.balance,
            penalty: p.penalty_amount,
            late_payment_charges: p.late_fee_amount,
            status: p.status
          })) || [],
          penaltyRecordId: data.penalties?.[0]?._id || null
        };
        setPenaltyData([formattedPenalty]);
      } else {
        setPenaltyData([]);
      }
    } catch (error) {
      console.error("Error fetching penalty:", error);
      setPenaltyData([]);
    } finally {
      setPenaltyLoading(false);
      isFetchingPenalty.current = false;
    }
  };
  const formatPenaltyAmount = (amount) => {
    return `₹${(amount || 0).toLocaleString("en-IN")}`;
  };
  const PenaltyColumns = [
    { key: "sl_no", header: "SL. NO" },
    { key: "groupName", header: "Group Name" },
    { key: "ticket", header: "Ticket" },
    { key: "totalExpected", header: "Total Expected" },
    { key: "totalPaid", header: "Total Paid" },
    { key: "balanceWithoutPenalty", header: "Balance (w/o Penalty)" },
    { key: "totalPenalty", header: "Total Penalty" },
    { key: "totalLateFee", header: "Late Fee" },
    { key: "vcPenalty", header: "VC Penalty" },
    { key: "grandTotalDue", header: "Total Outstanding" },
    { key: "action", header: "View Details" }
  ];
  const PenaltyBreakdownColumns = [
    { key: "cycle_no", header: "Auction No." },
    { key: "due_date", header: "Due Date" },
    { key: "expected", header: "Expected Amount" },
    { key: "paid", header: "Paid Amount" },
    { key: "balance", header: "Balance" },
    { key: "penalty", header: "Penalty" },
    { key: "late_payment_charges", header: "Late Fee" },
    { key: "status", header: "Status" }
  ];
  const penaltyHistoryColumns = [
    {
      title: "Date",
      dataIndex: "createdAt",
      key: "date",
      render: (date) => moment(date).format("DD-MM-YYYY HH:mm"),
      sorter: (a, b) => new Date(a.createdAt) - new Date(b.createdAt),
      defaultSortOrder: "descend"
    },
    {
      title: "Penalty Amount",
      dataIndex: "penalty_amount",
      key: "penalty_amount",
      align: "right",
      render: (amount) => amount > 0 ? `₹${(amount || 0).toLocaleString("en-IN")}` : "-"
    },
    {
      title: "Late Fee",
      dataIndex: "late_fee_amount",
      key: "late_fee_amount",
      align: "right",
      render: (amount) => amount > 0 ? `₹${(amount || 0).toLocaleString("en-IN")}` : "-"
    },
    {
      title: "Total Amount",
      key: "total",
      align: "right",
      render: (_, record) => {
        const total = (record.penalty_amount || 0) + (record.late_fee_amount || 0);
        return `₹${total.toLocaleString("en-IN")}`;
      }
    },
    {
      title: "Reason",
      dataIndex: "reason",
      key: "reason",
      render: (reason) => reason || "No reason provided"
    }
  ];
  const formattedCustomerPenaltyData = useMemo(() => {
    return penaltyData.map((item, index) => ({
      key: item.enrollmentId,
      sl_no: index + 1,
      groupName: item.groupName,
      ticket: item.ticket,
      totalExpected: formatPenaltyAmount(item.totalExpected),
      totalPaid: formatPenaltyAmount(item.totalPaid),
      balanceWithoutPenalty: /* @__PURE__ */ jsxDEV(
        "span",
        {
          className: item.balanceWithoutPenalty <= 0 ? "text-green-600 font-semibold" : "text-orange-600 font-semibold",
          children: formatPenaltyAmount(Math.abs(item.balanceWithoutPenalty || 0))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
          lineNumber: 1131,
          columnNumber: 7
        },
        this
      ),
      totalPenalty: formatPenaltyAmount(item.totalPenalty),
      totalLateFee: formatPenaltyAmount(item.totalLateFee),
      vcPenalty: formatPenaltyAmount(item.vcPenalty),
      grandTotalDue: /* @__PURE__ */ jsxDEV("span", { className: "text-red-600 font-bold text-base", children: formatPenaltyAmount(item.grandTotalDue) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
        lineNumber: 1145,
        columnNumber: 7
      }, this),
      action: /* @__PURE__ */ jsxDEV(
        Button,
        {
          type: "link",
          icon: /* @__PURE__ */ jsxDEV(EyeOutlined, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 1152,
            columnNumber: 15
          }, this),
          onClick: () => showPenaltyBreakdown(item),
          className: "text-blue-600",
          children: "View Cycles"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
          lineNumber: 1150,
          columnNumber: 7
        },
        this
      )
    }));
  }, [penaltyData]);
  const showPenaltyBreakdown = (penalty) => {
    setSelectedPenalty(penalty);
    setBreakdownModalVisible(true);
  };
  const formattedPenaltyCycles = useMemo(() => {
    if (!selectedPenalty?.cycles) return [];
    return selectedPenalty.cycles.map((cycle, index) => ({
      key: index,
      cycle_no: cycle.cycle_no || index + 1,
      due_date: cycle.due_date ? dayjs(cycle.due_date).format("DD-MM-YYYY") : "N/A",
      expected: formatPenaltyAmount(cycle.expected),
      paid: formatPenaltyAmount(cycle.paid),
      balance: /* @__PURE__ */ jsxDEV(
        "span",
        {
          className: cycle.balance <= 0 ? "text-green-600" : "text-orange-600",
          children: formatPenaltyAmount(Math.abs(cycle.balance || 0))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
          lineNumber: 1179,
          columnNumber: 7
        },
        this
      ),
      penalty: formatPenaltyAmount(cycle.penalty),
      late_payment_charges: formatPenaltyAmount(cycle.late_payment_charges),
      status: /* @__PURE__ */ jsxDEV(
        Tag,
        {
          color: cycle.balance === 0 ? "green" : cycle.balance > 0 ? "red" : "orange",
          children: cycle.balance === 0 ? "Paid" : cycle.balance > 0 ? "Pending" : "Excess"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
          lineNumber: 1188,
          columnNumber: 7
        },
        this
      )
    }));
  }, [selectedPenalty]);
  useEffect(() => {
    if (activeTab === "penalty" && selectedGroup && EnrollGroupId.groupId && EnrollGroupId.ticket) {
      fetchCustomerPenalty(EnrollGroupId.groupId, EnrollGroupId.ticket);
    } else if (activeTab === "penalty") {
      setPenaltyData([]);
    }
  }, [activeTab, selectedGroup, EnrollGroupId.groupId, EnrollGroupId.ticket]);
  const fetchCustomerBidRequests = async () => {
    if (!selectedGroup) return;
    try {
      setBidRequestsLoading(true);
      const response = await api.get(
        `/bid-request/get-by-user/${selectedGroup}`
      );
      if (response.data && response.data.success) {
        const formattedData = response.data.data.map((item, index) => {
          const userObject = item?.subscriberId || {};
          const groupObject = item?.groupId || {};
          const balance = item?.auctions?.balance || 0;
          const getStatusColor = (status) => {
            const statusColors = {
              Pending: "orange",
              Accept: "green",
              Decline: "red",
              NextAuction: "blue",
              Prized: "purple"
            };
            return statusColors[status] || "default";
          };
          return {
            _id: item._id,
            id: index + 1,
            bid_request_code: item.bid_request_code || `BR-${index + 1}`,
            request_date: item.createdAt ? dayjs(item.createdAt).format("DD-MM-YYYY") : "N/A",
            user_name: item.subscriberName || (typeof userObject === "object" ? userObject.full_name : "N/A"),
            group_name: item.groupName || (typeof groupObject === "object" ? groupObject.group_name : "N/A"),
            ticket_number: item.ticketNumber || "-",
            auction_date: item.auctionDate ? dayjs(item.auctionDate).format("DD-MM-YYYY") : "N/A",
            auction_time: item.auction_time ? dayjs(item.auction_time, "HH:mm").format("h:mm A") : "-",
            balance,
            balance_display: `₹${balance?.toLocaleString("en-IN") || 0}`,
            status: item.status || "Pending",
            status_color: getStatusColor(item.status),
            referred_by: item.referred_by || "N/A",
            admin_user: item.adminName || "N/A",
            auction_cycle: item.auction_cycle || "N/A",
            mobileNumber: item.mobileNumber || (typeof userObject === "object" ? userObject.phone_number : "N/A"),
            next_auction_date: item.latest_auction?.next_date ? dayjs(item.latest_auction.next_date).format("DD-MM-YYYY") : "N/A"
          };
        });
        setBidRequestsData(formattedData);
      } else {
        setBidRequestsData([]);
      }
    } catch (error) {
      console.error("Error fetching bid requests:", error);
      setBidRequestsData([]);
    } finally {
      setBidRequestsLoading(false);
    }
  };
  useEffect(() => {
    if (activeTab === "bidrequest" && selectedGroup) {
      fetchCustomerBidRequests();
    }
  }, [activeTab, selectedGroup]);
  const showBidRequestDetails = (bidRequest) => {
    setSelectedBidRequest(bidRequest);
    setBidRequestModalVisible(true);
  };
  const BidRequestColumns = [
    { key: "sl_no", header: "SL. NO" },
    { key: "bid_request_code", header: "Bid Request Code" },
    { key: "request_date", header: "Request Date" },
    { key: "group_name", header: "Group Name" },
    { key: "ticket_number", header: "Ticket" },
    { key: "auction_date", header: "Auction Date" },
    { key: "auction_time", header: "Auction Time" },
    { key: "balance_display", header: "Balance" },
    { key: "status", header: "Status" }
  ];
  const fetchCustomerVisitors = async () => {
    if (!selectedGroup) return;
    try {
      setVisitorLoading(true);
      const response = await api.get(`/visitors/user/${selectedGroup}`);
      let visitors = [];
      if (Array.isArray(response.data)) {
        visitors = response.data;
      } else if (response.data.data && Array.isArray(response.data.data)) {
        visitors = response.data.data;
      } else if (response.data.visitors && Array.isArray(response.data.visitors)) {
        visitors = response.data.visitors;
      } else {
        visitors = Object.values(response.data).find((v) => Array.isArray(v)) || [];
      }
      const formattedData = visitors.map((item, index) => {
        const formatDateTime = (dateString) => {
          if (!dateString) return "N/A";
          const date = new Date(dateString);
          if (isNaN(date.getTime())) return "Invalid Date";
          const day = String(date.getDate()).padStart(2, "0");
          const month = String(date.getMonth() + 1).padStart(2, "0");
          const year = date.getFullYear();
          let hours = date.getHours();
          const minutes = String(date.getMinutes()).padStart(2, "0");
          const ampm = hours >= 12 ? "PM" : "AM";
          hours = hours % 12;
          hours = hours ? hours : 12;
          const hoursStr = String(hours).padStart(2, "0");
          return `${day}/${month}/${year} ${hoursStr}:${minutes} ${ampm}`;
        };
        return {
          _id: item._id,
          sl_no: index + 1,
          // This will be used for the sl_no column
          id: index + 1,
          visitor_code: item.visitor_code || `VIS-${index + 1}`,
          name: item.name || "N/A",
          phone: item.phone || "N/A",
          email: item.email || "-",
          purpose: item.purpose || "-",
          description: item.description || "-",
          formatted_date: formatDateTime(item.dateTime),
          meet_person: item.meetPerson?.name || "N/A",
          group_name: item.groupName || item.chitGroup || "N/A",
          ticket_number: item.ticketNumber || "-",
          status: item.status || "Completed"
        };
      });
      setVisitorData(formattedData);
    } catch (error) {
      console.error("Error fetching visitor records:", error);
      setVisitorData([]);
    } finally {
      setVisitorLoading(false);
    }
  };
  useEffect(() => {
    if (activeTab === "visitor" && selectedGroup) {
      fetchCustomerVisitors();
    }
  }, [activeTab, selectedGroup]);
  const showVisitorDetails = (visitor) => {
    setSelectedVisitor(visitor);
    setVisitorModalVisible(true);
  };
  const VisitorColumns = [
    { key: "sl_no", header: "SL. NO" },
    { key: "visitor_code", header: "Visitor Code" },
    { key: "name", header: "Visitor Name" },
    { key: "phone", header: "Phone Number" },
    { key: "email", header: "Email" },
    { key: "purpose", header: "Purpose" },
    { key: "formatted_date", header: "Visit Date & Time" },
    { key: "meet_person", header: "Whom to Meet" },
    { key: "status", header: "Status" }
  ];
  async function getCustomerPaymentStatement() {
    try {
      setStatementLoading(true);
      const response = await api.get(
        `/enroll/customer-payment/customer-statement/${enrollmentId}`
      );
      const responseData = response.data?.data?.statement ?? [];
      const filteredResponse = responseData.map((statement, index) => {
        const balanceValue = Number(statement?.balance || 0);
        const paidValue = Number(statement?.paid || 0);
        const dueValue = Number(statement?.due || 0);
        const receivedValue = Number(statement?.received || 0);
        const payType = statement?.pay_type || "-";
        const receiptNo = statement?.receipt_no || "-";
        const isPositive = balanceValue <= 0;
        const isNotPaidRow = paidValue === 0 && dueValue > 0 && statement?.description?.startsWith("Auction");
        const dateStr = `${statement?.date}`?.split("T")?.[0] ?? "-";
        const paydateStr = statement?.paydate?.split("T")?.[0] ?? "-";
        return {
          id: index + 1,
          // ---------- RAW ----------
          rawDate: dateStr,
          rawPayDate: paydateStr,
          rawBalance: balanceValue,
          rawDescription: statement?.description,
          rawDue: dueValue,
          rawPaid: paidValue,
          rawReceived: receivedValue,
          rawPayType: payType,
          rawReceiptNo: receiptNo,
          // ---------- UI ----------
          date: /* @__PURE__ */ jsxDEV("div", { className: "text-slate-500 text-xs font-medium", children: dateStr }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 1466,
            columnNumber: 11
          }, this),
          paydate: /* @__PURE__ */ jsxDEV("div", { className: "text-slate-500 text-xs font-medium", children: paydateStr }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 1469,
            columnNumber: 11
          }, this),
          description: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-slate-900 font-bold text-sm tracking-tight", children: statement?.description || "General Payment" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 1476,
              columnNumber: 15
            }, this),
            isNotPaidRow && /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] text-rose-500 font-bold uppercase tracking-widest", children: '"-"' }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 1481,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] text-slate-400 font-medium uppercase tracking-widest", children: [
              "Ref: #",
              index.toString().padStart(4, "0")
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 1486,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 1475,
            columnNumber: 11
          }, this),
          payType: /* @__PURE__ */ jsxDEV("div", { className: "text-slate-600 font-semibold text-sm", children: payType.toLocaleString("en-IN") }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 1493,
            columnNumber: 11
          }, this),
          receiptNo: /* @__PURE__ */ jsxDEV("div", { className: "text-slate-600 font-semibold text-sm", children: receiptNo.toLocaleString("en-IN") }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 1499,
            columnNumber: 11
          }, this),
          due: /* @__PURE__ */ jsxDEV("div", { className: "text-slate-600 font-semibold text-sm", children: [
            "₹",
            dueValue.toLocaleString("en-IN")
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 1505,
            columnNumber: 11
          }, this),
          paid: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `font-bold text-sm ${receivedValue > 0 ? "text-emerald-600" : "text-slate-400"}`,
              children: paidValue > 0 ? `+ ₹${paidValue.toLocaleString("en-IN")}` : "-"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 1511,
              columnNumber: 11
            },
            this
          ),
          received: /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `font-bold text-sm ${receivedValue > 0 ? "text-emerald-600" : "text-slate-400"}`,
              children: receivedValue > 0 ? `+ ₹${receivedValue.toLocaleString("en-IN")}` : "-"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 1520,
              columnNumber: 11
            },
            this
          ),
          balance: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: [
              /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: `text-sm font-black ${isPositive ? "text-green-900" : "text-rose-600"}`,
                  children: [
                    "₹",
                    Math.abs(balanceValue).toLocaleString("en-IN")
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 1533,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: `text-[9px] font-bold uppercase tracking-widest ${isPositive ? "text-emerald-400" : "text-rose-500"}`,
                  children: isPositive ? "Settled" : "Outstanding"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 1540,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 1532,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `w-1 h-8 rounded-full ${isPositive ? "bg-emerald-200" : "bg-rose-200"}`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 1548,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 1531,
            columnNumber: 11
          }, this)
        };
      });
      setActiveEnrollmentData(filteredResponse);
    } catch (error) {
      setActiveEnrollmentData([]);
    } finally {
      setStatementLoading(false);
    }
  }
  useEffect(() => {
    if (enrollmentId) getCustomerPaymentStatement();
  }, [enrollmentId]);
  useEffect(() => {
    setEnrollmentId(""), setActiveEnrollmentData([]);
  }, [selectedGroup]);
  const handleEnrollmentChange = (e) => {
    const value = e.target.value;
    if (value) setEnrollmentId(value);
  };
  const handleTransactionsSelectFilter = (value) => {
    setSelectedLabel(value);
    const today2 = /* @__PURE__ */ new Date();
    const formatDate2 = (date) => date.toISOString().slice(0, 10);
    if (value === "Custom") {
      setShowFilterField(true);
      setTotalTransactons(0);
      const startOfMonth = new Date(today2.getFullYear(), today2.getMonth(), 1);
      setSelectedFromDate(formatDate2(startOfMonth));
      setSelectedToDate(formatDate2(today2));
    } else {
      setShowFilterField(false);
      setTotalTransactons(parseInt(value));
      setSelectedFromDate("");
      setSelectedToDate("");
    }
  };
  const dayGroup = [
    { value: "200", label: "Last 200 Transactions" },
    { value: "100", label: "Last 100 Transactions" },
    { value: "50", label: "Last 50 Transactions" },
    { value: "25", label: "Last 25 Transactions" },
    { value: "Custom", label: "Custom" }
  ];
  const loanColumns = [
    { key: "sl_no", header: "SL. No" },
    { key: "loan", header: "Loan ID" },
    { key: "start_date", header: "Start Date" },
    { key: "end_date", header: "End Date" },
    { key: "loan_amount", header: "Loan Amount" },
    { key: "service_charge", header: "Service Charge" },
    { key: "tenure", header: "Tenure" },
    { key: "late_fee", header: "Late fee" },
    { key: "total_paid_amount", header: "Total Paid Amount" },
    { key: "balance", header: "Balance" }
  ];
  const pigmeColumns = [
    { key: "sl_no", header: "SL. No" },
    { key: "pigme", header: "Pigme ID" },
    { key: "start_date", header: "Start Date" },
    { key: "duration", header: "duration" },
    { key: "maturity_interest", header: "Intrest" },
    { key: "total_deposited_amount", header: "Total Deposited Amount" }
  ];
  const handleGroupAuctionChange = async (userId2) => {
    setSelectedEnrollments([]);
    setTableAuctions([]);
    setCommission(0);
    setTotalToBePaid(0);
    setNetTotalProfit(0);
    setTotalPaid(0);
    setTotalProfit(0);
    if (!userId2) return;
    const currentRequestId = Date.now();
    handleGroupAuctionChange.latestRequest = currentRequestId;
    try {
      const response = await api.get(`/v1/admin/groups/group-report?user_id=${userId2}`);
      setSelectedEnrollments(response?.data?.data);
      if (!response?.data?.data?.length) return;
      const formattedData = response?.data?.data?.map((data, index) => {
        return {
          id: index + 1,
          group: data?.group_id?.group_name || "",
          ticket: data?.tickets || "",
          totalBePaid: data?.total_payable,
          profit: data?.total_profit,
          toBePaidAmount: data?.total_payable,
          lateFee: data?.total_late_fee,
          penalty: data?.total_penalty,
          paidAmount: data?.total_investment,
          balance: data?.total_balance,
          referred_type: data?.referred_type || "N/A",
          referrer_name: data?.referred_agent?.name || "N/A",
          chit_asking_month: data?.chit_asking_month || "N/A",
          customer_status: data?.customer_status || "N/A",
          removal_reason: "N/A",
          enrollmentDate: data?.createdAt?.split("T")?.[0] || "N/A",
          isPrized: data?.is_prized ? "Prized" : "Un Prized"
        };
      }).filter(Boolean);
      setTableAuctions(formattedData);
      setTotalToBePaid(
        formattedData.reduce((sum, row) => sum + row.totalBePaid, 0)
      );
      setNetTotalProfit(
        formattedData.reduce((sum, row) => sum + row.toBePaidAmount, 0)
      );
      setTotalPaid(formattedData.reduce((sum, row) => sum + row.paidAmount, 0));
      setTotalProfit(formattedData.reduce((sum, row) => sum + row.profit, 0));
    } catch (error) {
      console.error("Error fetching enrollment data:", error);
    }
  };
  useEffect(() => {
    if (userId) {
      handleGroupAuctionChange(userId);
    }
  }, []);
  const Auctioncolumns = [
    { key: "id", header: "SL. NO" },
    { key: "customer_status", header: "Customer Status" },
    { key: "removal_reason", header: "Removal Reason" },
    { key: "group", header: "Group Name" },
    { key: "enrollmentDate", header: "Enrollment Date" },
    { key: "ticket", header: "Ticket" },
    { key: "referred_type", header: "Referrer Type" },
    { key: "referrer_name", header: "Referred By" },
    { key: "chit_asking_month", header: "Chit Asking Month" },
    { key: "isPrized", header: "Is Prized" },
    // { key: "totalBePaid", header: "Amount to be Paid" },
    { key: "profit", header: "Profit" },
    { key: "paidAmount", header: "Amount Paid" },
    { key: "lateFee", header: "Late Fee" },
    { key: "penalty", header: "Penalty" },
    { key: "toBePaidAmount", header: "Amount Payable" },
    { key: "balance", header: "Balance" }
  ];
  const formatPayDate = (dateString) => {
    const date = new Date(dateString);
    return date.toISOString().split("T")[0];
  };
  useEffect(() => {
    const fetchEnroll = async () => {
      setTableEnrolls([]);
      setBasicLoading(true);
      try {
        setIsLoading(true);
        const response = await api.get(
          `/enroll/get-user-payment?group_id=${EnrollGroupId.groupId}&ticket=${EnrollGroupId.ticket}&user_id=${selectedGroup}`
        );
        console.info(response, "test user payments");
        if (response.data && response.data.length > 0) {
          setFilteredUsers(response.data);
          const Paid = response.data;
          setGroupPaid(Paid[0].groupPaidAmount);
          const toBePaid = response.data;
          setGroupToBePaid(toBePaid[0].totalToBePaidAmount);
          let balance = 0;
          const formattedData = response.data.map((group2, index) => {
            balance += Number(group2.amount);
            return {
              _id: group2._id,
              id: index + 1,
              date: formatPayDate(group2?.pay_date),
              amount: group2.amount,
              receipt: group2.receipt_no,
              old_receipt: group2.old_receipt_no,
              type: group2.pay_type,
              balance
            };
          });
          formattedData.push({
            id: "",
            date: "",
            amount: "",
            receipt: "",
            old_receipt: "",
            type: "",
            balance
          });
          setTableEnrolls(formattedData);
        } else {
          setFilteredUsers([]);
          setTableEnrolls([]);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredUsers([]);
        setTableEnrolls([]);
      } finally {
        setBasicLoading(false);
        setIsLoading(false);
      }
    };
    if (EnrollGroupId.groupId !== "Loan" && EnrollGroupId.groupId !== "Pigme")
      fetchEnroll();
  }, [selectedGroup, EnrollGroupId.groupId, EnrollGroupId.ticket]);
  const Basiccolumns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Date" },
    { key: "amount", header: "Amount" },
    { key: "receipt", header: "Receipt No" },
    { key: "old_receipt", header: "Old Receipt No" },
    { key: "type", header: "Payment Type" },
    { key: "balance", header: "Balance" }
  ];
  const CustomerPaymentStatementColumns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Date" },
    { key: "description", header: "Description" },
    { key: "receiptNo", header: "Receipt No" },
    { key: "payType", header: "Payment Mode" },
    { key: "due", header: "Due Amount" },
    // { key: "paydate", header: "Paid Date" },
    { key: "paid", header: "Credit Amount" },
    { key: "received", header: "Debit Amount" },
    { key: "balance", header: "Balance" }
  ];
  const CustomerPaymentStatementExportsColumns = [
    { key: "id", header: "SL. NO" },
    { key: "rawDate", header: "Date" },
    { key: "rawDescription", header: "Description" },
    { key: "rawReceiptNo", header: "Receipt No" },
    { key: "rawPayType", header: "Payment Mode" },
    { key: "rawDue", header: "Due Amount" },
    // { key: "rawPayDate", header: "Paid Date" },
    { key: "rawPaid", header: "Paid Amount" },
    { key: "rawBalance", header: "Balance" }
  ];
  const formatDate = (dateString) => {
    const parts = dateString.split("-");
    if (parts.length === 3) {
      return `${parts[2]}-${parts[1]}-${parts[0]}`;
    }
    return dateString;
  };
  const formattedFromDate = formatDate(fromDate);
  const formattedToDate = formatDate(toDate);
  useEffect(() => {
    const fetchEnroll = async () => {
      try {
        const response = await api.get(
          `/group-report/get-group-enroll-date/${selectedGroup}?fromDate=${formattedFromDate}&toDate=${formattedToDate}`
        );
        if (response.data && response.data.length > 0) {
          setFilteredUsers(response.data);
          const Paid = response.data;
          setGroupPaidDate(Paid[0].groupPaidAmount || 0);
          const toBePaid = response.data;
          setGroupToBePaidDate(toBePaid[0].totalToBePaidAmount);
          const totalAmount2 = response.data.reduce(
            (sum, group2) => sum + parseInt(group2.amount),
            0
          );
          setTotalAmount(totalAmount2);
          const formattedData = response.data.map((group2, index) => ({
            id: index + 1,
            name: group2?.user?.full_name,
            phone_number: group2?.user?.phone_number,
            ticket: group2.ticket,
            amount_to_be_paid: parseInt(group2.group.group_install) + group2.totalToBePaidAmount,
            amount_paid: group2.totalPaidAmount,
            amount_balance: parseInt(group2.group.group_install) + group2.totalToBePaidAmount - group2.totalPaidAmount
          }));
          setTableEnrollsDate(formattedData);
        } else {
          setFilteredUsers([]);
          setTotalAmount(0);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredUsers([]);
        setTotalAmount(0);
      }
    };
    fetchEnroll();
  }, [selectedGroup, formattedFromDate, formattedToDate]);
  useEffect(() => {
    if (groupInfo && formData.bid_amount) {
      const commission2 = groupInfo.group_value * 5 / 100 || 0;
      const win_amount = (groupInfo.group_value || 0) - (formData.bid_amount || 0);
      const divident = (formData.bid_amount || 0) - commission2;
      const divident_head = groupInfo.group_members ? divident / groupInfo.group_members : 0;
      const payable = (groupInfo.group_install || 0) - divident_head;
      setFormData((prevData) => ({
        ...prevData,
        group_id: groupInfo._id,
        commission: commission2,
        win_amount,
        divident,
        divident_head,
        payable
      }));
    }
  }, [groupInfo, formData.bid_amount]);
  useEffect(() => {
    if (selectedGroup) {
      api.post(`/enroll/get-next-tickets/${selectedGroup}`).then((response) => {
        setAvailableTickets(response.data.availableTickets || []);
      }).catch((error) => {
        console.error("Error fetching available tickets:", error);
      });
    } else {
      setAvailableTickets([]);
    }
  }, [selectedGroup]);
  if (screenLoading)
    return /* @__PURE__ */ jsxDEV("div", { className: "w-screen m-24", children: /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-green-600" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
      lineNumber: 1920,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
      lineNumber: 1919,
      columnNumber: 5
    }, this);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-h-screen overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 mt-30", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
          lineNumber: 1928,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-center", children: "Reports - Customer" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
          lineNumber: 1933,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center w-full gap-4 bg-blue-50    p-2 w-30 h-40  rounded-3xl  border   space-x-2  ", children: /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block text-lg text-gray-500 text-center  font-semibold mb-2",
                htmlFor: "SS",
                children: "Customer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 1940,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                id: "SS",
                value: selectedAuctionGroupId || void 0,
                onChange: handleGroupPayment,
                showSearch: true,
                popupMatchSelectWidth: false,
                placeholder: "Search or Select Customer",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                style: { height: "50px", width: "600px" },
                children: groups.map(
                  (group2) => /* @__PURE__ */ jsxDEV("option", { value: group2._id, children: [
                    group2.full_name,
                    " - ",
                    group2.phone_number
                  ] }, group2._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 1962,
                    columnNumber: 23
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 1946,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 1939,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 1938,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 1937,
            columnNumber: 15
          }, this),
          selectedGroup && /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-8 p-1.5 bg-slate-100/80 backdrop-blur-md rounded-2xl inline-flex items-center gap-1 shadow-inner border border-slate-200/50 overflow-x-auto no-scrollbar max-w-full", children: [
              {
                id: "groupDetails",
                label: "Customer Details",
                icon: /* @__PURE__ */ jsxDEV(FiUser, { size: 16 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 1979,
                  columnNumber: 29
                }, this)
              },
              {
                id: "accountDeails",
                label: "Account Details",
                icon: /* @__PURE__ */ jsxDEV(FiCreditCard, { size: 16 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 1984,
                  columnNumber: 29
                }, this)
              },
              {
                id: "basicReport",
                label: "Ledger",
                icon: /* @__PURE__ */ jsxDEV(FiBookOpen, { size: 16 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 1989,
                  columnNumber: 29
                }, this)
              },
              {
                id: "customerPaymentStatement",
                label: "Statement",
                icon: /* @__PURE__ */ jsxDEV(FiFileText, { size: 16 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 1994,
                  columnNumber: 29
                }, this)
              },
              {
                id: "transactions",
                label: "Transactions",
                icon: /* @__PURE__ */ jsxDEV(FiRepeat, { size: 16 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 1999,
                  columnNumber: 29
                }, this)
              },
              {
                id: "transferHistory",
                label: "Group Change History",
                icon: /* @__PURE__ */ jsxDEV(FiRefreshCcw, { size: 16 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2004,
                  columnNumber: 29
                }, this)
              },
              {
                id: "disbursement",
                label: "Payouts",
                icon: /* @__PURE__ */ jsxDEV(FaRupeeSign, { size: 16 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2009,
                  columnNumber: 29
                }, this)
              },
              {
                id: "penalty",
                label: "Penalty",
                icon: /* @__PURE__ */ jsxDEV(FaExclamationCircle, { size: 16 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2014,
                  columnNumber: 29
                }, this)
              },
              {
                id: "bidrequest",
                label: "Bidrequest",
                icon: /* @__PURE__ */ jsxDEV(MdGavel, { size: 16 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2020,
                  columnNumber: 29
                }, this)
              },
              {
                id: "visitor",
                label: "Visitor",
                icon: /* @__PURE__ */ jsxDEV(MdPeople, { size: 16 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2025,
                  columnNumber: 29
                }, this)
              }
            ].map(
              (tab) => /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => handleTabChange(tab.id),
                  className: `flex items-center gap-2.5 px-5 py-2.5 rounded-xl text-xs font-bold tracking-wide transition-all duration-300 whitespace-nowrap ${activeTab === tab.id ? "bg-white text-blue-600 shadow-sm ring-1 ring-slate-200" : "text-slate-500 hover:text-slate-800 hover:bg-white/40"}`,
                  children: [
                    /* @__PURE__ */ jsxDEV(
                      "span",
                      {
                        className: `${activeTab === tab.id ? "text-blue-500" : "text-slate-400"}`,
                        children: tab.icon
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2036,
                        columnNumber: 27
                      },
                      this
                    ),
                    tab.label
                  ]
                },
                tab.id,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2028,
                  columnNumber: 21
                },
                this
              )
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 1974,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mb-3", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => CustomerReportPrint(
                  group,
                  TableAuctions,
                  filteredBorrowerData,
                  filteredDisbursement,
                  {
                    TotalToBepaid,
                    Totalprofit,
                    NetTotalprofit,
                    Totalpaid
                  },
                  TableEnrolls,
                  customerTransactions
                ),
                className: "flex items-center gap-2 px-6 py-2 bg-blue-500 text-white rounded shadow",
                children: [
                  /* @__PURE__ */ jsxDEV(IoMdDownload, { size: 20 }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2065,
                    columnNumber: 25
                  }, this),
                  "Download Full Report"
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 2046,
                columnNumber: 23
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 2045,
              columnNumber: 21
            }, this),
            activeTab === "groupDetails" && /* @__PURE__ */ jsxDEV(Fragment, { children: detailsLoading ? /* @__PURE__ */ jsxDEV("p", { children: "loading..." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 2073,
              columnNumber: 21
            }, this) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "relative w-full max-w-lg  ", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "absolute inset-y-0 left-4 flex items-center text-gray-400 ", children: /* @__PURE__ */ jsxDEV(FiSearch, { className: "text-xl" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2079,
                    columnNumber: 35
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2078,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      placeholder: "Search customer details...",
                      className: "w-full pl-12 pr-5 py-3.5 text-gray-800 bg-white border border-gray-200 rounded-full shadow-3xl \r\n                   placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-blue-400 \r\n                   transition-all duration-300 ease-in-out text-sm md:text-base",
                      value: searchText,
                      onChange: (e) => setSearchText(e.target.value)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 2081,
                      columnNumber: 33
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2077,
                  columnNumber: 31
                }, this),
                searchText && (() => {
                  const detailsArray = [
                    { key: "Name", value: group.full_name },
                    { key: "Email", value: group.email },
                    { key: "Phone", value: group.phone_number },
                    {
                      key: "Alternate Number",
                      value: group.alternate_number
                    },
                    { key: "Address", value: group.address },
                    { key: "Aadhaar", value: group.adhaar_no },
                    { key: "PAN", value: group.pan_no },
                    { key: "Pincode", value: group.pincode },
                    {
                      key: "Father Name",
                      value: group.father_name
                    },
                    {
                      key: "Nominee Name",
                      value: group.nominee_name
                    },
                    {
                      key: "Bank Name",
                      value: group.bank_name
                    },
                    {
                      key: "Bank Account",
                      value: group.bank_account_number
                    }
                  ];
                  const fuse = new Fuse(detailsArray, {
                    keys: ["key", "value"],
                    threshold: 0.3
                    // Fuzzy match
                  });
                  const results = fuse.search(searchText);
                  return /* @__PURE__ */ jsxDEV("div", { className: "mt-2 bg-white border rounded shadow p-3 w-1/2", children: results.length > 0 ? results.map(
                    ({ item }) => /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "p-1 border-b",
                        children: [
                          /* @__PURE__ */ jsxDEV("strong", { children: item.key }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2141,
                            columnNumber: 45
                          }, this),
                          " →",
                          " ",
                          item.value || "-"
                        ]
                      },
                      item.key,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2137,
                        columnNumber: 31
                      },
                      this
                    )
                  ) : /* @__PURE__ */ jsxDEV("p", { children: "No matching details" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2146,
                    columnNumber: 31
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2134,
                    columnNumber: 29
                  }, this);
                })()
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 2076,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-5", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-4 mb-6", children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => setVisibleRows((prev) => ({
                        ...prev,
                        row1: !prev.row1
                      })),
                      className: `px-5 py-2 rounded-lg text-sm font-semibold transition-all duration-300 ease-in-out
        ${visibleRows.row1 ? "bg-gradient-to-r from-green-500 to-green-700 text-white shadow-lg" : "bg-gradient-to-r from-blue-700 to-blue-900 text-white shadow-md hover:shadow-lg hover:scale-105"}
      `,
                      children: visibleRows.row1 ? "✓ Hide Basic Info" : "Show Basic Info"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 2156,
                      columnNumber: 33
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => setVisibleRows((prev) => ({
                        ...prev,
                        row2: !prev.row2
                      })),
                      className: `px-5 py-2 rounded-lg text-sm font-semibold transition-all duration-300 ease-in-out
        ${visibleRows.row2 ? "bg-gradient-to-r from-green-500 to-green-700 text-white shadow-lg" : "bg-gradient-to-r from-blue-700 to-blue-900 text-white shadow-md hover:shadow-lg hover:scale-105"}
      `,
                      children: visibleRows.row2 ? "✓ Hide Address Info" : "Show Address Info"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 2175,
                      columnNumber: 33
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => setVisibleRows((prev) => ({
                        ...prev,
                        row3: !prev.row3
                      })),
                      className: `px-5 py-2 rounded-lg text-sm font-semibold transition-all duration-300 ease-in-out
        ${visibleRows.row3 ? "bg-gradient-to-r from-green-500 to-green-700 text-white shadow-lg" : "bg-gradient-to-r from-blue-700 to-blue-900 text-white shadow-md hover:shadow-lg hover:scale-105"}
      `,
                      children: visibleRows.row3 ? "✓ Hide Regional Info" : "Show Regional Info"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 2194,
                      columnNumber: 33
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => setVisibleRows((prev) => ({
                        ...prev,
                        row4: !prev.row4
                      })),
                      className: `px-5 py-2 rounded-lg text-sm font-semibold transition-all duration-300 ease-in-out
        ${visibleRows.row4 ? "bg-gradient-to-r from-green-500 to-green-700 text-white shadow-lg" : "bg-gradient-to-r from-blue-700 to-blue-900 text-white shadow-md hover:shadow-lg hover:scale-105"}
      `,
                      children: visibleRows.row4 ? "✓ Hide Referral, Nominee & Bank Details" : "Show Referral, Nominee & Bank Details"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 2213,
                      columnNumber: 33
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2155,
                  columnNumber: 31
                }, this),
                visibleRows.row1 && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-8 mb-6", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col w-full gap-4", children: [
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Name",
                        value: group.full_name
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2237,
                        columnNumber: 37
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(Input, { label: "Email", value: group.email }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 2241,
                      columnNumber: 37
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2236,
                    columnNumber: 35
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Phone Number",
                        value: group.phone_number
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2244,
                        columnNumber: 37
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Adhaar Number",
                        value: group.adhaar_no
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2248,
                        columnNumber: 37
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2243,
                    columnNumber: 35
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "PAN Number",
                        value: group.pan_no
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2254,
                        columnNumber: 37
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Pincode",
                        value: group.pincode
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2258,
                        columnNumber: 37
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2253,
                    columnNumber: 35
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2235,
                  columnNumber: 25
                }, this),
                visibleRows.row2 && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-8 mb-6", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Address",
                        value: group.address
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2270,
                        columnNumber: 37
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Gender",
                        value: group.gender
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2274,
                        columnNumber: 37
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2269,
                    columnNumber: 35
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Date of Birth",
                        value: group.dateofbirth ? new Date(group.dateofbirth).toISOString().split("T")[0] : ""
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2280,
                        columnNumber: 37
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Collection Area",
                        value: group?.collection_area?.route_name
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2290,
                        columnNumber: 37
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2279,
                    columnNumber: 35
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Marital Status",
                        value: group.marital_status
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2296,
                        columnNumber: 37
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Father Name",
                        value: group.father_name
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2300,
                        columnNumber: 37
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2295,
                    columnNumber: 35
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2268,
                  columnNumber: 25
                }, this),
                visibleRows.row3 && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-8 mb-6", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Nationality",
                        value: group.nationality
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2312,
                        columnNumber: 37
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Village",
                        value: group.village
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2316,
                        columnNumber: 37
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2311,
                    columnNumber: 35
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                    /* @__PURE__ */ jsxDEV(Input, { label: "Taluk", value: group.taluk }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 2322,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "District",
                        value: group.district
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2323,
                        columnNumber: 37
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2321,
                    columnNumber: 35
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                    /* @__PURE__ */ jsxDEV(Input, { label: "State", value: group.state }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 2329,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Alternate Number",
                        value: group.alternate_number
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2330,
                        columnNumber: 37
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2328,
                    columnNumber: 35
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2310,
                  columnNumber: 25
                }, this),
                visibleRows.row4 && /* @__PURE__ */ jsxDEV("div", { className: "flex gap-8 mb-6", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Referral Name",
                        value: group.referral_name
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2342,
                        columnNumber: 37
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Nominee Name",
                        value: group.nominee_name
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2346,
                        columnNumber: 37
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Nominee DOB",
                        value: group.nominee_dateofbirth ? new Date(group.nominee_dateofbirth).toISOString().split("T")[0] : ""
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2350,
                        columnNumber: 37
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2341,
                    columnNumber: 35
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Nominee Phone Number",
                        value: group.nominee_phone_number
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2362,
                        columnNumber: 37
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Nominee Relationship",
                        value: group.nominee_relationship
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2366,
                        columnNumber: 37
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Bank Name",
                        value: group.bank_name
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2370,
                        columnNumber: 37
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2361,
                    columnNumber: 35
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 w-full", children: [
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Bank Branch Name",
                        value: group.bank_branch_name
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2376,
                        columnNumber: 37
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Bank Account Number",
                        value: group.bank_account_number
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2380,
                        columnNumber: 37
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        label: "Bank IFSC Code",
                        value: group.bank_IFSC_code
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2384,
                        columnNumber: 37
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2375,
                    columnNumber: 35
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2340,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 2153,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium mb-4", children: "Enrolled Groups" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2394,
                  columnNumber: 31
                }, this),
                TableAuctions && TableAuctions.length > 0 && !isLoading && /* @__PURE__ */ jsxDEV("div", { className: "mt-5", children: /* @__PURE__ */ jsxDEV(
                  DataTable,
                  {
                    data: filterOption(
                      TableAuctions,
                      searchText
                    ),
                    columns: Auctioncolumns,
                    exportedPdfName: "Customer Chit Enrollment Details",
                    printHeaderKeys: [
                      "Customer Name",
                      "Phone Number",
                      "Total Amount To Be Paid",
                      "Total Profit",
                      "Total Net To be Paid",
                      "Total Balance"
                    ],
                    printHeaderValues: [
                      group.full_name,
                      group?.phone_number,
                      TotalToBepaid,
                      Totalprofit,
                      NetTotalprofit,
                      NetTotalprofit && Totalpaid ? NetTotalprofit - Totalpaid : ""
                    ],
                    exportedFileName: `Customer Chit Enrollment Details.csv`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2402,
                    columnNumber: 37
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2401,
                  columnNumber: 25
                }, this),
                filteredBorrowerData && filteredBorrowerData.length > 0 && !isLoading && /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium mb-4", children: "Loan Details" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2436,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    DataTable,
                    {
                      data: filteredBorrowerData,
                      columns: loanColumns,
                      exportedFileName: "Loan Details.csv",
                      exportedPdfName: "Loan Details"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 2439,
                      columnNumber: 37
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2435,
                  columnNumber: 25
                }, this),
                filteredPigmeData && filteredPigmeData.length > 0 && !isLoading && /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-medium mb-4", children: "Pigme Details" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2452,
                    columnNumber: 37
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    DataTable,
                    {
                      data: filteredPigmeData,
                      columns: pigmeColumns,
                      exportedFileName: "Pigmy Details.csv",
                      exportedPdfName: "Pigmy Details"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 2455,
                      columnNumber: 37
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2451,
                  columnNumber: 25
                }, this),
                !isLoading && TableAuctions.length === 0 && filteredBorrowerData.length === 0 && filteredPigmeData.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "p-20 w-full flex justify-center items-center text-gray-500", children: "No Chit Group, Loan, or Pigme data found for this customer" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2468,
                  columnNumber: 25
                }, this),
                isLoading && /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2475,
                  columnNumber: 25
                }, this),
                !isLoading && TableAuctions.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "p-40 w-full flex justify-center items-center", children: "No Enrolled Group Data Found" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2479,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 2393,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 mt-5", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "mb-1 text-sm font-medium text-gray-700", children: "Total Amount to be Paid" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2486,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      placeholder: "-",
                      value: TotalToBepaid || "",
                      readOnly: true,
                      className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 2489,
                      columnNumber: 33
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2485,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "mb-1 text-sm font-medium text-gray-700", children: "Total Profit" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2498,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      placeholder: "-",
                      value: Totalprofit || "",
                      readOnly: true,
                      className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 2501,
                      columnNumber: 33
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2497,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "mb-1 text-sm font-medium text-gray-700", children: "Total Net To be Paid" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2510,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      placeholder: "-",
                      value: NetTotalprofit || "",
                      readOnly: true,
                      className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 2513,
                      columnNumber: 33
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2509,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "mb-1 text-sm font-medium text-gray-700", children: "Total Amount Paid" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2522,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      placeholder: "-",
                      value: Totalpaid || "",
                      readOnly: true,
                      className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 2525,
                      columnNumber: 33
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2521,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "mb-1 text-sm font-medium text-gray-700", children: "Total Balance" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2534,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      type: "text",
                      placeholder: "-",
                      value: NetTotalprofit && Totalpaid ? NetTotalprofit - Totalpaid : "",
                      readOnly: true,
                      className: "border border-gray-300 rounded px-4 py-2 shadow-sm outline-none w-full"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 2537,
                      columnNumber: 33
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2533,
                  columnNumber: 31
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 2484,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 2075,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 2071,
              columnNumber: 19
            }, this),
            activeTab === "accountDeails" && /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-2xl shadow-md p-5 mt-4 space-y-6 overflow-x-auto", children: accountDetailsLoading ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-10 text-blue-600 font-semibold text-lg animate-pulse", children: "Loading Account Details..." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 2559,
              columnNumber: 21
            }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-5 gap-4 ", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-gray-100 rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-semibold uppercase tracking-widest text-gray-400 mb-2", children: "Customer Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2567,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("h2", { className: "font-semibold text-gray-900 text-sm truncate", children: accountDetails?.userDetails?.full_name || "—" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2570,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2566,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-gray-100 rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-semibold uppercase tracking-widest text-gray-400 mb-2", children: "Customer ID" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2576,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("h2", { className: "font-mono font-semibold text-gray-900 text-sm truncate", children: accountDetails?.userDetails?.customer_id || "—" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2579,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2575,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-gray-100 rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-semibold uppercase tracking-widest text-gray-400 mb-2", children: "Phone Number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2585,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("h2", { className: "font-semibold text-gray-900 text-sm", children: accountDetails?.userDetails?.phone_number || "—" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2588,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2584,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-emerald-50 border border-emerald-100 rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-semibold uppercase tracking-widest text-emerald-600 mb-2", children: "Balance" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2594,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("h2", { className: "font-mono font-bold text-emerald-700 text-xl", children: [
                    "₹",
                    accountDetails?.balance?.toLocaleString() || 0
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2597,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2593,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-gray-100 rounded-2xl p-4 shadow-sm hover:shadow-md transition-shadow", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-semibold uppercase tracking-widest text-gray-400 mb-2", children: "Created Date" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2603,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("h2", { className: "font-semibold text-gray-900 text-sm", children: accountDetails?.createdAt ? new Date(accountDetails.createdAt).toLocaleDateString() : "—" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2606,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2602,
                  columnNumber: 31
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 2565,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
                  /* @__PURE__ */ jsxDEV("h2", { className: "text-sm font-semibold uppercase tracking-widest text-gray-400", children: "User Accounts" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2617,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm", children: [
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        onClick: () => setView("grid"),
                        className: `flex items-center gap-1.5 px-3 py-2 text-xs font-medium transition-all ${view === "grid" ? "bg-gray-900 text-white" : "text-gray-500 hover:bg-gray-50"}`,
                        children: [
                          /* @__PURE__ */ jsxDEV(
                            "svg",
                            {
                              className: "w-3.5 h-3.5",
                              viewBox: "0 0 16 16",
                              fill: "none",
                              stroke: "currentColor",
                              strokeWidth: "1.5",
                              children: [
                                /* @__PURE__ */ jsxDEV("rect", { x: "1", y: "1", width: "6", height: "6", rx: "1" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                                  lineNumber: 2637,
                                  columnNumber: 39
                                }, this),
                                /* @__PURE__ */ jsxDEV("rect", { x: "9", y: "1", width: "6", height: "6", rx: "1" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                                  lineNumber: 2638,
                                  columnNumber: 39
                                }, this),
                                /* @__PURE__ */ jsxDEV("rect", { x: "1", y: "9", width: "6", height: "6", rx: "1" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                                  lineNumber: 2639,
                                  columnNumber: 39
                                }, this),
                                /* @__PURE__ */ jsxDEV("rect", { x: "9", y: "9", width: "6", height: "6", rx: "1" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                                  lineNumber: 2640,
                                  columnNumber: 39
                                }, this)
                              ]
                            },
                            void 0,
                            true,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2630,
                              columnNumber: 37
                            },
                            this
                          ),
                          "Grid"
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2623,
                        columnNumber: 35
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        onClick: () => setView("list"),
                        className: `flex items-center gap-1.5 px-3 py-2 text-xs font-medium transition-all ${view === "list" ? "bg-gray-900 text-white" : "text-gray-500 hover:bg-gray-50"}`,
                        children: [
                          /* @__PURE__ */ jsxDEV(
                            "svg",
                            {
                              className: "w-3.5 h-3.5",
                              viewBox: "0 0 16 16",
                              fill: "none",
                              stroke: "currentColor",
                              strokeWidth: "1.5",
                              children: [
                                /* @__PURE__ */ jsxDEV("line", { x1: "1", y1: "4", x2: "15", y2: "4" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                                  lineNumber: 2658,
                                  columnNumber: 39
                                }, this),
                                /* @__PURE__ */ jsxDEV("line", { x1: "1", y1: "8", x2: "15", y2: "8" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                                  lineNumber: 2659,
                                  columnNumber: 39
                                }, this),
                                /* @__PURE__ */ jsxDEV("line", { x1: "1", y1: "12", x2: "15", y2: "12" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                                  lineNumber: 2660,
                                  columnNumber: 39
                                }, this)
                              ]
                            },
                            void 0,
                            true,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2651,
                              columnNumber: 37
                            },
                            this
                          ),
                          "List"
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2644,
                        columnNumber: 35
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2622,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2616,
                  columnNumber: 31
                }, this),
                view === "grid" && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4", children: accountDetails?.useraccounts?.length > 0 ? accountDetails.useraccounts.map(
                  (item, index) => /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "bg-white rounded-2xl border border-gray-100 shadow-sm p-5 hover:shadow-md hover:border-gray-200 transition-all",
                      children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4", children: [
                          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-mono text-gray-400 bg-gray-50 border border-gray-200 px-2.5 py-0.5 rounded-full", children: [
                            "#",
                            String(index + 1).padStart(2, "0")
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2678,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            "span",
                            {
                              className: `text-[11px] font-semibold px-3 py-0.5 rounded-full tracking-wide ${item.type === "CREDIT" ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"}`,
                              children: item.type
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2681,
                              columnNumber: 43
                            },
                            this
                          )
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                          lineNumber: 2677,
                          columnNumber: 41
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          "p",
                          {
                            className: `font-mono font-bold text-2xl mb-3 ${item.type === "CREDIT" ? "text-green-600" : "text-red-600"}`,
                            children: [
                              item.type === "CREDIT" ? "+" : "–",
                              "₹",
                              Math.abs(Number(item.amount || 0)).toLocaleString()
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2692,
                            columnNumber: 41
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV("div", { className: "border-t border-gray-100 pt-3 grid grid-cols-2 gap-x-4 gap-y-2.5 text-sm", children: [
                          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400", children: "Group / Loan / Pigmy" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2703,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-gray-800 text-right truncate", children: item?.group_id?.group_name && item?.ticket ? `${item.group_id.group_name} Ticket ${item.ticket}` : item?.loan?.loan_id ? item.loan.loan_id : item?.pigme?.pigme_id ? item.pigme.pigme_id : "—" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2707,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400", children: "Reason" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2718,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-gray-800 text-right truncate", children: item?.reason || "—" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2719,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400", children: "Gross Amount" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2724,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-gray-800 text-right", children: [
                            "₹",
                            Number(item?.gross_amount || 0).toLocaleString()
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2725,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400", children: "Service Charge" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2730,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-gray-800 text-right", children: [
                            "₹",
                            Number(item?.service_charge || 0).toLocaleString()
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2731,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400", children: "GST" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2736,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-gray-800 text-right", children: [
                            "₹",
                            Number(item?.gst_amount || 0).toLocaleString()
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2737,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400", children: "INTEREST" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2742,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-gray-800 text-right", children: [
                            "₹",
                            (item?.interest_amount || 0).toLocaleString()
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2743,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400", children: "Net Amount" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2748,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            "span",
                            {
                              className: `text-xs font-bold text-right ${item.type === "CREDIT" ? "text-green-600" : "text-red-600"}`,
                              children: [
                                item.type === "CREDIT" ? "+" : "–",
                                "₹",
                                Math.abs(Number(item?.amount || 0)).toLocaleString()
                              ]
                            },
                            void 0,
                            true,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2749,
                              columnNumber: 43
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400", children: "Admin" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2758,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: [
                            /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-800", children: item?.admin_id?.name || "—" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2760,
                              columnNumber: 45
                            }, this),
                            /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-mono text-gray-500", children: item?.admin_id?.admin_code || "" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2763,
                              columnNumber: 45
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2759,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400", children: "Direction" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2769,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            "span",
                            {
                              className: `text-xs font-semibold px-2 py-0.5 rounded-full inline-block text-right ${item?.payment_direction === "OUT" ? "bg-red-100 text-red-700" : "bg-blue-100 text-blue-700"}`,
                              children: item?.payment_direction || "IN"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2770,
                              columnNumber: 43
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400", children: "Date" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2780,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-mono text-gray-500 text-right", children: new Date(item.createdAt).toLocaleString() }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2781,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-gray-400", children: "To User" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2786,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-mono text-gray-500 text-right", children: [
                            item.to_user?.full_name || "-",
                            "      ",
                            item.to_loan?.loan_id || "-"
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2787,
                            columnNumber: 43
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                          lineNumber: 2701,
                          columnNumber: 41
                        }, this)
                      ]
                    },
                    item._id,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 2672,
                      columnNumber: 27
                    },
                    this
                  )
                ) : /* @__PURE__ */ jsxDEV("div", { className: "col-span-full text-center py-10 text-gray-400 text-sm", children: "No account records found" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2794,
                  columnNumber: 27
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2669,
                  columnNumber: 25
                }, this),
                view === "list" && /* @__PURE__ */ jsxDEV("div", { className: "rounded-2xl border border-gray-200 shadow-sm bg-white overflow-auto", children: [
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: "\r\n        hidden md:grid\r\n        grid-cols-[60px_90px_100px_220px_160px_180px_150px_150px_130px_150px_150px_160px]\r\n        gap-x-8 px-6 py-4\r\n        bg-gray-50 border-b border-gray-200\r\n      ",
                      children: [
                        "SL NO",
                        "DATE",
                        "TYPE",
                        "FROM:(GROUP / Loan / Pigmy)",
                        "TO USER",
                        "REASON",
                        "GROSS AMOUNT",
                        "SERVICE CHARGE",
                        "GST",
                        "INTEREST",
                        "NET AMOUNT",
                        "ADMIN"
                      ].map((h, i) => {
                        const isNumeric = i >= 6 && i <= 10;
                        return /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: `text-[11px] font-semibold uppercase tracking-wider text-gray-500 ${isNumeric ? "text-right" : "text-left"}`,
                            children: h
                          },
                          h,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2830,
                            columnNumber: 33
                          },
                          this
                        );
                      })
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 2805,
                      columnNumber: 35
                    },
                    this
                  ),
                  accountDetails?.useraccounts?.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "divide-y divide-gray-100", children: accountDetails.useraccounts.map(
                    (item, index) => /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "\r\n              grid grid-cols-1\r\n              md:grid-cols-[60px_90px_100px_220px_160px_180px_150px_150px_130px_150px_150px_160px]\r\n              gap-x-8 px-6 py-5 items-center\r\n              hover:bg-blue-50 transition-all\r\n            ",
                        children: [
                          /* @__PURE__ */ jsxDEV("div", { className: "hidden md:block text-sm text-gray-500", children: String(index + 1).padStart(2, "0") }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2855,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { children: [
                            /* @__PURE__ */ jsxDEV("p", { className: "text-sm", children: new Date(item.createdAt).toLocaleDateString("en-IN") }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2861,
                              columnNumber: 45
                            }, this),
                            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: new Date(item.createdAt).toLocaleTimeString("en-IN", {
                              hour: "2-digit",
                              minute: "2-digit"
                            }) }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2865,
                              columnNumber: 45
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2860,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
                            "span",
                            {
                              className: `inline-flex px-3 py-1 rounded-full text-xs font-semibold ${item.type === "CREDIT" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`,
                              children: item.type
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2875,
                              columnNumber: 45
                            },
                            this
                          ) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2874,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold truncate", children: item?.group_id?.group_name && item?.ticket ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                            /* @__PURE__ */ jsxDEV("span", { className: "block truncate", children: item.group_id.group_name }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2890,
                              columnNumber: 51
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { className: "block text-xs text-gray-500 mt-1", children: [
                              "Ticket ",
                              item.ticket
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2894,
                              columnNumber: 51
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2889,
                            columnNumber: 35
                          }, this) : item?.loan?.loan_id ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                            /* @__PURE__ */ jsxDEV("span", { className: "block truncate", children: item.loan.loan_id }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2900,
                              columnNumber: 51
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { className: "block text-xs text-gray-500 mt-1", children: [
                              "Loan ₹ ",
                              item.loan.loan_amount
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2904,
                              columnNumber: 51
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2899,
                            columnNumber: 35
                          }, this) : item?.pigme?.pigme_id ? /* @__PURE__ */ jsxDEV("span", { className: "block truncate", children: item.pigme.pigme_id }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2909,
                            columnNumber: 35
                          }, this) : "—" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2887,
                            columnNumber: 45
                          }, this) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2886,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
                            /* @__PURE__ */ jsxDEV("p", { className: "text-sm truncate", children: item.to_user?.full_name || "-" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2920,
                              columnNumber: 45
                            }, this),
                            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 truncate", children: item.to_user?.phone_number || "-" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2924,
                              columnNumber: 45
                            }, this),
                            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 truncate", children: item.to_loan?.loan_id || "-" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2928,
                              columnNumber: 45
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2919,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { className: "truncate text-sm", children: item.reason || "-" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2934,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            "div",
                            {
                              className: `font-bold text-right whitespace-nowrap ${item.type === "CREDIT" ? "text-green-600" : "text-red-600"}`,
                              children: item.gross_amount ? `${item.type === "CREDIT" ? "+" : "–"} ₹${Number(
                                item.gross_amount
                              ).toLocaleString("en-IN")}` : "-"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2939,
                              columnNumber: 43
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV("div", { className: "font-bold text-right text-red-600 whitespace-nowrap", children: item.service_charge ? `– ₹${Number(item.service_charge).toLocaleString("en-IN")}` : "-" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2953,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { className: "font-bold text-right text-red-600 whitespace-nowrap", children: item.gst_amount ? `– ₹${Number(item.gst_amount).toLocaleString("en-IN")}` : "-" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2960,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { className: "font-bold text-right text-gray-600 whitespace-nowrap", children: [
                            "₹",
                            Number(item?.interest_amount || 0).toLocaleString("en-IN")
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2967,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            "div",
                            {
                              className: `text-right font-bold whitespace-nowrap ${item.type === "CREDIT" ? "text-green-600" : "text-red-600"}`,
                              children: [
                                item.type === "CREDIT" ? "+" : "–",
                                "₹",
                                Math.abs(Number(item.amount || 0)).toLocaleString("en-IN")
                              ]
                            },
                            void 0,
                            true,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2973,
                              columnNumber: 43
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV("div", { className: "border-l pl-4 min-w-0", children: item.admin_id ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
                            /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-sm truncate", children: item.admin_id.name }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2987,
                              columnNumber: 49
                            }, this),
                            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 truncate", children: item.admin_id.admin_code }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 2991,
                              columnNumber: 49
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2986,
                            columnNumber: 33
                          }, this) : "-" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 2984,
                            columnNumber: 43
                          }, this)
                        ]
                      },
                      item._id,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 2845,
                        columnNumber: 29
                      },
                      this
                    )
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 2843,
                    columnNumber: 27
                  }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-10 text-gray-400 text-sm", children: "No account records found" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3003,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 2803,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 2615,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 2563,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 2556,
              columnNumber: 19
            }, this),
            activeTab === "basicReport" && /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "mb-1 text-sm font-medium text-gray-700", children: "Groups and Tickets" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3021,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    value: EnrollGroupId.groupId ? `${EnrollGroupId.groupId}|${EnrollGroupId.ticket}` : "",
                    onChange: handleEnrollGroup,
                    className: "border border-gray-300 rounded px-6 py-2 shadow-sm outline-none w-full max-w-md",
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Group | Ticket" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 3033,
                        columnNumber: 33
                      }, this),
                      selectedEnrollments.map((group2) => {
                        if (group2?.group_id && ["Active", "On Hold"].find(
                          (status) => status === group2?.customer_status
                        )) {
                          return /* @__PURE__ */ jsxDEV(
                            "option",
                            {
                              value: `${group2?.group_id?._id}|${group2?.tickets}`,
                              children: [
                                group2?.group_id?.group_name,
                                " |",
                                " ",
                                group2?.tickets
                              ]
                            },
                            group2?.group_id?._id,
                            true,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 3045,
                              columnNumber: 35
                            },
                            this
                          );
                        }
                        return null;
                      }),
                      Array.isArray(loanCustomers?.overall_loan) && loanCustomers.overall_loan.map(
                        (loan, index) => /* @__PURE__ */ jsxDEV(
                          "option",
                          {
                            value: `Loan|${loan?.loan_details?.loan?._id || index}`,
                            children: [
                              loan?.loan_details?.loan?.loan_id || "N/A",
                              " ",
                              "| ₹",
                              loan?.loan_value || 0
                            ]
                          },
                          loan?.loan_details?.loan?._id || index,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 3060,
                            columnNumber: 31
                          },
                          this
                        )
                      ),
                      Array.isArray(pigmeCustomers?.overall_pigme) && pigmeCustomers.overall_pigme.map(
                        (pigme, index) => /* @__PURE__ */ jsxDEV(
                          "option",
                          {
                            value: `Pigme|${pigme?.pigme_details?.pigme?._id || index}`,
                            children: [
                              pigme?.pigme_details?.pigme?.pigme_id || "N/A",
                              " ",
                              "| ₹",
                              pigme?.total_deposited_amount || 0
                            ]
                          },
                          pigme?.pigme_details?.pigme?._id || index,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 3077,
                            columnNumber: 31
                          },
                          this
                        )
                      )
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3024,
                    columnNumber: 31
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3020,
                columnNumber: 29
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3019,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-6 flex justify-center gap-8 flex-wrap", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    value: `Registration Fee: ₹${registrationAmount || 0}`,
                    readOnly: true,
                    className: "px-4 py-2 border rounded font-semibold w-60 text-center bg-green-100 text-green-800 border-green-400"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3097,
                    columnNumber: 29
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    value: `Payment Balance: ₹${finalPaymentBalance}`,
                    readOnly: true,
                    className: "px-4 py-2 border rounded font-semibold w-60 text-center bg-blue-100 text-blue-800 border-blue-400"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3104,
                    columnNumber: 29
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    value: `Total: ₹${Number(finalPaymentBalance) + Number(registrationAmount || 0)}`,
                    readOnly: true,
                    className: "px-4 py-2 border rounded font-semibold w-60 text-center bg-purple-100 text-purple-800 border-purple-400"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3110,
                    columnNumber: 29
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3096,
                columnNumber: 27
              }, this),
              (TableEnrolls?.length > 0 || borrowersData?.length > 0 || pigmeCustomerData?.length > 0) && !basicLoading ? /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: /* @__PURE__ */ jsxDEV(
                DataTable,
                {
                  exportedPdfName: "Customer Ledger Report",
                  exportedFileName: "Customer Ledger Report.csv",
                  printHeaderKeys: EnrollGroupId.groupId === "Loan" ? [
                    "Customer Name",
                    "Customer Id",
                    "Phone Number",
                    "Loan ID",
                    "Loan Type"
                  ] : EnrollGroupId.groupId === "Pigme" ? [
                    "Customer Name",
                    "Customer Id",
                    "Phone Number",
                    "Pigmy ID",
                    "Pigmy Type"
                  ] : [
                    "Customer Name",
                    "Customer Id",
                    "Phone Number",
                    "Ticket Number",
                    "Group Name"
                  ],
                  printHeaderValues: EnrollGroupId.groupId === "Loan" ? [
                    group?.full_name,
                    group?.customer_id,
                    group?.phone_number,
                    (() => {
                      const selectedLoan = loanCustomers?.overall_loan?.find(
                        (loan) => loan?.loan_details?.loan?._id === EnrollGroupId.ticket
                      );
                      return selectedLoan?.loan_details?.loan?.loan_id || EnrollGroupId.ticket;
                    })(),
                    "Loan"
                  ] : EnrollGroupId.groupId === "Pigme" ? [
                    group?.full_name,
                    group?.customer_id,
                    group?.phone_number,
                    (() => {
                      const selectedPigme = pigmeCustomers?.overall_pigme?.find(
                        (pigme) => pigme?.pigme_details?.pigme?._id === EnrollGroupId.ticket
                      );
                      return selectedPigme?.pigme_details?.pigme?.pigme_id || EnrollGroupId.ticket;
                    })(),
                    "Pigmy"
                  ] : [
                    group?.full_name,
                    group?.customer_id,
                    group?.phone_number,
                    EnrollGroupId?.ticket,
                    groupDetails?.group_name
                  ],
                  data: EnrollGroupId?.groupId === "Loan" ? borrowersData : EnrollGroupId?.groupId === "Pigme" ? pigmeCustomerData : TableEnrolls,
                  columns: EnrollGroupId?.groupId === "Loan" ? BasicLoanColumns : EnrollGroupId?.groupId === "Pigme" ? BasicPigmeColumns : Basiccolumns
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3125,
                  columnNumber: 31
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3124,
                columnNumber: 23
              }, this) : /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: basicLoading }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3222,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 3018,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 3017,
              columnNumber: 19
            }, this),
            activeTab === "disbursement" && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "mb-1 text-sm  text-gray-700 font-bold", children: "Disbursement" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3230,
                columnNumber: 25
              }, this),
              disbursementLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3235,
                columnNumber: 21
              }, this) : filteredDisbursement?.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: /* @__PURE__ */ jsxDEV(
                DataTable,
                {
                  data: filteredDisbursement,
                  columns: DisbursementColumns,
                  exportedPdfName: `Customer Payout Report`,
                  exportedFileName: `Customer Payout Report.csv`,
                  printHeaderKeys: [
                    "Customer Name",
                    "Phone Number"
                  ],
                  printHeaderValues: [
                    group?.full_name,
                    group?.phone_number
                  ]
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3238,
                  columnNumber: 29
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3237,
                columnNumber: 21
              }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p-40  w-full flex justify-center items-center ", children: "No Disbursement Data Found" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3254,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 3229,
              columnNumber: 19
            }, this),
            activeTab === "customerPaymentStatement" && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "mb-1 text-sm  text-gray-700 font-bold", children: "Customer Payment Statement" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3263,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ function() {
              }(),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "mb-1 text-sm font-medium text-gray-700", children: "Groups and Tickets" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3268,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    value: enrollmentId,
                    onChange: handleEnrollmentChange,
                    className: "border border-gray-300 rounded px-6 py-2 shadow-sm outline-none w-full max-w-md",
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Group | Ticket" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 3276,
                        columnNumber: 29
                      }, this),
                      enrollmentData.map((e) => {
                        return /* @__PURE__ */ jsxDEV("option", { value: `${e?._id}`, children: [
                          e?.group_id?.group_name,
                          " | ",
                          e?.tickets
                        ] }, e?._id, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                          lineNumber: 3280,
                          columnNumber: 29
                        }, this);
                      })
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3271,
                    columnNumber: 27
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3267,
                columnNumber: 25
              }, this),
              statementLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3288,
                columnNumber: 21
              }, this) : activeEnrollmentData?.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: /* @__PURE__ */ jsxDEV(
                DataTable,
                {
                  data: activeEnrollmentData,
                  columns: CustomerPaymentStatementColumns,
                  exportCols: CustomerPaymentStatementExportsColumns,
                  exportedPdfName: `Customer Statement Report`,
                  exportedFileName: `Customer Statement.csv`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3291,
                  columnNumber: 29
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3290,
                columnNumber: 21
              }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p-40  w-full flex justify-center items-center ", children: "No Customer Payment Statement Found" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3302,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 3262,
              columnNumber: 19
            }, this),
            activeTab === "transactions" && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "m-4 text-sm  text-gray-700 font-bold", children: "Transactions" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3311,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "my-6 relative overflow-hidden group bg-gradient-to-br from-white to-blue-50 border border-blue-100 rounded-2xl p-4 shadow-sm transition-all duration-300 hover:shadow-md hover:border-blue-300", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "absolute -right-2 -bottom-2 text-blue-100/40 group-hover:text-blue-200/50 transition-colors", children: /* @__PURE__ */ jsxDEV(MdAccountBalanceWallet, { size: 80 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3318,
                  columnNumber: 29
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3317,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "relative z-10 flex items-center gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center w-12 h-12 bg-blue-600 rounded-xl shadow-lg shadow-blue-200", children: /* @__PURE__ */ jsxDEV(MdAccountBalanceWallet, { className: "text-white text-2xl" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3324,
                    columnNumber: 31
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3323,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-bold text-slate-400 uppercase tracking-widest leading-none mb-1", children: "Total Amount" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3328,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-baseline gap-1", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-bold text-blue-600", children: "₹" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 3332,
                        columnNumber: 33
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-black text-slate-800 tracking-tight", children: totalTransactionAmount.toLocaleString(
                        "en-IN"
                      ) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 3335,
                        columnNumber: 33
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3331,
                      columnNumber: 31
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3327,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3321,
                  columnNumber: 27
                }, this),
                totalTransactionAmount > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-3 pt-3 border-t border-blue-100/50", children: /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-medium text-blue-500 italic leading-tight", children: [
                  numberToIndianWords(totalTransactionAmount),
                  " ",
                  "Only"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3347,
                  columnNumber: 31
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3346,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3315,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-slate-700", children: "Date Range" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3357,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      showSearch: true,
                      popupMatchSelectWidth: false,
                      onChange: handleTransactionsSelectFilter,
                      value: selectedLabel || void 0,
                      placeholder: "Last 50 Transactions",
                      filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                      className: "w-full",
                      style: { height: "44px" },
                      children: dayGroup.map(
                        (time) => /* @__PURE__ */ jsxDEV(
                          Select.Option,
                          {
                            value: time.value,
                            children: time.label
                          },
                          time.value,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 3376,
                            columnNumber: 27
                          },
                          this
                        )
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3360,
                      columnNumber: 29
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3356,
                  columnNumber: 27
                }, this),
                showFilterField && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "From Date" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3390,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "date",
                        value: selectedFromDate,
                        onChange: (e) => setSelectedFromDate(e.target.value),
                        className: "w-full h-11 border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 3393,
                        columnNumber: 33
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3389,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700", children: "To Date" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3403,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "date",
                        value: selectedToDate,
                        onChange: (e) => setSelectedToDate(e.target.value),
                        className: "w-full h-11 border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 3406,
                        columnNumber: 33
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3402,
                    columnNumber: 31
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3388,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-slate-700", children: "Payment Mode" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3419,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      mode: "multiple",
                      value: selectedPaymentMode || void 0,
                      showSearch: true,
                      placeholder: "Select payment mode",
                      popupMatchSelectWidth: false,
                      onChange: (modes) => {
                        setSelectedPaymentMode(modes);
                      },
                      filterOption: (input, option) => option.label.toString().toLowerCase().includes(input.toLowerCase()),
                      className: "w-full",
                      style: { height: "44px" },
                      options: [
                        { label: "Cash", value: "cash" },
                        { label: "Online", value: "online" },
                        {
                          label: "Payment Link",
                          value: "Payment Link"
                        }
                      ]
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3423,
                      columnNumber: 29
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3418,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-slate-700", children: "Payment For" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3451,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      mode: "multiple",
                      value: selectedPaymentFor,
                      showSearch: true,
                      placeholder: "Select payment for",
                      popupMatchSelectWidth: false,
                      onChange: (modes) => {
                        setSelectedPaymentFor(modes);
                      },
                      filterOption: (input, option) => option.label.toString().toLowerCase().includes(input.toLowerCase()),
                      className: "w-full",
                      style: { height: "44px" },
                      options: [
                        { label: "Chit", value: "Chit" },
                        { label: "Pigme", value: "Pigme" },
                        { label: "Loan", value: "Loan" }
                      ]
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3455,
                      columnNumber: 29
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3450,
                  columnNumber: 27
                }, this),
                showAllPaymentModes && /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-slate-700", children: "Account Type" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3482,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      value: selectedAccountType,
                      showSearch: true,
                      placeholder: "Select account type",
                      popupMatchSelectWidth: false,
                      onChange: (groupId) => setSelectedAccountType(groupId),
                      filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                      className: "w-full",
                      style: { height: "44px" },
                      children: [
                        /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Types" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                          lineNumber: 3502,
                          columnNumber: 33
                        }, this),
                        /* @__PURE__ */ jsxDEV(Select.Option, { value: "suspense", children: "Suspense" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                          lineNumber: 3505,
                          columnNumber: 33
                        }, this),
                        /* @__PURE__ */ jsxDEV(Select.Option, { value: "credit", children: "Credit" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                          lineNumber: 3508,
                          columnNumber: 33
                        }, this),
                        /* @__PURE__ */ jsxDEV(Select.Option, { value: "adjustment", children: "Adjustment" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                          lineNumber: 3511,
                          columnNumber: 33
                        }, this),
                        /* @__PURE__ */ jsxDEV(Select.Option, { value: "others", children: "Others" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                          lineNumber: 3514,
                          columnNumber: 33
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3485,
                      columnNumber: 31
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3481,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3355,
                columnNumber: 25
              }, this),
              transactionsLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3523,
                columnNumber: 21
              }, this) : transactionsTable?.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: /* @__PURE__ */ jsxDEV(
                DataTable,
                {
                  data: transactionsTable,
                  columns: TransactionsColumns,
                  exportedPdfName: `Transactions Report`,
                  exportedFileName: `Transactions Report.csv`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3526,
                  columnNumber: 29
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3525,
                columnNumber: 21
              }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p-40  w-full flex justify-center items-center ", children: "No Transactions Found" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3534,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 3310,
              columnNumber: 19
            }, this),
            activeTab === "transferHistory" && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "mb-1 text-sm text-gray-700 font-bold p-3", children: "Group Change History" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3543,
                columnNumber: 25
              }, this),
              transferHistoryLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3548,
                columnNumber: 21
              }, this) : transferHistory?.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: /* @__PURE__ */ jsxDEV(
                DataTable,
                {
                  data: transferHistory,
                  columns: TransferHistoryColumns,
                  exportedPdfName: "Customer Group Change History",
                  exportedFileName: "Customer Group Change History.csv",
                  printHeaderKeys: [
                    "Customer Name",
                    "Phone Number"
                  ],
                  printHeaderValues: [
                    group?.full_name,
                    group?.phone_number
                  ]
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3551,
                  columnNumber: 29
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3550,
                columnNumber: 21
              }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p-40 w-full flex justify-center items-center", children: "No Group Change History Found" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3567,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 3542,
              columnNumber: 19
            }, this),
            activeTab === "penalty" && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-gray-700 flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, { className: "text-red-600" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3580,
                    columnNumber: 33
                  }, this),
                  "Penalty Details"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3579,
                  columnNumber: 31
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3578,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("label", { className: "mb-1 text-sm font-medium text-gray-700", children: "Groups and Tickets" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3584,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    value: EnrollGroupId.groupId ? `${EnrollGroupId.groupId}|${EnrollGroupId.ticket}` : "",
                    onChange: handleEnrollGroup,
                    className: "border border-gray-300 rounded px-6 py-2 shadow-sm outline-none w-full max-w-md",
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Group | Ticket" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 3596,
                        columnNumber: 31
                      }, this),
                      selectedEnrollments?.map((enrollment) => {
                        if (enrollment?.group_id && ["Active", "On Hold"].includes(enrollment?.customer_status)) {
                          return /* @__PURE__ */ jsxDEV(
                            "option",
                            {
                              value: `${enrollment?.group_id?._id}|${enrollment?.tickets}`,
                              children: [
                                enrollment?.group_id?.group_name || "N/A",
                                " |",
                                " ",
                                enrollment?.tickets || "N/A"
                              ]
                            },
                            enrollment?._id,
                            true,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 3605,
                              columnNumber: 33
                            },
                            this
                          );
                        }
                        return null;
                      }),
                      Array.isArray(loanCustomers?.overall_loan) && loanCustomers.overall_loan.map(
                        (loan, index) => /* @__PURE__ */ jsxDEV(
                          "option",
                          {
                            value: `Loan|${loan?.loan_details?.loan?._id || index}`,
                            children: [
                              loan?.loan_details?.loan?.loan_id || "N/A",
                              " | ₹",
                              loan?.loan_value || 0
                            ]
                          },
                          loan?.loan_details?.loan?._id || index,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 3620,
                            columnNumber: 27
                          },
                          this
                        )
                      ),
                      Array.isArray(pigmeCustomers?.overall_pigme) && pigmeCustomers.overall_pigme.map(
                        (pigme, index) => /* @__PURE__ */ jsxDEV(
                          "option",
                          {
                            value: `Pigme|${pigme?.pigme_details?.pigme?._id || index}`,
                            children: [
                              pigme?.pigme_details?.pigme?.pigme_id || "N/A",
                              " | ₹",
                              pigme?.total_deposited_amount || 0
                            ]
                          },
                          pigme?.pigme_details?.pigme?._id || index,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 3632,
                            columnNumber: 27
                          },
                          this
                        )
                      )
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3587,
                    columnNumber: 29
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3577,
                columnNumber: 27
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3576,
                columnNumber: 25
              }, this),
              !EnrollGroupId.groupId || !EnrollGroupId.ticket ? /* @__PURE__ */ jsxDEV("div", { className: "p-20 w-full flex justify-center items-center text-gray-500", children: /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
                /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, { className: "text-6xl text-gray-300 mx-auto mb-4" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3648,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-lg", children: "Please select a Group and Ticket" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3649,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-400 mt-2", children: "Choose a group and ticket from the dropdown above to view penalty details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3652,
                  columnNumber: 31
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3647,
                columnNumber: 29
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3646,
                columnNumber: 21
              }, this) : penaltyLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3660,
                columnNumber: 29
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3659,
                columnNumber: 21
              }, this) : formattedCustomerPenaltyData.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "mb-6 grid grid-cols-1 md:grid-cols-4 gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-red-50 p-4 rounded-lg border border-red-200", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600", children: "Total Penalty Amount" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3667,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-red-600", children: formatPenaltyAmount(
                      penaltyData.reduce(
                        (sum, p) => sum + (p.totalPenalty || 0),
                        0
                      )
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3670,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3666,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-orange-50 p-4 rounded-lg border border-orange-200", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600", children: "Total Late Fee" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3680,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-orange-600", children: formatPenaltyAmount(
                      penaltyData.reduce(
                        (sum, p) => sum + (p.totalLateFee || 0),
                        0
                      )
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3683,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3679,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-purple-50 p-4 rounded-lg border border-purple-200", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600", children: "Total VC Penalty" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3693,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-purple-600", children: formatPenaltyAmount(
                      penaltyData.reduce(
                        (sum, p) => sum + (p.vcPenalty || 0),
                        0
                      )
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3696,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3692,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 p-4 rounded-lg border border-blue-200", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600", children: "Total Outstanding" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3706,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-blue-600", children: formatPenaltyAmount(
                      penaltyData.reduce(
                        (sum, p) => sum + (p.grandTotalDue || 0),
                        0
                      )
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3709,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3705,
                    columnNumber: 31
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3665,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV(
                  DataTable,
                  {
                    data: formattedCustomerPenaltyData,
                    columns: PenaltyColumns,
                    exportedPdfName: `Customer_Penalty_Report`,
                    exportedFileName: `Customer_Penalty_Report.csv`,
                    printHeaderKeys: [
                      "Customer Name",
                      "Phone Number",
                      "Group Name",
                      "Ticket"
                    ],
                    printHeaderValues: [
                      group?.full_name,
                      group?.phone_number,
                      EnrollGroupId.groupId !== "Loan" && EnrollGroupId.groupId !== "Pigme" ? groupDetails?.group_name : EnrollGroupId.groupId === "Loan" ? "Loan" : "Pigme",
                      EnrollGroupId.ticket
                    ]
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3721,
                    columnNumber: 29
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3663,
                columnNumber: 21
              }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p-20 w-full flex justify-center items-center text-gray-500", children: /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
                /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, { className: "text-6xl text-gray-300 mx-auto mb-4" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3748,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-lg", children: "No penalty records found" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3749,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-400 mt-2", children: "No penalties or late fees found for this group/ticket combination" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3752,
                  columnNumber: 31
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3747,
                columnNumber: 29
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3746,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 3575,
              columnNumber: 19
            }, this),
            activeTab === "bidrequest" && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "mb-4 text-lg font-bold text-gray-700 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(MdGavel, { className: "text-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3764,
                  columnNumber: 27
                }, this),
                "Bid Requests History"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3763,
                columnNumber: 25
              }, this),
              bidRequestsLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3770,
                columnNumber: 29
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3769,
                columnNumber: 21
              }, this) : bidRequestsData && bidRequestsData.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "mb-6 grid grid-cols-1 md:grid-cols-5 gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 p-4 rounded-lg border border-blue-200", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600", children: "Total Requests" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3777,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-blue-600", children: bidRequestsData.length }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3780,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3776,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-yellow-50 p-4 rounded-lg border border-yellow-200", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600", children: "Pending" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3785,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-yellow-600", children: bidRequestsData.filter(
                      (r) => r.status === "Pending"
                    ).length }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3788,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3784,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-green-50 p-4 rounded-lg border border-green-200", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600", children: "Accepted" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3797,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-green-600", children: bidRequestsData.filter(
                      (r) => r.status === "Accept"
                    ).length }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3800,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3796,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-red-50 p-4 rounded-lg border border-red-200", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600", children: "Declined" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3809,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-red-600", children: bidRequestsData.filter(
                      (r) => r.status === "Decline"
                    ).length }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3812,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3808,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-purple-50 p-4 rounded-lg border border-purple-200", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600", children: "Prized" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3821,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-purple-600", children: bidRequestsData.filter(
                      (r) => r.status === "Prized"
                    ).length }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3824,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3820,
                    columnNumber: 31
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3775,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full bg-white border border-gray-200 rounded-lg", children: [
                  /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                    /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "SL. NO" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3839,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Bid Request Code" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3842,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Request Date" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3845,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Group Name" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3848,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Ticket" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3851,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Auction Date" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3854,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Auction Time" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3857,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Balance" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3860,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Status" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3863,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Actions" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3866,
                      columnNumber: 37
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3838,
                    columnNumber: 35
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3837,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-gray-200", children: bidRequestsData.map(
                    (bidRequest, index) => /* @__PURE__ */ jsxDEV(
                      "tr",
                      {
                        className: "hover:bg-gray-50",
                        children: [
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm text-gray-900", children: index + 1 }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 3877,
                            columnNumber: 39
                          }, this),
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm font-medium text-blue-600", children: bidRequest.bid_request_code }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 3880,
                            columnNumber: 39
                          }, this),
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm text-gray-900", children: bidRequest.request_date }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 3883,
                            columnNumber: 39
                          }, this),
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm text-gray-900", children: bidRequest.group_name }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 3886,
                            columnNumber: 39
                          }, this),
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm text-gray-900", children: bidRequest.ticket_number }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 3889,
                            columnNumber: 39
                          }, this),
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm text-gray-900", children: bidRequest.auction_date }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 3892,
                            columnNumber: 39
                          }, this),
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm text-gray-900", children: bidRequest.auction_time }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 3895,
                            columnNumber: 39
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            "td",
                            {
                              className: `px-4 py-3 text-sm font-medium ${bidRequest.balance <= 0 ? "text-green-600" : "text-red-600"}`,
                              children: bidRequest.balance_display
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 3898,
                              columnNumber: 39
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3", children: /* @__PURE__ */ jsxDEV(
                            "span",
                            {
                              className: `inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                      ${bidRequest.status_color === "orange" ? "bg-yellow-100 text-yellow-800" : ""}
                      ${bidRequest.status_color === "green" ? "bg-green-100 text-green-800" : ""}
                      ${bidRequest.status_color === "red" ? "bg-red-100 text-red-800" : ""}
                      ${bidRequest.status_color === "blue" ? "bg-blue-100 text-blue-800" : ""}
                      ${bidRequest.status_color === "purple" ? "bg-purple-100 text-purple-800" : ""}`,
                              children: bidRequest.status
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 3904,
                              columnNumber: 41
                            },
                            this
                          ) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 3903,
                            columnNumber: 39
                          }, this),
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3", children: /* @__PURE__ */ jsxDEV(
                            "button",
                            {
                              onClick: () => showBidRequestDetails(bidRequest),
                              className: "text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center gap-1",
                              children: [
                                /* @__PURE__ */ jsxDEV(FaEye, { size: 14 }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                                  lineNumber: 3922,
                                  columnNumber: 43
                                }, this),
                                "View Details"
                              ]
                            },
                            void 0,
                            true,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 3916,
                              columnNumber: 41
                            },
                            this
                          ) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 3915,
                            columnNumber: 39
                          }, this)
                        ]
                      },
                      bidRequest._id,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 3873,
                        columnNumber: 29
                      },
                      this
                    )
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3871,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3836,
                  columnNumber: 31
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3835,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3773,
                columnNumber: 21
              }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p-20 w-full flex justify-center items-center text-gray-500", children: /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
                /* @__PURE__ */ jsxDEV(MdGavel, { className: "text-6xl text-gray-300 mx-auto mb-4" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3935,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-lg", children: "No bid requests found for this customer" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3936,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-400 mt-2", children: "The customer has not raised any bid requests yet" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3939,
                  columnNumber: 31
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3934,
                columnNumber: 29
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3933,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 3762,
              columnNumber: 19
            }, this),
            activeTab === "visitor" && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col flex-1", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "mb-4 text-lg font-bold text-gray-700 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(MdPeople, { className: "text-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3951,
                  columnNumber: 27
                }, this),
                "Visitor Records"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3950,
                columnNumber: 25
              }, this),
              visitorLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3957,
                columnNumber: 29
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3956,
                columnNumber: 21
              }, this) : visitorData && visitorData.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "mb-6 grid grid-cols-1 md:grid-cols-4 gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 p-4 rounded-lg border border-blue-200", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600", children: "Total Visits" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3964,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-blue-600", children: visitorData.length }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3967,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3963,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-green-50 p-4 rounded-lg border border-green-200", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600", children: "Completed Visits" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3972,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-green-600", children: visitorData.filter(
                      (v) => v.status === "Completed"
                    ).length }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3975,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3971,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-purple-50 p-4 rounded-lg border border-purple-200", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600", children: "Purpose - Document Sign" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3984,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-purple-600", children: visitorData.filter(
                      (v) => v.purpose === "Document Sign"
                    ).length }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3987,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3983,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-yellow-50 p-4 rounded-lg border border-yellow-200", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600", children: "Purpose - Auction Bidding" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3996,
                      columnNumber: 33
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-yellow-600", children: visitorData.filter(
                      (v) => v.purpose === "Auction Bidding"
                    ).length }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 3999,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 3995,
                    columnNumber: 31
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 3962,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full bg-white border border-gray-200 rounded-lg", children: [
                  /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                    VisitorColumns.map(
                      (col) => /* @__PURE__ */ jsxDEV(
                        "th",
                        {
                          className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b",
                          children: col.header
                        },
                        col.key,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                          lineNumber: 4015,
                          columnNumber: 31
                        },
                        this
                      )
                    ),
                    /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b", children: "Actions" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                      lineNumber: 4022,
                      columnNumber: 37
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 4013,
                    columnNumber: 35
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 4012,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-gray-200", children: visitorData.map(
                    (visitor, index) => /* @__PURE__ */ jsxDEV(
                      "tr",
                      {
                        className: "hover:bg-gray-50",
                        children: [
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm text-gray-900", children: index + 1 }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 4033,
                            columnNumber: 39
                          }, this),
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm font-medium text-blue-600", children: visitor.visitor_code }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 4036,
                            columnNumber: 39
                          }, this),
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm text-gray-900", children: visitor.name }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 4040,
                            columnNumber: 39
                          }, this),
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm text-gray-900", children: visitor.phone }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 4043,
                            columnNumber: 39
                          }, this),
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm text-gray-500", children: visitor.email }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 4046,
                            columnNumber: 39
                          }, this),
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3", children: /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800", children: visitor.purpose }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 4050,
                            columnNumber: 41
                          }, this) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 4049,
                            columnNumber: 39
                          }, this),
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm text-gray-900", children: visitor.formatted_date }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 4054,
                            columnNumber: 39
                          }, this),
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm text-gray-900", children: visitor.meet_person }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 4057,
                            columnNumber: 39
                          }, this),
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3", children: /* @__PURE__ */ jsxDEV(
                            "span",
                            {
                              className: `inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                      ${visitor.status === "Completed" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}`,
                              children: visitor.status
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 4061,
                              columnNumber: 41
                            },
                            this
                          ) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 4060,
                            columnNumber: 39
                          }, this),
                          /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3", children: /* @__PURE__ */ jsxDEV(
                            "button",
                            {
                              onClick: () => showVisitorDetails(visitor),
                              className: "text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center gap-1",
                              children: [
                                /* @__PURE__ */ jsxDEV(FaEye, { size: 14 }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                                  lineNumber: 4075,
                                  columnNumber: 43
                                }, this),
                                "View Details"
                              ]
                            },
                            void 0,
                            true,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                              lineNumber: 4069,
                              columnNumber: 41
                            },
                            this
                          ) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                            lineNumber: 4068,
                            columnNumber: 39
                          }, this)
                        ]
                      },
                      visitor._id,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                        lineNumber: 4029,
                        columnNumber: 29
                      },
                      this
                    )
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                    lineNumber: 4027,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 4011,
                  columnNumber: 31
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 4010,
                  columnNumber: 29
                }, this),
                visitorData.some(
                  (v) => v.description && v.description !== "-"
                ) && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 text-sm text-gray-500 text-center", children: 'Click "View Details" to see complete visit information and description' }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 4088,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 3960,
                columnNumber: 21
              }, this) : /* @__PURE__ */ jsxDEV("div", { className: "p-20 w-full flex justify-center items-center text-gray-500", children: /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
                /* @__PURE__ */ jsxDEV(MdPeople, { className: "text-6xl text-gray-300 mx-auto mb-4" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 4097,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-lg", children: "No visitor records found for this customer" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 4098,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-400 mt-2", children: "The customer has not visited or no visit records exist" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 4101,
                  columnNumber: 31
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 4096,
                columnNumber: 29
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 4095,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 3949,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 1973,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 1972,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
          lineNumber: 1936,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
        lineNumber: 1932,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
      lineNumber: 1927,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
      lineNumber: 1926,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(EyeOutlined, { className: "text-blue-600 text-lg" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4122,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4121,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: "Penalty Breakdown" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4125,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 font-normal mt-0.5", children: "Cycle-wise penalty and payment details" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4126,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4124,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
          lineNumber: 4120,
          columnNumber: 9
        }, this),
        open: breakdownModalVisible,
        onCancel: () => {
          setBreakdownModalVisible(false);
          setSelectedPenalty(null);
        },
        width: 1e3,
        footer: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              onClick: () => {
                setBreakdownModalVisible(false);
                setSelectedPenalty(null);
              },
              children: "Close"
            },
            "close",
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4139,
              columnNumber: 9
            },
            this
          )
        ],
        children: selectedPenalty && /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-orange-50 rounded-lg p-4", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs uppercase font-semibold text-gray-500", children: "Group & Ticket" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 4155,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-2", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "font-semibold", children: selectedPenalty.groupName }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 4159,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-600", children: [
                  "Ticket: ",
                  selectedPenalty.ticket
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                  lineNumber: 4162,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 4158,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4154,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-red-50 rounded-lg p-4", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs uppercase font-semibold text-gray-500", children: "Total Penalty" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 4168,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-red-600", children: formatPenaltyAmount(selectedPenalty.totalPenalty) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 4171,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4167,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-yellow-50 rounded-lg p-4", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs uppercase font-semibold text-gray-500", children: "Total Late Fee" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 4176,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-yellow-600", children: formatPenaltyAmount(selectedPenalty.totalLateFee) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 4179,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4175,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-purple-50 rounded-lg p-4", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs uppercase font-semibold text-gray-500", children: "Grand Total Due" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 4184,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-purple-600", children: formatPenaltyAmount(selectedPenalty.grandTotalDue) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 4187,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4183,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4153,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 mb-4", children: "Cycle-wise Penalty Breakdown" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4195,
              columnNumber: 15
            }, this),
            formattedPenaltyCycles.length > 0 ? /* @__PURE__ */ jsxDEV(
              AntTable,
              {
                columns: PenaltyBreakdownColumns,
                dataSource: formattedPenaltyCycles,
                pagination: { pageSize: 10 },
                size: "middle"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 4199,
                columnNumber: 13
              },
              this
            ) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-8 bg-gray-50 rounded-lg", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: "No cycle data available" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4207,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4206,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4194,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
          lineNumber: 4151,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
        lineNumber: 4118,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(MdGavel, { className: "text-blue-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4218,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: "Bid Request Details" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4219,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
          lineNumber: 4217,
          columnNumber: 9
        }, this),
        open: bidRequestModalVisible,
        onCancel: () => setBidRequestModalVisible(false),
        footer: [
          /* @__PURE__ */ jsxDEV(Button, { onClick: () => setBidRequestModalVisible(false), children: "Close" }, "close", false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4225,
            columnNumber: 9
          }, this)
        ],
        width: 700,
        bodyStyle: { padding: "20px" },
        children: selectedBidRequest && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Bid Request Code" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4235,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: selectedBidRequest.bid_request_code }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4238,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4234,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Group Name" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4243,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: selectedBidRequest.group_name }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4244,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4242,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Ticket Number" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4249,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: selectedBidRequest.ticket_number }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4250,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4248,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Request Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4255,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: selectedBidRequest.request_date }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4256,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4254,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Auction Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4261,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: selectedBidRequest.auction_date }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4262,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4260,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Auction Time" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4267,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: selectedBidRequest.auction_time }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4268,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4266,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Current Balance" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4273,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "p",
              {
                className: `text-sm font-semibold ${selectedBidRequest.balance <= 0 ? "text-green-600" : "text-red-600"}`,
                children: selectedBidRequest.balance_display
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 4274,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4272,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Status" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4281,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "span",
              {
                className: `inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
          ${selectedBidRequest.status_color === "orange" ? "bg-yellow-100 text-yellow-800" : ""}
          ${selectedBidRequest.status_color === "green" ? "bg-green-100 text-green-800" : ""}
          ${selectedBidRequest.status_color === "red" ? "bg-red-100 text-red-800" : ""}
          ${selectedBidRequest.status_color === "blue" ? "bg-blue-100 text-blue-800" : ""}
          ${selectedBidRequest.status_color === "purple" ? "bg-purple-100 text-purple-800" : ""}`,
                children: selectedBidRequest.status
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 4282,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4280,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Referred By" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4294,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: selectedBidRequest.referred_by }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4295,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4293,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Created By (Admin)" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4300,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: selectedBidRequest.admin_user }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4303,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4299,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Auction Cycle" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4308,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: selectedBidRequest.auction_cycle }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4309,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4307,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
          lineNumber: 4233,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
        lineNumber: 4215,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(MdPeople, { className: "text-blue-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4320,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: "Visitor Details" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4321,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
          lineNumber: 4319,
          columnNumber: 9
        }, this),
        open: visitorModalVisible,
        onCancel: () => setVisitorModalVisible(false),
        footer: [
          /* @__PURE__ */ jsxDEV(Button, { onClick: () => setVisitorModalVisible(false), children: "Close" }, "close", false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4327,
            columnNumber: 9
          }, this)
        ],
        width: 700,
        bodyStyle: { padding: "20px" },
        children: selectedVisitor && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Visitor Code" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4337,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: selectedVisitor.visitor_code }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4338,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4336,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Visitor ID" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4343,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: selectedVisitor.visitorId }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4344,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4342,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Visitor Name" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4349,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: selectedVisitor.name }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4350,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4348,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Phone Number" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4355,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: selectedVisitor.phone }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4356,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4354,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Email" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4361,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: selectedVisitor.email }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4362,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4360,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Purpose" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4367,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: selectedVisitor.purpose }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4368,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4366,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Visit Date & Time" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4373,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: selectedVisitor.formatted_date }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4376,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4372,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Whom to Meet" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4381,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: selectedVisitor.meet_person }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4382,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4380,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2 col-span-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Description" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4387,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: selectedVisitor.description }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4388,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4386,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Group Name" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4393,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: selectedVisitor.group_name }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4394,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4392,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Ticket Number" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4399,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: selectedVisitor.ticket_number }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4400,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4398,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-b pb-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase", children: "Status" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
              lineNumber: 4405,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "span",
              {
                className: `inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
          ${selectedVisitor.status === "Completed" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}`,
                children: selectedVisitor.status
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
                lineNumber: 4406,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
            lineNumber: 4404,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
          lineNumber: 4335,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
        lineNumber: 4317,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx",
    lineNumber: 1925,
    columnNumber: 5
  }, this);
};
_s(UserReport, "3eID74CFbgOAMraKyLtj9KRP+wQ=", false, function() {
  return [useSearchParams];
});
_c = UserReport;
export default UserReport;
var _c;
$RefreshReg$(_c, "UserReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUZNLFNBKzdEZ0IsVUEvN0RoQjsyQkF2Rk47QUFBb0JBLG9CQUFtQkMsT0FBTSxzQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUM1RCxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLHlCQUF5QjtBQUNoQyxTQUFTQyxVQUFVQyxRQUFRQyxRQUFRQyxPQUFPQyxLQUFLQyxTQUFTQyxnQkFBZ0I7QUFDeEUsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsU0FBU0MsTUFBTUMsdUJBQXVCO0FBQ3RDLFNBQVNDLGNBQWNDLGdCQUFnQjtBQUN2QyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLHdCQUF3QkMsU0FBU0MsZ0JBQWdCO0FBQzFELE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsV0FBVztBQUNsQixTQUFTQywyQkFBMkI7QUFDcEM7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0MsYUFBYUMscUJBQXFCQyxhQUFhO0FBQ3hEO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FFSztBQUdQLE1BQU1DLGFBQWFBLE1BQU07QUFBQUMsS0FBQTtBQUN2QixRQUFNLENBQUNDLFlBQVksSUFBSXZCLGdCQUFnQjtBQUN2QyxRQUFNd0IsU0FBU0QsYUFBYUUsSUFBSSxTQUFTO0FBQ3pDLFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJM0MsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQzRDLFdBQVdDLFlBQVksSUFBSTdDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUM4QyxjQUFjQyxlQUFlLElBQUkvQyxTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDZ0QsZUFBZUMsZ0JBQWdCLElBQUlqRCxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDa0QsZUFBZUMsZ0JBQWdCLElBQUluRCxTQUFTd0MsU0FBU0EsU0FBUyxFQUFFO0FBQ3ZFLFFBQU0sQ0FBQ1ksT0FBT0MsUUFBUSxJQUFJckQsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ3NELFlBQVlDLGFBQWEsSUFBSXZELFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUN3RCxjQUFjQyxlQUFlLElBQUl6RCxTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDMEQsa0JBQWtCQyxtQkFBbUIsSUFBSTNELFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUM0RCxlQUFlQyxnQkFBZ0IsSUFBSTdELFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUM4RCxXQUFXQyxZQUFZLElBQUkvRCxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDZ0UsZUFBZUMsZ0JBQWdCLElBQUlqRSxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDa0Usc0JBQXNCQyx1QkFBdUIsSUFBSW5FLFNBQVMsSUFBSTtBQUNyRSxRQUFNLENBQUNvRSxnQkFBZ0JDLGlCQUFpQixJQUFJckUsU0FBUyxJQUFJO0FBQ3pELFFBQU0sQ0FBQ3NFLHVCQUF1QkMsd0JBQXdCLElBQUl2RSxTQUFTLEtBQUs7QUFDeEUsUUFBTSxDQUFDd0UsVUFBVUMsV0FBVyxJQUFJekUsU0FBUyxNQUFNO0FBQzdDLFVBQU0wRSxTQUFRLG9CQUFJQyxLQUFLO0FBQ3ZCLFdBQU9ELE9BQU1FLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQ3pDLENBQUM7QUFDRCxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSS9FLFNBQVMsTUFBTTtBQUN6QyxVQUFNMEUsU0FBUSxvQkFBSUMsS0FBSztBQUN2QixXQUFPRCxPQUFNRSxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxFQUN6QyxDQUFDO0FBQ0QsUUFBTSxDQUFDRyxhQUFhQyxjQUFjLElBQUlqRixTQUFTLENBQUM7QUFDaEQsUUFBTSxDQUFDa0YsZUFBZUMsZ0JBQWdCLElBQUluRixTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDb0YsbUJBQW1CQyxvQkFBb0IsSUFBSXJGLFNBQVMsRUFBRTtBQUM3RCxRQUFNLENBQUNzRixnQkFBZ0JDLGdCQUFnQixJQUFJdkYsU0FBUyxLQUFLO0FBQ3pELFFBQU0sQ0FBQ3dGLGNBQWNDLGVBQWUsSUFBSXpGLFNBQVMsS0FBSztBQUN0RCxRQUFNLENBQUMwRixhQUFhQyxjQUFjLElBQUkzRixTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDNEYsZUFBZUMsZ0JBQWdCLElBQUk3RixTQUFTO0FBQUEsSUFDakQ4RixTQUFTO0FBQUEsSUFDVEMsUUFBUTtBQUFBLEVBQ1YsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsaUJBQWlCQyxrQkFBa0IsSUFBSWpHLFNBQVM7QUFBQSxJQUNyRGtHLFFBQVE7QUFBQSxJQUNSQyxXQUFXO0FBQUEsRUFDYixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUlyRyxTQUFTO0FBQUEsSUFDN0NzRyxNQUFNO0FBQUEsSUFDTkMsTUFBTTtBQUFBLElBQ05DLE1BQU07QUFBQSxJQUNOQyxNQUFNO0FBQUEsSUFDTkMsTUFBTTtBQUFBLElBQ05DLE1BQU07QUFBQSxJQUNOQyxNQUFNO0FBQUEsSUFDTkMsTUFBTTtBQUFBLElBQ05DLE1BQU07QUFBQSxFQUNSLENBQUM7QUFFRCxRQUFNLENBQUNDLE1BQU1DLE9BQU8sSUFBSWhILFNBQVMsTUFBTTtBQUV2QyxRQUFNaUgsUUFBUUEsQ0FBQyxFQUFFQyxPQUFPQyxNQUFNLE1BQzVCLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLDJCQUFDLFdBQU0sV0FBVSwwQ0FBMENELG1CQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlFO0FBQUEsSUFDakU7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQUs7QUFBQSxRQUNMLGFBQWFBO0FBQUFBLFFBQ2IsT0FBT0MsU0FBUztBQUFBLFFBQ2hCO0FBQUEsUUFDQSxXQUFVO0FBQUE7QUFBQSxNQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUtvRjtBQUFBLE9BUHRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTQTtBQUVGLFFBQU0sQ0FBQ0MsZUFBZUMsZ0JBQWdCLElBQUlySCxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDc0gsV0FBV0MsWUFBWSxJQUFJdkgsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ3dILGFBQWFDLGNBQWMsSUFBSXpILFNBQVMsRUFBRTtBQUNqRCxRQUFNMEgsb0JBQW9CekgsT0FBTyxLQUFLO0FBRXRDLFFBQU0sQ0FBQzBILGdCQUFnQkMsaUJBQWlCLElBQUk1SCxTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDNkgsd0JBQXdCQyx5QkFBeUIsSUFBSTlIO0FBQUFBLElBQzFEd0MsU0FBU0EsU0FBUztBQUFBLEVBQ3BCO0FBQ0EsUUFBTSxDQUFDdUYscUJBQXFCQyxzQkFBc0IsSUFBSWhJLFNBQVMsRUFBRTtBQUNqRSxRQUFNLENBQUNpSSxXQUFXQyxZQUFZLElBQUlsSSxTQUFTLENBQUMsQ0FBQztBQUU3QyxRQUFNLENBQUNtSSxrQkFBa0JDLG1CQUFtQixJQUFJcEksU0FBUyxFQUFFO0FBQzNELFFBQU0sQ0FBQ3FJLGdCQUFnQkMsaUJBQWlCLElBQUl0SSxTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDdUkscUJBQXFCQyxzQkFBc0IsSUFBSXhJLFNBQVMsRUFBRTtBQUNqRSxRQUFNLENBQUN5SSxtQkFBbUJDLG9CQUFvQixJQUFJMUk7QUFBQUEsSUFDaER3QyxTQUFTQSxTQUFTO0FBQUEsRUFDcEI7QUFDQSxRQUFNLENBQUNtRyxVQUFVQyxXQUFXLElBQUk1SSxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDNkksa0JBQWtCQyxtQkFBbUIsSUFBSTlJLFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUMrSSxlQUFlQyxnQkFBZ0IsSUFBSWhKLFNBQVMsSUFBSTtBQUN2RCxRQUFNLENBQUNpSixXQUFXQyxZQUFZLElBQUlsSixTQUFTLGNBQWM7QUFDekQsUUFBTSxDQUFDbUosWUFBWUMsYUFBYSxJQUFJcEosU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ3FKLGNBQWNDLGVBQWUsSUFBSXRKLFNBQVMsR0FBRztBQUNwRCxRQUFNLENBQUN1SixlQUFlQyxnQkFBZ0IsSUFBSXhKLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUN5SixnQkFBZ0JDLGlCQUFpQixJQUFJMUosU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQzJKLG1CQUFtQkMsb0JBQW9CLElBQUk1SixTQUFTLEVBQUU7QUFDN0QsUUFBTSxDQUFDNkosU0FBU0MsVUFBVSxJQUFJOUosU0FBUyxJQUFJO0FBQzNDLFFBQU0sQ0FBQytKLG1CQUFtQkMsb0JBQW9CLElBQUloSyxTQUFTLEVBQUU7QUFDN0QsUUFBTSxDQUFDaUssZUFBZUMsZ0JBQWdCLElBQUlsSyxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDbUssWUFBWUMsYUFBYSxJQUFJcEssU0FBUyxJQUFJO0FBQ2pELFFBQU0sQ0FBQ3FLLHNCQUFzQkMsdUJBQXVCLElBQUl0SyxTQUFTLEVBQUU7QUFDbkUsUUFBTSxDQUFDdUssc0JBQXNCQyx1QkFBdUIsSUFBSXhLLFNBQVMsRUFBRTtBQUNuRSxRQUFNLENBQUN5SyxxQkFBcUJDLHNCQUFzQixJQUFJMUssU0FBUyxLQUFLO0FBQ3BFLFFBQU0sQ0FBQzJLLGtCQUFrQkMsbUJBQW1CLElBQUk1SyxTQUFTLEtBQUs7QUFDOUQsUUFBTSxDQUFDNksscUJBQXFCQyxzQkFBc0IsSUFBSTlLLFNBQVMsS0FBSztBQUVwRSxRQUFNLENBQUMrSyxvQkFBb0JDLHFCQUFxQixJQUFJaEwsU0FBUyxJQUFJO0FBQ2pFLFFBQU0sQ0FBQ2lMLGtCQUFrQkMsbUJBQW1CLElBQUlsTCxTQUFTLElBQUk7QUFDN0QsUUFBTSxDQUFDbUwscUJBQXFCQyxzQkFBc0IsSUFBSXBMLFNBQVMsQ0FBQztBQUVoRSxRQUFNLENBQUNxTCxlQUFlQyxnQkFBZ0IsSUFBSXRMLFNBQVMsSUFBSTtBQUN2RCxRQUFNLENBQUN1TCxpQkFBaUJDLGtCQUFrQixJQUFJeEwsU0FBUyxLQUFLO0FBQzVELFFBQU0wRSxRQUFRLG9CQUFJQyxLQUFLO0FBQ3ZCLFFBQU04RyxjQUFjL0csTUFBTUUsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBRXBELFFBQU0sQ0FBQzZHLGFBQWFDLGNBQWMsSUFBSTNMLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUM0TCxnQkFBZ0JDLGlCQUFpQixJQUFJN0wsU0FBUyxLQUFLO0FBQzFELFFBQU0sQ0FBQzhMLHVCQUF1QkMsd0JBQXdCLElBQUkvTCxTQUFTLEtBQUs7QUFDeEUsUUFBTSxDQUFDZ00saUJBQWlCQyxrQkFBa0IsSUFBSWpNLFNBQVMsSUFBSTtBQUMzRCxRQUFNLENBQUNrTSxpQkFBaUJDLGtCQUFrQixJQUFJbk0sU0FBUyxJQUFJO0FBQzNELFFBQU0sQ0FBQ29NLG9CQUFvQkMscUJBQXFCLElBQUlyTSxTQUFTLEtBQUs7QUFDbEUsUUFBTSxDQUFDc00sd0JBQXdCQyx5QkFBeUIsSUFBSXZNLFNBQVMsS0FBSztBQUMxRSxRQUFNLENBQUN3TSxvQkFBb0JDLHFCQUFxQixJQUFJek0sU0FBUyxJQUFJO0FBQ2pFLFFBQU0sQ0FBQzBNLGFBQWFDLGNBQWMsSUFBSTNNLFNBQVMsSUFBSTtBQUNuRCxRQUFNLENBQUM0TSxnQkFBZ0JDLGlCQUFpQixJQUFJN00sU0FBUyxLQUFLO0FBQzFELFFBQU0sQ0FBQzhNLHFCQUFxQkMsc0JBQXNCLElBQUkvTSxTQUFTLEtBQUs7QUFDcEUsUUFBTSxDQUFDZ04saUJBQWlCQyxrQkFBa0IsSUFBSWpOLFNBQVMsSUFBSTtBQUczRCxRQUFNLENBQUNrTixpQkFBaUJDLGtCQUFrQixJQUFJbk4sU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ29OLHFCQUFxQkMsc0JBQXNCLElBQUlyTixTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDc04sb0JBQW9CQyxxQkFBcUIsSUFBSXZOLFNBQVMsRUFBRTtBQUMvRCxRQUFNLENBQUN3TixxQkFBcUJDLHNCQUFzQixJQUFJek4sU0FBUyxLQUFLO0FBQ3BFLFFBQU0sQ0FBQzBOLG1CQUFtQkMsb0JBQW9CLElBQUkzTixTQUFTLEVBQUU7QUFDN0QsUUFBTSxDQUFDNE4sbUJBQW1CQyxtQkFBbUIsSUFBSTdOLFNBQVMsRUFBRTtBQUM1RCxRQUFNLENBQUM4Tix3QkFBd0JDLHlCQUF5QixJQUFJL04sU0FBUyxDQUFDO0FBQ3RFLFFBQU0sQ0FBQ2dPLGdCQUFnQkMsaUJBQWlCLElBQUlqTyxTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDa08sc0JBQXNCQyx1QkFBdUIsSUFBSW5PLFNBQVMsRUFBRTtBQUNuRSxRQUFNLENBQUNvTyx1QkFBdUJDLHdCQUF3QixJQUFJck8sU0FBUyxLQUFLO0FBQ3hFLFFBQU0sQ0FBQ3NPLHdCQUF3QkMseUJBQXlCLElBQUl2TyxTQUFTLEtBQUs7QUFDMUUsUUFBTSxDQUFDd08saUJBQWlCQyxrQkFBa0IsSUFBSXpPLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUMwTyxjQUFjQyxlQUFlLElBQUkzTyxTQUFTLEVBQUU7QUFDbkQsUUFBTTRPLDhCQUE4QkEsQ0FBQ0MsTUFBTTtBQUN6Q3pGLGtCQUFjeUYsRUFBRUMsT0FBTzNILEtBQUs7QUFBQSxFQUM5QjtBQUNBLFFBQU00SCxrQkFBa0JBLENBQUNDLFFBQVE7QUFDL0I5RixpQkFBYThGLEdBQUc7QUFBQSxFQUNsQjtBQUVBLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJbFAsU0FBUztBQUFBLElBQ3ZDbVAsVUFBVTtBQUFBLElBQ1ZDLFNBQVM7QUFBQSxJQUNUckosUUFBUTtBQUFBLElBQ1JzSixZQUFZO0FBQUEsSUFDWkMsVUFBVTtBQUFBLElBQ1ZwSixRQUFRO0FBQUEsSUFDUnFKLFVBQVU7QUFBQSxJQUNWQyxnQkFBZ0I7QUFBQSxFQUNsQixDQUFDO0FBRUQsUUFBTUMsbUJBQW1CO0FBQUEsSUFDdkIsRUFBRUMsS0FBSyxNQUFNQyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFRCxLQUFLLFlBQVlDLFFBQVEsZUFBZTtBQUFBLElBQzFDLEVBQUVELEtBQUssY0FBY0MsUUFBUSxhQUFhO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFRCxLQUFLLFlBQVlDLFFBQVEsZUFBZTtBQUFBLElBQzFDLEVBQUVELEtBQUssV0FBV0MsUUFBUSxVQUFVO0FBQUEsRUFBQztBQUV2QyxRQUFNQyxvQkFBb0I7QUFBQSxJQUN4QixFQUFFRixLQUFLLE1BQU1DLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVELEtBQUssWUFBWUMsUUFBUSxlQUFlO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVELEtBQUssWUFBWUMsUUFBUSxlQUFlO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLFVBQVU7QUFBQSxFQUFDO0FBRXZDLFFBQU1FLHNCQUFzQjtBQUFBLElBQzFCLEVBQUVILEtBQUssTUFBTUMsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxZQUFZQyxRQUFRLGlCQUFpQjtBQUFBLElBQzVDLEVBQUVELEtBQUssb0JBQW9CQyxRQUFRLG1CQUFtQjtBQUFBLElBQ3RELEVBQUVELEtBQUssY0FBY0MsUUFBUSxzQkFBc0I7QUFBQSxJQUNuRCxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFRCxLQUFLLFlBQVlDLFFBQVEsZUFBZTtBQUFBLElBQzFDLEVBQUVELEtBQUsscUJBQXFCQyxRQUFRLG9CQUFvQjtBQUFBLElBQ3hELEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFRCxLQUFLLFdBQVdDLFFBQVEsVUFBVTtBQUFBLEVBQUM7QUFHdkMsUUFBTUcseUJBQXlCO0FBQUEsSUFDN0IsRUFBRUosS0FBSyxNQUFNQyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFRCxLQUFLLGlCQUFpQkMsUUFBUSxvQkFBb0I7QUFBQSxJQUNwRCxFQUFFRCxLQUFLLGlCQUFpQkMsUUFBUSxvQkFBb0I7QUFBQSxJQUNwRCxFQUFFRCxLQUFLLGlCQUFpQkMsUUFBUSxnQkFBZ0I7QUFBQSxJQUNoRCxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVELEtBQUssZUFBZUMsUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRUQsS0FBSyxlQUFlQyxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFRCxLQUFLLFlBQVlDLFFBQVEsV0FBVztBQUFBLElBQ3RDLEVBQUVELEtBQUssYUFBYUMsUUFBUSxZQUFZO0FBQUEsSUFDeEMsRUFBRUQsS0FBSyxtQkFBbUJDLFFBQVEsc0JBQXNCO0FBQUE7QUFBQSxJQUV4RCxFQUFFRCxLQUFLLDBCQUEwQkMsUUFBUSxhQUFhO0FBQUEsSUFDdEQsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFRCxLQUFLLFNBQVNDLFFBQVEsYUFBYTtBQUFBLEVBQUM7QUFHeEMsUUFBTUksc0JBQXNCO0FBQUEsSUFDMUIsRUFBRUwsS0FBSyxNQUFNQyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFRCxLQUFLLFFBQVFDLFFBQVEsWUFBWTtBQUFBLElBQ25DLEVBQUVELEtBQUssb0JBQW9CQyxRQUFRLG1CQUFtQjtBQUFBLElBQ3RELEVBQUVELEtBQUssU0FBU0MsUUFBUSxhQUFhO0FBQUEsSUFDckMsRUFBRUQsS0FBSyxZQUFZQyxRQUFRLFdBQVc7QUFBQSxJQUN0QyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVELEtBQUssV0FBV0MsUUFBUSxVQUFVO0FBQUEsSUFDcEMsRUFBRUQsS0FBSyxrQkFBa0JDLFFBQVEsY0FBYztBQUFBLElBQy9DLEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUQsS0FBSyxRQUFRQyxRQUFRLGVBQWU7QUFBQSxJQUN0QyxHQUFJekMsa0JBQ0EsQ0FBQyxFQUFFd0MsS0FBSyxnQkFBZ0JDLFFBQVEsZUFBZSxDQUFDLElBQ2hEO0FBQUEsSUFDSixFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRUQsS0FBSyxtQkFBbUJDLFFBQVEsa0JBQWtCO0FBQUEsSUFDcEQsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBRXJDSztBQUFBQSxJQUFVLE1BQU07QUFDZCxZQUFNQyxrQkFBa0IsSUFBSUMsZ0JBQWdCO0FBQzVDLFlBQU1DLGdCQUFnQixZQUFZO0FBQ2hDLFlBQUksQ0FBQ2pOLGNBQWU7QUFFcEIsWUFBSTtBQUNGNEgsaUNBQXVCLElBQUk7QUFFM0IsZ0JBQU1zRixjQUFjLEVBQUU1TixRQUFRVSxjQUFjO0FBQzVDLGNBQUlpRixpQkFBa0JpSSxhQUFZQyxZQUFZbEk7QUFDOUMsY0FBSUUsZUFBZ0IrSCxhQUFZRSxVQUFVakk7QUFDMUMsY0FBSXVGO0FBQ0Z3Qyx3QkFBWXhDLG9CQUFvQkE7QUFDbEMsY0FBSXJGLHFCQUFxQmdJO0FBQ3ZCSCx3QkFBWWIsV0FBV2hIO0FBQ3pCLGNBQUk2RSxvQkFBcUJnRCxhQUFZSSxlQUFlcEQ7QUFDcEQsY0FBSUUsb0JBQW9CaUQ7QUFDdEJILHdCQUFZSyxVQUFVbkQ7QUFFeEIsZ0JBQU1vRCxXQUFXLE1BQU14USxJQUFJdUMsSUFBSSxrQ0FBa0M7QUFBQSxZQUMvRGtPLFFBQVFQO0FBQUFBLFlBQ1JRLFFBQVFYLGdCQUFnQlc7QUFBQUEsVUFDMUIsQ0FBQztBQUVELGNBQUlGLFNBQVNHLFFBQVFILFNBQVNHLEtBQUtOLFNBQVMsR0FBRztBQUM3QyxrQkFBTU8sV0FBV0osU0FBU0csS0FBS0U7QUFBQUEsY0FDN0IsQ0FBQ0MsS0FBS0MsU0FBU0QsTUFBTUUsT0FBT0QsS0FBSy9LLFVBQVUsQ0FBQztBQUFBLGNBQzVDO0FBQUEsWUFDRjtBQUNBNkgsc0NBQTBCK0MsUUFBUTtBQUNsQyxrQkFBTUssZ0JBQWdCVCxTQUFTRyxLQUFLTyxJQUFJLENBQUNILE1BQU1JLFVBQVU7QUFDdkQscUJBQU87QUFBQSxnQkFDTEMsS0FBS0wsS0FBS0s7QUFBQUEsZ0JBQ1ZDLElBQUlGLFFBQVE7QUFBQSxnQkFDWmpPLE9BQU82TixNQUFNOUIsVUFBVXFDLGNBQWNQLE1BQU1SLFdBQVc7QUFBQSxnQkFDdERnQixNQUFNUixNQUFNN0IsU0FBU3NDLGFBQWE7QUFBQSxnQkFDbENDLFVBQVVWLE1BQU1SLFdBQVc7QUFBQSxnQkFDM0JtQixjQUFjWCxNQUFNN0IsU0FBU3dDLGdCQUFnQjtBQUFBLGdCQUM3QzdMLFFBQVFrTCxNQUFNWSxPQUNWWixLQUFLWSxNQUFNQyxVQUNYYixNQUFNYyxRQUNKZCxLQUFLYyxPQUFPQyxXQUNaZixNQUFNbEwsVUFBVTtBQUFBLGdCQUN0QmtNLFNBQVNoQixNQUFNNUIsY0FBYztBQUFBLGdCQUM3QjZDLGdCQUFnQmpCLE1BQU1pQixrQkFBa0I7QUFBQSxnQkFDeENoTSxRQUFRK0ssTUFBTS9LLFVBQVU7QUFBQSxnQkFDeEJpTSxNQUFNbEIsS0FBSzNCLFVBQVV6SyxNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUs7QUFBQSxnQkFDeEN1TixrQkFBa0JuQixNQUFNOUssV0FBV3RCLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSztBQUFBLGdCQUN0RHdOLE1BQU1wQixNQUFNMUIsWUFBWTtBQUFBLGdCQUN4QmlCLGNBQWNTLE1BQU1ULGdCQUFnQjtBQUFBLGdCQUNwQzhCLGlCQUFpQnJCLE1BQU1xQixtQkFBbUI7QUFBQSxnQkFDMUNDLGNBQ0V0QixNQUFNc0IsY0FBY2QsUUFDcEJSLE1BQU11QixZQUFZQyxjQUNsQjtBQUFBLGdCQUNGQyxRQUNFO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQU07QUFBQSxzQkFDSkMsT0FBTztBQUFBLHdCQUNMO0FBQUEsMEJBQ0VqRCxLQUFLO0FBQUEsMEJBQ0x4SSxPQUNFO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLFFBQU87QUFBQSw4QkFDUCxJQUFJLFVBQVUrSixLQUFLSyxHQUFHO0FBQUEsOEJBQ3RCLFdBQVU7QUFBQSw4QkFBZTtBQUFBO0FBQUEsNEJBSDNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFNQTtBQUFBLHdCQUVKO0FBQUEsc0JBQUM7QUFBQSxvQkFFTDtBQUFBLG9CQUNBLFdBQVU7QUFBQSxvQkFFVixpQ0FBQyxZQUFTLFdBQVUsb0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9DO0FBQUE7QUFBQSxrQkFuQnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFvQkE7QUFBQSxjQUVKO0FBQUEsWUFDRixDQUFDO0FBRUQzRCxpQ0FBcUJ3RCxhQUFhO0FBQUEsVUFDcEMsT0FBTztBQUNMeUIsb0JBQVFDLEtBQUssdUNBQXVDekMsV0FBVztBQUMvRHpDLGlDQUFxQixFQUFFO0FBQUEsVUFDekI7QUFBQSxRQUNGLFNBQVNtRixPQUFPO0FBQ2QsY0FBSUEsTUFBTXJCLFNBQVMsY0FBYztBQUMvQjlELGlDQUFxQixFQUFFO0FBQ3ZCSSxzQ0FBMEIsQ0FBQztBQUFBLFVBQzdCO0FBQUEsUUFDRixVQUFDO0FBQ0NqRCxpQ0FBdUIsS0FBSztBQUFBLFFBQzlCO0FBQUEsTUFDRjtBQUVBcUYsb0JBQWM7QUFDZCxhQUFPLE1BQU1GLGdCQUFnQjhDLE1BQU07QUFBQSxJQUNyQztBQUFBLElBQUc7QUFBQSxNQUNENUs7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQXJGO0FBQUFBLE1BQ0FrSztBQUFBQSxNQUNBRTtBQUFBQSxNQUNBTTtBQUFBQSxNQUNBckM7QUFBQUEsSUFBZTtBQUFBLEVBQ2hCO0FBQ0R5RSxZQUFVLE1BQU07QUFDZCxVQUFNZ0QsdUJBQXVCLFlBQVk7QUFDdkMsVUFDRS9KLGNBQWMsaUJBQ2QvRixpQkFDQTBDLGNBQWNFLFdBQ2RGLGNBQWNHLFVBQ2RILGNBQWNFLFlBQVksVUFDMUJGLGtCQUFrQixTQUNsQjtBQUNBLFlBQUk7QUFDRm5DLDBCQUFnQixFQUFFO0FBQ2xCTSx1QkFBYSxFQUFFO0FBQ2ZFLDJCQUFpQixFQUFFO0FBQ25CK0csZ0NBQXNCLElBQUk7QUFDMUJFLDhCQUFvQixJQUFJO0FBQ3hCekYsMEJBQWdCLElBQUk7QUFDcEI1Qyx1QkFBYSxJQUFJO0FBRWpCLGdCQUFNNk4sV0FBVyxNQUFNeFEsSUFBSXVDO0FBQUFBLFlBQ3pCO0FBQUEsWUFDQTtBQUFBLGNBQ0VrTyxRQUFRO0FBQUEsZ0JBQ054QixVQUFVdkosY0FBY0U7QUFBQUEsZ0JBQ3hCQyxRQUFRSCxjQUFjRztBQUFBQSxnQkFDdEJxSixTQUFTbE07QUFBQUEsY0FDWDtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBRUEsZ0JBQU0sRUFBRXlGLHNCQUFXLElBQUlzSyxtQkFBbUIsR0FBRyxJQUFJdkMsU0FBU0csUUFBUSxDQUFDO0FBRW5FOU0sdUJBQWE0RSxVQUFTLENBQUMsR0FBR3VLLG1CQUFtQixDQUFDO0FBQzlDalAsMkJBQWlCMEUsVUFBUyxDQUFDLEdBQUd3Syx1QkFBdUIsQ0FBQztBQUV0RCxjQUFJQyxVQUFVO0FBQ2QsZ0JBQU1qQyxnQkFBZ0J4SSxVQUFTeUksSUFBSSxDQUFDaUMsU0FBU2hDLFVBQVU7QUFDckQrQix1QkFBV2xDLE9BQU9tQyxRQUFRbk4sVUFBVSxDQUFDO0FBQ3JDLG1CQUFPO0FBQUEsY0FDTG9MLEtBQUsrQixRQUFRL0I7QUFBQUEsY0FDYkMsSUFBSUYsUUFBUTtBQUFBLGNBQ1pjLE1BQU1tQixjQUFjRCxTQUFTL0QsUUFBUTtBQUFBLGNBQ3JDcEosUUFBUW1OLFFBQVFuTjtBQUFBQSxjQUNoQitMLFNBQVNvQixRQUFRaEU7QUFBQUEsY0FDakJrRSxhQUFhRixRQUFRbkI7QUFBQUEsY0FDckJzQixNQUFNSCxRQUFROUQ7QUFBQUEsY0FDZDZEO0FBQUFBLFlBQ0Y7QUFBQSxVQUNGLENBQUM7QUFFRCxjQUFJSyxpQkFBaUI7QUFDckJSLDJCQUFpQlMsUUFBUSxDQUFDQyxRQUFRQyxRQUFRO0FBQ3hDekMsMEJBQWMwQyxLQUFLO0FBQUEsY0FDakJ0QyxJQUFJO0FBQUEsY0FDSlksTUFBTXdCLE9BQU94TixZQUNULElBQUl4QixLQUFLZ1AsT0FBT3hOLFNBQVMsRUFBRTJOLG1CQUFtQixPQUFPLElBQ3JEO0FBQUEsY0FDSjVOLFFBQVF5TixPQUFPek47QUFBQUEsY0FDZitMLFNBQVMwQixPQUFPdEU7QUFBQUEsY0FDaEJrRSxhQUFhO0FBQUEsY0FDYkMsTUFBTUcsT0FBT2xELFdBQVc7QUFBQSxjQUN4QjJDLFNBQVM7QUFBQSxZQUNYLENBQUM7QUFFREssOEJBQWtCdkMsT0FBT3lDLE9BQU96TixVQUFVLENBQUM7QUFBQSxVQUM3QyxDQUFDO0FBRUQ4RSxnQ0FBc0J5SSxjQUFjO0FBRXBDLGNBQUlSLGlCQUFpQjFDLFNBQVMsR0FBRztBQUMvQnJGO0FBQUFBLGNBQ0UrSCxpQkFBaUIsQ0FBQyxHQUFHOU0sWUFDakIsSUFBSXhCLEtBQUtzTyxpQkFBaUIsQ0FBQyxFQUFFOU0sU0FBUyxFQUFFMk47QUFBQUEsZ0JBQ3hDO0FBQUEsY0FDRixJQUNFO0FBQUEsWUFDTjtBQUFBLFVBQ0Y7QUFFQSxjQUFJM0MsY0FBY1osU0FBUyxHQUFHO0FBQzVCWSwwQkFBYzBDLEtBQUs7QUFBQSxjQUNqQnRDLElBQUk7QUFBQSxjQUNKWSxNQUFNO0FBQUEsY0FDTmpNLFFBQVE7QUFBQSxjQUNSK0wsU0FBUztBQUFBLGNBQ1RzQixhQUFhO0FBQUEsY0FDYkMsTUFBTTtBQUFBLGNBQ05KO0FBQUFBLFlBQ0YsQ0FBQztBQUNEaEksbUNBQXVCZ0ksT0FBTztBQUFBLFVBQ2hDLE9BQU87QUFDTGhJLG1DQUF1QixDQUFDO0FBQUEsVUFDMUI7QUFFQTNILDBCQUFnQjBOLGFBQWE7QUFBQSxRQUMvQixTQUFTMkIsT0FBTztBQUNkRixrQkFBUUUsTUFBTSxpREFBaURBLEtBQUs7QUFDcEVyUCwwQkFBZ0IsRUFBRTtBQUNsQk0sdUJBQWEsRUFBRTtBQUNmRSwyQkFBaUIsRUFBRTtBQUNuQitHLGdDQUFzQixJQUFJO0FBQzFCRSw4QkFBb0IsSUFBSTtBQUFBLFFBQzFCLFVBQUM7QUFDQ3pGLDBCQUFnQixLQUFLO0FBQ3JCNUMsdUJBQWEsS0FBSztBQUFBLFFBQ3BCO0FBQUEsTUFDRixPQUFPO0FBQ0xZLHdCQUFnQixFQUFFO0FBQ2xCTSxxQkFBYSxFQUFFO0FBQ2ZFLHlCQUFpQixFQUFFO0FBQ25CK0csOEJBQXNCLElBQUk7QUFDMUJFLDRCQUFvQixJQUFJO0FBQUEsTUFDMUI7QUFBQSxJQUNGO0FBRUE4SCx5QkFBcUI7QUFBQSxFQUN2QixHQUFHLENBQUMvSixXQUFXL0YsZUFBZTBDLGNBQWNFLFNBQVNGLGNBQWNHLE1BQU0sQ0FBQztBQUUxRWlLLFlBQVUsTUFBTTtBQUNkLFVBQU0rRCx1QkFBdUIsWUFBWTtBQUN2QyxVQUFJO0FBQ0Z4RixrQ0FBMEIsSUFBSTtBQUU5QixjQUFNbUMsV0FBVyxNQUFNeFEsSUFBSXVDO0FBQUFBLFVBQ3pCLHNDQUFzQ1MsYUFBYTtBQUFBLFFBQ3JEO0FBRUEsY0FBTTJOLE9BQU9ILFVBQVVHLE1BQU1BLFFBQVE7QUFFckMsY0FBTU0sZ0JBQWdCTixLQUFLTyxJQUFJLENBQUNILE1BQU1JLFdBQVc7QUFBQSxVQUMvQ0MsS0FBS0wsS0FBS0s7QUFBQUEsVUFDVkMsSUFBSUYsUUFBUTtBQUFBLFVBRVoyQyxlQUFlL0MsS0FBS2dEO0FBQUFBLFVBRXBCQyxlQUNFakQsTUFBTWtELGlCQUFpQi9FLFNBQVNzQyxhQUFhO0FBQUEsVUFFL0MwQyxZQUNFbkQsTUFBTWtELGlCQUFpQi9FLFNBQVN3QyxnQkFBZ0I7QUFBQSxVQUVsRHlDLFlBQ0VwRCxNQUFNa0QsaUJBQWlCaEYsVUFBVXFDLGNBQWM7QUFBQSxVQUVqRDhDLGFBQ0VyRCxNQUFNa0QsaUJBQWlCSSxXQUFXO0FBQUEsVUFFcENDLGFBQ0V2RCxNQUFNd0QsZUFBZXJGLFNBQVNzQyxhQUFhO0FBQUEsVUFFN0NnRCxVQUNFekQsTUFBTXdELGVBQWVyRixTQUFTd0MsZ0JBQWdCO0FBQUEsVUFFaEQrQyxVQUNFMUQsTUFBTXdELGVBQWV0RixVQUFVcUMsY0FBYztBQUFBLFVBRS9Db0QsV0FDRTNELE1BQU13RCxlQUFlRixXQUFXO0FBQUEsVUFFbENNLGlCQUFpQjVELE1BQU00RCxtQkFBbUI7QUFBQSxVQUMxQ0Msa0JBQWtCN0QsTUFBTTZELG9CQUFvQjtBQUFBLFVBQzVDQyx3QkFBd0I5RCxNQUFNOEQsMEJBQTBCO0FBQUEsVUFDeERDLE9BQU8vRCxNQUFNK0QsT0FBT3ZDO0FBQUFBLFVBQ3BCd0MsUUFBUWhFLE1BQU1nRSxVQUFVO0FBQUEsVUFDeEJDLGVBQWU1QixjQUFjckMsTUFBTWlFLGFBQWE7QUFBQSxRQUNsRCxFQUFFO0FBRUZ6RywyQkFBbUIwQyxhQUFhO0FBQUEsTUFDbEMsU0FBUzJCLE9BQU87QUFDZEYsZ0JBQVFFO0FBQUFBLFVBQ047QUFBQSxVQUNBQTtBQUFBQSxVQUNBQSxPQUFPcEMsVUFBVUc7QUFBQUEsUUFDbkI7QUFDQXBDLDJCQUFtQixFQUFFO0FBQUEsTUFDdkIsVUFBQztBQUNDRixrQ0FBMEIsS0FBSztBQUFBLE1BQ2pDO0FBQUEsSUFDRjtBQUVBLFFBQUl0RixjQUFjLHFCQUFxQi9GLGVBQWU7QUFDcEQ2USwyQkFBcUI7QUFBQSxJQUN2QjtBQUFBLEVBQ0YsR0FBRyxDQUFDOUssV0FBVy9GLGFBQWEsQ0FBQztBQUU3QjhNLFlBQVUsTUFBTTtBQUNkLFVBQU1tRiwyQkFBMkIsWUFBWTtBQUMzQ2pMLHVCQUFpQixFQUFFO0FBQ25CekUsc0JBQWdCLElBQUk7QUFFcEIsVUFBSTtBQUVGLGNBQU0yUCxlQUFlN0wsZUFBZThMLGNBQWNDO0FBQUFBLFVBQ2hELENBQUN6RCxTQUFTQSxNQUFNMEQsY0FBYzFELE1BQU1QLFFBQVExTCxjQUFjRztBQUFBQSxRQUM1RDtBQUNBLGNBQU15UCxTQUNKSixjQUFjRyxjQUFjMUQsTUFBTVAsT0FBTzFMLGNBQWNHO0FBRXpELGNBQU0ySyxXQUFXLE1BQU14USxJQUFJdUM7QUFBQUEsVUFDekIsdUNBQXVDK1MsTUFBTTtBQUFBLFFBQy9DO0FBRUEsWUFBSTlFLFNBQVNHLE1BQU1OLFNBQVMsR0FBRztBQUM3QixjQUFJNkMsVUFBVTtBQUNkLGdCQUFNakMsZ0JBQWdCVCxTQUFTRyxLQUFLTyxJQUFJLENBQUNxRSxhQUFhcEUsVUFBVTtBQUM5RCtCLHVCQUFXbEMsT0FBT3VFLFlBQVl2UCxNQUFNO0FBQ3BDLG1CQUFPO0FBQUEsY0FDTG9MLEtBQUttRSxZQUFZbkU7QUFBQUEsY0FDakJDLElBQUlGLFFBQVE7QUFBQSxjQUNaL0IsVUFBVWdFLGNBQWNtQyxhQUFhbkcsUUFBUTtBQUFBLGNBQzdDcEosUUFBUXVQLFlBQVl2UDtBQUFBQSxjQUNwQm1KLFlBQVlvRyxZQUFZcEc7QUFBQUEsY0FDeEJFLFVBQVVrRyxZQUFZbEc7QUFBQUEsY0FDdEI2RDtBQUFBQSxZQUNGO0FBQUEsVUFDRixDQUFDO0FBQ0RqQyx3QkFBYzBDLEtBQUs7QUFBQSxZQUNqQnZDLEtBQUs7QUFBQSxZQUNMQyxJQUFJO0FBQUEsWUFDSmpDLFVBQVU7QUFBQSxZQUNWRCxZQUFZO0FBQUEsWUFDWm5KLFFBQVE7QUFBQSxZQUNScUosVUFBVTtBQUFBLFlBQ1Y2RDtBQUFBQSxVQUNGLENBQUM7QUFDRGxKLDJCQUFpQmlILGFBQWE7QUFBQSxRQUNoQyxPQUFPO0FBQ0xqSCwyQkFBaUIsRUFBRTtBQUFBLFFBQ3JCO0FBQUEsTUFDRixTQUFTNEksT0FBTztBQUNkRixnQkFBUUUsTUFBTSxxQ0FBcUNBLEtBQUs7QUFDeEQ1SSx5QkFBaUIsRUFBRTtBQUFBLE1BQ3JCLFVBQUM7QUFDQ3pFLHdCQUFnQixLQUFLO0FBQUEsTUFDdkI7QUFBQSxJQUNGO0FBRUEsUUFBSUcsY0FBY0UsWUFBWSxVQUFVRixjQUFjRztBQUNwRG9QLCtCQUF5QjtBQUFBLEVBQzdCLEdBQUcsQ0FBQ3ZQLGNBQWNHLE1BQU0sQ0FBQztBQUV6QmlLLFlBQVUsTUFBTTtBQUNkLFVBQU0wRiw0QkFBNEIsWUFBWTtBQUM1QzlMLDJCQUFxQixFQUFFO0FBQ3ZCbkUsc0JBQWdCLElBQUk7QUFFcEIsVUFBSTtBQUNGLGNBQU1pTCxXQUFXLE1BQU14USxJQUFJdUM7QUFBQUEsVUFDekIsK0NBQStDbUQsY0FBY0csTUFBTTtBQUFBLFFBQ3JFO0FBRUEsWUFBSTJLLFNBQVNHLFFBQVFILFNBQVNHLEtBQUtOLFNBQVMsR0FBRztBQUM3QyxjQUFJNkMsVUFBVTtBQUNkLGdCQUFNakMsZ0JBQWdCVCxTQUFTRyxLQUFLTyxJQUFJLENBQUN1RSxjQUFjdEUsVUFBVTtBQUMvRCtCLHVCQUFXbEMsT0FBT3lFLGFBQWF6UCxNQUFNO0FBQ3JDLG1CQUFPO0FBQUEsY0FDTG9MLEtBQUtxRSxhQUFhckU7QUFBQUEsY0FDbEJDLElBQUlGLFFBQVE7QUFBQSxjQUNaL0IsVUFBVWdFLGNBQWNxQyxjQUFjckcsUUFBUTtBQUFBLGNBQzlDcEosUUFBUXlQLGFBQWF6UDtBQUFBQSxjQUNyQm1KLFlBQVlzRyxhQUFhdEc7QUFBQUEsY0FDekJFLFVBQVVvRyxhQUFhcEc7QUFBQUEsY0FDdkI2RDtBQUFBQSxZQUNGO0FBQUEsVUFDRixDQUFDO0FBQ0RqQyx3QkFBYzBDLEtBQUs7QUFBQSxZQUNqQnZDLEtBQUs7QUFBQSxZQUNMQyxJQUFJO0FBQUEsWUFDSmpDLFVBQVU7QUFBQSxZQUNWRCxZQUFZO0FBQUEsWUFDWm5KLFFBQVE7QUFBQSxZQUNScUosVUFBVTtBQUFBLFlBQ1Y2RDtBQUFBQSxVQUNGLENBQUM7QUFDRHhKLCtCQUFxQnVILGFBQWE7QUFBQSxRQUNwQyxPQUFPO0FBQ0x2SCwrQkFBcUIsRUFBRTtBQUFBLFFBQ3pCO0FBQUEsTUFDRixTQUFTa0osT0FBTztBQUNkRixnQkFBUUUsTUFBTSxzQ0FBc0NBLEtBQUs7QUFDekRsSiw2QkFBcUIsRUFBRTtBQUFBLE1BQ3pCLFVBQUM7QUFDQ25FLHdCQUFnQixLQUFLO0FBQUEsTUFDdkI7QUFBQSxJQUNGO0FBRUEsUUFBSUcsY0FBY0UsWUFBWSxRQUFTNFAsMkJBQTBCO0FBQUEsRUFDbkUsR0FBRyxDQUFDOVAsY0FBY0csTUFBTSxDQUFDO0FBRXpCaUssWUFBVSxNQUFNO0FBQ2QsVUFBTTRGLGlCQUFpQixZQUFZO0FBQ2pDLFVBQUk7QUFDRixjQUFNbEYsV0FBVyxNQUFNeFEsSUFBSXVDO0FBQUFBLFVBQ3pCLDBCQUEwQm1ELGNBQWNFLE9BQU87QUFBQSxRQUNqRDtBQUNBLFlBQUk0SyxTQUFTbUYsVUFBVSxJQUFLLE9BQU0sSUFBSUMsTUFBTSxXQUFXO0FBQ3ZEeE0sd0JBQWdCb0gsU0FBU0csSUFBSTtBQUFBLE1BQy9CLFNBQVNrRixLQUFLO0FBQ1puRCxnQkFBUW9ELElBQUksd0NBQXdDRCxJQUFJRSxPQUFPO0FBQUEsTUFDakU7QUFBQSxJQUNGO0FBQ0EsUUFBSXJRLGNBQWNFLFlBQVksVUFBVUYsY0FBY0UsWUFBWTtBQUNoRThQLHFCQUFlO0FBQUEsRUFDbkIsR0FBRyxDQUFDaFEsZUFBZUcsTUFBTSxDQUFDO0FBRTFCaUssWUFBVSxNQUFNO0FBQ2RoSCxxQkFBaUIsSUFBSTtBQUVyQixVQUFNa04sY0FBYyxZQUFZO0FBQzlCM1EsdUJBQWlCLElBQUk7QUFDckIsVUFBSTtBQUNGLGNBQU1tTCxXQUFXLE1BQU14USxJQUFJdUMsSUFBSSxnQkFBZ0I7QUFDL0NFLGtCQUFVK04sU0FBU0csSUFBSTtBQUN2QjdILHlCQUFpQixLQUFLO0FBQ3RCekQseUJBQWlCLEtBQUs7QUFBQSxNQUN4QixTQUFTdU4sT0FBTztBQUNkRixnQkFBUUUsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxNQUNuRCxVQUFDO0FBQ0N2Tix5QkFBaUIsS0FBSztBQUFBLE1BQ3hCO0FBQUEsSUFDRjtBQUNBMlEsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsRUFBRTtBQUVMbEcsWUFBVSxNQUFNO0FBQ2QsVUFBTW1HLGdCQUFnQixZQUFZO0FBQ2hDLFVBQUk7QUFDRjNNLHlCQUFpQixFQUFFO0FBQ25CLGNBQU1rSCxXQUFXLE1BQU14USxJQUFJdUMsSUFBSSxzQkFBc0JTLGFBQWEsRUFBRTtBQUNwRSxZQUFJd04sU0FBU0csTUFBTTtBQUNqQixnQkFBTXhHLHdCQUF1QnFHLFNBQVNHLE1BQU13RSxjQUFjakU7QUFBQUEsWUFDeEQsQ0FBQ1MsTUFBTVIsV0FBVztBQUFBLGNBQ2hCK0UsT0FBTy9FLFFBQVE7QUFBQSxjQUNmUSxNQUFNQSxNQUFNMEQsY0FBYzFELE1BQU1DO0FBQUFBLGNBQ2hDdUUsWUFBWXhFLE1BQU0wRCxjQUFjMUQsTUFBTXdFLFlBQVl4UixNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsY0FDOUR5UixVQUFVekUsTUFBTTBELGNBQWMxRCxNQUFNeUUsVUFBVXpSLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxjQUMxRDBSLGFBQWExRSxNQUFNMkU7QUFBQUEsY0FDbkJDLFFBQVE1RSxNQUFNMEQsY0FBYzFELE1BQU00RTtBQUFBQSxjQUNsQ0MsZ0JBQWdCN0UsTUFBTTBELGNBQWMxRCxNQUFNOEU7QUFBQUEsY0FDMUNDLFVBQ0UvRSxNQUFNMEQsY0FBYzFELE1BQU1nRixlQUFlOUY7QUFBQUEsZ0JBQ3ZDLENBQUNDLEtBQUs4RixXQUFXOUYsTUFBTUUsT0FBTzRGLE9BQU81USxVQUFVLENBQUM7QUFBQSxnQkFDaEQ7QUFBQSxjQUNGLEtBQUs7QUFBQSxjQUNQNlEsbUJBQW1CbEYsTUFBTWtGO0FBQUFBLGNBQ3pCM0QsU0FBU3ZCLE1BQU11QjtBQUFBQSxZQUNqQjtBQUFBLFVBQ0Y7QUFDQTlJLGtDQUF3QkQscUJBQW9CO0FBQUEsUUFDOUM7QUFDQWIseUJBQWlCa0gsU0FBU0csSUFBSTtBQUU5QixZQUFJSCxTQUFTbUYsVUFBVSxJQUFLLE9BQU0sSUFBSUMsTUFBTSx3QkFBd0I7QUFBQSxNQUN0RSxTQUFTQyxLQUFLO0FBQ1puRCxnQkFBUW9ELElBQUksa0NBQWtDRCxJQUFJRSxPQUFPO0FBQ3pEM0wsZ0NBQXdCLEVBQUU7QUFBQSxNQUM1QjtBQUFBLElBQ0Y7QUFDQUoscUJBQWlCLEVBQUU7QUFDbkJFLGtCQUFjLElBQUk7QUFDbEIrTCxrQkFBYztBQUFBLEVBQ2hCLEdBQUcsQ0FBQ2pULGFBQWEsQ0FBQztBQUVsQjhNLFlBQVUsTUFBTTtBQUNkLFVBQU1nSCxhQUFhLFlBQVk7QUFDN0IsVUFBSTtBQUNGdE4sMEJBQWtCLEVBQUU7QUFDcEIsY0FBTWdILFdBQVcsTUFBTXhRLElBQUl1QyxJQUFJLHVCQUF1QlMsYUFBYSxFQUFFO0FBQ3JFLFlBQUl3TixTQUFTRyxNQUFNO0FBQ2pCLGdCQUFNOUcscUJBQW9CMkcsU0FBU0csTUFBTW9HLGVBQWU3RjtBQUFBQSxZQUN0RCxDQUFDVyxPQUFPVixXQUFXO0FBQUEsY0FDakIrRSxPQUFPL0UsUUFBUTtBQUFBLGNBQ2ZVLE9BQU9BLE9BQU9tRixlQUFlbkYsT0FBT0M7QUFBQUEsY0FDcENxRSxZQUNFdEUsT0FBT21GLGVBQWVuRixPQUFPc0UsWUFBWXhSLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxjQUN2RHNTLFVBQVVwRixPQUFPbUYsZUFBZW5GLE9BQU9vRjtBQUFBQSxjQUN2Q0MsbUJBQW1CckYsT0FBT21GLGVBQWVuRixPQUFPcUY7QUFBQUEsY0FDaERDLHdCQUF3QnRGLE9BQU9zRjtBQUFBQSxZQUNqQztBQUFBLFVBQ0Y7QUFDQXJOLCtCQUFxQkQsa0JBQWlCO0FBQUEsUUFDeEM7QUFDQUwsMEJBQWtCZ0gsU0FBU0csSUFBSTtBQUUvQixZQUFJSCxTQUFTbUYsVUFBVSxJQUFLLE9BQU0sSUFBSUMsTUFBTSx3QkFBd0I7QUFBQSxNQUN0RSxTQUFTQyxLQUFLO0FBQ1puRCxnQkFBUW9ELElBQUksbUNBQW1DRCxJQUFJRSxPQUFPO0FBQzFEak0sNkJBQXFCLEVBQUU7QUFBQSxNQUN6QjtBQUFBLElBQ0Y7QUFDQUoseUJBQXFCLEVBQUU7QUFDdkJFLGVBQVcsSUFBSTtBQUNma04sZUFBVztBQUFBLEVBQ2IsR0FBRyxDQUFDOVQsYUFBYSxDQUFDO0FBRWxCOE0sWUFBVSxNQUFNO0FBQ2QsVUFBTWtHLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTXhGLFdBQVcsTUFBTXhRLElBQUl1QyxJQUFJLHdCQUF3QlMsYUFBYSxFQUFFO0FBQ3RFRyxpQkFBU3FOLFNBQVNHLElBQUk7QUFBQSxNQUN4QixTQUFTaUMsT0FBTztBQUNkRixnQkFBUUUsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxNQUNuRDtBQUFBLElBQ0Y7QUFDQW9ELGdCQUFZO0FBQUEsRUFDZCxHQUFHLENBQUNoVCxhQUFhLENBQUM7QUFFbEI4TSxZQUFVLE1BQU07QUFDZCxVQUFNa0csY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRixjQUFNeEYsV0FBVyxNQUFNeFEsSUFBSXVDLElBQUksZ0JBQWdCO0FBQy9Db0IseUJBQWlCNk0sU0FBU0csSUFBSTtBQUFBLE1BQ2hDLFNBQVNpQyxPQUFPO0FBQ2RGLGdCQUFRRSxNQUFNLDhCQUE4QkEsS0FBSztBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUNBb0QsZ0JBQVk7QUFBQSxFQUNkLEdBQUcsRUFBRTtBQUdMbEcsWUFBVSxNQUFNO0FBQ2QsVUFBTXNILG9CQUFvQixZQUFZO0FBQ3BDLFVBQUk7QUFDRjVNLCtCQUF1QixJQUFJO0FBQzNCLGNBQU1nRyxXQUFXLE1BQU14USxJQUFJdUM7QUFBQUEsVUFDekI7QUFBQSxVQUNBO0FBQUEsWUFDRWtPLFFBQVE7QUFBQSxjQUNObk8sUUFBUVU7QUFBQUEsWUFDVjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBRUEsWUFBSXdOLFNBQVNHLE1BQU07QUFDakIsZ0JBQU1NLGdCQUFnQlQsU0FBU0csS0FBS08sSUFBSSxDQUFDaUMsU0FBU2hDLFVBQVU7QUFDMUQsZ0JBQUkrQixVQUFVO0FBRWRBLHVCQUFXbEMsT0FBT21DLFFBQVFuTixNQUFNO0FBQ2hDLG1CQUFPO0FBQUEsY0FDTG9MLEtBQUsrQixRQUFRL0I7QUFBQUEsY0FDYkMsSUFBSUYsUUFBUTtBQUFBLGNBQ1prRyxtQkFBbUJsRSxRQUFRa0U7QUFBQUE7QUFBQUEsY0FFM0IvRixZQUNFNkIsU0FBUzVDLFlBQVksU0FDakIsR0FBRzRDLFNBQVN4QixNQUFNQyxXQUFXLEVBQUUsS0FDL0J1QixTQUFTbEUsVUFBVXFDO0FBQUFBLGNBQ3pCbEMsVUFBVWdFLGNBQWNELFNBQVMvRCxRQUFRO0FBQUEsY0FDekN2SixRQUFRc04sUUFBUXROO0FBQUFBLGNBQ2hCcU0sa0JBQWtCa0IsY0FBY0QsUUFBUWxOLFNBQVM7QUFBQSxjQUNqREQsUUFBUW1OLFFBQVFuTjtBQUFBQSxjQUNoQm1KLFlBQVlnRSxRQUFRaEU7QUFBQUEsY0FDcEJFLFVBQVU4RCxRQUFROUQ7QUFBQUEsY0FDbEJpSSxjQUFjbkUsUUFBUWIsWUFBWWY7QUFBQUEsY0FDbEMyQjtBQUFBQSxZQUNGO0FBQUEsVUFDRixDQUFDO0FBRUQ1SSxrQ0FBd0IyRyxhQUFhO0FBQUEsUUFDdkMsT0FBTztBQUNMM0csa0NBQXdCLEVBQUU7QUFBQSxRQUM1QjtBQUFBLE1BQ0YsU0FBU3NJLE9BQU87QUFDZEYsZ0JBQVFFLE1BQU0sb0NBQW9DQSxPQUFPQSxNQUFNbUQsT0FBTztBQUN0RXpMLGdDQUF3QixFQUFFO0FBQUEsTUFDNUIsVUFBQztBQUNDRSwrQkFBdUIsS0FBSztBQUFBLE1BQzlCO0FBQUEsSUFDRjtBQUNBLFFBQUl4SCxjQUFlb1UsbUJBQWtCO0FBQUEsRUFDdkMsR0FBRyxDQUFDcFUsYUFBYSxDQUFDO0FBRWxCLFFBQU11VSxxQkFBcUIsT0FBTzNSLFlBQVk7QUFDNUNnQyw4QkFBMEJoQyxPQUFPO0FBQ2pDM0MscUJBQWlCMkMsT0FBTztBQUN4QjRSLDZCQUF5QjVSLE9BQU87QUFBQSxFQUNsQztBQUNBa0ssWUFBVSxNQUFNO0FBQ2QsUUFBSXhOLFFBQVE7QUFDVmlWLHlCQUFtQmpWLE1BQU07QUFBQSxJQUMzQjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTW1WLG9CQUFvQkEsQ0FBQ0MsVUFBVTtBQUNuQyxVQUFNelEsUUFBUXlRLE1BQU05SSxPQUFPM0g7QUFFM0IsUUFBSUEsT0FBTztBQUNULFlBQU0sQ0FBQ3JCLFNBQVNDLE1BQU0sSUFBSW9CLE1BQU10QyxNQUFNLEdBQUc7QUFDekNnQix1QkFBaUIsRUFBRUMsU0FBU0MsT0FBTyxDQUFDO0FBQUEsSUFDdEMsT0FBTztBQUNMRix1QkFBaUIsRUFBRUMsU0FBUyxJQUFJQyxRQUFRLEdBQUcsQ0FBQztBQUM1QyxVQUFJa0QsY0FBYyxXQUFXO0FBQzNCMEMsdUJBQWUsRUFBRTtBQUFBLE1BQ25CO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQXFFLFlBQVUsTUFBTTtBQUNkLFVBQU02SCwyQkFBMkIsWUFBWTtBQUMzQyxVQUFJO0FBQ0YsWUFBSSxDQUFDaFEsdUJBQXdCO0FBRTdCLGNBQU02SSxXQUFXLE1BQU14USxJQUFJdUM7QUFBQUEsVUFDekIsa0JBQWtCb0Ysc0JBQXNCO0FBQUEsUUFDMUM7QUFDQStLLGdCQUFRa0YsS0FBS3BILFNBQVNHLEtBQUtsSSxVQUFVLDJCQUEyQjtBQUNoRXhFLGdDQUF3QnVNLFNBQVNHLEtBQUtsSSxRQUFRO0FBQUEsTUFDaEQsU0FBU21LLE9BQU87QUFDZEYsZ0JBQVFFLE1BQU0sZ0RBQWdEQSxLQUFLO0FBQUEsTUFDckU7QUFBQSxJQUNGO0FBQ0ErRSw2QkFBeUI7QUFBQSxFQUMzQixHQUFHLENBQUNoUSxzQkFBc0IsQ0FBQztBQUUzQm1JO0FBQUFBLElBQVUsTUFBTTtBQUNkLFlBQU1HLGdCQUFnQixZQUFZO0FBQ2hDLFlBQUk7QUFDRixnQkFBTU8sV0FBVyxNQUFNeFEsSUFBSXVDLElBQUksaUNBQWlDO0FBQUEsWUFDOURrTyxRQUFRO0FBQUEsY0FDTk4sV0FBV2xJO0FBQUFBLGNBQ1htSSxTQUFTakk7QUFBQUEsY0FDVHZDLFNBQVMrQjtBQUFBQSxjQUNUckYsUUFBUWlHO0FBQUFBLGNBQ1I4RyxVQUFVaEg7QUFBQUEsWUFDWjtBQUFBLFVBQ0YsQ0FBQztBQUVELGNBQUltSSxTQUFTRyxRQUFRSCxTQUFTRyxLQUFLTixTQUFTLEdBQUc7QUFFN0Msa0JBQU13SCxjQUFjckgsU0FBU0c7QUFDN0Isa0JBQU03TCxlQUFjK1MsWUFBWWhIO0FBQUFBLGNBQzlCLENBQUNDLEtBQUtxQyxZQUFZckMsTUFBTUUsT0FBT21DLFFBQVFuTixVQUFVLENBQUM7QUFBQSxjQUNsRDtBQUFBLFlBQ0Y7QUFDQTBDLHdCQUFZNUQsWUFBVztBQUN2QixrQkFBTW1NLGdCQUFnQlQsU0FBU0csS0FBS08sSUFBSSxDQUFDaE8sUUFBT2lPLFdBQVc7QUFBQSxjQUN6REUsSUFBSUYsUUFBUTtBQUFBLGNBQ1pqTyxPQUFPQSxPQUFNK0wsVUFBVXFDO0FBQUFBLGNBQ3ZCQyxNQUFNck8sT0FBTWdNLFNBQVNzQztBQUFBQSxjQUNyQkUsY0FBY3hPLFFBQU9nTSxTQUFTd0M7QUFBQUEsY0FDOUI3TCxRQUFRM0MsUUFBTzJDO0FBQUFBLGNBQ2ZHLFFBQVE5QyxRQUFPOEM7QUFBQUEsY0FDZm1NLE1BQU1qUCxRQUFPbU07QUFBQUEsWUFDZixFQUFFO0FBQ0Z4TSw0QkFBZ0JvTyxhQUFhO0FBQUEsVUFDL0I7QUFBQSxRQUNGLFNBQVMyQixPQUFPO0FBQ2RGLGtCQUFRRSxNQUFNLGdDQUFnQ0EsS0FBSztBQUVuRGxLLHNCQUFZLENBQUM7QUFBQSxRQUNmO0FBQUEsTUFDRjtBQUVBdUgsb0JBQWM7QUFBQSxJQUNoQjtBQUFBLElBQUc7QUFBQSxNQUNEdEk7QUFBQUEsTUFDQVE7QUFBQUEsTUFDQUY7QUFBQUEsTUFDQUk7QUFBQUEsTUFDQUU7QUFBQUEsSUFBaUI7QUFBQSxFQUNsQjtBQUVELGlCQUFldVAsa0NBQWtDO0FBQy9DLFFBQUk7QUFDRjNKLCtCQUF5QixJQUFJO0FBRTdCLFlBQU1xQyxXQUFXLE1BQU14USxJQUFJdUMsSUFBSSxxQkFBcUJTLGFBQWEsRUFBRTtBQUNuRSxZQUFNK1UsZUFBZXZILFVBQVVHLE1BQU1BLFFBQVE7QUFFN0M1Qyx3QkFBa0JnSyxZQUFZO0FBQUEsSUFDaEMsU0FBU25GLE9BQU87QUFDZDdFLHdCQUFrQixFQUFFO0FBQUEsSUFDdEIsVUFBQztBQUNDSSwrQkFBeUIsS0FBSztBQUFBLElBQ2hDO0FBQUEsRUFDRjtBQUNBMkIsWUFBVSxNQUFNO0FBQ2QsUUFBSS9HLGNBQWM7QUFDaEIrTyxzQ0FBZ0M7QUFBQSxFQUNwQyxHQUFHLENBQUMvTyxXQUFXL0YsYUFBYSxDQUFDO0FBRzdCLFFBQU1nVixzQkFBc0IsT0FBTzFWLFlBQVc7QUFDNUMsUUFBSSxDQUFDQSxRQUFRO0FBRWIsUUFBSTtBQUNGK0IsK0JBQXlCLElBQUk7QUFFN0IsWUFBTW1NLFdBQVcsTUFBTXhRLElBQUl1QztBQUFBQSxRQUN6QiwyQkFBMkJELE9BQU07QUFBQSxNQUNuQztBQUVBb1EsY0FBUWtGLEtBQUtwSCxVQUFVLHNCQUFzQjtBQUU3QyxVQUFJQSxVQUFVRyxNQUFNZ0YsUUFBUTtBQUMxQnhSLDBCQUFrQnFNLFNBQVNHLEtBQUtBLElBQUk7QUFBQSxNQUN0QyxPQUFPO0FBQ0x4TSwwQkFBa0IsSUFBSTtBQUFBLE1BQ3hCO0FBQUEsSUFDRixTQUFTeU8sT0FBTztBQUNkRixjQUFRRSxNQUFNLG1DQUFtQ0EsS0FBSztBQUN0RHpPLHdCQUFrQixJQUFJO0FBQUEsSUFDeEIsVUFBQztBQUNDRSwrQkFBeUIsS0FBSztBQUFBLElBQ2hDO0FBQUEsRUFDRjtBQUVBeUwsWUFBVSxNQUFNO0FBQ2QsUUFBSTlNLGlCQUFpQitGLGNBQWMsaUJBQWlCO0FBQ2xEaVAsMEJBQW9CaFYsYUFBYTtBQUFBLElBQ25DO0FBQUEsRUFDRixHQUFHLENBQUNBLGVBQWUrRixTQUFTLENBQUM7QUFFN0IsUUFBTWtQLHFCQUFxQmpWLGdCQUN2QmtCLGdCQUFnQmdVLGNBQWNDLE9BQU8sQ0FBQ3BILFNBQVNBLEtBQUtLLFFBQVFwTyxhQUFhLElBQ3pFa0IsZ0JBQWdCZ1UsZ0JBQWdCO0FBR3BDLFFBQU1FLHVCQUF1QixPQUFPeFMsU0FBU0MsV0FBVztBQUN0RCxRQUFJLENBQUM3QyxpQkFBaUIsQ0FBQzRDLFdBQVcsQ0FBQ0MsUUFBUTtBQUN6QzRGLHFCQUFlLEVBQUU7QUFDakI7QUFBQSxJQUNGO0FBRUEsUUFBSWpFLGtCQUFrQjZRLFNBQVM7QUFDN0I7QUFBQSxJQUNGO0FBRUEsUUFBSTtBQUNGN1Esd0JBQWtCNlEsVUFBVTtBQUM1QjFNLHdCQUFrQixJQUFJO0FBRXRCLFlBQU02RSxXQUFXLE1BQU14USxJQUFJdUM7QUFBQUEsUUFDekIsd0NBQXdDUyxhQUFhLElBQUk0QyxPQUFPLElBQUlDLE1BQU07QUFBQSxNQUM1RTtBQUVBLFVBQUkySyxTQUFTRyxNQUFNMkgsV0FBVzlILFNBQVNHLE1BQU1BLE1BQU07QUFDakQsY0FBTUEsT0FBT0gsU0FBU0csS0FBS0E7QUFFM0IsY0FBTTRILG1CQUFtQjtBQUFBLFVBQ3ZCL0osY0FBY21DLEtBQUtuQyxnQkFBZ0I1STtBQUFBQSxVQUNuQzRTLFdBQVc3SCxLQUFLek4sT0FBT29PLGNBQWNYLEtBQUs2SCxhQUFhO0FBQUEsVUFDdkQzUztBQUFBQSxVQUNBNFMsY0FDRTlILEtBQUsrSCxNQUFNbEgsYUFDWGIsS0FBSzhILGdCQUNMdlYsT0FBT3NPLGFBQ1A7QUFBQSxVQUNGbUgsZUFDRWhJLEtBQUsrSCxNQUFNaEgsZ0JBQ1hmLEtBQUtnSSxpQkFDTHpWLE9BQU93TyxnQkFDUDtBQUFBLFVBQ0ZrSCxlQUFlakksS0FBS2tJLFNBQVNELGlCQUFpQjtBQUFBLFVBQzlDRSxXQUFXbkksS0FBS2tJLFNBQVNDLGFBQWE7QUFBQSxVQUN0Q0MsY0FBY3BJLEtBQUtrSSxTQUFTRSxnQkFBZ0I7QUFBQSxVQUM1Q0MsY0FBY3JJLEtBQUtrSSxTQUFTRyxnQkFBZ0I7QUFBQSxVQUM1Q0MsV0FBV3RJLEtBQUtrSSxTQUFTSSxhQUFhO0FBQUEsVUFDdENDLGVBQWV2SSxLQUFLa0ksU0FBU00sWUFBWTtBQUFBLFVBQ3pDQyx1QkFBdUJ6SSxLQUFLa0ksU0FBU1Esa0JBQWtCO0FBQUEsVUFDdkRBLGdCQUFnQjFJLEtBQUtrSSxTQUFTUSxrQkFBa0I7QUFBQSxVQUNoREMsUUFDRTNJLEtBQUs0SSxXQUFXckksSUFBSSxDQUFDc0ksT0FBTztBQUFBLFlBQzFCQyxVQUFVRCxFQUFFQztBQUFBQSxZQUNaQyxVQUFVRixFQUFFRTtBQUFBQSxZQUNaQyxVQUFVSCxFQUFFRztBQUFBQSxZQUNaQyxNQUFNSixFQUFFSTtBQUFBQSxZQUNSMUcsU0FBU3NHLEVBQUV0RztBQUFBQSxZQUNYMkcsU0FBU0wsRUFBRU07QUFBQUEsWUFDWEMsc0JBQXNCUCxFQUFFUTtBQUFBQSxZQUN4QnJFLFFBQVE2RCxFQUFFN0Q7QUFBQUEsVUFDWixFQUFFLEtBQUs7QUFBQSxVQUNUc0UsaUJBQWlCdEosS0FBSzRJLFlBQVksQ0FBQyxHQUFHbkksT0FBTztBQUFBLFFBQy9DO0FBRUEzRix1QkFBZSxDQUFDOE0sZ0JBQWdCLENBQUM7QUFBQSxNQUNuQyxPQUFPO0FBQ0w5TSx1QkFBZSxFQUFFO0FBQUEsTUFDbkI7QUFBQSxJQUNGLFNBQVNtSCxPQUFPO0FBQ2RGLGNBQVFFLE1BQU0sMkJBQTJCQSxLQUFLO0FBQzlDbkgscUJBQWUsRUFBRTtBQUFBLElBQ25CLFVBQUM7QUFDQ0Usd0JBQWtCLEtBQUs7QUFDdkJuRSx3QkFBa0I2USxVQUFVO0FBQUEsSUFDOUI7QUFBQSxFQUNGO0FBRUEsUUFBTTZCLHNCQUFzQkEsQ0FBQ2xVLFdBQVc7QUFDdEMsV0FBTyxLQUFLQSxVQUFVLEdBQUdtVSxlQUFlLE9BQU8sQ0FBQztBQUFBLEVBQ2xEO0FBRUEsUUFBTUMsaUJBQWlCO0FBQUEsSUFDckIsRUFBRTVLLEtBQUssU0FBU0MsUUFBUSxTQUFTO0FBQUEsSUFDakMsRUFBRUQsS0FBSyxhQUFhQyxRQUFRLGFBQWE7QUFBQSxJQUN6QyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVELEtBQUssaUJBQWlCQyxRQUFRLGlCQUFpQjtBQUFBLElBQ2pELEVBQUVELEtBQUssYUFBYUMsUUFBUSxhQUFhO0FBQUEsSUFDekMsRUFBRUQsS0FBSyx5QkFBeUJDLFFBQVEsd0JBQXdCO0FBQUEsSUFDaEUsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDL0MsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsV0FBVztBQUFBLElBQzFDLEVBQUVELEtBQUssYUFBYUMsUUFBUSxhQUFhO0FBQUEsSUFDekMsRUFBRUQsS0FBSyxpQkFBaUJDLFFBQVEsb0JBQW9CO0FBQUEsSUFDcEQsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLGVBQWU7QUFBQSxFQUFDO0FBRzNDLFFBQU00SywwQkFBMEI7QUFBQSxJQUM5QixFQUFFN0ssS0FBSyxZQUFZQyxRQUFRLGNBQWM7QUFBQSxJQUN6QyxFQUFFRCxLQUFLLFlBQVlDLFFBQVEsV0FBVztBQUFBLElBQ3RDLEVBQUVELEtBQUssWUFBWUMsUUFBUSxrQkFBa0I7QUFBQSxJQUM3QyxFQUFFRCxLQUFLLFFBQVFDLFFBQVEsY0FBYztBQUFBLElBQ3JDLEVBQUVELEtBQUssV0FBV0MsUUFBUSxVQUFVO0FBQUEsSUFDcEMsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLFVBQVU7QUFBQSxJQUNwQyxFQUFFRCxLQUFLLHdCQUF3QkMsUUFBUSxXQUFXO0FBQUEsSUFDbEQsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFFBQU02Syx3QkFBd0I7QUFBQSxJQUM1QjtBQUFBLE1BQ0VDLE9BQU87QUFBQSxNQUNQQyxXQUFXO0FBQUEsTUFDWGhMLEtBQUs7QUFBQSxNQUNMaUwsUUFBUUEsQ0FBQ3hJLFNBQVN5SSxPQUFPekksSUFBSSxFQUFFMEksT0FBTyxrQkFBa0I7QUFBQSxNQUN4REMsUUFBUUEsQ0FBQ0MsR0FBR0MsTUFBTSxJQUFJclcsS0FBS29XLEVBQUU1VSxTQUFTLElBQUksSUFBSXhCLEtBQUtxVyxFQUFFN1UsU0FBUztBQUFBLE1BQzlEOFUsa0JBQWtCO0FBQUEsSUFDcEI7QUFBQSxJQUNBO0FBQUEsTUFDRVIsT0FBTztBQUFBLE1BQ1BDLFdBQVc7QUFBQSxNQUNYaEwsS0FBSztBQUFBLE1BQ0x3TCxPQUFPO0FBQUEsTUFDUFAsUUFBUUEsQ0FBQ3pVLFdBQ1BBLFNBQVMsSUFBSSxLQUFLQSxVQUFVLEdBQUdtVSxlQUFlLE9BQU8sQ0FBQyxLQUFLO0FBQUEsSUFDL0Q7QUFBQSxJQUNBO0FBQUEsTUFDRUksT0FBTztBQUFBLE1BQ1BDLFdBQVc7QUFBQSxNQUNYaEwsS0FBSztBQUFBLE1BQ0x3TCxPQUFPO0FBQUEsTUFDUFAsUUFBUUEsQ0FBQ3pVLFdBQ1BBLFNBQVMsSUFBSSxLQUFLQSxVQUFVLEdBQUdtVSxlQUFlLE9BQU8sQ0FBQyxLQUFLO0FBQUEsSUFDL0Q7QUFBQSxJQUNBO0FBQUEsTUFDRUksT0FBTztBQUFBLE1BQ1AvSyxLQUFLO0FBQUEsTUFDTHdMLE9BQU87QUFBQSxNQUNQUCxRQUFRQSxDQUFDUSxHQUFHQyxXQUFXO0FBQ3JCLGNBQU1DLFNBQ0hELE9BQU9wQixrQkFBa0IsTUFBTW9CLE9BQU9sQixtQkFBbUI7QUFDNUQsZUFBTyxJQUFJbUIsTUFBTWhCLGVBQWUsT0FBTyxDQUFDO0FBQUEsTUFDMUM7QUFBQSxJQUNGO0FBQUEsSUFDQTtBQUFBLE1BQ0VJLE9BQU87QUFBQSxNQUNQQyxXQUFXO0FBQUEsTUFDWGhMLEtBQUs7QUFBQSxNQUNMaUwsUUFBUUEsQ0FBQzFGLFdBQVdBLFVBQVU7QUFBQSxJQUNoQztBQUFBLEVBQUM7QUFHSCxRQUFNcUcsK0JBQStCQyxRQUFRLE1BQU07QUFDakQsV0FBTzdQLFlBQVkwRixJQUFJLENBQUNILE1BQU1JLFdBQVc7QUFBQSxNQUN2QzNCLEtBQUt1QixLQUFLdkM7QUFBQUEsTUFDVjBILE9BQU8vRSxRQUFRO0FBQUEsTUFDZnFILFdBQVd6SCxLQUFLeUg7QUFBQUEsTUFDaEIzUyxRQUFRa0wsS0FBS2xMO0FBQUFBLE1BQ2IrUyxlQUFlc0Isb0JBQW9CbkosS0FBSzZILGFBQWE7QUFBQSxNQUNyREUsV0FBV29CLG9CQUFvQm5KLEtBQUsrSCxTQUFTO0FBQUEsTUFDN0NNLHVCQUNFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUNFckksS0FBS3FJLHlCQUF5QixJQUMxQixpQ0FDQTtBQUFBLFVBR0xjLDhCQUFvQm9CLEtBQUtDLElBQUl4SyxLQUFLcUkseUJBQXlCLENBQUMsQ0FBQztBQUFBO0FBQUEsUUFQaEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUE7QUFBQSxNQUVGTCxjQUFjbUIsb0JBQW9CbkosS0FBS2dJLFlBQVk7QUFBQSxNQUNuREMsY0FBY2tCLG9CQUFvQm5KLEtBQUtpSSxZQUFZO0FBQUEsTUFDbkRDLFdBQVdpQixvQkFBb0JuSixLQUFLa0ksU0FBUztBQUFBLE1BQzdDQyxlQUNFLHVCQUFDLFVBQUssV0FBVSxvQ0FDYmdCLDhCQUFvQm5KLEtBQUttSSxhQUFhLEtBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUYxRyxRQUNFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxNQUFNLHVCQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVk7QUFBQSxVQUNsQixTQUFTLE1BQU1nSixxQkFBcUJ6SyxJQUFJO0FBQUEsVUFDeEMsV0FBVTtBQUFBLFVBQWU7QUFBQTtBQUFBLFFBSjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BO0FBQUEsSUFFSixFQUFFO0FBQUEsRUFDSixHQUFHLENBQUN2RixXQUFXLENBQUM7QUFFaEIsUUFBTWdRLHVCQUF1QkEsQ0FBQzNCLFlBQVk7QUFDeEM5Tix1QkFBbUI4TixPQUFPO0FBQzFCaE8sNkJBQXlCLElBQUk7QUFBQSxFQUMvQjtBQUVBLFFBQU00UCx5QkFBeUJKLFFBQVEsTUFBTTtBQUMzQyxRQUFJLENBQUN2UCxpQkFBaUJ3TixPQUFRLFFBQU87QUFFckMsV0FBT3hOLGdCQUFnQndOLE9BQU9wSSxJQUFJLENBQUN3SyxPQUFPdkssV0FBVztBQUFBLE1BQ25EM0IsS0FBSzJCO0FBQUFBLE1BQ0xzSSxVQUFVaUMsTUFBTWpDLFlBQVl0SSxRQUFRO0FBQUEsTUFDcEN1SSxVQUFVZ0MsTUFBTWhDLFdBQ1puWSxNQUFNbWEsTUFBTWhDLFFBQVEsRUFBRWlCLE9BQU8sWUFBWSxJQUN6QztBQUFBLE1BQ0poQixVQUFVTyxvQkFBb0J3QixNQUFNL0IsUUFBUTtBQUFBLE1BQzVDQyxNQUFNTSxvQkFBb0J3QixNQUFNOUIsSUFBSTtBQUFBLE1BQ3BDMUcsU0FDRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBV3dJLE1BQU14SSxXQUFXLElBQUksbUJBQW1CO0FBQUEsVUFFbERnSCw4QkFBb0JvQixLQUFLQyxJQUFJRyxNQUFNeEksV0FBVyxDQUFDLENBQUM7QUFBQTtBQUFBLFFBSG5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUlBO0FBQUEsTUFFRjJHLFNBQVNLLG9CQUFvQndCLE1BQU03QixPQUFPO0FBQUEsTUFDMUNFLHNCQUFzQkcsb0JBQW9Cd0IsTUFBTTNCLG9CQUFvQjtBQUFBLE1BQ3BFcEUsUUFDRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FDRStGLE1BQU14SSxZQUFZLElBQUksVUFBVXdJLE1BQU14SSxVQUFVLElBQUksUUFBUTtBQUFBLFVBRzdEd0ksZ0JBQU14SSxZQUFZLElBQ2YsU0FDQXdJLE1BQU14SSxVQUFVLElBQ2QsWUFDQTtBQUFBO0FBQUEsUUFUUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFVQTtBQUFBLElBRUosRUFBRTtBQUFBLEVBQ0osR0FBRyxDQUFDcEgsZUFBZSxDQUFDO0FBRXBCZ0UsWUFBVSxNQUFNO0FBQ2QsUUFDRS9HLGNBQWMsYUFDZC9GLGlCQUNBMEMsY0FBY0UsV0FDZEYsY0FBY0csUUFDZDtBQUNBdVMsMkJBQXFCMVMsY0FBY0UsU0FBU0YsY0FBY0csTUFBTTtBQUFBLElBQ2xFLFdBQVdrRCxjQUFjLFdBQVc7QUFDbEMwQyxxQkFBZSxFQUFFO0FBQUEsSUFDbkI7QUFBQSxFQUNGLEdBQUcsQ0FBQzFDLFdBQVcvRixlQUFlMEMsY0FBY0UsU0FBU0YsY0FBY0csTUFBTSxDQUFDO0FBUTFFLFFBQU04ViwyQkFBMkIsWUFBWTtBQUMzQyxRQUFJLENBQUMzWSxjQUFlO0FBRXBCLFFBQUk7QUFDRm1KLDRCQUFzQixJQUFJO0FBRzFCLFlBQU1xRSxXQUFXLE1BQU14USxJQUFJdUM7QUFBQUEsUUFDekIsNEJBQTRCUyxhQUFhO0FBQUEsTUFDM0M7QUFFQSxVQUFJd04sU0FBU0csUUFBUUgsU0FBU0csS0FBSzJILFNBQVM7QUFDMUMsY0FBTXJILGdCQUFnQlQsU0FBU0csS0FBS0EsS0FBS08sSUFBSSxDQUFDSCxNQUFNSSxVQUFVO0FBQzVELGdCQUFNeUssYUFBYTdLLE1BQU04SyxnQkFBZ0IsQ0FBQztBQUMxQyxnQkFBTUMsY0FBYy9LLE1BQU1uTCxXQUFXLENBQUM7QUFDdEMsZ0JBQU1zTixVQUFVbkMsTUFBTWdMLFVBQVU3SSxXQUFXO0FBRTNDLGdCQUFNOEksaUJBQWlCQSxDQUFDckcsV0FBVztBQUNqQyxrQkFBTXNHLGVBQWU7QUFBQSxjQUNuQkMsU0FBUztBQUFBLGNBQ1RDLFFBQVE7QUFBQSxjQUNSQyxTQUFTO0FBQUEsY0FDVEMsYUFBYTtBQUFBLGNBQ2JDLFFBQVE7QUFBQSxZQUNWO0FBQ0EsbUJBQU9MLGFBQWF0RyxNQUFNLEtBQUs7QUFBQSxVQUNqQztBQUVBLGlCQUFPO0FBQUEsWUFDTHZFLEtBQUtMLEtBQUtLO0FBQUFBLFlBQ1ZDLElBQUlGLFFBQVE7QUFBQSxZQUNab0wsa0JBQWtCeEwsS0FBS3dMLG9CQUFvQixNQUFNcEwsUUFBUSxDQUFDO0FBQUEsWUFDMURxTCxjQUFjekwsS0FBSzlLLFlBQ2YxRSxNQUFNd1AsS0FBSzlLLFNBQVMsRUFBRTBVLE9BQU8sWUFBWSxJQUN6QztBQUFBLFlBQ0o4QixXQUNFMUwsS0FBSzJMLG1CQUNKLE9BQU9kLGVBQWUsV0FBV0EsV0FBV3BLLFlBQVk7QUFBQSxZQUMzREYsWUFDRVAsS0FBS3lILGNBQ0osT0FBT3NELGdCQUFnQixXQUNwQkEsWUFBWXhLLGFBQ1o7QUFBQSxZQUNOcUwsZUFBZTVMLEtBQUs2TCxnQkFBZ0I7QUFBQSxZQUNwQ0MsY0FBYzlMLEtBQUsrTCxjQUNmdmIsTUFBTXdQLEtBQUsrTCxXQUFXLEVBQUVuQyxPQUFPLFlBQVksSUFDM0M7QUFBQSxZQUNKb0MsY0FBY2hNLEtBQUtnTSxlQUNmeGIsTUFBTXdQLEtBQUtnTSxjQUFjLE9BQU8sRUFBRXBDLE9BQU8sUUFBUSxJQUNqRDtBQUFBLFlBQ0p6SDtBQUFBQSxZQUNBOEosaUJBQWlCLElBQUk5SixTQUFTaUgsZUFBZSxPQUFPLEtBQUssQ0FBQztBQUFBLFlBQzFEeEUsUUFBUTVFLEtBQUs0RSxVQUFVO0FBQUEsWUFDdkJzSCxjQUFjakIsZUFBZWpMLEtBQUs0RSxNQUFNO0FBQUEsWUFDeEN1SCxhQUFhbk0sS0FBS21NLGVBQWU7QUFBQSxZQUNqQ0MsWUFBWXBNLEtBQUtxTSxhQUFhO0FBQUEsWUFDOUJDLGVBQWV0TSxLQUFLc00saUJBQWlCO0FBQUEsWUFDckNDLGNBQ0V2TSxLQUFLdU0saUJBQ0osT0FBTzFCLGVBQWUsV0FDbkJBLFdBQVdsSyxlQUNYO0FBQUEsWUFDTjZMLG1CQUFtQnhNLEtBQUt5TSxnQkFBZ0JDLFlBQ3BDbGMsTUFBTXdQLEtBQUt5TSxlQUFlQyxTQUFTLEVBQUU5QyxPQUFPLFlBQVksSUFDeEQ7QUFBQSxVQUNOO0FBQUEsUUFDRixDQUFDO0FBRUQxTywyQkFBbUJnRixhQUFhO0FBQUEsTUFDbEMsT0FBTztBQUNMaEYsMkJBQW1CLEVBQUU7QUFBQSxNQUN2QjtBQUFBLElBQ0YsU0FBUzJHLE9BQU87QUFDZEYsY0FBUUUsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFDbkQzRyx5QkFBbUIsRUFBRTtBQUFBLElBQ3ZCLFVBQUM7QUFDQ0UsNEJBQXNCLEtBQUs7QUFBQSxJQUM3QjtBQUFBLEVBQ0Y7QUFHQTJELFlBQVUsTUFBTTtBQUNkLFFBQUkvRyxjQUFjLGdCQUFnQi9GLGVBQWU7QUFDL0MyWSwrQkFBeUI7QUFBQSxJQUMzQjtBQUFBLEVBQ0YsR0FBRyxDQUFDNVMsV0FBVy9GLGFBQWEsQ0FBQztBQUc3QixRQUFNMGEsd0JBQXdCQSxDQUFDQyxlQUFlO0FBQzVDcFIsMEJBQXNCb1IsVUFBVTtBQUNoQ3RSLDhCQUEwQixJQUFJO0FBQUEsRUFDaEM7QUFHQSxRQUFNdVIsb0JBQW9CO0FBQUEsSUFDeEIsRUFBRXBPLEtBQUssU0FBU0MsUUFBUSxTQUFTO0FBQUEsSUFDakMsRUFBRUQsS0FBSyxvQkFBb0JDLFFBQVEsbUJBQW1CO0FBQUEsSUFDdEQsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVELEtBQUssY0FBY0MsUUFBUSxhQUFhO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxpQkFBaUJDLFFBQVEsU0FBUztBQUFBLElBQ3pDLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRUQsS0FBSyxtQkFBbUJDLFFBQVEsVUFBVTtBQUFBLElBQzVDLEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQyxRQUFNb08sd0JBQXdCLFlBQVk7QUFDeEMsUUFBSSxDQUFDN2EsY0FBZTtBQUVwQixRQUFJO0FBQ0YySix3QkFBa0IsSUFBSTtBQUd0QixZQUFNNkQsV0FBVyxNQUFNeFEsSUFBSXVDLElBQUksa0JBQWtCUyxhQUFhLEVBQUU7QUFDaEUsVUFBSThhLFdBQVc7QUFFZixVQUFJQyxNQUFNQyxRQUFReE4sU0FBU0csSUFBSSxHQUFHO0FBQ2hDbU4sbUJBQVd0TixTQUFTRztBQUFBQSxNQUN0QixXQUFXSCxTQUFTRyxLQUFLQSxRQUFRb04sTUFBTUMsUUFBUXhOLFNBQVNHLEtBQUtBLElBQUksR0FBRztBQUNsRW1OLG1CQUFXdE4sU0FBU0csS0FBS0E7QUFBQUEsTUFDM0IsV0FDRUgsU0FBU0csS0FBS21OLFlBQ2RDLE1BQU1DLFFBQVF4TixTQUFTRyxLQUFLbU4sUUFBUSxHQUNwQztBQUNBQSxtQkFBV3ROLFNBQVNHLEtBQUttTjtBQUFBQSxNQUMzQixPQUFPO0FBQ0xBLG1CQUNFRyxPQUFPQyxPQUFPMU4sU0FBU0csSUFBSSxFQUFFeUUsS0FBSyxDQUFDK0ksTUFBTUosTUFBTUMsUUFBUUcsQ0FBQyxDQUFDLEtBQUs7QUFBQSxNQUNsRTtBQUdBLFlBQU1sTixnQkFBZ0I2TSxTQUFTNU0sSUFBSSxDQUFDSCxNQUFNSSxVQUFVO0FBQ2xELGNBQU1pTixpQkFBaUJBLENBQUNDLGVBQWU7QUFDckMsY0FBSSxDQUFDQSxXQUFZLFFBQU87QUFDeEIsZ0JBQU1wTSxPQUFPLElBQUl4TixLQUFLNFosVUFBVTtBQUNoQyxjQUFJQyxNQUFNck0sS0FBS3NNLFFBQVEsQ0FBQyxFQUFHLFFBQU87QUFDbEMsZ0JBQU1DLE1BQU1DLE9BQU94TSxLQUFLeU0sUUFBUSxDQUFDLEVBQUVDLFNBQVMsR0FBRyxHQUFHO0FBQ2xELGdCQUFNQyxRQUFRSCxPQUFPeE0sS0FBSzRNLFNBQVMsSUFBSSxDQUFDLEVBQUVGLFNBQVMsR0FBRyxHQUFHO0FBQ3pELGdCQUFNRyxPQUFPN00sS0FBSzhNLFlBQVk7QUFDOUIsY0FBSUMsUUFBUS9NLEtBQUtnTixTQUFTO0FBQzFCLGdCQUFNQyxVQUFVVCxPQUFPeE0sS0FBS2tOLFdBQVcsQ0FBQyxFQUFFUixTQUFTLEdBQUcsR0FBRztBQUN6RCxnQkFBTVMsT0FBT0osU0FBUyxLQUFLLE9BQU87QUFDbENBLGtCQUFRQSxRQUFRO0FBQ2hCQSxrQkFBUUEsUUFBUUEsUUFBUTtBQUN4QixnQkFBTUssV0FBV1osT0FBT08sS0FBSyxFQUFFTCxTQUFTLEdBQUcsR0FBRztBQUM5QyxpQkFBTyxHQUFHSCxHQUFHLElBQUlJLEtBQUssSUFBSUUsSUFBSSxJQUFJTyxRQUFRLElBQUlILE9BQU8sSUFBSUUsSUFBSTtBQUFBLFFBQy9EO0FBRUEsZUFBTztBQUFBLFVBQ0xoTyxLQUFLTCxLQUFLSztBQUFBQSxVQUNWOEUsT0FBTy9FLFFBQVE7QUFBQTtBQUFBLFVBQ2ZFLElBQUlGLFFBQVE7QUFBQSxVQUNabU8sY0FBY3ZPLEtBQUt1TyxnQkFBZ0IsT0FBT25PLFFBQVEsQ0FBQztBQUFBLFVBQ25ESSxNQUFNUixLQUFLUSxRQUFRO0FBQUEsVUFDbkJnTyxPQUFPeE8sS0FBS3dPLFNBQVM7QUFBQSxVQUNyQkMsT0FBT3pPLEtBQUt5TyxTQUFTO0FBQUEsVUFDckJDLFNBQVMxTyxLQUFLME8sV0FBVztBQUFBLFVBQ3pCQyxhQUFhM08sS0FBSzJPLGVBQWU7QUFBQSxVQUNqQ0MsZ0JBQWdCdkIsZUFBZXJOLEtBQUs2TyxRQUFRO0FBQUEsVUFDNUNDLGFBQWE5TyxLQUFLK08sWUFBWXZPLFFBQVE7QUFBQSxVQUN0Q0QsWUFBWVAsS0FBS3lILGFBQWF6SCxLQUFLZ1AsYUFBYTtBQUFBLFVBQ2hEcEQsZUFBZTVMLEtBQUs2TCxnQkFBZ0I7QUFBQSxVQUNwQ2pILFFBQVE1RSxLQUFLNEUsVUFBVTtBQUFBLFFBQ3pCO0FBQUEsTUFDRixDQUFDO0FBRURsSixxQkFBZXdFLGFBQWE7QUFBQSxJQUM5QixTQUFTMkIsT0FBTztBQUNkRixjQUFRRSxNQUFNLG1DQUFtQ0EsS0FBSztBQUN0RG5HLHFCQUFlLEVBQUU7QUFBQSxJQUNuQixVQUFDO0FBQ0NFLHdCQUFrQixLQUFLO0FBQUEsSUFDekI7QUFBQSxFQUNGO0FBR0FtRCxZQUFVLE1BQU07QUFDZCxRQUFJL0csY0FBYyxhQUFhL0YsZUFBZTtBQUM1QzZhLDRCQUFzQjtBQUFBLElBQ3hCO0FBQUEsRUFDRixHQUFHLENBQUM5VSxXQUFXL0YsYUFBYSxDQUFDO0FBRzdCLFFBQU1nZCxxQkFBcUJBLENBQUNDLFlBQVk7QUFDdENsVCx1QkFBbUJrVCxPQUFPO0FBQzFCcFQsMkJBQXVCLElBQUk7QUFBQSxFQUM3QjtBQUVBLFFBQU1xVCxpQkFBaUI7QUFBQSxJQUNyQixFQUFFMVEsS0FBSyxTQUFTQyxRQUFRLFNBQVM7QUFBQSxJQUNqQyxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRUQsS0FBSyxRQUFRQyxRQUFRLGVBQWU7QUFBQSxJQUN0QyxFQUFFRCxLQUFLLFNBQVNDLFFBQVEsZUFBZTtBQUFBLElBQ3ZDLEVBQUVELEtBQUssU0FBU0MsUUFBUSxRQUFRO0FBQUEsSUFDaEMsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLFVBQVU7QUFBQSxJQUNwQyxFQUFFRCxLQUFLLGtCQUFrQkMsUUFBUSxvQkFBb0I7QUFBQSxJQUNyRCxFQUFFRCxLQUFLLGVBQWVDLFFBQVEsZUFBZTtBQUFBLElBQzdDLEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQyxpQkFBZTBRLDhCQUE4QjtBQUMzQyxRQUFJO0FBQ0Z6ViwwQkFBb0IsSUFBSTtBQUV4QixZQUFNOEYsV0FBVyxNQUFNeFEsSUFBSXVDO0FBQUFBLFFBQ3pCLCtDQUErQ2lNLFlBQVk7QUFBQSxNQUM3RDtBQUVBLFlBQU11SixlQUFldkgsU0FBU0csTUFBTUEsTUFBTXlQLGFBQWE7QUFFdkQsWUFBTUMsbUJBQW1CdEksYUFBYTdHLElBQUksQ0FBQ2tQLFdBQVdqUCxVQUFVO0FBQzlELGNBQU1tUCxlQUFldFAsT0FBT29QLFdBQVdsTixXQUFXLENBQUM7QUFDbkQsY0FBTXFOLFlBQVl2UCxPQUFPb1AsV0FBV3hHLFFBQVEsQ0FBQztBQUM3QyxjQUFNNEcsV0FBV3hQLE9BQU9vUCxXQUFXSyxPQUFPLENBQUM7QUFDM0MsY0FBTUMsZ0JBQWdCMVAsT0FBT29QLFdBQVdPLFlBQVksQ0FBQztBQUNyRCxjQUFNQyxVQUFVUixXQUFXL1EsWUFBWTtBQUN2QyxjQUFNd1IsWUFBWVQsV0FBV2pSLGNBQWM7QUFDM0MsY0FBTTJSLGFBQWFSLGdCQUFnQjtBQUNuQyxjQUFNUyxlQUNKUixjQUFjLEtBQ2RDLFdBQVcsS0FDWEosV0FBV1YsYUFBYXNCLFdBQVcsU0FBUztBQUU5QyxjQUFNQyxVQUFVLEdBQUdiLFdBQVduTyxJQUFJLElBQUl0TixNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUs7QUFFekQsY0FBTXVjLGFBQWFkLFdBQVdlLFNBQVN4YyxNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUs7QUFFMUQsZUFBTztBQUFBLFVBQ0wwTSxJQUFJRixRQUFRO0FBQUE7QUFBQSxVQUdaaVEsU0FBU0g7QUFBQUEsVUFDVEksWUFBWUg7QUFBQUEsVUFDWkksWUFBWWhCO0FBQUFBLFVBQ1ppQixnQkFBZ0JuQixXQUFXVjtBQUFBQSxVQUMzQjhCLFFBQVFoQjtBQUFBQSxVQUNSaUIsU0FBU2xCO0FBQUFBLFVBQ1RtQixhQUFhaEI7QUFBQUEsVUFDYmlCLFlBQVlmO0FBQUFBLFVBQ1pnQixjQUFjZjtBQUFBQTtBQUFBQSxVQUlkNU8sTUFDRSx1QkFBQyxTQUFJLFdBQVUsc0NBQXNDZ1AscUJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZEO0FBQUEsVUFFL0RFLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHNDQUNaRCx3QkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFHRnhCLGFBQ0UsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLG1EQUNiVSxxQkFBV1YsZUFBZSxxQkFEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUNxQixnQkFDQyx1QkFBQyxVQUFLLFdBQVUsaUVBQWdFLG1CQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFHRix1QkFBQyxVQUFLLFdBQVUsb0VBQW1FO0FBQUE7QUFBQSxjQUMxRTVQLE1BQU0wUSxTQUFTLEVBQUVsRCxTQUFTLEdBQUcsR0FBRztBQUFBLGlCQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWNBO0FBQUEsVUFHRmlDLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHdDQUNaQSxrQkFBUXpHLGVBQWUsT0FBTyxLQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFHRjBHLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLHdDQUNaQSxvQkFBVTFHLGVBQWUsT0FBTyxLQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFHRnNHLEtBQ0UsdUJBQUMsU0FBSSxXQUFVLHdDQUF1QztBQUFBO0FBQUEsWUFDbERELFNBQVNyRyxlQUFlLE9BQU87QUFBQSxlQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFHRlAsTUFDRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVyxxQkFBcUI4RyxnQkFBZ0IsSUFBSSxxQkFBcUIsZ0JBQWdCO0FBQUEsY0FHeEZILHNCQUFZLElBQUksTUFBTUEsVUFBVXBHLGVBQWUsT0FBTyxDQUFDLEtBQUs7QUFBQTtBQUFBLFlBSi9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBO0FBQUEsVUFHRndHLFVBQ0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVcscUJBQXFCRCxnQkFBZ0IsSUFBSSxxQkFBcUIsZ0JBQWdCO0FBQUEsY0FHeEZBLDBCQUFnQixJQUNiLE1BQU1BLGNBQWN2RyxlQUFlLE9BQU8sQ0FBQyxLQUMzQztBQUFBO0FBQUEsWUFOTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLFVBR0ZqSCxTQUNFLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxjQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVyxzQkFBc0I0TixhQUFhLG1CQUFtQixlQUFlO0FBQUEsa0JBQzNFO0FBQUE7QUFBQSxvQkFFSHhGLEtBQUtDLElBQUkrRSxZQUFZLEVBQUVuRyxlQUFlLE9BQU87QUFBQTtBQUFBO0FBQUEsZ0JBSmpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FFQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLGtEQUFrRDJHLGFBQWEscUJBQXFCLGVBQWU7QUFBQSxrQkFHN0dBLHVCQUFhLFlBQVk7QUFBQTtBQUFBLGdCQUo1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGlCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBY0E7QUFBQSxZQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVyx3QkFBd0JBLGFBQWEsbUJBQW1CLGFBQWE7QUFBQTtBQUFBLGNBRGxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUVPO0FBQUEsZUFuQlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxRQUVKO0FBQUEsTUFDRixDQUFDO0FBRUQ3Uyw4QkFBd0JvUyxnQkFBZ0I7QUFBQSxJQUMxQyxTQUFTek4sT0FBTztBQUNkM0UsOEJBQXdCLEVBQUU7QUFBQSxJQUM1QixVQUFDO0FBQ0N2RCwwQkFBb0IsS0FBSztBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUVBb0YsWUFBVSxNQUFNO0FBQ2QsUUFBSXRCLGFBQWMyUiw2QkFBNEI7QUFBQSxFQUNoRCxHQUFHLENBQUMzUixZQUFZLENBQUM7QUFDakJzQixZQUFVLE1BQU07QUFDYnJCLG9CQUFnQixFQUFFLEdBQUdSLHdCQUF3QixFQUFFO0FBQUEsRUFDbEQsR0FBRyxDQUFDakwsYUFBYSxDQUFDO0FBQ2xCLFFBQU04ZSx5QkFBeUJBLENBQUNuVCxNQUFNO0FBQ3BDLFVBQU0xSCxRQUFRMEgsRUFBRUMsT0FBTzNIO0FBQ3ZCLFFBQUlBLE1BQU93SCxpQkFBZ0J4SCxLQUFLO0FBQUEsRUFDbEM7QUFFQSxRQUFNOGEsaUNBQWlDQSxDQUFDOWEsVUFBVTtBQUNoRG1FLHFCQUFpQm5FLEtBQUs7QUFDdEIsVUFBTXpDLFNBQVEsb0JBQUlDLEtBQUs7QUFDdkIsVUFBTXVkLGNBQWFBLENBQUMvUCxTQUFTQSxLQUFLdk4sWUFBWSxFQUFFdWQsTUFBTSxHQUFHLEVBQUU7QUFFM0QsUUFBSWhiLFVBQVUsVUFBVTtBQUN0QnFFLHlCQUFtQixJQUFJO0FBQ3ZCcUMsMEJBQW9CLENBQUM7QUFFckIsWUFBTXVVLGVBQWUsSUFBSXpkLEtBQUtELE9BQU11YSxZQUFZLEdBQUd2YSxPQUFNcWEsU0FBUyxHQUFHLENBQUM7QUFDdEUzVywwQkFBb0I4WixZQUFXRSxZQUFZLENBQUM7QUFDNUM5Wix3QkFBa0I0WixZQUFXeGQsTUFBSyxDQUFDO0FBQUEsSUFDckMsT0FBTztBQUNMOEcseUJBQW1CLEtBQUs7QUFDeEJxQywwQkFBb0J3VSxTQUFTbGIsS0FBSyxDQUFDO0FBQ25DaUIsMEJBQW9CLEVBQUU7QUFDdEJFLHdCQUFrQixFQUFFO0FBQUEsSUFDdEI7QUFBQSxFQUNGO0FBRUEsUUFBTWdhLFdBQVc7QUFBQSxJQUNmLEVBQUVuYixPQUFPLE9BQU9ELE9BQU8sd0JBQXdCO0FBQUEsSUFDL0MsRUFBRUMsT0FBTyxPQUFPRCxPQUFPLHdCQUF3QjtBQUFBLElBQy9DLEVBQUVDLE9BQU8sTUFBTUQsT0FBTyx1QkFBdUI7QUFBQSxJQUM3QyxFQUFFQyxPQUFPLE1BQU1ELE9BQU8sdUJBQXVCO0FBQUEsSUFDN0MsRUFBRUMsT0FBTyxVQUFVRCxPQUFPLFNBQVM7QUFBQSxFQUFDO0FBRXRDLFFBQU1xYixjQUFjO0FBQUEsSUFDbEIsRUFBRTdTLEtBQUssU0FBU0MsUUFBUSxTQUFTO0FBQUEsSUFDakMsRUFBRUQsS0FBSyxRQUFRQyxRQUFRLFVBQVU7QUFBQSxJQUNqQyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVELEtBQUssWUFBWUMsUUFBUSxXQUFXO0FBQUEsSUFDdEMsRUFBRUQsS0FBSyxlQUFlQyxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFRCxLQUFLLGtCQUFrQkMsUUFBUSxpQkFBaUI7QUFBQSxJQUNsRCxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVELEtBQUssWUFBWUMsUUFBUSxXQUFXO0FBQUEsSUFDdEMsRUFBRUQsS0FBSyxxQkFBcUJDLFFBQVEsb0JBQW9CO0FBQUEsSUFDeEQsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLFVBQVU7QUFBQSxFQUFDO0FBR3ZDLFFBQU02UyxlQUFlO0FBQUEsSUFDbkIsRUFBRTlTLEtBQUssU0FBU0MsUUFBUSxTQUFTO0FBQUEsSUFDakMsRUFBRUQsS0FBSyxTQUFTQyxRQUFRLFdBQVc7QUFBQSxJQUNuQyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVELEtBQUssWUFBWUMsUUFBUSxXQUFXO0FBQUEsSUFDdEMsRUFBRUQsS0FBSyxxQkFBcUJDLFFBQVEsVUFBVTtBQUFBLElBQzlDLEVBQUVELEtBQUssMEJBQTBCQyxRQUFRLHlCQUF5QjtBQUFBLEVBQUM7QUFHckUsUUFBTStILDJCQUEyQixPQUFPbFYsWUFBVztBQUNqRHdGLDJCQUF1QixFQUFFO0FBQ3pCL0UscUJBQWlCLEVBQUU7QUFDbkJNLGtCQUFjLENBQUM7QUFDZjhELHFCQUFpQixDQUFDO0FBQ2xCTyxzQkFBa0IsQ0FBQztBQUNuQkwsaUJBQWEsQ0FBQztBQUNkRSxtQkFBZSxDQUFDO0FBRWhCLFFBQUksQ0FBQ2pGLFFBQVE7QUFHYixVQUFNaWdCLG1CQUFtQjlkLEtBQUsrZCxJQUFJO0FBQ2xDaEwsNkJBQXlCaUwsZ0JBQWdCRjtBQUV6QyxRQUFJO0FBQ0YsWUFBTS9SLFdBQVcsTUFBTXhRLElBQUl1QyxJQUFJLHlDQUF5Q0QsT0FBTSxFQUFFO0FBQ2hGd0YsNkJBQXVCMEksVUFBVUcsTUFBTUEsSUFBSTtBQUczQyxVQUFJLENBQUNILFVBQVVHLE1BQU1BLE1BQU1OLE9BQVE7QUFJbkMsWUFBTVksZ0JBQWdCVCxVQUFVRyxNQUFNQSxNQUNsQ08sSUFBSSxDQUFDUCxNQUFNUSxVQUFVO0FBR3JCLGVBQU87QUFBQSxVQUNMRSxJQUFJRixRQUFRO0FBQUEsVUFDWmpPLE9BQU95TixNQUFNMUIsVUFBVXFDLGNBQWM7QUFBQSxVQUNyQ3pMLFFBQVE4SyxNQUFNMEQsV0FBVztBQUFBLFVBQ3pCcU8sYUFBYS9SLE1BQU1nUztBQUFBQSxVQUNuQkMsUUFBUWpTLE1BQU1rUztBQUFBQSxVQUNkQyxnQkFBZ0JuUyxNQUFNZ1M7QUFBQUEsVUFDdEJJLFNBQVNwUyxNQUFNcVM7QUFBQUEsVUFDZm5KLFNBQVNsSixNQUFNc1M7QUFBQUEsVUFDZkMsWUFBWXZTLE1BQU13UztBQUFBQSxVQUNsQmpRLFNBQVN2QyxNQUFNeVM7QUFBQUEsVUFDZkMsZUFBZTFTLE1BQU0wUyxpQkFBaUI7QUFBQSxVQUN0Q0MsZUFBZTNTLE1BQU00UyxnQkFBZ0JoUyxRQUFRO0FBQUEsVUFDN0NpUyxtQkFBbUI3UyxNQUFNNlMscUJBQXFCO0FBQUEsVUFDOUNDLGlCQUFpQjlTLE1BQU04UyxtQkFBbUI7QUFBQSxVQUMxQ0MsZ0JBQWdCO0FBQUEsVUFDaEJDLGdCQUNFaFQsTUFBTTFLLFdBQVd0QixNQUFNLEdBQUcsSUFBSSxDQUFDLEtBQUs7QUFBQSxVQUN0Q2lmLFVBQVVqVCxNQUFNa1QsWUFBWSxXQUFXO0FBQUEsUUFDekM7QUFBQSxNQUNGLENBQUMsRUFDQTFMLE9BQU8yTCxPQUFPO0FBR2pCL2dCLHVCQUFpQmtPLGFBQWE7QUFHOUI5SjtBQUFBQSxRQUNFOEosY0FBY0osT0FBTyxDQUFDQyxLQUFLaVQsUUFBUWpULE1BQU1pVCxJQUFJckIsYUFBYSxDQUFDO0FBQUEsTUFDN0Q7QUFFQWhiO0FBQUFBLFFBQ0V1SixjQUFjSixPQUFPLENBQUNDLEtBQUtpVCxRQUFRalQsTUFBTWlULElBQUlqQixnQkFBZ0IsQ0FBQztBQUFBLE1BQ2hFO0FBRUF6YixtQkFBYTRKLGNBQWNKLE9BQU8sQ0FBQ0MsS0FBS2lULFFBQVFqVCxNQUFNaVQsSUFBSWIsWUFBWSxDQUFDLENBQUM7QUFFeEUzYixxQkFBZTBKLGNBQWNKLE9BQU8sQ0FBQ0MsS0FBS2lULFFBQVFqVCxNQUFNaVQsSUFBSW5CLFFBQVEsQ0FBQyxDQUFDO0FBQUEsSUFDeEUsU0FBU2hRLE9BQU87QUFDZEYsY0FBUUUsTUFBTSxtQ0FBbUNBLEtBQUs7QUFBQSxJQUN4RDtBQUFBLEVBQ0Y7QUFFQTlDLFlBQVUsTUFBTTtBQUNkLFFBQUl4TixRQUFRO0FBQ1ZrViwrQkFBeUJsVixNQUFNO0FBQUEsSUFDakM7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUNMLFFBQU0waEIsaUJBQWlCO0FBQUEsSUFDckIsRUFBRXhVLEtBQUssTUFBTUMsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxtQkFBbUJDLFFBQVEsa0JBQWtCO0FBQUEsSUFDcEQsRUFBRUQsS0FBSyxrQkFBa0JDLFFBQVEsaUJBQWlCO0FBQUEsSUFDbEQsRUFBRUQsS0FBSyxTQUFTQyxRQUFRLGFBQWE7QUFBQSxJQUNyQyxFQUFFRCxLQUFLLGtCQUFrQkMsUUFBUSxrQkFBa0I7QUFBQSxJQUNuRCxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVELEtBQUssaUJBQWlCQyxRQUFRLGdCQUFnQjtBQUFBLElBQ2hELEVBQUVELEtBQUssaUJBQWlCQyxRQUFRLGNBQWM7QUFBQSxJQUM5QyxFQUFFRCxLQUFLLHFCQUFxQkMsUUFBUSxvQkFBb0I7QUFBQSxJQUN4RCxFQUFFRCxLQUFLLFlBQVlDLFFBQVEsWUFBWTtBQUFBO0FBQUEsSUFFdkMsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsY0FBYztBQUFBLElBQzNDLEVBQUVELEtBQUssV0FBV0MsUUFBUSxXQUFXO0FBQUEsSUFDckMsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLFVBQVU7QUFBQSxJQUNwQyxFQUFFRCxLQUFLLGtCQUFrQkMsUUFBUSxpQkFBaUI7QUFBQSxJQUNsRCxFQUFFRCxLQUFLLFdBQVdDLFFBQVEsVUFBVTtBQUFBLEVBQUM7QUFHdkMsUUFBTTJELGdCQUFnQkEsQ0FBQ2lMLGVBQWU7QUFDcEMsVUFBTXBNLE9BQU8sSUFBSXhOLEtBQUs0WixVQUFVO0FBQ2hDLFdBQU9wTSxLQUFLdk4sWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFDeEM7QUFFQW1MLFlBQVUsTUFBTTtBQUNkLFVBQU1tVSxjQUFjLFlBQVk7QUFDOUIxZ0Isc0JBQWdCLEVBQUU7QUFDbEJnQyxzQkFBZ0IsSUFBSTtBQUVwQixVQUFJO0FBQ0Y1QyxxQkFBYSxJQUFJO0FBQ2pCLGNBQU02TixXQUFXLE1BQU14USxJQUFJdUM7QUFBQUEsVUFDekIscUNBQXFDbUQsY0FBY0UsT0FBTyxXQUFXRixjQUFjRyxNQUFNLFlBQVk3QyxhQUFhO0FBQUEsUUFDcEg7QUFFQTBQLGdCQUFRa0YsS0FBS3BILFVBQVUsb0JBQW9CO0FBRTNDLFlBQUlBLFNBQVNHLFFBQVFILFNBQVNHLEtBQUtOLFNBQVMsR0FBRztBQUM3QzFNLDJCQUFpQjZNLFNBQVNHLElBQUk7QUFFOUIsZ0JBQU11VCxPQUFPMVQsU0FBU0c7QUFDdEI5TSx1QkFBYXFnQixLQUFLLENBQUMsRUFBRWxSLGVBQWU7QUFFcEMsZ0JBQU1tUixXQUFXM1QsU0FBU0c7QUFDMUI1TSwyQkFBaUJvZ0IsU0FBUyxDQUFDLEVBQUVsUixtQkFBbUI7QUFFaEQsY0FBSUMsVUFBVTtBQUNkLGdCQUFNakMsZ0JBQWdCVCxTQUFTRyxLQUFLTyxJQUFJLENBQUNoTyxRQUFPaU8sVUFBVTtBQUN4RCtCLHVCQUFXbEMsT0FBTzlOLE9BQU04QyxNQUFNO0FBQzlCLG1CQUFPO0FBQUEsY0FDTG9MLEtBQUtsTyxPQUFNa087QUFBQUEsY0FDWEMsSUFBSUYsUUFBUTtBQUFBLGNBQ1pjLE1BQU1tQixjQUFjbFEsUUFBT2tNLFFBQVE7QUFBQSxjQUNuQ3BKLFFBQVE5QyxPQUFNOEM7QUFBQUEsY0FDZCtMLFNBQVM3TyxPQUFNaU07QUFBQUEsY0FDZmtFLGFBQWFuUSxPQUFNOE87QUFBQUEsY0FDbkJzQixNQUFNcFEsT0FBTW1NO0FBQUFBLGNBQ1o2RDtBQUFBQSxZQUNGO0FBQUEsVUFDRixDQUFDO0FBQ0RqQyx3QkFBYzBDLEtBQUs7QUFBQSxZQUNqQnRDLElBQUk7QUFBQSxZQUNKWSxNQUFNO0FBQUEsWUFDTmpNLFFBQVE7QUFBQSxZQUNSK0wsU0FBUztBQUFBLFlBQ1RzQixhQUFhO0FBQUEsWUFDYkMsTUFBTTtBQUFBLFlBQ05KO0FBQUFBLFVBQ0YsQ0FBQztBQUVEM1AsMEJBQWdCME4sYUFBYTtBQUFBLFFBQy9CLE9BQU87QUFDTHROLDJCQUFpQixFQUFFO0FBQ25CSiwwQkFBZ0IsRUFBRTtBQUFBLFFBQ3BCO0FBQUEsTUFDRixTQUFTcVAsT0FBTztBQUNkRixnQkFBUUUsTUFBTSxtQ0FBbUNBLEtBQUs7QUFDdERqUCx5QkFBaUIsRUFBRTtBQUNuQkosd0JBQWdCLEVBQUU7QUFBQSxNQUNwQixVQUFDO0FBQ0NnQyx3QkFBZ0IsS0FBSztBQUNyQjVDLHFCQUFhLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFDQSxRQUFJK0MsY0FBY0UsWUFBWSxVQUFVRixjQUFjRSxZQUFZO0FBQ2hFcWUsa0JBQVk7QUFBQSxFQUNoQixHQUFHLENBQUNqaEIsZUFBZTBDLGNBQWNFLFNBQVNGLGNBQWNHLE1BQU0sQ0FBQztBQUUvRCxRQUFNdWUsZUFBZTtBQUFBLElBQ25CLEVBQUU1VSxLQUFLLE1BQU1DLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVELEtBQUssUUFBUUMsUUFBUSxPQUFPO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFRCxLQUFLLFdBQVdDLFFBQVEsYUFBYTtBQUFBLElBQ3ZDLEVBQUVELEtBQUssZUFBZUMsUUFBUSxpQkFBaUI7QUFBQSxJQUMvQyxFQUFFRCxLQUFLLFFBQVFDLFFBQVEsZUFBZTtBQUFBLElBQ3RDLEVBQUVELEtBQUssV0FBV0MsUUFBUSxVQUFVO0FBQUEsRUFBQztBQUd2QyxRQUFNNFUsa0NBQWtDO0FBQUEsSUFDdEMsRUFBRTdVLEtBQUssTUFBTUMsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxRQUFRQyxRQUFRLE9BQU87QUFBQSxJQUM5QixFQUFFRCxLQUFLLGVBQWVDLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUVELEtBQUssYUFBYUMsUUFBUSxhQUFhO0FBQUEsSUFDekMsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLGVBQWU7QUFBQSxJQUN6QyxFQUFFRCxLQUFLLE9BQU9DLFFBQVEsYUFBYTtBQUFBO0FBQUEsSUFFbkMsRUFBRUQsS0FBSyxRQUFRQyxRQUFRLGdCQUFnQjtBQUFBLElBQ3ZDLEVBQUVELEtBQUssWUFBWUMsUUFBUSxlQUFlO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLFVBQVU7QUFBQSxFQUFDO0FBRXZDLFFBQU02VSx5Q0FBeUM7QUFBQSxJQUM3QyxFQUFFOVUsS0FBSyxNQUFNQyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFRCxLQUFLLFdBQVdDLFFBQVEsT0FBTztBQUFBLElBQ2pDLEVBQUVELEtBQUssa0JBQWtCQyxRQUFRLGNBQWM7QUFBQSxJQUMvQyxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxhQUFhO0FBQUEsSUFDNUMsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGVBQWU7QUFBQSxJQUM1QyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsYUFBYTtBQUFBO0FBQUEsSUFFdEMsRUFBRUQsS0FBSyxXQUFXQyxRQUFRLGNBQWM7QUFBQSxJQUN4QyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsVUFBVTtBQUFBLEVBQUM7QUFHMUMsUUFBTXVTLGFBQWFBLENBQUMzRCxlQUFlO0FBQ2pDLFVBQU1rRyxRQUFRbEcsV0FBVzFaLE1BQU0sR0FBRztBQUNsQyxRQUFJNGYsTUFBTWxVLFdBQVcsR0FBRztBQUN0QixhQUFPLEdBQUdrVSxNQUFNLENBQUMsQ0FBQyxJQUFJQSxNQUFNLENBQUMsQ0FBQyxJQUFJQSxNQUFNLENBQUMsQ0FBQztBQUFBLElBQzVDO0FBQ0EsV0FBT2xHO0FBQUFBLEVBQ1Q7QUFDQSxRQUFNbUcsb0JBQW9CeEMsV0FBVzFkLFFBQVE7QUFDN0MsUUFBTW1nQixrQkFBa0J6QyxXQUFXcGQsTUFBTTtBQUV6Q2tMLFlBQVUsTUFBTTtBQUNkLFVBQU1tVSxjQUFjLFlBQVk7QUFDOUIsVUFBSTtBQUNGLGNBQU16VCxXQUFXLE1BQU14USxJQUFJdUM7QUFBQUEsVUFDekIsdUNBQXVDUyxhQUFhLGFBQWF3aEIsaUJBQWlCLFdBQVdDLGVBQWU7QUFBQSxRQUM5RztBQUNBLFlBQUlqVSxTQUFTRyxRQUFRSCxTQUFTRyxLQUFLTixTQUFTLEdBQUc7QUFDN0MxTSwyQkFBaUI2TSxTQUFTRyxJQUFJO0FBRTlCLGdCQUFNdVQsT0FBTzFULFNBQVNHO0FBQ3RCMUwsMkJBQWlCaWYsS0FBSyxDQUFDLEVBQUVsUixtQkFBbUIsQ0FBQztBQUU3QyxnQkFBTW1SLFdBQVczVCxTQUFTRztBQUMxQnhMLCtCQUFxQmdmLFNBQVMsQ0FBQyxFQUFFbFIsbUJBQW1CO0FBRXBELGdCQUFNbk8sZUFBYzBMLFNBQVNHLEtBQUtFO0FBQUFBLFlBQ2hDLENBQUNDLEtBQUs1TixXQUFVNE4sTUFBTXFSLFNBQVNqZixPQUFNOEMsTUFBTTtBQUFBLFlBQzNDO0FBQUEsVUFDRjtBQUNBakIseUJBQWVELFlBQVc7QUFDMUIsZ0JBQU1tTSxnQkFBZ0JULFNBQVNHLEtBQUtPLElBQUksQ0FBQ2hPLFFBQU9pTyxXQUFXO0FBQUEsWUFDekRFLElBQUlGLFFBQVE7QUFBQSxZQUNaSSxNQUFNck8sUUFBT3dWLE1BQU1sSDtBQUFBQSxZQUNuQkUsY0FBY3hPLFFBQU93VixNQUFNaEg7QUFBQUEsWUFDM0I3TCxRQUFRM0MsT0FBTTJDO0FBQUFBLFlBQ2Q2ZSxtQkFDRXZDLFNBQVNqZixPQUFNQSxNQUFNeWhCLGFBQWEsSUFBSXpoQixPQUFNK1A7QUFBQUEsWUFDOUMyUixhQUFhMWhCLE9BQU0yaEI7QUFBQUEsWUFDbkJDLGdCQUNFM0MsU0FBU2pmLE9BQU1BLE1BQU15aEIsYUFBYSxJQUNsQ3poQixPQUFNK1Asc0JBQ04vUCxPQUFNMmhCO0FBQUFBLFVBQ1YsRUFBRTtBQUNGcGhCLDhCQUFvQndOLGFBQWE7QUFBQSxRQUNuQyxPQUFPO0FBQ0x0TiwyQkFBaUIsRUFBRTtBQUNuQm9CLHlCQUFlLENBQUM7QUFBQSxRQUNsQjtBQUFBLE1BQ0YsU0FBUzZOLE9BQU87QUFDZEYsZ0JBQVFFLE1BQU0sbUNBQW1DQSxLQUFLO0FBQ3REalAseUJBQWlCLEVBQUU7QUFDbkJvQix1QkFBZSxDQUFDO0FBQUEsTUFDbEI7QUFBQSxJQUNGO0FBQ0FrZixnQkFBWTtBQUFBLEVBQ2QsR0FBRyxDQUFDamhCLGVBQWV3aEIsbUJBQW1CQyxlQUFlLENBQUM7QUFFdEQzVSxZQUFVLE1BQU07QUFDZCxRQUFJL0gsYUFBYWdILFNBQVNnVyxZQUFZO0FBQ3BDLFlBQU0zaEIsY0FBYzJFLFVBQVVpZCxjQUFjLElBQUssT0FBTztBQUN4RCxZQUFNQyxjQUNIbGQsVUFBVWlkLGVBQWUsTUFBTWpXLFNBQVNnVyxjQUFjO0FBQ3pELFlBQU1HLFlBQVluVyxTQUFTZ1csY0FBYyxLQUFLM2hCO0FBQzlDLFlBQU0raEIsZ0JBQWdCcGQsVUFBVXFkLGdCQUM1QkYsV0FBV25kLFVBQVVxZCxnQkFDckI7QUFDSixZQUFNQyxXQUFXdGQsVUFBVTRjLGlCQUFpQixLQUFLUTtBQUNqRG5XLGtCQUFZLENBQUNzVyxjQUFjO0FBQUEsUUFDekIsR0FBR0E7QUFBQUEsUUFDSHJXLFVBQVVsSCxVQUFVcUo7QUFBQUEsUUFDcEJoTztBQUFBQSxRQUNBNmhCO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FFO0FBQUFBLE1BQ0YsRUFBRTtBQUFBLElBQ0o7QUFBQSxFQUNGLEdBQUcsQ0FBQ3RkLFdBQVdnSCxTQUFTZ1csVUFBVSxDQUFDO0FBRW5DalYsWUFBVSxNQUFNO0FBQ2QsUUFBSTlNLGVBQWU7QUFDakJoRCxVQUNHdWxCLEtBQUssNEJBQTRCdmlCLGFBQWEsRUFBRSxFQUNoRHdpQixLQUFLLENBQUNoVixhQUFhO0FBQ2xCNUgsNEJBQW9CNEgsU0FBU0csS0FBS2hJLG9CQUFvQixFQUFFO0FBQUEsTUFDMUQsQ0FBQyxFQUNBOGMsTUFBTSxDQUFDN1MsVUFBVTtBQUNoQkYsZ0JBQVFFLE1BQU0scUNBQXFDQSxLQUFLO0FBQUEsTUFDMUQsQ0FBQztBQUFBLElBQ0wsT0FBTztBQUNMaEssMEJBQW9CLEVBQUU7QUFBQSxJQUN4QjtBQUFBLEVBQ0YsR0FBRyxDQUFDNUYsYUFBYSxDQUFDO0FBQ2xCLE1BQUk2RjtBQUNGLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLGlCQUNiLGlDQUFDLGtCQUFlLE9BQU0sb0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0MsS0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBR0osU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFNBQUksV0FBVSx1Q0FDYixpQ0FBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBLFlBQVk7QUFBQTtBQUFBLFFBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRW1CO0FBQUEsTUFFbkIsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLGtDQUFpQyxrQ0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxRQUNiLGlDQUFDLFNBQUksV0FBVSxnSEFDYixpQ0FBQyxTQUFJLFdBQVUsUUFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVM7QUFBQSxnQkFBSztBQUFBO0FBQUEsY0FGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsSUFBRztBQUFBLGdCQUNILE9BQU9sQiwwQkFBMEIrZDtBQUFBQSxnQkFDakMsVUFBVW5PO0FBQUFBLGdCQUNWO0FBQUEsZ0JBQ0EsdUJBQXVCO0FBQUEsZ0JBQ3ZCLGFBQVk7QUFBQSxnQkFDWixjQUFjLENBQUNvTyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmhFLFNBQVMsRUFDVGlFLFlBQVksRUFDWkMsU0FBU0osTUFBTUcsWUFBWSxDQUFDO0FBQUEsZ0JBRWpDLE9BQU8sRUFBRUUsUUFBUSxRQUFRQyxPQUFPLFFBQVE7QUFBQSxnQkFFdkN6akIsaUJBQU8wTztBQUFBQSxrQkFBSSxDQUFDaE8sV0FDWCx1QkFBQyxZQUF1QixPQUFPQSxPQUFNa08sS0FDbENsTztBQUFBQSwyQkFBTXNPO0FBQUFBLG9CQUFVO0FBQUEsb0JBQUl0TyxPQUFNd087QUFBQUEsdUJBRGhCeE8sT0FBTWtPLEtBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDRDtBQUFBO0FBQUEsY0FuQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBb0JBO0FBQUEsZUEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0QkEsS0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE4QkEsS0EvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQ0E7QUFBQSxVQUVDcE8saUJBQ0MsbUNBQ0UsaUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMEtBQ1o7QUFBQSxjQUNDO0FBQUEsZ0JBQ0VxTyxJQUFJO0FBQUEsZ0JBQ0pySyxPQUFPO0FBQUEsZ0JBQ1BrZixNQUFNLHVCQUFDLFVBQU8sTUFBTSxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlCO0FBQUEsY0FDekI7QUFBQSxjQUNBO0FBQUEsZ0JBQ0U3VSxJQUFJO0FBQUEsZ0JBQ0pySyxPQUFPO0FBQUEsZ0JBQ1BrZixNQUFNLHVCQUFDLGdCQUFhLE1BQU0sTUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUI7QUFBQSxjQUMvQjtBQUFBLGNBQ0E7QUFBQSxnQkFDRTdVLElBQUk7QUFBQSxnQkFDSnJLLE9BQU87QUFBQSxnQkFDUGtmLE1BQU0sdUJBQUMsY0FBVyxNQUFNLE1BQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFCO0FBQUEsY0FDN0I7QUFBQSxjQUNBO0FBQUEsZ0JBQ0U3VSxJQUFJO0FBQUEsZ0JBQ0pySyxPQUFPO0FBQUEsZ0JBQ1BrZixNQUFNLHVCQUFDLGNBQVcsTUFBTSxNQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxQjtBQUFBLGNBQzdCO0FBQUEsY0FDQTtBQUFBLGdCQUNFN1UsSUFBSTtBQUFBLGdCQUNKckssT0FBTztBQUFBLGdCQUNQa2YsTUFBTSx1QkFBQyxZQUFTLE1BQU0sTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUI7QUFBQSxjQUMzQjtBQUFBLGNBQ0E7QUFBQSxnQkFDRTdVLElBQUk7QUFBQSxnQkFDSnJLLE9BQU87QUFBQSxnQkFDUGtmLE1BQU0sdUJBQUMsZ0JBQWEsTUFBTSxNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1QjtBQUFBLGNBQy9CO0FBQUEsY0FDQTtBQUFBLGdCQUNFN1UsSUFBSTtBQUFBLGdCQUNKckssT0FBTztBQUFBLGdCQUNQa2YsTUFBTSx1QkFBQyxlQUFZLE1BQU0sTUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0I7QUFBQSxjQUM5QjtBQUFBLGNBQ0E7QUFBQSxnQkFDRTdVLElBQUk7QUFBQSxnQkFDSnJLLE9BQU87QUFBQSxnQkFDUGtmLE1BQU0sdUJBQUMsdUJBQW9CLE1BQU0sTUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEI7QUFBQSxjQUN0QztBQUFBLGNBRUE7QUFBQSxnQkFDRTdVLElBQUk7QUFBQSxnQkFDSnJLLE9BQU87QUFBQSxnQkFDUGtmLE1BQU0sdUJBQUMsV0FBUSxNQUFNLE1BQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0I7QUFBQSxjQUMxQjtBQUFBLGNBQ0E7QUFBQSxnQkFDRTdVLElBQUk7QUFBQSxnQkFDSnJLLE9BQU87QUFBQSxnQkFDUGtmLE1BQU0sdUJBQUMsWUFBUyxNQUFNLE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1CO0FBQUEsY0FDM0I7QUFBQSxZQUFDLEVBQ0RoVjtBQUFBQSxjQUFJLENBQUNwQyxRQUNMO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUVDLFNBQVMsTUFBTUQsZ0JBQWdCQyxJQUFJdUMsRUFBRTtBQUFBLGtCQUNyQyxXQUFXLGtJQUFrSXRJLGNBQWMrRixJQUFJdUMsS0FDM0osMkRBQ0EsdURBQXVEO0FBQUEsa0JBRzNEO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVyxHQUFHdEksY0FBYytGLElBQUl1QyxLQUFLLGtCQUFrQixnQkFBZ0I7QUFBQSx3QkFFdEV2QyxjQUFJb1g7QUFBQUE7QUFBQUEsc0JBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUlBO0FBQUEsb0JBQ0NwWCxJQUFJOUg7QUFBQUE7QUFBQUE7QUFBQUEsZ0JBWkE4SCxJQUFJdUM7QUFBQUEsZ0JBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWNBO0FBQUEsWUFDRCxLQXJFSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXNFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUNQbFI7QUFBQUEsa0JBQ0UrQztBQUFBQSxrQkFDQUo7QUFBQUEsa0JBQ0FxSDtBQUFBQSxrQkFDQUU7QUFBQUEsa0JBQ0E7QUFBQSxvQkFDRW5EO0FBQUFBLG9CQUNBSTtBQUFBQSxvQkFDQUc7QUFBQUEsb0JBQ0FMO0FBQUFBLGtCQUNGO0FBQUEsa0JBQ0E5RDtBQUFBQSxrQkFDQVU7QUFBQUEsZ0JBQ0Y7QUFBQSxnQkFFRixXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxnQkFBYSxNQUFNLE1BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVCO0FBQUEsa0JBQUc7QUFBQTtBQUFBO0FBQUEsY0FuQjVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXFCQSxLQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVCQTtBQUFBLFlBRUMrRSxjQUFjLGtCQUNiLG1DQUNHM0QsMkJBQ0MsdUJBQUMsT0FBRSwwQkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFhLElBRWIsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBLHlDQUFDLFVBQUssV0FBVSw4REFDZCxpQ0FBQyxZQUFTLFdBQVUsYUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkIsS0FEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxhQUFZO0FBQUEsc0JBQ1osV0FBVTtBQUFBLHNCQUdWLE9BQU82RDtBQUFBQSxzQkFDUCxVQUFVLENBQUMwRixNQUNUekYsY0FBY3lGLEVBQUVDLE9BQU8zSCxLQUFLO0FBQUE7QUFBQSxvQkFSaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVNHO0FBQUEscUJBYkw7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFlQTtBQUFBLGdCQUVDZ0MsZUFDRSxNQUFNO0FBQ0wsd0JBQU1rZCxlQUFlO0FBQUEsb0JBQ25CLEVBQUUzVyxLQUFLLFFBQVF2SSxPQUFPL0QsTUFBTXNPLFVBQVU7QUFBQSxvQkFDdEMsRUFBRWhDLEtBQUssU0FBU3ZJLE9BQU8vRCxNQUFNc2MsTUFBTTtBQUFBLG9CQUNuQyxFQUFFaFEsS0FBSyxTQUFTdkksT0FBTy9ELE1BQU13TyxhQUFhO0FBQUEsb0JBQzFDO0FBQUEsc0JBQ0VsQyxLQUFLO0FBQUEsc0JBQ0x2SSxPQUFPL0QsTUFBTWtqQjtBQUFBQSxvQkFDZjtBQUFBLG9CQUNBLEVBQUU1VyxLQUFLLFdBQVd2SSxPQUFPL0QsTUFBTW1qQixRQUFRO0FBQUEsb0JBQ3ZDLEVBQUU3VyxLQUFLLFdBQVd2SSxPQUFPL0QsTUFBTW9qQixVQUFVO0FBQUEsb0JBQ3pDLEVBQUU5VyxLQUFLLE9BQU92SSxPQUFPL0QsTUFBTXFqQixPQUFPO0FBQUEsb0JBQ2xDLEVBQUUvVyxLQUFLLFdBQVd2SSxPQUFPL0QsTUFBTXNqQixRQUFRO0FBQUEsb0JBQ3ZDO0FBQUEsc0JBQ0VoWCxLQUFLO0FBQUEsc0JBQ0x2SSxPQUFPL0QsTUFBTXVqQjtBQUFBQSxvQkFDZjtBQUFBLG9CQUNBO0FBQUEsc0JBQ0VqWCxLQUFLO0FBQUEsc0JBQ0x2SSxPQUFPL0QsTUFBTXdqQjtBQUFBQSxvQkFDZjtBQUFBLG9CQUNBO0FBQUEsc0JBQ0VsWCxLQUFLO0FBQUEsc0JBQ0x2SSxPQUFPL0QsTUFBTXlqQjtBQUFBQSxvQkFDZjtBQUFBLG9CQUNBO0FBQUEsc0JBQ0VuWCxLQUFLO0FBQUEsc0JBQ0x2SSxPQUFPL0QsTUFBTTBqQjtBQUFBQSxvQkFDZjtBQUFBLGtCQUFDO0FBR0gsd0JBQU1DLE9BQU8sSUFBSXZsQixLQUFLNmtCLGNBQWM7QUFBQSxvQkFDbENXLE1BQU0sQ0FBQyxPQUFPLE9BQU87QUFBQSxvQkFDckJDLFdBQVc7QUFBQTtBQUFBLGtCQUNiLENBQUM7QUFFRCx3QkFBTUMsVUFBVUgsS0FBS0ksT0FBT2hlLFVBQVU7QUFFdEMseUJBQ0UsdUJBQUMsU0FBSSxXQUFVLGlEQUNaK2Qsa0JBQVEzVyxTQUFTLElBQ2hCMlcsUUFBUTlWO0FBQUFBLG9CQUFJLENBQUMsRUFBRUgsS0FBSyxNQUNsQjtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFFQyxXQUFVO0FBQUEsd0JBRVY7QUFBQSxpREFBQyxZQUFRQSxlQUFLdkIsT0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFrQjtBQUFBLDBCQUFTO0FBQUEsMEJBQUc7QUFBQSwwQkFDN0J1QixLQUFLOUosU0FBUztBQUFBO0FBQUE7QUFBQSxzQkFKVjhKLEtBQUt2QjtBQUFBQSxzQkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1BO0FBQUEsa0JBQ0QsSUFFRCx1QkFBQyxPQUFFLG1DQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNCLEtBWjFCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBY0E7QUFBQSxnQkFFSixHQUFHO0FBQUEsbUJBMUVQO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMkVBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsUUFFYjtBQUFBLHVDQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFNBQVMsTUFDUHJKLGVBQWUsQ0FBQytnQixVQUFVO0FBQUEsd0JBQ3hCLEdBQUdBO0FBQUFBLHdCQUNIOWdCLE1BQU0sQ0FBQzhnQixLQUFLOWdCO0FBQUFBLHNCQUNkLEVBQUU7QUFBQSxzQkFFSixXQUFXO0FBQUEsVUFDbkNGLFlBQVlFLE9BQ2tCLHNFQUNBLGlHQUFpRztBQUFBO0FBQUEsc0JBSXRHRixzQkFBWUUsT0FDVCxzQkFDQTtBQUFBO0FBQUEsb0JBaEJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFpQkE7QUFBQSxrQkFFQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxTQUFTLE1BQ1BELGVBQWUsQ0FBQytnQixVQUFVO0FBQUEsd0JBQ3hCLEdBQUdBO0FBQUFBLHdCQUNIN2dCLE1BQU0sQ0FBQzZnQixLQUFLN2dCO0FBQUFBLHNCQUNkLEVBQUU7QUFBQSxzQkFFSixXQUFXO0FBQUEsVUFDbkNILFlBQVlHLE9BQ2tCLHNFQUNBLGlHQUFpRztBQUFBO0FBQUEsc0JBSXRHSCxzQkFBWUcsT0FDVCx3QkFDQTtBQUFBO0FBQUEsb0JBaEJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFpQkE7QUFBQSxrQkFFQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxTQUFTLE1BQ1BGLGVBQWUsQ0FBQytnQixVQUFVO0FBQUEsd0JBQ3hCLEdBQUdBO0FBQUFBLHdCQUNINWdCLE1BQU0sQ0FBQzRnQixLQUFLNWdCO0FBQUFBLHNCQUNkLEVBQUU7QUFBQSxzQkFFSixXQUFXO0FBQUEsVUFDbkNKLFlBQVlJLE9BQ2tCLHNFQUNBLGlHQUFpRztBQUFBO0FBQUEsc0JBSXRHSixzQkFBWUksT0FDVCx5QkFDQTtBQUFBO0FBQUEsb0JBaEJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFpQkE7QUFBQSxrQkFFQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxTQUFTLE1BQ1BILGVBQWUsQ0FBQytnQixVQUFVO0FBQUEsd0JBQ3hCLEdBQUdBO0FBQUFBLHdCQUNIM2dCLE1BQU0sQ0FBQzJnQixLQUFLM2dCO0FBQUFBLHNCQUNkLEVBQUU7QUFBQSxzQkFFSixXQUFXO0FBQUEsVUFDbkNMLFlBQVlLLE9BQ2tCLHNFQUNBLGlHQUFpRztBQUFBO0FBQUEsc0JBSXRHTCxzQkFBWUssT0FDVCw0Q0FDQTtBQUFBO0FBQUEsb0JBaEJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFpQkE7QUFBQSxxQkEzRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE0RUE7QUFBQSxnQkFHQ0wsWUFBWUUsUUFDWCx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsOEJBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUFNO0FBQUEsd0JBQ04sT0FBT2xELE1BQU1zTztBQUFBQTtBQUFBQSxzQkFGZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBRXlCO0FBQUEsb0JBRXpCLHVCQUFDLFNBQU0sT0FBTSxTQUFRLE9BQU90TyxNQUFNc2MsU0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBd0M7QUFBQSx1QkFMMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE9BQU07QUFBQSx3QkFDTixPQUFPdGMsTUFBTXdPO0FBQUFBO0FBQUFBLHNCQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFFNEI7QUFBQSxvQkFFNUI7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsT0FBTTtBQUFBLHdCQUNOLE9BQU94TyxNQUFNb2pCO0FBQUFBO0FBQUFBLHNCQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFFeUI7QUFBQSx1QkFQM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFTQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE9BQU07QUFBQSx3QkFDTixPQUFPcGpCLE1BQU1xakI7QUFBQUE7QUFBQUEsc0JBRmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUVzQjtBQUFBLG9CQUV0QjtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUFNO0FBQUEsd0JBQ04sT0FBT3JqQixNQUFNc2pCO0FBQUFBO0FBQUFBLHNCQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFFdUI7QUFBQSx1QkFQekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFTQTtBQUFBLHFCQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTRCQTtBQUFBLGdCQUlEdGdCLFlBQVlHLFFBQ1gsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsT0FBTTtBQUFBLHdCQUNOLE9BQU9uRCxNQUFNbWpCO0FBQUFBO0FBQUFBLHNCQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFFdUI7QUFBQSxvQkFFdkI7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsT0FBTTtBQUFBLHdCQUNOLE9BQU9uakIsTUFBTWlrQjtBQUFBQTtBQUFBQSxzQkFGZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBRXNCO0FBQUEsdUJBUHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBU0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsOEJBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUFNO0FBQUEsd0JBQ04sT0FDRWprQixNQUFNa2tCLGNBQ0YsSUFBSTNpQixLQUFLdkIsTUFBTWtrQixXQUFXLEVBQ3pCMWlCLFlBQVksRUFDWkMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUNiO0FBQUE7QUFBQSxzQkFQUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBUUc7QUFBQSxvQkFFSDtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUFNO0FBQUEsd0JBQ04sT0FBT3pCLE9BQU9ta0IsaUJBQWlCQztBQUFBQTtBQUFBQSxzQkFGakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUU0QztBQUFBLHVCQWI5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWVBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsT0FBTTtBQUFBLHdCQUNOLE9BQU9wa0IsTUFBTXFrQjtBQUFBQTtBQUFBQSxzQkFGZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBRThCO0FBQUEsb0JBRTlCO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE9BQU07QUFBQSx3QkFDTixPQUFPcmtCLE1BQU11akI7QUFBQUE7QUFBQUEsc0JBRmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUUyQjtBQUFBLHVCQVA3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVNBO0FBQUEscUJBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBcUNBO0FBQUEsZ0JBSUR2Z0IsWUFBWUksUUFDWCx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsOEJBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUFNO0FBQUEsd0JBQ04sT0FBT3BELE1BQU1za0I7QUFBQUE7QUFBQUEsc0JBRmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUUyQjtBQUFBLG9CQUUzQjtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUFNO0FBQUEsd0JBQ04sT0FBT3RrQixNQUFNdWtCO0FBQUFBO0FBQUFBLHNCQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFFdUI7QUFBQSx1QkFQekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFTQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBLDJDQUFDLFNBQU0sT0FBTSxTQUFRLE9BQU92a0IsTUFBTXdrQixTQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF3QztBQUFBLG9CQUN4QztBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUFNO0FBQUEsd0JBQ04sT0FBT3hrQixNQUFNeWtCO0FBQUFBO0FBQUFBLHNCQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFFd0I7QUFBQSx1QkFKMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBLDJDQUFDLFNBQU0sT0FBTSxTQUFRLE9BQU96a0IsTUFBTTBrQixTQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF3QztBQUFBLG9CQUN4QztBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUFNO0FBQUEsd0JBQ04sT0FBTzFrQixNQUFNa2pCO0FBQUFBO0FBQUFBLHNCQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFFZ0M7QUFBQSx1QkFKbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBLHFCQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXlCQTtBQUFBLGdCQUlEbGdCLFlBQVlLLFFBQ1gsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsT0FBTTtBQUFBLHdCQUNOLE9BQU9yRCxNQUFNMmtCO0FBQUFBO0FBQUFBLHNCQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFFNkI7QUFBQSxvQkFFN0I7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsT0FBTTtBQUFBLHdCQUNOLE9BQU8za0IsTUFBTXdqQjtBQUFBQTtBQUFBQSxzQkFGZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBRTRCO0FBQUEsb0JBRTVCO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE9BQU07QUFBQSx3QkFDTixPQUNFeGpCLE1BQU00a0Isc0JBQ0YsSUFBSXJqQixLQUFLdkIsTUFBTTRrQixtQkFBbUIsRUFDakNwakIsWUFBWSxFQUNaQyxNQUFNLEdBQUcsRUFBRSxDQUFDLElBQ2I7QUFBQTtBQUFBLHNCQVBSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFRRztBQUFBLHVCQWpCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQW1CQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE9BQU07QUFBQSx3QkFDTixPQUFPekIsTUFBTTZrQjtBQUFBQTtBQUFBQSxzQkFGZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBRW9DO0FBQUEsb0JBRXBDO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE9BQU07QUFBQSx3QkFDTixPQUFPN2tCLE1BQU04a0I7QUFBQUE7QUFBQUEsc0JBRmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUVvQztBQUFBLG9CQUVwQztBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUFNO0FBQUEsd0JBQ04sT0FBTzlrQixNQUFNeWpCO0FBQUFBO0FBQUFBLHNCQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFFeUI7QUFBQSx1QkFYM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFhQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE9BQU07QUFBQSx3QkFDTixPQUFPempCLE1BQU0ra0I7QUFBQUE7QUFBQUEsc0JBRmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUVnQztBQUFBLG9CQUVoQztBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxPQUFNO0FBQUEsd0JBQ04sT0FBTy9rQixNQUFNMGpCO0FBQUFBO0FBQUFBLHNCQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFFbUM7QUFBQSxvQkFFbkM7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsT0FBTTtBQUFBLHdCQUNOLE9BQU8xakIsTUFBTWdsQjtBQUFBQTtBQUFBQSxzQkFGZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBRThCO0FBQUEsdUJBWGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBYUE7QUFBQSxxQkFoREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFpREE7QUFBQSxtQkE1T0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE4T0E7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDRCQUEyQiwrQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVDcGxCLGlCQUNDQSxjQUFjdU4sU0FBUyxLQUN2QixDQUFDM04sYUFDQyx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFNOUI7QUFBQUEsc0JBQ0prQztBQUFBQSxzQkFDQW1HO0FBQUFBLG9CQUNGO0FBQUEsb0JBQ0EsU0FBUythO0FBQUFBLG9CQUNULGlCQUFnQjtBQUFBLG9CQUNoQixpQkFBaUI7QUFBQSxzQkFDZjtBQUFBLHNCQUNBO0FBQUEsc0JBQ0E7QUFBQSxzQkFDQTtBQUFBLHNCQUNBO0FBQUEsc0JBQ0E7QUFBQSxvQkFBZTtBQUFBLG9CQUVqQixtQkFBbUI7QUFBQSxzQkFDakI5Z0IsTUFBTXNPO0FBQUFBLHNCQUNOdE8sT0FBT3dPO0FBQUFBLHNCQUNQeEs7QUFBQUEsc0JBQ0FJO0FBQUFBLHNCQUNBRztBQUFBQSxzQkFDQUEsa0JBQWtCTCxZQUNkSyxpQkFBaUJMLFlBQ2pCO0FBQUEsb0JBQUU7QUFBQSxvQkFFUixrQkFBa0I7QUFBQTtBQUFBLGtCQXpCcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQXlCMkQsS0ExQjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBNEJBO0FBQUEsZ0JBR0grQyx3QkFDQ0EscUJBQXFCa0csU0FBUyxLQUM5QixDQUFDM04sYUFDQyx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHlDQUFDLFFBQUcsV0FBVSw0QkFBMkIsNEJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFNeUg7QUFBQUEsc0JBQ04sU0FBU2tZO0FBQUFBLHNCQUNULGtCQUFpQjtBQUFBLHNCQUNqQixpQkFBZ0I7QUFBQTtBQUFBLG9CQUpsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSWdDO0FBQUEscUJBUmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQSxnQkFHSHhZLHFCQUNDQSxrQkFBa0J3RyxTQUFTLEtBQzNCLENBQUMzTixhQUNDLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEseUNBQUMsUUFBRyxXQUFVLDRCQUEyQiw2QkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQU1tSDtBQUFBQSxzQkFDTixTQUFTeVk7QUFBQUEsc0JBQ1Qsa0JBQWlCO0FBQUEsc0JBQ2pCLGlCQUFnQjtBQUFBO0FBQUEsb0JBSmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFJaUM7QUFBQSxxQkFSbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLGdCQUdILENBQUM1ZixhQUNBSSxjQUFjdU4sV0FBVyxLQUN6QmxHLHFCQUFxQmtHLFdBQVcsS0FDaEN4RyxrQkFBa0J3RyxXQUFXLEtBQzNCLHVCQUFDLFNBQUksV0FBVSw4REFBNkQsMEVBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFHSDNOLGFBQ0MsdUJBQUMsa0JBQWUsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUM7QUFBQSxnQkFHdEMsQ0FBQ0EsYUFBYUksY0FBY3VOLFdBQVcsS0FDdEMsdUJBQUMsU0FBSSxXQUFVLGdEQUErQyw0Q0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXhGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTBGQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLDBDQUF5Qyx1Q0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxhQUFZO0FBQUEsc0JBQ1osT0FBT25KLGlCQUFpQjtBQUFBLHNCQUN4QjtBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLb0Y7QUFBQSxxQkFUdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFXQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSwwQ0FBeUMsNEJBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsYUFBWTtBQUFBLHNCQUNaLE9BQU9JLGVBQWU7QUFBQSxzQkFDdEI7QUFBQSxzQkFDQSxXQUFVO0FBQUE7QUFBQSxvQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS29GO0FBQUEscUJBVHRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBV0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsMENBQXlDLG9DQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLGFBQVk7QUFBQSxzQkFDWixPQUFPRyxrQkFBa0I7QUFBQSxzQkFDekI7QUFBQSxzQkFDQSxXQUFVO0FBQUE7QUFBQSxvQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS29GO0FBQUEscUJBVHRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBV0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsMENBQXlDLGlDQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLGFBQVk7QUFBQSxzQkFDWixPQUFPTCxhQUFhO0FBQUEsc0JBQ3BCO0FBQUEsc0JBQ0EsV0FBVTtBQUFBO0FBQUEsb0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtvRjtBQUFBLHFCQVR0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVdBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLDBDQUF5Qyw2QkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxhQUFZO0FBQUEsc0JBQ1osT0FDRUssa0JBQWtCTCxZQUNkSyxpQkFBaUJMLFlBQ2pCO0FBQUEsc0JBRU47QUFBQSxzQkFDQSxXQUFVO0FBQUE7QUFBQSxvQkFUWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBU29GO0FBQUEscUJBYnRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZUE7QUFBQSxtQkFoRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpRUE7QUFBQSxpQkExZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEyZEEsS0EvZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpZUE7QUFBQSxZQUdEMkIsY0FBYyxtQkFDYix1QkFBQyxTQUFJLFdBQVUsdUVBRVozRSxrQ0FDQyx1QkFBQyxTQUFJLFdBQVUsdUVBQXNFLDBDQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLElBRUEsbUNBRUU7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsK0ZBQ2I7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsMEVBQXlFLDZCQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsUUFBRyxXQUFVLGdEQUNYRiwwQkFBZ0Jpa0IsYUFBYTNXLGFBQWEsT0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsK0ZBQ2I7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsMEVBQXlFLDJCQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsUUFBRyxXQUFVLDBEQUNYdE4sMEJBQWdCaWtCLGFBQWFDLGVBQWUsT0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsK0ZBQ2I7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsMEVBQXlFLDRCQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsUUFBRyxXQUFVLHVDQUNYbGtCLDBCQUFnQmlrQixhQUFhelcsZ0JBQWdCLE9BRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLHVHQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLDZFQUE0RSx1QkFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSxnREFBK0M7QUFBQTtBQUFBLG9CQUN6RHhOLGdCQUFnQmdQLFNBQVNpSCxlQUFlLEtBQUs7QUFBQSx1QkFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsK0ZBQ2I7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsMEVBQXlFLDRCQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsUUFBRyxXQUFVLHVDQUNYalcsMEJBQWdCK0IsWUFDYixJQUFJeEIsS0FBS1AsZUFBZStCLFNBQVMsRUFBRTJOLG1CQUFtQixJQUN0RCxPQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxxQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVNBO0FBQUEsbUJBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBK0NBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsSUFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHlDQUFDLFFBQUcsV0FBVSxpRUFBZ0UsNkJBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFHQSx1QkFBQyxTQUFJLFdBQVUsMEZBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxTQUFTLE1BQU05TSxRQUFRLE1BQU07QUFBQSx3QkFDN0IsV0FBVywwRUFBMEVELFNBQVMsU0FDMUYsMkJBQ0EsZ0NBQWdDO0FBQUEsd0JBR3BDO0FBQUE7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsV0FBVTtBQUFBLDhCQUNWLFNBQVE7QUFBQSw4QkFDUixNQUFLO0FBQUEsOEJBQ0wsUUFBTztBQUFBLDhCQUNQLGFBQVk7QUFBQSw4QkFFWjtBQUFBLHVEQUFDLFVBQUssR0FBRSxLQUFJLEdBQUUsS0FBSSxPQUFNLEtBQUksUUFBTyxLQUFJLElBQUcsT0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FBNkM7QUFBQSxnQ0FDN0MsdUJBQUMsVUFBSyxHQUFFLEtBQUksR0FBRSxLQUFJLE9BQU0sS0FBSSxRQUFPLEtBQUksSUFBRyxPQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUE2QztBQUFBLGdDQUM3Qyx1QkFBQyxVQUFLLEdBQUUsS0FBSSxHQUFFLEtBQUksT0FBTSxLQUFJLFFBQU8sS0FBSSxJQUFHLE9BQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBQTZDO0FBQUEsZ0NBQzdDLHVCQUFDLFVBQUssR0FBRSxLQUFJLEdBQUUsS0FBSSxPQUFNLEtBQUksUUFBTyxLQUFJLElBQUcsT0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FBNkM7QUFBQTtBQUFBO0FBQUEsNEJBVi9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFXQTtBQUFBLDBCQUFNO0FBQUE7QUFBQTtBQUFBLHNCQWxCUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBb0JBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsU0FBUyxNQUFNQyxRQUFRLE1BQU07QUFBQSx3QkFDN0IsV0FBVywwRUFBMEVELFNBQVMsU0FDMUYsMkJBQ0EsZ0NBQWdDO0FBQUEsd0JBR3BDO0FBQUE7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsV0FBVTtBQUFBLDhCQUNWLFNBQVE7QUFBQSw4QkFDUixNQUFLO0FBQUEsOEJBQ0wsUUFBTztBQUFBLDhCQUNQLGFBQVk7QUFBQSw4QkFFWjtBQUFBLHVEQUFDLFVBQUssSUFBRyxLQUFJLElBQUcsS0FBSSxJQUFHLE1BQUssSUFBRyxPQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUFrQztBQUFBLGdDQUNsQyx1QkFBQyxVQUFLLElBQUcsS0FBSSxJQUFHLEtBQUksSUFBRyxNQUFLLElBQUcsT0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FBa0M7QUFBQSxnQ0FDbEMsdUJBQUMsVUFBSyxJQUFHLEtBQUksSUFBRyxNQUFLLElBQUcsTUFBSyxJQUFHLFFBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBQW9DO0FBQUE7QUFBQTtBQUFBLDRCQVR0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBVUE7QUFBQSwwQkFBTTtBQUFBO0FBQUE7QUFBQSxzQkFqQlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQW1CQTtBQUFBLHVCQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQTBDQTtBQUFBLHFCQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlEQTtBQUFBLGdCQUdDQSxTQUFTLFVBQ1IsdUJBQUMsU0FBSSxXQUFVLHdEQUNaM0MsMEJBQWdCZ1UsY0FBYzdILFNBQVMsSUFDdENuTSxlQUFlZ1UsYUFBYWhIO0FBQUFBLGtCQUFJLENBQUNILE1BQU1JLFVBQ3JDO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUVDLFdBQVU7QUFBQSxzQkFHVjtBQUFBLCtDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlEQUFDLFVBQUssV0FBVSxvR0FBbUc7QUFBQTtBQUFBLDRCQUMvR3NOLE9BQU90TixRQUFRLENBQUMsRUFBRXdOLFNBQVMsR0FBRyxHQUFHO0FBQUEsK0JBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSwwQkFDQTtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxXQUFXLG9FQUFvRTVOLEtBQUt1QyxTQUFTLFdBQ3pGLG9DQUNBLHlCQUF5QjtBQUFBLDhCQUc1QnZDLGVBQUt1QztBQUFBQTtBQUFBQSw0QkFOUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBT0E7QUFBQSw2QkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQVlBO0FBQUEsd0JBR0E7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVyxxQ0FBcUN2QyxLQUFLdUMsU0FBUyxXQUFXLG1CQUFtQixjQUFjO0FBQUEsNEJBR3pHdkM7QUFBQUEsbUNBQUt1QyxTQUFTLFdBQVcsTUFBTTtBQUFBLDhCQUFJO0FBQUEsOEJBQ25DZ0ksS0FBS0MsSUFBSXZLLE9BQU9ELEtBQUsvSyxVQUFVLENBQUMsQ0FBQyxFQUFFbVUsZUFBZTtBQUFBO0FBQUE7QUFBQSwwQkFMckQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQU1BO0FBQUEsd0JBR0EsdUJBQUMsU0FBSSxXQUFVLDRFQUViO0FBQUEsaURBQUMsVUFBSyxXQUFVLDZCQUE0QixvQ0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDBCQUVBLHVCQUFDLFVBQUssV0FBVSx5REFDYnBKLGdCQUFNOUIsVUFBVXFDLGNBQWNQLE1BQU1sTCxTQUNqQyxHQUFHa0wsS0FBSzlCLFNBQVNxQyxVQUFVLFdBQVdQLEtBQUtsTCxNQUFNLEtBQ2pEa0wsTUFBTVksTUFBTUMsVUFDVmIsS0FBS1ksS0FBS0MsVUFDVmIsTUFBTWMsT0FBT0MsV0FDWGYsS0FBS2MsTUFBTUMsV0FDWCxPQVBWO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBUUE7QUFBQSwwQkFHQSx1QkFBQyxVQUFLLFdBQVUsNkJBQTRCLHNCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFrRDtBQUFBLDBCQUNsRCx1QkFBQyxVQUFLLFdBQVUseURBQ2JmLGdCQUFNZ0UsVUFBVSxPQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsMEJBR0EsdUJBQUMsVUFBSyxXQUFVLDZCQUE0Qiw0QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBd0Q7QUFBQSwwQkFDeEQsdUJBQUMsVUFBSyxXQUFVLGtEQUFpRDtBQUFBO0FBQUEsNEJBQzdEL0QsT0FBT0QsTUFBTXNYLGdCQUFnQixDQUFDLEVBQUVsTyxlQUFlO0FBQUEsK0JBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSwwQkFHQSx1QkFBQyxVQUFLLFdBQVUsNkJBQTRCLDhCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUEwRDtBQUFBLDBCQUMxRCx1QkFBQyxVQUFLLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSw0QkFDN0RuSixPQUFPRCxNQUFNeUYsa0JBQWtCLENBQUMsRUFBRTJELGVBQWU7QUFBQSwrQkFEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDBCQUdBLHVCQUFDLFVBQUssV0FBVSw2QkFBNEIsbUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQStDO0FBQUEsMEJBQy9DLHVCQUFDLFVBQUssV0FBVSxrREFBaUQ7QUFBQTtBQUFBLDRCQUM3RG5KLE9BQU9ELE1BQU11WCxjQUFjLENBQUMsRUFBRW5PLGVBQWU7QUFBQSwrQkFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDBCQUdBLHVCQUFDLFVBQUssV0FBVSw2QkFBNEIsd0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQW9EO0FBQUEsMEJBQ3BELHVCQUFDLFVBQUssV0FBVSxrREFBaUQ7QUFBQTtBQUFBLDZCQUM1RHBKLE1BQU13WCxtQkFBbUIsR0FBR3BPLGVBQWU7QUFBQSwrQkFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDBCQUdBLHVCQUFDLFVBQUssV0FBVSw2QkFBNEIsMEJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQXNEO0FBQUEsMEJBQ3REO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLFdBQVcsZ0NBQWdDcEosS0FBS3VDLFNBQVMsV0FBVyxtQkFBbUIsY0FBYztBQUFBLDhCQUdwR3ZDO0FBQUFBLHFDQUFLdUMsU0FBUyxXQUFXLE1BQU07QUFBQSxnQ0FBSTtBQUFBLGdDQUNuQ2dJLEtBQUtDLElBQUl2SyxPQUFPRCxNQUFNL0ssVUFBVSxDQUFDLENBQUMsRUFBRW1VLGVBQWU7QUFBQTtBQUFBO0FBQUEsNEJBTHREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFNQTtBQUFBLDBCQUdBLHVCQUFDLFVBQUssV0FBVSw2QkFBNEIscUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWlEO0FBQUEsMEJBQ2pELHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsbURBQUMsT0FBRSxXQUFVLHFDQUNWcEosZ0JBQU15WCxVQUFValgsUUFBUSxPQUQzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUVBO0FBQUEsNEJBQ0EsdUJBQUMsT0FBRSxXQUFVLHVDQUNWUixnQkFBTXlYLFVBQVVDLGNBQWMsTUFEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FFQTtBQUFBLCtCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBT0E7QUFBQSwwQkFHQSx1QkFBQyxVQUFLLFdBQVUsNkJBQTRCLHlCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFxRDtBQUFBLDBCQUNyRDtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxXQUFXLDBFQUEwRTFYLE1BQU0yWCxzQkFBc0IsUUFDN0csNEJBQ0EsMkJBQTJCO0FBQUEsOEJBRzlCM1gsZ0JBQU0yWCxxQkFBcUI7QUFBQTtBQUFBLDRCQU45QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBT0E7QUFBQSwwQkFHQSx1QkFBQyxVQUFLLFdBQVUsNkJBQTRCLG9CQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFnRDtBQUFBLDBCQUNoRCx1QkFBQyxVQUFLLFdBQVUsa0RBQ2IsY0FBSWprQixLQUFLc00sS0FBSzlLLFNBQVMsRUFBRWtVLGVBQWUsS0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDBCQUdBLHVCQUFDLFVBQUssV0FBVSw2QkFBNEIsdUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQW1EO0FBQUEsMEJBQ25ELHVCQUFDLFVBQUssV0FBVSxrREFDYnBKO0FBQUFBLGlDQUFLNFgsU0FBU25YLGFBQWE7QUFBQSw0QkFBSTtBQUFBLDRCQUFPVCxLQUFLNlgsU0FBU2hYLFdBQVc7QUFBQSwrQkFEbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDZCQXhGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQXlGQTtBQUFBO0FBQUE7QUFBQSxvQkFySEtiLEtBQUtLO0FBQUFBLG9CQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBdUhBO0FBQUEsZ0JBQ0QsSUFFRCx1QkFBQyxTQUFJLFdBQVUseURBQXdELHdDQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBLEtBL0hKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaUlBO0FBQUEsZ0JBSUR2SyxTQUFTLFVBQ1IsdUJBQUMsU0FBSSxXQUFVLHVFQUViO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQU9UO0FBQUEsd0JBQ0M7QUFBQSx3QkFDQTtBQUFBLHdCQUNBO0FBQUEsd0JBQ0E7QUFBQSx3QkFDQTtBQUFBLHdCQUNBO0FBQUEsd0JBQ0E7QUFBQSx3QkFDQTtBQUFBLHdCQUNBO0FBQUEsd0JBQ0E7QUFBQSx3QkFDQTtBQUFBLHdCQUNBO0FBQUEsc0JBQU8sRUFDUHFLLElBQUksQ0FBQzJYLEdBQUdDLE1BQU07QUFDZCw4QkFBTUMsWUFBWUQsS0FBSyxLQUFLQSxLQUFLO0FBRWpDLCtCQUNFO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUVDLFdBQVcsb0VBQW9FQyxZQUFZLGVBQWUsV0FBVztBQUFBLDRCQUdwSEY7QUFBQUE7QUFBQUEsMEJBSklBO0FBQUFBLDBCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBTUE7QUFBQSxzQkFFSixDQUFDO0FBQUE7QUFBQSxvQkFqQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQWtDQTtBQUFBLGtCQUdDM2tCLGdCQUFnQmdVLGNBQWM3SCxTQUFTLElBQ3RDLHVCQUFDLFNBQUksV0FBVSw0QkFDWm5NLHlCQUFlZ1UsYUFBYWhIO0FBQUFBLG9CQUFJLENBQUNILE1BQU1JLFVBQ3RDO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUVDLFdBQVU7QUFBQSx3QkFRVjtBQUFBLGlEQUFDLFNBQUksV0FBVSx5Q0FDWnNOLGlCQUFPdE4sUUFBUSxDQUFDLEVBQUV3TixTQUFTLEdBQUcsR0FBRyxLQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsMEJBR0EsdUJBQUMsU0FDQztBQUFBLG1EQUFDLE9BQUUsV0FBVSxXQUNWLGNBQUlsYSxLQUFLc00sS0FBSzlLLFNBQVMsRUFBRTJOLG1CQUFtQixPQUFPLEtBRHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQSw0QkFFQSx1QkFBQyxPQUFFLFdBQVUseUJBQ1YsY0FBSW5QLEtBQUtzTSxLQUFLOUssU0FBUyxFQUFFK2lCLG1CQUFtQixTQUFTO0FBQUEsOEJBQ3BEQyxNQUFNO0FBQUEsOEJBQ05DLFFBQVE7QUFBQSw0QkFDVixDQUFDLEtBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FLQTtBQUFBLCtCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBV0E7QUFBQSwwQkFHQSx1QkFBQyxTQUNDO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLFdBQVcsNERBQTREblksS0FBS3VDLFNBQVMsV0FDakYsZ0NBQ0EseUJBQXlCO0FBQUEsOEJBRzVCdkMsZUFBS3VDO0FBQUFBO0FBQUFBLDRCQU5SO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBU0E7QUFBQSwwQkFHQSx1QkFBQyxTQUFJLFdBQVUsV0FDYixpQ0FBQyxPQUFFLFdBQVUsa0NBQ1Z2QyxnQkFBTTlCLFVBQVVxQyxjQUFjUCxNQUFNbEwsU0FDbkMsbUNBQ0U7QUFBQSxtREFBQyxVQUFLLFdBQVUsa0JBQ2JrTCxlQUFLOUIsU0FBU3FDLGNBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQSw0QkFFQSx1QkFBQyxVQUFLLFdBQVUsb0NBQW1DO0FBQUE7QUFBQSw4QkFDekNQLEtBQUtsTDtBQUFBQSxpQ0FEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUVBO0FBQUEsK0JBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FRQSxJQUNFa0wsTUFBTVksTUFBTUMsVUFDZCxtQ0FDRTtBQUFBLG1EQUFDLFVBQUssV0FBVSxrQkFDYmIsZUFBS1ksS0FBS0MsV0FEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUVBO0FBQUEsNEJBRUEsdUJBQUMsVUFBSyxXQUFVLG9DQUFtQztBQUFBO0FBQUEsOEJBQ3pDYixLQUFLWSxLQUFLMEU7QUFBQUEsaUNBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQSwrQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQVFBLElBQ0V0RixNQUFNYyxPQUFPQyxXQUNmLHVCQUFDLFVBQUssV0FBVSxrQkFDYmYsZUFBS2MsTUFBTUMsWUFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBLElBRUEsT0ExQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0E0QkEsS0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0E4QkE7QUFBQSwwQkFHQSx1QkFBQyxTQUFJLFdBQVUsV0FDYjtBQUFBLG1EQUFDLE9BQUUsV0FBVSxvQkFDVmYsZUFBSzRYLFNBQVNuWCxhQUFhLE9BRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQSw0QkFFQSx1QkFBQyxPQUFFLFdBQVUsa0NBQ1ZULGVBQUs0WCxTQUFTalgsZ0JBQWdCLE9BRGpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQSw0QkFFQSx1QkFBQyxPQUFFLFdBQVUsa0NBQ1ZYLGVBQUs2WCxTQUFTaFgsV0FBVyxPQUQ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUVBO0FBQUEsK0JBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FZQTtBQUFBLDBCQUdBLHVCQUFDLFNBQUksV0FBVSxvQkFDWmIsZUFBS2dFLFVBQVUsT0FEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDBCQUdBO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLFdBQVcsMENBQTBDaEUsS0FBS3VDLFNBQVMsV0FDL0QsbUJBQ0EsY0FBYztBQUFBLDhCQUdqQnZDLGVBQUtzWCxlQUNGLEdBQUd0WCxLQUFLdUMsU0FBUyxXQUFXLE1BQU0sR0FBRyxLQUFLdEM7QUFBQUEsZ0NBQzFDRCxLQUFLc1g7QUFBQUEsOEJBQ1AsRUFBRWxPLGVBQWUsT0FBTyxDQUFDLEtBQ3ZCO0FBQUE7QUFBQSw0QkFWTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBV0E7QUFBQSwwQkFHQSx1QkFBQyxTQUFJLFdBQVUsdURBQ1pwSixlQUFLeUYsaUJBQ0YsTUFBTXhGLE9BQU9ELEtBQUt5RixjQUFjLEVBQUUyRCxlQUFlLE9BQU8sQ0FBQyxLQUN6RCxPQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBSUE7QUFBQSwwQkFHQSx1QkFBQyxTQUFJLFdBQVUsdURBQ1pwSixlQUFLdVgsYUFDRixNQUFNdFgsT0FBT0QsS0FBS3VYLFVBQVUsRUFBRW5PLGVBQWUsT0FBTyxDQUFDLEtBQ3JELE9BSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FJQTtBQUFBLDBCQUdBLHVCQUFDLFNBQUksV0FBVSx3REFBdUQ7QUFBQTtBQUFBLDRCQUVuRW5KLE9BQU9ELE1BQU13WCxtQkFBbUIsQ0FBQyxFQUFFcE8sZUFBZSxPQUFPO0FBQUEsK0JBRjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBR0E7QUFBQSwwQkFHQTtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxXQUFXLDBDQUEwQ3BKLEtBQUt1QyxTQUFTLFdBQy9ELG1CQUNBLGNBQWM7QUFBQSw4QkFHakJ2QztBQUFBQSxxQ0FBS3VDLFNBQVMsV0FBVyxNQUFNO0FBQUEsZ0NBQUk7QUFBQSxnQ0FDbkNnSSxLQUFLQyxJQUFJdkssT0FBT0QsS0FBSy9LLFVBQVUsQ0FBQyxDQUFDLEVBQUVtVSxlQUFlLE9BQU87QUFBQTtBQUFBO0FBQUEsNEJBUDVEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFRQTtBQUFBLDBCQUdBLHVCQUFDLFNBQUksV0FBVSx5QkFDWnBKLGVBQUt5WCxXQUNKLG1DQUNFO0FBQUEsbURBQUMsT0FBRSxXQUFVLGtDQUNWelgsZUFBS3lYLFNBQVNqWCxRQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUVBO0FBQUEsNEJBRUEsdUJBQUMsT0FBRSxXQUFVLGtDQUNWUixlQUFLeVgsU0FBU0MsY0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FFQTtBQUFBLCtCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBUUEsSUFFQSxPQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBY0E7QUFBQTtBQUFBO0FBQUEsc0JBeEpLMVgsS0FBS0s7QUFBQUEsc0JBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkEwSkE7QUFBQSxrQkFDRCxLQTdKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQThKQSxJQUVBLHVCQUFDLFNBQUksV0FBVSwyQ0FBMEMsd0NBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkExTUo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE0TUE7QUFBQSxtQkF4WUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkEyWUE7QUFBQSxpQkEvYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnY0EsS0F2Y0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5Y0E7QUFBQSxZQUdEckksY0FBYyxpQkFDYixtQ0FDRSxpQ0FBQyxTQUNDO0FBQUEscUNBQUMsU0FBSSxXQUFVLGNBQ2IsaUNBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDBDQUF5QyxrQ0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQ0VyRCxjQUFjRSxVQUNWLEdBQUdGLGNBQWNFLE9BQU8sSUFBSUYsY0FBY0csTUFBTSxLQUNoRDtBQUFBLG9CQUVOLFVBQVU0UjtBQUFBQSxvQkFDVixXQUFVO0FBQUEsb0JBRVY7QUFBQSw2Q0FBQyxZQUFPLE9BQU0sSUFBRyxxQ0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBc0M7QUFBQSxzQkFFckM1UCxvQkFBb0JxSixJQUFJLENBQUNoTyxXQUFVO0FBQ2xDLDRCQUNFQSxRQUFPK0wsWUFDUCxDQUFDLFVBQVUsU0FBUyxFQUFFbUc7QUFBQUEsMEJBQ3BCLENBQUNPLFdBQ0NBLFdBQ0F6UyxRQUFPdWdCO0FBQUFBLHdCQUNYLEdBQ0E7QUFDQSxpQ0FDRTtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFFQyxPQUFPLEdBQUd2Z0IsUUFBTytMLFVBQVVtQyxHQUFHLElBQUlsTyxRQUFPbVIsT0FBTztBQUFBLDhCQUUvQ25SO0FBQUFBLHdDQUFPK0wsVUFBVXFDO0FBQUFBLGdDQUFXO0FBQUEsZ0NBQUc7QUFBQSxnQ0FDL0JwTyxRQUFPbVI7QUFBQUE7QUFBQUE7QUFBQUEsNEJBSkhuUixRQUFPK0wsVUFBVW1DO0FBQUFBLDRCQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQU1BO0FBQUEsd0JBRUo7QUFDQSwrQkFBTztBQUFBLHNCQUNULENBQUM7QUFBQSxzQkFFQTJNLE1BQU1DLFFBQVEzVSxlQUFlOEwsWUFBWSxLQUN4QzlMLGNBQWM4TCxhQUFhakU7QUFBQUEsd0JBQ3pCLENBQUNTLE1BQU1SLFVBQ0w7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBSUMsT0FBTyxRQUFRUSxNQUFNMEQsY0FBYzFELE1BQU1QLE9BQU9ELEtBQUs7QUFBQSw0QkFHcERRO0FBQUFBLG9DQUFNMEQsY0FBYzFELE1BQU1DLFdBQ3pCO0FBQUEsOEJBQU87QUFBQSw4QkFBSTtBQUFBLDhCQUNURCxNQUFNMkUsY0FBYztBQUFBO0FBQUE7QUFBQSwwQkFQdEIzRSxNQUFNMEQsY0FBYzFELE1BQU1QLE9BQU9EO0FBQUFBLDBCQUZyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVVBO0FBQUEsc0JBRUo7QUFBQSxzQkFFRDRNLE1BQU1DLFFBQVF6VSxnQkFBZ0J3TixhQUFhLEtBQzFDeE4sZUFBZXdOLGNBQWM3RjtBQUFBQSx3QkFDM0IsQ0FBQ1csT0FBT1YsVUFDTjtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFLQyxPQUFPLFNBQVNVLE9BQU9tRixlQUFlbkYsT0FBT1QsT0FDM0NELEtBQUs7QUFBQSw0QkFHTlU7QUFBQUEscUNBQU9tRixlQUFlbkYsT0FDbkJDLFlBQVk7QUFBQSw4QkFBTztBQUFBLDhCQUFJO0FBQUEsOEJBQ3ZCRCxPQUFPc0YsMEJBQTBCO0FBQUE7QUFBQTtBQUFBLDBCQVRuQ3RGLE9BQU9tRixlQUFlbkYsT0FBT1QsT0FDN0JEO0FBQUFBLDBCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBWUE7QUFBQSxzQkFFSjtBQUFBO0FBQUE7QUFBQSxrQkFuRUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQW9FQTtBQUFBLG1CQXhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXlFQSxLQTFFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTJFQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE9BQU8sc0JBQXNCdEcsc0JBQXNCLENBQUM7QUFBQSxvQkFFcEQ7QUFBQSxvQkFDQSxXQUFVO0FBQUE7QUFBQSxrQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS2tIO0FBQUEsZ0JBRWxIO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxPQUFPLHFCQUFxQkksbUJBQW1CO0FBQUEsb0JBQy9DO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUkrRztBQUFBLGdCQUUvRztBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsT0FBTyxXQUFXK0YsT0FBTy9GLG1CQUFtQixJQUMxQytGLE9BQU9uRyxzQkFBc0IsQ0FBQyxDQUFDO0FBQUEsb0JBRWpDO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1xSDtBQUFBLG1CQXBCdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFzQkE7QUFBQSxlQUVFdkgsY0FBYytNLFNBQVMsS0FDdkJ0RyxlQUFlc0csU0FBUyxLQUN4QjVHLG1CQUFtQjRHLFNBQVMsTUFDNUIsQ0FBQy9LLGVBQ0QsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsaUJBQWdCO0FBQUEsa0JBQ2hCLGtCQUFpQjtBQUFBLGtCQUNqQixpQkFDRUksY0FBY0UsWUFBWSxTQUN0QjtBQUFBLG9CQUNBO0FBQUEsb0JBQ0E7QUFBQSxvQkFDQTtBQUFBLG9CQUNBO0FBQUEsb0JBQ0E7QUFBQSxrQkFBVyxJQUVYRixjQUFjRSxZQUFZLFVBQ3hCO0FBQUEsb0JBQ0E7QUFBQSxvQkFDQTtBQUFBLG9CQUNBO0FBQUEsb0JBQ0E7QUFBQSxvQkFDQTtBQUFBLGtCQUFZLElBRVo7QUFBQSxvQkFDQTtBQUFBLG9CQUNBO0FBQUEsb0JBQ0E7QUFBQSxvQkFDQTtBQUFBLG9CQUNBO0FBQUEsa0JBQVk7QUFBQSxrQkFHcEIsbUJBQ0VGLGNBQWNFLFlBQVksU0FDdEI7QUFBQSxvQkFDQTFDLE9BQU9zTztBQUFBQSxvQkFDUHRPLE9BQU9rbEI7QUFBQUEsb0JBQ1BsbEIsT0FBT3dPO0FBQUFBLHFCQUNOLE1BQU07QUFFTCw0QkFBTXdELGVBQ0o3TCxlQUFlOEwsY0FBY0M7QUFBQUEsd0JBQzNCLENBQUN6RCxTQUNDQSxNQUFNMEQsY0FBYzFELE1BQ2hCUCxRQUNKMUwsY0FBY0c7QUFBQUEsc0JBQ2xCO0FBQ0YsNkJBQ0VxUCxjQUFjRyxjQUFjMUQsTUFDeEJDLFdBQVdsTSxjQUFjRztBQUFBQSxvQkFFakMsR0FBRztBQUFBLG9CQUNIO0FBQUEsa0JBQU0sSUFFTkgsY0FBY0UsWUFBWSxVQUN4QjtBQUFBLG9CQUNBMUMsT0FBT3NPO0FBQUFBLG9CQUNQdE8sT0FBT2tsQjtBQUFBQSxvQkFDUGxsQixPQUFPd087QUFBQUEscUJBQ04sTUFBTTtBQUVMLDRCQUFNeVgsZ0JBQ0o1ZixnQkFBZ0J3TixlQUFlM0I7QUFBQUEsd0JBQzdCLENBQUN2RCxVQUNDQSxPQUFPbUYsZUFBZW5GLE9BQ2xCVCxRQUNKMUwsY0FBY0c7QUFBQUEsc0JBQ2xCO0FBQ0YsNkJBQ0VzakIsZUFBZW5TLGVBQ1huRixPQUFPQyxZQUNYcE0sY0FBY0c7QUFBQUEsb0JBRWxCLEdBQUc7QUFBQSxvQkFDSDtBQUFBLGtCQUFPLElBRVA7QUFBQSxvQkFDQTNDLE9BQU9zTztBQUFBQSxvQkFDUHRPLE9BQU9rbEI7QUFBQUEsb0JBQ1BsbEIsT0FBT3dPO0FBQUFBLG9CQUNQaE0sZUFBZUc7QUFBQUEsb0JBQ2ZzRCxjQUFjbUk7QUFBQUEsa0JBQVU7QUFBQSxrQkFHaEMsTUFDRTVMLGVBQWVFLFlBQVksU0FDdkJtRSxnQkFDQXJFLGVBQWVFLFlBQVksVUFDekI2RCxvQkFDQW5HO0FBQUFBLGtCQUVSLFNBQ0VvQyxlQUFlRSxZQUFZLFNBQ3ZCMkosbUJBQ0E3SixlQUFlRSxZQUFZLFVBQ3pCOEosb0JBQ0EwVTtBQUFBQTtBQUFBQSxnQkE1RlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBNkZHLEtBOUZMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0dBLElBRUEsdUJBQUMsa0JBQWUsV0FBVzllLGdCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QztBQUFBLGlCQTVNNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE4TUEsS0EvTUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnTkE7QUFBQSxZQUdEeUQsY0FBYyxrQkFDYix1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUseUNBQXdDLDRCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FFQ3dCLHNCQUNDLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWUsSUFDYkYsc0JBQXNCZ0csU0FBUyxJQUNqQyx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFNaEc7QUFBQUEsa0JBQ04sU0FBU3NGO0FBQUFBLGtCQUNULGlCQUFpQjtBQUFBLGtCQUNqQixrQkFBa0I7QUFBQSxrQkFDbEIsaUJBQWlCO0FBQUEsb0JBQ2Y7QUFBQSxvQkFDQTtBQUFBLGtCQUFjO0FBQUEsa0JBRWhCLG1CQUFtQjtBQUFBLG9CQUNqQnpNLE9BQU9zTztBQUFBQSxvQkFDUHRPLE9BQU93TztBQUFBQSxrQkFBWTtBQUFBO0FBQUEsZ0JBWHZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVlJLEtBYk47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxrREFBaUQsMENBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkEzQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE2QkE7QUFBQSxZQUdEM0ksY0FBYyw4QkFDYix1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUseUNBQXdDLDBDQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDRSwyQkFBWTtBQUFBLGNBQUUsRUFBRztBQUFBLGNBQ25CLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSwwQ0FBeUMsa0NBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxPQUFPeUY7QUFBQUEsb0JBQ1AsVUFBVXNUO0FBQUFBLG9CQUNWLFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLFlBQU8sT0FBTSxJQUFHLHFDQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFzQztBQUFBLHNCQUVyQ2hVLGVBQWVvRCxJQUFJLENBQUN2QyxNQUFNO0FBQ3pCLCtCQUNFLHVCQUFDLFlBQW9CLE9BQU8sR0FBR0EsR0FBR3lDLEdBQUcsSUFDbEN6QztBQUFBQSw2QkFBR00sVUFBVXFDO0FBQUFBLDBCQUFXO0FBQUEsMEJBQUkzQyxHQUFHMEY7QUFBQUEsNkJBRHJCMUYsR0FBR3lDLEtBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSxzQkFFSixDQUFDO0FBQUE7QUFBQTtBQUFBLGtCQWJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFjQTtBQUFBLG1CQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1CQTtBQUFBLGNBQ0MzRyxtQkFDQyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFlLElBQ2J1RCxzQkFBc0JxQyxTQUFTLElBQ2pDLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQU1yQztBQUFBQSxrQkFDTixTQUFTcVc7QUFBQUEsa0JBQ1QsWUFDRUM7QUFBQUEsa0JBRUYsaUJBQWlCO0FBQUEsa0JBQ2pCLGtCQUFrQjtBQUFBO0FBQUEsZ0JBUHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU82QyxLQVIvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGtEQUFpRCxtREFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQTFDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTRDQTtBQUFBLFlBR0R2YixjQUFjLGtCQUNiLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSx3Q0FBdUMsNEJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSxrTUFFYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwrRkFDYixpQ0FBQywwQkFBdUIsTUFBTSxNQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQyxLQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLHlDQUViO0FBQUEseUNBQUMsU0FBSSxXQUFVLCtGQUNiLGlDQUFDLDBCQUF1QixXQUFVLHlCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RCxLQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLG9GQUFtRiw0QkFBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLDZDQUFDLFVBQUssV0FBVSxtQ0FBa0MsaUJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQSx1QkFBQyxVQUFLLFdBQVUscURBQ2I2RSxpQ0FBdUJ1TTtBQUFBQSx3QkFDdEI7QUFBQSxzQkFDRixLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBSUE7QUFBQSx5QkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVNBO0FBQUEsdUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFjQTtBQUFBLHFCQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXFCQTtBQUFBLGdCQUdDdk0seUJBQXlCLEtBQ3hCLHVCQUFDLFNBQUksV0FBVSx5Q0FDYixpQ0FBQyxPQUFFLFdBQVUsOERBQ1ZwTTtBQUFBQSxzQ0FBb0JvTSxzQkFBc0I7QUFBQSxrQkFBRztBQUFBLGtCQUFJO0FBQUEscUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsbUJBcENKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0NBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsdUVBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSw0Q0FBMkMsMEJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQztBQUFBLHNCQUNBLHVCQUF1QjtBQUFBLHNCQUN2QixVQUFVbVU7QUFBQUEsc0JBQ1YsT0FBTzVXLGlCQUFpQnVhO0FBQUFBLHNCQUN4QixhQUFZO0FBQUEsc0JBQ1osY0FBYyxDQUFDQyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmhFLFNBQVMsRUFDVGlFLFlBQVksRUFDWkMsU0FBU0osTUFBTUcsWUFBWSxDQUFDO0FBQUEsc0JBRWpDLFdBQVU7QUFBQSxzQkFDVixPQUFPLEVBQUVFLFFBQVEsT0FBTztBQUFBLHNCQUV2QjVELG1CQUFTbFI7QUFBQUEsd0JBQUksQ0FBQ2tZLFNBQ2I7QUFBQSwwQkFBQyxPQUFPO0FBQUEsMEJBQVA7QUFBQSw0QkFFQyxPQUFPQSxLQUFLbmlCO0FBQUFBLDRCQUVYbWlCLGVBQUtwaUI7QUFBQUE7QUFBQUEsMEJBSERvaUIsS0FBS25pQjtBQUFBQSwwQkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUtBO0FBQUEsc0JBQ0Q7QUFBQTtBQUFBLG9CQXRCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBdUJBO0FBQUEscUJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBNEJBO0FBQUEsZ0JBR0NvRSxtQkFDQyxtQ0FDRTtBQUFBLHlDQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLDJDQUEwQyx5QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxPQUFPcEQ7QUFBQUEsd0JBQ1AsVUFBVSxDQUFDMEcsTUFDVHpHLG9CQUFvQnlHLEVBQUVDLE9BQU8zSCxLQUFLO0FBQUEsd0JBRXBDLFdBQVU7QUFBQTtBQUFBLHNCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNNko7QUFBQSx1QkFWL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFZQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLDJDQUEwQyx1QkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxPQUFPa0I7QUFBQUEsd0JBQ1AsVUFBVSxDQUFDd0csTUFDVHZHLGtCQUFrQnVHLEVBQUVDLE9BQU8zSCxLQUFLO0FBQUEsd0JBRWxDLFdBQVU7QUFBQTtBQUFBLHNCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNNko7QUFBQSx1QkFWL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFZQTtBQUFBLHFCQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTJCQTtBQUFBLGdCQUdGLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLDRDQUEyQyw0QkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUVBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxPQUFPb0IsdUJBQXVCcWQ7QUFBQUEsc0JBQzlCO0FBQUEsc0JBQ0EsYUFBWTtBQUFBLHNCQUNaLHVCQUF1QjtBQUFBLHNCQUN2QixVQUFVLENBQUMyRCxVQUFVO0FBQ25CL2dCLCtDQUF1QitnQixLQUFLO0FBQUEsc0JBQzlCO0FBQUEsc0JBQ0EsY0FBYyxDQUFDMUQsT0FBT0MsV0FDcEJBLE9BQU81ZSxNQUNKNmEsU0FBUyxFQUNUaUUsWUFBWSxFQUNaQyxTQUFTSixNQUFNRyxZQUFZLENBQUM7QUFBQSxzQkFFakMsV0FBVTtBQUFBLHNCQUNWLE9BQU8sRUFBRUUsUUFBUSxPQUFPO0FBQUEsc0JBQ3hCLFNBQVM7QUFBQSx3QkFDUCxFQUFFaGYsT0FBTyxRQUFRQyxPQUFPLE9BQU87QUFBQSx3QkFDL0IsRUFBRUQsT0FBTyxVQUFVQyxPQUFPLFNBQVM7QUFBQSx3QkFDbkM7QUFBQSwwQkFDRUQsT0FBTztBQUFBLDBCQUNQQyxPQUFPO0FBQUEsd0JBQ1Q7QUFBQSxzQkFBQztBQUFBO0FBQUEsb0JBdkJMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkF3Qkk7QUFBQSxxQkE3Qk47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkErQkE7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSw0Q0FBMkMsMkJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFFQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsT0FBT21HO0FBQUFBLHNCQUNQO0FBQUEsc0JBQ0EsYUFBWTtBQUFBLHNCQUNaLHVCQUF1QjtBQUFBLHNCQUN2QixVQUFVLENBQUNpYyxVQUFVO0FBQ25CaGMsOENBQXNCZ2MsS0FBSztBQUFBLHNCQUM3QjtBQUFBLHNCQUNBLGNBQWMsQ0FBQzFELE9BQU9DLFdBQ3BCQSxPQUFPNWUsTUFDSjZhLFNBQVMsRUFDVGlFLFlBQVksRUFDWkMsU0FBU0osTUFBTUcsWUFBWSxDQUFDO0FBQUEsc0JBRWpDLFdBQVU7QUFBQSxzQkFDVixPQUFPLEVBQUVFLFFBQVEsT0FBTztBQUFBLHNCQUN4QixTQUFTO0FBQUEsd0JBQ1AsRUFBRWhmLE9BQU8sUUFBUUMsT0FBTyxPQUFPO0FBQUEsd0JBQy9CLEVBQUVELE9BQU8sU0FBU0MsT0FBTyxRQUFRO0FBQUEsd0JBQ2pDLEVBQUVELE9BQU8sUUFBUUMsT0FBTyxPQUFPO0FBQUEsc0JBQUM7QUFBQTtBQUFBLG9CQXBCcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQXFCSTtBQUFBLHFCQTFCTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTRCQTtBQUFBLGdCQUVDcUcsdUJBQ0MsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsNENBQTJDLDRCQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FBT0o7QUFBQUEsc0JBQ1A7QUFBQSxzQkFDQSxhQUFZO0FBQUEsc0JBQ1osdUJBQXVCO0FBQUEsc0JBQ3ZCLFVBQVUsQ0FBQ3RILFlBQ1R1SCx1QkFBdUJ2SCxPQUFPO0FBQUEsc0JBRWhDLGNBQWMsQ0FBQytmLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKaEUsU0FBUyxFQUNUaUUsWUFBWSxFQUNaQyxTQUFTSixNQUFNRyxZQUFZLENBQUM7QUFBQSxzQkFFakMsV0FBVTtBQUFBLHNCQUNWLE9BQU8sRUFBRUUsUUFBUSxPQUFPO0FBQUEsc0JBRXhCO0FBQUEsK0NBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxJQUFHLHlCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQ0EsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxZQUFXLHdCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQ0EsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxVQUFTLHNCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQ0EsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxjQUFhLDBCQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQ0EsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxVQUFTLHNCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUE7QUFBQTtBQUFBLG9CQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBZ0NBO0FBQUEscUJBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBcUNBO0FBQUEsbUJBbktKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUtBO0FBQUEsY0FFQ3JiLHNCQUNDLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWUsSUFDYjZDLG1CQUFtQjZDLFNBQVMsSUFDOUIsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBTTdDO0FBQUFBLGtCQUNOLFNBQVNxQztBQUFBQSxrQkFDVCxpQkFBaUI7QUFBQSxrQkFDakIsa0JBQWtCO0FBQUE7QUFBQSxnQkFKcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSThDLEtBTGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0EsSUFFQSx1QkFBQyxTQUFJLFdBQVUsa0RBQWlELHFDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBbE9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb09BO0FBQUEsWUFHRDlHLGNBQWMscUJBQ2IsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLDRDQUEyQyxvQ0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBRUNxRix5QkFDQyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFlLElBQ2JFLGlCQUFpQitCLFNBQVMsSUFDNUIsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBTS9CO0FBQUFBLGtCQUNOLFNBQVNzQjtBQUFBQSxrQkFDVCxpQkFBZ0I7QUFBQSxrQkFDaEIsa0JBQWlCO0FBQUEsa0JBQ2pCLGlCQUFpQjtBQUFBLG9CQUNmO0FBQUEsb0JBQ0E7QUFBQSxrQkFBYztBQUFBLGtCQUVoQixtQkFBbUI7QUFBQSxvQkFDakIxTSxPQUFPc087QUFBQUEsb0JBQ1B0TyxPQUFPd087QUFBQUEsa0JBQVk7QUFBQTtBQUFBLGdCQVh2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FZSSxLQWJOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQStDLDZDQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkJBO0FBQUEsWUFHRDNJLGNBQWMsYUFDYix1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsY0FDYixpQ0FBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxRQUFHLFdBQVUsMkRBQ1o7QUFBQSx5Q0FBQyw2QkFBMEIsV0FBVSxrQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUQ7QUFBQSxrQkFBRztBQUFBLHFCQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLGdCQUNBLHVCQUFDLFdBQU0sV0FBVSwwQ0FBeUMsa0NBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxPQUNFckQsY0FBY0UsVUFDVixHQUFHRixjQUFjRSxPQUFPLElBQUlGLGNBQWNHLE1BQU0sS0FDaEQ7QUFBQSxvQkFFTixVQUFVNFI7QUFBQUEsb0JBQ1YsV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsWUFBTyxPQUFNLElBQUcscUNBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXNDO0FBQUEsc0JBR3JDNVAscUJBQXFCcUosSUFBSSxDQUFDb1ksZUFBZTtBQUN4Qyw0QkFDRUEsWUFBWXJhLFlBQ1osQ0FBQyxVQUFVLFNBQVMsRUFBRThXLFNBQVN1RCxZQUFZN0YsZUFBZSxHQUMxRDtBQUNBLGlDQUNFO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUVDLE9BQU8sR0FBRzZGLFlBQVlyYSxVQUFVbUMsR0FBRyxJQUFJa1ksWUFBWWpWLE9BQU87QUFBQSw4QkFFekRpVjtBQUFBQSw0Q0FBWXJhLFVBQVVxQyxjQUFjO0FBQUEsZ0NBQU07QUFBQSxnQ0FBRztBQUFBLGdDQUM3Q2dZLFlBQVlqVixXQUFXO0FBQUE7QUFBQTtBQUFBLDRCQUpuQmlWLFlBQVlsWTtBQUFBQSw0QkFEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFNQTtBQUFBLHdCQUVKO0FBQ0EsK0JBQU87QUFBQSxzQkFDVCxDQUFDO0FBQUEsc0JBR0EyTSxNQUFNQyxRQUFRM1UsZUFBZThMLFlBQVksS0FDeEM5TCxjQUFjOEwsYUFBYWpFO0FBQUFBLHdCQUFJLENBQUNTLE1BQU1SLFVBQ3BDO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUVDLE9BQU8sUUFBUVEsTUFBTTBELGNBQWMxRCxNQUFNUCxPQUFPRCxLQUFLO0FBQUEsNEJBRXBEUTtBQUFBQSxvQ0FBTTBELGNBQWMxRCxNQUFNQyxXQUFXO0FBQUEsOEJBQU07QUFBQSw4QkFDM0NELE1BQU0yRSxjQUFjO0FBQUE7QUFBQTtBQUFBLDBCQUpoQjNFLE1BQU0wRCxjQUFjMUQsTUFBTVAsT0FBT0Q7QUFBQUEsMEJBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBTUE7QUFBQSxzQkFDRDtBQUFBLHNCQUdGNE0sTUFBTUMsUUFBUXpVLGdCQUFnQndOLGFBQWEsS0FDMUN4TixlQUFld04sY0FBYzdGO0FBQUFBLHdCQUFJLENBQUNXLE9BQU9WLFVBQ3ZDO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUVDLE9BQU8sU0FBU1UsT0FBT21GLGVBQWVuRixPQUFPVCxPQUFPRCxLQUFLO0FBQUEsNEJBRXhEVTtBQUFBQSxxQ0FBT21GLGVBQWVuRixPQUFPQyxZQUFZO0FBQUEsOEJBQU07QUFBQSw4QkFDL0NELE9BQU9zRiwwQkFBMEI7QUFBQTtBQUFBO0FBQUEsMEJBSjdCdEYsT0FBT21GLGVBQWVuRixPQUFPVCxPQUFPRDtBQUFBQSwwQkFEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFNQTtBQUFBLHNCQUNEO0FBQUE7QUFBQTtBQUFBLGtCQXBETDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBcURBO0FBQUEsbUJBL0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0VBLEtBakVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa0VBO0FBQUEsY0FHQyxDQUFDekwsY0FBY0UsV0FBVyxDQUFDRixjQUFjRyxTQUN4Qyx1QkFBQyxTQUFJLFdBQVUsOERBQ2IsaUNBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSx1Q0FBQyw2QkFBMEIsV0FBVSx5Q0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEU7QUFBQSxnQkFDMUUsdUJBQUMsT0FBRSxXQUFVLFdBQVUsZ0RBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLHlGQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsbUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0EsSUFDRTZGLGlCQUNGLHVCQUFDLFNBQUksV0FBVSwwQ0FDYixpQ0FBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsSUFDRTBQLDZCQUE2Qi9LLFNBQVMsSUFDeEMsdUJBQUMsU0FBSSxXQUFVLFFBRWI7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUseUJBQXdCLG9DQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLG1DQUNaNko7QUFBQUEsc0JBQ0MxTyxZQUFZcUY7QUFBQUEsd0JBQ1YsQ0FBQ0MsS0FBSzBJLE1BQU0xSSxPQUFPMEksRUFBRVQsZ0JBQWdCO0FBQUEsd0JBQ3JDO0FBQUEsc0JBQ0Y7QUFBQSxvQkFDRixLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBT0E7QUFBQSx1QkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVlBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLHlCQUF3Qiw4QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSxzQ0FDWm1CO0FBQUFBLHNCQUNDMU8sWUFBWXFGO0FBQUFBLHdCQUNWLENBQUNDLEtBQUswSSxNQUFNMUksT0FBTzBJLEVBQUVSLGdCQUFnQjtBQUFBLHdCQUNyQztBQUFBLHNCQUNGO0FBQUEsb0JBQ0YsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU9BO0FBQUEsdUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFZQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSx3REFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSx5QkFBd0IsZ0NBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsc0NBQ1prQjtBQUFBQSxzQkFDQzFPLFlBQVlxRjtBQUFBQSx3QkFDVixDQUFDQyxLQUFLMEksTUFBTTFJLE9BQU8wSSxFQUFFUCxhQUFhO0FBQUEsd0JBQ2xDO0FBQUEsc0JBQ0Y7QUFBQSxvQkFDRixLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBT0E7QUFBQSx1QkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVlBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLG9EQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLHlCQUF3QixpQ0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSxvQ0FDWmlCO0FBQUFBLHNCQUNDMU8sWUFBWXFGO0FBQUFBLHdCQUNWLENBQUNDLEtBQUswSSxNQUFNMUksT0FBTzBJLEVBQUVOLGlCQUFpQjtBQUFBLHdCQUN0QztBQUFBLHNCQUNGO0FBQUEsb0JBQ0YsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU9BO0FBQUEsdUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFZQTtBQUFBLHFCQXBERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXFEQTtBQUFBLGdCQUdBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQU1rQztBQUFBQSxvQkFDTixTQUFTaEI7QUFBQUEsb0JBQ1QsaUJBQWlCO0FBQUEsb0JBQ2pCLGtCQUFrQjtBQUFBLG9CQUNsQixpQkFBaUI7QUFBQSxzQkFDZjtBQUFBLHNCQUNBO0FBQUEsc0JBQ0E7QUFBQSxzQkFDQTtBQUFBLG9CQUFRO0FBQUEsb0JBRVYsbUJBQW1CO0FBQUEsc0JBQ2pCbFgsT0FBT3NPO0FBQUFBLHNCQUNQdE8sT0FBT3dPO0FBQUFBLHNCQUNQaE0sY0FBY0UsWUFBWSxVQUN4QkYsY0FBY0UsWUFBWSxVQUN4QnVELGNBQWNtSSxhQUNkNUwsY0FBY0UsWUFBWSxTQUN4QixTQUNBO0FBQUEsc0JBQ05GLGNBQWNHO0FBQUFBLG9CQUFNO0FBQUE7QUFBQSxrQkFwQnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFxQkk7QUFBQSxtQkEvRU47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpRkEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsOERBQ2IsaUNBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSx1Q0FBQyw2QkFBMEIsV0FBVSx5Q0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEU7QUFBQSxnQkFDMUUsdUJBQUMsT0FBRSxXQUFVLFdBQVUsd0NBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLGlGQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsbUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxpQkF0TEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF3TEE7QUFBQSxZQUVEa0QsY0FBYyxnQkFDYix1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0VBQ2Y7QUFBQSx1Q0FBQyxXQUFRLFdBQVUsbUJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtDO0FBQUEsZ0JBQUc7QUFBQSxtQkFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBRUNtRCxxQkFDQyx1QkFBQyxTQUFJLFdBQVUsMENBQ2IsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZSxLQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBLElBQ0VGLG1CQUFtQkEsZ0JBQWdCcUUsU0FBUyxJQUM5Qyx1QkFBQyxTQUFJLFdBQVUsUUFFYjtBQUFBLHVDQUFDLFNBQUksV0FBVSw4Q0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxvREFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSx5QkFBd0IsOEJBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsb0NBQ1pyRSwwQkFBZ0JxRSxVQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFPQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSx3REFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSx5QkFBd0IsdUJBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsc0NBRVhyRSwwQkFBZ0JtTTtBQUFBQSxzQkFDZCxDQUFDb1IsTUFBTUEsRUFBRTVULFdBQVc7QUFBQSxvQkFDdEIsRUFBRXRGLFVBSk47QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFNQTtBQUFBLHVCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBV0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsc0RBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUseUJBQXdCLHdCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUVYckUsMEJBQWdCbU07QUFBQUEsc0JBQ2QsQ0FBQ29SLE1BQU1BLEVBQUU1VCxXQUFXO0FBQUEsb0JBQ3RCLEVBQUV0RixVQUpOO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTUE7QUFBQSx1QkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVdBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGtEQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLHlCQUF3Qix3QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSxtQ0FFWHJFLDBCQUFnQm1NO0FBQUFBLHNCQUNkLENBQUNvUixNQUFNQSxFQUFFNVQsV0FBVztBQUFBLG9CQUN0QixFQUFFdEYsVUFKTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU1BO0FBQUEsdUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFXQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSx3REFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSx5QkFBd0Isc0JBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsc0NBRVhyRSwwQkFBZ0JtTTtBQUFBQSxzQkFDZCxDQUFDb1IsTUFBTUEsRUFBRTVULFdBQVc7QUFBQSxvQkFDdEIsRUFBRXRGLFVBSk47QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFNQTtBQUFBLHVCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBV0E7QUFBQSxxQkF4REY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF5REE7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2IsaUNBQUMsV0FBTSxXQUFVLHlEQUNmO0FBQUEseUNBQUMsV0FBTSxXQUFVLGNBQ2YsaUNBQUMsUUFDQztBQUFBLDJDQUFDLFFBQUcsV0FBVSxrRkFBaUYsc0JBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsa0ZBQWlGLGdDQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsUUFBRyxXQUFVLGtGQUFpRiw0QkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFFBQUcsV0FBVSxrRkFBaUYsMEJBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsa0ZBQWlGLHNCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsUUFBRyxXQUFVLGtGQUFpRiw0QkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFFBQUcsV0FBVSxrRkFBaUYsNEJBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsa0ZBQWlGLHVCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsUUFBRyxXQUFVLGtGQUFpRixzQkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFFBQUcsV0FBVSxrRkFBaUYsdUJBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkErQkEsS0FoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFpQ0E7QUFBQSxrQkFDQSx1QkFBQyxXQUFNLFdBQVUsNEJBQ2RyRSwwQkFBZ0JrRjtBQUFBQSxvQkFBSSxDQUFDeU0sWUFBWXhNLFVBQ2hDO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUVDLFdBQVU7QUFBQSx3QkFFVjtBQUFBLGlEQUFDLFFBQUcsV0FBVSxtQ0FDWEEsa0JBQVEsS0FEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsMEJBQ0EsdUJBQUMsUUFBRyxXQUFVLCtDQUNYd00scUJBQVdwQixvQkFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsMEJBQ0EsdUJBQUMsUUFBRyxXQUFVLG1DQUNYb0IscUJBQVduQixnQkFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsMEJBQ0EsdUJBQUMsUUFBRyxXQUFVLG1DQUNYbUIscUJBQVdyTSxjQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSwwQkFDQSx1QkFBQyxRQUFHLFdBQVUsbUNBQ1hxTSxxQkFBV2hCLGlCQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSwwQkFDQSx1QkFBQyxRQUFHLFdBQVUsbUNBQ1hnQixxQkFBV2QsZ0JBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDBCQUNBLHVCQUFDLFFBQUcsV0FBVSxtQ0FDWGMscUJBQVdaLGdCQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSwwQkFDQTtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxXQUFXLGlDQUFpQ1ksV0FBV3pLLFdBQVcsSUFBSSxtQkFBbUIsY0FBYztBQUFBLDhCQUV0R3lLLHFCQUFXWDtBQUFBQTtBQUFBQSw0QkFIZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBSUE7QUFBQSwwQkFDQSx1QkFBQyxRQUFHLFdBQVUsYUFDWjtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxXQUFXO0FBQUEsd0JBQzdCVyxXQUFXVixpQkFBaUIsV0FBVyxrQ0FBa0MsRUFBRTtBQUFBLHdCQUMzRVUsV0FBV1YsaUJBQWlCLFVBQVUsZ0NBQWdDLEVBQUU7QUFBQSx3QkFDeEVVLFdBQVdWLGlCQUFpQixRQUFRLDRCQUE0QixFQUFFO0FBQUEsd0JBQ2xFVSxXQUFXVixpQkFBaUIsU0FBUyw4QkFBOEIsRUFBRTtBQUFBLHdCQUNyRVUsV0FBV1YsaUJBQWlCLFdBQVcsa0NBQWtDLEVBQUU7QUFBQSw4QkFFeERVLHFCQUFXaEk7QUFBQUE7QUFBQUEsNEJBUmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FXQTtBQUFBLDBCQUNBLHVCQUFDLFFBQUcsV0FBVSxhQUNaO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLFNBQVMsTUFDUCtILHNCQUFzQkMsVUFBVTtBQUFBLDhCQUVsQyxXQUFVO0FBQUEsOEJBRVY7QUFBQSx1REFBQyxTQUFNLE1BQU0sTUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUFnQjtBQUFBLGdDQUFHO0FBQUE7QUFBQTtBQUFBLDRCQU5yQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQVVBO0FBQUE7QUFBQTtBQUFBLHNCQW5ES0EsV0FBV3ZNO0FBQUFBLHNCQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQXFEQTtBQUFBLGtCQUNELEtBeERIO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBeURBO0FBQUEscUJBNUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBNkZBLEtBOUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBK0ZBO0FBQUEsbUJBN0pGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBOEpBLElBRUEsdUJBQUMsU0FBSSxXQUFVLDhEQUNiLGlDQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsdUNBQUMsV0FBUSxXQUFVLHlDQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RDtBQUFBLGdCQUN4RCx1QkFBQyxPQUFFLFdBQVUsV0FBVSx1REFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsZ0VBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGlCQXJMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVMQTtBQUFBLFlBR0RySSxjQUFjLGFBQ2IsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdFQUNmO0FBQUEsdUNBQUMsWUFBUyxXQUFVLG1CQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtQztBQUFBLGdCQUFHO0FBQUEsbUJBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUVDMkQsaUJBQ0MsdUJBQUMsU0FBSSxXQUFVLDBDQUNiLGlDQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWUsS0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQSxJQUNFRixlQUFlQSxZQUFZNkQsU0FBUyxJQUN0Qyx1QkFBQyxTQUFJLFdBQVUsUUFFYjtBQUFBLHVDQUFDLFNBQUksV0FBVSw4Q0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxvREFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSx5QkFBd0IsNEJBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsb0NBQ1o3RCxzQkFBWTZELFVBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBT0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsc0RBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUseUJBQXdCLGdDQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUVYN0Qsc0JBQVkyTDtBQUFBQSxzQkFDVixDQUFDZ0csTUFBTUEsRUFBRXhJLFdBQVc7QUFBQSxvQkFDdEIsRUFBRXRGLFVBSk47QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFNQTtBQUFBLHVCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBV0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUseUJBQXdCLHVDQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHNDQUVYN0Qsc0JBQVkyTDtBQUFBQSxzQkFDVixDQUFDZ0csTUFBTUEsRUFBRXNCLFlBQVk7QUFBQSxvQkFDdkIsRUFBRXBQLFVBSk47QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFNQTtBQUFBLHVCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBV0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUseUJBQXdCLHlDQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHNDQUVYN0Qsc0JBQVkyTDtBQUFBQSxzQkFDVixDQUFDZ0csTUFBTUEsRUFBRXNCLFlBQVk7QUFBQSxvQkFDdkIsRUFBRXBQLFVBSk47QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFNQTtBQUFBLHVCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBV0E7QUFBQSxxQkE1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE2Q0E7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2IsaUNBQUMsV0FBTSxXQUFVLHlEQUNmO0FBQUEseUNBQUMsV0FBTSxXQUFVLGNBQ2YsaUNBQUMsUUFDRTZQO0FBQUFBLG1DQUFlaFA7QUFBQUEsc0JBQUksQ0FBQ3NZLFFBQ25CO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUVDLFdBQVU7QUFBQSwwQkFFVEEsY0FBSS9aO0FBQUFBO0FBQUFBLHdCQUhBK1osSUFBSWhhO0FBQUFBLHdCQURYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBS0E7QUFBQSxvQkFDRDtBQUFBLG9CQUNELHVCQUFDLFFBQUcsV0FBVSwyRkFBMEYsdUJBQXhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVlBLEtBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFjQTtBQUFBLGtCQUNBLHVCQUFDLFdBQU0sV0FBVSw0QkFDZGhELHNCQUFZMEU7QUFBQUEsb0JBQUksQ0FBQytPLFNBQVM5TyxVQUN6QjtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFFQyxXQUFVO0FBQUEsd0JBRVY7QUFBQSxpREFBQyxRQUFHLFdBQVUsbUNBQ1hBLGtCQUFRLEtBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDBCQUNBLHVCQUFDLFFBQUcsV0FBVSwrQ0FDWDhPLGtCQUFRWCxnQkFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsMEJBRUEsdUJBQUMsUUFBRyxXQUFVLG1DQUNYVyxrQkFBUTFPLFFBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDBCQUNBLHVCQUFDLFFBQUcsV0FBVSxtQ0FDWDBPLGtCQUFRVixTQURYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSwwQkFDQSx1QkFBQyxRQUFHLFdBQVUsbUNBQ1hVLGtCQUFRVCxTQURYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSwwQkFDQSx1QkFBQyxRQUFHLFdBQVUsYUFDWixpQ0FBQyxVQUFLLFdBQVUscUdBQ2JTLGtCQUFRUixXQURYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUlBO0FBQUEsMEJBQ0EsdUJBQUMsUUFBRyxXQUFVLG1DQUNYUSxrQkFBUU4sa0JBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDBCQUNBLHVCQUFDLFFBQUcsV0FBVSxtQ0FDWE0sa0JBQVFKLGVBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDBCQUNBLHVCQUFDLFFBQUcsV0FBVSxhQUNaO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLFdBQVc7QUFBQSx3QkFDN0JJLFFBQVF0SyxXQUFXLGNBQWMsZ0NBQWdDLCtCQUErQjtBQUFBLDhCQUU3RXNLLGtCQUFRdEs7QUFBQUE7QUFBQUEsNEJBSlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FPQTtBQUFBLDBCQUNBLHVCQUFDLFFBQUcsV0FBVSxhQUNaO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLFNBQVMsTUFDUHFLLG1CQUFtQkMsT0FBTztBQUFBLDhCQUU1QixXQUFVO0FBQUEsOEJBRVY7QUFBQSx1REFBQyxTQUFNLE1BQU0sTUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUFnQjtBQUFBLGdDQUFHO0FBQUE7QUFBQTtBQUFBLDRCQU5yQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQVVBO0FBQUE7QUFBQTtBQUFBLHNCQWhES0EsUUFBUTdPO0FBQUFBLHNCQURmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBa0RBO0FBQUEsa0JBQ0QsS0FyREg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFzREE7QUFBQSxxQkF0RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF1RUEsS0F4RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF5RUE7QUFBQSxnQkFFQzVFLFlBQVlpZDtBQUFBQSxrQkFDWCxDQUFDdEwsTUFBTUEsRUFBRXVCLGVBQWV2QixFQUFFdUIsZ0JBQWdCO0FBQUEsZ0JBQzVDLEtBQ0ksdUJBQUMsU0FBSSxXQUFVLDBDQUF5QyxzRkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLG1CQW5JTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFJQSxJQUVBLHVCQUFDLFNBQUksV0FBVSw4REFDYixpQ0FBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLHVDQUFDLFlBQVMsV0FBVSx5Q0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUQ7QUFBQSxnQkFDekQsdUJBQUMsT0FBRSxXQUFVLFdBQVUsMERBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLHNFQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsbUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxpQkE3Sko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkErSkE7QUFBQSxlQXZsRUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5bEVBLEtBMWxFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTJsRUE7QUFBQSxhQS9uRUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlvRUE7QUFBQSxXQXJvRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNvRUE7QUFBQSxTQTNvRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRvRUEsS0E3b0VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4b0VBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FDRSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsbUVBQ2IsaUNBQUMsZUFBWSxXQUFVLDJCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QyxLQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHlCQUF3QixpQ0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUQ7QUFBQSxZQUN6RCx1QkFBQyxPQUFFLFdBQVUsNENBQTJDLHNEQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUVGLE1BQU05VDtBQUFBQSxRQUNOLFVBQVUsTUFBTTtBQUNkQyxtQ0FBeUIsS0FBSztBQUM5QkUsNkJBQW1CLElBQUk7QUFBQSxRQUN6QjtBQUFBLFFBQ0EsT0FBTztBQUFBLFFBQ1AsUUFBUTtBQUFBLFVBQ047QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLFNBQVMsTUFBTTtBQUNiRix5Q0FBeUIsS0FBSztBQUM5QkUsbUNBQW1CLElBQUk7QUFBQSxjQUN6QjtBQUFBLGNBQUU7QUFBQTtBQUFBLFlBSkU7QUFBQSxZQUROO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLFFBQVM7QUFBQSxRQUdWRCw2QkFDQyx1QkFBQyxTQUFJLFdBQVUsYUFFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLHFDQUFDLE9BQUUsV0FBVSxpREFBZ0QsOEJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLGlCQUNaQSwwQkFBZ0IwTSxhQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUF3QjtBQUFBO0FBQUEsa0JBQzVCMU0sZ0JBQWdCakc7QUFBQUEscUJBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsaUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDRCQUNiO0FBQUEscUNBQUMsT0FBRSxXQUFVLGlEQUFnRCw2QkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLG1DQUNacVUsOEJBQW9CcE8sZ0JBQWdCaU4sWUFBWSxLQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEscUNBQUMsT0FBRSxXQUFVLGlEQUFnRCw4QkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHNDQUNabUIsOEJBQW9CcE8sZ0JBQWdCa04sWUFBWSxLQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEscUNBQUMsT0FBRSxXQUFVLGlEQUFnRCwrQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHNDQUNaa0IsOEJBQW9CcE8sZ0JBQWdCb04sYUFBYSxLQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLGVBckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0NBO0FBQUEsVUFHQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsUUFBRyxXQUFVLG9DQUFtQyw0Q0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0N1Qyx1QkFBdUJwTCxTQUFTLElBQy9CO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBU2dLO0FBQUFBLGdCQUNULFlBQVlvQjtBQUFBQSxnQkFDWixZQUFZLEVBQUVpTyxVQUFVLEdBQUc7QUFBQSxnQkFDM0IsTUFBSztBQUFBO0FBQUEsY0FKUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJZSxJQUdmLHVCQUFDLFNBQUksV0FBVSwwQ0FDYixpQ0FBQyxPQUFFLFdBQVUsaUJBQWdCLHVDQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRCxLQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFkSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLGFBM0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0REE7QUFBQTtBQUFBLE1BN0ZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQStGQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQ0UsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaUNBQUMsV0FBUSxXQUFVLG1CQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQztBQUFBLFVBQ2xDLHVCQUFDLFVBQUssV0FBVSx5QkFBd0IsbUNBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJEO0FBQUEsYUFGN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFRixNQUFNdGQ7QUFBQUEsUUFDTixVQUFVLE1BQU1DLDBCQUEwQixLQUFLO0FBQUEsUUFDL0MsUUFBUTtBQUFBLFVBQ04sdUJBQUMsVUFBbUIsU0FBUyxNQUFNQSwwQkFBMEIsS0FBSyxHQUFHLHFCQUF6RCxTQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxRQUFTO0FBQUEsUUFFWCxPQUFPO0FBQUEsUUFDUCxXQUFXLEVBQUVzZCxTQUFTLE9BQU87QUFBQSxRQUU1QnJkLGdDQUNDLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSxtQ0FBa0MsZ0NBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSx1Q0FDVkEsNkJBQW1CaVEsb0JBRHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSxtQ0FBa0MsMEJBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlEO0FBQUEsWUFDekQsdUJBQUMsT0FBRSxXQUFVLHVDQUNWalEsNkJBQW1CZ0YsY0FEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLG1DQUFrQyw2QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEQ7QUFBQSxZQUM1RCx1QkFBQyxPQUFFLFdBQVUsdUNBQ1ZoRiw2QkFBbUJxUSxpQkFEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLG1DQUFrQyw0QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkQ7QUFBQSxZQUMzRCx1QkFBQyxPQUFFLFdBQVUsdUNBQ1ZyUSw2QkFBbUJrUSxnQkFEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLG1DQUFrQyw0QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkQ7QUFBQSxZQUMzRCx1QkFBQyxPQUFFLFdBQVUsdUNBQ1ZsUSw2QkFBbUJ1USxnQkFEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLG1DQUFrQyw0QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkQ7QUFBQSxZQUMzRCx1QkFBQyxPQUFFLFdBQVUsdUNBQ1Z2USw2QkFBbUJ5USxnQkFEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLG1DQUFrQywrQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEQ7QUFBQSxZQUM5RDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVcseUJBQXlCelEsbUJBQW1CNEcsV0FBVyxJQUFJLG1CQUFtQixjQUFjO0FBQUEsZ0JBRXRHNUcsNkJBQW1CMFE7QUFBQUE7QUFBQUEsY0FIdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSxtQ0FBa0Msc0JBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFEO0FBQUEsWUFDckQ7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXO0FBQUEsWUFDZjFRLG1CQUFtQjJRLGlCQUFpQixXQUFXLGtDQUFrQyxFQUFFO0FBQUEsWUFDbkYzUSxtQkFBbUIyUSxpQkFBaUIsVUFBVSxnQ0FBZ0MsRUFBRTtBQUFBLFlBQ2hGM1EsbUJBQW1CMlEsaUJBQWlCLFFBQVEsNEJBQTRCLEVBQUU7QUFBQSxZQUMxRTNRLG1CQUFtQjJRLGlCQUFpQixTQUFTLDhCQUE4QixFQUFFO0FBQUEsWUFDN0UzUSxtQkFBbUIyUSxpQkFBaUIsV0FBVyxrQ0FBa0MsRUFBRTtBQUFBLGdCQUU5RTNRLDZCQUFtQnFKO0FBQUFBO0FBQUFBLGNBUnRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVNBO0FBQUEsZUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsbUNBQWtDLDJCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRDtBQUFBLFlBQzFELHVCQUFDLE9BQUUsV0FBVSx1Q0FDVnJKLDZCQUFtQjRRLGVBRHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSxtQ0FBa0Msa0NBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSx1Q0FDVjVRLDZCQUFtQjZRLGNBRHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSxtQ0FBa0MsNkJBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTREO0FBQUEsWUFDNUQsdUJBQUMsT0FBRSxXQUFVLHVDQUNWN1EsNkJBQW1CK1EsaUJBRHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxhQS9FRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0ZBO0FBQUE7QUFBQSxNQWxHSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFvR0E7QUFBQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUNFLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGlDQUFDLFlBQVMsV0FBVSxtQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUM7QUFBQSxVQUNuQyx1QkFBQyxVQUFLLFdBQVUseUJBQXdCLCtCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RDtBQUFBLGFBRnpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRUYsTUFBTXpRO0FBQUFBLFFBQ04sVUFBVSxNQUFNQyx1QkFBdUIsS0FBSztBQUFBLFFBQzVDLFFBQVE7QUFBQSxVQUNOLHVCQUFDLFVBQW1CLFNBQVMsTUFBTUEsdUJBQXVCLEtBQUssR0FBRyxxQkFBdEQsU0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsUUFBUztBQUFBLFFBRVgsT0FBTztBQUFBLFFBQ1AsV0FBVyxFQUFFOGMsU0FBUyxPQUFPO0FBQUEsUUFFNUI3Yyw2QkFDQyx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsbUNBQWtDLDRCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRDtBQUFBLFlBQzNELHVCQUFDLE9BQUUsV0FBVSx1Q0FDVkEsMEJBQWdCd1MsZ0JBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSxtQ0FBa0MsMEJBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlEO0FBQUEsWUFDekQsdUJBQUMsT0FBRSxXQUFVLHVDQUNWeFMsMEJBQWdCOGMsYUFEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLG1DQUFrQyw0QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkQ7QUFBQSxZQUMzRCx1QkFBQyxPQUFFLFdBQVUsdUNBQ1Y5YywwQkFBZ0J5RSxRQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsbUNBQWtDLDRCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRDtBQUFBLFlBQzNELHVCQUFDLE9BQUUsV0FBVSx1Q0FDVnpFLDBCQUFnQnlTLFNBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSxtQ0FBa0MscUJBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9EO0FBQUEsWUFDcEQsdUJBQUMsT0FBRSxXQUFVLHVDQUNWelMsMEJBQWdCMFMsU0FEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLG1DQUFrQyx1QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0Q7QUFBQSxZQUN0RCx1QkFBQyxPQUFFLFdBQVUsdUNBQ1YxUywwQkFBZ0IyUyxXQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsbUNBQWtDLGlDQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsdUNBQ1YzUywwQkFBZ0I2UyxrQkFEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLG1DQUFrQyw0QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkQ7QUFBQSxZQUMzRCx1QkFBQyxPQUFFLFdBQVUsdUNBQ1Y3UywwQkFBZ0IrUyxlQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsbUNBQWtDLDJCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRDtBQUFBLFlBQzFELHVCQUFDLE9BQUUsV0FBVSx1Q0FDVi9TLDBCQUFnQjRTLGVBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSxtQ0FBa0MsMEJBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlEO0FBQUEsWUFDekQsdUJBQUMsT0FBRSxXQUFVLHVDQUNWNVMsMEJBQWdCd0UsY0FEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLG1DQUFrQyw2QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEQ7QUFBQSxZQUM1RCx1QkFBQyxPQUFFLFdBQVUsdUNBQ1Z4RSwwQkFBZ0I2UCxpQkFEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLG1DQUFrQyxzQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUQ7QUFBQSxZQUNyRDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVc7QUFBQSxZQUNmN1AsZ0JBQWdCNkksV0FBVyxjQUFjLGdDQUFnQywrQkFBK0I7QUFBQSxnQkFFbkc3SSwwQkFBZ0I2STtBQUFBQTtBQUFBQSxjQUpuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLGVBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLGFBN0VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE4RUE7QUFBQTtBQUFBLE1BaEdKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWtHQTtBQUFBLE9BMTdFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMjdFQTtBQUVKO0FBQUV2VCxHQWx5SUlELFlBQVU7QUFBQSxVQUNTckIsZUFBZTtBQUFBO0FBQUErb0IsS0FEbEMxbkI7QUFveUlOLGVBQWVBO0FBQVcsSUFBQTBuQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VSZWYiLCJhcGkiLCJEYXRhVGFibGUiLCJDaXJjdWxhckxvYWRlciIsIkN1c3RvbWVyUmVwb3J0UHJpbnQiLCJEcm9wZG93biIsIlNlbGVjdCIsIkJ1dHRvbiIsIk1vZGFsIiwiVGFnIiwiVGFibGUiLCJBbnRUYWJsZSIsIk5hdmJhciIsImZpbHRlck9wdGlvbiIsIkxpbmsiLCJ1c2VTZWFyY2hQYXJhbXMiLCJGaVJlZnJlc2hDY3ciLCJGaVNlYXJjaCIsIklvTWREb3dubG9hZCIsIklvTWRNb3JlIiwiTWRBY2NvdW50QmFsYW5jZVdhbGxldCIsIk1kR2F2ZWwiLCJNZFBlb3BsZSIsIkZ1c2UiLCJkYXlqcyIsIm51bWJlclRvSW5kaWFuV29yZHMiLCJGaVVzZXIiLCJGaUJvb2tPcGVuIiwiRmlGaWxlVGV4dCIsIkZpUmVwZWF0IiwiRmlDcmVkaXRDYXJkIiwiRmFSdXBlZVNpZ24iLCJGYUV4Y2xhbWF0aW9uQ2lyY2xlIiwiRmFFeWUiLCJFeWVPdXRsaW5lZCIsIkV4Y2xhbWF0aW9uQ2lyY2xlT3V0bGluZWQiLCJVc2VyUmVwb3J0IiwiX3MiLCJzZWFyY2hQYXJhbXMiLCJ1c2VySWQiLCJnZXQiLCJncm91cHMiLCJzZXRHcm91cHMiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJUYWJsZURheWJvb2siLCJzZXRUYWJsZURheWJvb2siLCJUYWJsZUF1Y3Rpb25zIiwic2V0VGFibGVBdWN0aW9ucyIsInNlbGVjdGVkR3JvdXAiLCJzZXRTZWxlY3RlZEdyb3VwIiwiZ3JvdXAiLCJzZXRHcm91cCIsImNvbW1pc3Npb24iLCJzZXRDb21taXNzaW9uIiwiVGFibGVFbnJvbGxzIiwic2V0VGFibGVFbnJvbGxzIiwiVGFibGVFbnJvbGxzRGF0ZSIsInNldFRhYmxlRW5yb2xsc0RhdGUiLCJmaWx0ZXJlZFVzZXJzIiwic2V0RmlsdGVyZWRVc2VycyIsImdyb3VwUGFpZCIsInNldEdyb3VwUGFpZCIsImdyb3VwVG9CZVBhaWQiLCJzZXRHcm91cFRvQmVQYWlkIiwiY3VzdG9tZXJUcmFuc2FjdGlvbnMiLCJzZXRDdXN0b21lclRyYW5zYWN0aW9ucyIsImFjY291bnREZXRhaWxzIiwic2V0QWNjb3VudERldGFpbHMiLCJhY2NvdW50RGV0YWlsc0xvYWRpbmciLCJzZXRBY2NvdW50RGV0YWlsc0xvYWRpbmciLCJmcm9tRGF0ZSIsInNldEZyb21EYXRlIiwidG9kYXkiLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsInRvRGF0ZSIsInNldFRvRGF0ZSIsInRvdGFsQW1vdW50Iiwic2V0VG90YWxBbW91bnQiLCJncm91cFBhaWREYXRlIiwic2V0R3JvdXBQYWlkRGF0ZSIsImdyb3VwVG9CZVBhaWREYXRlIiwic2V0R3JvdXBUb0JlUGFpZERhdGUiLCJkZXRhaWxzTG9hZGluZyIsInNldERldGFpbExvYWRpbmciLCJiYXNpY0xvYWRpbmciLCJzZXRCYXNpY0xvYWRpbmciLCJkYXRlTG9hZGluZyIsInNldERhdGVMb2FkaW5nIiwiRW5yb2xsR3JvdXBJZCIsInNldEVucm9sbEdyb3VwSWQiLCJncm91cElkIiwidGlja2V0IiwicmVnaXN0cmF0aW9uRmVlIiwic2V0UmVnaXN0cmF0aW9uRmVlIiwiYW1vdW50IiwiY3JlYXRlZEF0IiwidmlzaWJsZVJvd3MiLCJzZXRWaXNpYmxlUm93cyIsInJvdzEiLCJyb3cyIiwicm93MyIsInJvdzQiLCJyb3c1Iiwicm93NiIsInJvdzciLCJyb3c4Iiwicm93OSIsInZpZXciLCJzZXRWaWV3IiwiSW5wdXQiLCJsYWJlbCIsInZhbHVlIiwiVG90YWxUb0JlcGFpZCIsInNldFRvdGFsVG9CZVBhaWQiLCJUb3RhbHBhaWQiLCJzZXRUb3RhbFBhaWQiLCJUb3RhbHByb2ZpdCIsInNldFRvdGFsUHJvZml0IiwiaXNGZXRjaGluZ1BlbmFsdHkiLCJOZXRUb3RhbHByb2ZpdCIsInNldE5ldFRvdGFsUHJvZml0Iiwic2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCIsInNldFNlbGVjdGVkQXVjdGlvbkdyb3VwSWQiLCJzZWxlY3RlZEVucm9sbG1lbnRzIiwic2V0U2VsZWN0ZWRFbnJvbGxtZW50cyIsImdyb3VwSW5mbyIsInNldEdyb3VwSW5mbyIsInNlbGVjdGVkRnJvbURhdGUiLCJzZXRTZWxlY3RlZEZyb21EYXRlIiwic2VsZWN0ZWRUb0RhdGUiLCJzZXRTZWxlY3RlZFRvRGF0ZSIsInNlbGVjdGVkUGF5bWVudE1vZGUiLCJzZXRTZWxlY3RlZFBheW1lbnRNb2RlIiwic2VsZWN0ZWRDdXN0b21lcnMiLCJzZXRTZWxlY3RlZEN1c3RvbWVycyIsInBheW1lbnRzIiwic2V0UGF5bWVudHMiLCJhdmFpbGFibGVUaWNrZXRzIiwic2V0QXZhaWxhYmxlVGlja2V0cyIsInNjcmVlbkxvYWRpbmciLCJzZXRTY3JlZW5Mb2FkaW5nIiwiYWN0aXZlVGFiIiwic2V0QWN0aXZlVGFiIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJncm91cERldGFpbHMiLCJzZXRHcm91cERldGFpbHMiLCJsb2FuQ3VzdG9tZXJzIiwic2V0TG9hbkN1c3RvbWVycyIsInBpZ21lQ3VzdG9tZXJzIiwic2V0UGlnbWVDdXN0b21lcnMiLCJwaWdtZUN1c3RvbWVyRGF0YSIsInNldFBpZ21lQ3VzdG9tZXJEYXRhIiwicGlnbWVJZCIsInNldFBpZ21lSWQiLCJmaWx0ZXJlZFBpZ21lRGF0YSIsInNldEZpbHRlcmVkUGlnbWVEYXRhIiwiYm9ycm93ZXJzRGF0YSIsInNldEJvcnJvd2Vyc0RhdGEiLCJib3Jyb3dlcklkIiwic2V0Qm9ycm93ZXJJZCIsImZpbHRlcmVkQm9ycm93ZXJEYXRhIiwic2V0RmlsdGVyZWRCb3Jyb3dlckRhdGEiLCJmaWx0ZXJlZERpc2J1cnNlbWVudCIsInNldEZpbHRlcmVkRGlzYnVyc2VtZW50IiwiZGlzYnVyc2VtZW50TG9hZGluZyIsInNldERpc2J1cnNlbWVudExvYWRpbmciLCJzdGF0ZW1lbnRMb2FkaW5nIiwic2V0U3RhdGVtZW50TG9hZGluZyIsInRyYW5zYWN0aW9uc0xvYWRpbmciLCJzZXRUcmFuc2FjdGlvbnNMb2FkaW5nIiwicmVnaXN0cmF0aW9uQW1vdW50Iiwic2V0UmVnaXN0cmF0aW9uQW1vdW50IiwicmVnaXN0cmF0aW9uRGF0ZSIsInNldFJlZ2lzdHJhdGlvbkRhdGUiLCJmaW5hbFBheW1lbnRCYWxhbmNlIiwic2V0RmluYWxQYXltZW50QmFsYW5jZSIsInNlbGVjdGVkTGFiZWwiLCJzZXRTZWxlY3RlZExhYmVsIiwic2hvd0ZpbHRlckZpZWxkIiwic2V0U2hvd0ZpbHRlckZpZWxkIiwidG9kYXlTdHJpbmciLCJwZW5hbHR5RGF0YSIsInNldFBlbmFsdHlEYXRhIiwicGVuYWx0eUxvYWRpbmciLCJzZXRQZW5hbHR5TG9hZGluZyIsImJyZWFrZG93bk1vZGFsVmlzaWJsZSIsInNldEJyZWFrZG93bk1vZGFsVmlzaWJsZSIsInNlbGVjdGVkUGVuYWx0eSIsInNldFNlbGVjdGVkUGVuYWx0eSIsImJpZFJlcXVlc3RzRGF0YSIsInNldEJpZFJlcXVlc3RzRGF0YSIsImJpZFJlcXVlc3RzTG9hZGluZyIsInNldEJpZFJlcXVlc3RzTG9hZGluZyIsImJpZFJlcXVlc3RNb2RhbFZpc2libGUiLCJzZXRCaWRSZXF1ZXN0TW9kYWxWaXNpYmxlIiwic2VsZWN0ZWRCaWRSZXF1ZXN0Iiwic2V0U2VsZWN0ZWRCaWRSZXF1ZXN0IiwidmlzaXRvckRhdGEiLCJzZXRWaXNpdG9yRGF0YSIsInZpc2l0b3JMb2FkaW5nIiwic2V0VmlzaXRvckxvYWRpbmciLCJ2aXNpdG9yTW9kYWxWaXNpYmxlIiwic2V0VmlzaXRvck1vZGFsVmlzaWJsZSIsInNlbGVjdGVkVmlzaXRvciIsInNldFNlbGVjdGVkVmlzaXRvciIsImhpZGVBY2NvdW50VHlwZSIsInNldEhpZGVBY2NvdW50VHlwZSIsInNlbGVjdGVkQWNjb3VudFR5cGUiLCJzZXRTZWxlY3RlZEFjY291bnRUeXBlIiwic2VsZWN0ZWRQYXltZW50Rm9yIiwic2V0U2VsZWN0ZWRQYXltZW50Rm9yIiwic2hvd0FsbFBheW1lbnRNb2RlcyIsInNldFNob3dBbGxQYXltZW50TW9kZXMiLCJ0cmFuc2FjdGlvbnNUYWJsZSIsInNldFRyYW5zYWN0aW9uc1RhYmxlIiwidG90YWxUcmFuc2FjdGlvbnMiLCJzZXRUb3RhbFRyYW5zYWN0b25zIiwidG90YWxUcmFuc2FjdGlvbkFtb3VudCIsInNldFRvdGFsVHJhbnNhY3Rpb25BbW91bnQiLCJlbnJvbGxtZW50RGF0YSIsInNldEVucm9sbG1lbnREYXRhIiwiYWN0aXZlRW5yb2xsbWVudERhdGEiLCJzZXRBY3RpdmVFbnJvbGxtZW50RGF0YSIsImVucm9sbG1lbnREYXRhTG9hZGluZyIsInNldEVucm9sbG1lbnREYXRhTG9hZGluZyIsInRyYW5zZmVySGlzdG9yeUxvYWRpbmciLCJzZXRUcmFuc2Zlckhpc3RvcnlMb2FkaW5nIiwidHJhbnNmZXJIaXN0b3J5Iiwic2V0VHJhbnNmZXJIaXN0b3J5IiwiZW5yb2xsbWVudElkIiwic2V0RW5yb2xsbWVudElkIiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInRhcmdldCIsImhhbmRsZVRhYkNoYW5nZSIsInRhYiIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJncm91cF9pZCIsInVzZXJfaWQiLCJyZWNlaXB0X25vIiwicGF5X2RhdGUiLCJwYXlfdHlwZSIsInRyYW5zYWN0aW9uX2lkIiwiQmFzaWNMb2FuQ29sdW1ucyIsImtleSIsImhlYWRlciIsIkJhc2ljUGlnbWVDb2x1bW5zIiwiRGlzYnVyc2VtZW50Q29sdW1ucyIsIlRyYW5zZmVySGlzdG9yeUNvbHVtbnMiLCJUcmFuc2FjdGlvbnNDb2x1bW5zIiwidXNlRWZmZWN0IiwiYWJvcnRDb250cm9sbGVyIiwiQWJvcnRDb250cm9sbGVyIiwiZmV0Y2hQYXltZW50cyIsInF1ZXJ5UGFyYW1zIiwiZnJvbV9kYXRlIiwidG9fZGF0ZSIsImxlbmd0aCIsImFjY291bnRfdHlwZSIsInBheV9mb3IiLCJyZXNwb25zZSIsInBhcmFtcyIsInNpZ25hbCIsImRhdGEiLCJ0b3RhbFN1bSIsInJlZHVjZSIsInN1bSIsIml0ZW0iLCJOdW1iZXIiLCJmb3JtYXR0ZWREYXRhIiwibWFwIiwiaW5kZXgiLCJfaWQiLCJpZCIsImdyb3VwX25hbWUiLCJuYW1lIiwiZnVsbF9uYW1lIiwiY2F0ZWdvcnkiLCJwaG9uZV9udW1iZXIiLCJsb2FuIiwibG9hbl9pZCIsInBpZ21lIiwicGlnbWVfaWQiLCJyZWNlaXB0Iiwib2xkX3JlY2VpcHRfbm8iLCJkYXRlIiwidHJhbnNhY3Rpb25fZGF0ZSIsIm1vZGUiLCJjb2xsZWN0aW9uX3RpbWUiLCJjb2xsZWN0ZWRfYnkiLCJhZG1pbl90eXBlIiwiYWRtaW5fbmFtZSIsImFjdGlvbiIsIml0ZW1zIiwiY29uc29sZSIsIndhcm4iLCJlcnJvciIsImFib3J0IiwiZmV0Y2hSZWdpc3RyYXRpb25GZWUiLCJyZWdpc3RyYXRpb25GZWVzIiwiZ3JvdXBQYWlkQW1vdW50IiwidG90YWxUb0JlUGFpZEFtb3VudCIsImJhbGFuY2UiLCJwYXltZW50IiwiZm9ybWF0UGF5RGF0ZSIsIm9sZF9yZWNlaXB0IiwidHlwZSIsInRvdGFsUmVnQW1vdW50IiwiZm9yRWFjaCIsInJlZ0ZlZSIsImlkeCIsInB1c2giLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJmZXRjaFRyYW5zZmVySGlzdG9yeSIsInRyYW5zZmVyX2NvZGUiLCJlbnJvbGxfdHJhbnNmZXJfaGlzdG9yeV9jb2RlIiwiZnJvbV9jdXN0b21lciIsImZyb21fZW5yb2xsbWVudCIsImZyb21fcGhvbmUiLCJmcm9tX2dyb3VwIiwiZnJvbV90aWNrZXQiLCJ0aWNrZXRzIiwidG9fY3VzdG9tZXIiLCJ0b19lbnJvbGxtZW50IiwidG9fcGhvbmUiLCJ0b19ncm91cCIsInRvX3RpY2tldCIsInRyYW5zZmVyX2Ftb3VudCIsImRlZHVjdGlvbl9hbW91bnQiLCJuZXRfdHJhbnNmZXJyZWRfYW1vdW50IiwiYWRtaW4iLCJyZWFzb24iLCJ0cmFuc2Zlcl9kYXRlIiwiZmV0Y2hBbGxMb2FuUGF5bWVudHNieUlkIiwic2VsZWN0ZWRMb2FuIiwib3ZlcmFsbF9sb2FuIiwiZmluZCIsImxvYW5fZGV0YWlscyIsImxvYW5JZCIsImxvYW5QYXltZW50IiwiZmV0Y2hBbGxQaWdtZVBheW1lbnRzYnlJZCIsInBpZ21lUGF5bWVudCIsImZldGNoR3JvdXBCeUlkIiwic3RhdHVzIiwiRXJyb3IiLCJlcnIiLCJsb2ciLCJtZXNzYWdlIiwiZmV0Y2hHcm91cHMiLCJmZXRjaEJvcnJvd2VyIiwic2xfbm8iLCJzdGFydF9kYXRlIiwiZW5kX2RhdGUiLCJsb2FuX2Ftb3VudCIsImxvYW5fdmFsdWUiLCJ0ZW51cmUiLCJzZXJ2aWNlX2NoYXJnZSIsInNlcnZpY2VfY2hhcmdlcyIsImxhdGVfZmVlIiwiZXh0cmFfY2hhcmdlcyIsImNoYXJnZSIsInRvdGFsX3BhaWRfYW1vdW50IiwiZmV0Y2hQaWdtZSIsIm92ZXJhbGxfcGlnbWUiLCJwaWdtZV9kZXRhaWxzIiwiZHVyYXRpb24iLCJtYXR1cml0eV9pbnRlcmVzdCIsInRvdGFsX2RlcG9zaXRlZF9hbW91bnQiLCJmZXRjaERpc2J1cnNlbWVudCIsImRpc2J1cnNlbWVudF90eXBlIiwiZGlzYnVyc2VkX2J5IiwiaGFuZGxlR3JvdXBQYXltZW50IiwiaGFuZGxlR3JvdXBBdWN0aW9uQ2hhbmdlIiwiaGFuZGxlRW5yb2xsR3JvdXAiLCJldmVudCIsImZldGNoQ3VzdG9tZXJUcmFuc2FjdGlvbiIsImluZm8iLCJwYXltZW50RGF0YSIsImdldEFjdGl2ZUN1c3RvbWVyRW5yb2xsbWVudERhdGEiLCJyZXNwb25zZURhdGEiLCJmZXRjaEFjY291bnREZXRhaWxzIiwiZmlsdGVyZWRMZWRnZXJEYXRhIiwidXNlcmFjY291bnRzIiwiZmlsdGVyIiwiZmV0Y2hDdXN0b21lclBlbmFsdHkiLCJjdXJyZW50Iiwic3VjY2VzcyIsImZvcm1hdHRlZFBlbmFsdHkiLCJncm91cE5hbWUiLCJjdXN0b21lck5hbWUiLCJ1c2VyIiwiY3VzdG9tZXJQaG9uZSIsInRvdGFsRXhwZWN0ZWQiLCJzdW1tYXJ5IiwidG90YWxQYWlkIiwidG90YWxQZW5hbHR5IiwidG90YWxMYXRlRmVlIiwidmNQZW5hbHR5IiwiZ3JhbmRUb3RhbER1ZSIsInRvdGFsRHVlIiwiYmFsYW5jZVdpdGhvdXRQZW5hbHR5IiwiY3VycmVudEJhbGFuY2UiLCJjeWNsZXMiLCJwZW5hbHRpZXMiLCJwIiwiY3ljbGVfbm8iLCJkdWVfZGF0ZSIsImV4cGVjdGVkIiwicGFpZCIsInBlbmFsdHkiLCJwZW5hbHR5X2Ftb3VudCIsImxhdGVfcGF5bWVudF9jaGFyZ2VzIiwibGF0ZV9mZWVfYW1vdW50IiwicGVuYWx0eVJlY29yZElkIiwiZm9ybWF0UGVuYWx0eUFtb3VudCIsInRvTG9jYWxlU3RyaW5nIiwiUGVuYWx0eUNvbHVtbnMiLCJQZW5hbHR5QnJlYWtkb3duQ29sdW1ucyIsInBlbmFsdHlIaXN0b3J5Q29sdW1ucyIsInRpdGxlIiwiZGF0YUluZGV4IiwicmVuZGVyIiwibW9tZW50IiwiZm9ybWF0Iiwic29ydGVyIiwiYSIsImIiLCJkZWZhdWx0U29ydE9yZGVyIiwiYWxpZ24iLCJfIiwicmVjb3JkIiwidG90YWwiLCJmb3JtYXR0ZWRDdXN0b21lclBlbmFsdHlEYXRhIiwidXNlTWVtbyIsIk1hdGgiLCJhYnMiLCJzaG93UGVuYWx0eUJyZWFrZG93biIsImZvcm1hdHRlZFBlbmFsdHlDeWNsZXMiLCJjeWNsZSIsImZldGNoQ3VzdG9tZXJCaWRSZXF1ZXN0cyIsInVzZXJPYmplY3QiLCJzdWJzY3JpYmVySWQiLCJncm91cE9iamVjdCIsImF1Y3Rpb25zIiwiZ2V0U3RhdHVzQ29sb3IiLCJzdGF0dXNDb2xvcnMiLCJQZW5kaW5nIiwiQWNjZXB0IiwiRGVjbGluZSIsIk5leHRBdWN0aW9uIiwiUHJpemVkIiwiYmlkX3JlcXVlc3RfY29kZSIsInJlcXVlc3RfZGF0ZSIsInVzZXJfbmFtZSIsInN1YnNjcmliZXJOYW1lIiwidGlja2V0X251bWJlciIsInRpY2tldE51bWJlciIsImF1Y3Rpb25fZGF0ZSIsImF1Y3Rpb25EYXRlIiwiYXVjdGlvbl90aW1lIiwiYmFsYW5jZV9kaXNwbGF5Iiwic3RhdHVzX2NvbG9yIiwicmVmZXJyZWRfYnkiLCJhZG1pbl91c2VyIiwiYWRtaW5OYW1lIiwiYXVjdGlvbl9jeWNsZSIsIm1vYmlsZU51bWJlciIsIm5leHRfYXVjdGlvbl9kYXRlIiwibGF0ZXN0X2F1Y3Rpb24iLCJuZXh0X2RhdGUiLCJzaG93QmlkUmVxdWVzdERldGFpbHMiLCJiaWRSZXF1ZXN0IiwiQmlkUmVxdWVzdENvbHVtbnMiLCJmZXRjaEN1c3RvbWVyVmlzaXRvcnMiLCJ2aXNpdG9ycyIsIkFycmF5IiwiaXNBcnJheSIsIk9iamVjdCIsInZhbHVlcyIsInYiLCJmb3JtYXREYXRlVGltZSIsImRhdGVTdHJpbmciLCJpc05hTiIsImdldFRpbWUiLCJkYXkiLCJTdHJpbmciLCJnZXREYXRlIiwicGFkU3RhcnQiLCJtb250aCIsImdldE1vbnRoIiwieWVhciIsImdldEZ1bGxZZWFyIiwiaG91cnMiLCJnZXRIb3VycyIsIm1pbnV0ZXMiLCJnZXRNaW51dGVzIiwiYW1wbSIsImhvdXJzU3RyIiwidmlzaXRvcl9jb2RlIiwicGhvbmUiLCJlbWFpbCIsInB1cnBvc2UiLCJkZXNjcmlwdGlvbiIsImZvcm1hdHRlZF9kYXRlIiwiZGF0ZVRpbWUiLCJtZWV0X3BlcnNvbiIsIm1lZXRQZXJzb24iLCJjaGl0R3JvdXAiLCJzaG93VmlzaXRvckRldGFpbHMiLCJ2aXNpdG9yIiwiVmlzaXRvckNvbHVtbnMiLCJnZXRDdXN0b21lclBheW1lbnRTdGF0ZW1lbnQiLCJzdGF0ZW1lbnQiLCJmaWx0ZXJlZFJlc3BvbnNlIiwiYmFsYW5jZVZhbHVlIiwicGFpZFZhbHVlIiwiZHVlVmFsdWUiLCJkdWUiLCJyZWNlaXZlZFZhbHVlIiwicmVjZWl2ZWQiLCJwYXlUeXBlIiwicmVjZWlwdE5vIiwiaXNQb3NpdGl2ZSIsImlzTm90UGFpZFJvdyIsInN0YXJ0c1dpdGgiLCJkYXRlU3RyIiwicGF5ZGF0ZVN0ciIsInBheWRhdGUiLCJyYXdEYXRlIiwicmF3UGF5RGF0ZSIsInJhd0JhbGFuY2UiLCJyYXdEZXNjcmlwdGlvbiIsInJhd0R1ZSIsInJhd1BhaWQiLCJyYXdSZWNlaXZlZCIsInJhd1BheVR5cGUiLCJyYXdSZWNlaXB0Tm8iLCJ0b1N0cmluZyIsImhhbmRsZUVucm9sbG1lbnRDaGFuZ2UiLCJoYW5kbGVUcmFuc2FjdGlvbnNTZWxlY3RGaWx0ZXIiLCJmb3JtYXREYXRlIiwic2xpY2UiLCJzdGFydE9mTW9udGgiLCJwYXJzZUludCIsImRheUdyb3VwIiwibG9hbkNvbHVtbnMiLCJwaWdtZUNvbHVtbnMiLCJjdXJyZW50UmVxdWVzdElkIiwibm93IiwibGF0ZXN0UmVxdWVzdCIsInRvdGFsQmVQYWlkIiwidG90YWxfcGF5YWJsZSIsInByb2ZpdCIsInRvdGFsX3Byb2ZpdCIsInRvQmVQYWlkQW1vdW50IiwibGF0ZUZlZSIsInRvdGFsX2xhdGVfZmVlIiwidG90YWxfcGVuYWx0eSIsInBhaWRBbW91bnQiLCJ0b3RhbF9pbnZlc3RtZW50IiwidG90YWxfYmFsYW5jZSIsInJlZmVycmVkX3R5cGUiLCJyZWZlcnJlcl9uYW1lIiwicmVmZXJyZWRfYWdlbnQiLCJjaGl0X2Fza2luZ19tb250aCIsImN1c3RvbWVyX3N0YXR1cyIsInJlbW92YWxfcmVhc29uIiwiZW5yb2xsbWVudERhdGUiLCJpc1ByaXplZCIsImlzX3ByaXplZCIsIkJvb2xlYW4iLCJyb3ciLCJBdWN0aW9uY29sdW1ucyIsImZldGNoRW5yb2xsIiwiUGFpZCIsInRvQmVQYWlkIiwiQmFzaWNjb2x1bW5zIiwiQ3VzdG9tZXJQYXltZW50U3RhdGVtZW50Q29sdW1ucyIsIkN1c3RvbWVyUGF5bWVudFN0YXRlbWVudEV4cG9ydHNDb2x1bW5zIiwicGFydHMiLCJmb3JtYXR0ZWRGcm9tRGF0ZSIsImZvcm1hdHRlZFRvRGF0ZSIsImFtb3VudF90b19iZV9wYWlkIiwiZ3JvdXBfaW5zdGFsbCIsImFtb3VudF9wYWlkIiwidG90YWxQYWlkQW1vdW50IiwiYW1vdW50X2JhbGFuY2UiLCJiaWRfYW1vdW50IiwiZ3JvdXBfdmFsdWUiLCJ3aW5fYW1vdW50IiwiZGl2aWRlbnQiLCJkaXZpZGVudF9oZWFkIiwiZ3JvdXBfbWVtYmVycyIsInBheWFibGUiLCJwcmV2RGF0YSIsInBvc3QiLCJ0aGVuIiwiY2F0Y2giLCJ1bmRlZmluZWQiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsImhlaWdodCIsIndpZHRoIiwiaWNvbiIsImRldGFpbHNBcnJheSIsImFsdGVybmF0ZV9udW1iZXIiLCJhZGRyZXNzIiwiYWRoYWFyX25vIiwicGFuX25vIiwicGluY29kZSIsImZhdGhlcl9uYW1lIiwibm9taW5lZV9uYW1lIiwiYmFua19uYW1lIiwiYmFua19hY2NvdW50X251bWJlciIsImZ1c2UiLCJrZXlzIiwidGhyZXNob2xkIiwicmVzdWx0cyIsInNlYXJjaCIsInByZXYiLCJnZW5kZXIiLCJkYXRlb2ZiaXJ0aCIsImNvbGxlY3Rpb25fYXJlYSIsInJvdXRlX25hbWUiLCJtYXJpdGFsX3N0YXR1cyIsIm5hdGlvbmFsaXR5IiwidmlsbGFnZSIsInRhbHVrIiwiZGlzdHJpY3QiLCJzdGF0ZSIsInJlZmVycmFsX25hbWUiLCJub21pbmVlX2RhdGVvZmJpcnRoIiwibm9taW5lZV9waG9uZV9udW1iZXIiLCJub21pbmVlX3JlbGF0aW9uc2hpcCIsImJhbmtfYnJhbmNoX25hbWUiLCJiYW5rX0lGU0NfY29kZSIsInVzZXJEZXRhaWxzIiwiY3VzdG9tZXJfaWQiLCJncm9zc19hbW91bnQiLCJnc3RfYW1vdW50IiwiaW50ZXJlc3RfYW1vdW50IiwiYWRtaW5faWQiLCJhZG1pbl9jb2RlIiwicGF5bWVudF9kaXJlY3Rpb24iLCJ0b191c2VyIiwidG9fbG9hbiIsImgiLCJpIiwiaXNOdW1lcmljIiwidG9Mb2NhbGVUaW1lU3RyaW5nIiwiaG91ciIsIm1pbnV0ZSIsInNlbGVjdGVkUGlnbWUiLCJ0aW1lIiwibW9kZXMiLCJlbnJvbGxtZW50IiwiciIsImNvbCIsInNvbWUiLCJwYWdlU2l6ZSIsInBhZGRpbmciLCJ2aXNpdG9ySWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJVc2VyUmVwb3J0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VNZW1vLCB1c2VSZWYgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBDdXN0b21lclJlcG9ydFByaW50IGZyb20gXCIuLi9jb21wb25lbnRzL3ByaW50Rm9ybWF0cy9DdXN0b21lclJlcG9ydFByaW50XCI7XHJcbmltcG9ydCB7IERyb3Bkb3duLCBTZWxlY3QsIEJ1dHRvbiwgTW9kYWwsIFRhZywgVGFibGUgYXMgQW50VGFibGUgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcbmltcG9ydCB7IExpbmssIHVzZVNlYXJjaFBhcmFtcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IEZpUmVmcmVzaENjdywgRmlTZWFyY2ggfSBmcm9tIFwicmVhY3QtaWNvbnMvZmlcIjtcclxuaW1wb3J0IHsgSW9NZERvd25sb2FkIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCB7IElvTWRNb3JlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCB7IE1kQWNjb3VudEJhbGFuY2VXYWxsZXQsIE1kR2F2ZWwsIE1kUGVvcGxlIH0gZnJvbSBcInJlYWN0LWljb25zL21kXCI7XHJcbmltcG9ydCBGdXNlIGZyb20gXCJmdXNlLmpzXCI7XHJcbmltcG9ydCBkYXlqcyBmcm9tIFwiZGF5anNcIjtcclxuaW1wb3J0IHsgbnVtYmVyVG9JbmRpYW5Xb3JkcyB9IGZyb20gXCIuLi9oZWxwZXJzL251bWJlclRvSW5kaWFuV29yZHNcIjtcclxuaW1wb3J0IHtcclxuICBGaVVzZXIsXHJcbiAgRmlCb29rT3BlbixcclxuICBGaUZpbGVUZXh0LFxyXG4gIEZpUmVwZWF0LFxyXG4gIEZpQ3JlZGl0Q2FyZCxcclxufSBmcm9tIFwicmVhY3QtaWNvbnMvZmlcIjtcclxuaW1wb3J0IHsgRmFSdXBlZVNpZ24sIEZhRXhjbGFtYXRpb25DaXJjbGUsIEZhRXllIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7XHJcbiAgRXllT3V0bGluZWQsXHJcbiAgRXhjbGFtYXRpb25DaXJjbGVPdXRsaW5lZCxcclxuXHJcbn0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcblxyXG4vLyBpbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmNvbnN0IFVzZXJSZXBvcnQgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3NlYXJjaFBhcmFtc10gPSB1c2VTZWFyY2hQYXJhbXMoKTtcclxuICBjb25zdCB1c2VySWQgPSBzZWFyY2hQYXJhbXMuZ2V0KFwidXNlcl9pZFwiKTtcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW1RhYmxlRGF5Ym9vaywgc2V0VGFibGVEYXlib29rXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbVGFibGVBdWN0aW9ucywgc2V0VGFibGVBdWN0aW9uc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXAsIHNldFNlbGVjdGVkR3JvdXBdID0gdXNlU3RhdGUodXNlcklkID8gdXNlcklkIDogXCJcIik7XHJcbiAgY29uc3QgW2dyb3VwLCBzZXRHcm91cF0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2NvbW1pc3Npb24sIHNldENvbW1pc3Npb25dID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW1RhYmxlRW5yb2xscywgc2V0VGFibGVFbnJvbGxzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbVGFibGVFbnJvbGxzRGF0ZSwgc2V0VGFibGVFbnJvbGxzRGF0ZV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkVXNlcnMsIHNldEZpbHRlcmVkVXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtncm91cFBhaWQsIHNldEdyb3VwUGFpZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZ3JvdXBUb0JlUGFpZCwgc2V0R3JvdXBUb0JlUGFpZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbY3VzdG9tZXJUcmFuc2FjdGlvbnMsIHNldEN1c3RvbWVyVHJhbnNhY3Rpb25zXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFthY2NvdW50RGV0YWlscywgc2V0QWNjb3VudERldGFpbHNdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2FjY291bnREZXRhaWxzTG9hZGluZywgc2V0QWNjb3VudERldGFpbHNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZnJvbURhdGUsIHNldEZyb21EYXRlXSA9IHVzZVN0YXRlKCgpID0+IHtcclxuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuICAgIHJldHVybiB0b2RheS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcclxuICB9KTtcclxuICBjb25zdCBbdG9EYXRlLCBzZXRUb0RhdGVdID0gdXNlU3RhdGUoKCkgPT4ge1xyXG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgcmV0dXJuIHRvZGF5LnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdO1xyXG4gIH0pO1xyXG4gIGNvbnN0IFt0b3RhbEFtb3VudCwgc2V0VG90YWxBbW91bnRdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW2dyb3VwUGFpZERhdGUsIHNldEdyb3VwUGFpZERhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2dyb3VwVG9CZVBhaWREYXRlLCBzZXRHcm91cFRvQmVQYWlkRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZGV0YWlsc0xvYWRpbmcsIHNldERldGFpbExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtiYXNpY0xvYWRpbmcsIHNldEJhc2ljTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2RhdGVMb2FkaW5nLCBzZXREYXRlTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW0Vucm9sbEdyb3VwSWQsIHNldEVucm9sbEdyb3VwSWRdID0gdXNlU3RhdGUoe1xyXG4gICAgZ3JvdXBJZDogXCJcIixcclxuICAgIHRpY2tldDogXCJcIixcclxuICB9KTtcclxuICBjb25zdCBbcmVnaXN0cmF0aW9uRmVlLCBzZXRSZWdpc3RyYXRpb25GZWVdID0gdXNlU3RhdGUoe1xyXG4gICAgYW1vdW50OiAwLFxyXG4gICAgY3JlYXRlZEF0OiBudWxsLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFt2aXNpYmxlUm93cywgc2V0VmlzaWJsZVJvd3NdID0gdXNlU3RhdGUoe1xyXG4gICAgcm93MTogZmFsc2UsXHJcbiAgICByb3cyOiBmYWxzZSxcclxuICAgIHJvdzM6IGZhbHNlLFxyXG4gICAgcm93NDogZmFsc2UsXHJcbiAgICByb3c1OiBmYWxzZSxcclxuICAgIHJvdzY6IGZhbHNlLFxyXG4gICAgcm93NzogZmFsc2UsXHJcbiAgICByb3c4OiBmYWxzZSxcclxuICAgIHJvdzk6IGZhbHNlLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbdmlldywgc2V0Vmlld10gPSB1c2VTdGF0ZShcImxpc3RcIik7XHJcblxyXG4gIGNvbnN0IElucHV0ID0gKHsgbGFiZWwsIHZhbHVlIH0pID0+IChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBmbGV4LTFcIj5cclxuICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTEgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+e2xhYmVsfTwvbGFiZWw+XHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICBwbGFjZWhvbGRlcj17bGFiZWx9XHJcbiAgICAgICAgdmFsdWU9e3ZhbHVlIHx8IFwiXCJ9XHJcbiAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNCBweS0yIHNoYWRvdy1zbSBvdXRsaW5lLW5vbmUgdy1mdWxsXCJcclxuICAgICAgLz5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbiAgY29uc3QgW1RvdGFsVG9CZXBhaWQsIHNldFRvdGFsVG9CZVBhaWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW1RvdGFscGFpZCwgc2V0VG90YWxQYWlkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtUb3RhbHByb2ZpdCwgc2V0VG90YWxQcm9maXRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgaXNGZXRjaGluZ1BlbmFsdHkgPSB1c2VSZWYoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbTmV0VG90YWxwcm9maXQsIHNldE5ldFRvdGFsUHJvZml0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEF1Y3Rpb25Hcm91cElkLCBzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cElkXSA9IHVzZVN0YXRlKFxyXG4gICAgdXNlcklkID8gdXNlcklkIDogXCJcIixcclxuICApO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEVucm9sbG1lbnRzLCBzZXRTZWxlY3RlZEVucm9sbG1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZ3JvdXBJbmZvLCBzZXRHcm91cEluZm9dID0gdXNlU3RhdGUoe30pO1xyXG5cclxuICBjb25zdCBbc2VsZWN0ZWRGcm9tRGF0ZSwgc2V0U2VsZWN0ZWRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRUb0RhdGUsIHNldFNlbGVjdGVkVG9EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFBheW1lbnRNb2RlLCBzZXRTZWxlY3RlZFBheW1lbnRNb2RlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEN1c3RvbWVycywgc2V0U2VsZWN0ZWRDdXN0b21lcnNdID0gdXNlU3RhdGUoXHJcbiAgICB1c2VySWQgPyB1c2VySWQgOiBcIlwiLFxyXG4gICk7XHJcbiAgY29uc3QgW3BheW1lbnRzLCBzZXRQYXltZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2F2YWlsYWJsZVRpY2tldHMsIHNldEF2YWlsYWJsZVRpY2tldHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzY3JlZW5Mb2FkaW5nLCBzZXRTY3JlZW5Mb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZShcImdyb3VwRGV0YWlsc1wiKTtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZ3JvdXBEZXRhaWxzLCBzZXRHcm91cERldGFpbHNdID0gdXNlU3RhdGUoXCIgXCIpO1xyXG4gIGNvbnN0IFtsb2FuQ3VzdG9tZXJzLCBzZXRMb2FuQ3VzdG9tZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbcGlnbWVDdXN0b21lcnMsIHNldFBpZ21lQ3VzdG9tZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbcGlnbWVDdXN0b21lckRhdGEsIHNldFBpZ21lQ3VzdG9tZXJEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbcGlnbWVJZCwgc2V0UGlnbWVJZF0gPSB1c2VTdGF0ZShcIk5vXCIpO1xyXG4gIGNvbnN0IFtmaWx0ZXJlZFBpZ21lRGF0YSwgc2V0RmlsdGVyZWRQaWdtZURhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtib3Jyb3dlcnNEYXRhLCBzZXRCb3Jyb3dlcnNEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYm9ycm93ZXJJZCwgc2V0Qm9ycm93ZXJJZF0gPSB1c2VTdGF0ZShcIk5vXCIpO1xyXG4gIGNvbnN0IFtmaWx0ZXJlZEJvcnJvd2VyRGF0YSwgc2V0RmlsdGVyZWRCb3Jyb3dlckRhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtmaWx0ZXJlZERpc2J1cnNlbWVudCwgc2V0RmlsdGVyZWREaXNidXJzZW1lbnRdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtkaXNidXJzZW1lbnRMb2FkaW5nLCBzZXREaXNidXJzZW1lbnRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc3RhdGVtZW50TG9hZGluZywgc2V0U3RhdGVtZW50TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3RyYW5zYWN0aW9uc0xvYWRpbmcsIHNldFRyYW5zYWN0aW9uc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbcmVnaXN0cmF0aW9uQW1vdW50LCBzZXRSZWdpc3RyYXRpb25BbW91bnRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3JlZ2lzdHJhdGlvbkRhdGUsIHNldFJlZ2lzdHJhdGlvbkRhdGVdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2ZpbmFsUGF5bWVudEJhbGFuY2UsIHNldEZpbmFsUGF5bWVudEJhbGFuY2VdID0gdXNlU3RhdGUoMCk7XHJcbiAgLy8gdHJhbnNjdGlvbnMgZGV0YWlsc1xyXG4gIGNvbnN0IFtzZWxlY3RlZExhYmVsLCBzZXRTZWxlY3RlZExhYmVsXSA9IHVzZVN0YXRlKFwiNTBcIik7XHJcbiAgY29uc3QgW3Nob3dGaWx0ZXJGaWVsZCwgc2V0U2hvd0ZpbHRlckZpZWxkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgY29uc3QgdG9kYXlTdHJpbmcgPSB0b2RheS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcclxuICAvL3NhbmpheVxyXG4gIGNvbnN0IFtwZW5hbHR5RGF0YSwgc2V0UGVuYWx0eURhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtwZW5hbHR5TG9hZGluZywgc2V0UGVuYWx0eUxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFticmVha2Rvd25Nb2RhbFZpc2libGUsIHNldEJyZWFrZG93bk1vZGFsVmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkUGVuYWx0eSwgc2V0U2VsZWN0ZWRQZW5hbHR5XSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtiaWRSZXF1ZXN0c0RhdGEsIHNldEJpZFJlcXVlc3RzRGF0YV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbYmlkUmVxdWVzdHNMb2FkaW5nLCBzZXRCaWRSZXF1ZXN0c0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtiaWRSZXF1ZXN0TW9kYWxWaXNpYmxlLCBzZXRCaWRSZXF1ZXN0TW9kYWxWaXNpYmxlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VsZWN0ZWRCaWRSZXF1ZXN0LCBzZXRTZWxlY3RlZEJpZFJlcXVlc3RdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3Zpc2l0b3JEYXRhLCBzZXRWaXNpdG9yRGF0YV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbdmlzaXRvckxvYWRpbmcsIHNldFZpc2l0b3JMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdmlzaXRvck1vZGFsVmlzaWJsZSwgc2V0VmlzaXRvck1vZGFsVmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkVmlzaXRvciwgc2V0U2VsZWN0ZWRWaXNpdG9yXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIC8vIGNvbnN0IFtzZWxlY3RlZEdyb3VwRm9yUGVuYWx0eSwgc2V0U2VsZWN0ZWRHcm91cEZvclBlbmFsdHldID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIGNvbnN0IFtoaWRlQWNjb3VudFR5cGUsIHNldEhpZGVBY2NvdW50VHlwZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRBY2NvdW50VHlwZSwgc2V0U2VsZWN0ZWRBY2NvdW50VHlwZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRQYXltZW50Rm9yLCBzZXRTZWxlY3RlZFBheW1lbnRGb3JdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzaG93QWxsUGF5bWVudE1vZGVzLCBzZXRTaG93QWxsUGF5bWVudE1vZGVzXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdHJhbnNhY3Rpb25zVGFibGUsIHNldFRyYW5zYWN0aW9uc1RhYmxlXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdG90YWxUcmFuc2FjdGlvbnMsIHNldFRvdGFsVHJhbnNhY3RvbnNdID0gdXNlU3RhdGUoMTApO1xyXG4gIGNvbnN0IFt0b3RhbFRyYW5zYWN0aW9uQW1vdW50LCBzZXRUb3RhbFRyYW5zYWN0aW9uQW1vdW50XSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFtlbnJvbGxtZW50RGF0YSwgc2V0RW5yb2xsbWVudERhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthY3RpdmVFbnJvbGxtZW50RGF0YSwgc2V0QWN0aXZlRW5yb2xsbWVudERhdGFdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2Vucm9sbG1lbnREYXRhTG9hZGluZywgc2V0RW5yb2xsbWVudERhdGFMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdHJhbnNmZXJIaXN0b3J5TG9hZGluZywgc2V0VHJhbnNmZXJIaXN0b3J5TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3RyYW5zZmVySGlzdG9yeSwgc2V0VHJhbnNmZXJIaXN0b3J5XSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZW5yb2xsbWVudElkLCBzZXRFbnJvbGxtZW50SWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3Qgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgIHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpO1xyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlVGFiQ2hhbmdlID0gKHRhYikgPT4ge1xyXG4gICAgc2V0QWN0aXZlVGFiKHRhYik7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBncm91cF9pZDogXCJcIixcclxuICAgIHVzZXJfaWQ6IFwiXCIsXHJcbiAgICB0aWNrZXQ6IFwiXCIsXHJcbiAgICByZWNlaXB0X25vOiBcIlwiLFxyXG4gICAgcGF5X2RhdGU6IFwiXCIsXHJcbiAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICBwYXlfdHlwZTogXCJjYXNoXCIsXHJcbiAgICB0cmFuc2FjdGlvbl9pZDogXCJcIixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgQmFzaWNMb2FuQ29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5X2RhdGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJyZWNlaXB0X25vXCIsIGhlYWRlcjogXCJSZWNlaXB0IE5vXCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudFwiLCBoZWFkZXI6IFwiQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcInBheV90eXBlXCIsIGhlYWRlcjogXCJQYXltZW50IFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmFsYW5jZVwiLCBoZWFkZXI6IFwiQmFsYW5jZVwiIH0sXHJcbiAgXTtcclxuICBjb25zdCBCYXNpY1BpZ21lQ29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5X2RhdGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJyZWNlaXB0X25vXCIsIGhlYWRlcjogXCJSZWNlaXB0IE5vXCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudFwiLCBoZWFkZXI6IFwiQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcInBheV90eXBlXCIsIGhlYWRlcjogXCJQYXltZW50IFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmFsYW5jZVwiLCBoZWFkZXI6IFwiQmFsYW5jZVwiIH0sXHJcbiAgXTtcclxuICBjb25zdCBEaXNidXJzZW1lbnRDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJwYXlfZGF0ZVwiLCBoZWFkZXI6IFwiRGlzYnVyc2VkIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwidHJhbnNhY3Rpb25fZGF0ZVwiLCBoZWFkZXI6IFwiVHJhbnNhY3Rpb24gRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lLyBMb2FuIElEXCIgfSxcclxuICAgIHsga2V5OiBcInRpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0XCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudFwiLCBoZWFkZXI6IFwiQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcInJlY2VpcHRfbm9cIiwgaGVhZGVyOiBcIlJlY2VpcHQgTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5X3R5cGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJkaXNidXJzZW1lbnRfdHlwZVwiLCBoZWFkZXI6IFwiRGlzYnVyc2VtZW50IFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZGlzYnVyc2VkX2J5XCIsIGhlYWRlcjogXCJEaXNidXJzZWQgQnlcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmFsYW5jZVwiLCBoZWFkZXI6IFwiQmFsYW5jZVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgVHJhbnNmZXJIaXN0b3J5Q29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwidHJhbnNmZXJfY29kZVwiLCBoZWFkZXI6IFwiR3JvdXAgQ2hhbmdlIENvZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwidHJhbnNmZXJfZGF0ZVwiLCBoZWFkZXI6IFwiR3JvdXAgQ2hhbmdlIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZnJvbV9jdXN0b21lclwiLCBoZWFkZXI6IFwiRnJvbSBDdXN0b21lclwiIH0sXHJcbiAgICB7IGtleTogXCJmcm9tX2dyb3VwXCIsIGhlYWRlcjogXCJGcm9tIEdyb3VwXCIgfSxcclxuICAgIHsga2V5OiBcImZyb21fdGlja2V0XCIsIGhlYWRlcjogXCJGcm9tIFRpY2tldFwiIH0sXHJcbiAgICB7IGtleTogXCJ0b19jdXN0b21lclwiLCBoZWFkZXI6IFwiVG8gQ3VzdG9tZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwidG9fZ3JvdXBcIiwgaGVhZGVyOiBcIlRvIEdyb3VwXCIgfSxcclxuICAgIHsga2V5OiBcInRvX3RpY2tldFwiLCBoZWFkZXI6IFwiVG8gVGlja2V0XCIgfSxcclxuICAgIHsga2V5OiBcInRyYW5zZmVyX2Ftb3VudFwiLCBoZWFkZXI6IFwiR3JvdXAgQ2hhbmdlIEFtb3VudFwiIH0sXHJcbiAgICAvLyB7IGtleTogXCJkZWR1Y3Rpb25fYW1vdW50XCIsIGhlYWRlcjogXCJEZWR1Y3Rpb25cIiB9LFxyXG4gICAgeyBrZXk6IFwibmV0X3RyYW5zZmVycmVkX2Ftb3VudFwiLCBoZWFkZXI6IFwiTmV0IEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJyZWFzb25cIiwgaGVhZGVyOiBcIlJlYXNvblwiIH0sXHJcbiAgICB7IGtleTogXCJhZG1pblwiLCBoZWFkZXI6IFwiQ3JlYXRlZCBCeVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgVHJhbnNhY3Rpb25zQ29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiZGF0ZVwiLCBoZWFkZXI6IFwiUGFpZCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcInRyYW5zYWN0aW9uX2RhdGVcIiwgaGVhZGVyOiBcIlRyYW5zYWN0aW9uIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY2F0ZWdvcnlcIiwgaGVhZGVyOiBcIkNhdGVnb3J5XCIgfSxcclxuICAgIHsga2V5OiBcInRpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0XCIgfSxcclxuICAgIHsga2V5OiBcInJlY2VpcHRcIiwgaGVhZGVyOiBcIlJlY2VpcHRcIiB9LFxyXG4gICAgeyBrZXk6IFwib2xkX3JlY2VpcHRfbm9cIiwgaGVhZGVyOiBcIk9sZCBSZWNlaXB0XCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudFwiLCBoZWFkZXI6IFwiQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcIm1vZGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgTW9kZVwiIH0sXHJcbiAgICAuLi4oaGlkZUFjY291bnRUeXBlXHJcbiAgICAgID8gW3sga2V5OiBcImFjY291bnRfdHlwZVwiLCBoZWFkZXI6IFwiQWNjb3VudCBUeXBlXCIgfV1cclxuICAgICAgOiBbXSksXHJcbiAgICB7IGtleTogXCJjb2xsZWN0ZWRfYnlcIiwgaGVhZGVyOiBcIkNvbGxlY3RlZCBCeVwiIH0sXHJcbiAgICB7IGtleTogXCJjb2xsZWN0aW9uX3RpbWVcIiwgaGVhZGVyOiBcIkNvbGxlY3Rpb24gVGltZVwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgYWJvcnRDb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xyXG4gICAgY29uc3QgZmV0Y2hQYXltZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgaWYgKCFzZWxlY3RlZEdyb3VwKSByZXR1cm47XHJcblxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldFRyYW5zYWN0aW9uc0xvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgICAgIGNvbnN0IHF1ZXJ5UGFyYW1zID0geyB1c2VySWQ6IHNlbGVjdGVkR3JvdXAgfTtcclxuICAgICAgICBpZiAoc2VsZWN0ZWRGcm9tRGF0ZSkgcXVlcnlQYXJhbXMuZnJvbV9kYXRlID0gc2VsZWN0ZWRGcm9tRGF0ZTtcclxuICAgICAgICBpZiAoc2VsZWN0ZWRUb0RhdGUpIHF1ZXJ5UGFyYW1zLnRvX2RhdGUgPSBzZWxlY3RlZFRvRGF0ZTtcclxuICAgICAgICBpZiAodG90YWxUcmFuc2FjdGlvbnMpXHJcbiAgICAgICAgICBxdWVyeVBhcmFtcy50b3RhbFRyYW5zYWN0aW9ucyA9IHRvdGFsVHJhbnNhY3Rpb25zO1xyXG4gICAgICAgIGlmIChzZWxlY3RlZFBheW1lbnRNb2RlPy5sZW5ndGgpXHJcbiAgICAgICAgICBxdWVyeVBhcmFtcy5wYXlfdHlwZSA9IHNlbGVjdGVkUGF5bWVudE1vZGU7XHJcbiAgICAgICAgaWYgKHNlbGVjdGVkQWNjb3VudFR5cGUpIHF1ZXJ5UGFyYW1zLmFjY291bnRfdHlwZSA9IHNlbGVjdGVkQWNjb3VudFR5cGU7XHJcbiAgICAgICAgaWYgKHNlbGVjdGVkUGF5bWVudEZvcj8ubGVuZ3RoKVxyXG4gICAgICAgICAgcXVlcnlQYXJhbXMucGF5X2ZvciA9IHNlbGVjdGVkUGF5bWVudEZvcjtcclxuXHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvcGF5bWVudC9jdXN0b21lci90cmFuc2FjdGlvbnNgLCB7XHJcbiAgICAgICAgICBwYXJhbXM6IHF1ZXJ5UGFyYW1zLFxyXG4gICAgICAgICAgc2lnbmFsOiBhYm9ydENvbnRyb2xsZXIuc2lnbmFsLFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgIGNvbnN0IHRvdGFsU3VtID0gcmVzcG9uc2UuZGF0YS5yZWR1Y2UoXHJcbiAgICAgICAgICAgIChzdW0sIGl0ZW0pID0+IHN1bSArIE51bWJlcihpdGVtLmFtb3VudCB8fCAwKSxcclxuICAgICAgICAgICAgMCxcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgICBzZXRUb3RhbFRyYW5zYWN0aW9uQW1vdW50KHRvdGFsU3VtKTtcclxuICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLm1hcCgoaXRlbSwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICBfaWQ6IGl0ZW0uX2lkLFxyXG4gICAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgZ3JvdXA6IGl0ZW0/Lmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IGl0ZW0/LnBheV9mb3IgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICBuYW1lOiBpdGVtPy51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCJVbmtub3duIEN1c3RvbWVyXCIsXHJcbiAgICAgICAgICAgICAgY2F0ZWdvcnk6IGl0ZW0/LnBheV9mb3IgfHwgXCJDaGl0XCIsXHJcbiAgICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBpdGVtPy51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICB0aWNrZXQ6IGl0ZW0/LmxvYW5cclxuICAgICAgICAgICAgICAgID8gaXRlbS5sb2FuPy5sb2FuX2lkXHJcbiAgICAgICAgICAgICAgICA6IGl0ZW0/LnBpZ21lXHJcbiAgICAgICAgICAgICAgICAgID8gaXRlbS5waWdtZT8ucGlnbWVfaWRcclxuICAgICAgICAgICAgICAgICAgOiBpdGVtPy50aWNrZXQgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICByZWNlaXB0OiBpdGVtPy5yZWNlaXB0X25vIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgb2xkX3JlY2VpcHRfbm86IGl0ZW0/Lm9sZF9yZWNlaXB0X25vIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICAgIGFtb3VudDogaXRlbT8uYW1vdW50IHx8IDAsXHJcbiAgICAgICAgICAgICAgZGF0ZTogaXRlbS5wYXlfZGF0ZT8uc3BsaXQoXCJUXCIpPy5bMF0gfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICB0cmFuc2FjdGlvbl9kYXRlOiBpdGVtPy5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKT8uWzBdIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgbW9kZTogaXRlbT8ucGF5X3R5cGUgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICBhY2NvdW50X3R5cGU6IGl0ZW0/LmFjY291bnRfdHlwZSB8fCBcIi1cIixcclxuICAgICAgICAgICAgICBjb2xsZWN0aW9uX3RpbWU6IGl0ZW0/LmNvbGxlY3Rpb25fdGltZSB8fCBcIi1cIixcclxuICAgICAgICAgICAgICBjb2xsZWN0ZWRfYnk6XHJcbiAgICAgICAgICAgICAgICBpdGVtPy5jb2xsZWN0ZWRfYnk/Lm5hbWUgfHxcclxuICAgICAgICAgICAgICAgIGl0ZW0/LmFkbWluX3R5cGU/LmFkbWluX25hbWUgfHxcclxuICAgICAgICAgICAgICAgIFwiU3VwZXIgQWRtaW5cIixcclxuICAgICAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPXtgL3ByaW50LyR7aXRlbS5faWR9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByaW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIHNldFRyYW5zYWN0aW9uc1RhYmxlKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBjb25zb2xlLndhcm4oXCJObyBkYXRhIHJldHVybmVkIGZvciB0aGVzZSBmaWx0ZXJzOlwiLCBxdWVyeVBhcmFtcyk7XHJcbiAgICAgICAgICBzZXRUcmFuc2FjdGlvbnNUYWJsZShbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGlmIChlcnJvci5uYW1lICE9PSBcIkFib3J0RXJyb3JcIikge1xyXG4gICAgICAgICAgc2V0VHJhbnNhY3Rpb25zVGFibGUoW10pO1xyXG4gICAgICAgICAgc2V0VG90YWxUcmFuc2FjdGlvbkFtb3VudCgwKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0VHJhbnNhY3Rpb25zTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hQYXltZW50cygpO1xyXG4gICAgcmV0dXJuICgpID0+IGFib3J0Q29udHJvbGxlci5hYm9ydCgpO1xyXG4gIH0sIFtcclxuICAgIHNlbGVjdGVkRnJvbURhdGUsXHJcbiAgICBzZWxlY3RlZFRvRGF0ZSxcclxuICAgIHNlbGVjdGVkUGF5bWVudE1vZGUsXHJcbiAgICBzZWxlY3RlZEdyb3VwLFxyXG4gICAgc2VsZWN0ZWRBY2NvdW50VHlwZSxcclxuICAgIHNlbGVjdGVkUGF5bWVudEZvcixcclxuICAgIHRvdGFsVHJhbnNhY3Rpb25zLFxyXG4gICAgc2hvd0ZpbHRlckZpZWxkLFxyXG4gIF0pO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFJlZ2lzdHJhdGlvbkZlZSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgaWYgKFxyXG4gICAgICAgIGFjdGl2ZVRhYiA9PT0gXCJiYXNpY1JlcG9ydFwiICYmXHJcbiAgICAgICAgc2VsZWN0ZWRHcm91cCAmJlxyXG4gICAgICAgIEVucm9sbEdyb3VwSWQuZ3JvdXBJZCAmJlxyXG4gICAgICAgIEVucm9sbEdyb3VwSWQudGlja2V0ICYmXHJcbiAgICAgICAgRW5yb2xsR3JvdXBJZC5ncm91cElkICE9PSBcIkxvYW5cIiAmJlxyXG4gICAgICAgIEVucm9sbEdyb3VwSWQgIT09IFwiUGlnbWVcIlxyXG4gICAgICApIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgc2V0VGFibGVFbnJvbGxzKFtdKTtcclxuICAgICAgICAgIHNldEdyb3VwUGFpZChcIlwiKTtcclxuICAgICAgICAgIHNldEdyb3VwVG9CZVBhaWQoXCJcIik7XHJcbiAgICAgICAgICBzZXRSZWdpc3RyYXRpb25BbW91bnQobnVsbCk7XHJcbiAgICAgICAgICBzZXRSZWdpc3RyYXRpb25EYXRlKG51bGwpO1xyXG4gICAgICAgICAgc2V0QmFzaWNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICAgICAgXCIvZW5yb2xsL2dldC11c2VyLXJlZ2lzdHJhdGlvbi1mZWUtcmVwb3J0XCIsXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICAgIGdyb3VwX2lkOiBFbnJvbGxHcm91cElkLmdyb3VwSWQsXHJcbiAgICAgICAgICAgICAgICB0aWNrZXQ6IEVucm9sbEdyb3VwSWQudGlja2V0LFxyXG4gICAgICAgICAgICAgICAgdXNlcl9pZDogc2VsZWN0ZWRHcm91cCxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICBjb25zdCB7IHBheW1lbnRzID0gW10sIHJlZ2lzdHJhdGlvbkZlZXMgPSBbXSB9ID0gcmVzcG9uc2UuZGF0YSB8fCB7fTtcclxuXHJcbiAgICAgICAgICBzZXRHcm91cFBhaWQocGF5bWVudHNbMF0/Lmdyb3VwUGFpZEFtb3VudCB8fCAwKTtcclxuICAgICAgICAgIHNldEdyb3VwVG9CZVBhaWQocGF5bWVudHNbMF0/LnRvdGFsVG9CZVBhaWRBbW91bnQgfHwgMCk7XHJcblxyXG4gICAgICAgICAgbGV0IGJhbGFuY2UgPSAwO1xyXG4gICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHBheW1lbnRzLm1hcCgocGF5bWVudCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgYmFsYW5jZSArPSBOdW1iZXIocGF5bWVudC5hbW91bnQgfHwgMCk7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgX2lkOiBwYXltZW50Ll9pZCxcclxuICAgICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICAgIGRhdGU6IGZvcm1hdFBheURhdGUocGF5bWVudD8ucGF5X2RhdGUpLFxyXG4gICAgICAgICAgICAgIGFtb3VudDogcGF5bWVudC5hbW91bnQsXHJcbiAgICAgICAgICAgICAgcmVjZWlwdDogcGF5bWVudC5yZWNlaXB0X25vLFxyXG4gICAgICAgICAgICAgIG9sZF9yZWNlaXB0OiBwYXltZW50Lm9sZF9yZWNlaXB0X25vLFxyXG4gICAgICAgICAgICAgIHR5cGU6IHBheW1lbnQucGF5X3R5cGUsXHJcbiAgICAgICAgICAgICAgYmFsYW5jZSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIGxldCB0b3RhbFJlZ0Ftb3VudCA9IDA7XHJcbiAgICAgICAgICByZWdpc3RyYXRpb25GZWVzLmZvckVhY2goKHJlZ0ZlZSwgaWR4KSA9PiB7XHJcbiAgICAgICAgICAgIGZvcm1hdHRlZERhdGEucHVzaCh7XHJcbiAgICAgICAgICAgICAgaWQ6IFwiLVwiLFxyXG4gICAgICAgICAgICAgIGRhdGU6IHJlZ0ZlZS5jcmVhdGVkQXRcclxuICAgICAgICAgICAgICAgID8gbmV3IERhdGUocmVnRmVlLmNyZWF0ZWRBdCkudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tR0JcIilcclxuICAgICAgICAgICAgICAgIDogXCJcIixcclxuICAgICAgICAgICAgICBhbW91bnQ6IHJlZ0ZlZS5hbW91bnQsXHJcbiAgICAgICAgICAgICAgcmVjZWlwdDogcmVnRmVlLnJlY2VpcHRfbm8sXHJcbiAgICAgICAgICAgICAgb2xkX3JlY2VpcHQ6IFwiLVwiLFxyXG4gICAgICAgICAgICAgIHR5cGU6IHJlZ0ZlZS5wYXlfZm9yIHx8IFwiUmVnIEZlZVwiLFxyXG4gICAgICAgICAgICAgIGJhbGFuY2U6IFwiLVwiLFxyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIHRvdGFsUmVnQW1vdW50ICs9IE51bWJlcihyZWdGZWUuYW1vdW50IHx8IDApO1xyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgc2V0UmVnaXN0cmF0aW9uQW1vdW50KHRvdGFsUmVnQW1vdW50KTtcclxuXHJcbiAgICAgICAgICBpZiAocmVnaXN0cmF0aW9uRmVlcy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIHNldFJlZ2lzdHJhdGlvbkRhdGUoXHJcbiAgICAgICAgICAgICAgcmVnaXN0cmF0aW9uRmVlc1swXT8uY3JlYXRlZEF0XHJcbiAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKHJlZ2lzdHJhdGlvbkZlZXNbMF0uY3JlYXRlZEF0KS50b0xvY2FsZURhdGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgIFwiZW4tR0JcIixcclxuICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIDogbnVsbCxcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICBpZiAoZm9ybWF0dGVkRGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIGZvcm1hdHRlZERhdGEucHVzaCh7XHJcbiAgICAgICAgICAgICAgaWQ6IFwiXCIsXHJcbiAgICAgICAgICAgICAgZGF0ZTogXCJcIixcclxuICAgICAgICAgICAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgICAgICAgcmVjZWlwdDogXCJcIixcclxuICAgICAgICAgICAgICBvbGRfcmVjZWlwdDogXCJcIixcclxuICAgICAgICAgICAgICB0eXBlOiBcIlRPVEFMXCIsXHJcbiAgICAgICAgICAgICAgYmFsYW5jZSxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHNldEZpbmFsUGF5bWVudEJhbGFuY2UoYmFsYW5jZSk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBzZXRGaW5hbFBheW1lbnRCYWxhbmNlKDApO1xyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIHNldFRhYmxlRW5yb2xscyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHJlZ2lzdHJhdGlvbiBmZWUgYW5kIHBheW1lbnRzOlwiLCBlcnJvcik7XHJcbiAgICAgICAgICBzZXRUYWJsZUVucm9sbHMoW10pO1xyXG4gICAgICAgICAgc2V0R3JvdXBQYWlkKFwiXCIpO1xyXG4gICAgICAgICAgc2V0R3JvdXBUb0JlUGFpZChcIlwiKTtcclxuICAgICAgICAgIHNldFJlZ2lzdHJhdGlvbkFtb3VudChudWxsKTtcclxuICAgICAgICAgIHNldFJlZ2lzdHJhdGlvbkRhdGUobnVsbCk7XHJcbiAgICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAgIHNldEJhc2ljTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRUYWJsZUVucm9sbHMoW10pO1xyXG4gICAgICAgIHNldEdyb3VwUGFpZChcIlwiKTtcclxuICAgICAgICBzZXRHcm91cFRvQmVQYWlkKFwiXCIpO1xyXG4gICAgICAgIHNldFJlZ2lzdHJhdGlvbkFtb3VudChudWxsKTtcclxuICAgICAgICBzZXRSZWdpc3RyYXRpb25EYXRlKG51bGwpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoUmVnaXN0cmF0aW9uRmVlKCk7XHJcbiAgfSwgW2FjdGl2ZVRhYiwgc2VsZWN0ZWRHcm91cCwgRW5yb2xsR3JvdXBJZC5ncm91cElkLCBFbnJvbGxHcm91cElkLnRpY2tldF0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hUcmFuc2Zlckhpc3RvcnkgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0VHJhbnNmZXJIaXN0b3J5TG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgICAgYC92MS9hZG1pbi9lbnJvbGxzL3RyYW5zZmVyLWhpc3RvcnkvJHtzZWxlY3RlZEdyb3VwfWBcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICBjb25zdCBkYXRhID0gcmVzcG9uc2U/LmRhdGE/LmRhdGEgfHwgW107XHJcblxyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSBkYXRhLm1hcCgoaXRlbSwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICBfaWQ6IGl0ZW0uX2lkLFxyXG4gICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuXHJcbiAgICAgICAgICB0cmFuc2Zlcl9jb2RlOiBpdGVtLmVucm9sbF90cmFuc2Zlcl9oaXN0b3J5X2NvZGUsXHJcblxyXG4gICAgICAgICAgZnJvbV9jdXN0b21lcjpcclxuICAgICAgICAgICAgaXRlbT8uZnJvbV9lbnJvbGxtZW50Py51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCItXCIsXHJcblxyXG4gICAgICAgICAgZnJvbV9waG9uZTpcclxuICAgICAgICAgICAgaXRlbT8uZnJvbV9lbnJvbGxtZW50Py51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcblxyXG4gICAgICAgICAgZnJvbV9ncm91cDpcclxuICAgICAgICAgICAgaXRlbT8uZnJvbV9lbnJvbGxtZW50Py5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIi1cIixcclxuXHJcbiAgICAgICAgICBmcm9tX3RpY2tldDpcclxuICAgICAgICAgICAgaXRlbT8uZnJvbV9lbnJvbGxtZW50Py50aWNrZXRzIHx8IFwiLVwiLFxyXG5cclxuICAgICAgICAgIHRvX2N1c3RvbWVyOlxyXG4gICAgICAgICAgICBpdGVtPy50b19lbnJvbGxtZW50Py51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCItXCIsXHJcblxyXG4gICAgICAgICAgdG9fcGhvbmU6XHJcbiAgICAgICAgICAgIGl0ZW0/LnRvX2Vucm9sbG1lbnQ/LnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIi1cIixcclxuXHJcbiAgICAgICAgICB0b19ncm91cDpcclxuICAgICAgICAgICAgaXRlbT8udG9fZW5yb2xsbWVudD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCItXCIsXHJcblxyXG4gICAgICAgICAgdG9fdGlja2V0OlxyXG4gICAgICAgICAgICBpdGVtPy50b19lbnJvbGxtZW50Py50aWNrZXRzIHx8IFwiLVwiLFxyXG5cclxuICAgICAgICAgIHRyYW5zZmVyX2Ftb3VudDogaXRlbT8udHJhbnNmZXJfYW1vdW50IHx8IDAsXHJcbiAgICAgICAgICBkZWR1Y3Rpb25fYW1vdW50OiBpdGVtPy5kZWR1Y3Rpb25fYW1vdW50IHx8IDAsXHJcbiAgICAgICAgICBuZXRfdHJhbnNmZXJyZWRfYW1vdW50OiBpdGVtPy5uZXRfdHJhbnNmZXJyZWRfYW1vdW50IHx8IDAsXHJcbiAgICAgICAgICBhZG1pbjogaXRlbT8uYWRtaW4/LmFkbWluX25hbWUsXHJcbiAgICAgICAgICByZWFzb246IGl0ZW0/LnJlYXNvbiB8fCBcIi1cIixcclxuICAgICAgICAgIHRyYW5zZmVyX2RhdGU6IGZvcm1hdFBheURhdGUoaXRlbT8udHJhbnNmZXJfZGF0ZSksXHJcbiAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICBzZXRUcmFuc2Zlckhpc3RvcnkoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcclxuICAgICAgICAgIFwiRXJyb3IgZmV0Y2hpbmcgdHJhbnNmZXIgaGlzdG9yeTpcIixcclxuICAgICAgICAgIGVycm9yLFxyXG4gICAgICAgICAgZXJyb3I/LnJlc3BvbnNlPy5kYXRhXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXRUcmFuc2Zlckhpc3RvcnkoW10pO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldFRyYW5zZmVySGlzdG9yeUxvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGlmIChhY3RpdmVUYWIgPT09IFwidHJhbnNmZXJIaXN0b3J5XCIgJiYgc2VsZWN0ZWRHcm91cCkge1xyXG4gICAgICBmZXRjaFRyYW5zZmVySGlzdG9yeSgpO1xyXG4gICAgfVxyXG4gIH0sIFthY3RpdmVUYWIsIHNlbGVjdGVkR3JvdXBdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQWxsTG9hblBheW1lbnRzYnlJZCA9IGFzeW5jICgpID0+IHtcclxuICAgICAgc2V0Qm9ycm93ZXJzRGF0YShbXSk7XHJcbiAgICAgIHNldEJhc2ljTG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgLy8gRmluZCBhY3R1YWwgbG9hbl9pZCBmcm9tIHNlbGVjdGVkIGxvYW5cclxuICAgICAgICBjb25zdCBzZWxlY3RlZExvYW4gPSBsb2FuQ3VzdG9tZXJzPy5vdmVyYWxsX2xvYW4/LmZpbmQoXHJcbiAgICAgICAgICAobG9hbikgPT4gbG9hbj8ubG9hbl9kZXRhaWxzPy5sb2FuPy5faWQgPT09IEVucm9sbEdyb3VwSWQudGlja2V0LFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgY29uc3QgbG9hbklkID1cclxuICAgICAgICAgIHNlbGVjdGVkTG9hbj8ubG9hbl9kZXRhaWxzPy5sb2FuPy5faWQgfHwgRW5yb2xsR3JvdXBJZC50aWNrZXQ7XHJcblxyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICAgIGAvbG9hbi1wYXltZW50L2dldC1hbGwtbG9hbi1wYXltZW50cy8ke2xvYW5JZH1gLFxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhPy5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBsZXQgYmFsYW5jZSA9IDA7XHJcbiAgICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2UuZGF0YS5tYXAoKGxvYW5QYXltZW50LCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICBiYWxhbmNlICs9IE51bWJlcihsb2FuUGF5bWVudC5hbW91bnQpO1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgIF9pZDogbG9hblBheW1lbnQuX2lkLFxyXG4gICAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgcGF5X2RhdGU6IGZvcm1hdFBheURhdGUobG9hblBheW1lbnQ/LnBheV9kYXRlKSxcclxuICAgICAgICAgICAgICBhbW91bnQ6IGxvYW5QYXltZW50LmFtb3VudCxcclxuICAgICAgICAgICAgICByZWNlaXB0X25vOiBsb2FuUGF5bWVudC5yZWNlaXB0X25vLFxyXG4gICAgICAgICAgICAgIHBheV90eXBlOiBsb2FuUGF5bWVudC5wYXlfdHlwZSxcclxuICAgICAgICAgICAgICBiYWxhbmNlLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBmb3JtYXR0ZWREYXRhLnB1c2goe1xyXG4gICAgICAgICAgICBfaWQ6IFwiXCIsXHJcbiAgICAgICAgICAgIGlkOiBcIlwiLFxyXG4gICAgICAgICAgICBwYXlfZGF0ZTogXCJcIixcclxuICAgICAgICAgICAgcmVjZWlwdF9ubzogXCJcIixcclxuICAgICAgICAgICAgYW1vdW50OiBcIlwiLFxyXG4gICAgICAgICAgICBwYXlfdHlwZTogXCJcIixcclxuICAgICAgICAgICAgYmFsYW5jZSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgc2V0Qm9ycm93ZXJzRGF0YShmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0Qm9ycm93ZXJzRGF0YShbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBsb2FuIHBheW1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldEJvcnJvd2Vyc0RhdGEoW10pO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldEJhc2ljTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgaWYgKEVucm9sbEdyb3VwSWQuZ3JvdXBJZCA9PT0gXCJMb2FuXCIgJiYgRW5yb2xsR3JvdXBJZC50aWNrZXQpXHJcbiAgICAgIGZldGNoQWxsTG9hblBheW1lbnRzYnlJZCgpO1xyXG4gIH0sIFtFbnJvbGxHcm91cElkLnRpY2tldF0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hBbGxQaWdtZVBheW1lbnRzYnlJZCA9IGFzeW5jICgpID0+IHtcclxuICAgICAgc2V0UGlnbWVDdXN0b21lckRhdGEoW10pO1xyXG4gICAgICBzZXRCYXNpY0xvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICAgIGAvcGlnbWUtcGF5bWVudC9nZXQtYWxsLXBpZ21lLXBheW1lbnRzLWJ5LWlkLyR7RW5yb2xsR3JvdXBJZC50aWNrZXR9YCxcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgIGxldCBiYWxhbmNlID0gMDtcclxuICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLm1hcCgocGlnbWVQYXltZW50LCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICBiYWxhbmNlICs9IE51bWJlcihwaWdtZVBheW1lbnQuYW1vdW50KTtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICBfaWQ6IHBpZ21lUGF5bWVudC5faWQsXHJcbiAgICAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgICBwYXlfZGF0ZTogZm9ybWF0UGF5RGF0ZShwaWdtZVBheW1lbnQ/LnBheV9kYXRlKSxcclxuICAgICAgICAgICAgICBhbW91bnQ6IHBpZ21lUGF5bWVudC5hbW91bnQsXHJcbiAgICAgICAgICAgICAgcmVjZWlwdF9ubzogcGlnbWVQYXltZW50LnJlY2VpcHRfbm8sXHJcbiAgICAgICAgICAgICAgcGF5X3R5cGU6IHBpZ21lUGF5bWVudC5wYXlfdHlwZSxcclxuICAgICAgICAgICAgICBiYWxhbmNlLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBmb3JtYXR0ZWREYXRhLnB1c2goe1xyXG4gICAgICAgICAgICBfaWQ6IFwiXCIsXHJcbiAgICAgICAgICAgIGlkOiBcIlwiLFxyXG4gICAgICAgICAgICBwYXlfZGF0ZTogXCJcIixcclxuICAgICAgICAgICAgcmVjZWlwdF9ubzogXCJcIixcclxuICAgICAgICAgICAgYW1vdW50OiBcIlwiLFxyXG4gICAgICAgICAgICBwYXlfdHlwZTogXCJcIixcclxuICAgICAgICAgICAgYmFsYW5jZSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgc2V0UGlnbWVDdXN0b21lckRhdGEoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldFBpZ21lQ3VzdG9tZXJEYXRhKFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHBpZ21lIHBheW1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldFBpZ21lQ3VzdG9tZXJEYXRhKFtdKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRCYXNpY0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGlmIChFbnJvbGxHcm91cElkLmdyb3VwSWQgPT09IFwiUGlnbWVcIikgZmV0Y2hBbGxQaWdtZVBheW1lbnRzYnlJZCgpO1xyXG4gIH0sIFtFbnJvbGxHcm91cElkLnRpY2tldF0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hHcm91cEJ5SWQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgICAgYC9ncm91cC9nZXQtYnktaWQtZ3JvdXAvJHtFbnJvbGxHcm91cElkLmdyb3VwSWR9YCxcclxuICAgICAgICApO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPj0gNDAwKSB0aHJvdyBuZXcgRXJyb3IoXCJBUEkgRVJST1JcIik7XHJcbiAgICAgICAgc2V0R3JvdXBEZXRhaWxzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIkZhaWxlZCB0byBmZXRjaCBncm91cCBkZXRhaWxzIGJ5IElEOlwiLCBlcnIubWVzc2FnZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBpZiAoRW5yb2xsR3JvdXBJZC5ncm91cElkICE9PSBcIkxvYW5cIiAmJiBFbnJvbGxHcm91cElkLmdyb3VwSWQgIT09IFwiUGlnbWVcIilcclxuICAgICAgZmV0Y2hHcm91cEJ5SWQoKTtcclxuICB9LCBbRW5yb2xsR3JvdXBJZD8udGlja2V0XSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRTY3JlZW5Mb2FkaW5nKHRydWUpO1xyXG5cclxuICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICBzZXREZXRhaWxMb2FkaW5nKHRydWUpO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpO1xyXG4gICAgICAgIHNldEdyb3VwcyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgICBzZXRTY3JlZW5Mb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICBzZXREZXRhaWxMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldERldGFpbExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hHcm91cHMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEJvcnJvd2VyID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldExvYW5DdXN0b21lcnMoW10pO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3BheW1lbnQvbG9hbi91c2VyLyR7c2VsZWN0ZWRHcm91cH1gKTtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSkge1xyXG4gICAgICAgICAgY29uc3QgZmlsdGVyZWRCb3Jyb3dlckRhdGEgPSByZXNwb25zZS5kYXRhPy5vdmVyYWxsX2xvYW4/Lm1hcChcclxuICAgICAgICAgICAgKGxvYW4sIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgICAgIHNsX25vOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgbG9hbjogbG9hbj8ubG9hbl9kZXRhaWxzPy5sb2FuPy5sb2FuX2lkLFxyXG4gICAgICAgICAgICAgIHN0YXJ0X2RhdGU6IGxvYW4/LmxvYW5fZGV0YWlscz8ubG9hbj8uc3RhcnRfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICAgICAgICAgIGVuZF9kYXRlOiBsb2FuPy5sb2FuX2RldGFpbHM/LmxvYW4/LmVuZF9kYXRlPy5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgICAgICAgICAgbG9hbl9hbW91bnQ6IGxvYW4/LmxvYW5fdmFsdWUsXHJcbiAgICAgICAgICAgICAgdGVudXJlOiBsb2FuPy5sb2FuX2RldGFpbHM/LmxvYW4/LnRlbnVyZSxcclxuICAgICAgICAgICAgICBzZXJ2aWNlX2NoYXJnZTogbG9hbj8ubG9hbl9kZXRhaWxzPy5sb2FuPy5zZXJ2aWNlX2NoYXJnZXMsXHJcbiAgICAgICAgICAgICAgbGF0ZV9mZWU6XHJcbiAgICAgICAgICAgICAgICBsb2FuPy5sb2FuX2RldGFpbHM/LmxvYW4/LmV4dHJhX2NoYXJnZXM/LnJlZHVjZShcclxuICAgICAgICAgICAgICAgICAgKHN1bSwgY2hhcmdlKSA9PiBzdW0gKyBOdW1iZXIoY2hhcmdlLmFtb3VudCB8fCAwKSxcclxuICAgICAgICAgICAgICAgICAgMFxyXG4gICAgICAgICAgICAgICAgKSB8fCAwLFxyXG4gICAgICAgICAgICAgIHRvdGFsX3BhaWRfYW1vdW50OiBsb2FuPy50b3RhbF9wYWlkX2Ftb3VudCxcclxuICAgICAgICAgICAgICBiYWxhbmNlOiBsb2FuPy5iYWxhbmNlLFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZEJvcnJvd2VyRGF0YShmaWx0ZXJlZEJvcnJvd2VyRGF0YSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHNldExvYW5DdXN0b21lcnMocmVzcG9uc2UuZGF0YSk7XHJcblxyXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPj0gNDAwKSB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gc2VuZCBtZXNzYWdlXCIpO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcImZhaWxlZCB0byBmZXRjaCBsb2FuIGN1c3RvbWVyc1wiLCBlcnIubWVzc2FnZSk7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRCb3Jyb3dlckRhdGEoW10pO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgc2V0Qm9ycm93ZXJzRGF0YShbXSk7XHJcbiAgICBzZXRCb3Jyb3dlcklkKFwiTm9cIik7XHJcbiAgICBmZXRjaEJvcnJvd2VyKCk7XHJcbiAgfSwgW3NlbGVjdGVkR3JvdXBdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoUGlnbWUgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0UGlnbWVDdXN0b21lcnMoW10pO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3BheW1lbnQvcGlnbWUvdXNlci8ke3NlbGVjdGVkR3JvdXB9YCk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEpIHtcclxuICAgICAgICAgIGNvbnN0IGZpbHRlcmVkUGlnbWVEYXRhID0gcmVzcG9uc2UuZGF0YT8ub3ZlcmFsbF9waWdtZT8ubWFwKFxyXG4gICAgICAgICAgICAocGlnbWUsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgICAgIHNsX25vOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgcGlnbWU6IHBpZ21lPy5waWdtZV9kZXRhaWxzPy5waWdtZT8ucGlnbWVfaWQsXHJcbiAgICAgICAgICAgICAgc3RhcnRfZGF0ZTpcclxuICAgICAgICAgICAgICAgIHBpZ21lPy5waWdtZV9kZXRhaWxzPy5waWdtZT8uc3RhcnRfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICAgICAgICAgIGR1cmF0aW9uOiBwaWdtZT8ucGlnbWVfZGV0YWlscz8ucGlnbWU/LmR1cmF0aW9uLFxyXG4gICAgICAgICAgICAgIG1hdHVyaXR5X2ludGVyZXN0OiBwaWdtZT8ucGlnbWVfZGV0YWlscz8ucGlnbWU/Lm1hdHVyaXR5X2ludGVyZXN0LFxyXG4gICAgICAgICAgICAgIHRvdGFsX2RlcG9zaXRlZF9hbW91bnQ6IHBpZ21lPy50b3RhbF9kZXBvc2l0ZWRfYW1vdW50LFxyXG4gICAgICAgICAgICB9KSxcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZFBpZ21lRGF0YShmaWx0ZXJlZFBpZ21lRGF0YSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHNldFBpZ21lQ3VzdG9tZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG5cclxuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID49IDQwMCkgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIHNlbmQgbWVzc2FnZVwiKTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJmYWlsZWQgdG8gZmV0Y2ggUGlnbWUgY3VzdG9tZXJzXCIsIGVyci5tZXNzYWdlKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZFBpZ21lRGF0YShbXSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBzZXRQaWdtZUN1c3RvbWVyRGF0YShbXSk7XHJcbiAgICBzZXRQaWdtZUlkKFwiTm9cIik7XHJcbiAgICBmZXRjaFBpZ21lKCk7XHJcbiAgfSwgW3NlbGVjdGVkR3JvdXBdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3VzZXIvZ2V0LXVzZXItYnktaWQvJHtzZWxlY3RlZEdyb3VwfWApO1xyXG4gICAgICAgIHNldEdyb3VwKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFtzZWxlY3RlZEdyb3VwXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEdyb3VwcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFtdKTtcclxuICAvLyBkaXNidXJzZW1lbnQgcmVwb3J0XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaERpc2J1cnNlbWVudCA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXREaXNidXJzZW1lbnRMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICAgIGAvcGF5bWVudC1vdXQvZ2V0LXBheW1lbnQtb3V0LXJlcG9ydC1kYXlib29rYCxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgdXNlcklkOiBzZWxlY3RlZEdyb3VwLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSkge1xyXG4gICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlLmRhdGEubWFwKChwYXltZW50LCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgYmFsYW5jZSA9IDA7XHJcblxyXG4gICAgICAgICAgICBiYWxhbmNlICs9IE51bWJlcihwYXltZW50LmFtb3VudCk7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgX2lkOiBwYXltZW50Ll9pZCxcclxuICAgICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICAgIGRpc2J1cnNlbWVudF90eXBlOiBwYXltZW50LmRpc2J1cnNlbWVudF90eXBlLFxyXG4gICAgICAgICAgICAgIC8vIGdyb3VwX25hbWU6IHBheW1lbnQ/Lmdyb3VwX2lkPy5ncm91cF9uYW1lLFxyXG4gICAgICAgICAgICAgIGdyb3VwX25hbWU6XHJcbiAgICAgICAgICAgICAgICBwYXltZW50Py5wYXlfZm9yID09PSBcImxvYW5cIlxyXG4gICAgICAgICAgICAgICAgICA/IGAke3BheW1lbnQ/LmxvYW4/LmxvYW5faWQgfHwgXCJcIn1gXHJcbiAgICAgICAgICAgICAgICAgIDogcGF5bWVudD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgICAgcGF5X2RhdGU6IGZvcm1hdFBheURhdGUocGF5bWVudD8ucGF5X2RhdGUpLFxyXG4gICAgICAgICAgICAgIHRpY2tldDogcGF5bWVudC50aWNrZXQsXHJcbiAgICAgICAgICAgICAgdHJhbnNhY3Rpb25fZGF0ZTogZm9ybWF0UGF5RGF0ZShwYXltZW50LmNyZWF0ZWRBdCksXHJcbiAgICAgICAgICAgICAgYW1vdW50OiBwYXltZW50LmFtb3VudCxcclxuICAgICAgICAgICAgICByZWNlaXB0X25vOiBwYXltZW50LnJlY2VpcHRfbm8sXHJcbiAgICAgICAgICAgICAgcGF5X3R5cGU6IHBheW1lbnQucGF5X3R5cGUsXHJcbiAgICAgICAgICAgICAgZGlzYnVyc2VkX2J5OiBwYXltZW50LmFkbWluX3R5cGU/Lm5hbWUsXHJcbiAgICAgICAgICAgICAgYmFsYW5jZSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIHNldEZpbHRlcmVkRGlzYnVyc2VtZW50KGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZERpc2J1cnNlbWVudChbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBkaXNidXJzZW1lbnQgZGF0YVwiLCBlcnJvciwgZXJyb3IubWVzc2FnZSk7XHJcbiAgICAgICAgc2V0RmlsdGVyZWREaXNidXJzZW1lbnQoW10pO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldERpc2J1cnNlbWVudExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgaWYgKHNlbGVjdGVkR3JvdXApIGZldGNoRGlzYnVyc2VtZW50KCk7XHJcbiAgfSwgW3NlbGVjdGVkR3JvdXBdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3JvdXBQYXltZW50ID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHNldFNlbGVjdGVkQXVjdGlvbkdyb3VwSWQoZ3JvdXBJZCk7XHJcbiAgICBzZXRTZWxlY3RlZEdyb3VwKGdyb3VwSWQpO1xyXG4gICAgaGFuZGxlR3JvdXBBdWN0aW9uQ2hhbmdlKGdyb3VwSWQpO1xyXG4gIH07XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICh1c2VySWQpIHtcclxuICAgICAgaGFuZGxlR3JvdXBQYXltZW50KHVzZXJJZCk7XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVFbnJvbGxHcm91cCA9IChldmVudCkgPT4ge1xyXG4gICAgY29uc3QgdmFsdWUgPSBldmVudC50YXJnZXQudmFsdWU7XHJcblxyXG4gICAgaWYgKHZhbHVlKSB7XHJcbiAgICAgIGNvbnN0IFtncm91cElkLCB0aWNrZXRdID0gdmFsdWUuc3BsaXQoXCJ8XCIpO1xyXG4gICAgICBzZXRFbnJvbGxHcm91cElkKHsgZ3JvdXBJZCwgdGlja2V0IH0pO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0RW5yb2xsR3JvdXBJZCh7IGdyb3VwSWQ6IFwiXCIsIHRpY2tldDogXCJcIiB9KTtcclxuICAgICAgaWYgKGFjdGl2ZVRhYiA9PT0gXCJwZW5hbHR5XCIpIHtcclxuICAgICAgICBzZXRQZW5hbHR5RGF0YShbXSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hDdXN0b21lclRyYW5zYWN0aW9uID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGlmICghc2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCkgcmV0dXJuO1xyXG5cclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgICBgL3BheW1lbnQvdXNlcnMvJHtzZWxlY3RlZEF1Y3Rpb25Hcm91cElkfWAsXHJcbiAgICAgICAgKTtcclxuICAgICAgICBjb25zb2xlLmluZm8ocmVzcG9uc2UuZGF0YS5wYXltZW50cywgXCJGZXRjaGVkIHVzZXIgdHJhbnNhY3Rpb25zXCIpO1xyXG4gICAgICAgIHNldEN1c3RvbWVyVHJhbnNhY3Rpb25zKHJlc3BvbnNlLmRhdGEucGF5bWVudHMpOyAvLyA8LS0gc3RvcmUgaW4gc3RhdGVcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiVW5hYmxlIHRvIGZldGNoIGN1c3RvbWVyIHRyYW5zYWN0aW9uIGRldGFpbHNcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hDdXN0b21lclRyYW5zYWN0aW9uKCk7XHJcbiAgfSwgW3NlbGVjdGVkQXVjdGlvbkdyb3VwSWRdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoUGF5bWVudHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvcGF5bWVudC9nZXQtY3VzdG9tZXItaGlzdG9yeWAsIHtcclxuICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICBmcm9tX2RhdGU6IHNlbGVjdGVkRnJvbURhdGUsXHJcbiAgICAgICAgICAgIHRvX2RhdGU6IHNlbGVjdGVkVG9EYXRlLFxyXG4gICAgICAgICAgICBncm91cElkOiBzZWxlY3RlZEF1Y3Rpb25Hcm91cElkLFxyXG4gICAgICAgICAgICB1c2VySWQ6IHNlbGVjdGVkQ3VzdG9tZXJzLFxyXG4gICAgICAgICAgICBwYXlfdHlwZTogc2VsZWN0ZWRQYXltZW50TW9kZSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xyXG5cclxuICAgICAgICAgIGNvbnN0IHBheW1lbnREYXRhID0gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgICAgIGNvbnN0IHRvdGFsQW1vdW50ID0gcGF5bWVudERhdGEucmVkdWNlKFxyXG4gICAgICAgICAgICAoc3VtLCBwYXltZW50KSA9PiBzdW0gKyBOdW1iZXIocGF5bWVudC5hbW91bnQgfHwgMCksXHJcbiAgICAgICAgICAgIDAsXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgICAgc2V0UGF5bWVudHModG90YWxBbW91bnQpO1xyXG4gICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlLmRhdGEubWFwKChncm91cCwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgIGdyb3VwOiBncm91cC5ncm91cF9pZD8uZ3JvdXBfbmFtZSxcclxuICAgICAgICAgICAgbmFtZTogZ3JvdXAudXNlcl9pZD8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgICBwaG9uZV9udW1iZXI6IGdyb3VwPy51c2VyX2lkPy5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgIHRpY2tldDogZ3JvdXA/LnRpY2tldCxcclxuICAgICAgICAgICAgYW1vdW50OiBncm91cD8uYW1vdW50LFxyXG4gICAgICAgICAgICBtb2RlOiBncm91cD8ucGF5X3R5cGUsXHJcbiAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICBzZXRUYWJsZURheWJvb2soZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBwYXltZW50IGRhdGE6XCIsIGVycm9yKTtcclxuXHJcbiAgICAgICAgc2V0UGF5bWVudHMoMCk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hQYXltZW50cygpO1xyXG4gIH0sIFtcclxuICAgIHNlbGVjdGVkQXVjdGlvbkdyb3VwSWQsXHJcbiAgICBzZWxlY3RlZFRvRGF0ZSxcclxuICAgIHNlbGVjdGVkRnJvbURhdGUsXHJcbiAgICBzZWxlY3RlZFBheW1lbnRNb2RlLFxyXG4gICAgc2VsZWN0ZWRDdXN0b21lcnMsXHJcbiAgXSk7XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGdldEFjdGl2ZUN1c3RvbWVyRW5yb2xsbWVudERhdGEoKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRFbnJvbGxtZW50RGF0YUxvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9lbnJvbGwvY3VzdG9tZXJzLyR7c2VsZWN0ZWRHcm91cH1gKTtcclxuICAgICAgY29uc3QgcmVzcG9uc2VEYXRhID0gcmVzcG9uc2U/LmRhdGE/LmRhdGEgPz8gW107XHJcblxyXG4gICAgICBzZXRFbnJvbGxtZW50RGF0YShyZXNwb25zZURhdGEpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgc2V0RW5yb2xsbWVudERhdGEoW10pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0RW5yb2xsbWVudERhdGFMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChhY3RpdmVUYWIgPT09IFwiY3VzdG9tZXJQYXltZW50U3RhdGVtZW50XCIpXHJcbiAgICAgIGdldEFjdGl2ZUN1c3RvbWVyRW5yb2xsbWVudERhdGEoKTtcclxuICB9LCBbYWN0aXZlVGFiLCBzZWxlY3RlZEdyb3VwXSk7XHJcblxyXG5cclxuICBjb25zdCBmZXRjaEFjY291bnREZXRhaWxzID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgaWYgKCF1c2VySWQpIHJldHVybjtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRBY2NvdW50RGV0YWlsc0xvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgYC92MS9hZG1pbi91c2VyLWFjY291bnRzLyR7dXNlcklkfS9sZWRnZXJgLFxyXG4gICAgICApO1xyXG5cclxuICAgICAgY29uc29sZS5pbmZvKHJlc3BvbnNlLCBcImNoZWNraW5nIHRyYW5zYWN0aW9uXCIpO1xyXG5cclxuICAgICAgaWYgKHJlc3BvbnNlPy5kYXRhPy5zdGF0dXMpIHtcclxuICAgICAgICBzZXRBY2NvdW50RGV0YWlscyhyZXNwb25zZS5kYXRhLmRhdGEpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEFjY291bnREZXRhaWxzKG51bGwpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYWNjb3VudCBkZXRhaWxzOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFjY291bnREZXRhaWxzKG51bGwpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0QWNjb3VudERldGFpbHNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHNlbGVjdGVkR3JvdXAgJiYgYWN0aXZlVGFiID09PSBcImFjY291bnREZWFpbHNcIikge1xyXG4gICAgICBmZXRjaEFjY291bnREZXRhaWxzKHNlbGVjdGVkR3JvdXApO1xyXG4gICAgfVxyXG4gIH0sIFtzZWxlY3RlZEdyb3VwLCBhY3RpdmVUYWJdKTtcclxuXHJcbiAgY29uc3QgZmlsdGVyZWRMZWRnZXJEYXRhID0gc2VsZWN0ZWRHcm91cFxyXG4gICAgPyBhY2NvdW50RGV0YWlscz8udXNlcmFjY291bnRzPy5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0uX2lkID09PSBzZWxlY3RlZEdyb3VwKVxyXG4gICAgOiBhY2NvdW50RGV0YWlscz8udXNlcmFjY291bnRzIHx8IFtdO1xyXG5cclxuICAvL3NhbmpheVxyXG4gIGNvbnN0IGZldGNoQ3VzdG9tZXJQZW5hbHR5ID0gYXN5bmMgKGdyb3VwSWQsIHRpY2tldCkgPT4ge1xyXG4gICAgaWYgKCFzZWxlY3RlZEdyb3VwIHx8ICFncm91cElkIHx8ICF0aWNrZXQpIHtcclxuICAgICAgc2V0UGVuYWx0eURhdGEoW10pO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGlzRmV0Y2hpbmdQZW5hbHR5LmN1cnJlbnQpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGlzRmV0Y2hpbmdQZW5hbHR5LmN1cnJlbnQgPSB0cnVlO1xyXG4gICAgICBzZXRQZW5hbHR5TG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL3BlbmFsdHktbWFuYWdlbWVudC9jdXN0b21lci1wZW5hbHR5LyR7c2VsZWN0ZWRHcm91cH0vJHtncm91cElkfS8ke3RpY2tldH1gLFxyXG4gICAgICApO1xyXG5cclxuICAgICAgaWYgKHJlc3BvbnNlLmRhdGE/LnN1Y2Nlc3MgJiYgcmVzcG9uc2UuZGF0YT8uZGF0YSkge1xyXG4gICAgICAgIGNvbnN0IGRhdGEgPSByZXNwb25zZS5kYXRhLmRhdGE7XHJcblxyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZFBlbmFsdHkgPSB7XHJcbiAgICAgICAgICBlbnJvbGxtZW50SWQ6IGRhdGEuZW5yb2xsbWVudElkIHx8IGdyb3VwSWQsXHJcbiAgICAgICAgICBncm91cE5hbWU6IGRhdGEuZ3JvdXA/Lmdyb3VwX25hbWUgfHwgZGF0YS5ncm91cE5hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIHRpY2tldDogdGlja2V0LFxyXG4gICAgICAgICAgY3VzdG9tZXJOYW1lOlxyXG4gICAgICAgICAgICBkYXRhLnVzZXI/LmZ1bGxfbmFtZSB8fFxyXG4gICAgICAgICAgICBkYXRhLmN1c3RvbWVyTmFtZSB8fFxyXG4gICAgICAgICAgICBncm91cD8uZnVsbF9uYW1lIHx8XHJcbiAgICAgICAgICAgIFwiTi9BXCIsXHJcbiAgICAgICAgICBjdXN0b21lclBob25lOlxyXG4gICAgICAgICAgICBkYXRhLnVzZXI/LnBob25lX251bWJlciB8fFxyXG4gICAgICAgICAgICBkYXRhLmN1c3RvbWVyUGhvbmUgfHxcclxuICAgICAgICAgICAgZ3JvdXA/LnBob25lX251bWJlciB8fFxyXG4gICAgICAgICAgICBcIk4vQVwiLFxyXG4gICAgICAgICAgdG90YWxFeHBlY3RlZDogZGF0YS5zdW1tYXJ5Py50b3RhbEV4cGVjdGVkIHx8IDAsXHJcbiAgICAgICAgICB0b3RhbFBhaWQ6IGRhdGEuc3VtbWFyeT8udG90YWxQYWlkIHx8IDAsXHJcbiAgICAgICAgICB0b3RhbFBlbmFsdHk6IGRhdGEuc3VtbWFyeT8udG90YWxQZW5hbHR5IHx8IDAsXHJcbiAgICAgICAgICB0b3RhbExhdGVGZWU6IGRhdGEuc3VtbWFyeT8udG90YWxMYXRlRmVlIHx8IDAsXHJcbiAgICAgICAgICB2Y1BlbmFsdHk6IGRhdGEuc3VtbWFyeT8udmNQZW5hbHR5IHx8IDAsXHJcbiAgICAgICAgICBncmFuZFRvdGFsRHVlOiBkYXRhLnN1bW1hcnk/LnRvdGFsRHVlIHx8IDAsXHJcbiAgICAgICAgICBiYWxhbmNlV2l0aG91dFBlbmFsdHk6IGRhdGEuc3VtbWFyeT8uY3VycmVudEJhbGFuY2UgfHwgMCxcclxuICAgICAgICAgIGN1cnJlbnRCYWxhbmNlOiBkYXRhLnN1bW1hcnk/LmN1cnJlbnRCYWxhbmNlIHx8IDAsXHJcbiAgICAgICAgICBjeWNsZXM6XHJcbiAgICAgICAgICAgIGRhdGEucGVuYWx0aWVzPy5tYXAoKHApID0+ICh7XHJcbiAgICAgICAgICAgICAgY3ljbGVfbm86IHAuY3ljbGVfbm8sXHJcbiAgICAgICAgICAgICAgZHVlX2RhdGU6IHAuZHVlX2RhdGUsXHJcbiAgICAgICAgICAgICAgZXhwZWN0ZWQ6IHAuZXhwZWN0ZWQsXHJcbiAgICAgICAgICAgICAgcGFpZDogcC5wYWlkLFxyXG4gICAgICAgICAgICAgIGJhbGFuY2U6IHAuYmFsYW5jZSxcclxuICAgICAgICAgICAgICBwZW5hbHR5OiBwLnBlbmFsdHlfYW1vdW50LFxyXG4gICAgICAgICAgICAgIGxhdGVfcGF5bWVudF9jaGFyZ2VzOiBwLmxhdGVfZmVlX2Ftb3VudCxcclxuICAgICAgICAgICAgICBzdGF0dXM6IHAuc3RhdHVzLFxyXG4gICAgICAgICAgICB9KSkgfHwgW10sXHJcbiAgICAgICAgICBwZW5hbHR5UmVjb3JkSWQ6IGRhdGEucGVuYWx0aWVzPy5bMF0/Ll9pZCB8fCBudWxsLFxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIHNldFBlbmFsdHlEYXRhKFtmb3JtYXR0ZWRQZW5hbHR5XSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0UGVuYWx0eURhdGEoW10pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcGVuYWx0eTpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRQZW5hbHR5RGF0YShbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRQZW5hbHR5TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIGlzRmV0Y2hpbmdQZW5hbHR5LmN1cnJlbnQgPSBmYWxzZTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmb3JtYXRQZW5hbHR5QW1vdW50ID0gKGFtb3VudCkgPT4ge1xyXG4gICAgcmV0dXJuIGDigrkkeyhhbW91bnQgfHwgMCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IFBlbmFsdHlDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwic2xfbm9cIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJncm91cE5hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxFeHBlY3RlZFwiLCBoZWFkZXI6IFwiVG90YWwgRXhwZWN0ZWRcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxQYWlkXCIsIGhlYWRlcjogXCJUb3RhbCBQYWlkXCIgfSxcclxuICAgIHsga2V5OiBcImJhbGFuY2VXaXRob3V0UGVuYWx0eVwiLCBoZWFkZXI6IFwiQmFsYW5jZSAody9vIFBlbmFsdHkpXCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsUGVuYWx0eVwiLCBoZWFkZXI6IFwiVG90YWwgUGVuYWx0eVwiIH0sXHJcbiAgICB7IGtleTogXCJ0b3RhbExhdGVGZWVcIiwgaGVhZGVyOiBcIkxhdGUgRmVlXCIgfSxcclxuICAgIHsga2V5OiBcInZjUGVuYWx0eVwiLCBoZWFkZXI6IFwiVkMgUGVuYWx0eVwiIH0sXHJcbiAgICB7IGtleTogXCJncmFuZFRvdGFsRHVlXCIsIGhlYWRlcjogXCJUb3RhbCBPdXRzdGFuZGluZ1wiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIlZpZXcgRGV0YWlsc1wiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgUGVuYWx0eUJyZWFrZG93bkNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJjeWNsZV9ub1wiLCBoZWFkZXI6IFwiQXVjdGlvbiBOby5cIiB9LFxyXG4gICAgeyBrZXk6IFwiZHVlX2RhdGVcIiwgaGVhZGVyOiBcIkR1ZSBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImV4cGVjdGVkXCIsIGhlYWRlcjogXCJFeHBlY3RlZCBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwicGFpZFwiLCBoZWFkZXI6IFwiUGFpZCBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmFsYW5jZVwiLCBoZWFkZXI6IFwiQmFsYW5jZVwiIH0sXHJcbiAgICB7IGtleTogXCJwZW5hbHR5XCIsIGhlYWRlcjogXCJQZW5hbHR5XCIgfSxcclxuICAgIHsga2V5OiBcImxhdGVfcGF5bWVudF9jaGFyZ2VzXCIsIGhlYWRlcjogXCJMYXRlIEZlZVwiIH0sXHJcbiAgICB7IGtleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgcGVuYWx0eUhpc3RvcnlDb2x1bW5zID0gW1xyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJEYXRlXCIsXHJcbiAgICAgIGRhdGFJbmRleDogXCJjcmVhdGVkQXRcIixcclxuICAgICAga2V5OiBcImRhdGVcIixcclxuICAgICAgcmVuZGVyOiAoZGF0ZSkgPT4gbW9tZW50KGRhdGUpLmZvcm1hdChcIkRELU1NLVlZWVkgSEg6bW1cIiksXHJcbiAgICAgIHNvcnRlcjogKGEsIGIpID0+IG5ldyBEYXRlKGEuY3JlYXRlZEF0KSAtIG5ldyBEYXRlKGIuY3JlYXRlZEF0KSxcclxuICAgICAgZGVmYXVsdFNvcnRPcmRlcjogXCJkZXNjZW5kXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJQZW5hbHR5IEFtb3VudFwiLFxyXG4gICAgICBkYXRhSW5kZXg6IFwicGVuYWx0eV9hbW91bnRcIixcclxuICAgICAga2V5OiBcInBlbmFsdHlfYW1vdW50XCIsXHJcbiAgICAgIGFsaWduOiBcInJpZ2h0XCIsXHJcbiAgICAgIHJlbmRlcjogKGFtb3VudCkgPT5cclxuICAgICAgICBhbW91bnQgPiAwID8gYOKCuSR7KGFtb3VudCB8fCAwKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWAgOiBcIi1cIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRpdGxlOiBcIkxhdGUgRmVlXCIsXHJcbiAgICAgIGRhdGFJbmRleDogXCJsYXRlX2ZlZV9hbW91bnRcIixcclxuICAgICAga2V5OiBcImxhdGVfZmVlX2Ftb3VudFwiLFxyXG4gICAgICBhbGlnbjogXCJyaWdodFwiLFxyXG4gICAgICByZW5kZXI6IChhbW91bnQpID0+XHJcbiAgICAgICAgYW1vdW50ID4gMCA/IGDigrkkeyhhbW91bnQgfHwgMCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gIDogXCItXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJUb3RhbCBBbW91bnRcIixcclxuICAgICAga2V5OiBcInRvdGFsXCIsXHJcbiAgICAgIGFsaWduOiBcInJpZ2h0XCIsXHJcbiAgICAgIHJlbmRlcjogKF8sIHJlY29yZCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHRvdGFsID1cclxuICAgICAgICAgIChyZWNvcmQucGVuYWx0eV9hbW91bnQgfHwgMCkgKyAocmVjb3JkLmxhdGVfZmVlX2Ftb3VudCB8fCAwKTtcclxuICAgICAgICByZXR1cm4gYOKCuSR7dG90YWwudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gO1xyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdGl0bGU6IFwiUmVhc29uXCIsXHJcbiAgICAgIGRhdGFJbmRleDogXCJyZWFzb25cIixcclxuICAgICAga2V5OiBcInJlYXNvblwiLFxyXG4gICAgICByZW5kZXI6IChyZWFzb24pID0+IHJlYXNvbiB8fCBcIk5vIHJlYXNvbiBwcm92aWRlZFwiLFxyXG4gICAgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCBmb3JtYXR0ZWRDdXN0b21lclBlbmFsdHlEYXRhID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICByZXR1cm4gcGVuYWx0eURhdGEubWFwKChpdGVtLCBpbmRleCkgPT4gKHtcclxuICAgICAga2V5OiBpdGVtLmVucm9sbG1lbnRJZCxcclxuICAgICAgc2xfbm86IGluZGV4ICsgMSxcclxuICAgICAgZ3JvdXBOYW1lOiBpdGVtLmdyb3VwTmFtZSxcclxuICAgICAgdGlja2V0OiBpdGVtLnRpY2tldCxcclxuICAgICAgdG90YWxFeHBlY3RlZDogZm9ybWF0UGVuYWx0eUFtb3VudChpdGVtLnRvdGFsRXhwZWN0ZWQpLFxyXG4gICAgICB0b3RhbFBhaWQ6IGZvcm1hdFBlbmFsdHlBbW91bnQoaXRlbS50b3RhbFBhaWQpLFxyXG4gICAgICBiYWxhbmNlV2l0aG91dFBlbmFsdHk6IChcclxuICAgICAgICA8c3BhblxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtcclxuICAgICAgICAgICAgaXRlbS5iYWxhbmNlV2l0aG91dFBlbmFsdHkgPD0gMFxyXG4gICAgICAgICAgICAgID8gXCJ0ZXh0LWdyZWVuLTYwMCBmb250LXNlbWlib2xkXCJcclxuICAgICAgICAgICAgICA6IFwidGV4dC1vcmFuZ2UtNjAwIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtmb3JtYXRQZW5hbHR5QW1vdW50KE1hdGguYWJzKGl0ZW0uYmFsYW5jZVdpdGhvdXRQZW5hbHR5IHx8IDApKX1cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICksXHJcbiAgICAgIHRvdGFsUGVuYWx0eTogZm9ybWF0UGVuYWx0eUFtb3VudChpdGVtLnRvdGFsUGVuYWx0eSksXHJcbiAgICAgIHRvdGFsTGF0ZUZlZTogZm9ybWF0UGVuYWx0eUFtb3VudChpdGVtLnRvdGFsTGF0ZUZlZSksXHJcbiAgICAgIHZjUGVuYWx0eTogZm9ybWF0UGVuYWx0eUFtb3VudChpdGVtLnZjUGVuYWx0eSksXHJcbiAgICAgIGdyYW5kVG90YWxEdWU6IChcclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDAgZm9udC1ib2xkIHRleHQtYmFzZVwiPlxyXG4gICAgICAgICAge2Zvcm1hdFBlbmFsdHlBbW91bnQoaXRlbS5ncmFuZFRvdGFsRHVlKX1cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICksXHJcbiAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgIDxCdXR0b25cclxuICAgICAgICAgIHR5cGU9XCJsaW5rXCJcclxuICAgICAgICAgIGljb249ezxFeWVPdXRsaW5lZCAvPn1cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNob3dQZW5hbHR5QnJlYWtkb3duKGl0ZW0pfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgVmlldyBDeWNsZXNcclxuICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgKSxcclxuICAgIH0pKTtcclxuICB9LCBbcGVuYWx0eURhdGFdKTtcclxuXHJcbiAgY29uc3Qgc2hvd1BlbmFsdHlCcmVha2Rvd24gPSAocGVuYWx0eSkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRQZW5hbHR5KHBlbmFsdHkpO1xyXG4gICAgc2V0QnJlYWtkb3duTW9kYWxWaXNpYmxlKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZvcm1hdHRlZFBlbmFsdHlDeWNsZXMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGlmICghc2VsZWN0ZWRQZW5hbHR5Py5jeWNsZXMpIHJldHVybiBbXTtcclxuXHJcbiAgICByZXR1cm4gc2VsZWN0ZWRQZW5hbHR5LmN5Y2xlcy5tYXAoKGN5Y2xlLCBpbmRleCkgPT4gKHtcclxuICAgICAga2V5OiBpbmRleCxcclxuICAgICAgY3ljbGVfbm86IGN5Y2xlLmN5Y2xlX25vIHx8IGluZGV4ICsgMSxcclxuICAgICAgZHVlX2RhdGU6IGN5Y2xlLmR1ZV9kYXRlXHJcbiAgICAgICAgPyBkYXlqcyhjeWNsZS5kdWVfZGF0ZSkuZm9ybWF0KFwiREQtTU0tWVlZWVwiKVxyXG4gICAgICAgIDogXCJOL0FcIixcclxuICAgICAgZXhwZWN0ZWQ6IGZvcm1hdFBlbmFsdHlBbW91bnQoY3ljbGUuZXhwZWN0ZWQpLFxyXG4gICAgICBwYWlkOiBmb3JtYXRQZW5hbHR5QW1vdW50KGN5Y2xlLnBhaWQpLFxyXG4gICAgICBiYWxhbmNlOiAoXHJcbiAgICAgICAgPHNwYW5cclxuICAgICAgICAgIGNsYXNzTmFtZT17Y3ljbGUuYmFsYW5jZSA8PSAwID8gXCJ0ZXh0LWdyZWVuLTYwMFwiIDogXCJ0ZXh0LW9yYW5nZS02MDBcIn1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7Zm9ybWF0UGVuYWx0eUFtb3VudChNYXRoLmFicyhjeWNsZS5iYWxhbmNlIHx8IDApKX1cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICksXHJcbiAgICAgIHBlbmFsdHk6IGZvcm1hdFBlbmFsdHlBbW91bnQoY3ljbGUucGVuYWx0eSksXHJcbiAgICAgIGxhdGVfcGF5bWVudF9jaGFyZ2VzOiBmb3JtYXRQZW5hbHR5QW1vdW50KGN5Y2xlLmxhdGVfcGF5bWVudF9jaGFyZ2VzKSxcclxuICAgICAgc3RhdHVzOiAoXHJcbiAgICAgICAgPFRhZ1xyXG4gICAgICAgICAgY29sb3I9e1xyXG4gICAgICAgICAgICBjeWNsZS5iYWxhbmNlID09PSAwID8gXCJncmVlblwiIDogY3ljbGUuYmFsYW5jZSA+IDAgPyBcInJlZFwiIDogXCJvcmFuZ2VcIlxyXG4gICAgICAgICAgfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtjeWNsZS5iYWxhbmNlID09PSAwXHJcbiAgICAgICAgICAgID8gXCJQYWlkXCJcclxuICAgICAgICAgICAgOiBjeWNsZS5iYWxhbmNlID4gMFxyXG4gICAgICAgICAgICAgID8gXCJQZW5kaW5nXCJcclxuICAgICAgICAgICAgICA6IFwiRXhjZXNzXCJ9XHJcbiAgICAgICAgPC9UYWc+XHJcbiAgICAgICksXHJcbiAgICB9KSk7XHJcbiAgfSwgW3NlbGVjdGVkUGVuYWx0eV0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKFxyXG4gICAgICBhY3RpdmVUYWIgPT09IFwicGVuYWx0eVwiICYmXHJcbiAgICAgIHNlbGVjdGVkR3JvdXAgJiZcclxuICAgICAgRW5yb2xsR3JvdXBJZC5ncm91cElkICYmXHJcbiAgICAgIEVucm9sbEdyb3VwSWQudGlja2V0XHJcbiAgICApIHtcclxuICAgICAgZmV0Y2hDdXN0b21lclBlbmFsdHkoRW5yb2xsR3JvdXBJZC5ncm91cElkLCBFbnJvbGxHcm91cElkLnRpY2tldCk7XHJcbiAgICB9IGVsc2UgaWYgKGFjdGl2ZVRhYiA9PT0gXCJwZW5hbHR5XCIpIHtcclxuICAgICAgc2V0UGVuYWx0eURhdGEoW10pO1xyXG4gICAgfVxyXG4gIH0sIFthY3RpdmVUYWIsIHNlbGVjdGVkR3JvdXAsIEVucm9sbEdyb3VwSWQuZ3JvdXBJZCwgRW5yb2xsR3JvdXBJZC50aWNrZXRdKTtcclxuXHJcbiAgLy8gdXNlRWZmZWN0KCgpID0+IHtcclxuICAvLyAgIGlmIChzZWxlY3RlZEdyb3VwKSB7XHJcbiAgLy8gICAgIGZldGNoQ3VzdG9tZXJQZW5hbHR5KCk7XHJcbiAgLy8gICB9XHJcbiAgLy8gfSwgW3NlbGVjdGVkR3JvdXBdKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hDdXN0b21lckJpZFJlcXVlc3RzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFzZWxlY3RlZEdyb3VwKSByZXR1cm47IC8vIHNlbGVjdGVkR3JvdXAgaG9sZHMgdGhlIHVzZXJJZCBpbiB5b3VyIGNvZGVcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRCaWRSZXF1ZXN0c0xvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgICAvLyBDYWxsIHRoZSBuZXcgZGVkaWNhdGVkIGVuZHBvaW50XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL2JpZC1yZXF1ZXN0L2dldC1ieS11c2VyLyR7c2VsZWN0ZWRHcm91cH1gLFxyXG4gICAgICApO1xyXG5cclxuICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5zdWNjZXNzKSB7XHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlLmRhdGEuZGF0YS5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICBjb25zdCB1c2VyT2JqZWN0ID0gaXRlbT8uc3Vic2NyaWJlcklkIHx8IHt9O1xyXG4gICAgICAgICAgY29uc3QgZ3JvdXBPYmplY3QgPSBpdGVtPy5ncm91cElkIHx8IHt9O1xyXG4gICAgICAgICAgY29uc3QgYmFsYW5jZSA9IGl0ZW0/LmF1Y3Rpb25zPy5iYWxhbmNlIHx8IDA7XHJcblxyXG4gICAgICAgICAgY29uc3QgZ2V0U3RhdHVzQ29sb3IgPSAoc3RhdHVzKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IHN0YXR1c0NvbG9ycyA9IHtcclxuICAgICAgICAgICAgICBQZW5kaW5nOiBcIm9yYW5nZVwiLFxyXG4gICAgICAgICAgICAgIEFjY2VwdDogXCJncmVlblwiLFxyXG4gICAgICAgICAgICAgIERlY2xpbmU6IFwicmVkXCIsXHJcbiAgICAgICAgICAgICAgTmV4dEF1Y3Rpb246IFwiYmx1ZVwiLFxyXG4gICAgICAgICAgICAgIFByaXplZDogXCJwdXJwbGVcIixcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgcmV0dXJuIHN0YXR1c0NvbG9yc1tzdGF0dXNdIHx8IFwiZGVmYXVsdFwiO1xyXG4gICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBfaWQ6IGl0ZW0uX2lkLFxyXG4gICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICBiaWRfcmVxdWVzdF9jb2RlOiBpdGVtLmJpZF9yZXF1ZXN0X2NvZGUgfHwgYEJSLSR7aW5kZXggKyAxfWAsXHJcbiAgICAgICAgICAgIHJlcXVlc3RfZGF0ZTogaXRlbS5jcmVhdGVkQXRcclxuICAgICAgICAgICAgICA/IGRheWpzKGl0ZW0uY3JlYXRlZEF0KS5mb3JtYXQoXCJERC1NTS1ZWVlZXCIpXHJcbiAgICAgICAgICAgICAgOiBcIk4vQVwiLFxyXG4gICAgICAgICAgICB1c2VyX25hbWU6XHJcbiAgICAgICAgICAgICAgaXRlbS5zdWJzY3JpYmVyTmFtZSB8fFxyXG4gICAgICAgICAgICAgICh0eXBlb2YgdXNlck9iamVjdCA9PT0gXCJvYmplY3RcIiA/IHVzZXJPYmplY3QuZnVsbF9uYW1lIDogXCJOL0FcIiksXHJcbiAgICAgICAgICAgIGdyb3VwX25hbWU6XHJcbiAgICAgICAgICAgICAgaXRlbS5ncm91cE5hbWUgfHxcclxuICAgICAgICAgICAgICAodHlwZW9mIGdyb3VwT2JqZWN0ID09PSBcIm9iamVjdFwiXHJcbiAgICAgICAgICAgICAgICA/IGdyb3VwT2JqZWN0Lmdyb3VwX25hbWVcclxuICAgICAgICAgICAgICAgIDogXCJOL0FcIiksXHJcbiAgICAgICAgICAgIHRpY2tldF9udW1iZXI6IGl0ZW0udGlja2V0TnVtYmVyIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICBhdWN0aW9uX2RhdGU6IGl0ZW0uYXVjdGlvbkRhdGVcclxuICAgICAgICAgICAgICA/IGRheWpzKGl0ZW0uYXVjdGlvbkRhdGUpLmZvcm1hdChcIkRELU1NLVlZWVlcIilcclxuICAgICAgICAgICAgICA6IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIGF1Y3Rpb25fdGltZTogaXRlbS5hdWN0aW9uX3RpbWVcclxuICAgICAgICAgICAgICA/IGRheWpzKGl0ZW0uYXVjdGlvbl90aW1lLCBcIkhIOm1tXCIpLmZvcm1hdChcImg6bW0gQVwiKVxyXG4gICAgICAgICAgICAgIDogXCItXCIsXHJcbiAgICAgICAgICAgIGJhbGFuY2U6IGJhbGFuY2UsXHJcbiAgICAgICAgICAgIGJhbGFuY2VfZGlzcGxheTogYOKCuSR7YmFsYW5jZT8udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKSB8fCAwfWAsXHJcbiAgICAgICAgICAgIHN0YXR1czogaXRlbS5zdGF0dXMgfHwgXCJQZW5kaW5nXCIsXHJcbiAgICAgICAgICAgIHN0YXR1c19jb2xvcjogZ2V0U3RhdHVzQ29sb3IoaXRlbS5zdGF0dXMpLFxyXG4gICAgICAgICAgICByZWZlcnJlZF9ieTogaXRlbS5yZWZlcnJlZF9ieSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICBhZG1pbl91c2VyOiBpdGVtLmFkbWluTmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICBhdWN0aW9uX2N5Y2xlOiBpdGVtLmF1Y3Rpb25fY3ljbGUgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgbW9iaWxlTnVtYmVyOlxyXG4gICAgICAgICAgICAgIGl0ZW0ubW9iaWxlTnVtYmVyIHx8XHJcbiAgICAgICAgICAgICAgKHR5cGVvZiB1c2VyT2JqZWN0ID09PSBcIm9iamVjdFwiXHJcbiAgICAgICAgICAgICAgICA/IHVzZXJPYmplY3QucGhvbmVfbnVtYmVyXHJcbiAgICAgICAgICAgICAgICA6IFwiTi9BXCIpLFxyXG4gICAgICAgICAgICBuZXh0X2F1Y3Rpb25fZGF0ZTogaXRlbS5sYXRlc3RfYXVjdGlvbj8ubmV4dF9kYXRlXHJcbiAgICAgICAgICAgICAgPyBkYXlqcyhpdGVtLmxhdGVzdF9hdWN0aW9uLm5leHRfZGF0ZSkuZm9ybWF0KFwiREQtTU0tWVlZWVwiKVxyXG4gICAgICAgICAgICAgIDogXCJOL0FcIixcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHNldEJpZFJlcXVlc3RzRGF0YShmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRCaWRSZXF1ZXN0c0RhdGEoW10pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYmlkIHJlcXVlc3RzOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEJpZFJlcXVlc3RzRGF0YShbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRCaWRSZXF1ZXN0c0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIEFkZCB1c2VFZmZlY3QgdG8gZmV0Y2ggYmlkIHJlcXVlc3RzIHdoZW4gYmlkIHJlcXVlc3QgdGFiIGlzIGFjdGl2ZVxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoYWN0aXZlVGFiID09PSBcImJpZHJlcXVlc3RcIiAmJiBzZWxlY3RlZEdyb3VwKSB7XHJcbiAgICAgIGZldGNoQ3VzdG9tZXJCaWRSZXF1ZXN0cygpO1xyXG4gICAgfVxyXG4gIH0sIFthY3RpdmVUYWIsIHNlbGVjdGVkR3JvdXBdKTtcclxuXHJcbiAgLy8gQWRkIGZ1bmN0aW9uIHRvIHNob3cgYmlkIHJlcXVlc3QgZGV0YWlscyBtb2RhbFxyXG4gIGNvbnN0IHNob3dCaWRSZXF1ZXN0RGV0YWlscyA9IChiaWRSZXF1ZXN0KSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZEJpZFJlcXVlc3QoYmlkUmVxdWVzdCk7XHJcbiAgICBzZXRCaWRSZXF1ZXN0TW9kYWxWaXNpYmxlKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIC8vIEFkZCBiaWQgcmVxdWVzdCBjb2x1bW5zIGZvciB0aGUgdGFibGVcclxuICBjb25zdCBCaWRSZXF1ZXN0Q29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcInNsX25vXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiYmlkX3JlcXVlc3RfY29kZVwiLCBoZWFkZXI6IFwiQmlkIFJlcXVlc3QgQ29kZVwiIH0sXHJcbiAgICB7IGtleTogXCJyZXF1ZXN0X2RhdGVcIiwgaGVhZGVyOiBcIlJlcXVlc3QgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInRpY2tldF9udW1iZXJcIiwgaGVhZGVyOiBcIlRpY2tldFwiIH0sXHJcbiAgICB7IGtleTogXCJhdWN0aW9uX2RhdGVcIiwgaGVhZGVyOiBcIkF1Y3Rpb24gRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJhdWN0aW9uX3RpbWVcIiwgaGVhZGVyOiBcIkF1Y3Rpb24gVGltZVwiIH0sXHJcbiAgICB7IGtleTogXCJiYWxhbmNlX2Rpc3BsYXlcIiwgaGVhZGVyOiBcIkJhbGFuY2VcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGZldGNoQ3VzdG9tZXJWaXNpdG9ycyA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmICghc2VsZWN0ZWRHcm91cCkgcmV0dXJuO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIHNldFZpc2l0b3JMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgICAgLy8gRmV0Y2ggdmlzaXRvcnMgZm9yIHNwZWNpZmljIHVzZXIgdXNpbmcgdGhlIGVuZHBvaW50XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3Zpc2l0b3JzL3VzZXIvJHtzZWxlY3RlZEdyb3VwfWApO1xyXG4gICAgICBsZXQgdmlzaXRvcnMgPSBbXTtcclxuXHJcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KHJlc3BvbnNlLmRhdGEpKSB7XHJcbiAgICAgICAgdmlzaXRvcnMgPSByZXNwb25zZS5kYXRhO1xyXG4gICAgICB9IGVsc2UgaWYgKHJlc3BvbnNlLmRhdGEuZGF0YSAmJiBBcnJheS5pc0FycmF5KHJlc3BvbnNlLmRhdGEuZGF0YSkpIHtcclxuICAgICAgICB2aXNpdG9ycyA9IHJlc3BvbnNlLmRhdGEuZGF0YTtcclxuICAgICAgfSBlbHNlIGlmIChcclxuICAgICAgICByZXNwb25zZS5kYXRhLnZpc2l0b3JzICYmXHJcbiAgICAgICAgQXJyYXkuaXNBcnJheShyZXNwb25zZS5kYXRhLnZpc2l0b3JzKVxyXG4gICAgICApIHtcclxuICAgICAgICB2aXNpdG9ycyA9IHJlc3BvbnNlLmRhdGEudmlzaXRvcnM7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdmlzaXRvcnMgPVxyXG4gICAgICAgICAgT2JqZWN0LnZhbHVlcyhyZXNwb25zZS5kYXRhKS5maW5kKCh2KSA9PiBBcnJheS5pc0FycmF5KHYpKSB8fCBbXTtcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gRm9ybWF0IHRoZSB2aXNpdG9yIGRhdGFcclxuICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHZpc2l0b3JzLm1hcCgoaXRlbSwgaW5kZXgpID0+IHtcclxuICAgICAgICBjb25zdCBmb3JtYXREYXRlVGltZSA9IChkYXRlU3RyaW5nKSA9PiB7XHJcbiAgICAgICAgICBpZiAoIWRhdGVTdHJpbmcpIHJldHVybiBcIk4vQVwiO1xyXG4gICAgICAgICAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKGRhdGVTdHJpbmcpO1xyXG4gICAgICAgICAgaWYgKGlzTmFOKGRhdGUuZ2V0VGltZSgpKSkgcmV0dXJuIFwiSW52YWxpZCBEYXRlXCI7XHJcbiAgICAgICAgICBjb25zdCBkYXkgPSBTdHJpbmcoZGF0ZS5nZXREYXRlKCkpLnBhZFN0YXJ0KDIsIFwiMFwiKTtcclxuICAgICAgICAgIGNvbnN0IG1vbnRoID0gU3RyaW5nKGRhdGUuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsIFwiMFwiKTtcclxuICAgICAgICAgIGNvbnN0IHllYXIgPSBkYXRlLmdldEZ1bGxZZWFyKCk7XHJcbiAgICAgICAgICBsZXQgaG91cnMgPSBkYXRlLmdldEhvdXJzKCk7XHJcbiAgICAgICAgICBjb25zdCBtaW51dGVzID0gU3RyaW5nKGRhdGUuZ2V0TWludXRlcygpKS5wYWRTdGFydCgyLCBcIjBcIik7XHJcbiAgICAgICAgICBjb25zdCBhbXBtID0gaG91cnMgPj0gMTIgPyBcIlBNXCIgOiBcIkFNXCI7XHJcbiAgICAgICAgICBob3VycyA9IGhvdXJzICUgMTI7XHJcbiAgICAgICAgICBob3VycyA9IGhvdXJzID8gaG91cnMgOiAxMjtcclxuICAgICAgICAgIGNvbnN0IGhvdXJzU3RyID0gU3RyaW5nKGhvdXJzKS5wYWRTdGFydCgyLCBcIjBcIik7XHJcbiAgICAgICAgICByZXR1cm4gYCR7ZGF5fS8ke21vbnRofS8ke3llYXJ9ICR7aG91cnNTdHJ9OiR7bWludXRlc30gJHthbXBtfWA7XHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIF9pZDogaXRlbS5faWQsXHJcbiAgICAgICAgICBzbF9ubzogaW5kZXggKyAxLCAvLyBUaGlzIHdpbGwgYmUgdXNlZCBmb3IgdGhlIHNsX25vIGNvbHVtblxyXG4gICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgIHZpc2l0b3JfY29kZTogaXRlbS52aXNpdG9yX2NvZGUgfHwgYFZJUy0ke2luZGV4ICsgMX1gLFxyXG4gICAgICAgICAgbmFtZTogaXRlbS5uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICBwaG9uZTogaXRlbS5waG9uZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgZW1haWw6IGl0ZW0uZW1haWwgfHwgXCItXCIsXHJcbiAgICAgICAgICBwdXJwb3NlOiBpdGVtLnB1cnBvc2UgfHwgXCItXCIsXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbjogaXRlbS5kZXNjcmlwdGlvbiB8fCBcIi1cIixcclxuICAgICAgICAgIGZvcm1hdHRlZF9kYXRlOiBmb3JtYXREYXRlVGltZShpdGVtLmRhdGVUaW1lKSxcclxuICAgICAgICAgIG1lZXRfcGVyc29uOiBpdGVtLm1lZXRQZXJzb24/Lm5hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIGdyb3VwX25hbWU6IGl0ZW0uZ3JvdXBOYW1lIHx8IGl0ZW0uY2hpdEdyb3VwIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICB0aWNrZXRfbnVtYmVyOiBpdGVtLnRpY2tldE51bWJlciB8fCBcIi1cIixcclxuICAgICAgICAgIHN0YXR1czogaXRlbS5zdGF0dXMgfHwgXCJDb21wbGV0ZWRcIixcclxuICAgICAgICB9O1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHNldFZpc2l0b3JEYXRhKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHZpc2l0b3IgcmVjb3JkczpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRWaXNpdG9yRGF0YShbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRWaXNpdG9yTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gQWRkIHVzZUVmZmVjdCB0byBmZXRjaCB2aXNpdG9yIGRhdGEgd2hlbiB2aXNpdG9yIHRhYiBpcyBhY3RpdmVcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGFjdGl2ZVRhYiA9PT0gXCJ2aXNpdG9yXCIgJiYgc2VsZWN0ZWRHcm91cCkge1xyXG4gICAgICBmZXRjaEN1c3RvbWVyVmlzaXRvcnMoKTtcclxuICAgIH1cclxuICB9LCBbYWN0aXZlVGFiLCBzZWxlY3RlZEdyb3VwXSk7XHJcblxyXG4gIC8vIEFkZCBmdW5jdGlvbiB0byBzaG93IHZpc2l0b3IgZGV0YWlscyBtb2RhbFxyXG4gIGNvbnN0IHNob3dWaXNpdG9yRGV0YWlscyA9ICh2aXNpdG9yKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZFZpc2l0b3IodmlzaXRvcik7XHJcbiAgICBzZXRWaXNpdG9yTW9kYWxWaXNpYmxlKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IFZpc2l0b3JDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwic2xfbm9cIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJ2aXNpdG9yX2NvZGVcIiwgaGVhZGVyOiBcIlZpc2l0b3IgQ29kZVwiIH0sXHJcbiAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJWaXNpdG9yIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJlbWFpbFwiLCBoZWFkZXI6IFwiRW1haWxcIiB9LFxyXG4gICAgeyBrZXk6IFwicHVycG9zZVwiLCBoZWFkZXI6IFwiUHVycG9zZVwiIH0sXHJcbiAgICB7IGtleTogXCJmb3JtYXR0ZWRfZGF0ZVwiLCBoZWFkZXI6IFwiVmlzaXQgRGF0ZSAmIFRpbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwibWVldF9wZXJzb25cIiwgaGVhZGVyOiBcIldob20gdG8gTWVldFwiIH0sXHJcbiAgICB7IGtleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgXTtcclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gZ2V0Q3VzdG9tZXJQYXltZW50U3RhdGVtZW50KCkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0U3RhdGVtZW50TG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL2Vucm9sbC9jdXN0b21lci1wYXltZW50L2N1c3RvbWVyLXN0YXRlbWVudC8ke2Vucm9sbG1lbnRJZH1gLFxyXG4gICAgICApO1xyXG5cclxuICAgICAgY29uc3QgcmVzcG9uc2VEYXRhID0gcmVzcG9uc2UuZGF0YT8uZGF0YT8uc3RhdGVtZW50ID8/IFtdO1xyXG5cclxuICAgICAgY29uc3QgZmlsdGVyZWRSZXNwb25zZSA9IHJlc3BvbnNlRGF0YS5tYXAoKHN0YXRlbWVudCwgaW5kZXgpID0+IHtcclxuICAgICAgICBjb25zdCBiYWxhbmNlVmFsdWUgPSBOdW1iZXIoc3RhdGVtZW50Py5iYWxhbmNlIHx8IDApO1xyXG4gICAgICAgIGNvbnN0IHBhaWRWYWx1ZSA9IE51bWJlcihzdGF0ZW1lbnQ/LnBhaWQgfHwgMCk7XHJcbiAgICAgICAgY29uc3QgZHVlVmFsdWUgPSBOdW1iZXIoc3RhdGVtZW50Py5kdWUgfHwgMCk7XHJcbiAgICAgICAgY29uc3QgcmVjZWl2ZWRWYWx1ZSA9IE51bWJlcihzdGF0ZW1lbnQ/LnJlY2VpdmVkIHx8IDApO1xyXG4gICAgICAgIGNvbnN0IHBheVR5cGUgPSBzdGF0ZW1lbnQ/LnBheV90eXBlIHx8IFwiLVwiO1xyXG4gICAgICAgIGNvbnN0IHJlY2VpcHRObyA9IHN0YXRlbWVudD8ucmVjZWlwdF9ubyB8fCBcIi1cIjtcclxuICAgICAgICBjb25zdCBpc1Bvc2l0aXZlID0gYmFsYW5jZVZhbHVlIDw9IDA7XHJcbiAgICAgICAgY29uc3QgaXNOb3RQYWlkUm93ID1cclxuICAgICAgICAgIHBhaWRWYWx1ZSA9PT0gMCAmJlxyXG4gICAgICAgICAgZHVlVmFsdWUgPiAwICYmXHJcbiAgICAgICAgICBzdGF0ZW1lbnQ/LmRlc2NyaXB0aW9uPy5zdGFydHNXaXRoKFwiQXVjdGlvblwiKTtcclxuXHJcbiAgICAgICAgY29uc3QgZGF0ZVN0ciA9IGAke3N0YXRlbWVudD8uZGF0ZX1gPy5zcGxpdChcIlRcIik/LlswXSA/PyBcIi1cIjtcclxuXHJcbiAgICAgICAgY29uc3QgcGF5ZGF0ZVN0ciA9IHN0YXRlbWVudD8ucGF5ZGF0ZT8uc3BsaXQoXCJUXCIpPy5bMF0gPz8gXCItXCI7XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG5cclxuICAgICAgICAgIC8vIC0tLS0tLS0tLS0gUkFXIC0tLS0tLS0tLS1cclxuICAgICAgICAgIHJhd0RhdGU6IGRhdGVTdHIsXHJcbiAgICAgICAgICByYXdQYXlEYXRlOiBwYXlkYXRlU3RyLFxyXG4gICAgICAgICAgcmF3QmFsYW5jZTogYmFsYW5jZVZhbHVlLFxyXG4gICAgICAgICAgcmF3RGVzY3JpcHRpb246IHN0YXRlbWVudD8uZGVzY3JpcHRpb24sXHJcbiAgICAgICAgICByYXdEdWU6IGR1ZVZhbHVlLFxyXG4gICAgICAgICAgcmF3UGFpZDogcGFpZFZhbHVlLFxyXG4gICAgICAgICAgcmF3UmVjZWl2ZWQ6IHJlY2VpdmVkVmFsdWUsXHJcbiAgICAgICAgICByYXdQYXlUeXBlOiBwYXlUeXBlLFxyXG4gICAgICAgICAgcmF3UmVjZWlwdE5vOiByZWNlaXB0Tm8sXHJcblxyXG4gICAgICAgICAgLy8gLS0tLS0tLS0tLSBVSSAtLS0tLS0tLS0tXHJcblxyXG4gICAgICAgICAgZGF0ZTogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIHRleHQteHMgZm9udC1tZWRpdW1cIj57ZGF0ZVN0cn08L2Rpdj5cclxuICAgICAgICAgICksXHJcbiAgICAgICAgICBwYXlkYXRlOiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgdGV4dC14cyBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgIHtwYXlkYXRlU3RyfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICksXHJcblxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS05MDAgZm9udC1ib2xkIHRleHQtc20gdHJhY2tpbmctdGlnaHRcIj5cclxuICAgICAgICAgICAgICAgIHtzdGF0ZW1lbnQ/LmRlc2NyaXB0aW9uIHx8IFwiR2VuZXJhbCBQYXltZW50XCJ9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICB7aXNOb3RQYWlkUm93ICYmIChcclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtcm9zZS01MDAgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3RcIj5cclxuICAgICAgICAgICAgICAgICAgXCItXCJcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBmb250LW1lZGl1bSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0XCI+XHJcbiAgICAgICAgICAgICAgICBSZWY6ICN7aW5kZXgudG9TdHJpbmcoKS5wYWRTdGFydCg0LCBcIjBcIil9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICksXHJcblxyXG4gICAgICAgICAgcGF5VHlwZTogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwIGZvbnQtc2VtaWJvbGQgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgIHtwYXlUeXBlLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSxcclxuXHJcbiAgICAgICAgICByZWNlaXB0Tm86IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCBmb250LXNlbWlib2xkIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICB7cmVjZWlwdE5vLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSxcclxuXHJcbiAgICAgICAgICBkdWU6IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCBmb250LXNlbWlib2xkIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICDigrl7ZHVlVmFsdWUudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApLFxyXG5cclxuICAgICAgICAgIHBhaWQ6IChcclxuICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZvbnQtYm9sZCB0ZXh0LXNtICR7cmVjZWl2ZWRWYWx1ZSA+IDAgPyBcInRleHQtZW1lcmFsZC02MDBcIiA6IFwidGV4dC1zbGF0ZS00MDBcIlxyXG4gICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7cGFpZFZhbHVlID4gMCA/IGArIOKCuSR7cGFpZFZhbHVlLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCA6IFwiLVwifVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICksXHJcblxyXG4gICAgICAgICAgcmVjZWl2ZWQ6IChcclxuICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZvbnQtYm9sZCB0ZXh0LXNtICR7cmVjZWl2ZWRWYWx1ZSA+IDAgPyBcInRleHQtZW1lcmFsZC02MDBcIiA6IFwidGV4dC1zbGF0ZS00MDBcIlxyXG4gICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7cmVjZWl2ZWRWYWx1ZSA+IDBcclxuICAgICAgICAgICAgICAgID8gYCsg4oK5JHtyZWNlaXZlZFZhbHVlLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YFxyXG4gICAgICAgICAgICAgICAgOiBcIi1cIn1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApLFxyXG5cclxuICAgICAgICAgIGJhbGFuY2U6IChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtYmxhY2sgJHtpc1Bvc2l0aXZlID8gXCJ0ZXh0LWdyZWVuLTkwMFwiIDogXCJ0ZXh0LXJvc2UtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAg4oK5e01hdGguYWJzKGJhbGFuY2VWYWx1ZSkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC1bOXB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCAke2lzUG9zaXRpdmUgPyBcInRleHQtZW1lcmFsZC00MDBcIiA6IFwidGV4dC1yb3NlLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtpc1Bvc2l0aXZlID8gXCJTZXR0bGVkXCIgOiBcIk91dHN0YW5kaW5nXCJ9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy0xIGgtOCByb3VuZGVkLWZ1bGwgJHtpc1Bvc2l0aXZlID8gXCJiZy1lbWVyYWxkLTIwMFwiIDogXCJiZy1yb3NlLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSxcclxuICAgICAgICB9O1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHNldEFjdGl2ZUVucm9sbG1lbnREYXRhKGZpbHRlcmVkUmVzcG9uc2UpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgc2V0QWN0aXZlRW5yb2xsbWVudERhdGEoW10pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0U3RhdGVtZW50TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGVucm9sbG1lbnRJZCkgZ2V0Q3VzdG9tZXJQYXltZW50U3RhdGVtZW50KCk7XHJcbiAgfSwgW2Vucm9sbG1lbnRJZF0pO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAoc2V0RW5yb2xsbWVudElkKFwiXCIpLCBzZXRBY3RpdmVFbnJvbGxtZW50RGF0YShbXSkpO1xyXG4gIH0sIFtzZWxlY3RlZEdyb3VwXSk7XHJcbiAgY29uc3QgaGFuZGxlRW5yb2xsbWVudENoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB2YWx1ZSA9IGUudGFyZ2V0LnZhbHVlO1xyXG4gICAgaWYgKHZhbHVlKSBzZXRFbnJvbGxtZW50SWQodmFsdWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVRyYW5zYWN0aW9uc1NlbGVjdEZpbHRlciA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRMYWJlbCh2YWx1ZSk7XHJcbiAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgICBjb25zdCBmb3JtYXREYXRlID0gKGRhdGUpID0+IGRhdGUudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XHJcblxyXG4gICAgaWYgKHZhbHVlID09PSBcIkN1c3RvbVwiKSB7XHJcbiAgICAgIHNldFNob3dGaWx0ZXJGaWVsZCh0cnVlKTtcclxuICAgICAgc2V0VG90YWxUcmFuc2FjdG9ucygwKTtcclxuXHJcbiAgICAgIGNvbnN0IHN0YXJ0T2ZNb250aCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDEpO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGUoc3RhcnRPZk1vbnRoKSk7XHJcbiAgICAgIHNldFNlbGVjdGVkVG9EYXRlKGZvcm1hdERhdGUodG9kYXkpKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldFNob3dGaWx0ZXJGaWVsZChmYWxzZSk7XHJcbiAgICAgIHNldFRvdGFsVHJhbnNhY3RvbnMocGFyc2VJbnQodmFsdWUpKTtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShcIlwiKTtcclxuICAgICAgc2V0U2VsZWN0ZWRUb0RhdGUoXCJcIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZGF5R3JvdXAgPSBbXHJcbiAgICB7IHZhbHVlOiBcIjIwMFwiLCBsYWJlbDogXCJMYXN0IDIwMCBUcmFuc2FjdGlvbnNcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCIxMDBcIiwgbGFiZWw6IFwiTGFzdCAxMDAgVHJhbnNhY3Rpb25zXCIgfSxcclxuICAgIHsgdmFsdWU6IFwiNTBcIiwgbGFiZWw6IFwiTGFzdCA1MCBUcmFuc2FjdGlvbnNcIiB9LFxyXG4gICAgeyB2YWx1ZTogXCIyNVwiLCBsYWJlbDogXCJMYXN0IDI1IFRyYW5zYWN0aW9uc1wiIH0sXHJcbiAgICB7IHZhbHVlOiBcIkN1c3RvbVwiLCBsYWJlbDogXCJDdXN0b21cIiB9LFxyXG4gIF07XHJcbiAgY29uc3QgbG9hbkNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJzbF9ub1wiLCBoZWFkZXI6IFwiU0wuIE5vXCIgfSxcclxuICAgIHsga2V5OiBcImxvYW5cIiwgaGVhZGVyOiBcIkxvYW4gSURcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhcnRfZGF0ZVwiLCBoZWFkZXI6IFwiU3RhcnQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJlbmRfZGF0ZVwiLCBoZWFkZXI6IFwiRW5kIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwibG9hbl9hbW91bnRcIiwgaGVhZGVyOiBcIkxvYW4gQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcInNlcnZpY2VfY2hhcmdlXCIsIGhlYWRlcjogXCJTZXJ2aWNlIENoYXJnZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0ZW51cmVcIiwgaGVhZGVyOiBcIlRlbnVyZVwiIH0sXHJcbiAgICB7IGtleTogXCJsYXRlX2ZlZVwiLCBoZWFkZXI6IFwiTGF0ZSBmZWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxfcGFpZF9hbW91bnRcIiwgaGVhZGVyOiBcIlRvdGFsIFBhaWQgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcImJhbGFuY2VcIiwgaGVhZGVyOiBcIkJhbGFuY2VcIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IHBpZ21lQ29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcInNsX25vXCIsIGhlYWRlcjogXCJTTC4gTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwicGlnbWVcIiwgaGVhZGVyOiBcIlBpZ21lIElEXCIgfSxcclxuICAgIHsga2V5OiBcInN0YXJ0X2RhdGVcIiwgaGVhZGVyOiBcIlN0YXJ0IERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZHVyYXRpb25cIiwgaGVhZGVyOiBcImR1cmF0aW9uXCIgfSxcclxuICAgIHsga2V5OiBcIm1hdHVyaXR5X2ludGVyZXN0XCIsIGhlYWRlcjogXCJJbnRyZXN0XCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsX2RlcG9zaXRlZF9hbW91bnRcIiwgaGVhZGVyOiBcIlRvdGFsIERlcG9zaXRlZCBBbW91bnRcIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUdyb3VwQXVjdGlvbkNoYW5nZSA9IGFzeW5jICh1c2VySWQpID0+IHtcclxuICAgIHNldFNlbGVjdGVkRW5yb2xsbWVudHMoW10pO1xyXG4gICAgc2V0VGFibGVBdWN0aW9ucyhbXSk7XHJcbiAgICBzZXRDb21taXNzaW9uKDApO1xyXG4gICAgc2V0VG90YWxUb0JlUGFpZCgwKTtcclxuICAgIHNldE5ldFRvdGFsUHJvZml0KDApO1xyXG4gICAgc2V0VG90YWxQYWlkKDApO1xyXG4gICAgc2V0VG90YWxQcm9maXQoMCk7XHJcblxyXG4gICAgaWYgKCF1c2VySWQpIHJldHVybjtcclxuXHJcbiAgICAvLyDwn5SQIFJlcXVlc3QgZ3VhcmQgdG8gYXZvaWQgc3RhbGUgcmVzcG9uc2UgdXBkYXRlc1xyXG4gICAgY29uc3QgY3VycmVudFJlcXVlc3RJZCA9IERhdGUubm93KCk7XHJcbiAgICBoYW5kbGVHcm91cEF1Y3Rpb25DaGFuZ2UubGF0ZXN0UmVxdWVzdCA9IGN1cnJlbnRSZXF1ZXN0SWQ7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvdjEvYWRtaW4vZ3JvdXBzL2dyb3VwLXJlcG9ydD91c2VyX2lkPSR7dXNlcklkfWApO1xyXG4gICAgICBzZXRTZWxlY3RlZEVucm9sbG1lbnRzKHJlc3BvbnNlPy5kYXRhPy5kYXRhKVxyXG5cclxuXHJcbiAgICAgIGlmICghcmVzcG9uc2U/LmRhdGE/LmRhdGE/Lmxlbmd0aCkgcmV0dXJuO1xyXG5cclxuXHJcblxyXG4gICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2U/LmRhdGE/LmRhdGFcclxuICAgICAgICA/Lm1hcCgoZGF0YSwgaW5kZXgpID0+IHtcclxuXHJcblxyXG4gICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgZ3JvdXA6IGRhdGE/Lmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IFwiXCIsXHJcbiAgICAgICAgICAgIHRpY2tldDogZGF0YT8udGlja2V0cyB8fCBcIlwiLFxyXG4gICAgICAgICAgICB0b3RhbEJlUGFpZDogZGF0YT8udG90YWxfcGF5YWJsZSxcclxuICAgICAgICAgICAgcHJvZml0OiBkYXRhPy50b3RhbF9wcm9maXQsXHJcbiAgICAgICAgICAgIHRvQmVQYWlkQW1vdW50OiBkYXRhPy50b3RhbF9wYXlhYmxlLFxyXG4gICAgICAgICAgICBsYXRlRmVlOiBkYXRhPy50b3RhbF9sYXRlX2ZlZSxcclxuICAgICAgICAgICAgcGVuYWx0eTogZGF0YT8udG90YWxfcGVuYWx0eSxcclxuICAgICAgICAgICAgcGFpZEFtb3VudDogZGF0YT8udG90YWxfaW52ZXN0bWVudCxcclxuICAgICAgICAgICAgYmFsYW5jZTogZGF0YT8udG90YWxfYmFsYW5jZSxcclxuICAgICAgICAgICAgcmVmZXJyZWRfdHlwZTogZGF0YT8ucmVmZXJyZWRfdHlwZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICByZWZlcnJlcl9uYW1lOiBkYXRhPy5yZWZlcnJlZF9hZ2VudD8ubmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICBjaGl0X2Fza2luZ19tb250aDogZGF0YT8uY2hpdF9hc2tpbmdfbW9udGggfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgY3VzdG9tZXJfc3RhdHVzOiBkYXRhPy5jdXN0b21lcl9zdGF0dXMgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgcmVtb3ZhbF9yZWFzb246IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIGVucm9sbG1lbnREYXRlOlxyXG4gICAgICAgICAgICAgIGRhdGE/LmNyZWF0ZWRBdD8uc3BsaXQoXCJUXCIpPy5bMF0gfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgaXNQcml6ZWQ6IGRhdGE/LmlzX3ByaXplZCA/IFwiUHJpemVkXCIgOiBcIlVuIFByaXplZFwiLFxyXG4gICAgICAgICAgfTtcclxuICAgICAgICB9KVxyXG4gICAgICAgIC5maWx0ZXIoQm9vbGVhbik7XHJcblxyXG5cclxuICAgICAgc2V0VGFibGVBdWN0aW9ucyhmb3JtYXR0ZWREYXRhKTtcclxuXHJcbiAgICAgIC8vIPCfk4ogVG90YWxzXHJcbiAgICAgIHNldFRvdGFsVG9CZVBhaWQoXHJcbiAgICAgICAgZm9ybWF0dGVkRGF0YS5yZWR1Y2UoKHN1bSwgcm93KSA9PiBzdW0gKyByb3cudG90YWxCZVBhaWQsIDApLFxyXG4gICAgICApO1xyXG5cclxuICAgICAgc2V0TmV0VG90YWxQcm9maXQoXHJcbiAgICAgICAgZm9ybWF0dGVkRGF0YS5yZWR1Y2UoKHN1bSwgcm93KSA9PiBzdW0gKyByb3cudG9CZVBhaWRBbW91bnQsIDApLFxyXG4gICAgICApO1xyXG5cclxuICAgICAgc2V0VG90YWxQYWlkKGZvcm1hdHRlZERhdGEucmVkdWNlKChzdW0sIHJvdykgPT4gc3VtICsgcm93LnBhaWRBbW91bnQsIDApKTtcclxuXHJcbiAgICAgIHNldFRvdGFsUHJvZml0KGZvcm1hdHRlZERhdGEucmVkdWNlKChzdW0sIHJvdykgPT4gc3VtICsgcm93LnByb2ZpdCwgMCkpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVucm9sbG1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAodXNlcklkKSB7XHJcbiAgICAgIGhhbmRsZUdyb3VwQXVjdGlvbkNoYW5nZSh1c2VySWQpO1xyXG4gICAgfVxyXG4gIH0sIFtdKTtcclxuICBjb25zdCBBdWN0aW9uY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfc3RhdHVzXCIsIGhlYWRlcjogXCJDdXN0b21lciBTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVtb3ZhbF9yZWFzb25cIiwgaGVhZGVyOiBcIlJlbW92YWwgUmVhc29uXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImVucm9sbG1lbnREYXRlXCIsIGhlYWRlcjogXCJFbnJvbGxtZW50IERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVmZXJyZWRfdHlwZVwiLCBoZWFkZXI6IFwiUmVmZXJyZXIgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJyZWZlcnJlcl9uYW1lXCIsIGhlYWRlcjogXCJSZWZlcnJlZCBCeVwiIH0sXHJcbiAgICB7IGtleTogXCJjaGl0X2Fza2luZ19tb250aFwiLCBoZWFkZXI6IFwiQ2hpdCBBc2tpbmcgTW9udGhcIiB9LFxyXG4gICAgeyBrZXk6IFwiaXNQcml6ZWRcIiwgaGVhZGVyOiBcIklzIFByaXplZFwiIH0sXHJcbiAgICAvLyB7IGtleTogXCJ0b3RhbEJlUGFpZFwiLCBoZWFkZXI6IFwiQW1vdW50IHRvIGJlIFBhaWRcIiB9LFxyXG4gICAgeyBrZXk6IFwicHJvZml0XCIsIGhlYWRlcjogXCJQcm9maXRcIiB9LFxyXG4gICAgeyBrZXk6IFwicGFpZEFtb3VudFwiLCBoZWFkZXI6IFwiQW1vdW50IFBhaWRcIiB9LFxyXG4gICAgeyBrZXk6IFwibGF0ZUZlZVwiLCBoZWFkZXI6IFwiTGF0ZSBGZWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGVuYWx0eVwiLCBoZWFkZXI6IFwiUGVuYWx0eVwiIH0sXHJcbiAgICB7IGtleTogXCJ0b0JlUGFpZEFtb3VudFwiLCBoZWFkZXI6IFwiQW1vdW50IFBheWFibGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmFsYW5jZVwiLCBoZWFkZXI6IFwiQmFsYW5jZVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgZm9ybWF0UGF5RGF0ZSA9IChkYXRlU3RyaW5nKSA9PiB7XHJcbiAgICBjb25zdCBkYXRlID0gbmV3IERhdGUoZGF0ZVN0cmluZyk7XHJcbiAgICByZXR1cm4gZGF0ZS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hFbnJvbGwgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHNldFRhYmxlRW5yb2xscyhbXSk7XHJcbiAgICAgIHNldEJhc2ljTG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICAgIGAvZW5yb2xsL2dldC11c2VyLXBheW1lbnQ/Z3JvdXBfaWQ9JHtFbnJvbGxHcm91cElkLmdyb3VwSWR9JnRpY2tldD0ke0Vucm9sbEdyb3VwSWQudGlja2V0fSZ1c2VyX2lkPSR7c2VsZWN0ZWRHcm91cH1gLFxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIGNvbnNvbGUuaW5mbyhyZXNwb25zZSwgXCJ0ZXN0IHVzZXIgcGF5bWVudHNcIik7XHJcblxyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRVc2VycyhyZXNwb25zZS5kYXRhKTtcclxuXHJcbiAgICAgICAgICBjb25zdCBQYWlkID0gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgICAgIHNldEdyb3VwUGFpZChQYWlkWzBdLmdyb3VwUGFpZEFtb3VudCk7XHJcblxyXG4gICAgICAgICAgY29uc3QgdG9CZVBhaWQgPSByZXNwb25zZS5kYXRhO1xyXG4gICAgICAgICAgc2V0R3JvdXBUb0JlUGFpZCh0b0JlUGFpZFswXS50b3RhbFRvQmVQYWlkQW1vdW50KTtcclxuXHJcbiAgICAgICAgICBsZXQgYmFsYW5jZSA9IDA7XHJcbiAgICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2UuZGF0YS5tYXAoKGdyb3VwLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICBiYWxhbmNlICs9IE51bWJlcihncm91cC5hbW91bnQpO1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgIF9pZDogZ3JvdXAuX2lkLFxyXG4gICAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgZGF0ZTogZm9ybWF0UGF5RGF0ZShncm91cD8ucGF5X2RhdGUpLFxyXG4gICAgICAgICAgICAgIGFtb3VudDogZ3JvdXAuYW1vdW50LFxyXG4gICAgICAgICAgICAgIHJlY2VpcHQ6IGdyb3VwLnJlY2VpcHRfbm8sXHJcbiAgICAgICAgICAgICAgb2xkX3JlY2VpcHQ6IGdyb3VwLm9sZF9yZWNlaXB0X25vLFxyXG4gICAgICAgICAgICAgIHR5cGU6IGdyb3VwLnBheV90eXBlLFxyXG4gICAgICAgICAgICAgIGJhbGFuY2UsXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIGZvcm1hdHRlZERhdGEucHVzaCh7XHJcbiAgICAgICAgICAgIGlkOiBcIlwiLFxyXG4gICAgICAgICAgICBkYXRlOiBcIlwiLFxyXG4gICAgICAgICAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgICAgIHJlY2VpcHQ6IFwiXCIsXHJcbiAgICAgICAgICAgIG9sZF9yZWNlaXB0OiBcIlwiLFxyXG4gICAgICAgICAgICB0eXBlOiBcIlwiLFxyXG4gICAgICAgICAgICBiYWxhbmNlLFxyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgc2V0VGFibGVFbnJvbGxzKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKFtdKTtcclxuICAgICAgICAgIHNldFRhYmxlRW5yb2xscyhbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbnJvbGxtZW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKFtdKTtcclxuICAgICAgICBzZXRUYWJsZUVucm9sbHMoW10pO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldEJhc2ljTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGlmIChFbnJvbGxHcm91cElkLmdyb3VwSWQgIT09IFwiTG9hblwiICYmIEVucm9sbEdyb3VwSWQuZ3JvdXBJZCAhPT0gXCJQaWdtZVwiKVxyXG4gICAgICBmZXRjaEVucm9sbCgpO1xyXG4gIH0sIFtzZWxlY3RlZEdyb3VwLCBFbnJvbGxHcm91cElkLmdyb3VwSWQsIEVucm9sbEdyb3VwSWQudGlja2V0XSk7XHJcblxyXG4gIGNvbnN0IEJhc2ljY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiZGF0ZVwiLCBoZWFkZXI6IFwiRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJhbW91bnRcIiwgaGVhZGVyOiBcIkFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJyZWNlaXB0XCIsIGhlYWRlcjogXCJSZWNlaXB0IE5vXCIgfSxcclxuICAgIHsga2V5OiBcIm9sZF9yZWNlaXB0XCIsIGhlYWRlcjogXCJPbGQgUmVjZWlwdCBOb1wiIH0sXHJcbiAgICB7IGtleTogXCJ0eXBlXCIsIGhlYWRlcjogXCJQYXltZW50IFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmFsYW5jZVwiLCBoZWFkZXI6IFwiQmFsYW5jZVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgQ3VzdG9tZXJQYXltZW50U3RhdGVtZW50Q29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiZGF0ZVwiLCBoZWFkZXI6IFwiRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJkZXNjcmlwdGlvblwiLCBoZWFkZXI6IFwiRGVzY3JpcHRpb25cIiB9LFxyXG4gICAgeyBrZXk6IFwicmVjZWlwdE5vXCIsIGhlYWRlcjogXCJSZWNlaXB0IE5vXCIgfSxcclxuICAgIHsga2V5OiBcInBheVR5cGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgTW9kZVwiIH0sXHJcbiAgICB7IGtleTogXCJkdWVcIiwgaGVhZGVyOiBcIkR1ZSBBbW91bnRcIiB9LFxyXG4gICAgLy8geyBrZXk6IFwicGF5ZGF0ZVwiLCBoZWFkZXI6IFwiUGFpZCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcInBhaWRcIiwgaGVhZGVyOiBcIkNyZWRpdCBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVjZWl2ZWRcIiwgaGVhZGVyOiBcIkRlYml0IEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJiYWxhbmNlXCIsIGhlYWRlcjogXCJCYWxhbmNlXCIgfSxcclxuICBdO1xyXG4gIGNvbnN0IEN1c3RvbWVyUGF5bWVudFN0YXRlbWVudEV4cG9ydHNDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJyYXdEYXRlXCIsIGhlYWRlcjogXCJEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcInJhd0Rlc2NyaXB0aW9uXCIsIGhlYWRlcjogXCJEZXNjcmlwdGlvblwiIH0sXHJcbiAgICB7IGtleTogXCJyYXdSZWNlaXB0Tm9cIiwgaGVhZGVyOiBcIlJlY2VpcHQgTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwicmF3UGF5VHlwZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBNb2RlXCIgfSxcclxuICAgIHsga2V5OiBcInJhd0R1ZVwiLCBoZWFkZXI6IFwiRHVlIEFtb3VudFwiIH0sXHJcbiAgICAvLyB7IGtleTogXCJyYXdQYXlEYXRlXCIsIGhlYWRlcjogXCJQYWlkIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicmF3UGFpZFwiLCBoZWFkZXI6IFwiUGFpZCBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwicmF3QmFsYW5jZVwiLCBoZWFkZXI6IFwiQmFsYW5jZVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlU3RyaW5nKSA9PiB7XHJcbiAgICBjb25zdCBwYXJ0cyA9IGRhdGVTdHJpbmcuc3BsaXQoXCItXCIpO1xyXG4gICAgaWYgKHBhcnRzLmxlbmd0aCA9PT0gMykge1xyXG4gICAgICByZXR1cm4gYCR7cGFydHNbMl19LSR7cGFydHNbMV19LSR7cGFydHNbMF19YDtcclxuICAgIH1cclxuICAgIHJldHVybiBkYXRlU3RyaW5nO1xyXG4gIH07XHJcbiAgY29uc3QgZm9ybWF0dGVkRnJvbURhdGUgPSBmb3JtYXREYXRlKGZyb21EYXRlKTtcclxuICBjb25zdCBmb3JtYXR0ZWRUb0RhdGUgPSBmb3JtYXREYXRlKHRvRGF0ZSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEVucm9sbCA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgICBgL2dyb3VwLXJlcG9ydC9nZXQtZ3JvdXAtZW5yb2xsLWRhdGUvJHtzZWxlY3RlZEdyb3VwfT9mcm9tRGF0ZT0ke2Zvcm1hdHRlZEZyb21EYXRlfSZ0b0RhdGU9JHtmb3JtYXR0ZWRUb0RhdGV9YCxcclxuICAgICAgICApO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRVc2VycyhyZXNwb25zZS5kYXRhKTtcclxuXHJcbiAgICAgICAgICBjb25zdCBQYWlkID0gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgICAgIHNldEdyb3VwUGFpZERhdGUoUGFpZFswXS5ncm91cFBhaWRBbW91bnQgfHwgMCk7XHJcblxyXG4gICAgICAgICAgY29uc3QgdG9CZVBhaWQgPSByZXNwb25zZS5kYXRhO1xyXG4gICAgICAgICAgc2V0R3JvdXBUb0JlUGFpZERhdGUodG9CZVBhaWRbMF0udG90YWxUb0JlUGFpZEFtb3VudCk7XHJcblxyXG4gICAgICAgICAgY29uc3QgdG90YWxBbW91bnQgPSByZXNwb25zZS5kYXRhLnJlZHVjZShcclxuICAgICAgICAgICAgKHN1bSwgZ3JvdXApID0+IHN1bSArIHBhcnNlSW50KGdyb3VwLmFtb3VudCksXHJcbiAgICAgICAgICAgIDAsXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgICAgc2V0VG90YWxBbW91bnQodG90YWxBbW91bnQpO1xyXG4gICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlLmRhdGEubWFwKChncm91cCwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgIG5hbWU6IGdyb3VwPy51c2VyPy5mdWxsX25hbWUsXHJcbiAgICAgICAgICAgIHBob25lX251bWJlcjogZ3JvdXA/LnVzZXI/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgdGlja2V0OiBncm91cC50aWNrZXQsXHJcbiAgICAgICAgICAgIGFtb3VudF90b19iZV9wYWlkOlxyXG4gICAgICAgICAgICAgIHBhcnNlSW50KGdyb3VwLmdyb3VwLmdyb3VwX2luc3RhbGwpICsgZ3JvdXAudG90YWxUb0JlUGFpZEFtb3VudCxcclxuICAgICAgICAgICAgYW1vdW50X3BhaWQ6IGdyb3VwLnRvdGFsUGFpZEFtb3VudCxcclxuICAgICAgICAgICAgYW1vdW50X2JhbGFuY2U6XHJcbiAgICAgICAgICAgICAgcGFyc2VJbnQoZ3JvdXAuZ3JvdXAuZ3JvdXBfaW5zdGFsbCkgK1xyXG4gICAgICAgICAgICAgIGdyb3VwLnRvdGFsVG9CZVBhaWRBbW91bnQgLVxyXG4gICAgICAgICAgICAgIGdyb3VwLnRvdGFsUGFpZEFtb3VudCxcclxuICAgICAgICAgIH0pKTtcclxuICAgICAgICAgIHNldFRhYmxlRW5yb2xsc0RhdGUoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldEZpbHRlcmVkVXNlcnMoW10pO1xyXG4gICAgICAgICAgc2V0VG90YWxBbW91bnQoMCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbnJvbGxtZW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKFtdKTtcclxuICAgICAgICBzZXRUb3RhbEFtb3VudCgwKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoRW5yb2xsKCk7XHJcbiAgfSwgW3NlbGVjdGVkR3JvdXAsIGZvcm1hdHRlZEZyb21EYXRlLCBmb3JtYXR0ZWRUb0RhdGVdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChncm91cEluZm8gJiYgZm9ybURhdGEuYmlkX2Ftb3VudCkge1xyXG4gICAgICBjb25zdCBjb21taXNzaW9uID0gKGdyb3VwSW5mby5ncm91cF92YWx1ZSAqIDUpIC8gMTAwIHx8IDA7XHJcbiAgICAgIGNvbnN0IHdpbl9hbW91bnQgPVxyXG4gICAgICAgIChncm91cEluZm8uZ3JvdXBfdmFsdWUgfHwgMCkgLSAoZm9ybURhdGEuYmlkX2Ftb3VudCB8fCAwKTtcclxuICAgICAgY29uc3QgZGl2aWRlbnQgPSAoZm9ybURhdGEuYmlkX2Ftb3VudCB8fCAwKSAtIGNvbW1pc3Npb247XHJcbiAgICAgIGNvbnN0IGRpdmlkZW50X2hlYWQgPSBncm91cEluZm8uZ3JvdXBfbWVtYmVyc1xyXG4gICAgICAgID8gZGl2aWRlbnQgLyBncm91cEluZm8uZ3JvdXBfbWVtYmVyc1xyXG4gICAgICAgIDogMDtcclxuICAgICAgY29uc3QgcGF5YWJsZSA9IChncm91cEluZm8uZ3JvdXBfaW5zdGFsbCB8fCAwKSAtIGRpdmlkZW50X2hlYWQ7XHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgICBncm91cF9pZDogZ3JvdXBJbmZvLl9pZCxcclxuICAgICAgICBjb21taXNzaW9uLFxyXG4gICAgICAgIHdpbl9hbW91bnQsXHJcbiAgICAgICAgZGl2aWRlbnQsXHJcbiAgICAgICAgZGl2aWRlbnRfaGVhZCxcclxuICAgICAgICBwYXlhYmxlLFxyXG4gICAgICB9KSk7XHJcbiAgICB9XHJcbiAgfSwgW2dyb3VwSW5mbywgZm9ybURhdGEuYmlkX2Ftb3VudF0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHNlbGVjdGVkR3JvdXApIHtcclxuICAgICAgYXBpXHJcbiAgICAgICAgLnBvc3QoYC9lbnJvbGwvZ2V0LW5leHQtdGlja2V0cy8ke3NlbGVjdGVkR3JvdXB9YClcclxuICAgICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICAgIHNldEF2YWlsYWJsZVRpY2tldHMocmVzcG9uc2UuZGF0YS5hdmFpbGFibGVUaWNrZXRzIHx8IFtdKTtcclxuICAgICAgICB9KVxyXG4gICAgICAgIC5jYXRjaCgoZXJyb3IpID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBhdmFpbGFibGUgdGlja2V0czpcIiwgZXJyb3IpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0QXZhaWxhYmxlVGlja2V0cyhbXSk7XHJcbiAgICB9XHJcbiAgfSwgW3NlbGVjdGVkR3JvdXBdKTtcclxuICBpZiAoc2NyZWVuTG9hZGluZylcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1zY3JlZW4gbS0yNFwiPlxyXG4gICAgICAgIDxDaXJjdWxhckxvYWRlciBjb2xvcj1cInRleHQtZ3JlZW4tNjAwXCIgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLWgtc2NyZWVuIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG10LTMwXCI+XHJcbiAgICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgUmVwb3J0cyAtIEN1c3RvbWVyXHJcbiAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi04XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHctZnVsbCBnYXAtNCBiZy1ibHVlLTUwICAgIHAtMiB3LTMwIGgtNDAgIHJvdW5kZWQtM3hsICBib3JkZXIgICBzcGFjZS14LTIgIFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtbGcgdGV4dC1ncmF5LTUwMCB0ZXh0LWNlbnRlciAgZm9udC1zZW1pYm9sZCBtYi0yXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9e1wiU1NcIn1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lclxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJTU1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlR3JvdXBQYXltZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIG9yIFNlbGVjdCBDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBoZWlnaHQ6IFwiNTBweFwiLCB3aWR0aDogXCI2MDBweFwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2dyb3Vwcy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtncm91cC5faWR9IHZhbHVlPXtncm91cC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cC5mdWxsX25hbWV9IC0ge2dyb3VwLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAge3NlbGVjdGVkR3JvdXAgJiYgKFxyXG4gICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLThcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTggcC0xLjUgYmctc2xhdGUtMTAwLzgwIGJhY2tkcm9wLWJsdXItbWQgcm91bmRlZC0yeGwgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHNoYWRvdy1pbm5lciBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC81MCBvdmVyZmxvdy14LWF1dG8gbm8tc2Nyb2xsYmFyIG1heC13LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogXCJncm91cERldGFpbHNcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogXCJDdXN0b21lciBEZXRhaWxzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbjogPEZpVXNlciBzaXplPXsxNn0gLz4sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogXCJhY2NvdW50RGVhaWxzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IFwiQWNjb3VudCBEZXRhaWxzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbjogPEZpQ3JlZGl0Q2FyZCBzaXplPXsxNn0gLz4sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogXCJiYXNpY1JlcG9ydFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBcIkxlZGdlclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGljb246IDxGaUJvb2tPcGVuIHNpemU9ezE2fSAvPixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBcImN1c3RvbWVyUGF5bWVudFN0YXRlbWVudFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBcIlN0YXRlbWVudFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGljb246IDxGaUZpbGVUZXh0IHNpemU9ezE2fSAvPixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBcInRyYW5zYWN0aW9uc1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBcIlRyYW5zYWN0aW9uc1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGljb246IDxGaVJlcGVhdCBzaXplPXsxNn0gLz4sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogXCJ0cmFuc2Zlckhpc3RvcnlcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogXCJHcm91cCBDaGFuZ2UgSGlzdG9yeVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGljb246IDxGaVJlZnJlc2hDY3cgc2l6ZT17MTZ9IC8+LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IFwiZGlzYnVyc2VtZW50XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IFwiUGF5b3V0c1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGljb246IDxGYVJ1cGVlU2lnbiBzaXplPXsxNn0gLz4sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogXCJwZW5hbHR5XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IFwiUGVuYWx0eVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGljb246IDxGYUV4Y2xhbWF0aW9uQ2lyY2xlIHNpemU9ezE2fSAvPixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogXCJiaWRyZXF1ZXN0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IFwiQmlkcmVxdWVzdFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGljb246IDxNZEdhdmVsIHNpemU9ezE2fSAvPixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBcInZpc2l0b3JcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogXCJWaXNpdG9yXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbjogPE1kUGVvcGxlIHNpemU9ezE2fSAvPixcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIF0ubWFwKCh0YWIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17dGFiLmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVRhYkNoYW5nZSh0YWIuaWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgcHgtNSBweS0yLjUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFja2luZy13aWRlIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCB3aGl0ZXNwYWNlLW5vd3JhcCAke2FjdGl2ZVRhYiA9PT0gdGFiLmlkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctd2hpdGUgdGV4dC1ibHVlLTYwMCBzaGFkb3ctc20gcmluZy0xIHJpbmctc2xhdGUtMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LXNsYXRlLTUwMCBob3Zlcjp0ZXh0LXNsYXRlLTgwMCBob3ZlcjpiZy13aGl0ZS80MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Ake2FjdGl2ZVRhYiA9PT0gdGFiLmlkID8gXCJ0ZXh0LWJsdWUtNTAwXCIgOiBcInRleHQtc2xhdGUtNDAwXCJ9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGFiLmljb259XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt0YWIubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lclJlcG9ydFByaW50KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBUYWJsZUF1Y3Rpb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyZWRCb3Jyb3dlckRhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJlZERpc2J1cnNlbWVudCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWxUb0JlcGFpZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWxwcm9maXQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5ldFRvdGFscHJvZml0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbHBhaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVGFibGVFbnJvbGxzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VzdG9tZXJUcmFuc2FjdGlvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTYgcHktMiBiZy1ibHVlLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQgc2hhZG93XCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElvTWREb3dubG9hZCBzaXplPXsyMH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgRG93bmxvYWQgRnVsbCBSZXBvcnRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSBcImdyb3VwRGV0YWlsc1wiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtkZXRhaWxzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cD5sb2FkaW5nLi4uPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBtYXgtdy1sZyAgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteS0wIGxlZnQtNCBmbGV4IGl0ZW1zLWNlbnRlciB0ZXh0LWdyYXktNDAwIFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpU2VhcmNoIGNsYXNzTmFtZT1cInRleHQteGxcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGN1c3RvbWVyIGRldGFpbHMuLi5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTEyIHByLTUgcHktMy41IHRleHQtZ3JheS04MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgc2hhZG93LTN4bCBcclxuICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyLWdyYXktNDAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTQwMCBmb2N1czpib3JkZXItYmx1ZS00MDAgXHJcbiAgICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZWFzZS1pbi1vdXQgdGV4dC1zbSBtZDp0ZXh0LWJhc2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaFRleHR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VhcmNoVGV4dCAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBkZXRhaWxzQXJyYXkgPSBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsga2V5OiBcIk5hbWVcIiwgdmFsdWU6IGdyb3VwLmZ1bGxfbmFtZSB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogXCJFbWFpbFwiLCB2YWx1ZTogZ3JvdXAuZW1haWwgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6IFwiUGhvbmVcIiwgdmFsdWU6IGdyb3VwLnBob25lX251bWJlciB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIkFsdGVybmF0ZSBOdW1iZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogZ3JvdXAuYWx0ZXJuYXRlX251bWJlcixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6IFwiQWRkcmVzc1wiLCB2YWx1ZTogZ3JvdXAuYWRkcmVzcyB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGtleTogXCJBYWRoYWFyXCIsIHZhbHVlOiBncm91cC5hZGhhYXJfbm8gfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6IFwiUEFOXCIsIHZhbHVlOiBncm91cC5wYW5fbm8gfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBrZXk6IFwiUGluY29kZVwiLCB2YWx1ZTogZ3JvdXAucGluY29kZSB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIkZhdGhlciBOYW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IGdyb3VwLmZhdGhlcl9uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIk5vbWluZWUgTmFtZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiBncm91cC5ub21pbmVlX25hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiQmFuayBOYW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IGdyb3VwLmJhbmtfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCJCYW5rIEFjY291bnRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogZ3JvdXAuYmFua19hY2NvdW50X251bWJlcixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZnVzZSA9IG5ldyBGdXNlKGRldGFpbHNBcnJheSwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXlzOiBbXCJrZXlcIiwgXCJ2YWx1ZVwiXSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyZXNob2xkOiAwLjMsIC8vIEZ1enp5IG1hdGNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCByZXN1bHRzID0gZnVzZS5zZWFyY2goc2VhcmNoVGV4dCk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIGJnLXdoaXRlIGJvcmRlciByb3VuZGVkIHNoYWRvdyBwLTMgdy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVzdWx0cy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0cy5tYXAoKHsgaXRlbSB9KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0ua2V5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSBib3JkZXItYlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPntpdGVtLmtleX08L3N0cm9uZz4g4oaSe1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnZhbHVlIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwPk5vIG1hdGNoaW5nIGRldGFpbHM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFRvZ2dsZSBCdXR0b25zICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRWaXNpYmxlUm93cygocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdzE6ICFwcmV2LnJvdzEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNSBweS0yIHJvdW5kZWQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBlYXNlLWluLW91dFxyXG4gICAgICAgICR7dmlzaWJsZVJvd3Mucm93MVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmFkaWVudC10by1yIGZyb20tZ3JlZW4tNTAwIHRvLWdyZWVuLTcwMCB0ZXh0LXdoaXRlIHNoYWRvdy1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTcwMCB0by1ibHVlLTkwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgaG92ZXI6c2NhbGUtMTA1XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICBgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt2aXNpYmxlUm93cy5yb3cxXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCLinJMgSGlkZSBCYXNpYyBJbmZvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlNob3cgQmFzaWMgSW5mb1wifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRWaXNpYmxlUm93cygocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvdzI6ICFwcmV2LnJvdzIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNSBweS0yIHJvdW5kZWQtbGcgdGV4dC1zbSBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBlYXNlLWluLW91dFxyXG4gICAgICAgICR7dmlzaWJsZVJvd3Mucm93MlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmFkaWVudC10by1yIGZyb20tZ3JlZW4tNTAwIHRvLWdyZWVuLTcwMCB0ZXh0LXdoaXRlIHNoYWRvdy1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTcwMCB0by1ibHVlLTkwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgaG92ZXI6c2NhbGUtMTA1XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICBgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt2aXNpYmxlUm93cy5yb3cyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCLinJMgSGlkZSBBZGRyZXNzIEluZm9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiU2hvdyBBZGRyZXNzIEluZm9cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VmlzaWJsZVJvd3MoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3czOiAhcHJldi5yb3czLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTUgcHktMiByb3VuZGVkLWxnIHRleHQtc20gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZWFzZS1pbi1vdXRcclxuICAgICAgICAke3Zpc2libGVSb3dzLnJvdzNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctZ3JhZGllbnQtdG8tciBmcm9tLWdyZWVuLTUwMCB0by1ncmVlbi03MDAgdGV4dC13aGl0ZSBzaGFkb3ctbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS03MDAgdG8tYmx1ZS05MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIGhvdmVyOnNjYWxlLTEwNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgYH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmlzaWJsZVJvd3Mucm93M1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwi4pyTIEhpZGUgUmVnaW9uYWwgSW5mb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJTaG93IFJlZ2lvbmFsIEluZm9cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VmlzaWJsZVJvd3MoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3c0OiAhcHJldi5yb3c0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTUgcHktMiByb3VuZGVkLWxnIHRleHQtc20gZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgZWFzZS1pbi1vdXRcclxuICAgICAgICAke3Zpc2libGVSb3dzLnJvdzRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmctZ3JhZGllbnQtdG8tciBmcm9tLWdyZWVuLTUwMCB0by1ncmVlbi03MDAgdGV4dC13aGl0ZSBzaGFkb3ctbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS03MDAgdG8tYmx1ZS05MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIGhvdmVyOnNjYWxlLTEwNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgYH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmlzaWJsZVJvd3Mucm93NFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwi4pyTIEhpZGUgUmVmZXJyYWwsIE5vbWluZWUgJiBCYW5rIERldGFpbHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiU2hvdyBSZWZlcnJhbCwgTm9taW5lZSAmIEJhbmsgRGV0YWlsc1wifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBSb3cgMTogQmFzaWMgSW5mbyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Zpc2libGVSb3dzLnJvdzEgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtOCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgdy1mdWxsIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dyb3VwLmZ1bGxfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0IGxhYmVsPVwiRW1haWxcIiB2YWx1ZT17Z3JvdXAuZW1haWx9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNCB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJQaG9uZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cC5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiQWRoYWFyIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dyb3VwLmFkaGFhcl9ub31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00IHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlBBTiBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cC5wYW5fbm99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiUGluY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dyb3VwLnBpbmNvZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBSb3cgMjogQWRkcmVzcyBJbmZvICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmlzaWJsZVJvd3Mucm93MiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC04IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNCB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJBZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXAuYWRkcmVzc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJHZW5kZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cC5nZW5kZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNCB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJEYXRlIG9mIEJpcnRoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cC5kYXRlb2ZiaXJ0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKGdyb3VwLmRhdGVvZmJpcnRoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0lTT1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiQ29sbGVjdGlvbiBBcmVhXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXA/LmNvbGxlY3Rpb25fYXJlYT8ucm91dGVfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00IHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIk1hcml0YWwgU3RhdHVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXAubWFyaXRhbF9zdGF0dXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiRmF0aGVyIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cC5mYXRoZXJfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFJvdyAzOiBSZWdpb25hbCBJbmZvICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmlzaWJsZVJvd3Mucm93MyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC04IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNCB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJOYXRpb25hbGl0eVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dyb3VwLm5hdGlvbmFsaXR5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlZpbGxhZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cC52aWxsYWdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTQgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dCBsYWJlbD1cIlRhbHVrXCIgdmFsdWU9e2dyb3VwLnRhbHVrfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkRpc3RyaWN0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXAuZGlzdHJpY3R9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNCB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0IGxhYmVsPVwiU3RhdGVcIiB2YWx1ZT17Z3JvdXAuc3RhdGV9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiQWx0ZXJuYXRlIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dyb3VwLmFsdGVybmF0ZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBSb3cgNDogUmVmZXJyYWwsIE5vbWluZWUgJiBCYW5rIEluZm8gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt2aXNpYmxlUm93cy5yb3c0ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTggbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00IHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlJlZmVycmFsIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cC5yZWZlcnJhbF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIk5vbWluZWUgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dyb3VwLm5vbWluZWVfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJOb21pbmVlIERPQlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXAubm9taW5lZV9kYXRlb2ZiaXJ0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKGdyb3VwLm5vbWluZWVfZGF0ZW9mYmlydGgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvSVNPU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuc3BsaXQoXCJUXCIpWzBdXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00IHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIk5vbWluZWUgUGhvbmUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXAubm9taW5lZV9waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiTm9taW5lZSBSZWxhdGlvbnNoaXBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cC5ub21pbmVlX3JlbGF0aW9uc2hpcH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJCYW5rIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cC5iYW5rX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtNCB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJCYW5rIEJyYW5jaCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXAuYmFua19icmFuY2hfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJCYW5rIEFjY291bnQgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXAuYmFua19hY2NvdW50X251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJCYW5rIElGU0MgQ29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dyb3VwLmJhbmtfSUZTQ19jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFbnJvbGxlZCBHcm91cHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtUYWJsZUF1Y3Rpb25zICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGFibGVBdWN0aW9ucy5sZW5ndGggPiAwICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIWlzTG9hZGluZyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbihcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRhYmxlQXVjdGlvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWFyY2hUZXh0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17QXVjdGlvbmNvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiQ3VzdG9tZXIgQ2hpdCBFbnJvbGxtZW50IERldGFpbHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJDdXN0b21lciBOYW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlBob25lIE51bWJlclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJUb3RhbCBBbW91bnQgVG8gQmUgUGFpZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJUb3RhbCBQcm9maXRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiVG90YWwgTmV0IFRvIGJlIFBhaWRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiVG90YWwgQmFsYW5jZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJWYWx1ZXM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwLmZ1bGxfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwPy5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbFRvQmVwYWlkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWxwcm9maXQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOZXRUb3RhbHByb2ZpdCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5ldFRvdGFscHJvZml0ICYmIFRvdGFscGFpZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IE5ldFRvdGFscHJvZml0IC0gVG90YWxwYWlkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BDdXN0b21lciBDaGl0IEVucm9sbG1lbnQgRGV0YWlscy5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZEJvcnJvd2VyRGF0YSAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcmVkQm9ycm93ZXJEYXRhLmxlbmd0aCA+IDAgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAhaXNMb2FkaW5nICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1tZWRpdW0gbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIExvYW4gRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyZWRCb3Jyb3dlckRhdGF9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17bG9hbkNvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIkxvYW4gRGV0YWlscy5jc3ZcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkxvYW4gRGV0YWlsc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkUGlnbWVEYXRhICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyZWRQaWdtZURhdGEubGVuZ3RoID4gMCAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICFpc0xvYWRpbmcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGlnbWUgRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyZWRQaWdtZURhdGF9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17cGlnbWVDb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJQaWdteSBEZXRhaWxzLmNzdlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiUGlnbXkgRGV0YWlsc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFpc0xvYWRpbmcgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUYWJsZUF1Y3Rpb25zLmxlbmd0aCA9PT0gMCAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcmVkQm9ycm93ZXJEYXRhLmxlbmd0aCA9PT0gMCAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcmVkUGlnbWVEYXRhLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMjAgdy1mdWxsIGZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTm8gQ2hpdCBHcm91cCwgTG9hbiwgb3IgUGlnbWUgZGF0YSBmb3VuZCBmb3JcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcyBjdXN0b21lclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0xvYWRpbmcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e2lzTG9hZGluZ30gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshaXNMb2FkaW5nICYmIFRhYmxlQXVjdGlvbnMubGVuZ3RoID09PSAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNDAgdy1mdWxsIGZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBObyBFbnJvbGxlZCBHcm91cCBEYXRhIEZvdW5kXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNCBtdC01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWItMSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIEFtb3VudCB0byBiZSBQYWlkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiLVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17VG90YWxUb0JlcGFpZCB8fCBcIlwifSAvLyBEZWZhdWx0IHRvIGVtcHR5IHN0cmluZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC00IHB5LTIgc2hhZG93LXNtIG91dGxpbmUtbm9uZSB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTEgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBQcm9maXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCItXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtUb3RhbHByb2ZpdCB8fCBcIlwifSAvLyBEZWZhdWx0IHRvIGVtcHR5IHN0cmluZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBweC00IHB5LTIgc2hhZG93LXNtIG91dGxpbmUtbm9uZSB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTEgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBOZXQgVG8gYmUgUGFpZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIi1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e05ldFRvdGFscHJvZml0IHx8IFwiXCJ9IC8vIERlZmF1bHQgdG8gZW1wdHkgc3RyaW5nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTQgcHktMiBzaGFkb3ctc20gb3V0bGluZS1ub25lIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWItMSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIEFtb3VudCBQYWlkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiLVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17VG90YWxwYWlkIHx8IFwiXCJ9IC8vIERlZmF1bHQgdG8gZW1wdHkgc3RyaW5nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTQgcHktMiBzaGFkb3ctc20gb3V0bGluZS1ub25lIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWItMSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIEJhbGFuY2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCItXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTmV0VG90YWxwcm9maXQgJiYgVG90YWxwYWlkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBOZXRUb3RhbHByb2ZpdCAtIFRvdGFscGFpZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSAvLyBDYWxjdWxhdGUgb25seSBpZiBib3RoIGFyZSBudW1iZXJzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTQgcHktMiBzaGFkb3ctc20gb3V0bGluZS1ub25lIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwiYWNjb3VudERlYWlsc1wiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCByb3VuZGVkLTJ4bCBzaGFkb3ctbWQgcC01IG10LTQgc3BhY2UteS02IG92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogTG9hZGVyICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7YWNjb3VudERldGFpbHNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTAgdGV4dC1ibHVlLTYwMCBmb250LXNlbWlib2xkIHRleHQtbGcgYW5pbWF0ZS1wdWxzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgTG9hZGluZyBBY2NvdW50IERldGFpbHMuLi5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEN1c3RvbWVyIFN1bW1hcnkgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTUgZ2FwLTQgXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTEwMCByb3VuZGVkLTJ4bCBwLTQgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLXNoYWRvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LWdyYXktNDAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEN1c3RvbWVyIE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWNjb3VudERldGFpbHM/LnVzZXJEZXRhaWxzPy5mdWxsX25hbWUgfHwgXCLigJRcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTEwMCByb3VuZGVkLTJ4bCBwLTQgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLXNoYWRvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LWdyYXktNDAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEN1c3RvbWVyIElEXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJmb250LW1vbm8gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHRleHQtc20gdHJ1bmNhdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthY2NvdW50RGV0YWlscz8udXNlckRldGFpbHM/LmN1c3RvbWVyX2lkIHx8IFwi4oCUXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0xMDAgcm91bmRlZC0yeGwgcC00IHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbi1zaGFkb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgdGV4dC1ncmF5LTQwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQaG9uZSBOdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWNjb3VudERldGFpbHM/LnVzZXJEZXRhaWxzPy5waG9uZV9udW1iZXIgfHwgXCLigJRcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZW1lcmFsZC01MCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMTAwIHJvdW5kZWQtMnhsIHAtNCBzaGFkb3ctc20gaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb24tc2hhZG93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHRleHQtZW1lcmFsZC02MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQmFsYW5jZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNzAwIHRleHQteGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXthY2NvdW50RGV0YWlscz8uYmFsYW5jZT8udG9Mb2NhbGVTdHJpbmcoKSB8fCAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMTAwIHJvdW5kZWQtMnhsIHAtNCBzaGFkb3ctc20gaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb24tc2hhZG93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHRleHQtZ3JheS00MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ3JlYXRlZCBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FjY291bnREZXRhaWxzPy5jcmVhdGVkQXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBuZXcgRGF0ZShhY2NvdW50RGV0YWlscy5jcmVhdGVkQXQpLnRvTG9jYWxlRGF0ZVN0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCLigJRcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBVc2VyIEFjY291bnRzIENhcmRzICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCB0ZXh0LWdyYXktNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBVc2VyIEFjY291bnRzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFZpZXcgVG9nZ2xlICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLXhsIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VmlldyhcImdyaWRcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0yIHRleHQteHMgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgJHt2aWV3ID09PSBcImdyaWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmF5LTkwMCB0ZXh0LXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1ncmF5LTUwMCBob3ZlcjpiZy1ncmF5LTUwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDE2IDE2XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjEuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cmVjdCB4PVwiMVwiIHk9XCIxXCIgd2lkdGg9XCI2XCIgaGVpZ2h0PVwiNlwiIHJ4PVwiMVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHJlY3QgeD1cIjlcIiB5PVwiMVwiIHdpZHRoPVwiNlwiIGhlaWdodD1cIjZcIiByeD1cIjFcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxyZWN0IHg9XCIxXCIgeT1cIjlcIiB3aWR0aD1cIjZcIiBoZWlnaHQ9XCI2XCIgcng9XCIxXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cmVjdCB4PVwiOVwiIHk9XCI5XCIgd2lkdGg9XCI2XCIgaGVpZ2h0PVwiNlwiIHJ4PVwiMVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBHcmlkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VmlldyhcImxpc3RcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0yIHRleHQteHMgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgJHt2aWV3ID09PSBcImxpc3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmF5LTkwMCB0ZXh0LXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1ncmF5LTUwMCBob3ZlcjpiZy1ncmF5LTUwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDE2IDE2XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjEuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGluZSB4MT1cIjFcIiB5MT1cIjRcIiB4Mj1cIjE1XCIgeTI9XCI0XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGluZSB4MT1cIjFcIiB5MT1cIjhcIiB4Mj1cIjE1XCIgeTI9XCI4XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGluZSB4MT1cIjFcIiB5MT1cIjEyXCIgeDI9XCIxNVwiIHkyPVwiMTJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTGlzdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIOKUgOKUgCBHUklEIFZJRVcg4pSA4pSAICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmlldyA9PT0gXCJncmlkXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiB4bDpncmlkLWNvbHMtMyBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FjY291bnREZXRhaWxzPy51c2VyYWNjb3VudHM/Lmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjY291bnREZXRhaWxzLnVzZXJhY2NvdW50cy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItZ3JheS0xMDAgc2hhZG93LXNtIHAtNSBob3ZlcjpzaGFkb3ctbWQgaG92ZXI6Ym9yZGVyLWdyYXktMjAwIHRyYW5zaXRpb24tYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogSGVhZGVyOiBTTCBOTyArIFRZUEUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtbW9ubyB0ZXh0LWdyYXktNDAwIGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICN7U3RyaW5nKGluZGV4ICsgMSkucGFkU3RhcnQoMiwgXCIwXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCBweC0zIHB5LTAuNSByb3VuZGVkLWZ1bGwgdHJhY2tpbmctd2lkZSAke2l0ZW0udHlwZSA9PT0gXCJDUkVESVRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWVtZXJhbGQtMTAwIHRleHQtZW1lcmFsZC03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLXJlZC0xMDAgdGV4dC1yZWQtNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIE5ldCBBbW91bnQgKEJpZykgd2l0aCBzaWduIGFuZCBjb2xvciAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC0yeGwgbWItMyAke2l0ZW0udHlwZSA9PT0gXCJDUkVESVRcIiA/IFwidGV4dC1ncmVlbi02MDBcIiA6IFwidGV4dC1yZWQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udHlwZSA9PT0gXCJDUkVESVRcIiA/IFwiK1wiIDogXCLigJNcIn3igrlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge01hdGguYWJzKE51bWJlcihpdGVtLmFtb3VudCB8fCAwKSkudG9Mb2NhbGVTdHJpbmcoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogRGV0YWlscyBpbiB0d28tY29sdW1uIGxheW91dCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIHB0LTMgZ3JpZCBncmlkLWNvbHMtMiBnYXAteC00IGdhcC15LTIuNSB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBHcm91cCAvIExvYW4gLyBQaWdteSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyb3VwIC8gTG9hbiAvIFBpZ215XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMCB0ZXh0LXJpZ2h0IHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0/Lmdyb3VwX2lkPy5ncm91cF9uYW1lICYmIGl0ZW0/LnRpY2tldFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBgJHtpdGVtLmdyb3VwX2lkLmdyb3VwX25hbWV9IFRpY2tldCAke2l0ZW0udGlja2V0fWBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogaXRlbT8ubG9hbj8ubG9hbl9pZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGl0ZW0ubG9hbi5sb2FuX2lkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogaXRlbT8ucGlnbWU/LnBpZ21lX2lkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBpdGVtLnBpZ21lLnBpZ21lX2lkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIuKAlFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogUmVhc29uICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwXCI+UmVhc29uPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDAgdGV4dC1yaWdodCB0cnVuY2F0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtPy5yZWFzb24gfHwgXCLigJRcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEdyb3NzIEFtb3VudCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMFwiPkdyb3NzIEFtb3VudDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtOdW1iZXIoaXRlbT8uZ3Jvc3NfYW1vdW50IHx8IDApLnRvTG9jYWxlU3RyaW5nKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBTZXJ2aWNlIENoYXJnZSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMFwiPlNlcnZpY2UgQ2hhcmdlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCB0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e051bWJlcihpdGVtPy5zZXJ2aWNlX2NoYXJnZSB8fCAwKS50b0xvY2FsZVN0cmluZygpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogR1NUICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwXCI+R1NUPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCB0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e051bWJlcihpdGVtPy5nc3RfYW1vdW50IHx8IDApLnRvTG9jYWxlU3RyaW5nKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBJTlRFUkVTVCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMFwiPklOVEVSRVNUPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCB0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5eyhpdGVtPy5pbnRlcmVzdF9hbW91bnQgfHwgMCkudG9Mb2NhbGVTdHJpbmcoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIE5ldCBBbW91bnQgKHJlcGVhdGVkIGZvciBjbGFyaXR5KSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMFwiPk5ldCBBbW91bnQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC14cyBmb250LWJvbGQgdGV4dC1yaWdodCAke2l0ZW0udHlwZSA9PT0gXCJDUkVESVRcIiA/IFwidGV4dC1ncmVlbi02MDBcIiA6IFwidGV4dC1yZWQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udHlwZSA9PT0gXCJDUkVESVRcIiA/IFwiK1wiIDogXCLigJNcIn3igrlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7TWF0aC5hYnMoTnVtYmVyKGl0ZW0/LmFtb3VudCB8fCAwKSkudG9Mb2NhbGVTdHJpbmcoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEFkbWluICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwXCI+QWRtaW48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0/LmFkbWluX2lkPy5uYW1lIHx8IFwi4oCUXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtbW9ubyB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbT8uYWRtaW5faWQ/LmFkbWluX2NvZGUgfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIERpcmVjdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTQwMFwiPkRpcmVjdGlvbjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIGlubGluZS1ibG9jayB0ZXh0LXJpZ2h0ICR7aXRlbT8ucGF5bWVudF9kaXJlY3Rpb24gPT09IFwiT1VUXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1yZWQtMTAwIHRleHQtcmVkLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctYmx1ZS0xMDAgdGV4dC1ibHVlLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtPy5wYXltZW50X2RpcmVjdGlvbiB8fCBcIklOXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBEYXRlICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNDAwXCI+RGF0ZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1tb25vIHRleHQtZ3JheS01MDAgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShpdGVtLmNyZWF0ZWRBdCkudG9Mb2NhbGVTdHJpbmcoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFRPIFVTRVIgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtZ3JheS00MDBcIj5UbyBVc2VyPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8gdGV4dC1ncmF5LTUwMCB0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udG9fdXNlcj8uZnVsbF9uYW1lIHx8IFwiLVwifSAgICAgIHtpdGVtLnRvX2xvYW4/LmxvYW5faWQgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi1mdWxsIHRleHQtY2VudGVyIHB5LTEwIHRleHQtZ3JheS00MDAgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vIGFjY291bnQgcmVjb3JkcyBmb3VuZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Lyog4pSA4pSAIExJU1QgVklFVyDilIDilIAgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt2aWV3ID09PSBcImxpc3RcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHNoYWRvdy1zbSBiZy13aGl0ZSBvdmVyZmxvdy1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Lyog4pSA4pSA4pSAIEhFQURFUiDilIDilIDilIAgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIlxyXG4gICAgICAgIGhpZGRlbiBtZDpncmlkXHJcbiAgICAgICAgZ3JpZC1jb2xzLVs2MHB4XzkwcHhfMTAwcHhfMjIwcHhfMTYwcHhfMTgwcHhfMTUwcHhfMTUwcHhfMTMwcHhfMTUwcHhfMTUwcHhfMTYwcHhdXHJcbiAgICAgICAgZ2FwLXgtOCBweC02IHB5LTRcclxuICAgICAgICBiZy1ncmF5LTUwIGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMFxyXG4gICAgICBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiU0wgTk9cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIkRBVEVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlRZUEVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIkZST006KEdST1VQIC8gTG9hbiAvIFBpZ215KVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiVE8gVVNFUlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiUkVBU09OXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJHUk9TUyBBTU9VTlRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlNFUlZJQ0UgQ0hBUkdFXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJHU1RcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIklOVEVSRVNUXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJORVQgQU1PVU5UXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJBRE1JTlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdLm1hcCgoaCwgaSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzTnVtZXJpYyA9IGkgPj0gNiAmJiBpIDw9IDEwO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2h9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS01MDAgJHtpc051bWVyaWMgPyBcInRleHQtcmlnaHRcIiA6IFwidGV4dC1sZWZ0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2h9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiDilIDilIDilIAgUk9XUyDilIDilIDilIAgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWNjb3VudERldGFpbHM/LnVzZXJhY2NvdW50cz8ubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtZ3JheS0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWNjb3VudERldGFpbHMudXNlcmFjY291bnRzLm1hcCgoaXRlbSwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiXHJcbiAgICAgICAgICAgICAgZ3JpZCBncmlkLWNvbHMtMVxyXG4gICAgICAgICAgICAgIG1kOmdyaWQtY29scy1bNjBweF85MHB4XzEwMHB4XzIyMHB4XzE2MHB4XzE4MHB4XzE1MHB4XzE1MHB4XzEzMHB4XzE1MHB4XzE1MHB4XzE2MHB4XVxyXG4gICAgICAgICAgICAgIGdhcC14LTggcHgtNiBweS01IGl0ZW1zLWNlbnRlclxyXG4gICAgICAgICAgICAgIGhvdmVyOmJnLWJsdWUtNTAgdHJhbnNpdGlvbi1hbGxcclxuICAgICAgICAgICAgXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFNMIE5PICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBtZDpibG9jayB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7U3RyaW5nKGluZGV4ICsgMSkucGFkU3RhcnQoMiwgXCIwXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBEQVRFICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShpdGVtLmNyZWF0ZWRBdCkudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShpdGVtLmNyZWF0ZWRBdCkudG9Mb2NhbGVUaW1lU3RyaW5nKFwiZW4tSU5cIiwge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBob3VyOiBcIjItZGlnaXRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWludXRlOiBcIjItZGlnaXRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogVFlQRSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggcHgtMyBweS0xIHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgJHtpdGVtLnR5cGUgPT09IFwiQ1JFRElUXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1yZWQtMTAwIHRleHQtcmVkLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnR5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBHUk9VUCAvIExPQU4gLyBQSUdNWSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbT8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgJiYgaXRlbT8udGlja2V0ID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5ncm91cF9pZC5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRpY2tldCB7aXRlbS50aWNrZXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiBpdGVtPy5sb2FuPy5sb2FuX2lkID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5sb2FuLmxvYW5faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIHRleHQtZ3JheS01MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTG9hbiDigrkge2l0ZW0ubG9hbi5sb2FuX2Ftb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IGl0ZW0/LnBpZ21lPy5waWdtZV9pZCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgdHJ1bmNhdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5waWdtZS5waWdtZV9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCLigJRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFRPIFVTRVIgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdHJ1bmNhdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnRvX3VzZXI/LmZ1bGxfbmFtZSB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCB0cnVuY2F0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udG9fdXNlcj8ucGhvbmVfbnVtYmVyIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50b19sb2FuPy5sb2FuX2lkIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogUkVBU09OICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRydW5jYXRlIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5yZWFzb24gfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEdST1NTIEFNT1VOVCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZvbnQtYm9sZCB0ZXh0LXJpZ2h0IHdoaXRlc3BhY2Utbm93cmFwICR7aXRlbS50eXBlID09PSBcIkNSRURJVFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtcmVkLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmdyb3NzX2Ftb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBgJHtpdGVtLnR5cGUgPT09IFwiQ1JFRElUXCIgPyBcIitcIiA6IFwi4oCTXCJ9IOKCuSR7TnVtYmVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpdGVtLmdyb3NzX2Ftb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFNFUlZJQ0UgQ0hBUkdFICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXJpZ2h0IHRleHQtcmVkLTYwMCB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnNlcnZpY2VfY2hhcmdlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGDigJMg4oK5JHtOdW1iZXIoaXRlbS5zZXJ2aWNlX2NoYXJnZSkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBHU1QgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtcmlnaHQgdGV4dC1yZWQtNjAwIHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uZ3N0X2Ftb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBg4oCTIOKCuSR7TnVtYmVyKGl0ZW0uZ3N0X2Ftb3VudCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBJTlRFUkVTVCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1yaWdodCB0ZXh0LWdyYXktNjAwIHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge051bWJlcihpdGVtPy5pbnRlcmVzdF9hbW91bnQgfHwgMCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTkVUIEFNT1VOVCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQtcmlnaHQgZm9udC1ib2xkIHdoaXRlc3BhY2Utbm93cmFwICR7aXRlbS50eXBlID09PSBcIkNSRURJVFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtcmVkLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnR5cGUgPT09IFwiQ1JFRElUXCIgPyBcIitcIiA6IFwi4oCTXCJ94oK5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge01hdGguYWJzKE51bWJlcihpdGVtLmFtb3VudCB8fCAwKSkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQURNSU4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWwgcGwtNCBtaW4tdy0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uYWRtaW5faWQgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc20gdHJ1bmNhdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5hZG1pbl9pZC5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgdHJ1bmNhdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5hZG1pbl9pZC5hZG1pbl9jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCItXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTAgdGV4dC1ncmF5LTQwMCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTm8gYWNjb3VudCByZWNvcmRzIGZvdW5kXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwiYmFzaWNSZXBvcnRcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWItMSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBHcm91cHMgYW5kIFRpY2tldHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVucm9sbEdyb3VwSWQuZ3JvdXBJZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGAke0Vucm9sbEdyb3VwSWQuZ3JvdXBJZH18JHtFbnJvbGxHcm91cElkLnRpY2tldH1gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRW5yb2xsR3JvdXB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHB4LTYgcHktMiBzaGFkb3ctc20gb3V0bGluZS1ub25lIHctZnVsbCBtYXgtdy1tZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IEdyb3VwIHwgVGlja2V0PC9vcHRpb24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZEVucm9sbG1lbnRzLm1hcCgoZ3JvdXApID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXA/Lmdyb3VwX2lkICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFtcIkFjdGl2ZVwiLCBcIk9uIEhvbGRcIl0uZmluZChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoc3RhdHVzKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzID09PVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXA/LmN1c3RvbWVyX3N0YXR1cyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtncm91cD8uZ3JvdXBfaWQ/Ll9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgJHtncm91cD8uZ3JvdXBfaWQ/Ll9pZH18JHtncm91cD8udGlja2V0c31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWV9IHx7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXA/LnRpY2tldHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge0FycmF5LmlzQXJyYXkobG9hbkN1c3RvbWVycz8ub3ZlcmFsbF9sb2FuKSAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9hbkN1c3RvbWVycy5vdmVyYWxsX2xvYW4ubWFwKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAobG9hbiwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2FuPy5sb2FuX2RldGFpbHM/LmxvYW4/Ll9pZCB8fCBpbmRleFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2BMb2FufCR7bG9hbj8ubG9hbl9kZXRhaWxzPy5sb2FuPy5faWQgfHwgaW5kZXhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2xvYW4/LmxvYW5fZGV0YWlscz8ubG9hbj8ubG9hbl9pZCB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIk4vQVwifXtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHwg4oK5e2xvYW4/LmxvYW5fdmFsdWUgfHwgMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtBcnJheS5pc0FycmF5KHBpZ21lQ3VzdG9tZXJzPy5vdmVyYWxsX3BpZ21lKSAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGlnbWVDdXN0b21lcnMub3ZlcmFsbF9waWdtZS5tYXAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChwaWdtZSwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwaWdtZT8ucGlnbWVfZGV0YWlscz8ucGlnbWU/Ll9pZCB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2BQaWdtZXwke3BpZ21lPy5waWdtZV9kZXRhaWxzPy5waWdtZT8uX2lkIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZGV4XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwaWdtZT8ucGlnbWVfZGV0YWlscz8ucGlnbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPy5waWdtZV9pZCB8fCBcIk4vQVwifXtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHwg4oK5e3BpZ21lPy50b3RhbF9kZXBvc2l0ZWRfYW1vdW50IHx8IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtOCBmbGV4LXdyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgUmVnaXN0cmF0aW9uIEZlZTog4oK5JHtyZWdpc3RyYXRpb25BbW91bnQgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYm9yZGVyIHJvdW5kZWQgZm9udC1zZW1pYm9sZCB3LTYwIHRleHQtY2VudGVyIGJnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTgwMCBib3JkZXItZ3JlZW4tNDAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YFBheW1lbnQgQmFsYW5jZTog4oK5JHtmaW5hbFBheW1lbnRCYWxhbmNlfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgcm91bmRlZCBmb250LXNlbWlib2xkIHctNjAgdGV4dC1jZW50ZXIgYmctYmx1ZS0xMDAgdGV4dC1ibHVlLTgwMCBib3JkZXItYmx1ZS00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgVG90YWw6IOKCuSR7TnVtYmVyKGZpbmFsUGF5bWVudEJhbGFuY2UpICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOdW1iZXIocmVnaXN0cmF0aW9uQW1vdW50IHx8IDApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgcm91bmRlZCBmb250LXNlbWlib2xkIHctNjAgdGV4dC1jZW50ZXIgYmctcHVycGxlLTEwMCB0ZXh0LXB1cnBsZS04MDAgYm9yZGVyLXB1cnBsZS00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgeyhUYWJsZUVucm9sbHM/Lmxlbmd0aCA+IDAgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcnJvd2Vyc0RhdGE/Lmxlbmd0aCA+IDAgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBpZ21lQ3VzdG9tZXJEYXRhPy5sZW5ndGggPiAwKSAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIWJhc2ljTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkN1c3RvbWVyIExlZGdlciBSZXBvcnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJDdXN0b21lciBMZWRnZXIgUmVwb3J0LmNzdlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVucm9sbEdyb3VwSWQuZ3JvdXBJZCA9PT0gXCJMb2FuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJDdXN0b21lciBOYW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJDdXN0b21lciBJZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiUGhvbmUgTnVtYmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJMb2FuIElEXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJMb2FuIFR5cGVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IEVucm9sbEdyb3VwSWQuZ3JvdXBJZCA9PT0gXCJQaWdtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIkN1c3RvbWVyIE5hbWVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiQ3VzdG9tZXIgSWRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiUGhvbmUgTnVtYmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlBpZ215IElEXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlBpZ215IFR5cGVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIkN1c3RvbWVyIE5hbWVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiQ3VzdG9tZXIgSWRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiUGhvbmUgTnVtYmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlRpY2tldCBOdW1iZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiR3JvdXAgTmFtZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJWYWx1ZXM9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRW5yb2xsR3JvdXBJZC5ncm91cElkID09PSBcIkxvYW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cD8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwPy5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cD8ucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBGaW5kIHRoZSBzZWxlY3RlZCBsb2FuIHRvIGdldCBpdHMgbG9hbl9pZCAobm90IF9pZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHNlbGVjdGVkTG9hbiA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvYW5DdXN0b21lcnM/Lm92ZXJhbGxfbG9hbj8uZmluZChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAobG9hbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvYW4/LmxvYW5fZGV0YWlscz8ubG9hblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/Ll9pZCA9PT1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVucm9sbEdyb3VwSWQudGlja2V0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRMb2FuPy5sb2FuX2RldGFpbHM/LmxvYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/LmxvYW5faWQgfHwgRW5yb2xsR3JvdXBJZC50aWNrZXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkoKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIkxvYW5cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IEVucm9sbEdyb3VwSWQuZ3JvdXBJZCA9PT0gXCJQaWdtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cD8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXA/LmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXA/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEZpbmQgdGhlIHNlbGVjdGVkIHBpZ215IHRvIGdldCBpdHMgcGlnbWVfaWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc2VsZWN0ZWRQaWdtZSA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGlnbWVDdXN0b21lcnM/Lm92ZXJhbGxfcGlnbWU/LmZpbmQoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAocGlnbWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBpZ21lPy5waWdtZV9kZXRhaWxzPy5waWdtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8uX2lkID09PVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFbnJvbGxHcm91cElkLnRpY2tldCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkUGlnbWU/LnBpZ21lX2RldGFpbHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8ucGlnbWU/LnBpZ21lX2lkIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRW5yb2xsR3JvdXBJZC50aWNrZXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKCksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlBpZ215XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXA/LmZ1bGxfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwPy5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwPy5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFbnJvbGxHcm91cElkPy50aWNrZXQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cERldGFpbHM/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVucm9sbEdyb3VwSWQ/Lmdyb3VwSWQgPT09IFwiTG9hblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gYm9ycm93ZXJzRGF0YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IEVucm9sbEdyb3VwSWQ/Lmdyb3VwSWQgPT09IFwiUGlnbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gcGlnbWVDdXN0b21lckRhdGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFRhYmxlRW5yb2xsc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVucm9sbEdyb3VwSWQ/Lmdyb3VwSWQgPT09IFwiTG9hblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gQmFzaWNMb2FuQ29sdW1uc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IEVucm9sbEdyb3VwSWQ/Lmdyb3VwSWQgPT09IFwiUGlnbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gQmFzaWNQaWdtZUNvbHVtbnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IEJhc2ljY29sdW1uc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXtiYXNpY0xvYWRpbmd9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSBcImRpc2J1cnNlbWVudFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTEgdGV4dC1zbSAgdGV4dC1ncmF5LTcwMCBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBEaXNidXJzZW1lbnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtkaXNidXJzZW1lbnRMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogZmlsdGVyZWREaXNidXJzZW1lbnQ/Lmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJlZERpc2J1cnNlbWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17RGlzYnVyc2VtZW50Q29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPXtgQ3VzdG9tZXIgUGF5b3V0IFJlcG9ydGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BDdXN0b21lciBQYXlvdXQgUmVwb3J0LmNzdmB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiQ3VzdG9tZXIgTmFtZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiUGhvbmUgTnVtYmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXA/LmZ1bGxfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cD8ucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNDAgIHctZnVsbCBmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vIERpc2J1cnNlbWVudCBEYXRhIEZvdW5kXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSBcImN1c3RvbWVyUGF5bWVudFN0YXRlbWVudFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTEgdGV4dC1zbSAgdGV4dC1ncmF5LTcwMCBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lciBQYXltZW50IFN0YXRlbWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7KGZ1bmN0aW9uICgpIHsgfSkoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJtYi0xIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgR3JvdXBzIGFuZCBUaWNrZXRzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZW5yb2xsbWVudElkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUVucm9sbG1lbnRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNiBweS0yIHNoYWRvdy1zbSBvdXRsaW5lLW5vbmUgdy1mdWxsIG1heC13LW1kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IEdyb3VwIHwgVGlja2V0PC9vcHRpb24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vucm9sbG1lbnREYXRhLm1hcCgoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtlPy5faWR9IHZhbHVlPXtgJHtlPy5faWR9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZT8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWV9IHwge2U/LnRpY2tldHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtzdGF0ZW1lbnRMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogYWN0aXZlRW5yb2xsbWVudERhdGE/Lmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhPXthY3RpdmVFbnJvbGxtZW50RGF0YX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Q3VzdG9tZXJQYXltZW50U3RhdGVtZW50Q29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0Q29scz17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXJQYXltZW50U3RhdGVtZW50RXhwb3J0c0NvbHVtbnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9e2BDdXN0b21lciBTdGF0ZW1lbnQgUmVwb3J0YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YEN1c3RvbWVyIFN0YXRlbWVudC5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNDAgIHctZnVsbCBmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vIEN1c3RvbWVyIFBheW1lbnQgU3RhdGVtZW50IEZvdW5kXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSBcInRyYW5zYWN0aW9uc1wiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm0tNCB0ZXh0LXNtICB0ZXh0LWdyYXktNzAwIGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFRyYW5zYWN0aW9uc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJteS02IHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiBncm91cCBiZy1ncmFkaWVudC10by1iciBmcm9tLXdoaXRlIHRvLWJsdWUtNTAgYm9yZGVyIGJvcmRlci1ibHVlLTEwMCByb3VuZGVkLTJ4bCBwLTQgc2hhZG93LXNtIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBob3ZlcjpzaGFkb3ctbWQgaG92ZXI6Ym9yZGVyLWJsdWUtMzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFN1YnRsZSBCYWNrZ3JvdW5kIEljb24gRGVjb3JhdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIC1yaWdodC0yIC1ib3R0b20tMiB0ZXh0LWJsdWUtMTAwLzQwIGdyb3VwLWhvdmVyOnRleHQtYmx1ZS0yMDAvNTAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNZEFjY291bnRCYWxhbmNlV2FsbGV0IHNpemU9ezgwfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBJY29uIENvbnRhaW5lciAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdy0xMiBoLTEyIGJnLWJsdWUtNjAwIHJvdW5kZWQteGwgc2hhZG93LWxnIHNoYWRvdy1ibHVlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWRBY2NvdW50QmFsYW5jZVdhbGxldCBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIHRleHQtMnhsXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVzdCBsZWFkaW5nLW5vbmUgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1iYXNlbGluZSBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtYmx1ZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtc2xhdGUtODAwIHRyYWNraW5nLXRpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dG90YWxUcmFuc2FjdGlvbkFtb3VudC50b0xvY2FsZVN0cmluZyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJlbi1JTlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBSZWFsLXRpbWUgV29yZHMgQ29udmVyc2lvbiAtIGtlZXBpbmcgY29uc2lzdGVuY3kgd2l0aCB5b3VyIHBheXJvbGwgc3R5bGUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3RvdGFsVHJhbnNhY3Rpb25BbW91bnQgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBwdC0zIGJvcmRlci10IGJvcmRlci1ibHVlLTEwMC81MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LW1lZGl1bSB0ZXh0LWJsdWUtNTAwIGl0YWxpYyBsZWFkaW5nLXRpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHModG90YWxUcmFuc2FjdGlvbkFtb3VudCl9e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgeGw6Z3JpZC1jb2xzLTQgZ2FwLTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRGF0ZSBSYW5nZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlVHJhbnNhY3Rpb25zU2VsZWN0RmlsdGVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRMYWJlbCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTGFzdCA1MCBUcmFuc2FjdGlvbnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBoZWlnaHQ6IFwiNDRweFwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtkYXlHcm91cC5tYXAoKHRpbWUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXt0aW1lLnZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RpbWUudmFsdWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RpbWUubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogRGF0ZSBGaWVsZCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7c2hvd0ZpbHRlckZpZWxkICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRnJvbSBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEZyb21EYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGUudGFyZ2V0LnZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTEgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHB4LTQgcHktMiBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1pbmRpZ28tNTAwIGZvY3VzOmJvcmRlci10cmFuc3BhcmVudCB0cmFuc2l0aW9uLWFsbCBvdXRsaW5lLW5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvIERhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkVG9EYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFRvRGF0ZShlLnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTExIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC00IHB5LTIgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctaW5kaWdvLTUwMCBmb2N1czpib3JkZXItdHJhbnNwYXJlbnQgdHJhbnNpdGlvbi1hbGwgb3V0bGluZS1ub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IE1vZGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb2RlPVwibXVsdGlwbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRQYXltZW50TW9kZSB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgcGF5bWVudCBtb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhtb2RlcykgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkUGF5bWVudE1vZGUobW9kZXMpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5sYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBoZWlnaHQ6IFwiNDRweFwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiBcIkNhc2hcIiwgdmFsdWU6IFwiY2FzaFwiIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogXCJPbmxpbmVcIiwgdmFsdWU6IFwib25saW5lXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogXCJQYXltZW50IExpbmtcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiBcIlBheW1lbnQgTGlua1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IEZvclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vZGU9XCJtdWx0aXBsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFBheW1lbnRGb3J9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgcGF5bWVudCBmb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KG1vZGVzKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRQYXltZW50Rm9yKG1vZGVzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24ubGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgaGVpZ2h0OiBcIjQ0cHhcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBsYWJlbDogXCJDaGl0XCIsIHZhbHVlOiBcIkNoaXRcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiUGlnbWVcIiwgdmFsdWU6IFwiUGlnbWVcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiTG9hblwiLCB2YWx1ZTogXCJMb2FuXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93QWxsUGF5bWVudE1vZGVzICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWNjb3VudCBUeXBlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRBY2NvdW50VHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgYWNjb3VudCB0eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZ3JvdXBJZCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkQWNjb3VudFR5cGUoZ3JvdXBJZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBoZWlnaHQ6IFwiNDRweFwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWxsIFR5cGVzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwic3VzcGVuc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFN1c3BlbnNlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiY3JlZGl0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDcmVkaXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJhZGp1c3RtZW50XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBZGp1c3RtZW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwib3RoZXJzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBPdGhlcnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dHJhbnNhY3Rpb25zTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IHRyYW5zYWN0aW9uc1RhYmxlPy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT17dHJhbnNhY3Rpb25zVGFibGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e1RyYW5zYWN0aW9uc0NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT17YFRyYW5zYWN0aW9ucyBSZXBvcnRgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgVHJhbnNhY3Rpb25zIFJlcG9ydC5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNDAgIHctZnVsbCBmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vIFRyYW5zYWN0aW9ucyBGb3VuZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVRhYiA9PT0gXCJ0cmFuc2Zlckhpc3RvcnlcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJtYi0xIHRleHQtc20gdGV4dC1ncmF5LTcwMCBmb250LWJvbGQgcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgR3JvdXAgQ2hhbmdlIEhpc3RvcnlcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt0cmFuc2Zlckhpc3RvcnlMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogdHJhbnNmZXJIaXN0b3J5Py5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT17dHJhbnNmZXJIaXN0b3J5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtUcmFuc2Zlckhpc3RvcnlDb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJDdXN0b21lciBHcm91cCBDaGFuZ2UgSGlzdG9yeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJDdXN0b21lciBHcm91cCBDaGFuZ2UgSGlzdG9yeS5jc3ZcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmludEhlYWRlcktleXM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIkN1c3RvbWVyIE5hbWVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlBob25lIE51bWJlclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmludEhlYWRlclZhbHVlcz17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwPy5mdWxsX25hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXA/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQwIHctZnVsbCBmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgTm8gR3JvdXAgQ2hhbmdlIEhpc3RvcnkgRm91bmRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwicGVuYWx0eVwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWdyYXktNzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEV4Y2xhbWF0aW9uQ2lyY2xlT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQZW5hbHR5IERldGFpbHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTEgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyb3VwcyBhbmQgVGlja2V0c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVucm9sbEdyb3VwSWQuZ3JvdXBJZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBgJHtFbnJvbGxHcm91cElkLmdyb3VwSWR9fCR7RW5yb2xsR3JvdXBJZC50aWNrZXR9YFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUVucm9sbEdyb3VwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcHgtNiBweS0yIHNoYWRvdy1zbSBvdXRsaW5lLW5vbmUgdy1mdWxsIG1heC13LW1kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBHcm91cCB8IFRpY2tldDwvb3B0aW9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEFjdGl2ZSBDaGl0IEdyb3VwcyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkRW5yb2xsbWVudHM/Lm1hcCgoZW5yb2xsbWVudCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVucm9sbG1lbnQ/Lmdyb3VwX2lkICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBbXCJBY3RpdmVcIiwgXCJPbiBIb2xkXCJdLmluY2x1ZGVzKGVucm9sbG1lbnQ/LmN1c3RvbWVyX3N0YXR1cylcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2Vucm9sbG1lbnQ/Ll9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YCR7ZW5yb2xsbWVudD8uZ3JvdXBfaWQ/Ll9pZH18JHtlbnJvbGxtZW50Py50aWNrZXRzfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZW5yb2xsbWVudD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCJOL0FcIn0gfHtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZW5yb2xsbWVudD8udGlja2V0cyB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBMb2FuIE9wdGlvbnMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtBcnJheS5pc0FycmF5KGxvYW5DdXN0b21lcnM/Lm92ZXJhbGxfbG9hbikgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2FuQ3VzdG9tZXJzLm92ZXJhbGxfbG9hbi5tYXAoKGxvYW4sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17bG9hbj8ubG9hbl9kZXRhaWxzPy5sb2FuPy5faWQgfHwgaW5kZXh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtgTG9hbnwke2xvYW4/LmxvYW5fZGV0YWlscz8ubG9hbj8uX2lkIHx8IGluZGV4fWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsb2FuPy5sb2FuX2RldGFpbHM/LmxvYW4/LmxvYW5faWQgfHwgXCJOL0FcIn0gfCDigrlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2xvYW4/LmxvYW5fdmFsdWUgfHwgMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFBpZ21lIE9wdGlvbnMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtBcnJheS5pc0FycmF5KHBpZ21lQ3VzdG9tZXJzPy5vdmVyYWxsX3BpZ21lKSAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBpZ21lQ3VzdG9tZXJzLm92ZXJhbGxfcGlnbWUubWFwKChwaWdtZSwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtwaWdtZT8ucGlnbWVfZGV0YWlscz8ucGlnbWU/Ll9pZCB8fCBpbmRleH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2BQaWdtZXwke3BpZ21lPy5waWdtZV9kZXRhaWxzPy5waWdtZT8uX2lkIHx8IGluZGV4fWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwaWdtZT8ucGlnbWVfZGV0YWlscz8ucGlnbWU/LnBpZ21lX2lkIHx8IFwiTi9BXCJ9IHwg4oK5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwaWdtZT8udG90YWxfZGVwb3NpdGVkX2Ftb3VudCB8fCAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogU2hvdyBtZXNzYWdlIGlmIG5vIGdyb3VwL3RpY2tldCBzZWxlY3RlZCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgeyFFbnJvbGxHcm91cElkLmdyb3VwSWQgfHwgIUVucm9sbEdyb3VwSWQudGlja2V0ID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yMCB3LWZ1bGwgZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RXhjbGFtYXRpb25DaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LTZ4bCB0ZXh0LWdyYXktMzAwIG14LWF1dG8gbWItNFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQbGVhc2Ugc2VsZWN0IGEgR3JvdXAgYW5kIFRpY2tldFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTQwMCBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2hvb3NlIGEgZ3JvdXAgYW5kIHRpY2tldCBmcm9tIHRoZSBkcm9wZG93blxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFib3ZlIHRvIHZpZXcgcGVuYWx0eSBkZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogcGVuYWx0eUxvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBweS0yMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiBmb3JtYXR0ZWRDdXN0b21lclBlbmFsdHlEYXRhLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogU3VtbWFyeSBDYXJkcyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiBncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy00IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcmVkLTUwIHAtNCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItcmVkLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBQZW5hbHR5IEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdFBlbmFsdHlBbW91bnQoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlbmFsdHlEYXRhLnJlZHVjZShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoc3VtLCBwKSA9PiBzdW0gKyAocC50b3RhbFBlbmFsdHkgfHwgMCksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLW9yYW5nZS01MCBwLTQgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLW9yYW5nZS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgTGF0ZSBGZWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LW9yYW5nZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRQZW5hbHR5QW1vdW50KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZW5hbHR5RGF0YS5yZWR1Y2UoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKHN1bSwgcCkgPT4gc3VtICsgKHAudG90YWxMYXRlRmVlIHx8IDApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1wdXJwbGUtNTAgcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1wdXJwbGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIFZDIFBlbmFsdHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXB1cnBsZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRQZW5hbHR5QW1vdW50KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZW5hbHR5RGF0YS5yZWR1Y2UoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKHN1bSwgcCkgPT4gc3VtICsgKHAudmNQZW5hbHR5IHx8IDApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ibHVlLTUwIHAtNCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYmx1ZS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgT3V0c3RhbmRpbmdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWJsdWUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0UGVuYWx0eUFtb3VudChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGVuYWx0eURhdGEucmVkdWNlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChzdW0sIHApID0+IHN1bSArIChwLmdyYW5kVG90YWxEdWUgfHwgMCksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFBlbmFsdHkgVGFibGUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE9e2Zvcm1hdHRlZEN1c3RvbWVyUGVuYWx0eURhdGF9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e1BlbmFsdHlDb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9e2BDdXN0b21lcl9QZW5hbHR5X1JlcG9ydGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BDdXN0b21lcl9QZW5hbHR5X1JlcG9ydC5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmludEhlYWRlcktleXM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIkN1c3RvbWVyIE5hbWVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlBob25lIE51bWJlclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiR3JvdXAgTmFtZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiVGlja2V0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXA/LmZ1bGxfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cD8ucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVucm9sbEdyb3VwSWQuZ3JvdXBJZCAhPT0gXCJMb2FuXCIgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVucm9sbEdyb3VwSWQuZ3JvdXBJZCAhPT0gXCJQaWdtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGdyb3VwRGV0YWlscz8uZ3JvdXBfbmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBFbnJvbGxHcm91cElkLmdyb3VwSWQgPT09IFwiTG9hblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJMb2FuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlBpZ21lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRW5yb2xsR3JvdXBJZC50aWNrZXQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yMCB3LWZ1bGwgZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RXhjbGFtYXRpb25DaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LTZ4bCB0ZXh0LWdyYXktMzAwIG14LWF1dG8gbWItNFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBObyBwZW5hbHR5IHJlY29yZHMgZm91bmRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS00MDAgbXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vIHBlbmFsdGllcyBvciBsYXRlIGZlZXMgZm91bmQgZm9yIHRoaXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cC90aWNrZXQgY29tYmluYXRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwiYmlkcmVxdWVzdFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC1sZyBmb250LWJvbGQgdGV4dC1ncmF5LTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxNZEdhdmVsIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEJpZCBSZXF1ZXN0cyBIaXN0b3J5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7YmlkUmVxdWVzdHNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgcHktMjBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogYmlkUmVxdWVzdHNEYXRhICYmIGJpZFJlcXVlc3RzRGF0YS5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFN1bW1hcnkgQ2FyZHMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtNSBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtNTAgcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ibHVlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBSZXF1ZXN0c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtYmx1ZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtiaWRSZXF1ZXN0c0RhdGEubGVuZ3RofVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy15ZWxsb3ctNTAgcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci15ZWxsb3ctMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBlbmRpbmdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXllbGxvdy02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmlkUmVxdWVzdHNEYXRhLmZpbHRlcihcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAocikgPT4gci5zdGF0dXMgPT09IFwiUGVuZGluZ1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApLmxlbmd0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmVlbi01MCBwLTQgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyZWVuLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBY2NlcHRlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JlZW4tNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJpZFJlcXVlc3RzRGF0YS5maWx0ZXIoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKHIpID0+IHIuc3RhdHVzID09PSBcIkFjY2VwdFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApLmxlbmd0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1yZWQtNTAgcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1yZWQtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIERlY2xpbmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJpZFJlcXVlc3RzRGF0YS5maWx0ZXIoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKHIpID0+IHIuc3RhdHVzID09PSBcIkRlY2xpbmVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKS5sZW5ndGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcHVycGxlLTUwIHAtNCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItcHVycGxlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQcml6ZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXB1cnBsZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmlkUmVxdWVzdHNEYXRhLmZpbHRlcihcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAocikgPT4gci5zdGF0dXMgPT09IFwiUHJpemVkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkubGVuZ3RoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEJpZCBSZXF1ZXN0cyBUYWJsZSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTTC4gTk9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJpZCBSZXF1ZXN0IENvZGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJlcXVlc3QgRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgR3JvdXAgTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGlja2V0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBdWN0aW9uIERhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEF1Y3Rpb24gVGltZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQmFsYW5jZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU3RhdHVzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBY3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2JpZFJlcXVlc3RzRGF0YS5tYXAoKGJpZFJlcXVlc3QsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0clxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17YmlkUmVxdWVzdC5faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaG92ZXI6YmctZ3JheS01MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtc20gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2luZGV4ICsgMX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWJsdWUtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YmlkUmVxdWVzdC5iaWRfcmVxdWVzdF9jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LXNtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtiaWRSZXF1ZXN0LnJlcXVlc3RfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1zbSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YmlkUmVxdWVzdC5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LXNtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtiaWRSZXF1ZXN0LnRpY2tldF9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtc20gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2JpZFJlcXVlc3QuYXVjdGlvbl9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LXNtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtiaWRSZXF1ZXN0LmF1Y3Rpb25fdGltZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0zIHRleHQtc20gZm9udC1tZWRpdW0gJHtiaWRSZXF1ZXN0LmJhbGFuY2UgPD0gMCA/IFwidGV4dC1ncmVlbi02MDBcIiA6IFwidGV4dC1yZWQtNjAwXCJ9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YmlkUmVxdWVzdC5iYWxhbmNlX2Rpc3BsYXl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LW1lZGl1bSBcclxuICAgICAgICAgICAgICAgICAgICAgICR7YmlkUmVxdWVzdC5zdGF0dXNfY29sb3IgPT09IFwib3JhbmdlXCIgPyBcImJnLXllbGxvdy0xMDAgdGV4dC15ZWxsb3ctODAwXCIgOiBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgJHtiaWRSZXF1ZXN0LnN0YXR1c19jb2xvciA9PT0gXCJncmVlblwiID8gXCJiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDBcIiA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAke2JpZFJlcXVlc3Quc3RhdHVzX2NvbG9yID09PSBcInJlZFwiID8gXCJiZy1yZWQtMTAwIHRleHQtcmVkLTgwMFwiIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICR7YmlkUmVxdWVzdC5zdGF0dXNfY29sb3IgPT09IFwiYmx1ZVwiID8gXCJiZy1ibHVlLTEwMCB0ZXh0LWJsdWUtODAwXCIgOiBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgJHtiaWRSZXF1ZXN0LnN0YXR1c19jb2xvciA9PT0gXCJwdXJwbGVcIiA/IFwiYmctcHVycGxlLTEwMCB0ZXh0LXB1cnBsZS04MDBcIiA6IFwiXCJ9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2JpZFJlcXVlc3Quc3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dCaWRSZXF1ZXN0RGV0YWlscyhiaWRSZXF1ZXN0KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgaG92ZXI6dGV4dC1ibHVlLTgwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhRXllIHNpemU9ezE0fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBWaWV3IERldGFpbHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIwIHctZnVsbCBmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNZEdhdmVsIGNsYXNzTmFtZT1cInRleHQtNnhsIHRleHQtZ3JheS0zMDAgbXgtYXV0byBtYi00XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vIGJpZCByZXF1ZXN0cyBmb3VuZCBmb3IgdGhpcyBjdXN0b21lclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTQwMCBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGhlIGN1c3RvbWVyIGhhcyBub3QgcmFpc2VkIGFueSBiaWQgcmVxdWVzdHMgeWV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge2FjdGl2ZVRhYiA9PT0gXCJ2aXNpdG9yXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwibWItNCB0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWdyYXktNzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPE1kUGVvcGxlIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFZpc2l0b3IgUmVjb3Jkc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3Zpc2l0b3JMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgcHktMjBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogdmlzaXRvckRhdGEgJiYgdmlzaXRvckRhdGEubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBTdW1tYXJ5IENhcmRzICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02IGdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ibHVlLTUwIHAtNCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYmx1ZS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgVmlzaXRzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ibHVlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Zpc2l0b3JEYXRhLmxlbmd0aH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JlZW4tNTAgcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmVlbi0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ29tcGxldGVkIFZpc2l0c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JlZW4tNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZpc2l0b3JEYXRhLmZpbHRlcihcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAodikgPT4gdi5zdGF0dXMgPT09IFwiQ29tcGxldGVkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkubGVuZ3RoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXB1cnBsZS01MCBwLTQgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXB1cnBsZS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUHVycG9zZSAtIERvY3VtZW50IFNpZ25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXB1cnBsZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmlzaXRvckRhdGEuZmlsdGVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICh2KSA9PiB2LnB1cnBvc2UgPT09IFwiRG9jdW1lbnQgU2lnblwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApLmxlbmd0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy15ZWxsb3ctNTAgcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci15ZWxsb3ctMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFB1cnBvc2UgLSBBdWN0aW9uIEJpZGRpbmdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXllbGxvdy02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmlzaXRvckRhdGEuZmlsdGVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICh2KSA9PiB2LnB1cnBvc2UgPT09IFwiQXVjdGlvbiBCaWRkaW5nXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkubGVuZ3RoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFZpc2l0b3IgVGFibGUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7VmlzaXRvckNvbHVtbnMubWFwKChjb2wpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17Y29sLmtleX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBib3JkZXItYlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NvbC5oZWFkZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYm9yZGVyLWJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBY3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Zpc2l0b3JEYXRhLm1hcCgodmlzaXRvciwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXt2aXNpdG9yLl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJob3ZlcjpiZy1ncmF5LTUwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1zbSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aW5kZXggKyAxfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtYmx1ZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt2aXNpdG9yLnZpc2l0b3JfY29kZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtc20gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Zpc2l0b3IubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1zbSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmlzaXRvci5waG9uZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmlzaXRvci5lbWFpbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtbWVkaXVtIGJnLWJsdWUtMTAwIHRleHQtYmx1ZS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Zpc2l0b3IucHVycG9zZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1zbSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmlzaXRvci5mb3JtYXR0ZWRfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1zbSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dmlzaXRvci5tZWV0X3BlcnNvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtbWVkaXVtIFxyXG4gICAgICAgICAgICAgICAgICAgICAgJHt2aXNpdG9yLnN0YXR1cyA9PT0gXCJDb21wbGV0ZWRcIiA/IFwiYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwXCIgOiBcImJnLXllbGxvdy0xMDAgdGV4dC15ZWxsb3ctODAwXCJ9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Zpc2l0b3Iuc3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dWaXNpdG9yRGV0YWlscyh2aXNpdG9yKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgaG92ZXI6dGV4dC1ibHVlLTgwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhRXllIHNpemU9ezE0fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBWaWV3IERldGFpbHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Zpc2l0b3JEYXRhLnNvbWUoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICh2KSA9PiB2LmRlc2NyaXB0aW9uICYmIHYuZGVzY3JpcHRpb24gIT09IFwiLVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHRleHQtc20gdGV4dC1ncmF5LTUwMCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2xpY2sgXCJWaWV3IERldGFpbHNcIiB0byBzZWUgY29tcGxldGUgdmlzaXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZm9ybWF0aW9uIGFuZCBkZXNjcmlwdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yMCB3LWZ1bGwgZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWRQZW9wbGUgY2xhc3NOYW1lPVwidGV4dC02eGwgdGV4dC1ncmF5LTMwMCBteC1hdXRvIG1iLTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTm8gdmlzaXRvciByZWNvcmRzIGZvdW5kIGZvciB0aGlzIGN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNDAwIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUaGUgY3VzdG9tZXIgaGFzIG5vdCB2aXNpdGVkIG9yIG5vIHZpc2l0IHJlY29yZHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleGlzdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8TW9kYWxcclxuICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCBiZy1ibHVlLTEwMCByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgPEV5ZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgdGV4dC1sZ1wiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZFwiPlBlbmFsdHkgQnJlYWtkb3duPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBmb250LW5vcm1hbCBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgIEN5Y2xlLXdpc2UgcGVuYWx0eSBhbmQgcGF5bWVudCBkZXRhaWxzXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIH1cclxuICAgICAgICBvcGVuPXticmVha2Rvd25Nb2RhbFZpc2libGV9XHJcbiAgICAgICAgb25DYW5jZWw9eygpID0+IHtcclxuICAgICAgICAgIHNldEJyZWFrZG93bk1vZGFsVmlzaWJsZShmYWxzZSk7XHJcbiAgICAgICAgICBzZXRTZWxlY3RlZFBlbmFsdHkobnVsbCk7XHJcbiAgICAgICAgfX1cclxuICAgICAgICB3aWR0aD17MTAwMH1cclxuICAgICAgICBmb290ZXI9e1tcclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAga2V5PVwiY2xvc2VcIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0QnJlYWtkb3duTW9kYWxWaXNpYmxlKGZhbHNlKTtcclxuICAgICAgICAgICAgICBzZXRTZWxlY3RlZFBlbmFsdHkobnVsbCk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIENsb3NlXHJcbiAgICAgICAgICA8L0J1dHRvbj4sXHJcbiAgICAgICAgXX1cclxuICAgICAgPlxyXG4gICAgICAgIHtzZWxlY3RlZFBlbmFsdHkgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgICAgICAgey8qIFN1bW1hcnkgQ2FyZHMgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtNCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctb3JhbmdlLTUwIHJvdW5kZWQtbGcgcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHVwcGVyY2FzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgR3JvdXAgJiBUaWNrZXRcclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRQZW5hbHR5Lmdyb3VwTmFtZX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVGlja2V0OiB7c2VsZWN0ZWRQZW5hbHR5LnRpY2tldH1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXJlZC01MCByb3VuZGVkLWxnIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB1cHBlcmNhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFRvdGFsIFBlbmFsdHlcclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICB7Zm9ybWF0UGVuYWx0eUFtb3VudChzZWxlY3RlZFBlbmFsdHkudG90YWxQZW5hbHR5KX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmcteWVsbG93LTUwIHJvdW5kZWQtbGcgcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHVwcGVyY2FzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVG90YWwgTGF0ZSBGZWVcclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQteWVsbG93LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICB7Zm9ybWF0UGVuYWx0eUFtb3VudChzZWxlY3RlZFBlbmFsdHkudG90YWxMYXRlRmVlKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcHVycGxlLTUwIHJvdW5kZWQtbGcgcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHVwcGVyY2FzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgR3JhbmQgVG90YWwgRHVlXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXB1cnBsZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAge2Zvcm1hdFBlbmFsdHlBbW91bnQoc2VsZWN0ZWRQZW5hbHR5LmdyYW5kVG90YWxEdWUpfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIEN5Y2xlcyBUYWJsZSAqL31cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgIEN5Y2xlLXdpc2UgUGVuYWx0eSBCcmVha2Rvd25cclxuICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgIHtmb3JtYXR0ZWRQZW5hbHR5Q3ljbGVzLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICA8QW50VGFibGVcclxuICAgICAgICAgICAgICAgICAgY29sdW1ucz17UGVuYWx0eUJyZWFrZG93bkNvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U9e2Zvcm1hdHRlZFBlbmFsdHlDeWNsZXN9XHJcbiAgICAgICAgICAgICAgICAgIHBhZ2luYXRpb249e3sgcGFnZVNpemU6IDEwIH19XHJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJtaWRkbGVcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS04IGJnLWdyYXktNTAgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCI+Tm8gY3ljbGUgZGF0YSBhdmFpbGFibGU8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICA8TW9kYWxcclxuICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxNZEdhdmVsIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIiAvPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGRcIj5CaWQgUmVxdWVzdCBEZXRhaWxzPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG9wZW49e2JpZFJlcXVlc3RNb2RhbFZpc2libGV9XHJcbiAgICAgICAgb25DYW5jZWw9eygpID0+IHNldEJpZFJlcXVlc3RNb2RhbFZpc2libGUoZmFsc2UpfVxyXG4gICAgICAgIGZvb3Rlcj17W1xyXG4gICAgICAgICAgPEJ1dHRvbiBrZXk9XCJjbG9zZVwiIG9uQ2xpY2s9eygpID0+IHNldEJpZFJlcXVlc3RNb2RhbFZpc2libGUoZmFsc2UpfT5cclxuICAgICAgICAgICAgQ2xvc2VcclxuICAgICAgICAgIDwvQnV0dG9uPixcclxuICAgICAgICBdfVxyXG4gICAgICAgIHdpZHRoPXs3MDB9XHJcbiAgICAgICAgYm9keVN0eWxlPXt7IHBhZGRpbmc6IFwiMjBweFwiIH19XHJcbiAgICAgID5cclxuICAgICAgICB7c2VsZWN0ZWRCaWRSZXF1ZXN0ICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIHBiLTJcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICBCaWQgUmVxdWVzdCBDb2RlXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWRCaWRSZXF1ZXN0LmJpZF9yZXF1ZXN0X2NvZGV9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBwYi0yXCI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPkdyb3VwIE5hbWU8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZEJpZFJlcXVlc3QuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIHBiLTJcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+VGlja2V0IE51bWJlcjwvcD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAge3NlbGVjdGVkQmlkUmVxdWVzdC50aWNrZXRfbnVtYmVyfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgcGItMlwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5SZXF1ZXN0IERhdGU8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZEJpZFJlcXVlc3QucmVxdWVzdF9kYXRlfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgcGItMlwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5BdWN0aW9uIERhdGU8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZEJpZFJlcXVlc3QuYXVjdGlvbl9kYXRlfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgcGItMlwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5BdWN0aW9uIFRpbWU8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZEJpZFJlcXVlc3QuYXVjdGlvbl90aW1lfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgcGItMlwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5DdXJyZW50IEJhbGFuY2U8L3A+XHJcbiAgICAgICAgICAgICAgPHBcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQtc20gZm9udC1zZW1pYm9sZCAke3NlbGVjdGVkQmlkUmVxdWVzdC5iYWxhbmNlIDw9IDAgPyBcInRleHQtZ3JlZW4tNjAwXCIgOiBcInRleHQtcmVkLTYwMFwifWB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3NlbGVjdGVkQmlkUmVxdWVzdC5iYWxhbmNlX2Rpc3BsYXl9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBwYi0yXCI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPlN0YXR1czwvcD5cclxuICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1tZWRpdW0gXHJcbiAgICAgICAgICAke3NlbGVjdGVkQmlkUmVxdWVzdC5zdGF0dXNfY29sb3IgPT09IFwib3JhbmdlXCIgPyBcImJnLXllbGxvdy0xMDAgdGV4dC15ZWxsb3ctODAwXCIgOiBcIlwifVxyXG4gICAgICAgICAgJHtzZWxlY3RlZEJpZFJlcXVlc3Quc3RhdHVzX2NvbG9yID09PSBcImdyZWVuXCIgPyBcImJnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTgwMFwiIDogXCJcIn1cclxuICAgICAgICAgICR7c2VsZWN0ZWRCaWRSZXF1ZXN0LnN0YXR1c19jb2xvciA9PT0gXCJyZWRcIiA/IFwiYmctcmVkLTEwMCB0ZXh0LXJlZC04MDBcIiA6IFwiXCJ9XHJcbiAgICAgICAgICAke3NlbGVjdGVkQmlkUmVxdWVzdC5zdGF0dXNfY29sb3IgPT09IFwiYmx1ZVwiID8gXCJiZy1ibHVlLTEwMCB0ZXh0LWJsdWUtODAwXCIgOiBcIlwifVxyXG4gICAgICAgICAgJHtzZWxlY3RlZEJpZFJlcXVlc3Quc3RhdHVzX2NvbG9yID09PSBcInB1cnBsZVwiID8gXCJiZy1wdXJwbGUtMTAwIHRleHQtcHVycGxlLTgwMFwiIDogXCJcIn1gfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZEJpZFJlcXVlc3Quc3RhdHVzfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgcGItMlwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5SZWZlcnJlZCBCeTwvcD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAge3NlbGVjdGVkQmlkUmVxdWVzdC5yZWZlcnJlZF9ieX1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIHBiLTJcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICBDcmVhdGVkIEJ5IChBZG1pbilcclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZEJpZFJlcXVlc3QuYWRtaW5fdXNlcn1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIHBiLTJcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+QXVjdGlvbiBDeWNsZTwvcD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAge3NlbGVjdGVkQmlkUmVxdWVzdC5hdWN0aW9uX2N5Y2xlfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgPE1vZGFsXHJcbiAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8TWRQZW9wbGUgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZFwiPlZpc2l0b3IgRGV0YWlsczwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIH1cclxuICAgICAgICBvcGVuPXt2aXNpdG9yTW9kYWxWaXNpYmxlfVxyXG4gICAgICAgIG9uQ2FuY2VsPXsoKSA9PiBzZXRWaXNpdG9yTW9kYWxWaXNpYmxlKGZhbHNlKX1cclxuICAgICAgICBmb290ZXI9e1tcclxuICAgICAgICAgIDxCdXR0b24ga2V5PVwiY2xvc2VcIiBvbkNsaWNrPXsoKSA9PiBzZXRWaXNpdG9yTW9kYWxWaXNpYmxlKGZhbHNlKX0+XHJcbiAgICAgICAgICAgIENsb3NlXHJcbiAgICAgICAgICA8L0J1dHRvbj4sXHJcbiAgICAgICAgXX1cclxuICAgICAgICB3aWR0aD17NzAwfVxyXG4gICAgICAgIGJvZHlTdHlsZT17eyBwYWRkaW5nOiBcIjIwcHhcIiB9fVxyXG4gICAgICA+XHJcbiAgICAgICAge3NlbGVjdGVkVmlzaXRvciAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBwYi0yXCI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPlZpc2l0b3IgQ29kZTwvcD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAge3NlbGVjdGVkVmlzaXRvci52aXNpdG9yX2NvZGV9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBwYi0yXCI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPlZpc2l0b3IgSUQ8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZFZpc2l0b3IudmlzaXRvcklkfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgcGItMlwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5WaXNpdG9yIE5hbWU8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZFZpc2l0b3IubmFtZX1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIHBiLTJcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+UGhvbmUgTnVtYmVyPC9wPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWRWaXNpdG9yLnBob25lfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgcGItMlwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5FbWFpbDwvcD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAge3NlbGVjdGVkVmlzaXRvci5lbWFpbH1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIHBiLTJcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+UHVycG9zZTwvcD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAge3NlbGVjdGVkVmlzaXRvci5wdXJwb3NlfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgcGItMlwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgIFZpc2l0IERhdGUgJiBUaW1lXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICB7c2VsZWN0ZWRWaXNpdG9yLmZvcm1hdHRlZF9kYXRlfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgcGItMlwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5XaG9tIHRvIE1lZXQ8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZFZpc2l0b3IubWVldF9wZXJzb259XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBwYi0yIGNvbC1zcGFuLTJcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+RGVzY3JpcHRpb248L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZFZpc2l0b3IuZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItYiBwYi0yXCI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPkdyb3VwIE5hbWU8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZFZpc2l0b3IuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iIHBiLTJcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+VGlja2V0IE51bWJlcjwvcD5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAge3NlbGVjdGVkVmlzaXRvci50aWNrZXRfbnVtYmVyfVxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLWIgcGItMlwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5TdGF0dXM8L3A+XHJcbiAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtbWVkaXVtIFxyXG4gICAgICAgICAgJHtzZWxlY3RlZFZpc2l0b3Iuc3RhdHVzID09PSBcIkNvbXBsZXRlZFwiID8gXCJiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDBcIiA6IFwiYmcteWVsbG93LTEwMCB0ZXh0LXllbGxvdy04MDBcIn1gfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZFZpc2l0b3Iuc3RhdHVzfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L01vZGFsPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFVzZXJSZXBvcnQ7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9Vc2VyUmVwb3J0LmpzeCJ9