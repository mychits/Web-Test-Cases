import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layouts/Sidebar.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const Fragment2 = __vite__cjsImport3_react["Fragment"]; const cloneElement = __vite__cjsImport3_react["cloneElement"]; const isValidElement = __vite__cjsImport3_react["isValidElement"]; const useCallback = __vite__cjsImport3_react["useCallback"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { ChevronLeft, ChevronRight } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import sidebarMenu from "/src/data/sidebarMenu.js";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { NavLink, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { TbArrowsLeftDown } from "/node_modules/.vite/deps/react-icons_tb.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
const sidebarAccentClasses = [
  "bg-blue-50 text-blue-700 border-blue-100/80",
  "bg-indigo-50 text-indigo-700 border-indigo-100/80",
  "bg-emerald-50 text-emerald-700 border-emerald-100/80",
  "bg-amber-50 text-amber-700 border-amber-100/80",
  "bg-sky-50 text-sky-700 border-sky-100/80",
  "bg-violet-50 text-violet-700 border-violet-100/80",
  "bg-rose-50 text-rose-700 border-rose-100/80",
  "bg-teal-50 text-teal-700 border-teal-100/80",
  "bg-slate-100 text-slate-700 border-slate-200/80"
];
const getSidebarAccentClass = (key = "") => {
  const text = String(key);
  const hash = [...text].reduce((sum, char) => sum + char.charCodeAt(0), 0);
  return sidebarAccentClasses[hash % sidebarAccentClasses.length];
};
const Sidebar = ({
  navSearchBarVisibility = false,
  navbarVisibility = true,
  onGlobalSearchChangeHandler = () => {
  },
  showMobileSidebar = false,
  setShowMobileSidebar = () => {
  },
  hideSidebar = false
}) => {
  _s();
  const [open, setOpen] = useState(true);
  const [showArrowLeft, setShowArrowLeft] = useState(false);
  const [submenuOpenIndex, setSubmenuOpenIndex] = useState(null);
  const [nestedSubmenuOpenIndex, setNestedSubmenuOpenIndex] = useState({});
  const [pendingCounts, setPendingCounts] = useState(0);
  const location = useLocation();
  const [isVisible, setIsVisible] = useState(false);
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  useEffect(() => {
    if (hideSidebar) {
      setOpen(false);
    }
  }, [hideSidebar]);
  useEffect(() => {
    const handleScroll = () => {
      setIsVisible(window.scrollY > 300);
    };
    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);
  useEffect(() => {
    const fetchPendingCounts = async () => {
      try {
        const res = await api.get("/other-services/daily/counts");
        const total = res.data?.data?.total ?? res.data?.total ?? 0;
        setPendingCounts(total);
      } catch (error) {
        console.error("Error fetching pending counts:", error);
      }
    };
    if (location.pathname.startsWith("/approval-menu")) {
      fetchPendingCounts();
    }
  }, [location.pathname]);
  const toggleSubMenu = (index) => {
    setSubmenuOpenIndex(submenuOpenIndex === index ? null : index);
  };
  const toggleNestedSubMenu = (submenuIndex, subIndex) => {
    setNestedSubmenuOpenIndex((prevState) => ({
      ...prevState,
      [submenuIndex]: prevState[submenuIndex] === subIndex ? null : subIndex
    }));
  };
  const isRouteActive = useCallback((link) => {
    if (!link || link === "#") return false;
    if (/^https?:\/\//.test(link)) return false;
    const normalizedLink = link.endsWith("/") && link.length > 1 ? link.slice(0, -1) : link;
    const normalizedPath = location.pathname.endsWith("/") && location.pathname.length > 1 ? location.pathname.slice(0, -1) : location.pathname;
    return normalizedPath === normalizedLink || normalizedPath.startsWith(`${normalizedLink}/`);
  }, [location.pathname]);
  const isMenuActive = useCallback((menu) => {
    if (isRouteActive(menu.link)) return true;
    return menu.submenuItems?.some((submenuItem) => {
      if (isRouteActive(submenuItem.link)) return true;
      return submenuItem.submenuItems?.some((subSubItem) => isRouteActive(subSubItem.link));
    });
  }, [isRouteActive]);
  useEffect(() => {
    const activeMenuIndex = sidebarMenu.findIndex(isMenuActive);
    if (activeMenuIndex === -1) return;
    const activeMenu = sidebarMenu[activeMenuIndex];
    if (activeMenu?.submenu) {
      setSubmenuOpenIndex(activeMenuIndex);
    }
    const activeSubmenuIndex = activeMenu?.submenuItems?.findIndex((submenuItem) => {
      if (isRouteActive(submenuItem.link)) return true;
      return submenuItem.submenuItems?.some((subSubItem) => isRouteActive(subSubItem.link));
    });
    if (activeSubmenuIndex >= 0 && activeMenu?.submenuItems?.[activeSubmenuIndex]?.submenu) {
      setNestedSubmenuOpenIndex((prevState) => ({
        ...prevState,
        [activeMenuIndex]: activeSubmenuIndex
      }));
    }
  }, [isMenuActive, isRouteActive, location.pathname]);
  const renderIcon = (Icon, className = "") => {
    if (!Icon) return null;
    if (isValidElement(Icon)) {
      return cloneElement(Icon, {
        className: `${Icon.props.className || ""} ${className}`.trim()
      });
    }
    const IconComponent = Icon;
    return /* @__PURE__ */ jsxDEV(IconComponent, { className }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
      lineNumber: 148,
      columnNumber: 12
    }, this);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        visibility: navSearchBarVisibility,
        onGlobalSearchChangeHandler,
        showMobileSidebar,
        setShowMobileSidebar
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
        lineNumber: 153,
        columnNumber: 7
      },
      this
    ),
    navbarVisibility && /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: `hidden shrink-0 transition-all duration-300 md:block ${open ? "w-64" : "w-20"}`
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
          lineNumber: 161,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: `sidebar-scrollbar fixed left-0 top-[68px] z-40 h-[calc(100vh-68px)] shrink-0 overflow-y-auto overflow-x-hidden border-r border-slate-200/70 bg-white/80 shadow-[1px_0_18px_rgba(15,23,42,0.05)] backdrop-blur-2xl transition-all duration-300 ${open ? "w-64" : "w-20"} ${showMobileSidebar ? "translate-x-0" : "-translate-x-full md:translate-x-0"}`,
          onMouseEnter: () => setShowArrowLeft(true),
          onMouseLeave: () => setShowArrowLeft(false),
          children: /* @__PURE__ */ jsxDEV("ul", { className: "space-y-2 px-3 pb-5 pt-3", children: sidebarMenu.map((menu, index) => {
            const isOpen = submenuOpenIndex === index;
            const menuIsActive = isMenuActive(menu);
            const menuLinkIsActive = isRouteActive(menu.link);
            const isActiveMenu = menuLinkIsActive && !menu.submenu || menuIsActive;
            return /* @__PURE__ */ jsxDEV(Fragment2, { children: [
              /* @__PURE__ */ jsxDEV(
                NavLink,
                {
                  to: menu.link || "#",
                  end: true,
                  onClick: (e) => {
                    if (menu.submenu) {
                      e.preventDefault();
                      toggleSubMenu(index);
                    } else {
                      scrollToTop();
                    }
                  },
                  className: ({ isActive }) => `group relative flex items-center border transition-all duration-200 ${open ? "min-h-[54px] w-full gap-x-3 rounded-xl px-2 py-1.5" : "mx-auto h-12 w-12 justify-center rounded-2xl p-0"} ${isActive && !menu.submenu || menuIsActive ? "border-indigo-100/80 bg-indigo-50/80 text-indigo-700 font-semibold shadow-sm shadow-indigo-900/[0.03]" : "border-transparent text-slate-600 hover:border-slate-200/70 hover:bg-white/70 hover:text-slate-950"} ${menu.spacing ? "mt-6" : ""}`,
                  children: [
                    isActiveMenu && open && /* @__PURE__ */ jsxDEV("span", { className: "absolute left-1 top-1/2 h-5 w-1 -translate-y-1/2 rounded-full bg-[#0071e3]/70" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
                      lineNumber: 235,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: `grid h-9 w-9 shrink-0 place-items-center rounded-xl border transition duration-200 ${getSidebarAccentClass(menu.title)} ${isActiveMenu ? "ring-2 ring-[#0071e3]/15" : "group-hover:scale-[1.03]"}`, children: renderIcon(menu.icon, "h-[18px] w-[18px]") }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
                      lineNumber: 237,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "span",
                      {
                        className: `text-sm font-semibold flex-1 truncate ${!open && "hidden"}`,
                        children: [
                          menu.title,
                          menu.pendingNotification === true && pendingCounts > 0 && /* @__PURE__ */ jsxDEV("span", { className: "ml-3 rounded-full bg-[#0071e3] px-2 py-0.5 text-[11px] font-semibold text-white shadow-sm shadow-blue-900/10", children: pendingCounts > 0 ? pendingCounts : "" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
                            lineNumber: 246,
                            columnNumber: 23
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
                        lineNumber: 240,
                        columnNumber: 21
                      },
                      this
                    ),
                    menu.submenu && open && /* @__PURE__ */ jsxDEV(
                      ChevronRight,
                      {
                        className: `ml-auto h-4 w-4 shrink-0 text-slate-400 transition-transform duration-200 ${isOpen ? "rotate-90 text-[#0071e3]" : ""}`,
                        strokeWidth: 1.8
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
                        lineNumber: 250,
                        columnNumber: 21
                      },
                      this
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
                  lineNumber: 214,
                  columnNumber: 19
                },
                this
              ),
              menu.submenu && isOpen && open && /* @__PURE__ */ jsxDEV("ul", { className: "ml-3 mt-1 space-y-1 border-l border-slate-200/70 pl-3 font-medium", children: menu.submenuItems.map((submenuItem, subIndex) => {
                const isNestedOpen = nestedSubmenuOpenIndex[index] === subIndex;
                return /* @__PURE__ */ jsxDEV(Fragment2, { children: [
                  /* @__PURE__ */ jsxDEV(
                    NavLink,
                    {
                      to: submenuItem.link || "#",
                      end: true,
                      target: submenuItem.newTab ? "_blank" : "_self",
                      onClick: (e) => {
                        if (submenuItem.submenu) {
                          e.preventDefault();
                          toggleNestedSubMenu(index, subIndex);
                        } else {
                          scrollToTop();
                        }
                      },
                      className: ({ isActive }) => `flex min-h-11 w-full items-center rounded-lg border px-2.5 py-2 text-sm transition-all duration-200 ${isActive || isRouteActive(submenuItem.link) || submenuItem.submenuItems?.some((item) => isRouteActive(item.link)) ? "border-indigo-100/80 bg-indigo-50/80 text-indigo-700 font-semibold shadow-sm shadow-indigo-900/[0.03]" : "border-transparent text-slate-600 hover:border-slate-200/70 hover:bg-white/70 hover:text-slate-950"}`,
                      children: [
                        submenuItem.icon && /* @__PURE__ */ jsxDEV("span", { className: `mr-2 grid h-8 w-8 shrink-0 place-items-center rounded-lg border ${getSidebarAccentClass(submenuItem.title)}`, children: renderIcon(submenuItem.icon, "h-4 w-4") }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
                          lineNumber: 288,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { className: "flex-1 truncate", children: submenuItem.title }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
                          lineNumber: 292,
                          columnNumber: 31
                        }, this),
                        submenuItem.submenu && /* @__PURE__ */ jsxDEV(
                          ChevronRight,
                          {
                            className: `ml-auto h-3.5 w-3.5 shrink-0 text-slate-400 transition-transform duration-200 ${isNestedOpen ? "rotate-90 text-[#0071e3]" : ""}`,
                            strokeWidth: 1.8
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
                            lineNumber: 294,
                            columnNumber: 29
                          },
                          this
                        )
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
                      lineNumber: 266,
                      columnNumber: 29
                    },
                    this
                  ),
                  submenuItem.submenu && isNestedOpen && /* @__PURE__ */ jsxDEV("ul", { className: "ml-4 mt-1 space-y-1 border-l border-slate-200/70 pl-3", children: submenuItem.submenuItems.map(
                    (subSubItem) => /* @__PURE__ */ jsxDEV(
                      NavLink,
                      {
                        to: subSubItem.link,
                        end: true,
                        onClick: () => {
                          scrollToTop();
                        },
                        className: ({ isActive }) => `flex min-h-10 w-full items-center rounded-lg border px-2.5 py-2 text-sm transition-all duration-200 ${isActive || isRouteActive(subSubItem.link) ? "border-indigo-100/80 bg-indigo-50/80 text-indigo-700 font-semibold shadow-sm shadow-indigo-900/[0.03]" : "border-transparent text-slate-500 hover:border-slate-200/70 hover:bg-white/70 hover:text-slate-950"}`,
                        children: [
                          subSubItem.icon && /* @__PURE__ */ jsxDEV("span", { className: `mr-2 grid h-7 w-7 shrink-0 place-items-center rounded-lg border ${getSidebarAccentClass(subSubItem.title)}`, children: renderIcon(subSubItem.icon, "h-3.5 w-3.5") }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
                            lineNumber: 321,
                            columnNumber: 31
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "truncate", children: subSubItem.title }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
                            lineNumber: 325,
                            columnNumber: 37
                          }, this)
                        ]
                      },
                      subSubItem.id,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
                        lineNumber: 305,
                        columnNumber: 29
                      },
                      this
                    )
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
                    lineNumber: 303,
                    columnNumber: 27
                  }, this)
                ] }, submenuItem.id, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
                  lineNumber: 265,
                  columnNumber: 25
                }, this);
              }) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
                lineNumber: 259,
                columnNumber: 19
              }, this)
            ] }, menu.id, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
              lineNumber: 213,
              columnNumber: 17
            }, this);
          }) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
            lineNumber: 173,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
          lineNumber: 166,
          columnNumber: 11
        },
        this
      ),
      showArrowLeft && /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          className: `fixed top-20 z-50 grid h-9 w-9 place-items-center rounded-full border border-slate-200/70 bg-white/85 text-slate-600 shadow-lg shadow-slate-900/10 backdrop-blur-xl transition-all duration-200 hover:bg-white hover:text-[#0071e3] focus:outline-none focus:ring-2 focus:ring-[#0071e3]/25 ${open ? "left-60" : "left-16 rotate-180"}`,
          onMouseEnter: () => setShowArrowLeft(true),
          onClick: () => setOpen(!open),
          "aria-label": open ? "Collapse sidebar" : "Expand sidebar",
          children: /* @__PURE__ */ jsxDEV(ChevronLeft, { className: "h-5 w-5", strokeWidth: 1.8 }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
            lineNumber: 353,
            columnNumber: 15
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
          lineNumber: 345,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
      lineNumber: 160,
      columnNumber: 7
    }, this),
    showMobileSidebar && /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: "fixed inset-0 z-30 bg-slate-900/20 backdrop-blur-[2px] md:hidden",
        onClick: () => setShowMobileSidebar(false)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
        lineNumber: 361,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: `fixed bottom-6 right-6 rounded-2xl border border-slate-200/70 bg-white/85 p-3 text-slate-700 shadow-lg shadow-slate-900/10 backdrop-blur-xl hover:bg-white hover:text-[#0071e3] active:scale-95 transition-all duration-300 cursor-pointer 
             z-[9999] ${isVisible ? "opacity-100" : "opacity-0 pointer-events-none"}`,
        onClick: scrollToTop,
        children: /* @__PURE__ */ jsxDEV(TbArrowsLeftDown, { className: "text-2xl rotate-90" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
          lineNumber: 373,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
        lineNumber: 368,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx",
    lineNumber: 152,
    columnNumber: 5
  }, this);
};
_s(Sidebar, "nx4ODs7VG9hnjmfq8xh0sAKoCkU=", false, function() {
  return [useLocation];
});
_c = Sidebar;
export default Sidebar;
var _c;
$RefreshReg$(_c, "Sidebar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/layouts/Sidebar.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUpXLFNBWUgsVUFaRzsyQkFuSlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQSxTQUFTQSx1QkFBVUMsY0FBY0MsZ0JBQWdCQyxhQUFhQyxXQUFXQyxnQkFBZ0I7QUFDekYsU0FBU0MsYUFBYUMsb0JBQW9CO0FBQzFDLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLFNBQVNDLG1CQUFtQjtBQUNyQyxTQUFTQyx3QkFBd0I7QUFDakMsT0FBT0MsU0FBUztBQUVoQixNQUFNQyx1QkFBdUI7QUFBQSxFQUMzQjtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQWlEO0FBR25ELE1BQU1DLHdCQUF3QkEsQ0FBQ0MsTUFBTSxPQUFPO0FBQzFDLFFBQU1DLE9BQU9DLE9BQU9GLEdBQUc7QUFDdkIsUUFBTUcsT0FBTyxDQUFDLEdBQUdGLElBQUksRUFBRUcsT0FBTyxDQUFDQyxLQUFLQyxTQUFTRCxNQUFNQyxLQUFLQyxXQUFXLENBQUMsR0FBRyxDQUFDO0FBQ3hFLFNBQU9ULHFCQUFxQkssT0FBT0wscUJBQXFCVSxNQUFNO0FBQ2hFO0FBRUEsTUFBTUMsVUFBVUEsQ0FBQztBQUFBLEVBQ2ZDLHlCQUF5QjtBQUFBLEVBQ3pCQyxtQkFBbUI7QUFBQSxFQUNuQkMsOEJBQThCQSxNQUFNO0FBQUEsRUFBRTtBQUFBLEVBQ3RDQyxvQkFBb0I7QUFBQSxFQUNwQkMsdUJBQXVCQSxNQUFNO0FBQUEsRUFBRTtBQUFBLEVBQy9CQyxjQUFjO0FBQ2hCLE1BQU07QUFBQUMsS0FBQTtBQUNKLFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJN0IsU0FBUyxJQUFJO0FBQ3JDLFFBQU0sQ0FBQzhCLGVBQWVDLGdCQUFnQixJQUFJL0IsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQ2dDLGtCQUFrQkMsbUJBQW1CLElBQUlqQyxTQUFTLElBQUk7QUFDN0QsUUFBTSxDQUFDa0Msd0JBQXdCQyx5QkFBeUIsSUFBSW5DLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZFLFFBQU0sQ0FBQ29DLGVBQWVDLGdCQUFnQixJQUFJckMsU0FBUyxDQUFDO0FBQ3BELFFBQU1zQyxXQUFXaEMsWUFBWTtBQUM3QixRQUFNLENBQUNpQyxXQUFXQyxZQUFZLElBQUl4QyxTQUFTLEtBQUs7QUFHaEQsUUFBTXlDLGNBQWNBLE1BQU07QUFDeEJDLFdBQU9DLFNBQVMsRUFBRUMsS0FBSyxHQUFHQyxVQUFVLFNBQVMsQ0FBQztBQUFBLEVBQ2hEO0FBQ0E5QyxZQUFVLE1BQU07QUFDZCxRQUFJMkIsYUFBYTtBQUNmRyxjQUFRLEtBQUs7QUFBQSxJQUNmO0FBQUEsRUFDRixHQUFHLENBQUNILFdBQVcsQ0FBQztBQUNoQjNCLFlBQVUsTUFBTTtBQUNkLFVBQU0rQyxlQUFlQSxNQUFNO0FBQ3pCTixtQkFBYUUsT0FBT0ssVUFBVSxHQUFHO0FBQUEsSUFDbkM7QUFFQUwsV0FBT00saUJBQWlCLFVBQVVGLFlBQVk7QUFFOUMsV0FBTyxNQUFNO0FBQ1hKLGFBQU9PLG9CQUFvQixVQUFVSCxZQUFZO0FBQUEsSUFDbkQ7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVML0MsWUFBVSxNQUFNO0FBQ2QsVUFBTW1ELHFCQUFxQixZQUFZO0FBQ3JDLFVBQUk7QUFDRixjQUFNQyxNQUFNLE1BQU0zQyxJQUFJNEMsSUFBSSw4QkFBOEI7QUFDeEQsY0FBTUMsUUFBUUYsSUFBSUcsTUFBTUEsTUFBTUQsU0FBU0YsSUFBSUcsTUFBTUQsU0FBUztBQUMxRGhCLHlCQUFpQmdCLEtBQUs7QUFBQSxNQUN4QixTQUFTRSxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLGtDQUFrQ0EsS0FBSztBQUFBLE1BQ3ZEO0FBQUEsSUFDRjtBQUdBLFFBQUlqQixTQUFTbUIsU0FBU0MsV0FBVyxnQkFBZ0IsR0FBRztBQUNsRFIseUJBQW1CO0FBQUEsSUFDckI7QUFBQSxFQUNGLEdBQUcsQ0FBQ1osU0FBU21CLFFBQVEsQ0FBQztBQUV0QixRQUFNRSxnQkFBZ0JBLENBQUNDLFVBQVU7QUFDL0IzQix3QkFBb0JELHFCQUFxQjRCLFFBQVEsT0FBT0EsS0FBSztBQUFBLEVBQy9EO0FBRUEsUUFBTUMsc0JBQXNCQSxDQUFDQyxjQUFjQyxhQUFhO0FBQ3RENUIsOEJBQTBCLENBQUM2QixlQUFlO0FBQUEsTUFDeEMsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRixZQUFZLEdBQUdFLFVBQVVGLFlBQVksTUFBTUMsV0FBVyxPQUFPQTtBQUFBQSxJQUNoRSxFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU1FLGdCQUFnQm5FLFlBQVksQ0FBQ29FLFNBQVM7QUFDMUMsUUFBSSxDQUFDQSxRQUFRQSxTQUFTLElBQUssUUFBTztBQUNsQyxRQUFJLGVBQWVDLEtBQUtELElBQUksRUFBRyxRQUFPO0FBRXRDLFVBQU1FLGlCQUFpQkYsS0FBS0csU0FBUyxHQUFHLEtBQUtILEtBQUsvQyxTQUFTLElBQUkrQyxLQUFLSSxNQUFNLEdBQUcsRUFBRSxJQUFJSjtBQUNuRixVQUFNSyxpQkFBaUJqQyxTQUFTbUIsU0FBU1ksU0FBUyxHQUFHLEtBQUsvQixTQUFTbUIsU0FBU3RDLFNBQVMsSUFDakZtQixTQUFTbUIsU0FBU2EsTUFBTSxHQUFHLEVBQUUsSUFDN0JoQyxTQUFTbUI7QUFFYixXQUFPYyxtQkFBbUJILGtCQUFrQkcsZUFBZWIsV0FBVyxHQUFHVSxjQUFjLEdBQUc7QUFBQSxFQUM1RixHQUFHLENBQUM5QixTQUFTbUIsUUFBUSxDQUFDO0FBRXRCLFFBQU1lLGVBQWUxRSxZQUFZLENBQUMyRSxTQUFTO0FBQ3pDLFFBQUlSLGNBQWNRLEtBQUtQLElBQUksRUFBRyxRQUFPO0FBRXJDLFdBQU9PLEtBQUtDLGNBQWNDLEtBQUssQ0FBQ0MsZ0JBQWdCO0FBQzlDLFVBQUlYLGNBQWNXLFlBQVlWLElBQUksRUFBRyxRQUFPO0FBQzVDLGFBQU9VLFlBQVlGLGNBQWNDLEtBQUssQ0FBQ0UsZUFBZVosY0FBY1ksV0FBV1gsSUFBSSxDQUFDO0FBQUEsSUFDdEYsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDRCxhQUFhLENBQUM7QUFFbEJsRSxZQUFVLE1BQU07QUFDZCxVQUFNK0Usa0JBQWtCM0UsWUFBWTRFLFVBQVVQLFlBQVk7QUFFMUQsUUFBSU0sb0JBQW9CLEdBQUk7QUFFNUIsVUFBTUUsYUFBYTdFLFlBQVkyRSxlQUFlO0FBRTlDLFFBQUlFLFlBQVlDLFNBQVM7QUFDdkJoRCwwQkFBb0I2QyxlQUFlO0FBQUEsSUFDckM7QUFFQSxVQUFNSSxxQkFBcUJGLFlBQVlOLGNBQWNLLFVBQVUsQ0FBQ0gsZ0JBQWdCO0FBQzlFLFVBQUlYLGNBQWNXLFlBQVlWLElBQUksRUFBRyxRQUFPO0FBQzVDLGFBQU9VLFlBQVlGLGNBQWNDLEtBQUssQ0FBQ0UsZUFBZVosY0FBY1ksV0FBV1gsSUFBSSxDQUFDO0FBQUEsSUFDdEYsQ0FBQztBQUVELFFBQUlnQixzQkFBc0IsS0FBS0YsWUFBWU4sZUFBZVEsa0JBQWtCLEdBQUdELFNBQVM7QUFDdEY5QyxnQ0FBMEIsQ0FBQzZCLGVBQWU7QUFBQSxRQUN4QyxHQUFHQTtBQUFBQSxRQUNILENBQUNjLGVBQWUsR0FBR0k7QUFBQUEsTUFDckIsRUFBRTtBQUFBLElBQ0o7QUFBQSxFQUNGLEdBQUcsQ0FBQ1YsY0FBY1AsZUFBZTNCLFNBQVNtQixRQUFRLENBQUM7QUFFbkQsUUFBTTBCLGFBQWFBLENBQUNDLE1BQU1DLFlBQVksT0FBTztBQUMzQyxRQUFJLENBQUNELEtBQU0sUUFBTztBQUVsQixRQUFJdkYsZUFBZXVGLElBQUksR0FBRztBQUN4QixhQUFPeEYsYUFBYXdGLE1BQU07QUFBQSxRQUN4QkMsV0FBVyxHQUFHRCxLQUFLRSxNQUFNRCxhQUFhLEVBQUUsSUFBSUEsU0FBUyxHQUFHRSxLQUFLO0FBQUEsTUFDL0QsQ0FBQztBQUFBLElBQ0g7QUFFQSxVQUFNQyxnQkFBZ0JKO0FBQ3RCLFdBQU8sdUJBQUMsaUJBQWMsYUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW9DO0FBQUEsRUFDN0M7QUFFQSxTQUNFLG1DQUNFO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFlBQVkvRDtBQUFBQSxRQUNaO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQTtBQUFBLE1BSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSTZDO0FBQUEsSUFFNUNDLG9CQUNDLG1DQUNFO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVcsd0RBQXdETSxPQUFPLFNBQVMsTUFBTTtBQUFBO0FBQUEsUUFEM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRU87QUFBQSxNQUdQO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFXLGlQQUFpUEEsT0FBTyxTQUFTLE1BQU0sSUFDNVFKLG9CQUFvQixrQkFBa0Isb0NBQW9DO0FBQUEsVUFFaEYsY0FBYyxNQUFNTyxpQkFBaUIsSUFBSTtBQUFBLFVBQ3pDLGNBQWMsTUFBTUEsaUJBQWlCLEtBQUs7QUFBQSxVQUU1QyxpQ0FBQyxRQUFHLFdBQVUsNEJBaUNYNUIsc0JBQVlzRixJQUFJLENBQUNoQixNQUFNYixVQUFVO0FBQ2hDLGtCQUFNOEIsU0FBUzFELHFCQUFxQjRCO0FBQ3BDLGtCQUFNK0IsZUFBZW5CLGFBQWFDLElBQUk7QUFDdEMsa0JBQU1tQixtQkFBbUIzQixjQUFjUSxLQUFLUCxJQUFJO0FBQ2hELGtCQUFNMkIsZUFBZ0JELG9CQUFvQixDQUFDbkIsS0FBS1EsV0FBWVU7QUFFNUQsbUJBQ0UsdUJBQUNoRyxXQUFBLEVBQ0M7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxJQUFJOEUsS0FBS1AsUUFBUTtBQUFBLGtCQUNqQjtBQUFBLGtCQUNBLFNBQVMsQ0FBQzRCLE1BQU07QUFDZCx3QkFBSXJCLEtBQUtRLFNBQVM7QUFDaEJhLHdCQUFFQyxlQUFlO0FBQ2pCcEMsb0NBQWNDLEtBQUs7QUFBQSxvQkFDckIsT0FDSztBQUVIbkIsa0NBQVk7QUFBQSxvQkFDZDtBQUFBLGtCQUNGO0FBQUEsa0JBQ0EsV0FBVyxDQUFDLEVBQUV1RCxTQUFTLE1BQ3ZCLHVFQUF1RXBFLE9BQU8sdURBQXVELGtEQUFrRCxJQUFLb0UsWUFBWSxDQUFDdkIsS0FBS1EsV0FBWVUsZUFDcE4sMEdBQ0Esb0dBQW9HLElBQ3BHbEIsS0FBS3dCLFVBQVUsU0FBUyxFQUFFO0FBQUEsa0JBRy9CSjtBQUFBQSxvQ0FBZ0JqRSxRQUNmLHVCQUFDLFVBQUssV0FBVSxtRkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0Y7QUFBQSxvQkFFakcsdUJBQUMsVUFBSyxXQUFXLHNGQUFzRmxCLHNCQUFzQitELEtBQUt5QixLQUFLLENBQUMsSUFBSUwsZUFBZSw2QkFBNkIsMEJBQTBCLElBQy9NVixxQkFBV1YsS0FBSzBCLE1BQU0sbUJBQW1CLEtBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFXLHlDQUF5QyxDQUFDdkUsUUFBUSxRQUFRO0FBQUEsd0JBR3BFNkM7QUFBQUEsK0JBQUt5QjtBQUFBQSwwQkFDTHpCLEtBQUsyQix3QkFBd0IsUUFBUWhFLGdCQUFnQixLQUNwRCx1QkFBQyxVQUFLLFdBQVUsZ0hBQ2JBLDBCQUFnQixJQUFJQSxnQkFBZ0IsTUFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FDMEM7QUFBQTtBQUFBO0FBQUEsc0JBUDlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFRQTtBQUFBLG9CQUNDcUMsS0FBS1EsV0FBV3JELFFBQ2Y7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVyw2RUFBNkU4RCxTQUFTLDZCQUE2QixFQUFFO0FBQUEsd0JBRWhJLGFBQWE7QUFBQTtBQUFBLHNCQUhmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFHbUI7QUFBQTtBQUFBO0FBQUEsZ0JBdkN2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0EwQ0E7QUFBQSxjQUVDakIsS0FBS1EsV0FBV1MsVUFBVTlELFFBQ3pCLHVCQUFDLFFBQUcsV0FBVSxxRUFDWDZDLGVBQUtDLGFBQWFlLElBQUksQ0FBQ2IsYUFBYWIsYUFBYTtBQUNoRCxzQkFBTXNDLGVBQ0puRSx1QkFBdUIwQixLQUFLLE1BQU1HO0FBRXBDLHVCQUNFLHVCQUFDcEUsV0FBQSxFQUNDO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsSUFBSWlGLFlBQVlWLFFBQVE7QUFBQSxzQkFDeEI7QUFBQSxzQkFDQSxRQUFRVSxZQUFZMEIsU0FBUyxXQUFXO0FBQUEsc0JBQ3hDLFNBQVMsQ0FBQ1IsTUFBTTtBQUNkLDRCQUFJbEIsWUFBWUssU0FBUztBQUN2QmEsNEJBQUVDLGVBQWU7QUFDakJsQyw4Q0FBb0JELE9BQU9HLFFBQVE7QUFBQSx3QkFDckMsT0FDSztBQUVIdEIsc0NBQVk7QUFBQSx3QkFDZDtBQUFBLHNCQUNGO0FBQUEsc0JBQ0EsV0FBVyxDQUFDLEVBQUV1RCxTQUFTLE1BQ3JCLHVHQUF1R0EsWUFBWS9CLGNBQWNXLFlBQVlWLElBQUksS0FBS1UsWUFBWUYsY0FBY0MsS0FBSyxDQUFDNEIsU0FBU3RDLGNBQWNzQyxLQUFLckMsSUFBSSxDQUFDLElBQ25OLDBHQUNBLG9HQUFvRztBQUFBLHNCQUl6R1U7QUFBQUEsb0NBQVl1QixRQUNYLHVCQUFDLFVBQUssV0FBVyxtRUFBbUV6RixzQkFBc0JrRSxZQUFZc0IsS0FBSyxDQUFDLElBQ3pIZixxQkFBV1AsWUFBWXVCLE1BQU0sU0FBUyxLQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBRUYsdUJBQUMsVUFBSyxXQUFVLG1CQUFtQnZCLHNCQUFZc0IsU0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBcUQ7QUFBQSx3QkFDcER0QixZQUFZSyxXQUNYO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVcsaUZBQWlGb0IsZUFBZSw2QkFBNkIsRUFBRTtBQUFBLDRCQUUxSSxhQUFhO0FBQUE7QUFBQSwwQkFIZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBR21CO0FBQUE7QUFBQTtBQUFBLG9CQS9CdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQWtDQTtBQUFBLGtCQUVDekIsWUFBWUssV0FBV29CLGdCQUN0Qix1QkFBQyxRQUFHLFdBQVUseURBQ1h6QixzQkFBWUYsYUFBYWU7QUFBQUEsb0JBQUksQ0FBQ1osZUFDN0I7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBRUMsSUFBSUEsV0FBV1g7QUFBQUEsd0JBQ2Y7QUFBQSx3QkFDQSxTQUFTLE1BQU07QUFFYnpCLHNDQUFZO0FBQUEsd0JBQ2Q7QUFBQSx3QkFDQSxXQUFXLENBQUMsRUFBRXVELFNBQVMsTUFDckIsdUdBQXVHQSxZQUFZL0IsY0FBY1ksV0FBV1gsSUFBSSxJQUM1SSwwR0FDQSxvR0FBb0c7QUFBQSx3QkFJekdXO0FBQUFBLHFDQUFXc0IsUUFDVix1QkFBQyxVQUFLLFdBQVcsbUVBQW1FekYsc0JBQXNCbUUsV0FBV3FCLEtBQUssQ0FBQyxJQUN4SGYscUJBQVdOLFdBQVdzQixNQUFNLGFBQWEsS0FENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDBCQUVGLHVCQUFDLFVBQUssV0FBVSxZQUFZdEIscUJBQVdxQixTQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUE2QztBQUFBO0FBQUE7QUFBQSxzQkFuQnhDckIsV0FBVzJCO0FBQUFBLHNCQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQXFCQTtBQUFBLGtCQUNELEtBeEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBeUJBO0FBQUEscUJBL0RXNUIsWUFBWTRCLElBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaUVBO0FBQUEsY0FFSixDQUFDLEtBekVIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMEVBO0FBQUEsaUJBeEhXL0IsS0FBSytCLElBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEhBO0FBQUEsVUFFSixDQUFDLEtBcEtIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUtBO0FBQUE7QUFBQSxRQTVLQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFnTEE7QUFBQSxNQUVDMUUsaUJBQ0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFdBQVcsK1JBQStSRixPQUFPLFlBQVksb0JBQW9CO0FBQUEsVUFFalYsY0FBYyxNQUFNRyxpQkFBaUIsSUFBSTtBQUFBLFVBQ3pDLFNBQVMsTUFBTUYsUUFBUSxDQUFDRCxJQUFJO0FBQUEsVUFDNUIsY0FBWUEsT0FBTyxxQkFBcUI7QUFBQSxVQUV4QyxpQ0FBQyxlQUFZLFdBQVUsV0FBVSxhQUFhLE9BQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtEO0FBQUE7QUFBQSxRQVJwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFTQTtBQUFBLFNBbE1KO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxTUE7QUFBQSxJQUdESixxQkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVTtBQUFBLFFBQ1YsU0FBUyxNQUFNQyxxQkFBcUIsS0FBSztBQUFBO0FBQUEsTUFGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBR0M7QUFBQSxJQUlIO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXO0FBQUEsd0JBQ0tjLFlBQVksZ0JBQWdCLCtCQUErQjtBQUFBLFFBQzNFLFNBQVNFO0FBQUFBLFFBRVQsaUNBQUMsb0JBQWlCLFdBQVUsd0JBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Q7QUFBQTtBQUFBLE1BTGxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1BO0FBQUEsT0E5TkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdPQTtBQUVKO0FBQUVkLEdBOVZJUCxTQUFPO0FBQUEsVUFhTWQsV0FBVztBQUFBO0FBQUFtRyxLQWJ4QnJGO0FBZ1dOLGVBQWVBO0FBQVEsSUFBQXFGO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJGcmFnbWVudCIsImNsb25lRWxlbWVudCIsImlzVmFsaWRFbGVtZW50IiwidXNlQ2FsbGJhY2siLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIkNoZXZyb25MZWZ0IiwiQ2hldnJvblJpZ2h0Iiwic2lkZWJhck1lbnUiLCJOYXZiYXIiLCJOYXZMaW5rIiwidXNlTG9jYXRpb24iLCJUYkFycm93c0xlZnREb3duIiwiYXBpIiwic2lkZWJhckFjY2VudENsYXNzZXMiLCJnZXRTaWRlYmFyQWNjZW50Q2xhc3MiLCJrZXkiLCJ0ZXh0IiwiU3RyaW5nIiwiaGFzaCIsInJlZHVjZSIsInN1bSIsImNoYXIiLCJjaGFyQ29kZUF0IiwibGVuZ3RoIiwiU2lkZWJhciIsIm5hdlNlYXJjaEJhclZpc2liaWxpdHkiLCJuYXZiYXJWaXNpYmlsaXR5Iiwib25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwic2hvd01vYmlsZVNpZGViYXIiLCJzZXRTaG93TW9iaWxlU2lkZWJhciIsImhpZGVTaWRlYmFyIiwiX3MiLCJvcGVuIiwic2V0T3BlbiIsInNob3dBcnJvd0xlZnQiLCJzZXRTaG93QXJyb3dMZWZ0Iiwic3VibWVudU9wZW5JbmRleCIsInNldFN1Ym1lbnVPcGVuSW5kZXgiLCJuZXN0ZWRTdWJtZW51T3BlbkluZGV4Iiwic2V0TmVzdGVkU3VibWVudU9wZW5JbmRleCIsInBlbmRpbmdDb3VudHMiLCJzZXRQZW5kaW5nQ291bnRzIiwibG9jYXRpb24iLCJpc1Zpc2libGUiLCJzZXRJc1Zpc2libGUiLCJzY3JvbGxUb1RvcCIsIndpbmRvdyIsInNjcm9sbFRvIiwidG9wIiwiYmVoYXZpb3IiLCJoYW5kbGVTY3JvbGwiLCJzY3JvbGxZIiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJmZXRjaFBlbmRpbmdDb3VudHMiLCJyZXMiLCJnZXQiLCJ0b3RhbCIsImRhdGEiLCJlcnJvciIsImNvbnNvbGUiLCJwYXRobmFtZSIsInN0YXJ0c1dpdGgiLCJ0b2dnbGVTdWJNZW51IiwiaW5kZXgiLCJ0b2dnbGVOZXN0ZWRTdWJNZW51Iiwic3VibWVudUluZGV4Iiwic3ViSW5kZXgiLCJwcmV2U3RhdGUiLCJpc1JvdXRlQWN0aXZlIiwibGluayIsInRlc3QiLCJub3JtYWxpemVkTGluayIsImVuZHNXaXRoIiwic2xpY2UiLCJub3JtYWxpemVkUGF0aCIsImlzTWVudUFjdGl2ZSIsIm1lbnUiLCJzdWJtZW51SXRlbXMiLCJzb21lIiwic3VibWVudUl0ZW0iLCJzdWJTdWJJdGVtIiwiYWN0aXZlTWVudUluZGV4IiwiZmluZEluZGV4IiwiYWN0aXZlTWVudSIsInN1Ym1lbnUiLCJhY3RpdmVTdWJtZW51SW5kZXgiLCJyZW5kZXJJY29uIiwiSWNvbiIsImNsYXNzTmFtZSIsInByb3BzIiwidHJpbSIsIkljb25Db21wb25lbnQiLCJtYXAiLCJpc09wZW4iLCJtZW51SXNBY3RpdmUiLCJtZW51TGlua0lzQWN0aXZlIiwiaXNBY3RpdmVNZW51IiwiZSIsInByZXZlbnREZWZhdWx0IiwiaXNBY3RpdmUiLCJzcGFjaW5nIiwidGl0bGUiLCJpY29uIiwicGVuZGluZ05vdGlmaWNhdGlvbiIsImlzTmVzdGVkT3BlbiIsIm5ld1RhYiIsIml0ZW0iLCJpZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNpZGViYXIuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIHJlYWN0L3Byb3AtdHlwZXMgKi9cclxuaW1wb3J0IHsgRnJhZ21lbnQsIGNsb25lRWxlbWVudCwgaXNWYWxpZEVsZW1lbnQsIHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IENoZXZyb25MZWZ0LCBDaGV2cm9uUmlnaHQgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCBzaWRlYmFyTWVudSBmcm9tIFwiLi4vLi4vZGF0YS9zaWRlYmFyTWVudVwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuL05hdmJhclwiO1xyXG5pbXBvcnQgeyBOYXZMaW5rLCB1c2VMb2NhdGlvbiB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IFRiQXJyb3dzTGVmdERvd24gfSBmcm9tIFwicmVhY3QtaWNvbnMvdGJcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5cclxuY29uc3Qgc2lkZWJhckFjY2VudENsYXNzZXMgPSBbXHJcbiAgXCJiZy1ibHVlLTUwIHRleHQtYmx1ZS03MDAgYm9yZGVyLWJsdWUtMTAwLzgwXCIsXHJcbiAgXCJiZy1pbmRpZ28tNTAgdGV4dC1pbmRpZ28tNzAwIGJvcmRlci1pbmRpZ28tMTAwLzgwXCIsXHJcbiAgXCJiZy1lbWVyYWxkLTUwIHRleHQtZW1lcmFsZC03MDAgYm9yZGVyLWVtZXJhbGQtMTAwLzgwXCIsXHJcbiAgXCJiZy1hbWJlci01MCB0ZXh0LWFtYmVyLTcwMCBib3JkZXItYW1iZXItMTAwLzgwXCIsXHJcbiAgXCJiZy1za3ktNTAgdGV4dC1za3ktNzAwIGJvcmRlci1za3ktMTAwLzgwXCIsXHJcbiAgXCJiZy12aW9sZXQtNTAgdGV4dC12aW9sZXQtNzAwIGJvcmRlci12aW9sZXQtMTAwLzgwXCIsXHJcbiAgXCJiZy1yb3NlLTUwIHRleHQtcm9zZS03MDAgYm9yZGVyLXJvc2UtMTAwLzgwXCIsXHJcbiAgXCJiZy10ZWFsLTUwIHRleHQtdGVhbC03MDAgYm9yZGVyLXRlYWwtMTAwLzgwXCIsXHJcbiAgXCJiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS03MDAgYm9yZGVyLXNsYXRlLTIwMC84MFwiLFxyXG5dO1xyXG5cclxuY29uc3QgZ2V0U2lkZWJhckFjY2VudENsYXNzID0gKGtleSA9IFwiXCIpID0+IHtcclxuICBjb25zdCB0ZXh0ID0gU3RyaW5nKGtleSk7XHJcbiAgY29uc3QgaGFzaCA9IFsuLi50ZXh0XS5yZWR1Y2UoKHN1bSwgY2hhcikgPT4gc3VtICsgY2hhci5jaGFyQ29kZUF0KDApLCAwKTtcclxuICByZXR1cm4gc2lkZWJhckFjY2VudENsYXNzZXNbaGFzaCAlIHNpZGViYXJBY2NlbnRDbGFzc2VzLmxlbmd0aF07XHJcbn07XHJcblxyXG5jb25zdCBTaWRlYmFyID0gKHtcclxuICBuYXZTZWFyY2hCYXJWaXNpYmlsaXR5ID0gZmFsc2UsXHJcbiAgbmF2YmFyVmlzaWJpbGl0eSA9IHRydWUsXHJcbiAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKCkgPT4geyB9LFxyXG4gIHNob3dNb2JpbGVTaWRlYmFyID0gZmFsc2UsXHJcbiAgc2V0U2hvd01vYmlsZVNpZGViYXIgPSAoKSA9PiB7IH0sXHJcbiAgaGlkZVNpZGViYXIgPSBmYWxzZVxyXG59KSA9PiB7XHJcbiAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW3Nob3dBcnJvd0xlZnQsIHNldFNob3dBcnJvd0xlZnRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzdWJtZW51T3BlbkluZGV4LCBzZXRTdWJtZW51T3BlbkluZGV4XSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtuZXN0ZWRTdWJtZW51T3BlbkluZGV4LCBzZXROZXN0ZWRTdWJtZW51T3BlbkluZGV4XSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbcGVuZGluZ0NvdW50cywgc2V0UGVuZGluZ0NvdW50c10gPSB1c2VTdGF0ZSgwKVxyXG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuICBjb25zdCBbaXNWaXNpYmxlLCBzZXRJc1Zpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuXHJcbiAgY29uc3Qgc2Nyb2xsVG9Ub3AgPSAoKSA9PiB7XHJcbiAgICB3aW5kb3cuc2Nyb2xsVG8oeyB0b3A6IDAsIGJlaGF2aW9yOiBcInNtb290aFwiIH0pO1xyXG4gIH07XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChoaWRlU2lkZWJhcikge1xyXG4gICAgICBzZXRPcGVuKGZhbHNlKTtcclxuICAgIH1cclxuICB9LCBbaGlkZVNpZGViYXJdKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgaGFuZGxlU2Nyb2xsID0gKCkgPT4ge1xyXG4gICAgICBzZXRJc1Zpc2libGUod2luZG93LnNjcm9sbFkgPiAzMDApO1xyXG4gICAgfTtcclxuXHJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInNjcm9sbFwiLCBoYW5kbGVTY3JvbGwpO1xyXG5cclxuICAgIHJldHVybiAoKSA9PiB7XHJcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwic2Nyb2xsXCIsIGhhbmRsZVNjcm9sbCk7XHJcbiAgICB9O1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoUGVuZGluZ0NvdW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL290aGVyLXNlcnZpY2VzL2RhaWx5L2NvdW50c1wiKTtcclxuICAgICAgICBjb25zdCB0b3RhbCA9IHJlcy5kYXRhPy5kYXRhPy50b3RhbCA/PyByZXMuZGF0YT8udG90YWwgPz8gMDtcclxuICAgICAgICBzZXRQZW5kaW5nQ291bnRzKHRvdGFsKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcGVuZGluZyBjb3VudHM6XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICAvLyBNYXRjaCBhbnkgcGF0aCB0aGF0IHN0YXJ0cyB3aXRoIC9hcHByb3ZhbC1tZW51XHJcbiAgICBpZiAobG9jYXRpb24ucGF0aG5hbWUuc3RhcnRzV2l0aCgnL2FwcHJvdmFsLW1lbnUnKSkge1xyXG4gICAgICBmZXRjaFBlbmRpbmdDb3VudHMoKTtcclxuICAgIH1cclxuICB9LCBbbG9jYXRpb24ucGF0aG5hbWVdKTtcclxuXHJcbiAgY29uc3QgdG9nZ2xlU3ViTWVudSA9IChpbmRleCkgPT4ge1xyXG4gICAgc2V0U3VibWVudU9wZW5JbmRleChzdWJtZW51T3BlbkluZGV4ID09PSBpbmRleCA/IG51bGwgOiBpbmRleCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdG9nZ2xlTmVzdGVkU3ViTWVudSA9IChzdWJtZW51SW5kZXgsIHN1YkluZGV4KSA9PiB7XHJcbiAgICBzZXROZXN0ZWRTdWJtZW51T3BlbkluZGV4KChwcmV2U3RhdGUpID0+ICh7XHJcbiAgICAgIC4uLnByZXZTdGF0ZSxcclxuICAgICAgW3N1Ym1lbnVJbmRleF06IHByZXZTdGF0ZVtzdWJtZW51SW5kZXhdID09PSBzdWJJbmRleCA/IG51bGwgOiBzdWJJbmRleCxcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBpc1JvdXRlQWN0aXZlID0gdXNlQ2FsbGJhY2soKGxpbmspID0+IHtcclxuICAgIGlmICghbGluayB8fCBsaW5rID09PSBcIiNcIikgcmV0dXJuIGZhbHNlO1xyXG4gICAgaWYgKC9eaHR0cHM/OlxcL1xcLy8udGVzdChsaW5rKSkgcmV0dXJuIGZhbHNlO1xyXG5cclxuICAgIGNvbnN0IG5vcm1hbGl6ZWRMaW5rID0gbGluay5lbmRzV2l0aChcIi9cIikgJiYgbGluay5sZW5ndGggPiAxID8gbGluay5zbGljZSgwLCAtMSkgOiBsaW5rO1xyXG4gICAgY29uc3Qgbm9ybWFsaXplZFBhdGggPSBsb2NhdGlvbi5wYXRobmFtZS5lbmRzV2l0aChcIi9cIikgJiYgbG9jYXRpb24ucGF0aG5hbWUubGVuZ3RoID4gMVxyXG4gICAgICA/IGxvY2F0aW9uLnBhdGhuYW1lLnNsaWNlKDAsIC0xKVxyXG4gICAgICA6IGxvY2F0aW9uLnBhdGhuYW1lO1xyXG5cclxuICAgIHJldHVybiBub3JtYWxpemVkUGF0aCA9PT0gbm9ybWFsaXplZExpbmsgfHwgbm9ybWFsaXplZFBhdGguc3RhcnRzV2l0aChgJHtub3JtYWxpemVkTGlua30vYCk7XHJcbiAgfSwgW2xvY2F0aW9uLnBhdGhuYW1lXSk7XHJcblxyXG4gIGNvbnN0IGlzTWVudUFjdGl2ZSA9IHVzZUNhbGxiYWNrKChtZW51KSA9PiB7XHJcbiAgICBpZiAoaXNSb3V0ZUFjdGl2ZShtZW51LmxpbmspKSByZXR1cm4gdHJ1ZTtcclxuXHJcbiAgICByZXR1cm4gbWVudS5zdWJtZW51SXRlbXM/LnNvbWUoKHN1Ym1lbnVJdGVtKSA9PiB7XHJcbiAgICAgIGlmIChpc1JvdXRlQWN0aXZlKHN1Ym1lbnVJdGVtLmxpbmspKSByZXR1cm4gdHJ1ZTtcclxuICAgICAgcmV0dXJuIHN1Ym1lbnVJdGVtLnN1Ym1lbnVJdGVtcz8uc29tZSgoc3ViU3ViSXRlbSkgPT4gaXNSb3V0ZUFjdGl2ZShzdWJTdWJJdGVtLmxpbmspKTtcclxuICAgIH0pO1xyXG4gIH0sIFtpc1JvdXRlQWN0aXZlXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBhY3RpdmVNZW51SW5kZXggPSBzaWRlYmFyTWVudS5maW5kSW5kZXgoaXNNZW51QWN0aXZlKTtcclxuXHJcbiAgICBpZiAoYWN0aXZlTWVudUluZGV4ID09PSAtMSkgcmV0dXJuO1xyXG5cclxuICAgIGNvbnN0IGFjdGl2ZU1lbnUgPSBzaWRlYmFyTWVudVthY3RpdmVNZW51SW5kZXhdO1xyXG5cclxuICAgIGlmIChhY3RpdmVNZW51Py5zdWJtZW51KSB7XHJcbiAgICAgIHNldFN1Ym1lbnVPcGVuSW5kZXgoYWN0aXZlTWVudUluZGV4KTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBhY3RpdmVTdWJtZW51SW5kZXggPSBhY3RpdmVNZW51Py5zdWJtZW51SXRlbXM/LmZpbmRJbmRleCgoc3VibWVudUl0ZW0pID0+IHtcclxuICAgICAgaWYgKGlzUm91dGVBY3RpdmUoc3VibWVudUl0ZW0ubGluaykpIHJldHVybiB0cnVlO1xyXG4gICAgICByZXR1cm4gc3VibWVudUl0ZW0uc3VibWVudUl0ZW1zPy5zb21lKChzdWJTdWJJdGVtKSA9PiBpc1JvdXRlQWN0aXZlKHN1YlN1Ykl0ZW0ubGluaykpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgaWYgKGFjdGl2ZVN1Ym1lbnVJbmRleCA+PSAwICYmIGFjdGl2ZU1lbnU/LnN1Ym1lbnVJdGVtcz8uW2FjdGl2ZVN1Ym1lbnVJbmRleF0/LnN1Ym1lbnUpIHtcclxuICAgICAgc2V0TmVzdGVkU3VibWVudU9wZW5JbmRleCgocHJldlN0YXRlKSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXZTdGF0ZSxcclxuICAgICAgICBbYWN0aXZlTWVudUluZGV4XTogYWN0aXZlU3VibWVudUluZGV4LFxyXG4gICAgICB9KSk7XHJcbiAgICB9XHJcbiAgfSwgW2lzTWVudUFjdGl2ZSwgaXNSb3V0ZUFjdGl2ZSwgbG9jYXRpb24ucGF0aG5hbWVdKTtcclxuXHJcbiAgY29uc3QgcmVuZGVySWNvbiA9IChJY29uLCBjbGFzc05hbWUgPSBcIlwiKSA9PiB7XHJcbiAgICBpZiAoIUljb24pIHJldHVybiBudWxsO1xyXG5cclxuICAgIGlmIChpc1ZhbGlkRWxlbWVudChJY29uKSkge1xyXG4gICAgICByZXR1cm4gY2xvbmVFbGVtZW50KEljb24sIHtcclxuICAgICAgICBjbGFzc05hbWU6IGAke0ljb24ucHJvcHMuY2xhc3NOYW1lIHx8IFwiXCJ9ICR7Y2xhc3NOYW1lfWAudHJpbSgpLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBJY29uQ29tcG9uZW50ID0gSWNvbjtcclxuICAgIHJldHVybiA8SWNvbkNvbXBvbmVudCBjbGFzc05hbWU9e2NsYXNzTmFtZX0gLz47XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxOYXZiYXJcclxuICAgICAgICB2aXNpYmlsaXR5PXtuYXZTZWFyY2hCYXJWaXNpYmlsaXR5fVxyXG4gICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgIHNob3dNb2JpbGVTaWRlYmFyPXtzaG93TW9iaWxlU2lkZWJhcn1cclxuICAgICAgICBzZXRTaG93TW9iaWxlU2lkZWJhcj17c2V0U2hvd01vYmlsZVNpZGViYXJ9XHJcbiAgICAgIC8+XHJcbiAgICAgIHtuYXZiYXJWaXNpYmlsaXR5ICYmIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e2BoaWRkZW4gc2hyaW5rLTAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIG1kOmJsb2NrICR7b3BlbiA/IFwidy02NFwiIDogXCJ3LTIwXCJcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e2BzaWRlYmFyLXNjcm9sbGJhciBmaXhlZCBsZWZ0LTAgdG9wLVs2OHB4XSB6LTQwIGgtW2NhbGMoMTAwdmgtNjhweCldIHNocmluay0wIG92ZXJmbG93LXktYXV0byBvdmVyZmxvdy14LWhpZGRlbiBib3JkZXItciBib3JkZXItc2xhdGUtMjAwLzcwIGJnLXdoaXRlLzgwIHNoYWRvdy1bMXB4XzBfMThweF9yZ2JhKDE1LDIzLDQyLDAuMDUpXSBiYWNrZHJvcC1ibHVyLTJ4bCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgJHtvcGVuID8gXCJ3LTY0XCIgOiBcInctMjBcIlxyXG4gICAgICAgICAgICAgIH0gJHtzaG93TW9iaWxlU2lkZWJhciA/IFwidHJhbnNsYXRlLXgtMFwiIDogXCItdHJhbnNsYXRlLXgtZnVsbCBtZDp0cmFuc2xhdGUteC0wXCJcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgb25Nb3VzZUVudGVyPXsoKSA9PiBzZXRTaG93QXJyb3dMZWZ0KHRydWUpfVxyXG4gICAgICAgICAgICBvbk1vdXNlTGVhdmU9eygpID0+IHNldFNob3dBcnJvd0xlZnQoZmFsc2UpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInNwYWNlLXktMiBweC0zIHBiLTUgcHQtM1wiPlxyXG4gICAgICAgICAgICB7Lyog4pyFIFNob3cgb25seSBvbmNlICovfVxyXG5cclxuXHJcblxyXG4gICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBiZy1ibHVlLTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBweC0yIHB5LTIgc2hhZG93LXNtIHNwYWNlLXgtMiBtYXgtdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMSBmbGV4LXNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICB7b3BlbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1bMC42NXJlbV0gc206dGV4dC1bMC45cmVtXSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1hdFRpbWUodGltZSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTEgZmxleC0xIG1pbi13LTBcIj5cclxuICAgICAgICAgICAgICAgIDxGYVVzZXJDaXJjbGUgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LXZpb2xldC00MDAgZmxleC1zaHJpbmstMFwiIC8+XHJcbiAgICAgICAgICAgICAgICB7b3BlbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMCBmb250LXNlbWlib2xkIGJyZWFrLXdvcmRzIHRydW5jYXRlIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IGBjbGFtcCgwLjhyZW0sICR7TWF0aC5taW4oKHVzZXJuYW1lPy5sZW5ndGggPz8gMCkgLyAyMCwgMSl9cmVtLCAwLjlyZW0pYCxcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPXt1c2VybmFtZSA/PyBcIlwifVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3VzZXJuYW1lID8/IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PiAqL31cclxuICAgICAgICAgICAge3NpZGViYXJNZW51Lm1hcCgobWVudSwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICBjb25zdCBpc09wZW4gPSBzdWJtZW51T3BlbkluZGV4ID09PSBpbmRleDtcclxuICAgICAgICAgICAgICBjb25zdCBtZW51SXNBY3RpdmUgPSBpc01lbnVBY3RpdmUobWVudSk7XHJcbiAgICAgICAgICAgICAgY29uc3QgbWVudUxpbmtJc0FjdGl2ZSA9IGlzUm91dGVBY3RpdmUobWVudS5saW5rKTtcclxuICAgICAgICAgICAgICBjb25zdCBpc0FjdGl2ZU1lbnUgPSAobWVudUxpbmtJc0FjdGl2ZSAmJiAhbWVudS5zdWJtZW51KSB8fCBtZW51SXNBY3RpdmU7XHJcblxyXG4gICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICA8RnJhZ21lbnQga2V5PXttZW51LmlkfT5cclxuICAgICAgICAgICAgICAgICAgPE5hdkxpbmtcclxuICAgICAgICAgICAgICAgICAgICB0bz17bWVudS5saW5rIHx8IFwiI1wifVxyXG4gICAgICAgICAgICAgICAgICAgIGVuZFxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZiAobWVudS5zdWJtZW51KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdG9nZ2xlU3ViTWVudShpbmRleCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gU2Nyb2xsIHRvIHRvcCBmb3IgbWFpbiBtZW51IGl0ZW1zIHdpdGhvdXQgc3VibWVudVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzY3JvbGxUb1RvcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIGBncm91cCByZWxhdGl2ZSBmbGV4IGl0ZW1zLWNlbnRlciBib3JkZXIgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwICR7b3BlbiA/IFwibWluLWgtWzU0cHhdIHctZnVsbCBnYXAteC0zIHJvdW5kZWQteGwgcHgtMiBweS0xLjVcIiA6IFwibXgtYXV0byBoLTEyIHctMTIganVzdGlmeS1jZW50ZXIgcm91bmRlZC0yeGwgcC0wXCJ9ICR7KGlzQWN0aXZlICYmICFtZW51LnN1Ym1lbnUpIHx8IG1lbnVJc0FjdGl2ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLWluZGlnby0xMDAvODAgYmctaW5kaWdvLTUwLzgwIHRleHQtaW5kaWdvLTcwMCBmb250LXNlbWlib2xkIHNoYWRvdy1zbSBzaGFkb3ctaW5kaWdvLTkwMC9bMC4wM11cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtc2xhdGUtNjAwIGhvdmVyOmJvcmRlci1zbGF0ZS0yMDAvNzAgaG92ZXI6Ymctd2hpdGUvNzAgaG92ZXI6dGV4dC1zbGF0ZS05NTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgfSAke21lbnUuc3BhY2luZyA/IFwibXQtNlwiIDogXCJcIn1gXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2lzQWN0aXZlTWVudSAmJiBvcGVuICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtMSB0b3AtMS8yIGgtNSB3LTEgLXRyYW5zbGF0ZS15LTEvMiByb3VuZGVkLWZ1bGwgYmctWyMwMDcxZTNdLzcwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGdyaWQgaC05IHctOSBzaHJpbmstMCBwbGFjZS1pdGVtcy1jZW50ZXIgcm91bmRlZC14bCBib3JkZXIgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDAgJHtnZXRTaWRlYmFyQWNjZW50Q2xhc3MobWVudS50aXRsZSl9ICR7aXNBY3RpdmVNZW51ID8gXCJyaW5nLTIgcmluZy1bIzAwNzFlM10vMTVcIiA6IFwiZ3JvdXAtaG92ZXI6c2NhbGUtWzEuMDNdXCJ9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cmVuZGVySWNvbihtZW51Lmljb24sIFwiaC1bMThweF0gdy1bMThweF1cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgZmxleC0xIHRydW5jYXRlICR7IW9wZW4gJiYgXCJoaWRkZW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bWVudS50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHttZW51LnBlbmRpbmdOb3RpZmljYXRpb24gPT09IHRydWUgJiYgcGVuZGluZ0NvdW50cyA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHJvdW5kZWQtZnVsbCBiZy1bIzAwNzFlM10gcHgtMiBweS0wLjUgdGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIHNoYWRvdy1zbSBzaGFkb3ctYmx1ZS05MDAvMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cGVuZGluZ0NvdW50cyA+IDAgPyBwZW5kaW5nQ291bnRzIDogXCJcIn08L3NwYW4+KX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAge21lbnUuc3VibWVudSAmJiBvcGVuICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgbWwtYXV0byBoLTQgdy00IHNocmluay0wIHRleHQtc2xhdGUtNDAwIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTIwMCAke2lzT3BlbiA/IFwicm90YXRlLTkwIHRleHQtWyMwMDcxZTNdXCIgOiBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsxLjh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvTmF2TGluaz5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHttZW51LnN1Ym1lbnUgJiYgaXNPcGVuICYmIG9wZW4gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJtbC0zIG10LTEgc3BhY2UteS0xIGJvcmRlci1sIGJvcmRlci1zbGF0ZS0yMDAvNzAgcGwtMyBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge21lbnUuc3VibWVudUl0ZW1zLm1hcCgoc3VibWVudUl0ZW0sIHN1YkluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzTmVzdGVkT3BlbiA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmVzdGVkU3VibWVudU9wZW5JbmRleFtpbmRleF0gPT09IHN1YkluZGV4O1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8RnJhZ21lbnQga2V5PXtzdWJtZW51SXRlbS5pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TmF2TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17c3VibWVudUl0ZW0ubGluayB8fCBcIiNcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZW5kXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldD17c3VibWVudUl0ZW0ubmV3VGFiID8gXCJfYmxhbmtcIiA6IFwiX3NlbGZcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoc3VibWVudUl0ZW0uc3VibWVudSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9nZ2xlTmVzdGVkU3ViTWVudShpbmRleCwgc3ViSW5kZXgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFNjcm9sbCB0byB0b3AgZm9yIHN1Ym1lbnUgaXRlbXMgd2l0aG91dCBuZXN0ZWQgc3VibWVudVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2Nyb2xsVG9Ub3AoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17KHsgaXNBY3RpdmUgfSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgZmxleCBtaW4taC0xMSB3LWZ1bGwgaXRlbXMtY2VudGVyIHJvdW5kZWQtbGcgYm9yZGVyIHB4LTIuNSBweS0yIHRleHQtc20gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwICR7aXNBY3RpdmUgfHwgaXNSb3V0ZUFjdGl2ZShzdWJtZW51SXRlbS5saW5rKSB8fCBzdWJtZW51SXRlbS5zdWJtZW51SXRlbXM/LnNvbWUoKGl0ZW0pID0+IGlzUm91dGVBY3RpdmUoaXRlbS5saW5rKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItaW5kaWdvLTEwMC84MCBiZy1pbmRpZ28tNTAvODAgdGV4dC1pbmRpZ28tNzAwIGZvbnQtc2VtaWJvbGQgc2hhZG93LXNtIHNoYWRvdy1pbmRpZ28tOTAwL1swLjAzXVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtc2xhdGUtNjAwIGhvdmVyOmJvcmRlci1zbGF0ZS0yMDAvNzAgaG92ZXI6Ymctd2hpdGUvNzAgaG92ZXI6dGV4dC1zbGF0ZS05NTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N1Ym1lbnVJdGVtLmljb24gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YG1yLTIgZ3JpZCBoLTggdy04IHNocmluay0wIHBsYWNlLWl0ZW1zLWNlbnRlciByb3VuZGVkLWxnIGJvcmRlciAke2dldFNpZGViYXJBY2NlbnRDbGFzcyhzdWJtZW51SXRlbS50aXRsZSl9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVuZGVySWNvbihzdWJtZW51SXRlbS5pY29uLCBcImgtNCB3LTRcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4LTEgdHJ1bmNhdGVcIj57c3VibWVudUl0ZW0udGl0bGV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3VibWVudUl0ZW0uc3VibWVudSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgbWwtYXV0byBoLTMuNSB3LTMuNSBzaHJpbmstMCB0ZXh0LXNsYXRlLTQwMCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0yMDAgJHtpc05lc3RlZE9wZW4gPyBcInJvdGF0ZS05MCB0ZXh0LVsjMDA3MWUzXVwiIDogXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsxLjh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTmF2TGluaz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3VibWVudUl0ZW0uc3VibWVudSAmJiBpc05lc3RlZE9wZW4gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwibWwtNCBtdC0xIHNwYWNlLXktMSBib3JkZXItbCBib3JkZXItc2xhdGUtMjAwLzcwIHBsLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3VibWVudUl0ZW0uc3VibWVudUl0ZW1zLm1hcCgoc3ViU3ViSXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE5hdkxpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtzdWJTdWJJdGVtLmlkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17c3ViU3ViSXRlbS5saW5rfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbmRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFNjcm9sbCB0byB0b3AgZm9yIG5lc3RlZCBzdWJtZW51IGl0ZW1zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2Nyb2xsVG9Ub3AoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXsoeyBpc0FjdGl2ZSB9KSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGBmbGV4IG1pbi1oLTEwIHctZnVsbCBpdGVtcy1jZW50ZXIgcm91bmRlZC1sZyBib3JkZXIgcHgtMi41IHB5LTIgdGV4dC1zbSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgJHtpc0FjdGl2ZSB8fCBpc1JvdXRlQWN0aXZlKHN1YlN1Ykl0ZW0ubGluaylcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItaW5kaWdvLTEwMC84MCBiZy1pbmRpZ28tNTAvODAgdGV4dC1pbmRpZ28tNzAwIGZvbnQtc2VtaWJvbGQgc2hhZG93LXNtIHNoYWRvdy1pbmRpZ28tOTAwL1swLjAzXVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtc2xhdGUtNTAwIGhvdmVyOmJvcmRlci1zbGF0ZS0yMDAvNzAgaG92ZXI6Ymctd2hpdGUvNzAgaG92ZXI6dGV4dC1zbGF0ZS05NTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N1YlN1Ykl0ZW0uaWNvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgbXItMiBncmlkIGgtNyB3LTcgc2hyaW5rLTAgcGxhY2UtaXRlbXMtY2VudGVyIHJvdW5kZWQtbGcgYm9yZGVyICR7Z2V0U2lkZWJhckFjY2VudENsYXNzKHN1YlN1Ykl0ZW0udGl0bGUpfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlbmRlckljb24oc3ViU3ViSXRlbS5pY29uLCBcImgtMy41IHctMy41XCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj57c3ViU3ViSXRlbS50aXRsZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L05hdkxpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvRnJhZ21lbnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9GcmFnbWVudD5cclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9KX1cclxuICAgICAgICAgIDwvdWw+XHJcblxyXG5cclxuXHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7c2hvd0Fycm93TGVmdCAmJiAoXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmaXhlZCB0b3AtMjAgei01MCBncmlkIGgtOSB3LTkgcGxhY2UtaXRlbXMtY2VudGVyIHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC83MCBiZy13aGl0ZS84NSB0ZXh0LXNsYXRlLTYwMCBzaGFkb3ctbGcgc2hhZG93LXNsYXRlLTkwMC8xMCBiYWNrZHJvcC1ibHVyLXhsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBob3ZlcjpiZy13aGl0ZSBob3Zlcjp0ZXh0LVsjMDA3MWUzXSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMwMDcxZTNdLzI1ICR7b3BlbiA/IFwibGVmdC02MFwiIDogXCJsZWZ0LTE2IHJvdGF0ZS0xODBcIlxyXG4gICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgb25Nb3VzZUVudGVyPXsoKSA9PiBzZXRTaG93QXJyb3dMZWZ0KHRydWUpfVxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE9wZW4oIW9wZW4pfVxyXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9e29wZW4gPyBcIkNvbGxhcHNlIHNpZGViYXJcIiA6IFwiRXhwYW5kIHNpZGViYXJcIn1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxDaGV2cm9uTGVmdCBjbGFzc05hbWU9XCJoLTUgdy01XCIgc3Ryb2tlV2lkdGg9ezEuOH0gLz5cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICA8Lz5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHtzaG93TW9iaWxlU2lkZWJhciAmJiAoXHJcbiAgICAgICAgPGRpdlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTMwIGJnLXNsYXRlLTkwMC8yMCBiYWNrZHJvcC1ibHVyLVsycHhdIG1kOmhpZGRlblwiXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TW9iaWxlU2lkZWJhcihmYWxzZSl9XHJcbiAgICAgICAgPjwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuXHJcbiAgICAgIDxkaXZcclxuICAgICAgICBjbGFzc05hbWU9e2BmaXhlZCBib3R0b20tNiByaWdodC02IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzcwIGJnLXdoaXRlLzg1IHAtMyB0ZXh0LXNsYXRlLTcwMCBzaGFkb3ctbGcgc2hhZG93LXNsYXRlLTkwMC8xMCBiYWNrZHJvcC1ibHVyLXhsIGhvdmVyOmJnLXdoaXRlIGhvdmVyOnRleHQtWyMwMDcxZTNdIGFjdGl2ZTpzY2FsZS05NSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgY3Vyc29yLXBvaW50ZXIgXHJcbiAgICAgICAgICAgICB6LVs5OTk5XSAke2lzVmlzaWJsZSA/ICdvcGFjaXR5LTEwMCcgOiAnb3BhY2l0eS0wIHBvaW50ZXItZXZlbnRzLW5vbmUnfWB9XHJcbiAgICAgICAgb25DbGljaz17c2Nyb2xsVG9Ub3B9XHJcbiAgICAgID5cclxuICAgICAgICA8VGJBcnJvd3NMZWZ0RG93biBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCByb3RhdGUtOTBcIiAvPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgU2lkZWJhcjtcclxuXHJcblxyXG5cclxuXHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhci5qc3gifQ==