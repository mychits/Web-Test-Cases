import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CustomerLoanReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import {
  Search,
  FileText,
  Users,
  Calendar,
  IndianRupee,
  TrendingUp
} from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import { DatePicker } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import __vite__cjsImport6_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport6_dayjs.__esModule ? __vite__cjsImport6_dayjs.default : __vite__cjsImport6_dayjs;
import { Collapse } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { FileTextOutlined, DollarOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import { FaMoneyBill } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
const { RangePicker } = DatePicker;
const CustomerLoanReport = () => {
  _s();
  const [loanReportTable, setLoanReportTable] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedLoanId, setSelectedLoanId] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState("");
  const [selectedReferredBy, setSelectedReferredBy] = useState("");
  const [dateRange, setDateRange] = useState(null);
  useEffect(() => {
    const fetchLoanReport = async () => {
      try {
        const response = await api.get(`/payment/customers/loan-report`);
        const formattedData = response.data.loanReports.map((loan, index) => ({
          id: loan?._id,
          slNo: index + 1,
          loanIds: loan?.loan_id || "N/A",
          loanAmountValue: loan?.loan_amount || 0,
          customerId: loan?.borrower?.customer_id || "N/A",
          customerName: loan?.borrower?.full_name || "N/A",
          customerPhone: loan?.borrower?.phone_number || "N/A",
          daily_payment_amount: loan?.daily_payment_amount || "N/A",
          loanStartDate: loan?.start_date ? new Date(loan.start_date).toLocaleDateString("en-GB") : "N/A",
          // Store the original date for filtering
          loanStartDateObj: loan?.start_date ? new Date(loan.start_date) : null,
          // loanStartDateObj: loan?.start_date ? new Date(loan.start_date) : null,
          loanEndDate: loan?.end_date ? `${loan?.end_date}`.split("T")[0] : "N/A",
          loanSanctionDate: loan?.loan_sanction_date ? `${loan?.loan_sanction_date}`.split("T")[0] : "N/A",
          loanDocumentCharges: loan?.document_charges ?? 0,
          payableLoanDays: loan?.days_count,
          loanServiceCharges: loan?.service_charges ?? 0,
          loanAmount: loan?.double_loan_amount ?? 0,
          payableAmount: loan?.amount_payable ?? 0,
          totalLoanAmount: loan?.total_paid_amount ?? 0,
          loanBalance: loan?.outstanding ?? 0,
          remainingBalance: loan?.balance ?? 0,
          status: loan?.status || "-",
          referredBy: loan?.referredBy || "N/A"
        }));
        setLoanReportTable(formattedData);
      } catch (error) {
        console.error("Error fetching loan report:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchLoanReport();
  }, []);
  const uniqueLoanCombos = useMemo(() => {
    const map = /* @__PURE__ */ new Map();
    loanReportTable.forEach((loan) => {
      const key = loan.loanIds;
      if (!map.has(key)) {
        map.set(key, { id: key, label: `${key} | ₹${loan.loanAmountValue}` });
      }
    });
    return Array.from(map.values());
  }, [loanReportTable]);
  const uniqueCustomers = useMemo(
    () => loanReportTable.map((loan) => ({
      id: loan.id,
      name: loan.customerName,
      phone: loan.customerPhone,
      custid: loan.customerId
    })),
    [loanReportTable]
  );
  const uniqueReferredBy = useMemo(() => {
    const set = /* @__PURE__ */ new Set();
    loanReportTable.forEach((loan) => {
      if (loan.referredBy && loan.referredBy !== "N/A") {
        set.add(loan.referredBy);
      }
    });
    return Array.from(set);
  }, [loanReportTable]);
  const filteredLoanReport = useMemo(
    () => {
      return loanReportTable.filter((loan) => {
        const matchLoanId = selectedLoanId ? loan.loanIds === selectedLoanId : true;
        const matchCustomer = selectedCustomer ? loan.id === selectedCustomer : true;
        const matchReferredBy = selectedReferredBy ? loan.referredBy === selectedReferredBy : true;
        let matchDateRange = true;
        if (dateRange && dateRange.length === 2 && loan.loanStartDateObj) {
          const startDate = dayjs(dateRange[0]).startOf("day");
          const endDate = dayjs(dateRange[1]).endOf("day");
          const loanDate = dayjs(loan.loanStartDateObj);
          matchDateRange = loanDate.isAfter(startDate) && loanDate.isBefore(endDate);
        }
        return matchLoanId && matchCustomer && matchReferredBy && matchDateRange;
      });
    },
    [
      loanReportTable,
      selectedLoanId,
      selectedCustomer,
      selectedReferredBy,
      dateRange
    ]
  );
  const summaryStats = useMemo(() => {
    const filtered = filteredLoanReport;
    return {
      totalLoans: filtered.length,
      totalAmount: filtered.reduce((sum, loan) => sum + loan.loanAmount, 0),
      totalPayable: filtered.reduce((sum, loan) => sum + loan.payableAmount, 0),
      totalPaid: filtered.reduce((sum, loan) => sum + loan.totalLoanAmount, 0),
      totalBalance: filtered.reduce((sum, loan) => sum + loan.loanBalance, 0)
    };
  }, [filteredLoanReport]);
  const loanReportColumns = [
    { key: "slNo", header: "Sl No" },
    { key: "loanIds", header: "Loan ID" },
    { key: "customerName", header: "Customer Name" },
    { key: "customerPhone", header: "Phone Number" },
    { key: "referredBy", header: "Referred By" },
    { key: "loanSanctionDate", header: "Sanction Date" },
    { key: "loanStartDate", header: "Loan Start Date" },
    { key: "loanEndDate", header: "Loan End Date" },
    { key: "loanServiceCharges", header: "Service Charges" },
    { key: "loanDocumentCharges", header: "Documentation Charges" },
    { key: "daily_payment_amount", header: "Daily Installment" },
    { key: "loanAmount", header: "Loan Amount" },
    { key: "payableLoanDays", header: "Loan Age (in Days)" },
    { key: "payableAmount", header: "Loan Payable" },
    { key: "totalLoanAmount", header: "Total Paid" },
    { key: "remainingBalance", header: "Balance" },
    { key: "loanBalance", header: "OutStanding" },
    { key: "status", header: "Status" }
  ];
  const StatCard = ({ icon: Icon, label, value, color }) => /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm border p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-600 mb-1", children: label }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
        lineNumber: 183,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-900", children: value }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
        lineNumber: 184,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
      lineNumber: 182,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: `p-3 rounded-lg ${color}`, children: /* @__PURE__ */ jsxDEV(Icon, { className: "w-6 h-6 text-white" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
      lineNumber: 187,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
      lineNumber: 186,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
    lineNumber: 181,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
    lineNumber: 180,
    columnNumber: 3
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "max-w-screen", children: /* @__PURE__ */ jsxDEV("div", { className: " mx-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV(FileText, { className: "w-7 h-7 text-violet-600" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
          lineNumber: 199,
          columnNumber: 13
        }, this),
        " Loan Summary Report"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
        lineNumber: 198,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 ml-10", children: "Overview of customer loans, payments & referral details" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
        lineNumber: 201,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
      lineNumber: 197,
      columnNumber: 9
    }, this),
    loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center h-96", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
      lineNumber: 208,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
      lineNumber: 207,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("div", { className: "my-6", children: /* @__PURE__ */ jsxDEV(
        Collapse,
        {
          items: [
            {
              key: "1",
              label: /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 text-base", children: "Shortcut Keys" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
                lineNumber: 218,
                columnNumber: 17
              }, this),
              children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-5 gap-4", children: [
                /* @__PURE__ */ jsxDEV(
                  Link,
                  {
                    to: "/other-service-menu/loan",
                    className: "flex text-base items-center gap-2 border  border-gray-200 rounded-lg px-4 py-2 text-gray-700 hover:border-violet-500 hover:text-violet-600 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(FaMoneyBill, { className: "text-violet-500", size: 30 }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
                        lineNumber: 228,
                        columnNumber: 27
                      }, this),
                      "Add Loan"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
                    lineNumber: 224,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Link,
                  {
                    to: "/reports/loan-due-report",
                    className: "flex text-base items-center gap-2 border  border-gray-200 rounded-lg px-4 py-2 text-gray-700 hover:border-violet-500 hover:text-violet-600 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(DollarOutlined, { className: "text-violet-500", size: 30 }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
                        lineNumber: 235,
                        columnNumber: 27
                      }, this),
                      "OutStanding Loan Report"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
                    lineNumber: 231,
                    columnNumber: 25
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Link,
                  {
                    to: "/reports/loan-completion-report",
                    className: "flex text-base items-center gap-2 border  border-gray-200 rounded-lg px-4 py-2 text-gray-700 hover:border-violet-500 hover:text-violet-600 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV(
                        FileTextOutlined,
                        {
                          className: "text-violet-500",
                          size: 30
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
                          lineNumber: 243,
                          columnNumber: 27
                        },
                        this
                      ),
                      "Loan Completion Report"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
                    lineNumber: 239,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
                lineNumber: 223,
                columnNumber: 17
              }, this)
            }
          ],
          defaultActiveKey: ["1"],
          className: "rounded-lg border border-gray-200 bg-white shadow-sm"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
          lineNumber: 213,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
        lineNumber: 212,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              icon: FileText,
              label: "Total Loans",
              value: summaryStats.totalLoans,
              color: "bg-violet-600"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
              lineNumber: 261,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "mt-2 text-xs font-mono text-green-700 break-words px-1", children: numberToIndianWords(summaryStats.totalLoans || 0) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
            lineNumber: 267,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
          lineNumber: 260,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              icon: IndianRupee,
              label: "Total Loan Amount",
              value: `₹${summaryStats.totalAmount}`,
              color: "bg-purple-600"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
              lineNumber: 274,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "mt-2 text-xs font-mono text-green-700 break-words px-1", children: numberToIndianWords(summaryStats.totalAmount || 0) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
            lineNumber: 280,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
          lineNumber: 273,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              icon: TrendingUp,
              label: "Total Payable",
              value: `₹${summaryStats.totalPayable}`,
              color: "bg-violet-600"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
              lineNumber: 287,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "mt-2 text-xs font-mono text-green-700 break-words px-1", children: numberToIndianWords(summaryStats.totalPayable || 0) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
            lineNumber: 293,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
          lineNumber: 286,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              icon: TrendingUp,
              label: "Total Paid",
              value: `₹${summaryStats.totalPaid}`,
              color: "bg-green-600"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
              lineNumber: 300,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "mt-2 text-xs font-mono text-green-700 break-words px-1", children: numberToIndianWords(summaryStats.totalPaid || 0) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
            lineNumber: 306,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
          lineNumber: 299,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
        lineNumber: 258,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm border p-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold flex items-center gap-2 mb-4", children: [
          /* @__PURE__ */ jsxDEV(Search, { className: "w-5 h-5" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
            lineNumber: 328,
            columnNumber: 17
          }, this),
          " Filter Options"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
          lineNumber: 327,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Loan ID & Amount" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
              lineNumber: 334,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                placeholder: "Select loan",
                value: selectedLoanId,
                onChange: setSelectedLoanId,
                allowClear: true,
                className: "w-full",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Loans" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
                    lineNumber: 345,
                    columnNumber: 21
                  }, this),
                  uniqueLoanCombos.map(
                    (loan) => /* @__PURE__ */ jsxDEV(Select.Option, { value: loan.id, children: loan.label }, loan.id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
                      lineNumber: 347,
                      columnNumber: 19
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
                lineNumber: 337,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
            lineNumber: 333,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Customer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
              lineNumber: 356,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                placeholder: "Select customer",
                value: selectedCustomer,
                onChange: setSelectedCustomer,
                allowClear: true,
                className: "w-full",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Customers" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
                    lineNumber: 367,
                    columnNumber: 21
                  }, this),
                  uniqueCustomers.map(
                    (cust) => /* @__PURE__ */ jsxDEV(Select.Option, { value: cust.id, children: [
                      cust.custid,
                      " | ",
                      cust.name,
                      " | ",
                      cust.phone
                    ] }, cust.id, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
                      lineNumber: 369,
                      columnNumber: 19
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
                lineNumber: 359,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
            lineNumber: 355,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Referred By" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
              lineNumber: 378,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                placeholder: "Select referrer",
                value: selectedReferredBy,
                onChange: setSelectedReferredBy,
                allowClear: true,
                className: "w-full",
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All Referred By" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
                    lineNumber: 389,
                    columnNumber: 21
                  }, this),
                  uniqueReferredBy.map(
                    (ref) => /* @__PURE__ */ jsxDEV(Select.Option, { value: ref, children: ref }, ref, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
                      lineNumber: 391,
                      columnNumber: 19
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
                lineNumber: 381,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
            lineNumber: 377,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Start Date Range" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
              lineNumber: 400,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              RangePicker,
              {
                value: dateRange,
                onChange: setDateRange,
                className: "w-full",
                format: "DD/MM/YYYY"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
                lineNumber: 403,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
            lineNumber: 399,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
          lineNumber: 331,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
        lineNumber: 326,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "max-w-screen", children: /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          columns: loanReportColumns,
          data: filteredLoanReport,
          printHeaderKeys: [
            "Total Loans",
            "Total Loan Amount",
            "Total Payable",
            "Total Paid",
            "Total Outstanding"
          ],
          printHeaderValues: [
            summaryStats.totalLoans.toLocaleString("en-IN"),
            `₹ ${summaryStats.totalAmount.toLocaleString("en-IN")}`,
            `₹ ${summaryStats.totalPayable.toLocaleString("en-IN")}`,
            `₹ ${summaryStats.totalPaid.toLocaleString("en-IN")}`,
            `₹ ${summaryStats.totalBalance.toLocaleString("en-IN")}`
          ],
          exportedPdfName: "Customer Loan Report",
          exportedFileName: "Customer Loan Report.csv"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
          lineNumber: 415,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
        lineNumber: 414,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
      lineNumber: 211,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
    lineNumber: 195,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx",
    lineNumber: 194,
    columnNumber: 5
  }, this);
};
_s(CustomerLoanReport, "dENn+Yil8LNzO5ED7UbXhI9EW3s=");
_c = CustomerLoanReport;
export default CustomerLoanReport;
var _c;
$RefreshReg$(_c, "CustomerLoanReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerLoanReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0xVLFNBNEJBLFVBNUJBOzJCQXRMVjtBQUFvQkEsb0JBQWlCLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDcEQ7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0Msa0JBQWtCO0FBQzNCLE9BQU9DLFdBQVc7QUFDbEIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFlBQVk7QUFDckIsU0FBU0Msa0JBQWtCQyxzQkFBc0I7QUFDakQsU0FBU0MsbUJBQW1CO0FBQzVCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixTQUFTQyxjQUFjO0FBQ3ZCLE9BQU9DLG9CQUFvQjtBQUMzQixTQUFTQywyQkFBMkI7QUFFcEMsTUFBTSxFQUFFQyxZQUFZLElBQUlaO0FBRXhCLE1BQU1hLHFCQUFxQkEsTUFBTTtBQUFBQyxLQUFBO0FBQy9CLFFBQU0sQ0FBQ0MsaUJBQWlCQyxrQkFBa0IsSUFBSXZCLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUN3QixTQUFTQyxVQUFVLElBQUl6QixTQUFTLElBQUk7QUFFM0MsUUFBTSxDQUFDMEIsZ0JBQWdCQyxpQkFBaUIsSUFBSTNCLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUM0QixrQkFBa0JDLG1CQUFtQixJQUFJN0IsU0FBUyxFQUFFO0FBQzNELFFBQU0sQ0FBQzhCLG9CQUFvQkMscUJBQXFCLElBQUkvQixTQUFTLEVBQUU7QUFDL0QsUUFBTSxDQUFDZ0MsV0FBV0MsWUFBWSxJQUFJakMsU0FBUyxJQUFJO0FBRS9Da0MsWUFBVSxNQUFNO0FBQ2QsVUFBTUMsa0JBQWtCLFlBQVk7QUFDbEMsVUFBSTtBQUNGLGNBQU1DLFdBQVcsTUFBTXRCLElBQUl1QixJQUFJLGdDQUFnQztBQUUvRCxjQUFNQyxnQkFBZ0JGLFNBQVNHLEtBQUtDLFlBQVlDLElBQUksQ0FBQ0MsTUFBTUMsV0FBVztBQUFBLFVBQ3BFQyxJQUFJRixNQUFNRztBQUFBQSxVQUNWQyxNQUFNSCxRQUFRO0FBQUEsVUFDZEksU0FBU0wsTUFBTU0sV0FBVztBQUFBLFVBQzFCQyxpQkFBaUJQLE1BQU1RLGVBQWU7QUFBQSxVQUV0Q0MsWUFBWVQsTUFBTVUsVUFBVUMsZUFBZTtBQUFBLFVBQzNDQyxjQUFjWixNQUFNVSxVQUFVRyxhQUFhO0FBQUEsVUFDM0NDLGVBQWVkLE1BQU1VLFVBQVVLLGdCQUFnQjtBQUFBLFVBQy9DQyxzQkFBc0JoQixNQUFNZ0Isd0JBQXdCO0FBQUEsVUFDcERDLGVBQWVqQixNQUFNa0IsYUFDakIsSUFBSUMsS0FBS25CLEtBQUtrQixVQUFVLEVBQUVFLG1CQUFtQixPQUFPLElBQ3BEO0FBQUE7QUFBQSxVQUVKQyxrQkFBa0JyQixNQUFNa0IsYUFBYSxJQUFJQyxLQUFLbkIsS0FBS2tCLFVBQVUsSUFBSTtBQUFBO0FBQUEsVUFFakVJLGFBQWF0QixNQUFNdUIsV0FDZixHQUFHdkIsTUFBTXVCLFFBQVEsR0FBR0MsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUNoQztBQUFBLFVBQ0pDLGtCQUFrQnpCLE1BQU0wQixxQkFDcEIsR0FBRzFCLE1BQU0wQixrQkFBa0IsR0FBR0YsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUMxQztBQUFBLFVBQ0pHLHFCQUFxQjNCLE1BQU00QixvQkFBb0I7QUFBQSxVQUMvQ0MsaUJBQWlCN0IsTUFBTThCO0FBQUFBLFVBQ3ZCQyxvQkFBb0IvQixNQUFNZ0MsbUJBQW1CO0FBQUEsVUFDN0NDLFlBQVlqQyxNQUFNa0Msc0JBQXNCO0FBQUEsVUFDeENDLGVBQWVuQyxNQUFNb0Msa0JBQWtCO0FBQUEsVUFDdkNDLGlCQUFpQnJDLE1BQU1zQyxxQkFBcUI7QUFBQSxVQUM1Q0MsYUFBYXZDLE1BQU13QyxlQUFlO0FBQUEsVUFDbENDLGtCQUFrQnpDLE1BQU0wQyxXQUFXO0FBQUEsVUFDbkNDLFFBQVEzQyxNQUFNMkMsVUFBVTtBQUFBLFVBQ3hCQyxZQUFZNUMsTUFBTTRDLGNBQWM7QUFBQSxRQUNsQyxFQUFFO0FBRUYvRCwyQkFBbUJlLGFBQWE7QUFBQSxNQUNsQyxTQUFTaUQsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSwrQkFBK0JBLEtBQUs7QUFBQSxNQUNwRCxVQUFDO0FBQ0M5RCxtQkFBVyxLQUFLO0FBQUEsTUFDbEI7QUFBQSxJQUNGO0FBRUFVLG9CQUFnQjtBQUFBLEVBQ2xCLEdBQUcsRUFBRTtBQUVMLFFBQU1zRCxtQkFBbUJDLFFBQVEsTUFBTTtBQUNyQyxVQUFNakQsTUFBTSxvQkFBSWtELElBQUk7QUFDcEJyRSxvQkFBZ0JzRSxRQUFRLENBQUNsRCxTQUFTO0FBQ2hDLFlBQU1tRCxNQUFNbkQsS0FBS0s7QUFDakIsVUFBSSxDQUFDTixJQUFJcUQsSUFBSUQsR0FBRyxHQUFHO0FBQ2pCcEQsWUFBSXNELElBQUlGLEtBQUssRUFBRWpELElBQUlpRCxLQUFLRyxPQUFPLEdBQUdILEdBQUcsT0FBT25ELEtBQUtPLGVBQWUsR0FBRyxDQUFDO0FBQUEsTUFDdEU7QUFBQSxJQUNGLENBQUM7QUFDRCxXQUFPZ0QsTUFBTUMsS0FBS3pELElBQUkwRCxPQUFPLENBQUM7QUFBQSxFQUNoQyxHQUFHLENBQUM3RSxlQUFlLENBQUM7QUFFcEIsUUFBTThFLGtCQUFrQlY7QUFBQUEsSUFDdEIsTUFDRXBFLGdCQUFnQm1CLElBQUksQ0FBQ0MsVUFBVTtBQUFBLE1BQzdCRSxJQUFJRixLQUFLRTtBQUFBQSxNQUNUeUQsTUFBTTNELEtBQUtZO0FBQUFBLE1BQ1hnRCxPQUFPNUQsS0FBS2M7QUFBQUEsTUFDWitDLFFBQVE3RCxLQUFLUztBQUFBQSxJQUNmLEVBQUU7QUFBQSxJQUNKLENBQUM3QixlQUFlO0FBQUEsRUFDbEI7QUFFQSxRQUFNa0YsbUJBQW1CZCxRQUFRLE1BQU07QUFDckMsVUFBTUssTUFBTSxvQkFBSVUsSUFBSTtBQUNwQm5GLG9CQUFnQnNFLFFBQVEsQ0FBQ2xELFNBQVM7QUFDaEMsVUFBSUEsS0FBSzRDLGNBQWM1QyxLQUFLNEMsZUFBZSxPQUFPO0FBQ2hEUyxZQUFJVyxJQUFJaEUsS0FBSzRDLFVBQVU7QUFBQSxNQUN6QjtBQUFBLElBQ0YsQ0FBQztBQUNELFdBQU9XLE1BQU1DLEtBQUtILEdBQUc7QUFBQSxFQUN2QixHQUFHLENBQUN6RSxlQUFlLENBQUM7QUFFcEIsUUFBTXFGLHFCQUFxQmpCO0FBQUFBLElBQVEsTUFBTTtBQUN2QyxhQUFPcEUsZ0JBQWdCc0YsT0FBTyxDQUFDbEUsU0FBUztBQUN0QyxjQUFNbUUsY0FBY25GLGlCQUNoQmdCLEtBQUtLLFlBQVlyQixpQkFDakI7QUFDSixjQUFNb0YsZ0JBQWdCbEYsbUJBQ2xCYyxLQUFLRSxPQUFPaEIsbUJBQ1o7QUFDSixjQUFNbUYsa0JBQWtCakYscUJBQ3BCWSxLQUFLNEMsZUFBZXhELHFCQUNwQjtBQUdKLFlBQUlrRixpQkFBaUI7QUFDckIsWUFBSWhGLGFBQWFBLFVBQVVpRixXQUFXLEtBQUt2RSxLQUFLcUIsa0JBQWtCO0FBQ2hFLGdCQUFNbUQsWUFBWTFHLE1BQU13QixVQUFVLENBQUMsQ0FBQyxFQUFFbUYsUUFBUSxLQUFLO0FBQ25ELGdCQUFNQyxVQUFVNUcsTUFBTXdCLFVBQVUsQ0FBQyxDQUFDLEVBQUVxRixNQUFNLEtBQUs7QUFDL0MsZ0JBQU1DLFdBQVc5RyxNQUFNa0MsS0FBS3FCLGdCQUFnQjtBQUM1Q2lELDJCQUNFTSxTQUFTQyxRQUFRTCxTQUFTLEtBQUtJLFNBQVNFLFNBQVNKLE9BQU87QUFBQSxRQUM1RDtBQUVBLGVBQU9QLGVBQWVDLGlCQUFpQkMsbUJBQW1CQztBQUFBQSxNQUM1RCxDQUFDO0FBQUEsSUFDSDtBQUFBLElBQUc7QUFBQSxNQUNEMUY7QUFBQUEsTUFDQUk7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUU7QUFBQUEsSUFBUztBQUFBLEVBQ1Y7QUFFRCxRQUFNeUYsZUFBZS9CLFFBQVEsTUFBTTtBQUNqQyxVQUFNZ0MsV0FBV2Y7QUFDakIsV0FBTztBQUFBLE1BQ0xnQixZQUFZRCxTQUFTVDtBQUFBQSxNQUNyQlcsYUFBYUYsU0FBU0csT0FBTyxDQUFDQyxLQUFLcEYsU0FBU29GLE1BQU1wRixLQUFLaUMsWUFBWSxDQUFDO0FBQUEsTUFDcEVvRCxjQUFjTCxTQUFTRyxPQUFPLENBQUNDLEtBQUtwRixTQUFTb0YsTUFBTXBGLEtBQUttQyxlQUFlLENBQUM7QUFBQSxNQUN4RW1ELFdBQVdOLFNBQVNHLE9BQU8sQ0FBQ0MsS0FBS3BGLFNBQVNvRixNQUFNcEYsS0FBS3FDLGlCQUFpQixDQUFDO0FBQUEsTUFDdkVrRCxjQUFjUCxTQUFTRyxPQUFPLENBQUNDLEtBQUtwRixTQUFTb0YsTUFBTXBGLEtBQUt1QyxhQUFhLENBQUM7QUFBQSxJQUN4RTtBQUFBLEVBQ0YsR0FBRyxDQUFDMEIsa0JBQWtCLENBQUM7QUFFdkIsUUFBTXVCLG9CQUFvQjtBQUFBLElBQ3hCLEVBQUVyQyxLQUFLLFFBQVFzQyxRQUFRLFFBQVE7QUFBQSxJQUMvQixFQUFFdEMsS0FBSyxXQUFXc0MsUUFBUSxVQUFVO0FBQUEsSUFDcEMsRUFBRXRDLEtBQUssZ0JBQWdCc0MsUUFBUSxnQkFBZ0I7QUFBQSxJQUMvQyxFQUFFdEMsS0FBSyxpQkFBaUJzQyxRQUFRLGVBQWU7QUFBQSxJQUMvQyxFQUFFdEMsS0FBSyxjQUFjc0MsUUFBUSxjQUFjO0FBQUEsSUFDM0MsRUFBRXRDLEtBQUssb0JBQW9Cc0MsUUFBUSxnQkFBZ0I7QUFBQSxJQUNuRCxFQUFFdEMsS0FBSyxpQkFBaUJzQyxRQUFRLGtCQUFrQjtBQUFBLElBQ2xELEVBQUV0QyxLQUFLLGVBQWVzQyxRQUFRLGdCQUFnQjtBQUFBLElBQzlDLEVBQUV0QyxLQUFLLHNCQUFzQnNDLFFBQVEsa0JBQWtCO0FBQUEsSUFDdkQsRUFBRXRDLEtBQUssdUJBQXVCc0MsUUFBUSx3QkFBd0I7QUFBQSxJQUM5RCxFQUFFdEMsS0FBSyx3QkFBd0JzQyxRQUFRLG9CQUFvQjtBQUFBLElBQzNELEVBQUV0QyxLQUFLLGNBQWNzQyxRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFdEMsS0FBSyxtQkFBbUJzQyxRQUFRLHFCQUFxQjtBQUFBLElBQ3ZELEVBQUV0QyxLQUFLLGlCQUFpQnNDLFFBQVEsZUFBZTtBQUFBLElBQy9DLEVBQUV0QyxLQUFLLG1CQUFtQnNDLFFBQVEsYUFBYTtBQUFBLElBQy9DLEVBQUV0QyxLQUFLLG9CQUFvQnNDLFFBQVEsVUFBVTtBQUFBLElBQzdDLEVBQUV0QyxLQUFLLGVBQWVzQyxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFdEMsS0FBSyxVQUFVc0MsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQyxRQUFNQyxXQUFXQSxDQUFDLEVBQUVDLE1BQU1DLE1BQU10QyxPQUFPdUMsT0FBT0MsTUFBTSxNQUNsRCx1QkFBQyxTQUFJLFdBQVUsNENBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsMkJBQUMsU0FDQztBQUFBLDZCQUFDLE9BQUUsV0FBVSwwQ0FBMEN4QyxtQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RDtBQUFBLE1BQzdELHVCQUFDLE9BQUUsV0FBVSxvQ0FBb0N1QyxtQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RDtBQUFBLFNBRnpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFXLGtCQUFrQkMsS0FBSyxJQUNyQyxpQ0FBQyxRQUFLLFdBQVUsd0JBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0MsS0FEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBVUE7QUFHRixTQUNFLHVCQUFDLFNBQUksV0FBVSxnQkFDYixpQ0FBQyxTQUFJLFdBQVUsWUFFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLDhDQUNaO0FBQUEsK0JBQUMsWUFBUyxXQUFVLDZCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZDO0FBQUEsUUFBRztBQUFBLFdBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxXQUFVLHVCQUFzQix1RUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUVDaEgsVUFDQyx1QkFBQyxTQUFJLFdBQVUseUNBQ2IsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxJQUVBLG1DQUNFO0FBQUEsNkJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU87QUFBQSxZQUNMO0FBQUEsY0FDRXFFLEtBQUs7QUFBQSxjQUNMRyxPQUNFLHVCQUFDLFVBQUssV0FBVSx5Q0FBd0MsNkJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVGeUMsVUFDRSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxJQUFHO0FBQUEsb0JBQ0gsV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsZUFBWSxXQUFVLG1CQUFrQixNQUFNLE1BQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWtEO0FBQUEsc0JBQUc7QUFBQTtBQUFBO0FBQUEsa0JBSnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLElBQUc7QUFBQSxvQkFDSCxXQUFVO0FBQUEsb0JBRVY7QUFBQSw2Q0FBQyxrQkFBZSxXQUFVLG1CQUFrQixNQUFNLE1BQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXFEO0FBQUEsc0JBQUc7QUFBQTtBQUFBO0FBQUEsa0JBSjFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLElBQUc7QUFBQSxvQkFDSCxXQUFVO0FBQUEsb0JBRVY7QUFBQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFVO0FBQUEsMEJBQ1YsTUFBTTtBQUFBO0FBQUEsd0JBRlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUVXO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVNBO0FBQUEsbUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMEJBO0FBQUEsWUFFSjtBQUFBLFVBQUM7QUFBQSxVQUVILGtCQUFrQixDQUFDLEdBQUc7QUFBQSxVQUN0QixXQUFVO0FBQUE7QUFBQSxRQXpDWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUF5Q2tFLEtBMUNwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNENBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsNkRBRWI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTXZJO0FBQUFBLGNBQ04sT0FBTTtBQUFBLGNBQ04sT0FBT3VILGFBQWFFO0FBQUFBLGNBQ3BCLE9BQU07QUFBQTtBQUFBLFlBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSXVCO0FBQUEsVUFFdkIsdUJBQUMsVUFBSyxXQUFVLDBEQUNiekcsOEJBQW9CdUcsYUFBYUUsY0FBYyxDQUFDLEtBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU10SDtBQUFBQSxjQUNOLE9BQU07QUFBQSxjQUNOLE9BQU8sSUFBSW9ILGFBQWFHLFdBQVc7QUFBQSxjQUNuQyxPQUFNO0FBQUE7QUFBQSxZQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUl1QjtBQUFBLFVBRXZCLHVCQUFDLFVBQUssV0FBVSwwREFDYjFHLDhCQUFvQnVHLGFBQWFHLGVBQWUsQ0FBQyxLQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNdEg7QUFBQUEsY0FDTixPQUFNO0FBQUEsY0FDTixPQUFPLElBQUltSCxhQUFhTSxZQUFZO0FBQUEsY0FDcEMsT0FBTTtBQUFBO0FBQUEsWUFKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJdUI7QUFBQSxVQUV2Qix1QkFBQyxVQUFLLFdBQVUsMERBQ2I3Ryw4QkFBb0J1RyxhQUFhTSxnQkFBZ0IsQ0FBQyxLQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNekg7QUFBQUEsY0FDTixPQUFNO0FBQUEsY0FDTixPQUFPLElBQUltSCxhQUFhTyxTQUFTO0FBQUEsY0FDakMsT0FBTTtBQUFBO0FBQUEsWUFKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJc0I7QUFBQSxVQUV0Qix1QkFBQyxVQUFLLFdBQVUsMERBQ2I5Ryw4QkFBb0J1RyxhQUFhTyxhQUFhLENBQUMsS0FEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsV0FuREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlFQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLGlEQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHNEQUNaO0FBQUEsaUNBQUMsVUFBTyxXQUFVLGFBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJCO0FBQUEsVUFBRztBQUFBLGFBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHdEQUViO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxrQ0FBaUMsZ0NBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQSxhQUFZO0FBQUEsZ0JBQ1osT0FBT3RHO0FBQUFBLGdCQUNQLFVBQVVDO0FBQUFBLGdCQUNWO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxJQUFHLHlCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQztBQUFBLGtCQUNoQzhELGlCQUFpQmhEO0FBQUFBLG9CQUFJLENBQUNDLFNBQ3JCLHVCQUFDLE9BQU8sUUFBUCxFQUE0QixPQUFPQSxLQUFLRSxJQUN0Q0YsZUFBS3NELFNBRFl0RCxLQUFLRSxJQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBO0FBQUEsY0FiSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFjQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsVUFHQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtDQUFpQyx3QkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWixPQUFPaEI7QUFBQUEsZ0JBQ1AsVUFBVUM7QUFBQUEsZ0JBQ1Y7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsNkJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFDO0FBQUEsa0JBQ3BDdUUsZ0JBQWdCM0Q7QUFBQUEsb0JBQUksQ0FBQ2lHLFNBQ3BCLHVCQUFDLE9BQU8sUUFBUCxFQUE0QixPQUFPQSxLQUFLOUYsSUFDdEM4RjtBQUFBQSwyQkFBS25DO0FBQUFBLHNCQUFPO0FBQUEsc0JBQUltQyxLQUFLckM7QUFBQUEsc0JBQUs7QUFBQSxzQkFBSXFDLEtBQUtwQztBQUFBQSx5QkFEbEJvQyxLQUFLOUYsSUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQTtBQUFBLGNBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBY0E7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLFVBR0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxrQ0FBaUMsMkJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQSxhQUFZO0FBQUEsZ0JBQ1osT0FBT2Q7QUFBQUEsZ0JBQ1AsVUFBVUM7QUFBQUEsZ0JBQ1Y7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsK0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVDO0FBQUEsa0JBQ3RDeUUsaUJBQWlCL0Q7QUFBQUEsb0JBQUksQ0FBQ2tHLFFBQ3JCLHVCQUFDLE9BQU8sUUFBUCxFQUF3QixPQUFPQSxLQUM3QkEsaUJBRGlCQSxLQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBO0FBQUEsY0FiSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFjQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsVUFHQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtDQUFpQyxnQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPM0c7QUFBQUEsZ0JBQ1AsVUFBVUM7QUFBQUEsZ0JBQ1YsV0FBVTtBQUFBLGdCQUNWLFFBQU87QUFBQTtBQUFBLGNBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSXFCO0FBQUEsZUFSdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLGFBOUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErRUE7QUFBQSxXQXBGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUZBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVNpRztBQUFBQSxVQUNULE1BQU12QjtBQUFBQSxVQUNOLGlCQUFpQjtBQUFBLFlBQ2Y7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsVUFBbUI7QUFBQSxVQUVyQixtQkFBbUI7QUFBQSxZQUNqQmMsYUFBYUUsV0FBV2lCLGVBQWUsT0FBTztBQUFBLFlBQzlDLEtBQUtuQixhQUFhRyxZQUFZZ0IsZUFBZSxPQUFPLENBQUM7QUFBQSxZQUNyRCxLQUFLbkIsYUFBYU0sYUFBYWEsZUFBZSxPQUFPLENBQUM7QUFBQSxZQUN0RCxLQUFLbkIsYUFBYU8sVUFBVVksZUFBZSxPQUFPLENBQUM7QUFBQSxZQUNuRCxLQUFLbkIsYUFBYVEsYUFBYVcsZUFBZSxPQUFPLENBQUM7QUFBQSxVQUFFO0FBQUEsVUFFMUQsaUJBQWdCO0FBQUEsVUFDaEIsa0JBQWlCO0FBQUE7QUFBQSxRQWxCbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1Ba0I2QyxLQW5CL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFCQTtBQUFBLFNBaE9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpT0E7QUFBQSxPQWpQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbVBBLEtBcFBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxUEE7QUFFSjtBQUFFdkgsR0FqYUlELG9CQUFrQjtBQUFBeUgsS0FBbEJ6SDtBQW1hTixlQUFlQTtBQUFtQixJQUFBeUg7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiU2VhcmNoIiwiRmlsZVRleHQiLCJVc2VycyIsIkNhbGVuZGFyIiwiSW5kaWFuUnVwZWUiLCJUcmVuZGluZ1VwIiwiRGF0ZVBpY2tlciIsImRheWpzIiwiQ29sbGFwc2UiLCJMaW5rIiwiRmlsZVRleHRPdXRsaW5lZCIsIkRvbGxhck91dGxpbmVkIiwiRmFNb25leUJpbGwiLCJhcGkiLCJEYXRhVGFibGUiLCJTZWxlY3QiLCJDaXJjdWxhckxvYWRlciIsIm51bWJlclRvSW5kaWFuV29yZHMiLCJSYW5nZVBpY2tlciIsIkN1c3RvbWVyTG9hblJlcG9ydCIsIl9zIiwibG9hblJlcG9ydFRhYmxlIiwic2V0TG9hblJlcG9ydFRhYmxlIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzZWxlY3RlZExvYW5JZCIsInNldFNlbGVjdGVkTG9hbklkIiwic2VsZWN0ZWRDdXN0b21lciIsInNldFNlbGVjdGVkQ3VzdG9tZXIiLCJzZWxlY3RlZFJlZmVycmVkQnkiLCJzZXRTZWxlY3RlZFJlZmVycmVkQnkiLCJkYXRlUmFuZ2UiLCJzZXREYXRlUmFuZ2UiLCJ1c2VFZmZlY3QiLCJmZXRjaExvYW5SZXBvcnQiLCJyZXNwb25zZSIsImdldCIsImZvcm1hdHRlZERhdGEiLCJkYXRhIiwibG9hblJlcG9ydHMiLCJtYXAiLCJsb2FuIiwiaW5kZXgiLCJpZCIsIl9pZCIsInNsTm8iLCJsb2FuSWRzIiwibG9hbl9pZCIsImxvYW5BbW91bnRWYWx1ZSIsImxvYW5fYW1vdW50IiwiY3VzdG9tZXJJZCIsImJvcnJvd2VyIiwiY3VzdG9tZXJfaWQiLCJjdXN0b21lck5hbWUiLCJmdWxsX25hbWUiLCJjdXN0b21lclBob25lIiwicGhvbmVfbnVtYmVyIiwiZGFpbHlfcGF5bWVudF9hbW91bnQiLCJsb2FuU3RhcnREYXRlIiwic3RhcnRfZGF0ZSIsIkRhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJsb2FuU3RhcnREYXRlT2JqIiwibG9hbkVuZERhdGUiLCJlbmRfZGF0ZSIsInNwbGl0IiwibG9hblNhbmN0aW9uRGF0ZSIsImxvYW5fc2FuY3Rpb25fZGF0ZSIsImxvYW5Eb2N1bWVudENoYXJnZXMiLCJkb2N1bWVudF9jaGFyZ2VzIiwicGF5YWJsZUxvYW5EYXlzIiwiZGF5c19jb3VudCIsImxvYW5TZXJ2aWNlQ2hhcmdlcyIsInNlcnZpY2VfY2hhcmdlcyIsImxvYW5BbW91bnQiLCJkb3VibGVfbG9hbl9hbW91bnQiLCJwYXlhYmxlQW1vdW50IiwiYW1vdW50X3BheWFibGUiLCJ0b3RhbExvYW5BbW91bnQiLCJ0b3RhbF9wYWlkX2Ftb3VudCIsImxvYW5CYWxhbmNlIiwib3V0c3RhbmRpbmciLCJyZW1haW5pbmdCYWxhbmNlIiwiYmFsYW5jZSIsInN0YXR1cyIsInJlZmVycmVkQnkiLCJlcnJvciIsImNvbnNvbGUiLCJ1bmlxdWVMb2FuQ29tYm9zIiwidXNlTWVtbyIsIk1hcCIsImZvckVhY2giLCJrZXkiLCJoYXMiLCJzZXQiLCJsYWJlbCIsIkFycmF5IiwiZnJvbSIsInZhbHVlcyIsInVuaXF1ZUN1c3RvbWVycyIsIm5hbWUiLCJwaG9uZSIsImN1c3RpZCIsInVuaXF1ZVJlZmVycmVkQnkiLCJTZXQiLCJhZGQiLCJmaWx0ZXJlZExvYW5SZXBvcnQiLCJmaWx0ZXIiLCJtYXRjaExvYW5JZCIsIm1hdGNoQ3VzdG9tZXIiLCJtYXRjaFJlZmVycmVkQnkiLCJtYXRjaERhdGVSYW5nZSIsImxlbmd0aCIsInN0YXJ0RGF0ZSIsInN0YXJ0T2YiLCJlbmREYXRlIiwiZW5kT2YiLCJsb2FuRGF0ZSIsImlzQWZ0ZXIiLCJpc0JlZm9yZSIsInN1bW1hcnlTdGF0cyIsImZpbHRlcmVkIiwidG90YWxMb2FucyIsInRvdGFsQW1vdW50IiwicmVkdWNlIiwic3VtIiwidG90YWxQYXlhYmxlIiwidG90YWxQYWlkIiwidG90YWxCYWxhbmNlIiwibG9hblJlcG9ydENvbHVtbnMiLCJoZWFkZXIiLCJTdGF0Q2FyZCIsImljb24iLCJJY29uIiwidmFsdWUiLCJjb2xvciIsImNoaWxkcmVuIiwiY3VzdCIsInJlZiIsInRvTG9jYWxlU3RyaW5nIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ3VzdG9tZXJMb2FuUmVwb3J0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VNZW1vIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7XHJcbiAgU2VhcmNoLFxyXG4gIEZpbGVUZXh0LFxyXG4gIFVzZXJzLFxyXG4gIENhbGVuZGFyLFxyXG4gIEluZGlhblJ1cGVlLFxyXG4gIFRyZW5kaW5nVXAsXHJcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQgeyBEYXRlUGlja2VyIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IGRheWpzIGZyb20gXCJkYXlqc1wiO1xyXG5pbXBvcnQgeyBDb2xsYXBzZSB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBGaWxlVGV4dE91dGxpbmVkLCBEb2xsYXJPdXRsaW5lZCB9IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5pbXBvcnQgeyBGYU1vbmV5QmlsbCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IHsgU2VsZWN0IH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgbnVtYmVyVG9JbmRpYW5Xb3JkcyB9IGZyb20gXCIuLi9oZWxwZXJzL251bWJlclRvSW5kaWFuV29yZHNcIjtcclxuXHJcbmNvbnN0IHsgUmFuZ2VQaWNrZXIgfSA9IERhdGVQaWNrZXI7XHJcblxyXG5jb25zdCBDdXN0b21lckxvYW5SZXBvcnQgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2xvYW5SZXBvcnRUYWJsZSwgc2V0TG9hblJlcG9ydFRhYmxlXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuXHJcbiAgY29uc3QgW3NlbGVjdGVkTG9hbklkLCBzZXRTZWxlY3RlZExvYW5JZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRDdXN0b21lciwgc2V0U2VsZWN0ZWRDdXN0b21lcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRSZWZlcnJlZEJ5LCBzZXRTZWxlY3RlZFJlZmVycmVkQnldID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2RhdGVSYW5nZSwgc2V0RGF0ZVJhbmdlXSA9IHVzZVN0YXRlKG51bGwpOyAvLyBORVcgU1RBVEUgZm9yIGRhdGUgcmFuZ2VcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoTG9hblJlcG9ydCA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9wYXltZW50L2N1c3RvbWVycy9sb2FuLXJlcG9ydGApO1xyXG5cclxuICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2UuZGF0YS5sb2FuUmVwb3J0cy5tYXAoKGxvYW4sIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgaWQ6IGxvYW4/Ll9pZCxcclxuICAgICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuICAgICAgICAgIGxvYW5JZHM6IGxvYW4/LmxvYW5faWQgfHwgXCJOL0FcIixcclxuICAgICAgICAgIGxvYW5BbW91bnRWYWx1ZTogbG9hbj8ubG9hbl9hbW91bnQgfHwgMCxcclxuXHJcbiAgICAgICAgICBjdXN0b21lcklkOiBsb2FuPy5ib3Jyb3dlcj8uY3VzdG9tZXJfaWQgfHwgXCJOL0FcIixcclxuICAgICAgICAgIGN1c3RvbWVyTmFtZTogbG9hbj8uYm9ycm93ZXI/LmZ1bGxfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgY3VzdG9tZXJQaG9uZTogbG9hbj8uYm9ycm93ZXI/LnBob25lX251bWJlciB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgZGFpbHlfcGF5bWVudF9hbW91bnQ6IGxvYW4/LmRhaWx5X3BheW1lbnRfYW1vdW50IHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICBsb2FuU3RhcnREYXRlOiBsb2FuPy5zdGFydF9kYXRlXHJcbiAgICAgICAgICAgID8gbmV3IERhdGUobG9hbi5zdGFydF9kYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1HQlwiKVxyXG4gICAgICAgICAgICA6IFwiTi9BXCIsXHJcbiAgICAgICAgICAvLyBTdG9yZSB0aGUgb3JpZ2luYWwgZGF0ZSBmb3IgZmlsdGVyaW5nXHJcbiAgICAgICAgICBsb2FuU3RhcnREYXRlT2JqOiBsb2FuPy5zdGFydF9kYXRlID8gbmV3IERhdGUobG9hbi5zdGFydF9kYXRlKSA6IG51bGwsXHJcbiAgICAgICAgICAvLyBsb2FuU3RhcnREYXRlT2JqOiBsb2FuPy5zdGFydF9kYXRlID8gbmV3IERhdGUobG9hbi5zdGFydF9kYXRlKSA6IG51bGwsXHJcbiAgICAgICAgICBsb2FuRW5kRGF0ZTogbG9hbj8uZW5kX2RhdGVcclxuICAgICAgICAgICAgPyBgJHtsb2FuPy5lbmRfZGF0ZX1gLnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgICAgICA6IFwiTi9BXCIsXHJcbiAgICAgICAgICBsb2FuU2FuY3Rpb25EYXRlOiBsb2FuPy5sb2FuX3NhbmN0aW9uX2RhdGVcclxuICAgICAgICAgICAgPyBgJHtsb2FuPy5sb2FuX3NhbmN0aW9uX2RhdGV9YC5zcGxpdChcIlRcIilbMF1cclxuICAgICAgICAgICAgOiBcIk4vQVwiLFxyXG4gICAgICAgICAgbG9hbkRvY3VtZW50Q2hhcmdlczogbG9hbj8uZG9jdW1lbnRfY2hhcmdlcyA/PyAwLFxyXG4gICAgICAgICAgcGF5YWJsZUxvYW5EYXlzOiBsb2FuPy5kYXlzX2NvdW50LFxyXG4gICAgICAgICAgbG9hblNlcnZpY2VDaGFyZ2VzOiBsb2FuPy5zZXJ2aWNlX2NoYXJnZXMgPz8gMCxcclxuICAgICAgICAgIGxvYW5BbW91bnQ6IGxvYW4/LmRvdWJsZV9sb2FuX2Ftb3VudCA/PyAwLFxyXG4gICAgICAgICAgcGF5YWJsZUFtb3VudDogbG9hbj8uYW1vdW50X3BheWFibGUgPz8gMCxcclxuICAgICAgICAgIHRvdGFsTG9hbkFtb3VudDogbG9hbj8udG90YWxfcGFpZF9hbW91bnQgPz8gMCxcclxuICAgICAgICAgIGxvYW5CYWxhbmNlOiBsb2FuPy5vdXRzdGFuZGluZyA/PyAwLFxyXG4gICAgICAgICAgcmVtYWluaW5nQmFsYW5jZTogbG9hbj8uYmFsYW5jZSA/PyAwLFxyXG4gICAgICAgICAgc3RhdHVzOiBsb2FuPy5zdGF0dXMgfHwgXCItXCIsXHJcbiAgICAgICAgICByZWZlcnJlZEJ5OiBsb2FuPy5yZWZlcnJlZEJ5IHx8IFwiTi9BXCIsXHJcbiAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICBzZXRMb2FuUmVwb3J0VGFibGUoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGxvYW4gcmVwb3J0OlwiLCBlcnJvcik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hMb2FuUmVwb3J0KCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCB1bmlxdWVMb2FuQ29tYm9zID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBtYXAgPSBuZXcgTWFwKCk7XHJcbiAgICBsb2FuUmVwb3J0VGFibGUuZm9yRWFjaCgobG9hbikgPT4ge1xyXG4gICAgICBjb25zdCBrZXkgPSBsb2FuLmxvYW5JZHM7XHJcbiAgICAgIGlmICghbWFwLmhhcyhrZXkpKSB7XHJcbiAgICAgICAgbWFwLnNldChrZXksIHsgaWQ6IGtleSwgbGFiZWw6IGAke2tleX0gfCDigrkke2xvYW4ubG9hbkFtb3VudFZhbHVlfWAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIEFycmF5LmZyb20obWFwLnZhbHVlcygpKTtcclxuICB9LCBbbG9hblJlcG9ydFRhYmxlXSk7XHJcblxyXG4gIGNvbnN0IHVuaXF1ZUN1c3RvbWVycyA9IHVzZU1lbW8oXHJcbiAgICAoKSA9PlxyXG4gICAgICBsb2FuUmVwb3J0VGFibGUubWFwKChsb2FuKSA9PiAoe1xyXG4gICAgICAgIGlkOiBsb2FuLmlkLFxyXG4gICAgICAgIG5hbWU6IGxvYW4uY3VzdG9tZXJOYW1lLFxyXG4gICAgICAgIHBob25lOiBsb2FuLmN1c3RvbWVyUGhvbmUsXHJcbiAgICAgICAgY3VzdGlkOiBsb2FuLmN1c3RvbWVySWQsXHJcbiAgICAgIH0pKSxcclxuICAgIFtsb2FuUmVwb3J0VGFibGVdLFxyXG4gICk7XHJcblxyXG4gIGNvbnN0IHVuaXF1ZVJlZmVycmVkQnkgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IHNldCA9IG5ldyBTZXQoKTtcclxuICAgIGxvYW5SZXBvcnRUYWJsZS5mb3JFYWNoKChsb2FuKSA9PiB7XHJcbiAgICAgIGlmIChsb2FuLnJlZmVycmVkQnkgJiYgbG9hbi5yZWZlcnJlZEJ5ICE9PSBcIk4vQVwiKSB7XHJcbiAgICAgICAgc2V0LmFkZChsb2FuLnJlZmVycmVkQnkpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIHJldHVybiBBcnJheS5mcm9tKHNldCk7XHJcbiAgfSwgW2xvYW5SZXBvcnRUYWJsZV0pO1xyXG5cclxuICBjb25zdCBmaWx0ZXJlZExvYW5SZXBvcnQgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiBsb2FuUmVwb3J0VGFibGUuZmlsdGVyKChsb2FuKSA9PiB7XHJcbiAgICAgIGNvbnN0IG1hdGNoTG9hbklkID0gc2VsZWN0ZWRMb2FuSWRcclxuICAgICAgICA/IGxvYW4ubG9hbklkcyA9PT0gc2VsZWN0ZWRMb2FuSWRcclxuICAgICAgICA6IHRydWU7XHJcbiAgICAgIGNvbnN0IG1hdGNoQ3VzdG9tZXIgPSBzZWxlY3RlZEN1c3RvbWVyXHJcbiAgICAgICAgPyBsb2FuLmlkID09PSBzZWxlY3RlZEN1c3RvbWVyXHJcbiAgICAgICAgOiB0cnVlO1xyXG4gICAgICBjb25zdCBtYXRjaFJlZmVycmVkQnkgPSBzZWxlY3RlZFJlZmVycmVkQnlcclxuICAgICAgICA/IGxvYW4ucmVmZXJyZWRCeSA9PT0gc2VsZWN0ZWRSZWZlcnJlZEJ5XHJcbiAgICAgICAgOiB0cnVlO1xyXG5cclxuICAgICAgLy8gTkVXOiBEYXRlIHJhbmdlIGZpbHRlcmluZ1xyXG4gICAgICBsZXQgbWF0Y2hEYXRlUmFuZ2UgPSB0cnVlO1xyXG4gICAgICBpZiAoZGF0ZVJhbmdlICYmIGRhdGVSYW5nZS5sZW5ndGggPT09IDIgJiYgbG9hbi5sb2FuU3RhcnREYXRlT2JqKSB7XHJcbiAgICAgICAgY29uc3Qgc3RhcnREYXRlID0gZGF5anMoZGF0ZVJhbmdlWzBdKS5zdGFydE9mKFwiZGF5XCIpO1xyXG4gICAgICAgIGNvbnN0IGVuZERhdGUgPSBkYXlqcyhkYXRlUmFuZ2VbMV0pLmVuZE9mKFwiZGF5XCIpO1xyXG4gICAgICAgIGNvbnN0IGxvYW5EYXRlID0gZGF5anMobG9hbi5sb2FuU3RhcnREYXRlT2JqKTtcclxuICAgICAgICBtYXRjaERhdGVSYW5nZSA9XHJcbiAgICAgICAgICBsb2FuRGF0ZS5pc0FmdGVyKHN0YXJ0RGF0ZSkgJiYgbG9hbkRhdGUuaXNCZWZvcmUoZW5kRGF0ZSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHJldHVybiBtYXRjaExvYW5JZCAmJiBtYXRjaEN1c3RvbWVyICYmIG1hdGNoUmVmZXJyZWRCeSAmJiBtYXRjaERhdGVSYW5nZTtcclxuICAgIH0pO1xyXG4gIH0sIFtcclxuICAgIGxvYW5SZXBvcnRUYWJsZSxcclxuICAgIHNlbGVjdGVkTG9hbklkLFxyXG4gICAgc2VsZWN0ZWRDdXN0b21lcixcclxuICAgIHNlbGVjdGVkUmVmZXJyZWRCeSxcclxuICAgIGRhdGVSYW5nZSxcclxuICBdKTtcclxuXHJcbiAgY29uc3Qgc3VtbWFyeVN0YXRzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCBmaWx0ZXJlZCA9IGZpbHRlcmVkTG9hblJlcG9ydDtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHRvdGFsTG9hbnM6IGZpbHRlcmVkLmxlbmd0aCxcclxuICAgICAgdG90YWxBbW91bnQ6IGZpbHRlcmVkLnJlZHVjZSgoc3VtLCBsb2FuKSA9PiBzdW0gKyBsb2FuLmxvYW5BbW91bnQsIDApLFxyXG4gICAgICB0b3RhbFBheWFibGU6IGZpbHRlcmVkLnJlZHVjZSgoc3VtLCBsb2FuKSA9PiBzdW0gKyBsb2FuLnBheWFibGVBbW91bnQsIDApLFxyXG4gICAgICB0b3RhbFBhaWQ6IGZpbHRlcmVkLnJlZHVjZSgoc3VtLCBsb2FuKSA9PiBzdW0gKyBsb2FuLnRvdGFsTG9hbkFtb3VudCwgMCksXHJcbiAgICAgIHRvdGFsQmFsYW5jZTogZmlsdGVyZWQucmVkdWNlKChzdW0sIGxvYW4pID0+IHN1bSArIGxvYW4ubG9hbkJhbGFuY2UsIDApLFxyXG4gICAgfTtcclxuICB9LCBbZmlsdGVyZWRMb2FuUmVwb3J0XSk7XHJcblxyXG4gIGNvbnN0IGxvYW5SZXBvcnRDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwic2xOb1wiLCBoZWFkZXI6IFwiU2wgTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwibG9hbklkc1wiLCBoZWFkZXI6IFwiTG9hbiBJRFwiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lck5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJQaG9uZVwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcInJlZmVycmVkQnlcIiwgaGVhZGVyOiBcIlJlZmVycmVkIEJ5XCIgfSxcclxuICAgIHsga2V5OiBcImxvYW5TYW5jdGlvbkRhdGVcIiwgaGVhZGVyOiBcIlNhbmN0aW9uIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwibG9hblN0YXJ0RGF0ZVwiLCBoZWFkZXI6IFwiTG9hbiBTdGFydCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImxvYW5FbmREYXRlXCIsIGhlYWRlcjogXCJMb2FuIEVuZCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImxvYW5TZXJ2aWNlQ2hhcmdlc1wiLCBoZWFkZXI6IFwiU2VydmljZSBDaGFyZ2VzXCIgfSxcclxuICAgIHsga2V5OiBcImxvYW5Eb2N1bWVudENoYXJnZXNcIiwgaGVhZGVyOiBcIkRvY3VtZW50YXRpb24gQ2hhcmdlc1wiIH0sXHJcbiAgICB7IGtleTogXCJkYWlseV9wYXltZW50X2Ftb3VudFwiLCBoZWFkZXI6IFwiRGFpbHkgSW5zdGFsbG1lbnRcIiB9LFxyXG4gICAgeyBrZXk6IFwibG9hbkFtb3VudFwiLCBoZWFkZXI6IFwiTG9hbiBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5YWJsZUxvYW5EYXlzXCIsIGhlYWRlcjogXCJMb2FuIEFnZSAoaW4gRGF5cylcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5YWJsZUFtb3VudFwiLCBoZWFkZXI6IFwiTG9hbiBQYXlhYmxlXCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsTG9hbkFtb3VudFwiLCBoZWFkZXI6IFwiVG90YWwgUGFpZFwiIH0sXHJcbiAgICB7IGtleTogXCJyZW1haW5pbmdCYWxhbmNlXCIsIGhlYWRlcjogXCJCYWxhbmNlXCIgfSxcclxuICAgIHsga2V5OiBcImxvYW5CYWxhbmNlXCIsIGhlYWRlcjogXCJPdXRTdGFuZGluZ1wiIH0sXHJcbiAgICB7IGtleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgU3RhdENhcmQgPSAoeyBpY29uOiBJY29uLCBsYWJlbCwgdmFsdWUsIGNvbG9yIH0pID0+IChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctc20gYm9yZGVyIHAtNlwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgbWItMVwiPntsYWJlbH08L3A+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPnt2YWx1ZX08L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BwLTMgcm91bmRlZC1sZyAke2NvbG9yfWB9PlxyXG4gICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LXdoaXRlXCIgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy1zY3JlZW5cIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCIgbXgtYXV0b1wiPlxyXG4gICAgICAgIHsvKiBIZWFkZXIgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XHJcbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxGaWxlVGV4dCBjbGFzc05hbWU9XCJ3LTcgaC03IHRleHQtdmlvbGV0LTYwMFwiIC8+IExvYW4gU3VtbWFyeSBSZXBvcnRcclxuICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIG1sLTEwXCI+XHJcbiAgICAgICAgICAgIE92ZXJ2aWV3IG9mIGN1c3RvbWVyIGxvYW5zLCBwYXltZW50cyAmIHJlZmVycmFsIGRldGFpbHNcclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGgtOTZcIj5cclxuICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPD5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJteS02XCI+XHJcbiAgICAgICAgICAgICAgPENvbGxhcHNlXHJcbiAgICAgICAgICAgICAgICBpdGVtcz17W1xyXG4gICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIHRleHQtYmFzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTaG9ydGN1dCBLZXlzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICBjaGlsZHJlbjogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIG1kOmdyaWQtY29scy01IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdG89XCIvb3RoZXItc2VydmljZS1tZW51L2xvYW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggdGV4dC1iYXNlIGl0ZW1zLWNlbnRlciBnYXAtMiBib3JkZXIgIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIHB4LTQgcHktMiB0ZXh0LWdyYXktNzAwIGhvdmVyOmJvcmRlci12aW9sZXQtNTAwIGhvdmVyOnRleHQtdmlvbGV0LTYwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFNb25leUJpbGwgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNTAwXCIgc2l6ZT17MzB9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQWRkIExvYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRvPVwiL3JlcG9ydHMvbG9hbi1kdWUtcmVwb3J0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IHRleHQtYmFzZSBpdGVtcy1jZW50ZXIgZ2FwLTIgYm9yZGVyICBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBweC00IHB5LTIgdGV4dC1ncmF5LTcwMCBob3Zlcjpib3JkZXItdmlvbGV0LTUwMCBob3Zlcjp0ZXh0LXZpb2xldC02MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPERvbGxhck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTUwMFwiIHNpemU9ezMwfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIE91dFN0YW5kaW5nIExvYW4gUmVwb3J0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdG89XCIvcmVwb3J0cy9sb2FuLWNvbXBsZXRpb24tcmVwb3J0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IHRleHQtYmFzZSBpdGVtcy1jZW50ZXIgZ2FwLTIgYm9yZGVyICBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBweC00IHB5LTIgdGV4dC1ncmF5LTcwMCBob3Zlcjpib3JkZXItdmlvbGV0LTUwMCBob3Zlcjp0ZXh0LXZpb2xldC02MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpbGVUZXh0T3V0bGluZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPXszMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIExvYW4gQ29tcGxldGlvbiBSZXBvcnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0QWN0aXZlS2V5PXtbXCIxXCJdfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMjAwIGJnLXdoaXRlIHNoYWRvdy1zbVwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHsvKiBTdW1tYXJ5IENhcmRzICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgIHsvKiBUb3RhbCBMb2FucyAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgIDxTdGF0Q2FyZFxyXG4gICAgICAgICAgICAgICAgICBpY29uPXtGaWxlVGV4dH1cclxuICAgICAgICAgICAgICAgICAgbGFiZWw9XCJUb3RhbCBMb2Fuc1wiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdW1tYXJ5U3RhdHMudG90YWxMb2Fuc31cclxuICAgICAgICAgICAgICAgICAgY29sb3I9XCJiZy12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgZm9udC1tb25vIHRleHQtZ3JlZW4tNzAwIGJyZWFrLXdvcmRzIHB4LTFcIj5cclxuICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoc3VtbWFyeVN0YXRzLnRvdGFsTG9hbnMgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBUb3RhbCBMb2FuIEFtb3VudCAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgIDxTdGF0Q2FyZFxyXG4gICAgICAgICAgICAgICAgICBpY29uPXtJbmRpYW5SdXBlZX1cclxuICAgICAgICAgICAgICAgICAgbGFiZWw9XCJUb3RhbCBMb2FuIEFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtg4oK5JHtzdW1tYXJ5U3RhdHMudG90YWxBbW91bnR9YH1cclxuICAgICAgICAgICAgICAgICAgY29sb3I9XCJiZy1wdXJwbGUtNjAwXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgZm9udC1tb25vIHRleHQtZ3JlZW4tNzAwIGJyZWFrLXdvcmRzIHB4LTFcIj5cclxuICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoc3VtbWFyeVN0YXRzLnRvdGFsQW1vdW50IHx8IDApfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogVG90YWwgUGF5YWJsZSAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgIDxTdGF0Q2FyZFxyXG4gICAgICAgICAgICAgICAgICBpY29uPXtUcmVuZGluZ1VwfVxyXG4gICAgICAgICAgICAgICAgICBsYWJlbD1cIlRvdGFsIFBheWFibGVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17YOKCuSR7c3VtbWFyeVN0YXRzLnRvdGFsUGF5YWJsZX1gfVxyXG4gICAgICAgICAgICAgICAgICBjb2xvcj1cImJnLXZpb2xldC02MDBcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyBmb250LW1vbm8gdGV4dC1ncmVlbi03MDAgYnJlYWstd29yZHMgcHgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhzdW1tYXJ5U3RhdHMudG90YWxQYXlhYmxlIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogVG90YWwgUGFpZCAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgIDxTdGF0Q2FyZFxyXG4gICAgICAgICAgICAgICAgICBpY29uPXtUcmVuZGluZ1VwfVxyXG4gICAgICAgICAgICAgICAgICBsYWJlbD1cIlRvdGFsIFBhaWRcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17YOKCuSR7c3VtbWFyeVN0YXRzLnRvdGFsUGFpZH1gfVxyXG4gICAgICAgICAgICAgICAgICBjb2xvcj1cImJnLWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LWdyZWVuLTcwMCBicmVhay13b3JkcyBweC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKHN1bW1hcnlTdGF0cy50b3RhbFBhaWQgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBUb3RhbCBCYWxhbmNlICovfVxyXG4gICAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgIDxTdGF0Q2FyZFxyXG4gICAgICBpY29uPXtDYWxlbmRhcn1cclxuICAgICAgbGFiZWw9XCJUb3RhbCBCYWxhbmNlXCJcclxuICAgICAgdmFsdWU9e2Digrkke3N1bW1hcnlTdGF0cy50b3RhbEJhbGFuY2V9YH1cclxuICAgICAgY29sb3I9XCJiZy1vcmFuZ2UtNjAwXCJcclxuICAgIC8+XHJcbiAgICA8c3BhbiBjbGFzc05hbWU9XCJtdC0yIHRleHQteHMgZm9udC1tb25vIHRleHQtZ3JlZW4tNzAwIGJyZWFrLXdvcmRzIHB4LTFcIj5cclxuICAgICAge251bWJlclRvSW5kaWFuV29yZHMoc3VtbWFyeVN0YXRzLnRvdGFsQmFsYW5jZSB8fCAwKX1cclxuICAgIDwvc3Bhbj5cclxuICA8L2Rpdj4gKi99XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIEZJTFRFUlMgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctc20gYm9yZGVyIHAtNiBtYi04XCI+XHJcbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPiBGaWx0ZXIgT3B0aW9uc1xyXG4gICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgICAgey8qIExvYW4gRmlsdGVyICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIExvYW4gSUQgJiBBbW91bnRcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBsb2FuXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRMb2FuSWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFNlbGVjdGVkTG9hbklkfVxyXG4gICAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGwgTG9hbnM8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAge3VuaXF1ZUxvYW5Db21ib3MubWFwKChsb2FuKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2xvYW4uaWR9IHZhbHVlPXtsb2FuLmlkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2xvYW4ubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIEN1c3RvbWVyIEZpbHRlciAqL31cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBDdXN0b21lclxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IGN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRDdXN0b21lcn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRDdXN0b21lcn1cclxuICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiXCI+QWxsIEN1c3RvbWVyczwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICB7dW5pcXVlQ3VzdG9tZXJzLm1hcCgoY3VzdCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtjdXN0LmlkfSB2YWx1ZT17Y3VzdC5pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtjdXN0LmN1c3RpZH0gfCB7Y3VzdC5uYW1lfSB8IHtjdXN0LnBob25lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBSZWZlcnJlZCBCeSBGaWx0ZXIgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUmVmZXJyZWQgQnlcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCByZWZlcnJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkUmVmZXJyZWRCeX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRSZWZlcnJlZEJ5fVxyXG4gICAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGwgUmVmZXJyZWQgQnk8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAge3VuaXF1ZVJlZmVycmVkQnkubWFwKChyZWYpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17cmVmfSB2YWx1ZT17cmVmfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3JlZn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogTkVXOiBEYXRlIFJhbmdlIEZpbHRlciAqL31cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBTdGFydCBEYXRlIFJhbmdlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxSYW5nZVBpY2tlclxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkYXRlUmFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldERhdGVSYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZvcm1hdD1cIkREL01NL1lZWVlcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFRBQkxFICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LXNjcmVlblwiPlxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgIGNvbHVtbnM9e2xvYW5SZXBvcnRDb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyZWRMb2FuUmVwb3J0fVxyXG4gICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtbXHJcbiAgICAgICAgICAgICAgICAgIFwiVG90YWwgTG9hbnNcIixcclxuICAgICAgICAgICAgICAgICAgXCJUb3RhbCBMb2FuIEFtb3VudFwiLFxyXG4gICAgICAgICAgICAgICAgICBcIlRvdGFsIFBheWFibGVcIixcclxuICAgICAgICAgICAgICAgICAgXCJUb3RhbCBQYWlkXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiVG90YWwgT3V0c3RhbmRpbmdcIixcclxuICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICBwcmludEhlYWRlclZhbHVlcz17W1xyXG4gICAgICAgICAgICAgICAgICBzdW1tYXJ5U3RhdHMudG90YWxMb2Fucy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpLFxyXG4gICAgICAgICAgICAgICAgICBg4oK5ICR7c3VtbWFyeVN0YXRzLnRvdGFsQW1vdW50LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgICAgICAgICAgICAgICAgYOKCuSAke3N1bW1hcnlTdGF0cy50b3RhbFBheWFibGUudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gLFxyXG4gICAgICAgICAgICAgICAgICBg4oK5ICR7c3VtbWFyeVN0YXRzLnRvdGFsUGFpZC50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWAsXHJcbiAgICAgICAgICAgICAgICAgIGDigrkgJHtzdW1tYXJ5U3RhdHMudG90YWxCYWxhbmNlLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJDdXN0b21lciBMb2FuIFJlcG9ydFwiXHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiQ3VzdG9tZXIgTG9hbiBSZXBvcnQuY3N2XCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEN1c3RvbWVyTG9hblJlcG9ydDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0N1c3RvbWVyTG9hblJlcG9ydC5qc3gifQ==