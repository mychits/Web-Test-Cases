import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AdminAccessRights.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import SettingSidebar from "/src/components/layouts/SettingSidebar.jsx";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { Input, Dropdown } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
const getAccessRightsErrorMessage = (error) => {
  const response = error?.response?.data;
  if (typeof response?.message === "string" && response.message) return response.message;
  if (typeof response?.error === "string" && response.error) return response.error;
  return "An unexpected error occurred. Please try again.";
};
const AdminAccessRights = () => {
  _s();
  const [users, setUsers] = useState([]);
  const [TableAgents, setTableAgents] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [currentUpdateUser, setCurrentUpdateUser] = useState(null);
  const [errors, setErrors] = useState({});
  const [searchText, setSearchText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [formData, setFormData] = useState({
    title: "",
    access_permissions: {
      view_dashboard: "",
      view_analytics: "",
      add_group: "",
      view_group: "",
      edit_group: "",
      delete_group: "",
      add_customer: "",
      view_customer: "",
      edit_customer: "",
      delete_customer: "",
      add_enrollment: "",
      delete_enrollment: "",
      view_enrollment: "",
      edit_enrollment: "",
      add_employee: "",
      view_employee: "",
      edit_employee: "",
      delete_employee: "",
      modify_payment_date: "",
      add_lead: "",
      view_lead: "",
      edit_lead: "",
      delete_lead: "",
      add_loan: "",
      view_loan: "",
      edit_loan: "",
      delete_loan: "",
      add_pigme: "",
      view_pigme: "",
      edit_pigme: "",
      delete_pigme: "",
      add_auction: "",
      view_auction: "",
      edit_auction: "",
      delete_auction: "",
      add_payment: "",
      view_payment: "",
      edit_payment: "",
      edit_limited_payment: "",
      delete_payment: "",
      view_reports: "",
      view_daybook: "",
      view_group_report: "",
      view_all_customer_report: "",
      view_customer_report: "",
      view_receipt_report: "",
      view_auction_report: "",
      view_lead_report: "",
      view_pigme_report: "",
      view_loan_report: "",
      view_agent_report: "",
      view_target: "",
      view_mobile_options: "",
      view_suspense_payments: "",
      unlink_enrollment: ""
    }
  });
  const [updateFormData, setUpdateFormData] = useState({
    title: "",
    access_permissions: {
      view_dashboard: "",
      view_analytics: "",
      add_group: "",
      view_group: "",
      edit_group: "",
      delete_group: "",
      add_customer: "",
      view_customer: "",
      edit_customer: "",
      delete_customer: "",
      add_enrollment: "",
      delete_enrollment: "",
      view_enrollment: "",
      edit_enrollment: "",
      add_employee: "",
      view_employee: "",
      edit_employee: "",
      delete_employee: "",
      modify_payment_date: "",
      add_lead: "",
      view_lead: "",
      edit_lead: "",
      delete_lead: "",
      add_loan: "",
      view_loan: "",
      edit_loan: "",
      delete_loan: "",
      add_pigme: "",
      view_pigme: "",
      edit_pigme: "",
      delete_pigme: "",
      add_auction: "",
      view_auction: "",
      edit_auction: "",
      delete_auction: "",
      add_payment: "",
      view_payment: "",
      edit_payment: "",
      edit_limited_payment: "",
      delete_payment: "",
      view_reports: "",
      view_daybook: "",
      view_group_report: "",
      view_all_customer_report: "",
      view_customer_report: "",
      view_receipt_report: "",
      view_auction_report: "",
      view_lead_report: "",
      view_pigme_report: "",
      view_loan_report: "",
      view_agent_report: "",
      view_target: "",
      view_mobile_options: "",
      view_suspense_payments: "",
      unlink_enrollment: ""
    }
  });
  useEffect(() => {
    const fetchAdminRights = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/admin-access-rights/get-all");
        setUsers(response.data);
        const formattedData = response.data.map((adminAccess, index) => ({
          _id: adminAccess?._id,
          id: index + 1,
          title: adminAccess?.title,
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center  gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-green-600",
                        onClick: () => handleUpdateModalOpen(adminAccess?._id),
                        children: "Edit"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                        lineNumber: 186,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-red-600",
                        onClick: () => handleDeleteModalOpen(adminAccess?._id),
                        children: "Delete"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                        lineNumber: 199,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 213,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 180,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 179,
            columnNumber: 11
          }, this)
        }));
        setTableAgents(formattedData);
      } catch (error) {
        console.error("Error fetching Admin Access data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchAdminRights();
  }, [reloadTrigger]);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevData) => ({
      ...prevData,
      [name]: ""
    }));
  };
  const validateForm = (type) => {
    const newErrors = {};
    const data = type === "addAccessRights" ? formData : updateFormData;
    if (!data.title.trim()) {
      newErrors.name = "Title is required";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValidate = validateForm("addAccessRights");
    try {
      if (isValidate) {
        const response = await api.post("/admin-access-rights/add", formData, {
          headers: {
            "Content-Type": "application/json"
          }
        });
        setShowModal(false);
        setReloadTrigger((prev) => prev + 1);
        setFormData({
          title: "",
          access_permissions: {
            view_dashboard: "",
            view_analytics: "",
            add_group: "",
            view_group: "",
            edit_group: "",
            delete_group: "",
            add_customer: "",
            view_customer: "",
            edit_customer: "",
            delete_customer: "",
            add_enrollment: "",
            view_enrollment: "",
            edit_enrollment: "",
            delete_enrollment: "",
            add_employee: "",
            view_employee: "",
            edit_employee: "",
            delete_employee: "",
            modify_payment_date: "",
            add_lead: "",
            view_lead: "",
            edit_lead: "",
            delete_lead: "",
            add_loan: "",
            view_loan: "",
            edit_loan: "",
            delete_loan: "",
            add_pigme: "",
            view_pigme: "",
            edit_pigme: "",
            delete_pigme: "",
            add_auction: "",
            view_auction: "",
            edit_auction: "",
            delete_auction: "",
            add_payment: "",
            view_payment: "",
            edit_payment: "",
            edit_limited_payment: "",
            delete_payment: "",
            view_reports: "",
            view_daybook: "",
            view_group_report: "",
            view_all_customer_report: "",
            view_customer_report: "",
            view_receipt_report: "",
            view_auction_report: "",
            view_lead_report: "",
            view_pigme_report: "",
            view_loan_report: "",
            view_agent_report: "",
            view_target: "",
            view_mobile_options: "",
            unlink_enrollment: ""
          }
        });
        setAlertConfig({
          visibility: true,
          message: "Access Rights Added Successfully",
          type: "success"
        });
      }
    } catch (error) {
      console.error("Error adding Access Rights:", error);
      setAlertConfig({
        visibility: true,
        message: getAccessRightsErrorMessage(error),
        type: "error"
      });
    }
  };
  useEffect(() => {
    const fetchAdminRights = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/admin-access-rights/get-all");
        setUsers(response.data);
        const formattedData = response.data.map((adminAccess, index) => ({
          _id: adminAccess?._id,
          id: index + 1,
          title: adminAccess?.title,
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center  gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-green-600",
                        onClick: () => handleUpdateModalOpen(adminAccess?._id),
                        children: "Edit"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                        lineNumber: 373,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-red-600",
                        onClick: () => handleDeleteModalOpen(adminAccess?._id),
                        children: "Delete"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                        lineNumber: 386,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 400,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 367,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 366,
            columnNumber: 11
          }, this)
        }));
        setTableAgents(formattedData);
      } catch (error) {
        console.error("Error fetching Admin Access data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchAdminRights();
  }, [reloadTrigger]);
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "title", header: "Admin Access Title" },
    { key: "action", header: "Action" }
  ];
  const filteredUsers = users.filter(
    (user) => user.title.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const handleDeleteModalOpen = async (userId) => {
    try {
      const response = await api.get(
        `/admin-access-rights/get-by-id/${userId}`
      );
      setCurrentUser(response.data);
      setShowModalDelete(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching user:", error);
    }
  };
  const handleUpdateModalOpen = async (userId) => {
    try {
      const response = await api.get(
        `/admin-access-rights/get-by-id/${userId}`
      );
      setCurrentUpdateUser(response.data);
      setUpdateFormData({
        title: response.data.title,
        access_permissions: {
          view_dashboard: response.data?.access_permissions?.view_dashboard === "true" || response.data?.access_permission?.view_dashboard === true,
          view_analytics: response.data?.access_permissions?.view_analytics === "true" || response.data?.access_permission?.view_analytics === true,
          add_group: response.data?.access_permissions?.add_group === "true" || response.data?.access_permission?.add_group === true,
          view_group: response.data?.access_permissions?.view_group === "true" || response.data?.access_permission?.view_group === true,
          edit_group: response.data?.access_permissions?.edit_group === "true" || response.data?.access_permission?.edit_group === true,
          delete_group: response.data?.access_permissions?.delete_group === "true" || response.data?.access_permission?.delete_group === true,
          add_customer: response.data?.access_permissions?.add_customer === "true" || response.data?.access_permission?.add_customer === true,
          view_customer: response.data?.access_permissions?.view_customer === "true" || response.data?.access_permission?.view_customer === true,
          edit_customer: response.data?.access_permissions?.edit_customer === "true" || response.data?.access_permission?.edit_customer === true,
          delete_customer: response.data?.access_permissions?.delete_customer === "true" || response.data?.access_permission?.delete_customer === true,
          add_enrollment: response.data?.access_permissions?.add_enrollment === "true" || response.data?.access_permission?.add_enrollment === true,
          delete_enrollment: response.data?.access_permissions?.delete_enrollment === "true" || response.data?.access_permission?.delete_enrollment === true,
          view_enrollment: response.data?.access_permissions?.view_enrollment === "true" || response.data?.access_permission?.view_enrollment === true,
          edit_enrollment: response.data?.access_permissions?.edit_enrollment === "true" || response.data?.access_permission?.edit_enrollment === true,
          add_employee: response.data?.access_permissions?.add_employee === "true" || response.data?.access_permission?.add_employee === true,
          view_employee: response.data?.access_permissions?.view_employee === "true" || response.data?.access_permission?.view_employee === true,
          edit_employee: response.data?.access_permissions?.edit_employee === "true" || response.data?.access_permission?.edit_employee === true,
          delete_employee: response.data?.access_permissions?.delete_employee === "true" || response.data?.access_permission?.delete_employee === true,
          modify_payment_date: response.data?.access_permissions?.modify_payment_date === "true" || response.data?.access_permission?.modify_payment_date === true,
          add_lead: response.data?.access_permissions?.add_lead === "true" || response.data?.access_permission?.add_lead === true,
          view_lead: response.data?.access_permissions?.view_lead === "true" || response.data?.access_permission?.view_lead === true,
          edit_lead: response.data?.access_permissions?.edit_lead === "true" || response.data?.access_permission?.edit_lead === true,
          delete_lead: response.data?.access_permissions?.delete_lead === "true" || response.data?.access_permission?.delete_lead === true,
          add_loan: response.data?.access_permissions?.add_loan === "true" || response.data?.access_permission?.add_loan === true,
          view_loan: response.data?.access_permissions?.view_loan === "true" || response.data?.access_permission?.view_loan === true,
          edit_loan: response.data?.access_permissions?.edit_loan === "true" || response.data?.access_permission?.edit_loan === true,
          delete_loan: response.data?.access_permissions?.delete_loan === "true" || response.data?.access_permission?.delete_loan === true,
          add_pigme: response.data?.access_permissions?.add_pigme === "true" || response.data?.access_permission?.add_pigme === true,
          view_pigme: response.data?.access_permissions?.view_pigme === "true" || response.data?.access_permission?.view_pigme === true,
          edit_pigme: response.data?.access_permissions?.edit_pigme === "true" || response.data?.access_permission?.edit_pigme === true,
          delete_pigme: response.data?.access_permissions?.delete_pigme === "true" || response.data?.access_permission?.delete_pigme === true,
          add_auction: response.data?.access_permissions?.add_auction === "true" || response.data?.access_permission?.add_auction === true,
          view_auction: response.data?.access_permissions?.view_auction === "true" || response.data?.access_permission?.view_auction === true,
          edit_auction: response.data?.access_permissions?.edit_auction === "true" || response.data?.access_permission?.edit_auction === true,
          delete_auction: response.data?.access_permissions?.delete_auction === "true" || response.data?.access_permission?.delete_auction === true,
          add_payment: response.data?.access_permissions?.add_payment === "true" || response.data?.access_permission?.add_payment === true,
          view_payment: response.data?.access_permissions?.view_payment === "true" || response.data?.access_permission?.view_payment === true,
          edit_payment: response.data?.access_permissions?.edit_payment === "true" || response.data?.access_permission?.edit_payment === true,
          edit_limited_payment: response.data?.access_permissions?.edit_limited_payment === "true" || response.data?.access_permission?.edit_limited_payment === true,
          delete_payment: response.data?.access_permissions?.delete_payment === "true" || response.data?.access_permission?.delete_payment === true,
          view_reports: response.data?.access_permissions?.view_reports === "true" || response.data?.access_permission?.view_reports === true,
          view_daybook: response.data?.access_permissions?.view_daybook === "true" || response.data?.access_permission?.view_daybook === true,
          view_group_report: response.data?.access_permissions?.view_group_report === "true" || response.data?.access_permission?.view_group_report === true,
          view_all_customer_report: response.data?.access_permissions?.view_all_customer_report === "true" || response.data?.access_permission?.view_all_customer_report === true,
          view_customer_report: response.data?.access_permissions?.view_customer_report === "true" || response.data?.access_permission?.view_customer_report === true,
          view_receipt_report: response.data?.access_permissions?.view_receipt_report === "true" || response.data?.access_permission?.view_receipt_report === true,
          view_auction_report: response.data?.access_permissions?.view_auction_report === "true" || response.data?.access_permission?.view_auction_report === true,
          view_lead_report: response.data?.access_permissions?.view_lead_report === "true" || response.data?.access_permission?.view_lead_report === true,
          view_pigme_report: response.data?.access_permissions?.view_pigme_report === "true" || response.data?.access_permission?.view_pigme_report === true,
          view_loan_report: response.data?.access_permissions?.view_loan_report === "true" || response.data?.access_permission?.view_loan_report === true,
          view_agent_report: response.data?.access_permissions?.view_agent_report === "true" || response.data?.access_permission?.view_agent_report === true,
          view_target: response.data?.access_permissions?.view_target === "true" || response.data?.access_permission?.view_target === true,
          view_mobile_options: response.data?.access_permissions?.view_mobile_options === "true" || response.data?.access_permission?.view_mobile_options === true,
          view_suspense_payments: response.data?.access_permissions?.view_suspense_payments === "true" || response.data?.access_permission?.view_suspense_payments === true,
          unlink_enrollment: response.data?.access_permission?.unlink_enrollment === "true" || response.data?.access_permission?.unlink_enrollment === true
        }
      });
      setShowModalUpdate(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching user:", error);
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  const handleDeleteUser = async () => {
    if (currentUser) {
      try {
        await api.delete(
          `/admin-access-rights/delete-by-id/${currentUser._id}`
        );
        setShowModalDelete(false);
        setCurrentUser(null);
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "Manager deleted successfully",
          type: "success"
        });
      } catch (error) {
        console.error("Error deleting manager:", error);
      }
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    try {
      if (isValid) {
        const response = await api.put(
          `/admin-access-rights/update-by-id/${currentUpdateUser._id}`,
          updateFormData
        );
        setShowModalUpdate(false);
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "Designation Updated Successfully",
          type: "success"
        });
      }
    } catch (error) {
      console.error("Error updating Designation:", error);
      setAlertConfig({
        visibility: true,
        message: getAccessRightsErrorMessage(error),
        type: "error"
      });
    }
  };
  useEffect(() => {
    const fetchAdminAccessRights = async () => {
      try {
        const response = await api.get(
          "/admin-access-rights/admin-access-rights"
        );
        setManagers(response.data);
      } catch (error) {
        console.error("Error fetching admin access rights:", error);
      }
    };
    fetchAdminAccessRights();
  }, [reloadTrigger]);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 696,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(SettingSidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
        lineNumber: 700,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 701,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Admin Access Rights" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 713,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowModal(true);
                setErrors({});
              },
              className: "ml-4 bg-blue-950 text-white px-4 py-2 rounded shadow-md hover:bg-blue-800 transition duration-200",
              children: "+ Create Access Role"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 714,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 712,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 711,
          columnNumber: 13
        }, this),
        TableAgents.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            updateHandler: handleUpdateModalOpen,
            data: filterOption(TableAgents, searchText),
            columns,
            exportedPdfName: `Admin Access Rights-${(/* @__PURE__ */ new Date()).toISOString()?.split("T")[0]}`,
            exportedFileName: `Admin Access Rights Employees.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 726,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: TableAgents.length <= 0,
            data: "Admin Access Role Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 736,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
        lineNumber: 710,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
      lineNumber: 695,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Create Access Role" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
        lineNumber: 747,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "email",
              children: [
                "Title ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 756,
                  columnNumber: 25
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 752,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "text",
              name: "title",
              value: formData.title,
              onChange: handleChange,
              id: "title",
              placeholder: "Enter the title",
              required: true,
              className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 758,
              columnNumber: 17
            },
            this
          ),
          errors.name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.title }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 769,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 751,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: /* @__PURE__ */ jsxDEV("label", { className: "text-lg font-bold", children: "Access Permissions" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 773,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 772,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Dashboard" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 777,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_dashboard,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_dashboard: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 781,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 795,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_dashboard ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 796,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 780,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 776,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Analytics" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 803,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_analytics,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_analytics: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 807,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 821,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_analytics ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 822,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 806,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 802,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Add Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 829,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.add_group,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    add_group: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 833,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 847,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.add_group ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 848,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 832,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 828,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 855,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_group,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_group: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 859,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 873,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_group ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 874,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 858,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 854,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Edit Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 881,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.edit_group,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    edit_group: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 885,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 899,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.edit_group ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 900,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 884,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 880,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Delete Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 907,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.delete_group,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    delete_group: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 911,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 925,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.delete_group ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 926,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 910,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 906,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Add Customer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 933,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.add_customer,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    add_customer: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 937,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 951,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.add_customer ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 952,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 936,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 932,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Customer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 959,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_customer,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_customer: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 963,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 977,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_customer ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 978,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 962,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 958,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Edit Customer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 985,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.edit_customer,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    edit_customer: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 989,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1003,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.edit_customer ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1004,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 988,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 984,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Delete Customer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1011,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.delete_customer,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    delete_customer: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1015,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1029,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.delete_customer ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1030,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1014,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1010,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Add Enrollment" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1037,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.add_enrollment,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    add_enrollment: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1041,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1055,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.add_enrollment ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1056,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1040,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1036,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Enrollment" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1062,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_enrollment,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_enrollment: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1066,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1080,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_enrollment ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1081,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1065,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1061,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Edit Enrollment" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1088,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.edit_enrollment,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    edit_enrollment: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1092,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1106,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.edit_enrollment ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1107,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1091,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1087,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Delete Enrollment" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1113,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.delete_enrollment,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    delete_enrollment: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1117,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1131,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.delete_enrollment ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1132,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1116,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1112,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Add Employee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1141,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.add_employee,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    add_employee: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1145,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1159,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.add_employee ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1160,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1144,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1140,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Employee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1167,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_employee,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_employee: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1171,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1185,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_employee ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1186,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1170,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1166,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Edit Employee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1193,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.edit_employee,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    edit_employee: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1197,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1211,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.edit_employee ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1212,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1196,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1192,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Delete Employee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1219,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.delete_employee,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    delete_employee: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1223,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1237,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.delete_employee ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1238,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1222,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1218,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Modify Payment Date" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1245,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.modify_payment_date,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    modify_payment_date: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1249,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1263,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.modify_payment_date ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1264,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1248,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1244,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Add Lead" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1273,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.add_lead,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    add_lead: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1277,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1291,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.add_lead ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1292,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1276,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1272,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Lead" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1299,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_lead,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_lead: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1303,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1317,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_lead ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1318,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1302,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1298,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Edit Lead" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1325,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.edit_lead,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    edit_lead: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1329,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1343,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.edit_lead ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1344,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1328,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1324,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Delete Lead" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1351,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.delete_lead,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    delete_lead: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1355,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1369,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.delete_lead ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1370,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1354,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1350,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Add Loan" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1377,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.add_loan,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    add_loan: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1381,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1395,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.add_loan ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1396,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1380,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1376,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Loan" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1403,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_loan,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_loan: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1407,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1421,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_loan ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1422,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1406,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1402,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Edit Loan" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1429,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.edit_loan,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    edit_loan: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1433,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1447,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.edit_loan ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1448,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1432,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1428,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Delete Loan" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1455,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.delete_loan,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    delete_loan: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1459,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1473,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.delete_loan ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1474,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1458,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1454,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Add Pigme" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1481,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.add_pigme,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    add_pigme: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1485,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1499,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.add_pigme ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1500,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1484,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1480,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Pigme" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1507,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_pigme,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_pigme: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1511,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1525,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_pigme ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1526,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1510,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1506,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Edit Pigme" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1533,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.edit_pigme,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    edit_pigme: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1537,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1551,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.edit_pigme ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1552,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1536,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1532,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Delete Pigme" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1559,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.delete_pigme,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    delete_pigme: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1563,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1577,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.delete_pigme ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1578,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1562,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1558,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Add Auction" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1585,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.add_auction,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    add_auction: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1589,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1603,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.add_auction ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1604,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1588,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1584,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Auction" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1611,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_auction,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_auction: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1615,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1629,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_auction ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1630,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1614,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1610,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Edit Auction" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1637,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.edit_auction,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    edit_auction: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1641,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1655,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.edit_auction ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1656,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1640,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1636,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Delete Auction" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1663,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.delete_auction,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    delete_auction: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1667,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1681,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.delete_auction ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1682,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1666,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1662,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Add Payment" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1689,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.add_payment,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    add_payment: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1693,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1707,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.add_payment ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1708,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1692,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1688,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Payment" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1715,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_payment,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_payment: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1719,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1733,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_payment ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1734,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1718,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1714,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Edit Payment" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1741,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.edit_payment,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    edit_payment: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1745,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1759,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.edit_payment ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1760,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1744,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1740,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Edit Limited Payment" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1767,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.edit_limited_payment,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    edit_limited_payment: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1771,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1785,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.edit_limited_payment ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1786,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1770,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1766,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Unlink Enrollment" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1792,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.unlink_enrollment,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    unlink_enrollment: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1796,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1810,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.unlink_enrollment ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1811,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1795,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1791,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Delete Payment" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1818,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.delete_payment,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    delete_payment: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1822,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1836,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.delete_payment ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1837,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1821,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1817,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Reports" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1844,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_reports,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_reports: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1848,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1862,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_reports ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1863,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1847,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1843,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Daybook" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1870,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_daybook,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_daybook: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1874,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1888,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_daybook ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1889,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1873,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1869,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Group Report" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1896,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_group_report,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_group_report: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1900,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1914,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_group_report ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1915,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1899,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1895,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View All Customer Report" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1924,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_all_customer_report,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_all_customer_report: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1928,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1944,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_all_customer_report ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1945,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1927,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1923,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Customer Report" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1954,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_customer_report,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_customer_report: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1958,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1972,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_customer_report ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 1973,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1957,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1953,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Receipt Report" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1982,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_receipt_report,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_receipt_report: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 1986,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2e3,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_receipt_report ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2001,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 1985,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 1981,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Auction Report" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 2010,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_auction_report,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_auction_report: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2014,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2028,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_auction_report ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2029,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 2013,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 2009,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Lead Report" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 2038,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_lead_report,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_lead_report: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2042,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2056,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_lead_report ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2057,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 2041,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 2037,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Pigme Report" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 2066,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_pigme_report,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_pigme_report: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2070,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2084,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_pigme_report ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2085,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 2069,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 2065,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Loan Report" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 2094,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_loan_report,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_loan_report: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2098,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2112,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_loan_report ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2113,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 2097,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 2093,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Agent Report" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 2122,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_agent_report,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_agent_report: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2126,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2140,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_agent_report ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2141,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 2125,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 2121,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Target" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 2150,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_target,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_target: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2154,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2166,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_target ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2167,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 2153,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 2149,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-4", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Mobile Options" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 2176,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "checkbox",
                checked: formData.access_permissions.view_mobile_options,
                onChange: (e) => setFormData({
                  ...formData,
                  access_permissions: {
                    ...formData.access_permissions,
                    view_mobile_options: e.target.checked
                  }
                }),
                className: "sr-only peer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2180,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2192,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: formData.access_permissions.view_mobile_options ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2193,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 2179,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 2175,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800\r\n              focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center border-2 border-black",
            children: "Save Access Roles"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 2205,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 2204,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
        lineNumber: 750,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
      lineNumber: 746,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
      lineNumber: 745,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Access Rights" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 2222,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: [
                    "Title ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                      lineNumber: 2232,
                      columnNumber: 25
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2228,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "title",
                  value: updateFormData.title,
                  onChange: handleInputChange,
                  id: "title",
                  placeholder: "Enter the Title",
                  required: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2234,
                  columnNumber: 17
                },
                this
              ),
              errors.title && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.title }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2245,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2227,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Dashboard" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2249,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_dashboard,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_dashboard: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2253,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2267,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_dashboard ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2268,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2252,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2248,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Analytics" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2277,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_analytics,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_analytics: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2281,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2295,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_analytics ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2296,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2280,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2276,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Add Group" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2305,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.add_group,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        add_group: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2309,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2323,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.add_group ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2324,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2308,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2304,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Group" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2331,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_group,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_group: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2335,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2349,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_group ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2350,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2334,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2330,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Edit Group" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2359,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.edit_group,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        edit_group: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2363,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2377,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.edit_group ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2378,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2362,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2358,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Delete Group" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2387,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.delete_group,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        delete_group: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2391,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2405,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.delete_group ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2406,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2390,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2386,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Add Customer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2415,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.add_customer,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        add_customer: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2419,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2433,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.add_customer ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2434,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2418,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2414,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Customer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2443,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_customer,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_customer: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2447,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2461,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_customer ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2462,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2446,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2442,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Edit Customer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2471,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.edit_customer,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        edit_customer: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2475,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2489,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.edit_customer ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2490,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2474,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2470,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Delete Customer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2499,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.delete_customer,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        delete_customer: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2503,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2517,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.delete_customer ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2518,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2502,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2498,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Add Enrollment" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2527,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.add_enrollment,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        add_enrollment: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2531,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2545,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.add_enrollment ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2546,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2530,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2526,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Delete Enrollment" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2555,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.delete_enrollment,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        delete_enrollment: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2559,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2575,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.delete_enrollment ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2576,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2558,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2554,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Enrollment" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2585,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_enrollment,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_enrollment: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2589,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2603,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_enrollment ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2604,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2588,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2584,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Edit Enrollment" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2613,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.edit_enrollment,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        edit_enrollment: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2617,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2631,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.edit_enrollment ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2632,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2616,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2612,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Add Employee" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2641,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.add_employee,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        add_employee: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2645,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2659,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.add_employee ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2660,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2644,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2640,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Employee" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2669,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_employee,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_employee: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2673,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2687,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_employee ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2688,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2672,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2668,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Edit Employee" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2697,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.edit_employee,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        edit_employee: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2701,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2715,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.edit_employee ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2716,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2700,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2696,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Delete Employee" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2725,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.delete_employee,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        delete_employee: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2729,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2743,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.delete_employee ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2744,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2728,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2724,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Modify Payment Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2753,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.modify_payment_date,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        modify_payment_date: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2757,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2773,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.modify_payment_date ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2774,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2756,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2752,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Add Lead" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2783,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.add_lead,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        add_lead: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2787,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2801,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.add_lead ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2802,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2786,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2782,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Lead" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2809,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_lead,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_lead: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2813,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2827,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_lead ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2828,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2812,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2808,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Edit Lead" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2835,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.edit_lead,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        edit_lead: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2839,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2853,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.edit_lead ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2854,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2838,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2834,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Delete Lead" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2861,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.delete_lead,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        delete_lead: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2865,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2879,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.delete_lead ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2880,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2864,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2860,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Add Loan" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2889,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.add_loan,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        add_loan: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2893,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2907,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.add_loan ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2908,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2892,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2888,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Loan" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2915,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_loan,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_loan: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2919,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2933,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_loan ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2934,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2918,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2914,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Edit Loan" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2941,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.edit_loan,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        edit_loan: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2945,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2959,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.edit_loan ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2960,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2944,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2940,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Delete Loan" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2967,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.delete_loan,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        delete_loan: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2971,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2985,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.delete_loan ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 2986,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2970,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2966,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Add Pigme" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2995,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.add_pigme,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        add_pigme: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 2999,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3013,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.add_pigme ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3014,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 2998,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 2994,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Pigme" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3021,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_pigme,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_pigme: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3025,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3039,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_pigme ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3040,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3024,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3020,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Edit Pigme" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3049,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.edit_pigme,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        edit_pigme: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3053,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3067,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.edit_pigme ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3068,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3052,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3048,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Delete Pigme" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3077,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.delete_pigme,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        delete_pigme: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3081,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3095,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.delete_pigme ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3096,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3080,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3076,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Add Auction" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3105,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.add_auction,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        add_auction: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3109,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3123,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.add_auction ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3124,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3108,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3104,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Auction" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3133,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_auction,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_auction: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3137,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3151,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_auction ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3152,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3136,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3132,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Edit Auction" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3161,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.edit_auction,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        edit_auction: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3165,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3179,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.edit_auction ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3180,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3164,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3160,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Delete Auction" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3189,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.delete_auction,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        delete_auction: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3193,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3207,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.delete_auction ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3208,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3192,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3188,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Add Payment" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3217,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.add_payment,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        add_payment: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3221,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3235,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.add_payment ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3236,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3220,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3216,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Payment" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3245,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_payment,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_payment: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3249,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3263,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_payment ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3264,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3248,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3244,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Edit Payment" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3273,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.edit_payment,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        edit_payment: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3277,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3291,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.edit_payment ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3292,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3276,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3272,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Edit Limited Payment" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3300,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.edit_limited_payment,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        edit_limited_payment: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3304,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3320,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.edit_limited_payment ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3321,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3303,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3299,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Unlink Enrollment" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3330,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.unlink_enrollment,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        unlink_enrollment: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3334,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3350,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.unlink_enrollment ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3351,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3333,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3329,
              columnNumber: 16
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "Delete Payment" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3360,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.delete_payment,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        delete_payment: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3364,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3378,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.delete_payment ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3379,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3363,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3359,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Reports" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3388,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_reports,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_reports: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3392,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3406,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_reports ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3407,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3391,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3387,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Daybook" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3416,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_daybook,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_daybook: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3420,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3434,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_daybook ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3435,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3419,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3415,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Group Report" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3444,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_group_report,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_group_report: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3448,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3464,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_group_report ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3465,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3447,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3443,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View All Customer Report" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3474,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_all_customer_report,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_all_customer_report: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3478,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3494,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_all_customer_report ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3495,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3477,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3473,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Customer Report" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3504,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_customer_report,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_customer_report: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3508,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3524,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_customer_report ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3525,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3507,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3503,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Receipt Report" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3534,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_receipt_report,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_receipt_report: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3538,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3554,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_receipt_report ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3555,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3537,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3533,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Auction Report" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3564,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_auction_report,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_auction_report: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3568,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3584,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_auction_report ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3585,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3567,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3563,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Lead Report" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3594,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_lead_report,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_lead_report: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3598,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3612,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_lead_report ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3613,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3597,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3593,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Pigme Report" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3622,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_pigme_report,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_pigme_report: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3626,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3642,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_pigme_report ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3643,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3625,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3621,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Loan Report" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3652,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_loan_report,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_loan_report: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3656,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3670,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_loan_report ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3671,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3655,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3651,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Agent Report" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3709,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_agent_report,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_agent_report: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3713,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3729,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_agent_report ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3730,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3712,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3708,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Target" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3738,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_target,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_target: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3742,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3758,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_target ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3759,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3741,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3737,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Mobile Options" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3767,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_mobile_options,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_mobile_options: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3771,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3787,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_mobile_options ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3788,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3770,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3766,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-900", children: "View Suspense Payments" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3797,
                columnNumber: 3
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "inline-flex relative items-center cursor-pointer", children: [
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "checkbox",
                    checked: updateFormData.access_permissions.view_suspense_payments,
                    onChange: (e) => setUpdateFormData({
                      ...updateFormData,
                      access_permissions: {
                        ...updateFormData.access_permissions,
                        view_suspense_payments: e.target.checked
                      }
                    }),
                    className: "sr-only peer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3801,
                    columnNumber: 5
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-4 peer-focus:ring-blue-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3815,
                  columnNumber: 5
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "ml-3 text-sm text-gray-600", children: updateFormData.access_permissions.view_suspense_payments ? "Yes" : "No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3816,
                  columnNumber: 5
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3800,
                columnNumber: 3
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3796,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Update"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                lineNumber: 3823,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3822,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 2226,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 2221,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
        lineNumber: 2217,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentUser(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Access Role" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
            lineNumber: 3843,
            columnNumber: 13
          }, this),
          currentUser && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteUser();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "groupName",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentUser.title }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                          lineNumber: 3860,
                          columnNumber: 21
                        }, this),
                        " ",
                        "to confirm deletion.",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                          lineNumber: 3864,
                          columnNumber: 21
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                      lineNumber: 3855,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      id: "groupName",
                      placeholder: "Enter the designation",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                      lineNumber: 3866,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                  lineNumber: 3854,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\n          focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
                    lineNumber: 3874,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
              lineNumber: 3847,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
          lineNumber: 3842,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
        lineNumber: 3835,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
    lineNumber: 694,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx",
    lineNumber: 693,
    columnNumber: 5
  }, this);
};
_s(AdminAccessRights, "hig9tDK7y9KDj0b8QLhm856ZjZs=");
_c = AdminAccessRights;
export default AdminAccessRights;
var _c;
$RefreshReg$(_c, "AdminAccessRights");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AdminAccessRights.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUx3QixTQTJmcEIsVUEzZm9COzJCQXpMeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQSxTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxPQUFPQyxnQkFBZ0I7QUFDaEMsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLHVCQUF1QjtBQUM5QixTQUFTQyxpQkFBaUI7QUFFMUIsTUFBTUMsOEJBQThCQSxDQUFDQyxVQUFVO0FBQzdDLFFBQU1DLFdBQVdELE9BQU9DLFVBQVVDO0FBQ2xDLE1BQUksT0FBT0QsVUFBVUUsWUFBWSxZQUFZRixTQUFTRSxRQUFTLFFBQU9GLFNBQVNFO0FBQy9FLE1BQUksT0FBT0YsVUFBVUQsVUFBVSxZQUFZQyxTQUFTRCxNQUFPLFFBQU9DLFNBQVNEO0FBQzNFLFNBQU87QUFDVDtBQUVBLE1BQU1JLG9CQUFvQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzlCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJckIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ3NCLGFBQWFDLGNBQWMsSUFBSXZCLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUN3QixZQUFZQyxhQUFhLElBQUl6QixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDMEIsV0FBV0MsWUFBWSxJQUFJM0IsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzRCLGlCQUFpQkMsa0JBQWtCLElBQUk3QixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDOEIsaUJBQWlCQyxrQkFBa0IsSUFBSS9CLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNnQyxhQUFhQyxjQUFjLElBQUlqQyxTQUFTLElBQUk7QUFDbkQsUUFBTSxDQUFDa0MsbUJBQW1CQyxvQkFBb0IsSUFBSW5DLFNBQVMsSUFBSTtBQUMvRCxRQUFNLENBQUNvQyxRQUFRQyxTQUFTLElBQUlyQyxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUNzQyxZQUFZQyxhQUFhLElBQUl2QyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDd0MsV0FBV0MsWUFBWSxJQUFJekMsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzBDLGVBQWVDLGdCQUFnQixJQUFJM0MsU0FBUyxDQUFDO0FBRXBELFFBQU00Qyw4QkFBOEJBLENBQUNDLE1BQU07QUFDekMsVUFBTSxFQUFFQyxNQUFNLElBQUlELEVBQUVFO0FBQ3BCUixrQkFBY08sS0FBSztBQUFBLEVBQ3JCO0FBRUEsUUFBTSxDQUFDRSxhQUFhQyxjQUFjLElBQUlqRCxTQUFTO0FBQUEsSUFDN0NrRCxZQUFZO0FBQUEsSUFDWmpDLFNBQVM7QUFBQSxJQUNUa0MsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJckQsU0FBUztBQUFBLElBQ3ZDc0QsT0FBTztBQUFBLElBQ1BDLG9CQUFvQjtBQUFBLE1BQ2xCQyxnQkFBZ0I7QUFBQSxNQUNoQkMsZ0JBQWdCO0FBQUEsTUFDaEJDLFdBQVc7QUFBQSxNQUNYQyxZQUFZO0FBQUEsTUFDWkMsWUFBWTtBQUFBLE1BQ1pDLGNBQWM7QUFBQSxNQUNkQyxjQUFjO0FBQUEsTUFDZEMsZUFBZTtBQUFBLE1BQ2ZDLGVBQWU7QUFBQSxNQUNmQyxpQkFBaUI7QUFBQSxNQUNqQkMsZ0JBQWdCO0FBQUEsTUFDaEJDLG1CQUFtQjtBQUFBLE1BQ25CQyxpQkFBaUI7QUFBQSxNQUNqQkMsaUJBQWlCO0FBQUEsTUFDakJDLGNBQWM7QUFBQSxNQUNkQyxlQUFlO0FBQUEsTUFDZkMsZUFBZTtBQUFBLE1BQ2ZDLGlCQUFpQjtBQUFBLE1BQ2pCQyxxQkFBcUI7QUFBQSxNQUNyQkMsVUFBVTtBQUFBLE1BQ1ZDLFdBQVc7QUFBQSxNQUNYQyxXQUFXO0FBQUEsTUFDWEMsYUFBYTtBQUFBLE1BQ2JDLFVBQVU7QUFBQSxNQUNWQyxXQUFXO0FBQUEsTUFDWEMsV0FBVztBQUFBLE1BQ1hDLGFBQWE7QUFBQSxNQUNiQyxXQUFXO0FBQUEsTUFDWEMsWUFBWTtBQUFBLE1BQ1pDLFlBQVk7QUFBQSxNQUNaQyxjQUFjO0FBQUEsTUFDZEMsYUFBYTtBQUFBLE1BQ2JDLGNBQWM7QUFBQSxNQUNkQyxjQUFjO0FBQUEsTUFDZEMsZ0JBQWdCO0FBQUEsTUFDaEJDLGFBQWE7QUFBQSxNQUNiQyxjQUFjO0FBQUEsTUFDZEMsY0FBYztBQUFBLE1BQ2RDLHNCQUFzQjtBQUFBLE1BQ3RCQyxnQkFBZ0I7QUFBQSxNQUNoQkMsY0FBYztBQUFBLE1BQ2RDLGNBQWM7QUFBQSxNQUNkQyxtQkFBbUI7QUFBQSxNQUNuQkMsMEJBQTBCO0FBQUEsTUFDMUJDLHNCQUFzQjtBQUFBLE1BQ3RCQyxxQkFBcUI7QUFBQSxNQUNyQkMscUJBQXFCO0FBQUEsTUFDckJDLGtCQUFrQjtBQUFBLE1BQ2xCQyxtQkFBbUI7QUFBQSxNQUNuQkMsa0JBQWtCO0FBQUEsTUFDbEJDLG1CQUFtQjtBQUFBLE1BQ25CQyxhQUFhO0FBQUEsTUFDYkMscUJBQXFCO0FBQUEsTUFDcEJDLHdCQUF3QjtBQUFBLE1BQ3hCQyxtQkFBbUI7QUFBQSxJQUN0QjtBQUFBLEVBQ0YsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsZ0JBQWdCQyxpQkFBaUIsSUFBSWhILFNBQVM7QUFBQSxJQUNuRHNELE9BQU87QUFBQSxJQUNQQyxvQkFBb0I7QUFBQSxNQUNsQkMsZ0JBQWdCO0FBQUEsTUFDaEJDLGdCQUFnQjtBQUFBLE1BQ2hCQyxXQUFXO0FBQUEsTUFDWEMsWUFBWTtBQUFBLE1BQ1pDLFlBQVk7QUFBQSxNQUNaQyxjQUFjO0FBQUEsTUFDZEMsY0FBYztBQUFBLE1BQ2RDLGVBQWU7QUFBQSxNQUNmQyxlQUFlO0FBQUEsTUFDZkMsaUJBQWlCO0FBQUEsTUFDakJDLGdCQUFnQjtBQUFBLE1BQ2hCQyxtQkFBbUI7QUFBQSxNQUNuQkMsaUJBQWlCO0FBQUEsTUFDakJDLGlCQUFpQjtBQUFBLE1BQ2pCQyxjQUFjO0FBQUEsTUFDZEMsZUFBZTtBQUFBLE1BQ2ZDLGVBQWU7QUFBQSxNQUNmQyxpQkFBaUI7QUFBQSxNQUNqQkMscUJBQXFCO0FBQUEsTUFDckJDLFVBQVU7QUFBQSxNQUNWQyxXQUFXO0FBQUEsTUFDWEMsV0FBVztBQUFBLE1BQ1hDLGFBQWE7QUFBQSxNQUNiQyxVQUFVO0FBQUEsTUFDVkMsV0FBVztBQUFBLE1BQ1hDLFdBQVc7QUFBQSxNQUNYQyxhQUFhO0FBQUEsTUFDYkMsV0FBVztBQUFBLE1BQ1hDLFlBQVk7QUFBQSxNQUNaQyxZQUFZO0FBQUEsTUFDWkMsY0FBYztBQUFBLE1BQ2RDLGFBQWE7QUFBQSxNQUNiQyxjQUFjO0FBQUEsTUFDZEMsY0FBYztBQUFBLE1BQ2RDLGdCQUFnQjtBQUFBLE1BQ2hCQyxhQUFhO0FBQUEsTUFDYkMsY0FBYztBQUFBLE1BQ2RDLGNBQWM7QUFBQSxNQUNkQyxzQkFBc0I7QUFBQSxNQUN0QkMsZ0JBQWdCO0FBQUEsTUFDaEJDLGNBQWM7QUFBQSxNQUNkQyxjQUFjO0FBQUEsTUFDZEMsbUJBQW1CO0FBQUEsTUFDbkJDLDBCQUEwQjtBQUFBLE1BQzFCQyxzQkFBc0I7QUFBQSxNQUN0QkMscUJBQXFCO0FBQUEsTUFDckJDLHFCQUFxQjtBQUFBLE1BQ3JCQyxrQkFBa0I7QUFBQSxNQUNsQkMsbUJBQW1CO0FBQUEsTUFDbkJDLGtCQUFrQjtBQUFBLE1BQ2xCQyxtQkFBbUI7QUFBQSxNQUNuQkMsYUFBYTtBQUFBLE1BQ2JDLHFCQUFxQjtBQUFBLE1BQ3BCQyx3QkFBd0I7QUFBQSxNQUN4QkMsbUJBQW1CO0FBQUEsSUFDdEI7QUFBQSxFQUNGLENBQUM7QUFDRC9HLFlBQVUsTUFBTTtBQUNkLFVBQU1rSCxtQkFBbUIsWUFBWTtBQUNuQyxVQUFJO0FBQ0Z4RSxxQkFBYSxJQUFJO0FBQ2pCLGNBQU0xQixXQUFXLE1BQU1ULElBQUk0RyxJQUFJLDhCQUE4QjtBQUM3RDdGLGlCQUFTTixTQUFTQyxJQUFJO0FBQ3RCLGNBQU1tRyxnQkFBZ0JwRyxTQUFTQyxLQUFLb0csSUFBSSxDQUFDQyxhQUFhQyxXQUFXO0FBQUEsVUFDL0RDLEtBQUtGLGFBQWFFO0FBQUFBLFVBQ2xCQyxJQUFJRixRQUFRO0FBQUEsVUFDWmhFLE9BQU8rRCxhQUFhL0Q7QUFBQUEsVUFDcEJtRSxRQUNFLHVCQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTTtBQUFBLGdCQUNKQyxPQUFPO0FBQUEsa0JBQ0w7QUFBQSxvQkFDRUMsS0FBSztBQUFBLG9CQUNMQyxPQUNFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFTLE1BQ1BDLHNCQUFzQlIsYUFBYUUsR0FBRztBQUFBLHdCQUN2QztBQUFBO0FBQUEsc0JBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU9BO0FBQUEsa0JBRUo7QUFBQSxrQkFDQTtBQUFBLG9CQUNFSSxLQUFLO0FBQUEsb0JBQ0xDLE9BQ0U7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVMsTUFDUEUsc0JBQXNCVCxhQUFhRSxHQUFHO0FBQUEsd0JBQ3ZDO0FBQUE7QUFBQSxzQkFKSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT0E7QUFBQSxrQkFFSjtBQUFBLGdCQUFDO0FBQUEsY0FFTDtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVYsaUNBQUMsWUFBUyxXQUFVLGVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStCO0FBQUE7QUFBQSxZQWpDakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBa0NBLEtBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0NBO0FBQUEsUUFFSixFQUFFO0FBQ0ZoRyx1QkFBZTRGLGFBQWE7QUFBQSxNQUM5QixTQUFTckcsT0FBTztBQUNkaUgsZ0JBQVFqSCxNQUFNLHFDQUFxQ0EsS0FBSztBQUFBLE1BQzFELFVBQUM7QUFDQzJCLHFCQUFhLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFDQXdFLHFCQUFpQjtBQUFBLEVBQ25CLEdBQUcsQ0FBQ3ZFLGFBQWEsQ0FBQztBQWdCbEIsUUFBTXNGLGVBQWVBLENBQUNuRixNQUFNO0FBQzFCLFVBQU0sRUFBRW9GLE1BQU1uRixNQUFNLElBQUlELEVBQUVFO0FBQzFCTSxnQkFBWSxDQUFDNkUsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0QsSUFBSSxHQUFHbkY7QUFBQUEsSUFDVixFQUFFO0FBQ0ZULGNBQVUsQ0FBQzZGLGNBQWM7QUFBQSxNQUN2QixHQUFHQTtBQUFBQSxNQUNILENBQUNELElBQUksR0FBRztBQUFBLElBQ1YsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNRSxlQUFlQSxDQUFDaEYsU0FBUztBQUM3QixVQUFNaUYsWUFBWSxDQUFDO0FBQ25CLFVBQU1wSCxPQUFPbUMsU0FBUyxvQkFBb0JDLFdBQVcyRDtBQUVyRCxRQUFJLENBQUMvRixLQUFLc0MsTUFBTStFLEtBQUssR0FBRztBQUN0QkQsZ0JBQVVILE9BQU87QUFBQSxJQUNuQjtBQUNBNUYsY0FBVStGLFNBQVM7QUFDbkIsV0FBT0UsT0FBT0MsS0FBS0gsU0FBUyxFQUFFSSxXQUFXO0FBQUEsRUFDM0M7QUFFQSxRQUFNQyxlQUFlLE9BQU81RixNQUFNO0FBQ2hDQSxNQUFFNkYsZUFBZTtBQUNqQixVQUFNQyxhQUFhUixhQUFhLGlCQUFpQjtBQUVqRCxRQUFJO0FBQ0YsVUFBSVEsWUFBWTtBQUNkLGNBQU01SCxXQUFXLE1BQU1ULElBQUlzSSxLQUFLLDRCQUE0QnhGLFVBQVU7QUFBQSxVQUNwRXlGLFNBQVM7QUFBQSxZQUNQLGdCQUFnQjtBQUFBLFVBQ2xCO0FBQUEsUUFDRixDQUFDO0FBRURsSCxxQkFBYSxLQUFLO0FBQ2xCZ0IseUJBQWlCLENBQUNtRyxTQUFTQSxPQUFPLENBQUM7QUFDbkN6RixvQkFBWTtBQUFBLFVBQ1ZDLE9BQU87QUFBQSxVQUNQQyxvQkFBb0I7QUFBQSxZQUNsQkMsZ0JBQWdCO0FBQUEsWUFDaEJDLGdCQUFnQjtBQUFBLFlBQ2hCQyxXQUFXO0FBQUEsWUFDWEMsWUFBWTtBQUFBLFlBQ1pDLFlBQVk7QUFBQSxZQUNaQyxjQUFjO0FBQUEsWUFDZEMsY0FBYztBQUFBLFlBQ2RDLGVBQWU7QUFBQSxZQUNmQyxlQUFlO0FBQUEsWUFDZkMsaUJBQWlCO0FBQUEsWUFDakJDLGdCQUFnQjtBQUFBLFlBQ2hCRSxpQkFBaUI7QUFBQSxZQUNqQkMsaUJBQWlCO0FBQUEsWUFDakJGLG1CQUFtQjtBQUFBLFlBQ25CRyxjQUFjO0FBQUEsWUFDZEMsZUFBZTtBQUFBLFlBQ2ZDLGVBQWU7QUFBQSxZQUNmQyxpQkFBaUI7QUFBQSxZQUNqQkMscUJBQXFCO0FBQUEsWUFDckJDLFVBQVU7QUFBQSxZQUNWQyxXQUFXO0FBQUEsWUFDWEMsV0FBVztBQUFBLFlBQ1hDLGFBQWE7QUFBQSxZQUNiQyxVQUFVO0FBQUEsWUFDVkMsV0FBVztBQUFBLFlBQ1hDLFdBQVc7QUFBQSxZQUNYQyxhQUFhO0FBQUEsWUFDYkMsV0FBVztBQUFBLFlBQ1hDLFlBQVk7QUFBQSxZQUNaQyxZQUFZO0FBQUEsWUFDWkMsY0FBYztBQUFBLFlBQ2RDLGFBQWE7QUFBQSxZQUNiQyxjQUFjO0FBQUEsWUFDZEMsY0FBYztBQUFBLFlBQ2RDLGdCQUFnQjtBQUFBLFlBQ2hCQyxhQUFhO0FBQUEsWUFDYkMsY0FBYztBQUFBLFlBQ2RDLGNBQWM7QUFBQSxZQUNkQyxzQkFBc0I7QUFBQSxZQUN0QkMsZ0JBQWdCO0FBQUEsWUFDaEJDLGNBQWM7QUFBQSxZQUNkQyxjQUFjO0FBQUEsWUFDZEMsbUJBQW1CO0FBQUEsWUFDbkJDLDBCQUEwQjtBQUFBLFlBQzFCQyxzQkFBc0I7QUFBQSxZQUN0QkMscUJBQXFCO0FBQUEsWUFDckJDLHFCQUFxQjtBQUFBLFlBQ3JCQyxrQkFBa0I7QUFBQSxZQUNsQkMsbUJBQW1CO0FBQUEsWUFDbkJDLGtCQUFrQjtBQUFBLFlBQ2xCQyxtQkFBbUI7QUFBQSxZQUNuQkMsYUFBYTtBQUFBLFlBQ2JDLHFCQUFxQjtBQUFBLFlBQ3JCRSxtQkFBbUI7QUFBQSxVQUNyQjtBQUFBLFFBQ0YsQ0FBQztBQUVEN0QsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWmpDLFNBQVM7QUFBQSxVQUNUa0MsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLFNBQVNyQyxPQUFPO0FBQ2RpSCxjQUFRakgsTUFBTSwrQkFBK0JBLEtBQUs7QUFDbERtQyxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaakMsU0FBU0osNEJBQTRCQyxLQUFLO0FBQUEsUUFDMUNxQyxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQXBELFlBQVUsTUFBTTtBQUNkLFVBQU1rSCxtQkFBbUIsWUFBWTtBQUNuQyxVQUFJO0FBQ0Z4RSxxQkFBYSxJQUFJO0FBQ2pCLGNBQU0xQixXQUFXLE1BQU1ULElBQUk0RyxJQUFJLDhCQUE4QjtBQUM3RDdGLGlCQUFTTixTQUFTQyxJQUFJO0FBQ3RCLGNBQU1tRyxnQkFBZ0JwRyxTQUFTQyxLQUFLb0csSUFBSSxDQUFDQyxhQUFhQyxXQUFXO0FBQUEsVUFDL0RDLEtBQUtGLGFBQWFFO0FBQUFBLFVBQ2xCQyxJQUFJRixRQUFRO0FBQUEsVUFDWmhFLE9BQU8rRCxhQUFhL0Q7QUFBQUEsVUFDcEJtRSxRQUNFLHVCQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTTtBQUFBLGdCQUNKQyxPQUFPO0FBQUEsa0JBQ0w7QUFBQSxvQkFDRUMsS0FBSztBQUFBLG9CQUNMQyxPQUNFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFTLE1BQ1BDLHNCQUFzQlIsYUFBYUUsR0FBRztBQUFBLHdCQUN2QztBQUFBO0FBQUEsc0JBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU9BO0FBQUEsa0JBRUo7QUFBQSxrQkFDQTtBQUFBLG9CQUNFSSxLQUFLO0FBQUEsb0JBQ0xDLE9BQ0U7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVMsTUFDUEUsc0JBQXNCVCxhQUFhRSxHQUFHO0FBQUEsd0JBQ3ZDO0FBQUE7QUFBQSxzQkFKSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT0E7QUFBQSxrQkFFSjtBQUFBLGdCQUFDO0FBQUEsY0FFTDtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVYsaUNBQUMsWUFBUyxXQUFVLGVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStCO0FBQUE7QUFBQSxZQWpDakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBa0NBLEtBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0NBO0FBQUEsUUFFSixFQUFFO0FBQ0ZoRyx1QkFBZTRGLGFBQWE7QUFBQSxNQUM5QixTQUFTckcsT0FBTztBQUNkaUgsZ0JBQVFqSCxNQUFNLHFDQUFxQ0EsS0FBSztBQUFBLE1BQzFELFVBQUM7QUFDQzJCLHFCQUFhLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFDQXdFLHFCQUFpQjtBQUFBLEVBQ25CLEdBQUcsQ0FBQ3ZFLGFBQWEsQ0FBQztBQUVsQixRQUFNcUcsVUFBVTtBQUFBLElBQ2QsRUFBRXBCLEtBQUssTUFBTXFCLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVyQixLQUFLLFNBQVNxQixRQUFRLHFCQUFxQjtBQUFBLElBQzdDLEVBQUVyQixLQUFLLFVBQVVxQixRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFFBQU1DLGdCQUFnQjdILE1BQU04SDtBQUFBQSxJQUFPLENBQUNDLFNBQ2xDQSxLQUFLN0YsTUFBTThGLFlBQVksRUFBRUMsU0FBUzdILFdBQVc0SCxZQUFZLENBQUM7QUFBQSxFQUM1RDtBQUVBLFFBQU10Qix3QkFBd0IsT0FBT3dCLFdBQVc7QUFDOUMsUUFBSTtBQUNGLFlBQU12SSxXQUFXLE1BQU1ULElBQUk0RztBQUFBQSxRQUN6QixrQ0FBa0NvQyxNQUFNO0FBQUEsTUFDMUM7QUFDQXJILHFCQUFlbEIsU0FBU0MsSUFBSTtBQUM1QmEseUJBQW1CLElBQUk7QUFDdkJRLGdCQUFVLENBQUMsQ0FBQztBQUFBLElBQ2QsU0FBU3ZCLE9BQU87QUFDZGlILGNBQVFqSCxNQUFNLHdCQUF3QkEsS0FBSztBQUFBLElBQzdDO0FBQUEsRUFDRjtBQUVBLFFBQU0rRyx3QkFBd0IsT0FBT3lCLFdBQVc7QUFDOUMsUUFBSTtBQUNGLFlBQU12SSxXQUFXLE1BQU1ULElBQUk0RztBQUFBQSxRQUN6QixrQ0FBa0NvQyxNQUFNO0FBQUEsTUFDMUM7QUFFQW5ILDJCQUFxQnBCLFNBQVNDLElBQUk7QUFDbENnRyx3QkFBa0I7QUFBQSxRQUNoQjFELE9BQU92QyxTQUFTQyxLQUFLc0M7QUFBQUEsUUFDckJDLG9CQUFvQjtBQUFBLFVBQ2xCQyxnQkFDRXpDLFNBQVNDLE1BQU11QyxvQkFBb0JDLG1CQUFtQixVQUN0RHpDLFNBQVNDLE1BQU11SSxtQkFBbUIvRixtQkFBbUI7QUFBQSxVQUN2REMsZ0JBQ0UxQyxTQUFTQyxNQUFNdUMsb0JBQW9CRSxtQkFBbUIsVUFDdEQxQyxTQUFTQyxNQUFNdUksbUJBQW1COUYsbUJBQW1CO0FBQUEsVUFDdkRDLFdBQ0UzQyxTQUFTQyxNQUFNdUMsb0JBQW9CRyxjQUFjLFVBQ2pEM0MsU0FBU0MsTUFBTXVJLG1CQUFtQjdGLGNBQWM7QUFBQSxVQUNsREMsWUFDRTVDLFNBQVNDLE1BQU11QyxvQkFBb0JJLGVBQWUsVUFDbEQ1QyxTQUFTQyxNQUFNdUksbUJBQW1CNUYsZUFBZTtBQUFBLFVBQ25EQyxZQUNFN0MsU0FBU0MsTUFBTXVDLG9CQUFvQkssZUFBZSxVQUNsRDdDLFNBQVNDLE1BQU11SSxtQkFBbUIzRixlQUFlO0FBQUEsVUFDbkRDLGNBQ0U5QyxTQUFTQyxNQUFNdUMsb0JBQW9CTSxpQkFBaUIsVUFDcEQ5QyxTQUFTQyxNQUFNdUksbUJBQW1CMUYsaUJBQWlCO0FBQUEsVUFDckRDLGNBQ0UvQyxTQUFTQyxNQUFNdUMsb0JBQW9CTyxpQkFBaUIsVUFDcEQvQyxTQUFTQyxNQUFNdUksbUJBQW1CekYsaUJBQWlCO0FBQUEsVUFDckRDLGVBQ0VoRCxTQUFTQyxNQUFNdUMsb0JBQW9CUSxrQkFBa0IsVUFDckRoRCxTQUFTQyxNQUFNdUksbUJBQW1CeEYsa0JBQWtCO0FBQUEsVUFDdERDLGVBQ0VqRCxTQUFTQyxNQUFNdUMsb0JBQW9CUyxrQkFBa0IsVUFDckRqRCxTQUFTQyxNQUFNdUksbUJBQW1CdkYsa0JBQWtCO0FBQUEsVUFDdERDLGlCQUNFbEQsU0FBU0MsTUFBTXVDLG9CQUFvQlUsb0JBQW9CLFVBQ3ZEbEQsU0FBU0MsTUFBTXVJLG1CQUFtQnRGLG9CQUFvQjtBQUFBLFVBQ3hEQyxnQkFDRW5ELFNBQVNDLE1BQU11QyxvQkFBb0JXLG1CQUFtQixVQUN0RG5ELFNBQVNDLE1BQU11SSxtQkFBbUJyRixtQkFBbUI7QUFBQSxVQUN2REMsbUJBQ0VwRCxTQUFTQyxNQUFNdUMsb0JBQW9CWSxzQkFBc0IsVUFDekRwRCxTQUFTQyxNQUFNdUksbUJBQW1CcEYsc0JBQXNCO0FBQUEsVUFDMURDLGlCQUNFckQsU0FBU0MsTUFBTXVDLG9CQUFvQmEsb0JBQW9CLFVBQ3ZEckQsU0FBU0MsTUFBTXVJLG1CQUFtQm5GLG9CQUFvQjtBQUFBLFVBQ3hEQyxpQkFDRXRELFNBQVNDLE1BQU11QyxvQkFBb0JjLG9CQUFvQixVQUN2RHRELFNBQVNDLE1BQU11SSxtQkFBbUJsRixvQkFBb0I7QUFBQSxVQUN4REMsY0FDRXZELFNBQVNDLE1BQU11QyxvQkFBb0JlLGlCQUFpQixVQUNwRHZELFNBQVNDLE1BQU11SSxtQkFBbUJqRixpQkFBaUI7QUFBQSxVQUNyREMsZUFDRXhELFNBQVNDLE1BQU11QyxvQkFBb0JnQixrQkFBa0IsVUFDckR4RCxTQUFTQyxNQUFNdUksbUJBQW1CaEYsa0JBQWtCO0FBQUEsVUFDdERDLGVBQ0V6RCxTQUFTQyxNQUFNdUMsb0JBQW9CaUIsa0JBQWtCLFVBQ3JEekQsU0FBU0MsTUFBTXVJLG1CQUFtQi9FLGtCQUFrQjtBQUFBLFVBQ3REQyxpQkFDRTFELFNBQVNDLE1BQU11QyxvQkFBb0JrQixvQkFBb0IsVUFDdkQxRCxTQUFTQyxNQUFNdUksbUJBQW1COUUsb0JBQW9CO0FBQUEsVUFDeERDLHFCQUNFM0QsU0FBU0MsTUFBTXVDLG9CQUFvQm1CLHdCQUF3QixVQUMzRDNELFNBQVNDLE1BQU11SSxtQkFBbUI3RSx3QkFBd0I7QUFBQSxVQUM1REMsVUFDRTVELFNBQVNDLE1BQU11QyxvQkFBb0JvQixhQUFhLFVBQ2hENUQsU0FBU0MsTUFBTXVJLG1CQUFtQjVFLGFBQWE7QUFBQSxVQUNqREMsV0FDRTdELFNBQVNDLE1BQU11QyxvQkFBb0JxQixjQUFjLFVBQ2pEN0QsU0FBU0MsTUFBTXVJLG1CQUFtQjNFLGNBQWM7QUFBQSxVQUNsREMsV0FDRTlELFNBQVNDLE1BQU11QyxvQkFBb0JzQixjQUFjLFVBQ2pEOUQsU0FBU0MsTUFBTXVJLG1CQUFtQjFFLGNBQWM7QUFBQSxVQUNsREMsYUFDRS9ELFNBQVNDLE1BQU11QyxvQkFBb0J1QixnQkFBZ0IsVUFDbkQvRCxTQUFTQyxNQUFNdUksbUJBQW1CekUsZ0JBQWdCO0FBQUEsVUFDcERDLFVBQ0VoRSxTQUFTQyxNQUFNdUMsb0JBQW9Cd0IsYUFBYSxVQUNoRGhFLFNBQVNDLE1BQU11SSxtQkFBbUJ4RSxhQUFhO0FBQUEsVUFDakRDLFdBQ0VqRSxTQUFTQyxNQUFNdUMsb0JBQW9CeUIsY0FBYyxVQUNqRGpFLFNBQVNDLE1BQU11SSxtQkFBbUJ2RSxjQUFjO0FBQUEsVUFDbERDLFdBQ0VsRSxTQUFTQyxNQUFNdUMsb0JBQW9CMEIsY0FBYyxVQUNqRGxFLFNBQVNDLE1BQU11SSxtQkFBbUJ0RSxjQUFjO0FBQUEsVUFDbERDLGFBQ0VuRSxTQUFTQyxNQUFNdUMsb0JBQW9CMkIsZ0JBQWdCLFVBQ25EbkUsU0FBU0MsTUFBTXVJLG1CQUFtQnJFLGdCQUFnQjtBQUFBLFVBQ3BEQyxXQUNFcEUsU0FBU0MsTUFBTXVDLG9CQUFvQjRCLGNBQWMsVUFDakRwRSxTQUFTQyxNQUFNdUksbUJBQW1CcEUsY0FBYztBQUFBLFVBQ2xEQyxZQUNFckUsU0FBU0MsTUFBTXVDLG9CQUFvQjZCLGVBQWUsVUFDbERyRSxTQUFTQyxNQUFNdUksbUJBQW1CbkUsZUFBZTtBQUFBLFVBQ25EQyxZQUNFdEUsU0FBU0MsTUFBTXVDLG9CQUFvQjhCLGVBQWUsVUFDbER0RSxTQUFTQyxNQUFNdUksbUJBQW1CbEUsZUFBZTtBQUFBLFVBQ25EQyxjQUNFdkUsU0FBU0MsTUFBTXVDLG9CQUFvQitCLGlCQUFpQixVQUNwRHZFLFNBQVNDLE1BQU11SSxtQkFBbUJqRSxpQkFBaUI7QUFBQSxVQUNyREMsYUFDRXhFLFNBQVNDLE1BQU11QyxvQkFBb0JnQyxnQkFBZ0IsVUFDbkR4RSxTQUFTQyxNQUFNdUksbUJBQW1CaEUsZ0JBQWdCO0FBQUEsVUFDcERDLGNBQ0V6RSxTQUFTQyxNQUFNdUMsb0JBQW9CaUMsaUJBQWlCLFVBQ3BEekUsU0FBU0MsTUFBTXVJLG1CQUFtQi9ELGlCQUFpQjtBQUFBLFVBQ3JEQyxjQUNFMUUsU0FBU0MsTUFBTXVDLG9CQUFvQmtDLGlCQUFpQixVQUNwRDFFLFNBQVNDLE1BQU11SSxtQkFBbUI5RCxpQkFBaUI7QUFBQSxVQUNyREMsZ0JBQ0UzRSxTQUFTQyxNQUFNdUMsb0JBQW9CbUMsbUJBQW1CLFVBQ3REM0UsU0FBU0MsTUFBTXVJLG1CQUFtQjdELG1CQUFtQjtBQUFBLFVBQ3ZEQyxhQUNFNUUsU0FBU0MsTUFBTXVDLG9CQUFvQm9DLGdCQUFnQixVQUNuRDVFLFNBQVNDLE1BQU11SSxtQkFBbUI1RCxnQkFBZ0I7QUFBQSxVQUNwREMsY0FDRTdFLFNBQVNDLE1BQU11QyxvQkFBb0JxQyxpQkFBaUIsVUFDcEQ3RSxTQUFTQyxNQUFNdUksbUJBQW1CM0QsaUJBQWlCO0FBQUEsVUFDckRDLGNBQ0U5RSxTQUFTQyxNQUFNdUMsb0JBQW9Cc0MsaUJBQWlCLFVBQ3BEOUUsU0FBU0MsTUFBTXVJLG1CQUFtQjFELGlCQUFpQjtBQUFBLFVBQ3JEQyxzQkFDRS9FLFNBQVNDLE1BQU11QyxvQkFBb0J1Qyx5QkFDakMsVUFDRi9FLFNBQVNDLE1BQU11SSxtQkFBbUJ6RCx5QkFBeUI7QUFBQSxVQUM3REMsZ0JBQ0VoRixTQUFTQyxNQUFNdUMsb0JBQW9Cd0MsbUJBQW1CLFVBQ3REaEYsU0FBU0MsTUFBTXVJLG1CQUFtQnhELG1CQUFtQjtBQUFBLFVBQ3ZEQyxjQUNFakYsU0FBU0MsTUFBTXVDLG9CQUFvQnlDLGlCQUFpQixVQUNwRGpGLFNBQVNDLE1BQU11SSxtQkFBbUJ2RCxpQkFBaUI7QUFBQSxVQUNyREMsY0FDRWxGLFNBQVNDLE1BQU11QyxvQkFBb0IwQyxpQkFBaUIsVUFDcERsRixTQUFTQyxNQUFNdUksbUJBQW1CdEQsaUJBQWlCO0FBQUEsVUFDckRDLG1CQUNFbkYsU0FBU0MsTUFBTXVDLG9CQUFvQjJDLHNCQUFzQixVQUN6RG5GLFNBQVNDLE1BQU11SSxtQkFBbUJyRCxzQkFBc0I7QUFBQSxVQUMxREMsMEJBQ0VwRixTQUFTQyxNQUFNdUMsb0JBQW9CNEMsNkJBQ2pDLFVBQ0ZwRixTQUFTQyxNQUFNdUksbUJBQW1CcEQsNkJBQTZCO0FBQUEsVUFDakVDLHNCQUNFckYsU0FBU0MsTUFBTXVDLG9CQUFvQjZDLHlCQUNqQyxVQUNGckYsU0FBU0MsTUFBTXVJLG1CQUFtQm5ELHlCQUF5QjtBQUFBLFVBQzdEQyxxQkFDRXRGLFNBQVNDLE1BQU11QyxvQkFBb0I4Qyx3QkFBd0IsVUFDM0R0RixTQUFTQyxNQUFNdUksbUJBQW1CbEQsd0JBQXdCO0FBQUEsVUFDNURDLHFCQUNFdkYsU0FBU0MsTUFBTXVDLG9CQUFvQitDLHdCQUF3QixVQUMzRHZGLFNBQVNDLE1BQU11SSxtQkFBbUJqRCx3QkFBd0I7QUFBQSxVQUM1REMsa0JBQ0V4RixTQUFTQyxNQUFNdUMsb0JBQW9CZ0QscUJBQXFCLFVBQ3hEeEYsU0FBU0MsTUFBTXVJLG1CQUFtQmhELHFCQUFxQjtBQUFBLFVBQ3pEQyxtQkFDRXpGLFNBQVNDLE1BQU11QyxvQkFBb0JpRCxzQkFBc0IsVUFDekR6RixTQUFTQyxNQUFNdUksbUJBQW1CL0Msc0JBQXNCO0FBQUEsVUFDMURDLGtCQUNFMUYsU0FBU0MsTUFBTXVDLG9CQUFvQmtELHFCQUFxQixVQUN4RDFGLFNBQVNDLE1BQU11SSxtQkFBbUI5QyxxQkFBcUI7QUFBQSxVQUN6REMsbUJBQ0UzRixTQUFTQyxNQUFNdUMsb0JBQW9CbUQsc0JBQXNCLFVBQ3pEM0YsU0FBU0MsTUFBTXVJLG1CQUFtQjdDLHNCQUFzQjtBQUFBLFVBQ3hEQyxhQUNBNUYsU0FBU0MsTUFBTXVDLG9CQUFvQm9ELGdCQUFnQixVQUNuRDVGLFNBQVNDLE1BQU11SSxtQkFBbUI1QyxnQkFBZ0I7QUFBQSxVQUN4REMscUJBQXFCN0YsU0FBU0MsTUFBTXVDLG9CQUFvQnFELHdCQUF3QixVQUMxRTdGLFNBQVNDLE1BQU11SSxtQkFBbUIzQyx3QkFBd0I7QUFBQSxVQUVoRUMsd0JBQXdCOUYsU0FBU0MsTUFBTXVDLG9CQUFvQnNELDJCQUEyQixVQUNsRjlGLFNBQVNDLE1BQU11SSxtQkFBbUIxQywyQkFBMkI7QUFBQSxVQUMvREMsbUJBQW1CL0YsU0FBU0MsTUFBTXVJLG1CQUFtQnpDLHNCQUFzQixVQUN6RS9GLFNBQVNDLE1BQU11SSxtQkFBbUJ6QyxzQkFBc0I7QUFBQSxRQUMxRDtBQUFBLE1BQ0YsQ0FBQztBQUNEL0UseUJBQW1CLElBQUk7QUFDdkJNLGdCQUFVLENBQUMsQ0FBQztBQUFBLElBQ2QsU0FBU3ZCLE9BQU87QUFDZGlILGNBQVFqSCxNQUFNLHdCQUF3QkEsS0FBSztBQUFBLElBQzdDO0FBQUEsRUFDRjtBQUVBLFFBQU0wSSxvQkFBb0JBLENBQUMzRyxNQUFNO0FBQy9CLFVBQU0sRUFBRW9GLE1BQU1uRixNQUFNLElBQUlELEVBQUVFO0FBQzFCaUUsc0JBQWtCLENBQUNrQixjQUFjO0FBQUEsTUFDL0IsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRCxJQUFJLEdBQUduRjtBQUFBQSxJQUNWLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTTJHLG1CQUFtQixZQUFZO0FBQ25DLFFBQUl6SCxhQUFhO0FBQ2YsVUFBSTtBQUNGLGNBQU0xQixJQUFJb0o7QUFBQUEsVUFDUixxQ0FBcUMxSCxZQUFZdUYsR0FBRztBQUFBLFFBQ3REO0FBQ0ExRiwyQkFBbUIsS0FBSztBQUN4QkksdUJBQWUsSUFBSTtBQUNuQlUseUJBQWlCLENBQUNtRyxTQUFTQSxPQUFPLENBQUM7QUFDbkM3Rix1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaakMsU0FBUztBQUFBLFVBQ1RrQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSCxTQUFTckMsT0FBTztBQUNkaUgsZ0JBQVFqSCxNQUFNLDJCQUEyQkEsS0FBSztBQUFBLE1BQ2hEO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNkksZUFBZSxPQUFPOUcsTUFBTTtBQUNoQ0EsTUFBRTZGLGVBQWU7QUFDakIsVUFBTWtCLFVBQVV6QixhQUFhO0FBQzdCLFFBQUk7QUFDRixVQUFJeUIsU0FBUztBQUNYLGNBQU03SSxXQUFXLE1BQU1ULElBQUl1SjtBQUFBQSxVQUN6QixxQ0FBcUMzSCxrQkFBa0JxRixHQUFHO0FBQUEsVUFDMURSO0FBQUFBLFFBQ0Y7QUFDQWhGLDJCQUFtQixLQUFLO0FBQ3hCWSx5QkFBaUIsQ0FBQ21HLFNBQVNBLE9BQU8sQ0FBQztBQUNuQzdGLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pqQyxTQUFTO0FBQUEsVUFDVGtDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixTQUFTckMsT0FBTztBQUNkaUgsY0FBUWpILE1BQU0sK0JBQStCQSxLQUFLO0FBQ2xEbUMscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWmpDLFNBQVNKLDRCQUE0QkMsS0FBSztBQUFBLFFBQzFDcUMsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBRUFwRCxZQUFVLE1BQU07QUFDZCxVQUFNK0oseUJBQXlCLFlBQVk7QUFDekMsVUFBSTtBQUNGLGNBQU0vSSxXQUFXLE1BQU1ULElBQUk0RztBQUFBQSxVQUN6QjtBQUFBLFFBQ0Y7QUFDQTZDLG9CQUFZaEosU0FBU0MsSUFBSTtBQUFBLE1BQzNCLFNBQVNGLE9BQU87QUFDZGlILGdCQUFRakgsTUFBTSx1Q0FBdUNBLEtBQUs7QUFBQSxNQUM1RDtBQUFBLElBQ0Y7QUFDQWdKLDJCQUF1QjtBQUFBLEVBQ3pCLEdBQUcsQ0FBQ3BILGFBQWEsQ0FBQztBQUVsQixTQUNFLG1DQUNFLGlDQUFDLFNBQ0M7QUFBQSwyQkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0EsWUFBWTtBQUFBO0FBQUEsUUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFbUI7QUFBQSxNQUVuQix1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWU7QUFBQSxNQUNmO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFNTSxZQUFZRztBQUFBQSxVQUNsQixXQUFXSCxZQUFZRTtBQUFBQSxVQUN2QixTQUFTRixZQUFZL0I7QUFBQUEsVUFDckIsU0FBUyxNQUNQZ0MsZUFBZSxDQUFDNkYsVUFBVSxFQUFFLEdBQUdBLE1BQU01RixZQUFZLE1BQU0sRUFBRTtBQUFBO0FBQUEsUUFMN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUc7QUFBQSxNQUdILHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxhQUNiLGlDQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSwwQkFBeUIsbUNBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBEO0FBQUEsVUFDMUQ7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTTtBQUNidkIsNkJBQWEsSUFBSTtBQUNqQlUsMEJBQVUsQ0FBQyxDQUFDO0FBQUEsY0FDZDtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBQW1HO0FBQUE7QUFBQSxZQUwvRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLGFBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsUUFDQ2YsWUFBWWtILFNBQVMsS0FBSyxDQUFDaEcsWUFDMUI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLGVBQWVxRjtBQUFBQSxZQUNmLE1BQU1wSCxhQUFhYSxhQUFhZ0IsVUFBVTtBQUFBLFlBQzFDO0FBQUEsWUFDQSxpQkFBaUIsd0JBQ2Ysb0JBQUkwSCxLQUFLLEdBQUVDLFlBQVksR0FBR0MsTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQUEsWUFFekMsa0JBQWtCO0FBQUE7QUFBQSxVQVBwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPd0QsSUFHeEQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxTQUFTNUksWUFBWWtILFVBQVU7QUFBQSxZQUMvQixNQUFLO0FBQUE7QUFBQSxVQUhQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUcrQjtBQUFBLFdBN0JuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0NBO0FBQUEsU0EvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdEQTtBQUFBLElBRUEsdUJBQUMsU0FBTSxXQUFXOUcsV0FBVyxTQUFTLE1BQU1DLGFBQWEsS0FBSyxHQUM1RCxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsd0NBQXVDLGtDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVU4RyxjQUFjLFlBQVUsTUFDNUQ7QUFBQSwrQkFBQyxTQUNDO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLFNBQVE7QUFBQSxjQUFPO0FBQUE7QUFBQSxnQkFFVCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQztBQUFBO0FBQUE7QUFBQSxZQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLE9BQU9yRixTQUFTRTtBQUFBQSxjQUNoQixVQUFVMEU7QUFBQUEsY0FDVixJQUFHO0FBQUEsY0FDSCxhQUFZO0FBQUEsY0FDWjtBQUFBLGNBQ0EsV0FBVTtBQUFBO0FBQUEsWUFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRdUk7QUFBQSxVQUV0STVGLE9BQU82RixRQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkI3RixpQkFBT2tCLFNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVEO0FBQUEsYUFsQjNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiLGlDQUFDLFdBQU0sV0FBVSxxQkFBb0Isa0NBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUQsS0FEekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDhCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTRixTQUFTRyxtQkFBbUJDO0FBQUFBLGdCQUNyQyxVQUFVLENBQUNYLE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNaQyxnQkFBZ0JYLEVBQUVFLE9BQU9vSDtBQUFBQSxrQkFDM0I7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQix1QkFBQyxTQUFJLFdBQVUsbVlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK1k7QUFBQSxZQUMvWSx1QkFBQyxVQUFLLFdBQVUsOEJBQ2IvRyxtQkFBU0csbUJBQW1CQyxpQkFBaUIsUUFBUSxRQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDhCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTSixTQUFTRyxtQkFBbUJFO0FBQUFBLGdCQUNyQyxVQUFVLENBQUNaLE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNaRSxnQkFBZ0JaLEVBQUVFLE9BQU9vSDtBQUFBQSxrQkFDM0I7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQix1QkFBQyxTQUFJLFdBQVUsbVlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK1k7QUFBQSxZQUMvWSx1QkFBQyxVQUFLLFdBQVUsOEJBQ2IvRyxtQkFBU0csbUJBQW1CRSxpQkFBaUIsUUFBUSxRQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLHlCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTTCxTQUFTRyxtQkFBbUJHO0FBQUFBLGdCQUNyQyxVQUFVLENBQUNiLE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNaRyxXQUFXYixFQUFFRSxPQUFPb0g7QUFBQUEsa0JBQ3RCO0FBQUEsZ0JBQ0YsQ0FBQztBQUFBLGdCQUVILFdBQVU7QUFBQTtBQUFBLGNBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWTBCO0FBQUEsWUFFMUIsdUJBQUMsU0FBSSxXQUFVLG1ZQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStZO0FBQUEsWUFDL1ksdUJBQUMsVUFBSyxXQUFVLDhCQUNiL0csbUJBQVNHLG1CQUFtQkcsWUFBWSxRQUFRLFFBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLGFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQ0FBb0MsMEJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNOLFNBQVNHLG1CQUFtQkk7QUFBQUEsZ0JBQ3JDLFVBQVUsQ0FBQ2QsTUFDVFEsWUFBWTtBQUFBLGtCQUNWLEdBQUdEO0FBQUFBLGtCQUNIRyxvQkFBb0I7QUFBQSxvQkFDbEIsR0FBR0gsU0FBU0c7QUFBQUEsb0JBQ1pJLFlBQVlkLEVBQUVFLE9BQU9vSDtBQUFBQSxrQkFDdkI7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQix1QkFBQyxTQUFJLFdBQVUsbVlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK1k7QUFBQSxZQUMvWSx1QkFBQyxVQUFLLFdBQVUsOEJBQ2IvRyxtQkFBU0csbUJBQW1CSSxhQUFhLFFBQVEsUUFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFDQUFvQywwQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU1AsU0FBU0csbUJBQW1CSztBQUFBQSxnQkFDckMsVUFBVSxDQUFDZixNQUNUUSxZQUFZO0FBQUEsa0JBQ1YsR0FBR0Q7QUFBQUEsa0JBQ0hHLG9CQUFvQjtBQUFBLG9CQUNsQixHQUFHSCxTQUFTRztBQUFBQSxvQkFDWkssWUFBWWYsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUN2QjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUJLLGFBQWEsUUFBUSxRQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDRCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTUixTQUFTRyxtQkFBbUJNO0FBQUFBLGdCQUNyQyxVQUFVLENBQUNoQixNQUNUUSxZQUFZO0FBQUEsa0JBQ1YsR0FBR0Q7QUFBQUEsa0JBQ0hHLG9CQUFvQjtBQUFBLG9CQUNsQixHQUFHSCxTQUFTRztBQUFBQSxvQkFDWk0sY0FBY2hCLEVBQUVFLE9BQU9vSDtBQUFBQSxrQkFDekI7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQix1QkFBQyxTQUFJLFdBQVUsbVlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK1k7QUFBQSxZQUMvWSx1QkFBQyxVQUFLLFdBQVUsOEJBQ2IvRyxtQkFBU0csbUJBQW1CTSxlQUFlLFFBQVEsUUFEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFDQUFvQyw0QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU1QsU0FBU0csbUJBQW1CTztBQUFBQSxnQkFDckMsVUFBVSxDQUFDakIsTUFDVFEsWUFBWTtBQUFBLGtCQUNWLEdBQUdEO0FBQUFBLGtCQUNIRyxvQkFBb0I7QUFBQSxvQkFDbEIsR0FBR0gsU0FBU0c7QUFBQUEsb0JBQ1pPLGNBQWNqQixFQUFFRSxPQUFPb0g7QUFBQUEsa0JBQ3pCO0FBQUEsZ0JBQ0YsQ0FBQztBQUFBLGdCQUVILFdBQVU7QUFBQTtBQUFBLGNBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWTBCO0FBQUEsWUFFMUIsdUJBQUMsU0FBSSxXQUFVLG1ZQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStZO0FBQUEsWUFDL1ksdUJBQUMsVUFBSyxXQUFVLDhCQUNiL0csbUJBQVNHLG1CQUFtQk8sZUFBZSxRQUFRLFFBRHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLGFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQ0FBb0MsNkJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNWLFNBQVNHLG1CQUFtQlE7QUFBQUEsZ0JBQ3JDLFVBQVUsQ0FBQ2xCLE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNaUSxlQUFlbEIsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUMxQjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUJRLGdCQUFnQixRQUFRLFFBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLGFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQ0FBb0MsNkJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNYLFNBQVNHLG1CQUFtQlM7QUFBQUEsZ0JBQ3JDLFVBQVUsQ0FBQ25CLE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNaUyxlQUFlbkIsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUMxQjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUJTLGdCQUFnQixRQUFRLFFBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLGFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQ0FBb0MsK0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNaLFNBQVNHLG1CQUFtQlU7QUFBQUEsZ0JBQ3JDLFVBQVUsQ0FBQ3BCLE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNaVSxpQkFBaUJwQixFQUFFRSxPQUFPb0g7QUFBQUEsa0JBQzVCO0FBQUEsZ0JBQ0YsQ0FBQztBQUFBLGdCQUVILFdBQVU7QUFBQTtBQUFBLGNBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWTBCO0FBQUEsWUFFMUIsdUJBQUMsU0FBSSxXQUFVLG1ZQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStZO0FBQUEsWUFDL1ksdUJBQUMsVUFBSyxXQUFVLDhCQUNiL0csbUJBQVNHLG1CQUFtQlUsa0JBQWtCLFFBQVEsUUFEekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFDQUFvQyw4QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU2IsU0FBU0csbUJBQW1CVztBQUFBQSxnQkFDckMsVUFBVSxDQUFDckIsTUFDVFEsWUFBWTtBQUFBLGtCQUNWLEdBQUdEO0FBQUFBLGtCQUNIRyxvQkFBb0I7QUFBQSxvQkFDbEIsR0FBR0gsU0FBU0c7QUFBQUEsb0JBQ1pXLGdCQUFnQnJCLEVBQUVFLE9BQU9vSDtBQUFBQSxrQkFDM0I7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQix1QkFBQyxTQUFJLFdBQVUsbVlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK1k7QUFBQSxZQUMvWSx1QkFBQyxVQUFLLFdBQVUsOEJBQ2IvRyxtQkFBU0csbUJBQW1CVyxpQkFBaUIsUUFBUSxRQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLCtCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTZCxTQUFTRyxtQkFBbUJhO0FBQUFBLGdCQUNyQyxVQUFVLENBQUN2QixNQUNUUSxZQUFZO0FBQUEsa0JBQ1YsR0FBR0Q7QUFBQUEsa0JBQ0hHLG9CQUFvQjtBQUFBLG9CQUNsQixHQUFHSCxTQUFTRztBQUFBQSxvQkFDWmEsaUJBQWlCdkIsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUM1QjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUJhLGtCQUFrQixRQUFRLFFBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLGFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQ0FBb0MsK0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNoQixTQUFTRyxtQkFBbUJjO0FBQUFBLGdCQUNyQyxVQUFVLENBQUN4QixNQUNUUSxZQUFZO0FBQUEsa0JBQ1YsR0FBR0Q7QUFBQUEsa0JBQ0hHLG9CQUFvQjtBQUFBLG9CQUNsQixHQUFHSCxTQUFTRztBQUFBQSxvQkFDWmMsaUJBQWlCeEIsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUM1QjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUJjLGtCQUFrQixRQUFRLFFBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLGFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQ0FBb0MsaUNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNqQixTQUFTRyxtQkFBbUJZO0FBQUFBLGdCQUNyQyxVQUFVLENBQUN0QixNQUNUUSxZQUFZO0FBQUEsa0JBQ1YsR0FBR0Q7QUFBQUEsa0JBQ0hHLG9CQUFvQjtBQUFBLG9CQUNsQixHQUFHSCxTQUFTRztBQUFBQSxvQkFDWlksbUJBQW1CdEIsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUM5QjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUJZLG9CQUN6QixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUJBO0FBQUEsYUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFDQUFvQyw0QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU2YsU0FBU0csbUJBQW1CZTtBQUFBQSxnQkFDckMsVUFBVSxDQUFDekIsTUFDVFEsWUFBWTtBQUFBLGtCQUNWLEdBQUdEO0FBQUFBLGtCQUNIRyxvQkFBb0I7QUFBQSxvQkFDbEIsR0FBR0gsU0FBU0c7QUFBQUEsb0JBQ1plLGNBQWN6QixFQUFFRSxPQUFPb0g7QUFBQUEsa0JBQ3pCO0FBQUEsZ0JBQ0YsQ0FBQztBQUFBLGdCQUVILFdBQVU7QUFBQTtBQUFBLGNBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWTBCO0FBQUEsWUFFMUIsdUJBQUMsU0FBSSxXQUFVLG1ZQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStZO0FBQUEsWUFDL1ksdUJBQUMsVUFBSyxXQUFVLDhCQUNiL0csbUJBQVNHLG1CQUFtQmUsZUFBZSxRQUFRLFFBRHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLGFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQ0FBb0MsNkJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNsQixTQUFTRyxtQkFBbUJnQjtBQUFBQSxnQkFDckMsVUFBVSxDQUFDMUIsTUFDVFEsWUFBWTtBQUFBLGtCQUNWLEdBQUdEO0FBQUFBLGtCQUNIRyxvQkFBb0I7QUFBQSxvQkFDbEIsR0FBR0gsU0FBU0c7QUFBQUEsb0JBQ1pnQixlQUFlMUIsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUMxQjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUJnQixnQkFBZ0IsUUFBUSxRQUR2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDZCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTbkIsU0FBU0csbUJBQW1CaUI7QUFBQUEsZ0JBQ3JDLFVBQVUsQ0FBQzNCLE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNaaUIsZUFBZTNCLEVBQUVFLE9BQU9vSDtBQUFBQSxrQkFDMUI7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQix1QkFBQyxTQUFJLFdBQVUsbVlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK1k7QUFBQSxZQUMvWSx1QkFBQyxVQUFLLFdBQVUsOEJBQ2IvRyxtQkFBU0csbUJBQW1CaUIsZ0JBQWdCLFFBQVEsUUFEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFDQUFvQywrQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU3BCLFNBQVNHLG1CQUFtQmtCO0FBQUFBLGdCQUNyQyxVQUFVLENBQUM1QixNQUNUUSxZQUFZO0FBQUEsa0JBQ1YsR0FBR0Q7QUFBQUEsa0JBQ0hHLG9CQUFvQjtBQUFBLG9CQUNsQixHQUFHSCxTQUFTRztBQUFBQSxvQkFDWmtCLGlCQUFpQjVCLEVBQUVFLE9BQU9vSDtBQUFBQSxrQkFDNUI7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQix1QkFBQyxTQUFJLFdBQVUsbVlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK1k7QUFBQSxZQUMvWSx1QkFBQyxVQUFLLFdBQVUsOEJBQ2IvRyxtQkFBU0csbUJBQW1Ca0Isa0JBQWtCLFFBQVEsUUFEekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFDQUFvQyxtQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU3JCLFNBQVNHLG1CQUFtQm1CO0FBQUFBLGdCQUNyQyxVQUFVLENBQUM3QixNQUNUUSxZQUFZO0FBQUEsa0JBQ1YsR0FBR0Q7QUFBQUEsa0JBQ0hHLG9CQUFvQjtBQUFBLG9CQUNsQixHQUFHSCxTQUFTRztBQUFBQSxvQkFDWm1CLHFCQUFxQjdCLEVBQUVFLE9BQU9vSDtBQUFBQSxrQkFDaEM7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQix1QkFBQyxTQUFJLFdBQVUsbVlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK1k7QUFBQSxZQUMvWSx1QkFBQyxVQUFLLFdBQVUsOEJBQ2IvRyxtQkFBU0csbUJBQW1CbUIsc0JBQ3pCLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsZUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxhQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMEJBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLHdCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTdEIsU0FBU0csbUJBQW1Cb0I7QUFBQUEsZ0JBQ3JDLFVBQVUsQ0FBQzlCLE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNab0IsVUFBVTlCLEVBQUVFLE9BQU9vSDtBQUFBQSxrQkFDckI7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQix1QkFBQyxTQUFJLFdBQVUsbVlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK1k7QUFBQSxZQUMvWSx1QkFBQyxVQUFLLFdBQVUsOEJBQ2IvRyxtQkFBU0csbUJBQW1Cb0IsV0FBVyxRQUFRLFFBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLGFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQ0FBb0MseUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVN2QixTQUFTRyxtQkFBbUJxQjtBQUFBQSxnQkFDckMsVUFBVSxDQUFDL0IsTUFDVFEsWUFBWTtBQUFBLGtCQUNWLEdBQUdEO0FBQUFBLGtCQUNIRyxvQkFBb0I7QUFBQSxvQkFDbEIsR0FBR0gsU0FBU0c7QUFBQUEsb0JBQ1pxQixXQUFXL0IsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUN0QjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUJxQixZQUFZLFFBQVEsUUFEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFDQUFvQyx5QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU3hCLFNBQVNHLG1CQUFtQnNCO0FBQUFBLGdCQUNyQyxVQUFVLENBQUNoQyxNQUNUUSxZQUFZO0FBQUEsa0JBQ1YsR0FBR0Q7QUFBQUEsa0JBQ0hHLG9CQUFvQjtBQUFBLG9CQUNsQixHQUFHSCxTQUFTRztBQUFBQSxvQkFDWnNCLFdBQVdoQyxFQUFFRSxPQUFPb0g7QUFBQUEsa0JBQ3RCO0FBQUEsZ0JBQ0YsQ0FBQztBQUFBLGdCQUVILFdBQVU7QUFBQTtBQUFBLGNBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWTBCO0FBQUEsWUFFMUIsdUJBQUMsU0FBSSxXQUFVLG1ZQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStZO0FBQUEsWUFDL1ksdUJBQUMsVUFBSyxXQUFVLDhCQUNiL0csbUJBQVNHLG1CQUFtQnNCLFlBQVksUUFBUSxRQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDJCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTekIsU0FBU0csbUJBQW1CdUI7QUFBQUEsZ0JBQ3JDLFVBQVUsQ0FBQ2pDLE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNadUIsYUFBYWpDLEVBQUVFLE9BQU9vSDtBQUFBQSxrQkFDeEI7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQix1QkFBQyxTQUFJLFdBQVUsbVlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK1k7QUFBQSxZQUMvWSx1QkFBQyxVQUFLLFdBQVUsOEJBQ2IvRyxtQkFBU0csbUJBQW1CdUIsY0FBYyxRQUFRLFFBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLGFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQ0FBb0Msd0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMxQixTQUFTRyxtQkFBbUJ3QjtBQUFBQSxnQkFDckMsVUFBVSxDQUFDbEMsTUFDVFEsWUFBWTtBQUFBLGtCQUNWLEdBQUdEO0FBQUFBLGtCQUNIRyxvQkFBb0I7QUFBQSxvQkFDbEIsR0FBR0gsU0FBU0c7QUFBQUEsb0JBQ1p3QixVQUFVbEMsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUNyQjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUJ3QixXQUFXLFFBQVEsUUFEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFDQUFvQyx5QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUzNCLFNBQVNHLG1CQUFtQnlCO0FBQUFBLGdCQUNyQyxVQUFVLENBQUNuQyxNQUNUUSxZQUFZO0FBQUEsa0JBQ1YsR0FBR0Q7QUFBQUEsa0JBQ0hHLG9CQUFvQjtBQUFBLG9CQUNsQixHQUFHSCxTQUFTRztBQUFBQSxvQkFDWnlCLFdBQVduQyxFQUFFRSxPQUFPb0g7QUFBQUEsa0JBQ3RCO0FBQUEsZ0JBQ0YsQ0FBQztBQUFBLGdCQUVILFdBQVU7QUFBQTtBQUFBLGNBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWTBCO0FBQUEsWUFFMUIsdUJBQUMsU0FBSSxXQUFVLG1ZQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStZO0FBQUEsWUFDL1ksdUJBQUMsVUFBSyxXQUFVLDhCQUNiL0csbUJBQVNHLG1CQUFtQnlCLFlBQVksUUFBUSxRQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLHlCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTNUIsU0FBU0csbUJBQW1CMEI7QUFBQUEsZ0JBQ3JDLFVBQVUsQ0FBQ3BDLE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNaMEIsV0FBV3BDLEVBQUVFLE9BQU9vSDtBQUFBQSxrQkFDdEI7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQix1QkFBQyxTQUFJLFdBQVUsbVlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK1k7QUFBQSxZQUMvWSx1QkFBQyxVQUFLLFdBQVUsOEJBQ2IvRyxtQkFBU0csbUJBQW1CMEIsWUFBWSxRQUFRLFFBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLGFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQ0FBb0MsMkJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVM3QixTQUFTRyxtQkFBbUIyQjtBQUFBQSxnQkFDckMsVUFBVSxDQUFDckMsTUFDVFEsWUFBWTtBQUFBLGtCQUNWLEdBQUdEO0FBQUFBLGtCQUNIRyxvQkFBb0I7QUFBQSxvQkFDbEIsR0FBR0gsU0FBU0c7QUFBQUEsb0JBQ1oyQixhQUFhckMsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUN4QjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUIyQixjQUFjLFFBQVEsUUFEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFDQUFvQyx5QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUzlCLFNBQVNHLG1CQUFtQjRCO0FBQUFBLGdCQUNyQyxVQUFVLENBQUN0QyxNQUNUUSxZQUFZO0FBQUEsa0JBQ1YsR0FBR0Q7QUFBQUEsa0JBQ0hHLG9CQUFvQjtBQUFBLG9CQUNsQixHQUFHSCxTQUFTRztBQUFBQSxvQkFDWjRCLFdBQVd0QyxFQUFFRSxPQUFPb0g7QUFBQUEsa0JBQ3RCO0FBQUEsZ0JBQ0YsQ0FBQztBQUFBLGdCQUVILFdBQVU7QUFBQTtBQUFBLGNBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWTBCO0FBQUEsWUFFMUIsdUJBQUMsU0FBSSxXQUFVLG1ZQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStZO0FBQUEsWUFDL1ksdUJBQUMsVUFBSyxXQUFVLDhCQUNiL0csbUJBQVNHLG1CQUFtQjRCLFlBQVksUUFBUSxRQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDBCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTL0IsU0FBU0csbUJBQW1CNkI7QUFBQUEsZ0JBQ3JDLFVBQVUsQ0FBQ3ZDLE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNaNkIsWUFBWXZDLEVBQUVFLE9BQU9vSDtBQUFBQSxrQkFDdkI7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQix1QkFBQyxTQUFJLFdBQVUsbVlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK1k7QUFBQSxZQUMvWSx1QkFBQyxVQUFLLFdBQVUsOEJBQ2IvRyxtQkFBU0csbUJBQW1CNkIsYUFBYSxRQUFRLFFBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLGFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQ0FBb0MsMEJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNoQyxTQUFTRyxtQkFBbUI4QjtBQUFBQSxnQkFDckMsVUFBVSxDQUFDeEMsTUFDVFEsWUFBWTtBQUFBLGtCQUNWLEdBQUdEO0FBQUFBLGtCQUNIRyxvQkFBb0I7QUFBQSxvQkFDbEIsR0FBR0gsU0FBU0c7QUFBQUEsb0JBQ1o4QixZQUFZeEMsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUN2QjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUI4QixhQUFhLFFBQVEsUUFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFDQUFvQyw0QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU2pDLFNBQVNHLG1CQUFtQitCO0FBQUFBLGdCQUNyQyxVQUFVLENBQUN6QyxNQUNUUSxZQUFZO0FBQUEsa0JBQ1YsR0FBR0Q7QUFBQUEsa0JBQ0hHLG9CQUFvQjtBQUFBLG9CQUNsQixHQUFHSCxTQUFTRztBQUFBQSxvQkFDWitCLGNBQWN6QyxFQUFFRSxPQUFPb0g7QUFBQUEsa0JBQ3pCO0FBQUEsZ0JBQ0YsQ0FBQztBQUFBLGdCQUVILFdBQVU7QUFBQTtBQUFBLGNBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWTBCO0FBQUEsWUFFMUIsdUJBQUMsU0FBSSxXQUFVLG1ZQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStZO0FBQUEsWUFDL1ksdUJBQUMsVUFBSyxXQUFVLDhCQUNiL0csbUJBQVNHLG1CQUFtQitCLGVBQWUsUUFBUSxRQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDJCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTbEMsU0FBU0csbUJBQW1CZ0M7QUFBQUEsZ0JBQ3JDLFVBQVUsQ0FBQzFDLE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNaZ0MsYUFBYTFDLEVBQUVFLE9BQU9vSDtBQUFBQSxrQkFDeEI7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQix1QkFBQyxTQUFJLFdBQVUsbVlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK1k7QUFBQSxZQUMvWSx1QkFBQyxVQUFLLFdBQVUsOEJBQ2IvRyxtQkFBU0csbUJBQW1CZ0MsY0FBYyxRQUFRLFFBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLGFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQ0FBb0MsNEJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNuQyxTQUFTRyxtQkFBbUJpQztBQUFBQSxnQkFDckMsVUFBVSxDQUFDM0MsTUFDVFEsWUFBWTtBQUFBLGtCQUNWLEdBQUdEO0FBQUFBLGtCQUNIRyxvQkFBb0I7QUFBQSxvQkFDbEIsR0FBR0gsU0FBU0c7QUFBQUEsb0JBQ1ppQyxjQUFjM0MsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUN6QjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUJpQyxlQUFlLFFBQVEsUUFEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFDQUFvQyw0QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU3BDLFNBQVNHLG1CQUFtQmtDO0FBQUFBLGdCQUNyQyxVQUFVLENBQUM1QyxNQUNUUSxZQUFZO0FBQUEsa0JBQ1YsR0FBR0Q7QUFBQUEsa0JBQ0hHLG9CQUFvQjtBQUFBLG9CQUNsQixHQUFHSCxTQUFTRztBQUFBQSxvQkFDWmtDLGNBQWM1QyxFQUFFRSxPQUFPb0g7QUFBQUEsa0JBQ3pCO0FBQUEsZ0JBQ0YsQ0FBQztBQUFBLGdCQUVILFdBQVU7QUFBQTtBQUFBLGNBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWTBCO0FBQUEsWUFFMUIsdUJBQUMsU0FBSSxXQUFVLG1ZQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStZO0FBQUEsWUFDL1ksdUJBQUMsVUFBSyxXQUFVLDhCQUNiL0csbUJBQVNHLG1CQUFtQmtDLGVBQWUsUUFBUSxRQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDhCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTckMsU0FBU0csbUJBQW1CbUM7QUFBQUEsZ0JBQ3JDLFVBQVUsQ0FBQzdDLE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNabUMsZ0JBQWdCN0MsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUMzQjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUJtQyxpQkFBaUIsUUFBUSxRQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDJCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTdEMsU0FBU0csbUJBQW1Cb0M7QUFBQUEsZ0JBQ3JDLFVBQVUsQ0FBQzlDLE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNab0MsYUFBYTlDLEVBQUVFLE9BQU9vSDtBQUFBQSxrQkFDeEI7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQix1QkFBQyxTQUFJLFdBQVUsbVlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK1k7QUFBQSxZQUMvWSx1QkFBQyxVQUFLLFdBQVUsOEJBQ2IvRyxtQkFBU0csbUJBQW1Cb0MsY0FBYyxRQUFRLFFBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLGFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQ0FBb0MsNEJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVN2QyxTQUFTRyxtQkFBbUJxQztBQUFBQSxnQkFDckMsVUFBVSxDQUFDL0MsTUFDVFEsWUFBWTtBQUFBLGtCQUNWLEdBQUdEO0FBQUFBLGtCQUNIRyxvQkFBb0I7QUFBQSxvQkFDbEIsR0FBR0gsU0FBU0c7QUFBQUEsb0JBQ1pxQyxjQUFjL0MsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUN6QjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUJxQyxlQUFlLFFBQVEsUUFEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFDQUFvQyw0QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU3hDLFNBQVNHLG1CQUFtQnNDO0FBQUFBLGdCQUNyQyxVQUFVLENBQUNoRCxNQUNUUSxZQUFZO0FBQUEsa0JBQ1YsR0FBR0Q7QUFBQUEsa0JBQ0hHLG9CQUFvQjtBQUFBLG9CQUNsQixHQUFHSCxTQUFTRztBQUFBQSxvQkFDWnNDLGNBQWNoRCxFQUFFRSxPQUFPb0g7QUFBQUEsa0JBQ3pCO0FBQUEsZ0JBQ0YsQ0FBQztBQUFBLGdCQUVILFdBQVU7QUFBQTtBQUFBLGNBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWTBCO0FBQUEsWUFFMUIsdUJBQUMsU0FBSSxXQUFVLG1ZQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStZO0FBQUEsWUFDL1ksdUJBQUMsVUFBSyxXQUFVLDhCQUNiL0csbUJBQVNHLG1CQUFtQnNDLGVBQWUsUUFBUSxRQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLG9DQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTekMsU0FBU0csbUJBQW1CdUM7QUFBQUEsZ0JBQ3JDLFVBQVUsQ0FBQ2pELE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNadUMsc0JBQXNCakQsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUNqQztBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUJ1Qyx1QkFBdUIsUUFBUSxRQUQ5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLGlDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTMUMsU0FBU0csbUJBQW1CdUQ7QUFBQUEsZ0JBQ3JDLFVBQVUsQ0FBQ2pFLE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNadUQsbUJBQW1CakUsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUM5QjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUJ1RCxvQkFBb0IsUUFBUSxRQUQzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDhCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTMUQsU0FBU0csbUJBQW1Cd0M7QUFBQUEsZ0JBQ3JDLFVBQVUsQ0FBQ2xELE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNad0MsZ0JBQWdCbEQsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUMzQjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUJ3QyxpQkFBaUIsUUFBUSxRQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDRCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTM0MsU0FBU0csbUJBQW1CeUM7QUFBQUEsZ0JBQ3JDLFVBQVUsQ0FBQ25ELE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNaeUMsY0FBY25ELEVBQUVFLE9BQU9vSDtBQUFBQSxrQkFDekI7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQix1QkFBQyxTQUFJLFdBQVUsbVlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK1k7QUFBQSxZQUMvWSx1QkFBQyxVQUFLLFdBQVUsOEJBQ2IvRyxtQkFBU0csbUJBQW1CeUMsZUFBZSxRQUFRLFFBRHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLGFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3QkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQ0FBb0MsNEJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVM1QyxTQUFTRyxtQkFBbUIwQztBQUFBQSxnQkFDckMsVUFBVSxDQUFDcEQsTUFDVFEsWUFBWTtBQUFBLGtCQUNWLEdBQUdEO0FBQUFBLGtCQUNIRyxvQkFBb0I7QUFBQSxvQkFDbEIsR0FBR0gsU0FBU0c7QUFBQUEsb0JBQ1owQyxjQUFjcEQsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUN6QjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUIwQyxlQUFlLFFBQVEsUUFEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFDQUFvQyxpQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUzdDLFNBQVNHLG1CQUFtQjJDO0FBQUFBLGdCQUNyQyxVQUFVLENBQUNyRCxNQUNUUSxZQUFZO0FBQUEsa0JBQ1YsR0FBR0Q7QUFBQUEsa0JBQ0hHLG9CQUFvQjtBQUFBLG9CQUNsQixHQUFHSCxTQUFTRztBQUFBQSxvQkFDWjJDLG1CQUFtQnJELEVBQUVFLE9BQU9vSDtBQUFBQSxrQkFDOUI7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQix1QkFBQyxTQUFJLFdBQVUsbVlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK1k7QUFBQSxZQUMvWSx1QkFBQyxVQUFLLFdBQVUsOEJBQ2IvRyxtQkFBU0csbUJBQW1CMkMsb0JBQ3pCLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsZUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxhQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMEJBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLHdDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUNFOUMsU0FBU0csbUJBQW1CNEM7QUFBQUEsZ0JBRTlCLFVBQVUsQ0FBQ3RELE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNaNEMsMEJBQTBCdEQsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUNyQztBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQWRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWMwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUI0QywyQkFDekIsUUFDQSxRQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxlQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVCQTtBQUFBLGFBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0QkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQ0FBb0Msb0NBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMvQyxTQUFTRyxtQkFBbUI2QztBQUFBQSxnQkFDckMsVUFBVSxDQUFDdkQsTUFDVFEsWUFBWTtBQUFBLGtCQUNWLEdBQUdEO0FBQUFBLGtCQUNIRyxvQkFBb0I7QUFBQSxvQkFDbEIsR0FBR0gsU0FBU0c7QUFBQUEsb0JBQ1o2QyxzQkFBc0J2RCxFQUFFRSxPQUFPb0g7QUFBQUEsa0JBQ2pDO0FBQUEsZ0JBQ0YsQ0FBQztBQUFBLGdCQUVILFdBQVU7QUFBQTtBQUFBLGNBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWTBCO0FBQUEsWUFFMUIsdUJBQUMsU0FBSSxXQUFVLG1ZQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStZO0FBQUEsWUFDL1ksdUJBQUMsVUFBSyxXQUFVLDhCQUNiL0csbUJBQVNHLG1CQUFtQjZDLHVCQUN6QixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUJBO0FBQUEsYUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFDQUFvQyxtQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU2hELFNBQVNHLG1CQUFtQjhDO0FBQUFBLGdCQUNyQyxVQUFVLENBQUN4RCxNQUNUUSxZQUFZO0FBQUEsa0JBQ1YsR0FBR0Q7QUFBQUEsa0JBQ0hHLG9CQUFvQjtBQUFBLG9CQUNsQixHQUFHSCxTQUFTRztBQUFBQSxvQkFDWjhDLHFCQUFxQnhELEVBQUVFLE9BQU9vSDtBQUFBQSxrQkFDaEM7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQix1QkFBQyxTQUFJLFdBQVUsbVlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK1k7QUFBQSxZQUMvWSx1QkFBQyxVQUFLLFdBQVUsOEJBQ2IvRyxtQkFBU0csbUJBQW1COEMsc0JBQ3pCLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsZUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxhQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMEJBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLG1DQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTakQsU0FBU0csbUJBQW1CK0M7QUFBQUEsZ0JBQ3JDLFVBQVUsQ0FBQ3pELE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNaK0MscUJBQXFCekQsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUNoQztBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUIrQyxzQkFDekIsUUFDQSxRQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxlQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFCQTtBQUFBLGFBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQ0FBb0MsZ0NBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNsRCxTQUFTRyxtQkFBbUJnRDtBQUFBQSxnQkFDckMsVUFBVSxDQUFDMUQsTUFDVFEsWUFBWTtBQUFBLGtCQUNWLEdBQUdEO0FBQUFBLGtCQUNIRyxvQkFBb0I7QUFBQSxvQkFDbEIsR0FBR0gsU0FBU0c7QUFBQUEsb0JBQ1pnRCxrQkFBa0IxRCxFQUFFRSxPQUFPb0g7QUFBQUEsa0JBQzdCO0FBQUEsZ0JBQ0YsQ0FBQztBQUFBLGdCQUVILFdBQVU7QUFBQTtBQUFBLGNBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWTBCO0FBQUEsWUFFMUIsdUJBQUMsU0FBSSxXQUFVLG1ZQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStZO0FBQUEsWUFDL1ksdUJBQUMsVUFBSyxXQUFVLDhCQUNiL0csbUJBQVNHLG1CQUFtQmdELG1CQUN6QixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUJBO0FBQUEsYUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFDQUFvQyxpQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU25ELFNBQVNHLG1CQUFtQmlEO0FBQUFBLGdCQUNyQyxVQUFVLENBQUMzRCxNQUNUUSxZQUFZO0FBQUEsa0JBQ1YsR0FBR0Q7QUFBQUEsa0JBQ0hHLG9CQUFvQjtBQUFBLG9CQUNsQixHQUFHSCxTQUFTRztBQUFBQSxvQkFDWmlELG1CQUFtQjNELEVBQUVFLE9BQU9vSDtBQUFBQSxrQkFDOUI7QUFBQSxnQkFDRixDQUFDO0FBQUEsZ0JBRUgsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZMEI7QUFBQSxZQUUxQix1QkFBQyxTQUFJLFdBQVUsbVlBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK1k7QUFBQSxZQUMvWSx1QkFBQyxVQUFLLFdBQVUsOEJBQ2IvRyxtQkFBU0csbUJBQW1CaUQsb0JBQ3pCLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsZUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxhQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMEJBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUscUNBQW9DLGdDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTcEQsU0FBU0csbUJBQW1Ca0Q7QUFBQUEsZ0JBQ3JDLFVBQVUsQ0FBQzVELE1BQ1RRLFlBQVk7QUFBQSxrQkFDVixHQUFHRDtBQUFBQSxrQkFDSEcsb0JBQW9CO0FBQUEsb0JBQ2xCLEdBQUdILFNBQVNHO0FBQUFBLG9CQUNaa0Qsa0JBQWtCNUQsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUM3QjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFFSCxXQUFVO0FBQUE7QUFBQSxjQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVkwQjtBQUFBLFlBRTFCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUJrRCxtQkFDekIsUUFDQSxRQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxlQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFCQTtBQUFBLGFBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxxQ0FBb0MsaUNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVNyRCxTQUFTRyxtQkFBbUJtRDtBQUFBQSxnQkFDckMsVUFBVSxDQUFDN0QsTUFDVFEsWUFBWTtBQUFBLGtCQUNWLEdBQUdEO0FBQUFBLGtCQUNIRyxvQkFBb0I7QUFBQSxvQkFDbEIsR0FBR0gsU0FBU0c7QUFBQUEsb0JBQ1ptRCxtQkFBbUI3RCxFQUFFRSxPQUFPb0g7QUFBQUEsa0JBQzlCO0FBQUEsZ0JBQ0YsQ0FBQztBQUFBLGdCQUVILFdBQVU7QUFBQTtBQUFBLGNBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBWTBCO0FBQUEsWUFFMUIsdUJBQUMsU0FBSSxXQUFVLG1ZQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStZO0FBQUEsWUFDL1ksdUJBQUMsVUFBSyxXQUFVLDhCQUNiL0csbUJBQVNHLG1CQUFtQm1ELG9CQUN6QixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUJBO0FBQUEsYUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFDQUFvQywyQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRCxNQUFLO0FBQUEsZ0JBQ0wsU0FBU3RELFNBQVNHLG1CQUFtQm9EO0FBQUFBLGdCQUNyQyxVQUFZLENBQUM5RCxNQUFNUSxZQUFZO0FBQUEsa0JBQzdCLEdBQUdEO0FBQUFBLGtCQUNIRyxvQkFBb0I7QUFBQSxvQkFDbEIsR0FBR0gsU0FBU0c7QUFBQUEsb0JBQ1pvRCxhQUFhOUQsRUFBRUUsT0FBT29IO0FBQUFBLGtCQUN4QjtBQUFBLGdCQUNGLENBQUM7QUFBQSxnQkFDRCxXQUFVO0FBQUE7QUFBQSxjQVZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVV3QjtBQUFBLFlBRXhCLHVCQUFDLFNBQUksV0FBVSxtWUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErWTtBQUFBLFlBQy9ZLHVCQUFDLFVBQUssV0FBVSw4QkFDYi9HLG1CQUFTRyxtQkFBbUJvRCxjQUN6QixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFVLHFDQUFvQyxtQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRCxNQUFLO0FBQUEsZ0JBQ0wsU0FBU3ZELFNBQVNHLG1CQUFtQnFEO0FBQUFBLGdCQUNyQyxVQUFZLENBQUMvRCxNQUFNUSxZQUFZO0FBQUEsa0JBQzdCLEdBQUdEO0FBQUFBLGtCQUNIRyxvQkFBb0I7QUFBQSxvQkFDbEIsR0FBR0gsU0FBU0c7QUFBQUEsb0JBQ1pxRCxxQkFBcUIvRCxFQUFFRSxPQUFPb0g7QUFBQUEsa0JBQ2hDO0FBQUEsZ0JBQ0YsQ0FBQztBQUFBLGdCQUNELFdBQVU7QUFBQTtBQUFBLGNBVlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVXdCO0FBQUEsWUFFeEIsdUJBQUMsU0FBSSxXQUFVLG1ZQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStZO0FBQUEsWUFDL1ksdUJBQUMsVUFBSyxXQUFVLDhCQUNiL0csbUJBQVNHLG1CQUFtQnFELHNCQUN6QixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUJBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBS0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxXQUFVO0FBQUEsWUFDbUg7QUFBQTtBQUFBLFVBSC9IO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0F0N0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF1N0NBO0FBQUEsU0EzN0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0N0NBLEtBNzdDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBODdDQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVc5RTtBQUFBQSxRQUNYLFNBQVMsTUFBTUMsbUJBQW1CLEtBQUs7QUFBQSxRQUV2QyxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLG9DQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQSx1QkFBQyxVQUFLLFdBQVUsYUFBWSxVQUFVNEgsY0FBYyxZQUFVLE1BQzVEO0FBQUEsbUNBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQU87QUFBQTtBQUFBLG9CQUVULHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUE7QUFBQTtBQUFBLGdCQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPNUMsZUFBZXpEO0FBQUFBLGtCQUN0QixVQUFVa0c7QUFBQUEsa0JBQ1YsSUFBRztBQUFBLGtCQUNILGFBQVk7QUFBQSxrQkFDWjtBQUFBLGtCQUNBLFdBQVU7QUFBQTtBQUFBLGdCQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVF1STtBQUFBLGNBRXRJcEgsT0FBT2tCLFNBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QmxCLGlCQUFPa0IsU0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUQ7QUFBQSxpQkFsQjNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDhCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBU3lELGVBQWV4RCxtQkFBbUJDO0FBQUFBLG9CQUMzQyxVQUFVLENBQUNYLE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEJDLGdCQUFnQlgsRUFBRUUsT0FBT29IO0FBQUFBLHNCQUMzQjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWTBCO0FBQUEsZ0JBRTFCLHVCQUFDLFNBQUksV0FBVSxxV0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpWDtBQUFBLGdCQUNqWCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRCx5QkFBZXhELG1CQUFtQkMsaUJBQy9CLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsaUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDhCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBU3VELGVBQWV4RCxtQkFBbUJFO0FBQUFBLG9CQUMzQyxVQUFVLENBQUNaLE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEJFLGdCQUFnQlosRUFBRUUsT0FBT29IO0FBQUFBLHNCQUMzQjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWTBCO0FBQUEsZ0JBRTFCLHVCQUFDLFNBQUksV0FBVSxxV0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpWDtBQUFBLGdCQUNqWCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRCx5QkFBZXhELG1CQUFtQkUsaUJBQy9CLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsaUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLHlCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBU3NELGVBQWV4RCxtQkFBbUJHO0FBQUFBLG9CQUMzQyxVQUFVLENBQUNiLE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEJHLFdBQVdiLEVBQUVFLE9BQU9vSDtBQUFBQSxzQkFDdEI7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVkwQjtBQUFBLGdCQUUxQix1QkFBQyxTQUFJLFdBQVUscVdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaVg7QUFBQSxnQkFDalgsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEQseUJBQWV4RCxtQkFBbUJHLFlBQVksUUFBUSxRQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbUJBO0FBQUEsaUJBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBd0JBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDBCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBU3FELGVBQWV4RCxtQkFBbUJJO0FBQUFBLG9CQUMzQyxVQUFVLENBQUNkLE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEJJLFlBQVlkLEVBQUVFLE9BQU9vSDtBQUFBQSxzQkFDdkI7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVkwQjtBQUFBLGdCQUUxQix1QkFBQyxTQUFJLFdBQVUscVdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaVg7QUFBQSxnQkFDalgsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEQseUJBQWV4RCxtQkFBbUJJLGFBQy9CLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsaUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDBCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBU29ELGVBQWV4RCxtQkFBbUJLO0FBQUFBLG9CQUMzQyxVQUFVLENBQUNmLE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEJLLFlBQVlmLEVBQUVFLE9BQU9vSDtBQUFBQSxzQkFDdkI7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVkwQjtBQUFBLGdCQUUxQix1QkFBQyxTQUFJLFdBQVUscVdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaVg7QUFBQSxnQkFDalgsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEQseUJBQWV4RCxtQkFBbUJLLGFBQy9CLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsaUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDRCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBU21ELGVBQWV4RCxtQkFBbUJNO0FBQUFBLG9CQUMzQyxVQUFVLENBQUNoQixNQUNUbUUsa0JBQWtCO0FBQUEsc0JBQ2hCLEdBQUdEO0FBQUFBLHNCQUNIeEQsb0JBQW9CO0FBQUEsd0JBQ2xCLEdBQUd3RCxlQUFleEQ7QUFBQUEsd0JBQ2xCTSxjQUFjaEIsRUFBRUUsT0FBT29IO0FBQUFBLHNCQUN6QjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWTBCO0FBQUEsZ0JBRTFCLHVCQUFDLFNBQUksV0FBVSxxV0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpWDtBQUFBLGdCQUNqWCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRCx5QkFBZXhELG1CQUFtQk0sZUFDL0IsUUFDQSxRQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxQkE7QUFBQSxpQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0MsNEJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTa0QsZUFBZXhELG1CQUFtQk87QUFBQUEsb0JBQzNDLFVBQVUsQ0FBQ2pCLE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEJPLGNBQWNqQixFQUFFRSxPQUFPb0g7QUFBQUEsc0JBQ3pCO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLG9CQUVILFdBQVU7QUFBQTtBQUFBLGtCQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFZMEI7QUFBQSxnQkFFMUIsdUJBQUMsU0FBSSxXQUFVLHFXQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlYO0FBQUEsZ0JBQ2pYLHVCQUFDLFVBQUssV0FBVSw4QkFDYnBELHlCQUFleEQsbUJBQW1CTyxlQUMvQixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFCQTtBQUFBLGlCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQyw2QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVNpRCxlQUFleEQsbUJBQW1CUTtBQUFBQSxvQkFDM0MsVUFBVSxDQUFDbEIsTUFDVG1FLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSHhELG9CQUFvQjtBQUFBLHdCQUNsQixHQUFHd0QsZUFBZXhEO0FBQUFBLHdCQUNsQlEsZUFBZWxCLEVBQUVFLE9BQU9vSDtBQUFBQSxzQkFDMUI7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVkwQjtBQUFBLGdCQUUxQix1QkFBQyxTQUFJLFdBQVUscVdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaVg7QUFBQSxnQkFDalgsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEQseUJBQWV4RCxtQkFBbUJRLGdCQUMvQixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFCQTtBQUFBLGlCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQyw2QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVNnRCxlQUFleEQsbUJBQW1CUztBQUFBQSxvQkFDM0MsVUFBVSxDQUFDbkIsTUFDVG1FLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSHhELG9CQUFvQjtBQUFBLHdCQUNsQixHQUFHd0QsZUFBZXhEO0FBQUFBLHdCQUNsQlMsZUFBZW5CLEVBQUVFLE9BQU9vSDtBQUFBQSxzQkFDMUI7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVkwQjtBQUFBLGdCQUUxQix1QkFBQyxTQUFJLFdBQVUscVdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaVg7QUFBQSxnQkFDalgsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEQseUJBQWV4RCxtQkFBbUJTLGdCQUMvQixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFCQTtBQUFBLGlCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQywrQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVMrQyxlQUFleEQsbUJBQW1CVTtBQUFBQSxvQkFDM0MsVUFBVSxDQUFDcEIsTUFDVG1FLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSHhELG9CQUFvQjtBQUFBLHdCQUNsQixHQUFHd0QsZUFBZXhEO0FBQUFBLHdCQUNsQlUsaUJBQWlCcEIsRUFBRUUsT0FBT29IO0FBQUFBLHNCQUM1QjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWTBCO0FBQUEsZ0JBRTFCLHVCQUFDLFNBQUksV0FBVSxxV0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpWDtBQUFBLGdCQUNqWCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRCx5QkFBZXhELG1CQUFtQlUsa0JBQy9CLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsaUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDhCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBUzhDLGVBQWV4RCxtQkFBbUJXO0FBQUFBLG9CQUMzQyxVQUFVLENBQUNyQixNQUNUbUUsa0JBQWtCO0FBQUEsc0JBQ2hCLEdBQUdEO0FBQUFBLHNCQUNIeEQsb0JBQW9CO0FBQUEsd0JBQ2xCLEdBQUd3RCxlQUFleEQ7QUFBQUEsd0JBQ2xCVyxnQkFBZ0JyQixFQUFFRSxPQUFPb0g7QUFBQUEsc0JBQzNCO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLG9CQUVILFdBQVU7QUFBQTtBQUFBLGtCQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFZMEI7QUFBQSxnQkFFMUIsdUJBQUMsU0FBSSxXQUFVLHFXQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlYO0FBQUEsZ0JBQ2pYLHVCQUFDLFVBQUssV0FBVSw4QkFDYnBELHlCQUFleEQsbUJBQW1CVyxpQkFDL0IsUUFDQSxRQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxQkE7QUFBQSxpQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0MsaUNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUNFNkMsZUFBZXhELG1CQUFtQlk7QUFBQUEsb0JBRXBDLFVBQVUsQ0FBQ3RCLE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEJZLG1CQUFtQnRCLEVBQUVFLE9BQU9vSDtBQUFBQSxzQkFDOUI7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBZFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWMwQjtBQUFBLGdCQUUxQix1QkFBQyxTQUFJLFdBQVUscVdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaVg7QUFBQSxnQkFDalgsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEQseUJBQWV4RCxtQkFBbUJZLG9CQUMvQixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXVCQTtBQUFBLGlCQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTRCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQywrQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVM0QyxlQUFleEQsbUJBQW1CYTtBQUFBQSxvQkFDM0MsVUFBVSxDQUFDdkIsTUFDVG1FLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSHhELG9CQUFvQjtBQUFBLHdCQUNsQixHQUFHd0QsZUFBZXhEO0FBQUFBLHdCQUNsQmEsaUJBQWlCdkIsRUFBRUUsT0FBT29IO0FBQUFBLHNCQUM1QjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWTBCO0FBQUEsZ0JBRTFCLHVCQUFDLFNBQUksV0FBVSxxV0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpWDtBQUFBLGdCQUNqWCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRCx5QkFBZXhELG1CQUFtQmEsa0JBQy9CLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsaUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLCtCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBUzJDLGVBQWV4RCxtQkFBbUJjO0FBQUFBLG9CQUMzQyxVQUFVLENBQUN4QixNQUNUbUUsa0JBQWtCO0FBQUEsc0JBQ2hCLEdBQUdEO0FBQUFBLHNCQUNIeEQsb0JBQW9CO0FBQUEsd0JBQ2xCLEdBQUd3RCxlQUFleEQ7QUFBQUEsd0JBQ2xCYyxpQkFBaUJ4QixFQUFFRSxPQUFPb0g7QUFBQUEsc0JBQzVCO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLG9CQUVILFdBQVU7QUFBQTtBQUFBLGtCQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFZMEI7QUFBQSxnQkFFMUIsdUJBQUMsU0FBSSxXQUFVLHFXQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlYO0FBQUEsZ0JBQ2pYLHVCQUFDLFVBQUssV0FBVSw4QkFDYnBELHlCQUFleEQsbUJBQW1CYyxrQkFDL0IsUUFDQSxRQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxQkE7QUFBQSxpQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0MsNEJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTMEMsZUFBZXhELG1CQUFtQmU7QUFBQUEsb0JBQzNDLFVBQVUsQ0FBQ3pCLE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEJlLGNBQWN6QixFQUFFRSxPQUFPb0g7QUFBQUEsc0JBQ3pCO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLG9CQUVILFdBQVU7QUFBQTtBQUFBLGtCQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFZMEI7QUFBQSxnQkFFMUIsdUJBQUMsU0FBSSxXQUFVLHFXQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlYO0FBQUEsZ0JBQ2pYLHVCQUFDLFVBQUssV0FBVSw4QkFDYnBELHlCQUFleEQsbUJBQW1CZSxlQUMvQixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFCQTtBQUFBLGlCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQyw2QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVN5QyxlQUFleEQsbUJBQW1CZ0I7QUFBQUEsb0JBQzNDLFVBQVUsQ0FBQzFCLE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEJnQixlQUFlMUIsRUFBRUUsT0FBT29IO0FBQUFBLHNCQUMxQjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWTBCO0FBQUEsZ0JBRTFCLHVCQUFDLFNBQUksV0FBVSxxV0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpWDtBQUFBLGdCQUNqWCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRCx5QkFBZXhELG1CQUFtQmdCLGdCQUMvQixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFCQTtBQUFBLGlCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQyw2QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVN3QyxlQUFleEQsbUJBQW1CaUI7QUFBQUEsb0JBQzNDLFVBQVUsQ0FBQzNCLE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEJpQixlQUFlM0IsRUFBRUUsT0FBT29IO0FBQUFBLHNCQUMxQjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWTBCO0FBQUEsZ0JBRTFCLHVCQUFDLFNBQUksV0FBVSxxV0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpWDtBQUFBLGdCQUNqWCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRCx5QkFBZXhELG1CQUFtQmlCLGdCQUMvQixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFCQTtBQUFBLGlCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQywrQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVN1QyxlQUFleEQsbUJBQW1Ca0I7QUFBQUEsb0JBQzNDLFVBQVUsQ0FBQzVCLE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEJrQixpQkFBaUI1QixFQUFFRSxPQUFPb0g7QUFBQUEsc0JBQzVCO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLG9CQUVILFdBQVU7QUFBQTtBQUFBLGtCQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFZMEI7QUFBQSxnQkFFMUIsdUJBQUMsU0FBSSxXQUFVLHFXQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlYO0FBQUEsZ0JBQ2pYLHVCQUFDLFVBQUssV0FBVSw4QkFDYnBELHlCQUFleEQsbUJBQW1Ca0Isa0JBQy9CLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsaUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLG1DQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FDRXNDLGVBQWV4RCxtQkFBbUJtQjtBQUFBQSxvQkFFcEMsVUFBVSxDQUFDN0IsTUFDVG1FLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSHhELG9CQUFvQjtBQUFBLHdCQUNsQixHQUFHd0QsZUFBZXhEO0FBQUFBLHdCQUNsQm1CLHFCQUFxQjdCLEVBQUVFLE9BQU9vSDtBQUFBQSxzQkFDaEM7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBZFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWMwQjtBQUFBLGdCQUUxQix1QkFBQyxTQUFJLFdBQVUscVdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaVg7QUFBQSxnQkFDalgsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEQseUJBQWV4RCxtQkFBbUJtQixzQkFDL0IsUUFDQSxRQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF1QkE7QUFBQSxpQkEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE0QkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0Msd0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTcUMsZUFBZXhELG1CQUFtQm9CO0FBQUFBLG9CQUMzQyxVQUFVLENBQUM5QixNQUNUbUUsa0JBQWtCO0FBQUEsc0JBQ2hCLEdBQUdEO0FBQUFBLHNCQUNIeEQsb0JBQW9CO0FBQUEsd0JBQ2xCLEdBQUd3RCxlQUFleEQ7QUFBQUEsd0JBQ2xCb0IsVUFBVTlCLEVBQUVFLE9BQU9vSDtBQUFBQSxzQkFDckI7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVkwQjtBQUFBLGdCQUUxQix1QkFBQyxTQUFJLFdBQVUscVdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaVg7QUFBQSxnQkFDalgsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEQseUJBQWV4RCxtQkFBbUJvQixXQUFXLFFBQVEsUUFEeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1CQTtBQUFBLGlCQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQyx5QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVNvQyxlQUFleEQsbUJBQW1CcUI7QUFBQUEsb0JBQzNDLFVBQVUsQ0FBQy9CLE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEJxQixXQUFXL0IsRUFBRUUsT0FBT29IO0FBQUFBLHNCQUN0QjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWTBCO0FBQUEsZ0JBRTFCLHVCQUFDLFNBQUksV0FBVSxxV0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpWDtBQUFBLGdCQUNqWCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRCx5QkFBZXhELG1CQUFtQnFCLFlBQVksUUFBUSxRQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbUJBO0FBQUEsaUJBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBd0JBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLHlCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBU21DLGVBQWV4RCxtQkFBbUJzQjtBQUFBQSxvQkFDM0MsVUFBVSxDQUFDaEMsTUFDVG1FLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSHhELG9CQUFvQjtBQUFBLHdCQUNsQixHQUFHd0QsZUFBZXhEO0FBQUFBLHdCQUNsQnNCLFdBQVdoQyxFQUFFRSxPQUFPb0g7QUFBQUEsc0JBQ3RCO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLG9CQUVILFdBQVU7QUFBQTtBQUFBLGtCQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFZMEI7QUFBQSxnQkFFMUIsdUJBQUMsU0FBSSxXQUFVLHFXQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlYO0FBQUEsZ0JBQ2pYLHVCQUFDLFVBQUssV0FBVSw4QkFDYnBELHlCQUFleEQsbUJBQW1Cc0IsWUFBWSxRQUFRLFFBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFtQkE7QUFBQSxpQkF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF3QkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0MsMkJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTa0MsZUFBZXhELG1CQUFtQnVCO0FBQUFBLG9CQUMzQyxVQUFVLENBQUNqQyxNQUNUbUUsa0JBQWtCO0FBQUEsc0JBQ2hCLEdBQUdEO0FBQUFBLHNCQUNIeEQsb0JBQW9CO0FBQUEsd0JBQ2xCLEdBQUd3RCxlQUFleEQ7QUFBQUEsd0JBQ2xCdUIsYUFBYWpDLEVBQUVFLE9BQU9vSDtBQUFBQSxzQkFDeEI7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVkwQjtBQUFBLGdCQUUxQix1QkFBQyxTQUFJLFdBQVUscVdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaVg7QUFBQSxnQkFDalgsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEQseUJBQWV4RCxtQkFBbUJ1QixjQUMvQixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFCQTtBQUFBLGlCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQyx3QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVNpQyxlQUFleEQsbUJBQW1Cd0I7QUFBQUEsb0JBQzNDLFVBQVUsQ0FBQ2xDLE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEJ3QixVQUFVbEMsRUFBRUUsT0FBT29IO0FBQUFBLHNCQUNyQjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWTBCO0FBQUEsZ0JBRTFCLHVCQUFDLFNBQUksV0FBVSxxV0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpWDtBQUFBLGdCQUNqWCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRCx5QkFBZXhELG1CQUFtQndCLFdBQVcsUUFBUSxRQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbUJBO0FBQUEsaUJBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBd0JBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLHlCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBU2dDLGVBQWV4RCxtQkFBbUJ5QjtBQUFBQSxvQkFDM0MsVUFBVSxDQUFDbkMsTUFDVG1FLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSHhELG9CQUFvQjtBQUFBLHdCQUNsQixHQUFHd0QsZUFBZXhEO0FBQUFBLHdCQUNsQnlCLFdBQVduQyxFQUFFRSxPQUFPb0g7QUFBQUEsc0JBQ3RCO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLG9CQUVILFdBQVU7QUFBQTtBQUFBLGtCQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFZMEI7QUFBQSxnQkFFMUIsdUJBQUMsU0FBSSxXQUFVLHFXQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlYO0FBQUEsZ0JBQ2pYLHVCQUFDLFVBQUssV0FBVSw4QkFDYnBELHlCQUFleEQsbUJBQW1CeUIsWUFBWSxRQUFRLFFBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFtQkE7QUFBQSxpQkF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF3QkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0MseUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTK0IsZUFBZXhELG1CQUFtQjBCO0FBQUFBLG9CQUMzQyxVQUFVLENBQUNwQyxNQUNUbUUsa0JBQWtCO0FBQUEsc0JBQ2hCLEdBQUdEO0FBQUFBLHNCQUNIeEQsb0JBQW9CO0FBQUEsd0JBQ2xCLEdBQUd3RCxlQUFleEQ7QUFBQUEsd0JBQ2xCMEIsV0FBV3BDLEVBQUVFLE9BQU9vSDtBQUFBQSxzQkFDdEI7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVkwQjtBQUFBLGdCQUUxQix1QkFBQyxTQUFJLFdBQVUscVdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaVg7QUFBQSxnQkFDalgsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEQseUJBQWV4RCxtQkFBbUIwQixZQUFZLFFBQVEsUUFEekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1CQTtBQUFBLGlCQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQywyQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVM4QixlQUFleEQsbUJBQW1CMkI7QUFBQUEsb0JBQzNDLFVBQVUsQ0FBQ3JDLE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEIyQixhQUFhckMsRUFBRUUsT0FBT29IO0FBQUFBLHNCQUN4QjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWTBCO0FBQUEsZ0JBRTFCLHVCQUFDLFNBQUksV0FBVSxxV0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpWDtBQUFBLGdCQUNqWCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRCx5QkFBZXhELG1CQUFtQjJCLGNBQy9CLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsaUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLHlCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBUzZCLGVBQWV4RCxtQkFBbUI0QjtBQUFBQSxvQkFDM0MsVUFBVSxDQUFDdEMsTUFDVG1FLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSHhELG9CQUFvQjtBQUFBLHdCQUNsQixHQUFHd0QsZUFBZXhEO0FBQUFBLHdCQUNsQjRCLFdBQVd0QyxFQUFFRSxPQUFPb0g7QUFBQUEsc0JBQ3RCO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLG9CQUVILFdBQVU7QUFBQTtBQUFBLGtCQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFZMEI7QUFBQSxnQkFFMUIsdUJBQUMsU0FBSSxXQUFVLHFXQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlYO0FBQUEsZ0JBQ2pYLHVCQUFDLFVBQUssV0FBVSw4QkFDYnBELHlCQUFleEQsbUJBQW1CNEIsWUFBWSxRQUFRLFFBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFtQkE7QUFBQSxpQkF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF3QkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0MsMEJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTNEIsZUFBZXhELG1CQUFtQjZCO0FBQUFBLG9CQUMzQyxVQUFVLENBQUN2QyxNQUNUbUUsa0JBQWtCO0FBQUEsc0JBQ2hCLEdBQUdEO0FBQUFBLHNCQUNIeEQsb0JBQW9CO0FBQUEsd0JBQ2xCLEdBQUd3RCxlQUFleEQ7QUFBQUEsd0JBQ2xCNkIsWUFBWXZDLEVBQUVFLE9BQU9vSDtBQUFBQSxzQkFDdkI7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVkwQjtBQUFBLGdCQUUxQix1QkFBQyxTQUFJLFdBQVUscVdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaVg7QUFBQSxnQkFDalgsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEQseUJBQWV4RCxtQkFBbUI2QixhQUMvQixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFCQTtBQUFBLGlCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQywwQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVMyQixlQUFleEQsbUJBQW1COEI7QUFBQUEsb0JBQzNDLFVBQVUsQ0FBQ3hDLE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEI4QixZQUFZeEMsRUFBRUUsT0FBT29IO0FBQUFBLHNCQUN2QjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWTBCO0FBQUEsZ0JBRTFCLHVCQUFDLFNBQUksV0FBVSxxV0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpWDtBQUFBLGdCQUNqWCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRCx5QkFBZXhELG1CQUFtQjhCLGFBQy9CLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsaUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDRCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBUzBCLGVBQWV4RCxtQkFBbUIrQjtBQUFBQSxvQkFDM0MsVUFBVSxDQUFDekMsTUFDVG1FLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSHhELG9CQUFvQjtBQUFBLHdCQUNsQixHQUFHd0QsZUFBZXhEO0FBQUFBLHdCQUNsQitCLGNBQWN6QyxFQUFFRSxPQUFPb0g7QUFBQUEsc0JBQ3pCO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLG9CQUVILFdBQVU7QUFBQTtBQUFBLGtCQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFZMEI7QUFBQSxnQkFFMUIsdUJBQUMsU0FBSSxXQUFVLHFXQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlYO0FBQUEsZ0JBQ2pYLHVCQUFDLFVBQUssV0FBVSw4QkFDYnBELHlCQUFleEQsbUJBQW1CK0IsZUFDL0IsUUFDQSxRQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxQkE7QUFBQSxpQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0MsMkJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTeUIsZUFBZXhELG1CQUFtQmdDO0FBQUFBLG9CQUMzQyxVQUFVLENBQUMxQyxNQUNUbUUsa0JBQWtCO0FBQUEsc0JBQ2hCLEdBQUdEO0FBQUFBLHNCQUNIeEQsb0JBQW9CO0FBQUEsd0JBQ2xCLEdBQUd3RCxlQUFleEQ7QUFBQUEsd0JBQ2xCZ0MsYUFBYTFDLEVBQUVFLE9BQU9vSDtBQUFBQSxzQkFDeEI7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVkwQjtBQUFBLGdCQUUxQix1QkFBQyxTQUFJLFdBQVUscVdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaVg7QUFBQSxnQkFDalgsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEQseUJBQWV4RCxtQkFBbUJnQyxjQUMvQixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFCQTtBQUFBLGlCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQyw0QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVN3QixlQUFleEQsbUJBQW1CaUM7QUFBQUEsb0JBQzNDLFVBQVUsQ0FBQzNDLE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEJpQyxjQUFjM0MsRUFBRUUsT0FBT29IO0FBQUFBLHNCQUN6QjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWTBCO0FBQUEsZ0JBRTFCLHVCQUFDLFNBQUksV0FBVSxxV0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpWDtBQUFBLGdCQUNqWCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRCx5QkFBZXhELG1CQUFtQmlDLGVBQy9CLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsaUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDRCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBU3VCLGVBQWV4RCxtQkFBbUJrQztBQUFBQSxvQkFDM0MsVUFBVSxDQUFDNUMsTUFDVG1FLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSHhELG9CQUFvQjtBQUFBLHdCQUNsQixHQUFHd0QsZUFBZXhEO0FBQUFBLHdCQUNsQmtDLGNBQWM1QyxFQUFFRSxPQUFPb0g7QUFBQUEsc0JBQ3pCO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLG9CQUVILFdBQVU7QUFBQTtBQUFBLGtCQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFZMEI7QUFBQSxnQkFFMUIsdUJBQUMsU0FBSSxXQUFVLHFXQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlYO0FBQUEsZ0JBQ2pYLHVCQUFDLFVBQUssV0FBVSw4QkFDYnBELHlCQUFleEQsbUJBQW1Ca0MsZUFDL0IsUUFDQSxRQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxQkE7QUFBQSxpQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0MsOEJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTc0IsZUFBZXhELG1CQUFtQm1DO0FBQUFBLG9CQUMzQyxVQUFVLENBQUM3QyxNQUNUbUUsa0JBQWtCO0FBQUEsc0JBQ2hCLEdBQUdEO0FBQUFBLHNCQUNIeEQsb0JBQW9CO0FBQUEsd0JBQ2xCLEdBQUd3RCxlQUFleEQ7QUFBQUEsd0JBQ2xCbUMsZ0JBQWdCN0MsRUFBRUUsT0FBT29IO0FBQUFBLHNCQUMzQjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWTBCO0FBQUEsZ0JBRTFCLHVCQUFDLFNBQUksV0FBVSxxV0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpWDtBQUFBLGdCQUNqWCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRCx5QkFBZXhELG1CQUFtQm1DLGlCQUMvQixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFCQTtBQUFBLGlCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQywyQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVNxQixlQUFleEQsbUJBQW1Cb0M7QUFBQUEsb0JBQzNDLFVBQVUsQ0FBQzlDLE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEJvQyxhQUFhOUMsRUFBRUUsT0FBT29IO0FBQUFBLHNCQUN4QjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWTBCO0FBQUEsZ0JBRTFCLHVCQUFDLFNBQUksV0FBVSxxV0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpWDtBQUFBLGdCQUNqWCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRCx5QkFBZXhELG1CQUFtQm9DLGNBQy9CLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsaUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDRCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBU29CLGVBQWV4RCxtQkFBbUJxQztBQUFBQSxvQkFDM0MsVUFBVSxDQUFDL0MsTUFDVG1FLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSHhELG9CQUFvQjtBQUFBLHdCQUNsQixHQUFHd0QsZUFBZXhEO0FBQUFBLHdCQUNsQnFDLGNBQWMvQyxFQUFFRSxPQUFPb0g7QUFBQUEsc0JBQ3pCO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLG9CQUVILFdBQVU7QUFBQTtBQUFBLGtCQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFZMEI7QUFBQSxnQkFFMUIsdUJBQUMsU0FBSSxXQUFVLHFXQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlYO0FBQUEsZ0JBQ2pYLHVCQUFDLFVBQUssV0FBVSw4QkFDYnBELHlCQUFleEQsbUJBQW1CcUMsZUFDL0IsUUFDQSxRQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxQkE7QUFBQSxpQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0MsNEJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTbUIsZUFBZXhELG1CQUFtQnNDO0FBQUFBLG9CQUMzQyxVQUFVLENBQUNoRCxNQUNUbUUsa0JBQWtCO0FBQUEsc0JBQ2hCLEdBQUdEO0FBQUFBLHNCQUNIeEQsb0JBQW9CO0FBQUEsd0JBQ2xCLEdBQUd3RCxlQUFleEQ7QUFBQUEsd0JBQ2xCc0MsY0FBY2hELEVBQUVFLE9BQU9vSDtBQUFBQSxzQkFDekI7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVkwQjtBQUFBLGdCQUUxQix1QkFBQyxTQUFJLFdBQVUscVdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaVg7QUFBQSxnQkFDalgsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEQseUJBQWV4RCxtQkFBbUJzQyxlQUMvQixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFCQTtBQUFBLGlCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQyxvQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQ0VrQixlQUFleEQsbUJBQW1CdUM7QUFBQUEsb0JBRXBDLFVBQVUsQ0FBQ2pELE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEJ1QyxzQkFBc0JqRCxFQUFFRSxPQUFPb0g7QUFBQUEsc0JBQ2pDO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLG9CQUVILFdBQVU7QUFBQTtBQUFBLGtCQWRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFjMEI7QUFBQSxnQkFFMUIsdUJBQUMsU0FBSSxXQUFVLHFXQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlYO0FBQUEsZ0JBQ2pYLHVCQUFDLFVBQUssV0FBVSw4QkFDYnBELHlCQUFleEQsbUJBQW1CdUMsdUJBQy9CLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdUJBO0FBQUEsaUJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNEJBO0FBQUEsWUFFQyx1QkFBQyxTQUFJLFdBQVUsMENBQ2Q7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLGlDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FDRWlCLGVBQWV4RCxtQkFBbUJ1RDtBQUFBQSxvQkFFcEMsVUFBVSxDQUFDakUsTUFDVG1FLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSHhELG9CQUFvQjtBQUFBLHdCQUNsQixHQUFHd0QsZUFBZXhEO0FBQUFBLHdCQUNsQnVELG1CQUFtQmpFLEVBQUVFLE9BQU9vSDtBQUFBQSxzQkFDOUI7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBZFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWMwQjtBQUFBLGdCQUUxQix1QkFBQyxTQUFJLFdBQVUscVdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaVg7QUFBQSxnQkFDalgsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEQseUJBQWV4RCxtQkFBbUJ1RCxvQkFDL0IsUUFDQSxRQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF1QkE7QUFBQSxpQkEzQkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE0QkQ7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0MsOEJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTQyxlQUFleEQsbUJBQW1Cd0M7QUFBQUEsb0JBQzNDLFVBQVUsQ0FBQ2xELE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEJ3QyxnQkFBZ0JsRCxFQUFFRSxPQUFPb0g7QUFBQUEsc0JBQzNCO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLG9CQUVILFdBQVU7QUFBQTtBQUFBLGtCQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFZMEI7QUFBQSxnQkFFMUIsdUJBQUMsU0FBSSxXQUFVLHFXQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlYO0FBQUEsZ0JBQ2pYLHVCQUFDLFVBQUssV0FBVSw4QkFDYnBELHlCQUFleEQsbUJBQW1Cd0MsaUJBQy9CLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsaUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDRCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBU2dCLGVBQWV4RCxtQkFBbUJ5QztBQUFBQSxvQkFDM0MsVUFBVSxDQUFDbkQsTUFDVG1FLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSHhELG9CQUFvQjtBQUFBLHdCQUNsQixHQUFHd0QsZUFBZXhEO0FBQUFBLHdCQUNsQnlDLGNBQWNuRCxFQUFFRSxPQUFPb0g7QUFBQUEsc0JBQ3pCO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLG9CQUVILFdBQVU7QUFBQTtBQUFBLGtCQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFZMEI7QUFBQSxnQkFFMUIsdUJBQUMsU0FBSSxXQUFVLHFXQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlYO0FBQUEsZ0JBQ2pYLHVCQUFDLFVBQUssV0FBVSw4QkFDYnBELHlCQUFleEQsbUJBQW1CeUMsZUFDL0IsUUFDQSxRQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxQkE7QUFBQSxpQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0MsNEJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTZSxlQUFleEQsbUJBQW1CMEM7QUFBQUEsb0JBQzNDLFVBQVUsQ0FBQ3BELE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEIwQyxjQUFjcEQsRUFBRUUsT0FBT29IO0FBQUFBLHNCQUN6QjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWTBCO0FBQUEsZ0JBRTFCLHVCQUFDLFNBQUksV0FBVSxxV0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpWDtBQUFBLGdCQUNqWCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRCx5QkFBZXhELG1CQUFtQjBDLGVBQy9CLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsaUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLGlDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FDRWMsZUFBZXhELG1CQUFtQjJDO0FBQUFBLG9CQUVwQyxVQUFVLENBQUNyRCxNQUNUbUUsa0JBQWtCO0FBQUEsc0JBQ2hCLEdBQUdEO0FBQUFBLHNCQUNIeEQsb0JBQW9CO0FBQUEsd0JBQ2xCLEdBQUd3RCxlQUFleEQ7QUFBQUEsd0JBQ2xCMkMsbUJBQW1CckQsRUFBRUUsT0FBT29IO0FBQUFBLHNCQUM5QjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFkWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBYzBCO0FBQUEsZ0JBRTFCLHVCQUFDLFNBQUksV0FBVSxxV0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpWDtBQUFBLGdCQUNqWCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRCx5QkFBZXhELG1CQUFtQjJDLG9CQUMvQixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXVCQTtBQUFBLGlCQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTRCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQyx3Q0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQ0VhLGVBQWV4RCxtQkFBbUI0QztBQUFBQSxvQkFFcEMsVUFBVSxDQUFDdEQsTUFDVG1FLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSHhELG9CQUFvQjtBQUFBLHdCQUNsQixHQUFHd0QsZUFBZXhEO0FBQUFBLHdCQUNsQjRDLDBCQUEwQnRELEVBQUVFLE9BQU9vSDtBQUFBQSxzQkFDckM7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBZFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWMwQjtBQUFBLGdCQUUxQix1QkFBQyxTQUFJLFdBQVUscVdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaVg7QUFBQSxnQkFDalgsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEQseUJBQWV4RCxtQkFBbUI0QywyQkFDL0IsUUFDQSxRQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF1QkE7QUFBQSxpQkEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE0QkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0Msb0NBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUNFWSxlQUFleEQsbUJBQW1CNkM7QUFBQUEsb0JBRXBDLFVBQVUsQ0FBQ3ZELE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEI2QyxzQkFBc0J2RCxFQUFFRSxPQUFPb0g7QUFBQUEsc0JBQ2pDO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLG9CQUVILFdBQVU7QUFBQTtBQUFBLGtCQWRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFjMEI7QUFBQSxnQkFFMUIsdUJBQUMsU0FBSSxXQUFVLHFXQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlYO0FBQUEsZ0JBQ2pYLHVCQUFDLFVBQUssV0FBVSw4QkFDYnBELHlCQUFleEQsbUJBQW1CNkMsdUJBQy9CLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdUJBO0FBQUEsaUJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNEJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLG1DQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FDRVcsZUFBZXhELG1CQUFtQjhDO0FBQUFBLG9CQUVwQyxVQUFVLENBQUN4RCxNQUNUbUUsa0JBQWtCO0FBQUEsc0JBQ2hCLEdBQUdEO0FBQUFBLHNCQUNIeEQsb0JBQW9CO0FBQUEsd0JBQ2xCLEdBQUd3RCxlQUFleEQ7QUFBQUEsd0JBQ2xCOEMscUJBQXFCeEQsRUFBRUUsT0FBT29IO0FBQUFBLHNCQUNoQztBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFkWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBYzBCO0FBQUEsZ0JBRTFCLHVCQUFDLFNBQUksV0FBVSxxV0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpWDtBQUFBLGdCQUNqWCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRCx5QkFBZXhELG1CQUFtQjhDLHNCQUMvQixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXVCQTtBQUFBLGlCQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTRCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQyxtQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQ0VVLGVBQWV4RCxtQkFBbUIrQztBQUFBQSxvQkFFcEMsVUFBVSxDQUFDekQsTUFDVG1FLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSHhELG9CQUFvQjtBQUFBLHdCQUNsQixHQUFHd0QsZUFBZXhEO0FBQUFBLHdCQUNsQitDLHFCQUFxQnpELEVBQUVFLE9BQU9vSDtBQUFBQSxzQkFDaEM7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBZFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWMwQjtBQUFBLGdCQUUxQix1QkFBQyxTQUFJLFdBQVUscVdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaVg7QUFBQSxnQkFDalgsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEQseUJBQWV4RCxtQkFBbUIrQyxzQkFDL0IsUUFDQSxRQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF1QkE7QUFBQSxpQkEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE0QkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0MsZ0NBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUFTUyxlQUFleEQsbUJBQW1CZ0Q7QUFBQUEsb0JBQzNDLFVBQVUsQ0FBQzFELE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEJnRCxrQkFBa0IxRCxFQUFFRSxPQUFPb0g7QUFBQUEsc0JBQzdCO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLG9CQUVILFdBQVU7QUFBQTtBQUFBLGtCQVpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFZMEI7QUFBQSxnQkFFMUIsdUJBQUMsU0FBSSxXQUFVLHFXQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlYO0FBQUEsZ0JBQ2pYLHVCQUFDLFVBQUssV0FBVSw4QkFDYnBELHlCQUFleEQsbUJBQW1CZ0QsbUJBQy9CLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsaUJBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLGlDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FDRVEsZUFBZXhELG1CQUFtQmlEO0FBQUFBLG9CQUVwQyxVQUFVLENBQUMzRCxNQUNUbUUsa0JBQWtCO0FBQUEsc0JBQ2hCLEdBQUdEO0FBQUFBLHNCQUNIeEQsb0JBQW9CO0FBQUEsd0JBQ2xCLEdBQUd3RCxlQUFleEQ7QUFBQUEsd0JBQ2xCaUQsbUJBQW1CM0QsRUFBRUUsT0FBT29IO0FBQUFBLHNCQUM5QjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFkWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBYzBCO0FBQUEsZ0JBRTFCLHVCQUFDLFNBQUksV0FBVSxxV0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpWDtBQUFBLGdCQUNqWCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRCx5QkFBZXhELG1CQUFtQmlELG9CQUMvQixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXVCQTtBQUFBLGlCQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTRCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQyxnQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVNPLGVBQWV4RCxtQkFBbUJrRDtBQUFBQSxvQkFDM0MsVUFBVSxDQUFDNUQsTUFDVG1FLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSHhELG9CQUFvQjtBQUFBLHdCQUNsQixHQUFHd0QsZUFBZXhEO0FBQUFBLHdCQUNsQmtELGtCQUFrQjVELEVBQUVFLE9BQU9vSDtBQUFBQSxzQkFDN0I7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVkwQjtBQUFBLGdCQUUxQix1QkFBQyxTQUFJLFdBQVUscVdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaVg7QUFBQSxnQkFDalgsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEQseUJBQWV4RCxtQkFBbUJrRCxtQkFDL0IsUUFDQSxRQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxQkE7QUFBQSxpQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQkE7QUFBQSxZQStCQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUscUNBQW9DLGlDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsb0RBQ2Y7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FDRU0sZUFBZXhELG1CQUFtQm1EO0FBQUFBLG9CQUVwQyxVQUFVLENBQUM3RCxNQUNUbUUsa0JBQWtCO0FBQUEsc0JBQ2hCLEdBQUdEO0FBQUFBLHNCQUNIeEQsb0JBQW9CO0FBQUEsd0JBQ2xCLEdBQUd3RCxlQUFleEQ7QUFBQUEsd0JBQ2xCbUQsbUJBQW1CN0QsRUFBRUUsT0FBT29IO0FBQUFBLHNCQUM5QjtBQUFBLG9CQUNGLENBQUM7QUFBQSxvQkFFSCxXQUFVO0FBQUE7QUFBQSxrQkFkWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBYzBCO0FBQUEsZ0JBRTFCLHVCQUFDLFNBQUksV0FBVSxxV0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpWDtBQUFBLGdCQUNqWCx1QkFBQyxVQUFLLFdBQVUsOEJBQ2JwRCx5QkFBZXhELG1CQUFtQm1ELG9CQUMvQixRQUNBLFFBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXVCQTtBQUFBLGlCQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTRCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQywyQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQ0VLLGVBQWV4RCxtQkFBbUJvRDtBQUFBQSxvQkFFcEMsVUFBVSxDQUFDOUQsTUFDVG1FLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSHhELG9CQUFvQjtBQUFBLHdCQUNsQixHQUFHd0QsZUFBZXhEO0FBQUFBLHdCQUNsQm9ELGFBQWE5RCxFQUFFRSxPQUFPb0g7QUFBQUEsc0JBQ3hCO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLG9CQUVILFdBQVU7QUFBQTtBQUFBLGtCQWRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFjMEI7QUFBQSxnQkFFMUIsdUJBQUMsU0FBSSxXQUFVLHFXQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlYO0FBQUEsZ0JBQ2pYLHVCQUFDLFVBQUssV0FBVSw4QkFDYnBELHlCQUFleEQsbUJBQW1Cb0QsY0FDL0IsUUFDQSxRQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF1QkE7QUFBQSxpQkEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE0QkE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSxxQ0FBb0MsbUNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSxvREFDZjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxTQUNFSSxlQUFleEQsbUJBQW1CcUQ7QUFBQUEsb0JBRXBDLFVBQVUsQ0FBQy9ELE1BQ1RtRSxrQkFBa0I7QUFBQSxzQkFDaEIsR0FBR0Q7QUFBQUEsc0JBQ0h4RCxvQkFBb0I7QUFBQSx3QkFDbEIsR0FBR3dELGVBQWV4RDtBQUFBQSx3QkFDbEJxRCxxQkFBcUIvRCxFQUFFRSxPQUFPb0g7QUFBQUEsc0JBQ2hDO0FBQUEsb0JBQ0YsQ0FBQztBQUFBLG9CQUVILFdBQVU7QUFBQTtBQUFBLGtCQWRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFjMEI7QUFBQSxnQkFFMUIsdUJBQUMsU0FBSSxXQUFVLHFXQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlYO0FBQUEsZ0JBQ2pYLHVCQUFDLFVBQUssV0FBVSw4QkFDYnBELHlCQUFleEQsbUJBQW1CcUQsc0JBQy9CLFFBQ0EsUUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdUJBO0FBQUEsaUJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNEJBO0FBQUEsWUFFUSx1QkFBQyxTQUFJLFdBQVUsMENBQ25DO0FBQUEscUNBQUMsVUFBSyxXQUFVLHFDQUFvQyxzQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLG9EQUNmO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVNHLGVBQWV4RCxtQkFBbUJzRDtBQUFBQSxvQkFDM0MsVUFBVSxDQUFDaEUsTUFDVG1FLGtCQUFrQjtBQUFBLHNCQUNoQixHQUFHRDtBQUFBQSxzQkFDSHhELG9CQUFvQjtBQUFBLHdCQUNsQixHQUFHd0QsZUFBZXhEO0FBQUFBLHdCQUNsQnNELHdCQUF3QmhFLEVBQUVFLE9BQU9vSDtBQUFBQSxzQkFDbkM7QUFBQSxvQkFDRixDQUFDO0FBQUEsb0JBRUgsV0FBVTtBQUFBO0FBQUEsa0JBWlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVkwQjtBQUFBLGdCQUUxQix1QkFBQyxTQUFJLFdBQVUscVdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaVg7QUFBQSxnQkFDalgsdUJBQUMsVUFBSyxXQUFVLDhCQUNicEQseUJBQWV4RCxtQkFBbUJzRCx5QkFBeUIsUUFBUSxRQUR0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbUJBO0FBQUEsaUJBdkJvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdCdEI7QUFBQSxZQUVjLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQzZGO0FBQUE7QUFBQSxjQUh6RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQXBrREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxa0RBO0FBQUEsYUExa0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEya0RBO0FBQUE7QUFBQSxNQS9rREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZ2xEQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVdqRjtBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiQyw2QkFBbUIsS0FBSztBQUN4QkkseUJBQWUsSUFBSTtBQUFBLFFBQ3JCO0FBQUEsUUFFQSxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLGtDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQ0QsZUFDQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsVUFBVSxDQUFDYSxNQUFNO0FBQ2ZBLGtCQUFFNkYsZUFBZTtBQUNqQmUsaUNBQWlCO0FBQUEsY0FDbkI7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsU0FDQztBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixTQUFRO0FBQUEsc0JBQVc7QUFBQTtBQUFBLHdCQUVOO0FBQUEsd0JBQ2IsdUJBQUMsVUFBSyxXQUFVLDBCQUNiekgsc0JBQVlzQixTQURmO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSx3QkFBUTtBQUFBLHdCQUFJO0FBQUEsd0JBQ1M7QUFBQSx3QkFDckIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBaUM7QUFBQTtBQUFBO0FBQUEsb0JBVG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFVQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxJQUFHO0FBQUEsc0JBQ0gsYUFBWTtBQUFBLHNCQUNaO0FBQUEsc0JBQ0EsV0FBVTtBQUFBO0FBQUEsb0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUt1STtBQUFBLHFCQWpCekk7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFtQkE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUN5RjtBQUFBO0FBQUEsa0JBSHJHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBO0FBQUE7QUFBQSxZQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFrQ0E7QUFBQSxhQXZDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUNBO0FBQUE7QUFBQSxNQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFpREE7QUFBQSxPQXRuR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVuR0EsS0F4bkdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5bkdBO0FBRUo7QUFBRW5DLEdBMXhISUQsbUJBQWlCO0FBQUFrSixLQUFqQmxKO0FBNHhITixlQUFlQTtBQUFrQixJQUFBa0o7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiU2V0dGluZ1NpZGViYXIiLCJJb01kTW9yZSIsIklucHV0IiwiRHJvcGRvd24iLCJNb2RhbCIsImFwaSIsIkRhdGFUYWJsZSIsIk5hdmJhciIsImZpbHRlck9wdGlvbiIsIkNpcmN1bGFyTG9hZGVyIiwiQ3VzdG9tQWxlcnREaWFsb2ciLCJmaWVsZFNpemUiLCJnZXRBY2Nlc3NSaWdodHNFcnJvck1lc3NhZ2UiLCJlcnJvciIsInJlc3BvbnNlIiwiZGF0YSIsIm1lc3NhZ2UiLCJBZG1pbkFjY2Vzc1JpZ2h0cyIsIl9zIiwidXNlcnMiLCJzZXRVc2VycyIsIlRhYmxlQWdlbnRzIiwic2V0VGFibGVBZ2VudHMiLCJzZWFyY2hUZXJtIiwic2V0U2VhcmNoVGVybSIsInNob3dNb2RhbCIsInNldFNob3dNb2RhbCIsInNob3dNb2RhbERlbGV0ZSIsInNldFNob3dNb2RhbERlbGV0ZSIsInNob3dNb2RhbFVwZGF0ZSIsInNldFNob3dNb2RhbFVwZGF0ZSIsImN1cnJlbnRVc2VyIiwic2V0Q3VycmVudFVzZXIiLCJjdXJyZW50VXBkYXRlVXNlciIsInNldEN1cnJlbnRVcGRhdGVVc2VyIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJyZWxvYWRUcmlnZ2VyIiwic2V0UmVsb2FkVHJpZ2dlciIsIm9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciIsImUiLCJ2YWx1ZSIsInRhcmdldCIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwidHlwZSIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJ0aXRsZSIsImFjY2Vzc19wZXJtaXNzaW9ucyIsInZpZXdfZGFzaGJvYXJkIiwidmlld19hbmFseXRpY3MiLCJhZGRfZ3JvdXAiLCJ2aWV3X2dyb3VwIiwiZWRpdF9ncm91cCIsImRlbGV0ZV9ncm91cCIsImFkZF9jdXN0b21lciIsInZpZXdfY3VzdG9tZXIiLCJlZGl0X2N1c3RvbWVyIiwiZGVsZXRlX2N1c3RvbWVyIiwiYWRkX2Vucm9sbG1lbnQiLCJkZWxldGVfZW5yb2xsbWVudCIsInZpZXdfZW5yb2xsbWVudCIsImVkaXRfZW5yb2xsbWVudCIsImFkZF9lbXBsb3llZSIsInZpZXdfZW1wbG95ZWUiLCJlZGl0X2VtcGxveWVlIiwiZGVsZXRlX2VtcGxveWVlIiwibW9kaWZ5X3BheW1lbnRfZGF0ZSIsImFkZF9sZWFkIiwidmlld19sZWFkIiwiZWRpdF9sZWFkIiwiZGVsZXRlX2xlYWQiLCJhZGRfbG9hbiIsInZpZXdfbG9hbiIsImVkaXRfbG9hbiIsImRlbGV0ZV9sb2FuIiwiYWRkX3BpZ21lIiwidmlld19waWdtZSIsImVkaXRfcGlnbWUiLCJkZWxldGVfcGlnbWUiLCJhZGRfYXVjdGlvbiIsInZpZXdfYXVjdGlvbiIsImVkaXRfYXVjdGlvbiIsImRlbGV0ZV9hdWN0aW9uIiwiYWRkX3BheW1lbnQiLCJ2aWV3X3BheW1lbnQiLCJlZGl0X3BheW1lbnQiLCJlZGl0X2xpbWl0ZWRfcGF5bWVudCIsImRlbGV0ZV9wYXltZW50Iiwidmlld19yZXBvcnRzIiwidmlld19kYXlib29rIiwidmlld19ncm91cF9yZXBvcnQiLCJ2aWV3X2FsbF9jdXN0b21lcl9yZXBvcnQiLCJ2aWV3X2N1c3RvbWVyX3JlcG9ydCIsInZpZXdfcmVjZWlwdF9yZXBvcnQiLCJ2aWV3X2F1Y3Rpb25fcmVwb3J0Iiwidmlld19sZWFkX3JlcG9ydCIsInZpZXdfcGlnbWVfcmVwb3J0Iiwidmlld19sb2FuX3JlcG9ydCIsInZpZXdfYWdlbnRfcmVwb3J0Iiwidmlld190YXJnZXQiLCJ2aWV3X21vYmlsZV9vcHRpb25zIiwidmlld19zdXNwZW5zZV9wYXltZW50cyIsInVubGlua19lbnJvbGxtZW50IiwidXBkYXRlRm9ybURhdGEiLCJzZXRVcGRhdGVGb3JtRGF0YSIsImZldGNoQWRtaW5SaWdodHMiLCJnZXQiLCJmb3JtYXR0ZWREYXRhIiwibWFwIiwiYWRtaW5BY2Nlc3MiLCJpbmRleCIsIl9pZCIsImlkIiwiYWN0aW9uIiwiaXRlbXMiLCJrZXkiLCJsYWJlbCIsImhhbmRsZVVwZGF0ZU1vZGFsT3BlbiIsImhhbmRsZURlbGV0ZU1vZGFsT3BlbiIsImNvbnNvbGUiLCJoYW5kbGVDaGFuZ2UiLCJuYW1lIiwicHJldkRhdGEiLCJ2YWxpZGF0ZUZvcm0iLCJuZXdFcnJvcnMiLCJ0cmltIiwiT2JqZWN0Iiwia2V5cyIsImxlbmd0aCIsImhhbmRsZVN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwiaXNWYWxpZGF0ZSIsInBvc3QiLCJoZWFkZXJzIiwicHJldiIsImNvbHVtbnMiLCJoZWFkZXIiLCJmaWx0ZXJlZFVzZXJzIiwiZmlsdGVyIiwidXNlciIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJ1c2VySWQiLCJhY2Nlc3NfcGVybWlzc2lvbiIsImhhbmRsZUlucHV0Q2hhbmdlIiwiaGFuZGxlRGVsZXRlVXNlciIsImRlbGV0ZSIsImhhbmRsZVVwZGF0ZSIsImlzVmFsaWQiLCJwdXQiLCJmZXRjaEFkbWluQWNjZXNzUmlnaHRzIiwic2V0TWFuYWdlcnMiLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsImNoZWNrZWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBZG1pbkFjY2Vzc1JpZ2h0cy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgU2V0dGluZ1NpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TZXR0aW5nU2lkZWJhclwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgeyBJbnB1dCwgRHJvcGRvd24gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydERpYWxvZyBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2dcIjtcclxuaW1wb3J0IHsgZmllbGRTaXplIH0gZnJvbSBcIi4uL2RhdGEvZmllbGRTaXplXCI7XHJcblxyXG5jb25zdCBnZXRBY2Nlc3NSaWdodHNFcnJvck1lc3NhZ2UgPSAoZXJyb3IpID0+IHtcclxuICBjb25zdCByZXNwb25zZSA9IGVycm9yPy5yZXNwb25zZT8uZGF0YTtcclxuICBpZiAodHlwZW9mIHJlc3BvbnNlPy5tZXNzYWdlID09PSBcInN0cmluZ1wiICYmIHJlc3BvbnNlLm1lc3NhZ2UpIHJldHVybiByZXNwb25zZS5tZXNzYWdlO1xyXG4gIGlmICh0eXBlb2YgcmVzcG9uc2U/LmVycm9yID09PSBcInN0cmluZ1wiICYmIHJlc3BvbnNlLmVycm9yKSByZXR1cm4gcmVzcG9uc2UuZXJyb3I7XHJcbiAgcmV0dXJuIFwiQW4gdW5leHBlY3RlZCBlcnJvciBvY2N1cnJlZC4gUGxlYXNlIHRyeSBhZ2Fpbi5cIjtcclxufTtcclxuXHJcbmNvbnN0IEFkbWluQWNjZXNzUmlnaHRzID0gKCkgPT4ge1xyXG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtUYWJsZUFnZW50cywgc2V0VGFibGVBZ2VudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXJtLCBzZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbERlbGV0ZSwgc2V0U2hvd01vZGFsRGVsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd01vZGFsVXBkYXRlLCBzZXRTaG93TW9kYWxVcGRhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50VXNlciwgc2V0Q3VycmVudFVzZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2N1cnJlbnRVcGRhdGVVc2VyLCBzZXRDdXJyZW50VXBkYXRlVXNlcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3JlbG9hZFRyaWdnZXIsIHNldFJlbG9hZFRyaWdnZXJdID0gdXNlU3RhdGUoMCk7XHJcblxyXG4gIGNvbnN0IG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFNlYXJjaFRleHQodmFsdWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgdGl0bGU6IFwiXCIsXHJcbiAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgdmlld19kYXNoYm9hcmQ6IFwiXCIsXHJcbiAgICAgIHZpZXdfYW5hbHl0aWNzOiBcIlwiLFxyXG4gICAgICBhZGRfZ3JvdXA6IFwiXCIsXHJcbiAgICAgIHZpZXdfZ3JvdXA6IFwiXCIsXHJcbiAgICAgIGVkaXRfZ3JvdXA6IFwiXCIsXHJcbiAgICAgIGRlbGV0ZV9ncm91cDogXCJcIixcclxuICAgICAgYWRkX2N1c3RvbWVyOiBcIlwiLFxyXG4gICAgICB2aWV3X2N1c3RvbWVyOiBcIlwiLFxyXG4gICAgICBlZGl0X2N1c3RvbWVyOiBcIlwiLFxyXG4gICAgICBkZWxldGVfY3VzdG9tZXI6IFwiXCIsXHJcbiAgICAgIGFkZF9lbnJvbGxtZW50OiBcIlwiLFxyXG4gICAgICBkZWxldGVfZW5yb2xsbWVudDogXCJcIixcclxuICAgICAgdmlld19lbnJvbGxtZW50OiBcIlwiLFxyXG4gICAgICBlZGl0X2Vucm9sbG1lbnQ6IFwiXCIsXHJcbiAgICAgIGFkZF9lbXBsb3llZTogXCJcIixcclxuICAgICAgdmlld19lbXBsb3llZTogXCJcIixcclxuICAgICAgZWRpdF9lbXBsb3llZTogXCJcIixcclxuICAgICAgZGVsZXRlX2VtcGxveWVlOiBcIlwiLFxyXG4gICAgICBtb2RpZnlfcGF5bWVudF9kYXRlOiBcIlwiLFxyXG4gICAgICBhZGRfbGVhZDogXCJcIixcclxuICAgICAgdmlld19sZWFkOiBcIlwiLFxyXG4gICAgICBlZGl0X2xlYWQ6IFwiXCIsXHJcbiAgICAgIGRlbGV0ZV9sZWFkOiBcIlwiLFxyXG4gICAgICBhZGRfbG9hbjogXCJcIixcclxuICAgICAgdmlld19sb2FuOiBcIlwiLFxyXG4gICAgICBlZGl0X2xvYW46IFwiXCIsXHJcbiAgICAgIGRlbGV0ZV9sb2FuOiBcIlwiLFxyXG4gICAgICBhZGRfcGlnbWU6IFwiXCIsXHJcbiAgICAgIHZpZXdfcGlnbWU6IFwiXCIsXHJcbiAgICAgIGVkaXRfcGlnbWU6IFwiXCIsXHJcbiAgICAgIGRlbGV0ZV9waWdtZTogXCJcIixcclxuICAgICAgYWRkX2F1Y3Rpb246IFwiXCIsXHJcbiAgICAgIHZpZXdfYXVjdGlvbjogXCJcIixcclxuICAgICAgZWRpdF9hdWN0aW9uOiBcIlwiLFxyXG4gICAgICBkZWxldGVfYXVjdGlvbjogXCJcIixcclxuICAgICAgYWRkX3BheW1lbnQ6IFwiXCIsXHJcbiAgICAgIHZpZXdfcGF5bWVudDogXCJcIixcclxuICAgICAgZWRpdF9wYXltZW50OiBcIlwiLFxyXG4gICAgICBlZGl0X2xpbWl0ZWRfcGF5bWVudDogXCJcIixcclxuICAgICAgZGVsZXRlX3BheW1lbnQ6IFwiXCIsXHJcbiAgICAgIHZpZXdfcmVwb3J0czogXCJcIixcclxuICAgICAgdmlld19kYXlib29rOiBcIlwiLFxyXG4gICAgICB2aWV3X2dyb3VwX3JlcG9ydDogXCJcIixcclxuICAgICAgdmlld19hbGxfY3VzdG9tZXJfcmVwb3J0OiBcIlwiLFxyXG4gICAgICB2aWV3X2N1c3RvbWVyX3JlcG9ydDogXCJcIixcclxuICAgICAgdmlld19yZWNlaXB0X3JlcG9ydDogXCJcIixcclxuICAgICAgdmlld19hdWN0aW9uX3JlcG9ydDogXCJcIixcclxuICAgICAgdmlld19sZWFkX3JlcG9ydDogXCJcIixcclxuICAgICAgdmlld19waWdtZV9yZXBvcnQ6IFwiXCIsXHJcbiAgICAgIHZpZXdfbG9hbl9yZXBvcnQ6IFwiXCIsXHJcbiAgICAgIHZpZXdfYWdlbnRfcmVwb3J0OiBcIlwiLFxyXG4gICAgICB2aWV3X3RhcmdldDogXCJcIixcclxuICAgICAgdmlld19tb2JpbGVfb3B0aW9uczogXCJcIixcclxuICAgICAgIHZpZXdfc3VzcGVuc2VfcGF5bWVudHM6IFwiXCIsXHJcbiAgICAgICB1bmxpbmtfZW5yb2xsbWVudDogXCJcIixcclxuICAgIH0sXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFt1cGRhdGVGb3JtRGF0YSwgc2V0VXBkYXRlRm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgdGl0bGU6IFwiXCIsXHJcbiAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgdmlld19kYXNoYm9hcmQ6IFwiXCIsXHJcbiAgICAgIHZpZXdfYW5hbHl0aWNzOiBcIlwiLFxyXG4gICAgICBhZGRfZ3JvdXA6IFwiXCIsXHJcbiAgICAgIHZpZXdfZ3JvdXA6IFwiXCIsXHJcbiAgICAgIGVkaXRfZ3JvdXA6IFwiXCIsXHJcbiAgICAgIGRlbGV0ZV9ncm91cDogXCJcIixcclxuICAgICAgYWRkX2N1c3RvbWVyOiBcIlwiLFxyXG4gICAgICB2aWV3X2N1c3RvbWVyOiBcIlwiLFxyXG4gICAgICBlZGl0X2N1c3RvbWVyOiBcIlwiLFxyXG4gICAgICBkZWxldGVfY3VzdG9tZXI6IFwiXCIsXHJcbiAgICAgIGFkZF9lbnJvbGxtZW50OiBcIlwiLFxyXG4gICAgICBkZWxldGVfZW5yb2xsbWVudDogXCJcIixcclxuICAgICAgdmlld19lbnJvbGxtZW50OiBcIlwiLFxyXG4gICAgICBlZGl0X2Vucm9sbG1lbnQ6IFwiXCIsXHJcbiAgICAgIGFkZF9lbXBsb3llZTogXCJcIixcclxuICAgICAgdmlld19lbXBsb3llZTogXCJcIixcclxuICAgICAgZWRpdF9lbXBsb3llZTogXCJcIixcclxuICAgICAgZGVsZXRlX2VtcGxveWVlOiBcIlwiLFxyXG4gICAgICBtb2RpZnlfcGF5bWVudF9kYXRlOiBcIlwiLFxyXG4gICAgICBhZGRfbGVhZDogXCJcIixcclxuICAgICAgdmlld19sZWFkOiBcIlwiLFxyXG4gICAgICBlZGl0X2xlYWQ6IFwiXCIsXHJcbiAgICAgIGRlbGV0ZV9sZWFkOiBcIlwiLFxyXG4gICAgICBhZGRfbG9hbjogXCJcIixcclxuICAgICAgdmlld19sb2FuOiBcIlwiLFxyXG4gICAgICBlZGl0X2xvYW46IFwiXCIsXHJcbiAgICAgIGRlbGV0ZV9sb2FuOiBcIlwiLFxyXG4gICAgICBhZGRfcGlnbWU6IFwiXCIsXHJcbiAgICAgIHZpZXdfcGlnbWU6IFwiXCIsXHJcbiAgICAgIGVkaXRfcGlnbWU6IFwiXCIsXHJcbiAgICAgIGRlbGV0ZV9waWdtZTogXCJcIixcclxuICAgICAgYWRkX2F1Y3Rpb246IFwiXCIsXHJcbiAgICAgIHZpZXdfYXVjdGlvbjogXCJcIixcclxuICAgICAgZWRpdF9hdWN0aW9uOiBcIlwiLFxyXG4gICAgICBkZWxldGVfYXVjdGlvbjogXCJcIixcclxuICAgICAgYWRkX3BheW1lbnQ6IFwiXCIsXHJcbiAgICAgIHZpZXdfcGF5bWVudDogXCJcIixcclxuICAgICAgZWRpdF9wYXltZW50OiBcIlwiLFxyXG4gICAgICBlZGl0X2xpbWl0ZWRfcGF5bWVudDogXCJcIixcclxuICAgICAgZGVsZXRlX3BheW1lbnQ6IFwiXCIsXHJcbiAgICAgIHZpZXdfcmVwb3J0czogXCJcIixcclxuICAgICAgdmlld19kYXlib29rOiBcIlwiLFxyXG4gICAgICB2aWV3X2dyb3VwX3JlcG9ydDogXCJcIixcclxuICAgICAgdmlld19hbGxfY3VzdG9tZXJfcmVwb3J0OiBcIlwiLFxyXG4gICAgICB2aWV3X2N1c3RvbWVyX3JlcG9ydDogXCJcIixcclxuICAgICAgdmlld19yZWNlaXB0X3JlcG9ydDogXCJcIixcclxuICAgICAgdmlld19hdWN0aW9uX3JlcG9ydDogXCJcIixcclxuICAgICAgdmlld19sZWFkX3JlcG9ydDogXCJcIixcclxuICAgICAgdmlld19waWdtZV9yZXBvcnQ6IFwiXCIsXHJcbiAgICAgIHZpZXdfbG9hbl9yZXBvcnQ6IFwiXCIsXHJcbiAgICAgIHZpZXdfYWdlbnRfcmVwb3J0OiBcIlwiLFxyXG4gICAgICB2aWV3X3RhcmdldDogXCJcIixcclxuICAgICAgdmlld19tb2JpbGVfb3B0aW9uczogXCJcIixcclxuICAgICAgIHZpZXdfc3VzcGVuc2VfcGF5bWVudHM6IFwiXCIsXHJcbiAgICAgICB1bmxpbmtfZW5yb2xsbWVudDogXCJcIixcclxuICAgIH0sXHJcbiAgfSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQWRtaW5SaWdodHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9hZG1pbi1hY2Nlc3MtcmlnaHRzL2dldC1hbGxcIik7XHJcbiAgICAgICAgc2V0VXNlcnMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlLmRhdGEubWFwKChhZG1pbkFjY2VzcywgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICBfaWQ6IGFkbWluQWNjZXNzPy5faWQsXHJcbiAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgdGl0bGU6IGFkbWluQWNjZXNzPy50aXRsZSxcclxuICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZVVwZGF0ZU1vZGFsT3BlbihhZG1pbkFjY2Vzcz8uX2lkKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEVkaXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVEZWxldGVNb2RhbE9wZW4oYWRtaW5BY2Nlc3M/Ll9pZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApLFxyXG4gICAgICAgIH0pKTtcclxuICAgICAgICBzZXRUYWJsZUFnZW50cyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgQWRtaW4gQWNjZXNzIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hBZG1pblJpZ2h0cygpO1xyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIC8vIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgLy8gICBjb25zdCBmZXRjaEFkbWluQWNjZXNzUmlnaHRzID0gYXN5bmMgKCkgPT4ge1xyXG4gIC8vICAgICB0cnkge1xyXG4gIC8vICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAvLyAgICAgICAgIFwiL2FkbWluLWFjY2Vzcy1yaWdodHMvYWRtaW4tYWNjZXNzLXJpZ2h0c1wiXHJcbiAgLy8gICAgICAgKTtcclxuICAvLyAgICAgICBzZXRNYW5hZ2VycyhyZXNwb25zZS5kYXRhKTtcclxuICAvLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAvLyAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYWRtaW4gYWNjZXNzIHJpZ2h0czpcIiwgZXJyb3IpO1xyXG4gIC8vICAgICB9XHJcbiAgLy8gICB9O1xyXG4gIC8vICAgZmV0Y2hBZG1pbkFjY2Vzc1JpZ2h0cygpO1xyXG4gIC8vIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW25hbWVdOiBcIlwiLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHZhbGlkYXRlRm9ybSA9ICh0eXBlKSA9PiB7XHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuICAgIGNvbnN0IGRhdGEgPSB0eXBlID09PSBcImFkZEFjY2Vzc1JpZ2h0c1wiID8gZm9ybURhdGEgOiB1cGRhdGVGb3JtRGF0YTtcclxuXHJcbiAgICBpZiAoIWRhdGEudGl0bGUudHJpbSgpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5uYW1lID0gXCJUaXRsZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG4gICAgc2V0RXJyb3JzKG5ld0Vycm9ycyk7XHJcbiAgICByZXR1cm4gT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGNvbnN0IGlzVmFsaWRhdGUgPSB2YWxpZGF0ZUZvcm0oXCJhZGRBY2Nlc3NSaWdodHNcIik7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgaWYgKGlzVmFsaWRhdGUpIHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KFwiL2FkbWluLWFjY2Vzcy1yaWdodHMvYWRkXCIsIGZvcm1EYXRhLCB7XHJcbiAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgdGl0bGU6IFwiXCIsXHJcbiAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgdmlld19kYXNoYm9hcmQ6IFwiXCIsXHJcbiAgICAgICAgICAgIHZpZXdfYW5hbHl0aWNzOiBcIlwiLFxyXG4gICAgICAgICAgICBhZGRfZ3JvdXA6IFwiXCIsXHJcbiAgICAgICAgICAgIHZpZXdfZ3JvdXA6IFwiXCIsXHJcbiAgICAgICAgICAgIGVkaXRfZ3JvdXA6IFwiXCIsXHJcbiAgICAgICAgICAgIGRlbGV0ZV9ncm91cDogXCJcIixcclxuICAgICAgICAgICAgYWRkX2N1c3RvbWVyOiBcIlwiLFxyXG4gICAgICAgICAgICB2aWV3X2N1c3RvbWVyOiBcIlwiLFxyXG4gICAgICAgICAgICBlZGl0X2N1c3RvbWVyOiBcIlwiLFxyXG4gICAgICAgICAgICBkZWxldGVfY3VzdG9tZXI6IFwiXCIsXHJcbiAgICAgICAgICAgIGFkZF9lbnJvbGxtZW50OiBcIlwiLFxyXG4gICAgICAgICAgICB2aWV3X2Vucm9sbG1lbnQ6IFwiXCIsXHJcbiAgICAgICAgICAgIGVkaXRfZW5yb2xsbWVudDogXCJcIixcclxuICAgICAgICAgICAgZGVsZXRlX2Vucm9sbG1lbnQ6IFwiXCIsXHJcbiAgICAgICAgICAgIGFkZF9lbXBsb3llZTogXCJcIixcclxuICAgICAgICAgICAgdmlld19lbXBsb3llZTogXCJcIixcclxuICAgICAgICAgICAgZWRpdF9lbXBsb3llZTogXCJcIixcclxuICAgICAgICAgICAgZGVsZXRlX2VtcGxveWVlOiBcIlwiLFxyXG4gICAgICAgICAgICBtb2RpZnlfcGF5bWVudF9kYXRlOiBcIlwiLFxyXG4gICAgICAgICAgICBhZGRfbGVhZDogXCJcIixcclxuICAgICAgICAgICAgdmlld19sZWFkOiBcIlwiLFxyXG4gICAgICAgICAgICBlZGl0X2xlYWQ6IFwiXCIsXHJcbiAgICAgICAgICAgIGRlbGV0ZV9sZWFkOiBcIlwiLFxyXG4gICAgICAgICAgICBhZGRfbG9hbjogXCJcIixcclxuICAgICAgICAgICAgdmlld19sb2FuOiBcIlwiLFxyXG4gICAgICAgICAgICBlZGl0X2xvYW46IFwiXCIsXHJcbiAgICAgICAgICAgIGRlbGV0ZV9sb2FuOiBcIlwiLFxyXG4gICAgICAgICAgICBhZGRfcGlnbWU6IFwiXCIsXHJcbiAgICAgICAgICAgIHZpZXdfcGlnbWU6IFwiXCIsXHJcbiAgICAgICAgICAgIGVkaXRfcGlnbWU6IFwiXCIsXHJcbiAgICAgICAgICAgIGRlbGV0ZV9waWdtZTogXCJcIixcclxuICAgICAgICAgICAgYWRkX2F1Y3Rpb246IFwiXCIsXHJcbiAgICAgICAgICAgIHZpZXdfYXVjdGlvbjogXCJcIixcclxuICAgICAgICAgICAgZWRpdF9hdWN0aW9uOiBcIlwiLFxyXG4gICAgICAgICAgICBkZWxldGVfYXVjdGlvbjogXCJcIixcclxuICAgICAgICAgICAgYWRkX3BheW1lbnQ6IFwiXCIsXHJcbiAgICAgICAgICAgIHZpZXdfcGF5bWVudDogXCJcIixcclxuICAgICAgICAgICAgZWRpdF9wYXltZW50OiBcIlwiLFxyXG4gICAgICAgICAgICBlZGl0X2xpbWl0ZWRfcGF5bWVudDogXCJcIixcclxuICAgICAgICAgICAgZGVsZXRlX3BheW1lbnQ6IFwiXCIsXHJcbiAgICAgICAgICAgIHZpZXdfcmVwb3J0czogXCJcIixcclxuICAgICAgICAgICAgdmlld19kYXlib29rOiBcIlwiLFxyXG4gICAgICAgICAgICB2aWV3X2dyb3VwX3JlcG9ydDogXCJcIixcclxuICAgICAgICAgICAgdmlld19hbGxfY3VzdG9tZXJfcmVwb3J0OiBcIlwiLFxyXG4gICAgICAgICAgICB2aWV3X2N1c3RvbWVyX3JlcG9ydDogXCJcIixcclxuICAgICAgICAgICAgdmlld19yZWNlaXB0X3JlcG9ydDogXCJcIixcclxuICAgICAgICAgICAgdmlld19hdWN0aW9uX3JlcG9ydDogXCJcIixcclxuICAgICAgICAgICAgdmlld19sZWFkX3JlcG9ydDogXCJcIixcclxuICAgICAgICAgICAgdmlld19waWdtZV9yZXBvcnQ6IFwiXCIsXHJcbiAgICAgICAgICAgIHZpZXdfbG9hbl9yZXBvcnQ6IFwiXCIsXHJcbiAgICAgICAgICAgIHZpZXdfYWdlbnRfcmVwb3J0OiBcIlwiLFxyXG4gICAgICAgICAgICB2aWV3X3RhcmdldDogXCJcIixcclxuICAgICAgICAgICAgdmlld19tb2JpbGVfb3B0aW9uczogXCJcIixcclxuICAgICAgICAgICAgdW5saW5rX2Vucm9sbG1lbnQ6IFwiXCIsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJBY2Nlc3MgUmlnaHRzIEFkZGVkIFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBhZGRpbmcgQWNjZXNzIFJpZ2h0czpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBnZXRBY2Nlc3NSaWdodHNFcnJvck1lc3NhZ2UoZXJyb3IpLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQWRtaW5SaWdodHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9hZG1pbi1hY2Nlc3MtcmlnaHRzL2dldC1hbGxcIik7XHJcbiAgICAgICAgc2V0VXNlcnMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlLmRhdGEubWFwKChhZG1pbkFjY2VzcywgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICBfaWQ6IGFkbWluQWNjZXNzPy5faWQsXHJcbiAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgdGl0bGU6IGFkbWluQWNjZXNzPy50aXRsZSxcclxuICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZVVwZGF0ZU1vZGFsT3BlbihhZG1pbkFjY2Vzcz8uX2lkKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEVkaXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVEZWxldGVNb2RhbE9wZW4oYWRtaW5BY2Nlc3M/Ll9pZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApLFxyXG4gICAgICAgIH0pKTtcclxuICAgICAgICBzZXRUYWJsZUFnZW50cyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgQWRtaW4gQWNjZXNzIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hBZG1pblJpZ2h0cygpO1xyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcInRpdGxlXCIsIGhlYWRlcjogXCJBZG1pbiBBY2Nlc3MgVGl0bGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGZpbHRlcmVkVXNlcnMgPSB1c2Vycy5maWx0ZXIoKHVzZXIpID0+XHJcbiAgICB1c2VyLnRpdGxlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpKVxyXG4gICk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZU1vZGFsT3BlbiA9IGFzeW5jICh1c2VySWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL2FkbWluLWFjY2Vzcy1yaWdodHMvZ2V0LWJ5LWlkLyR7dXNlcklkfWBcclxuICAgICAgKTtcclxuICAgICAgc2V0Q3VycmVudFVzZXIocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFNob3dNb2RhbERlbGV0ZSh0cnVlKTtcclxuICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxPcGVuID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvYWRtaW4tYWNjZXNzLXJpZ2h0cy9nZXQtYnktaWQvJHt1c2VySWR9YFxyXG4gICAgICApO1xyXG5cclxuICAgICAgc2V0Q3VycmVudFVwZGF0ZVVzZXIocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICB0aXRsZTogcmVzcG9uc2UuZGF0YS50aXRsZSxcclxuICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgIHZpZXdfZGFzaGJvYXJkOlxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbnM/LnZpZXdfZGFzaGJvYXJkID09PSBcInRydWVcIiB8fFxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbj8udmlld19kYXNoYm9hcmQgPT09IHRydWUsXHJcbiAgICAgICAgICB2aWV3X2FuYWx5dGljczpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb25zPy52aWV3X2FuYWx5dGljcyA9PT0gXCJ0cnVlXCIgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/LnZpZXdfYW5hbHl0aWNzID09PSB0cnVlLFxyXG4gICAgICAgICAgYWRkX2dyb3VwOlxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbnM/LmFkZF9ncm91cCA9PT0gXCJ0cnVlXCIgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/LmFkZF9ncm91cCA9PT0gdHJ1ZSxcclxuICAgICAgICAgIHZpZXdfZ3JvdXA6XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9ucz8udmlld19ncm91cCA9PT0gXCJ0cnVlXCIgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/LnZpZXdfZ3JvdXAgPT09IHRydWUsXHJcbiAgICAgICAgICBlZGl0X2dyb3VwOlxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbnM/LmVkaXRfZ3JvdXAgPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy5lZGl0X2dyb3VwID09PSB0cnVlLFxyXG4gICAgICAgICAgZGVsZXRlX2dyb3VwOlxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbnM/LmRlbGV0ZV9ncm91cCA9PT0gXCJ0cnVlXCIgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/LmRlbGV0ZV9ncm91cCA9PT0gdHJ1ZSxcclxuICAgICAgICAgIGFkZF9jdXN0b21lcjpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb25zPy5hZGRfY3VzdG9tZXIgPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy5hZGRfY3VzdG9tZXIgPT09IHRydWUsXHJcbiAgICAgICAgICB2aWV3X2N1c3RvbWVyOlxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbnM/LnZpZXdfY3VzdG9tZXIgPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy52aWV3X2N1c3RvbWVyID09PSB0cnVlLFxyXG4gICAgICAgICAgZWRpdF9jdXN0b21lcjpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb25zPy5lZGl0X2N1c3RvbWVyID09PSBcInRydWVcIiB8fFxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbj8uZWRpdF9jdXN0b21lciA9PT0gdHJ1ZSxcclxuICAgICAgICAgIGRlbGV0ZV9jdXN0b21lcjpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb25zPy5kZWxldGVfY3VzdG9tZXIgPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy5kZWxldGVfY3VzdG9tZXIgPT09IHRydWUsXHJcbiAgICAgICAgICBhZGRfZW5yb2xsbWVudDpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb25zPy5hZGRfZW5yb2xsbWVudCA9PT0gXCJ0cnVlXCIgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/LmFkZF9lbnJvbGxtZW50ID09PSB0cnVlLFxyXG4gICAgICAgICAgZGVsZXRlX2Vucm9sbG1lbnQ6XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9ucz8uZGVsZXRlX2Vucm9sbG1lbnQgPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy5kZWxldGVfZW5yb2xsbWVudCA9PT0gdHJ1ZSxcclxuICAgICAgICAgIHZpZXdfZW5yb2xsbWVudDpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb25zPy52aWV3X2Vucm9sbG1lbnQgPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy52aWV3X2Vucm9sbG1lbnQgPT09IHRydWUsXHJcbiAgICAgICAgICBlZGl0X2Vucm9sbG1lbnQ6XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9ucz8uZWRpdF9lbnJvbGxtZW50ID09PSBcInRydWVcIiB8fFxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbj8uZWRpdF9lbnJvbGxtZW50ID09PSB0cnVlLFxyXG4gICAgICAgICAgYWRkX2VtcGxveWVlOlxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbnM/LmFkZF9lbXBsb3llZSA9PT0gXCJ0cnVlXCIgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/LmFkZF9lbXBsb3llZSA9PT0gdHJ1ZSxcclxuICAgICAgICAgIHZpZXdfZW1wbG95ZWU6XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9ucz8udmlld19lbXBsb3llZSA9PT0gXCJ0cnVlXCIgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/LnZpZXdfZW1wbG95ZWUgPT09IHRydWUsXHJcbiAgICAgICAgICBlZGl0X2VtcGxveWVlOlxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbnM/LmVkaXRfZW1wbG95ZWUgPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy5lZGl0X2VtcGxveWVlID09PSB0cnVlLFxyXG4gICAgICAgICAgZGVsZXRlX2VtcGxveWVlOlxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbnM/LmRlbGV0ZV9lbXBsb3llZSA9PT0gXCJ0cnVlXCIgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/LmRlbGV0ZV9lbXBsb3llZSA9PT0gdHJ1ZSxcclxuICAgICAgICAgIG1vZGlmeV9wYXltZW50X2RhdGU6XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9ucz8ubW9kaWZ5X3BheW1lbnRfZGF0ZSA9PT0gXCJ0cnVlXCIgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/Lm1vZGlmeV9wYXltZW50X2RhdGUgPT09IHRydWUsXHJcbiAgICAgICAgICBhZGRfbGVhZDpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb25zPy5hZGRfbGVhZCA9PT0gXCJ0cnVlXCIgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/LmFkZF9sZWFkID09PSB0cnVlLFxyXG4gICAgICAgICAgdmlld19sZWFkOlxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbnM/LnZpZXdfbGVhZCA9PT0gXCJ0cnVlXCIgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/LnZpZXdfbGVhZCA9PT0gdHJ1ZSxcclxuICAgICAgICAgIGVkaXRfbGVhZDpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb25zPy5lZGl0X2xlYWQgPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy5lZGl0X2xlYWQgPT09IHRydWUsXHJcbiAgICAgICAgICBkZWxldGVfbGVhZDpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb25zPy5kZWxldGVfbGVhZCA9PT0gXCJ0cnVlXCIgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/LmRlbGV0ZV9sZWFkID09PSB0cnVlLFxyXG4gICAgICAgICAgYWRkX2xvYW46XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9ucz8uYWRkX2xvYW4gPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy5hZGRfbG9hbiA9PT0gdHJ1ZSxcclxuICAgICAgICAgIHZpZXdfbG9hbjpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb25zPy52aWV3X2xvYW4gPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy52aWV3X2xvYW4gPT09IHRydWUsXHJcbiAgICAgICAgICBlZGl0X2xvYW46XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9ucz8uZWRpdF9sb2FuID09PSBcInRydWVcIiB8fFxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbj8uZWRpdF9sb2FuID09PSB0cnVlLFxyXG4gICAgICAgICAgZGVsZXRlX2xvYW46XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9ucz8uZGVsZXRlX2xvYW4gPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy5kZWxldGVfbG9hbiA9PT0gdHJ1ZSxcclxuICAgICAgICAgIGFkZF9waWdtZTpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb25zPy5hZGRfcGlnbWUgPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy5hZGRfcGlnbWUgPT09IHRydWUsXHJcbiAgICAgICAgICB2aWV3X3BpZ21lOlxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbnM/LnZpZXdfcGlnbWUgPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy52aWV3X3BpZ21lID09PSB0cnVlLFxyXG4gICAgICAgICAgZWRpdF9waWdtZTpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb25zPy5lZGl0X3BpZ21lID09PSBcInRydWVcIiB8fFxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbj8uZWRpdF9waWdtZSA9PT0gdHJ1ZSxcclxuICAgICAgICAgIGRlbGV0ZV9waWdtZTpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb25zPy5kZWxldGVfcGlnbWUgPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy5kZWxldGVfcGlnbWUgPT09IHRydWUsXHJcbiAgICAgICAgICBhZGRfYXVjdGlvbjpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb25zPy5hZGRfYXVjdGlvbiA9PT0gXCJ0cnVlXCIgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/LmFkZF9hdWN0aW9uID09PSB0cnVlLFxyXG4gICAgICAgICAgdmlld19hdWN0aW9uOlxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbnM/LnZpZXdfYXVjdGlvbiA9PT0gXCJ0cnVlXCIgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/LnZpZXdfYXVjdGlvbiA9PT0gdHJ1ZSxcclxuICAgICAgICAgIGVkaXRfYXVjdGlvbjpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb25zPy5lZGl0X2F1Y3Rpb24gPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy5lZGl0X2F1Y3Rpb24gPT09IHRydWUsXHJcbiAgICAgICAgICBkZWxldGVfYXVjdGlvbjpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb25zPy5kZWxldGVfYXVjdGlvbiA9PT0gXCJ0cnVlXCIgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/LmRlbGV0ZV9hdWN0aW9uID09PSB0cnVlLFxyXG4gICAgICAgICAgYWRkX3BheW1lbnQ6XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9ucz8uYWRkX3BheW1lbnQgPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy5hZGRfcGF5bWVudCA9PT0gdHJ1ZSxcclxuICAgICAgICAgIHZpZXdfcGF5bWVudDpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb25zPy52aWV3X3BheW1lbnQgPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy52aWV3X3BheW1lbnQgPT09IHRydWUsXHJcbiAgICAgICAgICBlZGl0X3BheW1lbnQ6XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9ucz8uZWRpdF9wYXltZW50ID09PSBcInRydWVcIiB8fFxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbj8uZWRpdF9wYXltZW50ID09PSB0cnVlLFxyXG4gICAgICAgICAgZWRpdF9saW1pdGVkX3BheW1lbnQ6XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9ucz8uZWRpdF9saW1pdGVkX3BheW1lbnQgPT09XHJcbiAgICAgICAgICAgICAgXCJ0cnVlXCIgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/LmVkaXRfbGltaXRlZF9wYXltZW50ID09PSB0cnVlLFxyXG4gICAgICAgICAgZGVsZXRlX3BheW1lbnQ6XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9ucz8uZGVsZXRlX3BheW1lbnQgPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy5kZWxldGVfcGF5bWVudCA9PT0gdHJ1ZSxcclxuICAgICAgICAgIHZpZXdfcmVwb3J0czpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb25zPy52aWV3X3JlcG9ydHMgPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy52aWV3X3JlcG9ydHMgPT09IHRydWUsXHJcbiAgICAgICAgICB2aWV3X2RheWJvb2s6XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9ucz8udmlld19kYXlib29rID09PSBcInRydWVcIiB8fFxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbj8udmlld19kYXlib29rID09PSB0cnVlLFxyXG4gICAgICAgICAgdmlld19ncm91cF9yZXBvcnQ6XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9ucz8udmlld19ncm91cF9yZXBvcnQgPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy52aWV3X2dyb3VwX3JlcG9ydCA9PT0gdHJ1ZSxcclxuICAgICAgICAgIHZpZXdfYWxsX2N1c3RvbWVyX3JlcG9ydDpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb25zPy52aWV3X2FsbF9jdXN0b21lcl9yZXBvcnQgPT09XHJcbiAgICAgICAgICAgICAgXCJ0cnVlXCIgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/LnZpZXdfYWxsX2N1c3RvbWVyX3JlcG9ydCA9PT0gdHJ1ZSxcclxuICAgICAgICAgIHZpZXdfY3VzdG9tZXJfcmVwb3J0OlxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbnM/LnZpZXdfY3VzdG9tZXJfcmVwb3J0ID09PVxyXG4gICAgICAgICAgICAgIFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy52aWV3X2N1c3RvbWVyX3JlcG9ydCA9PT0gdHJ1ZSxcclxuICAgICAgICAgIHZpZXdfcmVjZWlwdF9yZXBvcnQ6XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9ucz8udmlld19yZWNlaXB0X3JlcG9ydCA9PT0gXCJ0cnVlXCIgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/LnZpZXdfcmVjZWlwdF9yZXBvcnQgPT09IHRydWUsXHJcbiAgICAgICAgICB2aWV3X2F1Y3Rpb25fcmVwb3J0OlxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbnM/LnZpZXdfYXVjdGlvbl9yZXBvcnQgPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy52aWV3X2F1Y3Rpb25fcmVwb3J0ID09PSB0cnVlLFxyXG4gICAgICAgICAgdmlld19sZWFkX3JlcG9ydDpcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb25zPy52aWV3X2xlYWRfcmVwb3J0ID09PSBcInRydWVcIiB8fFxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbj8udmlld19sZWFkX3JlcG9ydCA9PT0gdHJ1ZSxcclxuICAgICAgICAgIHZpZXdfcGlnbWVfcmVwb3J0OlxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbnM/LnZpZXdfcGlnbWVfcmVwb3J0ID09PSBcInRydWVcIiB8fFxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbj8udmlld19waWdtZV9yZXBvcnQgPT09IHRydWUsXHJcbiAgICAgICAgICB2aWV3X2xvYW5fcmVwb3J0OlxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbnM/LnZpZXdfbG9hbl9yZXBvcnQgPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy52aWV3X2xvYW5fcmVwb3J0ID09PSB0cnVlLFxyXG4gICAgICAgICAgdmlld19hZ2VudF9yZXBvcnQ6XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9ucz8udmlld19hZ2VudF9yZXBvcnQgPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9uPy52aWV3X2FnZW50X3JlcG9ydCA9PT0gdHJ1ZSxcclxuICAgICAgICAgICAgdmlld190YXJnZXQ6IFxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbnM/LnZpZXdfdGFyZ2V0ID09PSBcInRydWVcIiB8fFxyXG4gICAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbj8udmlld190YXJnZXQgPT09IHRydWUsXHJcbiAgICAgIHZpZXdfbW9iaWxlX29wdGlvbnM6IHJlc3BvbnNlLmRhdGE/LmFjY2Vzc19wZXJtaXNzaW9ucz8udmlld19tb2JpbGVfb3B0aW9ucyA9PT0gXCJ0cnVlXCIgfHxcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/LnZpZXdfbW9iaWxlX29wdGlvbnMgPT09IHRydWUsXHJcblxyXG4gICAgICB2aWV3X3N1c3BlbnNlX3BheW1lbnRzOiByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbnM/LnZpZXdfc3VzcGVuc2VfcGF5bWVudHMgPT09IFwidHJ1ZVwiIHx8XHJcbiAgICAgICAgICByZXNwb25zZS5kYXRhPy5hY2Nlc3NfcGVybWlzc2lvbj8udmlld19zdXNwZW5zZV9wYXltZW50cyA9PT0gdHJ1ZSxcclxuICAgICAgICB1bmxpbmtfZW5yb2xsbWVudDogcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/LnVubGlua19lbnJvbGxtZW50ID09PSBcInRydWVcIiB8fFxyXG4gICAgICAgICAgcmVzcG9uc2UuZGF0YT8uYWNjZXNzX3Blcm1pc3Npb24/LnVubGlua19lbnJvbGxtZW50ID09PSB0cnVlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRTaG93TW9kYWxVcGRhdGUodHJ1ZSk7XHJcbiAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlcjpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUlucHV0Q2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVVc2VyID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKGN1cnJlbnRVc2VyKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLmRlbGV0ZShcclxuICAgICAgICAgIGAvYWRtaW4tYWNjZXNzLXJpZ2h0cy9kZWxldGUtYnktaWQvJHtjdXJyZW50VXNlci5faWR9YFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICBzZXRDdXJyZW50VXNlcihudWxsKTtcclxuICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiTWFuYWdlciBkZWxldGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIG1hbmFnZXI6XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZSA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBjb25zdCBpc1ZhbGlkID0gdmFsaWRhdGVGb3JtKCk7XHJcbiAgICB0cnkge1xyXG4gICAgICBpZiAoaXNWYWxpZCkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnB1dChcclxuICAgICAgICAgIGAvYWRtaW4tYWNjZXNzLXJpZ2h0cy91cGRhdGUtYnktaWQvJHtjdXJyZW50VXBkYXRlVXNlci5faWR9YCxcclxuICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXRTaG93TW9kYWxVcGRhdGUoZmFsc2UpO1xyXG4gICAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJEZXNpZ25hdGlvbiBVcGRhdGVkIFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBEZXNpZ25hdGlvbjpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBnZXRBY2Nlc3NSaWdodHNFcnJvck1lc3NhZ2UoZXJyb3IpLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQWRtaW5BY2Nlc3NSaWdodHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgICAgXCIvYWRtaW4tYWNjZXNzLXJpZ2h0cy9hZG1pbi1hY2Nlc3MtcmlnaHRzXCJcclxuICAgICAgICApO1xyXG4gICAgICAgIHNldE1hbmFnZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBhZG1pbiBhY2Nlc3MgcmlnaHRzOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEFkbWluQWNjZXNzUmlnaHRzKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxTZXR0aW5nU2lkZWJhciAvPlxyXG4gICAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbiAgICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT5cclxuICAgICAgICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi04XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPkFkbWluIEFjY2VzcyBSaWdodHM8L2gxPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTQgYmctYmx1ZS05NTAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZCBzaGFkb3ctbWQgaG92ZXI6YmctYmx1ZS04MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICArIENyZWF0ZSBBY2Nlc3MgUm9sZVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7VGFibGVBZ2VudHMubGVuZ3RoID4gMCAmJiAhaXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgIHVwZGF0ZUhhbmRsZXI9e2hhbmRsZVVwZGF0ZU1vZGFsT3Blbn1cclxuICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbihUYWJsZUFnZW50cywgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPXtgQWRtaW4gQWNjZXNzIFJpZ2h0cy0ke1xyXG4gICAgICAgICAgICAgICAgICBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk/LnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgQWRtaW4gQWNjZXNzIFJpZ2h0cyBFbXBsb3llZXMuY3N2YH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICBmYWlsdXJlPXtUYWJsZUFnZW50cy5sZW5ndGggPD0gMH1cclxuICAgICAgICAgICAgICAgIGRhdGE9XCJBZG1pbiBBY2Nlc3MgUm9sZSBEYXRhXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxNb2RhbCBpc1Zpc2libGU9e3Nob3dNb2RhbH0gb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsKGZhbHNlKX0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgQ3JlYXRlIEFjY2VzcyBSb2xlXHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IG5vVmFsaWRhdGU+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFRpdGxlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0aXRsZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgaWQ9XCJ0aXRsZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIHRpdGxlXCJcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5uYW1lICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMudGl0bGV9PC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGRcIj5BY2Nlc3MgUGVybWlzc2lvbnM8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVmlldyBEYXNoYm9hcmRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19kYXNoYm9hcmR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdfZGFzaGJvYXJkOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctYmx1ZS04MDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfZGFzaGJvYXJkID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFZpZXcgQW5hbHl0aWNzXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfYW5hbHl0aWNzfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3X2FuYWx5dGljczogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X2FuYWx5dGljcyA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBBZGQgR3JvdXBcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuYWRkX2dyb3VwfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRfZ3JvdXA6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy1ibHVlLTgwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuYWRkX2dyb3VwID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFZpZXcgR3JvdXBcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19ncm91cH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld19ncm91cDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X2dyb3VwID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEVkaXQgR3JvdXBcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZWRpdF9ncm91cH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZWRpdF9ncm91cDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5lZGl0X2dyb3VwID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIERlbGV0ZSBHcm91cFxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5kZWxldGVfZ3JvdXB9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZV9ncm91cDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5kZWxldGVfZ3JvdXAgPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgQWRkIEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmFkZF9jdXN0b21lcn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkX2N1c3RvbWVyOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctYmx1ZS04MDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmFkZF9jdXN0b21lciA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBWaWV3IEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfY3VzdG9tZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdfY3VzdG9tZXI6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy1ibHVlLTgwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19jdXN0b21lciA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBFZGl0IEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmVkaXRfY3VzdG9tZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGVkaXRfY3VzdG9tZXI6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy1ibHVlLTgwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZWRpdF9jdXN0b21lciA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBEZWxldGUgQ3VzdG9tZXJcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZGVsZXRlX2N1c3RvbWVyfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxldGVfY3VzdG9tZXI6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy1ibHVlLTgwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZGVsZXRlX2N1c3RvbWVyID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEFkZCBFbnJvbGxtZW50XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmFkZF9lbnJvbGxtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRfZW5yb2xsbWVudDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5hZGRfZW5yb2xsbWVudCA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFZpZXcgRW5yb2xsbWVudFxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X2Vucm9sbG1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdfZW5yb2xsbWVudDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X2Vucm9sbG1lbnQgPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgRWRpdCBFbnJvbGxtZW50XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmVkaXRfZW5yb2xsbWVudH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZWRpdF9lbnJvbGxtZW50OiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctYmx1ZS04MDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmVkaXRfZW5yb2xsbWVudCA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIERlbGV0ZSBFbnJvbGxtZW50XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmRlbGV0ZV9lbnJvbGxtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxldGVfZW5yb2xsbWVudDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5kZWxldGVfZW5yb2xsbWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEFkZCBFbXBsb3llZVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5hZGRfZW1wbG95ZWV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFkZF9lbXBsb3llZTogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5hZGRfZW1wbG95ZWUgPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVmlldyBFbXBsb3llZVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X2VtcGxveWVlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3X2VtcGxveWVlOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctYmx1ZS04MDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfZW1wbG95ZWUgPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgRWRpdCBFbXBsb3llZVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5lZGl0X2VtcGxveWVlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBlZGl0X2VtcGxveWVlOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctYmx1ZS04MDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmVkaXRfZW1wbG95ZWUgPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgRGVsZXRlIEVtcGxveWVlXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmRlbGV0ZV9lbXBsb3llZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlX2VtcGxveWVlOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctYmx1ZS04MDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmRlbGV0ZV9lbXBsb3llZSA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBNb2RpZnkgUGF5bWVudCBEYXRlXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLm1vZGlmeV9wYXltZW50X2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1vZGlmeV9wYXltZW50X2RhdGU6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy1ibHVlLTgwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMubW9kaWZ5X3BheW1lbnRfZGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEFkZCBMZWFkXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmFkZF9sZWFkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRfbGVhZDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5hZGRfbGVhZCA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBWaWV3IExlYWRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19sZWFkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3X2xlYWQ6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy1ibHVlLTgwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19sZWFkID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEVkaXQgTGVhZFxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5lZGl0X2xlYWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGVkaXRfbGVhZDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5lZGl0X2xlYWQgPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgRGVsZXRlIExlYWRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZGVsZXRlX2xlYWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZV9sZWFkOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctYmx1ZS04MDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmRlbGV0ZV9sZWFkID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEFkZCBMb2FuXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmFkZF9sb2FufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRfbG9hbjogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5hZGRfbG9hbiA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBWaWV3IExvYW5cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19sb2FufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3X2xvYW46IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy1ibHVlLTgwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19sb2FuID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEVkaXQgTG9hblxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5lZGl0X2xvYW59XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGVkaXRfbG9hbjogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5lZGl0X2xvYW4gPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgRGVsZXRlIExvYW5cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZGVsZXRlX2xvYW59XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZV9sb2FuOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctYmx1ZS04MDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmRlbGV0ZV9sb2FuID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEFkZCBQaWdtZVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5hZGRfcGlnbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFkZF9waWdtZTogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5hZGRfcGlnbWUgPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVmlldyBQaWdtZVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X3BpZ21lfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3X3BpZ21lOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctYmx1ZS04MDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfcGlnbWUgPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgRWRpdCBQaWdtZVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5lZGl0X3BpZ21lfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBlZGl0X3BpZ21lOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctYmx1ZS04MDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmVkaXRfcGlnbWUgPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgRGVsZXRlIFBpZ21lXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmRlbGV0ZV9waWdtZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlX3BpZ21lOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctYmx1ZS04MDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmRlbGV0ZV9waWdtZSA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBBZGQgQXVjdGlvblxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5hZGRfYXVjdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkX2F1Y3Rpb246IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy1ibHVlLTgwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuYWRkX2F1Y3Rpb24gPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVmlldyBBdWN0aW9uXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfYXVjdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld19hdWN0aW9uOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctYmx1ZS04MDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfYXVjdGlvbiA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBFZGl0IEF1Y3Rpb25cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZWRpdF9hdWN0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBlZGl0X2F1Y3Rpb246IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy1ibHVlLTgwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZWRpdF9hdWN0aW9uID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIERlbGV0ZSBBdWN0aW9uXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmRlbGV0ZV9hdWN0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxldGVfYXVjdGlvbjogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5kZWxldGVfYXVjdGlvbiA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBBZGQgUGF5bWVudFxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5hZGRfcGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkX3BheW1lbnQ6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy1ibHVlLTgwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuYWRkX3BheW1lbnQgPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVmlldyBQYXltZW50XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfcGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld19wYXltZW50OiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctYmx1ZS04MDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfcGF5bWVudCA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBFZGl0IFBheW1lbnRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZWRpdF9wYXltZW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBlZGl0X3BheW1lbnQ6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy1ibHVlLTgwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZWRpdF9wYXltZW50ID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEVkaXQgTGltaXRlZCBQYXltZW50XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmVkaXRfbGltaXRlZF9wYXltZW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBlZGl0X2xpbWl0ZWRfcGF5bWVudDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5lZGl0X2xpbWl0ZWRfcGF5bWVudCA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFVubGluayBFbnJvbGxtZW50XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnVubGlua19lbnJvbGxtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB1bmxpbmtfZW5yb2xsbWVudDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy51bmxpbmtfZW5yb2xsbWVudCA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBEZWxldGUgUGF5bWVudFxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5kZWxldGVfcGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlX3BheW1lbnQ6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy1ibHVlLTgwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZGVsZXRlX3BheW1lbnQgPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVmlldyBSZXBvcnRzXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfcmVwb3J0c31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld19yZXBvcnRzOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctYmx1ZS04MDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfcmVwb3J0cyA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBWaWV3IERheWJvb2tcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19kYXlib29rfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3X2RheWJvb2s6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy1ibHVlLTgwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19kYXlib29rID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFZpZXcgR3JvdXAgUmVwb3J0XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfZ3JvdXBfcmVwb3J0fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3X2dyb3VwX3JlcG9ydDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X2dyb3VwX3JlcG9ydFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFZpZXcgQWxsIEN1c3RvbWVyIFJlcG9ydFxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfYWxsX2N1c3RvbWVyX3JlcG9ydFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld19hbGxfY3VzdG9tZXJfcmVwb3J0OiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctYmx1ZS04MDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfYWxsX2N1c3RvbWVyX3JlcG9ydFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFZpZXcgQ3VzdG9tZXIgUmVwb3J0XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfY3VzdG9tZXJfcmVwb3J0fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3X2N1c3RvbWVyX3JlcG9ydDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X2N1c3RvbWVyX3JlcG9ydFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFZpZXcgUmVjZWlwdCBSZXBvcnRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19yZWNlaXB0X3JlcG9ydH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld19yZWNlaXB0X3JlcG9ydDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X3JlY2VpcHRfcmVwb3J0XHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVmlldyBBdWN0aW9uIFJlcG9ydFxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X2F1Y3Rpb25fcmVwb3J0fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3X2F1Y3Rpb25fcmVwb3J0OiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctYmx1ZS04MDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfYXVjdGlvbl9yZXBvcnRcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBWaWV3IExlYWQgUmVwb3J0XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfbGVhZF9yZXBvcnR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdfbGVhZF9yZXBvcnQ6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy1ibHVlLTgwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19sZWFkX3JlcG9ydFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFZpZXcgUGlnbWUgUmVwb3J0XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfcGlnbWVfcmVwb3J0fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3X3BpZ21lX3JlcG9ydDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X3BpZ21lX3JlcG9ydFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFZpZXcgTG9hbiBSZXBvcnRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19sb2FuX3JlcG9ydH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld19sb2FuX3JlcG9ydDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X2xvYW5fcmVwb3J0XHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVmlldyBBZ2VudCBSZXBvcnRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19hZ2VudF9yZXBvcnR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdfYWdlbnRfcmVwb3J0OiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgZGFyazpwZWVyLWZvY3VzOnJpbmctYmx1ZS04MDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfYWdlbnRfcmVwb3J0XHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVmlldyBUYXJnZXRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X3RhcmdldH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2UgPSB7KGUpID0+IHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgIHZpZXdfdGFyZ2V0OiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBkYXJrOnBlZXItZm9jdXM6cmluZy1ibHVlLTgwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld190YXJnZXRcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBWaWV3IE1vYmlsZSBPcHRpb25zXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19tb2JpbGVfb3B0aW9uc31cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2UgPSB7KGUpID0+IHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAuLi5mb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLmZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgIHZpZXdfbW9iaWxlX29wdGlvbnM6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIGRhcms6cGVlci1mb2N1czpyaW5nLWJsdWUtODAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X21vYmlsZV9vcHRpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcbiAgICAgICAgICAgICBcclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzQgdGV4dC13aGl0ZSBiZy1ibHVlLTcwMCBob3ZlcjpiZy1ibHVlLTgwMFxyXG4gICAgICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXIgYm9yZGVyLTIgYm9yZGVyLWJsYWNrXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgU2F2ZSBBY2Nlc3MgUm9sZXNcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgICA8TW9kYWxcclxuICAgICAgICAgIGlzVmlzaWJsZT17c2hvd01vZGFsVXBkYXRlfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgVXBkYXRlIEFjY2VzcyBSaWdodHNcclxuICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXtoYW5kbGVVcGRhdGV9IG5vVmFsaWRhdGU+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFRpdGxlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0aXRsZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBpZD1cInRpdGxlXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgVGl0bGVcIlxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLnRpdGxlICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMudGl0bGV9PC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVmlldyBEYXNoYm9hcmRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19kYXNoYm9hcmR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdfZGFzaGJvYXJkOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfZGFzaGJvYXJkXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVmlldyBBbmFseXRpY3NcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19hbmFseXRpY3N9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdfYW5hbHl0aWNzOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfYW5hbHl0aWNzXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgQWRkIEdyb3VwXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmFkZF9ncm91cH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkX2dyb3VwOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmFkZF9ncm91cCA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBWaWV3IEdyb3VwXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfZ3JvdXB9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdfZ3JvdXA6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19ncm91cFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEVkaXQgR3JvdXBcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZWRpdF9ncm91cH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZWRpdF9ncm91cDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5lZGl0X2dyb3VwXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgRGVsZXRlIEdyb3VwXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmRlbGV0ZV9ncm91cH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlX2dyb3VwOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmRlbGV0ZV9ncm91cFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEFkZCBDdXN0b21lclxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5hZGRfY3VzdG9tZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFkZF9jdXN0b21lcjogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5hZGRfY3VzdG9tZXJcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBWaWV3IEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfY3VzdG9tZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdfY3VzdG9tZXI6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19jdXN0b21lclxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEVkaXQgQ3VzdG9tZXJcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZWRpdF9jdXN0b21lcn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZWRpdF9jdXN0b21lcjogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5lZGl0X2N1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgRGVsZXRlIEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmRlbGV0ZV9jdXN0b21lcn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlX2N1c3RvbWVyOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmRlbGV0ZV9jdXN0b21lclxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEFkZCBFbnJvbGxtZW50XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmFkZF9lbnJvbGxtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRfZW5yb2xsbWVudDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5hZGRfZW5yb2xsbWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIERlbGV0ZSBFbnJvbGxtZW50XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17XHJcbiAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZGVsZXRlX2Vucm9sbG1lbnRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZV9lbnJvbGxtZW50OiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmRlbGV0ZV9lbnJvbGxtZW50XHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVmlldyBFbnJvbGxtZW50XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfZW5yb2xsbWVudH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld19lbnJvbGxtZW50OiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfZW5yb2xsbWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEVkaXQgRW5yb2xsbWVudFxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5lZGl0X2Vucm9sbG1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGVkaXRfZW5yb2xsbWVudDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5lZGl0X2Vucm9sbG1lbnRcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBBZGQgRW1wbG95ZWVcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuYWRkX2VtcGxveWVlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRfZW1wbG95ZWU6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuYWRkX2VtcGxveWVlXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVmlldyBFbXBsb3llZVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X2VtcGxveWVlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3X2VtcGxveWVlOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfZW1wbG95ZWVcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBFZGl0IEVtcGxveWVlXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmVkaXRfZW1wbG95ZWV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGVkaXRfZW1wbG95ZWU6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZWRpdF9lbXBsb3llZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIERlbGV0ZSBFbXBsb3llZVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5kZWxldGVfZW1wbG95ZWV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZV9lbXBsb3llZTogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5kZWxldGVfZW1wbG95ZWVcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBNb2RpZnkgUGF5bWVudCBEYXRlXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17XHJcbiAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMubW9kaWZ5X3BheW1lbnRfZGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbW9kaWZ5X3BheW1lbnRfZGF0ZTogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5tb2RpZnlfcGF5bWVudF9kYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgQWRkIExlYWRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuYWRkX2xlYWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFkZF9sZWFkOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmFkZF9sZWFkID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFZpZXcgTGVhZFxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X2xlYWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdfbGVhZDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X2xlYWQgPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgRWRpdCBMZWFkXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmVkaXRfbGVhZH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZWRpdF9sZWFkOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmVkaXRfbGVhZCA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBEZWxldGUgTGVhZFxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5kZWxldGVfbGVhZH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlX2xlYWQ6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZGVsZXRlX2xlYWRcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBBZGQgTG9hblxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5hZGRfbG9hbn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkX2xvYW46IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuYWRkX2xvYW4gPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVmlldyBMb2FuXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfbG9hbn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld19sb2FuOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfbG9hbiA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBFZGl0IExvYW5cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZWRpdF9sb2FufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBlZGl0X2xvYW46IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZWRpdF9sb2FuID8gXCJZZXNcIiA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIERlbGV0ZSBMb2FuXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmRlbGV0ZV9sb2FufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxldGVfbG9hbjogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5kZWxldGVfbG9hblxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEFkZCBQaWdtZVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5hZGRfcGlnbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFkZF9waWdtZTogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5hZGRfcGlnbWUgPyBcIlllc1wiIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVmlldyBQaWdtZVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X3BpZ21lfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3X3BpZ21lOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfcGlnbWVcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBFZGl0IFBpZ21lXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmVkaXRfcGlnbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGVkaXRfcGlnbWU6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZWRpdF9waWdtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIERlbGV0ZSBQaWdtZVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5kZWxldGVfcGlnbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZV9waWdtZTogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5kZWxldGVfcGlnbWVcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBBZGQgQXVjdGlvblxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5hZGRfYXVjdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkX2F1Y3Rpb246IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuYWRkX2F1Y3Rpb25cclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBWaWV3IEF1Y3Rpb25cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19hdWN0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3X2F1Y3Rpb246IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19hdWN0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgRWRpdCBBdWN0aW9uXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmVkaXRfYXVjdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZWRpdF9hdWN0aW9uOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmVkaXRfYXVjdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIERlbGV0ZSBBdWN0aW9uXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmRlbGV0ZV9hdWN0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxldGVfYXVjdGlvbjogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5kZWxldGVfYXVjdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEFkZCBQYXltZW50XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmFkZF9wYXltZW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRfcGF5bWVudDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5hZGRfcGF5bWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFZpZXcgUGF5bWVudFxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X3BheW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdfcGF5bWVudDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X3BheW1lbnRcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBFZGl0IFBheW1lbnRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZWRpdF9wYXltZW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBlZGl0X3BheW1lbnQ6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMuZWRpdF9wYXltZW50XHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBFZGl0IExpbWl0ZWQgUGF5bWVudFxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmVkaXRfbGltaXRlZF9wYXltZW50XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBlZGl0X2xpbWl0ZWRfcGF5bWVudDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5lZGl0X2xpbWl0ZWRfcGF5bWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBVbmxpbmsgRW5yb2xsbWVudFxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnVubGlua19lbnJvbGxtZW50XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB1bmxpbmtfZW5yb2xsbWVudDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy51bmxpbmtfZW5yb2xsbWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIERlbGV0ZSBQYXltZW50XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLmRlbGV0ZV9wYXltZW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkZWxldGVfcGF5bWVudDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy5kZWxldGVfcGF5bWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFZpZXcgUmVwb3J0c1xyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X3JlcG9ydHN9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdfcmVwb3J0czogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X3JlcG9ydHNcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBWaWV3IERheWJvb2tcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19kYXlib29rfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3X2RheWJvb2s6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19kYXlib29rXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVmlldyBHcm91cCBSZXBvcnRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtcclxuICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X2dyb3VwX3JlcG9ydFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld19ncm91cF9yZXBvcnQ6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19ncm91cF9yZXBvcnRcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBWaWV3IEFsbCBDdXN0b21lciBSZXBvcnRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtcclxuICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X2FsbF9jdXN0b21lcl9yZXBvcnRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdfYWxsX2N1c3RvbWVyX3JlcG9ydDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X2FsbF9jdXN0b21lcl9yZXBvcnRcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBWaWV3IEN1c3RvbWVyIFJlcG9ydFxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfY3VzdG9tZXJfcmVwb3J0XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3X2N1c3RvbWVyX3JlcG9ydDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X2N1c3RvbWVyX3JlcG9ydFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFZpZXcgUmVjZWlwdCBSZXBvcnRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtcclxuICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X3JlY2VpcHRfcmVwb3J0XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3X3JlY2VpcHRfcmVwb3J0OiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfcmVjZWlwdF9yZXBvcnRcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBWaWV3IEF1Y3Rpb24gUmVwb3J0XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17XHJcbiAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19hdWN0aW9uX3JlcG9ydFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld19hdWN0aW9uX3JlcG9ydDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X2F1Y3Rpb25fcmVwb3J0XHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVmlldyBMZWFkIFJlcG9ydFxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X2xlYWRfcmVwb3J0fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3X2xlYWRfcmVwb3J0OiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfbGVhZF9yZXBvcnRcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBWaWV3IFBpZ21lIFJlcG9ydFxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfcGlnbWVfcmVwb3J0XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc19wZXJtaXNzaW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3X3BpZ21lX3JlcG9ydDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X3BpZ21lX3JlcG9ydFxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTm9cIn1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFZpZXcgTG9hbiBSZXBvcnRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19sb2FuX3JlcG9ydH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld19sb2FuX3JlcG9ydDogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X2xvYW5fcmVwb3J0XHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFZpZXcgQWdlbnQgUmVwb3J0XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17XHJcbiAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19hZ2VudF9yZXBvcnRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdfYWdlbnRfcmVwb3J0OiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfYWdlbnRfcmVwb3J0XHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PiAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVmlldyBBZ2VudCBSZXBvcnRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCByZWxhdGl2ZSBpdGVtcy1jZW50ZXIgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtcclxuICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X2FnZW50X3JlcG9ydFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld19hZ2VudF9yZXBvcnQ6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzci1vbmx5IHBlZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC02IGJnLWdyYXktMjAwIHJvdW5kZWQtZnVsbCBwZWVyIHBlZXItZm9jdXM6cmluZy00IHBlZXItZm9jdXM6cmluZy1ibHVlLTMwMCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6dHJhbnNsYXRlLXgtZnVsbCBwZWVyLWNoZWNrZWQ6YWZ0ZXI6Ym9yZGVyLXdoaXRlIGFmdGVyOmNvbnRlbnQtWycnXSBhZnRlcjphYnNvbHV0ZSBhZnRlcjp0b3AtWzJweF0gYWZ0ZXI6bGVmdC1bMnB4XSBhZnRlcjpiZy13aGl0ZSBhZnRlcjpib3JkZXItZ3JheS0zMDAgYWZ0ZXI6Ym9yZGVyIGFmdGVyOnJvdW5kZWQtZnVsbCBhZnRlcjpoLTUgYWZ0ZXI6dy01IGFmdGVyOnRyYW5zaXRpb24tYWxsIHBlZXItY2hlY2tlZDpiZy1ibHVlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0zIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19hZ2VudF9yZXBvcnRcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIk5vXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFZpZXcgVGFyZ2V0XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17XHJcbiAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld190YXJnZXRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXNzX3Blcm1pc3Npb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdfdGFyZ2V0OiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Itb25seSBwZWVyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMyB0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLnZpZXdfdGFyZ2V0XHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBWaWV3IE1vYmlsZSBPcHRpb25zXHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggcmVsYXRpdmUgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17XHJcbiAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19tb2JpbGVfb3B0aW9uc1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnVwZGF0ZUZvcm1EYXRhLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi51cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld19tb2JpbGVfb3B0aW9uczogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMSBoLTYgYmctZ3JheS0yMDAgcm91bmRlZC1mdWxsIHBlZXIgcGVlci1mb2N1czpyaW5nLTQgcGVlci1mb2N1czpyaW5nLWJsdWUtMzAwIHBlZXItY2hlY2tlZDphZnRlcjp0cmFuc2xhdGUteC1mdWxsIHBlZXItY2hlY2tlZDphZnRlcjpib3JkZXItd2hpdGUgYWZ0ZXI6Y29udGVudC1bJyddIGFmdGVyOmFic29sdXRlIGFmdGVyOnRvcC1bMnB4XSBhZnRlcjpsZWZ0LVsycHhdIGFmdGVyOmJnLXdoaXRlIGFmdGVyOmJvcmRlci1ncmF5LTMwMCBhZnRlcjpib3JkZXIgYWZ0ZXI6cm91bmRlZC1mdWxsIGFmdGVyOmgtNSBhZnRlcjp3LTUgYWZ0ZXI6dHJhbnNpdGlvbi1hbGwgcGVlci1jaGVja2VkOmJnLWJsdWUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X21vYmlsZV9vcHRpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJOb1wifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgIFZpZXcgU3VzcGVuc2UgUGF5bWVudHNcclxuICA8L3NwYW4+XHJcbiAgPGxhYmVsIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHJlbGF0aXZlIGl0ZW1zLWNlbnRlciBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgPElucHV0XHJcbiAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgIGNoZWNrZWQ9e3VwZGF0ZUZvcm1EYXRhLmFjY2Vzc19wZXJtaXNzaW9ucy52aWV3X3N1c3BlbnNlX3BheW1lbnRzfVxyXG4gICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICBhY2Nlc3NfcGVybWlzc2lvbnM6IHtcclxuICAgICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEuYWNjZXNzX3Blcm1pc3Npb25zLFxyXG4gICAgICAgICAgICB2aWV3X3N1c3BlbnNlX3BheW1lbnRzOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgcGVlclwiXHJcbiAgICAvPlxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtNiBiZy1ncmF5LTIwMCByb3VuZGVkLWZ1bGwgcGVlciBwZWVyLWZvY3VzOnJpbmctNCBwZWVyLWZvY3VzOnJpbmctYmx1ZS0zMDAgcGVlci1jaGVja2VkOmFmdGVyOnRyYW5zbGF0ZS14LWZ1bGwgcGVlci1jaGVja2VkOmFmdGVyOmJvcmRlci13aGl0ZSBhZnRlcjpjb250ZW50LVsnJ10gYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6dG9wLVsycHhdIGFmdGVyOmxlZnQtWzJweF0gYWZ0ZXI6Ymctd2hpdGUgYWZ0ZXI6Ym9yZGVyLWdyYXktMzAwIGFmdGVyOmJvcmRlciBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6aC01IGFmdGVyOnctNSBhZnRlcjp0cmFuc2l0aW9uLWFsbCBwZWVyLWNoZWNrZWQ6YmctYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTMgdGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgIHt1cGRhdGVGb3JtRGF0YS5hY2Nlc3NfcGVybWlzc2lvbnMudmlld19zdXNwZW5zZV9wYXltZW50cyA/IFwiWWVzXCIgOiBcIk5vXCJ9XHJcbiAgICA8L3NwYW4+XHJcbiAgPC9sYWJlbD5cclxuPC9kaXY+XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzQgdGV4dC13aGl0ZSBiZy1ibHVlLTcwMCBob3ZlcjpiZy1ibHVlLTgwMCBib3JkZXItMiBib3JkZXItYmxhY2tcclxuICAgICAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctYmx1ZS0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgVXBkYXRlXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbERlbGV0ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0Q3VycmVudFVzZXIobnVsbCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBEZWxldGUgQWNjZXNzIFJvbGVcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAge2N1cnJlbnRVc2VyICYmIChcclxuICAgICAgICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgICAgICAgb25TdWJtaXQ9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICAgICAgaGFuZGxlRGVsZXRlVXNlcigpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGxlYXNlIGVudGVye1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeSBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50VXNlci50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIHRvIGNvbmZpcm0gZGVsZXRpb24ue1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJncm91cE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIGRlc2lnbmF0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC13aGl0ZSBiZy1yZWQtNzAwIGhvdmVyOmJnLXJlZC04MDBcclxuICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFkbWluQWNjZXNzUmlnaHRzO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvQWRtaW5BY2Nlc3NSaWdodHMuanN4In0=