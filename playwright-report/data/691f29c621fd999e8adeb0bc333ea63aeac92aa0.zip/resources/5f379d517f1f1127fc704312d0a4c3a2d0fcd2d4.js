import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/IndividualChitPaymentLink.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import Modal from "/src/components/modals/Modal.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Dropdown, Modal as AntModal, Alert, Empty } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import BackdropBlurLoader from "/src/components/loaders/BackdropBlurLoader.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const IndividualChitPaymentLink = () => {
  _s();
  const [groups, setGroups] = useState([]);
  const [actualGroups, setActualGroups] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState("");
  const [TablePayments, setTablePayments] = useState([]);
  const [selectedAuctionGroup, setSelectedAuctionGroup] = useState("");
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [selectedAuctionGroupId, setSelectedAuctionGroupId] = useState("");
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [viewLoader, setViewLoader] = useState(false);
  const [filteredAuction, setFilteredAuction] = useState([]);
  const [groupInfo, setGroupInfo] = useState({});
  const [showModal, setShowModal] = useState(false);
  const [showModalView, setShowModalView] = useState(false);
  const [currentViewGroup, setCurrentViewGroup] = useState(null);
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const tomorrow = /* @__PURE__ */ new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowFormatted = tomorrow.toISOString().split("T")[0];
  const [isLoading, setIsLoading] = useState(false);
  const [loading, setLoading] = useState(false);
  const [disabled, setDisabled] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [borrowers, setBorrowers] = useState([]);
  const [pigmeCustomers, setPigmeCustomers] = useState([]);
  const [enableGroupColumn, setEnableGroupColumn] = useState(true);
  const [paymentGroupTickets, setPaymentGroupTickets] = useState([]);
  const [render, setRerender] = useState(0);
  const [openBackdropLoader, setOpenBackdropLoader] = useState(false);
  const [currentGroupId, setCurrentGroupId] = useState(null);
  const [alert, setAlert] = useState({
    visible: false,
    message: "",
    type: "info"
  });
  const dropDownItems = (group) => {
    const dropDownItemList = [
      {
        key: "1",
        label: /* @__PURE__ */ jsxDEV(Link, { to: `/print/${group._id}`, className: "text-violet-600 ", children: "Print" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
          lineNumber: 62,
          columnNumber: 7
        }, this)
      },
      {
        key: "3",
        label: /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "text-green-600",
            onClick: () => handleViewModalOpen(group._id),
            children: "View"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
            lineNumber: 70,
            columnNumber: 7
          },
          this
        )
      }
    ];
    return dropDownItemList;
  };
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    user_id: "",
    amount: "",
    payment_group_tickets: [],
    expiry: tomorrowFormatted,
    // Use the correctly calculated tomorrow
    send_sms: true,
    send_email: true
  });
  useEffect(() => {
    const usr = localStorage.getItem("user");
    let admin_type = null;
    try {
      if (usr) {
        admin_type = JSON.parse(usr);
      }
    } catch (e) {
      console.error("Failed to parse user from localStorage:", e);
    }
    const fetchTodaysPayments = async () => {
      try {
        setTablePayments([]);
        setIsLoading(true);
        const response = await api.get("/paymentapi/payment-link", {
          params: {
            from_date: today,
            to_date: today
          }
        });
        if (response.data && response.data.length > 0) {
          const formattedData = response.data.map((group, index) => {
            if (!group?.group_id?.group_name) return {};
            return {
              _id: group._id,
              id: index + 1,
              name: group?.user_id?.full_name,
              phone_number: group?.user_id?.phone_number,
              group_name: group?.group_id?.group_name,
              ticket: group.ticket,
              amount: group.amount,
              payment_status: group.payment_status,
              transaction_date: formatPayDate(group.createdAt),
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  trigger: ["click"],
                  menu: {
                    items: dropDownItems(group)
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                    lineNumber: 141,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                  lineNumber: 134,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 133,
                columnNumber: 15
              }, this)
            };
          });
          setTablePayments(formattedData);
          setEnableGroupColumn(true);
        } else {
          setFilteredAuction([]);
        }
      } catch (error) {
        console.error("Error fetching payment Link data:", error);
        setFilteredAuction([]);
        setAlert({
          visible: true,
          message: "Failed to load payment data",
          type: "error"
        });
      } finally {
        setIsLoading(false);
      }
    };
    fetchTodaysPayments();
  }, [render]);
  useEffect(() => {
    setBorrowers([]);
    const fetchCustomerLoanDetails = async () => {
      try {
        const response = await api.get(
          `/loans/get-borrower-by-user-id/${selectedGroupId}`
        );
        if (response.status >= 400)
          throw new Error("fetching loan borrowers Failed");
        setBorrowers(response.data);
      } catch (err) {
        console.log("Error Occurred");
      }
    };
    fetchCustomerLoanDetails();
  }, [selectedGroupId]);
  useEffect(() => {
    setPigmeCustomers([]);
    const fetchCustomerLoanDetails = async () => {
      try {
        const response = await api.get(
          `/pigme/get-pigme-customer-by-user-id/${selectedGroupId}`
        );
        if (response.status >= 400)
          throw new Error("fetching pigme customers Failed");
        setPigmeCustomers(response.data);
      } catch (err) {
        console.log(
          "Error Occurred while fetching pigme customers,",
          err.message
        );
      }
    };
    fetchCustomerLoanDetails();
  }, [selectedGroupId]);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/user/get-user");
        setGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setActualGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  const validateForm = () => {
    const newErrors = {};
    if (!selectedGroupId) {
      newErrors.customer = "Please select a customer";
    }
    if (!paymentGroupTickets || paymentGroupTickets.length === 0) {
      newErrors.payment_group_tickets = "Please select a group and ticket";
    }
    const amount = parseFloat(formData.amount);
    if (isNaN(amount) || amount <= 0) {
      newErrors.amount = "Please enter a valid positive amount";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevData) => ({ ...prevData, [name]: "" }));
  };
  const handlePaymentAntSelect = (values) => {
    setPaymentGroupTickets(values);
  };
  const handleGroupChange = async (groupId) => {
    setSelectedGroup(groupId);
    if (groupId) {
      try {
        const response = await api.get(`/enroll/get-group-enroll/${groupId}`);
        if (response.data && response.data.length > 0) {
          setFilteredUsers(response.data);
        } else {
          setFilteredUsers([]);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredUsers([]);
      }
    } else {
      setFilteredUsers([]);
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Customer Phone Number" }
  ];
  if (enableGroupColumn) {
    columns.push({ key: "group_name", header: "Group Name" });
  }
  columns.push(
    { key: "ticket", header: "Ticket Number" },
    { key: "amount", header: "Amount" },
    { key: "payment_status", header: "Payment Status" },
    { key: "action", header: "Action" }
  );
  const handleCustomer = async (groupId) => {
    setSelectedGroupId(groupId);
    setFormData((prevFormData) => ({
      ...prevFormData,
      user_id: groupId
    }));
    setErrors((prevData) => ({ ...prevData, customer: "" }));
    setPaymentGroupTickets([]);
    handleGroupChange(groupId);
    handleGroupAuctionChange(groupId);
    if (groupId) {
      try {
        const response = await api.get(`/group/get-by-id-group/${groupId}`);
        setGroupInfo(response.data || {});
      } catch (error) {
        setGroupInfo({});
      }
    } else {
      setGroupInfo({});
    }
  };
  const handleGroupPayment = async (groupId) => {
    setSelectedAuctionGroupId(groupId);
    handleGroupPaymentChange(groupId);
  };
  const formatPayDate = (dateString) => {
    return dateString?.split("T")[0];
  };
  const handleGroupPaymentChange = async (groupId) => {
    setSelectedAuctionGroup(groupId);
    if (groupId) {
      let url;
      if (groupId === "today") {
        url = `/paymentapi/payment-link/get-payments?from_date=${today}&to_date=${today}`;
        setEnableGroupColumn(true);
      } else {
        url = `/paymentapi/payment-link/${groupId}`;
        setEnableGroupColumn(false);
      }
      try {
        setTablePayments([]);
        setIsLoading(true);
        const response = await api.get(url);
        if (response.data && response.data.length > 0) {
          const formattedData = response.data.map((group, index) => {
            if (!group?.group_id?.group_name) return {};
            return {
              _id: group._id,
              id: index + 1,
              name: group?.user_id?.full_name,
              phone_number: group?.user_id?.phone_number,
              group_name: group?.group_id?.group_name,
              ticket: group.ticket,
              amount: group.amount,
              transaction_date: group?.createdAt?.split("T")[0],
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  trigger: ["click"],
                  menu: {
                    items: dropDownItems(group)
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                    lineNumber: 370,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                  lineNumber: 363,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 362,
                columnNumber: 15
              }, this)
            };
          });
          setTablePayments(formattedData);
        } else {
          setFilteredAuction([]);
        }
      } catch (error) {
        console.error("Error fetching payment data:", error);
        setFilteredAuction([]);
        setAlert({
          visible: true,
          message: "Failed to load payment data",
          type: "error"
        });
      } finally {
        setIsLoading(false);
      }
    } else {
      setFilteredAuction([]);
    }
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    try {
      if (isValid) {
        setDisabled(true);
        setAlert({ visible: false, message: "", type: "info" });
        setShowModal(false);
        let payload;
        const usr = localStorage.getItem("user");
        let admin_type = null;
        try {
          if (usr) {
            admin_type = JSON.parse(usr);
          }
        } catch (e2) {
          console.error("Failed to parse user from localStorage:", e2);
        }
        formData.payment_group_tickets = paymentGroupTickets;
        formData.admin_type = admin_type?._id;
        setOpenBackdropLoader(true);
        const response = await api.post("/paymentapi/payment-link", formData);
        if (response.status === 201) {
          setSelectedGroupId("");
          setPaymentGroupTickets([]);
          setDisabled(false);
          setFormData({
            user_id: "",
            amount: "",
            payment_group_tickets: [],
            expiry: tomorrowFormatted,
            // Reset with correct tomorrow date
            send_sms: true,
            send_email: true
          });
          setAlert({
            visible: true,
            message: "Payment Added Successfully",
            type: "success"
          });
        }
        if (response.status >= 400) {
          setShowModal(false);
          setSelectedGroupId("");
          setPaymentGroupTickets([]);
          setDisabled(false);
          setFormData({
            user_id: "",
            amount: "",
            payment_group_tickets: [],
            expiry: tomorrowFormatted,
            // Reset with correct tomorrow date
            send_sms: true,
            send_email: true
          });
          setAlert({
            visible: true,
            message: "Payment Added Failed",
            type: "error"
          });
        }
      }
    } catch (error) {
      setShowModal(false);
      setSelectedGroupId("");
      setFormData({
        user_id: "",
        amount: "",
        payment_group_tickets: [],
        expiry: tomorrowFormatted,
        // Reset with correct tomorrow date
        send_sms: true,
        send_email: true
      });
      setAlert({
        visible: true,
        message: `Error submitting payment data: ${error.message}`,
        type: "error"
      });
      setDisabled(false);
      console.error("Error submitting payment data:", error);
    } finally {
      setOpenBackdropLoader(false);
      setRerender((prev) => prev + 1);
    }
  };
  const handleViewModalOpen = async (groupId) => {
    try {
      setLoading(true);
      setShowModalView(true);
      setCurrentGroupId(groupId);
      setViewLoader(true);
      const response = await api.get(`/paymentapi/payment-link/${groupId}`);
      setCurrentViewGroup(response.data);
    } catch (error) {
      console.error("Error viewing Payment:", error);
      setAlert({
        visible: true,
        message: "Failed to load payment details",
        type: "error"
      });
    } finally {
      setLoading(false);
      setViewLoader(false);
    }
  };
  const handleGroupAuctionChange = async (groupId) => {
    if (groupId) {
      try {
        const response = await api.post(
          `/enroll/get-user-tickets-report/${groupId}`
        );
        if (response.data && response.data.length > 0) {
          const validAuctions = response.data.filter(
            (auction) => auction.enrollment && auction.enrollment.group
          );
          setFilteredAuction(validAuctions);
        } else {
          setFilteredAuction([]);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredAuction([]);
        setAlert({
          visible: true,
          message: "Failed to load group auction data",
          type: "error"
        });
      }
    } else {
      setFilteredAuction([]);
    }
  };
  const selectednewGroup = actualGroups.find(
    (g) => g._id === selectedAuctionGroupId
  );
  return /* @__PURE__ */ jsxDEV(Fragment, { children: openBackdropLoader ? /* @__PURE__ */ jsxDEV(BackdropBlurLoader, { title: "payment Data processing...." }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
    lineNumber: 539,
    columnNumber: 7
  }, this) : /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
        lineNumber: 543,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
      lineNumber: 547,
      columnNumber: 13
    }, this),
    alert.visible && /* @__PURE__ */ jsxDEV("div", { className: "fixed top-4 right-4 z-50 w-96", children: /* @__PURE__ */ jsxDEV(
      Alert,
      {
        message: alert.message,
        type: alert.type,
        showIcon: true,
        closable: true,
        onClose: () => setAlert({ ...alert, visible: false })
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
        lineNumber: 552,
        columnNumber: 17
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
      lineNumber: 551,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
        lineNumber: 563,
        columnNumber: 18
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Payment Links" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
        lineNumber: 564,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6  mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-10", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "font-bold", children: "Search or Select Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
            lineNumber: 567,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                placeholder: "Today's Payment",
                popupMatchSelectWidth: false,
                showSearch: true,
                className: "w-full  h-14 max-w-md",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                value: selectedAuctionGroupId || void 0,
                onChange: handleGroupPayment,
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "today", children: "Today's Payments" }, "#1", false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                    lineNumber: 583,
                    columnNumber: 23
                  }, this),
                  actualGroups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                      lineNumber: 587,
                      columnNumber: 21
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 569,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setShowModal(true),
                className: "ml-4 bg-violet-950 text-white px-4 py-2 rounded shadow-md hover:bg-violet-800 transition duration-200",
                children: "+ Add Payment Link"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 593,
                columnNumber: 23
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 592,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
            lineNumber: 568,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
          lineNumber: 566,
          columnNumber: 17
        }, this),
        isLoading ? /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            data: "Payments Data",
            failure: TablePayments.length <= 0 && selectedAuctionGroupId
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
            lineNumber: 603,
            columnNumber: 30
          },
          this
        ) : TablePayments && TablePayments.length > 0 ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: TablePayments.filter(
              (item) => Object.values(item).some(
                (value) => String(value).toLowerCase().includes(searchText.toLowerCase())
              )
            ),
            columns,
            exportedPdfName: "Payments",
            printHeaderKeys: ["Group Name"],
            printHeaderValues: [
              selectednewGroup?.group_name || "Today's"
            ],
            exportedFileName: `Payments.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
            lineNumber: 610,
            columnNumber: 15
          },
          this
        ) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10 text-center text-gray-500", children: /* @__PURE__ */ jsxDEV(Empty, { description: "No Payment Link Transaction Found" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
          lineNumber: 628,
          columnNumber: 20
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
          lineNumber: 627,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
        lineNumber: 565,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
      lineNumber: 562,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModal,
        onClose: () => {
          setSelectedGroupId("");
          setShowModal(false);
          setErrors({});
          setPaymentGroupTickets([]);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-6 text-xl font-bold text-gray-900 border-b pb-2", children: "Add Payment Link" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
            lineNumber: 644,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  htmlFor: "customer",
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  children: [
                    "Customer ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                      lineNumber: 654,
                      columnNumber: 32
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                  lineNumber: 650,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  id: "customer",
                  className: `bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg w-full ${fieldSize.height}`,
                  placeholder: "Select or Search Customer",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  filterOption: (input, option) => option?.children?.toString().toLowerCase().includes(input.toLowerCase()),
                  value: selectedGroupId || void 0,
                  onChange: handleCustomer,
                  children: groups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: `${group.full_name} | ${group.phone_number}` }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                      lineNumber: 672,
                      columnNumber: 21
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                  lineNumber: 656,
                  columnNumber: 21
                },
                this
              ),
              errors.customer && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-red-500", children: errors.customer }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 678,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 649,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  htmlFor: "group-ticket",
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  children: [
                    "Group & Ticket ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                      lineNumber: 689,
                      columnNumber: 38
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                  lineNumber: 685,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  id: "group-ticket",
                  mode: "multiple",
                  placeholder: "Select Group | Ticket",
                  onChange: handlePaymentAntSelect,
                  value: paymentGroupTickets,
                  className: `bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full ${fieldSize.height}`,
                  children: [
                    filteredAuction.map((entry, index) => {
                      const groupName = entry?.enrollment?.group?.group_name || "Unnamed Group";
                      const groupId = entry?.enrollment?.group?._id || `missing-${index}`;
                      const ticket = entry?.enrollment?.tickets || "Unknown";
                      return /* @__PURE__ */ jsxDEV(
                        Select.Option,
                        {
                          value: `chit-${groupId}|${ticket}`,
                          children: [
                            groupName,
                            " | ",
                            ticket
                          ]
                        },
                        `chit-${groupId}|${ticket}`,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                          lineNumber: 707,
                          columnNumber: 25
                        },
                        this
                      );
                    }),
                    pigmeCustomers?.map(
                      (pigme) => /* @__PURE__ */ jsxDEV(
                        Select.Option,
                        {
                          value: `pigme-${pigme._id}`,
                          children: `${pigme.pigme_id} | ₹ ${pigme.payable_amount}`
                        },
                        pigme._id,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                          lineNumber: 716,
                          columnNumber: 21
                        },
                        this
                      )
                    ),
                    borrowers?.map(
                      (borrower) => /* @__PURE__ */ jsxDEV(
                        Select.Option,
                        {
                          value: `loan-${borrower._id}`,
                          children: `loan-${borrower.loan_id} | ₹ ${borrower.loan_amount}`
                        },
                        borrower._id,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                          lineNumber: 724,
                          columnNumber: 21
                        },
                        this
                      )
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                  lineNumber: 691,
                  columnNumber: 21
                },
                this
              ),
              errors.payment_group_tickets && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-red-500", children: errors.payment_group_tickets }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 733,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 684,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col space-y-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    htmlFor: "amount",
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    children: [
                      "Amount ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                        lineNumber: 745,
                        columnNumber: 32
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                    lineNumber: 741,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    id: "amount",
                    type: "number",
                    name: "amount",
                    value: formData.amount,
                    onChange: handleChange,
                    placeholder: "Enter Amount",
                    required: true,
                    className: "flex-1 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                    lineNumber: 748,
                    columnNumber: 25
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                  lineNumber: 747,
                  columnNumber: 23
                }, this),
                errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-red-500", children: errors.amount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                  lineNumber: 760,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 740,
                columnNumber: 21
              }, this),
              formData.amount && paymentGroupTickets.length > 1 && /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Individual Ticket Amount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                  lineNumber: 768,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    className: "w-full bg-gray-100 border border-gray-300 text-gray-700 text-sm rounded-lg p-2.5 cursor-not-allowed",
                    placeholder: "Total Amount",
                    value: (Number(formData.amount) / paymentGroupTickets.length).toFixed(2),
                    disabled: true
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                    lineNumber: 771,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 767,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 739,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  htmlFor: "expiry",
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  children: "Expiry Date"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                  lineNumber: 785,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  id: "expiry",
                  type: "date",
                  name: "expiry",
                  min: tomorrowFormatted,
                  value: formData.expiry,
                  onChange: handleChange,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                  lineNumber: 791,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 784,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  id: "send_sms",
                  type: "checkbox",
                  name: "send_sms",
                  checked: formData.send_sms,
                  onChange: (e) => setFormData((prev) => ({
                    ...prev,
                    send_sms: e.target.checked
                  })),
                  className: "w-4 h-4 border border-gray-300 rounded bg-gray-50"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                  lineNumber: 804,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  htmlFor: "send_sms",
                  className: "ml-2 text-sm font-medium text-gray-900",
                  children: "Send SMS"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                  lineNumber: 817,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 803,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  id: "send_email",
                  type: "checkbox",
                  name: "send_email",
                  checked: formData.send_email,
                  onChange: (e) => setFormData((prev) => ({
                    ...prev,
                    send_email: e.target.checked
                  })),
                  className: "w-4 h-4 border border-gray-300 rounded bg-gray-50"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                  lineNumber: 827,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  htmlFor: "send_email",
                  className: "ml-2 text-sm font-medium text-gray-900",
                  children: "Send Email"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                  lineNumber: 840,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 826,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-4", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 active:bg-violet-900 \r\n                   border-2 border-violet-700 focus:ring-4 focus:outline-none focus:ring-violet-300 \r\n                   font-medium rounded-lg text-sm px-5 py-2.5 transition-colors duration-200",
                children: "Add Payment Link"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 849,
                columnNumber: 21
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 848,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
            lineNumber: 648,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
          lineNumber: 643,
          columnNumber: 15
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
        lineNumber: 634,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      AntModal,
      {
        open: showModalView,
        onCancel: () => setShowModalView(false),
        onClose: () => setShowModalView(false),
        onOk: () => setShowModalView(false),
        onReload: () => handleViewModalOpen(currentGroupId),
        footer: /* @__PURE__ */ jsxDEV("div", {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
          lineNumber: 868,
          columnNumber: 21
        }, this),
        loading: viewLoader,
        children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Payment Details" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
            lineNumber: 871,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Group: " }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 876,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.group_id?.group_name
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 875,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Group Value:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 880,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.group_id?.group_value
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 879,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Group Installment:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 884,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.group_id?.group_install
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 883,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "User:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 888,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.user_id?.full_name,
              " ",
              "| Ticket: ",
              currentViewGroup?.ticket
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 887,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Bid Amount:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 892,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.group_id?.group_value - currentViewGroup?.win_amount ? currentViewGroup?.group_id?.group_value - currentViewGroup?.win_amount : ""
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 891,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Commission:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 900,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.commission
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 899,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Winning Amount:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 903,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.win_amount
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 902,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Divident:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 907,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.divident
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 906,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Divident per Head:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 910,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.divident_head
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 909,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Next Payable:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 914,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.payable
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 913,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Auction Date:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 917,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.auction_date
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 916,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Next Date:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 921,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.next_date
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 920,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Created At:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 924,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.createdAt?.split("T")[0]
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 923,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Updated At:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
                lineNumber: 928,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.updatedAt?.split("T")[0]
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
              lineNumber: 927,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
            lineNumber: 874,
            columnNumber: 15
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
        lineNumber: 862,
        columnNumber: 13
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
    lineNumber: 542,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
    lineNumber: 541,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx",
    lineNumber: 537,
    columnNumber: 5
  }, this);
};
_s(IndividualChitPaymentLink, "zMKvXUzvnuWcSCgcomN5DvMVVhw=");
_c = IndividualChitPaymentLink;
export default IndividualChitPaymentLink;
var _c;
$RefreshReg$(_c, "IndividualChitPaymentLink");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/IndividualChitPaymentLink.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkRVLFNBMmROLFVBM2RNOzJCQTdEVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLFNBQVNBLFdBQVdDLGdCQUFnQjtBQUNwQyxPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLFFBQVFDLFVBQVVMLFNBQVNNLFVBQVVDLE9BQU9DLGFBQWE7QUFDbEUsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLFlBQVk7QUFDckIsT0FBT0Msd0JBQXdCO0FBQy9CLFNBQVNDLGlCQUFpQjtBQUMxQixPQUFPQyxnQkFBZ0I7QUFFdkIsTUFBTUMsNEJBQTRCQSxNQUFNO0FBQUFDLEtBQUE7QUFDdEMsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUlwQixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDcUIsY0FBY0MsZUFBZSxJQUFJdEIsU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQ3VCLGVBQWVDLGdCQUFnQixJQUFJeEIsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ3lCLGVBQWVDLGdCQUFnQixJQUFJMUIsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzJCLHNCQUFzQkMsdUJBQXVCLElBQUk1QixTQUFTLEVBQUU7QUFDbkUsUUFBTSxDQUFDNkIsaUJBQWlCQyxrQkFBa0IsSUFBSTlCLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUMrQix3QkFBd0JDLHlCQUF5QixJQUFJaEMsU0FBUyxFQUFFO0FBQ3ZFLFFBQU0sQ0FBQ2lDLGVBQWVDLGdCQUFnQixJQUFJbEMsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ21DLFlBQVlDLGFBQWEsSUFBSXBDLFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUNxQyxpQkFBaUJDLGtCQUFrQixJQUFJdEMsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ3VDLFdBQVdDLFlBQVksSUFBSXhDLFNBQVMsQ0FBQyxDQUFDO0FBQzdDLFFBQU0sQ0FBQ3lDLFdBQVdDLFlBQVksSUFBSTFDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMyQyxlQUFlQyxnQkFBZ0IsSUFBSTVDLFNBQVMsS0FBSztBQUN4RCxRQUFNLENBQUM2QyxrQkFBa0JDLG1CQUFtQixJQUFJOUMsU0FBUyxJQUFJO0FBQzdELFFBQU0rQyxTQUFRLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUduRCxRQUFNQyxXQUFXLG9CQUFJSCxLQUFLO0FBQzFCRyxXQUFTQyxRQUFRRCxTQUFTRSxRQUFRLElBQUksQ0FBQztBQUN2QyxRQUFNQyxvQkFBb0JILFNBQVNGLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUU3RCxRQUFNLENBQUNLLFdBQVdDLFlBQVksSUFBSXhELFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUN5RCxTQUFTQyxVQUFVLElBQUkxRCxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDMkQsVUFBVUMsV0FBVyxJQUFJNUQsU0FBUyxLQUFLO0FBQzlDLFFBQU0sQ0FBQzZELFlBQVlDLGFBQWEsSUFBSTlELFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUMrRCxXQUFXQyxZQUFZLElBQUloRSxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDaUUsZ0JBQWdCQyxpQkFBaUIsSUFBSWxFLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNtRSxtQkFBbUJDLG9CQUFvQixJQUFJcEUsU0FBUyxJQUFJO0FBQy9ELFFBQU0sQ0FBQ3FFLHFCQUFxQkMsc0JBQXNCLElBQUl0RSxTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDdUUsUUFBUUMsV0FBVyxJQUFJeEUsU0FBUyxDQUFDO0FBQ3hDLFFBQU0sQ0FBQ3lFLG9CQUFvQkMscUJBQXFCLElBQUkxRSxTQUFTLEtBQUs7QUFDbEUsUUFBTSxDQUFDMkUsZ0JBQWdCQyxpQkFBaUIsSUFBSTVFLFNBQVMsSUFBSTtBQUd6RCxRQUFNLENBQUM2RSxPQUFPQyxRQUFRLElBQUk5RSxTQUFTO0FBQUEsSUFDakMrRSxTQUFTO0FBQUEsSUFDVEMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFFRCxRQUFNQyxnQkFBZ0JBLENBQUNDLFVBQVU7QUFDL0IsVUFBTUMsbUJBQW1CO0FBQUEsTUFDdkI7QUFBQSxRQUNFQyxLQUFLO0FBQUEsUUFDTEMsT0FDRSx1QkFBQyxRQUFLLElBQUksVUFBVUgsTUFBTUksR0FBRyxJQUFJLFdBQVUsb0JBQW1CLHFCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxNQUVKO0FBQUEsTUFDQTtBQUFBLFFBQ0VGLEtBQUs7QUFBQSxRQUNMQyxPQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixTQUFTLE1BQU1FLG9CQUFvQkwsTUFBTUksR0FBRztBQUFBLFlBQUU7QUFBQTtBQUFBLFVBRmhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsTUFFSjtBQUFBLElBQUM7QUFHSCxXQUFPSDtBQUFBQSxFQUNUO0FBRUEsUUFBTUssOEJBQThCQSxDQUFDQyxNQUFNO0FBQ3pDLFVBQU0sRUFBRUMsTUFBTSxJQUFJRCxFQUFFRTtBQUNwQjlCLGtCQUFjNkIsS0FBSztBQUFBLEVBQ3JCO0FBRUEsUUFBTSxDQUFDRSxRQUFRQyxTQUFTLElBQUk5RixTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUMrRixVQUFVQyxXQUFXLElBQUloRyxTQUFTO0FBQUEsSUFDdkNpRyxTQUFTO0FBQUEsSUFDVEMsUUFBUTtBQUFBLElBQ1JDLHVCQUF1QjtBQUFBLElBQ3ZCQyxRQUFROUM7QUFBQUE7QUFBQUEsSUFDUitDLFVBQVU7QUFBQSxJQUNWQyxZQUFZO0FBQUEsRUFDZCxDQUFDO0FBRUR2RyxZQUFVLE1BQU07QUFDZCxVQUFNd0csTUFBTUMsYUFBYUMsUUFBUSxNQUFNO0FBQ3ZDLFFBQUlDLGFBQWE7QUFDakIsUUFBSTtBQUNGLFVBQUlILEtBQUs7QUFDUEcscUJBQWFDLEtBQUtDLE1BQU1MLEdBQUc7QUFBQSxNQUM3QjtBQUFBLElBQ0YsU0FBU2IsR0FBRztBQUNWbUIsY0FBUUMsTUFBTSwyQ0FBMkNwQixDQUFDO0FBQUEsSUFDNUQ7QUFFQSxVQUFNcUIsc0JBQXNCLFlBQVk7QUFDdEMsVUFBSTtBQUNGckYseUJBQWlCLEVBQUU7QUFDbkI4QixxQkFBYSxJQUFJO0FBQ2pCLGNBQU13RCxXQUFXLE1BQU05RyxJQUFJK0csSUFBSSw0QkFBNEI7QUFBQSxVQUN6REMsUUFBUTtBQUFBLFlBQ05DLFdBQVdwRTtBQUFBQSxZQUNYcUUsU0FBU3JFO0FBQUFBLFVBQ1g7QUFBQSxRQUNGLENBQUM7QUFDRCxZQUFJaUUsU0FBU0ssUUFBUUwsU0FBU0ssS0FBS0MsU0FBUyxHQUFHO0FBQzdDLGdCQUFNQyxnQkFBZ0JQLFNBQVNLLEtBQUtHLElBQUksQ0FBQ3JDLE9BQU9zQyxVQUFVO0FBQ3hELGdCQUFJLENBQUN0QyxPQUFPdUMsVUFBVUMsV0FBWSxRQUFPLENBQUM7QUFDMUMsbUJBQU87QUFBQSxjQUNMcEMsS0FBS0osTUFBTUk7QUFBQUEsY0FDWHFDLElBQUlILFFBQVE7QUFBQSxjQUNaSSxNQUFNMUMsT0FBT2MsU0FBUzZCO0FBQUFBLGNBQ3RCQyxjQUFjNUMsT0FBT2MsU0FBUzhCO0FBQUFBLGNBQzlCSixZQUFZeEMsT0FBT3VDLFVBQVVDO0FBQUFBLGNBQzdCSyxRQUFRN0MsTUFBTTZDO0FBQUFBLGNBQ2Q5QixRQUFRZixNQUFNZTtBQUFBQSxjQUNkK0IsZ0JBQWdCOUMsTUFBTThDO0FBQUFBLGNBQ3RCQyxrQkFBa0JDLGNBQWNoRCxNQUFNaUQsU0FBUztBQUFBLGNBQy9DQyxRQUNFLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTLENBQUMsT0FBTztBQUFBLGtCQUNqQixNQUFNO0FBQUEsb0JBQ0pDLE9BQU9wRCxjQUFjQyxLQUFLO0FBQUEsa0JBQzVCO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUVWLGlDQUFDLFlBQVMsV0FBVSxlQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQjtBQUFBO0FBQUEsZ0JBUGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLFlBRUo7QUFBQSxVQUNGLENBQUM7QUFDRHpELDJCQUFpQjZGLGFBQWE7QUFDOUJuRCwrQkFBcUIsSUFBSTtBQUFBLFFBQzNCLE9BQU87QUFDTDlCLDZCQUFtQixFQUFFO0FBQUEsUUFDdkI7QUFBQSxNQUNGLFNBQVN3RSxPQUFPO0FBQ2RELGdCQUFRQyxNQUFNLHFDQUFxQ0EsS0FBSztBQUN4RHhFLDJCQUFtQixFQUFFO0FBRXJCd0MsaUJBQVM7QUFBQSxVQUNQQyxTQUFTO0FBQUEsVUFDVEMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNILFVBQUM7QUFDQ3pCLHFCQUFhLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFFQXVELHdCQUFvQjtBQUFBLEVBQ3RCLEdBQUcsQ0FBQ3hDLE1BQU0sQ0FBQztBQUVYeEUsWUFBVSxNQUFNO0FBQ2RpRSxpQkFBYSxFQUFFO0FBQ2YsVUFBTXVFLDJCQUEyQixZQUFZO0FBQzNDLFVBQUk7QUFDRixjQUFNdkIsV0FBVyxNQUFNOUcsSUFBSStHO0FBQUFBLFVBQ3pCLGtDQUFrQ3BGLGVBQWU7QUFBQSxRQUNuRDtBQUNBLFlBQUltRixTQUFTd0IsVUFBVTtBQUNyQixnQkFBTSxJQUFJQyxNQUFNLGdDQUFnQztBQUNsRHpFLHFCQUFhZ0QsU0FBU0ssSUFBSTtBQUFBLE1BQzVCLFNBQVNxQixLQUFLO0FBQ1o3QixnQkFBUThCLElBQUksZ0JBQWdCO0FBQUEsTUFDOUI7QUFBQSxJQUNGO0FBRUFKLDZCQUF5QjtBQUFBLEVBQzNCLEdBQUcsQ0FBQzFHLGVBQWUsQ0FBQztBQUVwQjlCLFlBQVUsTUFBTTtBQUNkbUUsc0JBQWtCLEVBQUU7QUFDcEIsVUFBTXFFLDJCQUEyQixZQUFZO0FBQzNDLFVBQUk7QUFDRixjQUFNdkIsV0FBVyxNQUFNOUcsSUFBSStHO0FBQUFBLFVBQ3pCLHdDQUF3Q3BGLGVBQWU7QUFBQSxRQUN6RDtBQUNBLFlBQUltRixTQUFTd0IsVUFBVTtBQUNyQixnQkFBTSxJQUFJQyxNQUFNLGlDQUFpQztBQUNuRHZFLDBCQUFrQjhDLFNBQVNLLElBQUk7QUFBQSxNQUNqQyxTQUFTcUIsS0FBSztBQUNaN0IsZ0JBQVE4QjtBQUFBQSxVQUNOO0FBQUEsVUFDQUQsSUFBSTFEO0FBQUFBLFFBQ047QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUVBdUQsNkJBQXlCO0FBQUEsRUFDM0IsR0FBRyxDQUFDMUcsZUFBZSxDQUFDO0FBRXBCOUIsWUFBVSxNQUFNO0FBQ2QsVUFBTTZJLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTTVCLFdBQVcsTUFBTTlHLElBQUkrRyxJQUFJLGdCQUFnQjtBQUMvQzdGLGtCQUFVNEYsU0FBU0ssSUFBSTtBQUFBLE1BQ3pCLFNBQVNQLE9BQU87QUFDZEQsZ0JBQVFDLE1BQU0sOEJBQThCQSxLQUFLO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBQ0E4QixnQkFBWTtBQUFBLEVBQ2QsR0FBRyxFQUFFO0FBRUw3SSxZQUFVLE1BQU07QUFDZCxVQUFNNkksY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRixjQUFNNUIsV0FBVyxNQUFNOUcsSUFBSStHLElBQUksd0JBQXdCO0FBQ3ZEM0Ysd0JBQWdCMEYsU0FBU0ssSUFBSTtBQUFBLE1BQy9CLFNBQVNQLE9BQU87QUFDZEQsZ0JBQVFDLE1BQU0sOEJBQThCQSxLQUFLO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBQ0E4QixnQkFBWTtBQUFBLEVBQ2QsR0FBRyxFQUFFO0FBRUwsUUFBTUMsZUFBZUEsTUFBTTtBQUN6QixVQUFNQyxZQUFZLENBQUM7QUFFbkIsUUFBSSxDQUFDakgsaUJBQWlCO0FBQ3BCaUgsZ0JBQVVDLFdBQVc7QUFBQSxJQUN2QjtBQUVBLFFBQUksQ0FBQzFFLHVCQUF1QkEsb0JBQW9CaUQsV0FBVyxHQUFHO0FBQzVEd0IsZ0JBQVUzQyx3QkFBd0I7QUFBQSxJQUNwQztBQUVBLFVBQU1ELFNBQVM4QyxXQUFXakQsU0FBU0csTUFBTTtBQUN6QyxRQUFJK0MsTUFBTS9DLE1BQU0sS0FBS0EsVUFBVSxHQUFHO0FBQ2hDNEMsZ0JBQVU1QyxTQUFTO0FBQUEsSUFDckI7QUFFQUosY0FBVWdELFNBQVM7QUFDbkIsV0FBT0ksT0FBT0MsS0FBS0wsU0FBUyxFQUFFeEIsV0FBVztBQUFBLEVBQzNDO0FBRUEsUUFBTThCLGVBQWVBLENBQUMxRCxNQUFNO0FBQzFCLFVBQU0sRUFBRW1DLE1BQU1sQyxNQUFNLElBQUlELEVBQUVFO0FBQzFCSSxnQkFBWSxDQUFDcUQsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ3hCLElBQUksR0FBR2xDO0FBQUFBLElBQ1YsRUFBRTtBQUNGRyxjQUFVLENBQUN1RCxjQUFjLEVBQUUsR0FBR0EsVUFBVSxDQUFDeEIsSUFBSSxHQUFHLEdBQUcsRUFBRTtBQUFBLEVBQ3ZEO0FBRUEsUUFBTXlCLHlCQUF5QkEsQ0FBQ0MsV0FBVztBQUN6Q2pGLDJCQUF1QmlGLE1BQU07QUFBQSxFQUMvQjtBQUVBLFFBQU1DLG9CQUFvQixPQUFPQyxZQUFZO0FBQzNDakkscUJBQWlCaUksT0FBTztBQUV4QixRQUFJQSxTQUFTO0FBQ1gsVUFBSTtBQUNGLGNBQU16QyxXQUFXLE1BQU05RyxJQUFJK0csSUFBSSw0QkFBNEJ3QyxPQUFPLEVBQUU7QUFDcEUsWUFBSXpDLFNBQVNLLFFBQVFMLFNBQVNLLEtBQUtDLFNBQVMsR0FBRztBQUM3Q3BGLDJCQUFpQjhFLFNBQVNLLElBQUk7QUFBQSxRQUNoQyxPQUFPO0FBQ0xuRiwyQkFBaUIsRUFBRTtBQUFBLFFBQ3JCO0FBQUEsTUFDRixTQUFTNEUsT0FBTztBQUNkRCxnQkFBUUMsTUFBTSxtQ0FBbUNBLEtBQUs7QUFDdEQ1RSx5QkFBaUIsRUFBRTtBQUFBLE1BQ3JCO0FBQUEsSUFDRixPQUFPO0FBQ0xBLHVCQUFpQixFQUFFO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBRUEsUUFBTXdILFVBQVU7QUFBQSxJQUNkLEVBQUVyRSxLQUFLLE1BQU1zRSxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFdEUsS0FBSyxvQkFBb0JzRSxRQUFRLG1CQUFtQjtBQUFBLElBQ3RELEVBQUV0RSxLQUFLLFFBQVFzRSxRQUFRLGdCQUFnQjtBQUFBLElBQ3ZDLEVBQUV0RSxLQUFLLGdCQUFnQnNFLFFBQVEsd0JBQXdCO0FBQUEsRUFBQztBQUUxRCxNQUFJeEYsbUJBQW1CO0FBQ3JCdUYsWUFBUUUsS0FBSyxFQUFFdkUsS0FBSyxjQUFjc0UsUUFBUSxhQUFhLENBQUM7QUFBQSxFQUMxRDtBQUNBRCxVQUFRRTtBQUFBQSxJQUNOLEVBQUV2RSxLQUFLLFVBQVVzRSxRQUFRLGdCQUFnQjtBQUFBLElBQ3pDLEVBQUV0RSxLQUFLLFVBQVVzRSxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFdEUsS0FBSyxrQkFBa0JzRSxRQUFRLGlCQUFpQjtBQUFBLElBQ2xELEVBQUV0RSxLQUFLLFVBQVVzRSxRQUFRLFNBQVM7QUFBQSxFQUNwQztBQUVBLFFBQU1FLGlCQUFpQixPQUFPSixZQUFZO0FBQ3hDM0gsdUJBQW1CMkgsT0FBTztBQUMxQnpELGdCQUFZLENBQUM4RCxrQkFBa0I7QUFBQSxNQUM3QixHQUFHQTtBQUFBQSxNQUNIN0QsU0FBU3dEO0FBQUFBLElBQ1gsRUFBRTtBQUNGM0QsY0FBVSxDQUFDdUQsY0FBYyxFQUFFLEdBQUdBLFVBQVVOLFVBQVUsR0FBRyxFQUFFO0FBQ3ZEekUsMkJBQXVCLEVBQUU7QUFDekJrRixzQkFBa0JDLE9BQU87QUFDekJNLDZCQUF5Qk4sT0FBTztBQUVoQyxRQUFJQSxTQUFTO0FBQ1gsVUFBSTtBQUNGLGNBQU16QyxXQUFXLE1BQU05RyxJQUFJK0csSUFBSSwwQkFBMEJ3QyxPQUFPLEVBQUU7QUFDbEVqSCxxQkFBYXdFLFNBQVNLLFFBQVEsQ0FBQyxDQUFDO0FBQUEsTUFDbEMsU0FBU1AsT0FBTztBQUNkdEUscUJBQWEsQ0FBQyxDQUFDO0FBQUEsTUFDakI7QUFBQSxJQUNGLE9BQU87QUFDTEEsbUJBQWEsQ0FBQyxDQUFDO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBRUEsUUFBTXdILHFCQUFxQixPQUFPUCxZQUFZO0FBQzVDekgsOEJBQTBCeUgsT0FBTztBQUNqQ1EsNkJBQXlCUixPQUFPO0FBQUEsRUFDbEM7QUFFQSxRQUFNdEIsZ0JBQWdCQSxDQUFDK0IsZUFBZTtBQUNwQyxXQUFPQSxZQUFZaEgsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQ2pDO0FBRUEsUUFBTStHLDJCQUEyQixPQUFPUixZQUFZO0FBQ2xEN0gsNEJBQXdCNkgsT0FBTztBQUMvQixRQUFJQSxTQUFTO0FBQ1gsVUFBSVU7QUFDSixVQUFJVixZQUFZLFNBQVM7QUFDdkJVLGNBQU0sbURBQW1EcEgsS0FBSyxZQUFZQSxLQUFLO0FBQy9FcUIsNkJBQXFCLElBQUk7QUFBQSxNQUMzQixPQUFPO0FBQ0wrRixjQUFNLDRCQUE0QlYsT0FBTztBQUN6Q3JGLDZCQUFxQixLQUFLO0FBQUEsTUFDNUI7QUFDQSxVQUFJO0FBQ0YxQyx5QkFBaUIsRUFBRTtBQUNuQjhCLHFCQUFhLElBQUk7QUFDakIsY0FBTXdELFdBQVcsTUFBTTlHLElBQUkrRyxJQUFJa0QsR0FBRztBQUVsQyxZQUFJbkQsU0FBU0ssUUFBUUwsU0FBU0ssS0FBS0MsU0FBUyxHQUFHO0FBQzdDLGdCQUFNQyxnQkFBZ0JQLFNBQVNLLEtBQUtHLElBQUksQ0FBQ3JDLE9BQU9zQyxVQUFVO0FBQ3hELGdCQUFJLENBQUN0QyxPQUFPdUMsVUFBVUMsV0FBWSxRQUFPLENBQUM7QUFDMUMsbUJBQU87QUFBQSxjQUNMcEMsS0FBS0osTUFBTUk7QUFBQUEsY0FDWHFDLElBQUlILFFBQVE7QUFBQSxjQUNaSSxNQUFNMUMsT0FBT2MsU0FBUzZCO0FBQUFBLGNBQ3RCQyxjQUFjNUMsT0FBT2MsU0FBUzhCO0FBQUFBLGNBQzlCSixZQUFZeEMsT0FBT3VDLFVBQVVDO0FBQUFBLGNBQzdCSyxRQUFRN0MsTUFBTTZDO0FBQUFBLGNBQ2Q5QixRQUFRZixNQUFNZTtBQUFBQSxjQUNkZ0Msa0JBQWtCL0MsT0FBT2lELFdBQVdsRixNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsY0FDaERtRixRQUNFLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTLENBQUMsT0FBTztBQUFBLGtCQUNqQixNQUFNO0FBQUEsb0JBQ0pDLE9BQU9wRCxjQUFjQyxLQUFLO0FBQUEsa0JBQzVCO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUVWLGlDQUFDLFlBQVMsV0FBVSxlQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQjtBQUFBO0FBQUEsZ0JBUGpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLFlBRUo7QUFBQSxVQUNGLENBQUM7QUFDRHpELDJCQUFpQjZGLGFBQWE7QUFBQSxRQUNoQyxPQUFPO0FBQ0xqRiw2QkFBbUIsRUFBRTtBQUFBLFFBQ3ZCO0FBQUEsTUFDRixTQUFTd0UsT0FBTztBQUNkRCxnQkFBUUMsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFDbkR4RSwyQkFBbUIsRUFBRTtBQUVyQndDLGlCQUFTO0FBQUEsVUFDUEMsU0FBUztBQUFBLFVBQ1RDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSCxVQUFDO0FBQ0N6QixxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGLE9BQU87QUFDTGxCLHlCQUFtQixFQUFFO0FBQUEsSUFDdkI7QUFBQSxFQUNGO0FBRUEsUUFBTThILGVBQWUsT0FBTzFFLE1BQU07QUFDaENBLE1BQUUyRSxlQUFlO0FBQ2pCLFVBQU1DLFVBQVV6QixhQUFhO0FBQzdCLFFBQUk7QUFDRixVQUFJeUIsU0FBUztBQUNYMUcsb0JBQVksSUFBSTtBQUNoQmtCLGlCQUFTLEVBQUVDLFNBQVMsT0FBT0MsU0FBUyxJQUFJQyxNQUFNLE9BQU8sQ0FBQztBQUN0RHZDLHFCQUFhLEtBQUs7QUFDbEIsWUFBSTZIO0FBQ0osY0FBTWhFLE1BQU1DLGFBQWFDLFFBQVEsTUFBTTtBQUN2QyxZQUFJQyxhQUFhO0FBQ2pCLFlBQUk7QUFDRixjQUFJSCxLQUFLO0FBQ1BHLHlCQUFhQyxLQUFLQyxNQUFNTCxHQUFHO0FBQUEsVUFDN0I7QUFBQSxRQUNGLFNBQVNiLElBQUc7QUFDVm1CLGtCQUFRQyxNQUFNLDJDQUEyQ3BCLEVBQUM7QUFBQSxRQUM1RDtBQUNBSyxpQkFBU0ksd0JBQXdCOUI7QUFDakMwQixpQkFBU1csYUFBYUEsWUFBWW5CO0FBQ2xDYiw4QkFBc0IsSUFBSTtBQUMxQixjQUFNc0MsV0FBVyxNQUFNOUcsSUFBSXNLLEtBQUssNEJBQTRCekUsUUFBUTtBQUNwRSxZQUFJaUIsU0FBU3dCLFdBQVcsS0FBSztBQUMzQjFHLDZCQUFtQixFQUFFO0FBQ3JCd0MsaUNBQXVCLEVBQUU7QUFDekJWLHNCQUFZLEtBQUs7QUFDakJvQyxzQkFBWTtBQUFBLFlBQ1ZDLFNBQVM7QUFBQSxZQUNUQyxRQUFRO0FBQUEsWUFDUkMsdUJBQXVCO0FBQUEsWUFDdkJDLFFBQVE5QztBQUFBQTtBQUFBQSxZQUNSK0MsVUFBVTtBQUFBLFlBQ1ZDLFlBQVk7QUFBQSxVQUNkLENBQUM7QUFDRHhCLG1CQUFTO0FBQUEsWUFDUEMsU0FBUztBQUFBLFlBQ1RDLFNBQVM7QUFBQSxZQUNUQyxNQUFNO0FBQUEsVUFDUixDQUFDO0FBQUEsUUFDSDtBQUVBLFlBQUkrQixTQUFTd0IsVUFBVSxLQUFLO0FBQzFCOUYsdUJBQWEsS0FBSztBQUNsQlosNkJBQW1CLEVBQUU7QUFDckJ3QyxpQ0FBdUIsRUFBRTtBQUN6QlYsc0JBQVksS0FBSztBQUNqQm9DLHNCQUFZO0FBQUEsWUFDVkMsU0FBUztBQUFBLFlBQ1RDLFFBQVE7QUFBQSxZQUNSQyx1QkFBdUI7QUFBQSxZQUN2QkMsUUFBUTlDO0FBQUFBO0FBQUFBLFlBQ1IrQyxVQUFVO0FBQUEsWUFDVkMsWUFBWTtBQUFBLFVBQ2QsQ0FBQztBQUNEeEIsbUJBQVM7QUFBQSxZQUNQQyxTQUFTO0FBQUEsWUFDVEMsU0FBUztBQUFBLFlBQ1RDLE1BQU07QUFBQSxVQUNSLENBQUM7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0YsU0FBUzZCLE9BQU87QUFDZHBFLG1CQUFhLEtBQUs7QUFDbEJaLHlCQUFtQixFQUFFO0FBQ3JCa0Usa0JBQVk7QUFBQSxRQUNWQyxTQUFTO0FBQUEsUUFDVEMsUUFBUTtBQUFBLFFBQ1JDLHVCQUF1QjtBQUFBLFFBQ3ZCQyxRQUFROUM7QUFBQUE7QUFBQUEsUUFDUitDLFVBQVU7QUFBQSxRQUNWQyxZQUFZO0FBQUEsTUFDZCxDQUFDO0FBQ0R4QixlQUFTO0FBQUEsUUFDUEMsU0FBUztBQUFBLFFBQ1RDLFNBQVMsa0NBQWtDOEIsTUFBTTlCLE9BQU87QUFBQSxRQUN4REMsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNEckIsa0JBQVksS0FBSztBQUNqQmlELGNBQVFDLE1BQU0sa0NBQWtDQSxLQUFLO0FBQUEsSUFDdkQsVUFBQztBQUNDcEMsNEJBQXNCLEtBQUs7QUFDM0JGLGtCQUFZLENBQUNpRyxTQUFTQSxPQUFPLENBQUM7QUFBQSxJQUNoQztBQUFBLEVBQ0Y7QUFFQSxRQUFNakYsc0JBQXNCLE9BQU9pRSxZQUFZO0FBQzdDLFFBQUk7QUFDRi9GLGlCQUFXLElBQUk7QUFDZmQsdUJBQWlCLElBQUk7QUFDckJnQyx3QkFBa0I2RSxPQUFPO0FBQ3pCckgsb0JBQWMsSUFBSTtBQUNsQixZQUFNNEUsV0FBVyxNQUFNOUcsSUFBSStHLElBQUksNEJBQTRCd0MsT0FBTyxFQUFFO0FBQ3BFM0csMEJBQW9Ca0UsU0FBU0ssSUFBSTtBQUFBLElBQ25DLFNBQVNQLE9BQU87QUFDZEQsY0FBUUMsTUFBTSwwQkFBMEJBLEtBQUs7QUFDN0NoQyxlQUFTO0FBQUEsUUFDUEMsU0FBUztBQUFBLFFBQ1RDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSCxVQUFDO0FBQ0N2QixpQkFBVyxLQUFLO0FBQ2hCdEIsb0JBQWMsS0FBSztBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUVBLFFBQU0ySCwyQkFBMkIsT0FBT04sWUFBWTtBQUNsRCxRQUFJQSxTQUFTO0FBQ1gsVUFBSTtBQUNGLGNBQU16QyxXQUFXLE1BQU05RyxJQUFJc0s7QUFBQUEsVUFDekIsbUNBQW1DZixPQUFPO0FBQUEsUUFDNUM7QUFDQSxZQUFJekMsU0FBU0ssUUFBUUwsU0FBU0ssS0FBS0MsU0FBUyxHQUFHO0FBQzdDLGdCQUFNb0QsZ0JBQWdCMUQsU0FBU0ssS0FBS3NEO0FBQUFBLFlBQ2xDLENBQUNDLFlBQVlBLFFBQVFDLGNBQWNELFFBQVFDLFdBQVcxRjtBQUFBQSxVQUN4RDtBQUNBN0MsNkJBQW1Cb0ksYUFBYTtBQUFBLFFBQ2xDLE9BQU87QUFDTHBJLDZCQUFtQixFQUFFO0FBQUEsUUFDdkI7QUFBQSxNQUNGLFNBQVN3RSxPQUFPO0FBQ2RELGdCQUFRQyxNQUFNLG1DQUFtQ0EsS0FBSztBQUN0RHhFLDJCQUFtQixFQUFFO0FBRXJCd0MsaUJBQVM7QUFBQSxVQUNQQyxTQUFTO0FBQUEsVUFDVEMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixPQUFPO0FBQ0wzQyx5QkFBbUIsRUFBRTtBQUFBLElBQ3ZCO0FBQUEsRUFDRjtBQUVBLFFBQU13SSxtQkFBbUJ6SixhQUFhMEo7QUFBQUEsSUFDcEMsQ0FBQ0MsTUFBTUEsRUFBRXpGLFFBQVF4RDtBQUFBQSxFQUNuQjtBQUVBLFNBQ0UsbUNBQ0cwQywrQkFDQyx1QkFBQyxzQkFBbUIsT0FBTyxpQ0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUF5RCxJQUV6RCx1QkFBQyxTQUNDLGlDQUFDLFNBQUksV0FBVSxjQUNiO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDO0FBQUEsUUFDQSxZQUFZO0FBQUE7QUFBQSxNQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUVtQjtBQUFBLElBRW5CLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFRO0FBQUEsSUFHUEksTUFBTUUsV0FDTCx1QkFBQyxTQUFJLFdBQVUsaUNBQ2I7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVNGLE1BQU1HO0FBQUFBLFFBQ2YsTUFBTUgsTUFBTUk7QUFBQUEsUUFDWjtBQUFBLFFBQ0E7QUFBQSxRQUNBLFNBQVMsTUFBTUgsU0FBUyxFQUFFLEdBQUdELE9BQU9FLFNBQVMsTUFBTSxDQUFDO0FBQUE7QUFBQSxNQUx0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLd0QsS0FOMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFHRix1QkFBQyxTQUFJLFdBQVUsaUJBQ1Y7QUFBQSw2QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVc7QUFBQSxNQUNkLHVCQUFDLFFBQUcsV0FBVSwwQkFBeUIsNkJBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0Q7QUFBQSxNQUNwRCx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGFBQVksc0NBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1EO0FBQUEsVUFDbkQsdUJBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxhQUFZO0FBQUEsZ0JBQ1osdUJBQXVCO0FBQUEsZ0JBQ3ZCO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUNWLGNBQWMsQ0FBQ2tHLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1RDLFlBQVksRUFDWkMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsZ0JBRWpDLE9BQU90SiwwQkFBMEJ3SjtBQUFBQSxnQkFDakMsVUFBVXZCO0FBQUFBLGdCQUVWO0FBQUEseUNBQUMsT0FBTyxRQUFQLEVBQXlCLE9BQU8sU0FBUyxnQ0FBdEIsTUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNDM0ksYUFBYW1HO0FBQUFBLG9CQUFJLENBQUNyQyxVQUNqQix1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsTUFBTUksS0FDekNKLGdCQUFNd0MsY0FEV3hDLE1BQU1JLEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUE7QUFBQSxjQXJCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFzQkE7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU03QyxhQUFhLElBQUk7QUFBQSxnQkFDaEMsV0FBVTtBQUFBLGdCQUF1RztBQUFBO0FBQUEsY0FGbkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQ0E7QUFBQSxhQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUNBO0FBQUEsUUFFQ2EsWUFBVztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRVAsTUFBSztBQUFBLFlBQ0wsU0FDRTlCLGNBQWM2RixVQUFVLEtBQUt2RjtBQUFBQTtBQUFBQSxVQUp6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLTCxJQUNDTixpQkFBaUJBLGNBQWM2RixTQUFTLElBQzlDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFNN0YsY0FBY2tKO0FBQUFBLGNBQU8sQ0FBQ2EsU0FDMUJ0QyxPQUFPSyxPQUFPaUMsSUFBSSxFQUFFQztBQUFBQSxnQkFBSyxDQUFDOUYsVUFDeEIrRixPQUFPL0YsS0FBSyxFQUNUMEYsWUFBWSxFQUNaQyxTQUFTekgsV0FBV3dILFlBQVksQ0FBQztBQUFBLGNBQ3RDO0FBQUEsWUFDRjtBQUFBLFlBQ0E7QUFBQSxZQUNBLGlCQUFnQjtBQUFBLFlBQ2hCLGlCQUFpQixDQUFDLFlBQVk7QUFBQSxZQUM5QixtQkFBbUI7QUFBQSxjQUNqQlAsa0JBQWtCbkQsY0FBYztBQUFBLFlBQVM7QUFBQSxZQUUzQyxrQkFBa0I7QUFBQTtBQUFBLFVBZHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWNtQyxJQUduQyx1QkFBQyxTQUFJLFdBQVUsbUNBQ2QsaUNBQUMsU0FBTSxhQUFZLHVDQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNELEtBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBaEVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrRUE7QUFBQSxTQXJFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0VBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV2xGO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JYLDZCQUFtQixFQUFFO0FBQ3JCWSx1QkFBYSxLQUFLO0FBQ2xCb0Qsb0JBQVUsQ0FBQyxDQUFDO0FBQ1p4QixpQ0FBdUIsRUFBRTtBQUFBLFFBQzNCO0FBQUEsUUFFQSxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsc0RBQXFELGdDQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQSx1QkFBQyxVQUFLLFdBQVUsYUFBWSxVQUFVOEYsY0FBYyxZQUFVLE1BQzVEO0FBQUEsbUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFRO0FBQUEsa0JBQ1IsV0FBVTtBQUFBLGtCQUE4QztBQUFBO0FBQUEsb0JBRS9DLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQTtBQUFBO0FBQUEsZ0JBSjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxJQUFHO0FBQUEsa0JBQ0gsV0FBVyw2RUFBNkVySixVQUFVNEssTUFBTTtBQUFBLGtCQUN4RyxhQUFZO0FBQUEsa0JBQ1osdUJBQXVCO0FBQUEsa0JBQ3ZCO0FBQUEsa0JBQ0EsY0FBYyxDQUFDVixPQUFPQyxXQUNwQkEsUUFBUUMsVUFDSkMsU0FBUyxFQUNWQyxZQUFZLEVBQ1pDLFNBQVNMLE1BQU1JLFlBQVksQ0FBQztBQUFBLGtCQUVqQyxPQUFPeEosbUJBQW1CMEo7QUFBQUEsa0JBQzFCLFVBQVUxQjtBQUFBQSxrQkFFVDFJLGlCQUFPcUc7QUFBQUEsb0JBQUksQ0FBQ3JDLFVBQ1gsdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU1JLEtBQ3pDLGFBQUdKLE1BQU0yQyxTQUFTLE1BQU0zQyxNQUFNNEMsWUFBWSxNQUR6QjVDLE1BQU1JLEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQW9CQTtBQUFBLGNBQ0NNLE9BQU9rRCxZQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmxELGlCQUFPa0QsWUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBL0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUNBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVE7QUFBQSxrQkFDUixXQUFVO0FBQUEsa0JBQThDO0FBQUE7QUFBQSxvQkFFekMsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQztBQUFBO0FBQUE7QUFBQSxnQkFKakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLElBQUc7QUFBQSxrQkFDSCxNQUFLO0FBQUEsa0JBQ0wsYUFBWTtBQUFBLGtCQUNaLFVBQVVPO0FBQUFBLGtCQUNWLE9BQU9qRjtBQUFBQSxrQkFDUCxXQUFXLDJIQUEySHRELFVBQVU0SyxNQUFNO0FBQUEsa0JBRXJKdEo7QUFBQUEsb0NBQWdCbUYsSUFBSSxDQUFDb0UsT0FBT25FLFVBQVU7QUFDckMsNEJBQU1vRSxZQUNKRCxPQUFPZixZQUFZMUYsT0FBT3dDLGNBQzFCO0FBQ0YsNEJBQU04QixVQUNKbUMsT0FBT2YsWUFBWTFGLE9BQU9JLE9BQU8sV0FBV2tDLEtBQUs7QUFDbkQsNEJBQU1PLFNBQVM0RCxPQUFPZixZQUFZaUIsV0FBVztBQUM3Qyw2QkFDRTtBQUFBLHdCQUFDLE9BQU87QUFBQSx3QkFBUDtBQUFBLDBCQUVDLE9BQU8sUUFBUXJDLE9BQU8sSUFBSXpCLE1BQU07QUFBQSwwQkFFL0I2RDtBQUFBQTtBQUFBQSw0QkFBVTtBQUFBLDRCQUFJN0Q7QUFBQUE7QUFBQUE7QUFBQUEsd0JBSFYsUUFBUXlCLE9BQU8sSUFBSXpCLE1BQU07QUFBQSx3QkFEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFLQTtBQUFBLG9CQUVKLENBQUM7QUFBQSxvQkFDQS9ELGdCQUFnQnVEO0FBQUFBLHNCQUFJLENBQUN1RSxVQUNwQjtBQUFBLHdCQUFDLE9BQU87QUFBQSx3QkFBUDtBQUFBLDBCQUVDLE9BQU8sU0FBU0EsTUFBTXhHLEdBQUc7QUFBQSwwQkFFeEIsYUFBR3dHLE1BQU1DLFFBQVEsUUFBUUQsTUFBTUUsY0FBYztBQUFBO0FBQUEsd0JBSHpDRixNQUFNeEc7QUFBQUEsd0JBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFLQTtBQUFBLG9CQUNEO0FBQUEsb0JBQ0F4QixXQUFXeUQ7QUFBQUEsc0JBQUksQ0FBQzBFLGFBQ2Y7QUFBQSx3QkFBQyxPQUFPO0FBQUEsd0JBQVA7QUFBQSwwQkFFQyxPQUFPLFFBQVFBLFNBQVMzRyxHQUFHO0FBQUEsMEJBRTFCLGtCQUFRMkcsU0FBU0MsT0FBTyxRQUFRRCxTQUFTRSxXQUFXO0FBQUE7QUFBQSx3QkFIaERGLFNBQVMzRztBQUFBQSx3QkFEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFLQTtBQUFBLG9CQUNEO0FBQUE7QUFBQTtBQUFBLGdCQXZDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0F3Q0E7QUFBQSxjQUNDTSxPQUFPTSx5QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZOLGlCQUFPTSx5QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBbkRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcURBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVE7QUFBQSxvQkFDUixXQUFVO0FBQUEsb0JBQThDO0FBQUE7QUFBQSxzQkFFakQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnQztBQUFBO0FBQUE7QUFBQSxrQkFKekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLElBQUc7QUFBQSxvQkFDSCxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9KLFNBQVNHO0FBQUFBLG9CQUNoQixVQUFVa0Q7QUFBQUEsb0JBQ1YsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVEySSxLQVQ3STtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVdBO0FBQUEsZ0JBQ0N2RCxPQUFPSyxVQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVkwsaUJBQU9LLFVBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXdCQTtBQUFBLGNBRUNILFNBQVNHLFVBQVU3QixvQkFBb0JpRCxTQUFTLEtBQy9DLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLHdDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDVixhQUFZO0FBQUEsb0JBQ1osUUFDRStFLE9BQU90RyxTQUFTRyxNQUFNLElBQUk3QixvQkFBb0JpRCxRQUM5Q2dGLFFBQVEsQ0FBQztBQUFBLG9CQUNYLFVBQVE7QUFBQTtBQUFBLGtCQVBWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPVTtBQUFBLG1CQVhaO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBYUE7QUFBQSxpQkF6Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEyQ0E7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUTtBQUFBLGtCQUNSLFdBQVU7QUFBQSxrQkFBOEM7QUFBQTtBQUFBLGdCQUYxRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsSUFBRztBQUFBLGtCQUNILE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsS0FBS2hKO0FBQUFBLGtCQUNMLE9BQU95QyxTQUFTSztBQUFBQSxrQkFDaEIsVUFBVWdEO0FBQUFBLGtCQUNWLFdBQVU7QUFBQTtBQUFBLGdCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU8ySTtBQUFBLGlCQWQ3STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdCQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsSUFBRztBQUFBLGtCQUNILE1BQUs7QUFBQSxrQkFDTCxNQUFLO0FBQUEsa0JBQ0wsU0FBU3JELFNBQVNNO0FBQUFBLGtCQUNsQixVQUFVLENBQUNYLE1BQ1RNLFlBQVksQ0FBQ3lFLFVBQVU7QUFBQSxvQkFDckIsR0FBR0E7QUFBQUEsb0JBQ0hwRSxVQUFVWCxFQUFFRSxPQUFPMkc7QUFBQUEsa0JBQ3JCLEVBQUU7QUFBQSxrQkFFSixXQUFVO0FBQUE7QUFBQSxnQkFYWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FXK0Q7QUFBQSxjQUUvRDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFRO0FBQUEsa0JBQ1IsV0FBVTtBQUFBLGtCQUF3QztBQUFBO0FBQUEsZ0JBRnBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsaUJBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0JBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxJQUFHO0FBQUEsa0JBQ0gsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxTQUFTeEcsU0FBU087QUFBQUEsa0JBQ2xCLFVBQVUsQ0FBQ1osTUFDVE0sWUFBWSxDQUFDeUUsVUFBVTtBQUFBLG9CQUNyQixHQUFHQTtBQUFBQSxvQkFDSG5FLFlBQVlaLEVBQUVFLE9BQU8yRztBQUFBQSxrQkFDdkIsRUFBRTtBQUFBLGtCQUVKLFdBQVU7QUFBQTtBQUFBLGdCQVhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVcrRDtBQUFBLGNBRS9EO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVE7QUFBQSxrQkFDUixXQUFVO0FBQUEsa0JBQXdDO0FBQUE7QUFBQSxnQkFGcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxpQkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBRTZEO0FBQUE7QUFBQSxjQUp6RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxlQWpORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtOQTtBQUFBLGFBdk5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3TkE7QUFBQTtBQUFBLE1Bak9GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWtPQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE1BQU01SjtBQUFBQSxRQUNOLFVBQVUsTUFBTUMsaUJBQWlCLEtBQUs7QUFBQSxRQUN0QyxTQUFTLE1BQU1BLGlCQUFpQixLQUFLO0FBQUEsUUFDckMsTUFBTSxNQUFNQSxpQkFBaUIsS0FBSztBQUFBLFFBQ2xDLFVBQVUsTUFBTTRDLG9CQUFvQmIsY0FBYztBQUFBLFFBQ2xELFFBQVEsdUJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQUs7QUFBQSxRQUNiLFNBQVN4QztBQUFBQSxRQUVUO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QywrQkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGlJQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTyx1QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFlO0FBQUEsY0FBVTtBQUFBLGNBQ3hCVSxrQkFBa0I2RSxVQUFVQztBQUFBQSxpQkFGL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTyw0QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQjtBQUFBLGNBQVU7QUFBQSxjQUM3QjlFLGtCQUFrQjZFLFVBQVU4RTtBQUFBQSxpQkFGL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTyxrQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQjtBQUFBLGNBQVU7QUFBQSxjQUNuQzNKLGtCQUFrQjZFLFVBQVUrRTtBQUFBQSxpQkFGL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTyxxQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFhO0FBQUEsY0FBUztBQUFBLGNBQUU1SixrQkFBa0JvRCxTQUFTNkI7QUFBQUEsY0FBVztBQUFBLGNBQUk7QUFBQSxjQUN2RGpGLGtCQUFrQm1GO0FBQUFBLGlCQUYvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLDJCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1CO0FBQUEsY0FBVTtBQUFBLGNBQzVCbkYsa0JBQWtCNkUsVUFBVThFLGNBQzdCM0osa0JBQWtCNkosYUFDZDdKLGtCQUFrQjZFLFVBQVU4RSxjQUM1QjNKLGtCQUFrQjZKLGFBQ2xCO0FBQUEsaUJBTk47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTywyQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQjtBQUFBLGNBQVM7QUFBQSxjQUFFN0osa0JBQWtCOEo7QUFBQUEsaUJBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHFDQUFDLFlBQU8sK0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUI7QUFBQSxjQUFVO0FBQUEsY0FDaEM5SixrQkFBa0I2SjtBQUFBQSxpQkFGckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTyx5QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQjtBQUFBLGNBQVM7QUFBQSxjQUFFN0osa0JBQWtCK0o7QUFBQUEsaUJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHFDQUFDLFlBQU8sa0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEI7QUFBQSxjQUFVO0FBQUEsY0FDbkMvSixrQkFBa0JnSztBQUFBQSxpQkFGckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTyw2QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxQjtBQUFBLGNBQVM7QUFBQSxjQUFFaEssa0JBQWtCaUs7QUFBQUEsaUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHFDQUFDLFlBQU8sNkJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUI7QUFBQSxjQUFVO0FBQUEsY0FDOUJqSyxrQkFBa0JrSztBQUFBQSxpQkFGckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTywwQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrQjtBQUFBLGNBQVM7QUFBQSxjQUFFbEssa0JBQWtCbUs7QUFBQUEsaUJBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHFDQUFDLFlBQU8sMkJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUI7QUFBQSxjQUFVO0FBQUEsY0FDNUJuSyxrQkFBa0J1RixXQUFXbEYsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLGlCQUY1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLDJCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1CO0FBQUEsY0FBVTtBQUFBLGNBQzVCTCxrQkFBa0JvSyxXQUFXL0osTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLGlCQUY1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUF4REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5REE7QUFBQTtBQUFBO0FBQUEsTUFyRUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBc0VBO0FBQUEsT0F0WUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVZQSxLQXhZRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeVlBLEtBN1lKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErWUE7QUFFSjtBQUFFaEMsR0ExNUJJRCwyQkFBeUI7QUFBQWlNLEtBQXpCak07QUE0NUJOLGVBQWVBO0FBQTBCLElBQUFpTTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJTaWRlYmFyIiwiYXBpIiwiTW9kYWwiLCJEYXRhVGFibGUiLCJDaXJjdWxhckxvYWRlciIsIk5hdmJhciIsIlNlbGVjdCIsIkRyb3Bkb3duIiwiQW50TW9kYWwiLCJBbGVydCIsIkVtcHR5IiwiSW9NZE1vcmUiLCJMaW5rIiwiQmFja2Ryb3BCbHVyTG9hZGVyIiwiZmllbGRTaXplIiwiQnJlYWRjcnVtYiIsIkluZGl2aWR1YWxDaGl0UGF5bWVudExpbmsiLCJfcyIsImdyb3VwcyIsInNldEdyb3VwcyIsImFjdHVhbEdyb3VwcyIsInNldEFjdHVhbEdyb3VwcyIsInNlbGVjdGVkR3JvdXAiLCJzZXRTZWxlY3RlZEdyb3VwIiwiVGFibGVQYXltZW50cyIsInNldFRhYmxlUGF5bWVudHMiLCJzZWxlY3RlZEF1Y3Rpb25Hcm91cCIsInNldFNlbGVjdGVkQXVjdGlvbkdyb3VwIiwic2VsZWN0ZWRHcm91cElkIiwic2V0U2VsZWN0ZWRHcm91cElkIiwic2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCIsInNldFNlbGVjdGVkQXVjdGlvbkdyb3VwSWQiLCJmaWx0ZXJlZFVzZXJzIiwic2V0RmlsdGVyZWRVc2VycyIsInZpZXdMb2FkZXIiLCJzZXRWaWV3TG9hZGVyIiwiZmlsdGVyZWRBdWN0aW9uIiwic2V0RmlsdGVyZWRBdWN0aW9uIiwiZ3JvdXBJbmZvIiwic2V0R3JvdXBJbmZvIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwic2hvd01vZGFsVmlldyIsInNldFNob3dNb2RhbFZpZXciLCJjdXJyZW50Vmlld0dyb3VwIiwic2V0Q3VycmVudFZpZXdHcm91cCIsInRvZGF5IiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJ0b21vcnJvdyIsInNldERhdGUiLCJnZXREYXRlIiwidG9tb3Jyb3dGb3JtYXR0ZWQiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImRpc2FibGVkIiwic2V0RGlzYWJsZWQiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsImJvcnJvd2VycyIsInNldEJvcnJvd2VycyIsInBpZ21lQ3VzdG9tZXJzIiwic2V0UGlnbWVDdXN0b21lcnMiLCJlbmFibGVHcm91cENvbHVtbiIsInNldEVuYWJsZUdyb3VwQ29sdW1uIiwicGF5bWVudEdyb3VwVGlja2V0cyIsInNldFBheW1lbnRHcm91cFRpY2tldHMiLCJyZW5kZXIiLCJzZXRSZXJlbmRlciIsIm9wZW5CYWNrZHJvcExvYWRlciIsInNldE9wZW5CYWNrZHJvcExvYWRlciIsImN1cnJlbnRHcm91cElkIiwic2V0Q3VycmVudEdyb3VwSWQiLCJhbGVydCIsInNldEFsZXJ0IiwidmlzaWJsZSIsIm1lc3NhZ2UiLCJ0eXBlIiwiZHJvcERvd25JdGVtcyIsImdyb3VwIiwiZHJvcERvd25JdGVtTGlzdCIsImtleSIsImxhYmVsIiwiX2lkIiwiaGFuZGxlVmlld01vZGFsT3BlbiIsIm9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciIsImUiLCJ2YWx1ZSIsInRhcmdldCIsImVycm9ycyIsInNldEVycm9ycyIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJ1c2VyX2lkIiwiYW1vdW50IiwicGF5bWVudF9ncm91cF90aWNrZXRzIiwiZXhwaXJ5Iiwic2VuZF9zbXMiLCJzZW5kX2VtYWlsIiwidXNyIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsImFkbWluX3R5cGUiLCJKU09OIiwicGFyc2UiLCJjb25zb2xlIiwiZXJyb3IiLCJmZXRjaFRvZGF5c1BheW1lbnRzIiwicmVzcG9uc2UiLCJnZXQiLCJwYXJhbXMiLCJmcm9tX2RhdGUiLCJ0b19kYXRlIiwiZGF0YSIsImxlbmd0aCIsImZvcm1hdHRlZERhdGEiLCJtYXAiLCJpbmRleCIsImdyb3VwX2lkIiwiZ3JvdXBfbmFtZSIsImlkIiwibmFtZSIsImZ1bGxfbmFtZSIsInBob25lX251bWJlciIsInRpY2tldCIsInBheW1lbnRfc3RhdHVzIiwidHJhbnNhY3Rpb25fZGF0ZSIsImZvcm1hdFBheURhdGUiLCJjcmVhdGVkQXQiLCJhY3Rpb24iLCJpdGVtcyIsImZldGNoQ3VzdG9tZXJMb2FuRGV0YWlscyIsInN0YXR1cyIsIkVycm9yIiwiZXJyIiwibG9nIiwiZmV0Y2hHcm91cHMiLCJ2YWxpZGF0ZUZvcm0iLCJuZXdFcnJvcnMiLCJjdXN0b21lciIsInBhcnNlRmxvYXQiLCJpc05hTiIsIk9iamVjdCIsImtleXMiLCJoYW5kbGVDaGFuZ2UiLCJwcmV2RGF0YSIsImhhbmRsZVBheW1lbnRBbnRTZWxlY3QiLCJ2YWx1ZXMiLCJoYW5kbGVHcm91cENoYW5nZSIsImdyb3VwSWQiLCJjb2x1bW5zIiwiaGVhZGVyIiwicHVzaCIsImhhbmRsZUN1c3RvbWVyIiwicHJldkZvcm1EYXRhIiwiaGFuZGxlR3JvdXBBdWN0aW9uQ2hhbmdlIiwiaGFuZGxlR3JvdXBQYXltZW50IiwiaGFuZGxlR3JvdXBQYXltZW50Q2hhbmdlIiwiZGF0ZVN0cmluZyIsInVybCIsImhhbmRsZVN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwiaXNWYWxpZCIsInBheWxvYWQiLCJwb3N0IiwicHJldiIsInZhbGlkQXVjdGlvbnMiLCJmaWx0ZXIiLCJhdWN0aW9uIiwiZW5yb2xsbWVudCIsInNlbGVjdGVkbmV3R3JvdXAiLCJmaW5kIiwiZyIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJ0b1N0cmluZyIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJ1bmRlZmluZWQiLCJpdGVtIiwic29tZSIsIlN0cmluZyIsImhlaWdodCIsImVudHJ5IiwiZ3JvdXBOYW1lIiwidGlja2V0cyIsInBpZ21lIiwicGlnbWVfaWQiLCJwYXlhYmxlX2Ftb3VudCIsImJvcnJvd2VyIiwibG9hbl9pZCIsImxvYW5fYW1vdW50IiwiTnVtYmVyIiwidG9GaXhlZCIsImNoZWNrZWQiLCJncm91cF92YWx1ZSIsImdyb3VwX2luc3RhbGwiLCJ3aW5fYW1vdW50IiwiY29tbWlzc2lvbiIsImRpdmlkZW50IiwiZGl2aWRlbnRfaGVhZCIsInBheWFibGUiLCJhdWN0aW9uX2RhdGUiLCJuZXh0X2RhdGUiLCJ1cGRhdGVkQXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJJbmRpdmlkdWFsQ2hpdFBheW1lbnRMaW5rLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgRHJvcGRvd24sIE1vZGFsIGFzIEFudE1vZGFsLCBBbGVydCwgRW1wdHkgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IEJhY2tkcm9wQmx1ckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0JhY2tkcm9wQmx1ckxvYWRlclwiO1xyXG5pbXBvcnQgeyBmaWVsZFNpemUgfSBmcm9tIFwiLi4vZGF0YS9maWVsZFNpemVcIjtcclxuaW1wb3J0IEJyZWFkY3J1bWIgZnJvbSBcIi4uL2hlbHBlcnMvQnJlYWRjcnVtYlwiO1xyXG5cclxuY29uc3QgSW5kaXZpZHVhbENoaXRQYXltZW50TGluayA9ICgpID0+IHtcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthY3R1YWxHcm91cHMsIHNldEFjdHVhbEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXAsIHNldFNlbGVjdGVkR3JvdXBdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW1RhYmxlUGF5bWVudHMsIHNldFRhYmxlUGF5bWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEF1Y3Rpb25Hcm91cCwgc2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXBJZCwgc2V0U2VsZWN0ZWRHcm91cElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEF1Y3Rpb25Hcm91cElkLCBzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtmaWx0ZXJlZFVzZXJzLCBzZXRGaWx0ZXJlZFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdmlld0xvYWRlciwgc2V0Vmlld0xvYWRlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkQXVjdGlvbiwgc2V0RmlsdGVyZWRBdWN0aW9uXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZ3JvdXBJbmZvLCBzZXRHcm91cEluZm9dID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbFZpZXcsIHNldFNob3dNb2RhbFZpZXddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50Vmlld0dyb3VwLCBzZXRDdXJyZW50Vmlld0dyb3VwXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcclxuICBcclxuICAvLyBDYWxjdWxhdGUgdG9tb3Jyb3cgY29ycmVjdGx5IChjdXJyZW50IGRhdGUgKyAxIGRheSlcclxuICBjb25zdCB0b21vcnJvdyA9IG5ldyBEYXRlKCk7XHJcbiAgdG9tb3Jyb3cuc2V0RGF0ZSh0b21vcnJvdy5nZXREYXRlKCkgKyAxKTtcclxuICBjb25zdCB0b21vcnJvd0Zvcm1hdHRlZCA9IHRvbW9ycm93LnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdO1xyXG5cclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZGlzYWJsZWQsIHNldERpc2FibGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYm9ycm93ZXJzLCBzZXRCb3Jyb3dlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtwaWdtZUN1c3RvbWVycywgc2V0UGlnbWVDdXN0b21lcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtlbmFibGVHcm91cENvbHVtbiwgc2V0RW5hYmxlR3JvdXBDb2x1bW5dID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW3BheW1lbnRHcm91cFRpY2tldHMsIHNldFBheW1lbnRHcm91cFRpY2tldHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtyZW5kZXIsIHNldFJlcmVuZGVyXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFtvcGVuQmFja2Ryb3BMb2FkZXIsIHNldE9wZW5CYWNrZHJvcExvYWRlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2N1cnJlbnRHcm91cElkLCBzZXRDdXJyZW50R3JvdXBJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBcclxuICAvLyBBbGVydCBzdGF0ZSBmb3IgQW50IERlc2lnbiBBbGVydFxyXG4gIGNvbnN0IFthbGVydCwgc2V0QWxlcnRdID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJsZTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCJcclxuICB9KTtcclxuXHJcbiAgY29uc3QgZHJvcERvd25JdGVtcyA9IChncm91cCkgPT4ge1xyXG4gICAgY29uc3QgZHJvcERvd25JdGVtTGlzdCA9IFtcclxuICAgICAge1xyXG4gICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgIDxMaW5rIHRvPXtgL3ByaW50LyR7Z3JvdXAuX2lkfWB9IGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTYwMCBcIj5cclxuICAgICAgICAgICAgUHJpbnRcclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICApLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAga2V5OiBcIjNcIixcclxuICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVZpZXdNb2RhbE9wZW4oZ3JvdXAuX2lkKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgVmlld1xyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSxcclxuICAgICAgfSxcclxuICAgIF07XHJcblxyXG4gICAgcmV0dXJuIGRyb3BEb3duSXRlbUxpc3Q7XHJcbiAgfTtcclxuICBcclxuICBjb25zdCBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRTZWFyY2hUZXh0KHZhbHVlKTtcclxuICB9O1xyXG4gIFxyXG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICB1c2VyX2lkOiBcIlwiLFxyXG4gICAgYW1vdW50OiBcIlwiLFxyXG4gICAgcGF5bWVudF9ncm91cF90aWNrZXRzOiBbXSxcclxuICAgIGV4cGlyeTogdG9tb3Jyb3dGb3JtYXR0ZWQsIC8vIFVzZSB0aGUgY29ycmVjdGx5IGNhbGN1bGF0ZWQgdG9tb3Jyb3dcclxuICAgIHNlbmRfc21zOiB0cnVlLFxyXG4gICAgc2VuZF9lbWFpbDogdHJ1ZSxcclxuICB9KTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHVzciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGxldCBhZG1pbl90eXBlID0gbnVsbDtcclxuICAgIHRyeSB7XHJcbiAgICAgIGlmICh1c3IpIHtcclxuICAgICAgICBhZG1pbl90eXBlID0gSlNPTi5wYXJzZSh1c3IpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gcGFyc2UgdXNlciBmcm9tIGxvY2FsU3RvcmFnZTpcIiwgZSk7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgZmV0Y2hUb2RheXNQYXltZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRUYWJsZVBheW1lbnRzKFtdKTtcclxuICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3BheW1lbnRhcGkvcGF5bWVudC1saW5rXCIsIHtcclxuICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICBmcm9tX2RhdGU6IHRvZGF5LFxyXG4gICAgICAgICAgICB0b19kYXRlOiB0b2RheSxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gcmVzcG9uc2UuZGF0YS5tYXAoKGdyb3VwLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoIWdyb3VwPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSkgcmV0dXJuIHt9O1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgIF9pZDogZ3JvdXAuX2lkLFxyXG4gICAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgbmFtZTogZ3JvdXA/LnVzZXJfaWQ/LmZ1bGxfbmFtZSxcclxuICAgICAgICAgICAgICBwaG9uZV9udW1iZXI6IGdyb3VwPy51c2VyX2lkPy5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgICAgZ3JvdXBfbmFtZTogZ3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9uYW1lLFxyXG4gICAgICAgICAgICAgIHRpY2tldDogZ3JvdXAudGlja2V0LFxyXG4gICAgICAgICAgICAgIGFtb3VudDogZ3JvdXAuYW1vdW50LFxyXG4gICAgICAgICAgICAgIHBheW1lbnRfc3RhdHVzOiBncm91cC5wYXltZW50X3N0YXR1cyxcclxuICAgICAgICAgICAgICB0cmFuc2FjdGlvbl9kYXRlOiBmb3JtYXRQYXlEYXRlKGdyb3VwLmNyZWF0ZWRBdCksXHJcbiAgICAgICAgICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgICAgICAgICAgdHJpZ2dlcj17W1wiY2xpY2tcIl19XHJcbiAgICAgICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgaXRlbXM6IGRyb3BEb3duSXRlbXMoZ3JvdXApLFxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIHNldFRhYmxlUGF5bWVudHMoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgICAgICBzZXRFbmFibGVHcm91cENvbHVtbih0cnVlKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHBheW1lbnQgTGluayBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgICAgICAvLyBTaG93IGVycm9yIGFsZXJ0XHJcbiAgICAgICAgc2V0QWxlcnQoe1xyXG4gICAgICAgICAgdmlzaWJsZTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGxvYWQgcGF5bWVudCBkYXRhXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCJcclxuICAgICAgICB9KTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoVG9kYXlzUGF5bWVudHMoKTtcclxuICB9LCBbcmVuZGVyXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRCb3Jyb3dlcnMoW10pO1xyXG4gICAgY29uc3QgZmV0Y2hDdXN0b21lckxvYW5EZXRhaWxzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICAgIGAvbG9hbnMvZ2V0LWJvcnJvd2VyLWJ5LXVzZXItaWQvJHtzZWxlY3RlZEdyb3VwSWR9YFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA+PSA0MDApXHJcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJmZXRjaGluZyBsb2FuIGJvcnJvd2VycyBGYWlsZWRcIik7XHJcbiAgICAgICAgc2V0Qm9ycm93ZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIkVycm9yIE9jY3VycmVkXCIpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoQ3VzdG9tZXJMb2FuRGV0YWlscygpO1xyXG4gIH0sIFtzZWxlY3RlZEdyb3VwSWRdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldFBpZ21lQ3VzdG9tZXJzKFtdKTtcclxuICAgIGNvbnN0IGZldGNoQ3VzdG9tZXJMb2FuRGV0YWlscyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgICBgL3BpZ21lL2dldC1waWdtZS1jdXN0b21lci1ieS11c2VyLWlkLyR7c2VsZWN0ZWRHcm91cElkfWBcclxuICAgICAgICApO1xyXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPj0gNDAwKVxyXG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiZmV0Y2hpbmcgcGlnbWUgY3VzdG9tZXJzIEZhaWxlZFwiKTtcclxuICAgICAgICBzZXRQaWdtZUN1c3RvbWVycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXHJcbiAgICAgICAgICBcIkVycm9yIE9jY3VycmVkIHdoaWxlIGZldGNoaW5nIHBpZ21lIGN1c3RvbWVycyxcIixcclxuICAgICAgICAgIGVyci5tZXNzYWdlXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaEN1c3RvbWVyTG9hbkRldGFpbHMoKTtcclxuICB9LCBbc2VsZWN0ZWRHcm91cElkXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEdyb3VwcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuICAgICAgICBzZXRHcm91cHMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGdyb3VwIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoR3JvdXBzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hHcm91cHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2dyb3VwL2dldC1ncm91cC1hZG1pblwiKTtcclxuICAgICAgICBzZXRBY3R1YWxHcm91cHMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGdyb3VwIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoR3JvdXBzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCB2YWxpZGF0ZUZvcm0gPSAoKSA9PiB7XHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuXHJcbiAgICBpZiAoIXNlbGVjdGVkR3JvdXBJZCkge1xyXG4gICAgICBuZXdFcnJvcnMuY3VzdG9tZXIgPSBcIlBsZWFzZSBzZWxlY3QgYSBjdXN0b21lclwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghcGF5bWVudEdyb3VwVGlja2V0cyB8fCBwYXltZW50R3JvdXBUaWNrZXRzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICBuZXdFcnJvcnMucGF5bWVudF9ncm91cF90aWNrZXRzID0gXCJQbGVhc2Ugc2VsZWN0IGEgZ3JvdXAgYW5kIHRpY2tldFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGFtb3VudCA9IHBhcnNlRmxvYXQoZm9ybURhdGEuYW1vdW50KTtcclxuICAgIGlmIChpc05hTihhbW91bnQpIHx8IGFtb3VudCA8PSAwKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hbW91bnQgPSBcIlBsZWFzZSBlbnRlciBhIHZhbGlkIHBvc2l0aXZlIGFtb3VudFwiO1xyXG4gICAgfVxyXG5cclxuICAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKG5ld0Vycm9ycykubGVuZ3RoID09PSAwO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXZEYXRhKSA9PiAoeyAuLi5wcmV2RGF0YSwgW25hbWVdOiBcIlwiIH0pKTtcclxuICB9O1xyXG4gIFxyXG4gIGNvbnN0IGhhbmRsZVBheW1lbnRBbnRTZWxlY3QgPSAodmFsdWVzKSA9PiB7XHJcbiAgICBzZXRQYXltZW50R3JvdXBUaWNrZXRzKHZhbHVlcyk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3JvdXBDaGFuZ2UgPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRHcm91cChncm91cElkKTtcclxuXHJcbiAgICBpZiAoZ3JvdXBJZCkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL2Vucm9sbC9nZXQtZ3JvdXAtZW5yb2xsLyR7Z3JvdXBJZH1gKTtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgIHNldEZpbHRlcmVkVXNlcnMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldEZpbHRlcmVkVXNlcnMoW10pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW5yb2xsbWVudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRVc2VycyhbXSk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEZpbHRlcmVkVXNlcnMoW10pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcInRyYW5zYWN0aW9uX2RhdGVcIiwgaGVhZGVyOiBcIlRyYW5zYWN0aW9uIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIFBob25lIE51bWJlclwiIH0sXHJcbiAgXTtcclxuICBpZiAoZW5hYmxlR3JvdXBDb2x1bW4pIHtcclxuICAgIGNvbHVtbnMucHVzaCh7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSk7XHJcbiAgfVxyXG4gIGNvbHVtbnMucHVzaChcclxuICAgIHsga2V5OiBcInRpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0IE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJhbW91bnRcIiwgaGVhZGVyOiBcIkFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJwYXltZW50X3N0YXR1c1wiLCBoZWFkZXI6IFwiUGF5bWVudCBTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9XHJcbiAgKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ3VzdG9tZXIgPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRHcm91cElkKGdyb3VwSWQpO1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZGb3JtRGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkZvcm1EYXRhLFxyXG4gICAgICB1c2VyX2lkOiBncm91cElkLFxyXG4gICAgfSkpO1xyXG4gICAgc2V0RXJyb3JzKChwcmV2RGF0YSkgPT4gKHsgLi4ucHJldkRhdGEsIGN1c3RvbWVyOiBcIlwiIH0pKTtcclxuICAgIHNldFBheW1lbnRHcm91cFRpY2tldHMoW10pO1xyXG4gICAgaGFuZGxlR3JvdXBDaGFuZ2UoZ3JvdXBJZCk7XHJcbiAgICBoYW5kbGVHcm91cEF1Y3Rpb25DaGFuZ2UoZ3JvdXBJZCk7XHJcblxyXG4gICAgaWYgKGdyb3VwSWQpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9ncm91cC9nZXQtYnktaWQtZ3JvdXAvJHtncm91cElkfWApO1xyXG4gICAgICAgIHNldEdyb3VwSW5mbyhyZXNwb25zZS5kYXRhIHx8IHt9KTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBzZXRHcm91cEluZm8oe30pO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRHcm91cEluZm8oe30pO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgXHJcbiAgY29uc3QgaGFuZGxlR3JvdXBQYXltZW50ID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHNldFNlbGVjdGVkQXVjdGlvbkdyb3VwSWQoZ3JvdXBJZCk7XHJcbiAgICBoYW5kbGVHcm91cFBheW1lbnRDaGFuZ2UoZ3JvdXBJZCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZm9ybWF0UGF5RGF0ZSA9IChkYXRlU3RyaW5nKSA9PiB7XHJcbiAgICByZXR1cm4gZGF0ZVN0cmluZz8uc3BsaXQoXCJUXCIpWzBdO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUdyb3VwUGF5bWVudENoYW5nZSA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cChncm91cElkKTtcclxuICAgIGlmIChncm91cElkKSB7XHJcbiAgICAgIGxldCB1cmw7XHJcbiAgICAgIGlmIChncm91cElkID09PSBcInRvZGF5XCIpIHtcclxuICAgICAgICB1cmwgPSBgL3BheW1lbnRhcGkvcGF5bWVudC1saW5rL2dldC1wYXltZW50cz9mcm9tX2RhdGU9JHt0b2RheX0mdG9fZGF0ZT0ke3RvZGF5fWA7XHJcbiAgICAgICAgc2V0RW5hYmxlR3JvdXBDb2x1bW4odHJ1ZSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdXJsID0gYC9wYXltZW50YXBpL3BheW1lbnQtbGluay8ke2dyb3VwSWR9YDtcclxuICAgICAgICBzZXRFbmFibGVHcm91cENvbHVtbihmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRUYWJsZVBheW1lbnRzKFtdKTtcclxuICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KHVybCk7XHJcblxyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlLmRhdGEubWFwKChncm91cCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgaWYgKCFncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUpIHJldHVybiB7fTtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICBfaWQ6IGdyb3VwLl9pZCxcclxuICAgICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICAgIG5hbWU6IGdyb3VwPy51c2VyX2lkPy5mdWxsX25hbWUsXHJcbiAgICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiBncm91cD8udXNlcl9pZD8ucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgICAgICAgIGdyb3VwX25hbWU6IGdyb3VwPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSxcclxuICAgICAgICAgICAgICB0aWNrZXQ6IGdyb3VwLnRpY2tldCxcclxuICAgICAgICAgICAgICBhbW91bnQ6IGdyb3VwLmFtb3VudCxcclxuICAgICAgICAgICAgICB0cmFuc2FjdGlvbl9kYXRlOiBncm91cD8uY3JlYXRlZEF0Py5zcGxpdChcIlRcIilbMF0sXHJcbiAgICAgICAgICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgICAgICAgICAgdHJpZ2dlcj17W1wiY2xpY2tcIl19XHJcbiAgICAgICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgaXRlbXM6IGRyb3BEb3duSXRlbXMoZ3JvdXApLFxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIHNldFRhYmxlUGF5bWVudHMoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBwYXltZW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24oW10pO1xyXG4gICAgICAgIC8vIFNob3cgZXJyb3IgYWxlcnRcclxuICAgICAgICBzZXRBbGVydCh7XHJcbiAgICAgICAgICB2aXNpYmxlOiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gbG9hZCBwYXltZW50IGRhdGFcIixcclxuICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIlxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihbXSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGNvbnN0IGlzVmFsaWQgPSB2YWxpZGF0ZUZvcm0oKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGlmIChpc1ZhbGlkKSB7XHJcbiAgICAgICAgc2V0RGlzYWJsZWQodHJ1ZSk7XHJcbiAgICAgICAgc2V0QWxlcnQoeyB2aXNpYmxlOiBmYWxzZSwgbWVzc2FnZTogXCJcIiwgdHlwZTogXCJpbmZvXCIgfSk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgICBsZXQgcGF5bG9hZDtcclxuICAgICAgICBjb25zdCB1c3IgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICAgICAgbGV0IGFkbWluX3R5cGUgPSBudWxsO1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBpZiAodXNyKSB7XHJcbiAgICAgICAgICAgIGFkbWluX3R5cGUgPSBKU09OLnBhcnNlKHVzcik7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBwYXJzZSB1c2VyIGZyb20gbG9jYWxTdG9yYWdlOlwiLCBlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZm9ybURhdGEucGF5bWVudF9ncm91cF90aWNrZXRzID0gcGF5bWVudEdyb3VwVGlja2V0cztcclxuICAgICAgICBmb3JtRGF0YS5hZG1pbl90eXBlID0gYWRtaW5fdHlwZT8uX2lkO1xyXG4gICAgICAgIHNldE9wZW5CYWNrZHJvcExvYWRlcih0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KFwiL3BheW1lbnRhcGkvcGF5bWVudC1saW5rXCIsIGZvcm1EYXRhKTtcclxuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSAyMDEpIHtcclxuICAgICAgICAgIHNldFNlbGVjdGVkR3JvdXBJZChcIlwiKTtcclxuICAgICAgICAgIHNldFBheW1lbnRHcm91cFRpY2tldHMoW10pO1xyXG4gICAgICAgICAgc2V0RGlzYWJsZWQoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgICB1c2VyX2lkOiBcIlwiLFxyXG4gICAgICAgICAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgICAgIHBheW1lbnRfZ3JvdXBfdGlja2V0czogW10sXHJcbiAgICAgICAgICAgIGV4cGlyeTogdG9tb3Jyb3dGb3JtYXR0ZWQsIC8vIFJlc2V0IHdpdGggY29ycmVjdCB0b21vcnJvdyBkYXRlXHJcbiAgICAgICAgICAgIHNlbmRfc21zOiB0cnVlLFxyXG4gICAgICAgICAgICBzZW5kX2VtYWlsOiB0cnVlLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBzZXRBbGVydCh7XHJcbiAgICAgICAgICAgIHZpc2libGU6IHRydWUsXHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGF5bWVudCBBZGRlZCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPj0gNDAwKSB7XHJcbiAgICAgICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0U2VsZWN0ZWRHcm91cElkKFwiXCIpO1xyXG4gICAgICAgICAgc2V0UGF5bWVudEdyb3VwVGlja2V0cyhbXSk7XHJcbiAgICAgICAgICBzZXREaXNhYmxlZChmYWxzZSk7XHJcbiAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgIHVzZXJfaWQ6IFwiXCIsXHJcbiAgICAgICAgICAgIGFtb3VudDogXCJcIixcclxuICAgICAgICAgICAgcGF5bWVudF9ncm91cF90aWNrZXRzOiBbXSxcclxuICAgICAgICAgICAgZXhwaXJ5OiB0b21vcnJvd0Zvcm1hdHRlZCwgLy8gUmVzZXQgd2l0aCBjb3JyZWN0IHRvbW9ycm93IGRhdGVcclxuICAgICAgICAgICAgc2VuZF9zbXM6IHRydWUsXHJcbiAgICAgICAgICAgIHNlbmRfZW1haWw6IHRydWUsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIHNldEFsZXJ0KHtcclxuICAgICAgICAgICAgdmlzaWJsZTogdHJ1ZSxcclxuICAgICAgICAgICAgbWVzc2FnZTogXCJQYXltZW50IEFkZGVkIEZhaWxlZFwiLFxyXG4gICAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbiAgICAgIHNldFNlbGVjdGVkR3JvdXBJZChcIlwiKTtcclxuICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgIHVzZXJfaWQ6IFwiXCIsXHJcbiAgICAgICAgYW1vdW50OiBcIlwiLFxyXG4gICAgICAgIHBheW1lbnRfZ3JvdXBfdGlja2V0czogW10sXHJcbiAgICAgICAgZXhwaXJ5OiB0b21vcnJvd0Zvcm1hdHRlZCwgLy8gUmVzZXQgd2l0aCBjb3JyZWN0IHRvbW9ycm93IGRhdGVcclxuICAgICAgICBzZW5kX3NtczogdHJ1ZSxcclxuICAgICAgICBzZW5kX2VtYWlsOiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0QWxlcnQoe1xyXG4gICAgICAgIHZpc2libGU6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogYEVycm9yIHN1Ym1pdHRpbmcgcGF5bWVudCBkYXRhOiAke2Vycm9yLm1lc3NhZ2V9YCxcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXREaXNhYmxlZChmYWxzZSk7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBzdWJtaXR0aW5nIHBheW1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0T3BlbkJhY2tkcm9wTG9hZGVyKGZhbHNlKTtcclxuICAgICAgc2V0UmVyZW5kZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVWaWV3TW9kYWxPcGVuID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIHNldFNob3dNb2RhbFZpZXcodHJ1ZSk7XHJcbiAgICAgIHNldEN1cnJlbnRHcm91cElkKGdyb3VwSWQpO1xyXG4gICAgICBzZXRWaWV3TG9hZGVyKHRydWUpO1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9wYXltZW50YXBpL3BheW1lbnQtbGluay8ke2dyb3VwSWR9YCk7XHJcbiAgICAgIHNldEN1cnJlbnRWaWV3R3JvdXAocmVzcG9uc2UuZGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3Igdmlld2luZyBQYXltZW50OlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0KHtcclxuICAgICAgICB2aXNpYmxlOiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGxvYWQgcGF5bWVudCBkZXRhaWxzXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiXHJcbiAgICAgIH0pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIHNldFZpZXdMb2FkZXIoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUdyb3VwQXVjdGlvbkNoYW5nZSA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICBpZiAoZ3JvdXBJZCkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoXHJcbiAgICAgICAgICBgL2Vucm9sbC9nZXQtdXNlci10aWNrZXRzLXJlcG9ydC8ke2dyb3VwSWR9YFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBjb25zdCB2YWxpZEF1Y3Rpb25zID0gcmVzcG9uc2UuZGF0YS5maWx0ZXIoXHJcbiAgICAgICAgICAgIChhdWN0aW9uKSA9PiBhdWN0aW9uLmVucm9sbG1lbnQgJiYgYXVjdGlvbi5lbnJvbGxtZW50Lmdyb3VwXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKHZhbGlkQXVjdGlvbnMpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24oW10pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW5yb2xsbWVudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgICAgICAvLyBTaG93IGVycm9yIGFsZXJ0XHJcbiAgICAgICAgc2V0QWxlcnQoe1xyXG4gICAgICAgICAgdmlzaWJsZTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGxvYWQgZ3JvdXAgYXVjdGlvbiBkYXRhXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCJcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgIH1cclxuICB9O1xyXG4gIFxyXG4gIGNvbnN0IHNlbGVjdGVkbmV3R3JvdXAgPSBhY3R1YWxHcm91cHMuZmluZChcclxuICAgIChnKSA9PiBnLl9pZCA9PT0gc2VsZWN0ZWRBdWN0aW9uR3JvdXBJZFxyXG4gICk7XHJcbiAgXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIHtvcGVuQmFja2Ryb3BMb2FkZXIgPyAoXHJcbiAgICAgICAgPEJhY2tkcm9wQmx1ckxvYWRlciB0aXRsZT17XCJwYXltZW50IERhdGEgcHJvY2Vzc2luZy4uLi5cIn0gLz5cclxuICAgICAgKSA6IChcclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e29uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn1cclxuICAgICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgey8qIEFudCBEZXNpZ24gQWxlcnQgKi99XHJcbiAgICAgICAgICAgIHthbGVydC52aXNpYmxlICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIHRvcC00IHJpZ2h0LTQgei01MCB3LTk2XCI+XHJcbiAgICAgICAgICAgICAgICA8QWxlcnRcclxuICAgICAgICAgICAgICAgICAgbWVzc2FnZT17YWxlcnQubWVzc2FnZX1cclxuICAgICAgICAgICAgICAgICAgdHlwZT17YWxlcnQudHlwZX1cclxuICAgICAgICAgICAgICAgICAgc2hvd0ljb25cclxuICAgICAgICAgICAgICAgICAgY2xvc2FibGVcclxuICAgICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0QWxlcnQoeyAuLi5hbGVydCwgdmlzaWJsZTogZmFsc2UgfSl9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5QYXltZW50IExpbmtzPC9oMT5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgIG1iLThcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMTBcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPlNlYXJjaCBvciBTZWxlY3QgR3JvdXA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlRvZGF5J3MgUGF5bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsICBoLTE0IG1heC13LW1kXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEF1Y3Rpb25Hcm91cElkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVHcm91cFBheW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtcIiMxXCJ9IHZhbHVlPXtcInRvZGF5XCJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUb2RheSdzIFBheW1lbnRzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7YWN0dWFsR3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtncm91cC5faWR9IHZhbHVlPXtncm91cC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cC5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TW9kYWwodHJ1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTQgYmctdmlvbGV0LTk1MCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy12aW9sZXQtODAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKyBBZGQgUGF5bWVudCBMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7aXNMb2FkaW5nPyA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICBkYXRhPVwiUGF5bWVudHMgRGF0YVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBmYWlsdXJlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgVGFibGVQYXltZW50cy5sZW5ndGggPD0gMCAmJiBzZWxlY3RlZEF1Y3Rpb25Hcm91cElkXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz46IFRhYmxlUGF5bWVudHMgJiYgVGFibGVQYXltZW50cy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YT17VGFibGVQYXltZW50cy5maWx0ZXIoKGl0ZW0pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBPYmplY3QudmFsdWVzKGl0ZW0pLnNvbWUoKHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTdHJpbmcodmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoc2VhcmNoVGV4dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJQYXltZW50c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtbXCJHcm91cCBOYW1lXCJdfVxyXG4gICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbXHJcbiAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZG5ld0dyb3VwPy5ncm91cF9uYW1lIHx8IFwiVG9kYXknc1wiLFxyXG4gICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YFBheW1lbnRzLmNzdmB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwIHRleHQtY2VudGVyIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgIDxFbXB0eSBkZXNjcmlwdGlvbj1cIk5vIFBheW1lbnQgTGluayBUcmFuc2FjdGlvbiBGb3VuZFwiLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgICAgIGlzVmlzaWJsZT17c2hvd01vZGFsfVxyXG4gICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkR3JvdXBJZChcIlwiKTtcclxuICAgICAgICAgICAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgICAgICAgICAgICAgc2V0UGF5bWVudEdyb3VwVGlja2V0cyhbXSk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNiB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGJvcmRlci1iIHBiLTJcIj5cclxuICAgICAgICAgICAgICAgICAgQWRkIFBheW1lbnQgTGlua1xyXG4gICAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsICR7ZmllbGRTaXplLmhlaWdodH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3Qgb3IgU2VhcmNoIEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24/LmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPy50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEdyb3VwSWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUN1c3RvbWVyfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cHMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Ake2dyb3VwLmZ1bGxfbmFtZX0gfCAke2dyb3VwLnBob25lX251bWJlcn1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmN1c3RvbWVyICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jdXN0b21lcn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZ3JvdXAtdGlja2V0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBHcm91cCAmIFRpY2tldCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJncm91cC10aWNrZXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbW9kZT1cIm11bHRpcGxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEdyb3VwIHwgVGlja2V0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQYXltZW50QW50U2VsZWN0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BheW1lbnRHcm91cFRpY2tldHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCAke2ZpZWxkU2l6ZS5oZWlnaHR9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRBdWN0aW9uLm1hcCgoZW50cnksIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGdyb3VwTmFtZSA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZW50cnk/LmVucm9sbG1lbnQ/Lmdyb3VwPy5ncm91cF9uYW1lIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJVbm5hbWVkIEdyb3VwXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGdyb3VwSWQgPVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGVudHJ5Py5lbnJvbGxtZW50Py5ncm91cD8uX2lkIHx8IGBtaXNzaW5nLSR7aW5kZXh9YDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdGlja2V0ID0gZW50cnk/LmVucm9sbG1lbnQ/LnRpY2tldHMgfHwgXCJVbmtub3duXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17YGNoaXQtJHtncm91cElkfXwke3RpY2tldH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2BjaGl0LSR7Z3JvdXBJZH18JHt0aWNrZXR9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXBOYW1lfSB8IHt0aWNrZXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cGlnbWVDdXN0b21lcnM/Lm1hcCgocGlnbWUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3BpZ21lLl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YHBpZ21lLSR7cGlnbWUuX2lkfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7YCR7cGlnbWUucGlnbWVfaWR9IHwg4oK5ICR7cGlnbWUucGF5YWJsZV9hbW91bnR9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Ym9ycm93ZXJzPy5tYXAoKGJvcnJvd2VyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtib3Jyb3dlci5faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Bsb2FuLSR7Ym9ycm93ZXIuX2lkfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7YGxvYW4tJHtib3Jyb3dlci5sb2FuX2lkfSB8IOKCuSAke2JvcnJvd2VyLmxvYW5fYW1vdW50fWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGF5bWVudF9ncm91cF90aWNrZXRzICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXltZW50X2dyb3VwX3RpY2tldHN9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBbW91bnQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFtb3VudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmFtb3VudCAmJiBwYXltZW50R3JvdXBUaWNrZXRzLmxlbmd0aCA+IDEgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgSW5kaXZpZHVhbCBUaWNrZXQgQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctZ3JheS0xMDAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktNzAwIHRleHQtc20gcm91bmRlZC1sZyBwLTIuNSBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVG90YWwgQW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgTnVtYmVyKGZvcm1EYXRhLmFtb3VudCkgLyBwYXltZW50R3JvdXBUaWNrZXRzLmxlbmd0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkudG9GaXhlZCgyKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiBFeHBpcnkgRGF0ZSBGaWVsZCAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJleHBpcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIEV4cGlyeSBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZXhwaXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJleHBpcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbWluPXt0b21vcnJvd0Zvcm1hdHRlZH0gLy8gUHJldmVudCBzZWxlY3RpbmcgcGFzdCBkYXRlc1xyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmV4cGlyeX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogU2VuZCBTTVMgQ2hlY2tib3ggKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwic2VuZF9zbXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJzZW5kX3Ntc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtmb3JtRGF0YS5zZW5kX3Ntc31cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZW5kX3NtczogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTQgaC00IGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBiZy1ncmF5LTUwXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInNlbmRfc21zXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTZW5kIFNNU1xyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIFNlbmQgRW1haWwgQ2hlY2tib3ggKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwic2VuZF9lbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInNlbmRfZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGEuc2VuZF9lbWFpbH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZW5kX2VtYWlsOiBlLnRhcmdldC5jaGVja2VkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIGJnLWdyYXktNTBcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwic2VuZF9lbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2VuZCBFbWFpbFxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIHB0LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS80IHRleHQtd2hpdGUgYmctdmlvbGV0LTcwMCBob3ZlcjpiZy12aW9sZXQtODAwIGFjdGl2ZTpiZy12aW9sZXQtOTAwIFxyXG4gICAgICAgICAgICAgICAgICAgYm9yZGVyLTIgYm9yZGVyLXZpb2xldC03MDAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLXZpb2xldC0zMDAgXHJcbiAgICAgICAgICAgICAgICAgICBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBBZGQgUGF5bWVudCBMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgICAgICAgPEFudE1vZGFsXHJcbiAgICAgICAgICAgICAgb3Blbj17c2hvd01vZGFsVmlld31cclxuICAgICAgICAgICAgICBvbkNhbmNlbD17KCkgPT4gc2V0U2hvd01vZGFsVmlldyhmYWxzZSl9XHJcbiAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsVmlldyhmYWxzZSl9XHJcbiAgICAgICAgICAgICAgb25Paz17KCkgPT4gc2V0U2hvd01vZGFsVmlldyhmYWxzZSl9XHJcbiAgICAgICAgICAgICAgb25SZWxvYWQ9eygpID0+IGhhbmRsZVZpZXdNb2RhbE9wZW4oY3VycmVudEdyb3VwSWQpfVxyXG4gICAgICAgICAgICAgIGZvb3Rlcj17PGRpdj48L2Rpdj59XHJcbiAgICAgICAgICAgICAgbG9hZGluZz17dmlld0xvYWRlcn1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgIFBheW1lbnQgRGV0YWlsc1xyXG4gICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZ2FwLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPkdyb3VwOiA8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50Vmlld0dyb3VwPy5ncm91cF9pZD8uZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZ2FwLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPkdyb3VwIFZhbHVlOjwvc3Ryb25nPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAge2N1cnJlbnRWaWV3R3JvdXA/Lmdyb3VwX2lkPy5ncm91cF92YWx1ZX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZ2FwLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPkdyb3VwIEluc3RhbGxtZW50Ojwvc3Ryb25nPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAge2N1cnJlbnRWaWV3R3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9pbnN0YWxsfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+VXNlcjo8L3N0cm9uZz4ge2N1cnJlbnRWaWV3R3JvdXA/LnVzZXJfaWQ/LmZ1bGxfbmFtZX17XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHwgVGlja2V0OiB7Y3VycmVudFZpZXdHcm91cD8udGlja2V0fVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+QmlkIEFtb3VudDo8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50Vmlld0dyb3VwPy5ncm91cF9pZD8uZ3JvdXBfdmFsdWUgLVxyXG4gICAgICAgICAgICAgICAgICBjdXJyZW50Vmlld0dyb3VwPy53aW5fYW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgPyBjdXJyZW50Vmlld0dyb3VwPy5ncm91cF9pZD8uZ3JvdXBfdmFsdWUgLVxyXG4gICAgICAgICAgICAgICAgICAgICAgY3VycmVudFZpZXdHcm91cD8ud2luX2Ftb3VudFxyXG4gICAgICAgICAgICAgICAgICAgIDogXCJcIn1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZ2FwLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPkNvbW1pc3Npb246PC9zdHJvbmc+IHtjdXJyZW50Vmlld0dyb3VwPy5jb21taXNzaW9ufVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+V2lubmluZyBBbW91bnQ6PC9zdHJvbmc+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICB7Y3VycmVudFZpZXdHcm91cD8ud2luX2Ftb3VudH1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZ2FwLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPkRpdmlkZW50Ojwvc3Ryb25nPiB7Y3VycmVudFZpZXdHcm91cD8uZGl2aWRlbnR9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGdhcC14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5EaXZpZGVudCBwZXIgSGVhZDo8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50Vmlld0dyb3VwPy5kaXZpZGVudF9oZWFkfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+TmV4dCBQYXlhYmxlOjwvc3Ryb25nPiB7Y3VycmVudFZpZXdHcm91cD8ucGF5YWJsZX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZ2FwLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPkF1Y3Rpb24gRGF0ZTo8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50Vmlld0dyb3VwPy5hdWN0aW9uX2RhdGV9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGdhcC14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5OZXh0IERhdGU6PC9zdHJvbmc+IHtjdXJyZW50Vmlld0dyb3VwPy5uZXh0X2RhdGV9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGdhcC14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5DcmVhdGVkIEF0Ojwvc3Ryb25nPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAge2N1cnJlbnRWaWV3R3JvdXA/LmNyZWF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+VXBkYXRlZCBBdDo8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50Vmlld0dyb3VwPy51cGRhdGVkQXQ/LnNwbGl0KFwiVFwiKVswXX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L0FudE1vZGFsPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgSW5kaXZpZHVhbENoaXRQYXltZW50TGluaztcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0luZGl2aWR1YWxDaGl0UGF5bWVudExpbmsuanN4In0=