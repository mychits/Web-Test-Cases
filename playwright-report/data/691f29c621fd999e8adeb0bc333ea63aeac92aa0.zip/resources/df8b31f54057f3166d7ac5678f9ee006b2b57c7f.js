import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Guarantor.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Input, Select, Dropdown } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import handleGuarantorPrint from "/src/components/printFormats/GuarantorPrint.js";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { fieldSize } from "/src/data/fieldSize.js";
import { IoMdClose } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const Guarantor = () => {
  _s();
  const [users, setUsers] = useState([]);
  const [guarantor, setGuarantor] = useState([]);
  const [TableGuarantor, setTableGuarantor] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentGuarantor, setCurrentGuarantor] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [currentUpdateGuarantor, setCurrentUpdateGuarantor] = useState(null);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [enrollment, setEnrollment] = useState([]);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [customRelationship, setCustomRelationship] = useState("");
  const [errors, setErrors] = useState({});
  const [filteredEnrollments, setFilteredEnrollments] = useState([]);
  const [formData, setFormData] = useState({
    user_id: "",
    guarantor_name: "",
    guarantor_email: "",
    user_guarantor: "",
    guarantor_phone_number: "",
    guarantor_address: "",
    guarantor_pincode: "",
    guarantor_adhaar_no: "",
    guarantor_pan_no: "",
    guarantor_gender: "",
    guarantor_marital_status: "",
    guarantor_dateofbirth: "",
    guarantor_nationality: "",
    guarantor_village: "",
    guarantor_taluk: "",
    guarantor_father_name: "",
    guarantor_district: "",
    guarantor_state: "",
    guarantor_description: "",
    enrollment_ids: [],
    guarantor_alternate_number: "",
    guarantor_referred_type: "",
    guarantor_document_name: "",
    guarantor_document: "",
    guarantor_photo: "",
    guarantor_pan_document: "",
    guarantor_aadhar_document: "",
    guarantor_relationship_type: "",
    guarantor_occupation: "",
    guarantor_sector_name: "",
    guarantor_income_document: "",
    guarantor_consent_document: "",
    guarantor_bank_name: "",
    guarantor_bank_account_number: "",
    guarantor_bank_branch: "",
    guarantor_bank_ifsc_code: "",
    guarantor_bank_passbook: "",
    guarantor_bank_passbook_photo: "",
    guarantor_bussiness_type: "",
    guarantor_bussiness_name: "",
    guarantor_bussiness_address: "",
    guarantor_profession_type: "",
    guarantor_agri_rtc_no: "",
    guarantor_land_holdings: "",
    guarantor_occupation_sub: "",
    guarantor_all_document_name: "",
    guarantor_all_document: ""
  });
  const [updateFormData, setUpdateFormData] = useState({
    user_id: "",
    guarantor_name: "",
    guarantor_email: "",
    user_guarantor: "",
    guarantor_phone_number: "",
    guarantor_address: "",
    guarantor_pincode: "",
    guarantor_adhaar_no: "",
    guarantor_pan_no: "",
    guarantor_gender: "",
    guarantor_marital_status: "",
    guarantor_dateofbirth: "",
    guarantor_nationality: "",
    guarantor_village: "",
    guarantor_taluk: "",
    guarantor_father_name: "",
    guarantor_district: "",
    guarantor_state: "",
    guarantor_description: "",
    guarantor_alternate_number: "",
    enrollment_ids: [],
    guarantor_referred_type: "",
    guarantor_document: "",
    guarantor_document_name: "",
    guarantor_photo: "",
    guarantor_pan_document: "",
    guarantor_aadhar_document: "",
    guarantor_relationship_type: "",
    guarantor_occupation: "",
    guarantor_sector_name: "",
    guarantor_income_document: "",
    guarantor_consent_document: "",
    guarantor_bank_name: "",
    guarantor_bank_account_number: "",
    guarantor_bank_branch: "",
    guarantor_bank_ifsc_code: "",
    guarantor_bank_passbook: "",
    guarantor_bank_passbook_photo: "",
    guarantor_bussiness_type: "",
    guarantor_bussiness_name: "",
    guarantor_bussiness_address: "",
    guarantor_profession_type: "",
    guarantor_agri_rtc_no: "",
    guarantor_land_holdings: "",
    guarantor_occupation_sub: "",
    guarantor_all_document_name: "",
    guarantor_all_document: ""
  });
  const [searchText, setSearchText] = useState("");
  const GlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [extraDocs, setExtraDocs] = useState(
    formData.guarantor_all_document || [
      { document_name: "", file: null, preview: "" }
    ]
  );
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await api.get("/user/get-user");
        setUsers(response.data);
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };
    fetchUsers();
  }, []);
  const handleExtraDocNameChange = (index, e) => {
    const updated = [...extraDocs];
    updated[index].document_name = e.target.value;
    setExtraDocs(updated);
  };
  const handleExtraDocFileChange = (index, e) => {
    const file = e.target.files[0];
    if (file) {
      const updated = [...extraDocs];
      updated[index].file = file;
      updated[index].preview = URL.createObjectURL(file);
      setExtraDocs(updated);
    }
  };
  const addNewDocField = () => {
    setExtraDocs(
      [
        ...extraDocs,
        { document_name: "", file: null, preview: "" }
      ]
    );
  };
  const removeDocField = (index) => {
    const updated = extraDocs.filter((_, i) => i !== index);
    setExtraDocs(updated);
    setFormData({ ...formData, guarantor_all_document: updated });
  };
  useEffect(() => {
    const fetchEnrollmentData = async () => {
      setIsLoading(true);
      try {
        const response = await api.get(`/enroll-report/get-enroll-report`);
        if (response.data) {
          setEnrollment(response.data);
        }
      } catch (error) {
        console.error("Error fetching Enrollment data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchEnrollmentData();
  }, []);
  useEffect(() => {
    const fetchGuarantor = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/guarantor/get-guarantor-info");
        console.info("guarantor", response.data);
        const guarantors = response.data?.guarantor || [];
        console.info("guarantor", response.data);
        setGuarantor(guarantors);
        const formattedData = guarantors.map((group, index) => {
          const enrollmentDetails = (group?.enrollment_ids || []).map(
            (enroll) => {
              const groupName = enroll?.group_id?.group_name || "N/A";
              const ticket = enroll?.tickets || "N/A";
              return `${groupName} | Ticket: ${ticket}`;
            }
          );
          const guarantor2 = users.find((u) => u._id === group?.user_guarantor);
          console.info("test-test", guarantor2);
          const guarantorName = group?.guarantor_referred_type === "Customer" ? guarantor2?.full_name || "N/A" : group?.guarantor_name;
          const guarantorPhone = group?.guarantor_referred_type === "Customer" ? guarantor2?.phone_number || "N/A" : group?.guarantor_phone_number;
          return {
            _id: group?._id,
            id: index + 1,
            guarantor_code: group?.guarantor_code,
            user_id: group?.user_id?.full_name,
            enrollment_summary: enrollmentDetails.join(", "),
            guarantor_referred_type: group?.guarantor_referred_type,
            guarantor_name: guarantorName,
            guarantor_phone_number: guarantorPhone,
            guarantor_description: group?.guarantor_description,
            action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
              Dropdown,
              {
                trigger: ["click"],
                menu: {
                  items: [
                    {
                      key: "1",
                      label: /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: "text-green-600",
                          onClick: () => handleUpdateModalOpen(group?._id),
                          children: "Edit"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 278,
                          columnNumber: 21
                        },
                        this
                      )
                    },
                    {
                      key: "2",
                      label: /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: "text-red-600",
                          onClick: () => handleDeleteModalOpen(group?._id),
                          children: "Delete"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 289,
                          columnNumber: 21
                        },
                        this
                      )
                    },
                    {
                      key: "3",
                      label: /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          onClick: () => handleGuarantorPrint(group?._id),
                          className: " text-violet-600 ",
                          children: "Print"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 300,
                          columnNumber: 21
                        },
                        this
                      )
                    }
                  ]
                },
                placement: "bottomLeft",
                children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 312,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 271,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
              lineNumber: 270,
              columnNumber: 13
            }, this)
          };
        });
        let fData = formattedData.map((ele) => {
          if (ele?.guarantor_address && typeof ele.guarantor_address === "string" && ele?.guarantor_address?.includes(","))
            ele.guarantor_address = ele.guarantor_address.replaceAll(",", " ");
          return ele;
        });
        if (!fData) setTableGuarantor(formattedData);
        if (!fData) setTableGuarantor(formattedData);
        setTableGuarantor(fData);
      } catch (error) {
        console.error("Error fetching Guarantor data:", error.message);
      } finally {
        setIsLoading(false);
      }
    };
    fetchGuarantor();
  }, [reloadTrigger]);
  const handleAntDSelect = (field, value) => {
    setFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    if (value !== "Other") {
      setCustomRelationship("");
    }
    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: ""
    }));
  };
  const handleAntInputDSelect = (field, value) => {
    setUpdateFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors({ ...errors, [field]: "" });
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [name]: ""
    }));
  };
  const validateForm = (type) => {
    const newErrors = {};
    const data = type === "addGuarantor" ? formData : updateFormData;
    const regex = {
      email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
      phone: /^[6-9]\d{9}$/,
      pincode: /^\d{6}$/,
      adhaar: /^\d{12}$/,
      pan: /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/
    };
    const validateFile = (file, name) => {
      if (!file) {
        return `${name} is required`;
      }
      const allowedTypes = ["image/jpeg", "image/png", "image/jpg"];
      if (file instanceof File) {
        if (!allowedTypes.includes(file.type)) {
          return "Only JPG and PNG files are allowed";
        }
        if (file.size > 2 * 1024 * 1024) {
          return "File size must be less than 2MB";
        }
      } else if (typeof file === "string" && file.trim() === "") {
        return `${name} is required`;
      }
      return null;
    };
    if (!data.user_id) newErrors.user_id = "Customer Name is required";
    if (!data.guarantor_referred_type) newErrors.guarantor_referred_type = "Referred Type is required";
    if (!data.enrollment_ids || data.enrollment_ids.length === 0) newErrors.enrollment_ids = "Enrollment is required";
    if (data.guarantor_referred_type === "Customer") {
      if (!data.user_guarantor) newErrors.user_guarantor = "Referred Customer is required";
      if (!data.guarantor_description?.trim()) newErrors.guarantor_description = "Description is required";
    } else if (data.guarantor_referred_type === "Property") {
      if (!data.guarantor_description?.trim()) newErrors.guarantor_description = "Description is required";
      if (!data.guarantor_document_name?.trim()) newErrors.guarantor_document_name = "Document Name is required";
      let fileError = validateFile(data.guarantor_document, "Property Document Photo");
      if (fileError) newErrors.guarantor_document = fileError;
    } else if (data.guarantor_referred_type === "Third Party") {
      if (!data.guarantor_name?.trim()) newErrors.guarantor_name = "Guarantor Name is required";
      if (!data.guarantor_relationship_type?.trim()) newErrors.guarantor_relationship_type = "Guarantor Relationship is required";
      if (!data.guarantor_phone_number || !regex.phone.test(data.guarantor_phone_number)) {
        newErrors.guarantor_phone_number = "Invalid Phone Number";
      }
      if (!data.guarantor_email || !regex.email.test(data.guarantor_email)) {
        newErrors.guarantor_email = "Invalid Email";
      }
      if (!data.guarantor_address?.trim()) newErrors.guarantor_address = "Address is required";
      if (!data.guarantor_pincode || !regex.pincode.test(data.guarantor_pincode)) {
        newErrors.guarantor_pincode = "Invalid Pincode";
      }
      if (!data.guarantor_adhaar_no || !regex.adhaar.test(data.guarantor_adhaar_no)) {
        newErrors.guarantor_adhaar_no = "Invalid Aadhaar Number";
      }
      if (!data.guarantor_pan_no || !regex.pan.test(data.guarantor_pan_no)) {
        newErrors.guarantor_pan_no = "Invalid PAN Capital Alphabet with Number";
      }
      let fileError = validateFile(data.guarantor_photo, "Profile Photo");
      if (fileError) newErrors.guarantor_photo = fileError;
      fileError = validateFile(data.guarantor_pan_document, "PAN Card Photo");
      if (fileError) newErrors.guarantor_pan_document = fileError;
      fileError = validateFile(data.guarantor_aadhar_document, "Aadhaar Card Photo");
      if (fileError) newErrors.guarantor_aadhar_document = fileError;
      if (!data.guarantor_occupation) newErrors.guarantor_occupation = "Occupation is required";
      switch (data.guarantor_occupation) {
        case "Self Employed":
        case "Salaried":
          if (!data.guarantor_bussiness_type?.trim()) newErrors.guarantor_bussiness_type = "Business Type is required";
          if (!data.guarantor_bussiness_name?.trim()) newErrors.guarantor_bussiness_name = "Business Name is required";
          if (!data.guarantor_bussiness_address?.trim()) newErrors.guarantor_bussiness_address = "Business Address is required";
          break;
        case "Professional":
          if (!data.guarantor_profession_type?.trim()) newErrors.guarantor_profession_type = "Profession Type is required";
          if (!data.guarantor_bussiness_address?.trim()) newErrors.guarantor_bussiness_address = "Business Address is required";
          break;
        case "Agri Allied":
          if (!data.guarantor_agri_rtc_no?.trim()) newErrors.guarantor_agri_rtc_no = "RTC Number is required";
          if (!data.guarantor_land_holdings) newErrors.guarantor_land_holdings = "Land Holdings is required";
          if (!data.guarantor_bussiness_address?.trim()) newErrors.guarantor_bussiness_address = "Business Address is required";
          break;
        case "Other":
          if (!data.guarantor_occupation_sub?.trim()) newErrors.guarantor_occupation_sub = "Occupation Sub-category is required";
          if (data.guarantor_occupation_sub === "Running an unregistered Business" && !data.guarantor_bussiness_address?.trim()) {
            newErrors.guarantor_bussiness_address = "Address is required for this occupation";
          }
          break;
        default:
          break;
      }
      fileError = validateFile(data.guarantor_income_document, "Income Document Photo");
      if (fileError) newErrors.guarantor_income_document = fileError;
      if (!data.guarantor_bank_name?.trim()) newErrors.guarantor_bank_name = "Bank Name is required";
      if (!data.guarantor_bank_account_number?.trim()) newErrors.guarantor_bank_account_number = "Bank Account Number is required";
      if (!data.guarantor_bank_branch?.trim()) newErrors.guarantor_bank_branch = "Bank Branch is required";
      if (!data.guarantor_bank_ifsc_code?.trim()) newErrors.guarantor_bank_ifsc_code = "Bank IFSC Code is required";
      fileError = validateFile(data.guarantor_bank_passbook_photo, "Bank Passbook Photo");
      if (fileError) newErrors.guarantor_bank_passbook_photo = fileError;
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isvalid = validateForm("addGuarantor");
    if (isvalid) {
      try {
        const fmData = new FormData();
        Object.entries(formData).forEach(([key, value]) => {
          if (value instanceof File) {
            fmData.append(key, value);
          } else if (Array.isArray(value)) {
            value.forEach((v) => fmData.append(`${key}[]`, v));
          } else if (value) {
            fmData.append(key, value);
          }
        });
        extraDocs.forEach((doc, i) => {
          if (doc.file) {
            fmData.append("guarantor_all_document", doc.file);
            fmData.append(
              "document_name[]",
              doc.document_name || `Document_${i + 1}`
            );
          }
        });
        const response = await api.post(
          "/guarantor/add-guarantor-info",
          //formData,
          fmData,
          {
            headers: {
              "Content-Type": "multipart/form-data"
            }
          }
        );
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          type: "success",
          message: "Guarantor Added Successfully",
          visibility: true
        });
        setShowModal(false);
        setFormData({
          user_id: "",
          guarantor_name: "",
          guarantor_email: "",
          user_guarantor: "",
          guarantor_phone_number: "",
          guarantor_address: "",
          guarantor_pincode: "",
          guarantor_adhaar_no: "",
          guarantor_pan_no: "",
          guarantor_gender: "",
          guarantor_marital_status: "",
          guarantor_dateofbirth: "",
          guarantor_nationality: "",
          guarantor_village: "",
          guarantor_taluk: "",
          guarantor_father_name: "",
          guarantor_district: "",
          guarantor_state: "",
          guarantor_description: "",
          enrollment_ids: [],
          guarantor_alternate_number: "",
          guarantor_referred_type: "",
          guarantor_document: "",
          guarantor_document_name: "",
          guarantor_photo: "",
          guarantor_pan_document: "",
          guarantor_aadhar_document: "",
          guarantor_relationship_type: "",
          guarantor_occupation: "",
          guarantor_income: "",
          guarantor_consent_document: "",
          guarantor_bank_name: "",
          guarantor_bank_account_number: "",
          guarantor_bank_branch: "",
          guarantor_bank_ifsc_code: "",
          guarantor_bank_passbook_photo: "",
          guarantor_sector_name: "",
          guarantor_income_document: "",
          guarantor_bussiness_type: "",
          guarantor_bussiness_name: "",
          guarantor_bussiness_address: "",
          guarantor_profession_type: "",
          guarantor_agri_rtc_no: "",
          guarantor_land_holdings: "",
          guarantor_occupation_sub: "",
          guarantor_all_document_name: "",
          guarantor_all_document: ""
        });
      } catch (error) {
        console.error("Error adding Guarantor:", error);
        setAlertConfig({
          type: "error",
          message: error?.response?.data?.message || "An unexpected error occurred.",
          visibility: true
        });
      }
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      const fmData = new FormData();
      const { guarantor_all_document, ...rest } = updateFormData;
      Object.entries(rest).forEach(([key, value]) => {
        if (value) fmData.append(key, value);
      });
      const singleFileFields = [
        "guarantor_photo",
        "guarantor_aadhar_document",
        "guarantor_pan_document",
        "guarantor_income_document",
        "guarantor_bank_passbook_photo",
        "guarantor_document"
      ];
      singleFileFields.forEach((field) => {
        if (updateFormData[field] instanceof File) {
          fmData.append(field, updateFormData[field]);
        }
      });
      if (extraDocs && Array.isArray(extraDocs)) {
        extraDocs.forEach((doc, i) => {
          if (doc.file instanceof File) {
            fmData.append("guarantor_all_document", doc.file);
            fmData.append(
              "document_name[]",
              // ✅ send as array
              doc.document_name || `Document_${i + 1}`
            );
          }
        });
      }
      await api.put(
        `/guarantor/update-guarantor-info/${currentUpdateGuarantor?._id}`,
        fmData,
        { headers: { "Content-Type": "multipart/form-data" } }
      );
      setShowModalUpdate(false);
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        type: "success",
        message: "Guarantor Updated Successfully",
        visibility: true
      });
    } catch (error) {
      console.error("Error updating Guarantor:", error);
      setAlertConfig({
        type: "error",
        message: error?.response?.data?.message || "Update failed",
        visibility: true
      });
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "user_id", header: "Customer Name" },
    { key: "guarantor_code", header: "Guarantor Code" },
    { key: "guarantor_referred_type", header: "Referred Type" },
    { key: "enrollment_summary", header: "Enrollment Details" },
    { key: "guarantor_name", header: "Guarantor Name" },
    { key: "guarantor_phone_number", header: "Guarantor Phone Number" },
    // { key: "guarantor_address", header: "Guarantor Address" },
    // { key: "guarantor_pincode", header: "Guarantor Pincode" },
    // { key: "guarantor_description", header: "Guarantor Description" },
    { key: "action", header: "Action" }
  ];
  const filteredGuarantor = users.filter(
    (users2) => users2.full_name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const handleDeleteModalOpen = async (userId) => {
    try {
      const response = await api.get(
        `/guarantor/get-guarantor-info-by-id/${userId}`
      );
      setCurrentGuarantor(response.data?.guarantor);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching Guarantor:", error);
    }
  };
  const handleFileChange = (e) => {
    const { name, files } = e.target;
    const file = files[0];
    if (file) {
      setFormData((prev) => ({
        ...prev,
        [name]: file,
        // ✅ keep real file object
        [`${name}_preview`]: URL.createObjectURL(file)
        // for preview
      }));
    }
  };
  const handleUpdateModalOpen = async (userId) => {
    try {
      const response = await api.get(
        `/guarantor/get-guarantor-info-by-id/${userId}`
      );
      const guarantor2 = response?.data?.guarantor;
      const matchedEnrollments = (guarantor2?.enrollment_ids || []).map((e) => ({
        _id: e._id,
        group_name: e?.group_id?.group_name || "N/A",
        ticket: e?.tickets || "N/A"
      }));
      setFilteredEnrollments(matchedEnrollments);
      setUpdateFormData({
        user_id: guarantor2?.user_id?._id || "",
        enrollment_ids: guarantor2?.enrollment_ids?.map((e) => e._id) || [],
        guarantor_name: guarantor2?.guarantor_name || "",
        guarantor_email: guarantor2?.guarantor_email || "",
        guarantor_phone_number: guarantor2?.guarantor_phone_number || "",
        user_guarantor: guarantor2?.user_guarantor || "",
        guarantor_address: guarantor2?.guarantor_address || "",
        guarantor_pincode: guarantor2?.guarantor_pincode || "",
        guarantor_adhaar_no: guarantor2?.guarantor_adhaar_no || "",
        guarantor_pan_no: guarantor2?.guarantor_pan_no || "",
        guarantor_gender: guarantor2?.guarantor_gender || "",
        guarantor_marital_status: guarantor2?.guarantor_marital_status || "",
        guarantor_dateofbirth: guarantor2?.guarantor_dateofbirth || "",
        guarantor_nationality: guarantor2?.guarantor_nationality || "",
        guarantor_village: guarantor2?.guarantor_village || "",
        guarantor_taluk: guarantor2?.guarantor_taluk || "",
        guarantor_father_name: guarantor2?.guarantor_father_name || "",
        guarantor_district: guarantor2?.guarantor_district || "",
        guarantor_state: guarantor2?.guarantor_state || "",
        guarantor_description: guarantor2?.guarantor_description || "",
        guarantor_alternate_number: guarantor2?.guarantor_alternate_number,
        guarantor_document: guarantor2?.guarantor_document || "",
        guarantor_document_name: guarantor2?.guarantor_document_name || "",
        guarantor_referred_type: guarantor2?.guarantor_referred_type || "",
        guarantor_photo: guarantor2?.guarantor_photo || "",
        guarantor_pan_document: guarantor2?.guarantor_pan_document || "",
        guarantor_aadhar_document: guarantor2?.guarantor_aadhar_document || "",
        guarantor_relationship_type: guarantor2?.guarantor_relationship_type || "",
        guarantor_occupation: guarantor2?.guarantor_occupation || "",
        guarantor_income: guarantor2?.guarantor_income || "",
        guarantor_consent_document: guarantor2?.guarantor_consent_document || "",
        guarantor_bank_name: guarantor2?.guarantor_bank_name || "",
        guarantor_bank_account_number: guarantor2?.guarantor_bank_account_number || "",
        guarantor_bank_branch: guarantor2?.guarantor_bank_branch || "",
        guarantor_bank_ifsc_code: guarantor2?.guarantor_bank_ifsc_code || "",
        guarantor_bank_passbook_photo: guarantor2?.guarantor_bank_passbook_photo || "",
        guarantor_income_document: guarantor2.guarantor_income_document || "",
        guarantor_bussiness_type: guarantor2.guarantor_bussiness_type || "",
        guarantor_bussiness_name: guarantor2.guarantor_bussiness_name || "",
        guarantor_bussiness_address: guarantor2?.guarantor_bussiness_address || "",
        guarantor_profession_type: guarantor2?.guarantor_profession_type || "",
        guarantor_agri_rtc_no: guarantor2?.guarantor_agri_rtc_no || "",
        guarantor_land_holdings: guarantor2?.guarantor_land_holdings || "",
        guarantor_occupation_sub: guarantor2?.guarantor_occupation_sub || "",
        guarantor_all_document_name: guarantor2?.guarantor_all_document_name || "",
        guarantor_all_document: guarantor2?.guarantor_all_document || ""
      });
      setExtraDocs(
        (guarantor2?.guarantor_all_document || []).map((d) => ({
          document_name: d.document_name,
          file: null,
          // no new file yet
          preview: d.document_url,
          // show existing file preview
          existingUrl: d.document_url
          // keep original in case user doesn’t replace
        }))
      );
      setCurrentUpdateGuarantor(guarantor2);
      setShowModalUpdate(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching Guarantor:", error);
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevData) => ({
      ...prevData,
      [name]: ""
    }));
  };
  const handleDeleteGuarantor = async () => {
    if (currentGuarantor) {
      try {
        await api.delete(
          `/guarantor/delete-guarantor-info-by-id/${currentGuarantor._id}`
        );
        setAlertConfig({
          visibility: true,
          message: "guarantor deleted successfully",
          type: "success"
        });
        setReloadTrigger((prev) => prev + 1);
        setShowModalDelete(false);
        setCurrentGuarantor(null);
      } catch (error) {
        console.error("Error deleting Guarantor:", error);
      }
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
        lineNumber: 1124,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: GlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
          lineNumber: 1125,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
          lineNumber: 1129,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
          /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
            lineNumber: 1140,
            columnNumber: 18
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Guarantor" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
              lineNumber: 1143,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setShowModal(true);
                  setErrors({});
                },
                className: "ml-4 bg-violet-950 text-white px-4 py-2 rounded shadow-md hover:bg-violet-800 transition duration-200",
                children: "+ Add Guarantor"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 1145,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
            lineNumber: 1141,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
          lineNumber: 1139,
          columnNumber: 13
        }, this),
        TableGuarantor?.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            catcher: "_id",
            updateHandler: handleUpdateModalOpen,
            data: filterOption(TableGuarantor, searchText),
            columns,
            exportedPdfName: "Guarantor",
            exportedFileName: `Guarantor.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
            lineNumber: 1157,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: TableGuarantor.length <= 0,
            data: "Guarantor Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
            lineNumber: 1166,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
        lineNumber: 1138,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
      lineNumber: 1123,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Guarantor" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
        lineNumber: 1176,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(
        "form",
        {
          className: "space-y-6",
          method: "POST",
          onSubmit: handleSubmit,
          enctype: "multipart/form-data",
          noValidate: true,
          children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Customer Name ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1188,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 1187,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                  placeholder: "Select Or Search Customer",
                  showSearch: true,
                  value: formData.user_id || void 0,
                  onChange: (value) => {
                    setFormData((prev) => ({
                      ...prev,
                      user_id: value,
                      enrollment_ids: []
                    }));
                    const filtered = enrollment.filter((e) => e.user_id?._id === value).map((e) => ({
                      _id: e._id,
                      group_name: e.group_id?.group_name,
                      ticket: e.tickets
                    }));
                    setFilteredEnrollments(filtered);
                  },
                  filterOption: (input, option) => option?.children?.toLowerCase().includes(input.toLowerCase()),
                  children: Array.from(
                    new Map(
                      enrollment.filter((e) => e.user_id && e.user_id.full_name?.trim()).map((e) => [e.user_id._id, e.user_id])
                    ).values()
                  ).map(
                    (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: user.full_name }, user._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1225,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1190,
                  columnNumber: 17
                },
                this
              ),
              errors.user_id && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.user_id }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 1231,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
              lineNumber: 1186,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Select Enrollment ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1236,
                  columnNumber: 37
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 1235,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  mode: "tags",
                  allowClear: true,
                  placeholder: "Select enrollments",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                  value: formData.enrollment_ids,
                  onChange: (selectedEnrollmentIds) => {
                    setFormData((prev) => ({
                      ...prev,
                      enrollment_ids: selectedEnrollmentIds
                    }));
                  },
                  filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
                  children: filteredEnrollments.map((en) => {
                    const parts = [];
                    if (en.group_name && en.group_name !== "N/A")
                      parts.push(en.group_name);
                    if (en.ticket && en.ticket !== "N/A")
                      parts.push(`Ticket: ${en.ticket}`);
                    return /* @__PURE__ */ jsxDEV(Select.Option, { value: en._id, children: parts.join(" | ") }, en._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1261,
                      columnNumber: 23
                    }, this);
                  })
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1238,
                  columnNumber: 17
                },
                this
              ),
              errors.enrollment_ids && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.enrollment_ids }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 1269,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
              lineNumber: 1234,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "referred_type",
                  children: [
                    "Select Referred Type ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1280,
                      columnNumber: 40
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1276,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                  placeholder: "Select Referred Type",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "guarantor_referred_type",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: formData?.guarantor_referred_type || void 0,
                  onChange: (value) => handleAntDSelect("guarantor_referred_type", value),
                  children: ["Customer", "Third Party", "Property"].map(
                    (refType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: refType, children: refType }, refType, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1297,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1282,
                  columnNumber: 17
                },
                this
              ),
              errors.guarantor_referred_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_referred_type }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 1303,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
              lineNumber: 1275,
              columnNumber: 15
            }, this),
            formData.guarantor_referred_type === "Customer" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-full mb-4", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "category",
                    children: [
                      "Select Guarantor Customer",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1317,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1312,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                    placeholder: "Select Or Search Referred Guarantor",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "user_guarantor",
                    filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                    value: formData?.user_guarantor || void 0,
                    onChange: (value) => handleAntDSelect("user_guarantor", value),
                    children: users.map(
                      (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: user.full_name }, user._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1338,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1320,
                    columnNumber: 21
                  },
                  this
                ),
                errors.user_guarantor && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.user_guarantor }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1344,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 1311,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "desc",
                    children: [
                      "Description ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1354,
                        columnNumber: 35
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1350,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "guarantor_description",
                    value: formData.guarantor_description,
                    onChange: handleChange,
                    id: "name",
                    placeholder: "Enter the Description",
                    required: true,
                    className: `bg-gray-50 border ${fieldSize.height} border-gray-300 text-gray-900 text-sm rounded-lg w-full`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1356,
                    columnNumber: 21
                  },
                  this
                ),
                errors.guarantor_description && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_description }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1367,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 1349,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
              lineNumber: 1310,
              columnNumber: 15
            }, this),
            formData.guarantor_referred_type === "Third Party" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 mt-6", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-300 rounded-lg p-6 bg-white shadow-md", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold text-gray-800 text-center mb-6", children: "Personal Information" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1378,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Guarantor Name ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1386,
                        columnNumber: 42
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1385,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_name",
                        value: formData.guarantor_name,
                        onChange: handleChange,
                        placeholder: "Enter Guarantor Name",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1388,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_name }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1398,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1384,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Phone Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1405,
                        columnNumber: 40
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1404,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_phone_number",
                        value: formData.guarantor_phone_number,
                        onChange: handleChange,
                        placeholder: "Enter Phone Number",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1407,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_phone_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_phone_number }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1417,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1403,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1383,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Select Customer Relationship" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1427,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select Customer Relationship",
                        showSearch: true,
                        name: "guarantor_relationship_type",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: formData.guarantor_relationship_type || void 0,
                        onChange: (value) => handleAntDSelect(
                          "guarantor_relationship_type",
                          value
                        ),
                        children: ["Father", "Spouse", "Other"].map(
                          (rel) => /* @__PURE__ */ jsxDEV(Select.Option, { value: rel, children: rel }, rel, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                            lineNumber: 1451,
                            columnNumber: 25
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1430,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_relationship_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_relationship_type }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1457,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1426,
                    columnNumber: 23
                  }, this),
                  formData.guarantor_relationship_type === "Other" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Please specify the relationship:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1465,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full p-2.5",
                        placeholder: "Enter custom relationship",
                        value: customRelationship,
                        onChange: (e) => setCustomRelationship(e.target.value)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1468,
                        columnNumber: 27
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1464,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1425,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Email" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1484,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "email",
                        name: "guarantor_email",
                        value: formData.guarantor_email,
                        onChange: handleChange,
                        placeholder: "Enter Email",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1487,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_email && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_email }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1497,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1483,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Date of Birth" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1503,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "date",
                        name: "guarantor_dateofbirth",
                        value: formData.guarantor_dateofbirth ? new Date(formData.guarantor_dateofbirth).toISOString().split("T")[0] : "",
                        onChange: handleChange,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1506,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1502,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1482,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Marital Status" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1525,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select Marital Status",
                        showSearch: true,
                        name: "guarantor_marital_status",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: formData.guarantor_marital_status || void 0,
                        onChange: (value) => handleAntDSelect("guarantor_marital_status", value),
                        children: ["Married", "Unmarried", "Widow", "Divorced"].map(
                          (status) => /* @__PURE__ */ jsxDEV(Select.Option, { value: status, children: status }, status, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                            lineNumber: 1545,
                            columnNumber: 27
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1528,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1524,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Gender" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1553,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select Gender",
                        showSearch: true,
                        name: "guarantor_gender",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: formData.guarantor_gender || void 0,
                        onChange: (value) => handleAntDSelect("guarantor_gender", value),
                        children: ["Male", "Female"].map(
                          (g) => /* @__PURE__ */ jsxDEV(Select.Option, { value: g, children: g }, g, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                            lineNumber: 1572,
                            columnNumber: 25
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1556,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1552,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1523,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                    "Address ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1583,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1582,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      name: "guarantor_address",
                      value: formData.guarantor_address,
                      onChange: handleChange,
                      placeholder: "Enter the Address",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1585,
                      columnNumber: 23
                    },
                    this
                  ),
                  errors.guarantor_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_address }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1595,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1581,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Village" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1604,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_village",
                        value: formData.guarantor_village,
                        onChange: handleChange,
                        placeholder: "Enter Village",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1607,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1603,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Taluk" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1617,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_taluk",
                        value: formData.guarantor_taluk,
                        onChange: handleChange,
                        placeholder: "Enter Taluk",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1620,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1616,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1602,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "State" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1634,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select State",
                        showSearch: true,
                        name: "guarantor_state",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: formData.guarantor_state || void 0,
                        onChange: (value) => handleAntDSelect("guarantor_state", value),
                        children: ["Karnataka", "Maharashtra", "Tamil Nadu"].map(
                          (state) => /* @__PURE__ */ jsxDEV(Select.Option, { value: state, children: state }, state, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                            lineNumber: 1654,
                            columnNumber: 27
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1637,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1633,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "District" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1662,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_district",
                        value: formData.guarantor_district,
                        onChange: handleChange,
                        placeholder: "Enter District",
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1665,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1661,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1632,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Pincode ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1680,
                        columnNumber: 35
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1679,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_pincode",
                        value: formData.guarantor_pincode,
                        onChange: handleChange,
                        placeholder: "Enter Pincode",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1682,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_pincode && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_pincode }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1692,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1678,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Father Name" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1698,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_father_name",
                        value: formData.guarantor_father_name,
                        onChange: handleChange,
                        placeholder: "Enter Father Name",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1701,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1697,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1677,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Nationality" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1715,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select Nationality",
                        showSearch: true,
                        name: "guarantor_nationality",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: formData.guarantor_nationality || void 0,
                        onChange: (value) => handleAntDSelect("guarantor_nationality", value),
                        children: ["Indian", "Other"].map(
                          (nation) => /* @__PURE__ */ jsxDEV(Select.Option, { value: nation, children: nation }, nation, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                            lineNumber: 1734,
                            columnNumber: 25
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1718,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1714,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Alternate Phone Number" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1741,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_alternate_number",
                        value: formData.guarantor_alternate_number,
                        onChange: handleChange,
                        placeholder: "Enter Alternate Number",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1744,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1740,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1713,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 1377,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-300 rounded-lg p-6 bg-white shadow-md", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold text-gray-800 text-center mb-6", children: "KYC Documents" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1758,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Aadhaar Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1766,
                        columnNumber: 42
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1765,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_adhaar_no",
                        value: formData.guarantor_adhaar_no,
                        onChange: handleChange,
                        placeholder: "Enter Aadhaar Number",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1768,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_adhaar_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_adhaar_no }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1778,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1764,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "PAN Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1785,
                        columnNumber: 38
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1784,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_pan_no",
                        value: formData.guarantor_pan_no,
                        onChange: handleChange,
                        placeholder: "Enter PAN Number",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1787,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_pan_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_pan_no }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1797,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1783,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1763,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                    "Profile Photo ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1807,
                      columnNumber: 39
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1806,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "file",
                      name: "guarantor_photo",
                      onChange: handleFileChange,
                      accept: "image/*",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1809,
                      columnNumber: 23
                    },
                    this
                  ),
                  errors.guarantor_photo && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_photo }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1818,
                    columnNumber: 21
                  }, this),
                  formData.guarantor_photo && /* @__PURE__ */ jsxDEV(Link, { to: formData.guarantor_photo, download: true, children: /* @__PURE__ */ jsxDEV(
                    "img",
                    {
                      src: formData.guarantor_photo_preview,
                      alt: "Profile",
                      className: "w-56 h-56 object-cover mt-4 rounded-md shadow"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1824,
                      columnNumber: 27
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1823,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1805,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-6", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "PAN Card Photo ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1838,
                        columnNumber: 42
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1837,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "file",
                        name: "guarantor_pan_document",
                        onChange: handleFileChange,
                        accept: "image/*",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1840,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_pan_document && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_pan_document }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1849,
                      columnNumber: 23
                    }, this),
                    formData.guarantor_pan_document && /* @__PURE__ */ jsxDEV(Link, { to: formData.guarantor_pan_document, download: true, children: /* @__PURE__ */ jsxDEV(
                      "img",
                      {
                        src: formData.guarantor_pan_document_preview,
                        alt: "PAN",
                        className: "w-56 h-56 object-cover mt-4 rounded-md shadow"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1855,
                        columnNumber: 29
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1854,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1836,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Aadhaar Card Photo",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1867,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1865,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "file",
                        name: "guarantor_aadhar_document",
                        onChange: handleFileChange,
                        accept: "image/*",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1869,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_aadhar_document && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_aadhar_document }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1878,
                      columnNumber: 23
                    }, this),
                    formData.guarantor_aadhar_document && /* @__PURE__ */ jsxDEV(
                      Link,
                      {
                        to: formData.guarantor_aadhar_document,
                        download: true,
                        children: /* @__PURE__ */ jsxDEV(
                          "img",
                          {
                            src: formData.guarantor_aadhar_document_preview,
                            alt: "",
                            className: "w-56 h-56 object-cover mt-4 rounded-md shadow"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                            lineNumber: 1887,
                            columnNumber: 29
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1883,
                        columnNumber: 23
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1864,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1835,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold mb-2", children: "Additional Documents" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1899,
                    columnNumber: 23
                  }, this),
                  extraDocs.map(
                    (doc, index) => /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "mb-6 p-3 border border-gray-200 rounded-lg bg-gray-50",
                        children: [
                          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-4", children: [
                            /* @__PURE__ */ jsxDEV(
                              Input,
                              {
                                type: "text",
                                placeholder: "Document Name (e.g. Passport, Voter ID)",
                                value: doc.document_name,
                                onChange: (e) => handleExtraDocNameChange(index, e),
                                className: "w-1/2 h-12 border border-gray-300 rounded-lg p-2"
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                                lineNumber: 1909,
                                columnNumber: 29
                              },
                              this
                            ),
                            /* @__PURE__ */ jsxDEV(
                              "input",
                              {
                                type: "file",
                                name: "guarantor_all_document",
                                onChange: (e) => handleExtraDocFileChange(index, e),
                                accept: "image/*",
                                className: "w-1/2 h-12 border border-gray-300 rounded-lg"
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                                lineNumber: 1918,
                                columnNumber: 29
                              },
                              this
                            ),
                            /* @__PURE__ */ jsxDEV(
                              "button",
                              {
                                type: "button",
                                onClick: () => removeDocField(index),
                                className: "text-violet-600 font-bold text-xl",
                                children: /* @__PURE__ */ jsxDEV(IoMdClose, {}, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                                  lineNumber: 1932,
                                  columnNumber: 31
                                }, this)
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                                lineNumber: 1927,
                                columnNumber: 29
                              },
                              this
                            )
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                            lineNumber: 1908,
                            columnNumber: 27
                          }, this),
                          doc.preview && /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: /* @__PURE__ */ jsxDEV(
                            "img",
                            {
                              src: doc.preview,
                              alt: doc.document_name,
                              className: "w-56 h-56 object-cover rounded-md shadow"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                              lineNumber: 1939,
                              columnNumber: 31
                            },
                            this
                          ) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                            lineNumber: 1938,
                            columnNumber: 23
                          }, this)
                        ]
                      },
                      index,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 1903,
                        columnNumber: 21
                      },
                      this
                    )
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: addNewDocField,
                      className: "mt-2 px-2 py-1 bg-violet-600 text-white rounded-lg shadow hover:bg-violet-700",
                      children: "+ Add Document"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1949,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1898,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 1757,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-300 rounded-lg p-6 bg-white shadow-md", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold text-gray-800 text-center mb-6", children: "Occupation Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1960,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Guarantor Occupation" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 1967,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                      placeholder: "Select Occupation",
                      showSearch: true,
                      value: formData.guarantor_occupation || void 0,
                      onChange: (value) => {
                        setFormData((prev) => ({
                          ...prev,
                          guarantor_occupation: value,
                          guarantor_occupation_sub: "",
                          guarantor_bussiness_type: "",
                          guarantor_bussiness_name: "",
                          guarantor_bussiness_address: "",
                          guarantor_profession_type: "",
                          guarantor_agri_rtc_no: "",
                          guarantor_land_holdings: ""
                        }));
                      },
                      filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                      children: [
                        "Self Employed",
                        "Salaried",
                        "Professional",
                        "Agri Allied",
                        "Other"
                      ].map(
                        (occ) => /* @__PURE__ */ jsxDEV(Select.Option, { value: occ, children: occ }, occ, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 2004,
                          columnNumber: 25
                        }, this)
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 1972,
                      columnNumber: 25
                    },
                    this
                  ),
                  errors.guarantor_occupation && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_occupation }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2010,
                    columnNumber: 23
                  }, this),
                  formData.guarantor_occupation === "Other" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "mt-4 w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Please specify Occupation:" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2018,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Select,
                        {
                          className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                          placeholder: "Select Sub-Category",
                          showSearch: true,
                          value: formData.guarantor_occupation_sub || void 0,
                          onChange: (value) => setFormData((prev) => ({
                            ...prev,
                            guarantor_occupation_sub: value
                          })),
                          filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                          children: [
                            "House Wife",
                            "Retired",
                            "Student",
                            "Investment",
                            "Running an unregistered Business"
                          ].map(
                            (sub) => /* @__PURE__ */ jsxDEV(Select.Option, { value: sub, children: sub }, sub, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                              lineNumber: 2047,
                              columnNumber: 29
                            }, this)
                          )
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 2021,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.guarantor_occupation_sub && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_occupation_sub }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2053,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2017,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Address" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2059,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "guarantor_bussiness_address",
                          value: formData.guarantor_bussiness_address,
                          onChange: handleChange,
                          placeholder: "Enter  Address",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 2062,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.guarantor_bussiness_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bussiness_address }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2071,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2058,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2016,
                    columnNumber: 23
                  }, this),
                  ["Self Employed", "Salaried"].includes(
                    formData.guarantor_occupation
                  ) && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 space-y-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Business Type" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2085,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "guarantor_bussiness_type",
                          value: formData.guarantor_bussiness_type,
                          onChange: handleChange,
                          placeholder: "e.g., Retail, Manufacturing",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 2088,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.guarantor_bussiness_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bussiness_type }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2097,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2084,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Business Name" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2103,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "guarantor_bussiness_name",
                          value: formData.guarantor_bussiness_name,
                          onChange: handleChange,
                          placeholder: "Enter Business Name",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 2106,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.guarantor_bussiness_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bussiness_name }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2115,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2102,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Address" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2121,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "guarantor_bussiness_address",
                          value: formData.guarantor_bussiness_address,
                          onChange: handleChange,
                          placeholder: "Enter Address",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 2124,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.guarantor_bussiness_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bussiness_address }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2133,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2120,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2083,
                    columnNumber: 23
                  }, this),
                  formData.guarantor_occupation === "Professional" && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 space-y-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Profession Type" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2145,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "guarantor_profession_type",
                          value: formData.guarantor_profession_type,
                          onChange: handleChange,
                          placeholder: "e.g., Doctor, CA, Engineer",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 2148,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.guarantor_profession_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_profession_type }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2157,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2144,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Address" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2163,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "guarantor_bussiness_address",
                          value: formData.guarantor_bussiness_address,
                          onChange: handleChange,
                          placeholder: "Clinic/Office Address",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 2166,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.guarantor_bussiness_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bussiness_address }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2175,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2162,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2143,
                    columnNumber: 23
                  }, this),
                  formData.guarantor_occupation === "Agri Allied" && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 w-full space-y-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "RTC No / Land Record ID" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2187,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "guarantor_agri_rtc_no",
                          value: formData.guarantor_agri_rtc_no,
                          onChange: handleChange,
                          placeholder: "Enter RTC Number",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 2190,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.guarantor_agri_rtc_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_agri_rtc_no }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2199,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2186,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Land Holdings (in acres)" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2205,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "number",
                          name: "guarantor_land_holdings",
                          value: formData.guarantor_land_holdings,
                          onChange: handleChange,
                          placeholder: "e.g., 5.5",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 2208,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.guarantor_land_holdings && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_land_holdings }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2217,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2204,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Address" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2223,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "guarantor_bussiness_address",
                          value: formData.guarantor_bussiness_address,
                          onChange: handleChange,
                          placeholder: "Farm or Operation Address",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 2226,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.guarantor_bussiness_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bussiness_address }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2235,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2222,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2185,
                    columnNumber: 23
                  }, this),
                  formData.guarantor_occupation === "Other" && formData.guarantor_occupation_sub === "Running an unregistered Business" && /* @__PURE__ */ jsxDEV("div", { className: " w-full mt-4", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Address" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2248,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_bussiness_address",
                        value: formData.guarantor_bussiness_address,
                        onChange: handleChange,
                        placeholder: "Enter Address",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2251,
                        columnNumber: 31
                      },
                      this
                    ),
                    errors.guarantor_bussiness_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bussiness_address }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2260,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2247,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1966,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 1964,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: [
                    "Salary/Income Document Photo ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2272,
                      columnNumber: 53
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2271,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "file",
                      name: "guarantor_income_document",
                      onChange: handleFileChange,
                      accept: "image/*",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 hover:bg-gray-100 focus:ring-violet-500 focus:border-violet-500"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2274,
                      columnNumber: 23
                    },
                    this
                  ),
                  errors.guarantor_income_document && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_income_document }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2283,
                    columnNumber: 21
                  }, this),
                  formData.guarantor_income_document && /* @__PURE__ */ jsxDEV(Link, { to: formData.guarantor_income_document, download: true, children: /* @__PURE__ */ jsxDEV(
                    "img",
                    {
                      src: formData.guarantor_income_document_preview,
                      alt: "Income Document",
                      className: "w-56 h-56 object-cover mt-4 rounded-md shadow-md border"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2289,
                      columnNumber: 27
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2288,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2270,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 1959,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-300 rounded-lg p-6 bg-white shadow-md", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold text-gray-800 text-center mb-6", children: "Bank Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2301,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Bank Name" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2307,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_bank_name",
                        value: formData.guarantor_bank_name,
                        onChange: handleChange,
                        placeholder: "Enter Bank Name",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2310,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_bank_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bank_name }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2319,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2306,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Bank Account Number" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2325,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_bank_account_number",
                        value: formData.guarantor_bank_account_number,
                        onChange: handleChange,
                        placeholder: "Enter Account Number",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2328,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_bank_account_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bank_account_number }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2337,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2324,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2305,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Bank Branch" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2346,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_bank_branch",
                        value: formData.guarantor_bank_branch,
                        onChange: handleChange,
                        placeholder: "Enter Branch",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2349,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_bank_branch && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bank_branch }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2358,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2345,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Bank IFSC Code" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2364,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_bank_ifsc_code",
                        value: formData.guarantor_bank_ifsc_code,
                        onChange: handleChange,
                        placeholder: "Enter IFSC Code",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2367,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_bank_ifsc_code && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bank_ifsc_code }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2376,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2363,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2344,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                    "Bank Passbook ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2385,
                      columnNumber: 39
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2384,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "file",
                      name: "guarantor_bank_passbook_photo",
                      onChange: handleFileChange,
                      accept: "image/*",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2387,
                      columnNumber: 23
                    },
                    this
                  ),
                  errors.guarantor_bank_passbook_photo && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bank_passbook_photo }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2396,
                    columnNumber: 21
                  }, this),
                  formData.guarantor_bank_passbook_photo && /* @__PURE__ */ jsxDEV(
                    Link,
                    {
                      to: formData.guarantor_bank_passbook_photo,
                      download: true,
                      children: /* @__PURE__ */ jsxDEV(
                        "img",
                        {
                          src: formData.guarantor_bank_passbook_photo_preview,
                          alt: "Passbook",
                          className: "w-56 h-56 object-cover mt-4 rounded-md shadow"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 2405,
                          columnNumber: 27
                        },
                        this
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2401,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2383,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 2300,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
              lineNumber: 1375,
              columnNumber: 15
            }, this),
            formData.guarantor_referred_type === "Property" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "email",
                    children: [
                      "Property Name ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2423,
                        columnNumber: 37
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2419,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "guarantor_document_name",
                    value: formData.guarantor_document_name,
                    onChange: handleChange,
                    id: "name",
                    placeholder: "Enter the Description",
                    required: true,
                    className: `bg-gray-50 border ${fieldSize.height} border-gray-300 text-gray-900 text-sm rounded-lg w-full`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2425,
                    columnNumber: 21
                  },
                  this
                ),
                errors.guarantor_document_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_document_name }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2436,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 2418,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "guarantor_document",
                    children: [
                      "Property Document ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2446,
                        columnNumber: 41
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2442,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "file",
                    name: "guarantor_document",
                    onChange: handleFileChange,
                    id: "guarantor_document",
                    accept: "image/*",
                    placeholder: "Upload Document",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2448,
                    columnNumber: 21
                  },
                  this
                ),
                errors.guarantor_document && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_document }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2460,
                  columnNumber: 19
                }, this),
                formData.guarantor_document && /* @__PURE__ */ jsxDEV(Link, { to: formData.guarantor_document, download: true, children: /* @__PURE__ */ jsxDEV(
                  "img",
                  {
                    src: formData.guarantor_document_preview,
                    alt: "Property",
                    className: "w-56 h-56 object-cover mt-4 rounded-md shadow"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2466,
                    columnNumber: 27
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2465,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 2441,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "email",
                    children: [
                      "Description ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2479,
                        columnNumber: 35
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2475,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "guarantor_description",
                    value: formData.guarantor_description,
                    onChange: handleChange,
                    id: "name",
                    placeholder: "Enter the Description",
                    required: true,
                    className: `bg-gray-50 border ${fieldSize.height} border-gray-300 text-gray-900 text-sm rounded-lg w-full`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2481,
                    columnNumber: 21
                  },
                  this
                ),
                errors.guarantor_description && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_description }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2492,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 2474,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
              lineNumber: 2417,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Save Guarantor"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 2501,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
              lineNumber: 2500,
              columnNumber: 15
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
          lineNumber: 1179,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
      lineNumber: 1175,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
      lineNumber: 1174,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Guarantor" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
            lineNumber: 2517,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Customer Name ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2523,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 2522,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                  placeholder: "Select Or Search Customer",
                  showSearch: true,
                  value: updateFormData.user_id || "",
                  onChange: (value) => {
                    setUpdateFormData((prev) => ({
                      ...prev,
                      user_id: value,
                      enrollment_ids: []
                      // reset selected enrollments
                    }));
                    const filtered = enrollment.filter((e) => e.user_id?._id === value).map((e) => ({
                      _id: e._id,
                      group_name: e.group_id?.group_name,
                      ticket: e.tickets
                    }));
                    setFilteredEnrollments(filtered);
                  },
                  filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
                  children: enrollment.filter((e) => e.user_id && e.user_id.full_name?.trim()).map(
                    (e) => /* @__PURE__ */ jsxDEV(Select.Option, { value: e.user_id._id, children: e.user_id.full_name }, e.user_id._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2554,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2525,
                  columnNumber: 17
                },
                this
              ),
              errors.user_id && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.user_id }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 2560,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
              lineNumber: 2521,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Select Enrollment ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2565,
                  columnNumber: 37
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 2564,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  mode: "tags",
                  allowClear: true,
                  placeholder: "Select enrollments",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                  value: updateFormData.enrollment_ids,
                  onChange: (selectedEnrollmentIds) => {
                    setUpdateFormData((prev) => ({
                      ...prev,
                      enrollment_ids: selectedEnrollmentIds
                    }));
                  },
                  filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
                  children: filteredEnrollments.map((en) => {
                    const parts = [];
                    if (en.group_name && en.group_name !== "N/A")
                      parts.push(en.group_name);
                    if (en.ticket && en.ticket !== "N/A")
                      parts.push(`Ticket: ${en.ticket}`);
                    return /* @__PURE__ */ jsxDEV(Select.Option, { value: en._id, children: parts.join(" | ") }, en._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2590,
                      columnNumber: 23
                    }, this);
                  })
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2567,
                  columnNumber: 17
                },
                this
              ),
              errors.enrollment_ids && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.enrollment_ids }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 2597,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
              lineNumber: 2563,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "referred_type",
                  children: [
                    "Select Referred Type ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2608,
                      columnNumber: 40
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2604,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                  placeholder: "Select Referred Type",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "guarantor_referred_type",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.guarantor_referred_type || void 0,
                  onChange: (value) => handleAntInputDSelect("guarantor_referred_type", value),
                  children: ["Customer", "Third Party", "Property"].map(
                    (refType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: refType, children: refType }, refType, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2625,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2610,
                  columnNumber: 17
                },
                this
              ),
              errors.guarantor_referred_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_referred_type }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 2631,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
              lineNumber: 2603,
              columnNumber: 15
            }, this),
            updateFormData.guarantor_referred_type === "Customer" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-full mb-4", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "category",
                    children: [
                      "Select Guarantor Customer",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2645,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2640,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                    placeholder: "Select Or Search Referred Customer",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "user_guarantor",
                    filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                    value: updateFormData?.user_guarantor || void 0,
                    onChange: (value) => handleAntInputDSelect("user_guarantor", value),
                    children: users.map(
                      (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: user.full_name }, user._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2666,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2648,
                    columnNumber: 21
                  },
                  this
                ),
                errors.user_guarantor && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.user_guarantor }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2672,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 2639,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "email",
                    children: [
                      "Description ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2682,
                        columnNumber: 35
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2678,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "guarantor_description",
                    value: updateFormData.guarantor_description,
                    onChange: handleInputChange,
                    id: "name",
                    placeholder: "Enter the Description",
                    required: true,
                    className: `bg-gray-50 border ${fieldSize.height} border-gray-300 text-gray-900 text-sm rounded-lg w-full`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2684,
                    columnNumber: 21
                  },
                  this
                ),
                errors.guarantor_description && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_description }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2695,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 2677,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
              lineNumber: 2638,
              columnNumber: 15
            }, this),
            updateFormData.guarantor_referred_type === "Third Party" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 mt-6", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-300 rounded-lg p-6 bg-white shadow-md", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold text-gray-800 text-center mb-6", children: "Personal Information" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2706,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Guarantor Name ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2714,
                        columnNumber: 42
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2713,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_name",
                        value: updateFormData.guarantor_name,
                        onChange: handleInputChange,
                        placeholder: "Enter Guarantor Name",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2716,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_name }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2726,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2712,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Phone Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2734,
                        columnNumber: 40
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2733,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_phone_number",
                        value: updateFormData.guarantor_phone_number,
                        onChange: handleInputChange,
                        placeholder: "Enter Phone Number",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2736,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_phone_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_phone_number }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2746,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2732,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2711,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Select Customer Relationship" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2756,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select Customer Relationship",
                        showSearch: true,
                        name: "guarantor_relationship_type",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: updateFormData.guarantor_relationship_type || void 0,
                        onChange: (value) => handleAntInputDSelect(
                          "guarantor_relationship_type",
                          value
                        ),
                        children: ["Father", "Spouse", "Other"].map(
                          (rel) => /* @__PURE__ */ jsxDEV(Select.Option, { value: rel, children: rel }, rel, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                            lineNumber: 2781,
                            columnNumber: 25
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2759,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_relationship_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_relationship_type }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2787,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2755,
                    columnNumber: 23
                  }, this),
                  updateFormData.guarantor_relationship_type === "Other" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Please specify the relationship:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2796,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full p-2.5",
                        placeholder: "Enter custom relationship",
                        value: customRelationship,
                        onChange: (e) => setCustomRelationship(e.target.value)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2799,
                        columnNumber: 27
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2795,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2754,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Email" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2815,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "email",
                        name: "guarantor_email",
                        value: updateFormData.guarantor_email,
                        onChange: handleInputChange,
                        placeholder: "Enter Email",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2818,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_email && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_email }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2828,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2814,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Date of Birth" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2834,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "date",
                        name: "guarantor_dateofbirth",
                        value: updateFormData.guarantor_dateofbirth ? new Date(updateFormData.guarantor_dateofbirth).toISOString().split("T")[0] : "",
                        onChange: handleInputChange,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2837,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2833,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2813,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Marital Status" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2856,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select Marital Status",
                        showSearch: true,
                        name: "guarantor_marital_status",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: updateFormData.guarantor_marital_status || void 0,
                        onChange: (value) => handleAntInputDSelect(
                          "guarantor_marital_status",
                          value
                        ),
                        children: ["Married", "Unmarried", "Widow", "Divorced"].map(
                          (status) => /* @__PURE__ */ jsxDEV(Select.Option, { value: status, children: status }, status, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                            lineNumber: 2881,
                            columnNumber: 27
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2859,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2855,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Gender" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2889,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select Gender",
                        showSearch: true,
                        name: "guarantor_gender",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: updateFormData.guarantor_gender || void 0,
                        onChange: (value) => handleAntInputDSelect("guarantor_gender", value),
                        children: ["Male", "Female"].map(
                          (g) => /* @__PURE__ */ jsxDEV(Select.Option, { value: g, children: g }, g, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                            lineNumber: 2908,
                            columnNumber: 25
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2892,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2888,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2854,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                    "Address ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2919,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2918,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      name: "guarantor_address",
                      value: updateFormData.guarantor_address,
                      onChange: handleInputChange,
                      placeholder: "Enter the Address",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2921,
                      columnNumber: 23
                    },
                    this
                  ),
                  errors.guarantor_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_address }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2931,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2917,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Village" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2940,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_village",
                        value: updateFormData.guarantor_village,
                        onChange: handleInputChange,
                        placeholder: "Enter Village",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2943,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2939,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Taluk" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2953,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_taluk",
                        value: updateFormData.guarantor_taluk,
                        onChange: handleInputChange,
                        placeholder: "Enter Taluk",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2956,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2952,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2938,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "State" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2970,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select State",
                        showSearch: true,
                        name: "guarantor_state",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: updateFormData.guarantor_state || void 0,
                        onChange: (value) => handleAntInputDSelect("guarantor_state", value),
                        children: ["Karnataka", "Maharashtra", "Tamil Nadu"].map(
                          (state) => /* @__PURE__ */ jsxDEV(Select.Option, { value: state, children: state }, state, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                            lineNumber: 2990,
                            columnNumber: 27
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 2973,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2969,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "District" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 2998,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_district",
                        value: updateFormData.guarantor_district,
                        onChange: handleInputChange,
                        placeholder: "Enter District",
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3001,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 2997,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 2968,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Pincode ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3016,
                        columnNumber: 35
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3015,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_pincode",
                        value: updateFormData.guarantor_pincode,
                        onChange: handleInputChange,
                        placeholder: "Enter Pincode",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3018,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_pincode && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_pincode }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3028,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3014,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Father Name" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3034,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_father_name",
                        value: updateFormData.guarantor_father_name,
                        onChange: handleInputChange,
                        placeholder: "Enter Father Name",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3037,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3033,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 3013,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Nationality" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3051,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select Nationality",
                        showSearch: true,
                        name: "guarantor_nationality",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: updateFormData.guarantor_nationality || void 0,
                        onChange: (value) => handleAntInputDSelect(
                          "guarantor_nationality",
                          value
                        ),
                        children: ["Indian", "Other"].map(
                          (nation) => /* @__PURE__ */ jsxDEV(Select.Option, { value: nation, children: nation }, nation, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                            lineNumber: 3075,
                            columnNumber: 25
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3054,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3050,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Alternate Phone Number" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3082,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_alternate_number",
                        value: updateFormData.guarantor_alternate_number,
                        onChange: handleInputChange,
                        placeholder: "Enter Alternate Number",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3085,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3081,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 3049,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 2705,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-300 rounded-lg p-6 bg-white shadow-md", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold text-gray-800 text-center mb-6", children: "KYC Documents" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 3099,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Aadhaar Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3107,
                        columnNumber: 42
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3106,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_adhaar_no",
                        value: updateFormData.guarantor_adhaar_no,
                        onChange: handleInputChange,
                        placeholder: "Enter Aadhaar Number",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3109,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_adhaar_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_adhaar_no }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3119,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3105,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "PAN Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3126,
                        columnNumber: 38
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3125,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_pan_no",
                        value: updateFormData.guarantor_pan_no,
                        onChange: handleInputChange,
                        placeholder: "Enter PAN Number",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3128,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_pan_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_pan_no }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3138,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3124,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 3104,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                    "Profile Photo ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3148,
                      columnNumber: 39
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3147,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "file",
                      name: "guarantor_photo",
                      onChange: handleFileChange,
                      accept: "image/*",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3150,
                      columnNumber: 23
                    },
                    this
                  ),
                  errors.guarantor_photo && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_photo }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3159,
                    columnNumber: 21
                  }, this),
                  updateFormData.guarantor_photo && /* @__PURE__ */ jsxDEV(Link, { to: updateFormData.guarantor_photo, download: true, children: /* @__PURE__ */ jsxDEV(
                    "img",
                    {
                      src: updateFormData.guarantor_photo,
                      alt: "Profile",
                      className: "w-56 h-56 object-cover mt-4 rounded-md shadow"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3165,
                      columnNumber: 27
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3164,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 3146,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-6", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "PAN Card Photo ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3178,
                        columnNumber: 42
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3177,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "file",
                        name: "guarantor_pan_document",
                        onChange: handleFileChange,
                        accept: "image/*",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3180,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_pan_document && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_pan_document }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3189,
                      columnNumber: 23
                    }, this),
                    updateFormData.guarantor_pan_document && /* @__PURE__ */ jsxDEV(
                      Link,
                      {
                        to: updateFormData.guarantor_pan_document,
                        download: true,
                        children: /* @__PURE__ */ jsxDEV(
                          "img",
                          {
                            src: updateFormData.guarantor_pan_document,
                            alt: "PAN",
                            className: "w-56 h-56 object-cover mt-4 rounded-md shadow"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                            lineNumber: 3198,
                            columnNumber: 29
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3194,
                        columnNumber: 23
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3176,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Aadhaar Card Photo",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3209,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3207,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "file",
                        name: "guarantor_aadhar_document",
                        onChange: handleFileChange,
                        accept: "image/*",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3211,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_aadhar_document && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_aadhar_document }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3220,
                      columnNumber: 23
                    }, this),
                    updateFormData.guarantor_aadhar_document && /* @__PURE__ */ jsxDEV(
                      Link,
                      {
                        to: updateFormData.guarantor_aadhar_document,
                        download: true,
                        children: /* @__PURE__ */ jsxDEV(
                          "img",
                          {
                            src: updateFormData.guarantor_aadhar_document,
                            alt: "",
                            className: "w-56 h-56 object-cover mt-4 rounded-md shadow"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                            lineNumber: 3229,
                            columnNumber: 29
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3225,
                        columnNumber: 23
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3206,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 3175,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold mb-2", children: "Additional Documents" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3241,
                    columnNumber: 23
                  }, this),
                  extraDocs.map(
                    (doc, index) => /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "mb-6 p-3 border border-gray-200 rounded-lg bg-gray-50",
                        children: [
                          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-4", children: [
                            /* @__PURE__ */ jsxDEV(
                              Input,
                              {
                                type: "text",
                                placeholder: "Document Name (e.g. Passport, Voter ID)",
                                value: doc.document_name,
                                onChange: (e) => handleExtraDocNameChange(index, e),
                                className: "w-1/2 h-12 border border-gray-300 rounded-lg p-2"
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                                lineNumber: 3251,
                                columnNumber: 29
                              },
                              this
                            ),
                            /* @__PURE__ */ jsxDEV(
                              "input",
                              {
                                type: "file",
                                name: "guarantor_all_document",
                                onChange: (e) => handleExtraDocFileChange(index, e),
                                accept: "image/*",
                                className: "w-1/2 h-12 border border-gray-300 rounded-lg"
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                                lineNumber: 3260,
                                columnNumber: 29
                              },
                              this
                            ),
                            /* @__PURE__ */ jsxDEV(
                              "button",
                              {
                                type: "button",
                                onClick: () => removeDocField(index),
                                className: "text-violet-600 font-bold text-xl",
                                children: /* @__PURE__ */ jsxDEV(IoMdClose, {}, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                                  lineNumber: 3274,
                                  columnNumber: 31
                                }, this)
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                                lineNumber: 3269,
                                columnNumber: 29
                              },
                              this
                            )
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                            lineNumber: 3250,
                            columnNumber: 27
                          }, this),
                          doc.preview && /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: /* @__PURE__ */ jsxDEV(
                            "img",
                            {
                              src: doc.preview,
                              alt: doc.document_name,
                              className: "w-56 h-56 object-cover rounded-md shadow"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                              lineNumber: 3281,
                              columnNumber: 31
                            },
                            this
                          ) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                            lineNumber: 3280,
                            columnNumber: 23
                          }, this)
                        ]
                      },
                      index,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3245,
                        columnNumber: 21
                      },
                      this
                    )
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: addNewDocField,
                      className: "mt-2 px-2 py-1 bg-violet-600 text-white rounded-lg shadow hover:bg-violet-700",
                      children: "+ Add Document"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3291,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 3240,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 3098,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-300 rounded-lg p-6 bg-white shadow-md", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold text-gray-800 text-center mb-6", children: "Occupation Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 3409,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Guarantor Occupation" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3416,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                      placeholder: "Select Occupation",
                      showSearch: true,
                      value: updateFormData.guarantor_occupation || void 0,
                      onChange: (value) => {
                        setUpdateFormData((prev) => ({
                          ...prev,
                          guarantor_occupation: value,
                          guarantor_occupation_sub: "",
                          guarantor_bussiness_type: "",
                          guarantor_bussiness_name: "",
                          guarantor_bussiness_address: "",
                          guarantor_profession_type: "",
                          guarantor_agri_rtc_no: "",
                          guarantor_land_holdings: ""
                        }));
                      },
                      filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                      children: [
                        "Self Employed",
                        "Salaried",
                        "Professional",
                        "Agri Allied",
                        "Other"
                      ].map(
                        (occ) => /* @__PURE__ */ jsxDEV(Select.Option, { value: occ, children: occ }, occ, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 3455,
                          columnNumber: 25
                        }, this)
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3421,
                      columnNumber: 25
                    },
                    this
                  ),
                  errors.guarantor_occupation && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_occupation }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3461,
                    columnNumber: 23
                  }, this),
                  updateFormData.guarantor_occupation === "Other" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "mt-4 w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Please specify Occupation:" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3470,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Select,
                        {
                          className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                          placeholder: "Select Sub-Category",
                          showSearch: true,
                          value: updateFormData.guarantor_occupation_sub || void 0,
                          onChange: (value) => setFormData((prev) => ({
                            ...prev,
                            guarantor_occupation_sub: value
                          })),
                          filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                          children: [
                            "House Wife",
                            "Retired",
                            "Student",
                            "Investment",
                            "Running an unregistered Business"
                          ].map(
                            (sub) => /* @__PURE__ */ jsxDEV(Select.Option, { value: sub, children: sub }, sub, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                              lineNumber: 3500,
                              columnNumber: 29
                            }, this)
                          )
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 3473,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.guarantor_occupation_sub && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_occupation_sub }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3506,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3469,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Address" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3512,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "guarantor_bussiness_address",
                          value: updateFormData.guarantor_bussiness_address,
                          onChange: handleInputChange,
                          placeholder: "Enter Address",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 3515,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.guarantor_bussiness_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bussiness_address }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3526,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3511,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3468,
                    columnNumber: 23
                  }, this),
                  ["Self Employed", "Salaried"].includes(
                    updateFormData.guarantor_occupation
                  ) && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 space-y-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Business Type" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3540,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "guarantor_bussiness_type",
                          value: updateFormData.guarantor_bussiness_type,
                          onChange: handleInputChange,
                          placeholder: "e.g., Retail, Manufacturing",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 3543,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.guarantor_bussiness_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bussiness_type }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3552,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3539,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Business Name" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3558,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "guarantor_bussiness_name",
                          value: updateFormData.guarantor_bussiness_name,
                          onChange: handleInputChange,
                          placeholder: "Enter Business Name",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 3561,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.guarantor_bussiness_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bussiness_name }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3570,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3557,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Address" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3576,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "guarantor_bussiness_address",
                          value: updateFormData.guarantor_bussiness_address,
                          onChange: handleInputChange,
                          placeholder: "Enter Address",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 3579,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.guarantor_bussiness_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bussiness_address }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3590,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3575,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3538,
                    columnNumber: 23
                  }, this),
                  updateFormData.guarantor_occupation === "Professional" && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 space-y-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Profession Type" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3603,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "guarantor_profession_type",
                          value: updateFormData.guarantor_profession_type,
                          onChange: handleInputChange,
                          placeholder: "e.g., Doctor, CA, Engineer",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 3606,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.guarantor_profession_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_profession_type }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3615,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3602,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Address" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3621,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "guarantor_bussiness_address",
                          value: updateFormData.guarantor_bussiness_address,
                          onChange: handleInputChange,
                          placeholder: "Clinic/Office Address",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 3624,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.guarantor_bussiness_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bussiness_address }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3635,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3620,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3601,
                    columnNumber: 23
                  }, this),
                  updateFormData.guarantor_occupation === "Agri Allied" && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 w-full space-y-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "RTC No / Land Record ID" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3648,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "guarantor_agri_rtc_no",
                          value: updateFormData.guarantor_agri_rtc_no,
                          onChange: handleInputChange,
                          placeholder: "Enter RTC Number",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 3651,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.guarantor_agri_rtc_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_agri_rtc_no }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3660,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3647,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Land Holdings (in acres)" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3666,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "number",
                          name: "guarantor_land_holdings",
                          value: updateFormData.guarantor_land_holdings,
                          onChange: handleInputChange,
                          placeholder: "e.g., 5.5",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 3669,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.guarantor_land_holdings && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_land_holdings }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3678,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3665,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Address" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3684,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "guarantor_bussiness_address",
                          value: updateFormData.guarantor_bussiness_address,
                          onChange: handleInputChange,
                          placeholder: "Farm or Operation Address",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 3687,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.guarantor_bussiness_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bussiness_address }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3698,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3683,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3646,
                    columnNumber: 23
                  }, this),
                  updateFormData.guarantor_occupation === "Other" && updateFormData.guarantor_occupation_sub === "Running an unregistered Business" && /* @__PURE__ */ jsxDEV("div", { className: " w-full mt-4", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Address" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3711,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_bussiness_address",
                        value: updateFormData.guarantor_bussiness_address,
                        onChange: handleInputChange,
                        placeholder: "Enter Address",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3714,
                        columnNumber: 31
                      },
                      this
                    ),
                    errors.guarantor_bussiness_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bussiness_address }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3725,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3710,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 3415,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 3413,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: [
                    "Salary/Income Document Photo ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3737,
                      columnNumber: 53
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3736,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "file",
                      name: "guarantor_income_document",
                      onChange: handleFileChange,
                      accept: "image/*",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 hover:bg-gray-100 focus:ring-violet-500 focus:border-violet-500"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3739,
                      columnNumber: 23
                    },
                    this
                  ),
                  errors.guarantor_income_document && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_income_document }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3748,
                    columnNumber: 21
                  }, this),
                  updateFormData.guarantor_income_document && /* @__PURE__ */ jsxDEV(
                    Link,
                    {
                      to: updateFormData.guarantor_income_document,
                      download: true,
                      children: /* @__PURE__ */ jsxDEV(
                        "img",
                        {
                          src: updateFormData.guarantor_income_document,
                          alt: "Income Document",
                          className: "w-56 h-56 object-cover mt-4 rounded-md shadow-md border"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 3757,
                          columnNumber: 27
                        },
                        this
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3753,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 3735,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 3408,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-300 rounded-lg p-6 bg-white shadow-md", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold text-gray-800 text-center mb-6", children: "Bank Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 3769,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Bank Name" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3775,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_bank_name",
                        value: updateFormData.guarantor_bank_name,
                        onChange: handleInputChange,
                        placeholder: "Enter Bank Name",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3778,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_bank_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bank_name }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3787,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3774,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Bank Account Number" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3793,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_bank_account_number",
                        value: updateFormData.guarantor_bank_account_number,
                        onChange: handleInputChange,
                        placeholder: "Enter Account Number",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3796,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_bank_account_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bank_account_number }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3805,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3792,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 3773,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Bank Branch" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3814,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_bank_branch",
                        value: updateFormData.guarantor_bank_branch,
                        onChange: handleInputChange,
                        placeholder: "Enter Branch",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3817,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_bank_branch && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bank_branch }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3826,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3813,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Bank IFSC Code" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3832,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "guarantor_bank_ifsc_code",
                        value: updateFormData.guarantor_bank_ifsc_code,
                        onChange: handleInputChange,
                        placeholder: "Enter IFSC Code",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3835,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.guarantor_bank_ifsc_code && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bank_ifsc_code }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3844,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3831,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 3812,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                    "Bank Passbook ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3853,
                      columnNumber: 39
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3852,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "file",
                      name: "guarantor_bank_passbook_photo",
                      onChange: handleFileChange,
                      accept: "image/*",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3855,
                      columnNumber: 23
                    },
                    this
                  ),
                  errors.guarantor_bank_passbook_photo && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_bank_passbook_photo }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3864,
                    columnNumber: 21
                  }, this),
                  updateFormData.guarantor_bank_passbook_photo && /* @__PURE__ */ jsxDEV(
                    Link,
                    {
                      to: updateFormData.guarantor_bank_passbook_photo,
                      download: true,
                      children: /* @__PURE__ */ jsxDEV(
                        "img",
                        {
                          src: updateFormData.guarantor_bank_passbook_photo,
                          alt: "Passbook",
                          className: "w-56 h-56 object-cover mt-4 rounded-md shadow"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 3873,
                          columnNumber: 27
                        },
                        this
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 3869,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 3851,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 3768,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
              lineNumber: 2703,
              columnNumber: 15
            }, this),
            updateFormData.guarantor_referred_type === "Property" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "email",
                    children: [
                      "Property Name ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3891,
                        columnNumber: 37
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3887,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "guarantor_document_name",
                    value: updateFormData.guarantor_document_name,
                    onChange: handleInputChange,
                    id: "name",
                    placeholder: "Enter the Description",
                    required: true,
                    className: `bg-gray-50 border ${fieldSize.height} border-gray-300 text-gray-900 text-sm rounded-lg w-full`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3893,
                    columnNumber: 21
                  },
                  this
                ),
                errors.guarantor_document_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_document_name }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 3904,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 3886,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "email",
                    children: [
                      "Property Document ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3914,
                        columnNumber: 41
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3910,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "file",
                    name: "guarantor_document",
                    onChange: handleFileChange,
                    id: "guarantor_document",
                    accept: "image/*",
                    placeholder: "Upload Document",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3916,
                    columnNumber: 21
                  },
                  this
                ),
                errors.guarantor_document && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_document }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 3928,
                  columnNumber: 19
                }, this),
                updateFormData.guarantor_document && /* @__PURE__ */ jsxDEV(
                  Link,
                  {
                    to: updateFormData.guarantor_document,
                    download: true,
                    children: /* @__PURE__ */ jsxDEV(
                      "img",
                      {
                        src: updateFormData.guarantor_document,
                        alt: "Property",
                        className: "w-56 h-56 object-cover mt-4 rounded-md shadow"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3937,
                        columnNumber: 27
                      },
                      this
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3933,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 3909,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "description",
                    children: [
                      "Description ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                        lineNumber: 3950,
                        columnNumber: 35
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3946,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "guarantor_description",
                    value: updateFormData.guarantor_description,
                    onChange: handleInputChange,
                    id: "description",
                    placeholder: "Enter the Description",
                    required: true,
                    className: `bg-gray-50 border ${fieldSize.height} border-gray-300 text-gray-900 text-sm rounded-lg w-full`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 3952,
                    columnNumber: 21
                  },
                  this
                ),
                errors.guarantor_description && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.guarantor_description }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 3963,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 3945,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
              lineNumber: 3885,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Update"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                lineNumber: 3972,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
              lineNumber: 3971,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
            lineNumber: 2520,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
          lineNumber: 2516,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
        lineNumber: 2512,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentGuarantor(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Guarantor" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
            lineNumber: 3991,
            columnNumber: 13
          }, this),
          currentGuarantor && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteGuarantor();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "groupName",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentGuarantor.guarantor_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 4008,
                          columnNumber: 21
                        }, this),
                        " ",
                        "to confirm deletion.",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                          lineNumber: 4012,
                          columnNumber: 21
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 4003,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      id: "groupName",
                      placeholder: "Enter the Guarantor Name",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                      lineNumber: 4014,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                  lineNumber: 4002,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\n          focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
                    lineNumber: 4022,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
              lineNumber: 3995,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
          lineNumber: 3990,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
        lineNumber: 3983,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
    lineNumber: 1122,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx",
    lineNumber: 1121,
    columnNumber: 5
  }, this);
};
_s(Guarantor, "qHggitaQAi/MQf10QV3kOYAbiQE=");
_c = Guarantor;
export default Guarantor;
var _c;
$RefreshReg$(_c, "Guarantor");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Guarantor.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcVIwQixTQTBzREEsVUExc0RBOzJCQXJSMUI7QUFBb0JBLG9CQUFnQixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsU0FBU0MsT0FBT0MsUUFBUUMsZ0JBQWdCO0FBQ3hDLFNBQVNDLGdCQUFnQjtBQUN6QixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsMEJBQTBCO0FBQ2pDLE9BQU9DLHVCQUF1QjtBQUM5QixTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxpQkFBaUI7QUFDMUIsT0FBT0MsZ0JBQWdCO0FBRXZCLE1BQU1DLFlBQVlBLE1BQU07QUFBQUMsS0FBQTtBQUN0QixRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSXJCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNzQixXQUFXQyxZQUFZLElBQUl2QixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDd0IsZ0JBQWdCQyxpQkFBaUIsSUFBSXpCLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUMwQixZQUFZQyxhQUFhLElBQUkzQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDNEIsV0FBV0MsWUFBWSxJQUFJN0IsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzhCLGlCQUFpQkMsa0JBQWtCLElBQUkvQixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDZ0MsaUJBQWlCQyxrQkFBa0IsSUFBSWpDLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNrQyxrQkFBa0JDLG1CQUFtQixJQUFJbkMsU0FBUyxJQUFJO0FBQzdELFFBQU0sQ0FBQ29DLFdBQVdDLFlBQVksSUFBSXJDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNzQyx3QkFBd0JDLHlCQUF5QixJQUFJdkMsU0FBUyxJQUFJO0FBQ3pFLFFBQU0sQ0FBQ3dDLGVBQWVDLGdCQUFnQixJQUFJekMsU0FBUyxDQUFDO0FBQ3BELFFBQU0sQ0FBQzBDLFlBQVlDLGFBQWEsSUFBSTNDLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUM0QyxhQUFhQyxjQUFjLElBQUk3QyxTQUFTO0FBQUEsSUFDN0M4QyxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFDRCxRQUFNLENBQUNDLG9CQUFvQkMscUJBQXFCLElBQUlsRCxTQUFTLEVBQUU7QUFDL0QsUUFBTSxDQUFDbUQsUUFBUUMsU0FBUyxJQUFJcEQsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDcUQscUJBQXFCQyxzQkFBc0IsSUFBSXRELFNBQVMsRUFBRTtBQUVqRSxRQUFNLENBQUN1RCxVQUFVQyxXQUFXLElBQUl4RCxTQUFTO0FBQUEsSUFDdkN5RCxTQUFTO0FBQUEsSUFDVEMsZ0JBQWdCO0FBQUEsSUFDaEJDLGlCQUFpQjtBQUFBLElBQ2pCQyxnQkFBZ0I7QUFBQSxJQUNoQkMsd0JBQXdCO0FBQUEsSUFDeEJDLG1CQUFtQjtBQUFBLElBQ25CQyxtQkFBbUI7QUFBQSxJQUNuQkMscUJBQXFCO0FBQUEsSUFDckJDLGtCQUFrQjtBQUFBLElBQ2xCQyxrQkFBa0I7QUFBQSxJQUNsQkMsMEJBQTBCO0FBQUEsSUFDMUJDLHVCQUF1QjtBQUFBLElBQ3ZCQyx1QkFBdUI7QUFBQSxJQUN2QkMsbUJBQW1CO0FBQUEsSUFDbkJDLGlCQUFpQjtBQUFBLElBQ2pCQyx1QkFBdUI7QUFBQSxJQUN2QkMsb0JBQW9CO0FBQUEsSUFDcEJDLGlCQUFpQjtBQUFBLElBQ2pCQyx1QkFBdUI7QUFBQSxJQUN2QkMsZ0JBQWdCO0FBQUEsSUFDaEJDLDRCQUE0QjtBQUFBLElBQzVCQyx5QkFBeUI7QUFBQSxJQUN6QkMseUJBQXlCO0FBQUEsSUFDekJDLG9CQUFvQjtBQUFBLElBQ3BCQyxpQkFBaUI7QUFBQSxJQUNqQkMsd0JBQXdCO0FBQUEsSUFDeEJDLDJCQUEyQjtBQUFBLElBQzNCQyw2QkFBNkI7QUFBQSxJQUM3QkMsc0JBQXNCO0FBQUEsSUFDdEJDLHVCQUF1QjtBQUFBLElBQ3ZCQywyQkFBMkI7QUFBQSxJQUMzQkMsNEJBQTRCO0FBQUEsSUFDNUJDLHFCQUFxQjtBQUFBLElBQ3JCQywrQkFBK0I7QUFBQSxJQUMvQkMsdUJBQXVCO0FBQUEsSUFDdkJDLDBCQUEwQjtBQUFBLElBQzFCQyx5QkFBeUI7QUFBQSxJQUN6QkMsK0JBQStCO0FBQUEsSUFDL0JDLDBCQUEwQjtBQUFBLElBQzFCQywwQkFBMEI7QUFBQSxJQUMxQkMsNkJBQTZCO0FBQUEsSUFDN0JDLDJCQUEyQjtBQUFBLElBQzNCQyx1QkFBdUI7QUFBQSxJQUN2QkMseUJBQXlCO0FBQUEsSUFDekJDLDBCQUEwQjtBQUFBLElBQzFCQyw2QkFBNkI7QUFBQSxJQUM3QkMsd0JBQXdCO0FBQUEsRUFDMUIsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsZ0JBQWdCQyxpQkFBaUIsSUFBSXpHLFNBQVM7QUFBQSxJQUNuRHlELFNBQVM7QUFBQSxJQUNUQyxnQkFBZ0I7QUFBQSxJQUNoQkMsaUJBQWlCO0FBQUEsSUFDakJDLGdCQUFnQjtBQUFBLElBQ2hCQyx3QkFBd0I7QUFBQSxJQUN4QkMsbUJBQW1CO0FBQUEsSUFDbkJDLG1CQUFtQjtBQUFBLElBQ25CQyxxQkFBcUI7QUFBQSxJQUNyQkMsa0JBQWtCO0FBQUEsSUFDbEJDLGtCQUFrQjtBQUFBLElBQ2xCQywwQkFBMEI7QUFBQSxJQUMxQkMsdUJBQXVCO0FBQUEsSUFDdkJDLHVCQUF1QjtBQUFBLElBQ3ZCQyxtQkFBbUI7QUFBQSxJQUNuQkMsaUJBQWlCO0FBQUEsSUFDakJDLHVCQUF1QjtBQUFBLElBQ3ZCQyxvQkFBb0I7QUFBQSxJQUNwQkMsaUJBQWlCO0FBQUEsSUFDakJDLHVCQUF1QjtBQUFBLElBQ3ZCRSw0QkFBNEI7QUFBQSxJQUM1QkQsZ0JBQWdCO0FBQUEsSUFDaEJFLHlCQUF5QjtBQUFBLElBQ3pCRSxvQkFBb0I7QUFBQSxJQUNwQkQseUJBQXlCO0FBQUEsSUFDekJFLGlCQUFpQjtBQUFBLElBQ2pCQyx3QkFBd0I7QUFBQSxJQUN4QkMsMkJBQTJCO0FBQUEsSUFDM0JDLDZCQUE2QjtBQUFBLElBQzdCQyxzQkFBc0I7QUFBQSxJQUN0QkMsdUJBQXVCO0FBQUEsSUFDdkJDLDJCQUEyQjtBQUFBLElBQzNCQyw0QkFBNEI7QUFBQSxJQUM1QkMscUJBQXFCO0FBQUEsSUFDckJDLCtCQUErQjtBQUFBLElBQy9CQyx1QkFBdUI7QUFBQSxJQUN2QkMsMEJBQTBCO0FBQUEsSUFDMUJDLHlCQUF5QjtBQUFBLElBQ3pCQywrQkFBK0I7QUFBQSxJQUMvQkMsMEJBQTBCO0FBQUEsSUFDMUJDLDBCQUEwQjtBQUFBLElBQzFCQyw2QkFBNkI7QUFBQSxJQUM3QkMsMkJBQTJCO0FBQUEsSUFDM0JDLHVCQUF1QjtBQUFBLElBQ3ZCQyx5QkFBeUI7QUFBQSxJQUN6QkMsMEJBQTBCO0FBQUEsSUFDMUJDLDZCQUE2QjtBQUFBLElBQzdCQyx3QkFBd0I7QUFBQSxFQUMxQixDQUFDO0FBRUQsUUFBTSxDQUFDRyxZQUFZQyxhQUFhLElBQUkzRyxTQUFTLEVBQUU7QUFDL0MsUUFBTTRHLDRCQUE0QkEsQ0FBQ0MsTUFBTTtBQUN2QyxVQUFNLEVBQUVDLE1BQU0sSUFBSUQsRUFBRUU7QUFDcEJKLGtCQUFjRyxLQUFLO0FBQUEsRUFDckI7QUFDQSxRQUFNLENBQUNFLFdBQVdDLFlBQVksSUFBSWpIO0FBQUFBLElBQ2hDdUQsU0FBU2dELDBCQUEwQjtBQUFBLE1BQ2pDLEVBQUVXLGVBQWUsSUFBSUMsTUFBTSxNQUFNQyxTQUFTLEdBQUc7QUFBQSxJQUFDO0FBQUEsRUFFbEQ7QUFDQUMsWUFBVSxNQUFNO0FBQ2QsVUFBTUMsYUFBYSxZQUFZO0FBQzdCLFVBQUk7QUFDRixjQUFNQyxXQUFXLE1BQU1wSCxJQUFJcUgsSUFBSSxnQkFBZ0I7QUFFL0NuRyxpQkFBU2tHLFNBQVNFLElBQUk7QUFBQSxNQUN4QixTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUFBLE1BQ2xEO0FBQUEsSUFDRjtBQUNBSixlQUFXO0FBQUEsRUFDYixHQUFHLEVBQUU7QUFxQkwsUUFBTU0sMkJBQTJCQSxDQUFDQyxPQUFPaEIsTUFBTTtBQUM3QyxVQUFNaUIsVUFBVSxDQUFDLEdBQUdkLFNBQVM7QUFDN0JjLFlBQVFELEtBQUssRUFBRVgsZ0JBQWdCTCxFQUFFRSxPQUFPRDtBQUN4Q0csaUJBQWFhLE9BQU87QUFBQSxFQUN0QjtBQUVBLFFBQU1DLDJCQUEyQkEsQ0FBQ0YsT0FBT2hCLE1BQU07QUFDN0MsVUFBTU0sT0FBT04sRUFBRUUsT0FBT2lCLE1BQU0sQ0FBQztBQUM3QixRQUFJYixNQUFNO0FBQ1IsWUFBTVcsVUFBVSxDQUFDLEdBQUdkLFNBQVM7QUFDN0JjLGNBQVFELEtBQUssRUFBRVYsT0FBT0E7QUFDdEJXLGNBQVFELEtBQUssRUFBRVQsVUFBVWEsSUFBSUMsZ0JBQWdCZixJQUFJO0FBQ2pERixtQkFBYWEsT0FBTztBQUFBLElBQ3RCO0FBQUEsRUFDRjtBQUdBLFFBQU1LLGlCQUFpQkEsTUFBTTtBQUMzQmxCO0FBQUFBLE1BQWE7QUFBQSxRQUNYLEdBQUdEO0FBQUFBLFFBQ0gsRUFBRUUsZUFBZSxJQUFJQyxNQUFNLE1BQU1DLFNBQVMsR0FBRztBQUFBLE1BQUM7QUFBQSxJQUMvQztBQUFBLEVBQ0g7QUFFQSxRQUFNZ0IsaUJBQWlCQSxDQUFDUCxVQUFVO0FBQ2hDLFVBQU1DLFVBQVVkLFVBQVVxQixPQUFPLENBQUNDLEdBQUdDLE1BQU1BLE1BQU1WLEtBQUs7QUFDdERaLGlCQUFhYSxPQUFPO0FBQ3BCdEUsZ0JBQVksRUFBRSxHQUFHRCxVQUFVZ0Qsd0JBQXdCdUIsUUFBUSxDQUFDO0FBQUEsRUFDOUQ7QUFFQVQsWUFBVSxNQUFNO0FBQ2QsVUFBTW1CLHNCQUFzQixZQUFZO0FBQ3RDbkcsbUJBQWEsSUFBSTtBQUNqQixVQUFJO0FBQ0YsY0FBTWtGLFdBQVcsTUFBTXBILElBQUlxSCxJQUFJLGtDQUFrQztBQUNqRSxZQUFJRCxTQUFTRSxNQUFNO0FBQ2pCOUUsd0JBQWM0RSxTQUFTRSxJQUFJO0FBQUEsUUFDN0I7QUFBQSxNQUNGLFNBQVNDLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sbUNBQW1DQSxLQUFLO0FBQUEsTUFDeEQsVUFBQztBQUNDckYscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUNBbUcsd0JBQW9CO0FBQUEsRUFDdEIsR0FBRyxFQUFFO0FBRUxuQixZQUFVLE1BQU07QUFDZCxVQUFNb0IsaUJBQWlCLFlBQVk7QUFDakMsVUFBSTtBQUNGcEcscUJBQWEsSUFBSTtBQUNqQixjQUFNa0YsV0FBVyxNQUFNcEgsSUFBSXFILElBQUksK0JBQStCO0FBQzlERyxnQkFBUWUsS0FBSyxhQUFhbkIsU0FBU0UsSUFBSTtBQUN2QyxjQUFNa0IsYUFBYXBCLFNBQVNFLE1BQU1uRyxhQUFhO0FBQy9DcUcsZ0JBQVFlLEtBQUssYUFBYW5CLFNBQVNFLElBQUk7QUFDdkNsRyxxQkFBYW9ILFVBQVU7QUFDdkIsY0FBTUMsZ0JBQWdCRCxXQUFXRSxJQUFJLENBQUNDLE9BQU9qQixVQUFVO0FBQ3JELGdCQUFNa0IscUJBQXFCRCxPQUFPbEUsa0JBQWtCLElBQUlpRTtBQUFBQSxZQUN0RCxDQUFDRyxXQUFXO0FBQ1Ysb0JBQU1DLFlBQVlELFFBQVFFLFVBQVVDLGNBQWM7QUFDbEQsb0JBQU1DLFNBQVNKLFFBQVFLLFdBQVc7QUFDbEMscUJBQU8sR0FBR0osU0FBUyxjQUFjRyxNQUFNO0FBQUEsWUFDekM7QUFBQSxVQUNGO0FBRUEsZ0JBQU05SCxhQUFZRixNQUFNa0ksS0FBSyxDQUFDQyxNQUFNQSxFQUFFQyxRQUFRVixPQUFPbEYsY0FBYztBQUNuRStELGtCQUFRZSxLQUFLLGFBQWFwSCxVQUFTO0FBQ25DLGdCQUFNbUksZ0JBQ0pYLE9BQU9oRSw0QkFBNEIsYUFDL0J4RCxZQUFXb0ksYUFBYSxRQUN4QlosT0FBT3BGO0FBRWIsZ0JBQU1pRyxpQkFDSmIsT0FBT2hFLDRCQUE0QixhQUMvQnhELFlBQVdzSSxnQkFBZ0IsUUFDM0JkLE9BQU9qRjtBQUViLGlCQUFPO0FBQUEsWUFDTDJGLEtBQUtWLE9BQU9VO0FBQUFBLFlBQ1pLLElBQUloQyxRQUFRO0FBQUEsWUFDWGlDLGdCQUFnQmhCLE9BQU9nQjtBQUFBQSxZQUN4QnJHLFNBQVNxRixPQUFPckYsU0FBU2lHO0FBQUFBLFlBQ3pCSyxvQkFBb0JoQixrQkFBa0JpQixLQUFLLElBQUk7QUFBQSxZQUMvQ2xGLHlCQUF5QmdFLE9BQU9oRTtBQUFBQSxZQUNoQ3BCLGdCQUFnQitGO0FBQUFBLFlBQ2hCNUYsd0JBQXdCOEY7QUFBQUEsWUFDeEJoRix1QkFBdUJtRSxPQUFPbkU7QUFBQUEsWUFDOUJzRixRQUNFLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsZ0JBQ2pCLE1BQU07QUFBQSxrQkFDSkMsT0FBTztBQUFBLG9CQUNMO0FBQUEsc0JBQ0VDLEtBQUs7QUFBQSxzQkFDTEMsT0FDRTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFVO0FBQUEsMEJBQ1YsU0FBUyxNQUFNQyxzQkFBc0J2QixPQUFPVSxHQUFHO0FBQUEsMEJBQUU7QUFBQTtBQUFBLHdCQUZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBS0E7QUFBQSxvQkFFSjtBQUFBLG9CQUNBO0FBQUEsc0JBQ0VXLEtBQUs7QUFBQSxzQkFDTEMsT0FDRTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFVO0FBQUEsMEJBQ1YsU0FBUyxNQUFNRSxzQkFBc0J4QixPQUFPVSxHQUFHO0FBQUEsMEJBQUU7QUFBQTtBQUFBLHdCQUZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBS0E7QUFBQSxvQkFFSjtBQUFBLG9CQUNBO0FBQUEsc0JBQ0VXLEtBQUs7QUFBQSxzQkFDTEMsT0FDRTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxTQUFTLE1BQU14SixxQkFBcUJrSSxPQUFPVSxHQUFHO0FBQUEsMEJBQzlDLFdBQVU7QUFBQSwwQkFBbUI7QUFBQTtBQUFBLHdCQUYvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBS0E7QUFBQSxvQkFFSjtBQUFBLGtCQUFDO0FBQUEsZ0JBRUw7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBRVYsaUNBQUMsWUFBUyxXQUFVLGVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStCO0FBQUE7QUFBQSxjQXpDakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBMENBLEtBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNENBO0FBQUEsVUFFSjtBQUFBLFFBQ0YsQ0FBQztBQUVELFlBQUllLFFBQVEzQixjQUFjQyxJQUFJLENBQUMyQixRQUFRO0FBQ3JDLGNBQ0VBLEtBQUsxRyxxQkFDTCxPQUFPMEcsSUFBSTFHLHNCQUFzQixZQUNqQzBHLEtBQUsxRyxtQkFBbUIyRyxTQUFTLEdBQUc7QUFFcENELGdCQUFJMUcsb0JBQW9CMEcsSUFBSTFHLGtCQUFrQjRHLFdBQVcsS0FBSyxHQUFHO0FBQ25FLGlCQUFPRjtBQUFBQSxRQUNULENBQUM7QUFDRCxZQUFJLENBQUNELE1BQU85SSxtQkFBa0JtSCxhQUFhO0FBQzNDLFlBQUksQ0FBQzJCLE1BQU85SSxtQkFBa0JtSCxhQUFhO0FBQzNDbkgsMEJBQWtCOEksS0FBSztBQUFBLE1BQ3pCLFNBQVM3QyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLGtDQUFrQ0EsTUFBTTNFLE9BQU87QUFBQSxNQUMvRCxVQUFDO0FBQ0NWLHFCQUFhLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFDQW9HLG1CQUFlO0FBQUEsRUFDakIsR0FBRyxDQUFDakcsYUFBYSxDQUFDO0FBRWxCLFFBQU1tSSxtQkFBbUJBLENBQUNDLE9BQU85RCxVQUFVO0FBQ3pDdEQsZ0JBQVksQ0FBQ3FILGNBQWM7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNILENBQUNELEtBQUssR0FBRzlEO0FBQUFBLElBQ1gsRUFBRTtBQUNGLFFBQUlBLFVBQVUsU0FBUztBQUNyQjVELDRCQUFzQixFQUFFO0FBQUEsSUFDMUI7QUFFQUUsY0FBVSxDQUFDMEgsZ0JBQWdCO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRixLQUFLLEdBQUc7QUFBQSxJQUNYLEVBQUU7QUFBQSxFQUNKO0FBQ0EsUUFBTUcsd0JBQXdCQSxDQUFDSCxPQUFPOUQsVUFBVTtBQUM5Q0wsc0JBQWtCLENBQUNvRSxjQUFjO0FBQUEsTUFDL0IsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRCxLQUFLLEdBQUc5RDtBQUFBQSxJQUNYLEVBQUU7QUFFRjFELGNBQVUsRUFBRSxHQUFHRCxRQUFRLENBQUN5SCxLQUFLLEdBQUcsR0FBRyxDQUFDO0FBQUEsRUFDdEM7QUFDQSxRQUFNSSxlQUFlQSxDQUFDbkUsTUFBTTtBQUMxQixVQUFNLEVBQUVvRSxNQUFNbkUsTUFBTSxJQUFJRCxFQUFFRTtBQUMxQnZELGdCQUFZLENBQUNxSCxjQUFjO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDSSxJQUFJLEdBQUduRTtBQUFBQSxJQUNWLEVBQUU7QUFDRjFELGNBQVUsQ0FBQzBILGdCQUFnQjtBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0csSUFBSSxHQUFHO0FBQUEsSUFDVixFQUFFO0FBQUEsRUFDSjtBQTRORixRQUFNQyxlQUFlQSxDQUFDbEksU0FBUztBQUM3QixVQUFNbUksWUFBWSxDQUFDO0FBQ25CLFVBQU0xRCxPQUFPekUsU0FBUyxpQkFBaUJPLFdBQVdpRDtBQUdsRCxVQUFNNEUsUUFBUTtBQUFBLE1BQ1pDLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsTUFDUEMsU0FBUztBQUFBLE1BQ1RDLFFBQVE7QUFBQSxNQUNSQyxLQUFLO0FBQUEsSUFDUDtBQUdBLFVBQU1DLGVBQWVBLENBQUN2RSxNQUFNOEQsU0FBUztBQUNuQyxVQUFJLENBQUM5RCxNQUFNO0FBQ1QsZUFBTyxHQUFHOEQsSUFBSTtBQUFBLE1BQ2hCO0FBQ0EsWUFBTVUsZUFBZSxDQUFDLGNBQWMsYUFBYSxXQUFXO0FBQzVELFVBQUl4RSxnQkFBZ0J5RSxNQUFNO0FBQ3hCLFlBQUksQ0FBQ0QsYUFBYWxCLFNBQVN0RCxLQUFLbkUsSUFBSSxHQUFHO0FBQ3JDLGlCQUFPO0FBQUEsUUFDVDtBQUNBLFlBQUltRSxLQUFLMEUsT0FBTyxJQUFJLE9BQU8sTUFBTTtBQUMvQixpQkFBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGLFdBQVcsT0FBTzFFLFNBQVMsWUFBWUEsS0FBSzJFLEtBQUssTUFBTSxJQUFJO0FBQ3pELGVBQU8sR0FBR2IsSUFBSTtBQUFBLE1BQ2hCO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFHQSxRQUFJLENBQUN4RCxLQUFLaEUsUUFBUzBILFdBQVUxSCxVQUFVO0FBQ3ZDLFFBQUksQ0FBQ2dFLEtBQUszQyx3QkFBeUJxRyxXQUFVckcsMEJBQTBCO0FBQ3ZFLFFBQUksQ0FBQzJDLEtBQUs3QyxrQkFBa0I2QyxLQUFLN0MsZUFBZW1ILFdBQVcsRUFBR1osV0FBVXZHLGlCQUFpQjtBQUd6RixRQUFJNkMsS0FBSzNDLDRCQUE0QixZQUFZO0FBQy9DLFVBQUksQ0FBQzJDLEtBQUs3RCxlQUFnQnVILFdBQVV2SCxpQkFBaUI7QUFDckQsVUFBSSxDQUFDNkQsS0FBSzlDLHVCQUF1Qm1ILEtBQUssRUFBR1gsV0FBVXhHLHdCQUF3QjtBQUFBLElBQzdFLFdBQVc4QyxLQUFLM0MsNEJBQTRCLFlBQVk7QUFDdEQsVUFBSSxDQUFDMkMsS0FBSzlDLHVCQUF1Qm1ILEtBQUssRUFBR1gsV0FBVXhHLHdCQUF3QjtBQUMzRSxVQUFJLENBQUM4QyxLQUFLMUMseUJBQXlCK0csS0FBSyxFQUFHWCxXQUFVcEcsMEJBQTBCO0FBQy9FLFVBQUlpSCxZQUFZTixhQUFhakUsS0FBS3pDLG9CQUFvQix5QkFBeUI7QUFDL0UsVUFBSWdILFVBQVdiLFdBQVVuRyxxQkFBcUJnSDtBQUFBQSxJQUNoRCxXQUFXdkUsS0FBSzNDLDRCQUE0QixlQUFlO0FBRXpELFVBQUksQ0FBQzJDLEtBQUsvRCxnQkFBZ0JvSSxLQUFLLEVBQUdYLFdBQVV6SCxpQkFBaUI7QUFDN0QsVUFBSSxDQUFDK0QsS0FBS3JDLDZCQUE2QjBHLEtBQUssRUFBR1gsV0FBVS9GLDhCQUE4QjtBQUN2RixVQUFJLENBQUNxQyxLQUFLNUQsMEJBQTBCLENBQUN1SCxNQUFNRSxNQUFNVyxLQUFLeEUsS0FBSzVELHNCQUFzQixHQUFHO0FBQ2xGc0gsa0JBQVV0SCx5QkFBeUI7QUFBQSxNQUNyQztBQUNBLFVBQUksQ0FBQzRELEtBQUs5RCxtQkFBbUIsQ0FBQ3lILE1BQU1DLE1BQU1ZLEtBQUt4RSxLQUFLOUQsZUFBZSxHQUFHO0FBQ3BFd0gsa0JBQVV4SCxrQkFBa0I7QUFBQSxNQUM5QjtBQUNBLFVBQUksQ0FBQzhELEtBQUszRCxtQkFBbUJnSSxLQUFLLEVBQUdYLFdBQVVySCxvQkFBb0I7QUFDbkUsVUFBSSxDQUFDMkQsS0FBSzFELHFCQUFxQixDQUFDcUgsTUFBTUcsUUFBUVUsS0FBS3hFLEtBQUsxRCxpQkFBaUIsR0FBRztBQUMxRW9ILGtCQUFVcEgsb0JBQW9CO0FBQUEsTUFDaEM7QUFHQSxVQUFJLENBQUMwRCxLQUFLekQsdUJBQXVCLENBQUNvSCxNQUFNSSxPQUFPUyxLQUFLeEUsS0FBS3pELG1CQUFtQixHQUFHO0FBQzdFbUgsa0JBQVVuSCxzQkFBc0I7QUFBQSxNQUNsQztBQUNBLFVBQUksQ0FBQ3lELEtBQUt4RCxvQkFBb0IsQ0FBQ21ILE1BQU1LLElBQUlRLEtBQUt4RSxLQUFLeEQsZ0JBQWdCLEdBQUc7QUFDcEVrSCxrQkFBVWxILG1CQUFtQjtBQUFBLE1BQy9CO0FBQ0EsVUFBSStILFlBQVlOLGFBQWFqRSxLQUFLeEMsaUJBQWlCLGVBQWU7QUFDbEUsVUFBSStHLFVBQVdiLFdBQVVsRyxrQkFBa0IrRztBQUMzQ0Esa0JBQVlOLGFBQWFqRSxLQUFLdkMsd0JBQXdCLGdCQUFnQjtBQUN0RSxVQUFJOEcsVUFBV2IsV0FBVWpHLHlCQUF5QjhHO0FBQ2xEQSxrQkFBWU4sYUFBYWpFLEtBQUt0QywyQkFBMkIsb0JBQW9CO0FBQzdFLFVBQUk2RyxVQUFXYixXQUFVaEcsNEJBQTRCNkc7QUFHckQsVUFBSSxDQUFDdkUsS0FBS3BDLHFCQUFzQjhGLFdBQVU5Rix1QkFBdUI7QUFHakUsY0FBUW9DLEtBQUtwQyxzQkFBb0I7QUFBQSxRQUMvQixLQUFLO0FBQUEsUUFDTCxLQUFLO0FBQ0gsY0FBSSxDQUFDb0MsS0FBSzFCLDBCQUEwQitGLEtBQUssRUFBR1gsV0FBVXBGLDJCQUEyQjtBQUNqRixjQUFJLENBQUMwQixLQUFLekIsMEJBQTBCOEYsS0FBSyxFQUFHWCxXQUFVbkYsMkJBQTJCO0FBQ2pGLGNBQUksQ0FBQ3lCLEtBQUt4Qiw2QkFBNkI2RixLQUFLLEVBQUdYLFdBQVVsRiw4QkFBOEI7QUFDdkY7QUFBQSxRQUNGLEtBQUs7QUFDSCxjQUFJLENBQUN3QixLQUFLdkIsMkJBQTJCNEYsS0FBSyxFQUFHWCxXQUFVakYsNEJBQTRCO0FBQ25GLGNBQUksQ0FBQ3VCLEtBQUt4Qiw2QkFBNkI2RixLQUFLLEVBQUdYLFdBQVVsRiw4QkFBOEI7QUFDdkY7QUFBQSxRQUNGLEtBQUs7QUFDSCxjQUFJLENBQUN3QixLQUFLdEIsdUJBQXVCMkYsS0FBSyxFQUFHWCxXQUFVaEYsd0JBQXdCO0FBQzNFLGNBQUksQ0FBQ3NCLEtBQUtyQix3QkFBeUIrRSxXQUFVL0UsMEJBQTBCO0FBQ3ZFLGNBQUksQ0FBQ3FCLEtBQUt4Qiw2QkFBNkI2RixLQUFLLEVBQUdYLFdBQVVsRiw4QkFBOEI7QUFDdkY7QUFBQSxRQUNGLEtBQUs7QUFDSCxjQUFJLENBQUN3QixLQUFLcEIsMEJBQTBCeUYsS0FBSyxFQUFHWCxXQUFVOUUsMkJBQTJCO0FBQ2pGLGNBQUlvQixLQUFLcEIsNkJBQTZCLHNDQUFzQyxDQUFDb0IsS0FBS3hCLDZCQUE2QjZGLEtBQUssR0FBRztBQUNySFgsc0JBQVVsRiw4QkFBOEI7QUFBQSxVQUMxQztBQUNBO0FBQUEsUUFDRjtBQUNFO0FBQUEsTUFDSjtBQUNBK0Ysa0JBQVlOLGFBQWFqRSxLQUFLbEMsMkJBQTJCLHVCQUF1QjtBQUNoRixVQUFJeUcsVUFBV2IsV0FBVTVGLDRCQUE0QnlHO0FBR3JELFVBQUksQ0FBQ3ZFLEtBQUtoQyxxQkFBcUJxRyxLQUFLLEVBQUdYLFdBQVUxRixzQkFBc0I7QUFDdkUsVUFBSSxDQUFDZ0MsS0FBSy9CLCtCQUErQm9HLEtBQUssRUFBR1gsV0FBVXpGLGdDQUFnQztBQUMzRixVQUFJLENBQUMrQixLQUFLOUIsdUJBQXVCbUcsS0FBSyxFQUFHWCxXQUFVeEYsd0JBQXdCO0FBQzNFLFVBQUksQ0FBQzhCLEtBQUs3QiwwQkFBMEJrRyxLQUFLLEVBQUdYLFdBQVV2RiwyQkFBMkI7QUFDakZvRyxrQkFBWU4sYUFBYWpFLEtBQUszQiwrQkFBK0IscUJBQXFCO0FBQ2xGLFVBQUlrRyxVQUFXYixXQUFVckYsZ0NBQWdDa0c7QUFBQUEsSUFDM0Q7QUFFQTVJLGNBQVUrSCxTQUFTO0FBQ25CLFdBQU9lLE9BQU9DLEtBQUtoQixTQUFTLEVBQUVZLFdBQVc7QUFBQSxFQUMzQztBQUVFLFFBQU1LLGVBQWUsT0FBT3ZGLE1BQU07QUFDaENBLE1BQUV3RixlQUFlO0FBQ2pCLFVBQU1DLFVBQVVwQixhQUFhLGNBQWM7QUFDM0MsUUFBSW9CLFNBQVM7QUFDWCxVQUFJO0FBQ0YsY0FBTUMsU0FBUyxJQUFJQyxTQUFTO0FBQzVCTixlQUFPTyxRQUFRbEosUUFBUSxFQUFFbUosUUFBUSxDQUFDLENBQUN2QyxLQUFLckQsS0FBSyxNQUFNO0FBQ2pELGNBQUlBLGlCQUFpQjhFLE1BQU07QUFDekJXLG1CQUFPSSxPQUFPeEMsS0FBS3JELEtBQUs7QUFBQSxVQUMxQixXQUFXOEYsTUFBTUMsUUFBUS9GLEtBQUssR0FBRztBQUMvQkEsa0JBQU00RixRQUFRLENBQUNJLE1BQU1QLE9BQU9JLE9BQU8sR0FBR3hDLEdBQUcsTUFBTTJDLENBQUMsQ0FBQztBQUFBLFVBQ25ELFdBQVdoRyxPQUFPO0FBQ2hCeUYsbUJBQU9JLE9BQU94QyxLQUFLckQsS0FBSztBQUFBLFVBQzFCO0FBQUEsUUFDRixDQUFDO0FBa0JERSxrQkFBVTBGLFFBQVEsQ0FBQ0ssS0FBS3hFLE1BQU07QUFDNUIsY0FBSXdFLElBQUk1RixNQUFNO0FBQ1pvRixtQkFBT0ksT0FBTywwQkFBMEJJLElBQUk1RixJQUFJO0FBQ2hEb0YsbUJBQU9JO0FBQUFBLGNBQ0w7QUFBQSxjQUNBSSxJQUFJN0YsaUJBQWlCLFlBQVlxQixJQUFJLENBQUM7QUFBQSxZQUN4QztBQUFBLFVBQ0Y7QUFBQSxRQUNGLENBQUM7QUFFRCxjQUFNaEIsV0FBVyxNQUFNcEgsSUFBSTZNO0FBQUFBLFVBQ3pCO0FBQUE7QUFBQSxVQUVBVDtBQUFBQSxVQUNBO0FBQUEsWUFDRVUsU0FBUztBQUFBLGNBQ1AsZ0JBQWdCO0FBQUEsWUFDbEI7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUVBeEsseUJBQWlCLENBQUN5SyxTQUFTQSxPQUFPLENBQUM7QUFDbkNySyx1QkFBZTtBQUFBLFVBQ2JHLE1BQU07QUFBQSxVQUNORCxTQUFTO0FBQUEsVUFDVEQsWUFBWTtBQUFBLFFBQ2QsQ0FBQztBQUNEakIscUJBQWEsS0FBSztBQUNsQjJCLG9CQUFZO0FBQUEsVUFDVkMsU0FBUztBQUFBLFVBQ1RDLGdCQUFnQjtBQUFBLFVBQ2hCQyxpQkFBaUI7QUFBQSxVQUNqQkMsZ0JBQWdCO0FBQUEsVUFDaEJDLHdCQUF3QjtBQUFBLFVBQ3hCQyxtQkFBbUI7QUFBQSxVQUNuQkMsbUJBQW1CO0FBQUEsVUFDbkJDLHFCQUFxQjtBQUFBLFVBQ3JCQyxrQkFBa0I7QUFBQSxVQUNsQkMsa0JBQWtCO0FBQUEsVUFDbEJDLDBCQUEwQjtBQUFBLFVBQzFCQyx1QkFBdUI7QUFBQSxVQUN2QkMsdUJBQXVCO0FBQUEsVUFDdkJDLG1CQUFtQjtBQUFBLFVBQ25CQyxpQkFBaUI7QUFBQSxVQUNqQkMsdUJBQXVCO0FBQUEsVUFDdkJDLG9CQUFvQjtBQUFBLFVBQ3BCQyxpQkFBaUI7QUFBQSxVQUNqQkMsdUJBQXVCO0FBQUEsVUFDdkJDLGdCQUFnQjtBQUFBLFVBQ2hCQyw0QkFBNEI7QUFBQSxVQUM1QkMseUJBQXlCO0FBQUEsVUFDekJFLG9CQUFvQjtBQUFBLFVBQ3BCRCx5QkFBeUI7QUFBQSxVQUN6QkUsaUJBQWlCO0FBQUEsVUFDakJDLHdCQUF3QjtBQUFBLFVBQ3hCQywyQkFBMkI7QUFBQSxVQUMzQkMsNkJBQTZCO0FBQUEsVUFDN0JDLHNCQUFzQjtBQUFBLFVBQ3RCOEgsa0JBQWtCO0FBQUEsVUFDbEIzSCw0QkFBNEI7QUFBQSxVQUM1QkMscUJBQXFCO0FBQUEsVUFDckJDLCtCQUErQjtBQUFBLFVBQy9CQyx1QkFBdUI7QUFBQSxVQUN2QkMsMEJBQTBCO0FBQUEsVUFDMUJFLCtCQUErQjtBQUFBLFVBQy9CUix1QkFBdUI7QUFBQSxVQUN2QkMsMkJBQTJCO0FBQUEsVUFDM0JRLDBCQUEwQjtBQUFBLFVBQzFCQywwQkFBMEI7QUFBQSxVQUMxQkMsNkJBQTZCO0FBQUEsVUFDN0JDLDJCQUEyQjtBQUFBLFVBQzNCQyx1QkFBdUI7QUFBQSxVQUN2QkMseUJBQXlCO0FBQUEsVUFDekJDLDBCQUEwQjtBQUFBLFVBQzFCQyw2QkFBNkI7QUFBQSxVQUM3QkMsd0JBQXdCO0FBQUEsUUFDMUIsQ0FBQztBQUFBLE1BQ0gsU0FBU21CLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sMkJBQTJCQSxLQUFLO0FBQzlDN0UsdUJBQWU7QUFBQSxVQUNiRyxNQUFNO0FBQUEsVUFDTkQsU0FDRTJFLE9BQU9ILFVBQVVFLE1BQU0xRSxXQUFXO0FBQUEsVUFDcENELFlBQVk7QUFBQSxRQUNkLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFtRUYsUUFBTXNLLGVBQWUsT0FBT3ZHLE1BQU07QUFDaENBLE1BQUV3RixlQUFlO0FBQ2pCLFFBQUk7QUFDRixZQUFNRSxTQUFTLElBQUlDLFNBQVM7QUFFNUIsWUFBTSxFQUFFakcsd0JBQXdCLEdBQUc4RyxLQUFLLElBQUk3RztBQUc1QzBGLGFBQU9PLFFBQVFZLElBQUksRUFBRVgsUUFBUSxDQUFDLENBQUN2QyxLQUFLckQsS0FBSyxNQUFNO0FBQzdDLFlBQUlBLE1BQU95RixRQUFPSSxPQUFPeEMsS0FBS3JELEtBQUs7QUFBQSxNQUNyQyxDQUFDO0FBR0QsWUFBTXdHLG1CQUFtQjtBQUFBLFFBQ3ZCO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUFvQjtBQUd0QkEsdUJBQWlCWixRQUFRLENBQUM5QixVQUFVO0FBQ2xDLFlBQUlwRSxlQUFlb0UsS0FBSyxhQUFhZ0IsTUFBTTtBQUN6Q1csaUJBQU9JLE9BQU8vQixPQUFPcEUsZUFBZW9FLEtBQUssQ0FBQztBQUFBLFFBQzVDO0FBQUEsTUFDRixDQUFDO0FBR0QsVUFBSTVELGFBQWE0RixNQUFNQyxRQUFRN0YsU0FBUyxHQUFHO0FBQ3pDQSxrQkFBVTBGLFFBQVEsQ0FBQ0ssS0FBS3hFLE1BQU07QUFDNUIsY0FBSXdFLElBQUk1RixnQkFBZ0J5RSxNQUFNO0FBQzVCVyxtQkFBT0ksT0FBTywwQkFBMEJJLElBQUk1RixJQUFJO0FBQ2hEb0YsbUJBQU9JO0FBQUFBLGNBQ0w7QUFBQTtBQUFBLGNBQ0FJLElBQUk3RixpQkFBaUIsWUFBWXFCLElBQUksQ0FBQztBQUFBLFlBQ3hDO0FBQUEsVUFDRjtBQUFBLFFBQ0YsQ0FBQztBQUFBLE1BQ0g7QUFFQSxZQUFNcEksSUFBSW9OO0FBQUFBLFFBQ1Isb0NBQW9Dakwsd0JBQXdCa0gsR0FBRztBQUFBLFFBQy9EK0M7QUFBQUEsUUFDQSxFQUFFVSxTQUFTLEVBQUUsZ0JBQWdCLHNCQUFzQixFQUFFO0FBQUEsTUFDdkQ7QUFFQWhMLHlCQUFtQixLQUFLO0FBQ3hCUSx1QkFBaUIsQ0FBQ3lLLFNBQVNBLE9BQU8sQ0FBQztBQUNuQ3JLLHFCQUFlO0FBQUEsUUFDYkcsTUFBTTtBQUFBLFFBQ05ELFNBQVM7QUFBQSxRQUNURCxZQUFZO0FBQUEsTUFDZCxDQUFDO0FBQUEsSUFDSCxTQUFTNEUsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUNoRDdFLHFCQUFlO0FBQUEsUUFDYkcsTUFBTTtBQUFBLFFBQ05ELFNBQVMyRSxPQUFPSCxVQUFVRSxNQUFNMUUsV0FBVztBQUFBLFFBQzNDRCxZQUFZO0FBQUEsTUFDZCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFRSxRQUFNMEssVUFBVTtBQUFBLElBQ2QsRUFBRXJELEtBQUssTUFBTXNELFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUV0RCxLQUFLLFdBQVdzRCxRQUFRLGdCQUFnQjtBQUFBLElBQzFDLEVBQUN0RCxLQUFLLGtCQUFrQnNELFFBQVEsaUJBQWdCO0FBQUEsSUFDaEQsRUFBRXRELEtBQUssMkJBQTJCc0QsUUFBUSxnQkFBZ0I7QUFBQSxJQUMxRCxFQUFFdEQsS0FBSyxzQkFBc0JzRCxRQUFRLHFCQUFxQjtBQUFBLElBQzFELEVBQUV0RCxLQUFLLGtCQUFrQnNELFFBQVEsaUJBQWlCO0FBQUEsSUFDbEQsRUFBRXRELEtBQUssMEJBQTBCc0QsUUFBUSx5QkFBeUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUlsRSxFQUFFdEQsS0FBSyxVQUFVc0QsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQyxRQUFNQyxvQkFBb0J0TSxNQUFNaUg7QUFBQUEsSUFBTyxDQUFDakgsV0FDdENBLE9BQU1zSSxVQUFVaUUsWUFBWSxFQUFFbEQsU0FBUy9JLFdBQVdpTSxZQUFZLENBQUM7QUFBQSxFQUNqRTtBQUVBLFFBQU1yRCx3QkFBd0IsT0FBT3NELFdBQVc7QUFDOUMsUUFBSTtBQUNGLFlBQU1yRyxXQUFXLE1BQU1wSCxJQUFJcUg7QUFBQUEsUUFDekIsdUNBQXVDb0csTUFBTTtBQUFBLE1BQy9DO0FBQ0F6TCwwQkFBb0JvRixTQUFTRSxNQUFNbkcsU0FBUztBQUM1Q1MseUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTMkYsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUFBLElBQ2xEO0FBQUEsRUFDRjtBQUVBLFFBQU1tRyxtQkFBbUJBLENBQUNoSCxNQUFNO0FBQzlCLFVBQU0sRUFBRW9FLE1BQU1qRCxNQUFNLElBQUluQixFQUFFRTtBQUMxQixVQUFNSSxPQUFPYSxNQUFNLENBQUM7QUFFcEIsUUFBSWIsTUFBTTtBQUNSM0Qsa0JBQVksQ0FBQzBKLFVBQVU7QUFBQSxRQUNyQixHQUFHQTtBQUFBQSxRQUNILENBQUNqQyxJQUFJLEdBQUc5RDtBQUFBQTtBQUFBQSxRQUNSLENBQUMsR0FBRzhELElBQUksVUFBVSxHQUFHaEQsSUFBSUMsZ0JBQWdCZixJQUFJO0FBQUE7QUFBQSxNQUMvQyxFQUFFO0FBQUEsSUFDSjtBQUFBLEVBQ0Y7QUFFQSxRQUFNa0Qsd0JBQXdCLE9BQU91RCxXQUFXO0FBQzlDLFFBQUk7QUFDRixZQUFNckcsV0FBVyxNQUFNcEgsSUFBSXFIO0FBQUFBLFFBQ3pCLHVDQUF1Q29HLE1BQU07QUFBQSxNQUMvQztBQUNBLFlBQU10TSxhQUFZaUcsVUFBVUUsTUFBTW5HO0FBQ2xDLFlBQU13TSxzQkFBc0J4TSxZQUFXc0Qsa0JBQWtCLElBQUlpRSxJQUFJLENBQUNoQyxPQUFPO0FBQUEsUUFDdkUyQyxLQUFLM0MsRUFBRTJDO0FBQUFBLFFBQ1BMLFlBQVl0QyxHQUFHcUMsVUFBVUMsY0FBYztBQUFBLFFBQ3ZDQyxRQUFRdkMsR0FBR3dDLFdBQVc7QUFBQSxNQUN4QixFQUFFO0FBQ0YvRiw2QkFBdUJ3SyxrQkFBa0I7QUFFekNySCx3QkFBa0I7QUFBQSxRQUNoQmhELFNBQVNuQyxZQUFXbUMsU0FBUytGLE9BQU87QUFBQSxRQUNwQzVFLGdCQUFnQnRELFlBQVdzRCxnQkFBZ0JpRSxJQUFJLENBQUNoQyxNQUFNQSxFQUFFMkMsR0FBRyxLQUFLO0FBQUEsUUFDaEU5RixnQkFBZ0JwQyxZQUFXb0Msa0JBQWtCO0FBQUEsUUFDN0NDLGlCQUFpQnJDLFlBQVdxQyxtQkFBbUI7QUFBQSxRQUMvQ0Usd0JBQXdCdkMsWUFBV3VDLDBCQUEwQjtBQUFBLFFBQzdERCxnQkFBZ0J0QyxZQUFXc0Msa0JBQWtCO0FBQUEsUUFDN0NFLG1CQUFtQnhDLFlBQVd3QyxxQkFBcUI7QUFBQSxRQUNuREMsbUJBQW1CekMsWUFBV3lDLHFCQUFxQjtBQUFBLFFBQ25EQyxxQkFBcUIxQyxZQUFXMEMsdUJBQXVCO0FBQUEsUUFDdkRDLGtCQUFrQjNDLFlBQVcyQyxvQkFBb0I7QUFBQSxRQUNqREMsa0JBQWtCNUMsWUFBVzRDLG9CQUFvQjtBQUFBLFFBQ2pEQywwQkFBMEI3QyxZQUFXNkMsNEJBQTRCO0FBQUEsUUFDakVDLHVCQUF1QjlDLFlBQVc4Qyx5QkFBeUI7QUFBQSxRQUMzREMsdUJBQXVCL0MsWUFBVytDLHlCQUF5QjtBQUFBLFFBQzNEQyxtQkFBbUJoRCxZQUFXZ0QscUJBQXFCO0FBQUEsUUFDbkRDLGlCQUFpQmpELFlBQVdpRCxtQkFBbUI7QUFBQSxRQUMvQ0MsdUJBQXVCbEQsWUFBV2tELHlCQUF5QjtBQUFBLFFBQzNEQyxvQkFBb0JuRCxZQUFXbUQsc0JBQXNCO0FBQUEsUUFDckRDLGlCQUFpQnBELFlBQVdvRCxtQkFBbUI7QUFBQSxRQUMvQ0MsdUJBQXVCckQsWUFBV3FELHlCQUF5QjtBQUFBLFFBQzNERSw0QkFBNEJ2RCxZQUFXdUQ7QUFBQUEsUUFDdkNHLG9CQUFvQjFELFlBQVcwRCxzQkFBc0I7QUFBQSxRQUNyREQseUJBQXlCekQsWUFBV3lELDJCQUEyQjtBQUFBLFFBQy9ERCx5QkFBeUJ4RCxZQUFXd0QsMkJBQTJCO0FBQUEsUUFDL0RHLGlCQUFpQjNELFlBQVcyRCxtQkFBbUI7QUFBQSxRQUMvQ0Msd0JBQXdCNUQsWUFBVzRELDBCQUEwQjtBQUFBLFFBQzdEQywyQkFBMkI3RCxZQUFXNkQsNkJBQTZCO0FBQUEsUUFDbkVDLDZCQUNFOUQsWUFBVzhELCtCQUErQjtBQUFBLFFBQzVDQyxzQkFBc0IvRCxZQUFXK0Qsd0JBQXdCO0FBQUEsUUFDekQ4SCxrQkFBa0I3TCxZQUFXNkwsb0JBQW9CO0FBQUEsUUFDakQzSCw0QkFBNEJsRSxZQUFXa0UsOEJBQThCO0FBQUEsUUFDckVDLHFCQUFxQm5FLFlBQVdtRSx1QkFBdUI7QUFBQSxRQUN2REMsK0JBQ0VwRSxZQUFXb0UsaUNBQWlDO0FBQUEsUUFDOUNDLHVCQUF1QnJFLFlBQVdxRSx5QkFBeUI7QUFBQSxRQUMzREMsMEJBQTBCdEUsWUFBV3NFLDRCQUE0QjtBQUFBLFFBQ2pFRSwrQkFDRXhFLFlBQVd3RSxpQ0FBaUM7QUFBQSxRQUM5Q1AsMkJBQTJCakUsV0FBVWlFLDZCQUE2QjtBQUFBLFFBQ2xFUSwwQkFBMEJ6RSxXQUFVeUUsNEJBQTRCO0FBQUEsUUFDaEVDLDBCQUEwQjFFLFdBQVUwRSw0QkFBNEI7QUFBQSxRQUNoRUMsNkJBQ0UzRSxZQUFXMkUsK0JBQStCO0FBQUEsUUFDNUNDLDJCQUEyQjVFLFlBQVc0RSw2QkFBNkI7QUFBQSxRQUNuRUMsdUJBQXVCN0UsWUFBVzZFLHlCQUF5QjtBQUFBLFFBQzNEQyx5QkFBeUI5RSxZQUFXOEUsMkJBQTJCO0FBQUEsUUFDL0RDLDBCQUEwQi9FLFlBQVcrRSw0QkFBNEI7QUFBQSxRQUNqRUMsNkJBQ0VoRixZQUFXZ0YsK0JBQStCO0FBQUEsUUFDNUNDLHdCQUF3QmpGLFlBQVdpRiwwQkFBMEI7QUFBQSxNQUMvRCxDQUFDO0FBQ0RVO0FBQUFBLFNBQ0czRixZQUFXaUYsMEJBQTBCLElBQUlzQyxJQUFJLENBQUNrRixPQUFPO0FBQUEsVUFDcEQ3RyxlQUFlNkcsRUFBRTdHO0FBQUFBLFVBQ2pCQyxNQUFNO0FBQUE7QUFBQSxVQUNOQyxTQUFTMkcsRUFBRUM7QUFBQUE7QUFBQUEsVUFDWEMsYUFBYUYsRUFBRUM7QUFBQUE7QUFBQUEsUUFDakIsRUFBRTtBQUFBLE1BQ0o7QUFFQXpMLGdDQUEwQmpCLFVBQVM7QUFDbkNXLHlCQUFtQixJQUFJO0FBQ3ZCbUIsZ0JBQVUsQ0FBQyxDQUFDO0FBQUEsSUFDZCxTQUFTc0UsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUFBLElBQ2xEO0FBQUEsRUFDRjtBQUNBLFFBQU13RyxvQkFBb0JBLENBQUNySCxNQUFNO0FBQy9CLFVBQU0sRUFBRW9FLE1BQU1uRSxNQUFNLElBQUlELEVBQUVFO0FBQzFCTixzQkFBa0IsQ0FBQ29FLGNBQWM7QUFBQSxNQUMvQixHQUFHQTtBQUFBQSxNQUNILENBQUNJLElBQUksR0FBR25FO0FBQUFBLElBQ1YsRUFBRTtBQUNGMUQsY0FBVSxDQUFDeUgsY0FBYztBQUFBLE1BQ3ZCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0ksSUFBSSxHQUFHO0FBQUEsSUFDVixFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU1rRCx3QkFBd0IsWUFBWTtBQUN4QyxRQUFJak0sa0JBQWtCO0FBQ3BCLFVBQUk7QUFDRixjQUFNL0IsSUFBSWlPO0FBQUFBLFVBQ1IsMENBQTBDbE0saUJBQWlCc0gsR0FBRztBQUFBLFFBQ2hFO0FBRUEzRyx1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUNEUCx5QkFBaUIsQ0FBQ3lLLFNBQVNBLE9BQU8sQ0FBQztBQUNuQ25MLDJCQUFtQixLQUFLO0FBQ3hCSSw0QkFBb0IsSUFBSTtBQUFBLE1BQzFCLFNBQVN1RixPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUFBLE1BQ2xEO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLG1DQUNFLGlDQUFDLFNBQ0M7QUFBQSwyQkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLDZCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsNkJBQTZCZDtBQUFBQSxVQUM3QixZQUFZO0FBQUE7QUFBQSxRQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUVtQjtBQUFBLE1BRW5CO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFNaEUsWUFBWUk7QUFBQUEsVUFDbEIsV0FBV0osWUFBWUU7QUFBQUEsVUFDdkIsU0FBU0YsWUFBWUc7QUFBQUEsVUFDckIsU0FBUyxNQUNQRixlQUFlLENBQUNxSyxVQUFVLEVBQUUsR0FBR0EsTUFBTXBLLFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxRQUw3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNRztBQUFBLE1BR0gsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGFBQ1Y7QUFBQSxpQ0FBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFXO0FBQUEsVUFDZCx1QkFBQyxTQUFJLFdBQVUsNENBRWI7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsMEJBQXlCLHlCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRDtBQUFBLFlBRWhEO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNO0FBQ2JqQiwrQkFBYSxJQUFJO0FBQ2pCdUIsNEJBQVUsQ0FBQyxDQUFDO0FBQUEsZ0JBQ2Q7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBQXVHO0FBQUE7QUFBQSxjQUxuSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRQTtBQUFBLGVBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLGFBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdCQTtBQUFBLFFBQ0M1QixnQkFBZ0J1SyxTQUFTLEtBQUssQ0FBQzNKLFlBQzlCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixlQUFlaUk7QUFBQUEsWUFDZixNQUFNM0osYUFBYWMsZ0JBQWdCa0YsVUFBVTtBQUFBLFlBQzdDO0FBQUEsWUFDQSxpQkFBZ0I7QUFBQSxZQUNoQixrQkFBa0I7QUFBQTtBQUFBLFVBTnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1vQyxJQUdwQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0M7QUFBQSxZQUNBLFNBQVNsRixlQUFldUssVUFBVTtBQUFBLFlBQ2xDLE1BQUs7QUFBQTtBQUFBLFVBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR3VCO0FBQUEsV0EvQjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQ0E7QUFBQSxTQWpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0RBO0FBQUEsSUFDQSx1QkFBQyxTQUFNLFdBQVduSyxXQUFXLFNBQVMsTUFBTUMsYUFBYSxLQUFLLEdBQzVELGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSx3Q0FBdUMsNkJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVU7QUFBQSxVQUNWLFFBQU87QUFBQSxVQUNQLFVBQVV1SztBQUFBQSxVQUNWLFNBQVE7QUFBQSxVQUNSLFlBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGdCQUNoRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVcscUNBQXFDckwsVUFBVXNOLE1BQU07QUFBQSxrQkFDaEUsYUFBWTtBQUFBLGtCQUNaO0FBQUEsa0JBQ0EsT0FBTzlLLFNBQVNFLFdBQVc2SztBQUFBQSxrQkFDM0IsVUFBVSxDQUFDeEgsVUFBVTtBQUNuQnRELGdDQUFZLENBQUMwSixVQUFVO0FBQUEsc0JBQ3JCLEdBQUdBO0FBQUFBLHNCQUNIekosU0FBU3FEO0FBQUFBLHNCQUNUbEMsZ0JBQWdCO0FBQUEsb0JBQ2xCLEVBQUU7QUFFRiwwQkFBTTJKLFdBQVc3TCxXQUNkMkYsT0FBTyxDQUFDeEIsTUFBTUEsRUFBRXBELFNBQVMrRixRQUFRMUMsS0FBSyxFQUN0QytCLElBQUksQ0FBQ2hDLE9BQU87QUFBQSxzQkFDWDJDLEtBQUszQyxFQUFFMkM7QUFBQUEsc0JBQ1BMLFlBQVl0QyxFQUFFcUMsVUFBVUM7QUFBQUEsc0JBQ3hCQyxRQUFRdkMsRUFBRXdDO0FBQUFBLG9CQUNaLEVBQUU7QUFFSi9GLDJDQUF1QmlMLFFBQVE7QUFBQSxrQkFDakM7QUFBQSxrQkFDQSxjQUFjLENBQUNDLE9BQU9DLFdBQ3BCQSxRQUFRQyxVQUNKZixZQUFZLEVBQ2JsRCxTQUFTK0QsTUFBTWIsWUFBWSxDQUFDO0FBQUEsa0JBR2hDZixnQkFBTStCO0FBQUFBLG9CQUNMLElBQUlDO0FBQUFBLHNCQUNGbE0sV0FDRzJGLE9BQU8sQ0FBQ3hCLE1BQU1BLEVBQUVwRCxXQUFXb0QsRUFBRXBELFFBQVFpRyxXQUFXb0MsS0FBSyxDQUFDLEVBQ3REakQsSUFBSSxDQUFDaEMsTUFBTSxDQUFDQSxFQUFFcEQsUUFBUStGLEtBQUszQyxFQUFFcEQsT0FBTyxDQUFDO0FBQUEsb0JBQzFDLEVBQUVvTCxPQUFPO0FBQUEsa0JBQ1gsRUFBRWhHO0FBQUFBLG9CQUFJLENBQUNpRyxTQUNMLHVCQUFDLE9BQU8sUUFBUCxFQUE2QixPQUFPQSxLQUFLdEYsS0FDdkNzRixlQUFLcEYsYUFEWW9GLEtBQUt0RixLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQXRDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0F1Q0E7QUFBQSxjQUNDckcsT0FBT00sV0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCTixpQkFBT00sV0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUQ7QUFBQSxpQkE3QzdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0NBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGdCQUM1Qyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTDtBQUFBLGtCQUNBLGFBQVk7QUFBQSxrQkFDWixXQUFXLHFDQUFxQzFDLFVBQVVzTixNQUFNO0FBQUEsa0JBQ2hFLE9BQU85SyxTQUFTcUI7QUFBQUEsa0JBQ2hCLFVBQVUsQ0FBQ21LLDBCQUEwQjtBQUNuQ3ZMLGdDQUFZLENBQUMwSixVQUFVO0FBQUEsc0JBQ3JCLEdBQUdBO0FBQUFBLHNCQUNIdEksZ0JBQWdCbUs7QUFBQUEsb0JBQ2xCLEVBQUU7QUFBQSxrQkFDSjtBQUFBLGtCQUNBLGNBQWMsQ0FBQ1AsT0FBT0MsV0FDcEJBLFFBQVFyRSxPQUFPdUQsWUFBWSxFQUFFbEQsU0FBUytELE1BQU1iLFlBQVksQ0FBQztBQUFBLGtCQUcxRHRLLDhCQUFvQndGLElBQUksQ0FBQ21HLE9BQU87QUFDL0IsMEJBQU1DLFFBQVE7QUFDZCx3QkFBSUQsR0FBRzdGLGNBQWM2RixHQUFHN0YsZUFBZTtBQUNyQzhGLDRCQUFNQyxLQUFLRixHQUFHN0YsVUFBVTtBQUMxQix3QkFBSTZGLEdBQUc1RixVQUFVNEYsR0FBRzVGLFdBQVc7QUFDN0I2Riw0QkFBTUMsS0FBSyxXQUFXRixHQUFHNUYsTUFBTSxFQUFFO0FBQ25DLDJCQUNFLHVCQUFDLE9BQU8sUUFBUCxFQUEyQixPQUFPNEYsR0FBR3hGLEtBQ25DeUYsZ0JBQU1qRixLQUFLLEtBQUssS0FEQ2dGLEdBQUd4RixLQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBRUosQ0FBQztBQUFBO0FBQUEsZ0JBM0JIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQTRCQTtBQUFBLGNBRUNyRyxPQUFPeUIsa0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWekIsaUJBQU95QixrQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBckNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdUNBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQWU7QUFBQTtBQUFBLG9CQUVGLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUE7QUFBQTtBQUFBLGdCQUp4RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVyxxQ0FBcUM3RCxVQUFVc04sTUFBTTtBQUFBLGtCQUNoRSxhQUFZO0FBQUEsa0JBQ1osdUJBQXVCO0FBQUEsa0JBQ3ZCO0FBQUEsa0JBQ0EsTUFBSztBQUFBLGtCQUNMLGNBQWMsQ0FBQ0csT0FBT0MsV0FDcEJBLE9BQU9DLFNBQVNmLFlBQVksRUFBRWxELFNBQVMrRCxNQUFNYixZQUFZLENBQUM7QUFBQSxrQkFFNUQsT0FBT3BLLFVBQVV1QiwyQkFBMkJ3SjtBQUFBQSxrQkFDNUMsVUFBVSxDQUFDeEgsVUFDVDZELGlCQUFpQiwyQkFBMkI3RCxLQUFLO0FBQUEsa0JBR2xELFdBQUMsWUFBWSxlQUFlLFVBQVUsRUFBRStCO0FBQUFBLG9CQUFJLENBQUNzRyxZQUM1Qyx1QkFBQyxPQUFPLFFBQVAsRUFBNEIsT0FBT0EsU0FDakNBLHFCQURpQkEsU0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFsQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBbUJBO0FBQUEsY0FDQ2hNLE9BQU8yQiwyQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1YzQixpQkFBTzJCLDJCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkE5Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQ0E7QUFBQSxZQUVDdkIsU0FBU3VCLDRCQUE0QixjQUNwQyx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxlQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBVTtBQUFBO0FBQUEsc0JBRVE7QUFBQSxzQkFDMUIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUM7QUFBQTtBQUFBO0FBQUEsa0JBTG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVcscUNBQXFDL0QsVUFBVXNOLE1BQU07QUFBQSxvQkFDaEUsYUFBWTtBQUFBLG9CQUNaLHVCQUF1QjtBQUFBLG9CQUN2QjtBQUFBLG9CQUNBLE1BQUs7QUFBQSxvQkFDTCxjQUFjLENBQUNHLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKVSxTQUFTLEVBQ1R6QixZQUFZLEVBQ1psRCxTQUFTK0QsTUFBTWIsWUFBWSxDQUFDO0FBQUEsb0JBRWpDLE9BQU9wSyxVQUFVSyxrQkFBa0IwSztBQUFBQSxvQkFDbkMsVUFBVSxDQUFDeEgsVUFDVDZELGlCQUFpQixrQkFBa0I3RCxLQUFLO0FBQUEsb0JBR3pDMUYsZ0JBQU15SDtBQUFBQSxzQkFBSSxDQUFDaUcsU0FDVix1QkFBQyxPQUFPLFFBQVAsRUFBNkIsT0FBT0EsS0FBS3RGLEtBQ3ZDc0YsZUFBS3BGLGFBRFlvRixLQUFLdEYsS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUE7QUFBQSxrQkFyQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQXNCQTtBQUFBLGdCQUNDckcsT0FBT1Msa0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWVCxpQkFBT1Msa0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQW5DSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFDQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxzQkFFRix1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFKL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPTCxTQUFTb0I7QUFBQUEsb0JBQ2hCLFVBQVVxRztBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxxQkFBcUJqSyxVQUFVc04sTUFBTTtBQUFBO0FBQUEsa0JBUmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRNkc7QUFBQSxnQkFFNUdsTCxPQUFPd0IseUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWeEIsaUJBQU93Qix5QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0JBO0FBQUEsaUJBN0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOERBO0FBQUEsWUFFRHBCLFNBQVN1Qiw0QkFBNEIsaUJBQ3BDLHVCQUFDLFNBQUksV0FBVSxrQkFFYjtBQUFBLHFDQUFDLFNBQUksV0FBVSw0REFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSx5REFBd0Qsb0NBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLHNCQUMvQyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUEseUJBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU92QixTQUFTRztBQUFBQSx3QkFDaEIsVUFBVXNIO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPZ0o7QUFBQSxvQkFFL0k3SCxPQUFPTyxrQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZQLGlCQUFPTyxrQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBa0JBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxzQkFDakQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnQztBQUFBLHlCQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPSCxTQUFTTTtBQUFBQSx3QkFDaEIsVUFBVW1IO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPZ0o7QUFBQSxvQkFFL0k3SCxPQUFPVSwwQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZWLGlCQUFPVSwwQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBa0JBO0FBQUEscUJBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBdUNBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLE1BQUs7QUFBQSx3QkFDTCxjQUFjLENBQUMySyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmYsWUFBWSxFQUNabEQsU0FBUytELE1BQU1iLFlBQVksQ0FBQztBQUFBLHdCQUVqQyxPQUNFcEssU0FBUzZCLCtCQUErQmtKO0FBQUFBLHdCQUUxQyxVQUFVLENBQUN4SCxVQUNUNkQ7QUFBQUEsMEJBQ0U7QUFBQSwwQkFDQTdEO0FBQUFBLHdCQUNGO0FBQUEsd0JBR0QsV0FBQyxVQUFVLFVBQVUsT0FBTyxFQUFFK0I7QUFBQUEsMEJBQUksQ0FBQ3dHLFFBQ2xDLHVCQUFDLE9BQU8sUUFBUCxFQUF3QixPQUFPQSxLQUM3QkEsaUJBRGlCQSxLQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsd0JBQ0Q7QUFBQTtBQUFBLHNCQXhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBeUJBO0FBQUEsb0JBQ0NsTSxPQUFPaUMsK0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWakMsaUJBQU9pQywrQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBakNKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBbUNBO0FBQUEsa0JBRUM3QixTQUFTNkIsZ0NBQWdDLFdBQ3hDLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyxnREFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxXQUFVO0FBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLE9BQU9uQztBQUFBQSx3QkFDUCxVQUFVLENBQUM0RCxNQUNUM0Qsc0JBQXNCMkQsRUFBRUUsT0FBT0QsS0FBSztBQUFBO0FBQUEsc0JBTnhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPRztBQUFBLHVCQVhMO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBYUE7QUFBQSxxQkFwREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFzREE7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MscUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU92RCxTQUFTSTtBQUFBQSx3QkFDaEIsVUFBVXFIO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPZ0o7QUFBQSxvQkFFL0k3SCxPQUFPUSxtQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZSLGlCQUFPUSxtQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBa0JBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDZCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUNFSixTQUFTYSx3QkFDTCxJQUFJa0wsS0FBSy9MLFNBQVNhLHFCQUFxQixFQUNwQ21MLFlBQVksRUFDWkMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUNmO0FBQUEsd0JBRU4sVUFBVXhFO0FBQUFBLHdCQUNWLFdBQVU7QUFBQTtBQUFBLHNCQVhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFXZ0o7QUFBQSx1QkFmbEo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFpQkE7QUFBQSxxQkFyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFzQ0E7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsOEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsTUFBSztBQUFBLHdCQUNMLGNBQWMsQ0FBQ3dELE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKZixZQUFZLEVBQ1psRCxTQUFTK0QsTUFBTWIsWUFBWSxDQUFDO0FBQUEsd0JBRWpDLE9BQU9wSyxTQUFTWSw0QkFBNEJtSztBQUFBQSx3QkFDNUMsVUFBVSxDQUFDeEgsVUFDVDZELGlCQUFpQiw0QkFBNEI3RCxLQUFLO0FBQUEsd0JBR25ELFdBQUMsV0FBVyxhQUFhLFNBQVMsVUFBVSxFQUFFK0I7QUFBQUEsMEJBQzdDLENBQUM0RyxXQUNDLHVCQUFDLE9BQU8sUUFBUCxFQUEyQixPQUFPQSxRQUNoQ0Esb0JBRGlCQSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsd0JBRUo7QUFBQTtBQUFBLHNCQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBc0JBO0FBQUEsdUJBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBMkJBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHNCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLE1BQUs7QUFBQSx3QkFDTCxjQUFjLENBQUNqQixPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmYsWUFBWSxFQUNabEQsU0FBUytELE1BQU1iLFlBQVksQ0FBQztBQUFBLHdCQUVqQyxPQUFPcEssU0FBU1csb0JBQW9Cb0s7QUFBQUEsd0JBQ3BDLFVBQVUsQ0FBQ3hILFVBQ1Q2RCxpQkFBaUIsb0JBQW9CN0QsS0FBSztBQUFBLHdCQUczQyxXQUFDLFFBQVEsUUFBUSxFQUFFK0I7QUFBQUEsMEJBQUksQ0FBQzZHLE1BQ3ZCLHVCQUFDLE9BQU8sUUFBUCxFQUFzQixPQUFPQSxHQUMzQkEsZUFEaUJBLEdBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSx3QkFDRDtBQUFBO0FBQUEsc0JBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFvQkE7QUFBQSx1QkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF5QkE7QUFBQSxxQkF0REY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF1REE7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLG9CQUN0RCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdDO0FBQUEsdUJBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsTUFBSztBQUFBLHNCQUNMLE9BQU9uTSxTQUFTTztBQUFBQSxzQkFDaEIsVUFBVWtIO0FBQUFBLHNCQUNWLGFBQVk7QUFBQSxzQkFDWjtBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPa0c7QUFBQSxrQkFFakc3SCxPQUFPVyxxQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZYLGlCQUFPVyxxQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0JBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHVCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPUCxTQUFTZTtBQUFBQSx3QkFDaEIsVUFBVTBHO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWixXQUFVO0FBQUE7QUFBQSxzQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTWtHO0FBQUEsdUJBVnBHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBWUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MscUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU96SCxTQUFTZ0I7QUFBQUEsd0JBQ2hCLFVBQVV5RztBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1osV0FBVTtBQUFBO0FBQUEsc0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1rRztBQUFBLHVCQVZwRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVlBO0FBQUEscUJBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBMkJBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHFCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLE1BQUs7QUFBQSx3QkFDTCxjQUFjLENBQUN3RCxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmYsWUFBWSxFQUNabEQsU0FBUytELE1BQU1iLFlBQVksQ0FBQztBQUFBLHdCQUVqQyxPQUFPcEssU0FBU21CLG1CQUFtQjRKO0FBQUFBLHdCQUNuQyxVQUFVLENBQUN4SCxVQUNUNkQsaUJBQWlCLG1CQUFtQjdELEtBQUs7QUFBQSx3QkFHMUMsV0FBQyxhQUFhLGVBQWUsWUFBWSxFQUFFK0I7QUFBQUEsMEJBQzFDLENBQUM4RyxVQUNDLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPQSxPQUMvQkEsbUJBRGlCQSxPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsd0JBRUo7QUFBQTtBQUFBLHNCQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBc0JBO0FBQUEsdUJBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBMkJBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHdCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPcE0sU0FBU2tCO0FBQUFBLHdCQUNoQixVQUFVdUc7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVU7QUFBQTtBQUFBLHNCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNa0c7QUFBQSx1QkFWcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFZQTtBQUFBLHFCQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTBDQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsc0JBQ3RELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQSx5QkFEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT3pILFNBQVNRO0FBQUFBLHdCQUNoQixVQUFVaUg7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsV0FBVTtBQUFBO0FBQUEsc0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU9rRztBQUFBLG9CQUVqRzdILE9BQU9ZLHFCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVlosaUJBQU9ZLHFCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFrQkE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsMkJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9SLFNBQVNpQjtBQUFBQSx3QkFDaEIsVUFBVXdHO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWixXQUFVO0FBQUE7QUFBQSxzQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTWtHO0FBQUEsdUJBVnBHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBWUE7QUFBQSxxQkFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFpQ0E7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsMkJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsTUFBSztBQUFBLHdCQUNMLGNBQWMsQ0FBQ3dELE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKZixZQUFZLEVBQ1psRCxTQUFTK0QsTUFBTWIsWUFBWSxDQUFDO0FBQUEsd0JBRWpDLE9BQU9wSyxTQUFTYyx5QkFBeUJpSztBQUFBQSx3QkFDekMsVUFBVSxDQUFDeEgsVUFDVDZELGlCQUFpQix5QkFBeUI3RCxLQUFLO0FBQUEsd0JBR2hELFdBQUMsVUFBVSxPQUFPLEVBQUUrQjtBQUFBQSwwQkFBSSxDQUFDK0csV0FDeEIsdUJBQUMsT0FBTyxRQUFQLEVBQTJCLE9BQU9BLFFBQ2hDQSxvQkFEaUJBLFFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSx3QkFDRDtBQUFBO0FBQUEsc0JBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFvQkE7QUFBQSx1QkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF5QkE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0Msc0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9yTSxTQUFTc0I7QUFBQUEsd0JBQ2hCLFVBQVVtRztBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1osV0FBVTtBQUFBO0FBQUEsc0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1rRztBQUFBLHVCQVZwRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVlBO0FBQUEscUJBdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBd0NBO0FBQUEsbUJBeFhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeVhBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUseURBQXdELDZCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxzQkFDL0MsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnQztBQUFBLHlCQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPekgsU0FBU1M7QUFBQUEsd0JBQ2hCLFVBQVVnSDtBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxXQUFVO0FBQUE7QUFBQSxzQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT2tHO0FBQUEsb0JBRWpHN0gsT0FBT2EsdUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWYixpQkFBT2EsdUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWtCQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsc0JBQ25ELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQSx5QkFEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT1QsU0FBU1U7QUFBQUEsd0JBQ2hCLFVBQVUrRztBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxXQUFVO0FBQUE7QUFBQSxzQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT2tHO0FBQUEsb0JBRWpHN0gsT0FBT2Msb0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWZCxpQkFBT2Msb0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWtCQTtBQUFBLHFCQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXVDQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsb0JBQ2hELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQSx1QkFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxNQUFLO0FBQUEsc0JBQ0wsVUFBVTRKO0FBQUFBLHNCQUNWLFFBQU87QUFBQSxzQkFDUDtBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNa0c7QUFBQSxrQkFFakcxSyxPQUFPOEIsbUJBQ0osdUJBQUMsT0FBRSxXQUFVLDZCQUNWOUIsaUJBQU84QixtQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBRUgxQixTQUFTMEIsbUJBQ1IsdUJBQUMsUUFBSyxJQUFJMUIsU0FBUzBCLGlCQUFpQixVQUFRLE1BQzFDO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLEtBQUsxQixTQUFTc007QUFBQUEsc0JBQ2QsS0FBSTtBQUFBLHNCQUNKLFdBQVU7QUFBQTtBQUFBLG9CQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFHMkQsS0FKN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBLHFCQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTJCQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsc0JBQy9DLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQSx5QkFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsVUFBVWhDO0FBQUFBLHdCQUNWLFFBQU87QUFBQSx3QkFDUDtBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNa0c7QUFBQSxvQkFFakcxSyxPQUFPK0IsMEJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWL0IsaUJBQU8rQiwwQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBRUQzQixTQUFTMkIsMEJBQ1IsdUJBQUMsUUFBSyxJQUFJM0IsU0FBUzJCLHdCQUF3QixVQUFRLE1BQ2pEO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLEtBQUszQixTQUFTdU07QUFBQUEsd0JBQ2QsS0FBSTtBQUFBLHdCQUNKLFdBQVU7QUFBQTtBQUFBLHNCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFHMkQsS0FKN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFNQTtBQUFBLHVCQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQTJCQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsc0JBQzNDO0FBQUEsc0JBQ25CLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQSx5QkFGbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsVUFBVWpDO0FBQUFBLHdCQUNWLFFBQU87QUFBQSx3QkFDUDtBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNa0c7QUFBQSxvQkFFakcxSyxPQUFPZ0MsNkJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWaEMsaUJBQU9nQyw2QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBRUQ1QixTQUFTNEIsNkJBQ1I7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsSUFBSTVCLFNBQVM0QjtBQUFBQSx3QkFDYixVQUFRO0FBQUEsd0JBRVI7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsS0FBSzVCLFNBQVN3TTtBQUFBQSw0QkFDZCxLQUFJO0FBQUEsNEJBQ0osV0FBVTtBQUFBO0FBQUEsMEJBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUcyRDtBQUFBO0FBQUEsc0JBUDdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFTQTtBQUFBLHVCQTVCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQThCQTtBQUFBLHFCQTNERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTREQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEseUNBQUMsUUFBRyxXQUFVLDhCQUE2QixvQ0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNDL0ksVUFBVTZCO0FBQUFBLG9CQUFJLENBQUNrRSxLQUFLbEYsVUFDbkI7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBRUMsV0FBVTtBQUFBLHdCQUdWO0FBQUEsaURBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUE7QUFBQSw4QkFBQztBQUFBO0FBQUEsZ0NBQ0MsTUFBSztBQUFBLGdDQUNMLGFBQVk7QUFBQSxnQ0FDWixPQUFPa0YsSUFBSTdGO0FBQUFBLGdDQUNYLFVBQVUsQ0FBQ0wsTUFDVGUseUJBQXlCQyxPQUFPaEIsQ0FBQztBQUFBLGdDQUVuQyxXQUFVO0FBQUE7QUFBQSw4QkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBTzhEO0FBQUEsNEJBRTlEO0FBQUEsOEJBQUM7QUFBQTtBQUFBLGdDQUNDLE1BQUs7QUFBQSxnQ0FDTCxNQUFLO0FBQUEsZ0NBQ0wsVUFBVSxDQUFDQSxNQUNUa0IseUJBQXlCRixPQUFPaEIsQ0FBQztBQUFBLGdDQUVuQyxRQUFPO0FBQUEsZ0NBQ1AsV0FBVTtBQUFBO0FBQUEsOEJBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQU8wRDtBQUFBLDRCQUUxRDtBQUFBLDhCQUFDO0FBQUE7QUFBQSxnQ0FDQyxNQUFLO0FBQUEsZ0NBQ0wsU0FBUyxNQUFNdUIsZUFBZVAsS0FBSztBQUFBLGdDQUNuQyxXQUFVO0FBQUEsZ0NBRVYsaUNBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUFVO0FBQUE7QUFBQSw4QkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBTUE7QUFBQSwrQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0EwQkE7QUFBQSwwQkFHQ2tGLElBQUkzRixXQUNILHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLEtBQUsyRixJQUFJM0Y7QUFBQUEsOEJBQ1QsS0FBSzJGLElBQUk3RjtBQUFBQSw4QkFDVCxXQUFVO0FBQUE7QUFBQSw0QkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBR3NELEtBSnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBTUE7QUFBQTtBQUFBO0FBQUEsc0JBeENHVztBQUFBQSxzQkFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQTJDQTtBQUFBLGtCQUNEO0FBQUEsa0JBRUQ7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLFNBQVNNO0FBQUFBLHNCQUNULFdBQVU7QUFBQSxzQkFBK0U7QUFBQTtBQUFBLG9CQUgzRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTUE7QUFBQSxxQkF6REY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkEwREE7QUFBQSxtQkF2TUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF3TUE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSw0REFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSx5REFBd0Qsa0NBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsMkNBRWIsaUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLG9DQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBR0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLGFBQVk7QUFBQSxzQkFDWjtBQUFBLHNCQUNBLE9BQU81RSxTQUFTOEIsd0JBQXdCaUo7QUFBQUEsc0JBQ3hDLFVBQVUsQ0FBQ3hILFVBQVU7QUFFbkJ0RCxvQ0FBWSxDQUFDMEosVUFBVTtBQUFBLDBCQUNyQixHQUFHQTtBQUFBQSwwQkFDSDdILHNCQUFzQnlCO0FBQUFBLDBCQUN0QlQsMEJBQTBCO0FBQUEsMEJBQzFCTiwwQkFBMEI7QUFBQSwwQkFDMUJDLDBCQUEwQjtBQUFBLDBCQUMxQkMsNkJBQTZCO0FBQUEsMEJBQzdCQywyQkFBMkI7QUFBQSwwQkFDM0JDLHVCQUF1QjtBQUFBLDBCQUN2QkMseUJBQXlCO0FBQUEsd0JBQzNCLEVBQUU7QUFBQSxzQkFDSjtBQUFBLHNCQUNBLGNBQWMsQ0FBQ29JLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKZixZQUFZLEVBQ1psRCxTQUFTK0QsTUFBTWIsWUFBWSxDQUFDO0FBQUEsc0JBR2hDO0FBQUEsd0JBQ0M7QUFBQSx3QkFDQTtBQUFBLHdCQUNBO0FBQUEsd0JBQ0E7QUFBQSx3QkFDQTtBQUFBLHNCQUFPLEVBQ1A5RTtBQUFBQSx3QkFBSSxDQUFDbUgsUUFDTCx1QkFBQyxPQUFPLFFBQVAsRUFBd0IsT0FBT0EsS0FDN0JBLGlCQURpQkEsS0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHNCQUNEO0FBQUE7QUFBQSxvQkFuQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQW9DQTtBQUFBLGtCQUNDN00sT0FBT2tDLHdCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmxDLGlCQUFPa0Msd0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUdEOUIsU0FBUzhCLHlCQUF5QixXQUNqQyxtQ0FDRTtBQUFBLDJDQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsNkNBQUMsV0FBTSxXQUFVLGdEQUErQywwQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFdBQVU7QUFBQSwwQkFDVixhQUFZO0FBQUEsMEJBQ1o7QUFBQSwwQkFDQSxPQUNFOUIsU0FBUzhDLDRCQUE0QmlJO0FBQUFBLDBCQUV2QyxVQUFVLENBQUN4SCxVQUNUdEQsWUFBWSxDQUFDMEosVUFBVTtBQUFBLDRCQUNyQixHQUFHQTtBQUFBQSw0QkFDSDdHLDBCQUEwQlM7QUFBQUEsMEJBQzVCLEVBQUU7QUFBQSwwQkFFSixjQUFjLENBQUMwSCxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmYsWUFBWSxFQUNabEQsU0FBUytELE1BQU1iLFlBQVksQ0FBQztBQUFBLDBCQUdoQztBQUFBLDRCQUNDO0FBQUEsNEJBQ0E7QUFBQSw0QkFDQTtBQUFBLDRCQUNBO0FBQUEsNEJBQ0E7QUFBQSwwQkFBa0MsRUFDbEM5RTtBQUFBQSw0QkFBSSxDQUFDb0gsUUFDTCx1QkFBQyxPQUFPLFFBQVAsRUFBd0IsT0FBT0EsS0FDN0JBLGlCQURpQkEsS0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FFQTtBQUFBLDBCQUNEO0FBQUE7QUFBQSx3QkE3Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQThCQTtBQUFBLHNCQUNDOU0sT0FBT2tELDRCQUNaLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmxELGlCQUFPa0QsNEJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQXRDRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQXdDQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsNkNBQUMsV0FBTSxXQUFVLGdEQUErQyx1QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxNQUFLO0FBQUEsMEJBQ0wsT0FBTzlDLFNBQVMwQztBQUFBQSwwQkFDaEIsVUFBVStFO0FBQUFBLDBCQUNWLGFBQVk7QUFBQSwwQkFDWixXQUFVO0FBQUE7QUFBQSx3QkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTThJO0FBQUEsc0JBRTVJN0gsT0FBTzhDLCtCQUNiLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjlDLGlCQUFPOEMsK0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQWZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBaUJBO0FBQUEsdUJBM0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBNERBO0FBQUEsa0JBSUQsQ0FBQyxpQkFBaUIsVUFBVSxFQUFFd0U7QUFBQUEsb0JBQzdCbEgsU0FBUzhCO0FBQUFBLGtCQUNYLEtBQ0UsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLDZCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLE1BQUs7QUFBQSwwQkFDTCxPQUFPOUIsU0FBU3dDO0FBQUFBLDBCQUNoQixVQUFVaUY7QUFBQUEsMEJBQ1YsYUFBWTtBQUFBLDBCQUNaLFdBQVU7QUFBQTtBQUFBLHdCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFNOEk7QUFBQSxzQkFFN0k3SCxPQUFPNEMsNEJBQ1osdUJBQUMsT0FBRSxXQUFVLDZCQUNWNUMsaUJBQU80Qyw0QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBZkU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFpQkE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDZDQUFDLFdBQU0sV0FBVSxnREFBK0MsNkJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsTUFBSztBQUFBLDBCQUNMLE9BQU94QyxTQUFTeUM7QUFBQUEsMEJBQ2hCLFVBQVVnRjtBQUFBQSwwQkFDVixhQUFZO0FBQUEsMEJBQ1osV0FBVTtBQUFBO0FBQUEsd0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQU04STtBQUFBLHNCQUU3STdILE9BQU82Qyw0QkFDWix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Y3QyxpQkFBTzZDLDRCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFmRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWlCQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsNkNBQUMsV0FBTSxXQUFVLGdEQUErQyx1QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxNQUFLO0FBQUEsMEJBQ0wsT0FBT3pDLFNBQVMwQztBQUFBQSwwQkFDaEIsVUFBVStFO0FBQUFBLDBCQUNWLGFBQVk7QUFBQSwwQkFDWixXQUFVO0FBQUE7QUFBQSx3QkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTThJO0FBQUEsc0JBRTdJN0gsT0FBTzhDLCtCQUNaLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjlDLGlCQUFPOEMsK0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQWZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBaUJBO0FBQUEsdUJBdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBdURBO0FBQUEsa0JBSUQxQyxTQUFTOEIseUJBQXlCLGtCQUNqQyx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDZDQUFDLFdBQU0sV0FBVSxnREFBK0MsK0JBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsTUFBSztBQUFBLDBCQUNMLE9BQU85QixTQUFTMkM7QUFBQUEsMEJBQ2hCLFVBQVU4RTtBQUFBQSwwQkFDVixhQUFZO0FBQUEsMEJBQ1osV0FBVTtBQUFBO0FBQUEsd0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQU04STtBQUFBLHNCQUU3STdILE9BQU8rQyw2QkFDWix1QkFBQyxPQUFFLFdBQVUsNkJBQ1YvQyxpQkFBTytDLDZCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFmRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWlCQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsNkNBQUMsV0FBTSxXQUFVLGdEQUErQyx1QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxNQUFLO0FBQUEsMEJBQ0wsT0FBTzNDLFNBQVMwQztBQUFBQSwwQkFDaEIsVUFBVStFO0FBQUFBLDBCQUNWLGFBQVk7QUFBQSwwQkFDWixXQUFVO0FBQUE7QUFBQSx3QkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTThJO0FBQUEsc0JBRTdJN0gsT0FBTzhDLCtCQUNaLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjlDLGlCQUFPOEMsK0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQWZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBaUJBO0FBQUEsdUJBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBcUNBO0FBQUEsa0JBSUQxQyxTQUFTOEIseUJBQXlCLGlCQUNqQyx1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDZDQUFDLFdBQU0sV0FBVSxnREFBK0MsdUNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsTUFBSztBQUFBLDBCQUNMLE9BQU85QixTQUFTNEM7QUFBQUEsMEJBQ2hCLFVBQVU2RTtBQUFBQSwwQkFDVixhQUFZO0FBQUEsMEJBQ1osV0FBVTtBQUFBO0FBQUEsd0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQU04STtBQUFBLHNCQUU3STdILE9BQU9nRCx5QkFDWix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZoRCxpQkFBT2dELHlCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFmRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWlCQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsNkNBQUMsV0FBTSxXQUFVLGdEQUErQyx3Q0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxNQUFLO0FBQUEsMEJBQ0wsT0FBTzVDLFNBQVM2QztBQUFBQSwwQkFDaEIsVUFBVTRFO0FBQUFBLDBCQUNWLGFBQVk7QUFBQSwwQkFDWixXQUFVO0FBQUE7QUFBQSx3QkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTThJO0FBQUEsc0JBRTdJN0gsT0FBT2lELDJCQUNaLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmpELGlCQUFPaUQsMkJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQWZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBaUJBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLHVCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLE1BQUs7QUFBQSwwQkFDTCxPQUFPN0MsU0FBUzBDO0FBQUFBLDBCQUNoQixVQUFVK0U7QUFBQUEsMEJBQ1YsYUFBWTtBQUFBLDBCQUNaLFdBQVU7QUFBQTtBQUFBLHdCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFNOEk7QUFBQSxzQkFFN0k3SCxPQUFPOEMsK0JBQ1osdUJBQUMsT0FBRSxXQUFVLDZCQUNWOUMsaUJBQU84QywrQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBZkU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFpQkE7QUFBQSx1QkF0REY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF1REE7QUFBQSxrQkFJRDFDLFNBQVM4Qix5QkFBeUIsV0FDakM5QixTQUFTOEMsNkJBQ1Asc0NBQ0EsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyx1QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBTzlDLFNBQVMwQztBQUFBQSx3QkFDaEIsVUFBVStFO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWixXQUFVO0FBQUE7QUFBQSxzQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTThJO0FBQUEsb0JBRTdJN0gsT0FBTzhDLCtCQUNaLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjlDLGlCQUFPOEMsK0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQWZFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBaUJBO0FBQUEscUJBMVNOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBNFNBLEtBOVNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBK1NBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxvQkFDbEMsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQztBQUFBLHVCQUQ5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE1BQUs7QUFBQSxzQkFDTCxVQUFVNEg7QUFBQUEsc0JBQ1YsUUFBTztBQUFBLHNCQUNQO0FBQUEsc0JBQ0EsV0FBVTtBQUFBO0FBQUEsb0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU1nSztBQUFBLGtCQUUvSjFLLE9BQU9vQyw2QkFDSix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZwQyxpQkFBT29DLDZCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFFSGhDLFNBQVNnQyw2QkFDUix1QkFBQyxRQUFLLElBQUloQyxTQUFTZ0MsMkJBQTJCLFVBQVEsTUFDcEQ7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsS0FBS2hDLFNBQVMyTTtBQUFBQSxzQkFDZCxLQUFJO0FBQUEsc0JBQ0osV0FBVTtBQUFBO0FBQUEsb0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUdxRSxLQUp2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU1BO0FBQUEscUJBeEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBMEJBO0FBQUEsbUJBalZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa1ZBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUseURBQXdELDRCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHlCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPM00sU0FBU2tDO0FBQUFBLHdCQUNoQixVQUFVdUY7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVU7QUFBQTtBQUFBLHNCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNa0c7QUFBQSxvQkFFakc3SCxPQUFPc0MsdUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWdEMsaUJBQU9zQyx1QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFpQkE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsbUNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9sQyxTQUFTbUM7QUFBQUEsd0JBQ2hCLFVBQVVzRjtBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1osV0FBVTtBQUFBO0FBQUEsc0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1rRztBQUFBLG9CQUVqRzdILE9BQU91QyxpQ0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z2QyxpQkFBT3VDLGlDQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWlCQTtBQUFBLHFCQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXFDQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQywyQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT25DLFNBQVNvQztBQUFBQSx3QkFDaEIsVUFBVXFGO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWixXQUFVO0FBQUE7QUFBQSxzQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTWtHO0FBQUEsb0JBRWpHN0gsT0FBT3dDLHlCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnhDLGlCQUFPd0MseUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBaUJBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDhCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPcEMsU0FBU3FDO0FBQUFBLHdCQUNoQixVQUFVb0Y7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVU7QUFBQTtBQUFBLHNCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNa0c7QUFBQSxvQkFFakc3SCxPQUFPeUMsNEJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWekMsaUJBQU95Qyw0QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFpQkE7QUFBQSxxQkFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFxQ0E7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLG9CQUNoRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdDO0FBQUEsdUJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsTUFBSztBQUFBLHNCQUNMLFVBQVVpSTtBQUFBQSxzQkFDVixRQUFPO0FBQUEsc0JBQ1A7QUFBQSxzQkFDQSxXQUFVO0FBQUE7QUFBQSxvQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTWtHO0FBQUEsa0JBRWpHMUssT0FBTzJDLGlDQUNKLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjNDLGlCQUFPMkMsaUNBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUVIdkMsU0FBU3VDLGlDQUNSO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLElBQUl2QyxTQUFTdUM7QUFBQUEsc0JBQ2IsVUFBUTtBQUFBLHNCQUVSO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLEtBQUt2QyxTQUFTNE07QUFBQUEsMEJBQ2QsS0FBSTtBQUFBLDBCQUNKLFdBQVU7QUFBQTtBQUFBLHdCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFHMkQ7QUFBQTtBQUFBLG9CQVA3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBU0E7QUFBQSxxQkEzQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE2QkE7QUFBQSxtQkFoSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpSEE7QUFBQSxpQkE5Z0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK2dDQTtBQUFBLFlBRUQ1TSxTQUFTdUIsNEJBQTRCLGNBQ3BDLG1DQUNFO0FBQUEscUNBQUMsU0FDQztBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU87QUFBQTtBQUFBLHNCQUVELHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUpqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU92QixTQUFTd0I7QUFBQUEsb0JBQ2hCLFVBQVVpRztBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxxQkFBcUJqSyxVQUFVc04sTUFBTTtBQUFBO0FBQUEsa0JBUmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRNkc7QUFBQSxnQkFFNUdsTCxPQUFPNEIsMkJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWNUIsaUJBQU80QiwyQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0JBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBb0I7QUFBQTtBQUFBLHNCQUVWLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUpyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUVMLFVBQVU4STtBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsUUFBTztBQUFBLG9CQUNQLGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDOU0sVUFBVXNOLE1BQU07QUFBQTtBQUFBLGtCQVRsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBU2lLO0FBQUEsZ0JBRS9KbEwsT0FBTzZCLHNCQUNQLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjdCLGlCQUFPNkIsc0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVGekIsU0FBU3lCLHNCQUNMLHVCQUFDLFFBQUssSUFBSXpCLFNBQVN5QixvQkFBb0IsVUFBUSxNQUM3QztBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxLQUFLekIsU0FBUzZNO0FBQUFBLG9CQUNkLEtBQUk7QUFBQSxvQkFDSixXQUFVO0FBQUE7QUFBQSxrQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRzJELEtBSjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTUE7QUFBQSxtQkE5Qk47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQ0E7QUFBQSxjQUNBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFPO0FBQUE7QUFBQSxzQkFFSCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFKL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPN00sU0FBU29CO0FBQUFBLG9CQUNoQixVQUFVcUc7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUJBQXFCakssVUFBVXNOLE1BQU07QUFBQTtBQUFBLGtCQVJsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUTZHO0FBQUEsZ0JBRTVHbEwsT0FBT3dCLHlCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnhCLGlCQUFPd0IseUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNCQTtBQUFBLGlCQS9FRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdGQTtBQUFBLFlBR0YsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDK0Y7QUFBQTtBQUFBLGNBSDNHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBO0FBQUE7QUFBQSxRQWp6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1Ba3pDQTtBQUFBLFNBdHpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdXpDQSxLQXh6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXl6Q0E7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXM0M7QUFBQUEsUUFDWCxTQUFTLE1BQU1DLG1CQUFtQixLQUFLO0FBQUEsUUFFdkMsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QyxnQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVW1MLGNBQWMsWUFBVSxNQUM1RDtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxnQkFDaEQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLHFDQUFxQ3JNLFVBQVVzTixNQUFNO0FBQUEsa0JBQ2hFLGFBQVk7QUFBQSxrQkFDWjtBQUFBLGtCQUNBLE9BQU83SCxlQUFlL0MsV0FBVztBQUFBLGtCQUNqQyxVQUFVLENBQUNxRCxVQUFVO0FBQ25CTCxzQ0FBa0IsQ0FBQ3lHLFVBQVU7QUFBQSxzQkFDM0IsR0FBR0E7QUFBQUEsc0JBQ0h6SixTQUFTcUQ7QUFBQUEsc0JBQ1RsQyxnQkFBZ0I7QUFBQTtBQUFBLG9CQUNsQixFQUFFO0FBRUYsMEJBQU0ySixXQUFXN0wsV0FDZDJGLE9BQU8sQ0FBQ3hCLE1BQU1BLEVBQUVwRCxTQUFTK0YsUUFBUTFDLEtBQUssRUFDdEMrQixJQUFJLENBQUNoQyxPQUFPO0FBQUEsc0JBQ1gyQyxLQUFLM0MsRUFBRTJDO0FBQUFBLHNCQUNQTCxZQUFZdEMsRUFBRXFDLFVBQVVDO0FBQUFBLHNCQUN4QkMsUUFBUXZDLEVBQUV3QztBQUFBQSxvQkFDWixFQUFFO0FBRUovRiwyQ0FBdUJpTCxRQUFRO0FBQUEsa0JBQ2pDO0FBQUEsa0JBQ0EsY0FBYyxDQUFDQyxPQUFPQyxXQUNwQkEsUUFBUXJFLE9BQU91RCxZQUFZLEVBQUVsRCxTQUFTK0QsTUFBTWIsWUFBWSxDQUFDO0FBQUEsa0JBRzFEakwscUJBQ0UyRixPQUFPLENBQUN4QixNQUFNQSxFQUFFcEQsV0FBV29ELEVBQUVwRCxRQUFRaUcsV0FBV29DLEtBQUssQ0FBQyxFQUN0RGpEO0FBQUFBLG9CQUFJLENBQUNoQyxNQUNKLHVCQUFDLE9BQU8sUUFBUCxFQUFrQyxPQUFPQSxFQUFFcEQsUUFBUStGLEtBQ2pEM0MsWUFBRXBELFFBQVFpRyxhQURPN0MsRUFBRXBELFFBQVErRixLQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQWhDTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FpQ0E7QUFBQSxjQUNDckcsT0FBT00sV0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCTixpQkFBT00sV0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUQ7QUFBQSxpQkF2QzdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeUNBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGdCQUM1Qyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTDtBQUFBLGtCQUNBLGFBQVk7QUFBQSxrQkFDWixXQUFXLHFDQUFxQzFDLFVBQVVzTixNQUFNO0FBQUEsa0JBQ2hFLE9BQU83SCxlQUFlNUI7QUFBQUEsa0JBQ3RCLFVBQVUsQ0FBQ21LLDBCQUEwQjtBQUNuQ3RJLHNDQUFrQixDQUFDeUcsVUFBVTtBQUFBLHNCQUMzQixHQUFHQTtBQUFBQSxzQkFDSHRJLGdCQUFnQm1LO0FBQUFBLG9CQUNsQixFQUFFO0FBQUEsa0JBQ0o7QUFBQSxrQkFDQSxjQUFjLENBQUNQLE9BQU9DLFdBQ3BCQSxRQUFRckUsT0FBT3VELFlBQVksRUFBRWxELFNBQVMrRCxNQUFNYixZQUFZLENBQUM7QUFBQSxrQkFHMUR0Syw4QkFBb0J3RixJQUFJLENBQUNtRyxPQUFPO0FBQy9CLDBCQUFNQyxRQUFRO0FBQ2Qsd0JBQUlELEdBQUc3RixjQUFjNkYsR0FBRzdGLGVBQWU7QUFDckM4Riw0QkFBTUMsS0FBS0YsR0FBRzdGLFVBQVU7QUFDMUIsd0JBQUk2RixHQUFHNUYsVUFBVTRGLEdBQUc1RixXQUFXO0FBQzdCNkYsNEJBQU1DLEtBQUssV0FBV0YsR0FBRzVGLE1BQU0sRUFBRTtBQUNuQywyQkFDRSx1QkFBQyxPQUFPLFFBQVAsRUFBMkIsT0FBTzRGLEdBQUd4RixLQUNuQ3lGLGdCQUFNakYsS0FBSyxLQUFLLEtBRENnRixHQUFHeEYsS0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUVKLENBQUM7QUFBQTtBQUFBLGdCQTNCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0E0QkE7QUFBQSxjQUNDckcsT0FBT3lCLGtCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnpCLGlCQUFPeUIsa0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQXBDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXNDQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFlO0FBQUE7QUFBQSxvQkFFRix1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpQztBQUFBO0FBQUE7QUFBQSxnQkFKeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVcscUNBQXFDN0QsVUFBVXNOLE1BQU07QUFBQSxrQkFDaEUsYUFBWTtBQUFBLGtCQUNaLHVCQUF1QjtBQUFBLGtCQUN2QjtBQUFBLGtCQUNBLE1BQUs7QUFBQSxrQkFDTCxjQUFjLENBQUNHLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUFTZixZQUFZLEVBQUVsRCxTQUFTK0QsTUFBTWIsWUFBWSxDQUFDO0FBQUEsa0JBRTVELE9BQU9uSCxnQkFBZ0IxQiwyQkFBMkJ3SjtBQUFBQSxrQkFDbEQsVUFBVSxDQUFDeEgsVUFDVGlFLHNCQUFzQiwyQkFBMkJqRSxLQUFLO0FBQUEsa0JBR3ZELFdBQUMsWUFBWSxlQUFlLFVBQVUsRUFBRStCO0FBQUFBLG9CQUFJLENBQUNzRyxZQUM1Qyx1QkFBQyxPQUFPLFFBQVAsRUFBNEIsT0FBT0EsU0FDakNBLHFCQURpQkEsU0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFsQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBbUJBO0FBQUEsY0FDQ2hNLE9BQU8yQiwyQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1YzQixpQkFBTzJCLDJCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkE5Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQ0E7QUFBQSxZQUVDMEIsZUFBZTFCLDRCQUE0QixjQUMxQyx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxlQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBVTtBQUFBO0FBQUEsc0JBRVE7QUFBQSxzQkFDMUIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUM7QUFBQTtBQUFBO0FBQUEsa0JBTG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVcscUNBQXFDL0QsVUFBVXNOLE1BQU07QUFBQSxvQkFDaEUsYUFBWTtBQUFBLG9CQUNaLHVCQUF1QjtBQUFBLG9CQUN2QjtBQUFBLG9CQUNBLE1BQUs7QUFBQSxvQkFDTCxjQUFjLENBQUNHLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKVSxTQUFTLEVBQ1R6QixZQUFZLEVBQ1psRCxTQUFTK0QsTUFBTWIsWUFBWSxDQUFDO0FBQUEsb0JBRWpDLE9BQU9uSCxnQkFBZ0I1QyxrQkFBa0IwSztBQUFBQSxvQkFDekMsVUFBVSxDQUFDeEgsVUFDVGlFLHNCQUFzQixrQkFBa0JqRSxLQUFLO0FBQUEsb0JBRzlDMUYsZ0JBQU15SDtBQUFBQSxzQkFBSSxDQUFDaUcsU0FDVix1QkFBQyxPQUFPLFFBQVAsRUFBNkIsT0FBT0EsS0FBS3RGLEtBQ3ZDc0YsZUFBS3BGLGFBRFlvRixLQUFLdEYsS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUE7QUFBQSxrQkFyQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQXNCQTtBQUFBLGdCQUNDckcsT0FBT1Msa0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWVCxpQkFBT1Msa0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQW5DSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFDQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFPO0FBQUE7QUFBQSxzQkFFSCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFKL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPNEMsZUFBZTdCO0FBQUFBLG9CQUN0QixVQUFVdUo7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUJBQXFCbk4sVUFBVXNOLE1BQU07QUFBQTtBQUFBLGtCQVJsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUTZHO0FBQUEsZ0JBRTVHbEwsT0FBT3dCLHlCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnhCLGlCQUFPd0IseUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNCQTtBQUFBLGlCQTdERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQThEQTtBQUFBLFlBRUQ2QixlQUFlMUIsNEJBQTRCLGlCQUMxQyx1QkFBQyxTQUFJLFdBQVUsa0JBRWI7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUseURBQXdELG9DQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxzQkFDL0MsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnQztBQUFBLHlCQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPMEIsZUFBZTlDO0FBQUFBLHdCQUN0QixVQUFVd0s7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsV0FBVTtBQUFBO0FBQUEsc0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU9nSjtBQUFBLG9CQUUvSS9LLE9BQU9PLGtCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVlAsaUJBQU9PLGtCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFrQkE7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLHNCQUNqRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUEseUJBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU84QyxlQUFlM0M7QUFBQUEsd0JBQ3RCLFVBQVVxSztBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxXQUFVO0FBQUE7QUFBQSxzQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT2dKO0FBQUEsb0JBRS9JL0ssT0FBT1UsMEJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWVixpQkFBT1UsMEJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWtCQTtBQUFBLHFCQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXdDQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyw0Q0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxNQUFLO0FBQUEsd0JBQ0wsY0FBYyxDQUFDMkssT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pmLFlBQVksRUFDWmxELFNBQVMrRCxNQUFNYixZQUFZLENBQUM7QUFBQSx3QkFFakMsT0FDRW5ILGVBQWVwQiwrQkFDZmtKO0FBQUFBLHdCQUVGLFVBQVUsQ0FBQ3hILFVBQ1RpRTtBQUFBQSwwQkFDRTtBQUFBLDBCQUNBakU7QUFBQUEsd0JBQ0Y7QUFBQSx3QkFHRCxXQUFDLFVBQVUsVUFBVSxPQUFPLEVBQUUrQjtBQUFBQSwwQkFBSSxDQUFDd0csUUFDbEMsdUJBQUMsT0FBTyxRQUFQLEVBQXdCLE9BQU9BLEtBQzdCQSxpQkFEaUJBLEtBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSx3QkFDRDtBQUFBO0FBQUEsc0JBekJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkEwQkE7QUFBQSxvQkFDQ2xNLE9BQU9pQywrQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZqQyxpQkFBT2lDLCtCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFsQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFvQ0E7QUFBQSxrQkFFQ29CLGVBQWVwQixnQ0FDZCxXQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyxnREFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxXQUFVO0FBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLE9BQU9uQztBQUFBQSx3QkFDUCxVQUFVLENBQUM0RCxNQUNUM0Qsc0JBQXNCMkQsRUFBRUUsT0FBT0QsS0FBSztBQUFBO0FBQUEsc0JBTnhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPRztBQUFBLHVCQVhMO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBYUE7QUFBQSxxQkF0REo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF3REE7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MscUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9OLGVBQWU3QztBQUFBQSx3QkFDdEIsVUFBVXVLO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPZ0o7QUFBQSxvQkFFL0kvSyxPQUFPUSxtQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZSLGlCQUFPUSxtQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBa0JBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDZCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUNFNkMsZUFBZXBDLHdCQUNYLElBQUlrTCxLQUFLOUksZUFBZXBDLHFCQUFxQixFQUMxQ21MLFlBQVksRUFDWkMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUNmO0FBQUEsd0JBRU4sVUFBVXRCO0FBQUFBLHdCQUNWLFdBQVU7QUFBQTtBQUFBLHNCQVhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFXZ0o7QUFBQSx1QkFmbEo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFpQkE7QUFBQSxxQkFyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFzQ0E7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsOEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsTUFBSztBQUFBLHdCQUNMLGNBQWMsQ0FBQ00sT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pmLFlBQVksRUFDWmxELFNBQVMrRCxNQUFNYixZQUFZLENBQUM7QUFBQSx3QkFFakMsT0FDRW5ILGVBQWVyQyw0QkFBNEJtSztBQUFBQSx3QkFFN0MsVUFBVSxDQUFDeEgsVUFDVGlFO0FBQUFBLDBCQUNFO0FBQUEsMEJBQ0FqRTtBQUFBQSx3QkFDRjtBQUFBLHdCQUdELFdBQUMsV0FBVyxhQUFhLFNBQVMsVUFBVSxFQUFFK0I7QUFBQUEsMEJBQzdDLENBQUM0RyxXQUNDLHVCQUFDLE9BQU8sUUFBUCxFQUEyQixPQUFPQSxRQUNoQ0Esb0JBRGlCQSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsd0JBRUo7QUFBQTtBQUFBLHNCQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBMkJBO0FBQUEsdUJBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBZ0NBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHNCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLE1BQUs7QUFBQSx3QkFDTCxjQUFjLENBQUNqQixPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmYsWUFBWSxFQUNabEQsU0FBUytELE1BQU1iLFlBQVksQ0FBQztBQUFBLHdCQUVqQyxPQUFPbkgsZUFBZXRDLG9CQUFvQm9LO0FBQUFBLHdCQUMxQyxVQUFVLENBQUN4SCxVQUNUaUUsc0JBQXNCLG9CQUFvQmpFLEtBQUs7QUFBQSx3QkFHaEQsV0FBQyxRQUFRLFFBQVEsRUFBRStCO0FBQUFBLDBCQUFJLENBQUM2RyxNQUN2Qix1QkFBQyxPQUFPLFFBQVAsRUFBc0IsT0FBT0EsR0FDM0JBLGVBRGlCQSxHQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsd0JBQ0Q7QUFBQTtBQUFBLHNCQW5CSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBb0JBO0FBQUEsdUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBeUJBO0FBQUEscUJBM0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBNERBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxvQkFDdEQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQztBQUFBLHVCQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE1BQUs7QUFBQSxzQkFDTCxPQUFPbEosZUFBZTFDO0FBQUFBLHNCQUN0QixVQUFVb0s7QUFBQUEsc0JBQ1YsYUFBWTtBQUFBLHNCQUNaO0FBQUEsc0JBQ0EsV0FBVTtBQUFBO0FBQUEsb0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU9rRztBQUFBLGtCQUVqRy9LLE9BQU9XLHFCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVlgsaUJBQU9XLHFCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFrQkE7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsdUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU8wQyxlQUFlbEM7QUFBQUEsd0JBQ3RCLFVBQVU0SjtBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1osV0FBVTtBQUFBO0FBQUEsc0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1rRztBQUFBLHVCQVZwRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVlBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHFCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPMUgsZUFBZWpDO0FBQUFBLHdCQUN0QixVQUFVMko7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVU7QUFBQTtBQUFBLHNCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNa0c7QUFBQSx1QkFWcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFZQTtBQUFBLHFCQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTJCQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyxxQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxNQUFLO0FBQUEsd0JBQ0wsY0FBYyxDQUFDTSxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmYsWUFBWSxFQUNabEQsU0FBUytELE1BQU1iLFlBQVksQ0FBQztBQUFBLHdCQUVqQyxPQUFPbkgsZUFBZTlCLG1CQUFtQjRKO0FBQUFBLHdCQUN6QyxVQUFVLENBQUN4SCxVQUNUaUUsc0JBQXNCLG1CQUFtQmpFLEtBQUs7QUFBQSx3QkFHL0MsV0FBQyxhQUFhLGVBQWUsWUFBWSxFQUFFK0I7QUFBQUEsMEJBQzFDLENBQUM4RyxVQUNDLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPQSxPQUMvQkEsbUJBRGlCQSxPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsd0JBRUo7QUFBQTtBQUFBLHNCQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBc0JBO0FBQUEsdUJBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBMkJBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHdCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPbkosZUFBZS9CO0FBQUFBLHdCQUN0QixVQUFVeUo7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVU7QUFBQTtBQUFBLHNCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNa0c7QUFBQSx1QkFWcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFZQTtBQUFBLHFCQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTBDQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsc0JBQ3RELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQSx5QkFEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBTzFILGVBQWV6QztBQUFBQSx3QkFDdEIsVUFBVW1LO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPa0c7QUFBQSxvQkFFakcvSyxPQUFPWSxxQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZaLGlCQUFPWSxxQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBa0JBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDJCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPeUMsZUFBZWhDO0FBQUFBLHdCQUN0QixVQUFVMEo7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVU7QUFBQTtBQUFBLHNCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNa0c7QUFBQSx1QkFWcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFZQTtBQUFBLHFCQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlDQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQywyQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxNQUFLO0FBQUEsd0JBQ0wsY0FBYyxDQUFDTSxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmYsWUFBWSxFQUNabEQsU0FBUytELE1BQU1iLFlBQVksQ0FBQztBQUFBLHdCQUVqQyxPQUNFbkgsZUFBZW5DLHlCQUF5QmlLO0FBQUFBLHdCQUUxQyxVQUFVLENBQUN4SCxVQUNUaUU7QUFBQUEsMEJBQ0U7QUFBQSwwQkFDQWpFO0FBQUFBLHdCQUNGO0FBQUEsd0JBR0QsV0FBQyxVQUFVLE9BQU8sRUFBRStCO0FBQUFBLDBCQUFJLENBQUMrRyxXQUN4Qix1QkFBQyxPQUFPLFFBQVAsRUFBMkIsT0FBT0EsUUFDaENBLG9CQURpQkEsUUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLHdCQUNEO0FBQUE7QUFBQSxzQkF4Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQXlCQTtBQUFBLHVCQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQThCQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyxzQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT3BKLGVBQWUzQjtBQUFBQSx3QkFDdEIsVUFBVXFKO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWixXQUFVO0FBQUE7QUFBQSxzQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTWtHO0FBQUEsdUJBVnBHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBWUE7QUFBQSxxQkE1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE2Q0E7QUFBQSxtQkFyWUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFzWUE7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSw0REFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSx5REFBd0QsNkJBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLHNCQUMvQyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUEseUJBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU8xSCxlQUFleEM7QUFBQUEsd0JBQ3RCLFVBQVVrSztBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxXQUFVO0FBQUE7QUFBQSxzQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT2tHO0FBQUEsb0JBRWpHL0ssT0FBT2EsdUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWYixpQkFBT2EsdUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWtCQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsc0JBQ25ELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQSx5QkFEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT3dDLGVBQWV2QztBQUFBQSx3QkFDdEIsVUFBVWlLO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPa0c7QUFBQSxvQkFFakcvSyxPQUFPYyxvQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZkLGlCQUFPYyxvQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBa0JBO0FBQUEscUJBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBdUNBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxvQkFDaEQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQztBQUFBLHVCQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsTUFBSztBQUFBLHNCQUNMLE1BQUs7QUFBQSxzQkFDTCxVQUFVNEo7QUFBQUEsc0JBQ1YsUUFBTztBQUFBLHNCQUNQO0FBQUEsc0JBQ0EsV0FBVTtBQUFBO0FBQUEsb0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU1rRztBQUFBLGtCQUVoRzFLLE9BQU84QixtQkFDTCx1QkFBQyxPQUFFLFdBQVUsNkJBQ1Y5QixpQkFBTzhCLG1CQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFFSHVCLGVBQWV2QixtQkFDZCx1QkFBQyxRQUFLLElBQUl1QixlQUFldkIsaUJBQWlCLFVBQVEsTUFDaEQ7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsS0FBS3VCLGVBQWV2QjtBQUFBQSxzQkFDcEIsS0FBSTtBQUFBLHNCQUNKLFdBQVU7QUFBQTtBQUFBLG9CQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFHMkQsS0FKN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBLHFCQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTBCQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsc0JBQy9DLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQSx5QkFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsVUFBVTRJO0FBQUFBLHdCQUNWLFFBQU87QUFBQSx3QkFDUDtBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNa0c7QUFBQSxvQkFFakcxSyxPQUFPK0IsMEJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWL0IsaUJBQU8rQiwwQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBRURzQixlQUFldEIsMEJBQ2Q7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsSUFBSXNCLGVBQWV0QjtBQUFBQSx3QkFDbkIsVUFBUTtBQUFBLHdCQUVSO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLEtBQUtzQixlQUFldEI7QUFBQUEsNEJBQ3BCLEtBQUk7QUFBQSw0QkFDSixXQUFVO0FBQUE7QUFBQSwwQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBRzJEO0FBQUE7QUFBQSxzQkFQN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVNBO0FBQUEsdUJBM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBNkJBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxzQkFDM0M7QUFBQSxzQkFDbkIsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnQztBQUFBLHlCQUZsQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxVQUFVMkk7QUFBQUEsd0JBQ1YsUUFBTztBQUFBLHdCQUNQO0FBQUEsd0JBQ0EsV0FBVTtBQUFBO0FBQUEsc0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1rRztBQUFBLG9CQUVqRzFLLE9BQU9nQyw2QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZoQyxpQkFBT2dDLDZCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFRHFCLGVBQWVyQiw2QkFDZDtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxJQUFJcUIsZUFBZXJCO0FBQUFBLHdCQUNuQixVQUFRO0FBQUEsd0JBRVI7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsS0FBS3FCLGVBQWVyQjtBQUFBQSw0QkFDcEIsS0FBSTtBQUFBLDRCQUNKLFdBQVU7QUFBQTtBQUFBLDBCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFHMkQ7QUFBQTtBQUFBLHNCQVA3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBU0E7QUFBQSx1QkE1Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkE4QkE7QUFBQSxxQkE3REY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE4REE7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHlDQUFDLFFBQUcsV0FBVSw4QkFBNkIsb0NBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQzZCLFVBQVU2QjtBQUFBQSxvQkFBSSxDQUFDa0UsS0FBS2xGLFVBQ25CO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUVDLFdBQVU7QUFBQSx3QkFHVjtBQUFBLGlEQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBO0FBQUEsOEJBQUM7QUFBQTtBQUFBLGdDQUNDLE1BQUs7QUFBQSxnQ0FDTCxhQUFZO0FBQUEsZ0NBQ1osT0FBT2tGLElBQUk3RjtBQUFBQSxnQ0FDWCxVQUFVLENBQUNMLE1BQ1RlLHlCQUF5QkMsT0FBT2hCLENBQUM7QUFBQSxnQ0FFbkMsV0FBVTtBQUFBO0FBQUEsOEJBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQU84RDtBQUFBLDRCQUU5RDtBQUFBLDhCQUFDO0FBQUE7QUFBQSxnQ0FDQyxNQUFLO0FBQUEsZ0NBQ0wsTUFBSztBQUFBLGdDQUNMLFVBQVUsQ0FBQ0EsTUFDVGtCLHlCQUF5QkYsT0FBT2hCLENBQUM7QUFBQSxnQ0FFbkMsUUFBTztBQUFBLGdDQUNQLFdBQVU7QUFBQTtBQUFBLDhCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFPMEQ7QUFBQSw0QkFFMUQ7QUFBQSw4QkFBQztBQUFBO0FBQUEsZ0NBQ0MsTUFBSztBQUFBLGdDQUNMLFNBQVMsTUFBTXVCLGVBQWVQLEtBQUs7QUFBQSxnQ0FDbkMsV0FBVTtBQUFBLGdDQUVWLGlDQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FBVTtBQUFBO0FBQUEsOEJBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQU1BO0FBQUEsK0JBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBMEJBO0FBQUEsMEJBR0NrRixJQUFJM0YsV0FDSCx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxLQUFLMkYsSUFBSTNGO0FBQUFBLDhCQUNULEtBQUsyRixJQUFJN0Y7QUFBQUEsOEJBQ1QsV0FBVTtBQUFBO0FBQUEsNEJBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUdzRCxLQUp4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQU1BO0FBQUE7QUFBQTtBQUFBLHNCQXhDR1c7QUFBQUEsc0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkEyQ0E7QUFBQSxrQkFDRDtBQUFBLGtCQUVEO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxTQUFTTTtBQUFBQSxzQkFDVCxXQUFVO0FBQUEsc0JBQStFO0FBQUE7QUFBQSxvQkFIM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU1BO0FBQUEscUJBekRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBMERBO0FBQUEsbUJBeE1GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeU1BO0FBQUEsY0E2R0EsdUJBQUMsU0FBSSxXQUFVLDREQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLHlEQUF3RCxrQ0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSwyQ0FFYixpQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxnREFBK0Msb0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFHQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsYUFBWTtBQUFBLHNCQUNaO0FBQUEsc0JBQ0EsT0FDRTNCLGVBQWVuQix3QkFBd0JpSjtBQUFBQSxzQkFFekMsVUFBVSxDQUFDeEgsVUFBVTtBQUVuQkwsMENBQWtCLENBQUN5RyxVQUFVO0FBQUEsMEJBQzNCLEdBQUdBO0FBQUFBLDBCQUNIN0gsc0JBQXNCeUI7QUFBQUEsMEJBQ3RCVCwwQkFBMEI7QUFBQSwwQkFDMUJOLDBCQUEwQjtBQUFBLDBCQUMxQkMsMEJBQTBCO0FBQUEsMEJBQzFCQyw2QkFBNkI7QUFBQSwwQkFDN0JDLDJCQUEyQjtBQUFBLDBCQUMzQkMsdUJBQXVCO0FBQUEsMEJBQ3ZCQyx5QkFBeUI7QUFBQSx3QkFDM0IsRUFBRTtBQUFBLHNCQUNKO0FBQUEsc0JBQ0EsY0FBYyxDQUFDb0ksT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pmLFlBQVksRUFDWmxELFNBQVMrRCxNQUFNYixZQUFZLENBQUM7QUFBQSxzQkFHaEM7QUFBQSx3QkFDQztBQUFBLHdCQUNBO0FBQUEsd0JBQ0E7QUFBQSx3QkFDQTtBQUFBLHdCQUNBO0FBQUEsc0JBQU8sRUFDUDlFO0FBQUFBLHdCQUFJLENBQUNtSCxRQUNMLHVCQUFDLE9BQU8sUUFBUCxFQUF3QixPQUFPQSxLQUM3QkEsaUJBRGlCQSxLQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsc0JBQ0Q7QUFBQTtBQUFBLG9CQXJDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBc0NBO0FBQUEsa0JBQ0M3TSxPQUFPa0Msd0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWbEMsaUJBQU9rQyx3QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBSURtQixlQUFlbkIseUJBQXlCLFdBQ3ZDLG1DQUNFO0FBQUEsMkNBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLDBDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsV0FBVTtBQUFBLDBCQUNWLGFBQVk7QUFBQSwwQkFDWjtBQUFBLDBCQUNBLE9BQ0VtQixlQUFlSCw0QkFDZmlJO0FBQUFBLDBCQUVGLFVBQVUsQ0FBQ3hILFVBQ1R0RCxZQUFZLENBQUMwSixVQUFVO0FBQUEsNEJBQ3JCLEdBQUdBO0FBQUFBLDRCQUNIN0csMEJBQTBCUztBQUFBQSwwQkFDNUIsRUFBRTtBQUFBLDBCQUVKLGNBQWMsQ0FBQzBILE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKZixZQUFZLEVBQ1psRCxTQUFTK0QsTUFBTWIsWUFBWSxDQUFDO0FBQUEsMEJBR2hDO0FBQUEsNEJBQ0M7QUFBQSw0QkFDQTtBQUFBLDRCQUNBO0FBQUEsNEJBQ0E7QUFBQSw0QkFDQTtBQUFBLDBCQUFrQyxFQUNsQzlFO0FBQUFBLDRCQUFJLENBQUNvSCxRQUNMLHVCQUFDLE9BQU8sUUFBUCxFQUF3QixPQUFPQSxLQUM3QkEsaUJBRGlCQSxLQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUVBO0FBQUEsMEJBQ0Q7QUFBQTtBQUFBLHdCQTlCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBK0JBO0FBQUEsc0JBQ0M5TSxPQUFPa0QsNEJBQ1osdUJBQUMsT0FBRSxXQUFVLDZCQUNWbEQsaUJBQU9rRCw0QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBdkNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBeUNBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLHVCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLE1BQUs7QUFBQSwwQkFDTCxPQUNFRyxlQUFlUDtBQUFBQSwwQkFFakIsVUFBVWlJO0FBQUFBLDBCQUNWLGFBQVk7QUFBQSwwQkFDWixXQUFVO0FBQUE7QUFBQSx3QkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBUThJO0FBQUEsc0JBRTdJL0ssT0FBTzhDLCtCQUNaLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjlDLGlCQUFPOEMsK0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQWpCRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQW1CQTtBQUFBLHVCQTlERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQStEQTtBQUFBLGtCQUlELENBQUMsaUJBQWlCLFVBQVUsRUFBRXdFO0FBQUFBLG9CQUM3QmpFLGVBQWVuQjtBQUFBQSxrQkFDakIsS0FDRSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDZDQUFDLFdBQU0sV0FBVSxnREFBK0MsNkJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsTUFBSztBQUFBLDBCQUNMLE9BQU9tQixlQUFlVDtBQUFBQSwwQkFDdEIsVUFBVW1JO0FBQUFBLDBCQUNWLGFBQVk7QUFBQSwwQkFDWixXQUFVO0FBQUE7QUFBQSx3QkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTThJO0FBQUEsc0JBRTdJL0ssT0FBTzRDLDRCQUNaLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjVDLGlCQUFPNEMsNEJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQWZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBaUJBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLDZCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLE1BQUs7QUFBQSwwQkFDTCxPQUFPUyxlQUFlUjtBQUFBQSwwQkFDdEIsVUFBVWtJO0FBQUFBLDBCQUNWLGFBQVk7QUFBQSwwQkFDWixXQUFVO0FBQUE7QUFBQSx3QkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTThJO0FBQUEsc0JBRTdJL0ssT0FBTzZDLDRCQUNaLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjdDLGlCQUFPNkMsNEJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQWZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBaUJBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLHVCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLE1BQUs7QUFBQSwwQkFDTCxPQUNFUSxlQUFlUDtBQUFBQSwwQkFFakIsVUFBVWlJO0FBQUFBLDBCQUNWLGFBQVk7QUFBQSwwQkFDWixXQUFVO0FBQUE7QUFBQSx3QkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBUThJO0FBQUEsc0JBRTdJL0ssT0FBTzhDLCtCQUNaLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjlDLGlCQUFPOEMsK0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQWpCRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQW1CQTtBQUFBLHVCQXhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXlEQTtBQUFBLGtCQUlETyxlQUFlbkIseUJBQ2Qsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLCtCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLE1BQUs7QUFBQSwwQkFDTCxPQUFPbUIsZUFBZU47QUFBQUEsMEJBQ3RCLFVBQVVnSTtBQUFBQSwwQkFDVixhQUFZO0FBQUEsMEJBQ1osV0FBVTtBQUFBO0FBQUEsd0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQU04STtBQUFBLHNCQUU3SS9LLE9BQU8rQyw2QkFDWix1QkFBQyxPQUFFLFdBQVUsNkJBQ1YvQyxpQkFBTytDLDZCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFmRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWlCQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsNkNBQUMsV0FBTSxXQUFVLGdEQUErQyx1QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxNQUFLO0FBQUEsMEJBQ0wsT0FDRU0sZUFBZVA7QUFBQUEsMEJBRWpCLFVBQVVpSTtBQUFBQSwwQkFDVixhQUFZO0FBQUEsMEJBQ1osV0FBVTtBQUFBO0FBQUEsd0JBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQVE4STtBQUFBLHNCQUU3SS9LLE9BQU84QywrQkFDWix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Y5QyxpQkFBTzhDLCtCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFqQkU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFtQkE7QUFBQSx1QkF0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF1Q0E7QUFBQSxrQkFJRE8sZUFBZW5CLHlCQUNkLGlCQUNBLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsNkNBQUMsV0FBTSxXQUFVLGdEQUErQyx1Q0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxNQUFLO0FBQUEsMEJBQ0wsT0FBT21CLGVBQWVMO0FBQUFBLDBCQUN0QixVQUFVK0g7QUFBQUEsMEJBQ1YsYUFBWTtBQUFBLDBCQUNaLFdBQVU7QUFBQTtBQUFBLHdCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFNOEk7QUFBQSxzQkFFNUkvSyxPQUFPZ0QseUJBQ2IsdUJBQUMsT0FBRSxXQUFVLDZCQUNWaEQsaUJBQU9nRCx5QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBZkU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFpQkE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDZDQUFDLFdBQU0sV0FBVSxnREFBK0Msd0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsTUFBSztBQUFBLDBCQUNMLE9BQU9LLGVBQWVKO0FBQUFBLDBCQUN0QixVQUFVOEg7QUFBQUEsMEJBQ1YsYUFBWTtBQUFBLDBCQUNaLFdBQVU7QUFBQTtBQUFBLHdCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFNOEk7QUFBQSxzQkFFN0kvSyxPQUFPaUQsMkJBQ1osdUJBQUMsT0FBRSxXQUFVLDZCQUNWakQsaUJBQU9pRCwyQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBZkU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFpQkE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDZDQUFDLFdBQU0sV0FBVSxnREFBK0MsdUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsTUFBSztBQUFBLDBCQUNMLE9BQ0VJLGVBQWVQO0FBQUFBLDBCQUVqQixVQUFVaUk7QUFBQUEsMEJBQ1YsYUFBWTtBQUFBLDBCQUNaLFdBQVU7QUFBQTtBQUFBLHdCQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFROEk7QUFBQSxzQkFFN0kvSyxPQUFPOEMsK0JBQ1osdUJBQUMsT0FBRSxXQUFVLDZCQUNWOUMsaUJBQU84QywrQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBakJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBbUJBO0FBQUEsdUJBeERGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBeURBO0FBQUEsa0JBSURPLGVBQWVuQix5QkFBeUIsV0FDdkNtQixlQUFlSCw2QkFDYixzQ0FDQSx1QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHVCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUNFRyxlQUFlUDtBQUFBQSx3QkFFakIsVUFBVWlJO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWixXQUFVO0FBQUE7QUFBQSxzQkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBUThJO0FBQUEsb0JBRTVJL0ssT0FBTzhDLCtCQUNiLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjlDLGlCQUFPOEMsK0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQWpCRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQW1CQTtBQUFBLHFCQTFUTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTRUQSxLQTlURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQStUQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsb0JBQ2xDLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQSx1QkFEOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxNQUFLO0FBQUEsc0JBQ0wsVUFBVTRIO0FBQUFBLHNCQUNWLFFBQU87QUFBQSxzQkFDUDtBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNZ0s7QUFBQSxrQkFFL0oxSyxPQUFPb0MsNkJBQ0osdUJBQUMsT0FBRSxXQUFVLDZCQUNWcEMsaUJBQU9vQyw2QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBRUhpQixlQUFlakIsNkJBQ2Q7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsSUFBSWlCLGVBQWVqQjtBQUFBQSxzQkFDbkIsVUFBUTtBQUFBLHNCQUVSO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLEtBQUtpQixlQUFlakI7QUFBQUEsMEJBQ3BCLEtBQUk7QUFBQSwwQkFDSixXQUFVO0FBQUE7QUFBQSx3QkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBR3FFO0FBQUE7QUFBQSxvQkFQdkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVNBO0FBQUEscUJBM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBNkJBO0FBQUEsbUJBcFdGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcVdBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUseURBQXdELDRCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHlCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPaUIsZUFBZWY7QUFBQUEsd0JBQ3RCLFVBQVV5STtBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1osV0FBVTtBQUFBO0FBQUEsc0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1rRztBQUFBLG9CQUVqRy9LLE9BQU9zQyx1QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z0QyxpQkFBT3NDLHVCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWlCQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyxtQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT2UsZUFBZWQ7QUFBQUEsd0JBQ3RCLFVBQVV3STtBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1osV0FBVTtBQUFBO0FBQUEsc0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1rRztBQUFBLG9CQUVqRy9LLE9BQU91QyxpQ0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z2QyxpQkFBT3VDLGlDQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWlCQTtBQUFBLHFCQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXFDQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQywyQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT2MsZUFBZWI7QUFBQUEsd0JBQ3RCLFVBQVV1STtBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1osV0FBVTtBQUFBO0FBQUEsc0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1rRztBQUFBLG9CQUVqRy9LLE9BQU93Qyx5QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z4QyxpQkFBT3dDLHlCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWlCQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyw4QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT2EsZUFBZVo7QUFBQUEsd0JBQ3RCLFVBQVVzSTtBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1osV0FBVTtBQUFBO0FBQUEsc0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1rRztBQUFBLG9CQUVqRy9LLE9BQU95Qyw0QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z6QyxpQkFBT3lDLDRCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWlCQTtBQUFBLHFCQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXFDQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsb0JBQ2hELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQSx1QkFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxNQUFLO0FBQUEsc0JBQ0wsVUFBVWlJO0FBQUFBLHNCQUNWLFFBQU87QUFBQSxzQkFDUDtBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNa0c7QUFBQSxrQkFFakcxSyxPQUFPMkMsaUNBQ0osdUJBQUMsT0FBRSxXQUFVLDZCQUNWM0MsaUJBQU8yQyxpQ0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBRUhVLGVBQWVWLGlDQUNkO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLElBQUlVLGVBQWVWO0FBQUFBLHNCQUNuQixVQUFRO0FBQUEsc0JBRVI7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsS0FBS1UsZUFBZVY7QUFBQUEsMEJBQ3BCLEtBQUk7QUFBQSwwQkFDSixXQUFVO0FBQUE7QUFBQSx3QkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBRzJEO0FBQUE7QUFBQSxvQkFQN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVNBO0FBQUEscUJBM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBNkJBO0FBQUEsbUJBaEhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUhBO0FBQUEsaUJBMXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJwQ0E7QUFBQSxZQUVEVSxlQUFlMUIsNEJBQTRCLGNBQzFDLG1DQUNFO0FBQUEscUNBQUMsU0FDQztBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU87QUFBQTtBQUFBLHNCQUVELHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUpqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU8wQixlQUFlekI7QUFBQUEsb0JBQ3RCLFVBQVVtSjtBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxxQkFBcUJuTixVQUFVc04sTUFBTTtBQUFBO0FBQUEsa0JBUmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRNkc7QUFBQSxnQkFFNUdsTCxPQUFPNEIsMkJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWNUIsaUJBQU80QiwyQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0JBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBTztBQUFBO0FBQUEsc0JBRUcsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUM7QUFBQTtBQUFBO0FBQUEsa0JBSnJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBRUwsVUFBVThJO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxRQUFPO0FBQUEsb0JBQ1AsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxxQ0FBcUM5TSxVQUFVc04sTUFBTTtBQUFBO0FBQUEsa0JBVGxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFTaUs7QUFBQSxnQkFFL0psTCxPQUFPNkIsc0JBQ1AsdUJBQUMsT0FBRSxXQUFVLDZCQUNWN0IsaUJBQU82QixzQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRUR3QixlQUFleEIsc0JBQ1o7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsSUFBSXdCLGVBQWV4QjtBQUFBQSxvQkFDbkIsVUFBUTtBQUFBLG9CQUVSO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLEtBQUt3QixlQUFleEI7QUFBQUEsd0JBQ3BCLEtBQUk7QUFBQSx3QkFDSixXQUFVO0FBQUE7QUFBQSxzQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBRzJEO0FBQUE7QUFBQSxrQkFQN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVNBO0FBQUEsbUJBakNOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbUNBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBYTtBQUFBO0FBQUEsc0JBRVQsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUM7QUFBQTtBQUFBO0FBQUEsa0JBSi9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT3dCLGVBQWU3QjtBQUFBQSxvQkFDdEIsVUFBVXVKO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLHFCQUFxQm5OLFVBQVVzTixNQUFNO0FBQUE7QUFBQSxrQkFSbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVE2RztBQUFBLGdCQUU1R2xMLE9BQU93Qix5QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z4QixpQkFBT3dCLHlCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFzQkE7QUFBQSxpQkFsRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtRkE7QUFBQSxZQUdGLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQytGO0FBQUE7QUFBQSxjQUgzRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQW43Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvN0NBO0FBQUEsYUF4N0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5N0NBO0FBQUE7QUFBQSxNQTc3Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBODdDQTtBQUFBLElBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVc3QztBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiQyw2QkFBbUIsS0FBSztBQUN4QkksOEJBQW9CLElBQUk7QUFBQSxRQUMxQjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QyxnQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0NELG9CQUNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxVQUFVLENBQUMyRSxNQUFNO0FBQ2ZBLGtCQUFFd0YsZUFBZTtBQUNqQjhCLHNDQUFzQjtBQUFBLGNBQ3hCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFNBQ0M7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFXO0FBQUE7QUFBQSx3QkFFTjtBQUFBLHdCQUNiLHVCQUFDLFVBQUssV0FBVSwwQkFDYmpNLDJCQUFpQndCLGtCQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQVE7QUFBQSx3QkFBSTtBQUFBLHdCQUNTO0FBQUEsd0JBQ3JCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWlDO0FBQUE7QUFBQTtBQUFBLG9CQVRuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBVUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWjtBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLMkk7QUFBQSxxQkFqQjdJO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBbUJBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDMkY7QUFBQTtBQUFBLGtCQUh2RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQTtBQUFBO0FBQUEsWUFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBa0NBO0FBQUEsYUF2Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlDQTtBQUFBO0FBQUEsTUFoREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBaURBO0FBQUEsT0E5MUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErMUZBLEtBaDJGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaTJGQTtBQUVKO0FBQUV2QyxHQWw3SElELFdBQVM7QUFBQW1QLEtBQVRuUDtBQW83SE4sZUFBZUE7QUFBVSxJQUFBbVA7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiU2lkZWJhciIsIk1vZGFsIiwiYXBpIiwiRGF0YVRhYmxlIiwiSW5wdXQiLCJTZWxlY3QiLCJEcm9wZG93biIsIklvTWRNb3JlIiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwiQ2lyY3VsYXJMb2FkZXIiLCJoYW5kbGVHdWFyYW50b3JQcmludCIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwiTGluayIsImZpZWxkU2l6ZSIsIklvTWRDbG9zZSIsIkJyZWFkY3J1bWIiLCJHdWFyYW50b3IiLCJfcyIsInVzZXJzIiwic2V0VXNlcnMiLCJndWFyYW50b3IiLCJzZXRHdWFyYW50b3IiLCJUYWJsZUd1YXJhbnRvciIsInNldFRhYmxlR3VhcmFudG9yIiwic2VhcmNoVGVybSIsInNldFNlYXJjaFRlcm0iLCJzaG93TW9kYWwiLCJzZXRTaG93TW9kYWwiLCJzaG93TW9kYWxEZWxldGUiLCJzZXRTaG93TW9kYWxEZWxldGUiLCJzaG93TW9kYWxVcGRhdGUiLCJzZXRTaG93TW9kYWxVcGRhdGUiLCJjdXJyZW50R3VhcmFudG9yIiwic2V0Q3VycmVudEd1YXJhbnRvciIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsImN1cnJlbnRVcGRhdGVHdWFyYW50b3IiLCJzZXRDdXJyZW50VXBkYXRlR3VhcmFudG9yIiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJlbnJvbGxtZW50Iiwic2V0RW5yb2xsbWVudCIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsInR5cGUiLCJjdXN0b21SZWxhdGlvbnNoaXAiLCJzZXRDdXN0b21SZWxhdGlvbnNoaXAiLCJlcnJvcnMiLCJzZXRFcnJvcnMiLCJmaWx0ZXJlZEVucm9sbG1lbnRzIiwic2V0RmlsdGVyZWRFbnJvbGxtZW50cyIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJ1c2VyX2lkIiwiZ3VhcmFudG9yX25hbWUiLCJndWFyYW50b3JfZW1haWwiLCJ1c2VyX2d1YXJhbnRvciIsImd1YXJhbnRvcl9waG9uZV9udW1iZXIiLCJndWFyYW50b3JfYWRkcmVzcyIsImd1YXJhbnRvcl9waW5jb2RlIiwiZ3VhcmFudG9yX2FkaGFhcl9ubyIsImd1YXJhbnRvcl9wYW5fbm8iLCJndWFyYW50b3JfZ2VuZGVyIiwiZ3VhcmFudG9yX21hcml0YWxfc3RhdHVzIiwiZ3VhcmFudG9yX2RhdGVvZmJpcnRoIiwiZ3VhcmFudG9yX25hdGlvbmFsaXR5IiwiZ3VhcmFudG9yX3ZpbGxhZ2UiLCJndWFyYW50b3JfdGFsdWsiLCJndWFyYW50b3JfZmF0aGVyX25hbWUiLCJndWFyYW50b3JfZGlzdHJpY3QiLCJndWFyYW50b3Jfc3RhdGUiLCJndWFyYW50b3JfZGVzY3JpcHRpb24iLCJlbnJvbGxtZW50X2lkcyIsImd1YXJhbnRvcl9hbHRlcm5hdGVfbnVtYmVyIiwiZ3VhcmFudG9yX3JlZmVycmVkX3R5cGUiLCJndWFyYW50b3JfZG9jdW1lbnRfbmFtZSIsImd1YXJhbnRvcl9kb2N1bWVudCIsImd1YXJhbnRvcl9waG90byIsImd1YXJhbnRvcl9wYW5fZG9jdW1lbnQiLCJndWFyYW50b3JfYWFkaGFyX2RvY3VtZW50IiwiZ3VhcmFudG9yX3JlbGF0aW9uc2hpcF90eXBlIiwiZ3VhcmFudG9yX29jY3VwYXRpb24iLCJndWFyYW50b3Jfc2VjdG9yX25hbWUiLCJndWFyYW50b3JfaW5jb21lX2RvY3VtZW50IiwiZ3VhcmFudG9yX2NvbnNlbnRfZG9jdW1lbnQiLCJndWFyYW50b3JfYmFua19uYW1lIiwiZ3VhcmFudG9yX2JhbmtfYWNjb3VudF9udW1iZXIiLCJndWFyYW50b3JfYmFua19icmFuY2giLCJndWFyYW50b3JfYmFua19pZnNjX2NvZGUiLCJndWFyYW50b3JfYmFua19wYXNzYm9vayIsImd1YXJhbnRvcl9iYW5rX3Bhc3Nib29rX3Bob3RvIiwiZ3VhcmFudG9yX2J1c3NpbmVzc190eXBlIiwiZ3VhcmFudG9yX2J1c3NpbmVzc19uYW1lIiwiZ3VhcmFudG9yX2J1c3NpbmVzc19hZGRyZXNzIiwiZ3VhcmFudG9yX3Byb2Zlc3Npb25fdHlwZSIsImd1YXJhbnRvcl9hZ3JpX3J0Y19ubyIsImd1YXJhbnRvcl9sYW5kX2hvbGRpbmdzIiwiZ3VhcmFudG9yX29jY3VwYXRpb25fc3ViIiwiZ3VhcmFudG9yX2FsbF9kb2N1bWVudF9uYW1lIiwiZ3VhcmFudG9yX2FsbF9kb2N1bWVudCIsInVwZGF0ZUZvcm1EYXRhIiwic2V0VXBkYXRlRm9ybURhdGEiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsIkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIiLCJlIiwidmFsdWUiLCJ0YXJnZXQiLCJleHRyYURvY3MiLCJzZXRFeHRyYURvY3MiLCJkb2N1bWVudF9uYW1lIiwiZmlsZSIsInByZXZpZXciLCJ1c2VFZmZlY3QiLCJmZXRjaFVzZXJzIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwiZXJyb3IiLCJjb25zb2xlIiwiaGFuZGxlRXh0cmFEb2NOYW1lQ2hhbmdlIiwiaW5kZXgiLCJ1cGRhdGVkIiwiaGFuZGxlRXh0cmFEb2NGaWxlQ2hhbmdlIiwiZmlsZXMiLCJVUkwiLCJjcmVhdGVPYmplY3RVUkwiLCJhZGROZXdEb2NGaWVsZCIsInJlbW92ZURvY0ZpZWxkIiwiZmlsdGVyIiwiXyIsImkiLCJmZXRjaEVucm9sbG1lbnREYXRhIiwiZmV0Y2hHdWFyYW50b3IiLCJpbmZvIiwiZ3VhcmFudG9ycyIsImZvcm1hdHRlZERhdGEiLCJtYXAiLCJncm91cCIsImVucm9sbG1lbnREZXRhaWxzIiwiZW5yb2xsIiwiZ3JvdXBOYW1lIiwiZ3JvdXBfaWQiLCJncm91cF9uYW1lIiwidGlja2V0IiwidGlja2V0cyIsImZpbmQiLCJ1IiwiX2lkIiwiZ3VhcmFudG9yTmFtZSIsImZ1bGxfbmFtZSIsImd1YXJhbnRvclBob25lIiwicGhvbmVfbnVtYmVyIiwiaWQiLCJndWFyYW50b3JfY29kZSIsImVucm9sbG1lbnRfc3VtbWFyeSIsImpvaW4iLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImxhYmVsIiwiaGFuZGxlVXBkYXRlTW9kYWxPcGVuIiwiaGFuZGxlRGVsZXRlTW9kYWxPcGVuIiwiZkRhdGEiLCJlbGUiLCJpbmNsdWRlcyIsInJlcGxhY2VBbGwiLCJoYW5kbGVBbnREU2VsZWN0IiwiZmllbGQiLCJwcmV2RGF0YSIsInByZXZFcnJvcnMiLCJoYW5kbGVBbnRJbnB1dERTZWxlY3QiLCJoYW5kbGVDaGFuZ2UiLCJuYW1lIiwidmFsaWRhdGVGb3JtIiwibmV3RXJyb3JzIiwicmVnZXgiLCJlbWFpbCIsInBob25lIiwicGluY29kZSIsImFkaGFhciIsInBhbiIsInZhbGlkYXRlRmlsZSIsImFsbG93ZWRUeXBlcyIsIkZpbGUiLCJzaXplIiwidHJpbSIsImxlbmd0aCIsImZpbGVFcnJvciIsInRlc3QiLCJPYmplY3QiLCJrZXlzIiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJpc3ZhbGlkIiwiZm1EYXRhIiwiRm9ybURhdGEiLCJlbnRyaWVzIiwiZm9yRWFjaCIsImFwcGVuZCIsIkFycmF5IiwiaXNBcnJheSIsInYiLCJkb2MiLCJwb3N0IiwiaGVhZGVycyIsInByZXYiLCJndWFyYW50b3JfaW5jb21lIiwiaGFuZGxlVXBkYXRlIiwicmVzdCIsInNpbmdsZUZpbGVGaWVsZHMiLCJwdXQiLCJjb2x1bW5zIiwiaGVhZGVyIiwiZmlsdGVyZWRHdWFyYW50b3IiLCJ0b0xvd2VyQ2FzZSIsInVzZXJJZCIsImhhbmRsZUZpbGVDaGFuZ2UiLCJtYXRjaGVkRW5yb2xsbWVudHMiLCJkIiwiZG9jdW1lbnRfdXJsIiwiZXhpc3RpbmdVcmwiLCJoYW5kbGVJbnB1dENoYW5nZSIsImhhbmRsZURlbGV0ZUd1YXJhbnRvciIsImRlbGV0ZSIsImhlaWdodCIsInVuZGVmaW5lZCIsImZpbHRlcmVkIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsImZyb20iLCJNYXAiLCJ2YWx1ZXMiLCJ1c2VyIiwic2VsZWN0ZWRFbnJvbGxtZW50SWRzIiwiZW4iLCJwYXJ0cyIsInB1c2giLCJyZWZUeXBlIiwidG9TdHJpbmciLCJyZWwiLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsInN0YXR1cyIsImciLCJzdGF0ZSIsIm5hdGlvbiIsImd1YXJhbnRvcl9waG90b19wcmV2aWV3IiwiZ3VhcmFudG9yX3Bhbl9kb2N1bWVudF9wcmV2aWV3IiwiZ3VhcmFudG9yX2FhZGhhcl9kb2N1bWVudF9wcmV2aWV3Iiwib2NjIiwic3ViIiwiZ3VhcmFudG9yX2luY29tZV9kb2N1bWVudF9wcmV2aWV3IiwiZ3VhcmFudG9yX2JhbmtfcGFzc2Jvb2tfcGhvdG9fcHJldmlldyIsImd1YXJhbnRvcl9kb2N1bWVudF9wcmV2aWV3IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiR3VhcmFudG9yLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgeyBJbnB1dCwgU2VsZWN0LCBEcm9wZG93biB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IElvTWRNb3JlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IGhhbmRsZUd1YXJhbnRvclByaW50IGZyb20gXCIuLi9jb21wb25lbnRzL3ByaW50Rm9ybWF0cy9HdWFyYW50b3JQcmludFwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBmaWVsZFNpemUgfSBmcm9tIFwiLi4vZGF0YS9maWVsZFNpemVcIjtcclxuaW1wb3J0IHsgSW9NZENsb3NlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuXHJcbmNvbnN0IEd1YXJhbnRvciA9ICgpID0+IHtcclxuICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZ3VhcmFudG9yLCBzZXRHdWFyYW50b3JdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtUYWJsZUd1YXJhbnRvciwgc2V0VGFibGVHdWFyYW50b3JdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXJtLCBzZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbERlbGV0ZSwgc2V0U2hvd01vZGFsRGVsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd01vZGFsVXBkYXRlLCBzZXRTaG93TW9kYWxVcGRhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50R3VhcmFudG9yLCBzZXRDdXJyZW50R3VhcmFudG9yXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2N1cnJlbnRVcGRhdGVHdWFyYW50b3IsIHNldEN1cnJlbnRVcGRhdGVHdWFyYW50b3JdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3JlbG9hZFRyaWdnZXIsIHNldFJlbG9hZFRyaWdnZXJdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW2Vucm9sbG1lbnQsIHNldEVucm9sbG1lbnRdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW2N1c3RvbVJlbGF0aW9uc2hpcCwgc2V0Q3VzdG9tUmVsYXRpb25zaGlwXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkRW5yb2xsbWVudHMsIHNldEZpbHRlcmVkRW5yb2xsbWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIHVzZXJfaWQ6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfbmFtZTogXCJcIixcclxuICAgIGd1YXJhbnRvcl9lbWFpbDogXCJcIixcclxuICAgIHVzZXJfZ3VhcmFudG9yOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX3Bob25lX251bWJlcjogXCJcIixcclxuICAgIGd1YXJhbnRvcl9hZGRyZXNzOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX3BpbmNvZGU6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfYWRoYWFyX25vOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX3Bhbl9ubzogXCJcIixcclxuICAgIGd1YXJhbnRvcl9nZW5kZXI6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfbWFyaXRhbF9zdGF0dXM6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfZGF0ZW9mYmlydGg6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfbmF0aW9uYWxpdHk6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfdmlsbGFnZTogXCJcIixcclxuICAgIGd1YXJhbnRvcl90YWx1azogXCJcIixcclxuICAgIGd1YXJhbnRvcl9mYXRoZXJfbmFtZTogXCJcIixcclxuICAgIGd1YXJhbnRvcl9kaXN0cmljdDogXCJcIixcclxuICAgIGd1YXJhbnRvcl9zdGF0ZTogXCJcIixcclxuICAgIGd1YXJhbnRvcl9kZXNjcmlwdGlvbjogXCJcIixcclxuICAgIGVucm9sbG1lbnRfaWRzOiBbXSxcclxuICAgIGd1YXJhbnRvcl9hbHRlcm5hdGVfbnVtYmVyOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX3JlZmVycmVkX3R5cGU6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfZG9jdW1lbnRfbmFtZTogXCJcIixcclxuICAgIGd1YXJhbnRvcl9kb2N1bWVudDogXCJcIixcclxuICAgIGd1YXJhbnRvcl9waG90bzogXCJcIixcclxuICAgIGd1YXJhbnRvcl9wYW5fZG9jdW1lbnQ6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfYWFkaGFyX2RvY3VtZW50OiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX3JlbGF0aW9uc2hpcF90eXBlOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX29jY3VwYXRpb246IFwiXCIsXHJcbiAgICBndWFyYW50b3Jfc2VjdG9yX25hbWU6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfaW5jb21lX2RvY3VtZW50OiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX2NvbnNlbnRfZG9jdW1lbnQ6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfYmFua19uYW1lOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX2JhbmtfYWNjb3VudF9udW1iZXI6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfYmFua19icmFuY2g6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfYmFua19pZnNjX2NvZGU6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfYmFua19wYXNzYm9vazogXCJcIixcclxuICAgIGd1YXJhbnRvcl9iYW5rX3Bhc3Nib29rX3Bob3RvOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX2J1c3NpbmVzc190eXBlOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX2J1c3NpbmVzc19uYW1lOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX2J1c3NpbmVzc19hZGRyZXNzOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX3Byb2Zlc3Npb25fdHlwZTogXCJcIixcclxuICAgIGd1YXJhbnRvcl9hZ3JpX3J0Y19ubzogXCJcIixcclxuICAgIGd1YXJhbnRvcl9sYW5kX2hvbGRpbmdzOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX29jY3VwYXRpb25fc3ViOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX2FsbF9kb2N1bWVudF9uYW1lOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX2FsbF9kb2N1bWVudDogXCJcIixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW3VwZGF0ZUZvcm1EYXRhLCBzZXRVcGRhdGVGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICB1c2VyX2lkOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX25hbWU6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfZW1haWw6IFwiXCIsXHJcbiAgICB1c2VyX2d1YXJhbnRvcjogXCJcIixcclxuICAgIGd1YXJhbnRvcl9waG9uZV9udW1iZXI6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfYWRkcmVzczogXCJcIixcclxuICAgIGd1YXJhbnRvcl9waW5jb2RlOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX2FkaGFhcl9ubzogXCJcIixcclxuICAgIGd1YXJhbnRvcl9wYW5fbm86IFwiXCIsXHJcbiAgICBndWFyYW50b3JfZ2VuZGVyOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX21hcml0YWxfc3RhdHVzOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX2RhdGVvZmJpcnRoOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX25hdGlvbmFsaXR5OiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX3ZpbGxhZ2U6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfdGFsdWs6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfZmF0aGVyX25hbWU6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfZGlzdHJpY3Q6IFwiXCIsXHJcbiAgICBndWFyYW50b3Jfc3RhdGU6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfZGVzY3JpcHRpb246IFwiXCIsXHJcbiAgICBndWFyYW50b3JfYWx0ZXJuYXRlX251bWJlcjogXCJcIixcclxuICAgIGVucm9sbG1lbnRfaWRzOiBbXSxcclxuICAgIGd1YXJhbnRvcl9yZWZlcnJlZF90eXBlOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX2RvY3VtZW50OiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX2RvY3VtZW50X25hbWU6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfcGhvdG86IFwiXCIsXHJcbiAgICBndWFyYW50b3JfcGFuX2RvY3VtZW50OiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX2FhZGhhcl9kb2N1bWVudDogXCJcIixcclxuICAgIGd1YXJhbnRvcl9yZWxhdGlvbnNoaXBfdHlwZTogXCJcIixcclxuICAgIGd1YXJhbnRvcl9vY2N1cGF0aW9uOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX3NlY3Rvcl9uYW1lOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX2luY29tZV9kb2N1bWVudDogXCJcIixcclxuICAgIGd1YXJhbnRvcl9jb25zZW50X2RvY3VtZW50OiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX2JhbmtfbmFtZTogXCJcIixcclxuICAgIGd1YXJhbnRvcl9iYW5rX2FjY291bnRfbnVtYmVyOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX2JhbmtfYnJhbmNoOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX2JhbmtfaWZzY19jb2RlOiBcIlwiLFxyXG4gICAgZ3VhcmFudG9yX2JhbmtfcGFzc2Jvb2s6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfYmFua19wYXNzYm9va19waG90bzogXCJcIixcclxuICAgIGd1YXJhbnRvcl9idXNzaW5lc3NfdHlwZTogXCJcIixcclxuICAgIGd1YXJhbnRvcl9idXNzaW5lc3NfbmFtZTogXCJcIixcclxuICAgIGd1YXJhbnRvcl9idXNzaW5lc3NfYWRkcmVzczogXCJcIixcclxuICAgIGd1YXJhbnRvcl9wcm9mZXNzaW9uX3R5cGU6IFwiXCIsXHJcbiAgICBndWFyYW50b3JfYWdyaV9ydGNfbm86IFwiXCIsXHJcbiAgICBndWFyYW50b3JfbGFuZF9ob2xkaW5nczogXCJcIixcclxuICAgIGd1YXJhbnRvcl9vY2N1cGF0aW9uX3N1YjogXCJcIixcclxuICAgIGd1YXJhbnRvcl9hbGxfZG9jdW1lbnRfbmFtZTogXCJcIixcclxuICAgIGd1YXJhbnRvcl9hbGxfZG9jdW1lbnQ6IFwiXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IEdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRTZWFyY2hUZXh0KHZhbHVlKTtcclxuICB9O1xyXG4gIGNvbnN0IFtleHRyYURvY3MsIHNldEV4dHJhRG9jc10gPSB1c2VTdGF0ZShcclxuICAgIGZvcm1EYXRhLmd1YXJhbnRvcl9hbGxfZG9jdW1lbnQgfHwgW1xyXG4gICAgICB7IGRvY3VtZW50X25hbWU6IFwiXCIsIGZpbGU6IG51bGwsIHByZXZpZXc6IFwiXCIgfSxcclxuICAgIF1cclxuICApO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFVzZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpO1xyXG5cclxuICAgICAgICBzZXRVc2VycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlciBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaFVzZXJzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICAvLyBjb25zdCBoYW5kbGVFeHRyYURvY05hbWVDaGFuZ2UgPSAoaW5kZXgsIGUpID0+IHtcclxuICAvLyAgIGNvbnN0IHVwZGF0ZWQgPSBbLi4uZXh0cmFEb2NzXTtcclxuICAvLyAgIHVwZGF0ZWRbaW5kZXhdLmRvY3VtZW50X25hbWUgPSBlLnRhcmdldC52YWx1ZTtcclxuICAvLyAgIHNldEV4dHJhRG9jcyh1cGRhdGVkKTtcclxuICAvLyAgIHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIGd1YXJhbnRvcl9hbGxfZG9jdW1lbnQ6IHVwZGF0ZWQgfSk7XHJcbiAgLy8gfTtcclxuXHJcbiAgLy8gLy8gIEV4dHJhIGRvY3MgLSBoYW5kbGUgZmlsZSB1cGxvYWRcclxuICAvLyBjb25zdCBoYW5kbGVFeHRyYURvY0ZpbGVDaGFuZ2UgPSAoaW5kZXgsIGUpID0+IHtcclxuICAvLyAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlc1swXTtcclxuICAvLyAgIGlmIChmaWxlKSB7XHJcbiAgLy8gICAgIGNvbnN0IHVwZGF0ZWQgPSBbLi4uZXh0cmFEb2NzXTtcclxuICAvLyAgICAgdXBkYXRlZFtpbmRleF0uZmlsZSA9IGZpbGU7XHJcbiAgLy8gICAgIHVwZGF0ZWRbaW5kZXhdLnByZXZpZXcgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGZpbGUpO1xyXG4gIC8vICAgICBzZXRFeHRyYURvY3ModXBkYXRlZCk7XHJcbiAgLy8gICAgIHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIGd1YXJhbnRvcl9hbGxfZG9jdW1lbnQ6IHVwZGF0ZWQgfSk7XHJcbiAgLy8gICB9XHJcbiAgLy8gfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRXh0cmFEb2NOYW1lQ2hhbmdlID0gKGluZGV4LCBlKSA9PiB7XHJcbiAgICBjb25zdCB1cGRhdGVkID0gWy4uLmV4dHJhRG9jc107XHJcbiAgICB1cGRhdGVkW2luZGV4XS5kb2N1bWVudF9uYW1lID0gZS50YXJnZXQudmFsdWU7XHJcbiAgICBzZXRFeHRyYURvY3ModXBkYXRlZCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRXh0cmFEb2NGaWxlQ2hhbmdlID0gKGluZGV4LCBlKSA9PiB7XHJcbiAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXNbMF07XHJcbiAgICBpZiAoZmlsZSkge1xyXG4gICAgICBjb25zdCB1cGRhdGVkID0gWy4uLmV4dHJhRG9jc107XHJcbiAgICAgIHVwZGF0ZWRbaW5kZXhdLmZpbGUgPSBmaWxlO1xyXG4gICAgICB1cGRhdGVkW2luZGV4XS5wcmV2aWV3ID0gVVJMLmNyZWF0ZU9iamVjdFVSTChmaWxlKTtcclxuICAgICAgc2V0RXh0cmFEb2NzKHVwZGF0ZWQpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vICBBZGQvcmVtb3ZlIGV4dHJhIGRvY3NcclxuICBjb25zdCBhZGROZXdEb2NGaWVsZCA9ICgpID0+IHtcclxuICAgIHNldEV4dHJhRG9jcyhbXHJcbiAgICAgIC4uLmV4dHJhRG9jcyxcclxuICAgICAgeyBkb2N1bWVudF9uYW1lOiBcIlwiLCBmaWxlOiBudWxsLCBwcmV2aWV3OiBcIlwiIH0sXHJcbiAgICBdKTtcclxuICB9O1xyXG5cclxuICBjb25zdCByZW1vdmVEb2NGaWVsZCA9IChpbmRleCkgPT4ge1xyXG4gICAgY29uc3QgdXBkYXRlZCA9IGV4dHJhRG9jcy5maWx0ZXIoKF8sIGkpID0+IGkgIT09IGluZGV4KTtcclxuICAgIHNldEV4dHJhRG9jcyh1cGRhdGVkKTtcclxuICAgIHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIGd1YXJhbnRvcl9hbGxfZG9jdW1lbnQ6IHVwZGF0ZWQgfSk7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoRW5yb2xsbWVudERhdGEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9lbnJvbGwtcmVwb3J0L2dldC1lbnJvbGwtcmVwb3J0YCk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEpIHtcclxuICAgICAgICAgIHNldEVucm9sbG1lbnQocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBFbnJvbGxtZW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hFbnJvbGxtZW50RGF0YSgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoR3VhcmFudG9yID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvZ3VhcmFudG9yL2dldC1ndWFyYW50b3ItaW5mb1wiKTtcclxuICAgICAgICBjb25zb2xlLmluZm8oXCJndWFyYW50b3JcIiwgcmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgICAgY29uc3QgZ3VhcmFudG9ycyA9IHJlc3BvbnNlLmRhdGE/Lmd1YXJhbnRvciB8fCBbXTtcclxuICAgICAgICBjb25zb2xlLmluZm8oXCJndWFyYW50b3JcIiwgcmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgICAgc2V0R3VhcmFudG9yKGd1YXJhbnRvcnMpO1xyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSBndWFyYW50b3JzLm1hcCgoZ3JvdXAsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICBjb25zdCBlbnJvbGxtZW50RGV0YWlscyA9IChncm91cD8uZW5yb2xsbWVudF9pZHMgfHwgW10pLm1hcChcclxuICAgICAgICAgICAgKGVucm9sbCkgPT4ge1xyXG4gICAgICAgICAgICAgIGNvbnN0IGdyb3VwTmFtZSA9IGVucm9sbD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCJOL0FcIjtcclxuICAgICAgICAgICAgICBjb25zdCB0aWNrZXQgPSBlbnJvbGw/LnRpY2tldHMgfHwgXCJOL0FcIjtcclxuICAgICAgICAgICAgICByZXR1cm4gYCR7Z3JvdXBOYW1lfSB8IFRpY2tldDogJHt0aWNrZXR9YDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICBjb25zdCBndWFyYW50b3IgPSB1c2Vycy5maW5kKCh1KSA9PiB1Ll9pZCA9PT0gZ3JvdXA/LnVzZXJfZ3VhcmFudG9yKTtcclxuICAgICAgICAgIGNvbnNvbGUuaW5mbyhcInRlc3QtdGVzdFwiLCBndWFyYW50b3IpO1xyXG4gICAgICAgICAgY29uc3QgZ3VhcmFudG9yTmFtZSA9XHJcbiAgICAgICAgICAgIGdyb3VwPy5ndWFyYW50b3JfcmVmZXJyZWRfdHlwZSA9PT0gXCJDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgPyBndWFyYW50b3I/LmZ1bGxfbmFtZSB8fCBcIk4vQVwiXHJcbiAgICAgICAgICAgICAgOiBncm91cD8uZ3VhcmFudG9yX25hbWU7XHJcblxyXG4gICAgICAgICAgY29uc3QgZ3VhcmFudG9yUGhvbmUgPVxyXG4gICAgICAgICAgICBncm91cD8uZ3VhcmFudG9yX3JlZmVycmVkX3R5cGUgPT09IFwiQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgID8gZ3VhcmFudG9yPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIlxyXG4gICAgICAgICAgICAgIDogZ3JvdXA/Lmd1YXJhbnRvcl9waG9uZV9udW1iZXI7XHJcblxyXG4gICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgX2lkOiBncm91cD8uX2lkLFxyXG4gICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICAgZ3VhcmFudG9yX2NvZGU6IGdyb3VwPy5ndWFyYW50b3JfY29kZSxcclxuICAgICAgICAgICAgdXNlcl9pZDogZ3JvdXA/LnVzZXJfaWQ/LmZ1bGxfbmFtZSxcclxuICAgICAgICAgICAgZW5yb2xsbWVudF9zdW1tYXJ5OiBlbnJvbGxtZW50RGV0YWlscy5qb2luKFwiLCBcIiksXHJcbiAgICAgICAgICAgIGd1YXJhbnRvcl9yZWZlcnJlZF90eXBlOiBncm91cD8uZ3VhcmFudG9yX3JlZmVycmVkX3R5cGUsXHJcbiAgICAgICAgICAgIGd1YXJhbnRvcl9uYW1lOiBndWFyYW50b3JOYW1lLFxyXG4gICAgICAgICAgICBndWFyYW50b3JfcGhvbmVfbnVtYmVyOiBndWFyYW50b3JQaG9uZSxcclxuICAgICAgICAgICAgZ3VhcmFudG9yX2Rlc2NyaXB0aW9uOiBncm91cD8uZ3VhcmFudG9yX2Rlc2NyaXB0aW9uLFxyXG4gICAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVXBkYXRlTW9kYWxPcGVuKGdyb3VwPy5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVkaXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZU1vZGFsT3Blbihncm91cD8uX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlR3VhcmFudG9yUHJpbnQoZ3JvdXA/Ll9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCIgdGV4dC12aW9sZXQtNjAwIFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUHJpbnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSxcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGxldCBmRGF0YSA9IGZvcm1hdHRlZERhdGEubWFwKChlbGUpID0+IHtcclxuICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgZWxlPy5ndWFyYW50b3JfYWRkcmVzcyAmJlxyXG4gICAgICAgICAgICB0eXBlb2YgZWxlLmd1YXJhbnRvcl9hZGRyZXNzID09PSBcInN0cmluZ1wiICYmXHJcbiAgICAgICAgICAgIGVsZT8uZ3VhcmFudG9yX2FkZHJlc3M/LmluY2x1ZGVzKFwiLFwiKVxyXG4gICAgICAgICAgKVxyXG4gICAgICAgICAgICBlbGUuZ3VhcmFudG9yX2FkZHJlc3MgPSBlbGUuZ3VhcmFudG9yX2FkZHJlc3MucmVwbGFjZUFsbChcIixcIiwgXCIgXCIpO1xyXG4gICAgICAgICAgcmV0dXJuIGVsZTtcclxuICAgICAgICB9KTtcclxuICAgICAgICBpZiAoIWZEYXRhKSBzZXRUYWJsZUd1YXJhbnRvcihmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgICBpZiAoIWZEYXRhKSBzZXRUYWJsZUd1YXJhbnRvcihmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgICBzZXRUYWJsZUd1YXJhbnRvcihmRGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIEd1YXJhbnRvciBkYXRhOlwiLCBlcnJvci5tZXNzYWdlKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hHdWFyYW50b3IoKTtcclxuICB9LCBbcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVBbnREU2VsZWN0ID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW2ZpZWxkXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgICBpZiAodmFsdWUgIT09IFwiT3RoZXJcIikge1xyXG4gICAgICBzZXRDdXN0b21SZWxhdGlvbnNoaXAoXCJcIik7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0RXJyb3JzKChwcmV2RXJyb3JzKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RXJyb3JzLFxyXG4gICAgICBbZmllbGRdOiBcIlwiLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlQW50SW5wdXREU2VsZWN0ID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW2ZpZWxkXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcblxyXG4gICAgc2V0RXJyb3JzKHsgLi4uZXJyb3JzLCBbZmllbGRdOiBcIlwiIH0pO1xyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldkVycm9ycykgPT4gKHtcclxuICAgICAgLi4ucHJldkVycm9ycyxcclxuICAgICAgW25hbWVdOiBcIlwiLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4vLyAgIGNvbnN0IHZhbGlkYXRlRm9ybSA9ICh0eXBlKSA9PiB7XHJcbi8vICAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuLy8gICAgIGNvbnN0IGRhdGEgPSB0eXBlID09PSBcImFkZEd1YXJhbnRvclwiID8gZm9ybURhdGEgOiB1cGRhdGVGb3JtRGF0YTtcclxuXHJcbi8vICAgICBjb25zdCByZWdleCA9IHtcclxuLy8gICAgICAgZW1haWw6IC9eW15cXHNAXStAW15cXHNAXStcXC5bXlxcc0BdKyQvLFxyXG4vLyAgICAgICBwaG9uZTogL15bNi05XVxcZHs5fSQvLFxyXG4vLyAgICAgICBwaW5jb2RlOiAvXlxcZHs2fSQvLFxyXG4vLyAgICAgICBhZGhhYXI6IC9eXFxkezEyfSQvLFxyXG4vLyAgICAgICBwYW46IC9eW0EtWl17NX1bMC05XXs0fVtBLVpdezF9JC8sXHJcbi8vICAgICB9O1xyXG5cclxuLy8gICAgIGlmICghZGF0YS51c2VyX2lkKSBuZXdFcnJvcnMudXNlcl9pZCA9IFwiQ3VzdG9tZXIgTmFtZSBpcyByZXF1aXJlZFwiO1xyXG4vLyAgICAgaWYgKCFkYXRhLmd1YXJhbnRvcl9yZWZlcnJlZF90eXBlKVxyXG4vLyAgICAgICBuZXdFcnJvcnMuZ3VhcmFudG9yX3JlZmVycmVkX3R5cGUgPSBcIlJlZmVycmVkIFR5cGUgaXMgcmVxdWlyZWRcIjtcclxuLy8gICAgIGlmICghZGF0YS5lbnJvbGxtZW50X2lkcyB8fCBkYXRhLmVucm9sbG1lbnRfaWRzLmxlbmd0aCA9PT0gMClcclxuLy8gICAgICAgbmV3RXJyb3JzLmVucm9sbG1lbnRfaWRzID0gXCJFbnJvbGxtZW50IGlzIHJlcXVpcmVkXCI7XHJcblxyXG4vLyAgICAgaWYgKGRhdGEuZ3VhcmFudG9yX3JlZmVycmVkX3R5cGUgPT09IFwiQ3VzdG9tZXJcIikge1xyXG4vLyAgICAgICBpZiAoIWRhdGEudXNlcl9ndWFyYW50b3IpXHJcbi8vICAgICAgICAgbmV3RXJyb3JzLnVzZXJfZ3VhcmFudG9yID0gXCJSZWZlcnJlZCBDdXN0b21lciBpcyByZXF1aXJlZFwiO1xyXG4vLyAgICAgfVxyXG4vLyAgICAgaWYgKGRhdGEuZ3VhcmFudG9yX3JlZmVycmVkX3R5cGUgPT09IFwiQ3VzdG9tZXJcIikge1xyXG4vLyAgICAgICBpZiAoIWRhdGEuZ3VhcmFudG9yX2Rlc2NyaXB0aW9uPy50cmltKCkpXHJcbi8vICAgICAgICAgbmV3RXJyb3JzLmd1YXJhbnRvcl9kZXNjcmlwdGlvbiA9IFwiRGVzY3JpcHRpb24gaXMgcmVxdWlyZWRcIjtcclxuLy8gICAgIH1cclxuXHJcbi8vICAgICBpZiAoZGF0YS5ndWFyYW50b3JfcmVmZXJyZWRfdHlwZSA9PT0gXCJUaGlyZCBQYXJ0eVwiKSB7XHJcbi8vICAgICAgIGlmICghZGF0YS5ndWFyYW50b3JfbmFtZT8udHJpbSgpKVxyXG4vLyAgICAgICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfbmFtZSA9IFwiR3VhcmFudG9yIE5hbWUgaXMgcmVxdWlyZWRcIjtcclxuLy8gICAgICAgaWYgKCFkYXRhLmd1YXJhbnRvcl9yZWxhdGlvbnNoaXBfdHlwZT8udHJpbSgpKVxyXG4vLyAgICAgICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfcmVsYXRpb25zaGlwX3R5cGUgPVxyXG4vLyAgICAgICAgICAgXCJHdWFyYW50b3IgUmVsYXRpb25zaGlwIEN1c3RvbWVyIGlzIHJlcXVpcmVkXCI7XHJcblxyXG4vLyAgICAgICBpZiAoIWRhdGEuZ3VhcmFudG9yX3Bob25lX251bWJlcilcclxuLy8gICAgICAgICBuZXdFcnJvcnMuZ3VhcmFudG9yX3Bob25lX251bWJlciA9IFwiUGhvbmUgTnVtYmVyIGlzIHJlcXVpcmVkXCI7XHJcbi8vICAgICAgIGVsc2UgaWYgKCFyZWdleC5waG9uZS50ZXN0KGRhdGEuZ3VhcmFudG9yX3Bob25lX251bWJlcikpXHJcbi8vICAgICAgICAgbmV3RXJyb3JzLmd1YXJhbnRvcl9waG9uZV9udW1iZXIgPSBcIkludmFsaWQgUGhvbmUgTnVtYmVyXCI7XHJcblxyXG5cclxuLy8gICAgICAgaWYgKCFkYXRhLmd1YXJhbnRvcl9lbWFpbClcclxuLy8gICAgICAgICBuZXdFcnJvcnMuZ3VhcmFudG9yX2VtYWlsID0gXCJFbWFpbCAgaXMgcmVxdWlyZWRcIjtcclxuLy8gICAgICAgZWxzZSBpZiAoIXJlZ2V4LmVtYWlsLnRlc3QoZGF0YS5ndWFyYW50b3JfZW1haWwpKVxyXG4vLyAgICAgICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfZW1haWwgPSBcIkludmFsaWQgRW1haWwgXCI7XHJcblxyXG4vLyAgICAgICBpZiAoIWRhdGEuZ3VhcmFudG9yX2FkaGFhcl9ubylcclxuLy8gICAgICAgICBuZXdFcnJvcnMuZ3VhcmFudG9yX2FkaGFhcl9ubyA9IFwiQWRoYWFyIE51bWJlciBpcyByZXF1aXJlZFwiO1xyXG4vLyAgICAgICBlbHNlIGlmICghcmVnZXguYWRoYWFyLnRlc3QoZGF0YS5ndWFyYW50b3JfYWRoYWFyX25vKSlcclxuLy8gICAgICAgICBuZXdFcnJvcnMuZ3VhcmFudG9yX2FkaGFhcl9ubyA9IFwiSW52YWxpZCBBZGhhYXIgTnVtYmVyXCI7XHJcblxyXG4vLyAgICAgICBpZiAoIWRhdGEuZ3VhcmFudG9yX3BpbmNvZGUpXHJcbi8vICAgICAgICAgbmV3RXJyb3JzLmd1YXJhbnRvcl9waW5jb2RlID0gXCJQaW5jb2RlIGlzIHJlcXVpcmVkXCI7XHJcbi8vICAgICAgIGVsc2UgaWYgKCFyZWdleC5waW5jb2RlLnRlc3QoZGF0YS5ndWFyYW50b3JfcGluY29kZSkpXHJcbi8vICAgICAgICAgbmV3RXJyb3JzLmd1YXJhbnRvcl9waW5jb2RlID0gXCJJbnZhbGlkIFBpbmNvZGVcIjtcclxuXHJcbi8vICAgICAgaWYgKCFkYXRhLmd1YXJhbnRvcl9wYW5fbm8pXHJcbi8vICAgICAgICAgbmV3RXJyb3JzLmd1YXJhbnRvcl9wYW5fbm8gPSBcIlBhbiBOdW1iZXIgaXMgcmVxdWlyZWRcIjtcclxuLy8gICAgICAgLy8gZWxzZSBpZiAoIXJlZ2V4LnBhbi50ZXN0KGRhdGEuZ3VhcmFudG9yX3Bhbl9ubykpXHJcbi8vICAgICAgIC8vICAgbmV3RXJyb3JzLmd1YXJhbnRvcl9wYW5fbm8gPSBcIkludmFsaWQgUGFuIE51bWJlclwiO1xyXG4vLyAgICAgICAgLy8gbmV3RXJyb3JzLmd1YXJhbnRvcl9wYW5fbm8gPSBcIkludmFsaWQgUEFOIGZvcm1hdFwiO1xyXG5cclxuXHJcbi8vICAgICAgICAgaWYgKCFkYXRhLmd1YXJhbnRvcl9waG90byB8fCBkYXRhLmd1YXJhbnRvcl9waG90by5sZW5ndGggPT09IDApIHtcclxuLy8gICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfcGhvdG8gPSBcIlByb2ZpbGUgUGhvdG8gaXMgcmVxdWlyZWRcIjtcclxuLy8gICB9IGVsc2UgaWYgKHR5cGVvZiBkYXRhLmd1YXJhbnRvcl9waG90byA9PT0gXCJzdHJpbmdcIikge1xyXG4vLyAgICAgLy8gaWYgaXQncyBhIFVSTCBmcm9tIERCLCBhbGxvdyBpdFxyXG4vLyAgICAgaWYgKGRhdGEuZ3VhcmFudG9yX3Bob3RvLnRyaW0oKSA9PT0gXCJcIikge1xyXG4vLyAgICAgICBuZXdFcnJvcnMuZ3VhcmFudG9yX3Bob3RvID0gXCJQcm9maWxlIFBob3RvIGlzIHJlcXVpcmVkXCI7XHJcbi8vICAgICB9XHJcbi8vICAgfSBlbHNlIGlmIChkYXRhLmd1YXJhbnRvcl9waG90byBpbnN0YW5jZW9mIEZpbGUpIHtcclxuLy8gICAgIC8vIG9wdGlvbmFsOiBmaWxlIHR5cGUgJiBzaXplIHZhbGlkYXRpb25cclxuLy8gICAgIGNvbnN0IGFsbG93ZWRUeXBlcyA9IFtcImltYWdlL2pwZWdcIiwgXCJpbWFnZS9wbmdcIiwgXCJpbWFnZS9qcGdcIl07XHJcbi8vICAgICBpZiAoIWFsbG93ZWRUeXBlcy5pbmNsdWRlcyhkYXRhLmd1YXJhbnRvcl9waG90by50eXBlKSkge1xyXG4vLyAgICAgICBuZXdFcnJvcnMuZ3VhcmFudG9yX3Bob3RvID0gXCJPbmx5IEpQRyBhbmQgUE5HIGZpbGVzIGFyZSBhbGxvd2VkXCI7XHJcbi8vICAgICB9XHJcbi8vICAgICBpZiAoZGF0YS5ndWFyYW50b3JfcGhvdG8uc2l6ZSA+IDIgKiAxMDI0ICogMTAyNCkge1xyXG4vLyAgICAgICAvLyAyTUIgbGltaXRcclxuLy8gICAgICAgbmV3RXJyb3JzLmd1YXJhbnRvcl9waG90byA9IFwiRmlsZSBzaXplIG11c3QgYmUgbGVzcyB0aGFuIDJNQlwiO1xyXG4vLyAgICAgfVxyXG4vLyAgIH1cclxuXHJcbi8vICAgICAgIGlmICghZGF0YS5ndWFyYW50b3JfcGFuX2RvY3VtZW50IHx8IGRhdGEuZ3VhcmFudG9yX3Bhbl9kb2N1bWVudC5sZW5ndGggPT09IDApIHtcclxuLy8gICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfcGFuX2RvY3VtZW50ID0gXCJQYW4gUGhvdG8gaXMgcmVxdWlyZWRcIjtcclxuLy8gICB9IGVsc2UgaWYgKHR5cGVvZiBkYXRhLmd1YXJhbnRvcl9wYW5fZG9jdW1lbnQgPT09IFwic3RyaW5nXCIpIHtcclxuLy8gICAgIC8vIGlmIGl0J3MgYSBVUkwgZnJvbSBEQiwgYWxsb3cgaXRcclxuLy8gICAgIGlmIChkYXRhLmd1YXJhbnRvcl9wYW5fZG9jdW1lbnQudHJpbSgpID09PSBcIlwiKSB7XHJcbi8vICAgICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfcGFuX2RvY3VtZW50ID0gXCJQYW4gUGhvdG8gaXMgcmVxdWlyZWRcIjtcclxuLy8gICAgIH1cclxuLy8gICB9IGVsc2UgaWYgKGRhdGEuZ3VhcmFudG9yX3Bhbl9kb2N1bWVudCBpbnN0YW5jZW9mIEZpbGUpIHtcclxuLy8gICAgIC8vIG9wdGlvbmFsOiBmaWxlIHR5cGUgJiBzaXplIHZhbGlkYXRpb25cclxuLy8gICAgIGNvbnN0IGFsbG93ZWRUeXBlcyA9IFtcImltYWdlL2pwZWdcIiwgXCJpbWFnZS9wbmdcIiwgXCJpbWFnZS9qcGdcIl07XHJcbi8vICAgICBpZiAoIWFsbG93ZWRUeXBlcy5pbmNsdWRlcyhkYXRhLmd1YXJhbnRvcl9wYW5fZG9jdW1lbnQudHlwZSkpIHtcclxuLy8gICAgICAgbmV3RXJyb3JzLmd1YXJhbnRvcl9wYW5fZG9jdW1lbnQgPSBcIk9ubHkgSlBHIGFuZCBQTkcgZmlsZXMgYXJlIGFsbG93ZWRcIjtcclxuLy8gICAgIH1cclxuLy8gICAgIGlmIChkYXRhLmd1YXJhbnRvcl9wYW5fZG9jdW1lbnQuc2l6ZSA+IDIgKiAxMDI0ICogMTAyNCkge1xyXG4vLyAgICAgICAvLyAyTUIgbGltaXRcclxuLy8gICAgICAgbmV3RXJyb3JzLmd1YXJhbnRvcl9wYW5fZG9jdW1lbnQgPSBcIkZpbGUgc2l6ZSBtdXN0IGJlIGxlc3MgdGhhbiAyTUJcIjtcclxuLy8gICAgIH1cclxuLy8gICB9XHJcblxyXG4vLyAgICAgIGlmICghZGF0YS5ndWFyYW50b3JfYWFkaGFyX2RvY3VtZW50IHx8IGRhdGEuZ3VhcmFudG9yX2FhZGhhcl9kb2N1bWVudC5sZW5ndGggPT09IDApIHtcclxuLy8gICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfYWFkaGFyX2RvY3VtZW50ID0gXCJBYWRoYXIgUGhvdG8gaXMgcmVxdWlyZWRcIjtcclxuLy8gICB9IGVsc2UgaWYgKHR5cGVvZiBkYXRhLmd1YXJhbnRvcl9hYWRoYXJfZG9jdW1lbnQgPT09IFwic3RyaW5nXCIpIHtcclxuLy8gICAgIC8vIGlmIGl0J3MgYSBVUkwgZnJvbSBEQiwgYWxsb3cgaXRcclxuLy8gICAgIGlmIChkYXRhLmd1YXJhbnRvcl9hYWRoYXJfZG9jdW1lbnQudHJpbSgpID09PSBcIlwiKSB7XHJcbi8vICAgICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfYWFkaGFyX2RvY3VtZW50ID0gXCJBYWRoYXIgUGhvdG8gaXMgcmVxdWlyZWRcIjtcclxuLy8gICAgIH1cclxuLy8gICB9IGVsc2UgaWYgKGRhdGEuZ3VhcmFudG9yX2FhZGhhcl9kb2N1bWVudCBpbnN0YW5jZW9mIEZpbGUpIHtcclxuLy8gICAgIC8vIG9wdGlvbmFsOiBmaWxlIHR5cGUgJiBzaXplIHZhbGlkYXRpb25cclxuLy8gICAgIGNvbnN0IGFsbG93ZWRUeXBlcyA9IFtcImltYWdlL2pwZWdcIiwgXCJpbWFnZS9wbmdcIiwgXCJpbWFnZS9qcGdcIl07XHJcbi8vICAgICBpZiAoIWFsbG93ZWRUeXBlcy5pbmNsdWRlcyhkYXRhLmd1YXJhbnRvcl9hYWRoYXJfZG9jdW1lbnQudHlwZSkpIHtcclxuLy8gICAgICAgbmV3RXJyb3JzLmd1YXJhbnRvcl9hYWRoYXJfZG9jdW1lbnQgPSBcIk9ubHkgSlBHIGFuZCBQTkcgZmlsZXMgYXJlIGFsbG93ZWRcIjtcclxuLy8gICAgIH1cclxuLy8gICAgIGlmIChkYXRhLmd1YXJhbnRvcl9hYWRoYXJfZG9jdW1lbnQuc2l6ZSA+IDIgKiAxMDI0ICogMTAyNCkge1xyXG4vLyAgICAgICAvLyAyTUIgbGltaXRcclxuLy8gICAgICAgbmV3RXJyb3JzLmd1YXJhbnRvcl9hYWRoYXJfZG9jdW1lbnQgPSBcIkZpbGUgc2l6ZSBtdXN0IGJlIGxlc3MgdGhhbiAyTUJcIjtcclxuLy8gICAgIH1cclxuLy8gICB9XHJcblxyXG4vLyAgICBpZiAoIWRhdGEuZ3VhcmFudG9yX2luY29tZV9kb2N1bWVudCB8fCBkYXRhLmd1YXJhbnRvcl9pbmNvbWVfZG9jdW1lbnQubGVuZ3RoID09PSAwKSB7XHJcbi8vICAgICBuZXdFcnJvcnMuZ3VhcmFudG9yX2luY29tZV9kb2N1bWVudCA9IFwiT2NjdXBhdGlvbiBEb2N1bWVudCBQaG90byBpcyByZXF1aXJlZFwiO1xyXG4vLyAgIH0gZWxzZSBpZiAodHlwZW9mIGRhdGEuZ3VhcmFudG9yX2luY29tZV9kb2N1bWVudCA9PT0gXCJzdHJpbmdcIikge1xyXG4vLyAgICAgLy8gaWYgaXQncyBhIFVSTCBmcm9tIERCLCBhbGxvdyBpdFxyXG4vLyAgICAgaWYgKGRhdGEuZ3VhcmFudG9yX2luY29tZV9kb2N1bWVudC50cmltKCkgPT09IFwiXCIpIHtcclxuLy8gICAgICAgbmV3RXJyb3JzLmd1YXJhbnRvcl9pbmNvbWVfZG9jdW1lbnQgPSBcIkFhZGhhciBQaG90byBpcyByZXF1aXJlZFwiO1xyXG4vLyAgICAgfVxyXG4vLyAgIH0gZWxzZSBpZiAoZGF0YS5ndWFyYW50b3JfaW5jb21lX2RvY3VtZW50IGluc3RhbmNlb2YgRmlsZSkge1xyXG4vLyAgICAgLy8gb3B0aW9uYWw6IGZpbGUgdHlwZSAmIHNpemUgdmFsaWRhdGlvblxyXG4vLyAgICAgY29uc3QgYWxsb3dlZFR5cGVzID0gW1wiaW1hZ2UvanBlZ1wiLCBcImltYWdlL3BuZ1wiLCBcImltYWdlL2pwZ1wiXTtcclxuLy8gICAgIGlmICghYWxsb3dlZFR5cGVzLmluY2x1ZGVzKGRhdGEuZ3VhcmFudG9yX2luY29tZV9kb2N1bWVudC50eXBlKSkge1xyXG4vLyAgICAgICBuZXdFcnJvcnMuZ3VhcmFudG9yX2luY29tZV9kb2N1bWVudCA9IFwiT25seSBKUEcgYW5kIFBORyBmaWxlcyBhcmUgYWxsb3dlZFwiO1xyXG4vLyAgICAgfVxyXG4vLyAgICAgaWYgKGRhdGEuZ3VhcmFudG9yX2luY29tZV9kb2N1bWVudC5zaXplID4gMiAqIDEwMjQgKiAxMDI0KSB7XHJcbi8vICAgICAgIC8vIDJNQiBsaW1pdFxyXG4vLyAgICAgICBuZXdFcnJvcnMuZ3VhcmFudG9yX2luY29tZV9kb2N1bWVudCA9IFwiRmlsZSBzaXplIG11c3QgYmUgbGVzcyB0aGFuIDJNQlwiO1xyXG4vLyAgICAgfVxyXG4vLyAgIH1cclxuXHJcbi8vICAgICAgIGlmICghZGF0YS5ndWFyYW50b3JfYWRkcmVzcz8udHJpbSgpKVxyXG4vLyAgICAgICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfYWRkcmVzcyA9IFwiQWRkcmVzcyBpcyByZXF1aXJlZFwiO1xyXG5cclxuLy8gICAgICAgaWYgKCFkYXRhLmd1YXJhbnRvcl9vY2N1cGF0aW9uKVxyXG4vLyAgICAgICAgIG5ld0Vycm9ycy5ndWFyYW50b3Jfb2NjdXBhdGlvbiA9IFwiRW50ZXIgT2NjdXBhdGlvbiBEZXRhaWxzXCI7XHJcbi8vICAgICAgIGlmICghZGF0YS5ndWFyYW50b3JfcHJvZmVzc2lvbl90eXBlKVxyXG4vLyAgICAgICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfcHJvZmVzc2lvbl90eXBlID0gXCJFbnRlciBQcm9mZXNzaW9uIFR5cGVcIjtcclxuXHJcbi8vICAgICAgIGlmICghZGF0YS5ndWFyYW50b3JfYWdyaV9ydGNfbm8pXHJcbi8vICAgICAgICAgbmV3RXJyb3JzLmd1YXJhbnRvcl9hZ3JpX3J0Y19ubyA9IFwiRW50ZXIgQWdyaWN1bHR1cmUgUlRDIG51bWJlclwiO1xyXG5cclxuLy8gICAgICAgaWYgKCFkYXRhLmd1YXJhbnRvcl9sYW5kX2hvbGRpbmdzKVxyXG4vLyAgICAgICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfbGFuZF9ob2xkaW5ncyA9IFwiRW50ZXIgQWdyaWN1bHR1cmUgbGFuZCBBcmVhXCI7XHJcblxyXG4vLyAgICAgICBpZighZGF0YS5ndWFyYW50b3JfYmFua19hY2NvdW50X251bWJlcilcclxuLy8gICAgICAgICBuZXdFcnJvcnMuZ3VhcmFudG9yX2JhbmtfYWNjb3VudF9udW1iZXIgPSBcIkVudGVyIEJhbmsgQWNjb3VudCBOdW1iZXIgXCJcclxuLy8gICAgICAgaWYoIWRhdGEuZ3VhcmFudG9yX2JhbmtfYnJhbmNoKVxyXG4vLyAgICAgICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfYmFua19icmFuY2ggPSBcIkVudGVyIEJhbmsgQnJhbmNoIE5hbWUgXCJcclxuLy8gICAgICAgaWYoIWRhdGEuZ3VhcmFudG9yX2JhbmtfaWZzY19jb2RlKVxyXG4vLyAgICAgICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfYmFua19pZnNjX2NvZGUgPSBcIkVudGVyIEJhbmsgSUZTQyBDb2RlIFwiXHJcblxyXG5cclxuLy8gICAgICAgICAgIGlmICghZGF0YS5ndWFyYW50b3JfYmFua19wYXNzYm9va19waG90byB8fCBkYXRhLmd1YXJhbnRvcl9iYW5rX3Bhc3Nib29rX3Bob3RvLmxlbmd0aCA9PT0gMCkge1xyXG4vLyAgICAgbmV3RXJyb3JzLmd1YXJhbnRvcl9iYW5rX3Bhc3Nib29rX3Bob3RvID0gXCJCYW5rIFBhc3NCb29rIFBob3RvIGlzIHJlcXVpcmVkXCI7XHJcbi8vICAgfSBlbHNlIGlmICh0eXBlb2YgZGF0YS5ndWFyYW50b3JfYmFua19wYXNzYm9va19waG90byA9PT0gXCJzdHJpbmdcIikge1xyXG4vLyAgICAgLy8gaWYgaXQncyBhIFVSTCBmcm9tIERCLCBhbGxvdyBpdFxyXG4vLyAgICAgaWYgKGRhdGEuZ3VhcmFudG9yX2JhbmtfcGFzc2Jvb2tfcGhvdG8udHJpbSgpID09PSBcIlwiKSB7XHJcbi8vICAgICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfYmFua19wYXNzYm9va19waG90byA9IFwiQmFuayBQYXNzQm9vayBQaG90byBpcyByZXF1aXJlZFwiO1xyXG4vLyAgICAgfVxyXG4vLyAgIH0gZWxzZSBpZiAoZGF0YS5ndWFyYW50b3JfYmFua19wYXNzYm9va19waG90byBpbnN0YW5jZW9mIEZpbGUpIHtcclxuLy8gICAgIC8vIG9wdGlvbmFsOiBmaWxlIHR5cGUgJiBzaXplIHZhbGlkYXRpb25cclxuLy8gICAgIGNvbnN0IGFsbG93ZWRUeXBlcyA9IFtcImltYWdlL2pwZWdcIiwgXCJpbWFnZS9wbmdcIiwgXCJpbWFnZS9qcGdcIl07XHJcbi8vICAgICBpZiAoIWFsbG93ZWRUeXBlcy5pbmNsdWRlcyhkYXRhLmd1YXJhbnRvcl9iYW5rX3Bhc3Nib29rX3Bob3RvLnR5cGUpKSB7XHJcbi8vICAgICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfYmFua19wYXNzYm9va19waG90byA9IFwiT25seSBKUEcgYW5kIFBORyBmaWxlcyBhcmUgYWxsb3dlZFwiO1xyXG4vLyAgICAgfVxyXG4vLyAgICAgaWYgKGRhdGEuZ3VhcmFudG9yX2JhbmtfcGFzc2Jvb2tfcGhvdG8uc2l6ZSA+IDIgKiAxMDI0ICogMTAyNCkge1xyXG4vLyAgICAgICAvLyAyTUIgbGltaXRcclxuLy8gICAgICAgbmV3RXJyb3JzLmd1YXJhbnRvcl9iYW5rX3Bhc3Nib29rX3Bob3RvID0gXCJGaWxlIHNpemUgbXVzdCBiZSBsZXNzIHRoYW4gMk1CXCI7XHJcbi8vICAgICB9XHJcbi8vICAgfVxyXG5cclxuXHJcblxyXG4vLyAgICAgICBpZighZGF0YS5ndWFyYW50b3JfYmFua19uYW1lKVxyXG4vLyAgICAgICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfYmFua19uYW1lID0gXCJFbnRlciBCYW5rIE5hbWUgXCJcclxuXHJcbi8vICAgICAgIGlmKCFkYXRhLmd1YXJhbnRvcl9vY2N1cGF0aW9uX3N1YilcclxuLy8gICAgICAgICBuZXdFcnJvcnMuZ3VhcmFudG9yX29jY3VwYXRpb25fc3ViID0gXCJFbnRlciBPY2N1cGF0aW9uIENhdGFnb3J5IFwiXHJcbiAgICAgIFxyXG4vLyAgICAgICBpZighZGF0YS5ndWFyYW50b3JfYnVzc2luZXNzX3R5cGUpXHJcbi8vICAgICAgICAgbmV3RXJyb3JzLmd1YXJhbnRvcl9idXNzaW5lc3NfdHlwZSA9IFwiRW50ZXIgT2NjdXBhdGlvbiBUeXBlIGlzIFJlcXVpcmVkICBcIlxyXG5cclxuLy8gaWYoIWRhdGEuZ3VhcmFudG9yX2J1c3NpbmVzc19hZGRyZXNzKVxyXG4vLyAgICAgICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfYnVzc2luZXNzX2FkZHJlc3MgPSBcIkVudGVyIEFkZHJlc3MgIFwiXHJcblxyXG4vLyAgICAgICBpZighZGF0YS5ndWFyYW50b3JfYnVzc2luZXNzX25hbWUpXHJcbi8vICAgICAgICAgbmV3RXJyb3JzLmd1YXJhbnRvcl9idXNzaW5lc3NfbmFtZSA9IFwiRW50ZXIgT2NjdXBhdGlvbiBOYW1lIGlzIFJlcXVpcmVkIFwiXHJcblxyXG5cclxuLy8gICAgICAgaWYgKCFkYXRhLmd1YXJhbnRvcl9pbmNvbWUpXHJcbi8vICAgICAgICAgbmV3RXJyb3JzLmd1YXJhbnRvcl9pbmNvbWUgPSBcIkd1YXJhbnRvciBpbmNvbWUgRGV0YWlscyBpcyByZXF1aXJlZFwiO1xyXG4vLyAgICAgfVxyXG5cclxuLy8gICAgIGlmIChkYXRhLmd1YXJhbnRvcl9yZWZlcnJlZF90eXBlID09PSBcIlByb3BlcnR5XCIpIHtcclxuLy8gICAgICAgaWYgKCFkYXRhLmd1YXJhbnRvcl9kZXNjcmlwdGlvbj8udHJpbSgpKVxyXG4vLyAgICAgICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfZGVzY3JpcHRpb24gPSBcIkRlc2NyaXB0aW9uIGlzIHJlcXVpcmVkXCI7XHJcbi8vICAgICB9XHJcbi8vICAgICBpZiAoZGF0YS5ndWFyYW50b3JfcmVmZXJyZWRfdHlwZSA9PT0gXCJDdXN0b21lclwiKSB7XHJcbi8vICAgICAgIGlmICghZGF0YS5ndWFyYW50b3JfZGVzY3JpcHRpb24/LnRyaW0oKSlcclxuLy8gICAgICAgICBuZXdFcnJvcnMuZ3VhcmFudG9yX2Rlc2NyaXB0aW9uID0gXCJEZXNjcmlwdGlvbiBpcyByZXF1aXJlZFwiO1xyXG4vLyAgICAgfVxyXG4vLyAgICAgaWYgKGRhdGEuZ3VhcmFudG9yX3JlZmVycmVkX3R5cGUgPT09IFwiUHJvcGVydHlcIikge1xyXG4vLyAgICAgICBpZiAoIWRhdGEuZ3VhcmFudG9yX2RvY3VtZW50X25hbWU/LnRyaW0oKSlcclxuLy8gICAgICAgICBuZXdFcnJvcnMuZ3VhcmFudG9yX2RvY3VtZW50X25hbWUgPSBcIkRvY3VtZW50IE5hbWUgaXMgcmVxdWlyZWRcIjtcclxuLy8gICAgIH1cclxuXHJcbi8vICAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuLy8gICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuLy8gICB9O1xyXG5cclxuY29uc3QgdmFsaWRhdGVGb3JtID0gKHR5cGUpID0+IHtcclxuICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuICBjb25zdCBkYXRhID0gdHlwZSA9PT0gXCJhZGRHdWFyYW50b3JcIiA/IGZvcm1EYXRhIDogdXBkYXRlRm9ybURhdGE7XHJcblxyXG4gIC8vIERlZmluZSBhIHNpbmdsZSByZWdleCBvYmplY3RcclxuICBjb25zdCByZWdleCA9IHtcclxuICAgIGVtYWlsOiAvXlteXFxzQF0rQFteXFxzQF0rXFwuW15cXHNAXSskLyxcclxuICAgIHBob25lOiAvXls2LTldXFxkezl9JC8sXHJcbiAgICBwaW5jb2RlOiAvXlxcZHs2fSQvLFxyXG4gICAgYWRoYWFyOiAvXlxcZHsxMn0kLyxcclxuICAgIHBhbjogL15bQS1aXXs1fVswLTldezR9W0EtWl17MX0kLyxcclxuICB9O1xyXG5cclxuICAvLyBIZWxwZXIgZnVuY3Rpb24gZm9yIGZpbGUgdmFsaWRhdGlvblxyXG4gIGNvbnN0IHZhbGlkYXRlRmlsZSA9IChmaWxlLCBuYW1lKSA9PiB7XHJcbiAgICBpZiAoIWZpbGUpIHtcclxuICAgICAgcmV0dXJuIGAke25hbWV9IGlzIHJlcXVpcmVkYDtcclxuICAgIH1cclxuICAgIGNvbnN0IGFsbG93ZWRUeXBlcyA9IFtcImltYWdlL2pwZWdcIiwgXCJpbWFnZS9wbmdcIiwgXCJpbWFnZS9qcGdcIl07XHJcbiAgICBpZiAoZmlsZSBpbnN0YW5jZW9mIEZpbGUpIHtcclxuICAgICAgaWYgKCFhbGxvd2VkVHlwZXMuaW5jbHVkZXMoZmlsZS50eXBlKSkge1xyXG4gICAgICAgIHJldHVybiBcIk9ubHkgSlBHIGFuZCBQTkcgZmlsZXMgYXJlIGFsbG93ZWRcIjtcclxuICAgICAgfVxyXG4gICAgICBpZiAoZmlsZS5zaXplID4gMiAqIDEwMjQgKiAxMDI0KSB7XHJcbiAgICAgICAgcmV0dXJuIFwiRmlsZSBzaXplIG11c3QgYmUgbGVzcyB0aGFuIDJNQlwiO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiBmaWxlID09PSBcInN0cmluZ1wiICYmIGZpbGUudHJpbSgpID09PSBcIlwiKSB7XHJcbiAgICAgIHJldHVybiBgJHtuYW1lfSBpcyByZXF1aXJlZGA7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9O1xyXG5cclxuICAvLyBHZW5lcmFsIHZhbGlkYXRpb24gZm9yIGFsbCB0eXBlc1xyXG4gIGlmICghZGF0YS51c2VyX2lkKSBuZXdFcnJvcnMudXNlcl9pZCA9IFwiQ3VzdG9tZXIgTmFtZSBpcyByZXF1aXJlZFwiO1xyXG4gIGlmICghZGF0YS5ndWFyYW50b3JfcmVmZXJyZWRfdHlwZSkgbmV3RXJyb3JzLmd1YXJhbnRvcl9yZWZlcnJlZF90eXBlID0gXCJSZWZlcnJlZCBUeXBlIGlzIHJlcXVpcmVkXCI7XHJcbiAgaWYgKCFkYXRhLmVucm9sbG1lbnRfaWRzIHx8IGRhdGEuZW5yb2xsbWVudF9pZHMubGVuZ3RoID09PSAwKSBuZXdFcnJvcnMuZW5yb2xsbWVudF9pZHMgPSBcIkVucm9sbG1lbnQgaXMgcmVxdWlyZWRcIjtcclxuXHJcbiAgLy8gQ29uZGl0aW9uYWwgdmFsaWRhdGlvbiBiYXNlZCBvbiByZWZlcnJlZCB0eXBlXHJcbiAgaWYgKGRhdGEuZ3VhcmFudG9yX3JlZmVycmVkX3R5cGUgPT09IFwiQ3VzdG9tZXJcIikge1xyXG4gICAgaWYgKCFkYXRhLnVzZXJfZ3VhcmFudG9yKSBuZXdFcnJvcnMudXNlcl9ndWFyYW50b3IgPSBcIlJlZmVycmVkIEN1c3RvbWVyIGlzIHJlcXVpcmVkXCI7XHJcbiAgICBpZiAoIWRhdGEuZ3VhcmFudG9yX2Rlc2NyaXB0aW9uPy50cmltKCkpIG5ld0Vycm9ycy5ndWFyYW50b3JfZGVzY3JpcHRpb24gPSBcIkRlc2NyaXB0aW9uIGlzIHJlcXVpcmVkXCI7XHJcbiAgfSBlbHNlIGlmIChkYXRhLmd1YXJhbnRvcl9yZWZlcnJlZF90eXBlID09PSBcIlByb3BlcnR5XCIpIHtcclxuICAgIGlmICghZGF0YS5ndWFyYW50b3JfZGVzY3JpcHRpb24/LnRyaW0oKSkgbmV3RXJyb3JzLmd1YXJhbnRvcl9kZXNjcmlwdGlvbiA9IFwiRGVzY3JpcHRpb24gaXMgcmVxdWlyZWRcIjtcclxuICAgIGlmICghZGF0YS5ndWFyYW50b3JfZG9jdW1lbnRfbmFtZT8udHJpbSgpKSBuZXdFcnJvcnMuZ3VhcmFudG9yX2RvY3VtZW50X25hbWUgPSBcIkRvY3VtZW50IE5hbWUgaXMgcmVxdWlyZWRcIjtcclxuICAgIGxldCBmaWxlRXJyb3IgPSB2YWxpZGF0ZUZpbGUoZGF0YS5ndWFyYW50b3JfZG9jdW1lbnQsIFwiUHJvcGVydHkgRG9jdW1lbnQgUGhvdG9cIik7XHJcbiAgICBpZiAoZmlsZUVycm9yKSBuZXdFcnJvcnMuZ3VhcmFudG9yX2RvY3VtZW50ID0gZmlsZUVycm9yO1xyXG4gIH0gZWxzZSBpZiAoZGF0YS5ndWFyYW50b3JfcmVmZXJyZWRfdHlwZSA9PT0gXCJUaGlyZCBQYXJ0eVwiKSB7XHJcbiAgICAvLyBQZXJzb25hbCBJbmZvcm1hdGlvblxyXG4gICAgaWYgKCFkYXRhLmd1YXJhbnRvcl9uYW1lPy50cmltKCkpIG5ld0Vycm9ycy5ndWFyYW50b3JfbmFtZSA9IFwiR3VhcmFudG9yIE5hbWUgaXMgcmVxdWlyZWRcIjtcclxuICAgIGlmICghZGF0YS5ndWFyYW50b3JfcmVsYXRpb25zaGlwX3R5cGU/LnRyaW0oKSkgbmV3RXJyb3JzLmd1YXJhbnRvcl9yZWxhdGlvbnNoaXBfdHlwZSA9IFwiR3VhcmFudG9yIFJlbGF0aW9uc2hpcCBpcyByZXF1aXJlZFwiO1xyXG4gICAgaWYgKCFkYXRhLmd1YXJhbnRvcl9waG9uZV9udW1iZXIgfHwgIXJlZ2V4LnBob25lLnRlc3QoZGF0YS5ndWFyYW50b3JfcGhvbmVfbnVtYmVyKSkge1xyXG4gICAgICBuZXdFcnJvcnMuZ3VhcmFudG9yX3Bob25lX251bWJlciA9IFwiSW52YWxpZCBQaG9uZSBOdW1iZXJcIjtcclxuICAgIH1cclxuICAgIGlmICghZGF0YS5ndWFyYW50b3JfZW1haWwgfHwgIXJlZ2V4LmVtYWlsLnRlc3QoZGF0YS5ndWFyYW50b3JfZW1haWwpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfZW1haWwgPSBcIkludmFsaWQgRW1haWxcIjtcclxuICAgIH1cclxuICAgIGlmICghZGF0YS5ndWFyYW50b3JfYWRkcmVzcz8udHJpbSgpKSBuZXdFcnJvcnMuZ3VhcmFudG9yX2FkZHJlc3MgPSBcIkFkZHJlc3MgaXMgcmVxdWlyZWRcIjtcclxuICAgIGlmICghZGF0YS5ndWFyYW50b3JfcGluY29kZSB8fCAhcmVnZXgucGluY29kZS50ZXN0KGRhdGEuZ3VhcmFudG9yX3BpbmNvZGUpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfcGluY29kZSA9IFwiSW52YWxpZCBQaW5jb2RlXCI7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gS1lDIERvY3VtZW50c1xyXG4gICAgaWYgKCFkYXRhLmd1YXJhbnRvcl9hZGhhYXJfbm8gfHwgIXJlZ2V4LmFkaGFhci50ZXN0KGRhdGEuZ3VhcmFudG9yX2FkaGFhcl9ubykpIHtcclxuICAgICAgbmV3RXJyb3JzLmd1YXJhbnRvcl9hZGhhYXJfbm8gPSBcIkludmFsaWQgQWFkaGFhciBOdW1iZXJcIjtcclxuICAgIH1cclxuICAgIGlmICghZGF0YS5ndWFyYW50b3JfcGFuX25vIHx8ICFyZWdleC5wYW4udGVzdChkYXRhLmd1YXJhbnRvcl9wYW5fbm8pKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5ndWFyYW50b3JfcGFuX25vID0gXCJJbnZhbGlkIFBBTiBDYXBpdGFsIEFscGhhYmV0IHdpdGggTnVtYmVyXCI7XHJcbiAgICB9XHJcbiAgICBsZXQgZmlsZUVycm9yID0gdmFsaWRhdGVGaWxlKGRhdGEuZ3VhcmFudG9yX3Bob3RvLCBcIlByb2ZpbGUgUGhvdG9cIik7XHJcbiAgICBpZiAoZmlsZUVycm9yKSBuZXdFcnJvcnMuZ3VhcmFudG9yX3Bob3RvID0gZmlsZUVycm9yO1xyXG4gICAgZmlsZUVycm9yID0gdmFsaWRhdGVGaWxlKGRhdGEuZ3VhcmFudG9yX3Bhbl9kb2N1bWVudCwgXCJQQU4gQ2FyZCBQaG90b1wiKTtcclxuICAgIGlmIChmaWxlRXJyb3IpIG5ld0Vycm9ycy5ndWFyYW50b3JfcGFuX2RvY3VtZW50ID0gZmlsZUVycm9yO1xyXG4gICAgZmlsZUVycm9yID0gdmFsaWRhdGVGaWxlKGRhdGEuZ3VhcmFudG9yX2FhZGhhcl9kb2N1bWVudCwgXCJBYWRoYWFyIENhcmQgUGhvdG9cIik7XHJcbiAgICBpZiAoZmlsZUVycm9yKSBuZXdFcnJvcnMuZ3VhcmFudG9yX2FhZGhhcl9kb2N1bWVudCA9IGZpbGVFcnJvcjtcclxuXHJcbiAgICAvLyBPY2N1cGF0aW9uIERldGFpbHNcclxuICAgIGlmICghZGF0YS5ndWFyYW50b3Jfb2NjdXBhdGlvbikgbmV3RXJyb3JzLmd1YXJhbnRvcl9vY2N1cGF0aW9uID0gXCJPY2N1cGF0aW9uIGlzIHJlcXVpcmVkXCI7XHJcbiAgICBcclxuICAgIC8vIENvbmRpdGlvbmFsIHZhbGlkYXRpb24gZm9yIE9jY3VwYXRpb24gZmllbGRzXHJcbiAgICBzd2l0Y2ggKGRhdGEuZ3VhcmFudG9yX29jY3VwYXRpb24pIHtcclxuICAgICAgY2FzZSBcIlNlbGYgRW1wbG95ZWRcIjpcclxuICAgICAgY2FzZSBcIlNhbGFyaWVkXCI6XHJcbiAgICAgICAgaWYgKCFkYXRhLmd1YXJhbnRvcl9idXNzaW5lc3NfdHlwZT8udHJpbSgpKSBuZXdFcnJvcnMuZ3VhcmFudG9yX2J1c3NpbmVzc190eXBlID0gXCJCdXNpbmVzcyBUeXBlIGlzIHJlcXVpcmVkXCI7XHJcbiAgICAgICAgaWYgKCFkYXRhLmd1YXJhbnRvcl9idXNzaW5lc3NfbmFtZT8udHJpbSgpKSBuZXdFcnJvcnMuZ3VhcmFudG9yX2J1c3NpbmVzc19uYW1lID0gXCJCdXNpbmVzcyBOYW1lIGlzIHJlcXVpcmVkXCI7XHJcbiAgICAgICAgaWYgKCFkYXRhLmd1YXJhbnRvcl9idXNzaW5lc3NfYWRkcmVzcz8udHJpbSgpKSBuZXdFcnJvcnMuZ3VhcmFudG9yX2J1c3NpbmVzc19hZGRyZXNzID0gXCJCdXNpbmVzcyBBZGRyZXNzIGlzIHJlcXVpcmVkXCI7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgXCJQcm9mZXNzaW9uYWxcIjpcclxuICAgICAgICBpZiAoIWRhdGEuZ3VhcmFudG9yX3Byb2Zlc3Npb25fdHlwZT8udHJpbSgpKSBuZXdFcnJvcnMuZ3VhcmFudG9yX3Byb2Zlc3Npb25fdHlwZSA9IFwiUHJvZmVzc2lvbiBUeXBlIGlzIHJlcXVpcmVkXCI7XHJcbiAgICAgICAgaWYgKCFkYXRhLmd1YXJhbnRvcl9idXNzaW5lc3NfYWRkcmVzcz8udHJpbSgpKSBuZXdFcnJvcnMuZ3VhcmFudG9yX2J1c3NpbmVzc19hZGRyZXNzID0gXCJCdXNpbmVzcyBBZGRyZXNzIGlzIHJlcXVpcmVkXCI7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgXCJBZ3JpIEFsbGllZFwiOlxyXG4gICAgICAgIGlmICghZGF0YS5ndWFyYW50b3JfYWdyaV9ydGNfbm8/LnRyaW0oKSkgbmV3RXJyb3JzLmd1YXJhbnRvcl9hZ3JpX3J0Y19ubyA9IFwiUlRDIE51bWJlciBpcyByZXF1aXJlZFwiO1xyXG4gICAgICAgIGlmICghZGF0YS5ndWFyYW50b3JfbGFuZF9ob2xkaW5ncykgbmV3RXJyb3JzLmd1YXJhbnRvcl9sYW5kX2hvbGRpbmdzID0gXCJMYW5kIEhvbGRpbmdzIGlzIHJlcXVpcmVkXCI7XHJcbiAgICAgICAgaWYgKCFkYXRhLmd1YXJhbnRvcl9idXNzaW5lc3NfYWRkcmVzcz8udHJpbSgpKSBuZXdFcnJvcnMuZ3VhcmFudG9yX2J1c3NpbmVzc19hZGRyZXNzID0gXCJCdXNpbmVzcyBBZGRyZXNzIGlzIHJlcXVpcmVkXCI7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgXCJPdGhlclwiOlxyXG4gICAgICAgIGlmICghZGF0YS5ndWFyYW50b3Jfb2NjdXBhdGlvbl9zdWI/LnRyaW0oKSkgbmV3RXJyb3JzLmd1YXJhbnRvcl9vY2N1cGF0aW9uX3N1YiA9IFwiT2NjdXBhdGlvbiBTdWItY2F0ZWdvcnkgaXMgcmVxdWlyZWRcIjtcclxuICAgICAgICBpZiAoZGF0YS5ndWFyYW50b3Jfb2NjdXBhdGlvbl9zdWIgPT09IFwiUnVubmluZyBhbiB1bnJlZ2lzdGVyZWQgQnVzaW5lc3NcIiAmJiAhZGF0YS5ndWFyYW50b3JfYnVzc2luZXNzX2FkZHJlc3M/LnRyaW0oKSkge1xyXG4gICAgICAgICAgbmV3RXJyb3JzLmd1YXJhbnRvcl9idXNzaW5lc3NfYWRkcmVzcyA9IFwiQWRkcmVzcyBpcyByZXF1aXJlZCBmb3IgdGhpcyBvY2N1cGF0aW9uXCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgfVxyXG4gICAgZmlsZUVycm9yID0gdmFsaWRhdGVGaWxlKGRhdGEuZ3VhcmFudG9yX2luY29tZV9kb2N1bWVudCwgXCJJbmNvbWUgRG9jdW1lbnQgUGhvdG9cIik7XHJcbiAgICBpZiAoZmlsZUVycm9yKSBuZXdFcnJvcnMuZ3VhcmFudG9yX2luY29tZV9kb2N1bWVudCA9IGZpbGVFcnJvcjtcclxuXHJcbiAgICAvLyBCYW5rIERldGFpbHNcclxuICAgIGlmICghZGF0YS5ndWFyYW50b3JfYmFua19uYW1lPy50cmltKCkpIG5ld0Vycm9ycy5ndWFyYW50b3JfYmFua19uYW1lID0gXCJCYW5rIE5hbWUgaXMgcmVxdWlyZWRcIjtcclxuICAgIGlmICghZGF0YS5ndWFyYW50b3JfYmFua19hY2NvdW50X251bWJlcj8udHJpbSgpKSBuZXdFcnJvcnMuZ3VhcmFudG9yX2JhbmtfYWNjb3VudF9udW1iZXIgPSBcIkJhbmsgQWNjb3VudCBOdW1iZXIgaXMgcmVxdWlyZWRcIjtcclxuICAgIGlmICghZGF0YS5ndWFyYW50b3JfYmFua19icmFuY2g/LnRyaW0oKSkgbmV3RXJyb3JzLmd1YXJhbnRvcl9iYW5rX2JyYW5jaCA9IFwiQmFuayBCcmFuY2ggaXMgcmVxdWlyZWRcIjtcclxuICAgIGlmICghZGF0YS5ndWFyYW50b3JfYmFua19pZnNjX2NvZGU/LnRyaW0oKSkgbmV3RXJyb3JzLmd1YXJhbnRvcl9iYW5rX2lmc2NfY29kZSA9IFwiQmFuayBJRlNDIENvZGUgaXMgcmVxdWlyZWRcIjtcclxuICAgIGZpbGVFcnJvciA9IHZhbGlkYXRlRmlsZShkYXRhLmd1YXJhbnRvcl9iYW5rX3Bhc3Nib29rX3Bob3RvLCBcIkJhbmsgUGFzc2Jvb2sgUGhvdG9cIik7XHJcbiAgICBpZiAoZmlsZUVycm9yKSBuZXdFcnJvcnMuZ3VhcmFudG9yX2JhbmtfcGFzc2Jvb2tfcGhvdG8gPSBmaWxlRXJyb3I7XHJcbiAgfVxyXG5cclxuICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICByZXR1cm4gT2JqZWN0LmtleXMobmV3RXJyb3JzKS5sZW5ndGggPT09IDA7XHJcbn07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBjb25zdCBpc3ZhbGlkID0gdmFsaWRhdGVGb3JtKFwiYWRkR3VhcmFudG9yXCIpO1xyXG4gICAgaWYgKGlzdmFsaWQpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCBmbURhdGEgPSBuZXcgRm9ybURhdGEoKTtcclxuICAgICAgICBPYmplY3QuZW50cmllcyhmb3JtRGF0YSkuZm9yRWFjaCgoW2tleSwgdmFsdWVdKSA9PiB7XHJcbiAgICAgICAgICBpZiAodmFsdWUgaW5zdGFuY2VvZiBGaWxlKSB7XHJcbiAgICAgICAgICAgIGZtRGF0YS5hcHBlbmQoa2V5LCB2YWx1ZSk7IC8vICBhY3R1YWwgZmlsZVxyXG4gICAgICAgICAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xyXG4gICAgICAgICAgICB2YWx1ZS5mb3JFYWNoKCh2KSA9PiBmbURhdGEuYXBwZW5kKGAke2tleX1bXWAsIHYpKTtcclxuICAgICAgICAgIH0gZWxzZSBpZiAodmFsdWUpIHtcclxuICAgICAgICAgICAgZm1EYXRhLmFwcGVuZChrZXksIHZhbHVlKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgLy8gZXh0cmFEb2NzLmZvckVhY2goKGRvYywgaSkgPT4ge1xyXG4gICAgICAgIC8vICAgICAgICAgaWYgKGRvYy5maWxlKSB7XHJcbiAgICAgICAgLy8gICAgICAgICAgIGZtRGF0YS5hcHBlbmQoXCJndWFyYW50b3JfYWxsX2RvY3VtZW50XCIsIGRvYy5maWxlKTtcclxuICAgICAgICAvLyAgICAgICAgICAgZm1EYXRhLmFwcGVuZChcclxuICAgICAgICAvLyAgICAgICAgICAgICBcImd1YXJhbnRvcl9hbGxfZG9jdW1lbnRfbmFtZVwiLFxyXG4gICAgICAgIC8vICAgICAgICAgICAgIGRvYy5kb2N1bWVudF9uYW1lIHx8IGBEb2NfJHtpICsgMX1gXHJcbiAgICAgICAgLy8gICAgICAgICAgICk7XHJcbiAgICAgICAgLy8gICAgICAgICB9XHJcbiAgICAgICAgLy8gICAgICAgfSk7XHJcbiAgICAgICAgLy8gZXh0cmFEb2NzLmZvckVhY2goKGRvYywgaSkgPT4ge1xyXG4gICAgICAgIC8vICAgICBpZiAoZG9jLmZpbGUpIHtcclxuICAgICAgICAvLyAgICAgICBmbURhdGEuYXBwZW5kKFwiZ3VhcmFudG9yX2FsbF9kb2N1bWVudFwiLCBkb2MuZmlsZSk7IC8vIG11bHRpcGxlIGZpbGVzXHJcbiAgICAgICAgLy8gICAgICAgZm1EYXRhLmFwcGVuZChcImd1YXJhbnRvcl9hbGxfZG9jdW1lbnRcIiwgZG9jLmRvY3VtZW50X25hbWUgfHwgYERvY3VtZW50XyR7aSArIDF9YCk7XHJcbiAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAvLyAgIH0pO1xyXG5cclxuICAgICAgICBleHRyYURvY3MuZm9yRWFjaCgoZG9jLCBpKSA9PiB7XHJcbiAgICAgICAgICBpZiAoZG9jLmZpbGUpIHtcclxuICAgICAgICAgICAgZm1EYXRhLmFwcGVuZChcImd1YXJhbnRvcl9hbGxfZG9jdW1lbnRcIiwgZG9jLmZpbGUpOyAvLyBmaWxlXHJcbiAgICAgICAgICAgIGZtRGF0YS5hcHBlbmQoXHJcbiAgICAgICAgICAgICAgXCJkb2N1bWVudF9uYW1lW11cIixcclxuICAgICAgICAgICAgICBkb2MuZG9jdW1lbnRfbmFtZSB8fCBgRG9jdW1lbnRfJHtpICsgMX1gXHJcbiAgICAgICAgICAgICk7IC8vIG5hbWUgc2VwYXJhdGVseVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KFxyXG4gICAgICAgICAgXCIvZ3VhcmFudG9yL2FkZC1ndWFyYW50b3ItaW5mb1wiLFxyXG4gICAgICAgICAgLy9mb3JtRGF0YSxcclxuICAgICAgICAgIGZtRGF0YSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwibXVsdGlwYXJ0L2Zvcm0tZGF0YVwiLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiR3VhcmFudG9yIEFkZGVkIFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgIHVzZXJfaWQ6IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3JfbmFtZTogXCJcIixcclxuICAgICAgICAgIGd1YXJhbnRvcl9lbWFpbDogXCJcIixcclxuICAgICAgICAgIHVzZXJfZ3VhcmFudG9yOiBcIlwiLFxyXG4gICAgICAgICAgZ3VhcmFudG9yX3Bob25lX251bWJlcjogXCJcIixcclxuICAgICAgICAgIGd1YXJhbnRvcl9hZGRyZXNzOiBcIlwiLFxyXG4gICAgICAgICAgZ3VhcmFudG9yX3BpbmNvZGU6IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3JfYWRoYWFyX25vOiBcIlwiLFxyXG4gICAgICAgICAgZ3VhcmFudG9yX3Bhbl9ubzogXCJcIixcclxuICAgICAgICAgIGd1YXJhbnRvcl9nZW5kZXI6IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3JfbWFyaXRhbF9zdGF0dXM6IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3JfZGF0ZW9mYmlydGg6IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3JfbmF0aW9uYWxpdHk6IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3JfdmlsbGFnZTogXCJcIixcclxuICAgICAgICAgIGd1YXJhbnRvcl90YWx1azogXCJcIixcclxuICAgICAgICAgIGd1YXJhbnRvcl9mYXRoZXJfbmFtZTogXCJcIixcclxuICAgICAgICAgIGd1YXJhbnRvcl9kaXN0cmljdDogXCJcIixcclxuICAgICAgICAgIGd1YXJhbnRvcl9zdGF0ZTogXCJcIixcclxuICAgICAgICAgIGd1YXJhbnRvcl9kZXNjcmlwdGlvbjogXCJcIixcclxuICAgICAgICAgIGVucm9sbG1lbnRfaWRzOiBbXSxcclxuICAgICAgICAgIGd1YXJhbnRvcl9hbHRlcm5hdGVfbnVtYmVyOiBcIlwiLFxyXG4gICAgICAgICAgZ3VhcmFudG9yX3JlZmVycmVkX3R5cGU6IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3JfZG9jdW1lbnQ6IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3JfZG9jdW1lbnRfbmFtZTogXCJcIixcclxuICAgICAgICAgIGd1YXJhbnRvcl9waG90bzogXCJcIixcclxuICAgICAgICAgIGd1YXJhbnRvcl9wYW5fZG9jdW1lbnQ6IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3JfYWFkaGFyX2RvY3VtZW50OiBcIlwiLFxyXG4gICAgICAgICAgZ3VhcmFudG9yX3JlbGF0aW9uc2hpcF90eXBlOiBcIlwiLFxyXG4gICAgICAgICAgZ3VhcmFudG9yX29jY3VwYXRpb246IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3JfaW5jb21lOiBcIlwiLFxyXG4gICAgICAgICAgZ3VhcmFudG9yX2NvbnNlbnRfZG9jdW1lbnQ6IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3JfYmFua19uYW1lOiBcIlwiLFxyXG4gICAgICAgICAgZ3VhcmFudG9yX2JhbmtfYWNjb3VudF9udW1iZXI6IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3JfYmFua19icmFuY2g6IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3JfYmFua19pZnNjX2NvZGU6IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3JfYmFua19wYXNzYm9va19waG90bzogXCJcIixcclxuICAgICAgICAgIGd1YXJhbnRvcl9zZWN0b3JfbmFtZTogXCJcIixcclxuICAgICAgICAgIGd1YXJhbnRvcl9pbmNvbWVfZG9jdW1lbnQ6IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3JfYnVzc2luZXNzX3R5cGU6IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3JfYnVzc2luZXNzX25hbWU6IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3JfYnVzc2luZXNzX2FkZHJlc3M6IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3JfcHJvZmVzc2lvbl90eXBlOiBcIlwiLFxyXG4gICAgICAgICAgZ3VhcmFudG9yX2FncmlfcnRjX25vOiBcIlwiLFxyXG4gICAgICAgICAgZ3VhcmFudG9yX2xhbmRfaG9sZGluZ3M6IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3Jfb2NjdXBhdGlvbl9zdWI6IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3JfYWxsX2RvY3VtZW50X25hbWU6IFwiXCIsXHJcbiAgICAgICAgICBndWFyYW50b3JfYWxsX2RvY3VtZW50OiBcIlwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBhZGRpbmcgR3VhcmFudG9yOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgICAgbWVzc2FnZTpcclxuICAgICAgICAgICAgZXJyb3I/LnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiQW4gdW5leHBlY3RlZCBlcnJvciBvY2N1cnJlZC5cIixcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBjb25zdCBoYW5kbGVVcGRhdGUgPSBhc3luYyAoZSkgPT4ge1xyXG4gIC8vICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gIC8vICAgdHJ5IHtcclxuICAvLyAgICAgY29uc3QgZm1EYXRhID0gbmV3IEZvcm1EYXRhKCk7XHJcblxyXG4gIC8vICAgICAvLyBhcHBlbmQgYWxsIGZpZWxkcyBmcm9tIHVwZGF0ZUZvcm1EYXRhXHJcbiAgLy8gICAgIC8vIE9iamVjdC5lbnRyaWVzKHVwZGF0ZUZvcm1EYXRhKS5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcclxuICAvLyAgICAgLy8gICBpZiAodmFsdWUpIGZtRGF0YS5hcHBlbmQoa2V5LCB2YWx1ZSk7XHJcbiAgLy8gICAgIC8vIH0pO1xyXG5cclxuICAvLyAgICAgY29uc3QgeyBndWFyYW50b3JfYWxsX2RvY3VtZW50LCAuLi5yZXN0IH0gPSB1cGRhdGVGb3JtRGF0YTtcclxuXHJcbiAgLy8gICAgIC8vIEFwcGVuZCBub24tZmlsZSBmaWVsZHMgYW5kIGV4aXN0aW5nIFVSTHNcclxuICAvLyAgICAgT2JqZWN0LmVudHJpZXMocmVzdCkuZm9yRWFjaCgoW2tleSwgdmFsdWVdKSA9PiB7XHJcbiAgLy8gICAgICAgaWYgKHZhbHVlKSBmbURhdGEuYXBwZW5kKGtleSwgdmFsdWUpO1xyXG4gIC8vICAgICB9KTtcclxuXHJcbiAgLy8gICAgIC8vIEFwcGVuZCBuZXcgZmlsZXMgb25seSBpZiB0aGV5IGFyZSBvZiB0eXBlICdGaWxlJ1xyXG4gIC8vICAgICBpZiAodXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX3Bob3RvIGluc3RhbmNlb2YgRmlsZSkge1xyXG4gIC8vICAgICAgIGZtRGF0YS5hcHBlbmQoXCJndWFyYW50b3JfcGhvdG9cIiwgdXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX3Bob3RvKTtcclxuICAvLyAgICAgfVxyXG4gIC8vICAgICAvLyBSZXBlYXQgdGhpcyBsb2dpYyBmb3IgYWxsIG90aGVyIHNpbmdsZSBmaWxlIGZpZWxkcy4uLlxyXG4gIC8vICAgICBpZiAodXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX2FhZGhhcl9kb2N1bWVudCBpbnN0YW5jZW9mIEZpbGUpIHtcclxuICAvLyAgICAgICBmbURhdGEuYXBwZW5kKFxyXG4gIC8vICAgICAgICAgXCJndWFyYW50b3JfYWFkaGFyX2RvY3VtZW50XCIsXHJcbiAgLy8gICAgICAgICB1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3JfYWFkaGFyX2RvY3VtZW50XHJcbiAgLy8gICAgICAgKTtcclxuICAvLyAgICAgfVxyXG5cclxuICAvLyAgICAgaWYgKGV4dHJhRG9jcyAmJiBBcnJheS5pc0FycmF5KGV4dHJhRG9jcykpIHtcclxuICAvLyAgICAgICBleHRyYURvY3MuZm9yRWFjaCgoZG9jLCBpKSA9PiB7XHJcbiAgLy8gICAgICAgICAvLyBDaGVjayBpZiB0aGUgaXRlbSBoYXMgYSBmaWxlIGFuZCBpdCdzIGEgbmV3IGZpbGUgb2JqZWN0XHJcbiAgLy8gICAgICAgICBpZiAoZG9jLmZpbGUgaW5zdGFuY2VvZiBGaWxlKSB7XHJcbiAgLy8gICAgICAgICAgIGZtRGF0YS5hcHBlbmQoXCJndWFyYW50b3JfYWxsX2RvY3VtZW50XCIsIGRvYy5maWxlKTtcclxuICAvLyAgICAgICAgICAgZm1EYXRhLmFwcGVuZChcclxuICAvLyAgICAgICAgICAgICBcImd1YXJhbnRvcl9hbGxfZG9jdW1lbnRcIixcclxuICAvLyAgICAgICAgICAgICBkb2MuZG9jdW1lbnRfbmFtZSB8fCBgRG9jXyR7aSArIDF9YFxyXG4gIC8vICAgICAgICAgICApO1xyXG4gIC8vICAgICAgICAgfVxyXG4gIC8vICAgICAgIH0pO1xyXG4gIC8vICAgICB9XHJcbiAgLy8gICAgIGF3YWl0IGFwaS5wdXQoXHJcbiAgLy8gICAgICAgYC9ndWFyYW50b3IvdXBkYXRlLWd1YXJhbnRvci1pbmZvLyR7Y3VycmVudFVwZGF0ZUd1YXJhbnRvcj8uX2lkfWAsXHJcbiAgLy8gICAgICAgZm1EYXRhLFxyXG4gIC8vICAgICAgIHtcclxuICAvLyAgICAgICAgIGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJtdWx0aXBhcnQvZm9ybS1kYXRhXCIgfSxcclxuICAvLyAgICAgICB9XHJcbiAgLy8gICAgICk7XHJcblxyXG4gIC8vICAgICBzZXRTaG93TW9kYWxVcGRhdGUoZmFsc2UpO1xyXG4gIC8vICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgLy8gICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAvLyAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAvLyAgICAgICBtZXNzYWdlOiBcIkd1YXJhbnRvciBVcGRhdGVkIFN1Y2Nlc3NmdWxseVwiLFxyXG4gIC8vICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgLy8gICAgIH0pO1xyXG4gIC8vICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAvLyAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIEd1YXJhbnRvcjpcIiwgZXJyb3IpO1xyXG4gIC8vICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgLy8gICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gIC8vICAgICAgIG1lc3NhZ2U6IGVycm9yPy5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIlVwZGF0ZSBmYWlsZWRcIixcclxuICAvLyAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gIC8vICAgICB9KTtcclxuICAvLyAgIH1cclxuICAvLyB9O1xyXG5jb25zdCBoYW5kbGVVcGRhdGUgPSBhc3luYyAoZSkgPT4ge1xyXG4gIGUucHJldmVudERlZmF1bHQoKTtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZm1EYXRhID0gbmV3IEZvcm1EYXRhKCk7XHJcblxyXG4gICAgY29uc3QgeyBndWFyYW50b3JfYWxsX2RvY3VtZW50LCAuLi5yZXN0IH0gPSB1cGRhdGVGb3JtRGF0YTtcclxuXHJcbiAgICAvLyBBcHBlbmQgbm9uLWZpbGUgZmllbGRzXHJcbiAgICBPYmplY3QuZW50cmllcyhyZXN0KS5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcclxuICAgICAgaWYgKHZhbHVlKSBmbURhdGEuYXBwZW5kKGtleSwgdmFsdWUpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgLy8gSGFuZGxlIHNpbmdsZSBmaWxlIGZpZWxkc1xyXG4gICAgY29uc3Qgc2luZ2xlRmlsZUZpZWxkcyA9IFtcclxuICAgICAgXCJndWFyYW50b3JfcGhvdG9cIixcclxuICAgICAgXCJndWFyYW50b3JfYWFkaGFyX2RvY3VtZW50XCIsXHJcbiAgICAgIFwiZ3VhcmFudG9yX3Bhbl9kb2N1bWVudFwiLFxyXG4gICAgICBcImd1YXJhbnRvcl9pbmNvbWVfZG9jdW1lbnRcIixcclxuICAgICAgXCJndWFyYW50b3JfYmFua19wYXNzYm9va19waG90b1wiLFxyXG4gICAgICBcImd1YXJhbnRvcl9kb2N1bWVudFwiLFxyXG4gICAgXTtcclxuXHJcbiAgICBzaW5nbGVGaWxlRmllbGRzLmZvckVhY2goKGZpZWxkKSA9PiB7XHJcbiAgICAgIGlmICh1cGRhdGVGb3JtRGF0YVtmaWVsZF0gaW5zdGFuY2VvZiBGaWxlKSB7XHJcbiAgICAgICAgZm1EYXRhLmFwcGVuZChmaWVsZCwgdXBkYXRlRm9ybURhdGFbZmllbGRdKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgLy8gSGFuZGxlIG11bHRpcGxlIGV4dHJhIGRvY3NcclxuICAgIGlmIChleHRyYURvY3MgJiYgQXJyYXkuaXNBcnJheShleHRyYURvY3MpKSB7XHJcbiAgICAgIGV4dHJhRG9jcy5mb3JFYWNoKChkb2MsIGkpID0+IHtcclxuICAgICAgICBpZiAoZG9jLmZpbGUgaW5zdGFuY2VvZiBGaWxlKSB7XHJcbiAgICAgICAgICBmbURhdGEuYXBwZW5kKFwiZ3VhcmFudG9yX2FsbF9kb2N1bWVudFwiLCBkb2MuZmlsZSk7IC8vIGZpbGVcclxuICAgICAgICAgIGZtRGF0YS5hcHBlbmQoXHJcbiAgICAgICAgICAgIFwiZG9jdW1lbnRfbmFtZVtdXCIsIC8vIOKchSBzZW5kIGFzIGFycmF5XHJcbiAgICAgICAgICAgIGRvYy5kb2N1bWVudF9uYW1lIHx8IGBEb2N1bWVudF8ke2kgKyAxfWBcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBhd2FpdCBhcGkucHV0KFxyXG4gICAgICBgL2d1YXJhbnRvci91cGRhdGUtZ3VhcmFudG9yLWluZm8vJHtjdXJyZW50VXBkYXRlR3VhcmFudG9yPy5faWR9YCxcclxuICAgICAgZm1EYXRhLFxyXG4gICAgICB7IGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJtdWx0aXBhcnQvZm9ybS1kYXRhXCIgfSB9XHJcbiAgICApO1xyXG5cclxuICAgIHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSk7XHJcbiAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICBtZXNzYWdlOiBcIkd1YXJhbnRvciBVcGRhdGVkIFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgfSk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBHdWFyYW50b3I6XCIsIGVycm9yKTtcclxuICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICBtZXNzYWdlOiBlcnJvcj8ucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJVcGRhdGUgZmFpbGVkXCIsXHJcbiAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICB9KTtcclxuICB9XHJcbn07XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcInVzZXJfaWRcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAge2tleTogXCJndWFyYW50b3JfY29kZVwiLCBoZWFkZXI6IFwiR3VhcmFudG9yIENvZGVcIn0sXHJcbiAgICB7IGtleTogXCJndWFyYW50b3JfcmVmZXJyZWRfdHlwZVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJlbnJvbGxtZW50X3N1bW1hcnlcIiwgaGVhZGVyOiBcIkVucm9sbG1lbnQgRGV0YWlsc1wiIH0sXHJcbiAgICB7IGtleTogXCJndWFyYW50b3JfbmFtZVwiLCBoZWFkZXI6IFwiR3VhcmFudG9yIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3VhcmFudG9yX3Bob25lX251bWJlclwiLCBoZWFkZXI6IFwiR3VhcmFudG9yIFBob25lIE51bWJlclwiIH0sXHJcbiAgICAvLyB7IGtleTogXCJndWFyYW50b3JfYWRkcmVzc1wiLCBoZWFkZXI6IFwiR3VhcmFudG9yIEFkZHJlc3NcIiB9LFxyXG4gICAgLy8geyBrZXk6IFwiZ3VhcmFudG9yX3BpbmNvZGVcIiwgaGVhZGVyOiBcIkd1YXJhbnRvciBQaW5jb2RlXCIgfSxcclxuICAgIC8vIHsga2V5OiBcImd1YXJhbnRvcl9kZXNjcmlwdGlvblwiLCBoZWFkZXI6IFwiR3VhcmFudG9yIERlc2NyaXB0aW9uXCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCBmaWx0ZXJlZEd1YXJhbnRvciA9IHVzZXJzLmZpbHRlcigodXNlcnMpID0+XHJcbiAgICB1c2Vycy5mdWxsX25hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hUZXJtLnRvTG93ZXJDYXNlKCkpXHJcbiAgKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlTW9kYWxPcGVuID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvZ3VhcmFudG9yL2dldC1ndWFyYW50b3ItaW5mby1ieS1pZC8ke3VzZXJJZH1gXHJcbiAgICAgICk7XHJcbiAgICAgIHNldEN1cnJlbnRHdWFyYW50b3IocmVzcG9uc2UuZGF0YT8uZ3VhcmFudG9yKTtcclxuICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIEd1YXJhbnRvcjpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUZpbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCBmaWxlcyB9ID0gZS50YXJnZXQ7XHJcbiAgICBjb25zdCBmaWxlID0gZmlsZXNbMF07XHJcblxyXG4gICAgaWYgKGZpbGUpIHtcclxuICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgLi4ucHJldixcclxuICAgICAgICBbbmFtZV06IGZpbGUsIC8vIOKchSBrZWVwIHJlYWwgZmlsZSBvYmplY3RcclxuICAgICAgICBbYCR7bmFtZX1fcHJldmlld2BdOiBVUkwuY3JlYXRlT2JqZWN0VVJMKGZpbGUpLCAvLyBmb3IgcHJldmlld1xyXG4gICAgICB9KSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxPcGVuID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvZ3VhcmFudG9yL2dldC1ndWFyYW50b3ItaW5mby1ieS1pZC8ke3VzZXJJZH1gXHJcbiAgICAgICk7XHJcbiAgICAgIGNvbnN0IGd1YXJhbnRvciA9IHJlc3BvbnNlPy5kYXRhPy5ndWFyYW50b3I7XHJcbiAgICAgIGNvbnN0IG1hdGNoZWRFbnJvbGxtZW50cyA9IChndWFyYW50b3I/LmVucm9sbG1lbnRfaWRzIHx8IFtdKS5tYXAoKGUpID0+ICh7XHJcbiAgICAgICAgX2lkOiBlLl9pZCxcclxuICAgICAgICBncm91cF9uYW1lOiBlPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgIHRpY2tldDogZT8udGlja2V0cyB8fCBcIk4vQVwiLFxyXG4gICAgICB9KSk7XHJcbiAgICAgIHNldEZpbHRlcmVkRW5yb2xsbWVudHMobWF0Y2hlZEVucm9sbG1lbnRzKTtcclxuXHJcbiAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICB1c2VyX2lkOiBndWFyYW50b3I/LnVzZXJfaWQ/Ll9pZCB8fCBcIlwiLFxyXG4gICAgICAgIGVucm9sbG1lbnRfaWRzOiBndWFyYW50b3I/LmVucm9sbG1lbnRfaWRzPy5tYXAoKGUpID0+IGUuX2lkKSB8fCBbXSxcclxuICAgICAgICBndWFyYW50b3JfbmFtZTogZ3VhcmFudG9yPy5ndWFyYW50b3JfbmFtZSB8fCBcIlwiLFxyXG4gICAgICAgIGd1YXJhbnRvcl9lbWFpbDogZ3VhcmFudG9yPy5ndWFyYW50b3JfZW1haWwgfHwgXCJcIixcclxuICAgICAgICBndWFyYW50b3JfcGhvbmVfbnVtYmVyOiBndWFyYW50b3I/Lmd1YXJhbnRvcl9waG9uZV9udW1iZXIgfHwgXCJcIixcclxuICAgICAgICB1c2VyX2d1YXJhbnRvcjogZ3VhcmFudG9yPy51c2VyX2d1YXJhbnRvciB8fCBcIlwiLFxyXG4gICAgICAgIGd1YXJhbnRvcl9hZGRyZXNzOiBndWFyYW50b3I/Lmd1YXJhbnRvcl9hZGRyZXNzIHx8IFwiXCIsXHJcbiAgICAgICAgZ3VhcmFudG9yX3BpbmNvZGU6IGd1YXJhbnRvcj8uZ3VhcmFudG9yX3BpbmNvZGUgfHwgXCJcIixcclxuICAgICAgICBndWFyYW50b3JfYWRoYWFyX25vOiBndWFyYW50b3I/Lmd1YXJhbnRvcl9hZGhhYXJfbm8gfHwgXCJcIixcclxuICAgICAgICBndWFyYW50b3JfcGFuX25vOiBndWFyYW50b3I/Lmd1YXJhbnRvcl9wYW5fbm8gfHwgXCJcIixcclxuICAgICAgICBndWFyYW50b3JfZ2VuZGVyOiBndWFyYW50b3I/Lmd1YXJhbnRvcl9nZW5kZXIgfHwgXCJcIixcclxuICAgICAgICBndWFyYW50b3JfbWFyaXRhbF9zdGF0dXM6IGd1YXJhbnRvcj8uZ3VhcmFudG9yX21hcml0YWxfc3RhdHVzIHx8IFwiXCIsXHJcbiAgICAgICAgZ3VhcmFudG9yX2RhdGVvZmJpcnRoOiBndWFyYW50b3I/Lmd1YXJhbnRvcl9kYXRlb2ZiaXJ0aCB8fCBcIlwiLFxyXG4gICAgICAgIGd1YXJhbnRvcl9uYXRpb25hbGl0eTogZ3VhcmFudG9yPy5ndWFyYW50b3JfbmF0aW9uYWxpdHkgfHwgXCJcIixcclxuICAgICAgICBndWFyYW50b3JfdmlsbGFnZTogZ3VhcmFudG9yPy5ndWFyYW50b3JfdmlsbGFnZSB8fCBcIlwiLFxyXG4gICAgICAgIGd1YXJhbnRvcl90YWx1azogZ3VhcmFudG9yPy5ndWFyYW50b3JfdGFsdWsgfHwgXCJcIixcclxuICAgICAgICBndWFyYW50b3JfZmF0aGVyX25hbWU6IGd1YXJhbnRvcj8uZ3VhcmFudG9yX2ZhdGhlcl9uYW1lIHx8IFwiXCIsXHJcbiAgICAgICAgZ3VhcmFudG9yX2Rpc3RyaWN0OiBndWFyYW50b3I/Lmd1YXJhbnRvcl9kaXN0cmljdCB8fCBcIlwiLFxyXG4gICAgICAgIGd1YXJhbnRvcl9zdGF0ZTogZ3VhcmFudG9yPy5ndWFyYW50b3Jfc3RhdGUgfHwgXCJcIixcclxuICAgICAgICBndWFyYW50b3JfZGVzY3JpcHRpb246IGd1YXJhbnRvcj8uZ3VhcmFudG9yX2Rlc2NyaXB0aW9uIHx8IFwiXCIsXHJcbiAgICAgICAgZ3VhcmFudG9yX2FsdGVybmF0ZV9udW1iZXI6IGd1YXJhbnRvcj8uZ3VhcmFudG9yX2FsdGVybmF0ZV9udW1iZXIsXHJcbiAgICAgICAgZ3VhcmFudG9yX2RvY3VtZW50OiBndWFyYW50b3I/Lmd1YXJhbnRvcl9kb2N1bWVudCB8fCBcIlwiLFxyXG4gICAgICAgIGd1YXJhbnRvcl9kb2N1bWVudF9uYW1lOiBndWFyYW50b3I/Lmd1YXJhbnRvcl9kb2N1bWVudF9uYW1lIHx8IFwiXCIsXHJcbiAgICAgICAgZ3VhcmFudG9yX3JlZmVycmVkX3R5cGU6IGd1YXJhbnRvcj8uZ3VhcmFudG9yX3JlZmVycmVkX3R5cGUgfHwgXCJcIixcclxuICAgICAgICBndWFyYW50b3JfcGhvdG86IGd1YXJhbnRvcj8uZ3VhcmFudG9yX3Bob3RvIHx8IFwiXCIsXHJcbiAgICAgICAgZ3VhcmFudG9yX3Bhbl9kb2N1bWVudDogZ3VhcmFudG9yPy5ndWFyYW50b3JfcGFuX2RvY3VtZW50IHx8IFwiXCIsXHJcbiAgICAgICAgZ3VhcmFudG9yX2FhZGhhcl9kb2N1bWVudDogZ3VhcmFudG9yPy5ndWFyYW50b3JfYWFkaGFyX2RvY3VtZW50IHx8IFwiXCIsXHJcbiAgICAgICAgZ3VhcmFudG9yX3JlbGF0aW9uc2hpcF90eXBlOlxyXG4gICAgICAgICAgZ3VhcmFudG9yPy5ndWFyYW50b3JfcmVsYXRpb25zaGlwX3R5cGUgfHwgXCJcIixcclxuICAgICAgICBndWFyYW50b3Jfb2NjdXBhdGlvbjogZ3VhcmFudG9yPy5ndWFyYW50b3Jfb2NjdXBhdGlvbiB8fCBcIlwiLFxyXG4gICAgICAgIGd1YXJhbnRvcl9pbmNvbWU6IGd1YXJhbnRvcj8uZ3VhcmFudG9yX2luY29tZSB8fCBcIlwiLFxyXG4gICAgICAgIGd1YXJhbnRvcl9jb25zZW50X2RvY3VtZW50OiBndWFyYW50b3I/Lmd1YXJhbnRvcl9jb25zZW50X2RvY3VtZW50IHx8IFwiXCIsXHJcbiAgICAgICAgZ3VhcmFudG9yX2JhbmtfbmFtZTogZ3VhcmFudG9yPy5ndWFyYW50b3JfYmFua19uYW1lIHx8IFwiXCIsXHJcbiAgICAgICAgZ3VhcmFudG9yX2JhbmtfYWNjb3VudF9udW1iZXI6XHJcbiAgICAgICAgICBndWFyYW50b3I/Lmd1YXJhbnRvcl9iYW5rX2FjY291bnRfbnVtYmVyIHx8IFwiXCIsXHJcbiAgICAgICAgZ3VhcmFudG9yX2JhbmtfYnJhbmNoOiBndWFyYW50b3I/Lmd1YXJhbnRvcl9iYW5rX2JyYW5jaCB8fCBcIlwiLFxyXG4gICAgICAgIGd1YXJhbnRvcl9iYW5rX2lmc2NfY29kZTogZ3VhcmFudG9yPy5ndWFyYW50b3JfYmFua19pZnNjX2NvZGUgfHwgXCJcIixcclxuICAgICAgICBndWFyYW50b3JfYmFua19wYXNzYm9va19waG90bzpcclxuICAgICAgICAgIGd1YXJhbnRvcj8uZ3VhcmFudG9yX2JhbmtfcGFzc2Jvb2tfcGhvdG8gfHwgXCJcIixcclxuICAgICAgICBndWFyYW50b3JfaW5jb21lX2RvY3VtZW50OiBndWFyYW50b3IuZ3VhcmFudG9yX2luY29tZV9kb2N1bWVudCB8fCBcIlwiLFxyXG4gICAgICAgIGd1YXJhbnRvcl9idXNzaW5lc3NfdHlwZTogZ3VhcmFudG9yLmd1YXJhbnRvcl9idXNzaW5lc3NfdHlwZSB8fCBcIlwiLFxyXG4gICAgICAgIGd1YXJhbnRvcl9idXNzaW5lc3NfbmFtZTogZ3VhcmFudG9yLmd1YXJhbnRvcl9idXNzaW5lc3NfbmFtZSB8fCBcIlwiLFxyXG4gICAgICAgIGd1YXJhbnRvcl9idXNzaW5lc3NfYWRkcmVzczpcclxuICAgICAgICAgIGd1YXJhbnRvcj8uZ3VhcmFudG9yX2J1c3NpbmVzc19hZGRyZXNzIHx8IFwiXCIsXHJcbiAgICAgICAgZ3VhcmFudG9yX3Byb2Zlc3Npb25fdHlwZTogZ3VhcmFudG9yPy5ndWFyYW50b3JfcHJvZmVzc2lvbl90eXBlIHx8IFwiXCIsXHJcbiAgICAgICAgZ3VhcmFudG9yX2FncmlfcnRjX25vOiBndWFyYW50b3I/Lmd1YXJhbnRvcl9hZ3JpX3J0Y19ubyB8fCBcIlwiLFxyXG4gICAgICAgIGd1YXJhbnRvcl9sYW5kX2hvbGRpbmdzOiBndWFyYW50b3I/Lmd1YXJhbnRvcl9sYW5kX2hvbGRpbmdzIHx8IFwiXCIsXHJcbiAgICAgICAgZ3VhcmFudG9yX29jY3VwYXRpb25fc3ViOiBndWFyYW50b3I/Lmd1YXJhbnRvcl9vY2N1cGF0aW9uX3N1YiB8fCBcIlwiLFxyXG4gICAgICAgIGd1YXJhbnRvcl9hbGxfZG9jdW1lbnRfbmFtZTpcclxuICAgICAgICAgIGd1YXJhbnRvcj8uZ3VhcmFudG9yX2FsbF9kb2N1bWVudF9uYW1lIHx8IFwiXCIsXHJcbiAgICAgICAgZ3VhcmFudG9yX2FsbF9kb2N1bWVudDogZ3VhcmFudG9yPy5ndWFyYW50b3JfYWxsX2RvY3VtZW50IHx8IFwiXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRFeHRyYURvY3MoXHJcbiAgICAgICAgKGd1YXJhbnRvcj8uZ3VhcmFudG9yX2FsbF9kb2N1bWVudCB8fCBbXSkubWFwKChkKSA9PiAoe1xyXG4gICAgICAgICAgZG9jdW1lbnRfbmFtZTogZC5kb2N1bWVudF9uYW1lLFxyXG4gICAgICAgICAgZmlsZTogbnVsbCwgLy8gbm8gbmV3IGZpbGUgeWV0XHJcbiAgICAgICAgICBwcmV2aWV3OiBkLmRvY3VtZW50X3VybCwgLy8gc2hvdyBleGlzdGluZyBmaWxlIHByZXZpZXdcclxuICAgICAgICAgIGV4aXN0aW5nVXJsOiBkLmRvY3VtZW50X3VybCwgLy8ga2VlcCBvcmlnaW5hbCBpbiBjYXNlIHVzZXIgZG9lc27igJl0IHJlcGxhY2VcclxuICAgICAgICB9KSlcclxuICAgICAgKTtcclxuXHJcbiAgICAgIHNldEN1cnJlbnRVcGRhdGVHdWFyYW50b3IoZ3VhcmFudG9yKTtcclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKHRydWUpO1xyXG4gICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIEd1YXJhbnRvcjpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlSW5wdXRDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG4gICAgc2V0RXJyb3JzKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtuYW1lXTogXCJcIixcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVHdWFyYW50b3IgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoY3VycmVudEd1YXJhbnRvcikge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGF3YWl0IGFwaS5kZWxldGUoXHJcbiAgICAgICAgICBgL2d1YXJhbnRvci9kZWxldGUtZ3VhcmFudG9yLWluZm8tYnktaWQvJHtjdXJyZW50R3VhcmFudG9yLl9pZH1gXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiZ3VhcmFudG9yIGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICBzZXRDdXJyZW50R3VhcmFudG9yKG51bGwpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBkZWxldGluZyBHdWFyYW50b3I6XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXtHbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxDdXN0b21BbGVydERpYWxvZ1xyXG4gICAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbiAgICAgICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+XHJcbiAgICAgICAgICAgICAgc2V0QWxlcnRDb25maWcoKHByZXYpID0+ICh7IC4uLnByZXYsIHZpc2liaWxpdHk6IGZhbHNlIH0pKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5HdWFyYW50b3I8L2gxPlxyXG5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFNob3dNb2RhbCh0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC00IGJnLXZpb2xldC05NTAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZCBzaGFkb3ctbWQgaG92ZXI6YmctdmlvbGV0LTgwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICsgQWRkIEd1YXJhbnRvclxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7VGFibGVHdWFyYW50b3I/Lmxlbmd0aCA+IDAgJiYgIWlzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICBjYXRjaGVyPVwiX2lkXCJcclxuICAgICAgICAgICAgICAgIHVwZGF0ZUhhbmRsZXI9e2hhbmRsZVVwZGF0ZU1vZGFsT3Blbn1cclxuICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbihUYWJsZUd1YXJhbnRvciwgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiR3VhcmFudG9yXCJcclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BHdWFyYW50b3IuY3N2YH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICBmYWlsdXJlPXtUYWJsZUd1YXJhbnRvci5sZW5ndGggPD0gMH1cclxuICAgICAgICAgICAgICAgIGRhdGE9XCJHdWFyYW50b3IgRGF0YVwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxNb2RhbCBpc1Zpc2libGU9e3Nob3dNb2RhbH0gb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsKGZhbHNlKX0+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgQWRkIEd1YXJhbnRvclxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiXHJcbiAgICAgICAgICAgICAgbWV0aG9kPVwiUE9TVFwiXHJcbiAgICAgICAgICAgICAgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH1cclxuICAgICAgICAgICAgICBlbmN0eXBlPVwibXVsdGlwYXJ0L2Zvcm0tZGF0YVwiXHJcbiAgICAgICAgICAgICAgbm9WYWxpZGF0ZVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBDdXN0b21lciBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEudXNlcl9pZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICB1c2VyX2lkOiB2YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgIGVucm9sbG1lbnRfaWRzOiBbXSxcclxuICAgICAgICAgICAgICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpbHRlcmVkID0gZW5yb2xsbWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgLmZpbHRlcigoZSkgPT4gZS51c2VyX2lkPy5faWQgPT09IHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgLm1hcCgoZSkgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgX2lkOiBlLl9pZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXBfbmFtZTogZS5ncm91cF9pZD8uZ3JvdXBfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGlja2V0OiBlLnRpY2tldHMsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHNldEZpbHRlcmVkRW5yb2xsbWVudHMoZmlsdGVyZWQpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbj8uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgID8udG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge0FycmF5LmZyb20oXHJcbiAgICAgICAgICAgICAgICAgICAgbmV3IE1hcChcclxuICAgICAgICAgICAgICAgICAgICAgIGVucm9sbG1lbnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmZpbHRlcigoZSkgPT4gZS51c2VyX2lkICYmIGUudXNlcl9pZC5mdWxsX25hbWU/LnRyaW0oKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgLm1hcCgoZSkgPT4gW2UudXNlcl9pZC5faWQsIGUudXNlcl9pZF0pXHJcbiAgICAgICAgICAgICAgICAgICAgKS52YWx1ZXMoKVxyXG4gICAgICAgICAgICAgICAgICApLm1hcCgodXNlcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dXNlci5faWR9IHZhbHVlPXt1c2VyLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7dXNlci5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy51c2VyX2lkICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMudXNlcl9pZH08L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFNlbGVjdCBFbnJvbGxtZW50IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBtb2RlPVwidGFnc1wiXHJcbiAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgZW5yb2xsbWVudHNcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmVucm9sbG1lbnRfaWRzfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHNlbGVjdGVkRW5yb2xsbWVudElkcykgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgIGVucm9sbG1lbnRfaWRzOiBzZWxlY3RlZEVucm9sbG1lbnRJZHMsXHJcbiAgICAgICAgICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbj8ubGFiZWw/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRFbnJvbGxtZW50cy5tYXAoKGVuKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcGFydHMgPSBbXTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZW4uZ3JvdXBfbmFtZSAmJiBlbi5ncm91cF9uYW1lICE9PSBcIk4vQVwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGFydHMucHVzaChlbi5ncm91cF9uYW1lKTtcclxuICAgICAgICAgICAgICAgICAgICBpZiAoZW4udGlja2V0ICYmIGVuLnRpY2tldCAhPT0gXCJOL0FcIilcclxuICAgICAgICAgICAgICAgICAgICAgIHBhcnRzLnB1c2goYFRpY2tldDogJHtlbi50aWNrZXR9YCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17ZW4uX2lkfSB2YWx1ZT17ZW4uX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3BhcnRzLmpvaW4oXCIgfCBcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuXHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLmVucm9sbG1lbnRfaWRzICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZW5yb2xsbWVudF9pZHN9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwicmVmZXJyZWRfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFNlbGVjdCBSZWZlcnJlZCBUeXBlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFJlZmVycmVkIFR5cGVcIlxyXG4gICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfcmVmZXJyZWRfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/Lmd1YXJhbnRvcl9yZWZlcnJlZF90eXBlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnREU2VsZWN0KFwiZ3VhcmFudG9yX3JlZmVycmVkX3R5cGVcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge1tcIkN1c3RvbWVyXCIsIFwiVGhpcmQgUGFydHlcIiwgXCJQcm9wZXJ0eVwiXS5tYXAoKHJlZlR5cGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3JlZlR5cGV9IHZhbHVlPXtyZWZUeXBlfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtyZWZUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX3JlZmVycmVkX3R5cGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfcmVmZXJyZWRfdHlwZX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAge2Zvcm1EYXRhLmd1YXJhbnRvcl9yZWZlcnJlZF90eXBlID09PSBcIkN1c3RvbWVyXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgR3VhcmFudG9yIEN1c3RvbWVye1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggUmVmZXJyZWQgR3VhcmFudG9yXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwidXNlcl9ndWFyYW50b3JcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy51c2VyX2d1YXJhbnRvciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnREU2VsZWN0KFwidXNlcl9ndWFyYW50b3JcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3VzZXJzLm1hcCgodXNlcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLmZ1bGxfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy51c2VyX2d1YXJhbnRvciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMudXNlcl9ndWFyYW50b3J9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGVzY1wiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRGVzY3JpcHRpb24gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfZGVzY3JpcHRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmd1YXJhbnRvcl9kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgRGVzY3JpcHRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyICR7ZmllbGRTaXplLmhlaWdodH0gYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9kZXNjcmlwdGlvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2Rlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICB7Zm9ybURhdGEuZ3VhcmFudG9yX3JlZmVycmVkX3R5cGUgPT09IFwiVGhpcmQgUGFydHlcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNiBtdC02XCI+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiBQZXJzb25hbCBJbmZvcm1hdGlvbiBDYXJkICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBwLTYgYmctd2hpdGUgc2hhZG93LW1kXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCB0ZXh0LWNlbnRlciBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBQZXJzb25hbCBJbmZvcm1hdGlvblxyXG4gICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBHdWFyYW50b3IgTmFtZSAmIFBob25lICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgR3VhcmFudG9yIE5hbWUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmd1YXJhbnRvcl9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBHdWFyYW50b3IgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfbmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUGhvbmUgTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX3Bob25lX251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmd1YXJhbnRvcl9waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBob25lIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfcGhvbmVfbnVtYmVyICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBDdXN0b21lciBSZWxhdGlvbnNoaXAgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTQgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IEN1c3RvbWVyIFJlbGF0aW9uc2hpcFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBDdXN0b21lciBSZWxhdGlvbnNoaXBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX3JlbGF0aW9uc2hpcF90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5ndWFyYW50b3JfcmVsYXRpb25zaGlwX3R5cGUgfHwgdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnREU2VsZWN0KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImd1YXJhbnRvcl9yZWxhdGlvbnNoaXBfdHlwZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtbXCJGYXRoZXJcIiwgXCJTcG91c2VcIiwgXCJPdGhlclwiXS5tYXAoKHJlbCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtyZWx9IHZhbHVlPXtyZWx9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfcmVsYXRpb25zaGlwX3R5cGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX3JlbGF0aW9uc2hpcF90eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5ndWFyYW50b3JfcmVsYXRpb25zaGlwX3R5cGUgPT09IFwiT3RoZXJcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBQbGVhc2Ugc3BlY2lmeSB0aGUgcmVsYXRpb25zaGlwOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBjdXN0b20gcmVsYXRpb25zaGlwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXN0b21SZWxhdGlvbnNoaXB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEN1c3RvbVJlbGF0aW9uc2hpcChlLnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBFbWFpbCAmIERPQiAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNCBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEVtYWlsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl9lbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmd1YXJhbnRvcl9lbWFpbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2VtYWlsICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9lbWFpbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRGF0ZSBvZiBCaXJ0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl9kYXRlb2ZiaXJ0aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEuZ3VhcmFudG9yX2RhdGVvZmJpcnRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gbmV3IERhdGUoZm9ybURhdGEuZ3VhcmFudG9yX2RhdGVvZmJpcnRoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvSVNPU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5zcGxpdChcIlRcIilbMF1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIE1hcml0YWwgU3RhdHVzICYgR2VuZGVyICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTWFyaXRhbCBTdGF0dXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgTWFyaXRhbCBTdGF0dXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX21hcml0YWxfc3RhdHVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZ3VhcmFudG9yX21hcml0YWxfc3RhdHVzIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcImd1YXJhbnRvcl9tYXJpdGFsX3N0YXR1c1wiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7W1wiTWFycmllZFwiLCBcIlVubWFycmllZFwiLCBcIldpZG93XCIsIFwiRGl2b3JjZWRcIl0ubWFwKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKHN0YXR1cykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3N0YXR1c30gdmFsdWU9e3N0YXR1c30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0YXR1c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEdlbmRlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBHZW5kZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2dlbmRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmd1YXJhbnRvcl9nZW5kZXIgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnREU2VsZWN0KFwiZ3VhcmFudG9yX2dlbmRlclwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7W1wiTWFsZVwiLCBcIkZlbWFsZVwiXS5tYXAoKGcpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z30gdmFsdWU9e2d9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIEFkZHJlc3MgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWRkcmVzcyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ndWFyYW50b3JfYWRkcmVzc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgQWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYWRkcmVzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogVmlsbGFnZSAmIFRhbHVrICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgVmlsbGFnZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl92aWxsYWdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZ3VhcmFudG9yX3ZpbGxhZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFZpbGxhZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgVGFsdWtcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfdGFsdWtcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ndWFyYW50b3JfdGFsdWt9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFRhbHVrXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBTdGF0ZSAmIERpc3RyaWN0ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgU3RhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgU3RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX3N0YXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZ3VhcmFudG9yX3N0YXRlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcImd1YXJhbnRvcl9zdGF0ZVwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7W1wiS2FybmF0YWthXCIsIFwiTWFoYXJhc2h0cmFcIiwgXCJUYW1pbCBOYWR1XCJdLm1hcChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChzdGF0ZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3N0YXRlfSB2YWx1ZT17c3RhdGV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIERpc3RyaWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2Rpc3RyaWN0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZ3VhcmFudG9yX2Rpc3RyaWN0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBEaXN0cmljdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogUGluY29kZSAmIEZhdGhlciBOYW1lICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUGluY29kZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl9waW5jb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZ3VhcmFudG9yX3BpbmNvZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfcGluY29kZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfcGluY29kZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRmF0aGVyIE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfZmF0aGVyX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ndWFyYW50b3JfZmF0aGVyX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEZhdGhlciBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBOYXRpb25hbGl0eSAmIEFsdGVybmF0ZSBOdW1iZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTQgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBOYXRpb25hbGl0eVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBOYXRpb25hbGl0eVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfbmF0aW9uYWxpdHlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ndWFyYW50b3JfbmF0aW9uYWxpdHkgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnREU2VsZWN0KFwiZ3VhcmFudG9yX25hdGlvbmFsaXR5XCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtbXCJJbmRpYW5cIiwgXCJPdGhlclwiXS5tYXAoKG5hdGlvbikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtuYXRpb259IHZhbHVlPXtuYXRpb259PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bmF0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBBbHRlcm5hdGUgUGhvbmUgTnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2FsdGVybmF0ZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ndWFyYW50b3JfYWx0ZXJuYXRlX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQWx0ZXJuYXRlIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBLWUMgRG9jdW1lbnRzIENhcmQgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHAtNiBiZy13aGl0ZSBzaGFkb3ctbWRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIHRleHQtY2VudGVyIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEtZQyBEb2N1bWVudHNcclxuICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogQWFkaGFhciAmIFBBTiBOdW1iZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQWFkaGFhciBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfYWRoYWFyX25vXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZ3VhcmFudG9yX2FkaGFhcl9ub31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQWFkaGFhciBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYWRoYWFyX25vICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9hZGhhYXJfbm99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFBBTiBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfcGFuX25vXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZ3VhcmFudG9yX3Bhbl9ub31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUEFOIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9wYW5fbm8gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX3Bhbl9ub31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIFByb2ZpbGUgUGhvdG8gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUHJvZmlsZSBQaG90byA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfcGhvdG9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfcGhvdG8gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX3Bob3RvfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5ndWFyYW50b3JfcGhvdG8gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGluayB0bz17Zm9ybURhdGEuZ3VhcmFudG9yX3Bob3RvfSBkb3dubG9hZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2Zvcm1EYXRhLmd1YXJhbnRvcl9waG90b19wcmV2aWV3fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwiUHJvZmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTU2IGgtNTYgb2JqZWN0LWNvdmVyIG10LTQgcm91bmRlZC1tZCBzaGFkb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIFBBTiAmIEFhZGhhYXIgRG9jcyAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNCBtdC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFBBTiBDYXJkIFBob3RvIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX3Bhbl9kb2N1bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUZpbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9wYW5fZG9jdW1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX3Bhbl9kb2N1bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5ndWFyYW50b3JfcGFuX2RvY3VtZW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayB0bz17Zm9ybURhdGEuZ3VhcmFudG9yX3Bhbl9kb2N1bWVudH0gZG93bmxvYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17Zm9ybURhdGEuZ3VhcmFudG9yX3Bhbl9kb2N1bWVudF9wcmV2aWV3fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9XCJQQU5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTU2IGgtNTYgb2JqZWN0LWNvdmVyIG10LTQgcm91bmRlZC1tZCBzaGFkb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEFhZGhhYXIgQ2FyZCBQaG90b3tcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl9hYWRoYXJfZG9jdW1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVGaWxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYWFkaGFyX2RvY3VtZW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9hYWRoYXJfZG9jdW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuZ3VhcmFudG9yX2FhZGhhcl9kb2N1bWVudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPXtmb3JtRGF0YS5ndWFyYW50b3JfYWFkaGFyX2RvY3VtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZG93bmxvYWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17Zm9ybURhdGEuZ3VhcmFudG9yX2FhZGhhcl9kb2N1bWVudF9wcmV2aWV3fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9XCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTU2IGgtNTYgb2JqZWN0LWNvdmVyIG10LTQgcm91bmRlZC1tZCBzaGFkb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qICBFeHRyYSBEeW5hbWljIERvY3VtZW50cyBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEFkZGl0aW9uYWwgRG9jdW1lbnRzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2V4dHJhRG9jcy5tYXAoKGRvYywgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItNiBwLTMgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIGJnLWdyYXktNTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFJvdyBmb3IgaW5wdXRzICsgcmVtb3ZlIGJ1dHRvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJEb2N1bWVudCBOYW1lIChlLmcuIFBhc3Nwb3J0LCBWb3RlciBJRClcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZG9jLmRvY3VtZW50X25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVFeHRyYURvY05hbWVDaGFuZ2UoaW5kZXgsIGUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzIgaC0xMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcC0yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2FsbF9kb2N1bWVudFwiIC8vIOKaoO+4jyBtdXN0IG1hdGNoIG11bHRlciBjb25maWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUV4dHJhRG9jRmlsZUNoYW5nZShpbmRleCwgZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzIgaC0xMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlbW92ZURvY0ZpZWxkKGluZGV4KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwIGZvbnQtYm9sZCB0ZXh0LXhsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElvTWRDbG9zZSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBQcmV2aWV3IHNob3duIGJlbG93ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtkb2MucHJldmlldyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17ZG9jLnByZXZpZXd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXtkb2MuZG9jdW1lbnRfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTU2IGgtNTYgb2JqZWN0LWNvdmVyIHJvdW5kZWQtbWQgc2hhZG93XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17YWRkTmV3RG9jRmllbGR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTIgcHgtMiBweS0xIGJnLXZpb2xldC02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdyBob3ZlcjpiZy12aW9sZXQtNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKyBBZGQgRG9jdW1lbnRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHAtNiBiZy13aGl0ZSBzaGFkb3ctbWRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIHRleHQtY2VudGVyIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIE9jY3VwYXRpb24gRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogTGVmdCBDb2x1bW46IE9jY3VwYXRpb24gJiBEeW5hbWljIEZpZWxkcyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEd1YXJhbnRvciBPY2N1cGF0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogTWFpbiBPY2N1cGF0aW9uIFNlbGVjdCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT2NjdXBhdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ndWFyYW50b3Jfb2NjdXBhdGlvbiB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gUmVzZXQgcmVsYXRlZCBmaWVsZHMgd2hlbiBvY2N1cGF0aW9uIGNoYW5nZXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBndWFyYW50b3Jfb2NjdXBhdGlvbjogdmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGd1YXJhbnRvcl9vY2N1cGF0aW9uX3N1YjogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3VhcmFudG9yX2J1c3NpbmVzc190eXBlOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBndWFyYW50b3JfYnVzc2luZXNzX25hbWU6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGd1YXJhbnRvcl9idXNzaW5lc3NfYWRkcmVzczogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3VhcmFudG9yX3Byb2Zlc3Npb25fdHlwZTogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3VhcmFudG9yX2FncmlfcnRjX25vOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBndWFyYW50b3JfbGFuZF9ob2xkaW5nczogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiU2VsZiBFbXBsb3llZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJTYWxhcmllZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJQcm9mZXNzaW9uYWxcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiQWdyaSBBbGxpZWRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiT3RoZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBdLm1hcCgob2NjKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e29jY30gdmFsdWU9e29jY30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvY2N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9vY2N1cGF0aW9uICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9vY2N1cGF0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIFN1Yi1vcHRpb24gZm9yIFwiT3RoZXJcIiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmd1YXJhbnRvcl9vY2N1cGF0aW9uID09PSBcIk90aGVyXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBsZWFzZSBzcGVjaWZ5IE9jY3VwYXRpb246XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFN1Yi1DYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLmd1YXJhbnRvcl9vY2N1cGF0aW9uX3N1YiB8fCB1bmRlZmluZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBndWFyYW50b3Jfb2NjdXBhdGlvbl9zdWI6IHZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiSG91c2UgV2lmZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJSZXRpcmVkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlN0dWRlbnRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiSW52ZXN0bWVudFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJSdW5uaW5nIGFuIHVucmVnaXN0ZXJlZCBCdXNpbmVzc1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF0ubWFwKChzdWIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17c3VifSB2YWx1ZT17c3VifT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N1Yn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX29jY3VwYXRpb25fc3ViICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9vY2N1cGF0aW9uX3N1Yn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFkZHJlc3NcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfYnVzc2luZXNzX2FkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ndWFyYW50b3JfYnVzc2luZXNzX2FkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyICBBZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0zIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9idXNzaW5lc3NfYWRkcmVzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYnVzc2luZXNzX2FkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogU2VsZiBFbXBsb3llZCAmIFNhbGFyaWVkOiBCdXNpbmVzcyBUeXBlLCBOYW1lLCBBZGRyZXNzICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7W1wiU2VsZiBFbXBsb3llZFwiLCBcIlNhbGFyaWVkXCJdLmluY2x1ZGVzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLmd1YXJhbnRvcl9vY2N1cGF0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJ1c2luZXNzIFR5cGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfYnVzc2luZXNzX3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ndWFyYW50b3JfYnVzc2luZXNzX3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4sIFJldGFpbCwgTWFudWZhY3R1cmluZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9idXNzaW5lc3NfdHlwZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYnVzc2luZXNzX3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCdXNpbmVzcyBOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2J1c3NpbmVzc19uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZ3VhcmFudG9yX2J1c3NpbmVzc19uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBCdXNpbmVzcyBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0zIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2J1c3NpbmVzc19uYW1lICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9idXNzaW5lc3NfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFkZHJlc3NcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfYnVzc2luZXNzX2FkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ndWFyYW50b3JfYnVzc2luZXNzX2FkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTMgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYnVzc2luZXNzX2FkZHJlc3MgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2J1c3NpbmVzc19hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIFByb2Zlc3Npb25hbDogUHJvZmVzc2lvbiBUeXBlICsgQnVzaW5lc3MgQWRkcmVzcyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmd1YXJhbnRvcl9vY2N1cGF0aW9uID09PSBcIlByb2Zlc3Npb25hbFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQcm9mZXNzaW9uIFR5cGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfcHJvZmVzc2lvbl90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZ3VhcmFudG9yX3Byb2Zlc3Npb25fdHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiwgRG9jdG9yLCBDQSwgRW5naW5lZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTMgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfcHJvZmVzc2lvbl90eXBlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9wcm9mZXNzaW9uX3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBZGRyZXNzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2J1c3NpbmVzc19hZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZ3VhcmFudG9yX2J1c3NpbmVzc19hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJDbGluaWMvT2ZmaWNlIEFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTMgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYnVzc2luZXNzX2FkZHJlc3MgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2J1c3NpbmVzc19hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEFncmkgQWxsaWVkOiBSVEMgTm8sIExhbmQgSG9sZGluZ3MsIEJ1c2luZXNzIEFkZHJlc3MgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5ndWFyYW50b3Jfb2NjdXBhdGlvbiA9PT0gXCJBZ3JpIEFsbGllZFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgdy1mdWxsIHNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUlRDIE5vIC8gTGFuZCBSZWNvcmQgSURcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfYWdyaV9ydGNfbm9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ndWFyYW50b3JfYWdyaV9ydGNfbm99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFJUQyBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTMgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYWdyaV9ydGNfbm8gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2FncmlfcnRjX25vfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTGFuZCBIb2xkaW5ncyAoaW4gYWNyZXMpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfbGFuZF9ob2xkaW5nc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmd1YXJhbnRvcl9sYW5kX2hvbGRpbmdzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuLCA1LjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTMgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfbGFuZF9ob2xkaW5ncyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfbGFuZF9ob2xkaW5nc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFkZHJlc3NcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfYnVzc2luZXNzX2FkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ndWFyYW50b3JfYnVzc2luZXNzX2FkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkZhcm0gb3IgT3BlcmF0aW9uIEFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTMgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYnVzc2luZXNzX2FkZHJlc3MgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2J1c3NpbmVzc19hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEZvciBcIk90aGVyXCIg4oaSIE9ubHkgc2hvdyBCdXNpbmVzcyBBZGRyZXNzIGlmIFwiUnVubmluZyBhbiB1bnJlZ2lzdGVyZWQgQnVzaW5lc3NcIiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmd1YXJhbnRvcl9vY2N1cGF0aW9uID09PSBcIk90aGVyXCIgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5ndWFyYW50b3Jfb2NjdXBhdGlvbl9zdWIgPT09XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlJ1bm5pbmcgYW4gdW5yZWdpc3RlcmVkIEJ1c2luZXNzXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCIgdy1mdWxsIG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWRkcmVzc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl9idXNzaW5lc3NfYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmd1YXJhbnRvcl9idXNzaW5lc3NfYWRkcmVzc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9idXNzaW5lc3NfYWRkcmVzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYnVzc2luZXNzX2FkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogRG9jdW1lbnQgVXBsb2FkIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICBTYWxhcnkvSW5jb21lIERvY3VtZW50IFBob3RvIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl9pbmNvbWVfZG9jdW1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTMgaG92ZXI6YmctZ3JheS0xMDAgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9pbmNvbWVfZG9jdW1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2luY29tZV9kb2N1bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuZ3VhcmFudG9yX2luY29tZV9kb2N1bWVudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPXtmb3JtRGF0YS5ndWFyYW50b3JfaW5jb21lX2RvY3VtZW50fSBkb3dubG9hZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2Zvcm1EYXRhLmd1YXJhbnRvcl9pbmNvbWVfZG9jdW1lbnRfcHJldmlld31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD1cIkluY29tZSBEb2N1bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTU2IGgtNTYgb2JqZWN0LWNvdmVyIG10LTQgcm91bmRlZC1tZCBzaGFkb3ctbWQgYm9yZGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBCYW5rIERldGFpbHMgQ2FyZCAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcC02IGJnLXdoaXRlIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1jZW50ZXIgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQmFuayBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQmFuayBOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2JhbmtfbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmd1YXJhbnRvcl9iYW5rX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEJhbmsgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYmFua19uYW1lICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9iYW5rX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEJhbmsgQWNjb3VudCBOdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfYmFua19hY2NvdW50X251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmd1YXJhbnRvcl9iYW5rX2FjY291bnRfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBY2NvdW50IE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYmFua19hY2NvdW50X251bWJlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYmFua19hY2NvdW50X251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTQgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBCYW5rIEJyYW5jaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl9iYW5rX2JyYW5jaFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmd1YXJhbnRvcl9iYW5rX2JyYW5jaH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQnJhbmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9iYW5rX2JyYW5jaCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYmFua19icmFuY2h9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEJhbmsgSUZTQyBDb2RlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2JhbmtfaWZzY19jb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZ3VhcmFudG9yX2JhbmtfaWZzY19jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBJRlNDIENvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2JhbmtfaWZzY19jb2RlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9iYW5rX2lmc2NfY29kZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQmFuayBQYXNzYm9vayA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfYmFua19wYXNzYm9va19waG90b1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVGaWxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9iYW5rX3Bhc3Nib29rX3Bob3RvICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9iYW5rX3Bhc3Nib29rX3Bob3RvfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5ndWFyYW50b3JfYmFua19wYXNzYm9va19waG90byAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e2Zvcm1EYXRhLmd1YXJhbnRvcl9iYW5rX3Bhc3Nib29rX3Bob3RvfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRvd25sb2FkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2Zvcm1EYXRhLmd1YXJhbnRvcl9iYW5rX3Bhc3Nib29rX3Bob3RvX3ByZXZpZXd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9XCJQYXNzYm9va1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTU2IGgtNTYgb2JqZWN0LWNvdmVyIG10LTQgcm91bmRlZC1tZCBzaGFkb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICB7Zm9ybURhdGEuZ3VhcmFudG9yX3JlZmVycmVkX3R5cGUgPT09IFwiUHJvcGVydHlcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBQcm9wZXJ0eSBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2RvY3VtZW50X25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmd1YXJhbnRvcl9kb2N1bWVudF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBEZXNjcmlwdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgJHtmaWVsZFNpemUuaGVpZ2h0fSBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsYH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2RvY3VtZW50X25hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9kb2N1bWVudF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImd1YXJhbnRvcl9kb2N1bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUHJvcGVydHkgRG9jdW1lbnQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfZG9jdW1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gIHZhbHVlPXtmb3JtRGF0YS5ndWFyYW50b3JfZG9jdW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGlkPVwiZ3VhcmFudG9yX2RvY3VtZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJVcGxvYWQgRG9jdW1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2RvY3VtZW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfZG9jdW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5ndWFyYW50b3JfZG9jdW1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGluayB0bz17Zm9ybURhdGEuZ3VhcmFudG9yX2RvY3VtZW50fSBkb3dubG9hZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2Zvcm1EYXRhLmd1YXJhbnRvcl9kb2N1bWVudF9wcmV2aWV3fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwiUHJvcGVydHlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy01NiBoLTU2IG9iamVjdC1jb3ZlciBtdC00IHJvdW5kZWQtbWQgc2hhZG93XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRGVzY3JpcHRpb24gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfZGVzY3JpcHRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmd1YXJhbnRvcl9kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgRGVzY3JpcHRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyICR7ZmllbGRTaXplLmhlaWdodH0gYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9kZXNjcmlwdGlvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2Rlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzQgdGV4dC13aGl0ZSBiZy12aW9sZXQtNzAwIGhvdmVyOmJnLXZpb2xldC04MDAgYm9yZGVyLTIgYm9yZGVyLWJsYWNrXHJcbiAgICAgICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLXZpb2xldC0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgU2F2ZSBHdWFyYW50b3JcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxVcGRhdGV9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTaG93TW9kYWxVcGRhdGUoZmFsc2UpfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBVcGRhdGUgR3VhcmFudG9yXHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXtoYW5kbGVVcGRhdGV9IG5vVmFsaWRhdGU+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBDdXN0b21lciBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEudXNlcl9pZCB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgdXNlcl9pZDogdmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICBlbnJvbGxtZW50X2lkczogW10sIC8vIHJlc2V0IHNlbGVjdGVkIGVucm9sbG1lbnRzXHJcbiAgICAgICAgICAgICAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWx0ZXJlZCA9IGVucm9sbG1lbnRcclxuICAgICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoKGUpID0+IGUudXNlcl9pZD8uX2lkID09PSB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgIC5tYXAoKGUpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9pZDogZS5faWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwX25hbWU6IGUuZ3JvdXBfaWQ/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpY2tldDogZS50aWNrZXRzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBzZXRGaWx0ZXJlZEVucm9sbG1lbnRzKGZpbHRlcmVkKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24/LmxhYmVsPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2Vucm9sbG1lbnRcclxuICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKChlKSA9PiBlLnVzZXJfaWQgJiYgZS51c2VyX2lkLmZ1bGxfbmFtZT8udHJpbSgpKSAvLyByZW1vdmVzIGVtcHR5IG9yIGludmFsaWQgbmFtZXNcclxuICAgICAgICAgICAgICAgICAgICAubWFwKChlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2UudXNlcl9pZC5faWR9IHZhbHVlPXtlLnVzZXJfaWQuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2UudXNlcl9pZC5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMudXNlcl9pZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLnVzZXJfaWR9PC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBTZWxlY3QgRW5yb2xsbWVudCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgbW9kZT1cInRhZ3NcIlxyXG4gICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IGVucm9sbG1lbnRzXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5lbnJvbGxtZW50X2lkc31cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhzZWxlY3RlZEVucm9sbG1lbnRJZHMpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICBlbnJvbGxtZW50X2lkczogc2VsZWN0ZWRFbnJvbGxtZW50SWRzLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24/LmxhYmVsPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkRW5yb2xsbWVudHMubWFwKChlbikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHBhcnRzID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVuLmdyb3VwX25hbWUgJiYgZW4uZ3JvdXBfbmFtZSAhPT0gXCJOL0FcIilcclxuICAgICAgICAgICAgICAgICAgICAgIHBhcnRzLnB1c2goZW4uZ3JvdXBfbmFtZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVuLnRpY2tldCAmJiBlbi50aWNrZXQgIT09IFwiTi9BXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICBwYXJ0cy5wdXNoKGBUaWNrZXQ6ICR7ZW4udGlja2V0fWApO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2VuLl9pZH0gdmFsdWU9e2VuLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtwYXJ0cy5qb2luKFwiIHwgXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLmVucm9sbG1lbnRfaWRzICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZW5yb2xsbWVudF9pZHN9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwicmVmZXJyZWRfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFNlbGVjdCBSZWZlcnJlZCBUeXBlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFJlZmVycmVkIFR5cGVcIlxyXG4gICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfcmVmZXJyZWRfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/Lmd1YXJhbnRvcl9yZWZlcnJlZF90eXBlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJndWFyYW50b3JfcmVmZXJyZWRfdHlwZVwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7W1wiQ3VzdG9tZXJcIiwgXCJUaGlyZCBQYXJ0eVwiLCBcIlByb3BlcnR5XCJdLm1hcCgocmVmVHlwZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17cmVmVHlwZX0gdmFsdWU9e3JlZlR5cGV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3JlZlR5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfcmVmZXJyZWRfdHlwZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9yZWZlcnJlZF90eXBlfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX3JlZmVycmVkX3R5cGUgPT09IFwiQ3VzdG9tZXJcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBHdWFyYW50b3IgQ3VzdG9tZXJ7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBSZWZlcnJlZCBDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInVzZXJfZ3VhcmFudG9yXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8udXNlcl9ndWFyYW50b3IgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFwidXNlcl9ndWFyYW50b3JcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3VzZXJzLm1hcCgodXNlcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLmZ1bGxfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy51c2VyX2d1YXJhbnRvciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMudXNlcl9ndWFyYW50b3J9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIERlc2NyaXB0aW9uIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2Rlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3JfZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgRGVzY3JpcHRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyICR7ZmllbGRTaXplLmhlaWdodH0gYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9kZXNjcmlwdGlvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2Rlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX3JlZmVycmVkX3R5cGUgPT09IFwiVGhpcmQgUGFydHlcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNiBtdC02XCI+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiBQZXJzb25hbCBJbmZvcm1hdGlvbiBDYXJkICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBwLTYgYmctd2hpdGUgc2hhZG93LW1kXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCB0ZXh0LWNlbnRlciBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBQZXJzb25hbCBJbmZvcm1hdGlvblxyXG4gICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBHdWFyYW50b3IgTmFtZSAmIFBob25lICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgR3VhcmFudG9yIE5hbWUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEd1YXJhbnRvciBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9uYW1lICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUGhvbmUgTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX3Bob25lX251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGhvbmUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9waG9uZV9udW1iZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX3Bob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIEN1c3RvbWVyIFJlbGF0aW9uc2hpcCAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNCBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgQ3VzdG9tZXIgUmVsYXRpb25zaGlwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEN1c3RvbWVyIFJlbGF0aW9uc2hpcFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfcmVsYXRpb25zaGlwX3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9yZWxhdGlvbnNoaXBfdHlwZSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZ3VhcmFudG9yX3JlbGF0aW9uc2hpcF90eXBlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge1tcIkZhdGhlclwiLCBcIlNwb3VzZVwiLCBcIk90aGVyXCJdLm1hcCgocmVsKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3JlbH0gdmFsdWU9e3JlbH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtyZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9yZWxhdGlvbnNoaXBfdHlwZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfcmVsYXRpb25zaGlwX3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9yZWxhdGlvbnNoaXBfdHlwZSA9PT1cclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJPdGhlclwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBsZWFzZSBzcGVjaWZ5IHRoZSByZWxhdGlvbnNoaXA6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIGN1c3RvbSByZWxhdGlvbnNoaXBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1c3RvbVJlbGF0aW9uc2hpcH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q3VzdG9tUmVsYXRpb25zaGlwKGUudGFyZ2V0LnZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIEVtYWlsICYgRE9CICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRW1haWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2VtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX2VtYWlsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9lbWFpbCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIERhdGUgb2YgQmlydGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfZGF0ZW9mYmlydGhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9kYXRlb2ZiaXJ0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKHVwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9kYXRlb2ZiaXJ0aClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0lTT1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuc3BsaXQoXCJUXCIpWzBdXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIE1hcml0YWwgU3RhdHVzICYgR2VuZGVyICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTWFyaXRhbCBTdGF0dXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgTWFyaXRhbCBTdGF0dXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX21hcml0YWxfc3RhdHVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3JfbWFyaXRhbF9zdGF0dXMgfHwgdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZ3VhcmFudG9yX21hcml0YWxfc3RhdHVzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge1tcIk1hcnJpZWRcIiwgXCJVbm1hcnJpZWRcIiwgXCJXaWRvd1wiLCBcIkRpdm9yY2VkXCJdLm1hcChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChzdGF0dXMpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtzdGF0dXN9IHZhbHVlPXtzdGF0dXN9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdGF0dXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBHZW5kZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgR2VuZGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl9nZW5kZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3JfZ2VuZGVyIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFwiZ3VhcmFudG9yX2dlbmRlclwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7W1wiTWFsZVwiLCBcIkZlbWFsZVwiXS5tYXAoKGcpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z30gdmFsdWU9e2d9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIEFkZHJlc3MgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWRkcmVzcyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3JfYWRkcmVzc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBBZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9hZGRyZXNzICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2FkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBWaWxsYWdlICYgVGFsdWsgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTQgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBWaWxsYWdlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX3ZpbGxhZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3JfdmlsbGFnZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBWaWxsYWdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFRhbHVrXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX3RhbHVrXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX3RhbHVrfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFRhbHVrXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBTdGF0ZSAmIERpc3RyaWN0ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgU3RhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgU3RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX3N0YXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX3N0YXRlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFwiZ3VhcmFudG9yX3N0YXRlXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtbXCJLYXJuYXRha2FcIiwgXCJNYWhhcmFzaHRyYVwiLCBcIlRhbWlsIE5hZHVcIl0ubWFwKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKHN0YXRlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17c3RhdGV9IHZhbHVlPXtzdGF0ZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0YXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRGlzdHJpY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfZGlzdHJpY3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3JfZGlzdHJpY3R9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRGlzdHJpY3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIFBpbmNvZGUgJiBGYXRoZXIgTmFtZSAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNCBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFBpbmNvZGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfcGluY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9waW5jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfcGluY29kZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfcGluY29kZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRmF0aGVyIE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfZmF0aGVyX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3JfZmF0aGVyX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRmF0aGVyIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIE5hdGlvbmFsaXR5ICYgQWx0ZXJuYXRlIE51bWJlciAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNCBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIE5hdGlvbmFsaXR5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE5hdGlvbmFsaXR5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl9uYXRpb25hbGl0eVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX25hdGlvbmFsaXR5IHx8IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImd1YXJhbnRvcl9uYXRpb25hbGl0eVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtbXCJJbmRpYW5cIiwgXCJPdGhlclwiXS5tYXAoKG5hdGlvbikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtuYXRpb259IHZhbHVlPXtuYXRpb259PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bmF0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBBbHRlcm5hdGUgUGhvbmUgTnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2FsdGVybmF0ZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3JfYWx0ZXJuYXRlX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBbHRlcm5hdGUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIEtZQyBEb2N1bWVudHMgQ2FyZCAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcC02IGJnLXdoaXRlIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1jZW50ZXIgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgS1lDIERvY3VtZW50c1xyXG4gICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBBYWRoYWFyICYgUEFOIE51bWJlciAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBBYWRoYWFyIE51bWJlciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl9hZGhhYXJfbm9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3JfYWRoYWFyX25vfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFhZGhhYXIgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2FkaGFhcl9ubyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYWRoYWFyX25vfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBQQU4gTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX3Bhbl9ub1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9wYW5fbm99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUEFOIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9wYW5fbm8gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX3Bhbl9ub31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIFByb2ZpbGUgUGhvdG8gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUHJvZmlsZSBQaG90byA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfcGhvdG9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX3Bob3RvICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9waG90b31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX3Bob3RvICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89e3VwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9waG90b30gZG93bmxvYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXt1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3JfcGhvdG99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9XCJQcm9maWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNTYgaC01NiBvYmplY3QtY292ZXIgbXQtNCByb3VuZGVkLW1kIHNoYWRvd1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIFBBTiAmIEFhZGhhYXIgRG9jcyAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNCBtdC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFBBTiBDYXJkIFBob3RvIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX3Bhbl9kb2N1bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUZpbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9wYW5fZG9jdW1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX3Bhbl9kb2N1bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3JfcGFuX2RvY3VtZW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e3VwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9wYW5fZG9jdW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkb3dubG9hZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXt1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3JfcGFuX2RvY3VtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9XCJQQU5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTU2IGgtNTYgb2JqZWN0LWNvdmVyIG10LTQgcm91bmRlZC1tZCBzaGFkb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQWFkaGFhciBDYXJkIFBob3Rve1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2FhZGhhcl9kb2N1bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUZpbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9hYWRoYXJfZG9jdW1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2FhZGhhcl9kb2N1bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3JfYWFkaGFyX2RvY3VtZW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e3VwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9hYWRoYXJfZG9jdW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkb3dubG9hZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXt1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3JfYWFkaGFyX2RvY3VtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9XCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTU2IGgtNTYgb2JqZWN0LWNvdmVyIG10LTQgcm91bmRlZC1tZCBzaGFkb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qICBFeHRyYSBEeW5hbWljIERvY3VtZW50cyBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEFkZGl0aW9uYWwgRG9jdW1lbnRzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2V4dHJhRG9jcy5tYXAoKGRvYywgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItNiBwLTMgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIGJnLWdyYXktNTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFJvdyBmb3IgaW5wdXRzICsgcmVtb3ZlIGJ1dHRvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJEb2N1bWVudCBOYW1lIChlLmcuIFBhc3Nwb3J0LCBWb3RlciBJRClcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZG9jLmRvY3VtZW50X25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVFeHRyYURvY05hbWVDaGFuZ2UoaW5kZXgsIGUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzIgaC0xMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcC0yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2FsbF9kb2N1bWVudFwiIC8vIOKaoO+4jyBtdXN0IG1hdGNoIG11bHRlciBjb25maWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUV4dHJhRG9jRmlsZUNoYW5nZShpbmRleCwgZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzIgaC0xMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlbW92ZURvY0ZpZWxkKGluZGV4KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwIGZvbnQtYm9sZCB0ZXh0LXhsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElvTWRDbG9zZSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBQcmV2aWV3IHNob3duIGJlbG93ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtkb2MucHJldmlldyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17ZG9jLnByZXZpZXd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXtkb2MuZG9jdW1lbnRfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTU2IGgtNTYgb2JqZWN0LWNvdmVyIHJvdW5kZWQtbWQgc2hhZG93XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17YWRkTmV3RG9jRmllbGR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTIgcHgtMiBweS0xIGJnLXZpb2xldC02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdyBob3ZlcjpiZy12aW9sZXQtNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKyBBZGQgRG9jdW1lbnRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBJbmNvbWUgRGV0YWlscyBDYXJkICovfVxyXG4gICAgICAgICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcC02IGJnLXdoaXRlIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1jZW50ZXIgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgSW5jb21lIERldGFpbHNcclxuICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBHdWFyYW50b3IgT2NjdXBhdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl9vY2N1cGF0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZ3VhcmFudG9yX29jY3VwYXRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIE9jY3VwYXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTMgaG92ZXI6YmctZ3JheS0xMDAgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJndWFyYW50b3Jfb2NjdXBhdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3Jfb2NjdXBhdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmd1YXJhbnRvcl9vY2N1cGF0aW9uIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcImd1YXJhbnRvcl9vY2N1cGF0aW9uXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtbXCJTZWxmIEVtcGxveWVkXCIsXCJTYWxhcmllZFwiLFwiUHJvZmVzc2lvbmFsXCIsIFwiQWdyaSBBbGxpZWRcIiwgXCJPdGhlclwiXS5tYXAoKG5hdGlvbikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtuYXRpb259IHZhbHVlPXtuYXRpb259PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bmF0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmd1YXJhbnRvcl9vY2N1cGF0aW9uID09PSBcIk90aGVyXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUGxlYXNlIHNwZWNpZnkgT2NjdXBhdGlvbjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZ3VhcmFudG9yX29jY3VwYXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX29jY3VwYXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ndWFyYW50b3Jfb2NjdXBhdGlvbiB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudERTZWxlY3QoXCJndWFyYW50b3Jfb2NjdXBhdGlvblwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7W1wiSG91c2UgV2lmZVwiLFwiUmV0aXJlZFwiLFwiU3R1ZGVudFwiLCBcIkludmVzdG1lbnRcIiwgXCJSdW5uaW5nIGFuIHVucmVnaXN0ZXJlZCBCdXNzaW5lc3NcIl0ubWFwKChuYXRpb24pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17bmF0aW9ufSB2YWx1ZT17bmF0aW9ufT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge25hdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBHdWFyYW50b3IgU2VjdG9yXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX3NlY3Rvcl9uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZ3VhcmFudG9yX3NlY3Rvcl9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBXb3JraW5nIFNlY3RvclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyBob3ZlcjpiZy1ncmF5LTEwMCBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIERvY3VtZW50IFBob3RvIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl9pbmNvbWVfZG9jdW1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTMgaG92ZXI6YmctZ3JheS0xMDAgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuZ3VhcmFudG9yX2luY29tZV9kb2N1bWVudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPXtmb3JtRGF0YS5ndWFyYW50b3JfaW5jb21lX2RvY3VtZW50fSBkb3dubG9hZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2Zvcm1EYXRhLmd1YXJhbnRvcl9pbmNvbWVfZG9jdW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9XCJJbmNvbWUgRG9jdW1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy01NiBoLTU2IG9iamVjdC1jb3ZlciBtdC00IHJvdW5kZWQtbWQgc2hhZG93LW1kIGJvcmRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+ICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBwLTYgYmctd2hpdGUgc2hhZG93LW1kXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCB0ZXh0LWNlbnRlciBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBPY2N1cGF0aW9uIERldGFpbHNcclxuICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIExlZnQgQ29sdW1uOiBPY2N1cGF0aW9uICYgRHluYW1pYyBGaWVsZHMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBHdWFyYW50b3IgT2NjdXBhdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIE1haW4gT2NjdXBhdGlvbiBTZWxlY3QgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9jY3VwYXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3Jfb2NjdXBhdGlvbiB8fCB1bmRlZmluZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gUmVzZXQgcmVsYXRlZCBmaWVsZHMgd2hlbiBvY2N1cGF0aW9uIGNoYW5nZXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBndWFyYW50b3Jfb2NjdXBhdGlvbjogdmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGd1YXJhbnRvcl9vY2N1cGF0aW9uX3N1YjogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3VhcmFudG9yX2J1c3NpbmVzc190eXBlOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBndWFyYW50b3JfYnVzc2luZXNzX25hbWU6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGd1YXJhbnRvcl9idXNzaW5lc3NfYWRkcmVzczogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3VhcmFudG9yX3Byb2Zlc3Npb25fdHlwZTogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3VhcmFudG9yX2FncmlfcnRjX25vOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBndWFyYW50b3JfbGFuZF9ob2xkaW5nczogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiU2VsZiBFbXBsb3llZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJTYWxhcmllZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJQcm9mZXNzaW9uYWxcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiQWdyaSBBbGxpZWRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiT3RoZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBdLm1hcCgob2NjKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e29jY30gdmFsdWU9e29jY30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvY2N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9vY2N1cGF0aW9uICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9vY2N1cGF0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBTdWItb3B0aW9uIGZvciBcIk90aGVyXCIgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3Jfb2NjdXBhdGlvbiA9PT0gXCJPdGhlclwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQbGVhc2Ugc3BlY2lmeSBPY2N1cGF0aW9uOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBTdWItQ2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3Jfb2NjdXBhdGlvbl9zdWIgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGd1YXJhbnRvcl9vY2N1cGF0aW9uX3N1YjogdmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJIb3VzZSBXaWZlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlJldGlyZWRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiU3R1ZGVudFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJJbnZlc3RtZW50XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlJ1bm5pbmcgYW4gdW5yZWdpc3RlcmVkIEJ1c2luZXNzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXS5tYXAoKHN1YikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtzdWJ9IHZhbHVlPXtzdWJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3VifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3Jfb2NjdXBhdGlvbl9zdWIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX29jY3VwYXRpb25fc3VifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWRkcmVzc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl9idXNzaW5lc3NfYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX2J1c3NpbmVzc19hZGRyZXNzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTMgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYnVzc2luZXNzX2FkZHJlc3MgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2J1c3NpbmVzc19hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIFNlbGYgRW1wbG95ZWQgJiBTYWxhcmllZDogQnVzaW5lc3MgVHlwZSwgTmFtZSwgQWRkcmVzcyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAge1tcIlNlbGYgRW1wbG95ZWRcIiwgXCJTYWxhcmllZFwiXS5pbmNsdWRlcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3Jfb2NjdXBhdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICApICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCdXNpbmVzcyBUeXBlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2J1c3NpbmVzc190eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX2J1c3NpbmVzc190eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4sIFJldGFpbCwgTWFudWZhY3R1cmluZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9idXNzaW5lc3NfdHlwZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYnVzc2luZXNzX3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCdXNpbmVzcyBOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2J1c3NpbmVzc19uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX2J1c3NpbmVzc19uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEJ1c2luZXNzIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTMgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYnVzc2luZXNzX25hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2J1c3NpbmVzc19uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWRkcmVzc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl9idXNzaW5lc3NfYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX2J1c3NpbmVzc19hZGRyZXNzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTMgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYnVzc2luZXNzX2FkZHJlc3MgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2J1c3NpbmVzc19hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIFByb2Zlc3Npb25hbDogUHJvZmVzc2lvbiBUeXBlICsgQnVzaW5lc3MgQWRkcmVzcyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9vY2N1cGF0aW9uID09PVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiUHJvZmVzc2lvbmFsXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByb2Zlc3Npb24gVHlwZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl9wcm9mZXNzaW9uX3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3JfcHJvZmVzc2lvbl90eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4sIERvY3RvciwgQ0EsIEVuZ2luZWVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0zIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX3Byb2Zlc3Npb25fdHlwZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfcHJvZmVzc2lvbl90eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWRkcmVzc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl9idXNzaW5lc3NfYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX2J1c3NpbmVzc19hZGRyZXNzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNsaW5pYy9PZmZpY2UgQWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9idXNzaW5lc3NfYWRkcmVzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYnVzc2luZXNzX2FkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogQWdyaSBBbGxpZWQ6IFJUQyBObywgTGFuZCBIb2xkaW5ncywgQnVzaW5lc3MgQWRkcmVzcyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9vY2N1cGF0aW9uID09PVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiQWdyaSBBbGxpZWRcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHctZnVsbCBzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJUQyBObyAvIExhbmQgUmVjb3JkIElEXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2FncmlfcnRjX25vXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX2FncmlfcnRjX25vfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFJUQyBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTMgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2FncmlfcnRjX25vICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9hZ3JpX3J0Y19ub31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIExhbmQgSG9sZGluZ3MgKGluIGFjcmVzKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2xhbmRfaG9sZGluZ3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3JfbGFuZF9ob2xkaW5nc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuLCA1LjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTMgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfbGFuZF9ob2xkaW5ncyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfbGFuZF9ob2xkaW5nc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFkZHJlc3NcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfYnVzc2luZXNzX2FkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9idXNzaW5lc3NfYWRkcmVzc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJGYXJtIG9yIE9wZXJhdGlvbiBBZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0zIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2J1c3NpbmVzc19hZGRyZXNzICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9idXNzaW5lc3NfYWRkcmVzc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBGb3IgXCJPdGhlclwiIOKGkiBPbmx5IHNob3cgQnVzaW5lc3MgQWRkcmVzcyBpZiBcIlJ1bm5pbmcgYW4gdW5yZWdpc3RlcmVkIEJ1c2luZXNzXCIgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3Jfb2NjdXBhdGlvbiA9PT0gXCJPdGhlclwiICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX29jY3VwYXRpb25fc3ViID09PVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJSdW5uaW5nIGFuIHVucmVnaXN0ZXJlZCBCdXNpbmVzc1wiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiIHctZnVsbCBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFkZHJlc3NcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfYnVzc2luZXNzX2FkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9idXNzaW5lc3NfYWRkcmVzc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0zIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9idXNzaW5lc3NfYWRkcmVzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYnVzc2luZXNzX2FkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogRG9jdW1lbnQgVXBsb2FkIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICBTYWxhcnkvSW5jb21lIERvY3VtZW50IFBob3RvIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl9pbmNvbWVfZG9jdW1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTMgaG92ZXI6YmctZ3JheS0xMDAgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9pbmNvbWVfZG9jdW1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2luY29tZV9kb2N1bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX2luY29tZV9kb2N1bWVudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e3VwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9pbmNvbWVfZG9jdW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZG93bmxvYWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17dXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX2luY29tZV9kb2N1bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD1cIkluY29tZSBEb2N1bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTU2IGgtNTYgb2JqZWN0LWNvdmVyIG10LTQgcm91bmRlZC1tZCBzaGFkb3ctbWQgYm9yZGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBCYW5rIERldGFpbHMgQ2FyZCAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcC02IGJnLXdoaXRlIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1jZW50ZXIgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQmFuayBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQmFuayBOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2JhbmtfbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9iYW5rX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQmFuayBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9iYW5rX25hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2JhbmtfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQmFuayBBY2NvdW50IE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl9iYW5rX2FjY291bnRfbnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX2JhbmtfYWNjb3VudF9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQWNjb3VudCBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2JhbmtfYWNjb3VudF9udW1iZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2JhbmtfYWNjb3VudF9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQmFuayBCcmFuY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWFyYW50b3JfYmFua19icmFuY2hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3JfYmFua19icmFuY2h9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQnJhbmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9iYW5rX2JyYW5jaCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYmFua19icmFuY2h9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEJhbmsgSUZTQyBDb2RlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2JhbmtfaWZzY19jb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX2JhbmtfaWZzY19jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIElGU0MgQ29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfYmFua19pZnNjX2NvZGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2JhbmtfaWZzY19jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBCYW5rIFBhc3Nib29rIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl9iYW5rX3Bhc3Nib29rX3Bob3RvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUZpbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2JhbmtfcGFzc2Jvb2tfcGhvdG8gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2JhbmtfcGFzc2Jvb2tfcGhvdG99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9iYW5rX3Bhc3Nib29rX3Bob3RvICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17dXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX2JhbmtfcGFzc2Jvb2tfcGhvdG99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZG93bmxvYWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17dXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX2JhbmtfcGFzc2Jvb2tfcGhvdG99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9XCJQYXNzYm9va1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTU2IGgtNTYgb2JqZWN0LWNvdmVyIG10LTQgcm91bmRlZC1tZCBzaGFkb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX3JlZmVycmVkX3R5cGUgPT09IFwiUHJvcGVydHlcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBQcm9wZXJ0eSBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2RvY3VtZW50X25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9kb2N1bWVudF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIERlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciAke2ZpZWxkU2l6ZS5oZWlnaHR9IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfZG9jdW1lbnRfbmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2RvY3VtZW50X25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFByb3BlcnR5IERvY3VtZW50IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3VhcmFudG9yX2RvY3VtZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8vICB2YWx1ZT17Zm9ybURhdGEuZ3VhcmFudG9yX2RvY3VtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUZpbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cImd1YXJhbnRvcl9kb2N1bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVXBsb2FkIERvY3VtZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmd1YXJhbnRvcl9kb2N1bWVudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2RvY3VtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9kb2N1bWVudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e3VwZGF0ZUZvcm1EYXRhLmd1YXJhbnRvcl9kb2N1bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBkb3dubG9hZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXt1cGRhdGVGb3JtRGF0YS5ndWFyYW50b3JfZG9jdW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9XCJQcm9wZXJ0eVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTU2IGgtNTYgb2JqZWN0LWNvdmVyIG10LTQgcm91bmRlZC1tZCBzaGFkb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBEZXNjcmlwdGlvbiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImd1YXJhbnRvcl9kZXNjcmlwdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuZ3VhcmFudG9yX2Rlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJkZXNjcmlwdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBEZXNjcmlwdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgJHtmaWVsZFNpemUuaGVpZ2h0fSBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsYH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZ3VhcmFudG9yX2Rlc2NyaXB0aW9uICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ndWFyYW50b3JfZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvNCB0ZXh0LXdoaXRlIGJnLXZpb2xldC03MDAgaG92ZXI6YmctdmlvbGV0LTgwMCBib3JkZXItMiBib3JkZXItYmxhY2tcclxuICAgICAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctdmlvbGV0LTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBVcGRhdGVcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxEZWxldGV9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldEN1cnJlbnRHdWFyYW50b3IobnVsbCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBEZWxldGUgR3VhcmFudG9yXHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIHtjdXJyZW50R3VhcmFudG9yICYmIChcclxuICAgICAgICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgICAgICAgb25TdWJtaXQ9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICAgICAgaGFuZGxlRGVsZXRlR3VhcmFudG9yKCk7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3BhY2UteS02XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImdyb3VwTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBQbGVhc2UgZW50ZXJ7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5IGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRHdWFyYW50b3IuZ3VhcmFudG9yX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICB0byBjb25maXJtIGRlbGV0aW9uLntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZ3JvdXBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBHdWFyYW50b3IgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXdoaXRlIGJnLXJlZC03MDAgaG92ZXI6YmctcmVkLTgwMFxyXG4gICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLXZpb2xldC0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBHdWFyYW50b3I7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9HdWFyYW50b3IuanN4In0=