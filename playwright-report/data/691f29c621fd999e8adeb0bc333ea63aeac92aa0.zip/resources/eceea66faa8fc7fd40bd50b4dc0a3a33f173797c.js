import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PayOutMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { HiCurrencyRupee } from "/node_modules/.vite/deps/react-icons_hi2.js?v=819e0a34";
import { Banknote, Briefcase, TicketCheck, MoreHorizontal, ChevronRight, Zap, BarChart3, Eye, Lock, AlertCircle, X, CreditCard, Calendar, Clock, Users, Wallet, TrendingUp, CheckCircle, XCircle, Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import { TbCash } from "/node_modules/.vite/deps/react-icons_tb.js?v=819e0a34";
import { Link as RouterLink } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { GiTakeMyMoney } from "/node_modules/.vite/deps/react-icons_gi.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
import api from "/src/instance/TokenInstance.js";
import { FiXCircle } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { FaEye, FaEyeSlash, FaPiggyBank } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { FiChevronDown, FiChevronUp } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
const PayOutMenu = () => {
  _s();
  const [showOverviewModal, setShowOverviewModal] = useState(false);
  const [password, setPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [isAuthenticatedForOverview, setIsAuthenticatedForOverview] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState("thisMonth");
  const [customFromDate, setCustomFromDate] = useState("");
  const [customToDate, setCustomToDate] = useState("");
  const [showCustomDatePicker, setShowCustomDatePicker] = useState(false);
  const [expandedSections, setExpandedSections] = useState({
    chit: false,
    loan: false,
    cancellation: false,
    salary: false
    // new section for salary pending
  });
  const [overviewData, setOverviewData] = useState({
    totalPaymentOut: 0,
    categories: [],
    loading: true,
    error: null
  });
  const [pendingData, setPendingData] = useState({
    chitPayouts: [],
    loanPayouts: [],
    chitCancellations: [],
    salaryPending: [],
    // new array for salary pending
    additionalSalaryPending: [],
    employeeIncentivePending: [],
    loading: true,
    error: null,
    totalPending: 0
  });
  const [showPassword, setShowPassword] = useState(false);
  const formatLocalDate = (date) => {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  };
  const getDateRange = (filter) => {
    const now = /* @__PURE__ */ new Date();
    let fromDate, toDate;
    switch (filter) {
      case "today":
        fromDate = formatLocalDate(now);
        toDate = formatLocalDate(now);
        break;
      case "yesterday":
        const yesterday = new Date(now);
        yesterday.setDate(yesterday.getDate() - 1);
        fromDate = formatLocalDate(yesterday);
        toDate = formatLocalDate(yesterday);
        break;
      case "thisMonth":
        const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
        const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
        fromDate = formatLocalDate(firstDay);
        toDate = formatLocalDate(lastDay);
        break;
      case "lastMonth":
        const lastMonthFirstDay = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        const lastMonthLastDay = new Date(now.getFullYear(), now.getMonth(), 0);
        fromDate = formatLocalDate(lastMonthFirstDay);
        toDate = formatLocalDate(lastMonthLastDay);
        break;
      case "custom":
        fromDate = customFromDate || formatLocalDate(/* @__PURE__ */ new Date());
        toDate = customToDate || formatLocalDate(/* @__PURE__ */ new Date());
        break;
      default:
        fromDate = formatLocalDate(/* @__PURE__ */ new Date());
        toDate = formatLocalDate(/* @__PURE__ */ new Date());
    }
    return { fromDate, toDate };
  };
  const toggleSection = (section) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section]
    }));
  };
  const fetchPaymentOutData = async (fromDate, toDate) => {
    try {
      const response = await api.get("/v1/admin/payments-out/", {
        params: {
          from_date: fromDate,
          to_date: toDate
        }
      });
      if (!response.data.success || !response.data.data) {
        throw new Error("Invalid response from server");
      }
      return response.data.data;
    } catch (error) {
      console.error("Error fetching payment out data:", error);
      return [];
    }
  };
  const processPaymentData = (payments) => {
    const categoryMap = /* @__PURE__ */ new Map();
    payments.forEach((payment) => {
      let category = payment.category || payment.pay_for || payment.disbursement_type || "Other";
      if (category === "Pigme Payment" || category === "Pigme") {
        category = "PIGME PAYOUT";
      } else if (category === "Loan Payment" || category === "Loan") {
        category = "LOAN PAYOUT";
      } else if (category === "Auction Winning Payout") {
        category = "CHIT PAYOUT";
      } else if (category === "Chit Cancellation" || category === "Transfer") {
        category = "CHIT CANCELLATION";
      } else if (category === "salary") {
        category = "SALARY";
      } else if (category === "Chit Cancellation/Payout") {
        category = "CHIT CANCELLATION";
      }
      const amount = parseFloat(payment.amount || payment.total_amount || 0);
      if (categoryMap.has(category)) {
        categoryMap.set(category, categoryMap.get(category) + amount);
      } else {
        categoryMap.set(category, amount);
      }
    });
    const categories = Array.from(categoryMap.entries()).map(([name, amount]) => ({ name, amount })).sort((a, b) => b.amount - a.amount);
    const totalPaymentOut = categories.reduce((sum, cat) => sum + cat.amount, 0);
    return { categories, totalPaymentOut };
  };
  const fetchPendingPaymentOuts = async () => {
    setPendingData((prev) => ({ ...prev, loading: true, error: null }));
    try {
      const chitResponse = await api.get("/v1/admin/auctions/payment-outs");
      const chitPayouts = (chitResponse.data?.data || []).filter(
        (item) => item.user_id?.full_name && item.user_id?.full_name !== "N/A"
      );
      const loanResponse = await api.get("/v1/admin/loans/?approval_status=APPROVED");
      const loanPayouts = loanResponse.data.data || [];
      const cancellationResponse = await api.get("/v1/admin/user-accounts");
      const chitCancellations = cancellationResponse.data.data || [];
      const salaryResponse = await api.get("/salary-payment/status/pending");
      const salaryPending = salaryResponse.data.data || [];
      const additionalSalaryResponse = await api.get(
        "/additional-salary-payment-out?status=Pending"
      );
      const additionalSalaryPending = additionalSalaryResponse.data?.data || [];
      const [
        chitIncentiveResponse,
        loanIncentiveResponse,
        pigmyIncentiveResponse
      ] = await Promise.all(
        [
          api.get("/employee-incentive-payment-out?incentive_type=Chit&status=Pending"),
          api.get("/employee-incentive-payment-out?incentive_type=Loan&status=Pending"),
          api.get("/employee-incentive-payment-out?incentive_type=Pigmy&status=Pending")
        ]
      );
      const chitIncentivePending = chitIncentiveResponse.data?.data || [];
      const loanIncentivePending = loanIncentiveResponse.data?.data || [];
      const pigmyIncentivePending = pigmyIncentiveResponse.data?.data || [];
      const employeeIncentivePending = [
        ...chitIncentivePending,
        ...loanIncentivePending,
        ...pigmyIncentivePending
      ];
      const employeeIncentiveTotal = employeeIncentivePending.reduce(
        (sum, item) => sum + Number(item?.amount || 0),
        0
      );
      const chitTotal = chitPayouts.reduce(
        (sum, item) => sum + parseFloat(item.win_amount || 0),
        0
      );
      const loanTotal = loanPayouts.reduce(
        (sum, item) => sum + Number(item?.loan_amount || 0) - Number(item.service_charges || 0) - Number(item.document_charges || 0),
        0
      );
      const cancellationTotal = chitCancellations.reduce(
        (sum, item) => sum + parseFloat(item.balance || 0),
        0
      );
      const salaryTotal = salaryPending.reduce(
        (sum, item) => sum + parseFloat(item.net_payable || item.remaining_balance || 0),
        0
      );
      const additionalSalaryTotal = additionalSalaryPending.reduce(
        (sum, item) => sum + Number(item?.payable_amount || 0),
        0
      );
      setPendingData({
        chitPayouts,
        loanPayouts,
        chitCancellations,
        salaryPending,
        additionalSalaryPending,
        employeeIncentivePending,
        loading: false,
        error: null,
        totalPending: chitTotal + loanTotal + cancellationTotal + salaryTotal + additionalSalaryTotal + employeeIncentiveTotal
      });
    } catch (error) {
      console.error("Error fetching pending payment outs:", error);
      setPendingData((prev) => ({
        ...prev,
        loading: false,
        error: error.message || "Failed to load pending data"
      }));
    }
  };
  const loadOverviewData = async (filter = selectedFilter) => {
    const { fromDate, toDate } = getDateRange(filter);
    setOverviewData((prev) => ({ ...prev, loading: true, error: null }));
    try {
      const payments = await fetchPaymentOutData(fromDate, toDate);
      if (payments.length === 0) {
        setOverviewData({
          totalPaymentOut: 0,
          categories: [],
          loading: false,
          error: null
        });
        return;
      }
      const { categories, totalPaymentOut } = processPaymentData(payments);
      setOverviewData({
        totalPaymentOut,
        categories,
        loading: false,
        error: null
      });
    } catch (err) {
      setOverviewData((prev) => ({
        ...prev,
        loading: false,
        error: err.message || "Failed to load data"
      }));
    }
  };
  const userRole = localStorage.getItem("userRole") || "superadmin";
  const isSuperAdmin = userRole === "superadmin";
  const handleOverviewClick = () => {
    if (!isSuperAdmin) {
      setPasswordError("Access denied: Only superadmin can view overview");
      setShowOverviewModal(true);
      return;
    }
    setPassword("");
    setPasswordError("");
    setIsAuthenticatedForOverview(false);
    setShowOverviewModal(true);
    setSelectedFilter("thisMonth");
    setCustomFromDate("");
    setCustomToDate("");
    setShowCustomDatePicker(false);
    fetchPendingPaymentOuts();
  };
  const verifyPasswordAndShowData = () => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    const validPassword = userObj?.password;
    const adminAccessPermissions = userObj.admin_access_right_id?.access_permissions;
    if (password === validPassword && adminAccessPermissions?.edit_payment === "true") {
      setIsAuthenticatedForOverview(true);
      setPasswordError("");
      loadOverviewData("thisMonth");
      fetchPendingPaymentOuts();
    } else {
      setPasswordError("Invalid password or insufficient privileges");
    }
  };
  const closeModal = () => {
    setShowOverviewModal(false);
    setPassword("");
    setPasswordError("");
    setIsAuthenticatedForOverview(false);
  };
  const handleFilterChange = (filter) => {
    setSelectedFilter(filter);
    if (filter === "custom") {
      setShowCustomDatePicker(true);
    } else {
      setShowCustomDatePicker(false);
      loadOverviewData(filter);
    }
  };
  const handleCustomDateApply = () => {
    if (customFromDate && customToDate) {
      loadOverviewData("custom");
    }
  };
  const getDateRangeDisplay = () => {
    const { fromDate, toDate } = getDateRange(selectedFilter);
    if (selectedFilter === "today") return "Today";
    if (selectedFilter === "yesterday") return "Yesterday";
    if (selectedFilter === "thisMonth") return "This Month";
    if (selectedFilter === "lastMonth") return "Last Month";
    if (selectedFilter === "custom") {
      if (customFromDate && customToDate) {
        return `${formatDisplayDate(customFromDate)} - ${formatDisplayDate(customToDate)}`;
      }
      return "Custom Range";
    }
    return "";
  };
  const formatDisplayDate = (dateStr) => {
    if (!dateStr) return "";
    const parts = dateStr.split("-");
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
  };
  useEffect(() => {
    if (showOverviewModal) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [showOverviewModal]);
  const formatIndianNumber = (num) => {
    return num.toLocaleString("en-IN");
  };
  const paymentOutMenuCategories = [
    {
      id: "#1",
      title: "Chit Payout",
      description: "Manage customer chit payment out transaction information.",
      icon: TicketCheck,
      gradient: "from-violet-500 via-purple-500 to-pink-500",
      bgGradient: "from-violet-50 via-purple-50 to-pink-50",
      href: "/payment-menu/payment-in-out-menu/pay-out-menu/chit",
      stats: "Chit Payment Out Info",
      secondaryIcon: Eye,
      iconColor: "text-violet-600",
      bgColor: "bg-violet-100",
      section: "payment"
    },
    {
      id: "#3",
      title: "Employee Salary",
      description: "Manage Employee salary information.",
      icon: Briefcase,
      gradient: "from-purple-500 via-indigo-500 to-violet-500",
      bgGradient: "from-purple-50 via-indigo-50 to-violet-50",
      href: "/payment-menu/payment-in-out-menu/pay-out-menu/salary-payment",
      stats: "Employee Salary Out Info",
      secondaryIcon: Eye,
      iconColor: "text-purple-600",
      bgColor: "bg-purple-100",
      section: "employee"
    },
    {
      id: "#4",
      title: "Employee Salary Incentive",
      description: "Manage Employee Incentive payment out transaction information.",
      icon: HiCurrencyRupee,
      gradient: "from-blue-500 via-indigo-500 to-blue-700",
      bgGradient: "from-blue-50 via-indigo-50 to-blue-100",
      href: "/payment-menu/payment-in-out-menu/pay-out-menu/salary-incentive",
      stats: "Incentive Information",
      secondaryIcon: Eye,
      iconColor: "text-blue-600",
      bgColor: "bg-blue-100",
      section: "employee"
    },
    {
      id: "#5",
      title: "Employee Additional Salary",
      description: "Manage Employee Incentive payment out transaction information.",
      icon: HiCurrencyRupee,
      gradient: "from-blue-500 via-indigo-500 to-blue-700",
      bgGradient: "from-blue-50 via-indigo-50 to-blue-100",
      href: "/payment-menu/payment-in-out-menu/pay-out-menu/additional-salary",
      stats: "Incentive Information",
      secondaryIcon: Eye,
      iconColor: "text-blue-600",
      bgColor: "bg-blue-100",
      section: "employee"
    },
    {
      id: "#7",
      title: "Employee Advances",
      description: "Manage Employee advance payment information.",
      icon: TbCash,
      gradient: "from-teal-500 via-emerald-500 to-green-500",
      bgGradient: "from-teal-50 via-emerald-50 to-green-50",
      href: "/payment-menu/payment-in-out-menu/pay-out-menu/advance-payment",
      stats: "Advance Payment Info",
      secondaryIcon: Eye,
      iconColor: "text-emerald-600",
      bgColor: "bg-emerald-100",
      section: "employee"
    },
    {
      id: "#8",
      title: "Loan Payout",
      description: "Manage Loan Payment Out.",
      icon: GiTakeMyMoney,
      gradient: "from-emerald-500 via-teal-500 to-cyan-500",
      bgGradient: "from-emerald-50 via-teal-50 to-cyan-50",
      href: "/payment-menu/payment-in-out-menu/pay-out-menu/loan-payout",
      stats: "Loan Payment Out Info",
      secondaryIcon: Eye,
      iconColor: "text-teal-600",
      bgColor: "bg-teal-100",
      section: "payment"
    },
    {
      id: "#9",
      title: "Pigmy Payout",
      description: "Manage Pigmy Payment Out.",
      icon: FaPiggyBank,
      gradient: "from-blue-600 to-blue-700",
      bgGradient: "from-blue-50 via-blue-100 to-blue-200",
      href: "/payment-menu/payment-in-out-menu/pay-out-menu/pigmy-payout",
      stats: "Pigmy Payment Out",
      secondaryIcon: Eye,
      iconColor: "text-teal-600",
      bgColor: "bg-teal-100",
      section: "payment"
    },
    {
      id: "#10",
      title: "Chit Cancellation / Closure Payout",
      description: "Manage customer chit cancellation, closure payments.",
      icon: FiXCircle,
      gradient: "from-red-500 via-violet-500 to-cyan-500",
      bgGradient: "from-red-50 via-violet-50 to-cyan-50",
      href: "/payment-menu/payment-in-out-menu/pay-out-menu/chit-cancelation-pay-out",
      stats: "Chit Cancel/Close Info",
      secondaryIcon: CreditCard,
      iconColor: "text-red-600",
      bgColor: "bg-red-100",
      section: "payment"
    },
    {
      id: "#11",
      title: "Others",
      description: "Manage Others information.",
      icon: MoreHorizontal,
      gradient: "from-gray-500 via-slate-500 to-gray-500",
      bgGradient: "from-gray-50 via-slate-50 to-gray-50",
      href: "/payment-menu/payment-in-out-menu/pay-out-menu/others",
      stats: "Other Payment Out Info",
      secondaryIcon: Eye,
      iconColor: "text-gray-600",
      bgColor: "bg-gray-100",
      section: "employee"
    }
  ];
  const SmallCard = ({ category, onClick }) => {
    const Icon = category.icon;
    const SecondaryIcon = category.secondaryIcon;
    const content = /* @__PURE__ */ jsxDEV("div", { className: "relative h-full overflow-hidden rounded-2xl bg-white/90 backdrop-blur-sm border border-white/30 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 rounded-2xl bg-gradient-to-r opacity-0 group-hover:opacity-100 transition-opacity duration-500 p-[1px]", children: /* @__PURE__ */ jsxDEV("div", { className: `w-full h-full rounded-2xl bg-gradient-to-r ${category.gradient}` }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
        lineNumber: 562,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
        lineNumber: 561,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative h-full bg-white rounded-2xl p-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: `absolute top-2 right-2 w-20 h-20 rounded-full bg-gradient-to-br ${category.bgGradient} opacity-20 blur-xl` }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 565,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between mb-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: `relative w-10 h-10 rounded-xl ${category.bgColor} flex items-center justify-center shadow-md group-hover:scale-105 transition-transform duration-300`, children: /* @__PURE__ */ jsxDEV(Icon, { className: `w-5 h-5 ${category.iconColor}` }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 568,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 567,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-1.5 rounded-xl bg-slate-50 shadow-sm opacity-0 group-hover:opacity-100 transition-all duration-300", children: /* @__PURE__ */ jsxDEV(SecondaryIcon, { className: "w-3.5 h-3.5 text-slate-500" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 571,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 570,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 566,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-3", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-slate-800 mb-1 group-hover:text-purple-700 transition-colors duration-300", children: category.title }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 575,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500 leading-relaxed line-clamp-2", children: category.description }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 578,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 574,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between pt-3 border-t border-slate-100", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-medium text-slate-400 uppercase tracking-wider", children: category.stats }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 583,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1 text-purple-500 opacity-0 group-hover:opacity-100 transition-all duration-300", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold", children: "Explore" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 587,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(ChevronRight, { className: "w-3.5 h-3.5" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 588,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 586,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 582,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
        lineNumber: 564,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
      lineNumber: 560,
      columnNumber: 5
    }, this);
    if (onClick) {
      return /* @__PURE__ */ jsxDEV("div", { onClick, className: "group cursor-pointer", children: content }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
        lineNumber: 595,
        columnNumber: 14
      }, this);
    }
    return /* @__PURE__ */ jsxDEV(RouterLink, { to: category.href, className: "group block", children: content }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
      lineNumber: 597,
      columnNumber: 12
    }, this);
  };
  const overviewCard = {
    id: "overview",
    title: "Overview",
    description: "View complete payment out summary (Superadmin only)",
    icon: BarChart3,
    gradient: "from-emerald-500 via-teal-500 to-cyan-500",
    bgGradient: "from-emerald-50 via-teal-50 to-cyan-50",
    stats: "Superadmin Protected",
    secondaryIcon: Eye,
    iconColor: "text-emerald-600",
    bgColor: "bg-emerald-100"
  };
  const paymentCategories = paymentOutMenuCategories.filter(
    (item) => item.section === "payment"
  );
  const employeeCategories = paymentOutMenuCategories.filter(
    (item) => item.section === "employee"
  );
  const PendingCard = ({ title, icon: Icon, data, amountKey, bgColor, iconColor, gradient }) => {
    const total = data.reduce((sum, item) => sum + parseFloat(item[amountKey] || 0), 0);
    const count = data.length;
    return /* @__PURE__ */ jsxDEV("div", { className: `bg-gradient-to-br ${gradient} rounded-xl p-4 border border-white/20 shadow-lg hover:shadow-xl transition-all duration-300`, children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
        /* @__PURE__ */ jsxDEV("div", { className: `inline-flex p-2 rounded-lg ${bgColor} bg-opacity-20 mb-2`, children: /* @__PURE__ */ jsxDEV(Icon, { className: `w-5 h-5 ${iconColor}` }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 631,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 630,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-semibold text-white/90 mb-1", children: title }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 633,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-white", children: [
          "₹ ",
          formatIndianNumber(total)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 634,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-white/70 mt-1", children: [
          count,
          " pending ",
          count === 1 ? "item" : "items"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 635,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
        lineNumber: 629,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white/20 rounded-full px-2 py-1 text-xs font-medium text-white", children: count }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
        lineNumber: 637,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
      lineNumber: 628,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
      lineNumber: 627,
      columnNumber: 7
    }, this);
  };
  const PendingListItem = ({ item, type }) => {
    const getIcon = () => {
      switch (type) {
        case "chit":
          return /* @__PURE__ */ jsxDEV(TicketCheck, { className: "w-4 h-4 text-violet-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 650,
            columnNumber: 18
          }, this);
        case "loan":
          return /* @__PURE__ */ jsxDEV(GiTakeMyMoney, { className: "w-4 h-4 text-emerald-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 652,
            columnNumber: 18
          }, this);
        case "cancellation":
          return /* @__PURE__ */ jsxDEV(FiXCircle, { className: "w-4 h-4 text-red-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 654,
            columnNumber: 18
          }, this);
        case "salary":
          return /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-4 h-4 text-purple-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 656,
            columnNumber: 18
          }, this);
        default:
          return /* @__PURE__ */ jsxDEV(Wallet, { className: "w-4 h-4 text-gray-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 658,
            columnNumber: 18
          }, this);
      }
    };
    const getStatusBadge = (status) => {
      if (status === "Prized") {
        return /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1 text-[10px] bg-green-100 text-green-700 ", children: [
          /* @__PURE__ */ jsxDEV(CheckCircle, { className: "w-3 h-3" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 664,
            columnNumber: 99
          }, this),
          "Prized"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 664,
          columnNumber: 16
        }, this);
      } else if (status === "Un Prized") {
        return /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1 text-[10px] bg-amber-100 text-amber-700", children: [
          /* @__PURE__ */ jsxDEV(Clock, { className: "w-3 h-3" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 668,
            columnNumber: 98
          }, this),
          " Un Prized"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 668,
          columnNumber: 16
        }, this);
      }
      return null;
    };
    if (type === "salary") {
      const employee = item.employee_id || {};
      const employeeName = employee.name || "N/A";
      const employeeCode = employee.employeeCode || "N/A";
      const amount = parseFloat(item.net_payable || item.remaining_balance || 0);
      return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-3 bg-white rounded-lg border border-gray-100 hover:border-gray-200 transition-all hover:shadow-md", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 flex-1 min-w-0", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-gray-50 rounded-lg", children: getIcon() }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 682,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-800 truncate", children: [
              employeeName,
              " ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-400", children: [
                "(",
                employeeCode,
                ")"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 687,
                columnNumber: 32
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 686,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-xs text-gray-500 flex-wrap", children: [
              /* @__PURE__ */ jsxDEV("span", { children: [
                "Salary: ",
                item.salary_month,
                " ",
                item.salary_year
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 690,
                columnNumber: 17
              }, this),
              item.status && /* @__PURE__ */ jsxDEV("span", { className: "text-amber-600 text-[10px] font-medium", children: item.status }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 691,
                columnNumber: 33
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 689,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 685,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 681,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 flex-shrink-0", children: /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800 min-w-[80px] text-right", children: [
          "₹ ",
          formatIndianNumber(amount)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 696,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 695,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
        lineNumber: 680,
        columnNumber: 9
      }, this);
    }
    if (type === "chit") {
      return /* @__PURE__ */ jsxDEV("tr", { className: "border-t hover:bg-gray-50 transition-colors", children: [
        /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-gray-50 rounded-lg", children: getIcon() }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 709,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-800", children: item.group_name || item.borrower?.full_name || item.userDetails?.full_name || "N/A" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 712,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 708,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 707,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3", children: item.group_id?.group_value ? `₹${formatIndianNumber(parseFloat(item.group_id?.group_value))}` : "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 721,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3", children: item.user_id.full_name || (item.customer_id && item.customer_id !== "N/A" ? item.user_id.full_name : "-") }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 727,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3", children: item.auction_code || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 734,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3", children: item.ticket || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 736,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-1", children: [
          getStatusBadge(item.status),
          item.approval_status === "APPROVED" && /* @__PURE__ */ jsxDEV("span", { className: "text-green-600 text-xs font-medium", children: "✓ Approved" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 742,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 739,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 738,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-right font-semibold text-gray-800", children: [
          "₹",
          " ",
          formatIndianNumber(
            parseFloat(
              item.win_amount || Number(item?.loan_amount || 0) - Number(item.service_charges || 0) - Number(item.document_charges || 0) || item.balance || 0
            )
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 749,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
        lineNumber: 706,
        columnNumber: 9
      }, this);
    }
    return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-3 bg-white rounded-lg border border-gray-100 hover:border-gray-200 transition-all hover:shadow-md", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 flex-1 min-w-0", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-gray-50 rounded-lg", children: getIcon() }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 770,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-800 truncate", children: item.group_name || item.borrower?.full_name || item.userDetails?.full_name || "N/A" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 774,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-xs text-gray-500 flex-wrap", children: [
            item.group_value && /* @__PURE__ */ jsxDEV("span", { children: [
              "Group: ₹",
              formatIndianNumber(parseFloat(item.group_value))
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 778,
              columnNumber: 36
            }, this),
            item.loan_id && /* @__PURE__ */ jsxDEV("span", { children: [
              "Loan: ",
              item.loan_id
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 779,
              columnNumber: 32
            }, this),
            item.userDetails?.customer_id && /* @__PURE__ */ jsxDEV("span", { children: [
              "Customer: ",
              item.userDetails.full_name
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 780,
              columnNumber: 49
            }, this),
            item.customer_id && item.customer_id !== "N/A" && /* @__PURE__ */ jsxDEV("span", { children: [
              "Customer: ",
              item.full_name
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 781,
              columnNumber: 66
            }, this),
            item.auction_code && /* @__PURE__ */ jsxDEV("span", { children: [
              "Auction: ",
              item.auction_code
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 782,
              columnNumber: 37
            }, this),
            item.auction_code && /* @__PURE__ */ jsxDEV("span", { children: [
              "Ticket: ",
              item.ticket
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 783,
              columnNumber: 37
            }, this),
            item.approval_status === "APPROVED" && /* @__PURE__ */ jsxDEV("span", { className: "text-green-600 text-[10px] font-medium", children: "✓ Approved" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 784,
              columnNumber: 55
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 777,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 773,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
        lineNumber: 769,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 flex-shrink-0", children: [
        getStatusBadge(item.status),
        /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800 min-w-[80px] text-right", children: [
          "₹ ",
          formatIndianNumber(parseFloat(item.win_amount || Number(item?.loan_amount || 0) - Number(item.service_charges || 0) - Number(item.document_charges || 0) || item.balance || 0))
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 790,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
        lineNumber: 788,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
      lineNumber: 768,
      columnNumber: 7
    }, this);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen w-full relative overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
        lineNumber: 801,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 relative", children: [
        /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 803,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "p-6 relative", children: [
          /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 805,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "relative group", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "absolute -inset-1 bg-gradient-to-r from-violet-600 to-purple-600 rounded-xl blur-md opacity-75 group-hover:opacity-100 transition duration-500" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 809,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-lg", children: /* @__PURE__ */ jsxDEV(Banknote, { className: "w-6 h-6 text-white" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 811,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 810,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 808,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold bg-gradient-to-r from-slate-800 via-purple-800 to-slate-800 bg-clip-text text-transparent", children: "Payment-Out Management" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 815,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-slate-500 text-sm mt-0.5", children: "Manage and view payment-out information and transactions" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 818,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 814,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 807,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 806,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-12", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-bold text-gray-900 mb-6 border-b pb-3", children: "Payment Section" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 826,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 lg:grid-cols-5 gap-4", children: [
              paymentCategories.map(
                (category) => /* @__PURE__ */ jsxDEV(SmallCard, { category }, category.id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 832,
                  columnNumber: 17
                }, this)
              ),
              /* @__PURE__ */ jsxDEV(SmallCard, { category: overviewCard, onClick: handleOverviewClick }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 834,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 830,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 825,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-12", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-bold text-gray-900 mb-6 border-b pb-3", children: "Employee Section" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 839,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 lg:grid-cols-5 gap-4", children: employeeCategories.map(
              (category) => /* @__PURE__ */ jsxDEV(SmallCard, { category }, category.id, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 845,
                columnNumber: 17
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 843,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 838,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative p-5 bg-gradient-to-br from-violet-50 via-purple-50 to-pink-50 rounded-2xl border border-white/40 shadow-md overflow-hidden", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-violet-200/20 to-transparent rounded-full blur-2xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 851,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "absolute bottom-0 left-0 w-32 h-32 bg-gradient-to-tr from-purple-200/20 to-transparent rounded-full blur-2xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 852,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "relative flex items-start gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "relative group", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "absolute -inset-1 bg-gradient-to-r from-violet-400 to-purple-400 rounded-xl blur-md opacity-50" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 855,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "relative w-10 h-10 rounded-xl bg-white shadow-md flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(Zap, { className: "w-5 h-5 text-violet-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 857,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 856,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 854,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-slate-800 flex items-center gap-2 mb-1", children: "Quick Tips" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 861,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-slate-600 text-sm leading-relaxed", children: "Use Chit, Incentive, Salary, Advances, Loan, and Others directories to manage payment-out transactions." }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 864,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-slate-600 text-sm leading-relaxed mt-1", children: [
                  "📊 ",
                  /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Overview card" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 868,
                    columnNumber: 24
                  }, this),
                  " is protected — only Superadmin can view real totals (fetched from live API)."
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 867,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 860,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 853,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 850,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 804,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
        lineNumber: 802,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
      lineNumber: 800,
      columnNumber: 7
    }, this),
    showOverviewModal && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm", children: /* @__PURE__ */ jsxDEV("div", { className: "relative bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "sticky top-0 bg-white border-b border-gray-100 px-6 py-4 flex items-center justify-between z-10", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-emerald-100 rounded-xl", children: /* @__PURE__ */ jsxDEV(BarChart3, { className: "w-5 h-5 text-emerald-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 884,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 883,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-slate-800", children: "Payment Out Overview" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 886,
            columnNumber: 17
          }, this),
          isSuperAdmin && !isAuthenticatedForOverview && /* @__PURE__ */ jsxDEV("span", { className: "ml-2 text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full", children: "Superadmin required" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 888,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 882,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: closeModal, className: "p-1.5 rounded-lg hover:bg-gray-100", children: /* @__PURE__ */ jsxDEV(X, { className: "w-5 h-5 text-slate-500" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 892,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 891,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
        lineNumber: 881,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: !isAuthenticatedForOverview ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 p-4 bg-amber-50 rounded-xl border border-amber-200", children: [
          /* @__PURE__ */ jsxDEV(Lock, { className: "w-5 h-5 text-amber-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 900,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-amber-800", children: "This section contains sensitive payment statistics. Only Superadmin can access." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 901,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 899,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-slate-700 mb-2", children: "Enter Superadmin Password" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 904,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative mb-6", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: showPassword ? "text" : "password",
                value: password,
                onChange: (e) => setPassword(e.target.value),
                onKeyDown: (e) => e.key === "Enter" && verifyPasswordAndShowData(),
                className: "w-full px-4 py-2.5 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none",
                placeholder: "••••••••",
                autoFocus: true
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 906,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => setShowPassword(!showPassword),
                className: "absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-emerald-600",
                children: showPassword ? /* @__PURE__ */ jsxDEV(FaEyeSlash, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 921,
                  columnNumber: 39
                }, this) : /* @__PURE__ */ jsxDEV(FaEye, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 921,
                  columnNumber: 56
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 916,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 905,
            columnNumber: 22
          }, this),
          passwordError && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-sm text-red-600 bg-red-50 p-2 rounded-lg", children: [
            /* @__PURE__ */ jsxDEV(AlertCircle, { className: "w-4 h-4" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 926,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV("span", { children: passwordError }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 927,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 925,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: verifyPasswordAndShowData,
              className: "w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-semibold rounded-xl hover:shadow-lg transition-all",
              children: "Unlock Overview"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 930,
              columnNumber: 21
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 903,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
        lineNumber: 898,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: pendingData.error ? /* @__PURE__ */ jsxDEV("div", { className: "text-red-600 text-center py-4 bg-red-50 rounded-xl", children: [
          "Error loading pending data: ",
          pendingData.error
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 957,
          columnNumber: 17
        }, this) : pendingData.loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-10", children: /* @__PURE__ */ jsxDEV("div", { className: "animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 962,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 961,
          columnNumber: 17
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl border border-gray-100 p-4 hover:shadow-md transition", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-violet-50 rounded-lg", children: /* @__PURE__ */ jsxDEV(TicketCheck, { className: "w-5 h-5 text-violet-600" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 977,
                    columnNumber: 35
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 976,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: "Chit Payouts" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                      lineNumber: 981,
                      columnNumber: 35
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: [
                      pendingData.chitPayouts.length,
                      " pending",
                      " ",
                      pendingData.chitPayouts.length === 1 ? "item" : "items"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                      lineNumber: 985,
                      columnNumber: 35
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 980,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 974,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-bold text-gray-800", children: [
                    "₹",
                    " ",
                    formatIndianNumber(
                      pendingData.chitPayouts.reduce(
                        (sum, item) => sum + parseFloat(item.win_amount || 0),
                        0
                      )
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 993,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => toggleSection("chit"),
                      className: " px-3 py-1.5 text-xs font-semibold rounded-lg bg-violet-50 text-violet-600 hover:bg-violet-100 transition ",
                      children: expandedSections.chit ? "Hide Details" : "View Details"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                      lineNumber: 1003,
                      columnNumber: 33
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 992,
                  columnNumber: 31
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 972,
                columnNumber: 29
              }, this),
              expandedSections.chit && pendingData.chitPayouts.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-3 border-t border-gray-100 max-h-[200px] overflow-y-auto pr-2", children: /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto rounded-lg border border-gray-200 bg-white", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-sm", children: [
                /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                  /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left", children: "Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1018,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left", children: "Group Value" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1019,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left", children: "Customer" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1020,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left", children: "Auction" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1021,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left", children: "Ticket" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1022,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left", children: "Status" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1023,
                    columnNumber: 41
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-right", children: "Amount" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1024,
                    columnNumber: 41
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1017,
                  columnNumber: 39
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1016,
                  columnNumber: 37
                }, this),
                /* @__PURE__ */ jsxDEV("tbody", { children: pendingData.chitPayouts.map(
                  (item, idx) => /* @__PURE__ */ jsxDEV(PendingListItem, { item, type: "chit" }, idx, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1029,
                    columnNumber: 31
                  }, this)
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1027,
                  columnNumber: 37
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1015,
                columnNumber: 35
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1014,
                columnNumber: 33
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1013,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 970,
              columnNumber: 27
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl border border-gray-100 p-4 hover:shadow-md transition", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-emerald-50 rounded-lg", children: /* @__PURE__ */ jsxDEV(GiTakeMyMoney, { className: "w-5 h-5 text-emerald-600" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1049,
                    columnNumber: 35
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1048,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: "Loan Payouts" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                      lineNumber: 1053,
                      columnNumber: 35
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: [
                      pendingData.loanPayouts.length,
                      " pending",
                      " ",
                      pendingData.loanPayouts.length === 1 ? "item" : "items"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                      lineNumber: 1057,
                      columnNumber: 35
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1052,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1046,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-bold text-gray-800", children: [
                    "₹",
                    " ",
                    formatIndianNumber(
                      pendingData.loanPayouts.reduce(
                        (sum, item) => sum + Number(item?.loan_amount || 0) - Number(item?.service_charges || 0) - Number(item?.document_charges || 0),
                        0
                      )
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1068,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => toggleSection("loan"),
                      className: " px-3 py-1.5 text-xs  font-semibold rounded-lg  bg-emerald-50 text-emerald-600 hover:bg-emerald-100 transition  ",
                      children: expandedSections.loan ? "Hide Details" : "View Details"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                      lineNumber: 1083,
                      columnNumber: 33
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1066,
                  columnNumber: 31
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1044,
                columnNumber: 29
              }, this),
              expandedSections.loan && /* @__PURE__ */ jsxDEV("div", { className: "  mt-4  pt-3 border-t border-gray-100 space-y-2  max-h-[200px]  overflow-y-auto pr-2 ", children: pendingData.loanPayouts.map(
                (item, idx) => /* @__PURE__ */ jsxDEV(
                  PendingListItem,
                  {
                    item,
                    type: "loan"
                  },
                  idx,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1096,
                    columnNumber: 25
                  },
                  this
                )
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1094,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 1042,
              columnNumber: 27
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl border border-gray-100 p-4 hover:shadow-md transition", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-red-50 rounded-lg", children: /* @__PURE__ */ jsxDEV(FiXCircle, { className: "w-5 h-5 text-red-600" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1114,
                    columnNumber: 35
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1113,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: "Chit Cancellation" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                      lineNumber: 1118,
                      columnNumber: 35
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: [
                      pendingData.chitCancellations.length,
                      " pending",
                      " ",
                      pendingData.chitCancellations.length === 1 ? "item" : "items"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                      lineNumber: 1122,
                      columnNumber: 35
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1117,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1111,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-bold text-gray-800", children: [
                    "₹",
                    " ",
                    formatIndianNumber(
                      pendingData.chitCancellations.reduce(
                        (sum, item) => sum + parseFloat(item.balance || 0),
                        0
                      )
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1132,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => toggleSection("cancellation"),
                      className: " px-3 py-1.5 text-xs font-semibold rounded-lg bg-red-50  text-red-600 hover:bg-red-100 transition ",
                      children: expandedSections.cancellation ? "Hide Details" : "View Details"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                      lineNumber: 1141,
                      columnNumber: 33
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1131,
                  columnNumber: 31
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1109,
                columnNumber: 29
              }, this),
              expandedSections.cancellation && /* @__PURE__ */ jsxDEV("div", { className: " mt-4 pt-3 border-t border-gray-100 space-y-2 max-h-[200px] overflow-y-auto pr-2 ", children: pendingData.chitCancellations.map(
                (item, idx) => /* @__PURE__ */ jsxDEV(
                  PendingListItem,
                  {
                    item,
                    type: "cancellation"
                  },
                  idx,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1157,
                    columnNumber: 25
                  },
                  this
                )
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1155,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 1108,
              columnNumber: 27
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl border border-gray-100 p-4 hover:shadow-md transition", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-purple-50 rounded-lg", children: /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-5 h-5 text-purple-600" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1174,
                    columnNumber: 35
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1173,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: "Salary Pending" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                      lineNumber: 1178,
                      columnNumber: 35
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: [
                      pendingData.salaryPending.length,
                      " pending",
                      " ",
                      pendingData.salaryPending.length === 1 ? "item" : "items"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                      lineNumber: 1182,
                      columnNumber: 35
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1177,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1172,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-bold text-gray-800", children: [
                    "₹",
                    " ",
                    formatIndianNumber(
                      pendingData.salaryPending.reduce(
                        (sum, item) => sum + parseFloat(
                          item.net_payable || item.remaining_balance || 0
                        ),
                        0
                      )
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1193,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => toggleSection("salary"),
                      className: "px-3 py-1.5 text-xs font-semibold rounded-lg bg-purple-50 text-purple-600 hover:bg-purple-100transition",
                      children: expandedSections.salary ? "Hide Details" : "View Details"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                      lineNumber: 1210,
                      columnNumber: 33
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1191,
                  columnNumber: 31
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1171,
                columnNumber: 29
              }, this),
              expandedSections.salary && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-3 border-t border-gray-100 space-y-2 max-h-[200px] overflow-y-auto pr-2", children: pendingData.salaryPending.map(
                (item, idx) => /* @__PURE__ */ jsxDEV(
                  PendingListItem,
                  {
                    item,
                    type: "salary"
                  },
                  idx,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1225,
                    columnNumber: 25
                  },
                  this
                )
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1223,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 1169,
              columnNumber: 27
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 967,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl border border-gray-100 p-4 hover:shadow-md transition", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 min-w-0", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-orange-50 rounded-lg flex-shrink-0", children: /* @__PURE__ */ jsxDEV(Briefcase, { className: "w-5 h-5 text-orange-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1243,
                  columnNumber: 33
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1242,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: "Additional Salary" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1247,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: [
                    pendingData.additionalSalaryPending.length,
                    " pending",
                    " ",
                    pendingData.additionalSalaryPending.length === 1 ? "item" : "items"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1251,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1246,
                  columnNumber: 31
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1241,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 flex-shrink-0", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-bold text-gray-800", children: [
                  "₹",
                  " ",
                  formatIndianNumber(
                    pendingData.additionalSalaryPending.reduce(
                      (sum, item) => sum + Number(item?.payable_amount || 0),
                      0
                    )
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1261,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => toggleSection("additionalSalary"),
                    className: "px-3 py-1.5 text-xs font-semibold rounded-lg bg-orange-50 text-orange-600 hover:bg-orange-100 transition",
                    children: expandedSections.additionalSalary ? "Hide Details" : "View Details"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1271,
                    columnNumber: 31
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1260,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 1240,
              columnNumber: 27
            }, this),
            expandedSections.additionalSalary && pendingData.additionalSalaryPending.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-3 border-t border-gray-100 max-h-[200px] overflow-y-auto pr-2", children: /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto rounded-lg border border-gray-200 bg-white", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-sm", children: [
              /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left", children: "Employee" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1289,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left", children: "Employee Code" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1290,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left", children: "Month" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1291,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left", children: "Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1292,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left", children: "Status" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1293,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-right", children: "Amount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1294,
                  columnNumber: 41
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1288,
                columnNumber: 39
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1287,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("tbody", { children: pendingData.additionalSalaryPending.map(
                (item, idx) => /* @__PURE__ */ jsxDEV("tr", { className: "border-t border-gray-100", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 font-medium text-gray-800", children: item?.employee_id?.name || "-" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1301,
                    columnNumber: 43
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-gray-500", children: item?.employee_id?.employeeCode || "-" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1305,
                    columnNumber: 43
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-gray-500", children: item?.salary_month ? `${item.salary_month} ${item?.salary_year || ""}` : "-" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1309,
                    columnNumber: 43
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-gray-500", children: item?.details || "-" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1315,
                    columnNumber: 43
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3", children: /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-1 rounded-full text-[10px] font-semibold bg-amber-50 text-amber-600", children: item?.status || "Pending" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1320,
                    columnNumber: 45
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1319,
                    columnNumber: 43
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-right font-bold text-gray-800", children: [
                    "₹",
                    formatIndianNumber(item?.payable_amount || 0)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1325,
                    columnNumber: 43
                  }, this)
                ] }, item?._id || idx, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1300,
                  columnNumber: 29
                }, this)
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1298,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 1286,
              columnNumber: 35
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 1285,
              columnNumber: 33
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 1284,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 1239,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl border border-gray-100 p-4 hover:shadow-md transition", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 min-w-0", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-cyan-50 rounded-lg flex-shrink-0", children: /* @__PURE__ */ jsxDEV(TrendingUp, { className: "w-5 h-5 text-cyan-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1342,
                  columnNumber: 33
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1341,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: "Employee Incentives" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1346,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: [
                    pendingData.employeeIncentivePending?.length,
                    " pending",
                    " ",
                    pendingData.employeeIncentivePending.length === 1 ? "item" : "items"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1350,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1345,
                  columnNumber: 31
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1340,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 flex-shrink-0", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-bold text-gray-800", children: [
                  "₹",
                  " ",
                  formatIndianNumber(
                    pendingData.employeeIncentivePending.reduce(
                      (sum, item) => sum + Number(item?.amount || 0),
                      0
                    )
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1360,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => toggleSection("employeeIncentive"),
                    className: "px-3 py-1.5 text-xs font-semibold rounded-lg bg-cyan-50 text-cyan-600 hover:bg-cyan-100 transition",
                    children: expandedSections.employeeIncentive ? "Hide Details" : "View Details"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1370,
                    columnNumber: 31
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1359,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 1339,
              columnNumber: 27
            }, this),
            expandedSections.employeeIncentive && pendingData.employeeIncentivePending.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-3 border-t border-gray-100 max-h-[200px] overflow-y-auto pr-2", children: /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto rounded-lg border border-gray-200 bg-white", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-sm", children: [
              /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left", children: "Employee" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1388,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left", children: "Employee Code" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1389,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left", children: "Incentive Type" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1390,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left", children: "Month" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1391,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left", children: "Pay Type" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1392,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left", children: "Status" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1393,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-right", children: "Amount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1394,
                  columnNumber: 41
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1387,
                columnNumber: 39
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1386,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("tbody", { children: pendingData.employeeIncentivePending.map(
                (item, idx) => /* @__PURE__ */ jsxDEV("tr", { className: "border-t border-gray-100", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 font-medium text-gray-800", children: item?.employee_id?.name || "-" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1401,
                    columnNumber: 43
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-gray-500", children: item?.employee_id?.employeeCode || "-" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1405,
                    columnNumber: 43
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-gray-500", children: item?.incentive_type || "-" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1409,
                    columnNumber: 43
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-gray-500", children: item?.month ? `${item.month} ${item?.year || ""}` : "-" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1413,
                    columnNumber: 43
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-gray-500 capitalize", children: item?.pay_type || "-" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1419,
                    columnNumber: 43
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3", children: /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-1 rounded-full text-[10px] font-semibold bg-amber-50 text-amber-600", children: item?.status || "Pending" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1424,
                    columnNumber: 45
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1423,
                    columnNumber: 43
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-right font-bold text-gray-800", children: [
                    "₹",
                    formatIndianNumber(item?.amount || 0)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                    lineNumber: 1429,
                    columnNumber: 43
                  }, this)
                ] }, item?._id || idx, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1400,
                  columnNumber: 29
                }, this)
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1398,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 1385,
              columnNumber: 35
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 1384,
              columnNumber: 33
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 1383,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 1338,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between p-4 bg-white rounded-lg border border-amber-200 shadow-sm", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-amber-50 rounded-lg", children: /* @__PURE__ */ jsxDEV(TrendingUp, { className: "w-5 h-5 text-amber-600" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1445,
                columnNumber: 31
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1444,
                columnNumber: 29
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-700", children: "Total Payment Out" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1448,
                  columnNumber: 31
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Awaiting processing" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                  lineNumber: 1449,
                  columnNumber: 31
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
                lineNumber: 1447,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 1443,
              columnNumber: 27
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-gray-800", children: [
              "₹ ",
              formatIndianNumber(pendingData.totalPending)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
              lineNumber: 1452,
              columnNumber: 27
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 1442,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-4" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
            lineNumber: 1458,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 965,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 942,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-slate-400 italic border-t pt-3 mt-2", children: "* Data fetched from live API. Pending payments show amounts awaiting processing." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
          lineNumber: 1559,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
        lineNumber: 940,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
        lineNumber: 896,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
      lineNumber: 880,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
      lineNumber: 879,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("style", { jsx: true, children: `
        .line-clamp-2 {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      ` }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
      lineNumber: 1569,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx",
    lineNumber: 799,
    columnNumber: 5
  }, this);
};
_s(PayOutMenu, "/iyR8AuBVeJHc9tlcnSRD2639nw=");
_c = PayOutMenu;
export default PayOutMenu;
var _c;
$RefreshReg$(_c, "PayOutMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutMenu.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaWpCVSxTQW1aWSxVQW5aWjsyQkFqakJWO0FBQW1CQSxvQkFBaUIsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzQyxPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGFBQWE7QUFDcEIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLFVBQVVDLFdBQVdDLGFBQWFDLGdCQUFnQkMsY0FBY0MsS0FBS0MsV0FBV0MsS0FBS0MsTUFBTUMsYUFBYUMsR0FBR0MsWUFBWUMsVUFBVUMsT0FBT0MsT0FBT0MsUUFBUUMsWUFBWUMsYUFBYUMsU0FBU0MsZUFBZTtBQUNqTixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLFFBQVFDLGtCQUFrQjtBQUNuQyxTQUFTQyxxQkFBcUI7QUFDOUIsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE9BQU9DLFNBQVM7QUFDaEIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLE9BQU9DLFlBQVlDLG1CQUFtQjtBQUMvQyxTQUFTQyxlQUFlQyxtQkFBbUI7QUFFM0MsTUFBTUMsYUFBYUEsTUFBTTtBQUFBQyxLQUFBO0FBRXZCLFFBQU0sQ0FBQ0MsbUJBQW1CQyxvQkFBb0IsSUFBSUMsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJRixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDRyxlQUFlQyxnQkFBZ0IsSUFBSUosU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ0ssNEJBQTRCQyw2QkFBNkIsSUFBSU4sU0FBUyxLQUFLO0FBR2xGLFFBQU0sQ0FBQ08sZ0JBQWdCQyxpQkFBaUIsSUFBSVIsU0FBUyxXQUFXO0FBQ2hFLFFBQU0sQ0FBQ1MsZ0JBQWdCQyxpQkFBaUIsSUFBSVYsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQ1csY0FBY0MsZUFBZSxJQUFJWixTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDYSxzQkFBc0JDLHVCQUF1QixJQUFJZCxTQUFTLEtBQUs7QUFDdEUsUUFBTSxDQUFDZSxrQkFBa0JDLG1CQUFtQixJQUFJaEIsU0FBUztBQUFBLElBQ3ZEaUIsTUFBTTtBQUFBLElBQ05DLE1BQU07QUFBQSxJQUNOQyxjQUFjO0FBQUEsSUFDZEMsUUFBUTtBQUFBO0FBQUEsRUFDVixDQUFDO0FBR0QsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUl0QixTQUFTO0FBQUEsSUFDL0N1QixpQkFBaUI7QUFBQSxJQUNqQkMsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxPQUFPO0FBQUEsRUFDVCxDQUFDO0FBR0QsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUk1QixTQUFTO0FBQUEsSUFDN0M2QixhQUFhO0FBQUEsSUFDYkMsYUFBYTtBQUFBLElBQ2JDLG1CQUFtQjtBQUFBLElBQ25CQyxlQUFlO0FBQUE7QUFBQSxJQUNmQyx5QkFBeUI7QUFBQSxJQUN6QkMsMEJBQTBCO0FBQUEsSUFDMUJULFNBQVM7QUFBQSxJQUNUQyxPQUFPO0FBQUEsSUFDUFMsY0FBYztBQUFBLEVBQ2hCLENBQUM7QUFDRCxRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSXJDLFNBQVMsS0FBSztBQUd0RCxRQUFNc0Msa0JBQWtCQSxDQUFDQyxTQUFTO0FBQ2hDLFVBQU1DLElBQUlELEtBQUtFLFlBQVk7QUFDM0IsVUFBTUMsSUFBSUMsT0FBT0osS0FBS0ssU0FBUyxJQUFJLENBQUMsRUFBRUMsU0FBUyxHQUFHLEdBQUc7QUFDckQsVUFBTUMsSUFBSUgsT0FBT0osS0FBS1EsUUFBUSxDQUFDLEVBQUVGLFNBQVMsR0FBRyxHQUFHO0FBQ2hELFdBQU8sR0FBR0wsQ0FBQyxJQUFJRSxDQUFDLElBQUlJLENBQUM7QUFBQSxFQUN2QjtBQUdBLFFBQU1FLGVBQWVBLENBQUNDLFdBQVc7QUFDL0IsVUFBTUMsTUFBTSxvQkFBSUMsS0FBSztBQUNyQixRQUFJQyxVQUFVQztBQUVkLFlBQVFKLFFBQU07QUFBQSxNQUNaLEtBQUs7QUFDSEcsbUJBQVdkLGdCQUFnQlksR0FBRztBQUM5QkcsaUJBQVNmLGdCQUFnQlksR0FBRztBQUM1QjtBQUFBLE1BQ0YsS0FBSztBQUNILGNBQU1JLFlBQVksSUFBSUgsS0FBS0QsR0FBRztBQUM5Qkksa0JBQVVDLFFBQVFELFVBQVVQLFFBQVEsSUFBSSxDQUFDO0FBQ3pDSyxtQkFBV2QsZ0JBQWdCZ0IsU0FBUztBQUNwQ0QsaUJBQVNmLGdCQUFnQmdCLFNBQVM7QUFDbEM7QUFBQSxNQUNGLEtBQUs7QUFDSCxjQUFNRSxXQUFXLElBQUlMLEtBQUtELElBQUlULFlBQVksR0FBR1MsSUFBSU4sU0FBUyxHQUFHLENBQUM7QUFDOUQsY0FBTWEsVUFBVSxJQUFJTixLQUFLRCxJQUFJVCxZQUFZLEdBQUdTLElBQUlOLFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDakVRLG1CQUFXZCxnQkFBZ0JrQixRQUFRO0FBQ25DSCxpQkFBU2YsZ0JBQWdCbUIsT0FBTztBQUNoQztBQUFBLE1BQ0YsS0FBSztBQUNILGNBQU1DLG9CQUFvQixJQUFJUCxLQUFLRCxJQUFJVCxZQUFZLEdBQUdTLElBQUlOLFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDM0UsY0FBTWUsbUJBQW1CLElBQUlSLEtBQUtELElBQUlULFlBQVksR0FBR1MsSUFBSU4sU0FBUyxHQUFHLENBQUM7QUFDdEVRLG1CQUFXZCxnQkFBZ0JvQixpQkFBaUI7QUFDNUNMLGlCQUFTZixnQkFBZ0JxQixnQkFBZ0I7QUFDekM7QUFBQSxNQUNGLEtBQUs7QUFDSFAsbUJBQVczQyxrQkFBa0I2QixnQkFBZ0Isb0JBQUlhLEtBQUssQ0FBQztBQUN2REUsaUJBQVMxQyxnQkFBZ0IyQixnQkFBZ0Isb0JBQUlhLEtBQUssQ0FBQztBQUNuRDtBQUFBLE1BQ0Y7QUFDRUMsbUJBQVdkLGdCQUFnQixvQkFBSWEsS0FBSyxDQUFDO0FBQ3JDRSxpQkFBU2YsZ0JBQWdCLG9CQUFJYSxLQUFLLENBQUM7QUFBQSxJQUN2QztBQUVBLFdBQU8sRUFBRUMsVUFBVUMsT0FBTztBQUFBLEVBQzVCO0FBRUEsUUFBTU8sZ0JBQWdCQSxDQUFDQyxZQUFZO0FBQ2pDN0Msd0JBQW9CLENBQUM4QyxVQUFVO0FBQUEsTUFDN0IsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRCxPQUFPLEdBQUcsQ0FBQ0MsS0FBS0QsT0FBTztBQUFBLElBQzFCLEVBQUU7QUFBQSxFQUNKO0FBR0EsUUFBTUUsc0JBQXNCLE9BQU9YLFVBQVVDLFdBQVc7QUFDdEQsUUFBSTtBQUNGLFlBQU1XLFdBQVcsTUFBTTNFLElBQUk0RSxJQUFJLDJCQUEyQjtBQUFBLFFBQ3hEQyxRQUFRO0FBQUEsVUFDTkMsV0FBV2Y7QUFBQUEsVUFDWGdCLFNBQVNmO0FBQUFBLFFBQ1g7QUFBQSxNQUNGLENBQUM7QUFFRCxVQUFJLENBQUNXLFNBQVNLLEtBQUtDLFdBQVcsQ0FBQ04sU0FBU0ssS0FBS0EsTUFBTTtBQUNqRCxjQUFNLElBQUlFLE1BQU0sOEJBQThCO0FBQUEsTUFDaEQ7QUFFQSxhQUFPUCxTQUFTSyxLQUFLQTtBQUFBQSxJQUN2QixTQUFTM0MsT0FBTztBQUNkOEMsY0FBUTlDLE1BQU0sb0NBQW9DQSxLQUFLO0FBQ3ZELGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUdBLFFBQU0rQyxxQkFBcUJBLENBQUNDLGFBQWE7QUFDdkMsVUFBTUMsY0FBYyxvQkFBSUMsSUFBSTtBQUU1QkYsYUFBU0csUUFBUSxDQUFBQyxZQUFXO0FBQzFCLFVBQUlDLFdBQVdELFFBQVFDLFlBQVlELFFBQVFFLFdBQVdGLFFBQVFHLHFCQUFxQjtBQUVuRixVQUFJRixhQUFhLG1CQUFtQkEsYUFBYSxTQUFTO0FBQ3hEQSxtQkFBVztBQUFBLE1BQ2IsV0FBV0EsYUFBYSxrQkFBa0JBLGFBQWEsUUFBUTtBQUM3REEsbUJBQVc7QUFBQSxNQUNiLFdBQVdBLGFBQWEsMEJBQTBCO0FBQ2hEQSxtQkFBVztBQUFBLE1BQ2IsV0FBV0EsYUFBYSx1QkFBdUJBLGFBQWEsWUFBWTtBQUN0RUEsbUJBQVc7QUFBQSxNQUNiLFdBQVdBLGFBQWEsVUFBVTtBQUNoQ0EsbUJBQVc7QUFBQSxNQUNiLFdBQVdBLGFBQWEsNEJBQTRCO0FBQ2xEQSxtQkFBVztBQUFBLE1BQ2I7QUFFQSxZQUFNRyxTQUFTQyxXQUFXTCxRQUFRSSxVQUFVSixRQUFRTSxnQkFBZ0IsQ0FBQztBQUVyRSxVQUFJVCxZQUFZVSxJQUFJTixRQUFRLEdBQUc7QUFDN0JKLG9CQUFZVyxJQUFJUCxVQUFVSixZQUFZVixJQUFJYyxRQUFRLElBQUlHLE1BQU07QUFBQSxNQUM5RCxPQUFPO0FBQ0xQLG9CQUFZVyxJQUFJUCxVQUFVRyxNQUFNO0FBQUEsTUFDbEM7QUFBQSxJQUNGLENBQUM7QUFFRCxVQUFNMUQsYUFBYStELE1BQU1DLEtBQUtiLFlBQVljLFFBQVEsQ0FBQyxFQUNoREMsSUFBSSxDQUFDLENBQUNDLE1BQU1ULE1BQU0sT0FBTyxFQUFFUyxNQUFNVCxPQUFPLEVBQUUsRUFDMUNVLEtBQUssQ0FBQ0MsR0FBR0MsTUFBTUEsRUFBRVosU0FBU1csRUFBRVgsTUFBTTtBQUVyQyxVQUFNM0Qsa0JBQWtCQyxXQUFXdUUsT0FBTyxDQUFDQyxLQUFLQyxRQUFRRCxNQUFNQyxJQUFJZixRQUFRLENBQUM7QUFFM0UsV0FBTyxFQUFFMUQsWUFBWUQsZ0JBQWdCO0FBQUEsRUFDdkM7QUFHQSxRQUFNMkUsMEJBQTBCLFlBQVk7QUFDMUN0RSxtQkFBZSxDQUFBa0MsVUFBUyxFQUFFLEdBQUdBLE1BQU1yQyxTQUFTLE1BQU1DLE9BQU8sS0FBSyxFQUFFO0FBRWhFLFFBQUk7QUFFRixZQUFNeUUsZUFBZSxNQUFNOUcsSUFBSTRFLElBQUksaUNBQWlDO0FBQ3BFLFlBQU1wQyxlQUFlc0UsYUFBYTlCLE1BQU1BLFFBQVEsSUFBSXBCO0FBQUFBLFFBQ2xELENBQUNtRCxTQUNDQSxLQUFLQyxTQUFTQyxhQUNkRixLQUFLQyxTQUFTQyxjQUFjO0FBQUEsTUFDaEM7QUFHQSxZQUFNQyxlQUFlLE1BQU1sSCxJQUFJNEUsSUFBSSwyQ0FBMkM7QUFDOUUsWUFBTW5DLGNBQWN5RSxhQUFhbEMsS0FBS0EsUUFBUTtBQUc5QyxZQUFNbUMsdUJBQXVCLE1BQU1uSCxJQUFJNEUsSUFBSSx5QkFBeUI7QUFDcEUsWUFBTWxDLG9CQUFvQnlFLHFCQUFxQm5DLEtBQUtBLFFBQVE7QUFHNUQsWUFBTW9DLGlCQUFpQixNQUFNcEgsSUFBSTRFLElBQUksZ0NBQWdDO0FBQ3JFLFlBQU1qQyxnQkFBZ0J5RSxlQUFlcEMsS0FBS0EsUUFBUTtBQUdsRCxZQUFNcUMsMkJBQTJCLE1BQU1ySCxJQUFJNEU7QUFBQUEsUUFDekM7QUFBQSxNQUNGO0FBQ0EsWUFBTWhDLDBCQUEwQnlFLHlCQUF5QnJDLE1BQU1BLFFBQVE7QUFHdkUsWUFBTTtBQUFBLFFBQ0pzQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxNQUFzQixJQUNwQixNQUFNQyxRQUFRQztBQUFBQSxRQUFJO0FBQUEsVUFDcEIxSCxJQUFJNEUsSUFBSSxvRUFBb0U7QUFBQSxVQUM1RTVFLElBQUk0RSxJQUFJLG9FQUFvRTtBQUFBLFVBQzVFNUUsSUFBSTRFLElBQUkscUVBQXFFO0FBQUEsUUFBQztBQUFBLE1BQy9FO0FBQ0QsWUFBTStDLHVCQUF1Qkwsc0JBQXNCdEMsTUFBTUEsUUFBUTtBQUNqRSxZQUFNNEMsdUJBQXVCTCxzQkFBc0J2QyxNQUFNQSxRQUFRO0FBQ2pFLFlBQU02Qyx3QkFBd0JMLHVCQUF1QnhDLE1BQU1BLFFBQVE7QUFFbkUsWUFBTW5DLDJCQUEyQjtBQUFBLFFBQy9CLEdBQUc4RTtBQUFBQSxRQUNILEdBQUdDO0FBQUFBLFFBQ0gsR0FBR0M7QUFBQUEsTUFBcUI7QUFHMUIsWUFBTUMseUJBQXlCakYseUJBQXlCNkQ7QUFBQUEsUUFDdEQsQ0FBQ0MsS0FBS0ksU0FBU0osTUFBTW9CLE9BQU9oQixNQUFNbEIsVUFBVSxDQUFDO0FBQUEsUUFDN0M7QUFBQSxNQUNGO0FBR0EsWUFBTW1DLFlBQVl4RixZQUFZa0U7QUFBQUEsUUFDNUIsQ0FBQ0MsS0FBS0ksU0FBU0osTUFBTWIsV0FBV2lCLEtBQUtrQixjQUFjLENBQUM7QUFBQSxRQUNwRDtBQUFBLE1BQ0Y7QUFFQSxZQUFNQyxZQUFZekYsWUFBWWlFO0FBQUFBLFFBQzVCLENBQUNDLEtBQUtJLFNBQ0pKLE1BQ0FvQixPQUFPaEIsTUFBTW9CLGVBQWUsQ0FBQyxJQUM3QkosT0FBT2hCLEtBQUtxQixtQkFBbUIsQ0FBQyxJQUNoQ0wsT0FBT2hCLEtBQUtzQixvQkFBb0IsQ0FBQztBQUFBLFFBQ25DO0FBQUEsTUFDRjtBQUVBLFlBQU1DLG9CQUFvQjVGLGtCQUFrQmdFO0FBQUFBLFFBQzFDLENBQUNDLEtBQUtJLFNBQVNKLE1BQU1iLFdBQVdpQixLQUFLd0IsV0FBVyxDQUFDO0FBQUEsUUFDakQ7QUFBQSxNQUNGO0FBRUEsWUFBTUMsY0FBYzdGLGNBQWMrRDtBQUFBQSxRQUNoQyxDQUFDQyxLQUFLSSxTQUNKSixNQUFNYixXQUFXaUIsS0FBSzBCLGVBQWUxQixLQUFLMkIscUJBQXFCLENBQUM7QUFBQSxRQUNsRTtBQUFBLE1BQ0Y7QUFHQSxZQUFNQyx3QkFBd0IvRix3QkFBd0I4RDtBQUFBQSxRQUNwRCxDQUFDQyxLQUFLSSxTQUFTSixNQUFNb0IsT0FBT2hCLE1BQU02QixrQkFBa0IsQ0FBQztBQUFBLFFBQ3JEO0FBQUEsTUFDRjtBQUlBckcscUJBQWU7QUFBQSxRQUNiQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBVCxTQUFTO0FBQUEsUUFDVEMsT0FBTztBQUFBLFFBQ1BTLGNBQ0VrRixZQUNBRSxZQUNBSSxvQkFDQUUsY0FDQUcsd0JBQ0FiO0FBQUFBLE1BQ0osQ0FBQztBQUFBLElBQ0gsU0FBU3pGLE9BQU87QUFDZDhDLGNBQVE5QyxNQUFNLHdDQUF3Q0EsS0FBSztBQUMzREUscUJBQWUsQ0FBQWtDLFVBQVM7QUFBQSxRQUN0QixHQUFHQTtBQUFBQSxRQUNIckMsU0FBUztBQUFBLFFBQ1RDLE9BQU9BLE1BQU13RyxXQUFXO0FBQUEsTUFDMUIsRUFBRTtBQUFBLElBQ0o7QUFBQSxFQUNGO0FBR0EsUUFBTUMsbUJBQW1CLE9BQU9sRixTQUFTMUMsbUJBQW1CO0FBQzFELFVBQU0sRUFBRTZDLFVBQVVDLE9BQU8sSUFBSUwsYUFBYUMsTUFBTTtBQUVoRDNCLG9CQUFnQixDQUFBd0MsVUFBUyxFQUFFLEdBQUdBLE1BQU1yQyxTQUFTLE1BQU1DLE9BQU8sS0FBSyxFQUFFO0FBQ2pFLFFBQUk7QUFDRixZQUFNZ0QsV0FBVyxNQUFNWCxvQkFBb0JYLFVBQVVDLE1BQU07QUFFM0QsVUFBSXFCLFNBQVMwRCxXQUFXLEdBQUc7QUFDekI5Ryx3QkFBZ0I7QUFBQSxVQUNkQyxpQkFBaUI7QUFBQSxVQUNqQkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxPQUFPO0FBQUEsUUFDVCxDQUFDO0FBQ0Q7QUFBQSxNQUNGO0FBRUEsWUFBTSxFQUFFRixZQUFZRCxnQkFBZ0IsSUFBSWtELG1CQUFtQkMsUUFBUTtBQUVuRXBELHNCQUFnQjtBQUFBLFFBQ2RDO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FDLFNBQVM7QUFBQSxRQUNUQyxPQUFPO0FBQUEsTUFDVCxDQUFDO0FBQUEsSUFDSCxTQUFTMkcsS0FBSztBQUNaL0csc0JBQWdCLENBQUF3QyxVQUFTO0FBQUEsUUFDdkIsR0FBR0E7QUFBQUEsUUFDSHJDLFNBQVM7QUFBQSxRQUNUQyxPQUFPMkcsSUFBSUgsV0FBVztBQUFBLE1BQ3hCLEVBQUU7QUFBQSxJQUNKO0FBQUEsRUFDRjtBQUdBLFFBQU1JLFdBQVdDLGFBQWFDLFFBQVEsVUFBVSxLQUFLO0FBQ3JELFFBQU1DLGVBQWVILGFBQWE7QUFFbEMsUUFBTUksc0JBQXNCQSxNQUFNO0FBQ2hDLFFBQUksQ0FBQ0QsY0FBYztBQUNqQnJJLHVCQUFpQixrREFBa0Q7QUFDbkVMLDJCQUFxQixJQUFJO0FBQ3pCO0FBQUEsSUFDRjtBQUNBRyxnQkFBWSxFQUFFO0FBQ2RFLHFCQUFpQixFQUFFO0FBQ25CRSxrQ0FBOEIsS0FBSztBQUNuQ1AseUJBQXFCLElBQUk7QUFDekJTLHNCQUFrQixXQUFXO0FBQzdCRSxzQkFBa0IsRUFBRTtBQUNwQkUsb0JBQWdCLEVBQUU7QUFDbEJFLDRCQUF3QixLQUFLO0FBRzdCb0YsNEJBQXdCO0FBQUEsRUFDMUI7QUFFQSxRQUFNeUMsNEJBQTRCQSxNQUFNO0FBQ3RDLFVBQU1DLE9BQU9MLGFBQWFDLFFBQVEsTUFBTTtBQUN4QyxVQUFNSyxVQUFVQyxLQUFLQyxNQUFNSCxJQUFJO0FBQy9CLFVBQU1JLGdCQUFnQkgsU0FBUzVJO0FBQy9CLFVBQU1nSix5QkFDSkosUUFBUUssdUJBQXVCQztBQUVqQyxRQUFJbEosYUFBYStJLGlCQUFpQkMsd0JBQXdCRyxpQkFBaUIsUUFBUTtBQUNqRjlJLG9DQUE4QixJQUFJO0FBQ2xDRix1QkFBaUIsRUFBRTtBQUNuQitILHVCQUFpQixXQUFXO0FBQzVCakMsOEJBQXdCO0FBQUEsSUFDMUIsT0FBTztBQUNMOUYsdUJBQWlCLDZDQUE2QztBQUFBLElBQ2hFO0FBQUEsRUFDRjtBQUVBLFFBQU1pSixhQUFhQSxNQUFNO0FBQ3ZCdEoseUJBQXFCLEtBQUs7QUFDMUJHLGdCQUFZLEVBQUU7QUFDZEUscUJBQWlCLEVBQUU7QUFDbkJFLGtDQUE4QixLQUFLO0FBQUEsRUFDckM7QUFHQSxRQUFNZ0oscUJBQXFCQSxDQUFDckcsV0FBVztBQUNyQ3pDLHNCQUFrQnlDLE1BQU07QUFDeEIsUUFBSUEsV0FBVyxVQUFVO0FBQ3ZCbkMsOEJBQXdCLElBQUk7QUFBQSxJQUM5QixPQUFPO0FBQ0xBLDhCQUF3QixLQUFLO0FBQzdCcUgsdUJBQWlCbEYsTUFBTTtBQUFBLElBQ3pCO0FBQUEsRUFDRjtBQUdBLFFBQU1zRyx3QkFBd0JBLE1BQU07QUFDbEMsUUFBSTlJLGtCQUFrQkUsY0FBYztBQUNsQ3dILHVCQUFpQixRQUFRO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBR0EsUUFBTXFCLHNCQUFzQkEsTUFBTTtBQUNoQyxVQUFNLEVBQUVwRyxVQUFVQyxPQUFPLElBQUlMLGFBQWF6QyxjQUFjO0FBQ3hELFFBQUlBLG1CQUFtQixRQUFTLFFBQU87QUFDdkMsUUFBSUEsbUJBQW1CLFlBQWEsUUFBTztBQUMzQyxRQUFJQSxtQkFBbUIsWUFBYSxRQUFPO0FBQzNDLFFBQUlBLG1CQUFtQixZQUFhLFFBQU87QUFDM0MsUUFBSUEsbUJBQW1CLFVBQVU7QUFDL0IsVUFBSUUsa0JBQWtCRSxjQUFjO0FBQ2xDLGVBQU8sR0FBRzhJLGtCQUFrQmhKLGNBQWMsQ0FBQyxNQUFNZ0osa0JBQWtCOUksWUFBWSxDQUFDO0FBQUEsTUFDbEY7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUNBLFdBQU87QUFBQSxFQUNUO0FBRUEsUUFBTThJLG9CQUFvQkEsQ0FBQ0MsWUFBWTtBQUNyQyxRQUFJLENBQUNBLFFBQVMsUUFBTztBQUNyQixVQUFNQyxRQUFRRCxRQUFRRSxNQUFNLEdBQUc7QUFDL0IsV0FBTyxHQUFHRCxNQUFNLENBQUMsQ0FBQyxJQUFJQSxNQUFNLENBQUMsQ0FBQyxJQUFJQSxNQUFNLENBQUMsQ0FBQztBQUFBLEVBQzVDO0FBR0FuTSxZQUFVLE1BQU07QUFDZCxRQUFJc0MsbUJBQW1CO0FBQ3JCK0osZUFBU0MsS0FBS0MsTUFBTUMsV0FBVztBQUFBLElBQ2pDLE9BQU87QUFDTEgsZUFBU0MsS0FBS0MsTUFBTUMsV0FBVztBQUFBLElBQ2pDO0FBQ0EsV0FBTyxNQUFNO0FBQ1hILGVBQVNDLEtBQUtDLE1BQU1DLFdBQVc7QUFBQSxJQUNqQztBQUFBLEVBQ0YsR0FBRyxDQUFDbEssaUJBQWlCLENBQUM7QUFFdEIsUUFBTW1LLHFCQUFxQkEsQ0FBQ0MsUUFBUTtBQUNsQyxXQUFPQSxJQUFJQyxlQUFlLE9BQU87QUFBQSxFQUNuQztBQUdBLFFBQU1DLDJCQUEyQjtBQUFBLElBQy9CO0FBQUEsTUFDRUMsSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTTFNO0FBQUFBLE1BQ04yTSxVQUFVO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsZUFBZTFNO0FBQUFBLE1BQ2YyTSxXQUFXO0FBQUEsTUFDWEMsU0FBUztBQUFBLE1BQ1RsSCxTQUFTO0FBQUEsSUFDWDtBQUFBLElBQ0E7QUFBQSxNQUNFd0csSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTTNNO0FBQUFBLE1BQ040TSxVQUFVO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsZUFBZTFNO0FBQUFBLE1BQ2YyTSxXQUFXO0FBQUEsTUFDWEMsU0FBUztBQUFBLE1BQ1RsSCxTQUFTO0FBQUEsSUFDWDtBQUFBLElBQ0E7QUFBQSxNQUNFd0csSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTTdNO0FBQUFBLE1BQ044TSxVQUFVO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsZUFBZTFNO0FBQUFBLE1BQ2YyTSxXQUFXO0FBQUEsTUFDWEMsU0FBUztBQUFBLE1BQ1RsSCxTQUFTO0FBQUEsSUFDWDtBQUFBLElBQ0E7QUFBQSxNQUNFd0csSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTTdNO0FBQUFBLE1BQ044TSxVQUFVO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsZUFBZTFNO0FBQUFBLE1BQ2YyTSxXQUFXO0FBQUEsTUFDWEMsU0FBUztBQUFBLE1BQ1RsSCxTQUFTO0FBQUEsSUFDWDtBQUFBLElBQ0E7QUFBQSxNQUNFd0csSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTXhMO0FBQUFBLE1BQ055TCxVQUFVO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsZUFBZTFNO0FBQUFBLE1BQ2YyTSxXQUFXO0FBQUEsTUFDWEMsU0FBUztBQUFBLE1BQ1RsSCxTQUFTO0FBQUEsSUFDWDtBQUFBLElBQ0E7QUFBQSxNQUNFd0csSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTXJMO0FBQUFBLE1BQ05zTCxVQUFVO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsZUFBZTFNO0FBQUFBLE1BQ2YyTSxXQUFXO0FBQUEsTUFDWEMsU0FBUztBQUFBLE1BQ1RsSCxTQUFTO0FBQUEsSUFDWDtBQUFBLElBQ0E7QUFBQSxNQUNFd0csSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTS9LO0FBQUFBLE1BQ05nTCxVQUFVO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsZUFBZTFNO0FBQUFBLE1BQ2YyTSxXQUFXO0FBQUEsTUFDWEMsU0FBUztBQUFBLE1BQ1RsSCxTQUFTO0FBQUEsSUFDWDtBQUFBLElBQ0E7QUFBQSxNQUNFd0csSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTWxMO0FBQUFBLE1BQ05tTCxVQUFVO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsZUFBZXRNO0FBQUFBLE1BQ2Z1TSxXQUFXO0FBQUEsTUFDWEMsU0FBUztBQUFBLE1BQ1RsSCxTQUFTO0FBQUEsSUFDWDtBQUFBLElBQ0E7QUFBQSxNQUNFd0csSUFBSTtBQUFBLE1BQ0pDLE9BQU87QUFBQSxNQUNQQyxhQUFhO0FBQUEsTUFDYkMsTUFBTXpNO0FBQUFBLE1BQ04wTSxVQUFVO0FBQUEsTUFDVkMsWUFBWTtBQUFBLE1BQ1pDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsZUFBZTFNO0FBQUFBLE1BQ2YyTSxXQUFXO0FBQUEsTUFDWEMsU0FBUztBQUFBLE1BQ1RsSCxTQUFTO0FBQUEsSUFDWDtBQUFBLEVBQUM7QUFHSCxRQUFNbUgsWUFBWUEsQ0FBQyxFQUFFakcsVUFBVWtHLFFBQVEsTUFBTTtBQUMzQyxVQUFNQyxPQUFPbkcsU0FBU3lGO0FBQ3RCLFVBQU1XLGdCQUFnQnBHLFNBQVM4RjtBQUMvQixVQUFNTyxVQUNKLHVCQUFDLFNBQUksV0FBVSx3TEFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSwySEFDYixpQ0FBQyxTQUFJLFdBQVcsOENBQThDckcsU0FBUzBGLFFBQVEsTUFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRixLQURyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVyxtRUFBbUUxRixTQUFTMkYsVUFBVSx5QkFBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2SDtBQUFBLFFBQzdILHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVyxpQ0FBaUMzRixTQUFTZ0csT0FBTyx1R0FDL0QsaUNBQUMsUUFBSyxXQUFXLFdBQVdoRyxTQUFTK0YsU0FBUyxNQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRCxLQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsd0dBQ2IsaUNBQUMsaUJBQWMsV0FBVSxnQ0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUQsS0FEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSxzR0FDWC9GLG1CQUFTdUYsU0FEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsdURBQ1Z2RixtQkFBU3dGLGVBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsb0VBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsbUVBQ2J4RixtQkFBUzZGLFNBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHlHQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHlCQUF3Qix1QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0M7QUFBQSxZQUMvQyx1QkFBQyxnQkFBYSxXQUFVLGlCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxQztBQUFBLGVBRnZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFdBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQkE7QUFBQSxTQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0NBO0FBRUYsUUFBSUssU0FBUztBQUNYLGFBQU8sdUJBQUMsU0FBSSxTQUFrQixXQUFVLHdCQUF3QkcscUJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUU7QUFBQSxJQUMxRTtBQUNBLFdBQU8sdUJBQUMsY0FBVyxJQUFJckcsU0FBUzRGLE1BQU0sV0FBVSxlQUFlUyxxQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRTtBQUFBLEVBQ3pFO0FBRUEsUUFBTUMsZUFBZTtBQUFBLElBQ25CaEIsSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxhQUFhO0FBQUEsSUFDYkMsTUFBTXRNO0FBQUFBLElBQ051TSxVQUFVO0FBQUEsSUFDVkMsWUFBWTtBQUFBLElBQ1pFLE9BQU87QUFBQSxJQUNQQyxlQUFlMU07QUFBQUEsSUFDZjJNLFdBQVc7QUFBQSxJQUNYQyxTQUFTO0FBQUEsRUFDWDtBQUVBLFFBQU1PLG9CQUFvQmxCLHlCQUF5Qm5IO0FBQUFBLElBQ2pELENBQUNtRCxTQUFTQSxLQUFLdkMsWUFBWTtBQUFBLEVBQzdCO0FBRUEsUUFBTTBILHFCQUFxQm5CLHlCQUF5Qm5IO0FBQUFBLElBQ2xELENBQUNtRCxTQUFTQSxLQUFLdkMsWUFBWTtBQUFBLEVBQzdCO0FBR0EsUUFBTTJILGNBQWNBLENBQUMsRUFBRWxCLE9BQU9FLE1BQU1VLE1BQU03RyxNQUFNb0gsV0FBV1YsU0FBU0QsV0FBV0wsU0FBUyxNQUFNO0FBQzVGLFVBQU1pQixRQUFRckgsS0FBSzBCLE9BQU8sQ0FBQ0MsS0FBS0ksU0FBU0osTUFBTWIsV0FBV2lCLEtBQUtxRixTQUFTLEtBQUssQ0FBQyxHQUFHLENBQUM7QUFDbEYsVUFBTUUsUUFBUXRILEtBQUsrRDtBQUVuQixXQUNFLHVCQUFDLFNBQUksV0FBVyxxQkFBcUJxQyxRQUFRLGdHQUMzQyxpQ0FBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVyw4QkFBOEJNLE9BQU8sdUJBQ25ELGlDQUFDLFFBQUssV0FBVyxXQUFXRCxTQUFTLE1BQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0MsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxRQUFHLFdBQVUsNENBQTRDUixtQkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRTtBQUFBLFFBQ2hFLHVCQUFDLE9BQUUsV0FBVSxpQ0FBZ0M7QUFBQTtBQUFBLFVBQUdMLG1CQUFtQnlCLEtBQUs7QUFBQSxhQUF4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBFO0FBQUEsUUFDMUUsdUJBQUMsT0FBRSxXQUFVLDhCQUE4QkM7QUFBQUE7QUFBQUEsVUFBTTtBQUFBLFVBQVVBLFVBQVUsSUFBSSxTQUFTO0FBQUEsYUFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwRjtBQUFBLFdBTjVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHFFQUNaQSxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQTtBQUFBLEVBRUo7QUFHQSxRQUFNQyxrQkFBa0JBLENBQUMsRUFBRXhGLE1BQU15RixLQUFLLE1BQU07QUFDMUMsVUFBTUMsVUFBVUEsTUFBTTtBQUNwQixjQUFRRCxNQUFJO0FBQUEsUUFDVixLQUFLO0FBQ0gsaUJBQU8sdUJBQUMsZUFBWSxXQUFVLDZCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRDtBQUFBLFFBQ3pELEtBQUs7QUFDSCxpQkFBTyx1QkFBQyxpQkFBYyxXQUFVLDhCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRDtBQUFBLFFBQzVELEtBQUs7QUFDSCxpQkFBTyx1QkFBQyxhQUFVLFdBQVUsMEJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJDO0FBQUEsUUFDcEQsS0FBSztBQUNILGlCQUFPLHVCQUFDLGFBQVUsV0FBVSw2QkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQSxRQUN2RDtBQUNFLGlCQUFPLHVCQUFDLFVBQU8sV0FBVSwyQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUM7QUFBQSxNQUNwRDtBQUFBLElBQ0Y7QUFFQSxVQUFNRSxpQkFBaUJBLENBQUNDLFdBQVc7QUFDakMsVUFBSUEsV0FBVyxVQUFVO0FBQ3ZCLGVBQU8sdUJBQUMsVUFBSyxXQUFVLG9FQUFtRTtBQUFBLGlDQUFDLGVBQVksV0FBVSxhQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQztBQUFBLFVBQUc7QUFBQSxhQUF0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRVA7QUFBQSxNQUNGLFdBQVdBLFdBQVcsYUFBYTtBQUNqQyxlQUFPLHVCQUFDLFVBQUssV0FBVSxtRUFBa0U7QUFBQSxpQ0FBQyxTQUFNLFdBQVUsYUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEI7QUFBQSxVQUFHO0FBQUEsYUFBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5SDtBQUFBLE1BQ2xJO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFHQSxRQUFJSCxTQUFTLFVBQVU7QUFDckIsWUFBTUksV0FBVzdGLEtBQUs4RixlQUFlLENBQUM7QUFDdEMsWUFBTUMsZUFBZUYsU0FBU3RHLFFBQVE7QUFDdEMsWUFBTXlHLGVBQWVILFNBQVNHLGdCQUFnQjtBQUM5QyxZQUFNbEgsU0FBU0MsV0FBV2lCLEtBQUswQixlQUFlMUIsS0FBSzJCLHFCQUFxQixDQUFDO0FBQ3pFLGFBQ0UsdUJBQUMsU0FBSSxXQUFVLHlJQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDZCQUNaK0Qsa0JBQVEsS0FEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsOENBQ1ZLO0FBQUFBO0FBQUFBLGNBQWE7QUFBQSxjQUFDLHVCQUFDLFVBQUssV0FBVSx5QkFBd0I7QUFBQTtBQUFBLGdCQUFFQztBQUFBQSxnQkFBYTtBQUFBLG1CQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RDtBQUFBLGlCQUR6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkRBQ2I7QUFBQSxxQ0FBQyxVQUFLO0FBQUE7QUFBQSxnQkFBU2hHLEtBQUtpRztBQUFBQSxnQkFBYTtBQUFBLGdCQUFFakcsS0FBS2tHO0FBQUFBLG1CQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRDtBQUFBLGNBQ25EbEcsS0FBSzRGLFVBQVUsdUJBQUMsVUFBSyxXQUFVLDBDQUEwQzVGLGVBQUs0RixVQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRTtBQUFBLGlCQUZ4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsYUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYixpQ0FBQyxVQUFLLFdBQVUsK0RBQThEO0FBQUE7QUFBQSxVQUN6RS9CLG1CQUFtQi9FLE1BQU07QUFBQSxhQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxXQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0JBO0FBQUEsSUFFSjtBQUVBLFFBQUkyRyxTQUFTLFFBQVE7QUFDbkIsYUFDRSx1QkFBQyxRQUFHLFdBQVUsK0NBQ1o7QUFBQSwrQkFBQyxRQUFHLFdBQVUsYUFDWixpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNkJBQ1pDLGtCQUFRLEtBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLDZCQUNiMUYsZUFBS21HLGNBQ0puRyxLQUFLb0csVUFBVWxHLGFBQ2ZGLEtBQUtxRyxhQUFhbkcsYUFDbEIsU0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxRQUVBLHVCQUFDLFFBQUcsV0FBVSxhQUNYRixlQUFLc0csVUFBVUMsY0FDWixJQUFJMUMsbUJBQW1COUUsV0FBV2lCLEtBQUtzRyxVQUFVQyxXQUFXLENBQUMsQ0FBQyxLQUM5RCxPQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBRUEsdUJBQUMsUUFBRyxXQUFVLGFBQ1h2RyxlQUFLQyxRQUFRQyxjQUNYRixLQUFLd0csZUFBZXhHLEtBQUt3RyxnQkFBZ0IsUUFDdEN4RyxLQUFLQyxRQUFRQyxZQUNiLFFBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFFQSx1QkFBQyxRQUFHLFdBQVUsYUFBYUYsZUFBS3lHLGdCQUFnQixPQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9EO0FBQUEsUUFFcEQsdUJBQUMsUUFBRyxXQUFVLGFBQWF6RyxlQUFLMEcsVUFBVSxPQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsUUFFOUMsdUJBQUMsUUFBRyxXQUFVLGFBQ1osaUNBQUMsU0FBSSxXQUFVLHVCQUNaZjtBQUFBQSx5QkFBZTNGLEtBQUs0RixNQUFNO0FBQUEsVUFDMUI1RixLQUFLMkcsb0JBQW9CLGNBQ3hCLHVCQUFDLFVBQUssV0FBVSxzQ0FBcUMsMEJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBRUEsdUJBQUMsUUFBRyxXQUFVLG9EQUFtRDtBQUFBO0FBQUEsVUFDN0Q7QUFBQSxVQUNEOUM7QUFBQUEsWUFDQzlFO0FBQUFBLGNBQ0VpQixLQUFLa0IsY0FDTEYsT0FBT2hCLE1BQU1vQixlQUFlLENBQUMsSUFDN0JKLE9BQU9oQixLQUFLcUIsbUJBQW1CLENBQUMsSUFDaENMLE9BQU9oQixLQUFLc0Isb0JBQW9CLENBQUMsS0FDakN0QixLQUFLd0IsV0FDTDtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQUEsYUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxXQXZERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0RBO0FBQUEsSUFFSjtBQUdBLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLHlJQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDZCQUNaa0Usa0JBQVEsS0FEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLGlDQUFDLE9BQUUsV0FBVSw4Q0FDVjFGLGVBQUttRyxjQUFjbkcsS0FBS29HLFVBQVVsRyxhQUFhRixLQUFLcUcsYUFBYW5HLGFBQWEsU0FEakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDJEQUNaRjtBQUFBQSxpQkFBS3VHLGVBQWUsdUJBQUMsVUFBSztBQUFBO0FBQUEsY0FBUzFDLG1CQUFtQjlFLFdBQVdpQixLQUFLdUcsV0FBVyxDQUFDO0FBQUEsaUJBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdFO0FBQUEsWUFDcEZ2RyxLQUFLNEcsV0FBVyx1QkFBQyxVQUFLO0FBQUE7QUFBQSxjQUFPNUcsS0FBSzRHO0FBQUFBLGlCQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwQjtBQUFBLFlBQzFDNUcsS0FBS3FHLGFBQWFHLGVBQWUsdUJBQUMsVUFBSztBQUFBO0FBQUEsY0FBV3hHLEtBQUtxRyxZQUFZbkc7QUFBQUEsaUJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRDO0FBQUEsWUFDN0VGLEtBQUt3RyxlQUFleEcsS0FBS3dHLGdCQUFnQixTQUFTLHVCQUFDLFVBQUs7QUFBQTtBQUFBLGNBQVd4RyxLQUFLRTtBQUFBQSxpQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQSxZQUNsRkYsS0FBS3lHLGdCQUFnQix1QkFBQyxVQUFLO0FBQUE7QUFBQSxjQUFVekcsS0FBS3lHO0FBQUFBLGlCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQztBQUFBLFlBQ3ZEekcsS0FBS3lHLGdCQUFnQix1QkFBQyxVQUFLO0FBQUE7QUFBQSxjQUFTekcsS0FBSzBHO0FBQUFBLGlCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQjtBQUFBLFlBQ2hEMUcsS0FBSzJHLG9CQUFvQixjQUFjLHVCQUFDLFVBQUssV0FBVSwwQ0FBeUMsMEJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1FO0FBQUEsZUFQN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLGFBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsV0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtCQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNaaEI7QUFBQUEsdUJBQWUzRixLQUFLNEYsTUFBTTtBQUFBLFFBQzNCLHVCQUFDLFVBQUssV0FBVSwrREFBOEQ7QUFBQTtBQUFBLFVBQ3pFL0IsbUJBQW1COUUsV0FBV2lCLEtBQUtrQixjQUFjRixPQUFPaEIsTUFBTW9CLGVBQWUsQ0FBQyxJQUFJSixPQUFPaEIsS0FBS3FCLG1CQUFtQixDQUFDLElBQUlMLE9BQU9oQixLQUFLc0Isb0JBQW9CLENBQUMsS0FBS3RCLEtBQUt3QixXQUFXLENBQUMsQ0FBQztBQUFBLGFBRG5MO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsU0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBCQTtBQUFBLEVBRUo7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHFEQUNiO0FBQUEsNkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUNSLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLCtCQUFDLFVBQU8sWUFBWSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlCO0FBQUEsUUFDekIsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsaUNBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBVztBQUFBLFVBQ1gsdUJBQUMsU0FBSSxXQUFVLFFBQ2IsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLG9KQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdLO0FBQUEsY0FDaEssdUJBQUMsU0FBSSxXQUFVLDRIQUNiLGlDQUFDLFlBQVMsV0FBVSx3QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0MsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsZ0hBQStHLHNDQUE3SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsaUNBQWdDLHdFQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLGVBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQSxLQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsdURBQXNELCtCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ1owRDtBQUFBQSxnQ0FBa0I1RjtBQUFBQSxnQkFBSSxDQUFDWCxhQUN0Qix1QkFBQyxhQUE0QixZQUFiQSxTQUFTc0YsSUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0Q7QUFBQSxjQUNqRDtBQUFBLGNBQ0QsdUJBQUMsYUFBVSxVQUFVZ0IsY0FBYyxTQUFTM0MsdUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdFO0FBQUEsaUJBSmxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxlQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLHVEQUFzRCxnQ0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLHdEQUNaNkMsNkJBQW1CN0Y7QUFBQUEsY0FBSSxDQUFDWCxhQUN2Qix1QkFBQyxhQUE0QixZQUFiQSxTQUFTc0YsSUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0Q7QUFBQSxZQUNqRCxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxlQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSx1SUFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxnSEFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0SDtBQUFBLFlBQzVILHVCQUFDLFNBQUksV0FBVSxrSEFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4SDtBQUFBLFlBQzlILHVCQUFDLFNBQUksV0FBVSxtQ0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxvR0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnSDtBQUFBLGdCQUNoSCx1QkFBQyxTQUFJLFdBQVUscUZBQ2IsaUNBQUMsT0FBSSxXQUFVLDZCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdDLEtBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSxtRUFBa0UsMEJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsMENBQXlDLHVIQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsT0FBRSxXQUFVLCtDQUE4QztBQUFBO0FBQUEsa0JBQ3RELHVCQUFDLFVBQUssV0FBVSxlQUFjLDZCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQztBQUFBLGtCQUFPO0FBQUEscUJBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBO0FBQUEsaUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0JBO0FBQUEsZUFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQSxhQXBFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUVBO0FBQUEsV0F2RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdFQTtBQUFBLFNBMUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyRUE7QUFBQSxJQUdDdksscUJBQ0MsdUJBQUMsU0FBSSxXQUFVLHdGQUNiLGlDQUFDLFNBQUksV0FBVSwwRkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxtR0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxpQ0FDYixpQ0FBQyxhQUFVLFdBQVUsOEJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStDLEtBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFFBQUcsV0FBVSxvQ0FBbUMsb0NBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFFO0FBQUEsVUFDcEUySSxnQkFBZ0IsQ0FBQ3BJLDhCQUNoQix1QkFBQyxVQUFLLFdBQVUscUVBQW9FLG1DQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RztBQUFBLGFBTjNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBQ0EsdUJBQUMsWUFBTyxTQUFTZ0osWUFBWSxXQUFVLHNDQUNyQyxpQ0FBQyxLQUFFLFdBQVUsNEJBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQyxLQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLE9BQ1osV0FBQ2hKLDZCQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDhFQUNiO0FBQUEsaUNBQUMsUUFBSyxXQUFVLDRCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QztBQUFBLFVBQ3hDLHVCQUFDLE9BQUUsV0FBVSwwQkFBeUIsK0ZBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFIO0FBQUEsYUFGdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxpREFBZ0QseUNBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBGO0FBQUEsVUFDekYsdUJBQUMsU0FBSSxXQUFVLGlCQUNoQjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBTStCLGVBQWUsU0FBUztBQUFBLGdCQUM5QixPQUFPbkM7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDZ04sTUFBTS9NLFlBQVkrTSxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsZ0JBQzNDLFdBQVcsQ0FBQ0YsTUFBTUEsRUFBRUcsUUFBUSxXQUFXekUsMEJBQTBCO0FBQUEsZ0JBQ2pFLFdBQVU7QUFBQSxnQkFDVixhQUFZO0FBQUEsZ0JBQ1osV0FBUztBQUFBO0FBQUEsY0FQWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPVztBQUFBLFlBR1g7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNdEcsZ0JBQWdCLENBQUNELFlBQVk7QUFBQSxnQkFDNUMsV0FBVTtBQUFBLGdCQUVUQSx5QkFBZSx1QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFXLElBQU0sdUJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFNO0FBQUE7QUFBQSxjQUx6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLGVBakJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JEO0FBQUEsVUFDQ2pDLGlCQUNDLHVCQUFDLFNBQUksV0FBVSx5RUFDYjtBQUFBLG1DQUFDLGVBQVksV0FBVSxhQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLFlBQ2hDLHVCQUFDLFVBQU1BLDJCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFCO0FBQUEsZUFGdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUY7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVN3STtBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUFnSTtBQUFBO0FBQUEsWUFGNUk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0NBO0FBQUEsV0F2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdDQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxhQUViO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGFBY1poSCxzQkFBWUQsUUFDWCx1QkFBQyxTQUFJLFdBQVUsc0RBQXFEO0FBQUE7QUFBQSxVQUNyQ0MsWUFBWUQ7QUFBQUEsYUFEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLElBQ0VDLFlBQVlGLFVBQ2QsdUJBQUMsU0FBSSxXQUFVLDZCQUNiLGlDQUFDLFNBQUksV0FBVSxxRUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlGLEtBRG5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUVBLG1DQUVFO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGFBR2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsNkVBRWI7QUFBQSxxQ0FBQyxTQUFJLFdBQVUscUNBRWI7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsMkJBRWI7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsK0JBQ2IsaUNBQUMsZUFBWSxXQUFVLDZCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnRCxLQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBRUEsdUJBQUMsU0FDQztBQUFBLDJDQUFDLE9BQUUsV0FBVSx1Q0FBc0MsNEJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFQSx1QkFBQyxPQUFFLFdBQVUseUJBQ1ZFO0FBQUFBLGtDQUFZRSxZQUFZdUc7QUFBQUEsc0JBQU87QUFBQSxzQkFBUztBQUFBLHNCQUN4Q3pHLFlBQVlFLFlBQVl1RyxXQUFXLElBQUksU0FBUztBQUFBLHlCQUZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsdUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFTQTtBQUFBLHFCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaUJBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFVLG1DQUFrQztBQUFBO0FBQUEsb0JBQzlDO0FBQUEsb0JBQ0Q2QjtBQUFBQSxzQkFDQ3RJLFlBQVlFLFlBQVlrRTtBQUFBQSx3QkFDdEIsQ0FBQ0MsS0FBS0ksU0FBU0osTUFBTWIsV0FBV2lCLEtBQUtrQixjQUFjLENBQUM7QUFBQSx3QkFDcEQ7QUFBQSxzQkFDRjtBQUFBLG9CQUNGO0FBQUEsdUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFRQTtBQUFBLGtCQUVBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFNBQVMsTUFBTTFELGNBQWMsTUFBTTtBQUFBLHNCQUNuQyxXQUFVO0FBQUEsc0JBRVQ3QywyQkFBaUJFLE9BQU8saUJBQWlCO0FBQUE7QUFBQSxvQkFKNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEscUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0JBO0FBQUEsbUJBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdUNBO0FBQUEsY0FDQ0YsaUJBQWlCRSxRQUFRVSxZQUFZRSxZQUFZdUcsU0FBUyxLQUN6RCx1QkFBQyxTQUFJLFdBQVUseUVBQ2IsaUNBQUMsU0FBSSxXQUFVLDhEQUNiLGlDQUFDLFdBQU0sV0FBVSxzQkFDZjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxjQUNmLGlDQUFDLFFBQ0M7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsdUJBQXNCLG9CQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3QztBQUFBLGtCQUN4Qyx1QkFBQyxRQUFHLFdBQVUsdUJBQXNCLDJCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQztBQUFBLGtCQUMvQyx1QkFBQyxRQUFHLFdBQVUsdUJBQXNCLHdCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0QztBQUFBLGtCQUM1Qyx1QkFBQyxRQUFHLFdBQVUsdUJBQXNCLHVCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQztBQUFBLGtCQUMzQyx1QkFBQyxRQUFHLFdBQVUsdUJBQXNCLHNCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwQztBQUFBLGtCQUMxQyx1QkFBQyxRQUFHLFdBQVUsdUJBQXNCLHNCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwQztBQUFBLGtCQUMxQyx1QkFBQyxRQUFHLFdBQVUsd0JBQXVCLHNCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQztBQUFBLHFCQVA3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLGdCQUNBLHVCQUFDLFdBQ0V6RyxzQkFBWUUsWUFBWTZEO0FBQUFBLGtCQUFJLENBQUNVLE1BQU1pSCxRQUNsQyx1QkFBQyxtQkFBMEIsTUFBWSxNQUFLLFVBQXRCQSxLQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrRDtBQUFBLGdCQUNuRCxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkEsS0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFtQkEsS0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxQkE7QUFBQSxpQkFoRUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFtRUE7QUFBQSxZQUtBLHVCQUFDLFNBQUksV0FBVSw2RUFFYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxxQ0FFYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwyQkFFYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxnQ0FDYixpQ0FBQyxpQkFBYyxXQUFVLDhCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtRCxLQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBRUEsdUJBQUMsU0FDQztBQUFBLDJDQUFDLE9BQUUsV0FBVSx1Q0FBc0MsNEJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFQSx1QkFBQyxPQUFFLFdBQVUseUJBQ1YxTDtBQUFBQSxrQ0FBWUcsWUFBWXNHO0FBQUFBLHNCQUFPO0FBQUEsc0JBQVM7QUFBQSxzQkFDeEN6RyxZQUFZRyxZQUFZc0csV0FBVyxJQUFJLFNBQVM7QUFBQSx5QkFGbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLHVCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBU0E7QUFBQSxxQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlCQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSwyQkFFYjtBQUFBLHlDQUFDLFVBQUssV0FBVSxtQ0FBa0M7QUFBQTtBQUFBLG9CQUM5QztBQUFBLG9CQUNENkI7QUFBQUEsc0JBQ0N0SSxZQUFZRyxZQUFZaUU7QUFBQUEsd0JBQ3RCLENBQUNDLEtBQUtJLFNBQ0pKLE1BQ0FvQixPQUFPaEIsTUFBTW9CLGVBQWUsQ0FBQyxJQUM3QkosT0FBT2hCLE1BQU1xQixtQkFBbUIsQ0FBQyxJQUNqQ0wsT0FBT2hCLE1BQU1zQixvQkFBb0IsQ0FBQztBQUFBLHdCQUNwQztBQUFBLHNCQUNGO0FBQUEsb0JBQ0Y7QUFBQSx1QkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVlBO0FBQUEsa0JBR0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsU0FBUyxNQUFNOUQsY0FBYyxNQUFNO0FBQUEsc0JBQ25DLFdBQVU7QUFBQSxzQkFFVDdDLDJCQUFpQkcsT0FBTyxpQkFBaUI7QUFBQTtBQUFBLG9CQUo1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS0E7QUFBQSxxQkF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF3QkE7QUFBQSxtQkE5Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnREE7QUFBQSxjQUNDSCxpQkFBaUJHLFFBQ2hCLHVCQUFDLFNBQUksV0FBVSx5RkFDWlMsc0JBQVlHLFlBQVk0RDtBQUFBQSxnQkFBSSxDQUFDVSxNQUFNaUgsUUFDbEM7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBRUM7QUFBQSxvQkFDQSxNQUFLO0FBQUE7QUFBQSxrQkFGQUE7QUFBQUEsa0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFHYTtBQUFBLGNBRWQsS0FQSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsaUJBNURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0RBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsNkVBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUscUNBRWI7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsMkJBRWI7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsNEJBQ2IsaUNBQUMsYUFBVSxXQUFVLDBCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQyxLQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBRUEsdUJBQUMsU0FDQztBQUFBLDJDQUFDLE9BQUUsV0FBVSx1Q0FBc0MsaUNBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFQSx1QkFBQyxPQUFFLFdBQVUseUJBQ1YxTDtBQUFBQSxrQ0FBWUksa0JBQWtCcUc7QUFBQUEsc0JBQU87QUFBQSxzQkFBUztBQUFBLHNCQUM5Q3pHLFlBQVlJLGtCQUFrQnFHLFdBQVcsSUFBSSxTQUFTO0FBQUEseUJBRnpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSx1QkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVNBO0FBQUEscUJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFpQkE7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsbUNBQWtDO0FBQUE7QUFBQSxvQkFDOUM7QUFBQSxvQkFDRDZCO0FBQUFBLHNCQUNDdEksWUFBWUksa0JBQWtCZ0U7QUFBQUEsd0JBQzVCLENBQUNDLEtBQUtJLFNBQVNKLE1BQU1iLFdBQVdpQixLQUFLd0IsV0FBVyxDQUFDO0FBQUEsd0JBQ2pEO0FBQUEsc0JBQ0Y7QUFBQSxvQkFDRjtBQUFBLHVCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxTQUFTLE1BQU1oRSxjQUFjLGNBQWM7QUFBQSxzQkFDM0MsV0FBVTtBQUFBLHNCQUVUN0MsMkJBQWlCSSxlQUNkLGlCQUNBO0FBQUE7QUFBQSxvQkFOTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBT0E7QUFBQSxxQkFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFtQkE7QUFBQSxtQkF6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkEyQ0E7QUFBQSxjQUVDSixpQkFBaUJJLGdCQUNoQix1QkFBQyxTQUFJLFdBQVUscUZBQ1pRLHNCQUFZSSxrQkFBa0IyRDtBQUFBQSxnQkFBSSxDQUFDVSxNQUFNaUgsUUFDeEM7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBRUM7QUFBQSxvQkFDQSxNQUFLO0FBQUE7QUFBQSxrQkFGQUE7QUFBQUEsa0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFHcUI7QUFBQSxjQUV0QixLQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxpQkF2REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwREE7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSw2RUFFYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSwrQkFDYixpQ0FBQyxhQUFVLFdBQVUsNkJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThDLEtBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFFQSx1QkFBQyxTQUNDO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHVDQUFzQyw4QkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUVBLHVCQUFDLE9BQUUsV0FBVSx5QkFDVjFMO0FBQUFBLGtDQUFZSyxjQUFjb0c7QUFBQUEsc0JBQU87QUFBQSxzQkFBUztBQUFBLHNCQUMxQ3pHLFlBQVlLLGNBQWNvRyxXQUFXLElBQUksU0FBUztBQUFBLHlCQUZyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsdUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFTQTtBQUFBLHFCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZ0JBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLDJCQUViO0FBQUEseUNBQUMsVUFBSyxXQUFVLG1DQUFrQztBQUFBO0FBQUEsb0JBQzlDO0FBQUEsb0JBQ0Q2QjtBQUFBQSxzQkFDQ3RJLFlBQVlLLGNBQWMrRDtBQUFBQSx3QkFDeEIsQ0FBQ0MsS0FBS0ksU0FDSkosTUFDQWI7QUFBQUEsMEJBQ0VpQixLQUFLMEIsZUFDTDFCLEtBQUsyQixxQkFDTDtBQUFBLHdCQUNGO0FBQUEsd0JBQ0Y7QUFBQSxzQkFDRjtBQUFBLG9CQUNGO0FBQUEsdUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFjQTtBQUFBLGtCQUdBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFNBQVMsTUFBTW5FLGNBQWMsUUFBUTtBQUFBLHNCQUNyQyxXQUFVO0FBQUEsc0JBRVQ3QywyQkFBaUJLLFNBQVMsaUJBQWlCO0FBQUE7QUFBQSxvQkFKOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEscUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBMEJBO0FBQUEsbUJBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0RBO0FBQUEsY0FHQ0wsaUJBQWlCSyxVQUNoQix1QkFBQyxTQUFJLFdBQVUsbUZBQ1pPLHNCQUFZSyxjQUFjMEQ7QUFBQUEsZ0JBQUksQ0FBQ1UsTUFBTWlILFFBQ3BDO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUVDO0FBQUEsb0JBQ0EsTUFBSztBQUFBO0FBQUEsa0JBRkFBO0FBQUFBLGtCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBR2U7QUFBQSxjQUVoQixLQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxpQkE5REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpRUE7QUFBQSxlQTNRRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZRQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLDZFQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLG1DQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDZDQUNiLGlDQUFDLGFBQVUsV0FBVSw2QkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEMsS0FEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLHVDQUFzQyxpQ0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUVBLHVCQUFDLE9BQUUsV0FBVSx5QkFDVjFMO0FBQUFBLGdDQUFZTSx3QkFBd0JtRztBQUFBQSxvQkFBTztBQUFBLG9CQUFTO0FBQUEsb0JBQ3BEekcsWUFBWU0sd0JBQXdCbUcsV0FBVyxJQUM1QyxTQUNBO0FBQUEsdUJBSk47QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLHFCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBV0E7QUFBQSxtQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSxtQ0FBa0M7QUFBQTtBQUFBLGtCQUM5QztBQUFBLGtCQUNENkI7QUFBQUEsb0JBQ0N0SSxZQUFZTSx3QkFBd0I4RDtBQUFBQSxzQkFDbEMsQ0FBQ0MsS0FBS0ksU0FBU0osTUFBTW9CLE9BQU9oQixNQUFNNkIsa0JBQWtCLENBQUM7QUFBQSxzQkFDckQ7QUFBQSxvQkFDRjtBQUFBLGtCQUNGO0FBQUEscUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFRQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTXJFLGNBQWMsa0JBQWtCO0FBQUEsb0JBQy9DLFdBQVU7QUFBQSxvQkFFVDdDLDJCQUFpQnVNLG1CQUNkLGlCQUNBO0FBQUE7QUFBQSxrQkFOTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT0E7QUFBQSxtQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFtQkE7QUFBQSxpQkF2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF3Q0E7QUFBQSxZQUVDdk0saUJBQWlCdU0sb0JBQ2hCM0wsWUFBWU0sd0JBQXdCbUcsU0FBUyxLQUMzQyx1QkFBQyxTQUFJLFdBQVUseUVBQ2IsaUNBQUMsU0FBSSxXQUFVLDhEQUNiLGlDQUFDLFdBQU0sV0FBVSxzQkFDZjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxjQUNmLGlDQUFDLFFBQ0M7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsdUJBQXNCLHdCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE0QztBQUFBLGdCQUM1Qyx1QkFBQyxRQUFHLFdBQVUsdUJBQXNCLDZCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpRDtBQUFBLGdCQUNqRCx1QkFBQyxRQUFHLFdBQVUsdUJBQXNCLHFCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5QztBQUFBLGdCQUN6Qyx1QkFBQyxRQUFHLFdBQVUsdUJBQXNCLHVCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyQztBQUFBLGdCQUMzQyx1QkFBQyxRQUFHLFdBQVUsdUJBQXNCLHNCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwQztBQUFBLGdCQUMxQyx1QkFBQyxRQUFHLFdBQVUsd0JBQXVCLHNCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyQztBQUFBLG1CQU43QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGNBRUEsdUJBQUMsV0FDRXpHLHNCQUFZTSx3QkFBd0J5RDtBQUFBQSxnQkFBSSxDQUFDVSxNQUFNaUgsUUFDOUMsdUJBQUMsUUFBMEIsV0FBVSw0QkFDbkM7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsdUNBQ1hqSCxnQkFBTThGLGFBQWF2RyxRQUFRLE9BRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFFQSx1QkFBQyxRQUFHLFdBQVUsMkJBQ1hTLGdCQUFNOEYsYUFBYUUsZ0JBQWdCLE9BRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFFQSx1QkFBQyxRQUFHLFdBQVUsMkJBQ1hoRyxnQkFBTWlHLGVBQ0gsR0FBR2pHLEtBQUtpRyxZQUFZLElBQUlqRyxNQUFNa0csZUFBZSxFQUFFLEtBQy9DLE9BSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQTtBQUFBLGtCQUVBLHVCQUFDLFFBQUcsV0FBVSwyQkFDWGxHLGdCQUFNbUgsV0FBVyxPQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBRUEsdUJBQUMsUUFBRyxXQUFVLGFBQ1osaUNBQUMsVUFBSyxXQUFVLCtFQUNibkgsZ0JBQU00RixVQUFVLGFBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUlBO0FBQUEsa0JBRUEsdUJBQUMsUUFBRyxXQUFVLGdEQUErQztBQUFBO0FBQUEsb0JBQ3pEL0IsbUJBQW1CN0QsTUFBTTZCLGtCQUFrQixDQUFDO0FBQUEsdUJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkEzQk83QixNQUFNb0gsT0FBT0gsS0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE0QkE7QUFBQSxjQUNELEtBL0JIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0NBO0FBQUEsaUJBNUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkNBLEtBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0NBLEtBaERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaURBO0FBQUEsZUE5Rk47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnR0E7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSw2RUFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxtQ0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwyQ0FDYixpQ0FBQyxjQUFXLFdBQVUsMkJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZDLEtBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsV0FDYjtBQUFBLHlDQUFDLE9BQUUsV0FBVSx1Q0FBc0MsbUNBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFFQSx1QkFBQyxPQUFFLFdBQVUseUJBQ1YxTDtBQUFBQSxnQ0FBWU8sMEJBQTBCa0c7QUFBQUEsb0JBQU87QUFBQSxvQkFBUztBQUFBLG9CQUN0RHpHLFlBQVlPLHlCQUF5QmtHLFdBQVcsSUFDN0MsU0FDQTtBQUFBLHVCQUpOO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxxQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVdBO0FBQUEsbUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUJBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsbUNBQWtDO0FBQUE7QUFBQSxrQkFDOUM7QUFBQSxrQkFDRDZCO0FBQUFBLG9CQUNDdEksWUFBWU8seUJBQXlCNkQ7QUFBQUEsc0JBQ25DLENBQUNDLEtBQUtJLFNBQVNKLE1BQU1vQixPQUFPaEIsTUFBTWxCLFVBQVUsQ0FBQztBQUFBLHNCQUM3QztBQUFBLG9CQUNGO0FBQUEsa0JBQ0Y7QUFBQSxxQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVFBO0FBQUEsZ0JBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsU0FBUyxNQUFNdEIsY0FBYyxtQkFBbUI7QUFBQSxvQkFDaEQsV0FBVTtBQUFBLG9CQUVUN0MsMkJBQWlCME0sb0JBQ2QsaUJBQ0E7QUFBQTtBQUFBLGtCQU5OO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPQTtBQUFBLG1CQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1CQTtBQUFBLGlCQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdDQTtBQUFBLFlBRUMxTSxpQkFBaUIwTSxxQkFDaEI5TCxZQUFZTyx5QkFBeUJrRyxTQUFTLEtBQzVDLHVCQUFDLFNBQUksV0FBVSx5RUFDYixpQ0FBQyxTQUFJLFdBQVUsOERBQ2IsaUNBQUMsV0FBTSxXQUFVLHNCQUNmO0FBQUEscUNBQUMsV0FBTSxXQUFVLGNBQ2YsaUNBQUMsUUFDQztBQUFBLHVDQUFDLFFBQUcsV0FBVSx1QkFBc0Isd0JBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRDO0FBQUEsZ0JBQzVDLHVCQUFDLFFBQUcsV0FBVSx1QkFBc0IsNkJBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlEO0FBQUEsZ0JBQ2pELHVCQUFDLFFBQUcsV0FBVSx1QkFBc0IsOEJBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtEO0FBQUEsZ0JBQ2xELHVCQUFDLFFBQUcsV0FBVSx1QkFBc0IscUJBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlDO0FBQUEsZ0JBQ3pDLHVCQUFDLFFBQUcsV0FBVSx1QkFBc0Isd0JBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRDO0FBQUEsZ0JBQzVDLHVCQUFDLFFBQUcsV0FBVSx1QkFBc0Isc0JBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBDO0FBQUEsZ0JBQzFDLHVCQUFDLFFBQUcsV0FBVSx3QkFBdUIsc0JBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJDO0FBQUEsbUJBUDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBO0FBQUEsY0FFQSx1QkFBQyxXQUNFekcsc0JBQVlPLHlCQUF5QndEO0FBQUFBLGdCQUFJLENBQUNVLE1BQU1pSCxRQUMvQyx1QkFBQyxRQUEwQixXQUFVLDRCQUNuQztBQUFBLHlDQUFDLFFBQUcsV0FBVSx1Q0FDWGpILGdCQUFNOEYsYUFBYXZHLFFBQVEsT0FEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUVBLHVCQUFDLFFBQUcsV0FBVSwyQkFDWFMsZ0JBQU04RixhQUFhRSxnQkFBZ0IsT0FEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUVBLHVCQUFDLFFBQUcsV0FBVSwyQkFDWGhHLGdCQUFNc0gsa0JBQWtCLE9BRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFFQSx1QkFBQyxRQUFHLFdBQVUsMkJBQ1h0SCxnQkFBTXVILFFBQ0gsR0FBR3ZILEtBQUt1SCxLQUFLLElBQUl2SCxNQUFNd0gsUUFBUSxFQUFFLEtBQ2pDLE9BSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQTtBQUFBLGtCQUVBLHVCQUFDLFFBQUcsV0FBVSxzQ0FDWHhILGdCQUFNeUgsWUFBWSxPQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBRUEsdUJBQUMsUUFBRyxXQUFVLGFBQ1osaUNBQUMsVUFBSyxXQUFVLCtFQUNiekgsZ0JBQU00RixVQUFVLGFBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUlBO0FBQUEsa0JBRUEsdUJBQUMsUUFBRyxXQUFVLGdEQUErQztBQUFBO0FBQUEsb0JBQ3pEL0IsbUJBQW1CN0QsTUFBTWxCLFVBQVUsQ0FBQztBQUFBLHVCQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBL0JPa0IsTUFBTW9ILE9BQU9ILEtBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZ0NBO0FBQUEsY0FDRCxLQW5DSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW9DQTtBQUFBLGlCQWpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtEQSxLQW5ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9EQSxLQXJERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXNEQTtBQUFBLGVBbkdOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUdBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsK0ZBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsOEJBQ2IsaUNBQUMsY0FBVyxXQUFVLDRCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QyxLQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsT0FBRSxXQUFVLHFDQUFvQyxpQ0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0U7QUFBQSxnQkFDbEUsdUJBQUMsT0FBRSxXQUFVLHlCQUF3QixtQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0Q7QUFBQSxtQkFGMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSxtQ0FBa0M7QUFBQTtBQUFBLGNBQzdDcEQsbUJBQW1CdEksWUFBWVEsWUFBWTtBQUFBLGlCQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsZUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdHQTtBQUFBLGFBN2tCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOGtCQSxLQXJtQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVtQkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxvREFBbUQsZ0dBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBN21CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOG1CQSxLQTFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTRwQkE7QUFBQSxTQTVxQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZxQkEsS0E5cUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErcUJBO0FBQUEsSUFHRix1QkFBQyxXQUFNLEtBQUcsTUFBRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9FO0FBQUEsT0F6d0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0Ewd0JBO0FBRUo7QUFBRXRDLEdBNWhESUQsWUFBVTtBQUFBa08sS0FBVmxPO0FBOGhETixlQUFlQTtBQUFXLElBQUFrTztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwiTmF2YmFyIiwiU2lkZWJhciIsIkhpQ3VycmVuY3lSdXBlZSIsIkJhbmtub3RlIiwiQnJpZWZjYXNlIiwiVGlja2V0Q2hlY2siLCJNb3JlSG9yaXpvbnRhbCIsIkNoZXZyb25SaWdodCIsIlphcCIsIkJhckNoYXJ0MyIsIkV5ZSIsIkxvY2siLCJBbGVydENpcmNsZSIsIlgiLCJDcmVkaXRDYXJkIiwiQ2FsZW5kYXIiLCJDbG9jayIsIlVzZXJzIiwiV2FsbGV0IiwiVHJlbmRpbmdVcCIsIkNoZWNrQ2lyY2xlIiwiWENpcmNsZSIsIkxvYWRlcjIiLCJUYkNhc2giLCJMaW5rIiwiUm91dGVyTGluayIsIkdpVGFrZU15TW9uZXkiLCJCcmVhZGNydW1iIiwiYXBpIiwiRmlYQ2lyY2xlIiwiRmFFeWUiLCJGYUV5ZVNsYXNoIiwiRmFQaWdneUJhbmsiLCJGaUNoZXZyb25Eb3duIiwiRmlDaGV2cm9uVXAiLCJQYXlPdXRNZW51IiwiX3MiLCJzaG93T3ZlcnZpZXdNb2RhbCIsInNldFNob3dPdmVydmlld01vZGFsIiwidXNlU3RhdGUiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwicGFzc3dvcmRFcnJvciIsInNldFBhc3N3b3JkRXJyb3IiLCJpc0F1dGhlbnRpY2F0ZWRGb3JPdmVydmlldyIsInNldElzQXV0aGVudGljYXRlZEZvck92ZXJ2aWV3Iiwic2VsZWN0ZWRGaWx0ZXIiLCJzZXRTZWxlY3RlZEZpbHRlciIsImN1c3RvbUZyb21EYXRlIiwic2V0Q3VzdG9tRnJvbURhdGUiLCJjdXN0b21Ub0RhdGUiLCJzZXRDdXN0b21Ub0RhdGUiLCJzaG93Q3VzdG9tRGF0ZVBpY2tlciIsInNldFNob3dDdXN0b21EYXRlUGlja2VyIiwiZXhwYW5kZWRTZWN0aW9ucyIsInNldEV4cGFuZGVkU2VjdGlvbnMiLCJjaGl0IiwibG9hbiIsImNhbmNlbGxhdGlvbiIsInNhbGFyeSIsIm92ZXJ2aWV3RGF0YSIsInNldE92ZXJ2aWV3RGF0YSIsInRvdGFsUGF5bWVudE91dCIsImNhdGVnb3JpZXMiLCJsb2FkaW5nIiwiZXJyb3IiLCJwZW5kaW5nRGF0YSIsInNldFBlbmRpbmdEYXRhIiwiY2hpdFBheW91dHMiLCJsb2FuUGF5b3V0cyIsImNoaXRDYW5jZWxsYXRpb25zIiwic2FsYXJ5UGVuZGluZyIsImFkZGl0aW9uYWxTYWxhcnlQZW5kaW5nIiwiZW1wbG95ZWVJbmNlbnRpdmVQZW5kaW5nIiwidG90YWxQZW5kaW5nIiwic2hvd1Bhc3N3b3JkIiwic2V0U2hvd1Bhc3N3b3JkIiwiZm9ybWF0TG9jYWxEYXRlIiwiZGF0ZSIsInkiLCJnZXRGdWxsWWVhciIsIm0iLCJTdHJpbmciLCJnZXRNb250aCIsInBhZFN0YXJ0IiwiZCIsImdldERhdGUiLCJnZXREYXRlUmFuZ2UiLCJmaWx0ZXIiLCJub3ciLCJEYXRlIiwiZnJvbURhdGUiLCJ0b0RhdGUiLCJ5ZXN0ZXJkYXkiLCJzZXREYXRlIiwiZmlyc3REYXkiLCJsYXN0RGF5IiwibGFzdE1vbnRoRmlyc3REYXkiLCJsYXN0TW9udGhMYXN0RGF5IiwidG9nZ2xlU2VjdGlvbiIsInNlY3Rpb24iLCJwcmV2IiwiZmV0Y2hQYXltZW50T3V0RGF0YSIsInJlc3BvbnNlIiwiZ2V0IiwicGFyYW1zIiwiZnJvbV9kYXRlIiwidG9fZGF0ZSIsImRhdGEiLCJzdWNjZXNzIiwiRXJyb3IiLCJjb25zb2xlIiwicHJvY2Vzc1BheW1lbnREYXRhIiwicGF5bWVudHMiLCJjYXRlZ29yeU1hcCIsIk1hcCIsImZvckVhY2giLCJwYXltZW50IiwiY2F0ZWdvcnkiLCJwYXlfZm9yIiwiZGlzYnVyc2VtZW50X3R5cGUiLCJhbW91bnQiLCJwYXJzZUZsb2F0IiwidG90YWxfYW1vdW50IiwiaGFzIiwic2V0IiwiQXJyYXkiLCJmcm9tIiwiZW50cmllcyIsIm1hcCIsIm5hbWUiLCJzb3J0IiwiYSIsImIiLCJyZWR1Y2UiLCJzdW0iLCJjYXQiLCJmZXRjaFBlbmRpbmdQYXltZW50T3V0cyIsImNoaXRSZXNwb25zZSIsIml0ZW0iLCJ1c2VyX2lkIiwiZnVsbF9uYW1lIiwibG9hblJlc3BvbnNlIiwiY2FuY2VsbGF0aW9uUmVzcG9uc2UiLCJzYWxhcnlSZXNwb25zZSIsImFkZGl0aW9uYWxTYWxhcnlSZXNwb25zZSIsImNoaXRJbmNlbnRpdmVSZXNwb25zZSIsImxvYW5JbmNlbnRpdmVSZXNwb25zZSIsInBpZ215SW5jZW50aXZlUmVzcG9uc2UiLCJQcm9taXNlIiwiYWxsIiwiY2hpdEluY2VudGl2ZVBlbmRpbmciLCJsb2FuSW5jZW50aXZlUGVuZGluZyIsInBpZ215SW5jZW50aXZlUGVuZGluZyIsImVtcGxveWVlSW5jZW50aXZlVG90YWwiLCJOdW1iZXIiLCJjaGl0VG90YWwiLCJ3aW5fYW1vdW50IiwibG9hblRvdGFsIiwibG9hbl9hbW91bnQiLCJzZXJ2aWNlX2NoYXJnZXMiLCJkb2N1bWVudF9jaGFyZ2VzIiwiY2FuY2VsbGF0aW9uVG90YWwiLCJiYWxhbmNlIiwic2FsYXJ5VG90YWwiLCJuZXRfcGF5YWJsZSIsInJlbWFpbmluZ19iYWxhbmNlIiwiYWRkaXRpb25hbFNhbGFyeVRvdGFsIiwicGF5YWJsZV9hbW91bnQiLCJtZXNzYWdlIiwibG9hZE92ZXJ2aWV3RGF0YSIsImxlbmd0aCIsImVyciIsInVzZXJSb2xlIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsImlzU3VwZXJBZG1pbiIsImhhbmRsZU92ZXJ2aWV3Q2xpY2siLCJ2ZXJpZnlQYXNzd29yZEFuZFNob3dEYXRhIiwidXNlciIsInVzZXJPYmoiLCJKU09OIiwicGFyc2UiLCJ2YWxpZFBhc3N3b3JkIiwiYWRtaW5BY2Nlc3NQZXJtaXNzaW9ucyIsImFkbWluX2FjY2Vzc19yaWdodF9pZCIsImFjY2Vzc19wZXJtaXNzaW9ucyIsImVkaXRfcGF5bWVudCIsImNsb3NlTW9kYWwiLCJoYW5kbGVGaWx0ZXJDaGFuZ2UiLCJoYW5kbGVDdXN0b21EYXRlQXBwbHkiLCJnZXREYXRlUmFuZ2VEaXNwbGF5IiwiZm9ybWF0RGlzcGxheURhdGUiLCJkYXRlU3RyIiwicGFydHMiLCJzcGxpdCIsImRvY3VtZW50IiwiYm9keSIsInN0eWxlIiwib3ZlcmZsb3ciLCJmb3JtYXRJbmRpYW5OdW1iZXIiLCJudW0iLCJ0b0xvY2FsZVN0cmluZyIsInBheW1lbnRPdXRNZW51Q2F0ZWdvcmllcyIsImlkIiwidGl0bGUiLCJkZXNjcmlwdGlvbiIsImljb24iLCJncmFkaWVudCIsImJnR3JhZGllbnQiLCJocmVmIiwic3RhdHMiLCJzZWNvbmRhcnlJY29uIiwiaWNvbkNvbG9yIiwiYmdDb2xvciIsIlNtYWxsQ2FyZCIsIm9uQ2xpY2siLCJJY29uIiwiU2Vjb25kYXJ5SWNvbiIsImNvbnRlbnQiLCJvdmVydmlld0NhcmQiLCJwYXltZW50Q2F0ZWdvcmllcyIsImVtcGxveWVlQ2F0ZWdvcmllcyIsIlBlbmRpbmdDYXJkIiwiYW1vdW50S2V5IiwidG90YWwiLCJjb3VudCIsIlBlbmRpbmdMaXN0SXRlbSIsInR5cGUiLCJnZXRJY29uIiwiZ2V0U3RhdHVzQmFkZ2UiLCJzdGF0dXMiLCJlbXBsb3llZSIsImVtcGxveWVlX2lkIiwiZW1wbG95ZWVOYW1lIiwiZW1wbG95ZWVDb2RlIiwic2FsYXJ5X21vbnRoIiwic2FsYXJ5X3llYXIiLCJncm91cF9uYW1lIiwiYm9ycm93ZXIiLCJ1c2VyRGV0YWlscyIsImdyb3VwX2lkIiwiZ3JvdXBfdmFsdWUiLCJjdXN0b21lcl9pZCIsImF1Y3Rpb25fY29kZSIsInRpY2tldCIsImFwcHJvdmFsX3N0YXR1cyIsImxvYW5faWQiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJrZXkiLCJpZHgiLCJhZGRpdGlvbmFsU2FsYXJ5IiwiZGV0YWlscyIsIl9pZCIsImVtcGxveWVlSW5jZW50aXZlIiwiaW5jZW50aXZlX3R5cGUiLCJtb250aCIsInllYXIiLCJwYXlfdHlwZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlBheU91dE1lbnUuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IHsgSGlDdXJyZW5jeVJ1cGVlIH0gZnJvbSBcInJlYWN0LWljb25zL2hpMlwiO1xyXG5pbXBvcnQgeyBCYW5rbm90ZSwgQnJpZWZjYXNlLCBUaWNrZXRDaGVjaywgTW9yZUhvcml6b250YWwsIENoZXZyb25SaWdodCwgWmFwLCBCYXJDaGFydDMsIEV5ZSwgTG9jaywgQWxlcnRDaXJjbGUsIFgsIENyZWRpdENhcmQsIENhbGVuZGFyLCBDbG9jaywgVXNlcnMsIFdhbGxldCwgVHJlbmRpbmdVcCwgQ2hlY2tDaXJjbGUsIFhDaXJjbGUsIExvYWRlcjIgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IFRiQ2FzaCB9IGZyb20gXCJyZWFjdC1pY29ucy90YlwiO1xyXG5pbXBvcnQgeyBMaW5rIGFzIFJvdXRlckxpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBHaVRha2VNeU1vbmV5IH0gZnJvbSBcInJlYWN0LWljb25zL2dpXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgeyBGaVhDaXJjbGUgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmlcIjtcclxuaW1wb3J0IHsgRmFFeWUsIEZhRXllU2xhc2gsIEZhUGlnZ3lCYW5rIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IEZpQ2hldnJvbkRvd24sIEZpQ2hldnJvblVwIH0gZnJvbSBcInJlYWN0LWljb25zL2ZpXCI7XHJcblxyXG5jb25zdCBQYXlPdXRNZW51ID0gKCkgPT4ge1xyXG4gIC8vIC0tLS0tLS0tLS0gU3VwZXJhZG1pbiAmIFBhc3N3b3JkIE1vZGFsIFN0YXRlIC0tLS0tLS0tLS1cclxuICBjb25zdCBbc2hvd092ZXJ2aWV3TW9kYWwsIHNldFNob3dPdmVydmlld01vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtwYXNzd29yZEVycm9yLCBzZXRQYXNzd29yZEVycm9yXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtpc0F1dGhlbnRpY2F0ZWRGb3JPdmVydmlldywgc2V0SXNBdXRoZW50aWNhdGVkRm9yT3ZlcnZpZXddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAvLyAtLS0tLS0tLS0tIERhdGUgRmlsdGVyIFN0YXRlIC0tLS0tLS0tLS1cclxuICBjb25zdCBbc2VsZWN0ZWRGaWx0ZXIsIHNldFNlbGVjdGVkRmlsdGVyXSA9IHVzZVN0YXRlKFwidGhpc01vbnRoXCIpO1xyXG4gIGNvbnN0IFtjdXN0b21Gcm9tRGF0ZSwgc2V0Q3VzdG9tRnJvbURhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2N1c3RvbVRvRGF0ZSwgc2V0Q3VzdG9tVG9EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzaG93Q3VzdG9tRGF0ZVBpY2tlciwgc2V0U2hvd0N1c3RvbURhdGVQaWNrZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtleHBhbmRlZFNlY3Rpb25zLCBzZXRFeHBhbmRlZFNlY3Rpb25zXSA9IHVzZVN0YXRlKHtcclxuICAgIGNoaXQ6IGZhbHNlLFxyXG4gICAgbG9hbjogZmFsc2UsXHJcbiAgICBjYW5jZWxsYXRpb246IGZhbHNlLFxyXG4gICAgc2FsYXJ5OiBmYWxzZSwgLy8gbmV3IHNlY3Rpb24gZm9yIHNhbGFyeSBwZW5kaW5nXHJcbiAgfSk7XHJcblxyXG4gIC8vIC0tLS0tLS0tLS0gUGF5bWVudCBPdXQgT3ZlcnZpZXcgRGF0YSAtLS0tLS0tLS0tXHJcbiAgY29uc3QgW292ZXJ2aWV3RGF0YSwgc2V0T3ZlcnZpZXdEYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIHRvdGFsUGF5bWVudE91dDogMCxcclxuICAgIGNhdGVnb3JpZXM6IFtdLFxyXG4gICAgbG9hZGluZzogdHJ1ZSxcclxuICAgIGVycm9yOiBudWxsLFxyXG4gIH0pO1xyXG5cclxuICAvLyAtLS0tLS0tLS0tIFBlbmRpbmcgUGF5bWVudCBPdXRzIFN0YXRlIC0tLS0tLS0tLS1cclxuICBjb25zdCBbcGVuZGluZ0RhdGEsIHNldFBlbmRpbmdEYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGNoaXRQYXlvdXRzOiBbXSxcclxuICAgIGxvYW5QYXlvdXRzOiBbXSxcclxuICAgIGNoaXRDYW5jZWxsYXRpb25zOiBbXSxcclxuICAgIHNhbGFyeVBlbmRpbmc6IFtdLCAvLyBuZXcgYXJyYXkgZm9yIHNhbGFyeSBwZW5kaW5nXHJcbiAgICBhZGRpdGlvbmFsU2FsYXJ5UGVuZGluZzogW10sXHJcbiAgICBlbXBsb3llZUluY2VudGl2ZVBlbmRpbmc6IFtdLFxyXG4gICAgbG9hZGluZzogdHJ1ZSxcclxuICAgIGVycm9yOiBudWxsLFxyXG4gICAgdG90YWxQZW5kaW5nOiAwLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFtzaG93UGFzc3dvcmQsIHNldFNob3dQYXNzd29yZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIC8vIEhlbHBlcjogZm9ybWF0IGRhdGUgYXMgWVlZWS1NTS1ERCBpbiBsb2NhbCB0aW1lXHJcbiAgY29uc3QgZm9ybWF0TG9jYWxEYXRlID0gKGRhdGUpID0+IHtcclxuICAgIGNvbnN0IHkgPSBkYXRlLmdldEZ1bGxZZWFyKCk7XHJcbiAgICBjb25zdCBtID0gU3RyaW5nKGRhdGUuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsICcwJyk7XHJcbiAgICBjb25zdCBkID0gU3RyaW5nKGRhdGUuZ2V0RGF0ZSgpKS5wYWRTdGFydCgyLCAnMCcpO1xyXG4gICAgcmV0dXJuIGAke3l9LSR7bX0tJHtkfWA7XHJcbiAgfTtcclxuXHJcbiAgLy8gSGVscGVyOiBnZXQgZGF0ZSByYW5nZSBiYXNlZCBvbiBmaWx0ZXJcclxuICBjb25zdCBnZXREYXRlUmFuZ2UgPSAoZmlsdGVyKSA9PiB7XHJcbiAgICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xyXG4gICAgbGV0IGZyb21EYXRlLCB0b0RhdGU7XHJcblxyXG4gICAgc3dpdGNoIChmaWx0ZXIpIHtcclxuICAgICAgY2FzZSBcInRvZGF5XCI6XHJcbiAgICAgICAgZnJvbURhdGUgPSBmb3JtYXRMb2NhbERhdGUobm93KTtcclxuICAgICAgICB0b0RhdGUgPSBmb3JtYXRMb2NhbERhdGUobm93KTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgY2FzZSBcInllc3RlcmRheVwiOlxyXG4gICAgICAgIGNvbnN0IHllc3RlcmRheSA9IG5ldyBEYXRlKG5vdyk7XHJcbiAgICAgICAgeWVzdGVyZGF5LnNldERhdGUoeWVzdGVyZGF5LmdldERhdGUoKSAtIDEpO1xyXG4gICAgICAgIGZyb21EYXRlID0gZm9ybWF0TG9jYWxEYXRlKHllc3RlcmRheSk7XHJcbiAgICAgICAgdG9EYXRlID0gZm9ybWF0TG9jYWxEYXRlKHllc3RlcmRheSk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgXCJ0aGlzTW9udGhcIjpcclxuICAgICAgICBjb25zdCBmaXJzdERheSA9IG5ldyBEYXRlKG5vdy5nZXRGdWxsWWVhcigpLCBub3cuZ2V0TW9udGgoKSwgMSk7XHJcbiAgICAgICAgY29uc3QgbGFzdERheSA9IG5ldyBEYXRlKG5vdy5nZXRGdWxsWWVhcigpLCBub3cuZ2V0TW9udGgoKSArIDEsIDApO1xyXG4gICAgICAgIGZyb21EYXRlID0gZm9ybWF0TG9jYWxEYXRlKGZpcnN0RGF5KTtcclxuICAgICAgICB0b0RhdGUgPSBmb3JtYXRMb2NhbERhdGUobGFzdERheSk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgXCJsYXN0TW9udGhcIjpcclxuICAgICAgICBjb25zdCBsYXN0TW9udGhGaXJzdERheSA9IG5ldyBEYXRlKG5vdy5nZXRGdWxsWWVhcigpLCBub3cuZ2V0TW9udGgoKSAtIDEsIDEpO1xyXG4gICAgICAgIGNvbnN0IGxhc3RNb250aExhc3REYXkgPSBuZXcgRGF0ZShub3cuZ2V0RnVsbFllYXIoKSwgbm93LmdldE1vbnRoKCksIDApO1xyXG4gICAgICAgIGZyb21EYXRlID0gZm9ybWF0TG9jYWxEYXRlKGxhc3RNb250aEZpcnN0RGF5KTtcclxuICAgICAgICB0b0RhdGUgPSBmb3JtYXRMb2NhbERhdGUobGFzdE1vbnRoTGFzdERheSk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgXCJjdXN0b21cIjpcclxuICAgICAgICBmcm9tRGF0ZSA9IGN1c3RvbUZyb21EYXRlIHx8IGZvcm1hdExvY2FsRGF0ZShuZXcgRGF0ZSgpKTtcclxuICAgICAgICB0b0RhdGUgPSBjdXN0b21Ub0RhdGUgfHwgZm9ybWF0TG9jYWxEYXRlKG5ldyBEYXRlKCkpO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIGZyb21EYXRlID0gZm9ybWF0TG9jYWxEYXRlKG5ldyBEYXRlKCkpO1xyXG4gICAgICAgIHRvRGF0ZSA9IGZvcm1hdExvY2FsRGF0ZShuZXcgRGF0ZSgpKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4geyBmcm9tRGF0ZSwgdG9EYXRlIH07XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdG9nZ2xlU2VjdGlvbiA9IChzZWN0aW9uKSA9PiB7XHJcbiAgICBzZXRFeHBhbmRlZFNlY3Rpb25zKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBbc2VjdGlvbl06ICFwcmV2W3NlY3Rpb25dLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIC8vIEZldGNoIHBheW1lbnQgb3V0IGRhdGEgZnJvbSBBUElcclxuICBjb25zdCBmZXRjaFBheW1lbnRPdXREYXRhID0gYXN5bmMgKGZyb21EYXRlLCB0b0RhdGUpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldCgnL3YxL2FkbWluL3BheW1lbnRzLW91dC8nLCB7XHJcbiAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICBmcm9tX2RhdGU6IGZyb21EYXRlLFxyXG4gICAgICAgICAgdG9fZGF0ZTogdG9EYXRlXHJcbiAgICAgICAgfSxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBpZiAoIXJlc3BvbnNlLmRhdGEuc3VjY2VzcyB8fCAhcmVzcG9uc2UuZGF0YS5kYXRhKSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIHJlc3BvbnNlIGZyb20gc2VydmVyJyk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHJldHVybiByZXNwb25zZS5kYXRhLmRhdGE7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcGF5bWVudCBvdXQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICByZXR1cm4gW107XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gUHJvY2VzcyBwYXltZW50IGRhdGEgYW5kIGNhbGN1bGF0ZSB0b3RhbHMgYnkgY2F0ZWdvcnlcclxuICBjb25zdCBwcm9jZXNzUGF5bWVudERhdGEgPSAocGF5bWVudHMpID0+IHtcclxuICAgIGNvbnN0IGNhdGVnb3J5TWFwID0gbmV3IE1hcCgpO1xyXG5cclxuICAgIHBheW1lbnRzLmZvckVhY2gocGF5bWVudCA9PiB7XHJcbiAgICAgIGxldCBjYXRlZ29yeSA9IHBheW1lbnQuY2F0ZWdvcnkgfHwgcGF5bWVudC5wYXlfZm9yIHx8IHBheW1lbnQuZGlzYnVyc2VtZW50X3R5cGUgfHwgJ090aGVyJztcclxuXHJcbiAgICAgIGlmIChjYXRlZ29yeSA9PT0gJ1BpZ21lIFBheW1lbnQnIHx8IGNhdGVnb3J5ID09PSAnUGlnbWUnKSB7XHJcbiAgICAgICAgY2F0ZWdvcnkgPSAnUElHTUUgUEFZT1VUJztcclxuICAgICAgfSBlbHNlIGlmIChjYXRlZ29yeSA9PT0gJ0xvYW4gUGF5bWVudCcgfHwgY2F0ZWdvcnkgPT09ICdMb2FuJykge1xyXG4gICAgICAgIGNhdGVnb3J5ID0gJ0xPQU4gUEFZT1VUJztcclxuICAgICAgfSBlbHNlIGlmIChjYXRlZ29yeSA9PT0gJ0F1Y3Rpb24gV2lubmluZyBQYXlvdXQnKSB7XHJcbiAgICAgICAgY2F0ZWdvcnkgPSAnQ0hJVCBQQVlPVVQnO1xyXG4gICAgICB9IGVsc2UgaWYgKGNhdGVnb3J5ID09PSAnQ2hpdCBDYW5jZWxsYXRpb24nIHx8IGNhdGVnb3J5ID09PSAnVHJhbnNmZXInKSB7XHJcbiAgICAgICAgY2F0ZWdvcnkgPSAnQ0hJVCBDQU5DRUxMQVRJT04nO1xyXG4gICAgICB9IGVsc2UgaWYgKGNhdGVnb3J5ID09PSAnc2FsYXJ5Jykge1xyXG4gICAgICAgIGNhdGVnb3J5ID0gJ1NBTEFSWSc7XHJcbiAgICAgIH0gZWxzZSBpZiAoY2F0ZWdvcnkgPT09ICdDaGl0IENhbmNlbGxhdGlvbi9QYXlvdXQnKSB7XHJcbiAgICAgICAgY2F0ZWdvcnkgPSAnQ0hJVCBDQU5DRUxMQVRJT04nO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCBhbW91bnQgPSBwYXJzZUZsb2F0KHBheW1lbnQuYW1vdW50IHx8IHBheW1lbnQudG90YWxfYW1vdW50IHx8IDApO1xyXG5cclxuICAgICAgaWYgKGNhdGVnb3J5TWFwLmhhcyhjYXRlZ29yeSkpIHtcclxuICAgICAgICBjYXRlZ29yeU1hcC5zZXQoY2F0ZWdvcnksIGNhdGVnb3J5TWFwLmdldChjYXRlZ29yeSkgKyBhbW91bnQpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNhdGVnb3J5TWFwLnNldChjYXRlZ29yeSwgYW1vdW50KTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgY2F0ZWdvcmllcyA9IEFycmF5LmZyb20oY2F0ZWdvcnlNYXAuZW50cmllcygpKVxyXG4gICAgICAubWFwKChbbmFtZSwgYW1vdW50XSkgPT4gKHsgbmFtZSwgYW1vdW50IH0pKVxyXG4gICAgICAuc29ydCgoYSwgYikgPT4gYi5hbW91bnQgLSBhLmFtb3VudCk7XHJcblxyXG4gICAgY29uc3QgdG90YWxQYXltZW50T3V0ID0gY2F0ZWdvcmllcy5yZWR1Y2UoKHN1bSwgY2F0KSA9PiBzdW0gKyBjYXQuYW1vdW50LCAwKTtcclxuXHJcbiAgICByZXR1cm4geyBjYXRlZ29yaWVzLCB0b3RhbFBheW1lbnRPdXQgfTtcclxuICB9O1xyXG5cclxuICAvLyAtLS0tLS0tLS0tIEZldGNoIFBlbmRpbmcgUGF5bWVudCBPdXRzIC0tLS0tLS0tLS1cclxuICBjb25zdCBmZXRjaFBlbmRpbmdQYXltZW50T3V0cyA9IGFzeW5jICgpID0+IHtcclxuICAgIHNldFBlbmRpbmdEYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgbG9hZGluZzogdHJ1ZSwgZXJyb3I6IG51bGwgfSkpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIC8vIEZldGNoIENoaXQgUGF5b3V0c1xyXG4gICAgICBjb25zdCBjaGl0UmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KCcvdjEvYWRtaW4vYXVjdGlvbnMvcGF5bWVudC1vdXRzJyk7XHJcbiAgICAgIGNvbnN0IGNoaXRQYXlvdXRzID0gKGNoaXRSZXNwb25zZS5kYXRhPy5kYXRhIHx8IFtdKS5maWx0ZXIoXHJcbiAgICAgICAgKGl0ZW0pID0+XHJcbiAgICAgICAgICBpdGVtLnVzZXJfaWQ/LmZ1bGxfbmFtZSAmJlxyXG4gICAgICAgICAgaXRlbS51c2VyX2lkPy5mdWxsX25hbWUgIT09IFwiTi9BXCJcclxuICAgICAgKTtcclxuXHJcbiAgICAgIC8vIEZldGNoIExvYW4gUGF5b3V0cyAoQVBQUk9WRUQgc3RhdHVzKVxyXG4gICAgICBjb25zdCBsb2FuUmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KCcvdjEvYWRtaW4vbG9hbnMvP2FwcHJvdmFsX3N0YXR1cz1BUFBST1ZFRCcpO1xyXG4gICAgICBjb25zdCBsb2FuUGF5b3V0cyA9IGxvYW5SZXNwb25zZS5kYXRhLmRhdGEgfHwgW107XHJcblxyXG4gICAgICAvLyBGZXRjaCBDaGl0IENhbmNlbGxhdGlvbnMgKFVzZXIgQWNjb3VudHMgd2l0aCBiYWxhbmNlKVxyXG4gICAgICBjb25zdCBjYW5jZWxsYXRpb25SZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoJy92MS9hZG1pbi91c2VyLWFjY291bnRzJyk7XHJcbiAgICAgIGNvbnN0IGNoaXRDYW5jZWxsYXRpb25zID0gY2FuY2VsbGF0aW9uUmVzcG9uc2UuZGF0YS5kYXRhIHx8IFtdO1xyXG5cclxuICAgICAgLy8gRmV0Y2ggU2FsYXJ5IFBlbmRpbmdcclxuICAgICAgY29uc3Qgc2FsYXJ5UmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KCcvc2FsYXJ5LXBheW1lbnQvc3RhdHVzL3BlbmRpbmcnKTtcclxuICAgICAgY29uc3Qgc2FsYXJ5UGVuZGluZyA9IHNhbGFyeVJlc3BvbnNlLmRhdGEuZGF0YSB8fCBbXTtcclxuXHJcbiAgICAgIC8vIC0tLS0tLS0tLS0gTkVXOiBGZXRjaCBBZGRpdGlvbmFsIFNhbGFyeSBQZW5kaW5nIC0tLS0tLS0tLS1cclxuICAgICAgY29uc3QgYWRkaXRpb25hbFNhbGFyeVJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICAnL2FkZGl0aW9uYWwtc2FsYXJ5LXBheW1lbnQtb3V0P3N0YXR1cz1QZW5kaW5nJ1xyXG4gICAgICApO1xyXG4gICAgICBjb25zdCBhZGRpdGlvbmFsU2FsYXJ5UGVuZGluZyA9IGFkZGl0aW9uYWxTYWxhcnlSZXNwb25zZS5kYXRhPy5kYXRhIHx8IFtdO1xyXG5cclxuICAgICAgLy8gLS0tLS0tLS0tLSBORVc6IEZldGNoIEVtcGxveWVlIEluY2VudGl2ZSBQZW5kaW5nIC0tLS0tLS0tLS1cclxuICAgICAgY29uc3QgW1xyXG4gICAgICAgIGNoaXRJbmNlbnRpdmVSZXNwb25zZSxcclxuICAgICAgICBsb2FuSW5jZW50aXZlUmVzcG9uc2UsXHJcbiAgICAgICAgcGlnbXlJbmNlbnRpdmVSZXNwb25zZSxcclxuICAgICAgXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICBhcGkuZ2V0KCcvZW1wbG95ZWUtaW5jZW50aXZlLXBheW1lbnQtb3V0P2luY2VudGl2ZV90eXBlPUNoaXQmc3RhdHVzPVBlbmRpbmcnKSxcclxuICAgICAgICBhcGkuZ2V0KCcvZW1wbG95ZWUtaW5jZW50aXZlLXBheW1lbnQtb3V0P2luY2VudGl2ZV90eXBlPUxvYW4mc3RhdHVzPVBlbmRpbmcnKSxcclxuICAgICAgICBhcGkuZ2V0KCcvZW1wbG95ZWUtaW5jZW50aXZlLXBheW1lbnQtb3V0P2luY2VudGl2ZV90eXBlPVBpZ215JnN0YXR1cz1QZW5kaW5nJyksXHJcbiAgICAgIF0pO1xyXG4gICAgICBjb25zdCBjaGl0SW5jZW50aXZlUGVuZGluZyA9IGNoaXRJbmNlbnRpdmVSZXNwb25zZS5kYXRhPy5kYXRhIHx8IFtdO1xyXG4gICAgICBjb25zdCBsb2FuSW5jZW50aXZlUGVuZGluZyA9IGxvYW5JbmNlbnRpdmVSZXNwb25zZS5kYXRhPy5kYXRhIHx8IFtdO1xyXG4gICAgICBjb25zdCBwaWdteUluY2VudGl2ZVBlbmRpbmcgPSBwaWdteUluY2VudGl2ZVJlc3BvbnNlLmRhdGE/LmRhdGEgfHwgW107XHJcblxyXG4gICAgICBjb25zdCBlbXBsb3llZUluY2VudGl2ZVBlbmRpbmcgPSBbXHJcbiAgICAgICAgLi4uY2hpdEluY2VudGl2ZVBlbmRpbmcsXHJcbiAgICAgICAgLi4ubG9hbkluY2VudGl2ZVBlbmRpbmcsXHJcbiAgICAgICAgLi4ucGlnbXlJbmNlbnRpdmVQZW5kaW5nLFxyXG4gICAgICBdO1xyXG5cclxuICAgICAgY29uc3QgZW1wbG95ZWVJbmNlbnRpdmVUb3RhbCA9IGVtcGxveWVlSW5jZW50aXZlUGVuZGluZy5yZWR1Y2UoXHJcbiAgICAgICAgKHN1bSwgaXRlbSkgPT4gc3VtICsgTnVtYmVyKGl0ZW0/LmFtb3VudCB8fCAwKSxcclxuICAgICAgICAwXHJcbiAgICAgICk7XHJcblxyXG4gICAgICAvLyBDYWxjdWxhdGUgdG90YWxzXHJcbiAgICAgIGNvbnN0IGNoaXRUb3RhbCA9IGNoaXRQYXlvdXRzLnJlZHVjZShcclxuICAgICAgICAoc3VtLCBpdGVtKSA9PiBzdW0gKyBwYXJzZUZsb2F0KGl0ZW0ud2luX2Ftb3VudCB8fCAwKSxcclxuICAgICAgICAwXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBjb25zdCBsb2FuVG90YWwgPSBsb2FuUGF5b3V0cy5yZWR1Y2UoXHJcbiAgICAgICAgKHN1bSwgaXRlbSkgPT5cclxuICAgICAgICAgIHN1bSArXHJcbiAgICAgICAgICBOdW1iZXIoaXRlbT8ubG9hbl9hbW91bnQgfHwgMCkgLVxyXG4gICAgICAgICAgTnVtYmVyKGl0ZW0uc2VydmljZV9jaGFyZ2VzIHx8IDApIC1cclxuICAgICAgICAgIE51bWJlcihpdGVtLmRvY3VtZW50X2NoYXJnZXMgfHwgMCksXHJcbiAgICAgICAgMFxyXG4gICAgICApO1xyXG5cclxuICAgICAgY29uc3QgY2FuY2VsbGF0aW9uVG90YWwgPSBjaGl0Q2FuY2VsbGF0aW9ucy5yZWR1Y2UoXHJcbiAgICAgICAgKHN1bSwgaXRlbSkgPT4gc3VtICsgcGFyc2VGbG9hdChpdGVtLmJhbGFuY2UgfHwgMCksXHJcbiAgICAgICAgMFxyXG4gICAgICApO1xyXG5cclxuICAgICAgY29uc3Qgc2FsYXJ5VG90YWwgPSBzYWxhcnlQZW5kaW5nLnJlZHVjZShcclxuICAgICAgICAoc3VtLCBpdGVtKSA9PlxyXG4gICAgICAgICAgc3VtICsgcGFyc2VGbG9hdChpdGVtLm5ldF9wYXlhYmxlIHx8IGl0ZW0ucmVtYWluaW5nX2JhbGFuY2UgfHwgMCksXHJcbiAgICAgICAgMFxyXG4gICAgICApO1xyXG5cclxuICAgICAgLy8gLS0tLS0tLS0tLSBORVc6IEFkZGl0aW9uYWwgU2FsYXJ5IFRvdGFsIC0tLS0tLS0tLS1cclxuICAgICAgY29uc3QgYWRkaXRpb25hbFNhbGFyeVRvdGFsID0gYWRkaXRpb25hbFNhbGFyeVBlbmRpbmcucmVkdWNlKFxyXG4gICAgICAgIChzdW0sIGl0ZW0pID0+IHN1bSArIE51bWJlcihpdGVtPy5wYXlhYmxlX2Ftb3VudCB8fCAwKSxcclxuICAgICAgICAwXHJcbiAgICAgICk7XHJcblxyXG5cclxuXHJcbiAgICAgIHNldFBlbmRpbmdEYXRhKHtcclxuICAgICAgICBjaGl0UGF5b3V0cyxcclxuICAgICAgICBsb2FuUGF5b3V0cyxcclxuICAgICAgICBjaGl0Q2FuY2VsbGF0aW9ucyxcclxuICAgICAgICBzYWxhcnlQZW5kaW5nLFxyXG4gICAgICAgIGFkZGl0aW9uYWxTYWxhcnlQZW5kaW5nLFxyXG4gICAgICAgIGVtcGxveWVlSW5jZW50aXZlUGVuZGluZyxcclxuICAgICAgICBsb2FkaW5nOiBmYWxzZSxcclxuICAgICAgICBlcnJvcjogbnVsbCxcclxuICAgICAgICB0b3RhbFBlbmRpbmc6XHJcbiAgICAgICAgICBjaGl0VG90YWwgK1xyXG4gICAgICAgICAgbG9hblRvdGFsICtcclxuICAgICAgICAgIGNhbmNlbGxhdGlvblRvdGFsICtcclxuICAgICAgICAgIHNhbGFyeVRvdGFsICtcclxuICAgICAgICAgIGFkZGl0aW9uYWxTYWxhcnlUb3RhbCArXHJcbiAgICAgICAgICBlbXBsb3llZUluY2VudGl2ZVRvdGFsLFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBwZW5kaW5nIHBheW1lbnQgb3V0czpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRQZW5kaW5nRGF0YShwcmV2ID0+ICh7XHJcbiAgICAgICAgLi4ucHJldixcclxuICAgICAgICBsb2FkaW5nOiBmYWxzZSxcclxuICAgICAgICBlcnJvcjogZXJyb3IubWVzc2FnZSB8fCAnRmFpbGVkIHRvIGxvYWQgcGVuZGluZyBkYXRhJ1xyXG4gICAgICB9KSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gTG9hZCBhbGwgZGF0YSB3aXRoIGRhdGUgZmlsdGVyXHJcbiAgY29uc3QgbG9hZE92ZXJ2aWV3RGF0YSA9IGFzeW5jIChmaWx0ZXIgPSBzZWxlY3RlZEZpbHRlcikgPT4ge1xyXG4gICAgY29uc3QgeyBmcm9tRGF0ZSwgdG9EYXRlIH0gPSBnZXREYXRlUmFuZ2UoZmlsdGVyKTtcclxuXHJcbiAgICBzZXRPdmVydmlld0RhdGEocHJldiA9PiAoeyAuLi5wcmV2LCBsb2FkaW5nOiB0cnVlLCBlcnJvcjogbnVsbCB9KSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBwYXltZW50cyA9IGF3YWl0IGZldGNoUGF5bWVudE91dERhdGEoZnJvbURhdGUsIHRvRGF0ZSk7XHJcblxyXG4gICAgICBpZiAocGF5bWVudHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgc2V0T3ZlcnZpZXdEYXRhKHtcclxuICAgICAgICAgIHRvdGFsUGF5bWVudE91dDogMCxcclxuICAgICAgICAgIGNhdGVnb3JpZXM6IFtdLFxyXG4gICAgICAgICAgbG9hZGluZzogZmFsc2UsXHJcbiAgICAgICAgICBlcnJvcjogbnVsbCxcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IHsgY2F0ZWdvcmllcywgdG90YWxQYXltZW50T3V0IH0gPSBwcm9jZXNzUGF5bWVudERhdGEocGF5bWVudHMpO1xyXG5cclxuICAgICAgc2V0T3ZlcnZpZXdEYXRhKHtcclxuICAgICAgICB0b3RhbFBheW1lbnRPdXQsXHJcbiAgICAgICAgY2F0ZWdvcmllcyxcclxuICAgICAgICBsb2FkaW5nOiBmYWxzZSxcclxuICAgICAgICBlcnJvcjogbnVsbCxcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2V0T3ZlcnZpZXdEYXRhKHByZXYgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIGxvYWRpbmc6IGZhbHNlLFxyXG4gICAgICAgIGVycm9yOiBlcnIubWVzc2FnZSB8fCAnRmFpbGVkIHRvIGxvYWQgZGF0YSdcclxuICAgICAgfSkpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIC0tLS0tLS0tLS0gU3VwZXJhZG1pbiAmIFBhc3N3b3JkIExvZ2ljIC0tLS0tLS0tLS1cclxuICBjb25zdCB1c2VyUm9sZSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclJvbGVcIikgfHwgXCJzdXBlcmFkbWluXCI7XHJcbiAgY29uc3QgaXNTdXBlckFkbWluID0gdXNlclJvbGUgPT09IFwic3VwZXJhZG1pblwiO1xyXG5cclxuICBjb25zdCBoYW5kbGVPdmVydmlld0NsaWNrID0gKCkgPT4ge1xyXG4gICAgaWYgKCFpc1N1cGVyQWRtaW4pIHtcclxuICAgICAgc2V0UGFzc3dvcmRFcnJvcihcIkFjY2VzcyBkZW5pZWQ6IE9ubHkgc3VwZXJhZG1pbiBjYW4gdmlldyBvdmVydmlld1wiKTtcclxuICAgICAgc2V0U2hvd092ZXJ2aWV3TW9kYWwodHJ1ZSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHNldFBhc3N3b3JkKFwiXCIpO1xyXG4gICAgc2V0UGFzc3dvcmRFcnJvcihcIlwiKTtcclxuICAgIHNldElzQXV0aGVudGljYXRlZEZvck92ZXJ2aWV3KGZhbHNlKTtcclxuICAgIHNldFNob3dPdmVydmlld01vZGFsKHRydWUpO1xyXG4gICAgc2V0U2VsZWN0ZWRGaWx0ZXIoXCJ0aGlzTW9udGhcIik7XHJcbiAgICBzZXRDdXN0b21Gcm9tRGF0ZShcIlwiKTtcclxuICAgIHNldEN1c3RvbVRvRGF0ZShcIlwiKTtcclxuICAgIHNldFNob3dDdXN0b21EYXRlUGlja2VyKGZhbHNlKTtcclxuXHJcbiAgICAvLyBGZXRjaCBwZW5kaW5nIGRhdGEgd2hlbiBtb2RhbCBvcGVuc1xyXG4gICAgZmV0Y2hQZW5kaW5nUGF5bWVudE91dHMoKTtcclxuICB9O1xyXG5cclxuICBjb25zdCB2ZXJpZnlQYXNzd29yZEFuZFNob3dEYXRhID0gKCkgPT4ge1xyXG4gICAgY29uc3QgdXNlciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGNvbnN0IHVzZXJPYmogPSBKU09OLnBhcnNlKHVzZXIpO1xyXG4gICAgY29uc3QgdmFsaWRQYXNzd29yZCA9IHVzZXJPYmo/LnBhc3N3b3JkO1xyXG4gICAgY29uc3QgYWRtaW5BY2Nlc3NQZXJtaXNzaW9ucyA9XHJcbiAgICAgIHVzZXJPYmouYWRtaW5fYWNjZXNzX3JpZ2h0X2lkPy5hY2Nlc3NfcGVybWlzc2lvbnM7XHJcblxyXG4gICAgaWYgKHBhc3N3b3JkID09PSB2YWxpZFBhc3N3b3JkICYmIGFkbWluQWNjZXNzUGVybWlzc2lvbnM/LmVkaXRfcGF5bWVudCA9PT0gXCJ0cnVlXCIpIHtcclxuICAgICAgc2V0SXNBdXRoZW50aWNhdGVkRm9yT3ZlcnZpZXcodHJ1ZSk7XHJcbiAgICAgIHNldFBhc3N3b3JkRXJyb3IoXCJcIik7XHJcbiAgICAgIGxvYWRPdmVydmlld0RhdGEoXCJ0aGlzTW9udGhcIik7XHJcbiAgICAgIGZldGNoUGVuZGluZ1BheW1lbnRPdXRzKCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRQYXNzd29yZEVycm9yKFwiSW52YWxpZCBwYXNzd29yZCBvciBpbnN1ZmZpY2llbnQgcHJpdmlsZWdlc1wiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBjbG9zZU1vZGFsID0gKCkgPT4ge1xyXG4gICAgc2V0U2hvd092ZXJ2aWV3TW9kYWwoZmFsc2UpO1xyXG4gICAgc2V0UGFzc3dvcmQoXCJcIik7XHJcbiAgICBzZXRQYXNzd29yZEVycm9yKFwiXCIpO1xyXG4gICAgc2V0SXNBdXRoZW50aWNhdGVkRm9yT3ZlcnZpZXcoZmFsc2UpO1xyXG4gIH07XHJcblxyXG4gIC8vIEhhbmRsZSBmaWx0ZXIgY2hhbmdlXHJcbiAgY29uc3QgaGFuZGxlRmlsdGVyQ2hhbmdlID0gKGZpbHRlcikgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRGaWx0ZXIoZmlsdGVyKTtcclxuICAgIGlmIChmaWx0ZXIgPT09IFwiY3VzdG9tXCIpIHtcclxuICAgICAgc2V0U2hvd0N1c3RvbURhdGVQaWNrZXIodHJ1ZSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRTaG93Q3VzdG9tRGF0ZVBpY2tlcihmYWxzZSk7XHJcbiAgICAgIGxvYWRPdmVydmlld0RhdGEoZmlsdGVyKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBIYW5kbGUgY3VzdG9tIGRhdGUgYXBwbHlcclxuICBjb25zdCBoYW5kbGVDdXN0b21EYXRlQXBwbHkgPSAoKSA9PiB7XHJcbiAgICBpZiAoY3VzdG9tRnJvbURhdGUgJiYgY3VzdG9tVG9EYXRlKSB7XHJcbiAgICAgIGxvYWRPdmVydmlld0RhdGEoXCJjdXN0b21cIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gR2V0IGZvcm1hdHRlZCBkYXRlIHJhbmdlIGRpc3BsYXlcclxuICBjb25zdCBnZXREYXRlUmFuZ2VEaXNwbGF5ID0gKCkgPT4ge1xyXG4gICAgY29uc3QgeyBmcm9tRGF0ZSwgdG9EYXRlIH0gPSBnZXREYXRlUmFuZ2Uoc2VsZWN0ZWRGaWx0ZXIpO1xyXG4gICAgaWYgKHNlbGVjdGVkRmlsdGVyID09PSBcInRvZGF5XCIpIHJldHVybiBcIlRvZGF5XCI7XHJcbiAgICBpZiAoc2VsZWN0ZWRGaWx0ZXIgPT09IFwieWVzdGVyZGF5XCIpIHJldHVybiBcIlllc3RlcmRheVwiO1xyXG4gICAgaWYgKHNlbGVjdGVkRmlsdGVyID09PSBcInRoaXNNb250aFwiKSByZXR1cm4gXCJUaGlzIE1vbnRoXCI7XHJcbiAgICBpZiAoc2VsZWN0ZWRGaWx0ZXIgPT09IFwibGFzdE1vbnRoXCIpIHJldHVybiBcIkxhc3QgTW9udGhcIjtcclxuICAgIGlmIChzZWxlY3RlZEZpbHRlciA9PT0gXCJjdXN0b21cIikge1xyXG4gICAgICBpZiAoY3VzdG9tRnJvbURhdGUgJiYgY3VzdG9tVG9EYXRlKSB7XHJcbiAgICAgICAgcmV0dXJuIGAke2Zvcm1hdERpc3BsYXlEYXRlKGN1c3RvbUZyb21EYXRlKX0gLSAke2Zvcm1hdERpc3BsYXlEYXRlKGN1c3RvbVRvRGF0ZSl9YDtcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4gXCJDdXN0b20gUmFuZ2VcIjtcclxuICAgIH1cclxuICAgIHJldHVybiBcIlwiO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZvcm1hdERpc3BsYXlEYXRlID0gKGRhdGVTdHIpID0+IHtcclxuICAgIGlmICghZGF0ZVN0cikgcmV0dXJuIFwiXCI7XHJcbiAgICBjb25zdCBwYXJ0cyA9IGRhdGVTdHIuc3BsaXQoJy0nKTtcclxuICAgIHJldHVybiBgJHtwYXJ0c1syXX0vJHtwYXJ0c1sxXX0vJHtwYXJ0c1swXX1gO1xyXG4gIH07XHJcblxyXG4gIC8vIExvY2sgYmFja2dyb3VuZCBzY3JvbGwgd2hlbiBtb2RhbCBvcGVuc1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoc2hvd092ZXJ2aWV3TW9kYWwpIHtcclxuICAgICAgZG9jdW1lbnQuYm9keS5zdHlsZS5vdmVyZmxvdyA9IFwiaGlkZGVuXCI7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBkb2N1bWVudC5ib2R5LnN0eWxlLm92ZXJmbG93ID0gXCJ1bnNldFwiO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgZG9jdW1lbnQuYm9keS5zdHlsZS5vdmVyZmxvdyA9IFwidW5zZXRcIjtcclxuICAgIH07XHJcbiAgfSwgW3Nob3dPdmVydmlld01vZGFsXSk7XHJcblxyXG4gIGNvbnN0IGZvcm1hdEluZGlhbk51bWJlciA9IChudW0pID0+IHtcclxuICAgIHJldHVybiBudW0udG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKTtcclxuICB9O1xyXG5cclxuICAvLyAtLS0tLS0tLS0tIFNtYWxsIENhcmRzIERhdGEgKGV4aXN0aW5nIHBheW1lbnQgb3V0IGNhdGVnb3JpZXMpIC0tLS0tLS0tLS1cclxuICBjb25zdCBwYXltZW50T3V0TWVudUNhdGVnb3JpZXMgPSBbXHJcbiAgICB7XHJcbiAgICAgIGlkOiBcIiMxXCIsXHJcbiAgICAgIHRpdGxlOiBcIkNoaXQgUGF5b3V0XCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBjdXN0b21lciBjaGl0IHBheW1lbnQgb3V0IHRyYW5zYWN0aW9uIGluZm9ybWF0aW9uLlwiLFxyXG4gICAgICBpY29uOiBUaWNrZXRDaGVjayxcclxuICAgICAgZ3JhZGllbnQ6IFwiZnJvbS12aW9sZXQtNTAwIHZpYS1wdXJwbGUtNTAwIHRvLXBpbmstNTAwXCIsXHJcbiAgICAgIGJnR3JhZGllbnQ6IFwiZnJvbS12aW9sZXQtNTAgdmlhLXB1cnBsZS01MCB0by1waW5rLTUwXCIsXHJcbiAgICAgIGhyZWY6IFwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9jaGl0XCIsXHJcbiAgICAgIHN0YXRzOiBcIkNoaXQgUGF5bWVudCBPdXQgSW5mb1wiLFxyXG4gICAgICBzZWNvbmRhcnlJY29uOiBFeWUsXHJcbiAgICAgIGljb25Db2xvcjogXCJ0ZXh0LXZpb2xldC02MDBcIixcclxuICAgICAgYmdDb2xvcjogXCJiZy12aW9sZXQtMTAwXCIsXHJcbiAgICAgIHNlY3Rpb246IFwicGF5bWVudFwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6IFwiIzNcIixcclxuICAgICAgdGl0bGU6IFwiRW1wbG95ZWUgU2FsYXJ5XCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBFbXBsb3llZSBzYWxhcnkgaW5mb3JtYXRpb24uXCIsXHJcbiAgICAgIGljb246IEJyaWVmY2FzZSxcclxuICAgICAgZ3JhZGllbnQ6IFwiZnJvbS1wdXJwbGUtNTAwIHZpYS1pbmRpZ28tNTAwIHRvLXZpb2xldC01MDBcIixcclxuICAgICAgYmdHcmFkaWVudDogXCJmcm9tLXB1cnBsZS01MCB2aWEtaW5kaWdvLTUwIHRvLXZpb2xldC01MFwiLFxyXG4gICAgICBocmVmOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktb3V0LW1lbnUvc2FsYXJ5LXBheW1lbnRcIixcclxuICAgICAgc3RhdHM6IFwiRW1wbG95ZWUgU2FsYXJ5IE91dCBJbmZvXCIsXHJcbiAgICAgIHNlY29uZGFyeUljb246IEV5ZSxcclxuICAgICAgaWNvbkNvbG9yOiBcInRleHQtcHVycGxlLTYwMFwiLFxyXG4gICAgICBiZ0NvbG9yOiBcImJnLXB1cnBsZS0xMDBcIixcclxuICAgICAgc2VjdGlvbjogXCJlbXBsb3llZVwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6IFwiIzRcIixcclxuICAgICAgdGl0bGU6IFwiRW1wbG95ZWUgU2FsYXJ5IEluY2VudGl2ZVwiLFxyXG4gICAgICBkZXNjcmlwdGlvbjogXCJNYW5hZ2UgRW1wbG95ZWUgSW5jZW50aXZlIHBheW1lbnQgb3V0IHRyYW5zYWN0aW9uIGluZm9ybWF0aW9uLlwiLFxyXG4gICAgICBpY29uOiBIaUN1cnJlbmN5UnVwZWUsXHJcbiAgICAgIGdyYWRpZW50OiBcImZyb20tYmx1ZS01MDAgdmlhLWluZGlnby01MDAgdG8tYmx1ZS03MDBcIixcclxuICAgICAgYmdHcmFkaWVudDogXCJmcm9tLWJsdWUtNTAgdmlhLWluZGlnby01MCB0by1ibHVlLTEwMFwiLFxyXG4gICAgICBocmVmOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktb3V0LW1lbnUvc2FsYXJ5LWluY2VudGl2ZVwiLFxyXG4gICAgICBzdGF0czogXCJJbmNlbnRpdmUgSW5mb3JtYXRpb25cIixcclxuICAgICAgc2Vjb25kYXJ5SWNvbjogRXllLFxyXG4gICAgICBpY29uQ29sb3I6IFwidGV4dC1ibHVlLTYwMFwiLFxyXG4gICAgICBiZ0NvbG9yOiBcImJnLWJsdWUtMTAwXCIsXHJcbiAgICAgIHNlY3Rpb246IFwiZW1wbG95ZWVcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiBcIiM1XCIsXHJcbiAgICAgIHRpdGxlOiBcIkVtcGxveWVlIEFkZGl0aW9uYWwgU2FsYXJ5XCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBFbXBsb3llZSBJbmNlbnRpdmUgcGF5bWVudCBvdXQgdHJhbnNhY3Rpb24gaW5mb3JtYXRpb24uXCIsXHJcbiAgICAgIGljb246IEhpQ3VycmVuY3lSdXBlZSxcclxuICAgICAgZ3JhZGllbnQ6IFwiZnJvbS1ibHVlLTUwMCB2aWEtaW5kaWdvLTUwMCB0by1ibHVlLTcwMFwiLFxyXG4gICAgICBiZ0dyYWRpZW50OiBcImZyb20tYmx1ZS01MCB2aWEtaW5kaWdvLTUwIHRvLWJsdWUtMTAwXCIsXHJcbiAgICAgIGhyZWY6IFwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9hZGRpdGlvbmFsLXNhbGFyeVwiLFxyXG4gICAgICBzdGF0czogXCJJbmNlbnRpdmUgSW5mb3JtYXRpb25cIixcclxuICAgICAgc2Vjb25kYXJ5SWNvbjogRXllLFxyXG4gICAgICBpY29uQ29sb3I6IFwidGV4dC1ibHVlLTYwMFwiLFxyXG4gICAgICBiZ0NvbG9yOiBcImJnLWJsdWUtMTAwXCIsXHJcbiAgICAgIHNlY3Rpb246IFwiZW1wbG95ZWVcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiBcIiM3XCIsXHJcbiAgICAgIHRpdGxlOiBcIkVtcGxveWVlIEFkdmFuY2VzXCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBFbXBsb3llZSBhZHZhbmNlIHBheW1lbnQgaW5mb3JtYXRpb24uXCIsXHJcbiAgICAgIGljb246IFRiQ2FzaCxcclxuICAgICAgZ3JhZGllbnQ6IFwiZnJvbS10ZWFsLTUwMCB2aWEtZW1lcmFsZC01MDAgdG8tZ3JlZW4tNTAwXCIsXHJcbiAgICAgIGJnR3JhZGllbnQ6IFwiZnJvbS10ZWFsLTUwIHZpYS1lbWVyYWxkLTUwIHRvLWdyZWVuLTUwXCIsXHJcbiAgICAgIGhyZWY6IFwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9hZHZhbmNlLXBheW1lbnRcIixcclxuICAgICAgc3RhdHM6IFwiQWR2YW5jZSBQYXltZW50IEluZm9cIixcclxuICAgICAgc2Vjb25kYXJ5SWNvbjogRXllLFxyXG4gICAgICBpY29uQ29sb3I6IFwidGV4dC1lbWVyYWxkLTYwMFwiLFxyXG4gICAgICBiZ0NvbG9yOiBcImJnLWVtZXJhbGQtMTAwXCIsXHJcbiAgICAgIHNlY3Rpb246IFwiZW1wbG95ZWVcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiBcIiM4XCIsXHJcbiAgICAgIHRpdGxlOiBcIkxvYW4gUGF5b3V0XCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBMb2FuIFBheW1lbnQgT3V0LlwiLFxyXG4gICAgICBpY29uOiBHaVRha2VNeU1vbmV5LFxyXG4gICAgICBncmFkaWVudDogXCJmcm9tLWVtZXJhbGQtNTAwIHZpYS10ZWFsLTUwMCB0by1jeWFuLTUwMFwiLFxyXG4gICAgICBiZ0dyYWRpZW50OiBcImZyb20tZW1lcmFsZC01MCB2aWEtdGVhbC01MCB0by1jeWFuLTUwXCIsXHJcbiAgICAgIGhyZWY6IFwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9sb2FuLXBheW91dFwiLFxyXG4gICAgICBzdGF0czogXCJMb2FuIFBheW1lbnQgT3V0IEluZm9cIixcclxuICAgICAgc2Vjb25kYXJ5SWNvbjogRXllLFxyXG4gICAgICBpY29uQ29sb3I6IFwidGV4dC10ZWFsLTYwMFwiLFxyXG4gICAgICBiZ0NvbG9yOiBcImJnLXRlYWwtMTAwXCIsXHJcbiAgICAgIHNlY3Rpb246IFwicGF5bWVudFwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6IFwiIzlcIixcclxuICAgICAgdGl0bGU6IFwiUGlnbXkgUGF5b3V0XCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBQaWdteSBQYXltZW50IE91dC5cIixcclxuICAgICAgaWNvbjogRmFQaWdneUJhbmssXHJcbiAgICAgIGdyYWRpZW50OiBcImZyb20tYmx1ZS02MDAgdG8tYmx1ZS03MDBcIixcclxuICAgICAgYmdHcmFkaWVudDogXCJmcm9tLWJsdWUtNTAgdmlhLWJsdWUtMTAwIHRvLWJsdWUtMjAwXCIsXHJcbiAgICAgIGhyZWY6IFwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9waWdteS1wYXlvdXRcIixcclxuICAgICAgc3RhdHM6IFwiUGlnbXkgUGF5bWVudCBPdXRcIixcclxuICAgICAgc2Vjb25kYXJ5SWNvbjogRXllLFxyXG4gICAgICBpY29uQ29sb3I6IFwidGV4dC10ZWFsLTYwMFwiLFxyXG4gICAgICBiZ0NvbG9yOiBcImJnLXRlYWwtMTAwXCIsXHJcbiAgICAgIHNlY3Rpb246IFwicGF5bWVudFwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6IFwiIzEwXCIsXHJcbiAgICAgIHRpdGxlOiBcIkNoaXQgQ2FuY2VsbGF0aW9uIC8gQ2xvc3VyZSBQYXlvdXRcIixcclxuICAgICAgZGVzY3JpcHRpb246IFwiTWFuYWdlIGN1c3RvbWVyIGNoaXQgY2FuY2VsbGF0aW9uLCBjbG9zdXJlIHBheW1lbnRzLlwiLFxyXG4gICAgICBpY29uOiBGaVhDaXJjbGUsXHJcbiAgICAgIGdyYWRpZW50OiBcImZyb20tcmVkLTUwMCB2aWEtdmlvbGV0LTUwMCB0by1jeWFuLTUwMFwiLFxyXG4gICAgICBiZ0dyYWRpZW50OiBcImZyb20tcmVkLTUwIHZpYS12aW9sZXQtNTAgdG8tY3lhbi01MFwiLFxyXG4gICAgICBocmVmOiBcIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktb3V0LW1lbnUvY2hpdC1jYW5jZWxhdGlvbi1wYXktb3V0XCIsXHJcbiAgICAgIHN0YXRzOiBcIkNoaXQgQ2FuY2VsL0Nsb3NlIEluZm9cIixcclxuICAgICAgc2Vjb25kYXJ5SWNvbjogQ3JlZGl0Q2FyZCxcclxuICAgICAgaWNvbkNvbG9yOiBcInRleHQtcmVkLTYwMFwiLFxyXG4gICAgICBiZ0NvbG9yOiBcImJnLXJlZC0xMDBcIixcclxuICAgICAgc2VjdGlvbjogXCJwYXltZW50XCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpZDogXCIjMTFcIixcclxuICAgICAgdGl0bGU6IFwiT3RoZXJzXCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiBcIk1hbmFnZSBPdGhlcnMgaW5mb3JtYXRpb24uXCIsXHJcbiAgICAgIGljb246IE1vcmVIb3Jpem9udGFsLFxyXG4gICAgICBncmFkaWVudDogXCJmcm9tLWdyYXktNTAwIHZpYS1zbGF0ZS01MDAgdG8tZ3JheS01MDBcIixcclxuICAgICAgYmdHcmFkaWVudDogXCJmcm9tLWdyYXktNTAgdmlhLXNsYXRlLTUwIHRvLWdyYXktNTBcIixcclxuICAgICAgaHJlZjogXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LW91dC1tZW51L290aGVyc1wiLFxyXG4gICAgICBzdGF0czogXCJPdGhlciBQYXltZW50IE91dCBJbmZvXCIsXHJcbiAgICAgIHNlY29uZGFyeUljb246IEV5ZSxcclxuICAgICAgaWNvbkNvbG9yOiBcInRleHQtZ3JheS02MDBcIixcclxuICAgICAgYmdDb2xvcjogXCJiZy1ncmF5LTEwMFwiLFxyXG4gICAgICBzZWN0aW9uOiBcImVtcGxveWVlXCIsXHJcbiAgICB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IFNtYWxsQ2FyZCA9ICh7IGNhdGVnb3J5LCBvbkNsaWNrIH0pID0+IHtcclxuICAgIGNvbnN0IEljb24gPSBjYXRlZ29yeS5pY29uO1xyXG4gICAgY29uc3QgU2Vjb25kYXJ5SWNvbiA9IGNhdGVnb3J5LnNlY29uZGFyeUljb247XHJcbiAgICBjb25zdCBjb250ZW50ID0gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGgtZnVsbCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC0yeGwgYmctd2hpdGUvOTAgYmFja2Ryb3AtYmx1ci1zbSBib3JkZXIgYm9yZGVyLXdoaXRlLzMwIHNoYWRvdy1sZyBob3ZlcjpzaGFkb3cteGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIHRyYW5zZm9ybSBob3ZlcjotdHJhbnNsYXRlLXktMVwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCByb3VuZGVkLTJ4bCBiZy1ncmFkaWVudC10by1yIG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHkgZHVyYXRpb24tNTAwIHAtWzFweF1cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdy1mdWxsIGgtZnVsbCByb3VuZGVkLTJ4bCBiZy1ncmFkaWVudC10by1yICR7Y2F0ZWdvcnkuZ3JhZGllbnR9YH0+PC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBoLWZ1bGwgYmctd2hpdGUgcm91bmRlZC0yeGwgcC00XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGFic29sdXRlIHRvcC0yIHJpZ2h0LTIgdy0yMCBoLTIwIHJvdW5kZWQtZnVsbCBiZy1ncmFkaWVudC10by1iciAke2NhdGVnb3J5LmJnR3JhZGllbnR9IG9wYWNpdHktMjAgYmx1ci14bGB9PjwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBtYi0zXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcmVsYXRpdmUgdy0xMCBoLTEwIHJvdW5kZWQteGwgJHtjYXRlZ29yeS5iZ0NvbG9yfSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaGFkb3ctbWQgZ3JvdXAtaG92ZXI6c2NhbGUtMTA1IHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTMwMGB9PlxyXG4gICAgICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT17YHctNSBoLTUgJHtjYXRlZ29yeS5pY29uQ29sb3J9YH0gLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZC14bCBiZy1zbGF0ZS01MCBzaGFkb3ctc20gb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiPlxyXG4gICAgICAgICAgICAgIDxTZWNvbmRhcnlJY29uIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtc2xhdGUtNTAwXCIgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItM1wiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBtYi0xIGdyb3VwLWhvdmVyOnRleHQtcHVycGxlLTcwMCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0zMDBcIj5cclxuICAgICAgICAgICAgICB7Y2F0ZWdvcnkudGl0bGV9XHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgbGVhZGluZy1yZWxheGVkIGxpbmUtY2xhbXAtMlwiPlxyXG4gICAgICAgICAgICAgIHtjYXRlZ29yeS5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwdC0zIGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDBcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAge2NhdGVnb3J5LnN0YXRzfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1wdXJwbGUtNTAwIG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj5FeHBsb3JlPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgICBpZiAob25DbGljaykge1xyXG4gICAgICByZXR1cm4gPGRpdiBvbkNsaWNrPXtvbkNsaWNrfSBjbGFzc05hbWU9XCJncm91cCBjdXJzb3ItcG9pbnRlclwiPntjb250ZW50fTwvZGl2PjtcclxuICAgIH1cclxuICAgIHJldHVybiA8Um91dGVyTGluayB0bz17Y2F0ZWdvcnkuaHJlZn0gY2xhc3NOYW1lPVwiZ3JvdXAgYmxvY2tcIj57Y29udGVudH08L1JvdXRlckxpbms+O1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IG92ZXJ2aWV3Q2FyZCA9IHtcclxuICAgIGlkOiBcIm92ZXJ2aWV3XCIsXHJcbiAgICB0aXRsZTogXCJPdmVydmlld1wiLFxyXG4gICAgZGVzY3JpcHRpb246IFwiVmlldyBjb21wbGV0ZSBwYXltZW50IG91dCBzdW1tYXJ5IChTdXBlcmFkbWluIG9ubHkpXCIsXHJcbiAgICBpY29uOiBCYXJDaGFydDMsXHJcbiAgICBncmFkaWVudDogXCJmcm9tLWVtZXJhbGQtNTAwIHZpYS10ZWFsLTUwMCB0by1jeWFuLTUwMFwiLFxyXG4gICAgYmdHcmFkaWVudDogXCJmcm9tLWVtZXJhbGQtNTAgdmlhLXRlYWwtNTAgdG8tY3lhbi01MFwiLFxyXG4gICAgc3RhdHM6IFwiU3VwZXJhZG1pbiBQcm90ZWN0ZWRcIixcclxuICAgIHNlY29uZGFyeUljb246IEV5ZSxcclxuICAgIGljb25Db2xvcjogXCJ0ZXh0LWVtZXJhbGQtNjAwXCIsXHJcbiAgICBiZ0NvbG9yOiBcImJnLWVtZXJhbGQtMTAwXCIsXHJcbiAgfTtcclxuXHJcbiAgY29uc3QgcGF5bWVudENhdGVnb3JpZXMgPSBwYXltZW50T3V0TWVudUNhdGVnb3JpZXMuZmlsdGVyKFxyXG4gICAgKGl0ZW0pID0+IGl0ZW0uc2VjdGlvbiA9PT0gXCJwYXltZW50XCJcclxuICApO1xyXG5cclxuICBjb25zdCBlbXBsb3llZUNhdGVnb3JpZXMgPSBwYXltZW50T3V0TWVudUNhdGVnb3JpZXMuZmlsdGVyKFxyXG4gICAgKGl0ZW0pID0+IGl0ZW0uc2VjdGlvbiA9PT0gXCJlbXBsb3llZVwiXHJcbiAgKTtcclxuXHJcbiAgLy8gUGVuZGluZyBQYXltZW50IENhcmQgQ29tcG9uZW50XHJcbiAgY29uc3QgUGVuZGluZ0NhcmQgPSAoeyB0aXRsZSwgaWNvbjogSWNvbiwgZGF0YSwgYW1vdW50S2V5LCBiZ0NvbG9yLCBpY29uQ29sb3IsIGdyYWRpZW50IH0pID0+IHtcclxuICAgIGNvbnN0IHRvdGFsID0gZGF0YS5yZWR1Y2UoKHN1bSwgaXRlbSkgPT4gc3VtICsgcGFyc2VGbG9hdChpdGVtW2Ftb3VudEtleV0gfHwgMCksIDApO1xyXG4gICAgY29uc3QgY291bnQgPSBkYXRhLmxlbmd0aDtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17YGJnLWdyYWRpZW50LXRvLWJyICR7Z3JhZGllbnR9IHJvdW5kZWQteGwgcC00IGJvcmRlciBib3JkZXItd2hpdGUvMjAgc2hhZG93LWxnIGhvdmVyOnNoYWRvdy14bCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBgfT5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGlubGluZS1mbGV4IHAtMiByb3VuZGVkLWxnICR7YmdDb2xvcn0gYmctb3BhY2l0eS0yMCBtYi0yYH0+XHJcbiAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPXtgdy01IGgtNSAke2ljb25Db2xvcn1gfSAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlLzkwIG1iLTFcIj57dGl0bGV9PC9oND5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtd2hpdGVcIj7igrkge2Zvcm1hdEluZGlhbk51bWJlcih0b3RhbCl9PC9wPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtd2hpdGUvNzAgbXQtMVwiPntjb3VudH0gcGVuZGluZyB7Y291bnQgPT09IDEgPyAnaXRlbScgOiAnaXRlbXMnfTwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZS8yMCByb3VuZGVkLWZ1bGwgcHgtMiBweS0xIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICB7Y291bnR9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIC8vIFBlbmRpbmcgTGlzdCBJdGVtIENvbXBvbmVudFxyXG4gIGNvbnN0IFBlbmRpbmdMaXN0SXRlbSA9ICh7IGl0ZW0sIHR5cGUgfSkgPT4ge1xyXG4gICAgY29uc3QgZ2V0SWNvbiA9ICgpID0+IHtcclxuICAgICAgc3dpdGNoICh0eXBlKSB7XHJcbiAgICAgICAgY2FzZSAnY2hpdCc6XHJcbiAgICAgICAgICByZXR1cm4gPFRpY2tldENoZWNrIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC12aW9sZXQtNjAwXCIgLz47XHJcbiAgICAgICAgY2FzZSAnbG9hbic6XHJcbiAgICAgICAgICByZXR1cm4gPEdpVGFrZU15TW9uZXkgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNjAwXCIgLz47XHJcbiAgICAgICAgY2FzZSAnY2FuY2VsbGF0aW9uJzpcclxuICAgICAgICAgIHJldHVybiA8RmlYQ2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1yZWQtNjAwXCIgLz47XHJcbiAgICAgICAgY2FzZSAnc2FsYXJ5JzpcclxuICAgICAgICAgIHJldHVybiA8QnJpZWZjYXNlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1wdXJwbGUtNjAwXCIgLz47XHJcbiAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgIHJldHVybiA8V2FsbGV0IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ncmF5LTYwMFwiIC8+O1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGdldFN0YXR1c0JhZGdlID0gKHN0YXR1cykgPT4ge1xyXG4gICAgICBpZiAoc3RhdHVzID09PSAnUHJpemVkJykge1xyXG4gICAgICAgIHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LVsxMHB4XSBiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi03MDAgXCI+PENoZWNrQ2lyY2xlIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxyXG4gICAgICAgICAgUHJpemVkXHJcbiAgICAgICAgPC9zcGFuPjtcclxuICAgICAgfSBlbHNlIGlmIChzdGF0dXMgPT09ICdVbiBQcml6ZWQnKSB7XHJcbiAgICAgICAgcmV0dXJuIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQtWzEwcHhdIGJnLWFtYmVyLTEwMCB0ZXh0LWFtYmVyLTcwMFwiPjxDbG9jayBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz4gVW4gUHJpemVkPC9zcGFuPjtcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH07XHJcblxyXG4gICAgLy8gRm9yIHNhbGFyeSBpdGVtcywgZGlzcGxheSBlbXBsb3llZSBuYW1lIGFuZCBjb2RlXHJcbiAgICBpZiAodHlwZSA9PT0gJ3NhbGFyeScpIHtcclxuICAgICAgY29uc3QgZW1wbG95ZWUgPSBpdGVtLmVtcGxveWVlX2lkIHx8IHt9O1xyXG4gICAgICBjb25zdCBlbXBsb3llZU5hbWUgPSBlbXBsb3llZS5uYW1lIHx8ICdOL0EnO1xyXG4gICAgICBjb25zdCBlbXBsb3llZUNvZGUgPSBlbXBsb3llZS5lbXBsb3llZUNvZGUgfHwgJ04vQSc7XHJcbiAgICAgIGNvbnN0IGFtb3VudCA9IHBhcnNlRmxvYXQoaXRlbS5uZXRfcGF5YWJsZSB8fCBpdGVtLnJlbWFpbmluZ19iYWxhbmNlIHx8IDApO1xyXG4gICAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtMyBiZy13aGl0ZSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0xMDAgaG92ZXI6Ym9yZGVyLWdyYXktMjAwIHRyYW5zaXRpb24tYWxsIGhvdmVyOnNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBmbGV4LTEgbWluLXctMFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1ncmF5LTUwIHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgICAgICB7Z2V0SWNvbigpfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMCB0cnVuY2F0ZVwiPlxyXG4gICAgICAgICAgICAgICAge2VtcGxveWVlTmFtZX0gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwXCI+KHtlbXBsb3llZUNvZGV9KTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIHRleHQtZ3JheS01MDAgZmxleC13cmFwXCI+XHJcbiAgICAgICAgICAgICAgICA8c3Bhbj5TYWxhcnk6IHtpdGVtLnNhbGFyeV9tb250aH0ge2l0ZW0uc2FsYXJ5X3llYXJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAge2l0ZW0uc3RhdHVzICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYW1iZXItNjAwIHRleHQtWzEwcHhdIGZvbnQtbWVkaXVtXCI+e2l0ZW0uc3RhdHVzfTwvc3Bhbj59XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIGZsZXgtc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbWluLXctWzgwcHhdIHRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICDigrkge2Zvcm1hdEluZGlhbk51bWJlcihhbW91bnQpfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICBpZiAodHlwZSA9PT0gXCJjaGl0XCIpIHtcclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYm9yZGVyLXQgaG92ZXI6YmctZ3JheS01MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxyXG4gICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktM1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmctZ3JheS01MCByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgICB7Z2V0SWNvbigpfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgIHtpdGVtLmdyb3VwX25hbWUgfHxcclxuICAgICAgICAgICAgICAgICAgaXRlbS5ib3Jyb3dlcj8uZnVsbF9uYW1lIHx8XHJcbiAgICAgICAgICAgICAgICAgIGl0ZW0udXNlckRldGFpbHM/LmZ1bGxfbmFtZSB8fFxyXG4gICAgICAgICAgICAgICAgICBcIk4vQVwifVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTNcIj5cclxuICAgICAgICAgICAge2l0ZW0uZ3JvdXBfaWQ/Lmdyb3VwX3ZhbHVlXHJcbiAgICAgICAgICAgICAgPyBg4oK5JHtmb3JtYXRJbmRpYW5OdW1iZXIocGFyc2VGbG9hdChpdGVtLmdyb3VwX2lkPy5ncm91cF92YWx1ZSkpfWBcclxuICAgICAgICAgICAgICA6IFwiLVwifVxyXG4gICAgICAgICAgPC90ZD5cclxuXHJcbiAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zXCI+XHJcbiAgICAgICAgICAgIHtpdGVtLnVzZXJfaWQuZnVsbF9uYW1lIHx8XHJcbiAgICAgICAgICAgICAgKGl0ZW0uY3VzdG9tZXJfaWQgJiYgaXRlbS5jdXN0b21lcl9pZCAhPT0gXCJOL0FcIlxyXG4gICAgICAgICAgICAgICAgPyBpdGVtLnVzZXJfaWQuZnVsbF9uYW1lXHJcbiAgICAgICAgICAgICAgICA6IFwiLVwiKX1cclxuICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktM1wiPntpdGVtLmF1Y3Rpb25fY29kZSB8fCBcIi1cIn08L3RkPlxyXG5cclxuICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTNcIj57aXRlbS50aWNrZXQgfHwgXCItXCJ9PC90ZD5cclxuXHJcbiAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgIHtnZXRTdGF0dXNCYWRnZShpdGVtLnN0YXR1cyl9XHJcbiAgICAgICAgICAgICAge2l0ZW0uYXBwcm92YWxfc3RhdHVzID09PSBcIkFQUFJPVkVEXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDAgdGV4dC14cyBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICDinJMgQXBwcm92ZWRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LXJpZ2h0IGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICDigrl7XCIgXCJ9XHJcbiAgICAgICAgICAgIHtmb3JtYXRJbmRpYW5OdW1iZXIoXHJcbiAgICAgICAgICAgICAgcGFyc2VGbG9hdChcclxuICAgICAgICAgICAgICAgIGl0ZW0ud2luX2Ftb3VudCB8fFxyXG4gICAgICAgICAgICAgICAgTnVtYmVyKGl0ZW0/LmxvYW5fYW1vdW50IHx8IDApIC1cclxuICAgICAgICAgICAgICAgIE51bWJlcihpdGVtLnNlcnZpY2VfY2hhcmdlcyB8fCAwKSAtXHJcbiAgICAgICAgICAgICAgICBOdW1iZXIoaXRlbS5kb2N1bWVudF9jaGFyZ2VzIHx8IDApIHx8XHJcbiAgICAgICAgICAgICAgICBpdGVtLmJhbGFuY2UgfHxcclxuICAgICAgICAgICAgICAgIDBcclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L3RkPlxyXG4gICAgICAgIDwvdHI+XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gRGVmYXVsdCBmb3Igb3RoZXIgdHlwZXNcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtMyBiZy13aGl0ZSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0xMDAgaG92ZXI6Ym9yZGVyLWdyYXktMjAwIHRyYW5zaXRpb24tYWxsIGhvdmVyOnNoYWRvdy1tZFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgZmxleC0xIG1pbi13LTBcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLWdyYXktNTAgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICB7Z2V0SWNvbigpfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMCB0cnVuY2F0ZVwiPlxyXG4gICAgICAgICAgICAgIHtpdGVtLmdyb3VwX25hbWUgfHwgaXRlbS5ib3Jyb3dlcj8uZnVsbF9uYW1lIHx8IGl0ZW0udXNlckRldGFpbHM/LmZ1bGxfbmFtZSB8fCAnTi9BJ31cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgdGV4dC1ncmF5LTUwMCBmbGV4LXdyYXBcIj5cclxuICAgICAgICAgICAgICB7aXRlbS5ncm91cF92YWx1ZSAmJiA8c3Bhbj5Hcm91cDog4oK5e2Zvcm1hdEluZGlhbk51bWJlcihwYXJzZUZsb2F0KGl0ZW0uZ3JvdXBfdmFsdWUpKX08L3NwYW4+fVxyXG4gICAgICAgICAgICAgIHtpdGVtLmxvYW5faWQgJiYgPHNwYW4+TG9hbjoge2l0ZW0ubG9hbl9pZH08L3NwYW4+fVxyXG4gICAgICAgICAgICAgIHtpdGVtLnVzZXJEZXRhaWxzPy5jdXN0b21lcl9pZCAmJiA8c3Bhbj5DdXN0b21lcjoge2l0ZW0udXNlckRldGFpbHMuZnVsbF9uYW1lfTwvc3Bhbj59XHJcbiAgICAgICAgICAgICAge2l0ZW0uY3VzdG9tZXJfaWQgJiYgaXRlbS5jdXN0b21lcl9pZCAhPT0gJ04vQScgJiYgPHNwYW4+Q3VzdG9tZXI6IHtpdGVtLmZ1bGxfbmFtZX08L3NwYW4+fVxyXG4gICAgICAgICAgICAgIHtpdGVtLmF1Y3Rpb25fY29kZSAmJiA8c3Bhbj5BdWN0aW9uOiB7aXRlbS5hdWN0aW9uX2NvZGV9PC9zcGFuPn1cclxuICAgICAgICAgICAgICB7aXRlbS5hdWN0aW9uX2NvZGUgJiYgPHNwYW4+VGlja2V0OiB7aXRlbS50aWNrZXR9PC9zcGFuPn1cclxuICAgICAgICAgICAgICB7aXRlbS5hcHByb3ZhbF9zdGF0dXMgPT09ICdBUFBST1ZFRCcgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDAgdGV4dC1bMTBweF0gZm9udC1tZWRpdW1cIj7inJMgQXBwcm92ZWQ8L3NwYW4+fVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgZmxleC1zaHJpbmstMFwiPlxyXG4gICAgICAgICAge2dldFN0YXR1c0JhZGdlKGl0ZW0uc3RhdHVzKX1cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG1pbi13LVs4MHB4XSB0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgIOKCuSB7Zm9ybWF0SW5kaWFuTnVtYmVyKHBhcnNlRmxvYXQoaXRlbS53aW5fYW1vdW50IHx8IE51bWJlcihpdGVtPy5sb2FuX2Ftb3VudCB8fCAwKSAtIE51bWJlcihpdGVtLnNlcnZpY2VfY2hhcmdlcyB8fCAwKSAtIE51bWJlcihpdGVtLmRvY3VtZW50X2NoYXJnZXMgfHwgMCkgfHwgaXRlbS5iYWxhbmNlIHx8IDApKX1cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLXNjcmVlbiB3LWZ1bGwgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSByZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgPE5hdmJhciB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgcmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIC1pbnNldC0xIGJnLWdyYWRpZW50LXRvLXIgZnJvbS12aW9sZXQtNjAwIHRvLXB1cnBsZS02MDAgcm91bmRlZC14bCBibHVyLW1kIG9wYWNpdHktNzUgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbiBkdXJhdGlvbi01MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LTEyIGgtMTIgcm91bmRlZC14bCBiZy1ncmFkaWVudC10by1iciBmcm9tLXZpb2xldC01MDAgdG8tcHVycGxlLTYwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaGFkb3ctbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICA8QmFua25vdGUgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LXdoaXRlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgYmctZ3JhZGllbnQtdG8tciBmcm9tLXNsYXRlLTgwMCB2aWEtcHVycGxlLTgwMCB0by1zbGF0ZS04MDAgYmctY2xpcC10ZXh0IHRleHQtdHJhbnNwYXJlbnRcIj5cclxuICAgICAgICAgICAgICAgICAgICBQYXltZW50LU91dCBNYW5hZ2VtZW50XHJcbiAgICAgICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIHRleHQtc20gbXQtMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgTWFuYWdlIGFuZCB2aWV3IHBheW1lbnQtb3V0IGluZm9ybWF0aW9uIGFuZCB0cmFuc2FjdGlvbnNcclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0xMlwiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBtYi02IGJvcmRlci1iIHBiLTNcIj5cclxuICAgICAgICAgICAgICAgIFBheW1lbnQgU2VjdGlvblxyXG4gICAgICAgICAgICAgIDwvaDM+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtNCBsZzpncmlkLWNvbHMtNSBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAge3BheW1lbnRDYXRlZ29yaWVzLm1hcCgoY2F0ZWdvcnkpID0+IChcclxuICAgICAgICAgICAgICAgICAgPFNtYWxsQ2FyZCBrZXk9e2NhdGVnb3J5LmlkfSBjYXRlZ29yeT17Y2F0ZWdvcnl9IC8+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDxTbWFsbENhcmQgY2F0ZWdvcnk9e292ZXJ2aWV3Q2FyZH0gb25DbGljaz17aGFuZGxlT3ZlcnZpZXdDbGlja30gLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTEyXCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIG1iLTYgYm9yZGVyLWIgcGItM1wiPlxyXG4gICAgICAgICAgICAgICAgRW1wbG95ZWUgU2VjdGlvblxyXG4gICAgICAgICAgICAgIDwvaDM+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtNCBsZzpncmlkLWNvbHMtNSBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAge2VtcGxveWVlQ2F0ZWdvcmllcy5tYXAoKGNhdGVnb3J5KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxTbWFsbENhcmQga2V5PXtjYXRlZ29yeS5pZH0gY2F0ZWdvcnk9e2NhdGVnb3J5fSAvPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBwLTUgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS12aW9sZXQtNTAgdmlhLXB1cnBsZS01MCB0by1waW5rLTUwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItd2hpdGUvNDAgc2hhZG93LW1kIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCB3LTMyIGgtMzIgYmctZ3JhZGllbnQtdG8tYmwgZnJvbS12aW9sZXQtMjAwLzIwIHRvLXRyYW5zcGFyZW50IHJvdW5kZWQtZnVsbCBibHVyLTJ4bFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTAgbGVmdC0wIHctMzIgaC0zMiBiZy1ncmFkaWVudC10by10ciBmcm9tLXB1cnBsZS0yMDAvMjAgdG8tdHJhbnNwYXJlbnQgcm91bmRlZC1mdWxsIGJsdXItMnhsXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLWluc2V0LTEgYmctZ3JhZGllbnQtdG8tciBmcm9tLXZpb2xldC00MDAgdG8tcHVycGxlLTQwMCByb3VuZGVkLXhsIGJsdXItbWQgb3BhY2l0eS01MFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctMTAgaC0xMCByb3VuZGVkLXhsIGJnLXdoaXRlIHNoYWRvdy1tZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXZpb2xldC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFF1aWNrIFRpcHNcclxuICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDAgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICBVc2UgQ2hpdCwgSW5jZW50aXZlLCBTYWxhcnksIEFkdmFuY2VzLCBMb2FuLCBhbmQgT3RoZXJzIGRpcmVjdG9yaWVzIHRvIG1hbmFnZSBwYXltZW50LW91dCB0cmFuc2FjdGlvbnMuXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDAgdGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWQgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIPCfk4ogPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj5PdmVydmlldyBjYXJkPC9zcGFuPiBpcyBwcm90ZWN0ZWQg4oCUIG9ubHkgU3VwZXJhZG1pbiBjYW4gdmlldyByZWFsIHRvdGFscyAoZmV0Y2hlZCBmcm9tIGxpdmUgQVBJKS5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIE92ZXJ2aWV3IE1vZGFsIHdpdGggQVBJIERhdGEgYW5kIEZpbHRlcnMgKi99XHJcbiAgICAgIHtzaG93T3ZlcnZpZXdNb2RhbCAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGJnLWJsYWNrLzUwIGJhY2tkcm9wLWJsdXItc21cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgYmctd2hpdGUgcm91bmRlZC0yeGwgdy1mdWxsIG1heC13LTR4bCBtYXgtaC1bOTB2aF0gb3ZlcmZsb3cteS1hdXRvIHNoYWRvdy0yeGxcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGlja3kgdG9wLTAgYmctd2hpdGUgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIHB4LTYgcHktNCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gei0xMFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLWVtZXJhbGQtMTAwIHJvdW5kZWQteGxcIj5cclxuICAgICAgICAgICAgICAgICAgPEJhckNoYXJ0MyBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZW1lcmFsZC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDBcIj5QYXltZW50IE91dCBPdmVydmlldzwvaDI+XHJcbiAgICAgICAgICAgICAgICB7aXNTdXBlckFkbWluICYmICFpc0F1dGhlbnRpY2F0ZWRGb3JPdmVydmlldyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgdGV4dC14cyBiZy1hbWJlci0xMDAgdGV4dC1hbWJlci03MDAgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsXCI+U3VwZXJhZG1pbiByZXF1aXJlZDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtjbG9zZU1vZGFsfSBjbGFzc05hbWU9XCJwLTEuNSByb3VuZGVkLWxnIGhvdmVyOmJnLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtc2xhdGUtNTAwXCIgLz5cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNlwiPlxyXG4gICAgICAgICAgICAgIHshaXNBdXRoZW50aWNhdGVkRm9yT3ZlcnZpZXcgPyAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNVwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHAtNCBiZy1hbWJlci01MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYW1iZXItMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPExvY2sgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWFtYmVyLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWFtYmVyLTgwMFwiPlRoaXMgc2VjdGlvbiBjb250YWlucyBzZW5zaXRpdmUgcGF5bWVudCBzdGF0aXN0aWNzLiBPbmx5IFN1cGVyYWRtaW4gY2FuIGFjY2Vzcy48L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMCBtYi0yXCI+RW50ZXIgU3VwZXJhZG1pbiBQYXNzd29yZDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT17c2hvd1Bhc3N3b3JkID8gXCJ0ZXh0XCIgOiBcInBhc3N3b3JkXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uS2V5RG93bj17KGUpID0+IGUua2V5ID09PSBcIkVudGVyXCIgJiYgdmVyaWZ5UGFzc3dvcmRBbmRTaG93RGF0YSgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTQgcHktMi41IGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC14bCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1lbWVyYWxkLTUwMCBmb2N1czpib3JkZXItZW1lcmFsZC01MDAgb3V0bGluZS1ub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi4oCi4oCi4oCi4oCi4oCi4oCi4oCi4oCiXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGF1dG9Gb2N1c1xyXG4gICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dQYXNzd29yZCghc2hvd1Bhc3N3b3JkKX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTMgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtZW1lcmFsZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtzaG93UGFzc3dvcmQgPyA8RmFFeWVTbGFzaCAvPiA6IDxGYUV5ZSAvPn1cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICB7cGFzc3dvcmRFcnJvciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gdGV4dC1yZWQtNjAwIGJnLXJlZC01MCBwLTIgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8QWxlcnRDaXJjbGUgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntwYXNzd29yZEVycm9yfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17dmVyaWZ5UGFzc3dvcmRBbmRTaG93RGF0YX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yLjUgYmctZ3JhZGllbnQtdG8tciBmcm9tLWVtZXJhbGQtNjAwIHRvLXRlYWwtNjAwIHRleHQtd2hpdGUgZm9udC1zZW1pYm9sZCByb3VuZGVkLXhsIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgVW5sb2NrIE92ZXJ2aWV3XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgdGV4dC1jZW50ZXIgbXQtMlwiPkRlbW8gcGFzc3dvcmQ6IDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ub1wiPjEyMzQ1PC9zcGFuPjwvcD4gKi99XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiA9PT09PSBQRU5ESU5HIFBBWU1FTlQgT1VUUyBTRUNUSU9OID09PT09ICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1hbWJlci0xMDAgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtYW1iZXItNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMFwiPlBlbmRpbmcgUGF5bWVudCBPdXRzPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBiZy1hbWJlci0xMDAgdGV4dC1hbWJlci03MDAgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsXCI+QXdhaXRpbmcgUHJvY2Vzc2luZzwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3BlbmRpbmdEYXRhLmxvYWRpbmcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZW1lcmFsZC02MDAgYW5pbWF0ZS1zcGluXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+ICovfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7cGVuZGluZ0RhdGEuZXJyb3IgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMCB0ZXh0LWNlbnRlciBweS00IGJnLXJlZC01MCByb3VuZGVkLXhsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEVycm9yIGxvYWRpbmcgcGVuZGluZyBkYXRhOiB7cGVuZGluZ0RhdGEuZXJyb3J9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApIDogcGVuZGluZ0RhdGEubG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBweS0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiByb3VuZGVkLWZ1bGwgaC04IHctOCBib3JkZXItYi0yIGJvcmRlci1lbWVyYWxkLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBQZW5kaW5nIFN1bW1hcnkgQ2FyZHMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBDaGl0IFBheW91dHMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0xMDAgcC00IGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uXCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmctdmlvbGV0LTUwIHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUaWNrZXRDaGVjayBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtdmlvbGV0LTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDaGl0IFBheW91dHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BlbmRpbmdEYXRhLmNoaXRQYXlvdXRzLmxlbmd0aH0gcGVuZGluZ3tcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BlbmRpbmdEYXRhLmNoaXRQYXlvdXRzLmxlbmd0aCA9PT0gMSA/IFwiaXRlbVwiIDogXCJpdGVtc1wifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0SW5kaWFuTnVtYmVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZW5kaW5nRGF0YS5jaGl0UGF5b3V0cy5yZWR1Y2UoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKHN1bSwgaXRlbSkgPT4gc3VtICsgcGFyc2VGbG9hdChpdGVtLndpbl9hbW91bnQgfHwgMCksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlU2VjdGlvbihcImNoaXRcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCIgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQtbGcgYmctdmlvbGV0LTUwIHRleHQtdmlvbGV0LTYwMCBob3ZlcjpiZy12aW9sZXQtMTAwIHRyYW5zaXRpb24gXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXhwYW5kZWRTZWN0aW9ucy5jaGl0ID8gXCJIaWRlIERldGFpbHNcIiA6IFwiVmlldyBEZXRhaWxzXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2V4cGFuZGVkU2VjdGlvbnMuY2hpdCAmJiBwZW5kaW5nRGF0YS5jaGl0UGF5b3V0cy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHB0LTMgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIG1heC1oLVsyMDBweF0gb3ZlcmZsb3cteS1hdXRvIHByLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0byByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdFwiPk5hbWU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWxlZnRcIj5Hcm91cCBWYWx1ZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdFwiPkN1c3RvbWVyPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1sZWZ0XCI+QXVjdGlvbjwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdFwiPlRpY2tldDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdFwiPlN0YXR1czwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtcmlnaHRcIj5BbW91bnQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGVuZGluZ0RhdGEuY2hpdFBheW91dHMubWFwKChpdGVtLCBpZHgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQZW5kaW5nTGlzdEl0ZW0ga2V5PXtpZHh9IGl0ZW09e2l0ZW19IHR5cGU9XCJjaGl0XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIExvYW4gUGF5b3V0cyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBwLTQgaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb25cIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1lbWVyYWxkLTUwIHJvdW5kZWQtbGdcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxHaVRha2VNeU1vbmV5IGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1lbWVyYWxkLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBMb2FuIFBheW91dHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BlbmRpbmdEYXRhLmxvYW5QYXlvdXRzLmxlbmd0aH0gcGVuZGluZ3tcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BlbmRpbmdEYXRhLmxvYW5QYXlvdXRzLmxlbmd0aCA9PT0gMSA/IFwiaXRlbVwiIDogXCJpdGVtc1wifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0SW5kaWFuTnVtYmVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZW5kaW5nRGF0YS5sb2FuUGF5b3V0cy5yZWR1Y2UoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKHN1bSwgaXRlbSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1bSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOdW1iZXIoaXRlbT8ubG9hbl9hbW91bnQgfHwgMCkgLVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTnVtYmVyKGl0ZW0/LnNlcnZpY2VfY2hhcmdlcyB8fCAwKSAtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOdW1iZXIoaXRlbT8uZG9jdW1lbnRfY2hhcmdlcyB8fCAwKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlU2VjdGlvbihcImxvYW5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCIgcHgtMyBweS0xLjUgdGV4dC14cyAgZm9udC1zZW1pYm9sZCByb3VuZGVkLWxnICBiZy1lbWVyYWxkLTUwIHRleHQtZW1lcmFsZC02MDAgaG92ZXI6YmctZW1lcmFsZC0xMDAgdHJhbnNpdGlvbiAgXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXhwYW5kZWRTZWN0aW9ucy5sb2FuID8gXCJIaWRlIERldGFpbHNcIiA6IFwiVmlldyBEZXRhaWxzXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtleHBhbmRlZFNlY3Rpb25zLmxvYW4gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIiAgbXQtNCAgcHQtMyBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgc3BhY2UteS0yICBtYXgtaC1bMjAwcHhdICBvdmVyZmxvdy15LWF1dG8gcHItMiBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGVuZGluZ0RhdGEubG9hblBheW91dHMubWFwKChpdGVtLCBpZHgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQZW5kaW5nTGlzdEl0ZW1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpZHh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW09e2l0ZW19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJsb2FuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBDaGl0IENhbmNlbGxhdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBwLTQgaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb25cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLXJlZC01MCByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlYQ2lyY2xlIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1yZWQtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENoaXQgQ2FuY2VsbGF0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwZW5kaW5nRGF0YS5jaGl0Q2FuY2VsbGF0aW9ucy5sZW5ndGh9IHBlbmRpbmd7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwZW5kaW5nRGF0YS5jaGl0Q2FuY2VsbGF0aW9ucy5sZW5ndGggPT09IDEgPyBcIml0ZW1cIiA6IFwiaXRlbXNcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0SW5kaWFuTnVtYmVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZW5kaW5nRGF0YS5jaGl0Q2FuY2VsbGF0aW9ucy5yZWR1Y2UoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKHN1bSwgaXRlbSkgPT4gc3VtICsgcGFyc2VGbG9hdChpdGVtLmJhbGFuY2UgfHwgMCksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB0b2dnbGVTZWN0aW9uKFwiY2FuY2VsbGF0aW9uXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIHB4LTMgcHktMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCByb3VuZGVkLWxnIGJnLXJlZC01MCAgdGV4dC1yZWQtNjAwIGhvdmVyOmJnLXJlZC0xMDAgdHJhbnNpdGlvbiBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtleHBhbmRlZFNlY3Rpb25zLmNhbmNlbGxhdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiSGlkZSBEZXRhaWxzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlZpZXcgRGV0YWlsc1wifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2V4cGFuZGVkU2VjdGlvbnMuY2FuY2VsbGF0aW9uICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCIgbXQtNCBwdC0zIGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBzcGFjZS15LTIgbWF4LWgtWzIwMHB4XSBvdmVyZmxvdy15LWF1dG8gcHItMiBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGVuZGluZ0RhdGEuY2hpdENhbmNlbGxhdGlvbnMubWFwKChpdGVtLCBpZHgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQZW5kaW5nTGlzdEl0ZW1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpZHh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW09e2l0ZW19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjYW5jZWxsYXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFNhbGFyeSBQZW5kaW5nICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMTAwIHAtNCBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvblwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1wdXJwbGUtNTAgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJyaWVmY2FzZSBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtcHVycGxlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTYWxhcnkgUGVuZGluZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGVuZGluZ0RhdGEuc2FsYXJ5UGVuZGluZy5sZW5ndGh9IHBlbmRpbmd7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwZW5kaW5nRGF0YS5zYWxhcnlQZW5kaW5nLmxlbmd0aCA9PT0gMSA/IFwiaXRlbVwiIDogXCJpdGVtc1wifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0SW5kaWFuTnVtYmVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZW5kaW5nRGF0YS5zYWxhcnlQZW5kaW5nLnJlZHVjZShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoc3VtLCBpdGVtKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3VtICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlRmxvYXQoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ubmV0X3BheWFibGUgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5yZW1haW5pbmdfYmFsYW5jZSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcblxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB0b2dnbGVTZWN0aW9uKFwic2FsYXJ5XCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQtbGcgYmctcHVycGxlLTUwIHRleHQtcHVycGxlLTYwMCBob3ZlcjpiZy1wdXJwbGUtMTAwdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2V4cGFuZGVkU2VjdGlvbnMuc2FsYXJ5ID8gXCJIaWRlIERldGFpbHNcIiA6IFwiVmlldyBEZXRhaWxzXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2V4cGFuZGVkU2VjdGlvbnMuc2FsYXJ5ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHB0LTMgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIHNwYWNlLXktMiBtYXgtaC1bMjAwcHhdIG92ZXJmbG93LXktYXV0byBwci0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BlbmRpbmdEYXRhLnNhbGFyeVBlbmRpbmcubWFwKChpdGVtLCBpZHgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQZW5kaW5nTGlzdEl0ZW1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpZHh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW09e2l0ZW19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzYWxhcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEFkZGl0aW9uYWwgU2FsYXJ5IFBlbmRpbmcgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMTAwIHAtNCBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1pbi13LTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmctb3JhbmdlLTUwIHJvdW5kZWQtbGcgZmxleC1zaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCcmllZmNhc2UgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LW9yYW5nZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBZGRpdGlvbmFsIFNhbGFyeVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGVuZGluZ0RhdGEuYWRkaXRpb25hbFNhbGFyeVBlbmRpbmcubGVuZ3RofSBwZW5kaW5ne1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BlbmRpbmdEYXRhLmFkZGl0aW9uYWxTYWxhcnlQZW5kaW5nLmxlbmd0aCA9PT0gMVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiaXRlbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJpdGVtc1wifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IGZsZXgtc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0SW5kaWFuTnVtYmVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGVuZGluZ0RhdGEuYWRkaXRpb25hbFNhbGFyeVBlbmRpbmcucmVkdWNlKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoc3VtLCBpdGVtKSA9PiBzdW0gKyBOdW1iZXIoaXRlbT8ucGF5YWJsZV9hbW91bnQgfHwgMCksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlU2VjdGlvbihcImFkZGl0aW9uYWxTYWxhcnlcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQtbGcgYmctb3JhbmdlLTUwIHRleHQtb3JhbmdlLTYwMCBob3ZlcjpiZy1vcmFuZ2UtMTAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2V4cGFuZGVkU2VjdGlvbnMuYWRkaXRpb25hbFNhbGFyeVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIkhpZGUgRGV0YWlsc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiVmlldyBEZXRhaWxzXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtleHBhbmRlZFNlY3Rpb25zLmFkZGl0aW9uYWxTYWxhcnkgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlbmRpbmdEYXRhLmFkZGl0aW9uYWxTYWxhcnlQZW5kaW5nLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcHQtMyBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgbWF4LWgtWzIwMHB4XSBvdmVyZmxvdy15LWF1dG8gcHItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBiZy13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1sZWZ0XCI+RW1wbG95ZWU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWxlZnRcIj5FbXBsb3llZSBDb2RlPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1sZWZ0XCI+TW9udGg8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWxlZnRcIj5EZXRhaWxzPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1sZWZ0XCI+U3RhdHVzPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1yaWdodFwiPkFtb3VudDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGVuZGluZ0RhdGEuYWRkaXRpb25hbFNhbGFyeVBlbmRpbmcubWFwKChpdGVtLCBpZHgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2l0ZW0/Ll9pZCB8fCBpZHh9IGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zIGZvbnQtbWVkaXVtIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbT8uZW1wbG95ZWVfaWQ/Lm5hbWUgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbT8uZW1wbG95ZWVfaWQ/LmVtcGxveWVlQ29kZSB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtPy5zYWxhcnlfbW9udGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gYCR7aXRlbS5zYWxhcnlfbW9udGh9ICR7aXRlbT8uc2FsYXJ5X3llYXIgfHwgXCJcIn1gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0/LmRldGFpbHMgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0xIHJvdW5kZWQtZnVsbCB0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkIGJnLWFtYmVyLTUwIHRleHQtYW1iZXItNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbT8uc3RhdHVzIHx8IFwiUGVuZGluZ1wifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1yaWdodCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtmb3JtYXRJbmRpYW5OdW1iZXIoaXRlbT8ucGF5YWJsZV9hbW91bnQgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBFbXBsb3llZSBJbmNlbnRpdmUgUGVuZGluZyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0xMDAgcC00IGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWluLXctMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1jeWFuLTUwIHJvdW5kZWQtbGcgZmxleC1zaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUcmVuZGluZ1VwIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1jeWFuLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVtcGxveWVlIEluY2VudGl2ZXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BlbmRpbmdEYXRhLmVtcGxveWVlSW5jZW50aXZlUGVuZGluZz8ubGVuZ3RofSBwZW5kaW5ne1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BlbmRpbmdEYXRhLmVtcGxveWVlSW5jZW50aXZlUGVuZGluZy5sZW5ndGggPT09IDFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIml0ZW1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiaXRlbXNcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBmbGV4LXNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEluZGlhbk51bWJlcihcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlbmRpbmdEYXRhLmVtcGxveWVlSW5jZW50aXZlUGVuZGluZy5yZWR1Y2UoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChzdW0sIGl0ZW0pID0+IHN1bSArIE51bWJlcihpdGVtPy5hbW91bnQgfHwgMCksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlU2VjdGlvbihcImVtcGxveWVlSW5jZW50aXZlXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCByb3VuZGVkLWxnIGJnLWN5YW4tNTAgdGV4dC1jeWFuLTYwMCBob3ZlcjpiZy1jeWFuLTEwMCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtleHBhbmRlZFNlY3Rpb25zLmVtcGxveWVlSW5jZW50aXZlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiSGlkZSBEZXRhaWxzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJWaWV3IERldGFpbHNcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2V4cGFuZGVkU2VjdGlvbnMuZW1wbG95ZWVJbmNlbnRpdmUgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlbmRpbmdEYXRhLmVtcGxveWVlSW5jZW50aXZlUGVuZGluZy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHB0LTMgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIG1heC1oLVsyMDBweF0gb3ZlcmZsb3cteS1hdXRvIHByLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0byByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdFwiPkVtcGxveWVlPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1sZWZ0XCI+RW1wbG95ZWUgQ29kZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdFwiPkluY2VudGl2ZSBUeXBlPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1sZWZ0XCI+TW9udGg8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWxlZnRcIj5QYXkgVHlwZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdFwiPlN0YXR1czwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtcmlnaHRcIj5BbW91bnQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BlbmRpbmdEYXRhLmVtcGxveWVlSW5jZW50aXZlUGVuZGluZy5tYXAoKGl0ZW0sIGlkeCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17aXRlbT8uX2lkIHx8IGlkeH0gY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtPy5lbXBsb3llZV9pZD8ubmFtZSB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtPy5lbXBsb3llZV9pZD8uZW1wbG95ZWVDb2RlIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0/LmluY2VudGl2ZV90eXBlIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0/Lm1vbnRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGAke2l0ZW0ubW9udGh9ICR7aXRlbT8ueWVhciB8fCBcIlwifWBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtZ3JheS01MDAgY2FwaXRhbGl6ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtPy5wYXlfdHlwZSB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTEgcm91bmRlZC1mdWxsIHRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgYmctYW1iZXItNTAgdGV4dC1hbWJlci02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtPy5zdGF0dXMgfHwgXCJQZW5kaW5nXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LXJpZ2h0IGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2Zvcm1hdEluZGlhbk51bWJlcihpdGVtPy5hbW91bnQgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBUb3RhbCBQZW5kaW5nIEFtb3VudCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcC00IGJnLXdoaXRlIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1hbWJlci0yMDAgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmctYW1iZXItNTAgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VHJlbmRpbmdVcCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtYW1iZXItNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+VG90YWwgUGF5bWVudCBPdXQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPkF3YWl0aW5nIHByb2Nlc3Npbmc8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrkge2Zvcm1hdEluZGlhbk51bWJlcihwZW5kaW5nRGF0YS50b3RhbFBlbmRpbmcpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogRGV0YWlsZWQgTGlzdHMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIENoaXQgUGF5b3V0cyBMaXN0ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiB7cGVuZGluZ0RhdGEuY2hpdFBheW91dHMubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGlja2V0Q2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXZpb2xldC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5DaGl0IFBheW91dHM8L2g0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTQwMFwiPih7cGVuZGluZ0RhdGEuY2hpdFBheW91dHMubGVuZ3RofSk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlU2VjdGlvbihcImNoaXRcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC1hdXRvIHRleHQtZ3JheS02MDAgaG92ZXI6dGV4dC12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXhwYW5kZWRTZWN0aW9ucy5jaGl0ID8gPEZpQ2hldnJvblVwIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPiA6IDxGaUNoZXZyb25Eb3duIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtleHBhbmRlZFNlY3Rpb25zLmNoaXQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIG1heC1oLVsyMDBweF0gb3ZlcmZsb3cteS1hdXRvIHByLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwZW5kaW5nRGF0YS5jaGl0UGF5b3V0cy5tYXAoKGl0ZW0sIGlkeCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UGVuZGluZ0xpc3RJdGVtIGtleT17aWR4fSBpdGVtPXtpdGVtfSB0eXBlPVwiY2hpdFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9ICovfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTG9hbiBQYXlvdXRzIExpc3QgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIHtwZW5kaW5nRGF0YS5sb2FuUGF5b3V0cy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxHaVRha2VNeU1vbmV5IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPkxvYW4gUGF5b3V0czwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwXCI+KHtwZW5kaW5nRGF0YS5sb2FuUGF5b3V0cy5sZW5ndGh9KTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB0b2dnbGVTZWN0aW9uKFwibG9hblwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLWF1dG8gdGV4dC1ncmF5LTYwMCBob3Zlcjp0ZXh0LWVtZXJhbGQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXhwYW5kZWRTZWN0aW9ucy5sb2FuID8gPEZpQ2hldnJvblVwIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPiA6IDxGaUNoZXZyb25Eb3duIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtleHBhbmRlZFNlY3Rpb25zLmxvYW4gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIG1heC1oLVsyMDBweF0gb3ZlcmZsb3cteS1hdXRvIHByLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwZW5kaW5nRGF0YS5sb2FuUGF5b3V0cy5tYXAoKGl0ZW0sIGlkeCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UGVuZGluZ0xpc3RJdGVtIGtleT17aWR4fSBpdGVtPXtpdGVtfSB0eXBlPVwibG9hblwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9ICovfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQ2hpdCBDYW5jZWxsYXRpb25zIExpc3QgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIHtwZW5kaW5nRGF0YS5jaGl0Q2FuY2VsbGF0aW9ucy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGaVhDaXJjbGUgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXJlZC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5DaGl0IENhbmNlbGxhdGlvbnM8L2g0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTQwMFwiPih7cGVuZGluZ0RhdGEuY2hpdENhbmNlbGxhdGlvbnMubGVuZ3RofSk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlU2VjdGlvbihcImNhbmNlbGxhdGlvblwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLWF1dG8gdGV4dC1ncmF5LTYwMCBob3Zlcjp0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtleHBhbmRlZFNlY3Rpb25zLmNhbmNlbGxhdGlvbiA/IDxGaUNoZXZyb25VcCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz4gOiA8RmlDaGV2cm9uRG93biBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXhwYW5kZWRTZWN0aW9ucy5jYW5jZWxsYXRpb24gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIG1heC1oLVsyMDBweF0gb3ZlcmZsb3cteS1hdXRvIHByLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwZW5kaW5nRGF0YS5jaGl0Q2FuY2VsbGF0aW9ucy5tYXAoKGl0ZW0sIGlkeCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UGVuZGluZ0xpc3RJdGVtIGtleT17aWR4fSBpdGVtPXtpdGVtfSB0eXBlPVwiY2FuY2VsbGF0aW9uXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX0gKi99XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBORVc6IFNhbGFyeSBQZW5kaW5nIExpc3QgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIHtwZW5kaW5nRGF0YS5zYWxhcnlQZW5kaW5nLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJyaWVmY2FzZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtcHVycGxlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlNhbGFyeSBQZW5kaW5nPC9oND5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS00MDBcIj4oe3BlbmRpbmdEYXRhLnNhbGFyeVBlbmRpbmcubGVuZ3RofSk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlU2VjdGlvbihcInNhbGFyeVwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLWF1dG8gdGV4dC1ncmF5LTYwMCBob3Zlcjp0ZXh0LXB1cnBsZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtleHBhbmRlZFNlY3Rpb25zLnNhbGFyeSA/IDxGaUNoZXZyb25VcCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz4gOiA8RmlDaGV2cm9uRG93biBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXhwYW5kZWRTZWN0aW9ucy5zYWxhcnkgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIG1heC1oLVsyMDBweF0gb3ZlcmZsb3cteS1hdXRvIHByLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwZW5kaW5nRGF0YS5zYWxhcnlQZW5kaW5nLm1hcCgoaXRlbSwgaWR4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQZW5kaW5nTGlzdEl0ZW0ga2V5PXtpZHh9IGl0ZW09e2l0ZW19IHR5cGU9XCJzYWxhcnlcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBpdGFsaWMgYm9yZGVyLXQgcHQtMyBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgKiBEYXRhIGZldGNoZWQgZnJvbSBsaXZlIEFQSS4gUGVuZGluZyBwYXltZW50cyBzaG93IGFtb3VudHMgYXdhaXRpbmcgcHJvY2Vzc2luZy5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAgPHN0eWxlIGpzeD57YFxyXG4gICAgICAgIC5saW5lLWNsYW1wLTIge1xyXG4gICAgICAgICAgZGlzcGxheTogLXdlYmtpdC1ib3g7XHJcbiAgICAgICAgICAtd2Via2l0LWxpbmUtY2xhbXA6IDI7XHJcbiAgICAgICAgICAtd2Via2l0LWJveC1vcmllbnQ6IHZlcnRpY2FsO1xyXG4gICAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgICAgICB9XHJcbiAgICAgIGB9PC9zdHlsZT5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQYXlPdXRNZW51OyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9QYXlPdXRNZW51LmpzeCJ9