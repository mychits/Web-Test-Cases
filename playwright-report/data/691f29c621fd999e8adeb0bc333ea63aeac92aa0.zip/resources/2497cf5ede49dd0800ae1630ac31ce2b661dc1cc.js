import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/EnquireCall.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"]; const useState = __vite__cjsImport3_react["useState"];
import {
  notification,
  Form,
  Input,
  DatePicker,
  Button,
  Select,
  Tabs
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import API from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import __vite__cjsImport8_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport8_dayjs.__esModule ? __vite__cjsImport8_dayjs.default : __vite__cjsImport8_dayjs;
import Modal from "/src/components/modals/Modal.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import {
  MdPhone,
  MdAdd,
  MdPerson,
  MdLoop,
  MdPeopleAlt,
  MdAdminPanelSettings,
  MdLocalFireDepartment,
  MdAcUnit,
  MdFlashOn,
  MdInbox,
  MdBarChart,
  MdSearch,
  MdMoreVert,
  MdEdit,
  MdDelete
} from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
const { Option } = Select;
const ActionMenu = ({ onEdit, onDelete }) => {
  _s();
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { className: "relative flex justify-center", ref, children: [
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        type: "button",
        onClick: () => setOpen((v) => !v),
        className: "w-8 h-8 flex items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-700 transition-colors cursor-pointer",
        children: /* @__PURE__ */ jsxDEV(MdMoreVert, { size: 18 }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 58,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
        lineNumber: 53,
        columnNumber: 7
      },
      this
    ),
    open && /* @__PURE__ */ jsxDEV("div", { className: "absolute right-0 z-50 mt-1 w-36 bg-white border border-slate-200 rounded-xl shadow-lg overflow-hidden top-full", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => {
            setOpen(false);
            onEdit();
          },
          className: "w-full flex items-center gap-2.5 px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-blue-50 hover:text-blue-700 transition-colors cursor-pointer",
          children: [
            /* @__PURE__ */ jsxDEV(MdEdit, { size: 15, className: "text-blue-500" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 71,
              columnNumber: 13
            }, this),
            "Edit"
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 63,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: () => {
            setOpen(false);
            onDelete();
          },
          className: "w-full flex items-center gap-2.5 px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-red-50 hover:text-red-600 transition-colors cursor-pointer",
          children: [
            /* @__PURE__ */ jsxDEV(MdDelete, { size: 15, className: "text-red-400" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 82,
              columnNumber: 13
            }, this),
            "Delete"
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 74,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
      lineNumber: 62,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
    lineNumber: 52,
    columnNumber: 5
  }, this);
};
_s(ActionMenu, "wl9VvfhnMVWQ+kCekFjcRPEi3/0=");
_c = ActionMenu;
const DeleteConfirmModal = ({ isOpen, onClose, onConfirm, loading }) => {
  if (!isOpen) return null;
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/40", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-xl p-7 w-[360px] border border-slate-200", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center w-12 h-12 rounded-full bg-red-100 mx-auto mb-4", children: /* @__PURE__ */ jsxDEV(MdDelete, { size: 24, className: "text-red-500" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
      lineNumber: 97,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
      lineNumber: 96,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("h3", { className: "text-center text-base font-extrabold text-slate-900 mb-1", children: "Delete Enquiry?" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
      lineNumber: 99,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "text-center text-sm text-slate-500 mb-6", children: "This action cannot be undone. The record will be permanently removed." }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
      lineNumber: 102,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: onClose,
          className: "flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-bold text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer",
          children: "Cancel"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 106,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          type: "button",
          onClick: onConfirm,
          disabled: loading,
          className: "flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-sm font-bold transition-colors cursor-pointer disabled:opacity-60",
          children: loading ? "Deleting…" : "Yes, Delete"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 113,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
      lineNumber: 105,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
    lineNumber: 95,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
    lineNumber: 94,
    columnNumber: 5
  }, this);
};
_c2 = DeleteConfirmModal;
const CallStatusBadge = ({ status }) => {
  const config = {
    Hot: {
      cls: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-red-100 text-red-700 border border-red-200",
      dot: "w-1.5 h-1.5 rounded-full bg-red-500 shrink-0"
    },
    Cold: {
      cls: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-700 border border-blue-200",
      dot: "w-1.5 h-1.5 rounded-full bg-blue-500 shrink-0"
    },
    Emergency: {
      cls: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-orange-100 text-orange-700 border border-orange-200",
      dot: "w-1.5 h-1.5 rounded-full bg-orange-500 shrink-0"
    }
  };
  const c = config[status] || {
    cls: "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-gray-100 text-gray-600 border border-gray-200",
    dot: "w-1.5 h-1.5 rounded-full bg-gray-400 shrink-0",
    Icon: MdBarChart
  };
  return /* @__PURE__ */ jsxDEV("span", { className: c.cls, children: [
    /* @__PURE__ */ jsxDEV("span", { className: c.dot }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
      lineNumber: 149,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(c.Icon, { size: 12 }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
      lineNumber: 150,
      columnNumber: 7
    }, this),
    status
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
    lineNumber: 148,
    columnNumber: 5
  }, this);
};
_c3 = CallStatusBadge;
const StatCard = ({ label, value, colorClass, bgClass, Icon }) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 bg-white rounded-2xl border border-slate-100 px-5 py-4 shadow-sm flex-1 min-w-[130px]", children: [
  /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: `w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${bgClass}`,
      children: /* @__PURE__ */ jsxDEV(Icon, { size: 22, className: colorClass }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
        lineNumber: 161,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
      lineNumber: 158,
      columnNumber: 5
    },
    this
  ),
  /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("p", { className: `text-2xl font-extrabold leading-none ${colorClass}`, children: value }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
      lineNumber: 164,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500 font-semibold mt-1", children: label }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
      lineNumber: 167,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
    lineNumber: 163,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
  lineNumber: 157,
  columnNumber: 1
}, this);
_c4 = StatCard;
const TypePill = ({ value, current, label, activeClass, Icon, onChange }) => {
  const active = value === current;
  return /* @__PURE__ */ jsxDEV(
    "button",
    {
      type: "button",
      onClick: () => onChange(value),
      className: `flex items-center gap-2 px-5 py-2 rounded-full border-2 text-sm font-bold transition-all duration-150 outline-none cursor-pointer
        ${active ? `${activeClass} text-white shadow-md border-transparent` : "border-slate-200 bg-white text-slate-500 hover:border-slate-300"}`,
      children: [
        /* @__PURE__ */ jsxDEV(Icon, { size: 15 }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 182,
          columnNumber: 7
        }, this),
        label
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
      lineNumber: 176,
      columnNumber: 5
    },
    this
  );
};
_c5 = TypePill;
const SectionLabel = ({ tagClass, tag, title }) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5 mb-4", children: [
  /* @__PURE__ */ jsxDEV(
    "span",
    {
      className: `text-[10px] font-extrabold tracking-widest px-2 py-0.5 rounded ${tagClass}`,
      children: tag
    },
    void 0,
    false,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
      lineNumber: 191,
      columnNumber: 5
    },
    this
  ),
  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-bold text-slate-800", children: title }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
    lineNumber: 196,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
  lineNumber: 190,
  columnNumber: 1
}, this);
_c6 = SectionLabel;
function EnquireCall() {
  _s2();
  const [api, contextHolder] = notification.useNotification();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [form] = Form.useForm();
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editForm] = Form.useForm();
  const [editingRecord, setEditingRecord] = useState(null);
  const [editCustomerType, setEditCustomerType] = useState("new");
  const [deleteTargetId, setDeleteTargetId] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [enquiries, setEnquiries] = useState([]);
  const [loadingEnquiries, setLoadingEnquiries] = useState(false);
  const [users, setUsers] = useState([]);
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [adminName, setAdminName] = useState("");
  const [customerType, setCustomerType] = useState("new");
  const [enquiryTab, setEnquiryTab] = useState("all");
  const notify = (type, title, description) => api[type]({
    title,
    description,
    placement: "top",
    duration: 2,
    getContainer: () => document.body,
    style: { lineHeight: "1.2" }
  });
  const fetchEnquiries = async () => {
    try {
      setLoadingEnquiries(true);
      const res = await API.get("/enquiry/all");
      setEnquiries(res.data || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingEnquiries(false);
    }
  };
  const fetchAdminProfile = async () => {
    try {
      const userStr = localStorage.getItem("user");
      if (!userStr) return;
      const user = JSON.parse(userStr);
      if (!user._id) return;
      const res = await API.get(`/admin/get-admin/${user._id}`);
      const name = res.data.name || user.admin_name || "";
      setAdminName(name);
      form.setFieldsValue({ adminName: name });
    } catch (e) {
      console.error(e);
    }
  };
  const fetchUsers = async () => {
    try {
      setLoadingUsers(true);
      const res = await API.get("/user/get-user");
      setUsers(res.data || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingUsers(false);
    }
  };
  const fetchCustomerEnrollments = async (userId, targetForm = form) => {
    try {
      const res = await API.post(`/enroll/get-user-tickets-report/${userId}`);
      if (res.data && res.data.length > 0) {
        const groupData = res.data[0]?.enrollment?.group;
        const enrollmentData = res.data[0]?.enrollment;
        if (groupData)
          targetForm.setFieldsValue({ groupName: groupData.group_name });
        if (enrollmentData)
          targetForm.setFieldsValue({
            ticketNumber: enrollmentData.tickets || enrollmentData.ticket_number || "N/A"
          });
      } else {
        targetForm.setFieldsValue({
          groupName: "No Active Group Found",
          ticketNumber: "N/A"
        });
      }
    } catch (e) {
      console.error(e);
    }
  };
  useEffect(() => {
    fetchEnquiries();
  }, []);
  const handleOpenModal = () => {
    setIsModalOpen(true);
    form.resetFields();
    setCustomerType("new");
    fetchAdminProfile();
    fetchUsers();
    form.setFieldsValue({ date: dayjs() });
  };
  const handleCustomerSelect = (userId) => {
    const u = users.find((x) => x._id === userId);
    if (u) {
      form.setFieldsValue({
        searchCustomer: userId,
        customerId: userId,
        existingCustomerName: u.full_name || u.name,
        existingCustomerPhone: u.phone_number || u.mobile
      });
      fetchCustomerEnrollments(userId, form);
    }
  };
  const handleCustomerTypeChange = (value) => {
    setCustomerType(value);
    form.resetFields(
      [
        "newCustomerName",
        "newCustomerPhone",
        "purposeNew",
        "customerId",
        "existingCustomerName",
        "existingCustomerPhone",
        "groupName",
        "ticketNumber",
        "purposeExisting",
        "searchCustomer",
        "guestName",
        "guestPhone",
        "purposeGuest",
        "adminName_field",
        "adminPhone",
        "adminDepartment",
        "purposeAdmin",
        "description",
        "callStatus"
      ]
    );
    form.setFieldsValue({ customerType: value, date: dayjs() });
  };
  const onFinish = async (values) => {
    try {
      let payload = {
        adminName: values.adminName,
        description: values.description,
        date: values.date ? values.date.format("YYYY-MM-DD") : null
      };
      if (customerType === "new")
        payload = {
          ...payload,
          customerType: "new",
          customerName: values.newCustomerName,
          customerPhone: values.newCustomerPhone,
          purpose: values.purposeNew,
          callStatus: values.callStatus
        };
      else if (customerType === "existing")
        payload = {
          ...payload,
          customerType: "old",
          customerId: values.customerId,
          customerName: values.existingCustomerName,
          customerPhone: values.existingCustomerPhone,
          groupName: values.groupName,
          ticketNumber: values.ticketNumber,
          purpose: values.purposeExisting,
          callStatus: values.callStatus
        };
      else if (customerType === "guest")
        payload = {
          ...payload,
          customerType: "guest",
          customerName: values.guestName,
          customerPhone: values.guestPhone || "N/A",
          purpose: values.purposeGuest,
          callStatus: values.callStatus,
          guestName: values.guestName,
          guestPhone: values.guestPhone
        };
      else if (customerType === "admin")
        payload = {
          ...payload,
          customerType: "admin",
          customerName: values.adminName_field,
          customerPhone: values.adminPhone || "N/A",
          purpose: values.purposeAdmin,
          callStatus: values.callStatus,
          adminDepartment: values.adminDepartment
        };
      await API.post("/enquiry/create", payload);
      notify("success", "Success", "Enquiry submitted successfully!");
      fetchEnquiries();
      setIsModalOpen(false);
      form.resetFields();
      setCustomerType("new");
    } catch (e) {
      console.error(e);
      notify("error", "Error", "Failed to submit enquiry");
    }
  };
  const handleOpenEdit = (record) => {
    setEditingRecord(record);
    let ct = "new";
    if (record.customerType === "old" || record.customerType === "Existing Customer") {
      ct = "existing";
    } else if (record.customerType === "guest" || record.customerType === "Guest") {
      ct = "guest";
    } else if (record.customerType === "admin" || record.customerType === "Admin") {
      ct = "admin";
    } else if (record.customerType === "new" || record.customerType === "New Customer") {
      ct = "new";
    }
    setEditCustomerType(ct);
    let parsedDate = dayjs();
    if (record.date) {
      const formats = ["DD-MM-YYYY", "YYYY-MM-DD", "MM/DD/YYYY", "DD/MM/YYYY"];
      for (const format of formats) {
        const d2 = dayjs(record.date, format);
        if (d2.isValid()) {
          parsedDate = d2;
          break;
        }
      }
      const d = dayjs(record.date);
      if (d.isValid()) {
        parsedDate = d;
      }
    }
    const fieldsToSet = {
      adminName: record.adminName || "",
      description: record.description || "",
      date: parsedDate,
      callStatus: record.callStatus || "Cold"
    };
    if (ct === "new") {
      fieldsToSet.newCustomerName = record.customerName || "";
      fieldsToSet.newCustomerPhone = record.customerPhone || "";
      fieldsToSet.purposeNew = record.purpose || "";
    } else if (ct === "existing") {
      fieldsToSet.existingCustomerName = record.customerName || "";
      fieldsToSet.existingCustomerPhone = record.customerPhone || "";
      fieldsToSet.groupName = record.groupName || "";
      fieldsToSet.ticketNumber = record.ticketNumber || "";
      fieldsToSet.purposeExisting = record.purpose || "";
      fieldsToSet.customerId = record.customerId || "";
    } else if (ct === "guest") {
      fieldsToSet.guestName = record.customerName || "";
      fieldsToSet.guestPhone = record.customerPhone || "";
      fieldsToSet.purposeGuest = record.purpose || "";
    } else if (ct === "admin") {
      fieldsToSet.adminName_field = record.customerName || "";
      fieldsToSet.adminPhone = record.customerPhone || "";
      fieldsToSet.adminDepartment = record.adminDepartment || "";
      fieldsToSet.purposeAdmin = record.purpose || "";
    }
    editForm.resetFields();
    setTimeout(() => {
      editForm.setFieldsValue(fieldsToSet);
    }, 50);
    fetchUsers();
    setIsEditModalOpen(true);
  };
  const handleEditCustomerSelect = (userId) => {
    const u = users.find((x) => x._id === userId);
    if (u) {
      editForm.setFieldsValue({
        searchCustomer: userId,
        customerId: userId,
        existingCustomerName: u.full_name || u.name,
        existingCustomerPhone: u.phone_number || u.mobile
      });
      fetchCustomerEnrollments(userId, editForm);
    }
  };
  const handleEditCustomerTypeChange = (value) => {
    setEditCustomerType(value);
    editForm.resetFields(
      [
        "newCustomerName",
        "newCustomerPhone",
        "purposeNew",
        "customerId",
        "existingCustomerName",
        "existingCustomerPhone",
        "groupName",
        "ticketNumber",
        "purposeExisting",
        "searchCustomer",
        "guestName",
        "guestPhone",
        "purposeGuest",
        "adminName_field",
        "adminPhone",
        "adminDepartment",
        "purposeAdmin"
      ]
    );
  };
  const onEditFinish = async (values) => {
    try {
      let payload = {
        adminName: values.adminName,
        description: values.description,
        date: values.date ? values.date.format("YYYY-MM-DD") : null
      };
      if (editCustomerType === "new")
        payload = {
          ...payload,
          customerType: "new",
          customerName: values.newCustomerName,
          customerPhone: values.newCustomerPhone,
          purpose: values.purposeNew,
          callStatus: values.callStatus
        };
      else if (editCustomerType === "existing")
        payload = {
          ...payload,
          customerType: "old",
          customerId: values.customerId,
          customerName: values.existingCustomerName,
          customerPhone: values.existingCustomerPhone,
          groupName: values.groupName,
          ticketNumber: values.ticketNumber,
          purpose: values.purposeExisting,
          callStatus: values.callStatus
        };
      else if (editCustomerType === "guest")
        payload = {
          ...payload,
          customerType: "guest",
          customerName: values.guestName,
          customerPhone: values.guestPhone || "N/A",
          purpose: values.purposeGuest,
          callStatus: values.callStatus,
          guestName: values.guestName,
          guestPhone: values.guestPhone
        };
      else if (editCustomerType === "admin")
        payload = {
          ...payload,
          customerType: "admin",
          customerName: values.adminName_field,
          customerPhone: values.adminPhone || "N/A",
          purpose: values.purposeAdmin,
          callStatus: values.callStatus,
          adminDepartment: values.adminDepartment
        };
      await API.put(`/enquiry/${editingRecord._id}`, payload);
      notify("success", "Updated", "Enquiry updated successfully!");
      fetchEnquiries();
      setIsEditModalOpen(false);
      editForm.resetFields();
    } catch (e) {
      console.error(e);
      notify("error", "Error", "Failed to update enquiry");
    }
  };
  const handleDeleteConfirm = async () => {
    try {
      setDeleteLoading(true);
      await API.delete(`/enquiry/${deleteTargetId}`);
      notify("success", "Deleted", "Enquiry deleted successfully!");
      fetchEnquiries();
    } catch (e) {
      console.error(e);
      notify("error", "Error", "Failed to delete enquiry");
    } finally {
      setDeleteLoading(false);
      setDeleteTargetId(null);
    }
  };
  const actionColumn = {
    key: "actions",
    header: "Actions",
    width: "80px",
    minWidth: "80px",
    render: (_, row) => /* @__PURE__ */ jsxDEV(
      ActionMenu,
      {
        onEdit: () => handleOpenEdit(row),
        onDelete: () => setDeleteTargetId(row._id)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
        lineNumber: 618,
        columnNumber: 5
      },
      this
    )
  };
  const getEnquiryColumns = (tab) => {
    const base = [
      { key: "customerName", header: "Customer Name" },
      { key: "customerPhone", header: "Phone Number" },
      { key: "purpose", header: "Purpose" },
      { key: "description", header: "Description" },
      {
        key: "callStatus",
        header: "Call Status",
        render: (text) => /* @__PURE__ */ jsxDEV(CallStatusBadge, { status: text }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 634,
          columnNumber: 25
        }, this)
      }
    ];
    let cols;
    if (tab === "all") {
      cols = [
        { key: "date", header: "Date" },
        { key: "customerType", header: "Customer Type" },
        { key: "adminName", header: "Admin Name" },
        ...base,
        { key: "groupName", header: "Group" },
        { key: "ticketNumber", header: "Ticket No" },
        { key: "adminDepartment", header: "Department" }
      ];
    } else if (tab === "existing") {
      cols = [
        ...base,
        { key: "groupName", header: "Group" },
        { key: "ticketNumber", header: "Ticket No" }
      ];
    } else if (tab === "admin") {
      cols = [...base, { key: "adminDepartment", header: "Department" }];
    } else {
      cols = base;
    }
    return [...cols, actionColumn];
  };
  const getFilteredEnquiries = () => {
    if (enquiryTab === "new")
      return enquiries.filter((i) => i.customerType === "new");
    if (enquiryTab === "existing")
      return enquiries.filter((i) => i.customerType === "old");
    if (enquiryTab === "guest")
      return enquiries.filter((i) => i.customerType === "guest");
    if (enquiryTab === "admin")
      return enquiries.filter((i) => i.customerType === "admin");
    return enquiries;
  };
  const formattedEnquiries = getFilteredEnquiries().map((item) => ({
    ...item,
    actions: /* @__PURE__ */ jsxDEV(
      ActionMenu,
      {
        onEdit: () => handleOpenEdit(item),
        onDelete: () => setDeleteTargetId(item._id)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
        lineNumber: 680,
        columnNumber: 5
      },
      this
    ),
    _customerType: item.customerType,
    date: item.date ? dayjs(item.date).format("DD-MM-YYYY") : "-",
    customerType: item.customerType === "new" ? "New Customer" : item.customerType === "old" ? "Existing Customer" : item.customerType === "guest" ? "Guest" : item.customerType === "admin" ? "Admin" : "Guest"
  }));
  const counts = {
    all: enquiries.length,
    new: enquiries.filter((e) => e.customerType === "new").length,
    existing: enquiries.filter((e) => e.customerType === "old").length,
    guest: enquiries.filter((e) => e.customerType === "guest").length,
    admin: enquiries.filter((e) => e.customerType === "admin").length,
    hot: enquiries.filter((e) => e.callStatus === "Hot").length,
    cold: enquiries.filter((e) => e.callStatus === "Cold").length,
    emergency: enquiries.filter((e) => e.callStatus === "Emergency").length
  };
  const tabItems = [
    { key: "all", label: `All (${counts.all})`, children: null },
    { key: "new", label: `New Customer (${counts.new})`, children: null },
    {
      key: "existing",
      label: `Existing Customer (${counts.existing})`,
      children: null
    },
    { key: "guest", label: `Guest (${counts.guest})`, children: null },
    { key: "admin", label: `Admin (${counts.admin})`, children: null }
  ];
  const renderFormBody = (isEdit = false) => {
    const f = isEdit ? editForm : form;
    const ct = isEdit ? editCustomerType : customerType;
    const onCtChange = isEdit ? handleEditCustomerTypeChange : handleCustomerTypeChange;
    const onCustSel = isEdit ? handleEditCustomerSelect : handleCustomerSelect;
    return /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(
        Form.Item,
        {
          label: "Admin Name",
          name: "adminName",
          rules: [{ required: true, message: "Admin Name is required!" }],
          className: "mb-4",
          children: /* @__PURE__ */ jsxDEV(
            Input,
            {
              placeholder: "Auto-fetched",
              readOnly: true,
              className: "bg-slate-50 text-slate-500 cursor-not-allowed rounded-lg border-slate-200"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 741,
              columnNumber: 11
            },
            this
          )
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 735,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 mb-5", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-bold text-slate-700 mb-3", children: [
          "Customer Type ",
          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 750,
            columnNumber: 27
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 749,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3 flex-wrap", children: [
          /* @__PURE__ */ jsxDEV(
            TypePill,
            {
              value: "new",
              current: ct,
              label: "New Customer",
              activeClass: "bg-emerald-600",
              Icon: MdPerson,
              onChange: onCtChange
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 753,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            TypePill,
            {
              value: "existing",
              current: ct,
              label: "Existing Customer",
              activeClass: "bg-violet-600",
              Icon: MdLoop,
              onChange: onCtChange
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 761,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            TypePill,
            {
              value: "guest",
              current: ct,
              label: "Guest",
              activeClass: "bg-amber-500",
              Icon: MdPeopleAlt,
              onChange: onCtChange
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 769,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            TypePill,
            {
              value: "admin",
              current: ct,
              label: "Admin",
              activeClass: "bg-cyan-600",
              Icon: MdAdminPanelSettings,
              onChange: onCtChange
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 777,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 752,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
        lineNumber: 748,
        columnNumber: 9
      }, this),
      ct === "new" && /* @__PURE__ */ jsxDEV("div", { className: "bg-emerald-50 border border-emerald-200 rounded-xl p-5 mb-4", children: [
        /* @__PURE__ */ jsxDEV(
          SectionLabel,
          {
            tagClass: "bg-emerald-100 text-emerald-800",
            tag: "NEW",
            title: "New Customer Details"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 790,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              label: "Customer Name",
              name: "newCustomerName",
              rules: [{ required: true, message: "Required!" }],
              className: "mb-3",
              children: /* @__PURE__ */ jsxDEV(
                Input,
                {
                  placeholder: "Enter Customer Name",
                  className: "rounded-lg"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                  lineNumber: 802,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 796,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              label: "Customer Phone",
              name: "newCustomerPhone",
              rules: [
                { required: true, message: "Required!" },
                {
                  pattern: /^[6-9]\d{9}$/,
                  message: "Must be 10 digits starting with 6–9"
                }
              ],
              className: "mb-3",
              children: /* @__PURE__ */ jsxDEV(
                Input,
                {
                  placeholder: "10-digit mobile",
                  className: "rounded-lg",
                  maxLength: 10,
                  onInput: (e) => {
                    e.target.value = e.target.value.replace(/[^0-9]/g, "");
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                  lineNumber: 819,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 807,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 795,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Form.Item,
          {
            label: "Purpose of Call",
            name: "purposeNew",
            rules: [{ required: true, message: "Required!" }],
            className: "mb-0",
            children: /* @__PURE__ */ jsxDEV(Select, { placeholder: "Select purpose…", children: [
              "Group Enquiries",
              "Loan Enquiries",
              "Pigmy Enquiries",
              "Sales",
              "Admin"
            ].map(
              (v) => /* @__PURE__ */ jsxDEV(Option, { value: v, children: v }, v, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                lineNumber: 843,
                columnNumber: 15
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 835,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 829,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
        lineNumber: 789,
        columnNumber: 9
      }, this),
      ct === "existing" && /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-50 border border-violet-200 rounded-xl p-5 mb-4", children: [
        /* @__PURE__ */ jsxDEV(
          SectionLabel,
          {
            tagClass: "bg-violet-100 text-violet-800",
            tag: "EXISTING",
            title: "Existing Customer Details"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 854,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Form.Item,
          {
            label: "Search Customer",
            name: "searchCustomer",
            rules: [{ required: true, message: "Please select a customer!" }],
            className: "mb-3",
            children: /* @__PURE__ */ jsxDEV(
              Select,
              {
                showSearch: true,
                placeholder: "Search by name or phone…",
                onChange: onCustSel,
                filterOption: (input, option) => (option?.label ?? "").toLowerCase().includes(input.toLowerCase()),
                loading: loadingUsers,
                suffixIcon: /* @__PURE__ */ jsxDEV(MdSearch, { size: 16, className: "text-slate-400" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                  lineNumber: 875,
                  columnNumber: 27
                }, this),
                options: users.map((u) => ({
                  value: u._id,
                  label: `${u.full_name || u.name || "Unknown"} — ${u.phone_number || u.mobile || "No Phone"}`
                }))
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                lineNumber: 865,
                columnNumber: 15
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 859,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              label: "Customer Name",
              name: "existingCustomerName",
              rules: [{ required: true, message: "Required!" }],
              className: "mb-3",
              children: /* @__PURE__ */ jsxDEV(
                Input,
                {
                  readOnly: true,
                  placeholder: "Auto-filled",
                  className: "bg-slate-100 text-slate-500 cursor-not-allowed rounded-lg"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                  lineNumber: 889,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 883,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              label: "Phone Number",
              name: "existingCustomerPhone",
              rules: [{ required: true, message: "Required!" }],
              className: "mb-3",
              children: /* @__PURE__ */ jsxDEV(
                Input,
                {
                  readOnly: true,
                  placeholder: "Auto-filled",
                  className: "bg-slate-100 text-slate-500 cursor-not-allowed rounded-lg"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                  lineNumber: 901,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 895,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              label: "Group Name",
              name: "groupName",
              className: "mb-3",
              children: /* @__PURE__ */ jsxDEV(
                Input,
                {
                  readOnly: true,
                  placeholder: "Auto-filled from enrollment",
                  className: "bg-slate-100 text-slate-500 cursor-not-allowed rounded-lg"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                  lineNumber: 912,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 907,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              label: "Ticket No",
              name: "ticketNumber",
              className: "mb-3",
              children: /* @__PURE__ */ jsxDEV(
                Input,
                {
                  readOnly: true,
                  placeholder: "Auto-filled from enrollment",
                  className: "bg-slate-100 text-slate-500 cursor-not-allowed rounded-lg"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                  lineNumber: 923,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 918,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 882,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Form.Item, { name: "customerId", hidden: true, children: /* @__PURE__ */ jsxDEV(Input, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 931,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 930,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Form.Item,
          {
            label: "Purpose of Call",
            name: "purposeExisting",
            rules: [{ required: true, message: "Required!" }],
            className: "mb-0",
            children: /* @__PURE__ */ jsxDEV(Select, { placeholder: "Select purpose…", children: [
              "Bid Request",
              "Account Statement",
              "Payment Status",
              "Action Date",
              "Documents",
              "Chit Cancellation",
              "New Group Enquire",
              "Loan Enquire",
              "Pigmy Enquire",
              "Others"
            ].map(
              (v) => /* @__PURE__ */ jsxDEV(Option, { value: v, children: v }, v, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                lineNumber: 952,
                columnNumber: 15
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 939,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 933,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
        lineNumber: 853,
        columnNumber: 9
      }, this),
      ct === "guest" && /* @__PURE__ */ jsxDEV("div", { className: "bg-amber-50 border border-amber-200 rounded-xl p-5 mb-4", children: [
        /* @__PURE__ */ jsxDEV(
          SectionLabel,
          {
            tagClass: "bg-amber-100 text-amber-800",
            tag: "GUEST",
            title: "Guest Details"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 963,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              label: "Guest Name",
              name: "guestName",
              rules: [{ required: true, message: "Required!" }],
              className: "mb-3",
              children: /* @__PURE__ */ jsxDEV(Input, { placeholder: "Enter Guest Name", className: "rounded-lg" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                lineNumber: 975,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 969,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              label: "Phone Number (optional)",
              name: "guestPhone",
              rules: [
                { required: false },
                { pattern: /^[0-9]{10}$/, message: "Must be 10 digits" }
              ],
              className: "mb-3",
              children: /* @__PURE__ */ jsxDEV(
                Input,
                {
                  placeholder: "Optional",
                  className: "rounded-lg",
                  maxLength: 10,
                  onInput: (e) => {
                    e.target.value = e.target.value.replace(/[^0-9]/g, "");
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                  lineNumber: 986,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 977,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 968,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Form.Item,
          {
            label: "Purpose of Call",
            name: "purposeGuest",
            rules: [{ required: true, message: "Required!" }],
            className: "mb-0",
            children: /* @__PURE__ */ jsxDEV(Select, { placeholder: "Select purpose…", children: [
              "General Enquiry",
              "Information",
              "Interview",
              "Complaint",
              "Feedback",
              "Others"
            ].map(
              (v) => /* @__PURE__ */ jsxDEV(Option, { value: v, children: v }, v, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                lineNumber: 1011,
                columnNumber: 15
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1002,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 996,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
        lineNumber: 962,
        columnNumber: 9
      }, this),
      ct === "admin" && /* @__PURE__ */ jsxDEV("div", { className: "bg-cyan-50 border border-cyan-200 rounded-xl p-5 mb-4", children: [
        /* @__PURE__ */ jsxDEV(
          SectionLabel,
          {
            tagClass: "bg-cyan-100 text-cyan-800",
            tag: "ADMIN",
            title: "Admin Details"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 1022,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              label: "Admin Name",
              name: "adminName_field",
              rules: [{ required: true, message: "Required!" }],
              className: "mb-3",
              children: /* @__PURE__ */ jsxDEV(Input, { placeholder: "Enter Admin Name", className: "rounded-lg" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                lineNumber: 1034,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1028,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              label: "Phone Number",
              name: "adminPhone",
              rules: [
                { required: true, message: "Required!" },
                { pattern: /^[6-9]\d{9}$/, message: "Must be 10 digits starting with 6–9" }
              ],
              className: "mb-3",
              children: /* @__PURE__ */ jsxDEV(
                Input,
                {
                  placeholder: "10-digit mobile",
                  className: "rounded-lg",
                  maxLength: 10,
                  onInput: (e) => {
                    e.target.value = e.target.value.replace(/[^0-9]/g, "");
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                  lineNumber: 1045,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1036,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 1027,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Form.Item,
          {
            label: "Department",
            name: "adminDepartment",
            rules: [{ required: true, message: "Required!" }],
            className: "mb-3",
            children: /* @__PURE__ */ jsxDEV(Select, { placeholder: "Select department…", children: [
              "Management",
              "Accounts",
              "Operations",
              "Sales",
              "Marketing",
              "HR",
              "IT",
              "Customer Support",
              "Others"
            ].map(
              (v) => /* @__PURE__ */ jsxDEV(Option, { value: v, children: v }, v, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                lineNumber: 1073,
                columnNumber: 15
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1061,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 1055,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Form.Item,
          {
            label: "Purpose of Call",
            name: "purposeAdmin",
            rules: [{ required: true, message: "Required!" }],
            className: "mb-0",
            children: /* @__PURE__ */ jsxDEV(Select, { placeholder: "Select purpose…", children: [
              "Meeting Scheduled",
              "Follow-up",
              "Document Verification",
              "Policy Discussion",
              "System Access",
              "Training",
              "Others"
            ].map(
              (v) => /* @__PURE__ */ jsxDEV(Option, { value: v, children: v }, v, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                lineNumber: 1095,
                columnNumber: 15
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1085,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 1079,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
        lineNumber: 1021,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 mt-1", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-5", children: [
        /* @__PURE__ */ jsxDEV(
          Form.Item,
          {
            label: "Description",
            name: "description",
            rules: [
              { required: true, message: "Please enter a description!" }
            ],
            className: "mb-0",
            children: /* @__PURE__ */ jsxDEV(
              Input.TextArea,
              {
                rows: 4,
                placeholder: "Brief notes about this call…",
                className: "rounded-lg resize-none"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                lineNumber: 1114,
                columnNumber: 15
              },
              this
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 1106,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              label: "Date",
              name: "date",
              rules: [{ required: true, message: "Please select a date!" }],
              className: "mb-3",
              children: /* @__PURE__ */ jsxDEV(DatePicker, { className: "w-full rounded-lg" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                lineNumber: 1127,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1121,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              label: "Call Status",
              name: "callStatus",
              rules: [{ required: true, message: "Please select a status!" }],
              className: "mb-0",
              children: /* @__PURE__ */ jsxDEV(Select, { placeholder: "Select call status…", children: [
                /* @__PURE__ */ jsxDEV(Option, { value: "Hot", children: /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "w-2 h-2 rounded-full bg-red-500 inline-block" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                    lineNumber: 1138,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    MdLocalFireDepartment,
                    {
                      size: 14,
                      className: "text-red-600"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                      lineNumber: 1139,
                      columnNumber: 23
                    },
                    this
                  ),
                  "Hot"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                  lineNumber: 1137,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                  lineNumber: 1136,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(Option, { value: "Cold", children: /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "w-2 h-2 rounded-full bg-blue-500 inline-block" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                    lineNumber: 1148,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(MdAcUnit, { size: 14, className: "text-blue-600" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                    lineNumber: 1149,
                    columnNumber: 23
                  }, this),
                  "Cold"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                  lineNumber: 1147,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                  lineNumber: 1146,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(Option, { value: "Emergency", children: /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "w-2 h-2 rounded-full bg-orange-500 inline-block" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                    lineNumber: 1155,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(MdFlashOn, { size: 14, className: "text-orange-600" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                    lineNumber: 1156,
                    columnNumber: 23
                  }, this),
                  "Emergency"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                  lineNumber: 1154,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                  lineNumber: 1153,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                lineNumber: 1135,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1129,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 1120,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
        lineNumber: 1105,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
        lineNumber: 1104,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
      lineNumber: 734,
      columnNumber: 7
    }, this);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    contextHolder,
    /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen overflow-x-hidden mt-20", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
        lineNumber: 1176,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
        /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 1180,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-7 mt-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-xl bg-blue-800 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxDEV(MdPhone, { size: 22, className: "text-white" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1184,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1183,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-extrabold text-slate-900 leading-tight", children: "IVR Call Management" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                lineNumber: 1187,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-500 mt-0.5", children: "Track and manage all inbound & outbound customer call enquiries" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                lineNumber: 1190,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1186,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 1182,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: handleOpenModal,
              className: "flex items-center gap-2 bg-blue-800 hover:bg-blue-700 text-white text-sm font-bold px-5 py-2.5 rounded-xl transition-colors duration-150 cursor-pointer shadow-md",
              children: [
                /* @__PURE__ */ jsxDEV(MdAdd, { size: 18 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                  lineNumber: 1200,
                  columnNumber: 15
                }, this),
                " Log New Call"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1196,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 1181,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3 mb-8 flex-wrap", children: [
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              label: "Total Calls",
              value: counts.all,
              colorClass: "text-blue-700",
              bgClass: "bg-blue-50",
              Icon: MdBarChart
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1205,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              label: "New Customers",
              value: counts.new,
              colorClass: "text-emerald-700",
              bgClass: "bg-emerald-50",
              Icon: MdPerson
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1212,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              label: "Existing",
              value: counts.existing,
              colorClass: "text-violet-700",
              bgClass: "bg-violet-50",
              Icon: MdLoop
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1219,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              label: "Guests",
              value: counts.guest,
              colorClass: "text-amber-600",
              bgClass: "bg-amber-50",
              Icon: MdPeopleAlt
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1226,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            StatCard,
            {
              label: "Admin",
              value: counts.admin,
              colorClass: "text-cyan-700",
              bgClass: "bg-cyan-50",
              Icon: MdAdminPanelSettings
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1233,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 1204,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl border border-slate-200 shadow-sm p-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-extrabold text-slate-900", children: "Recent Call Enquiries" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1265,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold bg-blue-50 text-blue-800 border border-blue-200 px-3 py-1 rounded-full", children: [
              formattedEnquiries.length,
              " records"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1268,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 1264,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Tabs,
            {
              activeKey: enquiryTab,
              onChange: setEnquiryTab,
              items: tabItems,
              className: "mb-2"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1273,
              columnNumber: 13
            },
            this
          ),
          loadingEnquiries ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center h-44", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 1282,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 1281,
            columnNumber: 13
          }, this) : formattedEnquiries.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center h-44 gap-3", children: [
            /* @__PURE__ */ jsxDEV(MdInbox, { size: 48, className: "text-slate-300" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1286,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-base font-bold text-slate-600", children: "No Enquiries Found" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1287,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-400", children: 'Click "Log New Call" to add the first entry.' }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1290,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 1285,
            columnNumber: 13
          }, this) : /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: formattedEnquiries,
              columns: getEnquiryColumns(enquiryTab),
              exportCols: getEnquiryColumns(enquiryTab).filter(
                (c) => c.key !== "actions"
              ),
              exportedFileName: `Enquiry Report_${enquiryTab}.csv`,
              exportedPdfName: `Enquiry Report - ${enquiryTab}`,
              isExportEnabled: true
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1295,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 1263,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
        lineNumber: 1179,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
      lineNumber: 1175,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: isModalOpen,
        onClose: () => setIsModalOpen(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "w-full ", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 border-b border-slate-100 pb-3 mb-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-xl bg-blue-800 flex items-center justify-center shrink-0", children: /* @__PURE__ */ jsxDEV(MdPhone, { size: 20, className: "text-white" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1319,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1318,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-extrabold text-slate-900 leading-tight", children: "Log Call Enquiry" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                lineNumber: 1323,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500 leading-tight", children: "Fill in the details to record this call" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                lineNumber: 1327,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1322,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 1317,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(Form, { form, layout: "vertical", onFinish, children: [
            renderFormBody(false),
            /* @__PURE__ */ jsxDEV(Form.Item, { className: "mt-3 mb-0", children: /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                htmlType: "submit",
                block: true,
                className: "bg-blue-800 hover:bg-blue-700 h-10 rounded-xl font-bold text-sm shadow-md",
                children: "Submit Call Enquiry"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                lineNumber: 1337,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1336,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 1333,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 1315,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
        lineNumber: 1311,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: isEditModalOpen,
        onClose: () => {
          setIsEditModalOpen(false);
          editForm.resetFields();
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "w-full ", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 border-b border-slate-100 pb-3 mb-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-7 h-10 rounded-xl bg-violet-700 flex items-center justify-center ", children: /* @__PURE__ */ jsxDEV(MdEdit, { size: 20, className: "text-white" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1362,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1361,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-extrabold text-slate-900 leading-tight", children: "Edit Call Enquiry" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                lineNumber: 1366,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500 leading-tight", children: "Update the details for this call record" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                lineNumber: 1370,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1365,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 1360,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(Form, { form: editForm, layout: "vertical", onFinish: onEditFinish, children: [
            renderFormBody(true),
            /* @__PURE__ */ jsxDEV(Form.Item, { className: "mt-3 mb-0", children: /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                htmlType: "submit",
                block: true,
                className: "bg-violet-700 hover:bg-violet-800 h-10 rounded-xl font-bold text-sm shadow-md",
                children: "Save Changes"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
                lineNumber: 1380,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
              lineNumber: 1379,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
            lineNumber: 1376,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
          lineNumber: 1358,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
        lineNumber: 1351,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      DeleteConfirmModal,
      {
        isOpen: !!deleteTargetId,
        onClose: () => setDeleteTargetId(null),
        onConfirm: handleDeleteConfirm,
        loading: deleteLoading
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
        lineNumber: 1395,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx",
    lineNumber: 1171,
    columnNumber: 5
  }, this);
}
_s2(EnquireCall, "oxgYUHx+ewiIqdaj3Ke7CQkWsCM=", false, function() {
  return [notification.useNotification, Form.useForm, Form.useForm];
});
_c7 = EnquireCall;
export default EnquireCall;
var _c, _c2, _c3, _c4, _c5, _c6, _c7;
$RefreshReg$(_c, "ActionMenu");
$RefreshReg$(_c2, "DeleteConfirmModal");
$RefreshReg$(_c3, "CallStatusBadge");
$RefreshReg$(_c4, "StatCard");
$RefreshReg$(_c5, "TypePill");
$RefreshReg$(_c6, "SectionLabel");
$RefreshReg$(_c7, "EnquireCall");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EnquireCall.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeURRLFNBb3FCRixVQXBxQkU7O0FBekRSLG9CQUFnQkEsT0FBV0Msc0JBQWdCLGVBQWU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDMUQ7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxhQUFhO0FBRXBCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUVQLE1BQU0sRUFBRUMsT0FBTyxJQUFJeEI7QUFFbkIsTUFBTXlCLGFBQWFBLENBQUMsRUFBRUMsUUFBUUMsU0FBUyxNQUFNO0FBQUFDLEtBQUE7QUFDM0MsUUFBTSxDQUFDQyxNQUFNQyxPQUFPLElBQUlDLFNBQVMsS0FBSztBQUN0QyxRQUFNQyxNQUFNdEMsT0FBTyxJQUFJO0FBRXZCRCxZQUFVLE1BQU07QUFDZCxVQUFNd0MsVUFBVUEsQ0FBQ0MsTUFBTTtBQUNyQixVQUFJRixJQUFJRyxXQUFXLENBQUNILElBQUlHLFFBQVFDLFNBQVNGLEVBQUVHLE1BQU0sRUFBR1AsU0FBUSxLQUFLO0FBQUEsSUFDbkU7QUFDQVEsYUFBU0MsaUJBQWlCLGFBQWFOLE9BQU87QUFDOUMsV0FBTyxNQUFNSyxTQUFTRSxvQkFBb0IsYUFBYVAsT0FBTztBQUFBLEVBQ2hFLEdBQUcsRUFBRTtBQUVMLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGdDQUErQixLQUM1QztBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFLO0FBQUEsUUFDTCxTQUFTLE1BQU1ILFFBQVEsQ0FBQ1csTUFBTSxDQUFDQSxDQUFDO0FBQUEsUUFDaEMsV0FBVTtBQUFBLFFBRVYsaUNBQUMsY0FBVyxNQUFNLE1BQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUI7QUFBQTtBQUFBLE1BTHZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1BO0FBQUEsSUFFQ1osUUFDQyx1QkFBQyxTQUFJLFdBQVUsa0hBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsU0FBUyxNQUFNO0FBQ2JDLG9CQUFRLEtBQUs7QUFDYkosbUJBQU87QUFBQSxVQUNUO0FBQUEsVUFDQSxXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLFVBQU8sTUFBTSxJQUFJLFdBQVUsbUJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJDO0FBQUEsWUFBRztBQUFBO0FBQUE7QUFBQSxRQVJoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFVQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLFNBQVMsTUFBTTtBQUNiSSxvQkFBUSxLQUFLO0FBQ2JILHFCQUFTO0FBQUEsVUFDWDtBQUFBLFVBQ0EsV0FBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxZQUFTLE1BQU0sSUFBSSxXQUFVLGtCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0QztBQUFBLFlBQUc7QUFBQTtBQUFBO0FBQUEsUUFSakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BVUE7QUFBQSxTQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUJBO0FBQUEsT0FqQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1DQTtBQUVKO0FBQUVDLEdBbERJSCxZQUFVO0FBQUFpQixLQUFWakI7QUFvRE4sTUFBTWtCLHFCQUFxQkEsQ0FBQyxFQUFFQyxRQUFRQyxTQUFTQyxXQUFXQyxRQUFRLE1BQU07QUFDdEUsTUFBSSxDQUFDSCxPQUFRLFFBQU87QUFDcEIsU0FDRSx1QkFBQyxTQUFJLFdBQVUsbUVBQ2IsaUNBQUMsU0FBSSxXQUFVLHdFQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLG1GQUNiLGlDQUFDLFlBQVMsTUFBTSxJQUFJLFdBQVUsa0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEMsS0FEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxRQUFHLFdBQVUsNERBQTJELCtCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLE9BQUUsV0FBVSwyQ0FBMEMscUZBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsU0FBU0M7QUFBQUEsVUFDVCxXQUFVO0FBQUEsVUFBc0k7QUFBQTtBQUFBLFFBSGxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsU0FBU0M7QUFBQUEsVUFDVCxVQUFVQztBQUFBQSxVQUNWLFdBQVU7QUFBQSxVQUVUQSxvQkFBVSxjQUFjO0FBQUE7QUFBQSxRQU4zQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPQTtBQUFBLFNBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCQTtBQUFBLE9BMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyQkEsS0E1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZCQTtBQUVKO0FBQUVDLE1BbENJTDtBQW9DTixNQUFNTSxrQkFBa0JBLENBQUMsRUFBRUMsT0FBTyxNQUFNO0FBQ3RDLFFBQU1DLFNBQVM7QUFBQSxJQUNiQyxLQUFLO0FBQUEsTUFDSEMsS0FBSztBQUFBLE1BQ0xDLEtBQUs7QUFBQSxJQUNQO0FBQUEsSUFDQUMsTUFBTTtBQUFBLE1BQ0pGLEtBQUs7QUFBQSxNQUNMQyxLQUFLO0FBQUEsSUFDUDtBQUFBLElBQ0FFLFdBQVc7QUFBQSxNQUNUSCxLQUFLO0FBQUEsTUFDTEMsS0FBSztBQUFBLElBQ1A7QUFBQSxFQUNGO0FBQ0EsUUFBTUcsSUFBSU4sT0FBT0QsTUFBTSxLQUFLO0FBQUEsSUFDMUJHLEtBQUs7QUFBQSxJQUNMQyxLQUFLO0FBQUEsSUFDTEksTUFBTXZDO0FBQUFBLEVBQ1I7QUFDQSxTQUNFLHVCQUFDLFVBQUssV0FBV3NDLEVBQUVKLEtBQ2pCO0FBQUEsMkJBQUMsVUFBSyxXQUFXSSxFQUFFSCxPQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVCO0FBQUEsSUFDdkIsdUJBQUMsRUFBRSxNQUFGLEVBQU8sTUFBTSxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUI7QUFBQSxJQUNoQko7QUFBQUEsT0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBSUE7QUFFSjtBQUFFUyxNQTNCSVY7QUE2Qk4sTUFBTVcsV0FBV0EsQ0FBQyxFQUFFQyxPQUFPQyxPQUFPQyxZQUFZQyxTQUFTTixLQUFLLE1BQzFELHVCQUFDLFNBQUksV0FBVSxpSEFDYjtBQUFBO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxXQUFXLGtFQUFrRU0sT0FBTztBQUFBLE1BRXBGLGlDQUFDLFFBQUssTUFBTSxJQUFJLFdBQVdELGNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0M7QUFBQTtBQUFBLElBSHhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBO0FBQUEsRUFDQSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsT0FBRSxXQUFXLHdDQUF3Q0EsVUFBVSxJQUM3REQsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxPQUFFLFdBQVUsNkNBQTZDRCxtQkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRTtBQUFBLE9BSmxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLQTtBQUFBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQVlBO0FBQ0FJLE1BZElMO0FBaUJOLE1BQU1NLFdBQVdBLENBQUMsRUFBRUosT0FBTzNCLFNBQVMwQixPQUFPTSxhQUFhVCxNQUFNVSxTQUFTLE1BQU07QUFDM0UsUUFBTUMsU0FBU1AsVUFBVTNCO0FBQ3pCLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLE1BQUs7QUFBQSxNQUNMLFNBQVMsTUFBTWlDLFNBQVNOLEtBQUs7QUFBQSxNQUM3QixXQUFXO0FBQUEsVUFDUE8sU0FBUyxHQUFHRixXQUFXLDZDQUE2QyxpRUFBaUU7QUFBQSxNQUV6STtBQUFBLCtCQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZTtBQUFBLFFBQ2ROO0FBQUFBO0FBQUFBO0FBQUFBLElBUEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBUUE7QUFFSjtBQUFFUyxNQWJJSjtBQWdCTixNQUFNSyxlQUFlQSxDQUFDLEVBQUVDLFVBQVVDLEtBQUtDLE1BQU0sTUFDM0MsdUJBQUMsU0FBSSxXQUFVLGtDQUNiO0FBQUE7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFdBQVcsa0VBQWtFRixRQUFRO0FBQUEsTUFFcEZDO0FBQUFBO0FBQUFBLElBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUE7QUFBQSxFQUNBLHVCQUFDLFVBQUssV0FBVSxvQ0FBb0NDLG1CQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQTBEO0FBQUEsS0FONUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQU9BO0FBQ0FDLE1BVElKO0FBWU4sU0FBU0ssY0FBYztBQUFBQyxNQUFBO0FBQ3JCLFFBQU0sQ0FBQ0MsS0FBS0MsYUFBYSxJQUFJcEYsYUFBYXFGLGdCQUFnQjtBQUUxRCxRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSW5ELFNBQVMsS0FBSztBQUNwRCxRQUFNLENBQUNvRCxJQUFJLElBQUl2RixLQUFLd0YsUUFBUTtBQUU1QixRQUFNLENBQUNDLGlCQUFpQkMsa0JBQWtCLElBQUl2RCxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDd0QsUUFBUSxJQUFJM0YsS0FBS3dGLFFBQVE7QUFDaEMsUUFBTSxDQUFDSSxlQUFlQyxnQkFBZ0IsSUFBSTFELFNBQVMsSUFBSTtBQUN2RCxRQUFNLENBQUMyRCxrQkFBa0JDLG1CQUFtQixJQUFJNUQsU0FBUyxLQUFLO0FBRTlELFFBQU0sQ0FBQzZELGdCQUFnQkMsaUJBQWlCLElBQUk5RCxTQUFTLElBQUk7QUFDekQsUUFBTSxDQUFDK0QsZUFBZUMsZ0JBQWdCLElBQUloRSxTQUFTLEtBQUs7QUFFeEQsUUFBTSxDQUFDaUUsV0FBV0MsWUFBWSxJQUFJbEUsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ21FLGtCQUFrQkMsbUJBQW1CLElBQUlwRSxTQUFTLEtBQUs7QUFDOUQsUUFBTSxDQUFDcUUsT0FBT0MsUUFBUSxJQUFJdEUsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ3VFLGNBQWNDLGVBQWUsSUFBSXhFLFNBQVMsS0FBSztBQUN0RCxRQUFNLENBQUN5RSxXQUFXQyxZQUFZLElBQUkxRSxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDMkUsY0FBY0MsZUFBZSxJQUFJNUUsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQzZFLFlBQVlDLGFBQWEsSUFBSTlFLFNBQVMsS0FBSztBQUVsRCxRQUFNK0UsU0FBU0EsQ0FBQ0MsTUFBTXJDLE9BQU9zQyxnQkFDM0JsQyxJQUFJaUMsSUFBSSxFQUFFO0FBQUEsSUFDUnJDO0FBQUFBLElBQ0FzQztBQUFBQSxJQUNBQyxXQUFXO0FBQUEsSUFDWEMsVUFBVTtBQUFBLElBQ1ZDLGNBQWNBLE1BQU03RSxTQUFTOEU7QUFBQUEsSUFDN0JDLE9BQU8sRUFBRUMsWUFBWSxNQUFNO0FBQUEsRUFDN0IsQ0FBQztBQUVILFFBQU1DLGlCQUFpQixZQUFZO0FBQ2pDLFFBQUk7QUFDRnBCLDBCQUFvQixJQUFJO0FBQ3hCLFlBQU1xQixNQUFNLE1BQU10SCxJQUFJdUgsSUFBSSxjQUFjO0FBQ3hDeEIsbUJBQWF1QixJQUFJRSxRQUFRLEVBQUU7QUFBQSxJQUM3QixTQUFTeEYsR0FBRztBQUNWeUYsY0FBUUMsTUFBTTFGLENBQUM7QUFBQSxJQUNqQixVQUFDO0FBQ0NpRSwwQkFBb0IsS0FBSztBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUVBLFFBQU0wQixvQkFBb0IsWUFBWTtBQUNwQyxRQUFJO0FBQ0YsWUFBTUMsVUFBVUMsYUFBYUMsUUFBUSxNQUFNO0FBQzNDLFVBQUksQ0FBQ0YsUUFBUztBQUNkLFlBQU1HLE9BQU9DLEtBQUtDLE1BQU1MLE9BQU87QUFDL0IsVUFBSSxDQUFDRyxLQUFLRyxJQUFLO0FBQ2YsWUFBTVosTUFBTSxNQUFNdEgsSUFBSXVILElBQUksb0JBQW9CUSxLQUFLRyxHQUFHLEVBQUU7QUFDeEQsWUFBTUMsT0FBT2IsSUFBSUUsS0FBS1csUUFBUUosS0FBS0ssY0FBYztBQUNqRDdCLG1CQUFhNEIsSUFBSTtBQUNqQmxELFdBQUtvRCxlQUFlLEVBQUUvQixXQUFXNkIsS0FBSyxDQUFDO0FBQUEsSUFDekMsU0FBU25HLEdBQUc7QUFDVnlGLGNBQVFDLE1BQU0xRixDQUFDO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBRUEsUUFBTXNHLGFBQWEsWUFBWTtBQUM3QixRQUFJO0FBQ0ZqQyxzQkFBZ0IsSUFBSTtBQUNwQixZQUFNaUIsTUFBTSxNQUFNdEgsSUFBSXVILElBQUksZ0JBQWdCO0FBQzFDcEIsZUFBU21CLElBQUlFLFFBQVEsRUFBRTtBQUFBLElBQ3pCLFNBQVN4RixHQUFHO0FBQ1Z5RixjQUFRQyxNQUFNMUYsQ0FBQztBQUFBLElBQ2pCLFVBQUM7QUFDQ3FFLHNCQUFnQixLQUFLO0FBQUEsSUFDdkI7QUFBQSxFQUNGO0FBRUEsUUFBTWtDLDJCQUEyQixPQUFPQyxRQUFRQyxhQUFheEQsU0FBUztBQUNwRSxRQUFJO0FBQ0YsWUFBTXFDLE1BQU0sTUFBTXRILElBQUkwSSxLQUFLLG1DQUFtQ0YsTUFBTSxFQUFFO0FBQ3RFLFVBQUlsQixJQUFJRSxRQUFRRixJQUFJRSxLQUFLbUIsU0FBUyxHQUFHO0FBQ25DLGNBQU1DLFlBQVl0QixJQUFJRSxLQUFLLENBQUMsR0FBR3FCLFlBQVlDO0FBQzNDLGNBQU1DLGlCQUFpQnpCLElBQUlFLEtBQUssQ0FBQyxHQUFHcUI7QUFDcEMsWUFBSUQ7QUFDRkgscUJBQVdKLGVBQWUsRUFBRVcsV0FBV0osVUFBVUssV0FBVyxDQUFDO0FBQy9ELFlBQUlGO0FBQ0ZOLHFCQUFXSixlQUFlO0FBQUEsWUFDeEJhLGNBQ0VILGVBQWVJLFdBQVdKLGVBQWVLLGlCQUFpQjtBQUFBLFVBQzlELENBQUM7QUFBQSxNQUNMLE9BQU87QUFDTFgsbUJBQVdKLGVBQWU7QUFBQSxVQUN4QlcsV0FBVztBQUFBLFVBQ1hFLGNBQWM7QUFBQSxRQUNoQixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsU0FBU2xILEdBQUc7QUFDVnlGLGNBQVFDLE1BQU0xRixDQUFDO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBRUF6QyxZQUFVLE1BQU07QUFDZDhILG1CQUFlO0FBQUEsRUFDakIsR0FBRyxFQUFFO0FBRUwsUUFBTWdDLGtCQUFrQkEsTUFBTTtBQUM1QnJFLG1CQUFlLElBQUk7QUFDbkJDLFNBQUtxRSxZQUFZO0FBQ2pCN0Msb0JBQWdCLEtBQUs7QUFDckJrQixzQkFBa0I7QUFDbEJXLGVBQVc7QUFDWHJELFNBQUtvRCxlQUFlLEVBQUVrQixNQUFNcEosTUFBTSxFQUFFLENBQUM7QUFBQSxFQUN2QztBQUVBLFFBQU1xSix1QkFBdUJBLENBQUNoQixXQUFXO0FBQ3ZDLFVBQU1pQixJQUFJdkQsTUFBTXdELEtBQUssQ0FBQ0MsTUFBTUEsRUFBRXpCLFFBQVFNLE1BQU07QUFDNUMsUUFBSWlCLEdBQUc7QUFDTHhFLFdBQUtvRCxlQUFlO0FBQUEsUUFDbEJ1QixnQkFBZ0JwQjtBQUFBQSxRQUNoQnFCLFlBQVlyQjtBQUFBQSxRQUNac0Isc0JBQXNCTCxFQUFFTSxhQUFhTixFQUFFdEI7QUFBQUEsUUFDdkM2Qix1QkFBdUJQLEVBQUVRLGdCQUFnQlIsRUFBRVM7QUFBQUEsTUFDN0MsQ0FBQztBQUNEM0IsK0JBQXlCQyxRQUFRdkQsSUFBSTtBQUFBLElBQ3ZDO0FBQUEsRUFDRjtBQUVBLFFBQU1rRiwyQkFBMkJBLENBQUN2RyxVQUFVO0FBQzFDNkMsb0JBQWdCN0MsS0FBSztBQUNyQnFCLFNBQUtxRTtBQUFBQSxNQUFZO0FBQUEsUUFDZjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQVk7QUFBQSxJQUNiO0FBQ0RyRSxTQUFLb0QsZUFBZSxFQUFFN0IsY0FBYzVDLE9BQU8yRixNQUFNcEosTUFBTSxFQUFFLENBQUM7QUFBQSxFQUM1RDtBQUVBLFFBQU1pSyxXQUFXLE9BQU9DLFdBQVc7QUFDakMsUUFBSTtBQUNGLFVBQUlDLFVBQVU7QUFBQSxRQUNaaEUsV0FBVytELE9BQU8vRDtBQUFBQSxRQUNsQlEsYUFBYXVELE9BQU92RDtBQUFBQSxRQUNwQnlDLE1BQU1jLE9BQU9kLE9BQU9jLE9BQU9kLEtBQUtnQixPQUFPLFlBQVksSUFBSTtBQUFBLE1BQ3pEO0FBQ0EsVUFBSS9ELGlCQUFpQjtBQUNuQjhELGtCQUFVO0FBQUEsVUFDUixHQUFHQTtBQUFBQSxVQUNIOUQsY0FBYztBQUFBLFVBQ2RnRSxjQUFjSCxPQUFPSTtBQUFBQSxVQUNyQkMsZUFBZUwsT0FBT007QUFBQUEsVUFDdEJDLFNBQVNQLE9BQU9RO0FBQUFBLFVBQ2hCQyxZQUFZVCxPQUFPUztBQUFBQSxRQUNyQjtBQUFBLGVBQ090RSxpQkFBaUI7QUFDeEI4RCxrQkFBVTtBQUFBLFVBQ1IsR0FBR0E7QUFBQUEsVUFDSDlELGNBQWM7QUFBQSxVQUNkcUQsWUFBWVEsT0FBT1I7QUFBQUEsVUFDbkJXLGNBQWNILE9BQU9QO0FBQUFBLFVBQ3JCWSxlQUFlTCxPQUFPTDtBQUFBQSxVQUN0QmhCLFdBQVdxQixPQUFPckI7QUFBQUEsVUFDbEJFLGNBQWNtQixPQUFPbkI7QUFBQUEsVUFDckIwQixTQUFTUCxPQUFPVTtBQUFBQSxVQUNoQkQsWUFBWVQsT0FBT1M7QUFBQUEsUUFDckI7QUFBQSxlQUNPdEUsaUJBQWlCO0FBQ3hCOEQsa0JBQVU7QUFBQSxVQUNSLEdBQUdBO0FBQUFBLFVBQ0g5RCxjQUFjO0FBQUEsVUFDZGdFLGNBQWNILE9BQU9XO0FBQUFBLFVBQ3JCTixlQUFlTCxPQUFPWSxjQUFjO0FBQUEsVUFDcENMLFNBQVNQLE9BQU9hO0FBQUFBLFVBQ2hCSixZQUFZVCxPQUFPUztBQUFBQSxVQUNuQkUsV0FBV1gsT0FBT1c7QUFBQUEsVUFDbEJDLFlBQVlaLE9BQU9ZO0FBQUFBLFFBQ3JCO0FBQUEsZUFDT3pFLGlCQUFpQjtBQUN4QjhELGtCQUFVO0FBQUEsVUFDUixHQUFHQTtBQUFBQSxVQUNIOUQsY0FBYztBQUFBLFVBQ2RnRSxjQUFjSCxPQUFPYztBQUFBQSxVQUNyQlQsZUFBZUwsT0FBT2UsY0FBYztBQUFBLFVBQ3BDUixTQUFTUCxPQUFPZ0I7QUFBQUEsVUFDaEJQLFlBQVlULE9BQU9TO0FBQUFBLFVBQ25CUSxpQkFBaUJqQixPQUFPaUI7QUFBQUEsUUFDMUI7QUFDRixZQUFNdEwsSUFBSTBJLEtBQUssbUJBQW1CNEIsT0FBTztBQUN6QzFELGFBQU8sV0FBVyxXQUFXLGlDQUFpQztBQUM5RFMscUJBQWU7QUFDZnJDLHFCQUFlLEtBQUs7QUFDcEJDLFdBQUtxRSxZQUFZO0FBQ2pCN0Msc0JBQWdCLEtBQUs7QUFBQSxJQUN2QixTQUFTekUsR0FBRztBQUNWeUYsY0FBUUMsTUFBTTFGLENBQUM7QUFDZjRFLGFBQU8sU0FBUyxTQUFTLDBCQUEwQjtBQUFBLElBQ3JEO0FBQUEsRUFDRjtBQUdBLFFBQU0yRSxpQkFBaUJBLENBQUNDLFdBQVc7QUFDakNqRyxxQkFBaUJpRyxNQUFNO0FBR3ZCLFFBQUlDLEtBQUs7QUFDVCxRQUNFRCxPQUFPaEYsaUJBQWlCLFNBQ3hCZ0YsT0FBT2hGLGlCQUFpQixxQkFDeEI7QUFDQWlGLFdBQUs7QUFBQSxJQUNQLFdBQ0VELE9BQU9oRixpQkFBaUIsV0FDeEJnRixPQUFPaEYsaUJBQWlCLFNBQ3hCO0FBQ0FpRixXQUFLO0FBQUEsSUFDUCxXQUNFRCxPQUFPaEYsaUJBQWlCLFdBQ3hCZ0YsT0FBT2hGLGlCQUFpQixTQUN4QjtBQUNBaUYsV0FBSztBQUFBLElBQ1AsV0FDRUQsT0FBT2hGLGlCQUFpQixTQUN4QmdGLE9BQU9oRixpQkFBaUIsZ0JBQ3hCO0FBQ0FpRixXQUFLO0FBQUEsSUFDUDtBQUVBaEcsd0JBQW9CZ0csRUFBRTtBQUd0QixRQUFJQyxhQUFhdkwsTUFBTTtBQUN2QixRQUFJcUwsT0FBT2pDLE1BQU07QUFFZixZQUFNb0MsVUFBVSxDQUFDLGNBQWMsY0FBYyxjQUFjLFlBQVk7QUFDdkUsaUJBQVdwQixVQUFVb0IsU0FBUztBQUM1QixjQUFNQyxLQUFJekwsTUFBTXFMLE9BQU9qQyxNQUFNZ0IsTUFBTTtBQUNuQyxZQUFJcUIsR0FBRUMsUUFBUSxHQUFHO0FBQ2ZILHVCQUFhRTtBQUNiO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFFQSxZQUFNQSxJQUFJekwsTUFBTXFMLE9BQU9qQyxJQUFJO0FBQzNCLFVBQUlxQyxFQUFFQyxRQUFRLEdBQUc7QUFDZkgscUJBQWFFO0FBQUFBLE1BQ2Y7QUFBQSxJQUNGO0FBR0EsVUFBTUUsY0FBYztBQUFBLE1BQ2xCeEYsV0FBV2tGLE9BQU9sRixhQUFhO0FBQUEsTUFDL0JRLGFBQWEwRSxPQUFPMUUsZUFBZTtBQUFBLE1BQ25DeUMsTUFBTW1DO0FBQUFBLE1BQ05aLFlBQVlVLE9BQU9WLGNBQWM7QUFBQSxJQUNuQztBQUVBLFFBQUlXLE9BQU8sT0FBTztBQUNoQkssa0JBQVlyQixrQkFBa0JlLE9BQU9oQixnQkFBZ0I7QUFDckRzQixrQkFBWW5CLG1CQUFtQmEsT0FBT2QsaUJBQWlCO0FBQ3ZEb0Isa0JBQVlqQixhQUFhVyxPQUFPWixXQUFXO0FBQUEsSUFDN0MsV0FBV2EsT0FBTyxZQUFZO0FBQzVCSyxrQkFBWWhDLHVCQUF1QjBCLE9BQU9oQixnQkFBZ0I7QUFDMURzQixrQkFBWTlCLHdCQUF3QndCLE9BQU9kLGlCQUFpQjtBQUM1RG9CLGtCQUFZOUMsWUFBWXdDLE9BQU94QyxhQUFhO0FBQzVDOEMsa0JBQVk1QyxlQUFlc0MsT0FBT3RDLGdCQUFnQjtBQUNsRDRDLGtCQUFZZixrQkFBa0JTLE9BQU9aLFdBQVc7QUFDaERrQixrQkFBWWpDLGFBQWEyQixPQUFPM0IsY0FBYztBQUFBLElBQ2hELFdBQVc0QixPQUFPLFNBQVM7QUFDekJLLGtCQUFZZCxZQUFZUSxPQUFPaEIsZ0JBQWdCO0FBQy9Dc0Isa0JBQVliLGFBQWFPLE9BQU9kLGlCQUFpQjtBQUNqRG9CLGtCQUFZWixlQUFlTSxPQUFPWixXQUFXO0FBQUEsSUFDL0MsV0FBV2EsT0FBTyxTQUFTO0FBQ3pCSyxrQkFBWVgsa0JBQWtCSyxPQUFPaEIsZ0JBQWdCO0FBQ3JEc0Isa0JBQVlWLGFBQWFJLE9BQU9kLGlCQUFpQjtBQUNqRG9CLGtCQUFZUixrQkFBa0JFLE9BQU9GLG1CQUFtQjtBQUN4RFEsa0JBQVlULGVBQWVHLE9BQU9aLFdBQVc7QUFBQSxJQUMvQztBQUdBdkYsYUFBU2lFLFlBQVk7QUFHckJ5QyxlQUFXLE1BQU07QUFDZjFHLGVBQVNnRCxlQUFleUQsV0FBVztBQUFBLElBQ3JDLEdBQUcsRUFBRTtBQUVMeEQsZUFBVztBQUNYbEQsdUJBQW1CLElBQUk7QUFBQSxFQUN6QjtBQUVBLFFBQU00RywyQkFBMkJBLENBQUN4RCxXQUFXO0FBQzNDLFVBQU1pQixJQUFJdkQsTUFBTXdELEtBQUssQ0FBQ0MsTUFBTUEsRUFBRXpCLFFBQVFNLE1BQU07QUFDNUMsUUFBSWlCLEdBQUc7QUFDTHBFLGVBQVNnRCxlQUFlO0FBQUEsUUFDdEJ1QixnQkFBZ0JwQjtBQUFBQSxRQUNoQnFCLFlBQVlyQjtBQUFBQSxRQUNac0Isc0JBQXNCTCxFQUFFTSxhQUFhTixFQUFFdEI7QUFBQUEsUUFDdkM2Qix1QkFBdUJQLEVBQUVRLGdCQUFnQlIsRUFBRVM7QUFBQUEsTUFDN0MsQ0FBQztBQUNEM0IsK0JBQXlCQyxRQUFRbkQsUUFBUTtBQUFBLElBQzNDO0FBQUEsRUFDRjtBQUVBLFFBQU00RywrQkFBK0JBLENBQUNySSxVQUFVO0FBQzlDNkIsd0JBQW9CN0IsS0FBSztBQUN6QnlCLGFBQVNpRTtBQUFBQSxNQUFZO0FBQUEsUUFDbkI7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFBYztBQUFBLElBQ2Y7QUFBQSxFQUNIO0FBRUEsUUFBTTRDLGVBQWUsT0FBTzdCLFdBQVc7QUFDckMsUUFBSTtBQUNGLFVBQUlDLFVBQVU7QUFBQSxRQUNaaEUsV0FBVytELE9BQU8vRDtBQUFBQSxRQUNsQlEsYUFBYXVELE9BQU92RDtBQUFBQSxRQUNwQnlDLE1BQU1jLE9BQU9kLE9BQU9jLE9BQU9kLEtBQUtnQixPQUFPLFlBQVksSUFBSTtBQUFBLE1BQ3pEO0FBQ0EsVUFBSS9FLHFCQUFxQjtBQUN2QjhFLGtCQUFVO0FBQUEsVUFDUixHQUFHQTtBQUFBQSxVQUNIOUQsY0FBYztBQUFBLFVBQ2RnRSxjQUFjSCxPQUFPSTtBQUFBQSxVQUNyQkMsZUFBZUwsT0FBT007QUFBQUEsVUFDdEJDLFNBQVNQLE9BQU9RO0FBQUFBLFVBQ2hCQyxZQUFZVCxPQUFPUztBQUFBQSxRQUNyQjtBQUFBLGVBQ090RixxQkFBcUI7QUFDNUI4RSxrQkFBVTtBQUFBLFVBQ1IsR0FBR0E7QUFBQUEsVUFDSDlELGNBQWM7QUFBQSxVQUNkcUQsWUFBWVEsT0FBT1I7QUFBQUEsVUFDbkJXLGNBQWNILE9BQU9QO0FBQUFBLFVBQ3JCWSxlQUFlTCxPQUFPTDtBQUFBQSxVQUN0QmhCLFdBQVdxQixPQUFPckI7QUFBQUEsVUFDbEJFLGNBQWNtQixPQUFPbkI7QUFBQUEsVUFDckIwQixTQUFTUCxPQUFPVTtBQUFBQSxVQUNoQkQsWUFBWVQsT0FBT1M7QUFBQUEsUUFDckI7QUFBQSxlQUNPdEYscUJBQXFCO0FBQzVCOEUsa0JBQVU7QUFBQSxVQUNSLEdBQUdBO0FBQUFBLFVBQ0g5RCxjQUFjO0FBQUEsVUFDZGdFLGNBQWNILE9BQU9XO0FBQUFBLFVBQ3JCTixlQUFlTCxPQUFPWSxjQUFjO0FBQUEsVUFDcENMLFNBQVNQLE9BQU9hO0FBQUFBLFVBQ2hCSixZQUFZVCxPQUFPUztBQUFBQSxVQUNuQkUsV0FBV1gsT0FBT1c7QUFBQUEsVUFDbEJDLFlBQVlaLE9BQU9ZO0FBQUFBLFFBQ3JCO0FBQUEsZUFDT3pGLHFCQUFxQjtBQUM1QjhFLGtCQUFVO0FBQUEsVUFDUixHQUFHQTtBQUFBQSxVQUNIOUQsY0FBYztBQUFBLFVBQ2RnRSxjQUFjSCxPQUFPYztBQUFBQSxVQUNyQlQsZUFBZUwsT0FBT2UsY0FBYztBQUFBLFVBQ3BDUixTQUFTUCxPQUFPZ0I7QUFBQUEsVUFDaEJQLFlBQVlULE9BQU9TO0FBQUFBLFVBQ25CUSxpQkFBaUJqQixPQUFPaUI7QUFBQUEsUUFDMUI7QUFDRixZQUFNdEwsSUFBSW1NLElBQUksWUFBWTdHLGNBQWM0QyxHQUFHLElBQUlvQyxPQUFPO0FBQ3REMUQsYUFBTyxXQUFXLFdBQVcsK0JBQStCO0FBQzVEUyxxQkFBZTtBQUNmakMseUJBQW1CLEtBQUs7QUFDeEJDLGVBQVNpRSxZQUFZO0FBQUEsSUFDdkIsU0FBU3RILEdBQUc7QUFDVnlGLGNBQVFDLE1BQU0xRixDQUFDO0FBQ2Y0RSxhQUFPLFNBQVMsU0FBUywwQkFBMEI7QUFBQSxJQUNyRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNd0Ysc0JBQXNCLFlBQVk7QUFDdEMsUUFBSTtBQUNGdkcsdUJBQWlCLElBQUk7QUFDckIsWUFBTTdGLElBQUlxTSxPQUFPLFlBQVkzRyxjQUFjLEVBQUU7QUFDN0NrQixhQUFPLFdBQVcsV0FBVywrQkFBK0I7QUFDNURTLHFCQUFlO0FBQUEsSUFDakIsU0FBU3JGLEdBQUc7QUFDVnlGLGNBQVFDLE1BQU0xRixDQUFDO0FBQ2Y0RSxhQUFPLFNBQVMsU0FBUywwQkFBMEI7QUFBQSxJQUNyRCxVQUFDO0FBQ0NmLHVCQUFpQixLQUFLO0FBQ3RCRix3QkFBa0IsSUFBSTtBQUFBLElBQ3hCO0FBQUEsRUFDRjtBQUdBLFFBQU0yRyxlQUFlO0FBQUEsSUFDbkJDLEtBQUs7QUFBQSxJQUNMQyxRQUFRO0FBQUEsSUFDUkMsT0FBTztBQUFBLElBQ1BDLFVBQVU7QUFBQSxJQUNWQyxRQUFRQSxDQUFDQyxHQUFHQyxRQUNWO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxRQUFRLE1BQU10QixlQUFlc0IsR0FBRztBQUFBLFFBQ2hDLFVBQVUsTUFBTWxILGtCQUFrQmtILElBQUkzRSxHQUFHO0FBQUE7QUFBQSxNQUYzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFNkM7QUFBQSxFQUdqRDtBQUVBLFFBQU00RSxvQkFBb0JBLENBQUNDLFFBQVE7QUFDakMsVUFBTUMsT0FBTztBQUFBLE1BQ1gsRUFBRVQsS0FBSyxnQkFBZ0JDLFFBQVEsZ0JBQWdCO0FBQUEsTUFDL0MsRUFBRUQsS0FBSyxpQkFBaUJDLFFBQVEsZUFBZTtBQUFBLE1BQy9DLEVBQUVELEtBQUssV0FBV0MsUUFBUSxVQUFVO0FBQUEsTUFDcEMsRUFBRUQsS0FBSyxlQUFlQyxRQUFRLGNBQWM7QUFBQSxNQUM1QztBQUFBLFFBQ0VELEtBQUs7QUFBQSxRQUNMQyxRQUFRO0FBQUEsUUFDUkcsUUFBUUEsQ0FBQ00sU0FBUyx1QkFBQyxtQkFBZ0IsUUFBUUEsUUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QjtBQUFBLE1BQ2xEO0FBQUEsSUFBQztBQUdILFFBQUlDO0FBQ0osUUFBSUgsUUFBUSxPQUFPO0FBQ2pCRyxhQUFPO0FBQUEsUUFDTCxFQUFFWCxLQUFLLFFBQVFDLFFBQVEsT0FBTztBQUFBLFFBQzlCLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGdCQUFnQjtBQUFBLFFBQy9DLEVBQUVELEtBQUssYUFBYUMsUUFBUSxhQUFhO0FBQUEsUUFDekMsR0FBR1E7QUFBQUEsUUFDSCxFQUFFVCxLQUFLLGFBQWFDLFFBQVEsUUFBUTtBQUFBLFFBQ3BDLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLFlBQVk7QUFBQSxRQUMzQyxFQUFFRCxLQUFLLG1CQUFtQkMsUUFBUSxhQUFhO0FBQUEsTUFBQztBQUFBLElBRXBELFdBQVdPLFFBQVEsWUFBWTtBQUM3QkcsYUFBTztBQUFBLFFBQ0wsR0FBR0Y7QUFBQUEsUUFDSCxFQUFFVCxLQUFLLGFBQWFDLFFBQVEsUUFBUTtBQUFBLFFBQ3BDLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLFlBQVk7QUFBQSxNQUFDO0FBQUEsSUFFaEQsV0FBV08sUUFBUSxTQUFTO0FBQzFCRyxhQUFPLENBQUMsR0FBR0YsTUFBTSxFQUFFVCxLQUFLLG1CQUFtQkMsUUFBUSxhQUFhLENBQUM7QUFBQSxJQUNuRSxPQUFPO0FBQ0xVLGFBQU9GO0FBQUFBLElBQ1Q7QUFFQSxXQUFPLENBQUMsR0FBR0UsTUFBTVosWUFBWTtBQUFBLEVBQy9CO0FBRUEsUUFBTWEsdUJBQXVCQSxNQUFNO0FBQ2pDLFFBQUl6RyxlQUFlO0FBQ2pCLGFBQU9aLFVBQVVzSCxPQUFPLENBQUNDLE1BQU1BLEVBQUU3RyxpQkFBaUIsS0FBSztBQUN6RCxRQUFJRSxlQUFlO0FBQ2pCLGFBQU9aLFVBQVVzSCxPQUFPLENBQUNDLE1BQU1BLEVBQUU3RyxpQkFBaUIsS0FBSztBQUN6RCxRQUFJRSxlQUFlO0FBQ2pCLGFBQU9aLFVBQVVzSCxPQUFPLENBQUNDLE1BQU1BLEVBQUU3RyxpQkFBaUIsT0FBTztBQUMzRCxRQUFJRSxlQUFlO0FBQ2pCLGFBQU9aLFVBQVVzSCxPQUFPLENBQUNDLE1BQU1BLEVBQUU3RyxpQkFBaUIsT0FBTztBQUMzRCxXQUFPVjtBQUFBQSxFQUNUO0FBRUEsUUFBTXdILHFCQUFxQkgscUJBQXFCLEVBQUVJLElBQUksQ0FBQ0MsVUFBVTtBQUFBLElBQy9ELEdBQUdBO0FBQUFBLElBRUhDLFNBQ0U7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFFBQVEsTUFBTWxDLGVBQWVpQyxJQUFJO0FBQUEsUUFDakMsVUFBVSxNQUFNN0gsa0JBQWtCNkgsS0FBS3RGLEdBQUc7QUFBQTtBQUFBLE1BRjVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUU4QztBQUFBLElBSWhEd0YsZUFBZUYsS0FBS2hIO0FBQUFBLElBRXBCK0MsTUFBTWlFLEtBQUtqRSxPQUFPcEosTUFBTXFOLEtBQUtqRSxJQUFJLEVBQUVnQixPQUFPLFlBQVksSUFBSTtBQUFBLElBRTFEL0QsY0FDRWdILEtBQUtoSCxpQkFBaUIsUUFDbEIsaUJBQ0FnSCxLQUFLaEgsaUJBQWlCLFFBQ3BCLHNCQUNBZ0gsS0FBS2hILGlCQUFpQixVQUNwQixVQUNBZ0gsS0FBS2hILGlCQUFpQixVQUNwQixVQUNBO0FBQUEsRUFDZCxFQUFFO0FBRUYsUUFBTW1ILFNBQVM7QUFBQSxJQUNiQyxLQUFLOUgsVUFBVTZDO0FBQUFBLElBQ2ZrRixLQUFLL0gsVUFBVXNILE9BQU8sQ0FBQ3BMLE1BQU1BLEVBQUV3RSxpQkFBaUIsS0FBSyxFQUFFbUM7QUFBQUEsSUFDdkRtRixVQUFVaEksVUFBVXNILE9BQU8sQ0FBQ3BMLE1BQU1BLEVBQUV3RSxpQkFBaUIsS0FBSyxFQUFFbUM7QUFBQUEsSUFDNURvRixPQUFPakksVUFBVXNILE9BQU8sQ0FBQ3BMLE1BQU1BLEVBQUV3RSxpQkFBaUIsT0FBTyxFQUFFbUM7QUFBQUEsSUFDM0RxRixPQUFPbEksVUFBVXNILE9BQU8sQ0FBQ3BMLE1BQU1BLEVBQUV3RSxpQkFBaUIsT0FBTyxFQUFFbUM7QUFBQUEsSUFDM0RzRixLQUFLbkksVUFBVXNILE9BQU8sQ0FBQ3BMLE1BQU1BLEVBQUU4SSxlQUFlLEtBQUssRUFBRW5DO0FBQUFBLElBQ3JEdUYsTUFBTXBJLFVBQVVzSCxPQUFPLENBQUNwTCxNQUFNQSxFQUFFOEksZUFBZSxNQUFNLEVBQUVuQztBQUFBQSxJQUN2RHdGLFdBQVdySSxVQUFVc0gsT0FBTyxDQUFDcEwsTUFBTUEsRUFBRThJLGVBQWUsV0FBVyxFQUFFbkM7QUFBQUEsRUFDbkU7QUFFQSxRQUFNeUYsV0FBVztBQUFBLElBQ2YsRUFBRTdCLEtBQUssT0FBTzVJLE9BQU8sUUFBUWdLLE9BQU9DLEdBQUcsS0FBS1MsVUFBVSxLQUFLO0FBQUEsSUFDM0QsRUFBRTlCLEtBQUssT0FBTzVJLE9BQU8saUJBQWlCZ0ssT0FBT0UsR0FBRyxLQUFLUSxVQUFVLEtBQUs7QUFBQSxJQUNwRTtBQUFBLE1BQ0U5QixLQUFLO0FBQUEsTUFDTDVJLE9BQU8sc0JBQXNCZ0ssT0FBT0csUUFBUTtBQUFBLE1BQzVDTyxVQUFVO0FBQUEsSUFDWjtBQUFBLElBQ0EsRUFBRTlCLEtBQUssU0FBUzVJLE9BQU8sVUFBVWdLLE9BQU9JLEtBQUssS0FBS00sVUFBVSxLQUFLO0FBQUEsSUFDakUsRUFBRTlCLEtBQUssU0FBUzVJLE9BQU8sVUFBVWdLLE9BQU9LLEtBQUssS0FBS0ssVUFBVSxLQUFLO0FBQUEsRUFBQztBQUdwRSxRQUFNQyxpQkFBaUJBLENBQUNDLFNBQVMsVUFBVTtBQUN6QyxVQUFNQyxJQUFJRCxTQUFTbEosV0FBV0o7QUFDOUIsVUFBTXdHLEtBQUs4QyxTQUFTL0ksbUJBQW1CZ0I7QUFDdkMsVUFBTWlJLGFBQWFGLFNBQ2Z0QywrQkFDQTlCO0FBQ0osVUFBTXVFLFlBQVlILFNBQVN2QywyQkFBMkJ4QztBQUV0RCxXQUNFLG1DQUNFO0FBQUE7QUFBQSxRQUFDLEtBQUs7QUFBQSxRQUFMO0FBQUEsVUFDQyxPQUFNO0FBQUEsVUFDTixNQUFLO0FBQUEsVUFDTCxPQUFPLENBQUMsRUFBRW1GLFVBQVUsTUFBTUMsU0FBUywwQkFBMEIsQ0FBQztBQUFBLFVBQzlELFdBQVU7QUFBQSxVQUVWO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxhQUFZO0FBQUEsY0FDWjtBQUFBLGNBQ0EsV0FBVTtBQUFBO0FBQUEsWUFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFHdUY7QUFBQTtBQUFBLFFBVHpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVdBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsaUVBQ2I7QUFBQSwrQkFBQyxPQUFFLFdBQVUseUNBQXdDO0FBQUE7QUFBQSxVQUNyQyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDO0FBQUEsYUFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sU0FBU25EO0FBQUFBLGNBQ1QsT0FBTTtBQUFBLGNBQ04sYUFBWTtBQUFBLGNBQ1osTUFBTWhMO0FBQUFBLGNBQ04sVUFBVWdPO0FBQUFBO0FBQUFBLFlBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTXVCO0FBQUEsVUFFdkI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLFNBQVNoRDtBQUFBQSxjQUNULE9BQU07QUFBQSxjQUNOLGFBQVk7QUFBQSxjQUNaLE1BQU0vSztBQUFBQSxjQUNOLFVBQVUrTjtBQUFBQTtBQUFBQSxZQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU11QjtBQUFBLFVBRXZCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixTQUFTaEQ7QUFBQUEsY0FDVCxPQUFNO0FBQUEsY0FDTixhQUFZO0FBQUEsY0FDWixNQUFNOUs7QUFBQUEsY0FDTixVQUFVOE47QUFBQUE7QUFBQUEsWUFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFNdUI7QUFBQSxVQUV2QjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sU0FBU2hEO0FBQUFBLGNBQ1QsT0FBTTtBQUFBLGNBQ04sYUFBWTtBQUFBLGNBQ1osTUFBTTdLO0FBQUFBLGNBQ04sVUFBVTZOO0FBQUFBO0FBQUFBLFlBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTXVCO0FBQUEsYUEvQnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQ0E7QUFBQSxXQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0NBO0FBQUEsTUFFQ2hELE9BQU8sU0FDTix1QkFBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsVUFBUztBQUFBLFlBQ1QsS0FBSTtBQUFBLFlBQ0osT0FBTTtBQUFBO0FBQUEsVUFIUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHOEI7QUFBQSxRQUU5Qix1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQTtBQUFBLFlBQUMsS0FBSztBQUFBLFlBQUw7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLE1BQUs7QUFBQSxjQUNMLE9BQU8sQ0FBQyxFQUFFa0QsVUFBVSxNQUFNQyxTQUFTLFlBQVksQ0FBQztBQUFBLGNBQ2hELFdBQVU7QUFBQSxjQUVWO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLGFBQVk7QUFBQSxrQkFDWixXQUFVO0FBQUE7QUFBQSxnQkFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FFd0I7QUFBQTtBQUFBLFlBUjFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVVBO0FBQUEsVUFDQTtBQUFBLFlBQUMsS0FBSztBQUFBLFlBQUw7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLE1BQUs7QUFBQSxjQUNMLE9BQU87QUFBQSxnQkFDTCxFQUFFRCxVQUFVLE1BQU1DLFNBQVMsWUFBWTtBQUFBLGdCQUN2QztBQUFBLGtCQUNFQyxTQUFTO0FBQUEsa0JBQ1RELFNBQVM7QUFBQSxnQkFDWDtBQUFBLGNBQUM7QUFBQSxjQUVILFdBQVU7QUFBQSxjQUVWO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLGFBQVk7QUFBQSxrQkFDWixXQUFVO0FBQUEsa0JBQ1YsV0FBVztBQUFBLGtCQUNYLFNBQVMsQ0FBQzVNLE1BQU07QUFDZEEsc0JBQUVHLE9BQU95QixRQUFRNUIsRUFBRUcsT0FBT3lCLE1BQU1rTCxRQUFRLFdBQVcsRUFBRTtBQUFBLGtCQUN2RDtBQUFBO0FBQUEsZ0JBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUk7QUFBQTtBQUFBLFlBbEJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQW9CQTtBQUFBLGFBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQ0E7QUFBQSxRQUNBO0FBQUEsVUFBQyxLQUFLO0FBQUEsVUFBTDtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sTUFBSztBQUFBLFlBQ0wsT0FBTyxDQUFDLEVBQUVILFVBQVUsTUFBTUMsU0FBUyxZQUFZLENBQUM7QUFBQSxZQUNoRCxXQUFVO0FBQUEsWUFFVixpQ0FBQyxVQUFPLGFBQVksbUJBQ2pCO0FBQUEsY0FDQztBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxZQUFPLEVBQ1ByQjtBQUFBQSxjQUFJLENBQUNoTCxNQUNMLHVCQUFDLFVBQWUsT0FBT0EsR0FDcEJBLGVBRFVBLEdBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLFlBQ0QsS0FYSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUE7QUFBQSxVQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFtQkE7QUFBQSxXQTNERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNERBO0FBQUEsTUFHRGtKLE9BQU8sY0FDTix1QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsVUFBUztBQUFBLFlBQ1QsS0FBSTtBQUFBLFlBQ0osT0FBTTtBQUFBO0FBQUEsVUFIUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHbUM7QUFBQSxRQUVuQztBQUFBLFVBQUMsS0FBSztBQUFBLFVBQUw7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE1BQUs7QUFBQSxZQUNMLE9BQU8sQ0FBQyxFQUFFa0QsVUFBVSxNQUFNQyxTQUFTLDRCQUE0QixDQUFDO0FBQUEsWUFDaEUsV0FBVTtBQUFBLFlBRVY7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQztBQUFBLGdCQUNBLGFBQVk7QUFBQSxnQkFDWixVQUFVRjtBQUFBQSxnQkFDVixjQUFjLENBQUNLLE9BQU9DLFlBQ25CQSxRQUFRckwsU0FBUyxJQUNmc0wsWUFBWSxFQUNaQyxTQUFTSCxNQUFNRSxZQUFZLENBQUM7QUFBQSxnQkFFakMsU0FBUzdJO0FBQUFBLGdCQUNULFlBQVksdUJBQUMsWUFBUyxNQUFNLElBQUksV0FBVSxvQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEM7QUFBQSxnQkFDMUQsU0FBU0YsTUFBTXFILElBQUksQ0FBQzlELE9BQU87QUFBQSxrQkFDekI3RixPQUFPNkYsRUFBRXZCO0FBQUFBLGtCQUNUdkUsT0FBTyxHQUFHOEYsRUFBRU0sYUFBYU4sRUFBRXRCLFFBQVEsU0FBUyxNQUFNc0IsRUFBRVEsZ0JBQWdCUixFQUFFUyxVQUFVLFVBQVU7QUFBQSxnQkFDNUYsRUFBRTtBQUFBO0FBQUEsY0FkSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFjTTtBQUFBO0FBQUEsVUFwQlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBc0JBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQTtBQUFBLFlBQUMsS0FBSztBQUFBLFlBQUw7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLE1BQUs7QUFBQSxjQUNMLE9BQU8sQ0FBQyxFQUFFeUUsVUFBVSxNQUFNQyxTQUFTLFlBQVksQ0FBQztBQUFBLGNBQ2hELFdBQVU7QUFBQSxjQUVWO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDO0FBQUEsa0JBQ0EsYUFBWTtBQUFBLGtCQUNaLFdBQVU7QUFBQTtBQUFBLGdCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUd1RTtBQUFBO0FBQUEsWUFUekU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV0E7QUFBQSxVQUNBO0FBQUEsWUFBQyxLQUFLO0FBQUEsWUFBTDtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sTUFBSztBQUFBLGNBQ0wsT0FBTyxDQUFDLEVBQUVELFVBQVUsTUFBTUMsU0FBUyxZQUFZLENBQUM7QUFBQSxjQUNoRCxXQUFVO0FBQUEsY0FFVjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQztBQUFBLGtCQUNBLGFBQVk7QUFBQSxrQkFDWixXQUFVO0FBQUE7QUFBQSxnQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FHdUU7QUFBQTtBQUFBLFlBVHpFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVdBO0FBQUEsVUFDQTtBQUFBLFlBQUMsS0FBSztBQUFBLFlBQUw7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUVWO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDO0FBQUEsa0JBQ0EsYUFBWTtBQUFBLGtCQUNaLFdBQVU7QUFBQTtBQUFBLGdCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUd1RTtBQUFBO0FBQUEsWUFSekU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxVQUNBO0FBQUEsWUFBQyxLQUFLO0FBQUEsWUFBTDtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBRVY7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0M7QUFBQSxrQkFDQSxhQUFZO0FBQUEsa0JBQ1osV0FBVTtBQUFBO0FBQUEsZ0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBR3VFO0FBQUE7QUFBQSxZQVJ6RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLGFBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErQ0E7QUFBQSxRQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE1BQUssY0FBYSxRQUFNLE1BQ2pDLGlDQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFNLEtBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQTtBQUFBLFVBQUMsS0FBSztBQUFBLFVBQUw7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE1BQUs7QUFBQSxZQUNMLE9BQU8sQ0FBQyxFQUFFRCxVQUFVLE1BQU1DLFNBQVMsWUFBWSxDQUFDO0FBQUEsWUFDaEQsV0FBVTtBQUFBLFlBRVYsaUNBQUMsVUFBTyxhQUFZLG1CQUNqQjtBQUFBLGNBQ0M7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxZQUFRLEVBQ1JyQjtBQUFBQSxjQUFJLENBQUNoTCxNQUNMLHVCQUFDLFVBQWUsT0FBT0EsR0FDcEJBLGVBRFVBLEdBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLFlBQ0QsS0FoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQTtBQUFBLFVBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXdCQTtBQUFBLFdBeEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5R0E7QUFBQSxNQUdEa0osT0FBTyxXQUNOLHVCQUFDLFNBQUksV0FBVSwyREFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxVQUFTO0FBQUEsWUFDVCxLQUFJO0FBQUEsWUFDSixPQUFNO0FBQUE7QUFBQSxVQUhSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUd1QjtBQUFBLFFBRXZCLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBO0FBQUEsWUFBQyxLQUFLO0FBQUEsWUFBTDtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sTUFBSztBQUFBLGNBQ0wsT0FBTyxDQUFDLEVBQUVrRCxVQUFVLE1BQU1DLFNBQVMsWUFBWSxDQUFDO0FBQUEsY0FDaEQsV0FBVTtBQUFBLGNBRVYsaUNBQUMsU0FBTSxhQUFZLG9CQUFtQixXQUFVLGdCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0RDtBQUFBO0FBQUEsWUFOOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxVQUNBO0FBQUEsWUFBQyxLQUFLO0FBQUEsWUFBTDtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sTUFBSztBQUFBLGNBQ0wsT0FBTztBQUFBLGdCQUNMLEVBQUVELFVBQVUsTUFBTTtBQUFBLGdCQUNsQixFQUFFRSxTQUFTLGVBQWVELFNBQVMsb0JBQW9CO0FBQUEsY0FBQztBQUFBLGNBRTFELFdBQVU7QUFBQSxjQUVWO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLGFBQVk7QUFBQSxrQkFDWixXQUFVO0FBQUEsa0JBQ1YsV0FBVztBQUFBLGtCQUNYLFNBQVMsQ0FBQzVNLE1BQU07QUFDZEEsc0JBQUVHLE9BQU95QixRQUFRNUIsRUFBRUcsT0FBT3lCLE1BQU1rTCxRQUFRLFdBQVcsRUFBRTtBQUFBLGtCQUN2RDtBQUFBO0FBQUEsZ0JBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUk7QUFBQTtBQUFBLFlBZk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBaUJBO0FBQUEsYUExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJCQTtBQUFBLFFBQ0E7QUFBQSxVQUFDLEtBQUs7QUFBQSxVQUFMO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixNQUFLO0FBQUEsWUFDTCxPQUFPLENBQUMsRUFBRUgsVUFBVSxNQUFNQyxTQUFTLFlBQVksQ0FBQztBQUFBLFlBQ2hELFdBQVU7QUFBQSxZQUVWLGlDQUFDLFVBQU8sYUFBWSxtQkFDakI7QUFBQSxjQUNDO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxZQUFRLEVBQ1JyQjtBQUFBQSxjQUFJLENBQUNoTCxNQUNMLHVCQUFDLFVBQWUsT0FBT0EsR0FDcEJBLGVBRFVBLEdBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLFlBQ0QsS0FaSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWFBO0FBQUE7QUFBQSxVQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFvQkE7QUFBQSxXQXRERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdURBO0FBQUEsTUFHRGtKLE9BQU8sV0FDTix1QkFBQyxTQUFJLFdBQVUseURBQ2I7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsVUFBUztBQUFBLFlBQ1QsS0FBSTtBQUFBLFlBQ0osT0FBTTtBQUFBO0FBQUEsVUFIUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHdUI7QUFBQSxRQUV2Qix1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQTtBQUFBLFlBQUMsS0FBSztBQUFBLFlBQUw7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLE1BQUs7QUFBQSxjQUNMLE9BQU8sQ0FBQyxFQUFFa0QsVUFBVSxNQUFNQyxTQUFTLFlBQVksQ0FBQztBQUFBLGNBQ2hELFdBQVU7QUFBQSxjQUVWLGlDQUFDLFNBQU0sYUFBWSxvQkFBbUIsV0FBVSxnQkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEQ7QUFBQTtBQUFBLFlBTjlEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsVUFDQTtBQUFBLFlBQUMsS0FBSztBQUFBLFlBQUw7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLE1BQUs7QUFBQSxjQUNMLE9BQU87QUFBQSxnQkFDTCxFQUFFRCxVQUFVLE1BQU1DLFNBQVMsWUFBWTtBQUFBLGdCQUN2QyxFQUFFQyxTQUFTLGdCQUFnQkQsU0FBUyxzQ0FBc0M7QUFBQSxjQUFDO0FBQUEsY0FFN0UsV0FBVTtBQUFBLGNBRVY7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsYUFBWTtBQUFBLGtCQUNaLFdBQVU7QUFBQSxrQkFDVixXQUFXO0FBQUEsa0JBQ1gsU0FBUyxDQUFDNU0sTUFBTTtBQUNkQSxzQkFBRUcsT0FBT3lCLFFBQVE1QixFQUFFRyxPQUFPeUIsTUFBTWtMLFFBQVEsV0FBVyxFQUFFO0FBQUEsa0JBQ3ZEO0FBQUE7QUFBQSxnQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNSTtBQUFBO0FBQUEsWUFmTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFpQkE7QUFBQSxhQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkJBO0FBQUEsUUFDQTtBQUFBLFVBQUMsS0FBSztBQUFBLFVBQUw7QUFBQSxZQUNDLE9BQU07QUFBQSxZQUNOLE1BQUs7QUFBQSxZQUNMLE9BQU8sQ0FBQyxFQUFFSCxVQUFVLE1BQU1DLFNBQVMsWUFBWSxDQUFDO0FBQUEsWUFDaEQsV0FBVTtBQUFBLFlBRVYsaUNBQUMsVUFBTyxhQUFZLHNCQUNqQjtBQUFBLGNBQ0M7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLFlBQVEsRUFDUnJCO0FBQUFBLGNBQUksQ0FBQ2hMLE1BQ0wsdUJBQUMsVUFBZSxPQUFPQSxHQUNwQkEsZUFEVUEsR0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsWUFDRCxLQWZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0JBO0FBQUE7QUFBQSxVQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUF1QkE7QUFBQSxRQUNBO0FBQUEsVUFBQyxLQUFLO0FBQUEsVUFBTDtBQUFBLFlBQ0MsT0FBTTtBQUFBLFlBQ04sTUFBSztBQUFBLFlBQ0wsT0FBTyxDQUFDLEVBQUVvTSxVQUFVLE1BQU1DLFNBQVMsWUFBWSxDQUFDO0FBQUEsWUFDaEQsV0FBVTtBQUFBLFlBRVYsaUNBQUMsVUFBTyxhQUFZLG1CQUNqQjtBQUFBLGNBQ0M7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxZQUFRLEVBQ1JyQjtBQUFBQSxjQUFJLENBQUNoTCxNQUNMLHVCQUFDLFVBQWUsT0FBT0EsR0FDcEJBLGVBRFVBLEdBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLFlBQ0QsS0FiSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWNBO0FBQUE7QUFBQSxVQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFxQkE7QUFBQSxXQS9FRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0ZBO0FBQUEsTUFHRix1QkFBQyxTQUFJLFdBQVUsaUVBQ2IsaUNBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUE7QUFBQSxVQUFDLEtBQUs7QUFBQSxVQUFMO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixNQUFLO0FBQUEsWUFDTCxPQUFPO0FBQUEsY0FDTCxFQUFFb00sVUFBVSxNQUFNQyxTQUFTLDhCQUE4QjtBQUFBLFlBQUM7QUFBQSxZQUU1RCxXQUFVO0FBQUEsWUFFVjtBQUFBLGNBQUMsTUFBTTtBQUFBLGNBQU47QUFBQSxnQkFDQyxNQUFNO0FBQUEsZ0JBQ04sYUFBWTtBQUFBLGdCQUNaLFdBQVU7QUFBQTtBQUFBLGNBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBR29DO0FBQUE7QUFBQSxVQVh0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFhQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBO0FBQUEsWUFBQyxLQUFLO0FBQUEsWUFBTDtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sTUFBSztBQUFBLGNBQ0wsT0FBTyxDQUFDLEVBQUVELFVBQVUsTUFBTUMsU0FBUyx3QkFBd0IsQ0FBQztBQUFBLGNBQzVELFdBQVU7QUFBQSxjQUVWLGlDQUFDLGNBQVcsV0FBVSx1QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUM7QUFBQTtBQUFBLFlBTjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsVUFDQTtBQUFBLFlBQUMsS0FBSztBQUFBLFlBQUw7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLE1BQUs7QUFBQSxjQUNMLE9BQU8sQ0FBQyxFQUFFRCxVQUFVLE1BQU1DLFNBQVMsMEJBQTBCLENBQUM7QUFBQSxjQUM5RCxXQUFVO0FBQUEsY0FFVixpQ0FBQyxVQUFPLGFBQVksdUJBQ2xCO0FBQUEsdUNBQUMsVUFBTyxPQUFNLE9BQ1osaUNBQUMsVUFBSyxXQUFVLGtDQUNkO0FBQUEseUNBQUMsVUFBSyxXQUFVLGtEQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE4RDtBQUFBLGtCQUM5RDtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFNO0FBQUEsc0JBQ04sV0FBVTtBQUFBO0FBQUEsb0JBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUUwQjtBQUFBO0FBQUEscUJBSjVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVNBO0FBQUEsZ0JBQ0EsdUJBQUMsVUFBTyxPQUFNLFFBQ1osaUNBQUMsVUFBSyxXQUFVLGtDQUNkO0FBQUEseUNBQUMsVUFBSyxXQUFVLG1EQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErRDtBQUFBLGtCQUMvRCx1QkFBQyxZQUFTLE1BQU0sSUFBSSxXQUFVLG1CQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE2QztBQUFBLGtCQUFHO0FBQUEscUJBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUEsS0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU1BO0FBQUEsZ0JBQ0EsdUJBQUMsVUFBTyxPQUFNLGFBQ1osaUNBQUMsVUFBSyxXQUFVLGtDQUNkO0FBQUEseUNBQUMsVUFBSyxXQUFVLHFEQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpRTtBQUFBLGtCQUNqRSx1QkFBQyxhQUFVLE1BQU0sSUFBSSxXQUFVLHFCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnRDtBQUFBLGtCQUFHO0FBQUEscUJBRnJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUEsS0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU1BO0FBQUEsbUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeUJBO0FBQUE7QUFBQSxZQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFnQ0E7QUFBQSxhQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMENBO0FBQUEsV0F6REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBEQSxLQTNERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNERBO0FBQUEsU0E5YUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQSthQTtBQUFBLEVBRUo7QUFHQSxTQUNFLG1DQUNHL0o7QUFBQUE7QUFBQUEsSUFHRCx1QkFBQyxTQUFJLFdBQVUsNkNBQ2I7QUFBQSw2QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BR1IsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsK0JBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQU87QUFBQSxRQUNQLHVCQUFDLFNBQUksV0FBVSwrQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSw4RUFDYixpQ0FBQyxXQUFRLE1BQU0sSUFBSSxXQUFVLGdCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5QyxLQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsUUFBRyxXQUFVLHdEQUF1RCxtQ0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsT0FBRSxXQUFVLGlDQUFnQywrRUFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTd0U7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFNBQU0sTUFBTSxNQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdCO0FBQUEsZ0JBQUc7QUFBQTtBQUFBO0FBQUEsWUFKckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUJBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsT0FBTTtBQUFBLGNBQ04sT0FBT3NFLE9BQU9DO0FBQUFBLGNBQ2QsWUFBVztBQUFBLGNBQ1gsU0FBUTtBQUFBLGNBQ1IsTUFBTTNNO0FBQUFBO0FBQUFBLFlBTFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS21CO0FBQUEsVUFFbkI7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLE9BQU8wTSxPQUFPRTtBQUFBQSxjQUNkLFlBQVc7QUFBQSxjQUNYLFNBQVE7QUFBQSxjQUNSLE1BQU1wTjtBQUFBQTtBQUFBQSxZQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtpQjtBQUFBLFVBRWpCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixPQUFPa04sT0FBT0c7QUFBQUEsY0FDZCxZQUFXO0FBQUEsY0FDWCxTQUFRO0FBQUEsY0FDUixNQUFNcE47QUFBQUE7QUFBQUEsWUFMUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLZTtBQUFBLFVBRWY7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE9BQU07QUFBQSxjQUNOLE9BQU9pTixPQUFPSTtBQUFBQSxjQUNkLFlBQVc7QUFBQSxjQUNYLFNBQVE7QUFBQSxjQUNSLE1BQU1wTjtBQUFBQTtBQUFBQSxZQUxSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtvQjtBQUFBLFVBRXBCO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixPQUFPZ04sT0FBT0s7QUFBQUEsY0FDZCxZQUFXO0FBQUEsY0FDWCxTQUFRO0FBQUEsY0FDUixNQUFNcE47QUFBQUE7QUFBQUEsWUFMUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLNkI7QUFBQSxhQWxDL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlEQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDhEQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLHlDQUF3QyxxQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsVUFBSyxXQUFVLGdHQUNiME07QUFBQUEsaUNBQW1CM0U7QUFBQUEsY0FBTztBQUFBLGlCQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBV2pDO0FBQUFBLGNBQ1gsVUFBVUM7QUFBQUEsY0FDVixPQUFPeUg7QUFBQUEsY0FDUCxXQUFVO0FBQUE7QUFBQSxZQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlrQjtBQUFBLFVBR2pCcEksbUJBQ0MsdUJBQUMsU0FBSSxXQUFVLHlDQUNiLGlDQUFDLGtCQUFlLFdBQVcsUUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0MsS0FEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxJQUNFc0gsbUJBQW1CM0UsV0FBVyxJQUNoQyx1QkFBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSxtQ0FBQyxXQUFRLE1BQU0sSUFBSSxXQUFVLG9CQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QztBQUFBLFlBQzdDLHVCQUFDLE9BQUUsV0FBVSxzQ0FBcUMsa0NBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSwwQkFBeUIsNERBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUEsSUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTTJFO0FBQUFBLGNBQ04sU0FBU1Isa0JBQWtCcEcsVUFBVTtBQUFBLGNBQ3JDLFlBQVlvRyxrQkFBa0JwRyxVQUFVLEVBQUUwRztBQUFBQSxnQkFDeEMsQ0FBQzdKLE1BQU1BLEVBQUVnSixRQUFRO0FBQUEsY0FDbkI7QUFBQSxjQUNBLGtCQUFrQixrQkFBa0I3RixVQUFVO0FBQUEsY0FDOUMsaUJBQWlCLG9CQUFvQkEsVUFBVTtBQUFBLGNBQy9DLGlCQUFpQjtBQUFBO0FBQUEsWUFSbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUXdCO0FBQUEsYUF4QzVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyQ0E7QUFBQSxXQS9IRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0lBO0FBQUEsU0FwSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFJQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVczQjtBQUFBQSxRQUNYLFNBQVMsTUFBTUMsZUFBZSxLQUFLO0FBQUEsUUFFbkMsaUNBQUMsU0FBSSxXQUFVLFdBRWI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsOEVBQ2IsaUNBQUMsV0FBUSxNQUFNLElBQUksV0FBVSxnQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUMsS0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUEsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFFBQUcsV0FBVSx1REFBc0QsZ0NBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVBLHVCQUFDLE9BQUUsV0FBVSx3Q0FBdUMsdURBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWNBO0FBQUEsVUFFQSx1QkFBQyxRQUFLLE1BQVksUUFBTyxZQUFXLFVBQ2pDc0o7QUFBQUEsMkJBQWUsS0FBSztBQUFBLFlBRXJCLHVCQUFDLEtBQUssTUFBTCxFQUFVLFdBQVUsYUFDbkI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsVUFBUztBQUFBLGdCQUNUO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUEyRTtBQUFBO0FBQUEsY0FKdkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsYUEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdDQTtBQUFBO0FBQUEsTUFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBcUNBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV25KO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JDLDZCQUFtQixLQUFLO0FBQ3hCQyxtQkFBU2lFLFlBQVk7QUFBQSxRQUN2QjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLFdBRWI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsdUVBQ2IsaUNBQUMsVUFBTyxNQUFNLElBQUksV0FBVSxnQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0MsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUEsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFFBQUcsV0FBVSx1REFBc0QsaUNBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVBLHVCQUFDLE9BQUUsV0FBVSx3Q0FBdUMsdURBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWNBO0FBQUEsVUFFQSx1QkFBQyxRQUFLLE1BQU1qRSxVQUFVLFFBQU8sWUFBVyxVQUFVNkcsY0FDL0NvQztBQUFBQSwyQkFBZSxJQUFJO0FBQUEsWUFFcEIsdUJBQUMsS0FBSyxNQUFMLEVBQVUsV0FBVSxhQUNuQjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxVQUFTO0FBQUEsZ0JBQ1Q7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBQStFO0FBQUE7QUFBQSxjQUozRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxlQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxhQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0NBO0FBQUE7QUFBQSxNQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF3Q0E7QUFBQSxJQUlBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxRQUFRLENBQUMsQ0FBQzVJO0FBQUFBLFFBQ1YsU0FBUyxNQUFNQyxrQkFBa0IsSUFBSTtBQUFBLFFBQ3JDLFdBQVd5RztBQUFBQSxRQUNYLFNBQVN4RztBQUFBQTtBQUFBQSxNQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUl5QjtBQUFBLE9BcE8zQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc09BO0FBRUo7QUFBQ2pCLElBbHJDUUQsYUFBVztBQUFBLFVBQ1dqRixhQUFhcUYsaUJBRzNCcEYsS0FBS3dGLFNBR0R4RixLQUFLd0YsT0FBTztBQUFBO0FBQUFpSyxNQVB4QnpLO0FBb3JDVCxlQUFlQTtBQXdxQmYsSUFBQWxDLElBQUFNLEtBQUFXLEtBQUFNLEtBQUFLLEtBQUFLLEtBQUEwSztBQUFBQyxhQUFBNU0sSUFBQTtBQUFBNE0sYUFBQXRNLEtBQUE7QUFBQXNNLGFBQUEzTCxLQUFBO0FBQUEyTCxhQUFBckwsS0FBQTtBQUFBcUwsYUFBQWhMLEtBQUE7QUFBQWdMLGFBQUEzSyxLQUFBO0FBQUEySyxhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlUmVmIiwibm90aWZpY2F0aW9uIiwiRm9ybSIsIklucHV0IiwiRGF0ZVBpY2tlciIsIkJ1dHRvbiIsIlNlbGVjdCIsIlRhYnMiLCJBUEkiLCJEYXRhVGFibGUiLCJDaXJjdWxhckxvYWRlciIsImRheWpzIiwiTW9kYWwiLCJOYXZiYXIiLCJTaWRlYmFyIiwiTWRQaG9uZSIsIk1kQWRkIiwiTWRQZXJzb24iLCJNZExvb3AiLCJNZFBlb3BsZUFsdCIsIk1kQWRtaW5QYW5lbFNldHRpbmdzIiwiTWRMb2NhbEZpcmVEZXBhcnRtZW50IiwiTWRBY1VuaXQiLCJNZEZsYXNoT24iLCJNZEluYm94IiwiTWRCYXJDaGFydCIsIk1kU2VhcmNoIiwiTWRNb3JlVmVydCIsIk1kRWRpdCIsIk1kRGVsZXRlIiwiT3B0aW9uIiwiQWN0aW9uTWVudSIsIm9uRWRpdCIsIm9uRGVsZXRlIiwiX3MiLCJvcGVuIiwic2V0T3BlbiIsInVzZVN0YXRlIiwicmVmIiwiaGFuZGxlciIsImUiLCJjdXJyZW50IiwiY29udGFpbnMiLCJ0YXJnZXQiLCJkb2N1bWVudCIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwidiIsIl9jIiwiRGVsZXRlQ29uZmlybU1vZGFsIiwiaXNPcGVuIiwib25DbG9zZSIsIm9uQ29uZmlybSIsImxvYWRpbmciLCJfYzIiLCJDYWxsU3RhdHVzQmFkZ2UiLCJzdGF0dXMiLCJjb25maWciLCJIb3QiLCJjbHMiLCJkb3QiLCJDb2xkIiwiRW1lcmdlbmN5IiwiYyIsIkljb24iLCJfYzMiLCJTdGF0Q2FyZCIsImxhYmVsIiwidmFsdWUiLCJjb2xvckNsYXNzIiwiYmdDbGFzcyIsIl9jNCIsIlR5cGVQaWxsIiwiYWN0aXZlQ2xhc3MiLCJvbkNoYW5nZSIsImFjdGl2ZSIsIl9jNSIsIlNlY3Rpb25MYWJlbCIsInRhZ0NsYXNzIiwidGFnIiwidGl0bGUiLCJfYzYiLCJFbnF1aXJlQ2FsbCIsIl9zMiIsImFwaSIsImNvbnRleHRIb2xkZXIiLCJ1c2VOb3RpZmljYXRpb24iLCJpc01vZGFsT3BlbiIsInNldElzTW9kYWxPcGVuIiwiZm9ybSIsInVzZUZvcm0iLCJpc0VkaXRNb2RhbE9wZW4iLCJzZXRJc0VkaXRNb2RhbE9wZW4iLCJlZGl0Rm9ybSIsImVkaXRpbmdSZWNvcmQiLCJzZXRFZGl0aW5nUmVjb3JkIiwiZWRpdEN1c3RvbWVyVHlwZSIsInNldEVkaXRDdXN0b21lclR5cGUiLCJkZWxldGVUYXJnZXRJZCIsInNldERlbGV0ZVRhcmdldElkIiwiZGVsZXRlTG9hZGluZyIsInNldERlbGV0ZUxvYWRpbmciLCJlbnF1aXJpZXMiLCJzZXRFbnF1aXJpZXMiLCJsb2FkaW5nRW5xdWlyaWVzIiwic2V0TG9hZGluZ0VucXVpcmllcyIsInVzZXJzIiwic2V0VXNlcnMiLCJsb2FkaW5nVXNlcnMiLCJzZXRMb2FkaW5nVXNlcnMiLCJhZG1pbk5hbWUiLCJzZXRBZG1pbk5hbWUiLCJjdXN0b21lclR5cGUiLCJzZXRDdXN0b21lclR5cGUiLCJlbnF1aXJ5VGFiIiwic2V0RW5xdWlyeVRhYiIsIm5vdGlmeSIsInR5cGUiLCJkZXNjcmlwdGlvbiIsInBsYWNlbWVudCIsImR1cmF0aW9uIiwiZ2V0Q29udGFpbmVyIiwiYm9keSIsInN0eWxlIiwibGluZUhlaWdodCIsImZldGNoRW5xdWlyaWVzIiwicmVzIiwiZ2V0IiwiZGF0YSIsImNvbnNvbGUiLCJlcnJvciIsImZldGNoQWRtaW5Qcm9maWxlIiwidXNlclN0ciIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJ1c2VyIiwiSlNPTiIsInBhcnNlIiwiX2lkIiwibmFtZSIsImFkbWluX25hbWUiLCJzZXRGaWVsZHNWYWx1ZSIsImZldGNoVXNlcnMiLCJmZXRjaEN1c3RvbWVyRW5yb2xsbWVudHMiLCJ1c2VySWQiLCJ0YXJnZXRGb3JtIiwicG9zdCIsImxlbmd0aCIsImdyb3VwRGF0YSIsImVucm9sbG1lbnQiLCJncm91cCIsImVucm9sbG1lbnREYXRhIiwiZ3JvdXBOYW1lIiwiZ3JvdXBfbmFtZSIsInRpY2tldE51bWJlciIsInRpY2tldHMiLCJ0aWNrZXRfbnVtYmVyIiwiaGFuZGxlT3Blbk1vZGFsIiwicmVzZXRGaWVsZHMiLCJkYXRlIiwiaGFuZGxlQ3VzdG9tZXJTZWxlY3QiLCJ1IiwiZmluZCIsIngiLCJzZWFyY2hDdXN0b21lciIsImN1c3RvbWVySWQiLCJleGlzdGluZ0N1c3RvbWVyTmFtZSIsImZ1bGxfbmFtZSIsImV4aXN0aW5nQ3VzdG9tZXJQaG9uZSIsInBob25lX251bWJlciIsIm1vYmlsZSIsImhhbmRsZUN1c3RvbWVyVHlwZUNoYW5nZSIsIm9uRmluaXNoIiwidmFsdWVzIiwicGF5bG9hZCIsImZvcm1hdCIsImN1c3RvbWVyTmFtZSIsIm5ld0N1c3RvbWVyTmFtZSIsImN1c3RvbWVyUGhvbmUiLCJuZXdDdXN0b21lclBob25lIiwicHVycG9zZSIsInB1cnBvc2VOZXciLCJjYWxsU3RhdHVzIiwicHVycG9zZUV4aXN0aW5nIiwiZ3Vlc3ROYW1lIiwiZ3Vlc3RQaG9uZSIsInB1cnBvc2VHdWVzdCIsImFkbWluTmFtZV9maWVsZCIsImFkbWluUGhvbmUiLCJwdXJwb3NlQWRtaW4iLCJhZG1pbkRlcGFydG1lbnQiLCJoYW5kbGVPcGVuRWRpdCIsInJlY29yZCIsImN0IiwicGFyc2VkRGF0ZSIsImZvcm1hdHMiLCJkIiwiaXNWYWxpZCIsImZpZWxkc1RvU2V0Iiwic2V0VGltZW91dCIsImhhbmRsZUVkaXRDdXN0b21lclNlbGVjdCIsImhhbmRsZUVkaXRDdXN0b21lclR5cGVDaGFuZ2UiLCJvbkVkaXRGaW5pc2giLCJwdXQiLCJoYW5kbGVEZWxldGVDb25maXJtIiwiZGVsZXRlIiwiYWN0aW9uQ29sdW1uIiwia2V5IiwiaGVhZGVyIiwid2lkdGgiLCJtaW5XaWR0aCIsInJlbmRlciIsIl8iLCJyb3ciLCJnZXRFbnF1aXJ5Q29sdW1ucyIsInRhYiIsImJhc2UiLCJ0ZXh0IiwiY29scyIsImdldEZpbHRlcmVkRW5xdWlyaWVzIiwiZmlsdGVyIiwiaSIsImZvcm1hdHRlZEVucXVpcmllcyIsIm1hcCIsIml0ZW0iLCJhY3Rpb25zIiwiX2N1c3RvbWVyVHlwZSIsImNvdW50cyIsImFsbCIsIm5ldyIsImV4aXN0aW5nIiwiZ3Vlc3QiLCJhZG1pbiIsImhvdCIsImNvbGQiLCJlbWVyZ2VuY3kiLCJ0YWJJdGVtcyIsImNoaWxkcmVuIiwicmVuZGVyRm9ybUJvZHkiLCJpc0VkaXQiLCJmIiwib25DdENoYW5nZSIsIm9uQ3VzdFNlbCIsInJlcXVpcmVkIiwibWVzc2FnZSIsInBhdHRlcm4iLCJyZXBsYWNlIiwiaW5wdXQiLCJvcHRpb24iLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiX2M3IiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkVucXVpcmVDYWxsLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7XHJcbiAgbm90aWZpY2F0aW9uLFxyXG4gIEZvcm0sXHJcbiAgSW5wdXQsXHJcbiAgRGF0ZVBpY2tlcixcclxuICBCdXR0b24sXHJcbiAgU2VsZWN0LFxyXG4gIFRhYnMsXHJcbn0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IEFQSSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBkYXlqcyBmcm9tIFwiZGF5anNcIjtcclxuaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5cclxuaW1wb3J0IHtcclxuICBNZFBob25lLFxyXG4gIE1kQWRkLFxyXG4gIE1kUGVyc29uLFxyXG4gIE1kTG9vcCxcclxuICBNZFBlb3BsZUFsdCxcclxuICBNZEFkbWluUGFuZWxTZXR0aW5ncyxcclxuICBNZExvY2FsRmlyZURlcGFydG1lbnQsXHJcbiAgTWRBY1VuaXQsXHJcbiAgTWRGbGFzaE9uLFxyXG4gIE1kSW5ib3gsXHJcbiAgTWRCYXJDaGFydCxcclxuICBNZFNlYXJjaCxcclxuICBNZE1vcmVWZXJ0LFxyXG4gIE1kRWRpdCxcclxuICBNZERlbGV0ZSxcclxufSBmcm9tIFwicmVhY3QtaWNvbnMvbWRcIjtcclxuXHJcbmNvbnN0IHsgT3B0aW9uIH0gPSBTZWxlY3Q7XHJcblxyXG5jb25zdCBBY3Rpb25NZW51ID0gKHsgb25FZGl0LCBvbkRlbGV0ZSB9KSA9PiB7XHJcbiAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IHJlZiA9IHVzZVJlZihudWxsKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGhhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgICBpZiAocmVmLmN1cnJlbnQgJiYgIXJlZi5jdXJyZW50LmNvbnRhaW5zKGUudGFyZ2V0KSkgc2V0T3BlbihmYWxzZSk7XHJcbiAgICB9O1xyXG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlZG93blwiLCBoYW5kbGVyKTtcclxuICAgIHJldHVybiAoKSA9PiBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwibW91c2Vkb3duXCIsIGhhbmRsZXIpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBqdXN0aWZ5LWNlbnRlclwiIHJlZj17cmVmfT5cclxuICAgICAgPGJ1dHRvblxyXG4gICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE9wZW4oKHYpID0+ICF2KX1cclxuICAgICAgICBjbGFzc05hbWU9XCJ3LTggaC04IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS01MDAgaG92ZXI6Ymctc2xhdGUtMTAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcclxuICAgICAgPlxyXG4gICAgICAgIDxNZE1vcmVWZXJ0IHNpemU9ezE4fSAvPlxyXG4gICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgIHtvcGVuICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTAgei01MCBtdC0xIHctMzYgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC14bCBzaGFkb3ctbGcgb3ZlcmZsb3ctaGlkZGVuIHRvcC1mdWxsXCI+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0T3BlbihmYWxzZSk7XHJcbiAgICAgICAgICAgICAgb25FZGl0KCk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IHB4LTQgcHktMi41IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBob3ZlcjpiZy1ibHVlLTUwIGhvdmVyOnRleHQtYmx1ZS03MDAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8TWRFZGl0IHNpemU9ezE1fSBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNTAwXCIgLz5cclxuICAgICAgICAgICAgRWRpdFxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0T3BlbihmYWxzZSk7XHJcbiAgICAgICAgICAgICAgb25EZWxldGUoKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgcHgtNCBweS0yLjUgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGhvdmVyOmJnLXJlZC01MCBob3Zlcjp0ZXh0LXJlZC02MDAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8TWREZWxldGUgc2l6ZT17MTV9IGNsYXNzTmFtZT1cInRleHQtcmVkLTQwMFwiIC8+XHJcbiAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuY29uc3QgRGVsZXRlQ29uZmlybU1vZGFsID0gKHsgaXNPcGVuLCBvbkNsb3NlLCBvbkNvbmZpcm0sIGxvYWRpbmcgfSkgPT4ge1xyXG4gIGlmICghaXNPcGVuKSByZXR1cm4gbnVsbDtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYmxhY2svNDBcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBzaGFkb3cteGwgcC03IHctWzM2MHB4XSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdy0xMiBoLTEyIHJvdW5kZWQtZnVsbCBiZy1yZWQtMTAwIG14LWF1dG8gbWItNFwiPlxyXG4gICAgICAgICAgPE1kRGVsZXRlIHNpemU9ezI0fSBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIiAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LWJhc2UgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgbWItMVwiPlxyXG4gICAgICAgICAgRGVsZXRlIEVucXVpcnk/XHJcbiAgICAgICAgPC9oMz5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LXNtIHRleHQtc2xhdGUtNTAwIG1iLTZcIj5cclxuICAgICAgICAgIFRoaXMgYWN0aW9uIGNhbm5vdCBiZSB1bmRvbmUuIFRoZSByZWNvcmQgd2lsbCBiZSBwZXJtYW5lbnRseSByZW1vdmVkLlxyXG4gICAgICAgIDwvcD5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTNcIj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweS0yLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTYwMCBob3ZlcjpiZy1zbGF0ZS01MCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNvbmZpcm19XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHktMi41IHJvdW5kZWQteGwgYmctcmVkLTYwMCBob3ZlcjpiZy1yZWQtNzAwIHRleHQtd2hpdGUgdGV4dC1zbSBmb250LWJvbGQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgZGlzYWJsZWQ6b3BhY2l0eS02MFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtsb2FkaW5nID8gXCJEZWxldGluZ+KAplwiIDogXCJZZXMsIERlbGV0ZVwifVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmNvbnN0IENhbGxTdGF0dXNCYWRnZSA9ICh7IHN0YXR1cyB9KSA9PiB7XHJcbiAgY29uc3QgY29uZmlnID0ge1xyXG4gICAgSG90OiB7XHJcbiAgICAgIGNsczogXCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtYm9sZCBiZy1yZWQtMTAwIHRleHQtcmVkLTcwMCBib3JkZXIgYm9yZGVyLXJlZC0yMDBcIixcclxuICAgICAgZG90OiBcInctMS41IGgtMS41IHJvdW5kZWQtZnVsbCBiZy1yZWQtNTAwIHNocmluay0wXCIsXHJcbiAgICB9LFxyXG4gICAgQ29sZDoge1xyXG4gICAgICBjbHM6IFwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LWJvbGQgYmctYmx1ZS0xMDAgdGV4dC1ibHVlLTcwMCBib3JkZXIgYm9yZGVyLWJsdWUtMjAwXCIsXHJcbiAgICAgIGRvdDogXCJ3LTEuNSBoLTEuNSByb3VuZGVkLWZ1bGwgYmctYmx1ZS01MDAgc2hyaW5rLTBcIixcclxuICAgIH0sXHJcbiAgICBFbWVyZ2VuY3k6IHtcclxuICAgICAgY2xzOiBcImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1ib2xkIGJnLW9yYW5nZS0xMDAgdGV4dC1vcmFuZ2UtNzAwIGJvcmRlciBib3JkZXItb3JhbmdlLTIwMFwiLFxyXG4gICAgICBkb3Q6IFwidy0xLjUgaC0xLjUgcm91bmRlZC1mdWxsIGJnLW9yYW5nZS01MDAgc2hyaW5rLTBcIixcclxuICAgIH0sXHJcbiAgfTtcclxuICBjb25zdCBjID0gY29uZmlnW3N0YXR1c10gfHwge1xyXG4gICAgY2xzOiBcImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1ib2xkIGJnLWdyYXktMTAwIHRleHQtZ3JheS02MDAgYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiLFxyXG4gICAgZG90OiBcInctMS41IGgtMS41IHJvdW5kZWQtZnVsbCBiZy1ncmF5LTQwMCBzaHJpbmstMFwiLFxyXG4gICAgSWNvbjogTWRCYXJDaGFydCxcclxuICB9O1xyXG4gIHJldHVybiAoXHJcbiAgICA8c3BhbiBjbGFzc05hbWU9e2MuY2xzfT5cclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPXtjLmRvdH0gLz5cclxuICAgICAgPGMuSWNvbiBzaXplPXsxMn0gLz5cclxuICAgICAge3N0YXR1c31cclxuICAgIDwvc3Bhbj5cclxuICApO1xyXG59O1xyXG5cclxuY29uc3QgU3RhdENhcmQgPSAoeyBsYWJlbCwgdmFsdWUsIGNvbG9yQ2xhc3MsIGJnQ2xhc3MsIEljb24gfSkgPT4gKFxyXG4gIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgYmctd2hpdGUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0xMDAgcHgtNSBweS00IHNoYWRvdy1zbSBmbGV4LTEgbWluLXctWzEzMHB4XVwiPlxyXG4gICAgPGRpdlxyXG4gICAgICBjbGFzc05hbWU9e2B3LTExIGgtMTEgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaHJpbmstMCAke2JnQ2xhc3N9YH1cclxuICAgID5cclxuICAgICAgPEljb24gc2l6ZT17MjJ9IGNsYXNzTmFtZT17Y29sb3JDbGFzc30gLz5cclxuICAgIDwvZGl2PlxyXG4gICAgPGRpdj5cclxuICAgICAgPHAgY2xhc3NOYW1lPXtgdGV4dC0yeGwgZm9udC1leHRyYWJvbGQgbGVhZGluZy1ub25lICR7Y29sb3JDbGFzc31gfT5cclxuICAgICAgICB7dmFsdWV9XHJcbiAgICAgIDwvcD5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBmb250LXNlbWlib2xkIG10LTFcIj57bGFiZWx9PC9wPlxyXG4gICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcbik7XHJcblxyXG5cclxuY29uc3QgVHlwZVBpbGwgPSAoeyB2YWx1ZSwgY3VycmVudCwgbGFiZWwsIGFjdGl2ZUNsYXNzLCBJY29uLCBvbkNoYW5nZSB9KSA9PiB7XHJcbiAgY29uc3QgYWN0aXZlID0gdmFsdWUgPT09IGN1cnJlbnQ7XHJcbiAgcmV0dXJuIChcclxuICAgIDxidXR0b25cclxuICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2hhbmdlKHZhbHVlKX1cclxuICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNSBweS0yIHJvdW5kZWQtZnVsbCBib3JkZXItMiB0ZXh0LXNtIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgb3V0bGluZS1ub25lIGN1cnNvci1wb2ludGVyXHJcbiAgICAgICAgJHthY3RpdmUgPyBgJHthY3RpdmVDbGFzc30gdGV4dC13aGl0ZSBzaGFkb3ctbWQgYm9yZGVyLXRyYW5zcGFyZW50YCA6IFwiYm9yZGVyLXNsYXRlLTIwMCBiZy13aGl0ZSB0ZXh0LXNsYXRlLTUwMCBob3Zlcjpib3JkZXItc2xhdGUtMzAwXCJ9YH1cclxuICAgID5cclxuICAgICAgPEljb24gc2l6ZT17MTV9IC8+XHJcbiAgICAgIHtsYWJlbH1cclxuICAgIDwvYnV0dG9uPlxyXG4gICk7XHJcbn07XHJcblxyXG5cclxuY29uc3QgU2VjdGlvbkxhYmVsID0gKHsgdGFnQ2xhc3MsIHRhZywgdGl0bGUgfSkgPT4gKFxyXG4gIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBtYi00XCI+XHJcbiAgICA8c3BhblxyXG4gICAgICBjbGFzc05hbWU9e2B0ZXh0LVsxMHB4XSBmb250LWV4dHJhYm9sZCB0cmFja2luZy13aWRlc3QgcHgtMiBweS0wLjUgcm91bmRlZCAke3RhZ0NsYXNzfWB9XHJcbiAgICA+XHJcbiAgICAgIHt0YWd9XHJcbiAgICA8L3NwYW4+XHJcbiAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMFwiPnt0aXRsZX08L3NwYW4+XHJcbiAgPC9kaXY+XHJcbik7XHJcblxyXG5cclxuZnVuY3Rpb24gRW5xdWlyZUNhbGwoKSB7XHJcbiAgY29uc3QgW2FwaSwgY29udGV4dEhvbGRlcl0gPSBub3RpZmljYXRpb24udXNlTm90aWZpY2F0aW9uKCk7XHJcblxyXG4gIGNvbnN0IFtpc01vZGFsT3Blbiwgc2V0SXNNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtmb3JtXSA9IEZvcm0udXNlRm9ybSgpO1xyXG5cclxuICBjb25zdCBbaXNFZGl0TW9kYWxPcGVuLCBzZXRJc0VkaXRNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlZGl0Rm9ybV0gPSBGb3JtLnVzZUZvcm0oKTtcclxuICBjb25zdCBbZWRpdGluZ1JlY29yZCwgc2V0RWRpdGluZ1JlY29yZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZWRpdEN1c3RvbWVyVHlwZSwgc2V0RWRpdEN1c3RvbWVyVHlwZV0gPSB1c2VTdGF0ZShcIm5ld1wiKTtcclxuXHJcbiAgY29uc3QgW2RlbGV0ZVRhcmdldElkLCBzZXREZWxldGVUYXJnZXRJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZGVsZXRlTG9hZGluZywgc2V0RGVsZXRlTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IFtlbnF1aXJpZXMsIHNldEVucXVpcmllc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2xvYWRpbmdFbnF1aXJpZXMsIHNldExvYWRpbmdFbnF1aXJpZXNdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FkaW5nVXNlcnMsIHNldExvYWRpbmdVc2Vyc10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FkbWluTmFtZSwgc2V0QWRtaW5OYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtjdXN0b21lclR5cGUsIHNldEN1c3RvbWVyVHlwZV0gPSB1c2VTdGF0ZShcIm5ld1wiKTtcclxuICBjb25zdCBbZW5xdWlyeVRhYiwgc2V0RW5xdWlyeVRhYl0gPSB1c2VTdGF0ZShcImFsbFwiKTtcclxuXHJcbiAgY29uc3Qgbm90aWZ5ID0gKHR5cGUsIHRpdGxlLCBkZXNjcmlwdGlvbikgPT5cclxuICAgIGFwaVt0eXBlXSh7XHJcbiAgICAgIHRpdGxlLFxyXG4gICAgICBkZXNjcmlwdGlvbixcclxuICAgICAgcGxhY2VtZW50OiBcInRvcFwiLFxyXG4gICAgICBkdXJhdGlvbjogMixcclxuICAgICAgZ2V0Q29udGFpbmVyOiAoKSA9PiBkb2N1bWVudC5ib2R5LFxyXG4gICAgICBzdHlsZTogeyBsaW5lSGVpZ2h0OiBcIjEuMlwiIH0sXHJcbiAgICB9KTtcclxuXHJcbiAgY29uc3QgZmV0Y2hFbnF1aXJpZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRMb2FkaW5nRW5xdWlyaWVzKHRydWUpO1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBBUEkuZ2V0KFwiL2VucXVpcnkvYWxsXCIpO1xyXG4gICAgICBzZXRFbnF1aXJpZXMocmVzLmRhdGEgfHwgW10pO1xyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGUpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZ0VucXVpcmllcyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hBZG1pblByb2ZpbGUgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCB1c2VyU3RyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgICBpZiAoIXVzZXJTdHIpIHJldHVybjtcclxuICAgICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UodXNlclN0cik7XHJcbiAgICAgIGlmICghdXNlci5faWQpIHJldHVybjtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgQVBJLmdldChgL2FkbWluL2dldC1hZG1pbi8ke3VzZXIuX2lkfWApO1xyXG4gICAgICBjb25zdCBuYW1lID0gcmVzLmRhdGEubmFtZSB8fCB1c2VyLmFkbWluX25hbWUgfHwgXCJcIjtcclxuICAgICAgc2V0QWRtaW5OYW1lKG5hbWUpO1xyXG4gICAgICBmb3JtLnNldEZpZWxkc1ZhbHVlKHsgYWRtaW5OYW1lOiBuYW1lIH0pO1xyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGUpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoVXNlcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRMb2FkaW5nVXNlcnModHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IEFQSS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKTtcclxuICAgICAgc2V0VXNlcnMocmVzLmRhdGEgfHwgW10pO1xyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGUpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZ1VzZXJzKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaEN1c3RvbWVyRW5yb2xsbWVudHMgPSBhc3luYyAodXNlcklkLCB0YXJnZXRGb3JtID0gZm9ybSkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgQVBJLnBvc3QoYC9lbnJvbGwvZ2V0LXVzZXItdGlja2V0cy1yZXBvcnQvJHt1c2VySWR9YCk7XHJcbiAgICAgIGlmIChyZXMuZGF0YSAmJiByZXMuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgY29uc3QgZ3JvdXBEYXRhID0gcmVzLmRhdGFbMF0/LmVucm9sbG1lbnQ/Lmdyb3VwO1xyXG4gICAgICAgIGNvbnN0IGVucm9sbG1lbnREYXRhID0gcmVzLmRhdGFbMF0/LmVucm9sbG1lbnQ7XHJcbiAgICAgICAgaWYgKGdyb3VwRGF0YSlcclxuICAgICAgICAgIHRhcmdldEZvcm0uc2V0RmllbGRzVmFsdWUoeyBncm91cE5hbWU6IGdyb3VwRGF0YS5ncm91cF9uYW1lIH0pO1xyXG4gICAgICAgIGlmIChlbnJvbGxtZW50RGF0YSlcclxuICAgICAgICAgIHRhcmdldEZvcm0uc2V0RmllbGRzVmFsdWUoe1xyXG4gICAgICAgICAgICB0aWNrZXROdW1iZXI6XHJcbiAgICAgICAgICAgICAgZW5yb2xsbWVudERhdGEudGlja2V0cyB8fCBlbnJvbGxtZW50RGF0YS50aWNrZXRfbnVtYmVyIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB0YXJnZXRGb3JtLnNldEZpZWxkc1ZhbHVlKHtcclxuICAgICAgICAgIGdyb3VwTmFtZTogXCJObyBBY3RpdmUgR3JvdXAgRm91bmRcIixcclxuICAgICAgICAgIHRpY2tldE51bWJlcjogXCJOL0FcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGUpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaEVucXVpcmllcygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlT3Blbk1vZGFsID0gKCkgPT4ge1xyXG4gICAgc2V0SXNNb2RhbE9wZW4odHJ1ZSk7XHJcbiAgICBmb3JtLnJlc2V0RmllbGRzKCk7XHJcbiAgICBzZXRDdXN0b21lclR5cGUoXCJuZXdcIik7XHJcbiAgICBmZXRjaEFkbWluUHJvZmlsZSgpO1xyXG4gICAgZmV0Y2hVc2VycygpO1xyXG4gICAgZm9ybS5zZXRGaWVsZHNWYWx1ZSh7IGRhdGU6IGRheWpzKCkgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ3VzdG9tZXJTZWxlY3QgPSAodXNlcklkKSA9PiB7XHJcbiAgICBjb25zdCB1ID0gdXNlcnMuZmluZCgoeCkgPT4geC5faWQgPT09IHVzZXJJZCk7XHJcbiAgICBpZiAodSkge1xyXG4gICAgICBmb3JtLnNldEZpZWxkc1ZhbHVlKHtcclxuICAgICAgICBzZWFyY2hDdXN0b21lcjogdXNlcklkLFxyXG4gICAgICAgIGN1c3RvbWVySWQ6IHVzZXJJZCxcclxuICAgICAgICBleGlzdGluZ0N1c3RvbWVyTmFtZTogdS5mdWxsX25hbWUgfHwgdS5uYW1lLFxyXG4gICAgICAgIGV4aXN0aW5nQ3VzdG9tZXJQaG9uZTogdS5waG9uZV9udW1iZXIgfHwgdS5tb2JpbGUsXHJcbiAgICAgIH0pO1xyXG4gICAgICBmZXRjaEN1c3RvbWVyRW5yb2xsbWVudHModXNlcklkLCBmb3JtKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDdXN0b21lclR5cGVDaGFuZ2UgPSAodmFsdWUpID0+IHtcclxuICAgIHNldEN1c3RvbWVyVHlwZSh2YWx1ZSk7XHJcbiAgICBmb3JtLnJlc2V0RmllbGRzKFtcclxuICAgICAgXCJuZXdDdXN0b21lck5hbWVcIixcclxuICAgICAgXCJuZXdDdXN0b21lclBob25lXCIsXHJcbiAgICAgIFwicHVycG9zZU5ld1wiLFxyXG4gICAgICBcImN1c3RvbWVySWRcIixcclxuICAgICAgXCJleGlzdGluZ0N1c3RvbWVyTmFtZVwiLFxyXG4gICAgICBcImV4aXN0aW5nQ3VzdG9tZXJQaG9uZVwiLFxyXG4gICAgICBcImdyb3VwTmFtZVwiLFxyXG4gICAgICBcInRpY2tldE51bWJlclwiLFxyXG4gICAgICBcInB1cnBvc2VFeGlzdGluZ1wiLFxyXG4gICAgICBcInNlYXJjaEN1c3RvbWVyXCIsXHJcbiAgICAgIFwiZ3Vlc3ROYW1lXCIsXHJcbiAgICAgIFwiZ3Vlc3RQaG9uZVwiLFxyXG4gICAgICBcInB1cnBvc2VHdWVzdFwiLFxyXG4gICAgICBcImFkbWluTmFtZV9maWVsZFwiLFxyXG4gICAgICBcImFkbWluUGhvbmVcIixcclxuICAgICAgXCJhZG1pbkRlcGFydG1lbnRcIixcclxuICAgICAgXCJwdXJwb3NlQWRtaW5cIixcclxuICAgICAgXCJkZXNjcmlwdGlvblwiLFxyXG4gICAgICBcImNhbGxTdGF0dXNcIixcclxuICAgIF0pO1xyXG4gICAgZm9ybS5zZXRGaWVsZHNWYWx1ZSh7IGN1c3RvbWVyVHlwZTogdmFsdWUsIGRhdGU6IGRheWpzKCkgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb25GaW5pc2ggPSBhc3luYyAodmFsdWVzKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBsZXQgcGF5bG9hZCA9IHtcclxuICAgICAgICBhZG1pbk5hbWU6IHZhbHVlcy5hZG1pbk5hbWUsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IHZhbHVlcy5kZXNjcmlwdGlvbixcclxuICAgICAgICBkYXRlOiB2YWx1ZXMuZGF0ZSA/IHZhbHVlcy5kYXRlLmZvcm1hdChcIllZWVktTU0tRERcIikgOiBudWxsLFxyXG4gICAgICB9O1xyXG4gICAgICBpZiAoY3VzdG9tZXJUeXBlID09PSBcIm5ld1wiKVxyXG4gICAgICAgIHBheWxvYWQgPSB7XHJcbiAgICAgICAgICAuLi5wYXlsb2FkLFxyXG4gICAgICAgICAgY3VzdG9tZXJUeXBlOiBcIm5ld1wiLFxyXG4gICAgICAgICAgY3VzdG9tZXJOYW1lOiB2YWx1ZXMubmV3Q3VzdG9tZXJOYW1lLFxyXG4gICAgICAgICAgY3VzdG9tZXJQaG9uZTogdmFsdWVzLm5ld0N1c3RvbWVyUGhvbmUsXHJcbiAgICAgICAgICBwdXJwb3NlOiB2YWx1ZXMucHVycG9zZU5ldyxcclxuICAgICAgICAgIGNhbGxTdGF0dXM6IHZhbHVlcy5jYWxsU3RhdHVzLFxyXG4gICAgICAgIH07XHJcbiAgICAgIGVsc2UgaWYgKGN1c3RvbWVyVHlwZSA9PT0gXCJleGlzdGluZ1wiKVxyXG4gICAgICAgIHBheWxvYWQgPSB7XHJcbiAgICAgICAgICAuLi5wYXlsb2FkLFxyXG4gICAgICAgICAgY3VzdG9tZXJUeXBlOiBcIm9sZFwiLFxyXG4gICAgICAgICAgY3VzdG9tZXJJZDogdmFsdWVzLmN1c3RvbWVySWQsXHJcbiAgICAgICAgICBjdXN0b21lck5hbWU6IHZhbHVlcy5leGlzdGluZ0N1c3RvbWVyTmFtZSxcclxuICAgICAgICAgIGN1c3RvbWVyUGhvbmU6IHZhbHVlcy5leGlzdGluZ0N1c3RvbWVyUGhvbmUsXHJcbiAgICAgICAgICBncm91cE5hbWU6IHZhbHVlcy5ncm91cE5hbWUsXHJcbiAgICAgICAgICB0aWNrZXROdW1iZXI6IHZhbHVlcy50aWNrZXROdW1iZXIsXHJcbiAgICAgICAgICBwdXJwb3NlOiB2YWx1ZXMucHVycG9zZUV4aXN0aW5nLFxyXG4gICAgICAgICAgY2FsbFN0YXR1czogdmFsdWVzLmNhbGxTdGF0dXMsXHJcbiAgICAgICAgfTtcclxuICAgICAgZWxzZSBpZiAoY3VzdG9tZXJUeXBlID09PSBcImd1ZXN0XCIpXHJcbiAgICAgICAgcGF5bG9hZCA9IHtcclxuICAgICAgICAgIC4uLnBheWxvYWQsXHJcbiAgICAgICAgICBjdXN0b21lclR5cGU6IFwiZ3Vlc3RcIixcclxuICAgICAgICAgIGN1c3RvbWVyTmFtZTogdmFsdWVzLmd1ZXN0TmFtZSxcclxuICAgICAgICAgIGN1c3RvbWVyUGhvbmU6IHZhbHVlcy5ndWVzdFBob25lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICBwdXJwb3NlOiB2YWx1ZXMucHVycG9zZUd1ZXN0LFxyXG4gICAgICAgICAgY2FsbFN0YXR1czogdmFsdWVzLmNhbGxTdGF0dXMsXHJcbiAgICAgICAgICBndWVzdE5hbWU6IHZhbHVlcy5ndWVzdE5hbWUsXHJcbiAgICAgICAgICBndWVzdFBob25lOiB2YWx1ZXMuZ3Vlc3RQaG9uZSxcclxuICAgICAgICB9O1xyXG4gICAgICBlbHNlIGlmIChjdXN0b21lclR5cGUgPT09IFwiYWRtaW5cIilcclxuICAgICAgICBwYXlsb2FkID0ge1xyXG4gICAgICAgICAgLi4ucGF5bG9hZCxcclxuICAgICAgICAgIGN1c3RvbWVyVHlwZTogXCJhZG1pblwiLFxyXG4gICAgICAgICAgY3VzdG9tZXJOYW1lOiB2YWx1ZXMuYWRtaW5OYW1lX2ZpZWxkLFxyXG4gICAgICAgICAgY3VzdG9tZXJQaG9uZTogdmFsdWVzLmFkbWluUGhvbmUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIHB1cnBvc2U6IHZhbHVlcy5wdXJwb3NlQWRtaW4sXHJcbiAgICAgICAgICBjYWxsU3RhdHVzOiB2YWx1ZXMuY2FsbFN0YXR1cyxcclxuICAgICAgICAgIGFkbWluRGVwYXJ0bWVudDogdmFsdWVzLmFkbWluRGVwYXJ0bWVudCxcclxuICAgICAgICB9O1xyXG4gICAgICBhd2FpdCBBUEkucG9zdChcIi9lbnF1aXJ5L2NyZWF0ZVwiLCBwYXlsb2FkKTtcclxuICAgICAgbm90aWZ5KFwic3VjY2Vzc1wiLCBcIlN1Y2Nlc3NcIiwgXCJFbnF1aXJ5IHN1Ym1pdHRlZCBzdWNjZXNzZnVsbHkhXCIpO1xyXG4gICAgICBmZXRjaEVucXVpcmllcygpO1xyXG4gICAgICBzZXRJc01vZGFsT3BlbihmYWxzZSk7XHJcbiAgICAgIGZvcm0ucmVzZXRGaWVsZHMoKTtcclxuICAgICAgc2V0Q3VzdG9tZXJUeXBlKFwibmV3XCIpO1xyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGUpO1xyXG4gICAgICBub3RpZnkoXCJlcnJvclwiLCBcIkVycm9yXCIsIFwiRmFpbGVkIHRvIHN1Ym1pdCBlbnF1aXJ5XCIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG5cclxuICBjb25zdCBoYW5kbGVPcGVuRWRpdCA9IChyZWNvcmQpID0+IHtcclxuICAgIHNldEVkaXRpbmdSZWNvcmQocmVjb3JkKTtcclxuXHJcblxyXG4gICAgbGV0IGN0ID0gXCJuZXdcIjtcclxuICAgIGlmIChcclxuICAgICAgcmVjb3JkLmN1c3RvbWVyVHlwZSA9PT0gXCJvbGRcIiB8fFxyXG4gICAgICByZWNvcmQuY3VzdG9tZXJUeXBlID09PSBcIkV4aXN0aW5nIEN1c3RvbWVyXCJcclxuICAgICkge1xyXG4gICAgICBjdCA9IFwiZXhpc3RpbmdcIjtcclxuICAgIH0gZWxzZSBpZiAoXHJcbiAgICAgIHJlY29yZC5jdXN0b21lclR5cGUgPT09IFwiZ3Vlc3RcIiB8fFxyXG4gICAgICByZWNvcmQuY3VzdG9tZXJUeXBlID09PSBcIkd1ZXN0XCJcclxuICAgICkge1xyXG4gICAgICBjdCA9IFwiZ3Vlc3RcIjtcclxuICAgIH0gZWxzZSBpZiAoXHJcbiAgICAgIHJlY29yZC5jdXN0b21lclR5cGUgPT09IFwiYWRtaW5cIiB8fFxyXG4gICAgICByZWNvcmQuY3VzdG9tZXJUeXBlID09PSBcIkFkbWluXCJcclxuICAgICkge1xyXG4gICAgICBjdCA9IFwiYWRtaW5cIjtcclxuICAgIH0gZWxzZSBpZiAoXHJcbiAgICAgIHJlY29yZC5jdXN0b21lclR5cGUgPT09IFwibmV3XCIgfHxcclxuICAgICAgcmVjb3JkLmN1c3RvbWVyVHlwZSA9PT0gXCJOZXcgQ3VzdG9tZXJcIlxyXG4gICAgKSB7XHJcbiAgICAgIGN0ID0gXCJuZXdcIjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRFZGl0Q3VzdG9tZXJUeXBlKGN0KTtcclxuXHJcblxyXG4gICAgbGV0IHBhcnNlZERhdGUgPSBkYXlqcygpO1xyXG4gICAgaWYgKHJlY29yZC5kYXRlKSB7XHJcblxyXG4gICAgICBjb25zdCBmb3JtYXRzID0gW1wiREQtTU0tWVlZWVwiLCBcIllZWVktTU0tRERcIiwgXCJNTS9ERC9ZWVlZXCIsIFwiREQvTU0vWVlZWVwiXTtcclxuICAgICAgZm9yIChjb25zdCBmb3JtYXQgb2YgZm9ybWF0cykge1xyXG4gICAgICAgIGNvbnN0IGQgPSBkYXlqcyhyZWNvcmQuZGF0ZSwgZm9ybWF0KTtcclxuICAgICAgICBpZiAoZC5pc1ZhbGlkKCkpIHtcclxuICAgICAgICAgIHBhcnNlZERhdGUgPSBkO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCBkID0gZGF5anMocmVjb3JkLmRhdGUpO1xyXG4gICAgICBpZiAoZC5pc1ZhbGlkKCkpIHtcclxuICAgICAgICBwYXJzZWREYXRlID0gZDtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHJcbiAgICBjb25zdCBmaWVsZHNUb1NldCA9IHtcclxuICAgICAgYWRtaW5OYW1lOiByZWNvcmQuYWRtaW5OYW1lIHx8IFwiXCIsXHJcbiAgICAgIGRlc2NyaXB0aW9uOiByZWNvcmQuZGVzY3JpcHRpb24gfHwgXCJcIixcclxuICAgICAgZGF0ZTogcGFyc2VkRGF0ZSxcclxuICAgICAgY2FsbFN0YXR1czogcmVjb3JkLmNhbGxTdGF0dXMgfHwgXCJDb2xkXCIsXHJcbiAgICB9O1xyXG5cclxuICAgIGlmIChjdCA9PT0gXCJuZXdcIikge1xyXG4gICAgICBmaWVsZHNUb1NldC5uZXdDdXN0b21lck5hbWUgPSByZWNvcmQuY3VzdG9tZXJOYW1lIHx8IFwiXCI7XHJcbiAgICAgIGZpZWxkc1RvU2V0Lm5ld0N1c3RvbWVyUGhvbmUgPSByZWNvcmQuY3VzdG9tZXJQaG9uZSB8fCBcIlwiO1xyXG4gICAgICBmaWVsZHNUb1NldC5wdXJwb3NlTmV3ID0gcmVjb3JkLnB1cnBvc2UgfHwgXCJcIjtcclxuICAgIH0gZWxzZSBpZiAoY3QgPT09IFwiZXhpc3RpbmdcIikge1xyXG4gICAgICBmaWVsZHNUb1NldC5leGlzdGluZ0N1c3RvbWVyTmFtZSA9IHJlY29yZC5jdXN0b21lck5hbWUgfHwgXCJcIjtcclxuICAgICAgZmllbGRzVG9TZXQuZXhpc3RpbmdDdXN0b21lclBob25lID0gcmVjb3JkLmN1c3RvbWVyUGhvbmUgfHwgXCJcIjtcclxuICAgICAgZmllbGRzVG9TZXQuZ3JvdXBOYW1lID0gcmVjb3JkLmdyb3VwTmFtZSB8fCBcIlwiO1xyXG4gICAgICBmaWVsZHNUb1NldC50aWNrZXROdW1iZXIgPSByZWNvcmQudGlja2V0TnVtYmVyIHx8IFwiXCI7XHJcbiAgICAgIGZpZWxkc1RvU2V0LnB1cnBvc2VFeGlzdGluZyA9IHJlY29yZC5wdXJwb3NlIHx8IFwiXCI7XHJcbiAgICAgIGZpZWxkc1RvU2V0LmN1c3RvbWVySWQgPSByZWNvcmQuY3VzdG9tZXJJZCB8fCBcIlwiO1xyXG4gICAgfSBlbHNlIGlmIChjdCA9PT0gXCJndWVzdFwiKSB7XHJcbiAgICAgIGZpZWxkc1RvU2V0Lmd1ZXN0TmFtZSA9IHJlY29yZC5jdXN0b21lck5hbWUgfHwgXCJcIjtcclxuICAgICAgZmllbGRzVG9TZXQuZ3Vlc3RQaG9uZSA9IHJlY29yZC5jdXN0b21lclBob25lIHx8IFwiXCI7XHJcbiAgICAgIGZpZWxkc1RvU2V0LnB1cnBvc2VHdWVzdCA9IHJlY29yZC5wdXJwb3NlIHx8IFwiXCI7XHJcbiAgICB9IGVsc2UgaWYgKGN0ID09PSBcImFkbWluXCIpIHtcclxuICAgICAgZmllbGRzVG9TZXQuYWRtaW5OYW1lX2ZpZWxkID0gcmVjb3JkLmN1c3RvbWVyTmFtZSB8fCBcIlwiO1xyXG4gICAgICBmaWVsZHNUb1NldC5hZG1pblBob25lID0gcmVjb3JkLmN1c3RvbWVyUGhvbmUgfHwgXCJcIjtcclxuICAgICAgZmllbGRzVG9TZXQuYWRtaW5EZXBhcnRtZW50ID0gcmVjb3JkLmFkbWluRGVwYXJ0bWVudCB8fCBcIlwiO1xyXG4gICAgICBmaWVsZHNUb1NldC5wdXJwb3NlQWRtaW4gPSByZWNvcmQucHVycG9zZSB8fCBcIlwiO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBlZGl0Rm9ybS5yZXNldEZpZWxkcygpO1xyXG5cclxuXHJcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgZWRpdEZvcm0uc2V0RmllbGRzVmFsdWUoZmllbGRzVG9TZXQpO1xyXG4gICAgfSwgNTApO1xyXG5cclxuICAgIGZldGNoVXNlcnMoKTtcclxuICAgIHNldElzRWRpdE1vZGFsT3Blbih0cnVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVFZGl0Q3VzdG9tZXJTZWxlY3QgPSAodXNlcklkKSA9PiB7XHJcbiAgICBjb25zdCB1ID0gdXNlcnMuZmluZCgoeCkgPT4geC5faWQgPT09IHVzZXJJZCk7XHJcbiAgICBpZiAodSkge1xyXG4gICAgICBlZGl0Rm9ybS5zZXRGaWVsZHNWYWx1ZSh7XHJcbiAgICAgICAgc2VhcmNoQ3VzdG9tZXI6IHVzZXJJZCxcclxuICAgICAgICBjdXN0b21lcklkOiB1c2VySWQsXHJcbiAgICAgICAgZXhpc3RpbmdDdXN0b21lck5hbWU6IHUuZnVsbF9uYW1lIHx8IHUubmFtZSxcclxuICAgICAgICBleGlzdGluZ0N1c3RvbWVyUGhvbmU6IHUucGhvbmVfbnVtYmVyIHx8IHUubW9iaWxlLFxyXG4gICAgICB9KTtcclxuICAgICAgZmV0Y2hDdXN0b21lckVucm9sbG1lbnRzKHVzZXJJZCwgZWRpdEZvcm0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUVkaXRDdXN0b21lclR5cGVDaGFuZ2UgPSAodmFsdWUpID0+IHtcclxuICAgIHNldEVkaXRDdXN0b21lclR5cGUodmFsdWUpO1xyXG4gICAgZWRpdEZvcm0ucmVzZXRGaWVsZHMoW1xyXG4gICAgICBcIm5ld0N1c3RvbWVyTmFtZVwiLFxyXG4gICAgICBcIm5ld0N1c3RvbWVyUGhvbmVcIixcclxuICAgICAgXCJwdXJwb3NlTmV3XCIsXHJcbiAgICAgIFwiY3VzdG9tZXJJZFwiLFxyXG4gICAgICBcImV4aXN0aW5nQ3VzdG9tZXJOYW1lXCIsXHJcbiAgICAgIFwiZXhpc3RpbmdDdXN0b21lclBob25lXCIsXHJcbiAgICAgIFwiZ3JvdXBOYW1lXCIsXHJcbiAgICAgIFwidGlja2V0TnVtYmVyXCIsXHJcbiAgICAgIFwicHVycG9zZUV4aXN0aW5nXCIsXHJcbiAgICAgIFwic2VhcmNoQ3VzdG9tZXJcIixcclxuICAgICAgXCJndWVzdE5hbWVcIixcclxuICAgICAgXCJndWVzdFBob25lXCIsXHJcbiAgICAgIFwicHVycG9zZUd1ZXN0XCIsXHJcbiAgICAgIFwiYWRtaW5OYW1lX2ZpZWxkXCIsXHJcbiAgICAgIFwiYWRtaW5QaG9uZVwiLFxyXG4gICAgICBcImFkbWluRGVwYXJ0bWVudFwiLFxyXG4gICAgICBcInB1cnBvc2VBZG1pblwiLFxyXG4gICAgXSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb25FZGl0RmluaXNoID0gYXN5bmMgKHZhbHVlcykgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgbGV0IHBheWxvYWQgPSB7XHJcbiAgICAgICAgYWRtaW5OYW1lOiB2YWx1ZXMuYWRtaW5OYW1lLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uOiB2YWx1ZXMuZGVzY3JpcHRpb24sXHJcbiAgICAgICAgZGF0ZTogdmFsdWVzLmRhdGUgPyB2YWx1ZXMuZGF0ZS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpIDogbnVsbCxcclxuICAgICAgfTtcclxuICAgICAgaWYgKGVkaXRDdXN0b21lclR5cGUgPT09IFwibmV3XCIpXHJcbiAgICAgICAgcGF5bG9hZCA9IHtcclxuICAgICAgICAgIC4uLnBheWxvYWQsXHJcbiAgICAgICAgICBjdXN0b21lclR5cGU6IFwibmV3XCIsXHJcbiAgICAgICAgICBjdXN0b21lck5hbWU6IHZhbHVlcy5uZXdDdXN0b21lck5hbWUsXHJcbiAgICAgICAgICBjdXN0b21lclBob25lOiB2YWx1ZXMubmV3Q3VzdG9tZXJQaG9uZSxcclxuICAgICAgICAgIHB1cnBvc2U6IHZhbHVlcy5wdXJwb3NlTmV3LFxyXG4gICAgICAgICAgY2FsbFN0YXR1czogdmFsdWVzLmNhbGxTdGF0dXMsXHJcbiAgICAgICAgfTtcclxuICAgICAgZWxzZSBpZiAoZWRpdEN1c3RvbWVyVHlwZSA9PT0gXCJleGlzdGluZ1wiKVxyXG4gICAgICAgIHBheWxvYWQgPSB7XHJcbiAgICAgICAgICAuLi5wYXlsb2FkLFxyXG4gICAgICAgICAgY3VzdG9tZXJUeXBlOiBcIm9sZFwiLFxyXG4gICAgICAgICAgY3VzdG9tZXJJZDogdmFsdWVzLmN1c3RvbWVySWQsXHJcbiAgICAgICAgICBjdXN0b21lck5hbWU6IHZhbHVlcy5leGlzdGluZ0N1c3RvbWVyTmFtZSxcclxuICAgICAgICAgIGN1c3RvbWVyUGhvbmU6IHZhbHVlcy5leGlzdGluZ0N1c3RvbWVyUGhvbmUsXHJcbiAgICAgICAgICBncm91cE5hbWU6IHZhbHVlcy5ncm91cE5hbWUsXHJcbiAgICAgICAgICB0aWNrZXROdW1iZXI6IHZhbHVlcy50aWNrZXROdW1iZXIsXHJcbiAgICAgICAgICBwdXJwb3NlOiB2YWx1ZXMucHVycG9zZUV4aXN0aW5nLFxyXG4gICAgICAgICAgY2FsbFN0YXR1czogdmFsdWVzLmNhbGxTdGF0dXMsXHJcbiAgICAgICAgfTtcclxuICAgICAgZWxzZSBpZiAoZWRpdEN1c3RvbWVyVHlwZSA9PT0gXCJndWVzdFwiKVxyXG4gICAgICAgIHBheWxvYWQgPSB7XHJcbiAgICAgICAgICAuLi5wYXlsb2FkLFxyXG4gICAgICAgICAgY3VzdG9tZXJUeXBlOiBcImd1ZXN0XCIsXHJcbiAgICAgICAgICBjdXN0b21lck5hbWU6IHZhbHVlcy5ndWVzdE5hbWUsXHJcbiAgICAgICAgICBjdXN0b21lclBob25lOiB2YWx1ZXMuZ3Vlc3RQaG9uZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgcHVycG9zZTogdmFsdWVzLnB1cnBvc2VHdWVzdCxcclxuICAgICAgICAgIGNhbGxTdGF0dXM6IHZhbHVlcy5jYWxsU3RhdHVzLFxyXG4gICAgICAgICAgZ3Vlc3ROYW1lOiB2YWx1ZXMuZ3Vlc3ROYW1lLFxyXG4gICAgICAgICAgZ3Vlc3RQaG9uZTogdmFsdWVzLmd1ZXN0UGhvbmUsXHJcbiAgICAgICAgfTtcclxuICAgICAgZWxzZSBpZiAoZWRpdEN1c3RvbWVyVHlwZSA9PT0gXCJhZG1pblwiKVxyXG4gICAgICAgIHBheWxvYWQgPSB7XHJcbiAgICAgICAgICAuLi5wYXlsb2FkLFxyXG4gICAgICAgICAgY3VzdG9tZXJUeXBlOiBcImFkbWluXCIsXHJcbiAgICAgICAgICBjdXN0b21lck5hbWU6IHZhbHVlcy5hZG1pbk5hbWVfZmllbGQsXHJcbiAgICAgICAgICBjdXN0b21lclBob25lOiB2YWx1ZXMuYWRtaW5QaG9uZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgcHVycG9zZTogdmFsdWVzLnB1cnBvc2VBZG1pbixcclxuICAgICAgICAgIGNhbGxTdGF0dXM6IHZhbHVlcy5jYWxsU3RhdHVzLFxyXG4gICAgICAgICAgYWRtaW5EZXBhcnRtZW50OiB2YWx1ZXMuYWRtaW5EZXBhcnRtZW50LFxyXG4gICAgICAgIH07XHJcbiAgICAgIGF3YWl0IEFQSS5wdXQoYC9lbnF1aXJ5LyR7ZWRpdGluZ1JlY29yZC5faWR9YCwgcGF5bG9hZCk7XHJcbiAgICAgIG5vdGlmeShcInN1Y2Nlc3NcIiwgXCJVcGRhdGVkXCIsIFwiRW5xdWlyeSB1cGRhdGVkIHN1Y2Nlc3NmdWxseSFcIik7XHJcbiAgICAgIGZldGNoRW5xdWlyaWVzKCk7XHJcbiAgICAgIHNldElzRWRpdE1vZGFsT3BlbihmYWxzZSk7XHJcbiAgICAgIGVkaXRGb3JtLnJlc2V0RmllbGRzKCk7XHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XHJcbiAgICAgIG5vdGlmeShcImVycm9yXCIsIFwiRXJyb3JcIiwgXCJGYWlsZWQgdG8gdXBkYXRlIGVucXVpcnlcIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlQ29uZmlybSA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldERlbGV0ZUxvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGF3YWl0IEFQSS5kZWxldGUoYC9lbnF1aXJ5LyR7ZGVsZXRlVGFyZ2V0SWR9YCk7XHJcbiAgICAgIG5vdGlmeShcInN1Y2Nlc3NcIiwgXCJEZWxldGVkXCIsIFwiRW5xdWlyeSBkZWxldGVkIHN1Y2Nlc3NmdWxseSFcIik7XHJcbiAgICAgIGZldGNoRW5xdWlyaWVzKCk7XHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XHJcbiAgICAgIG5vdGlmeShcImVycm9yXCIsIFwiRXJyb3JcIiwgXCJGYWlsZWQgdG8gZGVsZXRlIGVucXVpcnlcIik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXREZWxldGVMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgc2V0RGVsZXRlVGFyZ2V0SWQobnVsbCk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcblxyXG4gIGNvbnN0IGFjdGlvbkNvbHVtbiA9IHtcclxuICAgIGtleTogXCJhY3Rpb25zXCIsXHJcbiAgICBoZWFkZXI6IFwiQWN0aW9uc1wiLFxyXG4gICAgd2lkdGg6IFwiODBweFwiLFxyXG4gICAgbWluV2lkdGg6IFwiODBweFwiLFxyXG4gICAgcmVuZGVyOiAoXywgcm93KSA9PiAoXHJcbiAgICAgIDxBY3Rpb25NZW51XHJcbiAgICAgICAgb25FZGl0PXsoKSA9PiBoYW5kbGVPcGVuRWRpdChyb3cpfVxyXG4gICAgICAgIG9uRGVsZXRlPXsoKSA9PiBzZXREZWxldGVUYXJnZXRJZChyb3cuX2lkKX1cclxuICAgICAgLz5cclxuICAgICksXHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ2V0RW5xdWlyeUNvbHVtbnMgPSAodGFiKSA9PiB7XHJcbiAgICBjb25zdCBiYXNlID0gW1xyXG4gICAgICB7IGtleTogXCJjdXN0b21lck5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgICB7IGtleTogXCJjdXN0b21lclBob25lXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgICB7IGtleTogXCJwdXJwb3NlXCIsIGhlYWRlcjogXCJQdXJwb3NlXCIgfSxcclxuICAgICAgeyBrZXk6IFwiZGVzY3JpcHRpb25cIiwgaGVhZGVyOiBcIkRlc2NyaXB0aW9uXCIgfSxcclxuICAgICAge1xyXG4gICAgICAgIGtleTogXCJjYWxsU3RhdHVzXCIsXHJcbiAgICAgICAgaGVhZGVyOiBcIkNhbGwgU3RhdHVzXCIsXHJcbiAgICAgICAgcmVuZGVyOiAodGV4dCkgPT4gPENhbGxTdGF0dXNCYWRnZSBzdGF0dXM9e3RleHR9IC8+LFxyXG4gICAgICB9LFxyXG4gICAgXTtcclxuXHJcbiAgICBsZXQgY29scztcclxuICAgIGlmICh0YWIgPT09IFwiYWxsXCIpIHtcclxuICAgICAgY29scyA9IFtcclxuICAgICAgICB7IGtleTogXCJkYXRlXCIsIGhlYWRlcjogXCJEYXRlXCIgfSxcclxuICAgICAgICB7IGtleTogXCJjdXN0b21lclR5cGVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIFR5cGVcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcImFkbWluTmFtZVwiLCBoZWFkZXI6IFwiQWRtaW4gTmFtZVwiIH0sXHJcbiAgICAgICAgLi4uYmFzZSxcclxuICAgICAgICB7IGtleTogXCJncm91cE5hbWVcIiwgaGVhZGVyOiBcIkdyb3VwXCIgfSxcclxuICAgICAgICB7IGtleTogXCJ0aWNrZXROdW1iZXJcIiwgaGVhZGVyOiBcIlRpY2tldCBOb1wiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiYWRtaW5EZXBhcnRtZW50XCIsIGhlYWRlcjogXCJEZXBhcnRtZW50XCIgfSxcclxuICAgICAgXTtcclxuICAgIH0gZWxzZSBpZiAodGFiID09PSBcImV4aXN0aW5nXCIpIHtcclxuICAgICAgY29scyA9IFtcclxuICAgICAgICAuLi5iYXNlLFxyXG4gICAgICAgIHsga2V5OiBcImdyb3VwTmFtZVwiLCBoZWFkZXI6IFwiR3JvdXBcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcInRpY2tldE51bWJlclwiLCBoZWFkZXI6IFwiVGlja2V0IE5vXCIgfSxcclxuICAgICAgXTtcclxuICAgIH0gZWxzZSBpZiAodGFiID09PSBcImFkbWluXCIpIHtcclxuICAgICAgY29scyA9IFsuLi5iYXNlLCB7IGtleTogXCJhZG1pbkRlcGFydG1lbnRcIiwgaGVhZGVyOiBcIkRlcGFydG1lbnRcIiB9XTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbHMgPSBiYXNlO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBbLi4uY29scywgYWN0aW9uQ29sdW1uXTtcclxuICB9O1xyXG5cclxuICBjb25zdCBnZXRGaWx0ZXJlZEVucXVpcmllcyA9ICgpID0+IHtcclxuICAgIGlmIChlbnF1aXJ5VGFiID09PSBcIm5ld1wiKVxyXG4gICAgICByZXR1cm4gZW5xdWlyaWVzLmZpbHRlcigoaSkgPT4gaS5jdXN0b21lclR5cGUgPT09IFwibmV3XCIpO1xyXG4gICAgaWYgKGVucXVpcnlUYWIgPT09IFwiZXhpc3RpbmdcIilcclxuICAgICAgcmV0dXJuIGVucXVpcmllcy5maWx0ZXIoKGkpID0+IGkuY3VzdG9tZXJUeXBlID09PSBcIm9sZFwiKTtcclxuICAgIGlmIChlbnF1aXJ5VGFiID09PSBcImd1ZXN0XCIpXHJcbiAgICAgIHJldHVybiBlbnF1aXJpZXMuZmlsdGVyKChpKSA9PiBpLmN1c3RvbWVyVHlwZSA9PT0gXCJndWVzdFwiKTtcclxuICAgIGlmIChlbnF1aXJ5VGFiID09PSBcImFkbWluXCIpXHJcbiAgICAgIHJldHVybiBlbnF1aXJpZXMuZmlsdGVyKChpKSA9PiBpLmN1c3RvbWVyVHlwZSA9PT0gXCJhZG1pblwiKTtcclxuICAgIHJldHVybiBlbnF1aXJpZXM7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZm9ybWF0dGVkRW5xdWlyaWVzID0gZ2V0RmlsdGVyZWRFbnF1aXJpZXMoKS5tYXAoKGl0ZW0pID0+ICh7XHJcbiAgICAuLi5pdGVtLFxyXG5cclxuICAgIGFjdGlvbnM6IChcclxuICAgICAgPEFjdGlvbk1lbnVcclxuICAgICAgICBvbkVkaXQ9eygpID0+IGhhbmRsZU9wZW5FZGl0KGl0ZW0pfVxyXG4gICAgICAgIG9uRGVsZXRlPXsoKSA9PiBzZXREZWxldGVUYXJnZXRJZChpdGVtLl9pZCl9XHJcbiAgICAgIC8+XHJcbiAgICApLFxyXG5cclxuICAgIF9jdXN0b21lclR5cGU6IGl0ZW0uY3VzdG9tZXJUeXBlLFxyXG5cclxuICAgIGRhdGU6IGl0ZW0uZGF0ZSA/IGRheWpzKGl0ZW0uZGF0ZSkuZm9ybWF0KFwiREQtTU0tWVlZWVwiKSA6IFwiLVwiLFxyXG5cclxuICAgIGN1c3RvbWVyVHlwZTpcclxuICAgICAgaXRlbS5jdXN0b21lclR5cGUgPT09IFwibmV3XCJcclxuICAgICAgICA/IFwiTmV3IEN1c3RvbWVyXCJcclxuICAgICAgICA6IGl0ZW0uY3VzdG9tZXJUeXBlID09PSBcIm9sZFwiXHJcbiAgICAgICAgICA/IFwiRXhpc3RpbmcgQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgOiBpdGVtLmN1c3RvbWVyVHlwZSA9PT0gXCJndWVzdFwiXHJcbiAgICAgICAgICAgID8gXCJHdWVzdFwiXHJcbiAgICAgICAgICAgIDogaXRlbS5jdXN0b21lclR5cGUgPT09IFwiYWRtaW5cIlxyXG4gICAgICAgICAgICAgID8gXCJBZG1pblwiXHJcbiAgICAgICAgICAgICAgOiBcIkd1ZXN0XCIsXHJcbiAgfSkpO1xyXG5cclxuICBjb25zdCBjb3VudHMgPSB7XHJcbiAgICBhbGw6IGVucXVpcmllcy5sZW5ndGgsXHJcbiAgICBuZXc6IGVucXVpcmllcy5maWx0ZXIoKGUpID0+IGUuY3VzdG9tZXJUeXBlID09PSBcIm5ld1wiKS5sZW5ndGgsXHJcbiAgICBleGlzdGluZzogZW5xdWlyaWVzLmZpbHRlcigoZSkgPT4gZS5jdXN0b21lclR5cGUgPT09IFwib2xkXCIpLmxlbmd0aCxcclxuICAgIGd1ZXN0OiBlbnF1aXJpZXMuZmlsdGVyKChlKSA9PiBlLmN1c3RvbWVyVHlwZSA9PT0gXCJndWVzdFwiKS5sZW5ndGgsXHJcbiAgICBhZG1pbjogZW5xdWlyaWVzLmZpbHRlcigoZSkgPT4gZS5jdXN0b21lclR5cGUgPT09IFwiYWRtaW5cIikubGVuZ3RoLFxyXG4gICAgaG90OiBlbnF1aXJpZXMuZmlsdGVyKChlKSA9PiBlLmNhbGxTdGF0dXMgPT09IFwiSG90XCIpLmxlbmd0aCxcclxuICAgIGNvbGQ6IGVucXVpcmllcy5maWx0ZXIoKGUpID0+IGUuY2FsbFN0YXR1cyA9PT0gXCJDb2xkXCIpLmxlbmd0aCxcclxuICAgIGVtZXJnZW5jeTogZW5xdWlyaWVzLmZpbHRlcigoZSkgPT4gZS5jYWxsU3RhdHVzID09PSBcIkVtZXJnZW5jeVwiKS5sZW5ndGgsXHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdGFiSXRlbXMgPSBbXHJcbiAgICB7IGtleTogXCJhbGxcIiwgbGFiZWw6IGBBbGwgKCR7Y291bnRzLmFsbH0pYCwgY2hpbGRyZW46IG51bGwgfSxcclxuICAgIHsga2V5OiBcIm5ld1wiLCBsYWJlbDogYE5ldyBDdXN0b21lciAoJHtjb3VudHMubmV3fSlgLCBjaGlsZHJlbjogbnVsbCB9LFxyXG4gICAge1xyXG4gICAgICBrZXk6IFwiZXhpc3RpbmdcIixcclxuICAgICAgbGFiZWw6IGBFeGlzdGluZyBDdXN0b21lciAoJHtjb3VudHMuZXhpc3Rpbmd9KWAsXHJcbiAgICAgIGNoaWxkcmVuOiBudWxsLFxyXG4gICAgfSxcclxuICAgIHsga2V5OiBcImd1ZXN0XCIsIGxhYmVsOiBgR3Vlc3QgKCR7Y291bnRzLmd1ZXN0fSlgLCBjaGlsZHJlbjogbnVsbCB9LFxyXG4gICAgeyBrZXk6IFwiYWRtaW5cIiwgbGFiZWw6IGBBZG1pbiAoJHtjb3VudHMuYWRtaW59KWAsIGNoaWxkcmVuOiBudWxsIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgcmVuZGVyRm9ybUJvZHkgPSAoaXNFZGl0ID0gZmFsc2UpID0+IHtcclxuICAgIGNvbnN0IGYgPSBpc0VkaXQgPyBlZGl0Rm9ybSA6IGZvcm07XHJcbiAgICBjb25zdCBjdCA9IGlzRWRpdCA/IGVkaXRDdXN0b21lclR5cGUgOiBjdXN0b21lclR5cGU7XHJcbiAgICBjb25zdCBvbkN0Q2hhbmdlID0gaXNFZGl0XHJcbiAgICAgID8gaGFuZGxlRWRpdEN1c3RvbWVyVHlwZUNoYW5nZVxyXG4gICAgICA6IGhhbmRsZUN1c3RvbWVyVHlwZUNoYW5nZTtcclxuICAgIGNvbnN0IG9uQ3VzdFNlbCA9IGlzRWRpdCA/IGhhbmRsZUVkaXRDdXN0b21lclNlbGVjdCA6IGhhbmRsZUN1c3RvbWVyU2VsZWN0O1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgIDw+XHJcbiAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgbGFiZWw9XCJBZG1pbiBOYW1lXCJcclxuICAgICAgICAgIG5hbWU9XCJhZG1pbk5hbWVcIlxyXG4gICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIkFkbWluIE5hbWUgaXMgcmVxdWlyZWQhXCIgfV19XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJtYi00XCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBdXRvLWZldGNoZWRcIlxyXG4gICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MCB0ZXh0LXNsYXRlLTUwMCBjdXJzb3Itbm90LWFsbG93ZWQgcm91bmRlZC1sZyBib3JkZXItc2xhdGUtMjAwXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC14bCBweC01IHB5LTQgbWItNVwiPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItM1wiPlxyXG4gICAgICAgICAgICBDdXN0b21lciBUeXBlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTMgZmxleC13cmFwXCI+XHJcbiAgICAgICAgICAgIDxUeXBlUGlsbFxyXG4gICAgICAgICAgICAgIHZhbHVlPVwibmV3XCJcclxuICAgICAgICAgICAgICBjdXJyZW50PXtjdH1cclxuICAgICAgICAgICAgICBsYWJlbD1cIk5ldyBDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgYWN0aXZlQ2xhc3M9XCJiZy1lbWVyYWxkLTYwMFwiXHJcbiAgICAgICAgICAgICAgSWNvbj17TWRQZXJzb259XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9e29uQ3RDaGFuZ2V9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxUeXBlUGlsbFxyXG4gICAgICAgICAgICAgIHZhbHVlPVwiZXhpc3RpbmdcIlxyXG4gICAgICAgICAgICAgIGN1cnJlbnQ9e2N0fVxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiRXhpc3RpbmcgQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgIGFjdGl2ZUNsYXNzPVwiYmctdmlvbGV0LTYwMFwiXHJcbiAgICAgICAgICAgICAgSWNvbj17TWRMb29wfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXtvbkN0Q2hhbmdlfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8VHlwZVBpbGxcclxuICAgICAgICAgICAgICB2YWx1ZT1cImd1ZXN0XCJcclxuICAgICAgICAgICAgICBjdXJyZW50PXtjdH1cclxuICAgICAgICAgICAgICBsYWJlbD1cIkd1ZXN0XCJcclxuICAgICAgICAgICAgICBhY3RpdmVDbGFzcz1cImJnLWFtYmVyLTUwMFwiXHJcbiAgICAgICAgICAgICAgSWNvbj17TWRQZW9wbGVBbHR9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9e29uQ3RDaGFuZ2V9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxUeXBlUGlsbFxyXG4gICAgICAgICAgICAgIHZhbHVlPVwiYWRtaW5cIlxyXG4gICAgICAgICAgICAgIGN1cnJlbnQ9e2N0fVxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiQWRtaW5cIlxyXG4gICAgICAgICAgICAgIGFjdGl2ZUNsYXNzPVwiYmctY3lhbi02MDBcIlxyXG4gICAgICAgICAgICAgIEljb249e01kQWRtaW5QYW5lbFNldHRpbmdzfVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXtvbkN0Q2hhbmdlfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHtjdCA9PT0gXCJuZXdcIiAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWVtZXJhbGQtNTAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTIwMCByb3VuZGVkLXhsIHAtNSBtYi00XCI+XHJcbiAgICAgICAgICAgIDxTZWN0aW9uTGFiZWxcclxuICAgICAgICAgICAgICB0YWdDbGFzcz1cImJnLWVtZXJhbGQtMTAwIHRleHQtZW1lcmFsZC04MDBcIlxyXG4gICAgICAgICAgICAgIHRhZz1cIk5FV1wiXHJcbiAgICAgICAgICAgICAgdGl0bGU9XCJOZXcgQ3VzdG9tZXIgRGV0YWlsc1wiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgIGxhYmVsPVwiQ3VzdG9tZXIgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICBuYW1lPVwibmV3Q3VzdG9tZXJOYW1lXCJcclxuICAgICAgICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJSZXF1aXJlZCFcIiB9XX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTNcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEN1c3RvbWVyIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgbGFiZWw9XCJDdXN0b21lciBQaG9uZVwiXHJcbiAgICAgICAgICAgICAgICBuYW1lPVwibmV3Q3VzdG9tZXJQaG9uZVwiXHJcbiAgICAgICAgICAgICAgICBydWxlcz17W1xyXG4gICAgICAgICAgICAgICAgICB7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIlJlcXVpcmVkIVwiIH0sXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBwYXR0ZXJuOiAvXls2LTldXFxkezl9JC8sXHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogXCJNdXN0IGJlIDEwIGRpZ2l0cyBzdGFydGluZyB3aXRoIDbigJM5XCIsXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItM1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMTAtZGlnaXQgbW9iaWxlXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgIG1heExlbmd0aD17MTB9XHJcbiAgICAgICAgICAgICAgICAgIG9uSW5wdXQ9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWUgPSBlLnRhcmdldC52YWx1ZS5yZXBsYWNlKC9bXjAtOV0vZywgXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiUHVycG9zZSBvZiBDYWxsXCJcclxuICAgICAgICAgICAgICBuYW1lPVwicHVycG9zZU5ld1wiXHJcbiAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIlJlcXVpcmVkIVwiIH1dfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTBcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdCBwbGFjZWhvbGRlcj1cIlNlbGVjdCBwdXJwb3Nl4oCmXCI+XHJcbiAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICBcIkdyb3VwIEVucXVpcmllc1wiLFxyXG4gICAgICAgICAgICAgICAgICBcIkxvYW4gRW5xdWlyaWVzXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiUGlnbXkgRW5xdWlyaWVzXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiU2FsZXNcIixcclxuICAgICAgICAgICAgICAgICAgXCJBZG1pblwiLFxyXG4gICAgICAgICAgICAgICAgXS5tYXAoKHYpID0+IChcclxuICAgICAgICAgICAgICAgICAgPE9wdGlvbiBrZXk9e3Z9IHZhbHVlPXt2fT5cclxuICAgICAgICAgICAgICAgICAgICB7dn1cclxuICAgICAgICAgICAgICAgICAgPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICB7Y3QgPT09IFwiZXhpc3RpbmdcIiAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXZpb2xldC01MCBib3JkZXIgYm9yZGVyLXZpb2xldC0yMDAgcm91bmRlZC14bCBwLTUgbWItNFwiPlxyXG4gICAgICAgICAgICA8U2VjdGlvbkxhYmVsXHJcbiAgICAgICAgICAgICAgdGFnQ2xhc3M9XCJiZy12aW9sZXQtMTAwIHRleHQtdmlvbGV0LTgwMFwiXHJcbiAgICAgICAgICAgICAgdGFnPVwiRVhJU1RJTkdcIlxyXG4gICAgICAgICAgICAgIHRpdGxlPVwiRXhpc3RpbmcgQ3VzdG9tZXIgRGV0YWlsc1wiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICBsYWJlbD1cIlNlYXJjaCBDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgbmFtZT1cInNlYXJjaEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiUGxlYXNlIHNlbGVjdCBhIGN1c3RvbWVyIVwiIH1dfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTNcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggYnkgbmFtZSBvciBwaG9uZeKAplwiXHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17b25DdXN0U2VsfVxyXG4gICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgKG9wdGlvbj8ubGFiZWwgPz8gXCJcIilcclxuICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZ1VzZXJzfVxyXG4gICAgICAgICAgICAgICAgc3VmZml4SWNvbj17PE1kU2VhcmNoIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiIC8+fVxyXG4gICAgICAgICAgICAgICAgb3B0aW9ucz17dXNlcnMubWFwKCh1KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICB2YWx1ZTogdS5faWQsXHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsOiBgJHt1LmZ1bGxfbmFtZSB8fCB1Lm5hbWUgfHwgXCJVbmtub3duXCJ9IOKAlCAke3UucGhvbmVfbnVtYmVyIHx8IHUubW9iaWxlIHx8IFwiTm8gUGhvbmVcIn1gLFxyXG4gICAgICAgICAgICAgICAgfSkpfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICBsYWJlbD1cIkN1c3RvbWVyIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgbmFtZT1cImV4aXN0aW5nQ3VzdG9tZXJOYW1lXCJcclxuICAgICAgICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJSZXF1aXJlZCFcIiB9XX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTNcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkF1dG8tZmlsbGVkXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNTAwIGN1cnNvci1ub3QtYWxsb3dlZCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgbGFiZWw9XCJQaG9uZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgbmFtZT1cImV4aXN0aW5nQ3VzdG9tZXJQaG9uZVwiXHJcbiAgICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiUmVxdWlyZWQhXCIgfV19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi0zXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBdXRvLWZpbGxlZFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTUwMCBjdXJzb3Itbm90LWFsbG93ZWQgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgIGxhYmVsPVwiR3JvdXAgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICBuYW1lPVwiZ3JvdXBOYW1lXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTNcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkF1dG8tZmlsbGVkIGZyb20gZW5yb2xsbWVudFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTUwMCBjdXJzb3Itbm90LWFsbG93ZWQgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgIGxhYmVsPVwiVGlja2V0IE5vXCJcclxuICAgICAgICAgICAgICAgIG5hbWU9XCJ0aWNrZXROdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItM1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQXV0by1maWxsZWQgZnJvbSBlbnJvbGxtZW50XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNTAwIGN1cnNvci1ub3QtYWxsb3dlZCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJjdXN0b21lcklkXCIgaGlkZGVuPlxyXG4gICAgICAgICAgICAgIDxJbnB1dCAvPlxyXG4gICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiUHVycG9zZSBvZiBDYWxsXCJcclxuICAgICAgICAgICAgICBuYW1lPVwicHVycG9zZUV4aXN0aW5nXCJcclxuICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiUmVxdWlyZWQhXCIgfV19XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8U2VsZWN0IHBsYWNlaG9sZGVyPVwiU2VsZWN0IHB1cnBvc2XigKZcIj5cclxuICAgICAgICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgICAgICAgIFwiQmlkIFJlcXVlc3RcIixcclxuICAgICAgICAgICAgICAgICAgXCJBY2NvdW50IFN0YXRlbWVudFwiLFxyXG4gICAgICAgICAgICAgICAgICBcIlBheW1lbnQgU3RhdHVzXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiQWN0aW9uIERhdGVcIixcclxuICAgICAgICAgICAgICAgICAgXCJEb2N1bWVudHNcIixcclxuICAgICAgICAgICAgICAgICAgXCJDaGl0IENhbmNlbGxhdGlvblwiLFxyXG4gICAgICAgICAgICAgICAgICBcIk5ldyBHcm91cCBFbnF1aXJlXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiTG9hbiBFbnF1aXJlXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiUGlnbXkgRW5xdWlyZVwiLFxyXG4gICAgICAgICAgICAgICAgICBcIk90aGVyc1wiLFxyXG4gICAgICAgICAgICAgICAgXS5tYXAoKHYpID0+IChcclxuICAgICAgICAgICAgICAgICAgPE9wdGlvbiBrZXk9e3Z9IHZhbHVlPXt2fT5cclxuICAgICAgICAgICAgICAgICAgICB7dn1cclxuICAgICAgICAgICAgICAgICAgPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICB7Y3QgPT09IFwiZ3Vlc3RcIiAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWFtYmVyLTUwIGJvcmRlciBib3JkZXItYW1iZXItMjAwIHJvdW5kZWQteGwgcC01IG1iLTRcIj5cclxuICAgICAgICAgICAgPFNlY3Rpb25MYWJlbFxyXG4gICAgICAgICAgICAgIHRhZ0NsYXNzPVwiYmctYW1iZXItMTAwIHRleHQtYW1iZXItODAwXCJcclxuICAgICAgICAgICAgICB0YWc9XCJHVUVTVFwiXHJcbiAgICAgICAgICAgICAgdGl0bGU9XCJHdWVzdCBEZXRhaWxzXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgbGFiZWw9XCJHdWVzdCBOYW1lXCJcclxuICAgICAgICAgICAgICAgIG5hbWU9XCJndWVzdE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIlJlcXVpcmVkIVwiIH1dfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItM1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElucHV0IHBsYWNlaG9sZGVyPVwiRW50ZXIgR3Vlc3QgTmFtZVwiIGNsYXNzTmFtZT1cInJvdW5kZWQtbGdcIiAvPlxyXG4gICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgIGxhYmVsPVwiUGhvbmUgTnVtYmVyIChvcHRpb25hbClcIlxyXG4gICAgICAgICAgICAgICAgbmFtZT1cImd1ZXN0UGhvbmVcIlxyXG4gICAgICAgICAgICAgICAgcnVsZXM9e1tcclxuICAgICAgICAgICAgICAgICAgeyByZXF1aXJlZDogZmFsc2UgfSxcclxuICAgICAgICAgICAgICAgICAgeyBwYXR0ZXJuOiAvXlswLTldezEwfSQvLCBtZXNzYWdlOiBcIk11c3QgYmUgMTAgZGlnaXRzXCIgfSxcclxuICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi0zXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJPcHRpb25hbFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezEwfVxyXG4gICAgICAgICAgICAgICAgICBvbklucHV0PXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnZhbHVlID0gZS50YXJnZXQudmFsdWUucmVwbGFjZSgvW14wLTldL2csIFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICBsYWJlbD1cIlB1cnBvc2Ugb2YgQ2FsbFwiXHJcbiAgICAgICAgICAgICAgbmFtZT1cInB1cnBvc2VHdWVzdFwiXHJcbiAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIlJlcXVpcmVkIVwiIH1dfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTBcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdCBwbGFjZWhvbGRlcj1cIlNlbGVjdCBwdXJwb3Nl4oCmXCI+XHJcbiAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICBcIkdlbmVyYWwgRW5xdWlyeVwiLFxyXG4gICAgICAgICAgICAgICAgICBcIkluZm9ybWF0aW9uXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiSW50ZXJ2aWV3XCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiQ29tcGxhaW50XCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiRmVlZGJhY2tcIixcclxuICAgICAgICAgICAgICAgICAgXCJPdGhlcnNcIixcclxuICAgICAgICAgICAgICAgIF0ubWFwKCh2KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxPcHRpb24ga2V5PXt2fSB2YWx1ZT17dn0+XHJcbiAgICAgICAgICAgICAgICAgICAge3Z9XHJcbiAgICAgICAgICAgICAgICAgIDwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuXHJcbiAgICAgICAge2N0ID09PSBcImFkbWluXCIgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1jeWFuLTUwIGJvcmRlciBib3JkZXItY3lhbi0yMDAgcm91bmRlZC14bCBwLTUgbWItNFwiPlxyXG4gICAgICAgICAgICA8U2VjdGlvbkxhYmVsXHJcbiAgICAgICAgICAgICAgdGFnQ2xhc3M9XCJiZy1jeWFuLTEwMCB0ZXh0LWN5YW4tODAwXCJcclxuICAgICAgICAgICAgICB0YWc9XCJBRE1JTlwiXHJcbiAgICAgICAgICAgICAgdGl0bGU9XCJBZG1pbiBEZXRhaWxzXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgbGFiZWw9XCJBZG1pbiBOYW1lXCJcclxuICAgICAgICAgICAgICAgIG5hbWU9XCJhZG1pbk5hbWVfZmllbGRcIlxyXG4gICAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIlJlcXVpcmVkIVwiIH1dfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItM1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElucHV0IHBsYWNlaG9sZGVyPVwiRW50ZXIgQWRtaW4gTmFtZVwiIGNsYXNzTmFtZT1cInJvdW5kZWQtbGdcIiAvPlxyXG4gICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgIGxhYmVsPVwiUGhvbmUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgIG5hbWU9XCJhZG1pblBob25lXCJcclxuICAgICAgICAgICAgICAgIHJ1bGVzPXtbXHJcbiAgICAgICAgICAgICAgICAgIHsgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiUmVxdWlyZWQhXCIgfSxcclxuICAgICAgICAgICAgICAgICAgeyBwYXR0ZXJuOiAvXls2LTldXFxkezl9JC8sIG1lc3NhZ2U6IFwiTXVzdCBiZSAxMCBkaWdpdHMgc3RhcnRpbmcgd2l0aCA24oCTOVwiIH0sXHJcbiAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItM1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMTAtZGlnaXQgbW9iaWxlXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgIG1heExlbmd0aD17MTB9XHJcbiAgICAgICAgICAgICAgICAgIG9uSW5wdXQ9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWUgPSBlLnRhcmdldC52YWx1ZS5yZXBsYWNlKC9bXjAtOV0vZywgXCJcIik7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiRGVwYXJ0bWVudFwiXHJcbiAgICAgICAgICAgICAgbmFtZT1cImFkbWluRGVwYXJ0bWVudFwiXHJcbiAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIlJlcXVpcmVkIVwiIH1dfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTNcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdCBwbGFjZWhvbGRlcj1cIlNlbGVjdCBkZXBhcnRtZW504oCmXCI+XHJcbiAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICBcIk1hbmFnZW1lbnRcIixcclxuICAgICAgICAgICAgICAgICAgXCJBY2NvdW50c1wiLFxyXG4gICAgICAgICAgICAgICAgICBcIk9wZXJhdGlvbnNcIixcclxuICAgICAgICAgICAgICAgICAgXCJTYWxlc1wiLFxyXG4gICAgICAgICAgICAgICAgICBcIk1hcmtldGluZ1wiLFxyXG4gICAgICAgICAgICAgICAgICBcIkhSXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiSVRcIixcclxuICAgICAgICAgICAgICAgICAgXCJDdXN0b21lciBTdXBwb3J0XCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiT3RoZXJzXCIsXHJcbiAgICAgICAgICAgICAgICBdLm1hcCgodikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8T3B0aW9uIGtleT17dn0gdmFsdWU9e3Z9PlxyXG4gICAgICAgICAgICAgICAgICAgIHt2fVxyXG4gICAgICAgICAgICAgICAgICA8L09wdGlvbj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiUHVycG9zZSBvZiBDYWxsXCJcclxuICAgICAgICAgICAgICBuYW1lPVwicHVycG9zZUFkbWluXCJcclxuICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiUmVxdWlyZWQhXCIgfV19XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8U2VsZWN0IHBsYWNlaG9sZGVyPVwiU2VsZWN0IHB1cnBvc2XigKZcIj5cclxuICAgICAgICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgICAgICAgIFwiTWVldGluZyBTY2hlZHVsZWRcIixcclxuICAgICAgICAgICAgICAgICAgXCJGb2xsb3ctdXBcIixcclxuICAgICAgICAgICAgICAgICAgXCJEb2N1bWVudCBWZXJpZmljYXRpb25cIixcclxuICAgICAgICAgICAgICAgICAgXCJQb2xpY3kgRGlzY3Vzc2lvblwiLFxyXG4gICAgICAgICAgICAgICAgICBcIlN5c3RlbSBBY2Nlc3NcIixcclxuICAgICAgICAgICAgICAgICAgXCJUcmFpbmluZ1wiLFxyXG4gICAgICAgICAgICAgICAgICBcIk90aGVyc1wiLFxyXG4gICAgICAgICAgICAgICAgXS5tYXAoKHYpID0+IChcclxuICAgICAgICAgICAgICAgICAgPE9wdGlvbiBrZXk9e3Z9IHZhbHVlPXt2fT5cclxuICAgICAgICAgICAgICAgICAgICB7dn1cclxuICAgICAgICAgICAgICAgICAgPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTUwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQteGwgcHgtNSBweS00IG10LTFcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtNVwiPlxyXG4gICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJEZXNjcmlwdGlvblwiXHJcbiAgICAgICAgICAgICAgbmFtZT1cImRlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgICBydWxlcz17W1xyXG4gICAgICAgICAgICAgICAgeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJQbGVhc2UgZW50ZXIgYSBkZXNjcmlwdGlvbiFcIiB9LFxyXG4gICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8SW5wdXQuVGV4dEFyZWFcclxuICAgICAgICAgICAgICAgIHJvd3M9ezR9XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkJyaWVmIG5vdGVzIGFib3V0IHRoaXMgY2FsbOKAplwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIHJlc2l6ZS1ub25lXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICBsYWJlbD1cIkRhdGVcIlxyXG4gICAgICAgICAgICAgICAgbmFtZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIlBsZWFzZSBzZWxlY3QgYSBkYXRlIVwiIH1dfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItM1wiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPERhdGVQaWNrZXIgY2xhc3NOYW1lPVwidy1mdWxsIHJvdW5kZWQtbGdcIiAvPlxyXG4gICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgIGxhYmVsPVwiQ2FsbCBTdGF0dXNcIlxyXG4gICAgICAgICAgICAgICAgbmFtZT1cImNhbGxTdGF0dXNcIlxyXG4gICAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIlBsZWFzZSBzZWxlY3QgYSBzdGF0dXMhXCIgfV19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi0wXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0IHBsYWNlaG9sZGVyPVwiU2VsZWN0IGNhbGwgc3RhdHVz4oCmXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJIb3RcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLXJlZC01MDAgaW5saW5lLWJsb2NrXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxNZExvY2FsRmlyZURlcGFydG1lbnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT17MTR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgSG90XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L09wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIkNvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLWJsdWUtNTAwIGlubGluZS1ibG9ja1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8TWRBY1VuaXQgc2l6ZT17MTR9IGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ29sZFxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJFbWVyZ2VuY3lcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLW9yYW5nZS01MDAgaW5saW5lLWJsb2NrXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxNZEZsYXNoT24gc2l6ZT17MTR9IGNsYXNzTmFtZT1cInRleHQtb3JhbmdlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICBFbWVyZ2VuY3lcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvPlxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuICAvLyDilIDilIAgUmVuZGVyIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICB7Y29udGV4dEhvbGRlcn1cclxuXHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtc2NyZWVuIG92ZXJmbG93LXgtaGlkZGVuIG10LTIwXCI+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuXHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTBcIj5cclxuICAgICAgICAgIDxOYXZiYXIgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTcgbXQtM1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC14bCBiZy1ibHVlLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgICAgPE1kUGhvbmUgc2l6ZT17MjJ9IGNsYXNzTmFtZT1cInRleHQtd2hpdGVcIiAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgbGVhZGluZy10aWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICBJVlIgQ2FsbCBNYW5hZ2VtZW50XHJcbiAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTUwMCBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgICAgVHJhY2sgYW5kIG1hbmFnZSBhbGwgaW5ib3VuZCAmYW1wOyBvdXRib3VuZCBjdXN0b21lciBjYWxsXHJcbiAgICAgICAgICAgICAgICAgIGVucXVpcmllc1xyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZU9wZW5Nb2RhbH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1ibHVlLTgwMCBob3ZlcjpiZy1ibHVlLTcwMCB0ZXh0LXdoaXRlIHRleHQtc20gZm9udC1ib2xkIHB4LTUgcHktMi41IHJvdW5kZWQteGwgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMTUwIGN1cnNvci1wb2ludGVyIHNoYWRvdy1tZFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8TWRBZGQgc2l6ZT17MTh9IC8+IExvZyBOZXcgQ2FsbFxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMyBtYi04IGZsZXgtd3JhcFwiPlxyXG4gICAgICAgICAgICA8U3RhdENhcmRcclxuICAgICAgICAgICAgICBsYWJlbD1cIlRvdGFsIENhbGxzXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17Y291bnRzLmFsbH1cclxuICAgICAgICAgICAgICBjb2xvckNsYXNzPVwidGV4dC1ibHVlLTcwMFwiXHJcbiAgICAgICAgICAgICAgYmdDbGFzcz1cImJnLWJsdWUtNTBcIlxyXG4gICAgICAgICAgICAgIEljb249e01kQmFyQ2hhcnR9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxTdGF0Q2FyZFxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiTmV3IEN1c3RvbWVyc1wiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2NvdW50cy5uZXd9XHJcbiAgICAgICAgICAgICAgY29sb3JDbGFzcz1cInRleHQtZW1lcmFsZC03MDBcIlxyXG4gICAgICAgICAgICAgIGJnQ2xhc3M9XCJiZy1lbWVyYWxkLTUwXCJcclxuICAgICAgICAgICAgICBJY29uPXtNZFBlcnNvbn1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPFN0YXRDYXJkXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJFeGlzdGluZ1wiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2NvdW50cy5leGlzdGluZ31cclxuICAgICAgICAgICAgICBjb2xvckNsYXNzPVwidGV4dC12aW9sZXQtNzAwXCJcclxuICAgICAgICAgICAgICBiZ0NsYXNzPVwiYmctdmlvbGV0LTUwXCJcclxuICAgICAgICAgICAgICBJY29uPXtNZExvb3B9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxTdGF0Q2FyZFxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiR3Vlc3RzXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17Y291bnRzLmd1ZXN0fVxyXG4gICAgICAgICAgICAgIGNvbG9yQ2xhc3M9XCJ0ZXh0LWFtYmVyLTYwMFwiXHJcbiAgICAgICAgICAgICAgYmdDbGFzcz1cImJnLWFtYmVyLTUwXCJcclxuICAgICAgICAgICAgICBJY29uPXtNZFBlb3BsZUFsdH1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPFN0YXRDYXJkXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJBZG1pblwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2NvdW50cy5hZG1pbn1cclxuICAgICAgICAgICAgICBjb2xvckNsYXNzPVwidGV4dC1jeWFuLTcwMFwiXHJcbiAgICAgICAgICAgICAgYmdDbGFzcz1cImJnLWN5YW4tNTBcIlxyXG4gICAgICAgICAgICAgIEljb249e01kQWRtaW5QYW5lbFNldHRpbmdzfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICB7LyogPFN0YXRDYXJkXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJIb3RcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtjb3VudHMuaG90fVxyXG4gICAgICAgICAgICAgIGNvbG9yQ2xhc3M9XCJ0ZXh0LXJlZC03MDBcIlxyXG4gICAgICAgICAgICAgIGJnQ2xhc3M9XCJiZy1yZWQtNTBcIlxyXG4gICAgICAgICAgICAgIEljb249e01kTG9jYWxGaXJlRGVwYXJ0bWVudH1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPFN0YXRDYXJkXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJDb2xkXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17Y291bnRzLmNvbGR9XHJcbiAgICAgICAgICAgICAgY29sb3JDbGFzcz1cInRleHQtYmx1ZS03MDBcIlxyXG4gICAgICAgICAgICAgIGJnQ2xhc3M9XCJiZy1ibHVlLTUwXCJcclxuICAgICAgICAgICAgICBJY29uPXtNZEFjVW5pdH1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPFN0YXRDYXJkXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJFbWVyZ2VuY3lcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtjb3VudHMuZW1lcmdlbmN5fVxyXG4gICAgICAgICAgICAgIGNvbG9yQ2xhc3M9XCJ0ZXh0LW9yYW5nZS03MDBcIlxyXG4gICAgICAgICAgICAgIGJnQ2xhc3M9XCJiZy1vcmFuZ2UtNTBcIlxyXG4gICAgICAgICAgICAgIEljb249e01kRmxhc2hPbn1cclxuICAgICAgICAgICAgLz4gKi99XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHNoYWRvdy1zbSBwLTZcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItNFwiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwXCI+XHJcbiAgICAgICAgICAgICAgICBSZWNlbnQgQ2FsbCBFbnF1aXJpZXNcclxuICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCBiZy1ibHVlLTUwIHRleHQtYmx1ZS04MDAgYm9yZGVyIGJvcmRlci1ibHVlLTIwMCBweC0zIHB5LTEgcm91bmRlZC1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICB7Zm9ybWF0dGVkRW5xdWlyaWVzLmxlbmd0aH0gcmVjb3Jkc1xyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8VGFic1xyXG4gICAgICAgICAgICAgIGFjdGl2ZUtleT17ZW5xdWlyeVRhYn1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0RW5xdWlyeVRhYn1cclxuICAgICAgICAgICAgICBpdGVtcz17dGFiSXRlbXN9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMlwiXHJcbiAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICB7bG9hZGluZ0VucXVpcmllcyA/IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGgtNDRcIj5cclxuICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e3RydWV9IC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkgOiBmb3JtYXR0ZWRFbnF1aXJpZXMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgaC00NCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgPE1kSW5ib3ggc2l6ZT17NDh9IGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMzAwXCIgLz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgTm8gRW5xdWlyaWVzIEZvdW5kXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIENsaWNrIFwiTG9nIE5ldyBDYWxsXCIgdG8gYWRkIHRoZSBmaXJzdCBlbnRyeS5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICBkYXRhPXtmb3JtYXR0ZWRFbnF1aXJpZXN9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtnZXRFbnF1aXJ5Q29sdW1ucyhlbnF1aXJ5VGFiKX1cclxuICAgICAgICAgICAgICAgIGV4cG9ydENvbHM9e2dldEVucXVpcnlDb2x1bW5zKGVucXVpcnlUYWIpLmZpbHRlcihcclxuICAgICAgICAgICAgICAgICAgKGMpID0+IGMua2V5ICE9PSBcImFjdGlvbnNcIixcclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgRW5xdWlyeSBSZXBvcnRfJHtlbnF1aXJ5VGFifS5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPXtgRW5xdWlyeSBSZXBvcnQgLSAke2VucXVpcnlUYWJ9YH1cclxuICAgICAgICAgICAgICAgIGlzRXhwb3J0RW5hYmxlZD17dHJ1ZX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIOKUgOKUgCBDUkVBVEUgTU9EQUwg4pSA4pSAICovfVxyXG4gICAgICA8TW9kYWxcclxuICAgICAgICBpc1Zpc2libGU9e2lzTW9kYWxPcGVufVxyXG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldElzTW9kYWxPcGVuKGZhbHNlKX1cclxuICAgICAgPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIFwiPlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBwYi0zIG1iLTNcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC14bCBiZy1ibHVlLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgIDxNZFBob25lIHNpemU9ezIwfSBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlXCIgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGxlYWRpbmctdGlnaHRcIj5cclxuICAgICAgICAgICAgICAgIExvZyBDYWxsIEVucXVpcnlcclxuICAgICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGxlYWRpbmctdGlnaHRcIj5cclxuICAgICAgICAgICAgICAgIEZpbGwgaW4gdGhlIGRldGFpbHMgdG8gcmVjb3JkIHRoaXMgY2FsbFxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8Rm9ybSBmb3JtPXtmb3JtfSBsYXlvdXQ9XCJ2ZXJ0aWNhbFwiIG9uRmluaXNoPXtvbkZpbmlzaH0+XHJcbiAgICAgICAgICAgIHtyZW5kZXJGb3JtQm9keShmYWxzZSl9XHJcblxyXG4gICAgICAgICAgICA8Rm9ybS5JdGVtIGNsYXNzTmFtZT1cIm10LTMgbWItMFwiPlxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIGh0bWxUeXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgIGJsb2NrXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ibHVlLTgwMCBob3ZlcjpiZy1ibHVlLTcwMCBoLTEwIHJvdW5kZWQteGwgZm9udC1ib2xkIHRleHQtc20gc2hhZG93LW1kXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBTdWJtaXQgQ2FsbCBFbnF1aXJ5XHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgPC9Gb3JtPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgey8qIOKUgOKUgCBFRElUIE1PREFMIOKUgOKUgCAqL31cclxuICAgICAgPE1vZGFsXHJcbiAgICAgICAgaXNWaXNpYmxlPXtpc0VkaXRNb2RhbE9wZW59XHJcbiAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4gICAgICAgICAgc2V0SXNFZGl0TW9kYWxPcGVuKGZhbHNlKTtcclxuICAgICAgICAgIGVkaXRGb3JtLnJlc2V0RmllbGRzKCk7XHJcbiAgICAgICAgfX1cclxuICAgICAgPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIFwiPlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBwYi0zIG1iLTNcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTcgaC0xMCByb3VuZGVkLXhsIGJnLXZpb2xldC03MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgXCI+XHJcbiAgICAgICAgICAgICAgPE1kRWRpdCBzaXplPXsyMH0gY2xhc3NOYW1lPVwidGV4dC13aGl0ZVwiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBsZWFkaW5nLXRpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICBFZGl0IENhbGwgRW5xdWlyeVxyXG4gICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgbGVhZGluZy10aWdodFwiPlxyXG4gICAgICAgICAgICAgICAgVXBkYXRlIHRoZSBkZXRhaWxzIGZvciB0aGlzIGNhbGwgcmVjb3JkXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxGb3JtIGZvcm09e2VkaXRGb3JtfSBsYXlvdXQ9XCJ2ZXJ0aWNhbFwiIG9uRmluaXNoPXtvbkVkaXRGaW5pc2h9PlxyXG4gICAgICAgICAgICB7cmVuZGVyRm9ybUJvZHkodHJ1ZSl9XHJcblxyXG4gICAgICAgICAgICA8Rm9ybS5JdGVtIGNsYXNzTmFtZT1cIm10LTMgbWItMFwiPlxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgIGh0bWxUeXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgIGJsb2NrXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy12aW9sZXQtNzAwIGhvdmVyOmJnLXZpb2xldC04MDAgaC0xMCByb3VuZGVkLXhsIGZvbnQtYm9sZCB0ZXh0LXNtIHNoYWRvdy1tZFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgU2F2ZSBDaGFuZ2VzXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgPC9Gb3JtPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L01vZGFsPlxyXG5cclxuXHJcbiAgICAgIHsvKiDilIDilIAgREVMRVRFIENPTkZJUk0g4pSA4pSAICovfVxyXG4gICAgICA8RGVsZXRlQ29uZmlybU1vZGFsXHJcbiAgICAgICAgaXNPcGVuPXshIWRlbGV0ZVRhcmdldElkfVxyXG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldERlbGV0ZVRhcmdldElkKG51bGwpfVxyXG4gICAgICAgIG9uQ29uZmlybT17aGFuZGxlRGVsZXRlQ29uZmlybX1cclxuICAgICAgICBsb2FkaW5nPXtkZWxldGVMb2FkaW5nfVxyXG4gICAgICAvPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgRW5xdWlyZUNhbGw7XHJcblxyXG4vLyBpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG4vLyBpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbi8vIGltcG9ydCB7IG5vdGlmaWNhdGlvbiwgRm9ybSwgSW5wdXQsIERhdGVQaWNrZXIsIEJ1dHRvbiwgU2VsZWN0LCBUYWJzIH0gZnJvbSBcImFudGRcIjtcclxuLy8gaW1wb3J0IEFQSSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG4vLyBpbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbi8vIGltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbi8vIGltcG9ydCBkYXlqcyBmcm9tIFwiZGF5anNcIjtcclxuLy8gaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG4vLyBpbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbi8vIGltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5cclxuLy8gY29uc3QgeyBPcHRpb24gfSA9IFNlbGVjdDtcclxuXHJcbi8vIC8vIEhlbHBlciBDb21wb25lbnQgZm9yIFN0YXR1cyBCYWRnZVxyXG4vLyBjb25zdCBDYWxsU3RhdHVzQmFkZ2UgPSAoeyBzdGF0dXMgfSkgPT4ge1xyXG4vLyAgIGxldCBjb2xvckNsYXNzID0gXCJiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNzAwIGJvcmRlci1ncmF5LTIwMFwiO1xyXG5cclxuLy8gICBzd2l0Y2ggKHN0YXR1cykge1xyXG4vLyAgICAgY2FzZSBcIkhvdFwiOlxyXG4vLyAgICAgICBjb2xvckNsYXNzID0gXCJiZy1yZWQtMTAwIHRleHQtcmVkLTcwMCBib3JkZXItcmVkLTIwMFwiO1xyXG4vLyAgICAgICBicmVhaztcclxuLy8gICAgIGNhc2UgXCJDb2xkXCI6XHJcbi8vICAgICAgIGNvbG9yQ2xhc3MgPSBcImJnLWJsdWUtMTAwIHRleHQtYmx1ZS03MDAgYm9yZGVyLWJsdWUtMjAwXCI7XHJcbi8vICAgICAgIGJyZWFrO1xyXG4vLyAgICAgY2FzZSBcIkVtZXJnZW5jeVwiOlxyXG4vLyAgICAgICBjb2xvckNsYXNzID0gXCJiZy1vcmFuZ2UtMTAwIHRleHQtb3JhbmdlLTcwMCBib3JkZXItb3JhbmdlLTIwMFwiO1xyXG4vLyAgICAgICBicmVhaztcclxuLy8gICAgIGRlZmF1bHQ6XHJcbi8vICAgICAgIGJyZWFrO1xyXG4vLyAgIH1cclxuXHJcbi8vICAgcmV0dXJuIChcclxuLy8gICAgIDxzcGFuIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yLjUgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LXNlbWlib2xkIGJvcmRlciAke2NvbG9yQ2xhc3N9YH0+XHJcbi8vICAgICAgIHtzdGF0dXN9XHJcbi8vICAgICA8L3NwYW4+XHJcbi8vICAgKTtcclxuLy8gfTtcclxuXHJcbi8vIGZ1bmN0aW9uIEVucXVpcmVDYWxsKCkge1xyXG4vLyAgIGNvbnN0IFthcGksIGNvbnRleHRIb2xkZXJdID0gbm90aWZpY2F0aW9uLnVzZU5vdGlmaWNhdGlvbigpO1xyXG4vLyAgIGNvbnN0IFtpc01vZGFsT3Blbiwgc2V0SXNNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4vLyAgIGNvbnN0IFtmb3JtXSA9IEZvcm0udXNlRm9ybSgpO1xyXG5cclxuLy8gICBjb25zdCBbZW5xdWlyaWVzLCBzZXRFbnF1aXJpZXNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFtsb2FkaW5nRW5xdWlyaWVzLCBzZXRMb2FkaW5nRW5xdWlyaWVzXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbi8vICAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2xvYWRpbmdVc2Vycywgc2V0TG9hZGluZ1VzZXJzXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuLy8gICBjb25zdCBbYWRtaW5OYW1lLCBzZXRBZG1pbk5hbWVdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4vLyAgIGNvbnN0IFtjdXN0b21lclR5cGUsIHNldEN1c3RvbWVyVHlwZV0gPSB1c2VTdGF0ZShcIm5ld1wiKTtcclxuLy8gICBjb25zdCBbZW5xdWlyeVRhYiwgc2V0RW5xdWlyeVRhYl0gPSB1c2VTdGF0ZShcImFsbFwiKTtcclxuXHJcbi8vICAgY29uc3Qgbm90aWZ5ID0gKHR5cGUsIHRpdGxlLCBkZXNjcmlwdGlvbikgPT4ge1xyXG4vLyAgICAgYXBpW3R5cGVdKHtcclxuLy8gICAgICAgdGl0bGUsXHJcbi8vICAgICAgIGRlc2NyaXB0aW9uLFxyXG4vLyAgICAgICBwbGFjZW1lbnQ6IFwidG9wXCIsXHJcbi8vICAgICAgIGR1cmF0aW9uOiAyLFxyXG4vLyAgICAgICBnZXRDb250YWluZXI6ICgpID0+IGRvY3VtZW50LmJvZHksXHJcbi8vICAgICAgIHN0eWxlOiB7IGxpbmVIZWlnaHQ6IFwiMS4yXCIgfSxcclxuLy8gICAgIH0pO1xyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGZldGNoRW5xdWlyaWVzID0gYXN5bmMgKCkgPT4ge1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgc2V0TG9hZGluZ0VucXVpcmllcyh0cnVlKTtcclxuLy8gICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBUEkuZ2V0KFwiL2VucXVpcnkvYWxsXCIpO1xyXG4vLyAgICAgICBzZXRFbnF1aXJpZXMocmVzcG9uc2UuZGF0YSB8fCBbXSk7XHJcbi8vICAgICAgIHNldExvYWRpbmdFbnF1aXJpZXMoZmFsc2UpO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVucXVpcmllczpcIiwgZXJyb3IpO1xyXG4vLyAgICAgICBzZXRMb2FkaW5nRW5xdWlyaWVzKGZhbHNlKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBmZXRjaEFkbWluUHJvZmlsZSA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGNvbnN0IHVzZXJTdHIgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbi8vICAgICAgIGlmICghdXNlclN0cikgcmV0dXJuO1xyXG4vLyAgICAgICBjb25zdCB1c2VyID0gSlNPTi5wYXJzZSh1c2VyU3RyKTtcclxuLy8gICAgICAgY29uc3QgdXNlcklkID0gdXNlci5faWQ7XHJcbi8vICAgICAgIGlmICghdXNlcklkKSByZXR1cm47XHJcblxyXG4vLyAgICAgICBjb25zdCByZXMgPSBhd2FpdCBBUEkuZ2V0KGAvYWRtaW4vZ2V0LWFkbWluLyR7dXNlcklkfWApO1xyXG4vLyAgICAgICBjb25zdCBuYW1lID0gcmVzLmRhdGEubmFtZSB8fCB1c2VyLmFkbWluX25hbWUgfHwgXCJcIjtcclxuLy8gICAgICAgc2V0QWRtaW5OYW1lKG5hbWUpO1xyXG4vLyAgICAgICBmb3JtLnNldEZpZWxkc1ZhbHVlKHsgYWRtaW5OYW1lOiBuYW1lIH0pO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBhZG1pbiBwcm9maWxlOlwiLCBlcnJvcik7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgZmV0Y2hVc2VycyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIHNldExvYWRpbmdVc2Vycyh0cnVlKTtcclxuLy8gICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBUEkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbi8vICAgICAgIHNldFVzZXJzKHJlc3BvbnNlLmRhdGEgfHwgW10pO1xyXG4vLyAgICAgICBzZXRMb2FkaW5nVXNlcnMoZmFsc2UpO1xyXG4vLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuLy8gICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHVzZXJzOlwiLCBlcnJvcik7XHJcbi8vICAgICAgIHNldExvYWRpbmdVc2VycyhmYWxzZSk7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgZmV0Y2hDdXN0b21lckVucm9sbG1lbnRzID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4vLyAgICAgdHJ5IHtcclxuLy8gICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBBUEkucG9zdChgL2Vucm9sbC9nZXQtdXNlci10aWNrZXRzLXJlcG9ydC8ke3VzZXJJZH1gKTtcclxuXHJcbi8vICAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xyXG4vLyAgICAgICAgIGNvbnN0IGZpcnN0RW5yb2xsbWVudCA9IHJlc3BvbnNlLmRhdGFbMF07XHJcbi8vICAgICAgICAgY29uc3QgZ3JvdXBEYXRhID0gZmlyc3RFbnJvbGxtZW50Py5lbnJvbGxtZW50Py5ncm91cDtcclxuLy8gICAgICAgICBjb25zdCBlbnJvbGxtZW50RGF0YSA9IGZpcnN0RW5yb2xsbWVudD8uZW5yb2xsbWVudDtcclxuXHJcbi8vICAgICAgICAgaWYgKGdyb3VwRGF0YSkge1xyXG4vLyAgICAgICAgICAgZm9ybS5zZXRGaWVsZHNWYWx1ZSh7IGdyb3VwTmFtZTogZ3JvdXBEYXRhLmdyb3VwX25hbWUgfSk7XHJcbi8vICAgICAgICAgfVxyXG4vLyAgICAgICAgIGlmIChlbnJvbGxtZW50RGF0YSkge1xyXG4vLyAgICAgICAgICAgZm9ybS5zZXRGaWVsZHNWYWx1ZSh7XHJcbi8vICAgICAgICAgICAgIHRpY2tldE51bWJlcjogZW5yb2xsbWVudERhdGEudGlja2V0cyB8fCBlbnJvbGxtZW50RGF0YS50aWNrZXRfbnVtYmVyIHx8IFwiTi9BXCJcclxuLy8gICAgICAgICAgIH0pO1xyXG4vLyAgICAgICAgIH1cclxuLy8gICAgICAgfSBlbHNlIHtcclxuLy8gICAgICAgICBmb3JtLnNldEZpZWxkc1ZhbHVlKHsgZ3JvdXBOYW1lOiBcIk5vIEFjdGl2ZSBHcm91cCBGb3VuZFwiLCB0aWNrZXROdW1iZXI6IFwiTi9BXCIgfSk7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbi8vICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBjdXN0b21lciBlbnJvbGxtZW50czpcIiwgZXJyb3IpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGhhbmRsZUN1c3RvbWVyU2VsZWN0ID0gKHVzZXJJZCkgPT4ge1xyXG4vLyAgICAgY29uc3Qgc2VsZWN0ZWRVc2VyID0gdXNlcnMuZmluZCgodSkgPT4gdS5faWQgPT09IHVzZXJJZCk7XHJcbi8vICAgICBpZiAoc2VsZWN0ZWRVc2VyKSB7XHJcbi8vICAgICAgIGNvbnN0IGNOYW1lID0gc2VsZWN0ZWRVc2VyLmZ1bGxfbmFtZSB8fCBzZWxlY3RlZFVzZXIubmFtZTtcclxuLy8gICAgICAgY29uc3QgY1Bob25lID0gc2VsZWN0ZWRVc2VyLnBob25lX251bWJlciB8fCBzZWxlY3RlZFVzZXIubW9iaWxlO1xyXG5cclxuLy8gICAgICAgZm9ybS5zZXRGaWVsZHNWYWx1ZSh7XHJcbi8vICAgICAgICAgc2VhcmNoQ3VzdG9tZXI6IHVzZXJJZCxcclxuLy8gICAgICAgICBjdXN0b21lcklkOiB1c2VySWQsXHJcbi8vICAgICAgICAgZXhpc3RpbmdDdXN0b21lck5hbWU6IGNOYW1lLFxyXG4vLyAgICAgICAgIGV4aXN0aW5nQ3VzdG9tZXJQaG9uZTogY1Bob25lLFxyXG4vLyAgICAgICB9KTtcclxuLy8gICAgICAgZmV0Y2hDdXN0b21lckVucm9sbG1lbnRzKHVzZXJJZCk7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGZldGNoRW5xdWlyaWVzKCk7XHJcbi8vICAgfSwgW10pO1xyXG5cclxuLy8gICBjb25zdCBoYW5kbGVPcGVuTW9kYWwgPSAoKSA9PiB7XHJcbi8vICAgICBzZXRJc01vZGFsT3Blbih0cnVlKTtcclxuLy8gICAgIGZvcm0ucmVzZXRGaWVsZHMoKTtcclxuLy8gICAgIHNldEN1c3RvbWVyVHlwZShcIm5ld1wiKTtcclxuLy8gICAgIGZldGNoQWRtaW5Qcm9maWxlKCk7XHJcbi8vICAgICBmZXRjaFVzZXJzKCk7XHJcbi8vICAgICBmb3JtLnNldEZpZWxkc1ZhbHVlKHsgZGF0ZTogZGF5anMoKSB9KTtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBvbkZpbmlzaCA9IGFzeW5jICh2YWx1ZXMpID0+IHtcclxuLy8gICAgIHRyeSB7XHJcbi8vICAgICAgIGxldCBwYXlsb2FkID0ge1xyXG4vLyAgICAgICAgIGFkbWluTmFtZTogdmFsdWVzLmFkbWluTmFtZSxcclxuLy8gICAgICAgICBkZXNjcmlwdGlvbjogdmFsdWVzLmRlc2NyaXB0aW9uLFxyXG4vLyAgICAgICAgIGRhdGU6IHZhbHVlcy5kYXRlID8gdmFsdWVzLmRhdGUuZm9ybWF0KCdZWVlZLU1NLUREJykgOiBudWxsLFxyXG4vLyAgICAgICB9O1xyXG5cclxuLy8gICAgICAgaWYgKGN1c3RvbWVyVHlwZSA9PT0gJ25ldycpIHtcclxuLy8gICAgICAgICBwYXlsb2FkLmN1c3RvbWVyVHlwZSA9ICduZXcnO1xyXG4vLyAgICAgICAgIHBheWxvYWQuY3VzdG9tZXJOYW1lID0gdmFsdWVzLm5ld0N1c3RvbWVyTmFtZTtcclxuLy8gICAgICAgICBwYXlsb2FkLmN1c3RvbWVyUGhvbmUgPSB2YWx1ZXMubmV3Q3VzdG9tZXJQaG9uZTtcclxuLy8gICAgICAgICBwYXlsb2FkLnB1cnBvc2UgPSB2YWx1ZXMucHVycG9zZU5ldztcclxuLy8gICAgICAgICBwYXlsb2FkLmNhbGxTdGF0dXMgPSB2YWx1ZXMuY2FsbFN0YXR1cztcclxuLy8gICAgICAgfSBlbHNlIGlmIChjdXN0b21lclR5cGUgPT09ICdleGlzdGluZycpIHtcclxuLy8gICAgICAgICBwYXlsb2FkLmN1c3RvbWVyVHlwZSA9ICdvbGQnO1xyXG4vLyAgICAgICAgIHBheWxvYWQuY3VzdG9tZXJJZCA9IHZhbHVlcy5jdXN0b21lcklkO1xyXG4vLyAgICAgICAgIHBheWxvYWQuY3VzdG9tZXJOYW1lID0gdmFsdWVzLmV4aXN0aW5nQ3VzdG9tZXJOYW1lO1xyXG4vLyAgICAgICAgIHBheWxvYWQuY3VzdG9tZXJQaG9uZSA9IHZhbHVlcy5leGlzdGluZ0N1c3RvbWVyUGhvbmU7XHJcbi8vICAgICAgICAgcGF5bG9hZC5ncm91cE5hbWUgPSB2YWx1ZXMuZ3JvdXBOYW1lO1xyXG4vLyAgICAgICAgIHBheWxvYWQudGlja2V0TnVtYmVyID0gdmFsdWVzLnRpY2tldE51bWJlcjtcclxuLy8gICAgICAgICBwYXlsb2FkLnB1cnBvc2UgPSB2YWx1ZXMucHVycG9zZUV4aXN0aW5nO1xyXG4vLyAgICAgICAgIHBheWxvYWQuY2FsbFN0YXR1cyA9IHZhbHVlcy5jYWxsU3RhdHVzO1xyXG4vLyAgICAgICB9IGVsc2UgaWYgKGN1c3RvbWVyVHlwZSA9PT0gJ2d1ZXN0Jykge1xyXG4vLyAgICAgICAgIHBheWxvYWQuY3VzdG9tZXJUeXBlID0gJ2d1ZXN0JztcclxuLy8gICAgICAgICBwYXlsb2FkLmN1c3RvbWVyTmFtZSA9IHZhbHVlcy5ndWVzdE5hbWU7XHJcbi8vICAgICAgICAgcGF5bG9hZC5jdXN0b21lclBob25lID0gdmFsdWVzLmd1ZXN0UGhvbmUgfHwgJ04vQSc7XHJcbi8vICAgICAgICAgcGF5bG9hZC5wdXJwb3NlID0gdmFsdWVzLnB1cnBvc2VHdWVzdDtcclxuLy8gICAgICAgICBwYXlsb2FkLmNhbGxTdGF0dXMgPSB2YWx1ZXMuY2FsbFN0YXR1cztcclxuLy8gICAgICAgICBwYXlsb2FkLmd1ZXN0TmFtZSA9IHZhbHVlcy5ndWVzdE5hbWU7XHJcbi8vICAgICAgICAgcGF5bG9hZC5ndWVzdFBob25lID0gdmFsdWVzLmd1ZXN0UGhvbmU7XHJcbi8vICAgICAgIH1cclxuXHJcbi8vICAgICAgIGF3YWl0IEFQSS5wb3N0KFwiL2VucXVpcnkvY3JlYXRlXCIsIHBheWxvYWQpO1xyXG5cclxuLy8gICAgICAgbm90aWZ5KFwic3VjY2Vzc1wiLCBcIlN1Y2Nlc3NcIiwgXCJZb3VyIGVucXVpcnkgaGFzIGJlZW4gc3VibWl0dGVkIHN1Y2Nlc3NmdWxseSFcIik7XHJcbi8vICAgICAgIGZldGNoRW5xdWlyaWVzKCk7XHJcblxyXG4vLyAgICAgICBzZXRJc01vZGFsT3BlbihmYWxzZSk7XHJcbi8vICAgICAgIGZvcm0ucmVzZXRGaWVsZHMoKTtcclxuLy8gICAgICAgc2V0Q3VzdG9tZXJUeXBlKFwibmV3XCIpO1xyXG4vLyAgICAgICBzZXRBZG1pbk5hbWUoXCJcIik7XHJcbi8vICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4vLyAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3Igc3VibWl0dGluZyBlbnF1aXJ5OlwiLCBlcnJvcik7XHJcbi8vICAgICAgIG5vdGlmeShcImVycm9yXCIsIFwiRXJyb3JcIiwgXCJGYWlsZWQgdG8gc3VibWl0IGVucXVpcnlcIik7XHJcbi8vICAgICB9XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgZ2V0RW5xdWlyeUNvbHVtbnMgPSAodGFiKSA9PiB7XHJcbi8vICAgICBjb25zdCBiYXNlQ29sdW1ucyA9IFtcclxuLy8gICAgICAgeyBrZXk6IFwiYWRtaW5OYW1lXCIsIGhlYWRlcjogXCJBZG1pbiBOYW1lXCIgfSxcclxuLy8gICAgICAgeyBrZXk6IFwiY3VzdG9tZXJOYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuLy8gICAgICAgeyBrZXk6IFwiY3VzdG9tZXJQaG9uZVwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuLy8gICAgICAgeyBrZXk6IFwicHVycG9zZVwiLCBoZWFkZXI6IFwiUHVycG9zZVwiIH0sXHJcbi8vICAgICAgIHtcclxuLy8gICAgICAgICBrZXk6IFwiY2FsbFN0YXR1c1wiLFxyXG4vLyAgICAgICAgIGhlYWRlcjogXCJDYWxsIFN0YXR1c1wiLFxyXG4vLyAgICAgICAgIHJlbmRlcjogKHRleHQpID0+IDxDYWxsU3RhdHVzQmFkZ2Ugc3RhdHVzPXt0ZXh0fSAvPlxyXG4vLyAgICAgICB9LFxyXG4vLyAgICAgICB7IGtleTogXCJkZXNjcmlwdGlvblwiLCBoZWFkZXI6IFwiRGVzY3JpcHRpb25cIiB9LFxyXG4vLyAgICAgICB7IGtleTogXCJkYXRlXCIsIGhlYWRlcjogXCJEYXRlXCIgfSxcclxuLy8gICAgIF07XHJcblxyXG4vLyAgICAgaWYgKHRhYiA9PT0gJ2FsbCcpIHtcclxuLy8gICAgICAgcmV0dXJuIFtcclxuLy8gICAgICAgICB7IGtleTogXCJjdXN0b21lclR5cGVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIFR5cGVcIiB9LFxyXG4vLyAgICAgICAgIC4uLmJhc2VDb2x1bW5zLFxyXG4vLyAgICAgICAgIHsga2V5OiBcImdyb3VwTmFtZVwiLCBoZWFkZXI6IFwiR3JvdXBcIiB9LFxyXG4vLyAgICAgICAgIHsga2V5OiBcInRpY2tldE51bWJlclwiLCBoZWFkZXI6IFwiVGlja2V0IE5vXCIgfSxcclxuLy8gICAgICAgXTtcclxuLy8gICAgIH0gZWxzZSBpZiAodGFiID09PSAnbmV3Jykge1xyXG4vLyAgICAgICByZXR1cm4gYmFzZUNvbHVtbnM7XHJcbi8vICAgICB9IGVsc2UgaWYgKHRhYiA9PT0gJ2V4aXN0aW5nJykge1xyXG4vLyAgICAgICByZXR1cm4gW1xyXG4vLyAgICAgICAgIC4uLmJhc2VDb2x1bW5zLFxyXG4vLyAgICAgICAgIHsga2V5OiBcImdyb3VwTmFtZVwiLCBoZWFkZXI6IFwiR3JvdXBcIiB9LFxyXG4vLyAgICAgICAgIHsga2V5OiBcInRpY2tldE51bWJlclwiLCBoZWFkZXI6IFwiVGlja2V0IE5vXCIgfSxcclxuLy8gICAgICAgXTtcclxuLy8gICAgIH0gZWxzZSBpZiAodGFiID09PSAnZ3Vlc3QnKSB7XHJcbi8vICAgICAgIHJldHVybiBiYXNlQ29sdW1ucztcclxuLy8gICAgIH1cclxuLy8gICAgIHJldHVybiBiYXNlQ29sdW1ucztcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBnZXRGaWx0ZXJlZEVucXVpcmllcyA9ICgpID0+IHtcclxuLy8gICAgIGlmIChlbnF1aXJ5VGFiID09PSAnbmV3Jykge1xyXG4vLyAgICAgICByZXR1cm4gZW5xdWlyaWVzLmZpbHRlcihpdGVtID0+IGl0ZW0uY3VzdG9tZXJUeXBlID09PSAnbmV3Jyk7XHJcbi8vICAgICB9IGVsc2UgaWYgKGVucXVpcnlUYWIgPT09ICdleGlzdGluZycpIHtcclxuLy8gICAgICAgcmV0dXJuIGVucXVpcmllcy5maWx0ZXIoaXRlbSA9PiBpdGVtLmN1c3RvbWVyVHlwZSA9PT0gJ29sZCcpO1xyXG4vLyAgICAgfSBlbHNlIGlmIChlbnF1aXJ5VGFiID09PSAnZ3Vlc3QnKSB7XHJcbi8vICAgICAgIHJldHVybiBlbnF1aXJpZXMuZmlsdGVyKGl0ZW0gPT4gaXRlbS5jdXN0b21lclR5cGUgPT09ICdndWVzdCcpO1xyXG4vLyAgICAgfVxyXG4vLyAgICAgcmV0dXJuIGVucXVpcmllcztcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBmb3JtYXR0ZWRFbnF1aXJpZXMgPSBnZXRGaWx0ZXJlZEVucXVpcmllcygpLm1hcCgoaXRlbSkgPT4ge1xyXG4vLyAgICAgcmV0dXJuIHtcclxuLy8gICAgICAgLi4uaXRlbSxcclxuLy8gICAgICAgZGF0ZTogaXRlbS5kYXRlID8gZGF5anMoaXRlbS5kYXRlKS5mb3JtYXQoJ0RELU1NLVlZWVknKSA6IFwiLVwiLFxyXG4vLyAgICAgICBjdXN0b21lclR5cGU6IGl0ZW0uY3VzdG9tZXJUeXBlID09PSAnbmV3JyA/ICdOZXcgQ3VzdG9tZXInIDpcclxuLy8gICAgICAgICBpdGVtLmN1c3RvbWVyVHlwZSA9PT0gJ29sZCcgPyAnRXhpc3RpbmcgQ3VzdG9tZXInIDogJ0d1ZXN0J1xyXG4vLyAgICAgfTtcclxuLy8gICB9KTtcclxuXHJcbi8vICAgY29uc3QgdGFiSXRlbXMgPSBbXHJcbi8vICAgICB7XHJcbi8vICAgICAgIGtleTogJ2FsbCcsXHJcbi8vICAgICAgIGxhYmVsOiBgQWxsICgke2VucXVpcmllcy5sZW5ndGh9KWAsXHJcbi8vICAgICAgIGNoaWxkcmVuOiBudWxsLFxyXG4vLyAgICAgfSxcclxuLy8gICAgIHtcclxuLy8gICAgICAga2V5OiAnbmV3JyxcclxuLy8gICAgICAgbGFiZWw6IGBOZXcgQ3VzdG9tZXIgKCR7ZW5xdWlyaWVzLmZpbHRlcihlID0+IGUuY3VzdG9tZXJUeXBlID09PSAnbmV3JykubGVuZ3RofSlgLFxyXG4vLyAgICAgICBjaGlsZHJlbjogbnVsbCxcclxuLy8gICAgIH0sXHJcbi8vICAgICB7XHJcbi8vICAgICAgIGtleTogJ2V4aXN0aW5nJyxcclxuLy8gICAgICAgbGFiZWw6IGBFeGlzdGluZyBDdXN0b21lciAoJHtlbnF1aXJpZXMuZmlsdGVyKGUgPT4gZS5jdXN0b21lclR5cGUgPT09ICdvbGQnKS5sZW5ndGh9KWAsXHJcbi8vICAgICAgIGNoaWxkcmVuOiBudWxsLFxyXG4vLyAgICAgfSxcclxuLy8gICAgIHtcclxuLy8gICAgICAga2V5OiAnZ3Vlc3QnLFxyXG4vLyAgICAgICBsYWJlbDogYEd1ZXN0ICgke2VucXVpcmllcy5maWx0ZXIoZSA9PiBlLmN1c3RvbWVyVHlwZSA9PT0gJ2d1ZXN0JykubGVuZ3RofSlgLFxyXG4vLyAgICAgICBjaGlsZHJlbjogbnVsbCxcclxuLy8gICAgIH0sXHJcbi8vICAgXTtcclxuXHJcbi8vICAgcmV0dXJuIChcclxuLy8gICAgIDw+XHJcbi8vICAgICAgIHtjb250ZXh0SG9sZGVyfVxyXG4vLyAgICAgICA8TmF2YmFyIC8+XHJcblxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggdy1zY3JlZW4gbXQtMTRcIj5cclxuLy8gICAgICAgICA8U2lkZWJhciAvPlxyXG5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtY29sIHctZnVsbCBwLTRcIj5cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWItNCBqdXN0aWZ5LWJldHdlZW5cIj5cclxuLy8gICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCBteS01XCI+Q2FsbCBNYW5hZ2VtZW50PC9oMj5cclxuXHJcbi8vICAgICAgICAgICAgIDxidXR0b25cclxuLy8gICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVPcGVuTW9kYWx9XHJcbi8vICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBiZy1ibHVlLTgwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHB4LTQgcHktMiByb3VuZGVkLW1kIGhvdmVyOmJnLWJsdWUtMzAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxyXG4vLyAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgRW5xdWlyZSBDYWxsXHJcbi8vICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgey8qIEVOUVVJUlkgVEFCUyBTRUNUSU9OICovfVxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMCBtaW4taC1bMzAwcHhdXCI+XHJcbi8vICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBtYi00XCI+UmVjZW50IEVucXVpcmllcyBDYWxsPC9oMz5cclxuXHJcbi8vICAgICAgICAgICAgIDxUYWJzXHJcbi8vICAgICAgICAgICAgICAgYWN0aXZlS2V5PXtlbnF1aXJ5VGFifVxyXG4vLyAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoa2V5KSA9PiBzZXRFbnF1aXJ5VGFiKGtleSl9XHJcbi8vICAgICAgICAgICAgICAgaXRlbXM9e3RhYkl0ZW1zfVxyXG4vLyAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTRcIlxyXG4vLyAgICAgICAgICAgICAvPlxyXG5cclxuLy8gICAgICAgICAgICAge2xvYWRpbmdFbnF1aXJpZXMgPyAoXHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBoLTQwXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXt0cnVlfSAvPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICApIDogZm9ybWF0dGVkRW5xdWlyaWVzLmxlbmd0aCA9PT0gMCA/IChcclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNiByb3VuZGVkLWxnIHNoYWRvdyBib3JkZXIgdGV4dC1jZW50ZXIgdGV4dC1ncmF5LTUwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bVwiPk5vIEVucXVpcmllcyBGb3VuZDwvcD5cclxuLy8gICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc21cIj5DbGljayBcIkVucXVpcmUgQ2FsbFwiIHRvIGFkZCBhIG5ldyBlbnRyeS48L3A+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4vLyAgICAgICAgICAgICAgICAgZGF0YT17Zm9ybWF0dGVkRW5xdWlyaWVzfVxyXG4vLyAgICAgICAgICAgICAgICAgY29sdW1ucz17Z2V0RW5xdWlyeUNvbHVtbnMoZW5xdWlyeVRhYil9XHJcbi8vICAgICAgICAgICAgICAgICBleHBvcnRDb2xzPXtnZXRFbnF1aXJ5Q29sdW1ucyhlbnF1aXJ5VGFiKX1cclxuLy8gICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BFbnF1aXJ5IFJlcG9ydF8ke2VucXVpcnlUYWJ9LmNzdmB9XHJcbi8vICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9e2BFbnF1aXJ5IFJlcG9ydCAtICR7ZW5xdWlyeVRhYn1gfVxyXG4vLyAgICAgICAgICAgICAgICAgaXNFeHBvcnRFbmFibGVkPXt0cnVlfVxyXG4vLyAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICl9XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICB7LyogRU5RVUlSRSBDQUxMIE1PREFMICovfVxyXG4vLyAgICAgICAgICAgPE1vZGFsIGlzVmlzaWJsZT17aXNNb2RhbE9wZW59IG9uQ2xvc2U9eygpID0+IHNldElzTW9kYWxPcGVuKGZhbHNlKX0+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbi8vICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIG1iLTYgdGV4dC1ibHVlLTgwMCBib3JkZXItYiBwYi0yXCI+RW5xdWlyZSBDYWxsPC9oMj5cclxuXHJcbi8vICAgICAgICAgICAgICAgPEZvcm0gZm9ybT17Zm9ybX0gbGF5b3V0PVwidmVydGljYWxcIiBvbkZpbmlzaD17b25GaW5pc2h9IGNsYXNzTmFtZT1cImZvbnQtc2Fuc1wiPlxyXG5cclxuLy8gICAgICAgICAgICAgICAgIHsvKiBBRE1JTiBOQU1FICovfVxyXG4vLyAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4vLyAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkFkbWluIE5hbWVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICBuYW1lPVwiYWRtaW5OYW1lXCJcclxuLy8gICAgICAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiAnQWRtaW4gTmFtZSBpcyByZXF1aXJlZCEnIH1dfVxyXG4vLyAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi00XCJcclxuLy8gICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgPElucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBdXRvLWZldGNoZWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbi8vICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTYwMCBjdXJzb3Itbm90LWFsbG93ZWQgcm91bmRlZC1tZCBzaGFkb3ctc21cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgey8qIENVU1RPTUVSIFRZUEUgU0VMRUNUT1IgKi99XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgcC00IGJnLWdyYXktNTAgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJsdWUtMTAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1ib2xkIHRleHQtYmx1ZS05MDBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICBDdXN0b21lciBUeXBlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuLy8gICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC1tZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1c3RvbWVyVHlwZX1cclxuLy8gICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBzZXRDdXN0b21lclR5cGUodmFsdWUpO1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgZm9ybS5yZXNldEZpZWxkcyhbXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICduZXdDdXN0b21lck5hbWUnLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAnbmV3Q3VzdG9tZXJQaG9uZScsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICdwdXJwb3NlTmV3JyxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgJ2N1c3RvbWVySWQnLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAnZXhpc3RpbmdDdXN0b21lck5hbWUnLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAnZXhpc3RpbmdDdXN0b21lclBob25lJyxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgJ2dyb3VwTmFtZScsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICd0aWNrZXROdW1iZXInLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAncHVycG9zZUV4aXN0aW5nJyxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgJ3NlYXJjaEN1c3RvbWVyJyxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgJ2d1ZXN0TmFtZScsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICdndWVzdFBob25lJyxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgJ3B1cnBvc2VHdWVzdCcsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICdkZXNjcmlwdGlvbicsXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICdjYWxsU3RhdHVzJ1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgXSk7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBmb3JtLnNldEZpZWxkc1ZhbHVlKHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY3VzdG9tZXJUeXBlOiB2YWx1ZSxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgZGF0ZTogZGF5anMoKVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgfX1cclxuLy8gICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJuZXdcIj5OZXcgQ3VzdG9tZXI8L09wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiZXhpc3RpbmdcIj5FeGlzdGluZyBDdXN0b21lcjwvT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJndWVzdFwiPkd1ZXN0PC9PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgey8qIE5FVyBDVVNUT01FUiBGSUVMRFMgKi99XHJcbi8vICAgICAgICAgICAgICAgICB7Y3VzdG9tZXJUeXBlID09PSAnbmV3JyAmJiAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBwLTUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWJsdWUtMTAwIGJnLWJsdWUtNTAvMzBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LWJsdWUtOTAwIG1iLTQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJnLWJsdWUtMTAwIHRleHQtYmx1ZS04MDAgcC0xIHJvdW5kZWQgdGV4dC14c1wiPk5FVzwvc3Bhbj4gQ3VzdG9tZXIgRGV0YWlsc1xyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiQ3VzdG9tZXIgTmFtZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJuZXdDdXN0b21lck5hbWVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6ICdSZXF1aXJlZCEnIH1dfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi0wXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0IHBsYWNlaG9sZGVyPVwiRW50ZXIgQ3VzdG9tZXIgTmFtZVwiIGNsYXNzTmFtZT1cInJvdW5kZWQtbWRcIiAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiQ3VzdG9tZXIgUGhvbmVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwibmV3Q3VzdG9tZXJQaG9uZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogJ1JlcXVpcmVkIScgfSxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXR0ZXJuOiAvXls2LTldXFxkezl9JC8sXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlBob25lIG51bWJlciBtdXN0IGJlIDEwIGRpZ2l0cyBzdGFydGluZyB3aXRoIDYtOVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBdfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi0wXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIxMC1kaWdpdCBudW1iZXJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbWRcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heExlbmd0aD17MTB9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgb25JbnB1dD17KGUpID0+IHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUudGFyZ2V0LnZhbHVlID0gZS50YXJnZXQudmFsdWUucmVwbGFjZSgvW14wLTldL2csICcnKTtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiUHVycG9zZSBvZiBDYWxsXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInB1cnBvc2VOZXdcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6ICdSZXF1aXJlZCEnIH1dfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0IHBsYWNlaG9sZGVyPVwiU2VsZWN0IFB1cnBvc2VcIiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIkdyb3VwIEVucXVpcmllc1wiPkdyb3VwIEVucXVpcmllczwvT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJMb2FuIEVucXVpcmllc1wiPkxvYW4gRW5xdWlyaWVzPC9PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIlBpZ215IEVucXVpcmllc1wiPlBpZ215IEVucXVpcmllczwvT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJTYWxlc1wiPlNhbGVzPC9PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIkFkbWluXCI+QWRtaW48L09wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICApfVxyXG5cclxuLy8gICAgICAgICAgICAgICAgIHsvKiBFWElTVElORyBDVVNUT01FUiBGSUVMRFMgKi99XHJcbi8vICAgICAgICAgICAgICAgICB7Y3VzdG9tZXJUeXBlID09PSAnZXhpc3RpbmcnICYmIChcclxuLy8gICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00IHAtNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctZ3JheS01MFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgbWItNCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctZ3JheS0yMDAgdGV4dC1ncmF5LTcwMCBwLTEgcm91bmRlZCB0ZXh0LXhzXCI+RVhJU1RJTkc8L3NwYW4+IEN1c3RvbWVyIERldGFpbHNcclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJTZWFyY2ggQ3VzdG9tZXJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwic2VhcmNoQ3VzdG9tZXJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6ICdQbGVhc2Ugc2VhcmNoIGFuZCBzZWxlY3QgYSBjdXN0b21lciEnIH1dfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGJ5IHBob25lIG51bWJlciBvciBuYW1lLi4uXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ3VzdG9tZXJTZWxlY3R9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT4gKG9wdGlvbj8ubGFiZWwgPz8gXCJcIikudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nVXNlcnN9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1tZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17dXNlcnMubWFwKCh1c2VyKSA9PiAoe1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IHVzZXIuX2lkLFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IGAke3VzZXIuZnVsbF9uYW1lIHx8IHVzZXIubmFtZSB8fCAnVW5rbm93biBOYW1lJ30gLSAke3VzZXIucGhvbmVfbnVtYmVyIHx8IHVzZXIubW9iaWxlIHx8ICdObyBQaG9uZSd9YCxcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB9KSl9XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiQ3VzdG9tZXIgTmFtZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJleGlzdGluZ0N1c3RvbWVyTmFtZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogJ1JlcXVpcmVkIScgfV19XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTBcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBDdXN0b21lciBhYm92ZVwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTEwMCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTYwMCBjdXJzb3Itbm90LWFsbG93ZWQgcm91bmRlZC1tZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJQaG9uZSBOdW1iZXJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZXhpc3RpbmdDdXN0b21lclBob25lXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiAnUmVxdWlyZWQhJyB9XX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEN1c3RvbWVyIGFib3ZlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktMTAwIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktNjAwIGN1cnNvci1ub3QtYWxsb3dlZCByb3VuZGVkLW1kXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTQgbXQtNFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkdyb3VwIE5hbWVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3JvdXBOYW1lXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiAnUmVxdWlyZWQhJyB9XX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEN1c3RvbWVyIHRvIGZldGNoIEdyb3VwXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktMTAwIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktNjAwIGN1cnNvci1ub3QtYWxsb3dlZCByb3VuZGVkLW1kXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlRpY2tldCBOb1wiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0aWNrZXROdW1iZXJcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6ICdSZXF1aXJlZCEnIH1dfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi0wXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgQ3VzdG9tZXIgdG8gZmV0Y2ggVGlja2V0XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktMTAwIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktNjAwIGN1cnNvci1ub3QtYWxsb3dlZCByb3VuZGVkLW1kXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJjdXN0b21lcklkXCIgaGlkZGVuPjxJbnB1dCAvPjwvRm9ybS5JdGVtPlxyXG5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJQdXJwb3NlIG9mIENhbGxcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicHVycG9zZUV4aXN0aW5nXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiAnUmVxdWlyZWQhJyB9XX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdCBwbGFjZWhvbGRlcj1cIlNlbGVjdCBQdXJwb3NlXCIgY2xhc3NOYW1lPVwicm91bmRlZC1tZFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJCaWQgUmVxdWVzdFwiPkJpZCBSZXF1ZXN0PC9PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIkFjY291bnQgU3RhdGVtZW50XCI+QWNjb3VudCBTdGF0ZW1lbnQ8L09wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiUGF5bWVudCBTdGF0dXNcIj5QYXltZW50IFN0YXR1czwvT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJBY3Rpb24gRGF0ZVwiPkFjdGlvbiBEYXRlPC9PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIkRvY3VtZW50c1wiPkRvY3VtZW50czwvT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJDaGl0IENhbmNlbGxhdGlvblwiPkNoaXQgQ2FuY2VsbGF0aW9uPC9PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIk5ldyBHcm91cCBFbnF1aXJlXCI+TmV3IEdyb3VwIEVucXVpcmU8L09wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiTG9hbiBFbnF1aXJlXCI+TG9hbiBFbnF1aXJlPC9PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIlBpZ215IEVucXVpcmVcIj5QaWdteSBFbnF1aXJlPC9PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIk90aGVyc1wiPk90aGVyczwvT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICl9XHJcblxyXG4vLyAgICAgICAgICAgICAgICAgey8qIEdVRVNUIENVU1RPTUVSIEZJRUxEUyAqL31cclxuLy8gICAgICAgICAgICAgICAgIHtjdXN0b21lclR5cGUgPT09ICdndWVzdCcgJiYgKFxyXG4vLyAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgcC01IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1wdXJwbGUtMTAwIGJnLXB1cnBsZS01MC8zMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtcHVycGxlLTkwMCBtYi00IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1wdXJwbGUtMTAwIHRleHQtcHVycGxlLTgwMCBwLTEgcm91bmRlZCB0ZXh0LXhzXCI+R1VFU1Q8L3NwYW4+IEd1ZXN0IERldGFpbHNcclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkd1ZXN0IE5hbWVcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZ3Vlc3ROYW1lXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiAnUmVxdWlyZWQhJyB9XX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItMFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dCBwbGFjZWhvbGRlcj1cIkVudGVyIEd1ZXN0IE5hbWVcIiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlBob25lIE51bWJlclwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJndWVzdFBob25lXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgcnVsZXM9e1tcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB7IHJlcXVpcmVkOiBmYWxzZSB9LFxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhdHRlcm46IC9eWzAtOV17MTB9JC8sXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlBob25lIG51bWJlciBtdXN0IGJlIDEwIGRpZ2l0c1wiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBdfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi0wXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJPcHRpb25hbCAtIDEwLWRpZ2l0IG51bWJlclwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1tZFwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXsxMH1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICBvbklucHV0PXsoZSkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZS50YXJnZXQudmFsdWUgPSBlLnRhcmdldC52YWx1ZS5yZXBsYWNlKC9bXjAtOV0vZywgJycpO1xyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTRcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJQdXJwb3NlIG9mIENhbGxcIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicHVycG9zZUd1ZXN0XCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiAnUmVxdWlyZWQhJyB9XX1cclxuLy8gICAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdCBwbGFjZWhvbGRlcj1cIlNlbGVjdCBQdXJwb3NlXCIgY2xhc3NOYW1lPVwicm91bmRlZC1tZFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJHZW5lcmFsIEVucXVpcnlcIj5HZW5lcmFsIEVucXVpcnk8L09wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiSW5mb3JtYXRpb25cIj5JbmZvcm1hdGlvbjwvT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJJbnRlcnZpZXdcIj5JbnRlcnZpZXc8L09wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiQ29tcGxhaW50XCI+Q29tcGxhaW50PC9PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIkZlZWRiYWNrXCI+RmVlZGJhY2s8L09wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiT3RoZXJzXCI+T3RoZXJzPC9PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICAgICAgKX1cclxuXHJcbi8vICAgICAgICAgICAgICAgICB7LyogQ09NTU9OIEZJRUxEUyAqL31cclxuLy8gICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNCBtdC0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJEZXNjcmlwdGlvblwiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZGVzY3JpcHRpb25cIlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiAnUGxlYXNlIGlucHV0IGRlc2NyaXB0aW9uIScgfV19XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPElucHV0LlRleHRBcmVhIHJvd3M9ezR9IHBsYWNlaG9sZGVyPVwiRW50ZXIgRGVzY3JpcHRpb25cIiBjbGFzc05hbWU9XCJyb3VuZGVkLW1kXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuLy8gICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJEYXRlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJkYXRlXCJcclxuLy8gICAgICAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogJ1BsZWFzZSBzZWxlY3QgYSBkYXRlIScgfV19XHJcbi8vICAgICAgICAgICAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgPERhdGVQaWNrZXIgc3R5bGU9e3sgd2lkdGg6ICcxMDAlJyB9fSBjbGFzc05hbWU9XCJyb3VuZGVkLW1kXCIgLz5cclxuLy8gICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuXHJcbi8vICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJDYWxsIFN0YXR1c1wiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY2FsbFN0YXR1c1wiXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6ICdQbGVhc2Ugc2VsZWN0IHN0YXR1cyEnIH1dfVxyXG4vLyAgICAgICAgICAgICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QgcGxhY2Vob2xkZXI9XCJTZWxlY3QgQ2FsbCBTdGF0dXNcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC1tZFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiSG90XCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTIgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LXNlbWlib2xkIGJnLXJlZC0xMDAgdGV4dC1yZWQtNzAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICBIb3RcclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgIDwvT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiQ29sZFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTEgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1zZW1pYm9sZCBiZy1ibHVlLTEwMCB0ZXh0LWJsdWUtNzAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDb2xkXHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8L09wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIkVtZXJnZW5jeVwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBweC0yIHB5LTEgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1zZW1pYm9sZCBiZy1vcmFuZ2UtMTAwIHRleHQtb3JhbmdlLTcwMFwiPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRW1lcmdlbmN5XHJcbi8vICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgICAgICAgICA8L09wdGlvbj5cclxuLy8gICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4vLyAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgICAgIHsvKiBTdWJtaXQgQnV0dG9uICovfVxyXG4vLyAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbSBjbGFzc05hbWU9XCJtdC00IG1iLTBcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwicHJpbWFyeVwiIGh0bWxUeXBlPVwic3VibWl0XCIgYmxvY2sgY2xhc3NOYW1lPVwiYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS03MDAgaC0xMCByb3VuZGVkLW1kIGZvbnQtc2VtaWJvbGQgc2hhZG93LW1kXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgICAgU3VibWl0IEVucXVpcnlcclxuLy8gICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbi8vICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuXHJcbi8vICAgICAgICAgICAgICAgPC9Gb3JtPlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgIDwvTW9kYWw+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgIDwvZGl2PlxyXG4vLyAgICAgPC8+XHJcbi8vICAgKTtcclxuLy8gfVxyXG5cclxuLy8gZXhwb3J0IGRlZmF1bHQgRW5xdWlyZUNhbGw7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9FbnF1aXJlQ2FsbC5qc3gifQ==