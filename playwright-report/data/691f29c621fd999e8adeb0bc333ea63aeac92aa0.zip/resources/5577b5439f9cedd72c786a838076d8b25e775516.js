import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PenaltyManagement.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useRef = __vite__cjsImport3_react["useRef"]; const useCallback = __vite__cjsImport3_react["useCallback"]





;
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import {
  Button,
  Drawer,
  Alert,
  Select,
  Input,
  Typography,
  Modal as AntModal,
  Table,
  Popconfirm,
  Tag,
  Space,
  Badge,
  Card,
  Row,
  Col,
  Checkbox,
  DatePicker,
  Radio,
  message,
  Spin
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import {
  CalculatorOutlined,
  ArrowLeftOutlined,
  CheckCircleOutlined,
  InfoCircleOutlined,
  CloseCircleOutlined,
  FileTextOutlined,
  ReloadOutlined,
  ArrowDownOutlined,
  CalendarOutlined,
  EyeOutlined,
  DeleteOutlined,
  HistoryOutlined,
  WalletOutlined,
  UserOutlined,
  PhoneOutlined,
  TeamOutlined,
  CreditCardOutlined,
  EditOutlined,
  DollarOutlined,
  ClockCircleOutlined,
  ExclamationCircleOutlined,
  SaveOutlined,
  GiftOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import __vite__cjsImport8_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport8_dayjs.__esModule ? __vite__cjsImport8_dayjs.default : __vite__cjsImport8_dayjs;
import api from "/src/instance/TokenInstance.js";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Dropdown } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { FaEye, FaMoneyBillWave, FaRupeeSign } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import moment from "/node_modules/.vite/deps/moment.js?v=819e0a34";
import { ViewIcon } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
const { Title, Text } = Typography;
function PenaltyManagement() {
  _s();
  const [groups, setGroups] = useState([]);
  const [enrolledUsers, setEnrolledUsers] = useState([]);
  const [dueCustomers, setDueCustomers] = useState([]);
  const [penalties, setPenalties] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [isLoadingGroups, setIsLoadingGroups] = useState(false);
  const [isLoadingUsers, setIsLoadingUsers] = useState(false);
  const [isLoadingPenalties, setIsLoadingPenalties] = useState(false);
  const [addPenaltyDrawerOpen, setAddPenaltyDrawerOpen] = useState(false);
  const [addPenaltyDetails, setAddPenaltyDetails] = useState(null);
  const [addPenaltyAmount, setAddPenaltyAmount] = useState("");
  const [addLateFeeAmount, setAddLateFeeAmount] = useState("");
  const [addPenaltyLoading, setAddPenaltyLoading] = useState(false);
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [selectedGroupName, setSelectedGroupName] = useState("");
  const [selectedCustomerId, setSelectedCustomerId] = useState("");
  const [selectedCustomerName, setSelectedCustomerName] = useState("");
  const [selectedTicket, setSelectedTicket] = useState("");
  const [searchText, setSearchText] = useState("");
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [penaltyFilters, setPenaltyFilters] = useState({
    groupId: "",
    startDate: "",
    endDate: ""
  });
  const [statementModalVisible, setStatementModalVisible] = useState(false);
  const [statementData, setStatementData] = useState(null);
  const [isLoadingStatement, setIsLoadingStatement] = useState(false);
  const [waiveOffModalVisible, setWaiveOffModalVisible] = useState(false);
  const [waiveOffData, setWaiveOffData] = useState(null);
  const [waiveOffAmount, setWaiveOffAmount] = useState("");
  const [waiveOffType, setWaiveOffType] = useState("both");
  const [waiveOffReason, setWaiveOffReason] = useState("");
  const [isWaivingOff, setIsWaivingOff] = useState(false);
  const [selectedCustomerForWaive, setSelectedCustomerForWaive] = useState(null);
  const [waiverHistoryModalVisible, setWaiverHistoryModalVisible] = useState(false);
  const [waiverHistoryData, setWaiverHistoryData] = useState([]);
  const [isLoadingWaiverHistory, setIsLoadingWaiverHistory] = useState(false);
  const [batchWaiveModalVisible, setBatchWaiveModalVisible] = useState(false);
  const [customersWithPenalties, setCustomersWithPenalties] = useState([]);
  const [selectedCustomers, setSelectedCustomers] = useState([]);
  const [batchWaiveAmount, setBatchWaiveAmount] = useState("");
  const [batchWaiveType, setBatchWaiveType] = useState("both");
  const [batchWaiveReason, setBatchWaiveReason] = useState("");
  const [isBatchWaiving, setIsBatchWaiving] = useState(false);
  const [isLoadingCustomers, setIsLoadingCustomers] = useState(false);
  const [penaltyHistoryModalVisible, setPenaltyHistoryModalVisible] = useState(false);
  const [penaltyHistoryData, setPenaltyHistoryData] = useState([]);
  const [isLoadingPenaltyHistory, setIsLoadingPenaltyHistory] = useState(false);
  const [selectedPenaltyCustomer, setSelectedPenaltyCustomer] = useState(null);
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [editingPenalty, setEditingPenalty] = useState(null);
  const [editPenaltyAmount, setEditPenaltyAmount] = useState("");
  const [editLateFeeAmount, setEditLateFeeAmount] = useState("");
  const [editReason, setEditReason] = useState("");
  const [isUpdatingPenalty, setIsUpdatingPenalty] = useState(false);
  const [editDate, setEditDate] = useState(null);
  const [penaltyType, setPenaltyType] = useState("chit");
  const [penaltyLoan, setPenaltyLoan] = useState(null);
  const [penaltyCharges, setPenaltyCharges] = useState(
    [
      { amount: "", reason: "" }
    ]
  );
  const [penaltyLoading, setPenaltyLoading] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState("");
  const [users, setUsers] = useState([]);
  const [borrowers, setBorrowers] = useState([]);
  const [enrollmentLoading, setEnrollmentLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [paymentGroupTickets, setPaymentGroupTickets] = useState([]);
  const [filteredEnrollments, setFilteredEnrollments] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [formData, setFormData] = useState({
    remarks: "",
    user_id: ""
  });
  const [errors, setErrors] = useState({});
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const isFetchingRef = useRef(false);
  const [activePenaltyView, setActivePenaltyView] = useState("chit");
  const [loanPenalties, setLoanPenalties] = useState([]);
  const [loanTableData, setLoanTableData] = useState([]);
  const [isLoadingLoanPenalties, setIsLoadingLoanPenalties] = useState(false);
  const [editLoanModalVisible, setEditLoanModalVisible] = useState(false);
  const [editingLoanPenalty, setEditingLoanPenalty] = useState(null);
  const [editLoanAmount, setEditLoanAmount] = useState("");
  const [editLoanReason, setEditLoanReason] = useState("");
  const [isUpdatingLoanPenalty, setIsUpdatingLoanPenalty] = useState(false);
  const [showPenaltyModal, setShowPenaltyModal] = useState(false);
  useEffect(() => {
    fetchGroups();
  }, []);
  useEffect(() => {
    if (selectedGroupId) {
      fetchDueCustomers(selectedGroupId);
    } else {
      setDueCustomers([]);
      setEnrolledUsers([]);
    }
  }, [selectedGroupId]);
  const fetchLoanPenalties = useCallback(async () => {
    setIsLoadingLoanPenalties(true);
    try {
      const response = await api.get("/v1/admin/loan-penaltys/loan-penalties/");
      const rawData = Array.isArray(response.data) ? response.data : response.data?.data || [];
      setLoanPenalties(rawData);
      const formatted = rawData.map((item, idx) => ({
        _id: item._id,
        id: idx + 1,
        date: moment(item.penalty_date || item.createdAt).format("DD-MM-YYYY HH:mm"),
        loan_id: item.loan_id?.loan_id || item.loan_id?._id || "N/A",
        loan_amount: item.loan_id?.loan_amount || "0",
        customer_name: item.user_id?.full_name || "N/A",
        phone_number: item.user_id?.phone_number || "N/A",
        penalty_amount: item.penalty_amount,
        total_amount: item.penalty_amount,
        reason: item.reason || "-",
        raw_penalty: item,
        // Action dropdown
        action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center", children: /* @__PURE__ */ jsxDEV(
          Dropdown,
          {
            menu: {
              items: [
                {
                  key: "view",
                  label: /* @__PURE__ */ jsxDEV(Space, { className: "px-2 py-1", children: [
                    /* @__PURE__ */ jsxDEV(FaEye, { className: "text-blue-600 text-sm" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 223,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: "View Penalty" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 224,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 222,
                    columnNumber: 17
                  }, this),
                  onClick: () => handleViewLoanPenalty(item)
                },
                {
                  key: "edit",
                  label: /* @__PURE__ */ jsxDEV(Space, { className: "px-2 py-1", children: [
                    /* @__PURE__ */ jsxDEV(EditOutlined, { className: "text-green-600" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 233,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { children: "Edit Penalty" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 234,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 232,
                    columnNumber: 17
                  }, this),
                  onClick: () => handleEditLoanPenalty(item)
                },
                {
                  key: "delete",
                  label: /* @__PURE__ */ jsxDEV(
                    Popconfirm,
                    {
                      title: "Are you sure you want to delete this loan penalty?",
                      onConfirm: () => handleDeleteLoanPenalty(item._id),
                      okText: "Yes",
                      cancelText: "No",
                      children: /* @__PURE__ */ jsxDEV(Space, { className: "px-2 py-1 cursor-pointer", children: [
                        /* @__PURE__ */ jsxDEV(DeleteOutlined, { className: "text-red-600" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                          lineNumber: 249,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV("span", { children: "Delete Penalty" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                          lineNumber: 250,
                          columnNumber: 27
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 248,
                        columnNumber: 25
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 242,
                      columnNumber: 17
                    },
                    this
                  )
                }
              ]
            },
            placement: "bottomRight",
            trigger: ["click"],
            children: /* @__PURE__ */ jsxDEV(Button, { type: "text", icon: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 260,
              columnNumber: 41
            }, this), className: "hover:bg-gray-100" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 260,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 216,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 215,
          columnNumber: 9
        }, this)
      }));
      setLoanTableData(formatted);
    } catch (error) {
      console.error("Error fetching loan penalties:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to fetch loan penalties",
        type: "error"
      });
      setLoanPenalties([]);
      setLoanTableData([]);
    } finally {
      setIsLoadingLoanPenalties(false);
    }
  }, []);
  useEffect(() => {
    if (activePenaltyView === "chit") {
      fetchPenalties();
    } else {
      fetchLoanPenalties();
    }
  }, [activePenaltyView, penaltyFilters]);
  useEffect(() => {
    const fetchAllCustomers = async () => {
      try {
        const response = await api.get("user/verified");
        setUsers(response?.data?.data);
      } catch (error) {
        setUsers([]);
        console.error("Error fetching group data:", error);
      }
    };
    fetchAllCustomers();
  }, []);
  const handlePaymentAntSelect = (values) => {
    setPaymentGroupTickets(values);
  };
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (!isFetchingRef.current) {
        fetchPenalties();
      }
    }, 300);
    return () => clearTimeout(timeoutId);
  }, [penaltyFilters]);
  const fetchGroups = async () => {
    setIsLoadingGroups(true);
    try {
      const response = await api.get("/group/get-group-admin");
      setGroups(response.data);
    } catch (error) {
      console.error("Error fetching groups:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to fetch groups",
        type: "error"
      });
    } finally {
      setIsLoadingGroups(false);
    }
  };
  const handleEditLoanPenalty = (penaltyItem) => {
    setEditingLoanPenalty(penaltyItem);
    setEditLoanAmount(penaltyItem.penalty_amount);
    setEditLoanReason(penaltyItem.reason);
    setEditLoanModalVisible(true);
  };
  const handleViewLoanPenalty = async (item) => {
    try {
      setPenaltyLoading(true);
      const { data } = await api.get(
        `v1/admin/loan-penaltys/${item._id}`
      );
      setPenaltyLoan(data?.data || data);
      setShowPenaltyModal(true);
    } catch (error) {
      console.error("Error fetching penalty details:", error);
      message.error("Failed to fetch penalty details");
    } finally {
      setPenaltyLoading(false);
    }
  };
  const handleUpdateLoanPenalty = async () => {
    if (!editLoanAmount || parseFloat(editLoanAmount) <= 0) {
      message.warning("Please enter a valid penalty amount");
      return;
    }
    setIsUpdatingLoanPenalty(true);
    try {
      await api.put(`/v1/admin/loan-penaltys/loan-penalty/${editingLoanPenalty._id}`, {
        penaltyAmount: parseFloat(editLoanAmount),
        reason: editLoanReason
      });
      message.success("Loan penalty updated successfully");
      setEditLoanModalVisible(false);
      fetchLoanPenalties();
    } catch (error) {
      console.error("Error updating loan penalty:", error);
      message.error(error.response?.data?.message || "Failed to update penalty");
    } finally {
      setIsUpdatingLoanPenalty(false);
    }
  };
  const handleDeleteLoanPenalty = async (penaltyId) => {
    try {
      await api.delete(`/v1/admin/loan-penaltys/loan-penalty/${penaltyId}`);
      message.success("Loan penalty deleted successfully");
      fetchLoanPenalties();
    } catch (error) {
      console.error("Error deleting loan penalty:", error);
      message.error(error.response?.data?.message || "Failed to delete penalty");
    }
  };
  const handlePenaltyModalOpen = (borrower) => {
    setPenaltyLoan(borrower);
    setPenaltyCharges([{ amount: "", reason: "" }]);
    setShowPenaltyModal(true);
  };
  const handleAddPenaltyRow = () => {
    setPenaltyCharges((prev) => [...prev, { amount: "", reason: "" }]);
  };
  const handleRemovePenaltyRow = (index) => {
    setPenaltyCharges((prev) => prev.filter((_, i) => i !== index));
  };
  const handlePenaltyChange = (index, field, value) => {
    setPenaltyCharges(
      (prev) => prev.map((row, i) => i === index ? { ...row, [field]: value } : row)
    );
  };
  const handlePenaltySubmit = async () => {
    const loanItem = paymentGroupTickets.find((item) => item.startsWith("loan-"));
    const loanId = loanItem?.split("loan-")[1];
    const invalid = penaltyCharges.some((c) => !c.amount || !c.reason.trim());
    if (invalid) {
      message.warning("Please fill in all amount and reason fields");
      return;
    }
    setPenaltyLoading(true);
    try {
      const newCharges = penaltyCharges.map((c) => ({
        penaltyAmount: Number(c.amount),
        reason: c.reason.trim(),
        paid: false
      }));
      await api.post(`/v1/admin/loan-penaltys`, {
        userId: selectedUserId,
        loanId,
        penaltyAmount: newCharges[0].penaltyAmount,
        reason: newCharges[0].reason
      });
      message.success("Penalty charges added successfully");
      setPenaltyLoan(null);
      setPenaltyCharges([{ amount: "", reason: "" }]);
      setPaymentGroupTickets([]);
      setSelectedUserId("");
      setAddPenaltyDrawerOpen(false);
      if (activePenaltyView === "loan") {
        fetchLoanPenalties();
      }
    } catch (error) {
      console.error(error);
      message.error("Failed to add penalty charges");
    } finally {
      setPenaltyLoading(false);
    }
  };
  const handleCustomer = async (userId) => {
    setFilteredUsers([]);
    setFilteredEnrollments([]);
    setSelectedUserId(userId);
    setFormData((prevFormData) => ({
      ...prevFormData,
      user_id: userId
    }));
    setErrors((prevData) => ({ ...prevData, customer: "" }));
    setPaymentGroupTickets([]);
  };
  const getTicketDetails = (item) => {
    const borrower = borrowers?.find((b) => `loan-${b._id}` === item);
    if (borrower) {
      const dailyPayment = borrower.daily_payment_amount || 0;
      const loanAmount = borrower?.loan_amount || 0;
      const totalPaid = borrower?.total_payments || 0;
      const startDate = borrower?.start_date;
      const endDate = borrower?.end_date;
      const balance = borrower?.remaining_loan || 0;
      const totalLoan = borrower.loan_amount || 0;
      return {
        type: "loan",
        name: borrower.loan_id,
        ticket: "-",
        loanAmount,
        dailyPayment,
        startDate,
        endDate,
        totalPaid,
        balance,
        profit: 0,
        auctionCount: 0
      };
    }
    return null;
  };
  const fetchDueCustomers = async (groupId) => {
    setIsLoadingUsers(true);
    try {
      const response = await api.get(
        `/penalty-management/due-customers/${groupId}`
      );
      const dueCustomersData = response.data.data || [];
      setDueCustomers(dueCustomersData);
      const transformedUsers = dueCustomersData.map((customer) => ({
        userId: customer.userId,
        userName: customer.userName,
        userPhone: customer.userPhone,
        ticket: customer.ticket,
        groupId,
        groupName: selectedGroupName,
        balance: customer.dueAmount,
        totalPenalty: customer.totalPenalty || 0,
        totalLateFee: customer.totalLateFee || 0,
        enrollmentId: customer.enrollmentId
      }));
      setEnrolledUsers(transformedUsers);
    } catch (error) {
      console.error("Error fetching due customers:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to fetch due customers",
        type: "error"
      });
      setDueCustomers([]);
      setEnrolledUsers([]);
    } finally {
      setIsLoadingUsers(false);
    }
  };
  const fetchPenalties = useCallback(async () => {
    if (isFetchingRef.current) {
      console.log("Fetch already in progress, skipping...");
      return;
    }
    isFetchingRef.current = true;
    setIsLoadingPenalties(true);
    try {
      const params = new URLSearchParams();
      if (penaltyFilters.groupId)
        params.append("groupId", penaltyFilters.groupId);
      if (penaltyFilters.startDate)
        params.append("startDate", penaltyFilters.startDate);
      if (penaltyFilters.endDate)
        params.append("endDate", penaltyFilters.endDate);
      const response = await api.get(
        `/penalty-management/get-penalties-with-totals?${params.toString()}`
      );
      const penaltiesData = response.data.data || [];
      setPenalties(penaltiesData);
      const formattedData = penaltiesData.map((penalty, index) => {
        const totalDue = penalty.current_balance || 0;
        const totalPaid = penalty.total_paid || 0;
        const totalPenaltySum = penalty.total_penalty_sum || 0;
        const totalLateFeeSum = penalty.total_late_fee_sum || 0;
        const currentBalance = totalDue - totalPenaltySum - totalLateFeeSum;
        const penaltyPlusDue = currentBalance + totalPenaltySum + totalLateFeeSum;
        const getDisplayDate = (penalty2) => {
          if (penalty2.penalty_date && penalty2.createdAt) {
            const penaltyDate = new Date(penalty2.penalty_date);
            const createdDate = new Date(penalty2.createdAt);
            if (penaltyDate.getTime() !== createdDate.getTime()) {
              return moment(penalty2.penalty_date).format("DD-MM-YYYY HH:mm");
            }
          }
          return moment(penalty2.createdAt).format("DD-MM-YYYY HH:mm");
        };
        return {
          _id: penalty._id,
          id: index + 1,
          // date: moment(penalty.createdAt).format("DD-MM-YYYY HH:mm"),
          //  date: getDisplayDate(penalty),
          date: moment(penalty.penalty_date || penalty.createdAt).format("DD-MM-YYYY HH:mm"),
          group_name: penalty.group_id?.group_name || "N/A",
          customer_name: penalty.user_id?.full_name || "N/A",
          phone_number: penalty.user_id?.phone_number || "N/A",
          ticket: penalty.ticket,
          balance_raw: currentBalance,
          balance: /* @__PURE__ */ jsxDEV("span", { className: "text-orange-600 font-bold", children: [
            "₹",
            (currentBalance || 0).toLocaleString("en-IN")
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 598,
            columnNumber: 11
          }, this),
          balance_status: (currentBalance || 0) < 0 ? "Excess" : "Due",
          total_paid_raw: totalPaid,
          total_paid: /* @__PURE__ */ jsxDEV("span", { className: "text-green-600 font-bold", children: [
            "₹",
            (totalPaid || 0).toLocaleString("en-IN")
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 605,
            columnNumber: 11
          }, this),
          penalty_plus_due_raw: penaltyPlusDue,
          penalty_plus_due: /* @__PURE__ */ jsxDEV("span", { className: "text-red-600 font-bold", children: [
            "₹",
            penaltyPlusDue.toLocaleString("en-IN")
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 611,
            columnNumber: 11
          }, this),
          total_penalty_sum: `₹${(totalPenaltySum || 0).toLocaleString("en-IN")}`,
          total_late_fee_sum: `₹${(totalLateFeeSum || 0).toLocaleString("en-IN")}`,
          penalty_amount_raw: penalty.penalty_amount,
          penalty_amount: `₹${(penalty.penalty_amount || 0).toLocaleString("en-IN")}`,
          late_fee_amount_raw: penalty.late_fee_amount,
          late_fee_amount: `₹${(penalty.late_fee_amount || 0).toLocaleString("en-IN")}`,
          total_amount_raw: (penalty.penalty_amount || 0) + (penalty.late_fee_amount || 0),
          total_amount: `₹${((penalty.penalty_amount || 0) + (penalty.late_fee_amount || 0)).toLocaleString("en-IN")}`,
          reason: penalty.reason || "-",
          raw_penalty: penalty,
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              menu: {
                items: [
                  {
                    key: "view",
                    label: /* @__PURE__ */ jsxDEV(Space, { className: "px-2 py-1", children: [
                      /* @__PURE__ */ jsxDEV(EyeOutlined, { className: "text-blue-600" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 635,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: "View Statement" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 636,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 634,
                      columnNumber: 19
                    }, this),
                    onClick: () => handleViewStatement(penalty)
                  },
                  {
                    key: "edit",
                    label: /* @__PURE__ */ jsxDEV(Space, { className: "px-2 py-1", children: [
                      /* @__PURE__ */ jsxDEV(EditOutlined, { className: "text-green-600" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 645,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: "Edit Penalty" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 646,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 644,
                      columnNumber: 19
                    }, this),
                    onClick: () => handleEditPenalty(penalty)
                  },
                  {
                    key: "waive",
                    label: /* @__PURE__ */ jsxDEV(Space, { className: "px-2 py-1", children: [
                      /* @__PURE__ */ jsxDEV(DollarOutlined, { className: "text-purple-600" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 655,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { children: "Waive Off Penalties" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 656,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 654,
                      columnNumber: 19
                    }, this),
                    onClick: () => {
                      handleOpenWaiveOffModal(penalty);
                    }
                  },
                  {
                    key: "delete",
                    label: /* @__PURE__ */ jsxDEV(
                      Popconfirm,
                      {
                        title: "Are you sure you want to delete this penalty?",
                        onConfirm: () => handleDeletePenalty(penalty._id),
                        okText: "Yes",
                        cancelText: "No",
                        children: /* @__PURE__ */ jsxDEV(Space, { className: "px-2 py-1 cursor-pointer", children: [
                          /* @__PURE__ */ jsxDEV(DeleteOutlined, { className: "text-red-600" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                            lineNumber: 673,
                            columnNumber: 29
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { children: "Delete Penalty" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                            lineNumber: 674,
                            columnNumber: 29
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                          lineNumber: 672,
                          columnNumber: 27
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 666,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomRight",
              trigger: ["click"],
              children: /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "text",
                  icon: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-xl" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 686,
                    columnNumber: 23
                  }, this),
                  className: "hover:bg-gray-100"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 684,
                  columnNumber: 17
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 628,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 627,
            columnNumber: 11
          }, this)
        };
      });
      setTableData(formattedData);
    } catch (error) {
      console.error("Error fetching penalties:", error);
      if (error.response?.status === 404) {
        setPenalties([]);
        setTableData([]);
      } else {
        setAlertConfig({
          visibility: true,
          message: "Failed to fetch penalties",
          type: "error"
        });
        setPenalties([]);
        setTableData([]);
      }
    } finally {
      setIsLoadingPenalties(false);
      setTimeout(() => {
        isFetchingRef.current = false;
      }, 500);
    }
  }, [penaltyFilters]);
  const fetchCustomersWithPenalties = async () => {
    setIsLoadingCustomers(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 500));
      const response = await api.get(
        `/penalty-management/get-penalties-with-totals?limit=1000`
      );
      const allPenalties = response.data.data || [];
      const customerMap = /* @__PURE__ */ new Map();
      allPenalties.forEach((penalty) => {
        const key = `${penalty.user_id?._id}_${penalty.group_id?._id}_${penalty.ticket}`;
        if (!customerMap.has(key)) {
          customerMap.set(key, {
            // Customer info - FIXED: Use correct property names from API response
            userId: penalty.user_id?._id,
            userName: penalty.user_id?.full_name || "N/A",
            userPhone: penalty.user_id?.phone_number || "N/A",
            // Group info
            groupId: penalty.group_id?._id,
            groupName: penalty.group_id?.group_name || "N/A",
            // Ticket info
            ticket: penalty.ticket,
            enrollmentId: penalty.enrollment_id,
            // This is critical!
            // Amounts - FIXED: Use correct property names
            totalPenalty: 0,
            totalLateFee: 0,
            currentBalance: penalty.current_balance || 0,
            penaltyAmount: penalty.penalty_amount || 0,
            lateFeeAmount: penalty.late_fee_amount || 0
          });
        }
        const customer = customerMap.get(key);
        customer.totalPenalty += penalty.penalty_amount || 0;
        customer.totalLateFee += penalty.late_fee_amount || 0;
      });
      const customersArray = Array.from(customerMap.values());
      setCustomersWithPenalties(customersArray);
    } catch (error) {
      console.error("Error fetching customers with penalties:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to fetch customers with penalties",
        type: "error"
      });
    } finally {
      setIsLoadingCustomers(false);
    }
  };
  const handleBatchWaiveOff = async () => {
    if (selectedCustomers.length === 0) {
      setAlertConfig({
        visibility: true,
        message: "Please select at least one customer",
        type: "warning"
      });
      return;
    }
    if (!batchWaiveAmount || parseFloat(batchWaiveAmount) <= 0) {
      setAlertConfig({
        visibility: true,
        message: "Please enter a valid amount to waive off",
        type: "warning"
      });
      return;
    }
    setIsBatchWaiving(true);
    let successCount = 0;
    let errorCount = 0;
    const errors2 = [];
    try {
      for (let i = 0; i < selectedCustomers.length; i++) {
        const customer = selectedCustomers[i];
        if (!customer.userId) {
          console.error("Missing userId for customer:", customer);
          errorCount++;
          errors2.push(
            `Customer ${customer.userName || "Unknown"}: Missing userId`
          );
          continue;
        }
        if (!customer.groupId) {
          console.error("Missing groupId for customer:", customer);
          errorCount++;
          errors2.push(`${customer.userName}: Missing groupId`);
          continue;
        }
        if (!customer.enrollmentId) {
          console.error("Missing enrollmentId for customer:", customer);
          errorCount++;
          errors2.push(`${customer.userName}: Missing enrollmentId`);
          continue;
        }
        if (!customer.ticket) {
          console.error("Missing ticket for customer:", customer);
          errorCount++;
          errors2.push(`${customer.userName}: Missing ticket`);
          continue;
        }
        const requestData = {
          userId: customer.userId,
          groupId: customer.groupId,
          enrollmentId: customer.enrollmentId,
          ticket: String(customer.ticket),
          // Convert to string
          waiveOffAmount: parseFloat(batchWaiveAmount),
          waiveOffType: batchWaiveType,
          reason: batchWaiveReason || `Batch waiver - ${(/* @__PURE__ */ new Date()).toLocaleString()}`
        };
        try {
          const response = await api.post(
            "/penalty-management/waive-off-penalties",
            requestData
          );
          if (response.data.success) {
            successCount++;
            console.log(
              `✅ Successfully waived for ${customer.userName} - Ticket ${customer.ticket}`
            );
          } else {
            errorCount++;
            errors2.push(
              `${customer.userName} - Ticket ${customer.ticket}: ${response.data.message}`
            );
          }
        } catch (err) {
          errorCount++;
          const errorMsg = err.response?.data?.message || err.message;
          errors2.push(
            `${customer.userName} - Ticket ${customer.ticket}: ${errorMsg}`
          );
          console.error(
            `❌ Failed to waive for ${customer.userName}:`,
            err.response?.data || err
          );
        }
      }
      if (successCount > 0) {
        setAlertConfig({
          visibility: true,
          message: `✅ Successfully waived off for ${successCount} ticket(s). Failed: ${errorCount}`,
          type: "success"
        });
        setBatchWaiveModalVisible(false);
        setSelectedCustomers([]);
        setBatchWaiveAmount("");
        setBatchWaiveReason("");
        setBatchWaiveType("both");
        setCustomersWithPenalties([]);
        await fetchPenalties();
        if (selectedGroupId) {
          await fetchDueCustomers(selectedGroupId);
        }
      } else if (errorCount > 0) {
        setAlertConfig({
          visibility: true,
          message: `❌ Failed for ${errorCount} ticket(s). Please check console for details.`,
          type: "error"
        });
      }
    } catch (error) {
      console.error("Error in batch waive off:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to process batch waiver: " + (error.message || "Unknown error"),
        type: "error"
      });
    } finally {
      setIsBatchWaiving(false);
    }
  };
  const handleViewStatement = async (penalty) => {
    setStatementModalVisible(true);
    setIsLoadingStatement(true);
    try {
      const response = await api.get(
        `/penalty-management/statement/${penalty.user_id._id}/${penalty.group_id._id}/${penalty.ticket}`
      );
      setStatementData(response.data.data);
    } catch (error) {
      console.error("Error fetching statement:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to fetch statement",
        type: "error"
      });
    } finally {
      setIsLoadingStatement(false);
    }
  };
  useEffect(() => {
    setBorrowers([]);
    const fetchCustomerLoanDetails = async () => {
      if (!selectedUserId) return;
      try {
        const response = await api.get(`/v1/admin/loans/get-borrower-details/${selectedUserId}`);
        if (response.data?.data) {
          setBorrowers(response.data.data);
        } else {
          setBorrowers([]);
        }
      } catch (err) {
        setBorrowers([]);
        console.log("Error fetching loan details:", err);
      }
    };
    fetchCustomerLoanDetails();
  }, [selectedUserId]);
  const handleViewPenaltyHistory = async () => {
    if (!addPenaltyDetails) return;
    setPenaltyHistoryModalVisible(true);
    setIsLoadingPenaltyHistory(true);
    setSelectedPenaltyCustomer({
      userName: addPenaltyDetails.userName,
      userPhone: addPenaltyDetails.userPhone,
      groupName: addPenaltyDetails.groupName,
      ticket: addPenaltyDetails.paymentsTicket
    });
    try {
      const response = await api.get(
        `/penalty-management/statement/${addPenaltyDetails.userId}/${addPenaltyDetails.groupId}/${addPenaltyDetails.paymentsTicket}`
      );
      const statementData2 = response.data.data;
      const penaltyTransactions = statementData2.transactions?.filter(
        (t) => t.type === "Penalty" || t.type === "Late Fee"
      ) || [];
      const formattedPenalties = penaltyTransactions.map((t, index) => ({
        _id: index,
        createdAt: t.date,
        penalty_amount: t.type === "Penalty" ? t.debit || 0 : 0,
        late_fee_amount: t.type === "Late Fee" ? t.debit || 0 : 0,
        reason: t.description || "Manual penalty added",
        status: "pending"
      }));
      setPenaltyHistoryData(formattedPenalties);
    } catch (error) {
      console.error("Error fetching penalty history:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to fetch penalty history",
        type: "error"
      });
      setPenaltyHistoryData([]);
    } finally {
      setIsLoadingPenaltyHistory(false);
    }
  };
  const handleEditPenalty = (penalty) => {
    setEditingPenalty(penalty);
    setEditPenaltyAmount(penalty.penalty_amount);
    setEditLateFeeAmount(penalty.late_fee_amount);
    setEditReason(penalty.reason || "");
    setEditDate(dayjs(penalty.createdAt));
    setEditModalVisible(true);
  };
  const handleUpdatePenalty = async () => {
    if (!editPenaltyAmount && !editLateFeeAmount) {
      setAlertConfig({
        visibility: true,
        message: "Please enter at least one amount",
        type: "warning"
      });
      return;
    }
    setIsUpdatingPenalty(true);
    try {
      const response = await api.put(
        `/penalty-management/update-penalty/${editingPenalty._id}`,
        {
          penalty_amount: parseFloat(editPenaltyAmount) || 0,
          late_fee_amount: parseFloat(editLateFeeAmount) || 0,
          reason: editReason,
          penalty_date: editDate ? editDate.toISOString() : null
        }
      );
      if (response.data.success) {
        setAlertConfig({
          visibility: true,
          message: "Penalty updated successfully!",
          type: "success"
        });
        setEditModalVisible(false);
        setEditingPenalty(null);
        fetchPenalties();
        if (selectedGroupId) {
          fetchDueCustomers(selectedGroupId);
        }
      }
    } catch (error) {
      console.error("Error updating penalty:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to update penalty",
        type: "error"
      });
    } finally {
      setIsUpdatingPenalty(false);
    }
  };
  const processedTransactions = useMemo(() => {
    if (!statementData) {
      return [];
    }
    if (!statementData.transactions || !Array.isArray(statementData.transactions)) {
      return [];
    }
    if (statementData.transactions.length === 0) {
      return [];
    }
    let runningTotalPaid = 0;
    let runningDue = statementData.enrollment?.currentBalance || 0;
    const sortedTransactions = [...statementData.transactions].sort(
      (a, b) => new Date(a.date) - new Date(b.date)
    );
    const result = [];
    for (const item of sortedTransactions) {
      if (item.type === "Payment") {
        const paymentAmount = item.credit || 0;
        runningTotalPaid += paymentAmount;
      }
      if (item.type === "Penalty") {
        const penaltyAmount = item.debit || 0;
        runningDue += penaltyAmount;
      }
      if (item.type === "Late Fee") {
        const lateFeeAmount = item.debit || 0;
        runningDue += lateFeeAmount;
      }
      result.push({
        ...item,
        calculatedTotalPaid: runningTotalPaid,
        calculatedDebit: item.type === "Penalty" || item.type === "Late Fee" ? item.debit || 0 : 0,
        calculatedDue: Math.abs(runningDue),
        actualDue: runningDue
      });
    }
    return result;
  }, [statementData]);
  const totalPenaltyAmount = useMemo(() => {
    if (!Array.isArray(penaltyHistoryData)) return 0;
    return penaltyHistoryData.reduce((sum, item) => {
      return sum + ((item.penalty_amount || 0) + (item.late_fee_amount || 0));
    }, 0);
  }, [penaltyHistoryData]);
  const groupOptions = useMemo(() => {
    return groups.map((group) => ({
      value: group._id,
      label: group.group_name
    }));
  }, [groups]);
  const penaltyHistoryColumns = [
    {
      title: "Date",
      dataIndex: "createdAt",
      key: "date",
      render: (date) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(CalendarOutlined, { className: "text-purple-400 text-sm" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 1139,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700", children: moment(date).format("DD-MM-YYYY HH:mm") }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 1140,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 1138,
        columnNumber: 5
      }, this),
      sorter: (a, b) => new Date(a.createdAt) - new Date(b.createdAt),
      defaultSortOrder: "descend"
    },
    {
      title: "Penalty Amount",
      dataIndex: "penalty_amount",
      key: "penalty_amount",
      align: "right",
      render: (amount) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-2", children: [
        amount > 0 && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(ArrowDownOutlined, { className: "text-red-500 text-xs" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 1157,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-red-600 font-semibold", children: [
            "₹",
            (amount || 0).toLocaleString("en-IN")
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 1158,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 1156,
          columnNumber: 7
        }, this),
        (!amount || amount === 0) && /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 1164,
          columnNumber: 7
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 1154,
        columnNumber: 5
      }, this),
      sorter: (a, b) => (a.penalty_amount || 0) - (b.penalty_amount || 0)
    },
    {
      title: "Late Fee",
      dataIndex: "late_fee_amount",
      key: "late_fee_amount",
      align: "right",
      render: (amount) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-2", children: [
        amount > 0 && /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV(ArrowDownOutlined, { className: "text-orange-500 text-xs" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 1179,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-orange-600 font-semibold", children: [
            "₹",
            (amount || 0).toLocaleString("en-IN")
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 1180,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 1178,
          columnNumber: 7
        }, this),
        (!amount || amount === 0) && /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 1186,
          columnNumber: 7
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 1176,
        columnNumber: 5
      }, this),
      sorter: (a, b) => (a.late_fee_amount || 0) - (b.late_fee_amount || 0)
    },
    {
      title: "Total Amount",
      key: "total",
      align: "right",
      render: (_, record) => {
        const total = (record.penalty_amount || 0) + (record.late_fee_amount || 0);
        return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-end gap-2", children: [
          /* @__PURE__ */ jsxDEV(CalculatorOutlined, { className: "text-purple-500 text-sm" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 1201,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-purple-700", children: [
            "₹",
            total.toLocaleString("en-IN")
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 1202,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 1200,
          columnNumber: 9
        }, this);
      },
      sorter: (a, b) => (a.penalty_amount || 0) + (a.late_fee_amount || 0) - ((b.penalty_amount || 0) + (b.late_fee_amount || 0))
    },
    {
      title: "Reason",
      dataIndex: "reason",
      key: "reason",
      render: (reason) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(FileTextOutlined, { className: "text-gray-400 text-sm" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 1219,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700", children: reason || "No reason provided" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 1220,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 1218,
        columnNumber: 5
      }, this)
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (status) => {
        const statusConfig = {
          pending: {
            color: "gold",
            icon: /* @__PURE__ */ jsxDEV(ClockCircleOutlined, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 1234,
              columnNumber: 17
            }, this),
            text: "PENDING"
          },
          paid: { color: "green", icon: /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 1237,
            columnNumber: 39
          }, this), text: "PAID" },
          cancelled: {
            color: "red",
            icon: /* @__PURE__ */ jsxDEV(CloseCircleOutlined, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 1240,
              columnNumber: 17
            }, this),
            text: "CANCELLED"
          }
        };
        const config = statusConfig[status] || statusConfig.pending;
        return /* @__PURE__ */ jsxDEV(
          Tag,
          {
            color: config.color,
            icon: config.icon,
            className: "px-3 py-1 rounded-full font-semibold text-xs",
            children: config.text
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 1247,
            columnNumber: 9
          },
          this
        );
      },
      filters: [
        { text: "Pending", value: "pending" },
        { text: "Paid", value: "paid" },
        { text: "Cancelled", value: "cancelled" }
      ],
      onFilter: (value, record) => record.status === value
    }
  ];
  const transactionColumns = [
    {
      title: "Date",
      dataIndex: "date",
      key: "date",
      render: (date) => moment(date).format("DD-MM-YYYY HH:mm"),
      sorter: (a, b) => new Date(a.date) - new Date(b.date),
      defaultSortOrder: "descend",
      width: 150
    },
    {
      title: "Type",
      dataIndex: "type",
      key: "type",
      render: (type) => /* @__PURE__ */ jsxDEV(
        Tag,
        {
          color: type === "Payment" ? "green" : type === "Penalty" ? "red" : "orange",
          children: type === "Payment" ? "Payment" : type === "Penalty" ? "Penalty" : "Late Fee"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 1280,
          columnNumber: 5
        },
        this
      ),
      width: 100
    },
    {
      title: "Description",
      dataIndex: "description",
      key: "description"
    },
    {
      title: "Total Paid",
      dataIndex: "calculatedTotalPaid",
      key: "totalPaid",
      align: "right",
      render: (amount) => `₹${(amount || 0).toLocaleString("en-IN")}`
    },
    {
      title: "Payment (Credit)",
      dataIndex: "credit",
      key: "credit",
      align: "right",
      render: (amount) => amount > 0 ? /* @__PURE__ */ jsxDEV("span", { className: "text-green-600 font-semibold", children: [
        "₹",
        amount.toLocaleString("en-IN")
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 1313,
        columnNumber: 5
      }, this) : "-"
    },
    {
      title: "Penalty/Late Fee",
      key: "debit",
      align: "right",
      render: (_, record) => {
        const amount = record.calculatedDebit || 0;
        return amount > 0 ? /* @__PURE__ */ jsxDEV("span", { className: "text-orange-600 font-semibold", children: [
          "₹",
          amount.toLocaleString("en-IN")
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 1327,
          columnNumber: 7
        }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 1331,
          columnNumber: 7
        }, this);
      }
    },
    {
      title: "Outstanding Due Balance",
      key: "due",
      align: "right",
      render: (_, record) => {
        const debit = record.calculatedDebit || 0;
        if (debit > 0) {
          return /* @__PURE__ */ jsxDEV("span", { className: "text-red-600 font-semibold", children: [
            "₹",
            (record.calculatedDue || 0).toLocaleString("en-IN")
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 1343,
            columnNumber: 11
          }, this);
        }
        return /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 1348,
          columnNumber: 14
        }, this);
      }
    }
  ];
  const customerOptions = useMemo(() => {
    if (!selectedGroupId) return [];
    const uniqueCustomers = /* @__PURE__ */ new Map();
    enrolledUsers.forEach((user) => {
      if (!uniqueCustomers.has(user.userId) && user.balance > 0) {
        uniqueCustomers.set(user.userId, {
          value: user.userId,
          label: `${user.userName} - ${user.userPhone} (Due: ₹${(user.balance || 0).toLocaleString("en-IN")})`,
          userName: user.userName,
          userPhone: user.userPhone,
          balance: user.balance
        });
      }
    });
    return Array.from(uniqueCustomers.values());
  }, [enrolledUsers, selectedGroupId]);
  const ticketOptions = useMemo(() => {
    if (!selectedCustomerId || !selectedGroupId) return [];
    const userTickets = enrolledUsers.filter(
      (user) => user.userId === selectedCustomerId && user.balance > 0
    );
    return userTickets.map((ticket) => ({
      value: ticket.ticket,
      label: `Ticket: ${ticket.ticket} | Due: ₹${(ticket.balance || 0).toLocaleString("en-IN")}`,
      balance: ticket.balance,
      totalPenalty: ticket.totalPenalty,
      totalLateFee: ticket.totalLateFee,
      userName: ticket.userName,
      userPhone: ticket.userPhone,
      groupName: ticket.groupName,
      userId: ticket.userId,
      enrollmentId: ticket.enrollmentId
    }));
  }, [enrolledUsers, selectedCustomerId, selectedGroupId]);
  const handleGroupSelect = (value) => {
    setSelectedGroupId(value || "");
    setSelectedCustomerId("");
    setSelectedTicket("");
    setSelectedCustomerName("");
    const selectedGroup = groups.find((g) => g._id === value);
    setSelectedGroupName(selectedGroup?.group_name || "");
  };
  const handleCustomerSelect = (value) => {
    setSelectedCustomerId(value || "");
    setSelectedTicket("");
    const selectedCustomer2 = customerOptions.find((c) => c.value === value);
    setSelectedCustomerName(selectedCustomer2?.userName || "");
  };
  const handleTicketSelect = (value) => {
    setSelectedTicket(value || "");
  };
  const fetchCurrentPenaltyTotals = async (userId, groupId, ticket) => {
    try {
      const response = await api.get(
        `/penalty-management/statement/${userId}/${groupId}/${ticket}`
      );
      return {
        totalPenalty: response.data.data.summary?.totalPenalty || 0,
        totalLateFee: response.data.data.summary?.totalLateFee || 0,
        currentBalance: response.data.data.enrollment?.currentBalance || 0
      };
    } catch (error) {
      console.error("Error fetching penalty totals:", error);
      return { totalPenalty: 0, totalLateFee: 0, currentBalance: 0 };
    }
  };
  const handleProceedToPenalty = async () => {
    const selectedTicketData = ticketOptions.find(
      (t) => t.value === selectedTicket
    );
    if (!selectedTicketData) {
      setAlertConfig({
        visibility: true,
        message: "Please select a valid ticket",
        type: "error"
      });
      return;
    }
    const currentTotals = await fetchCurrentPenaltyTotals(
      selectedCustomerId,
      selectedGroupId,
      selectedTicket
    );
    setAddPenaltyDetails({
      userId: selectedCustomerId,
      userName: selectedCustomerName,
      userPhone: selectedTicketData.userPhone,
      groupId: selectedGroupId,
      groupName: selectedGroupName,
      paymentsTicket: selectedTicket,
      balance: selectedTicketData.balance,
      totalPenalty: currentTotals.totalPenalty,
      totalLateFee: currentTotals.totalLateFee,
      currentBalance: currentTotals.currentBalance,
      enrollmentId: selectedTicketData.enrollmentId
    });
    setAddPenaltyDrawerOpen(false);
  };
  const handleSavePenalty = async () => {
    if (!addPenaltyAmount && !addLateFeeAmount) {
      setAlertConfig({
        visibility: true,
        message: "Please enter at least one amount (Penalty or Late Fee)",
        type: "warning"
      });
      return;
    }
    setAddPenaltyLoading(true);
    try {
      const response = await api.post("/penalty-management/add-penalty", {
        userId: addPenaltyDetails.userId,
        groupId: addPenaltyDetails.groupId,
        enrollmentId: addPenaltyDetails.enrollmentId,
        ticket: addPenaltyDetails.paymentsTicket,
        penaltyAmount: parseFloat(addPenaltyAmount) || 0,
        lateFeeAmount: parseFloat(addLateFeeAmount) || 0,
        reason: "Manual penalty added by admin"
      });
      if (response.data.success) {
        setAlertConfig({
          visibility: true,
          message: "Penalty added successfully!",
          type: "success"
        });
        setAddPenaltyDetails(null);
        setAddPenaltyAmount("");
        setAddLateFeeAmount("");
        await fetchPenalties();
        if (selectedGroupId && response.data.data?.remainingBalance !== void 0) {
          setEnrolledUsers(
            (prevUsers) => prevUsers.map(
              (user) => user.userId === addPenaltyDetails.userId && user.ticket === addPenaltyDetails.paymentsTicket ? { ...user, balance: response.data.data.remainingBalance } : user
            )
          );
          setDueCustomers(
            (prevCustomers) => prevCustomers.map(
              (customer) => customer.userId === addPenaltyDetails.userId && customer.ticket === addPenaltyDetails.paymentsTicket ? {
                ...customer,
                dueAmount: response.data.data.remainingBalance
              } : customer
            )
          );
        }
      } else {
        throw new Error(response.data.message || "Failed to add penalty");
      }
    } catch (error) {
      console.error("Error saving penalty:", error);
      setAlertConfig({
        visibility: true,
        message: error?.response?.data?.message || error.message || "Failed to add penalty",
        type: "error"
      });
    } finally {
      setAddPenaltyLoading(false);
    }
  };
  const fetchCustomerAllPenalties = async (userId, groupId, ticket) => {
    try {
      const response = await api.get(
        `/penalty-management/statement/${userId}/${groupId}/${ticket}`
      );
      const statementData2 = response.data.data;
      const penaltyTransactions = statementData2.transactions?.filter(
        (t) => t.type === "Penalty" || t.type === "Late Fee"
      ) || [];
      return {
        penalties: penaltyTransactions,
        totalPenalty: statementData2.summary?.totalPenalty || 0,
        totalLateFee: statementData2.summary?.totalLateFee || 0,
        currentBalance: statementData2.enrollment?.currentBalance || 0,
        enrollmentId: statementData2.enrollment?._id
      };
    } catch (error) {
      console.error("Error fetching customer penalties:", error);
      throw error;
    }
  };
  const handleWaiveOffPenalties = async () => {
    if (!waiveOffAmount || parseFloat(waiveOffAmount) <= 0) {
      setAlertConfig({
        visibility: true,
        message: "Please enter a valid amount to waive off",
        type: "warning"
      });
      return;
    }
    const amountToWaive = parseFloat(waiveOffAmount);
    if (waiveOffType === "penalty" && amountToWaive > waiveOffData.totalPenalty) {
      setAlertConfig({
        visibility: true,
        message: `Cannot waive off more than total penalty amount (₹${waiveOffData.totalPenalty.toLocaleString("en-IN")})`,
        type: "error"
      });
      return;
    }
    if (waiveOffType === "latefee" && amountToWaive > waiveOffData.totalLateFee) {
      setAlertConfig({
        visibility: true,
        message: `Cannot waive off more than total late fee amount (₹${waiveOffData.totalLateFee.toLocaleString("en-IN")})`,
        type: "error"
      });
      return;
    }
    if (waiveOffType === "both" && amountToWaive > waiveOffData.totalPenalty + waiveOffData.totalLateFee) {
      setAlertConfig({
        visibility: true,
        message: `Cannot waive off more than total penalty + late fee amount (₹${(waiveOffData.totalPenalty + waiveOffData.totalLateFee).toLocaleString("en-IN")})`,
        type: "error"
      });
      return;
    }
    setIsWaivingOff(true);
    try {
      const response = await api.post(
        "/penalty-management/waive-off-penalties",
        {
          userId: waiveOffData.userId,
          groupId: waiveOffData.groupId,
          enrollmentId: waiveOffData.enrollmentId,
          ticket: waiveOffData.ticket,
          waiveOffAmount: amountToWaive,
          waiveOffType,
          reason: waiveOffReason || `Waived off by admin - ${(/* @__PURE__ */ new Date()).toLocaleString()}`
        }
      );
      if (response.data.success) {
        setAlertConfig({
          visibility: true,
          message: `✅ Successfully waived off ₹${amountToWaive.toLocaleString("en-IN")}`,
          type: "success"
        });
        setWaiveOffModalVisible(false);
        setWaiveOffData(null);
        setWaiveOffAmount("");
        setWaiveOffReason("");
        setWaiveOffType("both");
        await fetchPenalties();
        if (selectedGroupId) {
          await fetchDueCustomers(selectedGroupId);
        }
      } else {
        throw new Error(
          response.data.message || "Failed to waive off penalties"
        );
      }
    } catch (error) {
      console.error("Error waiving off penalties:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to waive off penalties",
        type: "error"
      });
    } finally {
      setIsWaivingOff(false);
    }
  };
  const handleOpenWaiveOffModal = async (record) => {
    const penaltyData = record.raw_penalty || record;
    if (!penaltyData) {
      console.error("No penalty data found");
      setAlertConfig({
        visibility: true,
        message: "No penalty data found",
        type: "error"
      });
      return;
    }
    setSelectedCustomerForWaive(record);
    setIsLoadingStatement(true);
    try {
      const response = await api.get(
        `/penalty-management/statement/${penaltyData.user_id._id}/${penaltyData.group_id._id}/${penaltyData.ticket}`
      );
      const statementData2 = response.data.data;
      const penaltyTransactions = statementData2.transactions?.filter(
        (t) => t.type === "Penalty" || t.type === "Late Fee"
      ) || [];
      const totalPenalty = penaltyTransactions.filter((t) => t.type === "Penalty").reduce((sum, t) => sum + (t.debit || 0), 0);
      const totalLateFee = penaltyTransactions.filter((t) => t.type === "Late Fee").reduce((sum, t) => sum + (t.debit || 0), 0);
      setWaiveOffData({
        userId: penaltyData.user_id._id,
        userName: penaltyData.user_id.full_name,
        userPhone: penaltyData.user_id.phone_number,
        groupId: penaltyData.group_id._id,
        groupName: penaltyData.group_id.group_name,
        ticket: penaltyData.ticket,
        enrollmentId: penaltyData.enrollment_id,
        totalPenalty,
        totalLateFee,
        currentBalance: statementData2.enrollment?.currentBalance || 0,
        penalties: penaltyTransactions
      });
      setWaiveOffModalVisible(true);
    } catch (error) {
      console.error("Error fetching customer penalties:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to fetch customer penalty data: " + (error.message || "Unknown error"),
        type: "error"
      });
    } finally {
      setIsLoadingStatement(false);
    }
  };
  const fetchWaiverHistory = async (userId, groupId, ticket) => {
    setIsLoadingWaiverHistory(true);
    try {
      const response = await api.get(
        `/penalty-management/waiver-history/${userId}/${groupId}/${ticket}`
      );
      setWaiverHistoryData(response.data.data || []);
      setWaiverHistoryModalVisible(true);
    } catch (error) {
      console.error("Error fetching waiver history:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to fetch waiver history",
        type: "error"
      });
    } finally {
      setIsLoadingWaiverHistory(false);
    }
  };
  const handleDeletePenalty = async (penaltyId) => {
    try {
      const response = await api.delete(
        `/penalty-management/delete-penalty/${penaltyId}`
      );
      if (response.data.success) {
        setAlertConfig({
          visibility: true,
          message: "Penalty deleted successfully",
          type: "success"
        });
        fetchPenalties();
        if (selectedGroupId) {
          fetchDueCustomers(selectedGroupId);
        }
      }
    } catch (error) {
      console.error("Error deleting penalty:", error);
      setAlertConfig({
        visibility: true,
        message: "Failed to delete penalty",
        type: "error"
      });
    }
  };
  const handleCloseFirstDrawer = () => {
    setAddPenaltyDrawerOpen(false);
    setTimeout(() => {
      setSelectedGroupId("");
      setSelectedGroupName("");
      setSelectedCustomerId("");
      setSelectedCustomerName("");
      setSelectedTicket("");
    }, 300);
  };
  const openBatchWaiveModal = async () => {
    setBatchWaiveModalVisible(true);
    await fetchCustomersWithPenalties();
  };
  const loanColumns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Date" },
    { key: "loan_id", header: "Loan ID" },
    { key: "customer_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "penalty_amount", header: "Penalty Amount" },
    { key: "total_amount", header: "Total" },
    { key: "reason", header: "Reason" },
    { key: "action", header: "Action" }
  ];
  const loanExportColumns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Date" },
    { key: "loan_id", header: "Loan ID" },
    { key: "customer_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "penalty_amount", header: "Penalty Amount" },
    { key: "total_amount", header: "Total" },
    { key: "reason", header: "Reason" }
  ];
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Date" },
    { key: "group_name", header: "Group" },
    { key: "customer_name", header: "Customer" },
    { key: "phone_number", header: "Phone" },
    { key: "ticket", header: "Ticket" },
    { key: "total_paid", header: "Total Paid" },
    { key: "balance", header: "Balance" },
    { key: "balance_status", header: "Status" },
    { key: "penalty_amount", header: "Penalty" },
    { key: "late_fee_amount", header: "Late Fee" },
    { key: "total_amount", header: "Total" },
    { key: "penalty_plus_due", header: "balance + Penalty" },
    { key: "reason", header: "Reason" },
    { key: "action", header: "Action" }
  ];
  const excelcolumns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Date" },
    { key: "group_name", header: "Group" },
    { key: "customer_name", header: "Customer" },
    { key: "phone_number", header: "Phone" },
    { key: "ticket", header: "Ticket" },
    { key: "total_paid_raw", header: "Total Paid" },
    { key: "balance_raw", header: "Balance" },
    { key: "balance_status", header: "Status" },
    { key: "penalty_amount_raw", header: "Penalty" },
    { key: "late_fee_amount_raw", header: "Late Fee" },
    { key: "total_amount_raw", header: "Total" },
    { key: "penalty_plus_due_raw", header: "Balance + Penalty" },
    { key: "reason", header: "Reason" },
    { key: "action", header: "Action" }
  ];
  const filterPenalties = (data, search) => {
    if (!search) return data;
    return data.filter(
      (item) => item.customer_name?.toLowerCase().includes(search.toLowerCase()) || item.group_name?.toLowerCase().includes(search.toLowerCase()) || item.ticket?.toLowerCase().includes(search.toLowerCase()) || item.phone_number?.toLowerCase().includes(search.toLowerCase())
    );
  };
  const summaryData = useMemo(() => {
    const totalPenalty = penalties.reduce(
      (sum, p) => sum + (p.penalty_amount || 0),
      0
    );
    const totalLateFee = penalties.reduce(
      (sum, p) => sum + (p.late_fee_amount || 0),
      0
    );
    const totalPenalties = penalties.length;
    let totalDue = 0;
    let totalExcess = 0;
    let dueCount = 0;
    let excessCount = 0;
    penalties.forEach((penalty) => {
      const balance = penalty.current_balance || 0;
      if (balance > 0) {
        totalDue += balance;
        dueCount++;
      } else if (balance < 0) {
        totalExcess += Math.abs(balance);
        excessCount++;
      }
    });
    return {
      totalPenalty,
      totalLateFee,
      totalPenalties,
      totalDue,
      totalExcess,
      dueCount,
      excessCount
    };
  }, [penalties]);
  const loanSummaryData = useMemo(() => {
    const totalPenalties = loanTableData.length;
    const totalPenaltyAmount2 = loanTableData.reduce((sum, item) => sum + (item.penalty_amount || 0), 0);
    const uniqueCustomers = new Set(loanTableData.map((item) => item.customer_name)).size;
    return {
      totalPenalties,
      totalPenaltyAmount: totalPenaltyAmount2,
      uniqueCustomers
    };
  }, [loanTableData]);
  const batchWaiveColumns = [
    {
      title: /* @__PURE__ */ jsxDEV(
        Checkbox,
        {
          onChange: (e) => {
            if (e.target.checked) {
              setSelectedCustomers(customersWithPenalties);
            } else {
              setSelectedCustomers([]);
            }
          }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 1928,
          columnNumber: 5
        },
        this
      ),
      dataIndex: "selection",
      key: "selection",
      width: 50,
      render: (_, record) => /* @__PURE__ */ jsxDEV(
        Checkbox,
        {
          checked: selectedCustomers.some((c) => c.userId === record.userId),
          onChange: (e) => {
            if (e.target.checked) {
              setSelectedCustomers([...selectedCustomers, record]);
            } else {
              setSelectedCustomers(
                selectedCustomers.filter((c) => c.userId !== record.userId)
              );
            }
          }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 1942,
          columnNumber: 5
        },
        this
      )
    },
    {
      title: "Customer Name",
      dataIndex: "userName",
      key: "userName",
      sorter: (a, b) => a.userName.localeCompare(b.userName)
    },
    {
      title: "Phone Number",
      dataIndex: "userPhone",
      key: "userPhone"
    },
    {
      title: "Total Penalty",
      dataIndex: "totalPenalty",
      key: "totalPenalty",
      align: "right",
      render: (amount) => /* @__PURE__ */ jsxDEV("span", { className: "text-red-600 font-semibold", children: [
        "₹",
        amount.toLocaleString("en-IN")
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 1973,
        columnNumber: 5
      }, this),
      sorter: (a, b) => a.totalPenalty - b.totalPenalty
    },
    {
      title: "Total Late Fee",
      dataIndex: "totalLateFee",
      key: "totalLateFee",
      align: "right",
      render: (amount) => /* @__PURE__ */ jsxDEV("span", { className: "text-orange-600 font-semibold", children: [
        "₹",
        amount.toLocaleString("en-IN")
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 1985,
        columnNumber: 5
      }, this),
      sorter: (a, b) => a.totalLateFee - b.totalLateFee
    },
    {
      title: "Total Due",
      dataIndex: "totalDue",
      key: "totalDue",
      align: "right",
      render: (amount) => /* @__PURE__ */ jsxDEV("span", { className: "text-purple-600 font-bold", children: [
        "₹",
        amount.toLocaleString("en-IN")
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 1997,
        columnNumber: 5
      }, this),
      sorter: (a, b) => a.totalDue - b.totalDue
    },
    {
      title: "Tickets Count",
      dataIndex: "tickets",
      key: "ticketsCount",
      align: "center",
      render: (tickets) => tickets.length
    }
  ];
  const selectedCustomer = users.find(
    (user) => user._id === selectedUserId
  );
  const getDueInfo = (endDate) => {
    if (!endDate) return null;
    const end = new Date(endDate);
    const today = /* @__PURE__ */ new Date();
    end.setHours(0, 0, 0, 0);
    today.setHours(0, 0, 0, 0);
    const diffTime = today - end;
    const diffDays = Math.floor(diffTime / (1e3 * 60 * 60 * 24));
    if (diffDays > 0) {
      return {
        status: "overdue",
        text: `${diffDays} day(s) overdue`
      };
    }
    if (diffDays < 0) {
      return {
        status: "upcoming",
        text: `${Math.abs(diffDays)} day(s) remaining`
      };
    }
    return {
      status: "today",
      text: "Due today"
    };
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen mt-20 bg-gradient-to-br from-gray-50 to-gray-100", children: [
    /* @__PURE__ */ jsxDEV(
      CustomAlert,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 2050,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 2060,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 2061,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8 flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold text-gray-800 mb-2", children: "Penalty Management" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2069,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-6 flex gap-3", children: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: activePenaltyView === "chit" ? "primary" : "default",
                  onClick: () => setActivePenaltyView("chit"),
                  size: "large",
                  children: "Chit Penalties"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2073,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: activePenaltyView === "loan" ? "primary" : "default",
                  onClick: () => setActivePenaltyView("loan"),
                  size: "large",
                  children: "Loan Penalties"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2080,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2072,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600", children: "Monitor and efficiently manage customer penalties, late fees, and outstanding balances in one place." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2088,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2068,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                icon: /* @__PURE__ */ jsxDEV(GiftOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2096,
                  columnNumber: 23
                }, this),
                onClick: openBatchWaiveModal,
                disabled: activePenaltyView === "loan",
                style: { backgroundColor: "#7c3aed", borderColor: "#7c3aed" },
                children: "Waive Off"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2094,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                icon: /* @__PURE__ */ jsxDEV(CalculatorOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2105,
                  columnNumber: 23
                }, this),
                onClick: () => setAddPenaltyDrawerOpen(true),
                children: "Add Penalty"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2103,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2093,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 2067,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow mb-6 p-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold", children: "Penalty Filter" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2116,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Button, { icon: /* @__PURE__ */ jsxDEV(ReloadOutlined, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2117,
              columnNumber: 29
            }, this), onClick: fetchPenalties, children: "Refresh" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2117,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2115,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: activePenaltyView === "chit" ? "Group" : "Customer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2125,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "w-full",
                  placeholder: "All Groups",
                  allowClear: true,
                  showSearch: true,
                  value: penaltyFilters.groupId || void 0,
                  onChange: (value) => setPenaltyFilters((prev) => ({
                    ...prev,
                    groupId: value || ""
                  })),
                  filterOption: (input, option) => option?.children?.toString().toLowerCase().includes(input.toLowerCase()),
                  size: "large",
                  children: groups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 2149,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2128,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2124,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "Start Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2158,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  size: "large",
                  type: "date",
                  value: penaltyFilters.startDate,
                  onChange: (e) => setPenaltyFilters((prev) => ({
                    ...prev,
                    startDate: e.target.value
                  }))
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2161,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2157,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: "End Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2176,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  size: "large",
                  type: "date",
                  value: penaltyFilters.endDate,
                  onChange: (e) => setPenaltyFilters((prev) => ({
                    ...prev,
                    endDate: e.target.value
                  }))
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2179,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2175,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-end", children: /* @__PURE__ */ jsxDEV(
              Button,
              {
                size: "middle",
                onClick: () => setPenaltyFilters({
                  groupId: "",
                  startDate: "",
                  endDate: ""
                }),
                children: "Clear Filters"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2194,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2193,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2122,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 2114,
          columnNumber: 11
        }, this),
        activePenaltyView === "chit" && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow mb-6 p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow p-4 border-l-4 border-blue-500", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-xs uppercase tracking-wide", children: "Total Penalties" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2218,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-800", children: summaryData.totalPenalties }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2219,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2217,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-100 p-2 rounded-full", children: /* @__PURE__ */ jsxDEV(CalculatorOutlined, { className: "text-blue-600 text-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2222,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2221,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2216,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2215,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow p-4 border-l-4 border-orange-500", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-xs uppercase tracking-wide", children: "Total Due Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2230,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-orange-600", children: [
                "₹",
                summaryData.totalDue.toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2231,
                columnNumber: 23
              }, this),
              summaryData.dueCount > 0 && /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: [
                summaryData.dueCount,
                " customers have due"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2233,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2229,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-orange-100 p-2 rounded-full", children: /* @__PURE__ */ jsxDEV(CalculatorOutlined, { className: "text-orange-600 text-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2237,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2236,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2228,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2227,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow p-4 border-l-4 border-red-500", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-xs uppercase tracking-wide", children: "Total Penalty Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2245,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-red-600", children: [
                "₹",
                summaryData.totalPenalty.toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2246,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2244,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-red-100 p-2 rounded-full", children: /* @__PURE__ */ jsxDEV(CalculatorOutlined, { className: "text-red-600 text-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2249,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2248,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2243,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2242,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow p-4 border-l-4 border-purple-500", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-xs uppercase tracking-wide", children: "Total Late Fee" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2257,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-purple-600", children: [
                "₹",
                summaryData.totalLateFee.toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2258,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2256,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-purple-100 p-2 rounded-full", children: /* @__PURE__ */ jsxDEV(CalculatorOutlined, { className: "text-purple-600 text-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2261,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2260,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2255,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2254,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 2213,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 2212,
          columnNumber: 11
        }, this),
        activePenaltyView === "loan" && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow mb-6 p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow p-4 border-l-4 border-blue-500", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-xs uppercase tracking-wide", children: "Total Loan Penalties" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2276,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-800", children: loanSummaryData.totalPenalties }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2277,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2275,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-100 p-2 rounded-full", children: /* @__PURE__ */ jsxDEV(CalculatorOutlined, { className: "text-blue-600 text-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2280,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2279,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2274,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2273,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow p-4 border-l-4 border-red-500", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-xs uppercase tracking-wide", children: "Total Penalty Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2288,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-red-600", children: [
                "₹",
                loanSummaryData.totalPenaltyAmount.toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2289,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2287,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-red-100 p-2 rounded-full", children: /* @__PURE__ */ jsxDEV(CalculatorOutlined, { className: "text-red-600 text-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2292,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2291,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2286,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2285,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow p-4 border-l-4 border-purple-500", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-xs uppercase tracking-wide", children: "Unique Customers" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2300,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-800", children: loanSummaryData.uniqueCustomers }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2301,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2299,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-purple-100 p-2 rounded-full", children: /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-purple-600 text-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2304,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2303,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2298,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2297,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 2271,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 2270,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow", children: activePenaltyView === "chit" ? isLoadingPenalties ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-8", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2317,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-gray-500", children: "Loading chit penalties..." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2318,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 2316,
          columnNumber: 13
        }, this) : tableData.length > 0 ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: filterPenalties(tableData, searchText),
            columns,
            exportCols: excelcolumns,
            exportedFileName: `Chit_Penalties_${moment().format("DD-MM-YYYY")}`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2321,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-8 text-gray-500", children: [
          /* @__PURE__ */ jsxDEV("p", { children: "No chit penalty records found" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2329,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm mt-2", children: 'Click "Add Penalty" to create a new penalty record' }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2330,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 2328,
          columnNumber: 13
        }, this) : isLoadingLoanPenalties ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-8", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2336,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-gray-500", children: "Loading loan penalties..." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2337,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 2335,
          columnNumber: 13
        }, this) : loanTableData.length > 0 ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: filterPenalties(loanTableData, searchText),
            columns: loanColumns,
            exportCols: loanExportColumns,
            exportedFileName: `Loan_Penalties_${moment().format("DD-MM-YYYY")}`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2340,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-8 text-gray-500", children: [
          /* @__PURE__ */ jsxDEV("p", { children: "No loan penalty records found" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2348,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm mt-2", children: 'Click "Add Penalty" and select "Loan Penalty" to create' }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2349,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 2347,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 2313,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 2066,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
      lineNumber: 2059,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      AntModal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(GiftOutlined, { className: "text-purple-600 text-lg" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2362,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2361,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: "Batch Waive Off Penalties" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2365,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 font-normal mt-0.5", children: "Select customers and waive off penalties in bulk" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2368,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2364,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 2360,
          columnNumber: 9
        }, this),
        open: batchWaiveModalVisible,
        onCancel: () => {
          setBatchWaiveModalVisible(false);
          setSelectedCustomers([]);
          setBatchWaiveAmount("");
          setBatchWaiveReason("");
          setBatchWaiveType("both");
          setCustomersWithPenalties([]);
        },
        width: 1200,
        footer: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              onClick: () => {
                setBatchWaiveModalVisible(false);
                setSelectedCustomers([]);
                setCustomersWithPenalties([]);
              },
              children: "Cancel"
            },
            "cancel",
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2385,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "primary",
              danger: true,
              loading: isBatchWaiving,
              onClick: handleBatchWaiveOff,
              disabled: selectedCustomers.length === 0 || !batchWaiveAmount || parseFloat(batchWaiveAmount) <= 0,
              className: "bg-red-600 hover:bg-red-700",
              children: [
                "Waive Off for Selected (",
                selectedCustomers.length,
                ")"
              ]
            },
            "submit",
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2395,
              columnNumber: 9
            },
            this
          )
        ],
        styles: {
          body: { maxHeight: "70vh", overflowY: "auto", padding: "20px" }
        },
        children: isLoadingCustomers ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center py-12", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "animate-spin rounded-full h-16 w-16 border-b-2 border-purple-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2418,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(GiftOutlined, { className: "text-purple-400 text-xl animate-pulse" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2420,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2419,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2417,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-gray-600 font-medium", children: "Loading customers with penalties..." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2423,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-400", children: "Please wait while we fetch the data" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2426,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 2416,
          columnNumber: 9
        }, this) : customersWithPenalties.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-12", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4", children: /* @__PURE__ */ jsxDEV(GiftOutlined, { className: "text-gray-400 text-3xl" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2433,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2432,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 font-medium", children: "No customers with penalties found" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2435,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-400 mt-1", children: "All penalties have been cleared or waived off" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2438,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 2431,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg p-4 border border-purple-200", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-purple-800 mb-3 flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(CalculatorOutlined, { className: "text-purple-600" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2447,
                columnNumber: 17
              }, this),
              "Waive Off Configuration"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2446,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2453,
                    columnNumber: 21
                  }, this),
                  " Waive Off Type"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2452,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: "w-full",
                    value: batchWaiveType,
                    onChange: setBatchWaiveType,
                    size: "large",
                    children: [
                      /* @__PURE__ */ jsxDEV(Select.Option, { value: "penalty", children: "Penalty Only" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 2461,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(Select.Option, { value: "latefee", children: "Late Fee Only" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 2462,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(Select.Option, { value: "both", children: "Both Penalty & Late Fee" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 2463,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2455,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2451,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2470,
                    columnNumber: 21
                  }, this),
                  " Amount to Waive (₹)"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2469,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    value: batchWaiveAmount,
                    onChange: (e) => setBatchWaiveAmount(e.target.value),
                    placeholder: "Enter amount",
                    min: 0,
                    step: 0.01,
                    prefix: "₹",
                    size: "large",
                    className: "rounded-lg"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2472,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2468,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Reason (Optional)" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2485,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    value: batchWaiveReason,
                    onChange: (e) => setBatchWaiveReason(e.target.value),
                    placeholder: "Enter reason for waiver",
                    size: "large",
                    className: "rounded-lg"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2488,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2484,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2450,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2445,
            columnNumber: 13
          }, this),
          selectedCustomers.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 rounded-lg p-3 border border-blue-200 flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-blue-800", children: [
                "Selected: ",
                selectedCustomers.length,
                " customer(s)"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2503,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600", children: [
                "Total Penalty: ₹",
                selectedCustomers.reduce((sum, c) => sum + c.totalPenalty, 0).toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2506,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600", children: [
                "Total Late Fee: ₹",
                selectedCustomers.reduce((sum, c) => sum + c.totalLateFee, 0).toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2512,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2502,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                size: "small",
                onClick: () => setSelectedCustomers([]),
                className: "text-blue-600",
                children: "Clear All"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2519,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2501,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-3", children: /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800", children: [
              "Customers with Penalties (",
              customersWithPenalties.length,
              ")"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2532,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2531,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "border rounded-lg overflow-hidden", children: /* @__PURE__ */ jsxDEV(
              Table,
              {
                columns: [
                  {
                    title: /* @__PURE__ */ jsxDEV(
                      Checkbox,
                      {
                        checked: selectedCustomers.length === customersWithPenalties.length && customersWithPenalties.length > 0,
                        indeterminate: selectedCustomers.length > 0 && selectedCustomers.length < customersWithPenalties.length,
                        onChange: (e) => {
                          if (e.target.checked) {
                            setSelectedCustomers([...customersWithPenalties]);
                          } else {
                            setSelectedCustomers([]);
                          }
                        }
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 2543,
                        columnNumber: 19
                      },
                      this
                    ),
                    dataIndex: "selection",
                    key: "selection",
                    width: 50,
                    render: (_, record) => /* @__PURE__ */ jsxDEV(
                      Checkbox,
                      {
                        checked: selectedCustomers.some(
                          (c) => c.userId === record.userId && c.ticket === record.ticket && c.groupId === record.groupId
                        ),
                        onChange: (e) => {
                          if (e.target.checked) {
                            setSelectedCustomers(
                              [
                                ...selectedCustomers,
                                record
                              ]
                            );
                          } else {
                            setSelectedCustomers(
                              selectedCustomers.filter(
                                (c) => !(c.userId === record.userId && c.ticket === record.ticket && c.groupId === record.groupId)
                              )
                            );
                          }
                        }
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 2567,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    title: "Customer Name",
                    dataIndex: "userName",
                    key: "userName",
                    sorter: (a, b) => a.userName.localeCompare(b.userName)
                  },
                  {
                    title: "Phone Number",
                    dataIndex: "userPhone",
                    key: "userPhone"
                  },
                  {
                    title: "Group",
                    dataIndex: "groupName",
                    key: "groupName"
                  },
                  {
                    title: "Ticket",
                    dataIndex: "ticket",
                    key: "ticket"
                  },
                  {
                    title: "Penalty Amount",
                    dataIndex: "penaltyAmount",
                    key: "penaltyAmount",
                    align: "right",
                    render: (amount, record) => /* @__PURE__ */ jsxDEV("span", { className: "text-red-600 font-semibold", children: [
                      "₹",
                      (record.penaltyAmount || 0).toLocaleString("en-IN")
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 2623,
                      columnNumber: 19
                    }, this),
                    sorter: (a, b) => a.penaltyAmount - b.penaltyAmount
                  },
                  {
                    title: "Late Fee",
                    dataIndex: "lateFeeAmount",
                    key: "lateFeeAmount",
                    align: "right",
                    render: (amount, record) => /* @__PURE__ */ jsxDEV("span", { className: "text-orange-600 font-semibold", children: [
                      "₹",
                      (record.lateFeeAmount || 0).toLocaleString("en-IN")
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 2635,
                      columnNumber: 19
                    }, this),
                    sorter: (a, b) => a.lateFeeAmount - b.lateFeeAmount
                  },
                  {
                    title: "Current Balance",
                    dataIndex: "currentBalance",
                    key: "currentBalance",
                    align: "right",
                    render: (amount) => /* @__PURE__ */ jsxDEV("span", { className: "text-purple-600 font-bold", children: [
                      "₹",
                      (amount || 0).toLocaleString("en-IN")
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 2647,
                      columnNumber: 19
                    }, this),
                    sorter: (a, b) => a.currentBalance - b.currentBalance
                  },
                  {
                    title: "Due + Penalty",
                    key: "duePlusPenalty",
                    align: "right",
                    render: (_, record) => {
                      const total = (record.currentBalance || 0) + (record.penaltyAmount || 0) + (record.lateFeeAmount || 0);
                      return /* @__PURE__ */ jsxDEV("span", { className: "text-red-600 font-bold", children: [
                        "₹",
                        total.toLocaleString("en-IN")
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 2664,
                        columnNumber: 23
                      }, this);
                    },
                    sorter: (a, b) => {
                      const totalA = (a.currentBalance || 0) + (a.penaltyAmount || 0) + (a.lateFeeAmount || 0);
                      const totalB = (b.currentBalance || 0) + (b.penaltyAmount || 0) + (b.lateFeeAmount || 0);
                      return totalA - totalB;
                    }
                  }
                ],
                dataSource: customersWithPenalties,
                rowKey: (record) => `${record.userId}_${record.ticket}`,
                pagination: {
                  pageSize: 10,
                  showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} customers`,
                  showSizeChanger: true
                },
                size: "middle",
                scroll: { x: true }
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2539,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2538,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2530,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Alert,
            {
              message: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, { className: "text-red-500 text-lg" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2702,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Important Notice" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2703,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2701,
                columnNumber: 13
              }, this),
              description: /* @__PURE__ */ jsxDEV("div", { className: "ml-6", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "mb-1", children: "This action will waive off the specified amount for ALL selected customers." }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2708,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-red-600 font-semibold", children: "This action cannot be undone. Please verify before proceeding." }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2712,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2707,
                columnNumber: 13
              }, this),
              type: "warning",
              showIcon: false,
              className: "border-l-4 border-red-500 bg-red-50"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2699,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 2443,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 2358,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      AntModal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(EyeOutlined, { className: "text-blue-600 text-lg" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2731,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2730,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: "Customer Statement" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2734,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 font-normal mt-0.5", children: "Complete transaction history and account summary" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2735,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2733,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 2729,
          columnNumber: 9
        }, this),
        open: statementModalVisible,
        onCancel: () => setStatementModalVisible(false),
        width: 1200,
        footer: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              onClick: () => setStatementModalVisible(false),
              className: "px-6",
              size: "large",
              children: "Close"
            },
            "close",
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2745,
              columnNumber: 9
            },
            this
          )
        ],
        className: "customer-statement-modal",
        styles: {
          body: { padding: "24px", maxHeight: "70vh", overflowY: "auto" }
        },
        children: isLoadingStatement ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-12", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "inline-block", children: /* @__PURE__ */ jsxDEV("div", { className: "animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2762,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2761,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-gray-500 font-medium", children: "Loading customer statement..." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2764,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 2760,
          columnNumber: 9
        }, this) : statementData ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-100 overflow-hidden shadow-sm", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-blue-600 to-indigo-600 px-5 py-3", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-white text-lg" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2774,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-white text-base mb-0", children: "Customer Information" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2775,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2773,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2772,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-5", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-9 h-9 bg-blue-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2784,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2783,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-gray-500 uppercase mb-1", children: "Customer Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2787,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800 text-base", children: statementData.user?.name || "N/A" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2790,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2786,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2782,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-9 h-9 bg-green-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(PhoneOutlined, { className: "text-green-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2797,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2796,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-gray-500 uppercase mb-1", children: "Phone Number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2800,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800 text-base", children: statementData.user?.phone || "N/A" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2803,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2799,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2795,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-9 h-9 bg-purple-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(TeamOutlined, { className: "text-purple-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2810,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2809,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-gray-500 uppercase mb-1", children: "Group Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2813,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800 text-base", children: statementData.group?.name || "N/A" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2816,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2812,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2808,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-9 h-9 bg-orange-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(CreditCardOutlined, { className: "text-orange-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2823,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2822,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-gray-500 uppercase mb-1", children: "Ticket Number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2826,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800 text-base", children: statementData.ticket || "N/A" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2829,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2825,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2821,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2781,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2780,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2771,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1 h-6 bg-gradient-to-b from-blue-500 to-purple-500 rounded-full" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2841,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 text-base mb-0", children: "Financial Summary" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2842,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2840,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "group relative bg-gradient-to-br from-green-50 to-green-100 rounded-xl border border-green-200 p-4 hover:shadow-lg transition-all duration-300 cursor-pointer overflow-hidden", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 right-0 w-20 h-20 bg-green-200 rounded-full -mr-10 -mt-10 opacity-50 group-hover:scale-150 transition-transform duration-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2849,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "relative z-10", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-green-700 uppercase", children: [
                      " ",
                      "Paid"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 2852,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "text-green-600 text-lg" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 2856,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2851,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-green-700", children: [
                    "₹",
                    (statementData.summary?.totalPaid || 0).toLocaleString(
                      "en-IN"
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2858,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-green-600 mt-1", children: "Total amount paid" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2864,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2850,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2848,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "group relative bg-gradient-to-br from-red-50 to-red-100 rounded-xl border border-red-200 p-4 hover:shadow-lg transition-all duration-300 cursor-pointer overflow-hidden", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 right-0 w-20 h-20 bg-red-200 rounded-full -mr-10 -mt-10 opacity-50 group-hover:scale-150 transition-transform duration-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2872,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "relative z-10", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-red-700 uppercase", children: "Penalty" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 2875,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, { className: "text-red-600 text-lg" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 2878,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2874,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-red-700", children: [
                    "₹",
                    (statementData.summary?.totalPenalty || 0).toLocaleString("en-IN")
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2880,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-red-600 mt-1", children: "Total penalty charged" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2886,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2873,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2871,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "group relative bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl border border-orange-200 p-4 hover:shadow-lg transition-all duration-300 cursor-pointer overflow-hidden", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 right-0 w-20 h-20 bg-orange-200 rounded-full -mr-10 -mt-10 opacity-50 group-hover:scale-150 transition-transform duration-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2894,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "relative z-10", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-orange-700 uppercase", children: "Late Fee" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 2897,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(ClockCircleOutlined, { className: "text-orange-600 text-lg" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 2900,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2896,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-orange-700", children: [
                    "₹",
                    (statementData.summary?.totalLateFee || 0).toLocaleString("en-IN")
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2902,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-orange-600 mt-1", children: "Total late fee charged" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2908,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2895,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2893,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "group relative bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl border border-blue-200 p-4 hover:shadow-lg transition-all duration-300 cursor-pointer overflow-hidden", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 right-0 w-20 h-20 bg-blue-200 rounded-full -mr-10 -mt-10 opacity-50 group-hover:scale-150 transition-transform duration-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2916,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "relative z-10", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-blue-700 uppercase", children: "Current Balance" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 2919,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(WalletOutlined, { className: "text-blue-600 text-lg" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 2922,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2918,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "p",
                    {
                      className: `text-2xl font-bold ${(statementData.enrollment?.currentBalance || 0) > 0 ? "text-orange-600" : "text-green-600"}`,
                      children: [
                        "₹",
                        Math.abs(
                          statementData.enrollment?.currentBalance || 0
                        ).toLocaleString("en-IN")
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 2924,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "p",
                    {
                      className: `text-xs mt-1 font-medium ${(statementData.enrollment?.currentBalance || 0) > 0 ? "text-orange-600" : "text-green-600"}`,
                      children: (statementData.enrollment?.currentBalance || 0) > 0 ? "Amount Due" : "Excess Amount"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 2932,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2917,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2915,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "group relative bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl border border-purple-200 p-4 hover:shadow-lg transition-all duration-300 cursor-pointer overflow-hidden", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 right-0 w-20 h-20 bg-purple-200 rounded-full -mr-10 -mt-10 opacity-50 group-hover:scale-150 transition-transform duration-500" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2944,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "relative z-10", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-purple-700 uppercase", children: "Penalty + Due" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 2947,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(CalculatorOutlined, { className: "text-purple-600 text-lg" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 2950,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2946,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-purple-700", children: [
                    "₹",
                    ((statementData.enrollment?.currentBalance || 0) + (statementData.summary?.totalPenalty || 0) + (statementData.summary?.totalLateFee || 0)).toLocaleString("en-IN")
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2952,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-purple-600 mt-1", children: "Total outstanding Due balance" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 2960,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2945,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2943,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2846,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2839,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1 h-6 bg-gradient-to-b from-green-500 to-blue-500 rounded-full" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2971,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 text-base mb-0", children: "Transaction History" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2972,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "ml-auto", children: /* @__PURE__ */ jsxDEV(
                Badge,
                {
                  count: `${processedTransactions?.length || 0} Transactions`,
                  className: "bg-blue-100 text-blue-700"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 2976,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2975,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2970,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-200 rounded-xl overflow-hidden shadow-sm", children: /* @__PURE__ */ jsxDEV(
              Table,
              {
                columns: transactionColumns,
                dataSource: processedTransactions || [],
                rowKey: (record, index) => index,
                pagination: {
                  pageSize: 10,
                  showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} transactions`,
                  showSizeChanger: true,
                  showQuickJumper: true
                },
                size: "middle",
                scroll: { x: true },
                className: "transaction-table",
                rowClassName: "hover:bg-gray-50 transition-colors duration-200",
                locale: { emptyText: "No transactions found" }
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 2984,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 2983,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 2969,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 2769,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-12", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4", children: /* @__PURE__ */ jsxDEV(EyeOutlined, { className: "text-gray-400 text-2xl" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3007,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3006,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 font-medium", children: "No data available" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3009,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-400 text-sm mt-1", children: "Unable to load customer statement" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3010,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 3005,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 2727,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      AntModal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(HistoryOutlined, { className: "text-purple-600 text-lg" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3022,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3021,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: "Penalty History" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3025,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 font-normal mt-0.5", children: "Complete penalty and late fee records" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3026,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3024,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 3020,
          columnNumber: 9
        }, this),
        open: penaltyHistoryModalVisible,
        onCancel: () => setPenaltyHistoryModalVisible(false),
        width: 1e3,
        footer: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              onClick: () => setPenaltyHistoryModalVisible(false),
              className: "px-6",
              size: "large",
              children: "Close"
            },
            "close",
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3036,
              columnNumber: 9
            },
            this
          )
        ],
        className: "penalty-history-modal",
        styles: {
          body: { padding: "24px", maxHeight: "70vh", overflowY: "auto" }
        },
        children: isLoadingPenaltyHistory ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-12", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "inline-block", children: /* @__PURE__ */ jsxDEV("div", { className: "animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3053,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3052,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-gray-500 font-medium", children: "Loading penalty history..." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3055,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 3051,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: selectedPenaltyCustomer && /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border border-purple-100 overflow-hidden shadow-sm", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-purple-600 to-pink-600 px-5 py-3", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-white text-lg" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3067,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-white text-base mb-0", children: "Customer Information" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3068,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3066,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3065,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-5", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-5", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-9 h-9 bg-blue-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3077,
                  columnNumber: 27
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3076,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-gray-500 uppercase mb-1", children: "Customer Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3080,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800 text-base", children: selectedPenaltyCustomer.userName }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3083,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3079,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3075,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-9 h-9 bg-green-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(PhoneOutlined, { className: "text-green-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3090,
                  columnNumber: 27
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3089,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-gray-500 uppercase mb-1", children: "Phone Number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3093,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800 text-base", children: selectedPenaltyCustomer.userPhone }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3096,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3092,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3088,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-9 h-9 bg-purple-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(TeamOutlined, { className: "text-purple-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3103,
                  columnNumber: 27
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3102,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-gray-500 uppercase mb-1", children: "Group Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3106,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800 text-base", children: selectedPenaltyCustomer.groupName }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3109,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3105,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3101,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-9 h-9 bg-orange-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(CreditCardOutlined, { className: "text-orange-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3116,
                  columnNumber: 27
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3115,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-gray-500 uppercase mb-1", children: "Ticket Number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3119,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800 text-base", children: selectedPenaltyCustomer.ticket }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3122,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3118,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3114,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3 bg-gradient-to-r from-red-50 to-orange-50 p-3 rounded-lg border border-red-200", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-9 h-9 bg-red-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, { className: "text-red-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3129,
                  columnNumber: 27
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3128,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-gray-500 uppercase mb-1", children: "Total Penalty & Late Fee" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3132,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-bold text-red-600 text-xl", children: [
                    "₹",
                    totalPenaltyAmount.toLocaleString("en-IN")
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3135,
                    columnNumber: 27
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3131,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3127,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3074,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3073,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3064,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1 h-6 bg-gradient-to-b from-purple-500 to-pink-500 rounded-full" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3147,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 text-base mb-0", children: "Penalty & Late Fee Records" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3148,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "ml-auto", children: /* @__PURE__ */ jsxDEV(
                Badge,
                {
                  count: `${penaltyHistoryData.length} Records`,
                  className: "bg-purple-100 text-purple-700"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3152,
                  columnNumber: 23
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3151,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3146,
              columnNumber: 19
            }, this),
            penaltyHistoryData.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-200 rounded-xl overflow-hidden shadow-sm", children: /* @__PURE__ */ jsxDEV(
              Table,
              {
                columns: penaltyHistoryColumns,
                dataSource: penaltyHistoryData,
                rowKey: "_id",
                pagination: {
                  pageSize: 10,
                  showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} records`,
                  showSizeChanger: true,
                  showQuickJumper: true
                },
                size: "middle",
                className: "penalty-table",
                rowClassName: (record) => {
                  if (record.type === "Penalty") return "penalty-row";
                  if (record.type === "Late Fee") return "latefee-row";
                  return "";
                }
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3161,
                columnNumber: 23
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3160,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-12 bg-gray-50 rounded-xl border border-gray-200", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4", children: /* @__PURE__ */ jsxDEV(HistoryOutlined, { className: "text-gray-400 text-2xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3184,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3183,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 font-medium", children: "No penalty history found" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3186,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-400 text-sm mt-1", children: "This customer has no penalty or late fee records" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3189,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3182,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3145,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 3062,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 3060,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 3018,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      AntModal,
      {
        title: "Edit Loan Penalty",
        open: editLoanModalVisible,
        onCancel: () => {
          setEditLoanModalVisible(false);
          setEditingLoanPenalty(null);
          setEditLoanAmount("");
          setEditLoanReason("");
        },
        footer: [
          /* @__PURE__ */ jsxDEV(Button, { onClick: () => setEditLoanModalVisible(false), children: "Cancel" }, "cancel", false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3212,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { type: "primary", loading: isUpdatingLoanPenalty, onClick: handleUpdateLoanPenalty, children: "Update Penalty" }, "submit", false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3213,
            columnNumber: 9
          }, this)
        ],
        width: 500,
        children: editingLoanPenalty && /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Customer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3222,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { value: editingLoanPenalty.user_id?.full_name || "N/A", disabled: true }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3223,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3221,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Loan ID" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3226,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { value: editingLoanPenalty.loan_id?.loan_id || editingLoanPenalty.loan_id?._id || "N/A", disabled: true }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3227,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3225,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Penalty Amount (₹)" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3230,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                value: editLoanAmount,
                onChange: (e) => setEditLoanAmount(e.target.value),
                placeholder: "Enter penalty amount",
                min: 0,
                step: 0.01,
                autoFocus: true
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3231,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3229,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Reason" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3242,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input.TextArea,
              {
                value: editLoanReason,
                onChange: (e) => setEditLoanReason(e.target.value),
                placeholder: "Reason for penalty",
                rows: 3
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3243,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3241,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 3220,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 3202,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      AntModal,
      {
        open: showPenaltyModal,
        onCancel: () => {
          setShowPenaltyModal(false);
          setPenaltyLoan(null);
          setPenaltyCharges([{ amount: "", reason: "" }]);
        },
        footer: null,
        centered: true,
        width: 700,
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsxDEV("span", { className: "text-orange-600 font-bold text-lg", children: "View Penalty Charges" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 3267,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 3266,
          columnNumber: 9
        }, this),
        children: /* @__PURE__ */ jsxDEV(Spin, { spinning: penaltyLoading, tip: "Loading penalty details...", children: /* @__PURE__ */ jsxDEV("div", { className: "p-2", children: [
          penaltyLoan && /* @__PURE__ */ jsxDEV("div", { className: "bg-orange-50 border border-orange-200 rounded-xl p-4 mb-5", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] uppercase text-gray-500 font-bold", children: "Borrower" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3278,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: penaltyLoan?.user_id?.full_name || penaltyLoan?.borrower_name || "—" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3279,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3277,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] uppercase text-gray-500 font-bold", children: "Loan ID" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3284,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800", children: penaltyLoan?.loan_id?.loan_id || "—" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3285,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3283,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] uppercase text-gray-500 font-bold", children: "Loan Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3290,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-green-600", children: [
                "₹",
                penaltyLoan?.loan_id?.loan_amount?.toLocaleString("en-IN") || 0
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3291,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3289,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] uppercase text-gray-500 font-bold", children: "Due Date" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3296,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-red-600", children: penaltyLoan?.loan_id?.end_date?.split("T")[0]?.split("-")?.reverse()?.join("-") || "—" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3297,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3295,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3276,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3275,
            columnNumber: 13
          }, this),
          penaltyLoan?.loan_id?.extra_charges?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mb-5", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-bold text-gray-600 uppercase mb-2", children: "Existing Charges" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3308,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg border overflow-hidden", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-sm", children: [
              /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-100 text-gray-600 text-xs font-semibold", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left", children: "Status" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3313,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-left", children: "Reason" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3314,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-right", children: "Charge (₹)" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3315,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-right", children: "Paid (₹)" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3316,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-3 py-2 text-right", children: "Balance (₹)" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3317,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3312,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3311,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("tbody", { className: "divide-y divide-gray-200", children: penaltyLoan.loan_id?.extra_charges.map((charge, idx) => {
                const isPaid = charge.paid === true;
                const paidAmount = charge.paid_amount || (isPaid ? charge.amount : 0);
                const balanceAmount = charge.balance_amount || (isPaid ? 0 : charge.amount - paidAmount);
                let statusText = "Unpaid";
                let statusColor = "bg-red-100 text-red-700";
                if (isPaid) {
                  statusText = "Paid";
                  statusColor = "bg-green-100 text-green-700";
                } else if (paidAmount > 0 && paidAmount < charge.amount) {
                  statusText = "Partially Paid";
                  statusColor = "bg-yellow-100 text-yellow-700";
                }
                return /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-100", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2", children: /* @__PURE__ */ jsxDEV("span", { className: `text-[10px] font-bold px-2 py-0.5 rounded-full ${statusColor}`, children: statusText }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3337,
                    columnNumber: 31
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3336,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-gray-700", children: charge.reason }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3341,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right font-medium text-gray-800", children: [
                    "₹",
                    Number(charge.amount || 0).toLocaleString("en-IN")
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3342,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right text-green-600 font-semibold", children: paidAmount > 0 ? `₹${paidAmount.toLocaleString("en-IN")}` : "—" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3345,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right text-red-600 font-semibold", children: balanceAmount > 0 ? `₹${balanceAmount.toLocaleString("en-IN")}` : "—" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3348,
                    columnNumber: 29
                  }, this)
                ] }, charge._id || idx, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3335,
                  columnNumber: 25
                }, this);
              }) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3320,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("tfoot", { className: "bg-orange-50 text-orange-800 font-bold", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                /* @__PURE__ */ jsxDEV("td", { colSpan: "2", className: "px-3 py-2 text-sm", children: "Totals" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3357,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right", children: [
                  "₹",
                  penaltyLoan.loan_id?.extra_charges.reduce((s, c) => s + Number(c.amount || 0), 0).toLocaleString("en-IN")
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3358,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right", children: [
                  "₹",
                  penaltyLoan.loan_id?.extra_charges.reduce((s, c) => s + Number(c.paid_amount || (c.paid ? c.amount : 0)), 0).toLocaleString("en-IN")
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3361,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-3 py-2 text-right", children: [
                  "₹",
                  penaltyLoan.loan_id?.extra_charges.reduce((s, c) => s + Number(c.balance_amount || (c.paid ? 0 : c.amount - (c.paid_amount || 0))), 0).toLocaleString("en-IN")
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3364,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3356,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3355,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3310,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3309,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3307,
            columnNumber: 13
          }, this),
          penaltyCharges.some((c) => c.amount) && /* @__PURE__ */ jsxDEV("div", { className: "mt-3 text-right text-sm font-bold text-orange-600", children: [
            "New Charges Total: ₹",
            penaltyCharges.reduce((s, c) => s + Number(c.amount || 0), 0).toLocaleString("en-IN")
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3376,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3 mt-6 pt-4 border-t", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowPenaltyModal(false);
                setPenaltyLoan(null);
                setPenaltyCharges([{ amount: "", reason: "" }]);
              },
              className: "px-5 py-2 rounded-lg border border-gray-300 text-gray-600 hover:bg-gray-50 font-medium",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3382,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3381,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 3272,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 3271,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 3255,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      AntModal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(EditOutlined, { className: "text-green-600 text-lg" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3402,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3401,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: "Edit Penalty & Late Fee" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3405,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 font-normal mt-0.5", children: "Modify penalty details for this transaction" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3408,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3404,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 3400,
          columnNumber: 9
        }, this),
        open: editModalVisible,
        onCancel: () => {
          setEditModalVisible(false);
          setEditingPenalty(null);
          setEditPenaltyAmount("");
          setEditLateFeeAmount("");
          setEditReason("");
        },
        width: 600,
        footer: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              onClick: () => {
                setEditModalVisible(false);
                setEditingPenalty(null);
                setEditPenaltyAmount("");
                setEditLateFeeAmount("");
                setEditReason("");
              },
              size: "large",
              className: "px-6",
              children: "Cancel"
            },
            "cancel",
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3424,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "primary",
              loading: isUpdatingPenalty,
              onClick: handleUpdatePenalty,
              size: "large",
              className: "px-6 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 border-none",
              icon: /* @__PURE__ */ jsxDEV(SaveOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3445,
                columnNumber: 17
              }, this),
              children: "Update Penalty"
            },
            "submit",
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3438,
              columnNumber: 9
            },
            this
          )
        ],
        className: "edit-penalty-modal",
        styles: {
          body: { padding: "24px" }
        },
        children: editingPenalty && /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-100 overflow-hidden", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-green-600 to-emerald-600 px-4 py-3", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-white text-base" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3461,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-white text-sm mb-0", children: "Transaction Details" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3462,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3460,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3459,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-blue-600 text-sm" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3471,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3470,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-gray-500 uppercase mb-1", children: "Customer" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3474,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: editingPenalty.user_id?.full_name }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3477,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3473,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3469,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(TeamOutlined, { className: "text-purple-600 text-sm" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3484,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3483,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-gray-500 uppercase mb-1", children: "Group" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3487,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: editingPenalty.group_id?.group_name }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3490,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3486,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3482,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(CreditCardOutlined, { className: "text-orange-600 text-sm" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3497,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3496,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-gray-500 uppercase mb-1", children: "Ticket" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3500,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: editingPenalty.ticket }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3503,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3499,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3495,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(CalendarOutlined, { className: "text-green-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3510,
                    columnNumber: 23
                  }, this),
                  "Penalty Date"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3509,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  DatePicker,
                  {
                    className: "w-full",
                    size: "large",
                    value: editDate,
                    format: "DD-MM-YYYY",
                    onChange: (date) => setEditDate(date)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3514,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3508,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3468,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3467,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3458,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl border border-yellow-200 p-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-3", children: [
              /* @__PURE__ */ jsxDEV(InfoCircleOutlined, { className: "text-yellow-600" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3529,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-700", children: "Current Amounts" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3530,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3528,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "text-center p-3 bg-white rounded-lg shadow-sm", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mb-1", children: "Current Penalty" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3536,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-red-600", children: [
                  "₹",
                  (editingPenalty.penalty_amount || 0).toLocaleString(
                    "en-IN"
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3537,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3535,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-center p-3 bg-white rounded-lg shadow-sm", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mb-1", children: "Current Late Fee" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3545,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-orange-600", children: [
                  "₹",
                  (editingPenalty.late_fee_amount || 0).toLocaleString(
                    "en-IN"
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3546,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3544,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3534,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3527,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1 h-5 bg-gradient-to-b from-green-500 to-emerald-500 rounded-full" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3559,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 text-base mb-0", children: "Edit Details" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3560,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3558,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(DollarOutlined, { className: "text-red-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3569,
                    columnNumber: 21
                  }, this),
                  "Penalty Amount"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3568,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    value: editPenaltyAmount,
                    onChange: (e) => setEditPenaltyAmount(e.target.value),
                    placeholder: "Enter penalty amount",
                    min: 0,
                    step: 0.01,
                    prefix: "₹",
                    size: "large",
                    className: "rounded-lg border-gray-300 focus:border-red-400 focus:ring-red-400",
                    suffix: editPenaltyAmount && /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-400", children: [
                      "New total: ₹",
                      ((editingPenalty.penalty_amount || 0) + parseFloat(editPenaltyAmount || 0)).toLocaleString("en-IN")
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 3584,
                      columnNumber: 19
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3572,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3567,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(ClockCircleOutlined, { className: "text-orange-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3599,
                    columnNumber: 21
                  }, this),
                  "Late Fee Amount"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3598,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    value: editLateFeeAmount,
                    onChange: (e) => setEditLateFeeAmount(e.target.value),
                    placeholder: "Enter late fee amount",
                    min: 0,
                    step: 0.01,
                    prefix: "₹",
                    size: "large",
                    className: "rounded-lg border-gray-300 focus:border-orange-400 focus:ring-orange-400",
                    suffix: editLateFeeAmount && /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-400", children: [
                      "New total: ₹",
                      ((editingPenalty.late_fee_amount || 0) + parseFloat(editLateFeeAmount || 0)).toLocaleString("en-IN")
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 3614,
                      columnNumber: 19
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3602,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3597,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(FileTextOutlined, { className: "text-blue-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3629,
                    columnNumber: 21
                  }, this),
                  "Reason for Update"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3628,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input.TextArea,
                  {
                    value: editReason,
                    onChange: (e) => setEditReason(e.target.value),
                    placeholder: "Enter reason for updating penalty/late fee...",
                    rows: 3,
                    className: "rounded-lg border-gray-300 focus:border-blue-400 focus:ring-blue-400",
                    maxLength: 200,
                    showCount: true
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3632,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3627,
                columnNumber: 17
              }, this),
              (editPenaltyAmount || editLateFeeAmount) && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-4 border border-blue-200 animate-fadeIn", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-3", children: [
                  /* @__PURE__ */ jsxDEV(CalculatorOutlined, { className: "text-blue-600" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3647,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-700", children: "Updated Summary Preview" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3648,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3646,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600", children: "New Penalty Amount:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 3654,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-red-600", children: [
                      "₹",
                      ((editingPenalty.penalty_amount || 0) + parseFloat(editPenaltyAmount || 0)).toLocaleString("en-IN")
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 3657,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3653,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600", children: "New Late Fee Amount:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 3666,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-orange-600", children: [
                      "₹",
                      ((editingPenalty.late_fee_amount || 0) + parseFloat(editLateFeeAmount || 0)).toLocaleString("en-IN")
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 3669,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3665,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t border-blue-200", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-700", children: "Total Addition:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 3678,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-purple-600 text-lg", children: [
                      "₹",
                      (parseFloat(editPenaltyAmount || 0) + parseFloat(editLateFeeAmount || 0)).toLocaleString("en-IN")
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 3681,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3677,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3652,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3645,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3565,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3557,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Alert,
            {
              message: "Important Notice",
              description: "Editing penalty amounts will affect the customer's total due balance. Please verify the changes before updating.",
              type: "warning",
              showIcon: true,
              className: "border-l-4 border-yellow-500 bg-yellow-50"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3696,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 3456,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 3398,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      AntModal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(DollarOutlined, { className: "text-purple-600 text-lg" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3712,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3711,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: "Waive Off Penalties" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3715,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 font-normal mt-0.5", children: "Reduce or remove penalties and late fees for this customer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3716,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3714,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 3710,
          columnNumber: 9
        }, this),
        open: waiveOffModalVisible,
        onCancel: () => {
          setWaiveOffModalVisible(false);
          setWaiveOffData(null);
          setWaiveOffAmount("");
          setWaiveOffReason("");
          setWaiveOffType("both");
        },
        width: 700,
        footer: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              onClick: () => {
                setWaiveOffModalVisible(false);
                setWaiveOffData(null);
                setWaiveOffAmount("");
                setWaiveOffReason("");
              },
              children: "Cancel"
            },
            "cancel",
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3732,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "primary",
              danger: true,
              loading: isWaivingOff,
              onClick: handleWaiveOffPenalties,
              disabled: !waiveOffAmount || parseFloat(waiveOffAmount) <= 0,
              className: "bg-red-600 hover:bg-red-700",
              children: "Waive Off Amount"
            },
            "submit",
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3743,
              columnNumber: 9
            },
            this
          )
        ],
        styles: {
          body: { maxHeight: "70vh", overflowY: "auto", padding: "20px" }
        },
        children: isLoadingStatement ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center py-12", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "animate-spin rounded-full h-16 w-16 border-b-2 border-purple-600" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3762,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(DollarOutlined, { className: "text-purple-400 text-xl animate-pulse" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3764,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3763,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3761,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-gray-600 font-medium", children: "Loading customer data..." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3767,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-400", children: "Please wait while we fetch the details" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3770,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 3760,
          columnNumber: 9
        }, this) : waiveOffData ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-gray-50 to-blue-50 rounded-xl border border-gray-200 overflow-hidden", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-purple-600 to-indigo-600 px-4 py-3", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-white text-base" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3780,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-white text-sm mb-0", children: "Customer Information" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3781,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3779,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3778,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-2", children: [
                /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-blue-500 mt-0.5" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3789,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Customer Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3791,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: waiveOffData.userName }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3792,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3790,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3788,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-2", children: [
                /* @__PURE__ */ jsxDEV(PhoneOutlined, { className: "text-green-500 mt-0.5" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3798,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Phone Number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3800,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: waiveOffData.userPhone }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3801,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3799,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3797,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-2", children: [
                /* @__PURE__ */ jsxDEV(TeamOutlined, { className: "text-purple-500 mt-0.5" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3807,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Group Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3809,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: waiveOffData.groupName }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3810,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3808,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3806,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-2", children: [
                /* @__PURE__ */ jsxDEV(CreditCardOutlined, { className: "text-orange-500 mt-0.5" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3816,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Ticket Number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3818,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: waiveOffData.ticket }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3819,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3817,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3815,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3787,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3786,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3777,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-red-50 to-red-100 rounded-xl border border-red-200 p-4 text-center", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-red-600 uppercase", children: "Total Penalty" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3831,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-red-600 mt-1", children: [
                "₹",
                waiveOffData.totalPenalty.toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3834,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3830,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl border border-orange-200 p-4 text-center", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-orange-600 uppercase", children: "Total Late Fee" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3839,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-orange-600 mt-1", children: [
                "₹",
                waiveOffData.totalLateFee.toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3842,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3838,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl border border-blue-200 p-4 text-center", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-blue-600 uppercase", children: "Current Balance" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3847,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-blue-600 mt-1", children: [
                "₹",
                Math.abs(waiveOffData.currentBalance).toLocaleString(
                  "en-IN"
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3850,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-1", children: waiveOffData.currentBalance > 0 ? "Amount Due" : "Excess Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3856,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3846,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3829,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border border-purple-200 p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-purple-600 uppercase", children: "Total Due (Including Penalties)" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3868,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-purple-700", children: [
                "₹",
                (waiveOffData.currentBalance + waiveOffData.totalPenalty + waiveOffData.totalLateFee).toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3871,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3867,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(CalculatorOutlined, { className: "text-purple-500 text-3xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3880,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3866,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3865,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl border border-gray-200 overflow-hidden", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 px-4 py-3 border-b border-gray-200", children: /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-800 flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(EditOutlined, { className: "text-purple-600" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3888,
                columnNumber: 19
              }, this),
              "Waive Off Configuration"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3887,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3886,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-4 space-y-4", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3896,
                    columnNumber: 21
                  }, this),
                  " Waive Off Type"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3895,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: "w-full",
                    value: waiveOffType,
                    onChange: setWaiveOffType,
                    size: "large",
                    children: [
                      /* @__PURE__ */ jsxDEV(Select.Option, { value: "penalty", children: "Penalty Only" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 3904,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(Select.Option, { value: "latefee", children: "Late Fee Only" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 3905,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(Select.Option, { value: "both", children: "Both Penalty & Late Fee" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 3906,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3898,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3894,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3915,
                    columnNumber: 21
                  }, this),
                  " Amount to Waive (₹)"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3914,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    value: waiveOffAmount,
                    onChange: (e) => setWaiveOffAmount(e.target.value),
                    placeholder: "Enter amount to waive off",
                    min: 0,
                    step: 0.01,
                    prefix: "₹",
                    size: "large",
                    className: "rounded-lg",
                    suffix: waiveOffAmount && /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-400", children: [
                      "Max: ₹",
                      (waiveOffType === "penalty" ? waiveOffData.totalPenalty : waiveOffType === "latefee" ? waiveOffData.totalLateFee : waiveOffData.totalPenalty + waiveOffData.totalLateFee).toLocaleString("en-IN")
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 3929,
                      columnNumber: 19
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3917,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3913,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Reason (Optional)" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3946,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Input.TextArea,
                  {
                    value: waiveOffReason,
                    onChange: (e) => setWaiveOffReason(e.target.value),
                    placeholder: "Enter reason for waiving off penalties...",
                    rows: 3,
                    className: "rounded-lg",
                    maxLength: 200,
                    showCount: true
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3949,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3945,
                columnNumber: 17
              }, this),
              waiveOffAmount && parseFloat(waiveOffAmount) > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-green-50 to-teal-50 rounded-lg p-4 border border-green-200", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-3", children: [
                  /* @__PURE__ */ jsxDEV(CalculatorOutlined, { className: "text-green-600" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3964,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-700", children: "Preview After Waiver" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3965,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3963,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600", children: "Amount to Waive:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 3971,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-red-600 text-lg", children: [
                      "₹",
                      parseFloat(waiveOffAmount).toLocaleString("en-IN")
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 3974,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3970,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center pt-2 border-t border-green-200", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-700", children: "Remaining Amount:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 3979,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-green-600 text-lg", children: [
                      "₹",
                      ((waiveOffType === "penalty" ? waiveOffData.totalPenalty : waiveOffType === "latefee" ? waiveOffData.totalLateFee : waiveOffData.totalPenalty + waiveOffData.totalLateFee) - parseFloat(waiveOffAmount)).toLocaleString("en-IN")
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 3982,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 3978,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 3969,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 3962,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 3892,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 3885,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            Alert,
            {
              message: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, { className: "text-red-500 text-lg" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4005,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Important Notice" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4006,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4004,
                columnNumber: 13
              }, this),
              description: /* @__PURE__ */ jsxDEV("div", { className: "ml-6", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "mb-1", children: "This action will permanently reduce the customer's penalty/late fee amount." }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4011,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-red-600 font-semibold", children: "This action cannot be undone. Please verify before proceeding." }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4015,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4010,
                columnNumber: 13
              }, this),
              type: "warning",
              showIcon: false,
              className: "border-l-4 border-red-500 bg-red-50"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4002,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 3775,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-12", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4", children: /* @__PURE__ */ jsxDEV(DollarOutlined, { className: "text-gray-400 text-2xl" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4029,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4028,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 font-medium", children: "No data available" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4031,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-400 text-sm mt-1", children: "Unable to load customer penalty data" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4032,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 4027,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 3708,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      AntModal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(HistoryOutlined, { className: "text-blue-600 text-lg" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4043,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4042,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: "Waiver History" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4046,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 font-normal mt-0.5", children: "Complete record of all waived off penalties and late fees" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4047,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4045,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 4041,
          columnNumber: 9
        }, this),
        open: waiverHistoryModalVisible,
        onCancel: () => setWaiverHistoryModalVisible(false),
        width: 1e3,
        footer: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              onClick: () => setWaiverHistoryModalVisible(false),
              children: "Close"
            },
            "close",
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4057,
              columnNumber: 9
            },
            this
          )
        ],
        children: isLoadingWaiverHistory ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-8", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4067,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "mt-2", children: "Loading waiver history..." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4068,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 4066,
          columnNumber: 9
        }, this) : waiverHistoryData.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-12", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4", children: /* @__PURE__ */ jsxDEV(HistoryOutlined, { className: "text-gray-400 text-2xl" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4073,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4072,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: "No waiver history found" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4075,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 4071,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV(
          Table,
          {
            columns: [
              {
                title: "Date",
                dataIndex: "createdAt",
                key: "date",
                render: (date) => moment(date).format("DD-MM-YYYY HH:mm:ss"),
                sorter: (a, b) => new Date(a.createdAt) - new Date(b.createdAt),
                defaultSortOrder: "descend"
              },
              {
                title: "Waived Amount",
                dataIndex: "waived_amount",
                key: "waived_amount",
                align: "right",
                render: (amount) => /* @__PURE__ */ jsxDEV("span", { className: "text-green-600 font-semibold", children: [
                  "₹",
                  amount.toLocaleString("en-IN")
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4094,
                  columnNumber: 13
                }, this),
                sorter: (a, b) => a.waived_amount - b.waived_amount
              },
              {
                title: "Penalty Waived",
                dataIndex: "waived_penalty_amount",
                key: "waived_penalty_amount",
                align: "right",
                render: (amount) => /* @__PURE__ */ jsxDEV("span", { className: "text-red-600", children: [
                  "₹",
                  amount.toLocaleString("en-IN")
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4106,
                  columnNumber: 13
                }, this)
              },
              {
                title: "Late Fee Waived",
                dataIndex: "waived_late_fee_amount",
                key: "waived_late_fee_amount",
                align: "right",
                render: (amount) => /* @__PURE__ */ jsxDEV("span", { className: "text-orange-600", children: [
                  "₹",
                  amount.toLocaleString("en-IN")
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4117,
                  columnNumber: 13
                }, this)
              },
              {
                title: "Type",
                dataIndex: "waive_off_type",
                key: "type",
                render: (type) => /* @__PURE__ */ jsxDEV(
                  Tag,
                  {
                    color: type === "both" ? "purple" : type === "penalty" ? "red" : "orange",
                    children: type === "both" ? "Both" : type === "penalty" ? "Penalty Only" : "Late Fee Only"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4127,
                    columnNumber: 13
                  },
                  this
                )
              },
              {
                title: "Reason",
                dataIndex: "reason",
                key: "reason",
                ellipsis: true
              },
              {
                title: "Waived By",
                dataIndex: "waived_by",
                key: "waived_by",
                render: (user) => user?.full_name || "System"
              }
            ],
            dataSource: waiverHistoryData,
            rowKey: "_id",
            pagination: { pageSize: 10 },
            size: "middle"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4078,
            columnNumber: 9
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 4039,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
          /* @__PURE__ */ jsxDEV(CalculatorOutlined, { className: "mr-2 text-blue-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4169,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-semibold", children: "Add Manual Penalty" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4170,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 4168,
          columnNumber: 9
        }, this),
        placement: "right",
        onClose: handleCloseFirstDrawer,
        open: addPenaltyDrawerOpen,
        width: 700,
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-5", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: [
              "Penalty Type ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4181,
                columnNumber: 26
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4180,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(
              Radio.Group,
              {
                value: penaltyType,
                onChange: (e) => setPenaltyType(e.target.value),
                buttonStyle: "solid",
                children: [
                  /* @__PURE__ */ jsxDEV(Radio.Button, { value: "chit", children: "Chit Penalty" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4189,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV(Radio.Button, { value: "loan", children: "Loan Penalty" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4190,
                    columnNumber: 13
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4184,
                columnNumber: 11
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4179,
            columnNumber: 9
          }, this),
          penaltyType === "chit" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 p-4 rounded-xl bg-blue-50 border-l-4 border-blue-500 shadow-sm", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "text-blue-600 text-xl", children: "ℹ️" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4199,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-blue-800 text-sm", children: "Select Customer for Penalty" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4201,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-blue-700 text-sm", children: "Only customers with outstanding dues are shown." }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4204,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4200,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4198,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4197,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: [
                "Group ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4214,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4213,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "w-full",
                  placeholder: "Select Group",
                  value: selectedGroupId || void 0,
                  onChange: handleGroupSelect,
                  allowClear: true,
                  loading: isLoadingGroups,
                  showSearch: true,
                  filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
                  children: groupOptions.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group.value, children: group.label }, group.value, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4230,
                      columnNumber: 15
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4217,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4212,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: [
                "Customer ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4240,
                  columnNumber: 26
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4239,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "w-full",
                  placeholder: "Select Customer",
                  value: selectedCustomerId || void 0,
                  onChange: handleCustomerSelect,
                  disabled: !selectedGroupId,
                  allowClear: true,
                  loading: isLoadingUsers,
                  showSearch: true,
                  filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
                  children: customerOptions.map(
                    (customer) => /* @__PURE__ */ jsxDEV(Select.Option, { value: customer.value, children: customer.label }, customer.value, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4257,
                      columnNumber: 15
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4243,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4238,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-5", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-2", children: [
                "Ticket ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4267,
                  columnNumber: 24
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4266,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "w-full",
                  placeholder: "Select Ticket",
                  value: selectedTicket || void 0,
                  onChange: handleTicketSelect,
                  disabled: !selectedCustomerId,
                  allowClear: true,
                  showSearch: true,
                  filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
                  children: ticketOptions.map(
                    (ticket) => /* @__PURE__ */ jsxDEV(Select.Option, { value: ticket.value, children: ticket.label }, ticket.value, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4283,
                      columnNumber: 15
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4270,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4265,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "pt-4 flex gap-3", children: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "primary",
                  className: "flex-1",
                  disabled: !selectedTicket,
                  onClick: handleProceedToPenalty,
                  children: "Proceed to Add Penalty"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4291,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(Button, { onClick: handleCloseFirstDrawer, children: "Cancel" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4300,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4290,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4196,
            columnNumber: 9
          }, this),
          penaltyType === "loan" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-5", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-blue-50 to-indigo-50 p-4 rounded-xl border border-blue-200", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-blue-800 mb-2", children: "Loan Penalty Information" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4309,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-600", children: "Select a customer and a loan, then add penalty charges." }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4310,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4308,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                "Customer ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4315,
                  columnNumber: 90
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4315,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  placeholder: "Select Or Search Customer",
                  showSearch: true,
                  className: "w-full",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: selectedUserId || void 0,
                  onChange: handleCustomer,
                  size: "large",
                  children: users.map(
                    (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: `${user.full_name} | ${user.phone_number}` }, user._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4328,
                      columnNumber: 15
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4316,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4314,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: [
                "Select Loan ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4337,
                  columnNumber: 93
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4337,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  mode: "multiple",
                  placeholder: "Select Loan",
                  onChange: (value) => {
                    handlePaymentAntSelect(value);
                    setOpen(false);
                  },
                  loading: enrollmentLoading,
                  value: paymentGroupTickets,
                  className: "w-full",
                  size: "large",
                  children: borrowers?.map(
                    (borrower) => /* @__PURE__ */ jsxDEV(Select.Option, { value: `loan-${borrower._id}`, children: `${borrower.loan_id} | ₹ ${borrower.loan_amount}` }, `loan-${borrower._id}`, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4351,
                      columnNumber: 15
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4338,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4336,
              columnNumber: 13
            }, this),
            paymentGroupTickets.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "border rounded-lg bg-gray-50  space-y-2", children: paymentGroupTickets.map((item) => {
              const details = getTicketDetails(item);
              if (!details) return null;
              const dueInfo = getDueInfo(details.endDate);
              return /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-3 rounded shadow-sm border-l-4 border-blue-400", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV(Tag, { color: "blue", children: "LOAN" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4369,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "font-semibold mt-1", children: details.name }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4370,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4368,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-500 font-medium", children: "Due Status:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4373,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: `font-bold text-sm ${dueInfo?.status === "overdue" ? "text-red-600" : dueInfo?.status === "upcoming" ? "text-green-600" : "text-orange-600"}`, children: dueInfo.text }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4374,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4372,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Balance" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4383,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-red-600", children: [
                      "₹",
                      details.balance.toLocaleString("en-IN")
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4384,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4381,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4367,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 rounded-xl p-2", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 font-medium", children: "Loan Amount" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4389,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "font-bold text-blue-700 text-lg", children: [
                      "₹",
                      details.loanAmount.toLocaleString("en-IN")
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4392,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4388,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-green-50 rounded-xl p-2", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 font-medium", children: "Daily Payment" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4399,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "font-bold text-green-700 text-lg", children: [
                      "₹",
                      details.dailyPayment.toLocaleString("en-IN")
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4402,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4398,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-purple-50 rounded-xl p-2", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 font-medium", children: "Start Date" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4408,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: details.startDate?.split("T")[0].split("-").reverse().join("-") }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4411,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4407,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-orange-50 rounded-xl p-2", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 font-medium", children: "End Date" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4421,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: details.endDate?.split("T")[0].split("-").reverse().join("-") }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4424,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4420,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-emerald-50 rounded-xl p-2", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 font-medium", children: "Total Paid" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4434,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "font-bold text-emerald-700 text-lg", children: [
                      "₹",
                      details.totalPaid.toLocaleString("en-IN")
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4437,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4433,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4387,
                  columnNumber: 23
                }, this)
              ] }, item, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4366,
                columnNumber: 17
              }, this);
            }) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4360,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-700 mb-2", children: "Add Penalty Charges" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4450,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: penaltyCharges.map(
                (charge, index) => /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "flex items-center gap-4",
                    children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "w-50", children: /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "number",
                          placeholder: "Amount ₹",
                          value: charge.amount,
                          min: 0,
                          onChange: (e) => handlePenaltyChange(index, "amount", e.target.value),
                          prefix: "₹",
                          className: "h-11"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                          lineNumber: 4458,
                          columnNumber: 23
                        },
                        this
                      ) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 4457,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-[450px]", children: /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          placeholder: "Reason (e.g. Late fee, Penalty)",
                          value: charge.reason,
                          onChange: (e) => handlePenaltyChange(index, "reason", e.target.value),
                          className: "h-11"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                          lineNumber: 4472,
                          columnNumber: 23
                        },
                        this
                      ) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 4471,
                        columnNumber: 21
                      }, this),
                      penaltyCharges.length > 1 && /* @__PURE__ */ jsxDEV(
                        Button,
                        {
                          danger: true,
                          type: "text",
                          className: "mt-1 text-lg",
                          onClick: () => handleRemovePenaltyRow(index),
                          children: "×"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                          lineNumber: 4483,
                          columnNumber: 17
                        },
                        this
                      )
                    ]
                  },
                  index,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4453,
                    columnNumber: 15
                  },
                  this
                )
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4451,
                columnNumber: 15
              }, this),
              penaltyCharges.some((c) => c.amount) && /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-right text-sm font-bold text-orange-600", children: [
                "Total: ₹",
                penaltyCharges.reduce((s, c) => s + Number(c.amount || 0), 0).toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4496,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4449,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3 pt-4 border-t", children: [
              /* @__PURE__ */ jsxDEV(Button, { onClick: handleCloseFirstDrawer, children: "Cancel" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4507,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(Button, { type: "primary", loading: penaltyLoading, onClick: handlePenaltySubmit, children: "Save Penalty Charges" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4508,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4506,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4307,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 4166,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        title: null,
        placement: "right",
        onClose: () => {
          setAddPenaltyDetails(null);
          setAddPenaltyAmount("");
          setAddLateFeeAmount("");
        },
        open: !!addPenaltyDetails,
        width: 800,
        closable: false,
        children: addPenaltyDetails && /* @__PURE__ */ jsxDEV("div", { className: "h-full flex flex-col bg-white rounded-xl shadow-lg overflow-hidden", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-green-600 to-green-700 text-white p-6 border-b border-green-500", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-1", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-1 h-8 bg-yellow-400 rounded-full" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4536,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(Title, { level: 3, className: "text-white mb-0", children: "Add Manual Penalty" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4537,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4535,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(Text, { className: "text-green-100 text-sm", children: "Enter penalty and late fee amounts for customer account" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4541,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4534,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Space, { children: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  icon: /* @__PURE__ */ jsxDEV(HistoryOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4547,
                    columnNumber: 25
                  }, this),
                  onClick: handleViewPenaltyHistory,
                  className: "bg-white/10 border-white/20 text-white hover:bg-white/20 hover:text-white",
                  children: "View Penalty History"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4546,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  danger: true,
                  icon: /* @__PURE__ */ jsxDEV(ArrowLeftOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4555,
                    columnNumber: 25
                  }, this),
                  onClick: () => {
                    setAddPenaltyDetails(null);
                    setAddPenaltyAmount("");
                    setAddLateFeeAmount("");
                  },
                  className: "bg-red-500/10 border-red-500/20 text-red-500 hover:bg-red-500/20",
                  children: "Close"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4553,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4545,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4533,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4532,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-6 flex-grow overflow-auto bg-gray-50", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-6 bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-blue-500 to-indigo-500 px-5 py-3 border-b border-gray-200", children: /* @__PURE__ */ jsxDEV(Title, { level: 5, className: "mb-0 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-blue-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4574,
                  columnNumber: 21
                }, this),
                "Customer Information"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4573,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4572,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "p-5", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-blue-600 text-sm" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4582,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4581,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV(
                        Text,
                        {
                          type: "secondary",
                          className: "text-xs uppercase block font-semibold",
                          children: "Customer"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                          lineNumber: 4585,
                          columnNumber: 25
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(Text, { strong: true, className: "text-base", children: addPenaltyDetails.userName }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 4591,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4584,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4580,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(PhoneOutlined, { className: "text-green-600 text-sm" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4598,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4597,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV(
                        Text,
                        {
                          type: "secondary",
                          className: "text-xs uppercase block font-semibold",
                          children: "Phone"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                          lineNumber: 4601,
                          columnNumber: 25
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(Text, { strong: true, className: "text-base", children: addPenaltyDetails.userPhone }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 4607,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4600,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4596,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(TeamOutlined, { className: "text-purple-600 text-sm" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4614,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4613,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV(
                        Text,
                        {
                          type: "secondary",
                          className: "text-xs uppercase block font-semibold",
                          children: "Group"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                          lineNumber: 4617,
                          columnNumber: 25
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(Text, { strong: true, className: "text-base", children: addPenaltyDetails.groupName }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 4623,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4616,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4612,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(CreditCardOutlined, { className: "text-orange-600 text-sm" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4630,
                      columnNumber: 25
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4629,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV(
                        Text,
                        {
                          type: "secondary",
                          className: "text-xs uppercase block font-semibold",
                          children: "Ticket"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                          lineNumber: 4633,
                          columnNumber: 25
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(Text, { strong: true, className: "text-base", children: addPenaltyDetails.paymentsTicket }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 4639,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4632,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4628,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4579,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 mt-5 pt-4 border-t border-gray-200", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-orange-50 to-orange-100 rounded-lg p-3 border border-orange-200", children: [
                    /* @__PURE__ */ jsxDEV(
                      Text,
                      {
                        type: "secondary",
                        className: "text-xs uppercase block font-semibold",
                        children: "Current Due Balance"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 4649,
                        columnNumber: 23
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-baseline gap-1 mt-1", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-bold text-orange-600", children: "₹" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 4656,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-bold text-orange-600", children: (addPenaltyDetails.currentBalance || addPenaltyDetails.balance || 0).toLocaleString("en-IN") }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 4659,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4655,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4648,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-red-50 to-red-100 rounded-lg p-3 border border-red-200", children: [
                    /* @__PURE__ */ jsxDEV(
                      Text,
                      {
                        type: "secondary",
                        className: "text-xs uppercase block font-semibold",
                        children: "Current Penalty"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 4669,
                        columnNumber: 23
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-baseline gap-1 mt-1", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-bold text-red-600", children: "₹" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 4676,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-bold text-red-600", children: (addPenaltyDetails.totalPenalty || 0).toLocaleString(
                        "en-IN"
                      ) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 4679,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4675,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4668,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-red-50 to-red-100 rounded-lg p-3 border border-red-200", children: [
                    /* @__PURE__ */ jsxDEV(
                      Text,
                      {
                        type: "secondary",
                        className: "text-xs uppercase block font-semibold",
                        children: "Current Late Fee"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 4687,
                        columnNumber: 23
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-baseline gap-1 mt-1", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-bold text-red-600", children: "₹" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 4694,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-bold text-red-600", children: (addPenaltyDetails.totalLateFee || 0).toLocaleString(
                        "en-IN"
                      ) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 4697,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4693,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4686,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4647,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4578,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4571,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-6 bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-purple-300 to-pink-300 px-5 py-3 border-b border-gray-200", children: /* @__PURE__ */ jsxDEV(Title, { level: 4, className: "mb-0 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(EditOutlined, { className: "text-purple-600" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4712,
                  columnNumber: 21
                }, this),
                "Enter Penalty Details"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4711,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4710,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "p-5", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV(DollarOutlined, { className: "text-orange-500" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4721,
                      columnNumber: 25
                    }, this),
                    "Penalty Amount"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4720,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      value: addPenaltyAmount,
                      onChange: (e) => setAddPenaltyAmount(e.target.value),
                      placeholder: "Enter penalty amount",
                      min: 0,
                      step: 0.01,
                      size: "large",
                      prefix: "₹",
                      className: "rounded-lg border-gray-300 focus:border-orange-400 focus:ring-orange-400"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4724,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "mt-2 p-2 bg-orange-50 rounded-lg border border-orange-200", children: [
                    /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-xs", children: "New total penalty will be:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4736,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-baseline gap-1", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-orange-600", children: "₹" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 4740,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-base font-bold text-orange-600", children: (addPenaltyDetails.totalPenalty + (parseFloat(addPenaltyAmount) || 0)).toLocaleString("en-IN") }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 4743,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4739,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4735,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4719,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV(ClockCircleOutlined, { className: "text-red-500" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4756,
                      columnNumber: 25
                    }, this),
                    "Late Fee Amount"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4755,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      value: addLateFeeAmount,
                      onChange: (e) => setAddLateFeeAmount(e.target.value),
                      placeholder: "Enter late fee amount",
                      min: 0,
                      step: 0.01,
                      size: "large",
                      prefix: "₹",
                      className: "rounded-lg border-gray-300 focus:border-red-400 focus:ring-red-400"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4759,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "mt-2 p-2 bg-red-50 rounded-lg border border-red-200", children: [
                    /* @__PURE__ */ jsxDEV(Text, { type: "secondary", className: "text-xs", children: "New total late fee will be:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4771,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-baseline gap-1", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-red-600", children: "₹" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 4775,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-base font-bold text-red-600", children: (addPenaltyDetails.totalLateFee + (parseFloat(addLateFeeAmount) || 0)).toLocaleString("en-IN") }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                        lineNumber: 4778,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4774,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4770,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4754,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4717,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4716,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4709,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-6 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl border border-yellow-200 overflow-hidden", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-yellow-100 to-orange-100 px-5 py-3", children: /* @__PURE__ */ jsxDEV(Title, { level: 5, className: "mb-0 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(CalculatorOutlined, { className: "text-yellow-700" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4795,
                  columnNumber: 21
                }, this),
                "Summary After Adding"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4794,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4793,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "p-5", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-center p-3 bg-white rounded-lg shadow-sm", children: [
                  /* @__PURE__ */ jsxDEV(
                    Text,
                    {
                      type: "secondary",
                      className: "text-xs uppercase block font-semibold",
                      children: "Current Due Balance"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4802,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "mt-2", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-gray-800", children: "₹" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4809,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-bold text-gray-800", children: (addPenaltyDetails.currentBalance || addPenaltyDetails.balance || 0).toLocaleString("en-IN") }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4812,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4808,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4801,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-center p-3 bg-white rounded-lg shadow-sm", children: [
                  /* @__PURE__ */ jsxDEV(
                    Text,
                    {
                      type: "secondary",
                      className: "text-xs uppercase block font-semibold",
                      children: "New Penalty + Late Fee"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4822,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "mt-2", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-red-600", children: "₹" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4829,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-bold text-red-600", children: ((parseFloat(addPenaltyAmount) || 0) + (parseFloat(addLateFeeAmount) || 0)).toLocaleString("en-IN") }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4832,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4828,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4821,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-center p-4 bg-gradient-to-br from-orange-500 to-red-500 rounded-lg shadow-lg transform hover:scale-105 transition-transform duration-300", children: [
                  /* @__PURE__ */ jsxDEV(
                    Text,
                    {
                      type: "secondary",
                      className: "text-xs uppercase block font-semibold text-white/90",
                      children: "New Total Due"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4841,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "mt-2", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xl font-bold text-white", children: "₹" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4848,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-3xl font-bold text-white", children: ((addPenaltyDetails.currentBalance || addPenaltyDetails.balance || 0) + (parseFloat(addPenaltyAmount) || 0) + (parseFloat(addLateFeeAmount) || 0)).toLocaleString("en-IN") }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                      lineNumber: 4849,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4847,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4840,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4800,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4799,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4792,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Alert,
              {
                message: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, { className: "text-yellow-600 text-lg" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4868,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Important Notice" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4869,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4867,
                  columnNumber: 15
                }, this),
                description: /* @__PURE__ */ jsxDEV("div", { className: "ml-6", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "mb-1", children: "The penalty and late fee amounts will be added to the customer's account." }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4874,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-red-600 font-semibold", children: "This action cannot be undone. Please verify the amounts before proceeding." }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4878,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4873,
                  columnNumber: 15
                }, this),
                type: "warning",
                showIcon: false,
                className: "mb-6 border-l-4 border-yellow-500 bg-yellow-50"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                lineNumber: 4865,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 sticky bottom-0 bg-gray-50 pt-4 border-t border-gray-200", children: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  size: "large",
                  className: "flex-1 h-12 text-base font-semibold",
                  onClick: () => {
                    setAddPenaltyDetails(null);
                    setAddPenaltyAmount("");
                    setAddLateFeeAmount("");
                  },
                  children: "Cancel"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4891,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "primary",
                  size: "large",
                  className: `flex-1 h-12 text-base font-semibold ${addPenaltyLoading || !addPenaltyAmount && !addLateFeeAmount ? "opacity-50 cursor-not-allowed" : "bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800"}`,
                  disabled: addPenaltyLoading || !addPenaltyAmount && !addLateFeeAmount,
                  onClick: handleSavePenalty,
                  loading: addPenaltyLoading,
                  icon: /* @__PURE__ */ jsxDEV(SaveOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                    lineNumber: 4916,
                    columnNumber: 23
                  }, this),
                  children: "Add Penalty & Late Fee"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
                  lineNumber: 4902,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
              lineNumber: 4890,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
            lineNumber: 4569,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
          lineNumber: 4530,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
        lineNumber: 4517,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx",
    lineNumber: 2049,
    columnNumber: 5
  }, this);
}
_s(PenaltyManagement, "MUb6L0CXfZHqftC/1YySLnl3DO4=");
_c = PenaltyManagement;
export default PenaltyManagement;
var _c;
$RefreshReg$(_c, "PenaltyManagement");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PenaltyManagement.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOE53QixTQXE2QlosVUFyNkJZOzJCQTlOeEI7QUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBQ1ZBO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGFBQWE7QUFDcEI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxTQUFTQztBQUFBQSxFQUNUQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1A7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxlQUFlO0FBQ3RCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsT0FBT0MsaUJBQWlCQyxtQkFBbUI7QUFDcEQsT0FBT0MsWUFBWTtBQUNuQixTQUFTQyxnQkFBZ0I7QUFFekIsTUFBTSxFQUFFQyxPQUFPQyxLQUFLLElBQUluRDtBQUV4QixTQUFTb0Qsb0JBQW9CO0FBQUFDLEtBQUE7QUFDM0IsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUlsRSxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDbUUsZUFBZUMsZ0JBQWdCLElBQUlwRSxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDcUUsY0FBY0MsZUFBZSxJQUFJdEUsU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQ3VFLFdBQVdDLFlBQVksSUFBSXhFLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUN5RSxXQUFXQyxZQUFZLElBQUkxRSxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDMkUsaUJBQWlCQyxrQkFBa0IsSUFBSTVFLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUM2RSxnQkFBZ0JDLGlCQUFpQixJQUFJOUUsU0FBUyxLQUFLO0FBQzFELFFBQU0sQ0FBQytFLG9CQUFvQkMscUJBQXFCLElBQUloRixTQUFTLEtBQUs7QUFDbEUsUUFBTSxDQUFDaUYsc0JBQXNCQyx1QkFBdUIsSUFBSWxGLFNBQVMsS0FBSztBQUN0RSxRQUFNLENBQUNtRixtQkFBbUJDLG9CQUFvQixJQUFJcEYsU0FBUyxJQUFJO0FBQy9ELFFBQU0sQ0FBQ3FGLGtCQUFrQkMsbUJBQW1CLElBQUl0RixTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDdUYsa0JBQWtCQyxtQkFBbUIsSUFBSXhGLFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUN5RixtQkFBbUJDLG9CQUFvQixJQUFJMUYsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQzJGLGlCQUFpQkMsa0JBQWtCLElBQUk1RixTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDNkYsbUJBQW1CQyxvQkFBb0IsSUFBSTlGLFNBQVMsRUFBRTtBQUM3RCxRQUFNLENBQUMrRixvQkFBb0JDLHFCQUFxQixJQUFJaEcsU0FBUyxFQUFFO0FBQy9ELFFBQU0sQ0FBQ2lHLHNCQUFzQkMsdUJBQXVCLElBQUlsRyxTQUFTLEVBQUU7QUFDbkUsUUFBTSxDQUFDbUcsZ0JBQWdCQyxpQkFBaUIsSUFBSXBHLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNxRyxZQUFZQyxhQUFhLElBQUl0RyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDdUcsYUFBYUMsY0FBYyxJQUFJeEcsU0FBUztBQUFBLElBQzdDeUcsWUFBWTtBQUFBLElBQ1poRixTQUFTO0FBQUEsSUFDVGlGLE1BQU07QUFBQSxFQUNSLENBQUM7QUFDRCxRQUFNLENBQUNDLGdCQUFnQkMsaUJBQWlCLElBQUk1RyxTQUFTO0FBQUEsSUFDbkQ2RyxTQUFTO0FBQUEsSUFDVEMsV0FBVztBQUFBLElBQ1hDLFNBQVM7QUFBQSxFQUNYLENBQUM7QUFHRCxRQUFNLENBQUNDLHVCQUF1QkMsd0JBQXdCLElBQUlqSCxTQUFTLEtBQUs7QUFDeEUsUUFBTSxDQUFDa0gsZUFBZUMsZ0JBQWdCLElBQUluSCxTQUFTLElBQUk7QUFDdkQsUUFBTSxDQUFDb0gsb0JBQW9CQyxxQkFBcUIsSUFBSXJILFNBQVMsS0FBSztBQUVsRSxRQUFNLENBQUNzSCxzQkFBc0JDLHVCQUF1QixJQUFJdkgsU0FBUyxLQUFLO0FBQ3RFLFFBQU0sQ0FBQ3dILGNBQWNDLGVBQWUsSUFBSXpILFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUMwSCxnQkFBZ0JDLGlCQUFpQixJQUFJM0gsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQzRILGNBQWNDLGVBQWUsSUFBSTdILFNBQVMsTUFBTTtBQUN2RCxRQUFNLENBQUM4SCxnQkFBZ0JDLGlCQUFpQixJQUFJL0gsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQ2dJLGNBQWNDLGVBQWUsSUFBSWpJLFNBQVMsS0FBSztBQUN0RCxRQUFNLENBQUNrSSwwQkFBMEJDLDJCQUEyQixJQUMxRG5JLFNBQVMsSUFBSTtBQUVmLFFBQU0sQ0FBQ29JLDJCQUEyQkMsNEJBQTRCLElBQzVEckksU0FBUyxLQUFLO0FBQ2hCLFFBQU0sQ0FBQ3NJLG1CQUFtQkMsb0JBQW9CLElBQUl2SSxTQUFTLEVBQUU7QUFDN0QsUUFBTSxDQUFDd0ksd0JBQXdCQyx5QkFBeUIsSUFBSXpJLFNBQVMsS0FBSztBQUUxRSxRQUFNLENBQUMwSSx3QkFBd0JDLHlCQUF5QixJQUFJM0ksU0FBUyxLQUFLO0FBQzFFLFFBQU0sQ0FBQzRJLHdCQUF3QkMseUJBQXlCLElBQUk3SSxTQUFTLEVBQUU7QUFDdkUsUUFBTSxDQUFDOEksbUJBQW1CQyxvQkFBb0IsSUFBSS9JLFNBQVMsRUFBRTtBQUM3RCxRQUFNLENBQUNnSixrQkFBa0JDLG1CQUFtQixJQUFJakosU0FBUyxFQUFFO0FBQzNELFFBQU0sQ0FBQ2tKLGdCQUFnQkMsaUJBQWlCLElBQUluSixTQUFTLE1BQU07QUFDM0QsUUFBTSxDQUFDb0osa0JBQWtCQyxtQkFBbUIsSUFBSXJKLFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUNzSixnQkFBZ0JDLGlCQUFpQixJQUFJdkosU0FBUyxLQUFLO0FBQzFELFFBQU0sQ0FBQ3dKLG9CQUFvQkMscUJBQXFCLElBQUl6SixTQUFTLEtBQUs7QUFHbEUsUUFBTSxDQUFDMEosNEJBQTRCQyw2QkFBNkIsSUFBSTNKLFNBQVMsS0FBSztBQUNsRixRQUFNLENBQUM0SixvQkFBb0JDLHFCQUFxQixJQUFJN0osU0FBUyxFQUFFO0FBQy9ELFFBQU0sQ0FBQzhKLHlCQUF5QkMsMEJBQTBCLElBQUkvSixTQUFTLEtBQUs7QUFDNUUsUUFBTSxDQUFDZ0sseUJBQXlCQywwQkFBMEIsSUFBSWpLLFNBQVMsSUFBSTtBQUUzRSxRQUFNLENBQUNrSyxrQkFBa0JDLG1CQUFtQixJQUFJbkssU0FBUyxLQUFLO0FBQzlELFFBQU0sQ0FBQ29LLGdCQUFnQkMsaUJBQWlCLElBQUlySyxTQUFTLElBQUk7QUFDekQsUUFBTSxDQUFDc0ssbUJBQW1CQyxvQkFBb0IsSUFBSXZLLFNBQVMsRUFBRTtBQUM3RCxRQUFNLENBQUN3SyxtQkFBbUJDLG9CQUFvQixJQUFJekssU0FBUyxFQUFFO0FBQzdELFFBQU0sQ0FBQzBLLFlBQVlDLGFBQWEsSUFBSTNLLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUM0SyxtQkFBbUJDLG9CQUFvQixJQUFJN0ssU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQzhLLFVBQVVDLFdBQVcsSUFBSS9LLFNBQVMsSUFBSTtBQUM3QyxRQUFNLENBQUNnTCxhQUFhQyxjQUFjLElBQUlqTCxTQUFTLE1BQU07QUFDckQsUUFBTSxDQUFDa0wsYUFBYUMsY0FBYyxJQUFJbkwsU0FBUyxJQUFJO0FBRW5ELFFBQU0sQ0FBQ29MLGdCQUFnQkMsaUJBQWlCLElBQUlyTDtBQUFBQSxJQUFTO0FBQUEsTUFDbkQsRUFBRXNMLFFBQVEsSUFBSUMsUUFBUSxHQUFHO0FBQUEsSUFBQztBQUFBLEVBQzNCO0FBQ0QsUUFBTSxDQUFDQyxnQkFBZ0JDLGlCQUFpQixJQUFJekwsU0FBUyxLQUFLO0FBQzFELFFBQU0sQ0FBQzBMLGdCQUFnQkMsaUJBQWlCLElBQUkzTCxTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDNEwsT0FBT0MsUUFBUSxJQUFJN0wsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQzhMLFdBQVdDLFlBQVksSUFBSS9MLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNnTSxtQkFBbUJDLG9CQUFvQixJQUFJak0sU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQ2tNLE1BQU1DLE9BQU8sSUFBSW5NLFNBQVMsS0FBSztBQUN0QyxRQUFNLENBQUNvTSxxQkFBcUJDLHNCQUFzQixJQUFJck0sU0FBUyxFQUFFO0FBQ2pFLFFBQU0sQ0FBQ3NNLHFCQUFxQkMsc0JBQXNCLElBQUl2TSxTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDd00sZUFBZUMsZ0JBQWdCLElBQUl6TSxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDME0sVUFBVUMsV0FBVyxJQUFJM00sU0FBUztBQUFBLElBQ3ZDNE0sU0FBUztBQUFBLElBQ1RDLFNBQVM7QUFBQSxFQUNYLENBQUM7QUFDRCxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSS9NLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLFFBQU0sQ0FBQ2dOLGVBQWVDLGdCQUFnQixJQUFJak4sU0FBUyxDQUFDO0FBRXBELFFBQU1rTixnQkFBZ0JoTixPQUFPLEtBQUs7QUFHbEMsUUFBTSxDQUFDaU4sbUJBQW1CQyxvQkFBb0IsSUFBSXBOLFNBQVMsTUFBTTtBQUdqRSxRQUFNLENBQUNxTixlQUFlQyxnQkFBZ0IsSUFBSXROLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUN1TixlQUFlQyxnQkFBZ0IsSUFBSXhOLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUN5Tix3QkFBd0JDLHlCQUF5QixJQUFJMU4sU0FBUyxLQUFLO0FBRzFFLFFBQU0sQ0FBQzJOLHNCQUFzQkMsdUJBQXVCLElBQUk1TixTQUFTLEtBQUs7QUFDdEUsUUFBTSxDQUFDNk4sb0JBQW9CQyxxQkFBcUIsSUFBSTlOLFNBQVMsSUFBSTtBQUNqRSxRQUFNLENBQUMrTixnQkFBZ0JDLGlCQUFpQixJQUFJaE8sU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQ2lPLGdCQUFnQkMsaUJBQWlCLElBQUlsTyxTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDbU8sdUJBQXVCQyx3QkFBd0IsSUFBSXBPLFNBQVMsS0FBSztBQUN4RSxRQUFNLENBQUNxTyxrQkFBa0JDLG1CQUFtQixJQUFJdE8sU0FBUyxLQUFLO0FBQzlERCxZQUFVLE1BQU07QUFDZHdPLGdCQUFZO0FBQUEsRUFDZCxHQUFHLEVBQUU7QUFFTHhPLFlBQVUsTUFBTTtBQUNkLFFBQUk0RixpQkFBaUI7QUFDbkI2SSx3QkFBa0I3SSxlQUFlO0FBQUEsSUFDbkMsT0FBTztBQUNMckIsc0JBQWdCLEVBQUU7QUFDbEJGLHVCQUFpQixFQUFFO0FBQUEsSUFDckI7QUFBQSxFQUNGLEdBQUcsQ0FBQ3VCLGVBQWUsQ0FBQztBQUVwQixRQUFNOEkscUJBQXFCdE8sWUFBWSxZQUFZO0FBQ2pEdU4sOEJBQTBCLElBQUk7QUFDOUIsUUFBSTtBQUNGLFlBQU1nQixXQUFXLE1BQU12TCxJQUFJd0wsSUFBSSx5Q0FBeUM7QUFFeEUsWUFBTUMsVUFBVUMsTUFBTUMsUUFBUUosU0FBU0ssSUFBSSxJQUFJTCxTQUFTSyxPQUFRTCxTQUFTSyxNQUFNQSxRQUFRO0FBQ3ZGekIsdUJBQWlCc0IsT0FBTztBQUV4QixZQUFNSSxZQUFZSixRQUFRSyxJQUFJLENBQUNDLE1BQU1DLFNBQVM7QUFBQSxRQUM1Q0MsS0FBS0YsS0FBS0U7QUFBQUEsUUFDVkMsSUFBSUYsTUFBTTtBQUFBLFFBQ1ZHLE1BQU0zTCxPQUFPdUwsS0FBS0ssZ0JBQWdCTCxLQUFLTSxTQUFTLEVBQUVDLE9BQU8sa0JBQWtCO0FBQUEsUUFDM0VDLFNBQVNSLEtBQUtRLFNBQVNBLFdBQVdSLEtBQUtRLFNBQVNOLE9BQU87QUFBQSxRQUN2RE8sYUFBYVQsS0FBS1EsU0FBU0MsZUFBZTtBQUFBLFFBQzFDQyxlQUFlVixLQUFLckMsU0FBU2dELGFBQWE7QUFBQSxRQUMxQ0MsY0FBY1osS0FBS3JDLFNBQVNpRCxnQkFBZ0I7QUFBQSxRQUM1Q0MsZ0JBQWdCYixLQUFLYTtBQUFBQSxRQUNyQkMsY0FBY2QsS0FBS2E7QUFBQUEsUUFDbkJ4RSxRQUFRMkQsS0FBSzNELFVBQVU7QUFBQSxRQUN2QjBFLGFBQWFmO0FBQUFBO0FBQUFBLFFBRWJnQixRQUNFLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBTTtBQUFBLGNBQ0pDLE9BQU87QUFBQSxnQkFDTDtBQUFBLGtCQUNFQyxLQUFLO0FBQUEsa0JBQ0xDLE9BQ0UsdUJBQUMsU0FBTSxXQUFVLGFBQ2Y7QUFBQSwyQ0FBQyxTQUFNLFdBQVUsMkJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXdDO0FBQUEsb0JBQ3hDLHVCQUFDLFVBQUssNEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBa0I7QUFBQSx1QkFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUVGQyxTQUFTQSxNQUFNQyxzQkFBc0JyQixJQUFJO0FBQUEsZ0JBQzNDO0FBQUEsZ0JBQ0E7QUFBQSxrQkFDRWtCLEtBQUs7QUFBQSxrQkFDTEMsT0FDRSx1QkFBQyxTQUFNLFdBQVUsYUFDZjtBQUFBLDJDQUFDLGdCQUFhLFdBQVUsb0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXdDO0FBQUEsb0JBQ3hDLHVCQUFDLFVBQUssNEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBa0I7QUFBQSx1QkFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUVGQyxTQUFTQSxNQUFNRSxzQkFBc0J0QixJQUFJO0FBQUEsZ0JBQzNDO0FBQUEsZ0JBQ0E7QUFBQSxrQkFDRWtCLEtBQUs7QUFBQSxrQkFDTEMsT0FDRTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxPQUFNO0FBQUEsc0JBQ04sV0FBVyxNQUFNSSx3QkFBd0J2QixLQUFLRSxHQUFHO0FBQUEsc0JBQ2pELFFBQU87QUFBQSxzQkFDUCxZQUFXO0FBQUEsc0JBRVgsaUNBQUMsU0FBTSxXQUFVLDRCQUNmO0FBQUEsK0NBQUMsa0JBQWUsV0FBVSxrQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBd0M7QUFBQSx3QkFDeEMsdUJBQUMsVUFBSyw4QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFvQjtBQUFBLDJCQUZ0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUE7QUFBQSxvQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBVUE7QUFBQSxnQkFFSjtBQUFBLGNBQUM7QUFBQSxZQUVMO0FBQUEsWUFDQSxXQUFVO0FBQUEsWUFDVixTQUFTLENBQUMsT0FBTztBQUFBLFlBRWpCLGlDQUFDLFVBQU8sTUFBSyxRQUFPLE1BQU0sdUJBQUMsWUFBUyxXQUFVLGFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZCLEdBQUssV0FBVSx1QkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUY7QUFBQTtBQUFBLFVBNUMzRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUE2Q0EsS0E5Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStDQTtBQUFBLE1BRUosRUFBRTtBQUNGNUIsdUJBQWlCd0IsU0FBUztBQUFBLElBQzVCLFNBQVMwQixPQUFPO0FBQ2RDLGNBQVFELE1BQU0sa0NBQWtDQSxLQUFLO0FBQ3JEbEsscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWmhGLFNBQVNpUCxNQUFNaEMsVUFBVUssTUFBTXROLFdBQVc7QUFBQSxRQUMxQ2lGLE1BQU07QUFBQSxNQUNSLENBQUM7QUFDRDRHLHVCQUFpQixFQUFFO0FBQ25CRSx1QkFBaUIsRUFBRTtBQUFBLElBQ3JCLFVBQUM7QUFDQ0UsZ0NBQTBCLEtBQUs7QUFBQSxJQUNqQztBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwzTixZQUFVLE1BQU07QUFDZCxRQUFJb04sc0JBQXNCLFFBQVE7QUFDaEN5RCxxQkFBZTtBQUFBLElBQ2pCLE9BQU87QUFDTG5DLHlCQUFtQjtBQUFBLElBQ3JCO0FBQUEsRUFDRixHQUFHLENBQUN0QixtQkFBbUJ4RyxjQUFjLENBQUM7QUFFdEM1RyxZQUFVLE1BQU07QUFDZCxVQUFNOFEsb0JBQW9CLFlBQVk7QUFDcEMsVUFBSTtBQUNGLGNBQU1uQyxXQUFXLE1BQU12TCxJQUFJd0wsSUFBSSxlQUFlO0FBQzlDOUMsaUJBQVM2QyxVQUFVSyxNQUFNQSxJQUFJO0FBQUEsTUFDL0IsU0FBUzJCLE9BQU87QUFDZDdFLGlCQUFTLEVBQUU7QUFDWDhFLGdCQUFRRCxNQUFNLDhCQUE4QkEsS0FBSztBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUNBRyxzQkFBa0I7QUFBQSxFQUNwQixHQUFHLEVBQUU7QUFFTCxRQUFNQyx5QkFBeUJBLENBQUNDLFdBQVc7QUFDekMxRSwyQkFBdUIwRSxNQUFNO0FBQUEsRUFDL0I7QUFFQWhSLFlBQVUsTUFBTTtBQUNkLFVBQU1pUixZQUFZQyxXQUFXLE1BQU07QUFDakMsVUFBSSxDQUFDL0QsY0FBY2dFLFNBQVM7QUFDMUJOLHVCQUFlO0FBQUEsTUFDakI7QUFBQSxJQUNGLEdBQUcsR0FBRztBQUNOLFdBQU8sTUFBTU8sYUFBYUgsU0FBUztBQUFBLEVBQ3JDLEdBQUcsQ0FBQ3JLLGNBQWMsQ0FBQztBQUVuQixRQUFNNEgsY0FBYyxZQUFZO0FBQzlCM0osdUJBQW1CLElBQUk7QUFDdkIsUUFBSTtBQUNGLFlBQU04SixXQUFXLE1BQU12TCxJQUFJd0wsSUFBSSx3QkFBd0I7QUFDdkR6SyxnQkFBVXdLLFNBQVNLLElBQUk7QUFBQSxJQUN6QixTQUFTMkIsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDBCQUEwQkEsS0FBSztBQUM3Q2xLLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1poRixTQUFTO0FBQUEsUUFDVGlGLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNILFVBQUM7QUFDQzlCLHlCQUFtQixLQUFLO0FBQUEsSUFDMUI7QUFBQSxFQUNGO0FBRUEsUUFBTTRMLHdCQUF3QkEsQ0FBQ1ksZ0JBQWdCO0FBQzdDdEQsMEJBQXNCc0QsV0FBVztBQUNqQ3BELHNCQUFrQm9ELFlBQVlyQixjQUFjO0FBQzVDN0Isc0JBQWtCa0QsWUFBWTdGLE1BQU07QUFDcENxQyw0QkFBd0IsSUFBSTtBQUFBLEVBQzlCO0FBRUEsUUFBTTJDLHdCQUF3QixPQUFPckIsU0FBUztBQUM1QyxRQUFJO0FBQ0Z6RCx3QkFBa0IsSUFBSTtBQUN0QixZQUFNLEVBQUVzRCxLQUFLLElBQUksTUFBTTVMLElBQUl3TDtBQUFBQSxRQUN6QiwwQkFBMEJPLEtBQUtFLEdBQUc7QUFBQSxNQUNwQztBQUVBakUscUJBQWU0RCxNQUFNQSxRQUFRQSxJQUFJO0FBQ2pDVCwwQkFBb0IsSUFBSTtBQUFBLElBQzFCLFNBQVNvQyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sbUNBQW1DQSxLQUFLO0FBQ3REalAsY0FBUWlQLE1BQU0saUNBQWlDO0FBQUEsSUFDakQsVUFBQztBQUNDakYsd0JBQWtCLEtBQUs7QUFBQSxJQUN6QjtBQUFBLEVBQ0Y7QUFJQSxRQUFNNEYsMEJBQTBCLFlBQVk7QUFDMUMsUUFBSSxDQUFDdEQsa0JBQWtCdUQsV0FBV3ZELGNBQWMsS0FBSyxHQUFHO0FBQ3REdE0sY0FBUThQLFFBQVEscUNBQXFDO0FBQ3JEO0FBQUEsSUFDRjtBQUNBbkQsNkJBQXlCLElBQUk7QUFDN0IsUUFBSTtBQUNGLFlBQU1qTCxJQUFJcU8sSUFBSSx3Q0FBd0MzRCxtQkFBbUJ1QixHQUFHLElBQUk7QUFBQSxRQUM5RXFDLGVBQWVILFdBQVd2RCxjQUFjO0FBQUEsUUFDeEN4QyxRQUFRMEM7QUFBQUEsTUFDVixDQUFDO0FBQ0R4TSxjQUFRaVEsUUFBUSxtQ0FBbUM7QUFDbkQ5RCw4QkFBd0IsS0FBSztBQUM3QmEseUJBQW1CO0FBQUEsSUFDckIsU0FBU2lDLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFDbkRqUCxjQUFRaVAsTUFBTUEsTUFBTWhDLFVBQVVLLE1BQU10TixXQUFXLDBCQUEwQjtBQUFBLElBQzNFLFVBQUM7QUFDQzJNLCtCQUF5QixLQUFLO0FBQUEsSUFDaEM7QUFBQSxFQUNGO0FBRUEsUUFBTXFDLDBCQUEwQixPQUFPa0IsY0FBYztBQUNuRCxRQUFJO0FBQ0YsWUFBTXhPLElBQUl5TyxPQUFPLHdDQUF3Q0QsU0FBUyxFQUFFO0FBQ3BFbFEsY0FBUWlRLFFBQVEsbUNBQW1DO0FBQ25EakQseUJBQW1CO0FBQUEsSUFDckIsU0FBU2lDLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFDbkRqUCxjQUFRaVAsTUFBTUEsTUFBTWhDLFVBQVVLLE1BQU10TixXQUFXLDBCQUEwQjtBQUFBLElBQzNFO0FBQUEsRUFDRjtBQUVBLFFBQU1vUSx5QkFBeUJBLENBQUNDLGFBQWE7QUFDM0MzRyxtQkFBZTJHLFFBQVE7QUFDdkJ6RyxzQkFBa0IsQ0FBQyxFQUFFQyxRQUFRLElBQUlDLFFBQVEsR0FBRyxDQUFDLENBQUM7QUFDOUMrQyx3QkFBb0IsSUFBSTtBQUFBLEVBQzFCO0FBRUEsUUFBTXlELHNCQUFzQkEsTUFBTTtBQUNoQzFHLHNCQUFrQixDQUFBMkcsU0FBUSxDQUFDLEdBQUdBLE1BQU0sRUFBRTFHLFFBQVEsSUFBSUMsUUFBUSxHQUFHLENBQUMsQ0FBQztBQUFBLEVBQ2pFO0FBRUEsUUFBTTBHLHlCQUF5QkEsQ0FBQ0MsVUFBVTtBQUN4QzdHLHNCQUFrQixDQUFBMkcsU0FBUUEsS0FBS0csT0FBTyxDQUFDQyxHQUFHQyxNQUFNQSxNQUFNSCxLQUFLLENBQUM7QUFBQSxFQUM5RDtBQUVBLFFBQU1JLHNCQUFzQkEsQ0FBQ0osT0FBT0ssT0FBT0MsVUFBVTtBQUNuRG5IO0FBQUFBLE1BQWtCLENBQUEyRyxTQUNoQkEsS0FBSy9DLElBQUksQ0FBQ3dELEtBQUtKLE1BQU1BLE1BQU1ILFFBQVEsRUFBRSxHQUFHTyxLQUFLLENBQUNGLEtBQUssR0FBR0MsTUFBTSxJQUFJQyxHQUFHO0FBQUEsSUFDckU7QUFBQSxFQUNGO0FBRUEsUUFBTUMsc0JBQXNCLFlBQVk7QUFDdEMsVUFBTUMsV0FBV3ZHLG9CQUFvQndHLEtBQUssQ0FBQTFELFNBQVFBLEtBQUsyRCxXQUFXLE9BQU8sQ0FBQztBQUMxRSxVQUFNQyxTQUFTSCxVQUFVSSxNQUFNLE9BQU8sRUFBRSxDQUFDO0FBQ3pDLFVBQU1DLFVBQVU1SCxlQUFlNkgsS0FBSyxDQUFBQyxNQUFLLENBQUNBLEVBQUU1SCxVQUFVLENBQUM0SCxFQUFFM0gsT0FBTzRILEtBQUssQ0FBQztBQUN0RSxRQUFJSCxTQUFTO0FBQ1h2UixjQUFROFAsUUFBUSw2Q0FBNkM7QUFDN0Q7QUFBQSxJQUNGO0FBQ0E5RixzQkFBa0IsSUFBSTtBQUN0QixRQUFJO0FBQ0YsWUFBTTJILGFBQWFoSSxlQUFlNkQsSUFBSSxDQUFBaUUsT0FBTTtBQUFBLFFBQzFDekIsZUFBZTRCLE9BQU9ILEVBQUU1SCxNQUFNO0FBQUEsUUFDOUJDLFFBQVEySCxFQUFFM0gsT0FBTzRILEtBQUs7QUFBQSxRQUN0QkcsTUFBTTtBQUFBLE1BQ1IsRUFBRTtBQUNGLFlBQU1uUSxJQUFJb1EsS0FBSywyQkFBMkI7QUFBQSxRQUN4Q0MsUUFBUTlIO0FBQUFBLFFBQ1JvSDtBQUFBQSxRQUNBckIsZUFBZTJCLFdBQVcsQ0FBQyxFQUFFM0I7QUFBQUEsUUFDN0JsRyxRQUFRNkgsV0FBVyxDQUFDLEVBQUU3SDtBQUFBQSxNQUN4QixDQUFDO0FBQ0Q5SixjQUFRaVEsUUFBUSxvQ0FBb0M7QUFFcER2RyxxQkFBZSxJQUFJO0FBQ25CRSx3QkFBa0IsQ0FBQyxFQUFFQyxRQUFRLElBQUlDLFFBQVEsR0FBRyxDQUFDLENBQUM7QUFDOUNjLDZCQUF1QixFQUFFO0FBQ3pCVix3QkFBa0IsRUFBRTtBQUNwQnpHLDhCQUF3QixLQUFLO0FBRTdCLFVBQUlpSSxzQkFBc0IsUUFBUTtBQUNoQ3NCLDJCQUFtQjtBQUFBLE1BQ3JCO0FBQUEsSUFDRixTQUFTaUMsT0FBTztBQUNkQyxjQUFRRCxNQUFNQSxLQUFLO0FBQ25CalAsY0FBUWlQLE1BQU0sK0JBQStCO0FBQUEsSUFDL0MsVUFBQztBQUNDakYsd0JBQWtCLEtBQUs7QUFBQSxJQUN6QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0ksaUJBQWlCLE9BQU9ELFdBQVc7QUFDdkMvRyxxQkFBaUIsRUFBRTtBQUNuQkYsMkJBQXVCLEVBQUU7QUFDekJaLHNCQUFrQjZILE1BQU07QUFDeEI3RyxnQkFBWSxDQUFDK0csa0JBQWtCO0FBQUEsTUFDN0IsR0FBR0E7QUFBQUEsTUFDSDdHLFNBQVMyRztBQUFBQSxJQUNYLEVBQUU7QUFDRnpHLGNBQVUsQ0FBQzRHLGNBQWMsRUFBRSxHQUFHQSxVQUFVQyxVQUFVLEdBQUcsRUFBRTtBQUN2RHZILDJCQUF1QixFQUFFO0FBQUEsRUFFM0I7QUFFQSxRQUFNd0gsbUJBQW1CQSxDQUFDM0UsU0FBUztBQUVqQyxVQUFNNEMsV0FBV2hHLFdBQVc4RyxLQUFLLENBQUNrQixNQUFNLFFBQVFBLEVBQUUxRSxHQUFHLE9BQU9GLElBQUk7QUFDaEUsUUFBSTRDLFVBQVU7QUFHWixZQUFNaUMsZUFBZWpDLFNBQVNrQyx3QkFBd0I7QUFDdEQsWUFBTUMsYUFBYW5DLFVBQVVuQyxlQUFlO0FBQzVDLFlBQU11RSxZQUFZcEMsVUFBVXFDLGtCQUFrQjtBQUM5QyxZQUFNck4sWUFBWWdMLFVBQVVzQztBQUM1QixZQUFNck4sVUFBVStLLFVBQVV1QztBQUMxQixZQUFNQyxVQUFVeEMsVUFBVXlDLGtCQUFrQjtBQUM1QyxZQUFNQyxZQUFZMUMsU0FBU25DLGVBQWU7QUFDMUMsYUFBTztBQUFBLFFBQ0xqSixNQUFNO0FBQUEsUUFDTitOLE1BQU0zQyxTQUFTcEM7QUFBQUEsUUFDZmdGLFFBQVE7QUFBQSxRQUNSVDtBQUFBQSxRQUNBRjtBQUFBQSxRQUNBak47QUFBQUEsUUFDQUM7QUFBQUEsUUFDQW1OO0FBQUFBLFFBQ0FJO0FBQUFBLFFBQ0FLLFFBQVE7QUFBQSxRQUNSQyxjQUFjO0FBQUEsTUFDaEI7QUFBQSxJQUNGO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFFQSxRQUFNcEcsb0JBQW9CLE9BQU8zSCxZQUFZO0FBQzNDL0Isc0JBQWtCLElBQUk7QUFDdEIsUUFBSTtBQUNGLFlBQU00SixXQUFXLE1BQU12TCxJQUFJd0w7QUFBQUEsUUFDekIscUNBQXFDOUgsT0FBTztBQUFBLE1BQzlDO0FBQ0EsWUFBTWdPLG1CQUFtQm5HLFNBQVNLLEtBQUtBLFFBQVE7QUFFL0N6SyxzQkFBZ0J1USxnQkFBZ0I7QUFFaEMsWUFBTUMsbUJBQW1CRCxpQkFBaUI1RixJQUFJLENBQUMyRSxjQUFjO0FBQUEsUUFDM0RKLFFBQVFJLFNBQVNKO0FBQUFBLFFBQ2pCdUIsVUFBVW5CLFNBQVNtQjtBQUFBQSxRQUNuQkMsV0FBV3BCLFNBQVNvQjtBQUFBQSxRQUNwQk4sUUFBUWQsU0FBU2M7QUFBQUEsUUFDakI3TjtBQUFBQSxRQUNBb08sV0FBV3BQO0FBQUFBLFFBQ1h5TyxTQUFTVixTQUFTc0I7QUFBQUEsUUFDbEJDLGNBQWN2QixTQUFTdUIsZ0JBQWdCO0FBQUEsUUFDdkNDLGNBQWN4QixTQUFTd0IsZ0JBQWdCO0FBQUEsUUFDdkNDLGNBQWN6QixTQUFTeUI7QUFBQUEsTUFDekIsRUFBRTtBQUVGalIsdUJBQWlCMFEsZ0JBQWdCO0FBQUEsSUFDbkMsU0FBU3BFLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxpQ0FBaUNBLEtBQUs7QUFDcERsSyxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaaEYsU0FDRWlQLE1BQU1oQyxVQUFVSyxNQUFNdE4sV0FBVztBQUFBLFFBQ25DaUYsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNEcEMsc0JBQWdCLEVBQUU7QUFDbEJGLHVCQUFpQixFQUFFO0FBQUEsSUFDckIsVUFBQztBQUNDVSx3QkFBa0IsS0FBSztBQUFBLElBQ3pCO0FBQUEsRUFDRjtBQUVBLFFBQU04TCxpQkFBaUJ6USxZQUFZLFlBQVk7QUFDN0MsUUFBSStNLGNBQWNnRSxTQUFTO0FBQ3pCUCxjQUFRMkUsSUFBSSx3Q0FBd0M7QUFDcEQ7QUFBQSxJQUNGO0FBRUFwSSxrQkFBY2dFLFVBQVU7QUFDeEJsTSwwQkFBc0IsSUFBSTtBQUUxQixRQUFJO0FBQ0YsWUFBTXVRLFNBQVMsSUFBSUMsZ0JBQWdCO0FBQ25DLFVBQUk3TyxlQUFlRTtBQUNqQjBPLGVBQU9FLE9BQU8sV0FBVzlPLGVBQWVFLE9BQU87QUFDakQsVUFBSUYsZUFBZUc7QUFDakJ5TyxlQUFPRSxPQUFPLGFBQWE5TyxlQUFlRyxTQUFTO0FBQ3JELFVBQUlILGVBQWVJO0FBQ2pCd08sZUFBT0UsT0FBTyxXQUFXOU8sZUFBZUksT0FBTztBQUVqRCxZQUFNMkgsV0FBVyxNQUFNdkwsSUFBSXdMO0FBQUFBLFFBQ3pCLGlEQUFpRDRHLE9BQU9HLFNBQVMsQ0FBQztBQUFBLE1BQ3BFO0FBRUEsWUFBTUMsZ0JBQWdCakgsU0FBU0ssS0FBS0EsUUFBUTtBQUM1Q3ZLLG1CQUFhbVIsYUFBYTtBQUUxQixZQUFNQyxnQkFBZ0JELGNBQWMxRyxJQUFJLENBQUM0RyxTQUFTM0QsVUFBVTtBQUcxRCxjQUFNNEQsV0FBV0QsUUFBUUUsbUJBQW1CO0FBRTVDLGNBQU03QixZQUFZMkIsUUFBUUcsY0FBYztBQUN4QyxjQUFNQyxrQkFBa0JKLFFBQVFLLHFCQUFxQjtBQUNyRCxjQUFNQyxrQkFBa0JOLFFBQVFPLHNCQUFzQjtBQUV0RCxjQUFNQyxpQkFBaUJQLFdBQVdHLGtCQUFrQkU7QUFFcEQsY0FBTUcsaUJBQ0pELGlCQUFpQkosa0JBQWtCRTtBQUVyQyxjQUFNSSxpQkFBaUJBLENBQUNWLGFBQVk7QUFDbEMsY0FBSUEsU0FBUXRHLGdCQUFnQnNHLFNBQVFyRyxXQUFXO0FBQzdDLGtCQUFNZ0gsY0FBYyxJQUFJQyxLQUFLWixTQUFRdEcsWUFBWTtBQUNqRCxrQkFBTW1ILGNBQWMsSUFBSUQsS0FBS1osU0FBUXJHLFNBQVM7QUFFOUMsZ0JBQUlnSCxZQUFZRyxRQUFRLE1BQU1ELFlBQVlDLFFBQVEsR0FBRztBQUNuRCxxQkFBT2hULE9BQU9rUyxTQUFRdEcsWUFBWSxFQUFFRSxPQUFPLGtCQUFrQjtBQUFBLFlBQy9EO0FBQUEsVUFDRjtBQUNBLGlCQUFPOUwsT0FBT2tTLFNBQVFyRyxTQUFTLEVBQUVDLE9BQU8sa0JBQWtCO0FBQUEsUUFDNUQ7QUFLQSxlQUFPO0FBQUEsVUFDTEwsS0FBS3lHLFFBQVF6RztBQUFBQSxVQUNiQyxJQUFJNkMsUUFBUTtBQUFBO0FBQUE7QUFBQSxVQUdaNUMsTUFBTTNMLE9BQU9rUyxRQUFRdEcsZ0JBQWdCc0csUUFBUXJHLFNBQVMsRUFBRUMsT0FBTyxrQkFBa0I7QUFBQSxVQUNqRm1ILFlBQVlmLFFBQVFnQixVQUFVRCxjQUFjO0FBQUEsVUFDNUNoSCxlQUFlaUcsUUFBUWhKLFNBQVNnRCxhQUFhO0FBQUEsVUFDN0NDLGNBQWMrRixRQUFRaEosU0FBU2lELGdCQUFnQjtBQUFBLFVBQy9DNEUsUUFBUW1CLFFBQVFuQjtBQUFBQSxVQUNoQm9DLGFBQWFUO0FBQUFBLFVBQ2IvQixTQUNFLHVCQUFDLFVBQUssV0FBVSw2QkFBNEI7QUFBQTtBQUFBLGFBQ3ZDK0Isa0JBQWtCLEdBQUdVLGVBQWUsT0FBTztBQUFBLGVBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVGQyxpQkFBaUJYLGtCQUFrQixLQUFLLElBQUksV0FBVztBQUFBLFVBQ3ZEWSxnQkFBZ0IvQztBQUFBQSxVQUNoQjhCLFlBQ0UsdUJBQUMsVUFBSyxXQUFVLDRCQUEyQjtBQUFBO0FBQUEsYUFDdEM5QixhQUFhLEdBQUc2QyxlQUFlLE9BQU87QUFBQSxlQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFRkcsc0JBQXNCWjtBQUFBQSxVQUN0QmEsa0JBQ0UsdUJBQUMsVUFBSyxXQUFVLDBCQUF5QjtBQUFBO0FBQUEsWUFDckNiLGVBQWVTLGVBQWUsT0FBTztBQUFBLGVBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVGYixtQkFBbUIsS0FBS0QsbUJBQW1CLEdBQUdjLGVBQWUsT0FBTyxDQUFDO0FBQUEsVUFDckVYLG9CQUFvQixLQUFLRCxtQkFBbUIsR0FBR1ksZUFBZSxPQUFPLENBQUM7QUFBQSxVQUN0RUssb0JBQW9CdkIsUUFBUTlGO0FBQUFBLFVBQzVCQSxnQkFBZ0IsS0FBSzhGLFFBQVE5RixrQkFBa0IsR0FBR2dILGVBQWUsT0FBTyxDQUFDO0FBQUEsVUFDekVNLHFCQUFxQnhCLFFBQVF5QjtBQUFBQSxVQUM3QkEsaUJBQWlCLEtBQUt6QixRQUFReUIsbUJBQW1CLEdBQUdQLGVBQWUsT0FBTyxDQUFDO0FBQUEsVUFDM0VRLG1CQUNHMUIsUUFBUTlGLGtCQUFrQixNQUFNOEYsUUFBUXlCLG1CQUFtQjtBQUFBLFVBQzlEdEgsY0FBYyxNQUFNNkYsUUFBUTlGLGtCQUFrQixNQUFNOEYsUUFBUXlCLG1CQUFtQixJQUFJUCxlQUFlLE9BQU8sQ0FBQztBQUFBLFVBQzFHeEwsUUFBUXNLLFFBQVF0SyxVQUFVO0FBQUEsVUFDMUIwRSxhQUFhNEY7QUFBQUEsVUFDYjNGLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNO0FBQUEsZ0JBQ0pDLE9BQU87QUFBQSxrQkFDTDtBQUFBLG9CQUNFQyxLQUFLO0FBQUEsb0JBQ0xDLE9BQ0UsdUJBQUMsU0FBTSxXQUFVLGFBQ2Y7QUFBQSw2Q0FBQyxlQUFZLFdBQVUsbUJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXNDO0FBQUEsc0JBQ3RDLHVCQUFDLFVBQUssOEJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBb0I7QUFBQSx5QkFGdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLG9CQUVGQyxTQUFTQSxNQUFNa0gsb0JBQW9CM0IsT0FBTztBQUFBLGtCQUM1QztBQUFBLGtCQUNBO0FBQUEsb0JBQ0V6RixLQUFLO0FBQUEsb0JBQ0xDLE9BQ0UsdUJBQUMsU0FBTSxXQUFVLGFBQ2Y7QUFBQSw2Q0FBQyxnQkFBYSxXQUFVLG9CQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF3QztBQUFBLHNCQUN4Qyx1QkFBQyxVQUFLLDRCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWtCO0FBQUEseUJBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSxvQkFFRkMsU0FBU0EsTUFBTW1ILGtCQUFrQjVCLE9BQU87QUFBQSxrQkFDMUM7QUFBQSxrQkFDQTtBQUFBLG9CQUNFekYsS0FBSztBQUFBLG9CQUNMQyxPQUNFLHVCQUFDLFNBQU0sV0FBVSxhQUNmO0FBQUEsNkNBQUMsa0JBQWUsV0FBVSxxQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBMkM7QUFBQSxzQkFDM0MsdUJBQUMsVUFBSyxtQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5QjtBQUFBLHlCQUYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsb0JBRUZDLFNBQVNBLE1BQU07QUFDYm9ILDhDQUF3QjdCLE9BQU87QUFBQSxvQkFDakM7QUFBQSxrQkFDRjtBQUFBLGtCQUNBO0FBQUEsb0JBQ0V6RixLQUFLO0FBQUEsb0JBQ0xDLE9BQ0U7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsT0FBTTtBQUFBLHdCQUNOLFdBQVcsTUFBTXNILG9CQUFvQjlCLFFBQVF6RyxHQUFHO0FBQUEsd0JBQ2hELFFBQU87QUFBQSx3QkFDUCxZQUFXO0FBQUEsd0JBRVgsaUNBQUMsU0FBTSxXQUFVLDRCQUNmO0FBQUEsaURBQUMsa0JBQWUsV0FBVSxrQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBd0M7QUFBQSwwQkFDeEMsdUJBQUMsVUFBSyw4QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFvQjtBQUFBLDZCQUZ0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUdBO0FBQUE7QUFBQSxzQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBVUE7QUFBQSxrQkFFSjtBQUFBLGdCQUFDO0FBQUEsY0FFTDtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBQ1YsU0FBUyxDQUFDLE9BQU87QUFBQSxjQUVqQjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBTSx1QkFBQyxZQUFTLFdBQVUsYUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNkI7QUFBQSxrQkFDbkMsV0FBVTtBQUFBO0FBQUEsZ0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRytCO0FBQUE7QUFBQSxZQTNEakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBNkRBLEtBOURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0RBO0FBQUEsUUFFSjtBQUFBLE1BQ0YsQ0FBQztBQUVEMUssbUJBQWFrUixhQUFhO0FBQUEsSUFDNUIsU0FBU2xGLE9BQU87QUFDZEMsY0FBUUQsTUFBTSw2QkFBNkJBLEtBQUs7QUFDaEQsVUFBSUEsTUFBTWhDLFVBQVVrSixXQUFXLEtBQUs7QUFDbENwVCxxQkFBYSxFQUFFO0FBQ2ZFLHFCQUFhLEVBQUU7QUFBQSxNQUNqQixPQUFPO0FBQ0w4Qix1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaaEYsU0FBUztBQUFBLFVBQ1RpRixNQUFNO0FBQUEsUUFDUixDQUFDO0FBQ0RsQyxxQkFBYSxFQUFFO0FBQ2ZFLHFCQUFhLEVBQUU7QUFBQSxNQUNqQjtBQUFBLElBQ0YsVUFBQztBQUNDTSw0QkFBc0IsS0FBSztBQUMzQmlNLGlCQUFXLE1BQU07QUFDZi9ELHNCQUFjZ0UsVUFBVTtBQUFBLE1BQzFCLEdBQUcsR0FBRztBQUFBLElBQ1I7QUFBQSxFQUNGLEdBQUcsQ0FBQ3ZLLGNBQWMsQ0FBQztBQUVuQixRQUFNa1IsOEJBQThCLFlBQVk7QUFDOUNwTywwQkFBc0IsSUFBSTtBQUMxQixRQUFJO0FBQ0YsWUFBTSxJQUFJcU8sUUFBUSxDQUFDQyxZQUFZOUcsV0FBVzhHLFNBQVMsR0FBRyxDQUFDO0FBRXZELFlBQU1ySixXQUFXLE1BQU12TCxJQUFJd0w7QUFBQUEsUUFDekI7QUFBQSxNQUNGO0FBQ0EsWUFBTXFKLGVBQWV0SixTQUFTSyxLQUFLQSxRQUFRO0FBRTNDLFlBQU1rSixjQUFjLG9CQUFJQyxJQUFJO0FBQzVCRixtQkFBYUcsUUFBUSxDQUFDdEMsWUFBWTtBQUVoQyxjQUFNekYsTUFBTSxHQUFHeUYsUUFBUWhKLFNBQVN1QyxHQUFHLElBQUl5RyxRQUFRZ0IsVUFBVXpILEdBQUcsSUFBSXlHLFFBQVFuQixNQUFNO0FBRTlFLFlBQUksQ0FBQ3VELFlBQVlHLElBQUloSSxHQUFHLEdBQUc7QUFDekI2SCxzQkFBWUksSUFBSWpJLEtBQUs7QUFBQTtBQUFBLFlBRW5Cb0QsUUFBUXFDLFFBQVFoSixTQUFTdUM7QUFBQUEsWUFDekIyRixVQUFVYyxRQUFRaEosU0FBU2dELGFBQWE7QUFBQSxZQUN4Q21GLFdBQVdhLFFBQVFoSixTQUFTaUQsZ0JBQWdCO0FBQUE7QUFBQSxZQUU1Q2pKLFNBQVNnUCxRQUFRZ0IsVUFBVXpIO0FBQUFBLFlBQzNCNkYsV0FBV1ksUUFBUWdCLFVBQVVELGNBQWM7QUFBQTtBQUFBLFlBRTNDbEMsUUFBUW1CLFFBQVFuQjtBQUFBQSxZQUNoQlcsY0FBY1EsUUFBUXlDO0FBQUFBO0FBQUFBO0FBQUFBLFlBRXRCbkQsY0FBYztBQUFBLFlBQ2RDLGNBQWM7QUFBQSxZQUNkaUIsZ0JBQWdCUixRQUFRRSxtQkFBbUI7QUFBQSxZQUMzQ3RFLGVBQWVvRSxRQUFROUYsa0JBQWtCO0FBQUEsWUFDekN3SSxlQUFlMUMsUUFBUXlCLG1CQUFtQjtBQUFBLFVBQzVDLENBQUM7QUFBQSxRQUNIO0FBRUEsY0FBTTFELFdBQVdxRSxZQUFZdEosSUFBSXlCLEdBQUc7QUFDcEN3RCxpQkFBU3VCLGdCQUFnQlUsUUFBUTlGLGtCQUFrQjtBQUNuRDZELGlCQUFTd0IsZ0JBQWdCUyxRQUFReUIsbUJBQW1CO0FBQUEsTUFDdEQsQ0FBQztBQUVELFlBQU1rQixpQkFBaUIzSixNQUFNNEosS0FBS1IsWUFBWWxILE9BQU8sQ0FBQztBQUN0RGxJLGdDQUEwQjJQLGNBQWM7QUFBQSxJQUMxQyxTQUFTOUgsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDRDQUE0Q0EsS0FBSztBQUMvRGxLLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1poRixTQUFTO0FBQUEsUUFDVGlGLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNILFVBQUM7QUFDQytDLDRCQUFzQixLQUFLO0FBQUEsSUFDN0I7QUFBQSxFQUNGO0FBR0EsUUFBTWlQLHNCQUFzQixZQUFZO0FBQ3RDLFFBQUk1UCxrQkFBa0I2UCxXQUFXLEdBQUc7QUFDbENuUyxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaaEYsU0FBUztBQUFBLFFBQ1RpRixNQUFNO0FBQUEsTUFDUixDQUFDO0FBQ0Q7QUFBQSxJQUNGO0FBRUEsUUFBSSxDQUFDc0Msb0JBQW9Cc0ksV0FBV3RJLGdCQUFnQixLQUFLLEdBQUc7QUFDMUR4QyxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaaEYsU0FBUztBQUFBLFFBQ1RpRixNQUFNO0FBQUEsTUFDUixDQUFDO0FBQ0Q7QUFBQSxJQUNGO0FBRUE2QyxzQkFBa0IsSUFBSTtBQUN0QixRQUFJcVAsZUFBZTtBQUNuQixRQUFJQyxhQUFhO0FBQ2pCLFVBQU0vTCxVQUFTO0FBRWYsUUFBSTtBQUVGLGVBQVN1RixJQUFJLEdBQUdBLElBQUl2SixrQkFBa0I2UCxRQUFRdEcsS0FBSztBQUNqRCxjQUFNdUIsV0FBVzlLLGtCQUFrQnVKLENBQUM7QUFHcEMsWUFBSSxDQUFDdUIsU0FBU0osUUFBUTtBQUNwQjdDLGtCQUFRRCxNQUFNLGdDQUFnQ2tELFFBQVE7QUFDdERpRjtBQUNBL0wsa0JBQU9nTTtBQUFBQSxZQUNMLFlBQVlsRixTQUFTbUIsWUFBWSxTQUFTO0FBQUEsVUFDNUM7QUFDQTtBQUFBLFFBQ0Y7QUFFQSxZQUFJLENBQUNuQixTQUFTL00sU0FBUztBQUNyQjhKLGtCQUFRRCxNQUFNLGlDQUFpQ2tELFFBQVE7QUFDdkRpRjtBQUNBL0wsa0JBQU9nTSxLQUFLLEdBQUdsRixTQUFTbUIsUUFBUSxtQkFBbUI7QUFDbkQ7QUFBQSxRQUNGO0FBRUEsWUFBSSxDQUFDbkIsU0FBU3lCLGNBQWM7QUFDMUIxRSxrQkFBUUQsTUFBTSxzQ0FBc0NrRCxRQUFRO0FBQzVEaUY7QUFDQS9MLGtCQUFPZ00sS0FBSyxHQUFHbEYsU0FBU21CLFFBQVEsd0JBQXdCO0FBQ3hEO0FBQUEsUUFDRjtBQUVBLFlBQUksQ0FBQ25CLFNBQVNjLFFBQVE7QUFDcEIvRCxrQkFBUUQsTUFBTSxnQ0FBZ0NrRCxRQUFRO0FBQ3REaUY7QUFDQS9MLGtCQUFPZ00sS0FBSyxHQUFHbEYsU0FBU21CLFFBQVEsa0JBQWtCO0FBQ2xEO0FBQUEsUUFDRjtBQUVBLGNBQU1nRSxjQUFjO0FBQUEsVUFDbEJ2RixRQUFRSSxTQUFTSjtBQUFBQSxVQUNqQjNNLFNBQVMrTSxTQUFTL007QUFBQUEsVUFDbEJ3TyxjQUFjekIsU0FBU3lCO0FBQUFBLFVBQ3ZCWCxRQUFRc0UsT0FBT3BGLFNBQVNjLE1BQU07QUFBQTtBQUFBLFVBQzlCaE4sZ0JBQWdCNEosV0FBV3RJLGdCQUFnQjtBQUFBLFVBQzNDcEIsY0FBY3NCO0FBQUFBLFVBQ2RxQyxRQUNFbkMsb0JBQW9CLG1CQUFrQixvQkFBSXFOLEtBQUssR0FBRU0sZUFBZSxDQUFDO0FBQUEsUUFDckU7QUFFQSxZQUFJO0FBQ0YsZ0JBQU1ySSxXQUFXLE1BQU12TCxJQUFJb1E7QUFBQUEsWUFDekI7QUFBQSxZQUNBd0Y7QUFBQUEsVUFDRjtBQUVBLGNBQUlySyxTQUFTSyxLQUFLMkMsU0FBUztBQUN6QmtIO0FBQ0FqSSxvQkFBUTJFO0FBQUFBLGNBQ04sNkJBQTZCMUIsU0FBU21CLFFBQVEsYUFBYW5CLFNBQVNjLE1BQU07QUFBQSxZQUM1RTtBQUFBLFVBQ0YsT0FBTztBQUNMbUU7QUFDQS9MLG9CQUFPZ007QUFBQUEsY0FDTCxHQUFHbEYsU0FBU21CLFFBQVEsYUFBYW5CLFNBQVNjLE1BQU0sS0FBS2hHLFNBQVNLLEtBQUt0TixPQUFPO0FBQUEsWUFDNUU7QUFBQSxVQUNGO0FBQUEsUUFDRixTQUFTd1gsS0FBSztBQUNaSjtBQUNBLGdCQUFNSyxXQUFXRCxJQUFJdkssVUFBVUssTUFBTXROLFdBQVd3WCxJQUFJeFg7QUFDcERxTCxrQkFBT2dNO0FBQUFBLFlBQ0wsR0FBR2xGLFNBQVNtQixRQUFRLGFBQWFuQixTQUFTYyxNQUFNLEtBQUt3RSxRQUFRO0FBQUEsVUFDL0Q7QUFDQXZJLGtCQUFRRDtBQUFBQSxZQUNOLHlCQUF5QmtELFNBQVNtQixRQUFRO0FBQUEsWUFDMUNrRSxJQUFJdkssVUFBVUssUUFBUWtLO0FBQUFBLFVBQ3hCO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFHQSxVQUFJTCxlQUFlLEdBQUc7QUFDcEJwUyx1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaaEYsU0FBUyxpQ0FBaUNtWCxZQUFZLHVCQUF1QkMsVUFBVTtBQUFBLFVBQ3ZGblMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUdEaUMsa0NBQTBCLEtBQUs7QUFDL0JJLDZCQUFxQixFQUFFO0FBQ3ZCRSw0QkFBb0IsRUFBRTtBQUN0QkksNEJBQW9CLEVBQUU7QUFDdEJGLDBCQUFrQixNQUFNO0FBQ3hCTixrQ0FBMEIsRUFBRTtBQUc1QixjQUFNK0gsZUFBZTtBQUNyQixZQUFJakwsaUJBQWlCO0FBQ25CLGdCQUFNNkksa0JBQWtCN0ksZUFBZTtBQUFBLFFBQ3pDO0FBQUEsTUFDRixXQUFXa1QsYUFBYSxHQUFHO0FBQ3pCclMsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWmhGLFNBQVMsZ0JBQWdCb1gsVUFBVTtBQUFBLFVBQ25DblMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLFNBQVNnSyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sNkJBQTZCQSxLQUFLO0FBQ2hEbEsscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWmhGLFNBQ0Usc0NBQ0NpUCxNQUFNalAsV0FBVztBQUFBLFFBQ3BCaUYsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDNkMsd0JBQWtCLEtBQUs7QUFBQSxJQUN6QjtBQUFBLEVBQ0Y7QUFHQSxRQUFNaU8sc0JBQXNCLE9BQU8zQixZQUFZO0FBQzdDNU8sNkJBQXlCLElBQUk7QUFDN0JJLDBCQUFzQixJQUFJO0FBQzFCLFFBQUk7QUFDRixZQUFNcUgsV0FBVyxNQUFNdkwsSUFBSXdMO0FBQUFBLFFBQ3pCLGlDQUFpQ2tILFFBQVFoSixRQUFRdUMsR0FBRyxJQUFJeUcsUUFBUWdCLFNBQVN6SCxHQUFHLElBQUl5RyxRQUFRbkIsTUFBTTtBQUFBLE1BQ2hHO0FBQ0F2Tix1QkFBaUJ1SCxTQUFTSyxLQUFLQSxJQUFJO0FBQUEsSUFDckMsU0FBUzJCLE9BQU87QUFDZEMsY0FBUUQsTUFBTSw2QkFBNkJBLEtBQUs7QUFDaERsSyxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaaEYsU0FBUztBQUFBLFFBQ1RpRixNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSCxVQUFDO0FBQ0NXLDRCQUFzQixLQUFLO0FBQUEsSUFDN0I7QUFBQSxFQUNGO0FBRUF0SCxZQUFVLE1BQU07QUFDZGdNLGlCQUFhLEVBQUU7QUFDZixVQUFNb04sMkJBQTJCLFlBQVk7QUFDM0MsVUFBSSxDQUFDek4sZUFBZ0I7QUFDckIsVUFBSTtBQUNGLGNBQU1nRCxXQUFXLE1BQU12TCxJQUFJd0wsSUFBSSx3Q0FBd0NqRCxjQUFjLEVBQUU7QUFDdkYsWUFBSWdELFNBQVNLLE1BQU1BLE1BQU07QUFDdkJoRCx1QkFBYTJDLFNBQVNLLEtBQUtBLElBQUk7QUFBQSxRQUNqQyxPQUFPO0FBQ0xoRCx1QkFBYSxFQUFFO0FBQUEsUUFDakI7QUFBQSxNQUNGLFNBQVNrTixLQUFLO0FBQ1psTixxQkFBYSxFQUFFO0FBQ2Y0RSxnQkFBUTJFLElBQUksZ0NBQWdDMkQsR0FBRztBQUFBLE1BQ2pEO0FBQUEsSUFDRjtBQUNBRSw2QkFBeUI7QUFBQSxFQUMzQixHQUFHLENBQUN6TixjQUFjLENBQUM7QUFHbkIsUUFBTTBOLDJCQUEyQixZQUFZO0FBQzNDLFFBQUksQ0FBQ2pVLGtCQUFtQjtBQUV4QndFLGtDQUE4QixJQUFJO0FBQ2xDSSwrQkFBMkIsSUFBSTtBQUMvQkUsK0JBQTJCO0FBQUEsTUFDekI4SyxVQUFVNVAsa0JBQWtCNFA7QUFBQUEsTUFDNUJDLFdBQVc3UCxrQkFBa0I2UDtBQUFBQSxNQUM3QkMsV0FBVzlQLGtCQUFrQjhQO0FBQUFBLE1BQzdCUCxRQUFRdlAsa0JBQWtCa1U7QUFBQUEsSUFDNUIsQ0FBQztBQUVELFFBQUk7QUFDRixZQUFNM0ssV0FBVyxNQUFNdkwsSUFBSXdMO0FBQUFBLFFBQ3pCLGlDQUFpQ3hKLGtCQUFrQnFPLE1BQU0sSUFBSXJPLGtCQUFrQjBCLE9BQU8sSUFBSTFCLGtCQUFrQmtVLGNBQWM7QUFBQSxNQUM1SDtBQUNBLFlBQU1uUyxpQkFBZ0J3SCxTQUFTSyxLQUFLQTtBQUVwQyxZQUFNdUssc0JBQ0pwUyxlQUFjcVMsY0FBY3BIO0FBQUFBLFFBQzFCLENBQUNxSCxNQUFNQSxFQUFFOVMsU0FBUyxhQUFhOFMsRUFBRTlTLFNBQVM7QUFBQSxNQUM1QyxLQUFLO0FBRVAsWUFBTStTLHFCQUFxQkgsb0JBQW9CckssSUFBSSxDQUFDdUssR0FBR3RILFdBQVc7QUFBQSxRQUNoRTlDLEtBQUs4QztBQUFBQSxRQUNMMUMsV0FBV2dLLEVBQUVsSztBQUFBQSxRQUNiUyxnQkFBZ0J5SixFQUFFOVMsU0FBUyxZQUFZOFMsRUFBRUUsU0FBUyxJQUFJO0FBQUEsUUFDdERwQyxpQkFBaUJrQyxFQUFFOVMsU0FBUyxhQUFhOFMsRUFBRUUsU0FBUyxJQUFJO0FBQUEsUUFDeERuTyxRQUFRaU8sRUFBRUcsZUFBZTtBQUFBLFFBQ3pCL0IsUUFBUTtBQUFBLE1BQ1YsRUFBRTtBQUVGL04sNEJBQXNCNFAsa0JBQWtCO0FBQUEsSUFDMUMsU0FBUy9JLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxtQ0FBbUNBLEtBQUs7QUFDdERsSyxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaaEYsU0FBUztBQUFBLFFBQ1RpRixNQUFNO0FBQUEsTUFDUixDQUFDO0FBQ0RtRCw0QkFBc0IsRUFBRTtBQUFBLElBQzFCLFVBQUM7QUFDQ0UsaUNBQTJCLEtBQUs7QUFBQSxJQUNsQztBQUFBLEVBQ0Y7QUFHQSxRQUFNME4sb0JBQW9CQSxDQUFDNUIsWUFBWTtBQUNyQ3hMLHNCQUFrQndMLE9BQU87QUFDekJ0TCx5QkFBcUJzTCxRQUFROUYsY0FBYztBQUMzQ3RGLHlCQUFxQm9MLFFBQVF5QixlQUFlO0FBQzVDM00sa0JBQWNrTCxRQUFRdEssVUFBVSxFQUFFO0FBQ2xDUixnQkFBWTdILE1BQU0yUyxRQUFRckcsU0FBUyxDQUFDO0FBQ3BDckYsd0JBQW9CLElBQUk7QUFBQSxFQUMxQjtBQUdBLFFBQU15UCxzQkFBc0IsWUFBWTtBQUN0QyxRQUFJLENBQUN0UCxxQkFBcUIsQ0FBQ0UsbUJBQW1CO0FBQzVDaEUscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWmhGLFNBQVM7QUFBQSxRQUNUaUYsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNEO0FBQUEsSUFDRjtBQUVBbUUseUJBQXFCLElBQUk7QUFDekIsUUFBSTtBQUNGLFlBQU02RCxXQUFXLE1BQU12TCxJQUFJcU87QUFBQUEsUUFDekIsc0NBQXNDcEgsZUFBZWdGLEdBQUc7QUFBQSxRQUN4RDtBQUFBLFVBQ0VXLGdCQUFnQnVCLFdBQVdoSCxpQkFBaUIsS0FBSztBQUFBLFVBQ2pEZ04saUJBQWlCaEcsV0FBVzlHLGlCQUFpQixLQUFLO0FBQUEsVUFDbERlLFFBQVFiO0FBQUFBLFVBQ1I2RSxjQUFjekUsV0FBV0EsU0FBUytPLFlBQVksSUFBSTtBQUFBLFFBQ3BEO0FBQUEsTUFDRjtBQUVBLFVBQUluTCxTQUFTSyxLQUFLMkMsU0FBUztBQUN6QmxMLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1poRixTQUFTO0FBQUEsVUFDVGlGLE1BQU07QUFBQSxRQUNSLENBQUM7QUFDRHlELDRCQUFvQixLQUFLO0FBQ3pCRSwwQkFBa0IsSUFBSTtBQUN0QnVHLHVCQUFlO0FBQ2YsWUFBSWpMLGlCQUFpQjtBQUNuQjZJLDRCQUFrQjdJLGVBQWU7QUFBQSxRQUNuQztBQUFBLE1BQ0Y7QUFBQSxJQUNGLFNBQVMrSyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sMkJBQTJCQSxLQUFLO0FBQzlDbEsscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWmhGLFNBQVNpUCxNQUFNaEMsVUFBVUssTUFBTXROLFdBQVc7QUFBQSxRQUMxQ2lGLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNILFVBQUM7QUFDQ21FLDJCQUFxQixLQUFLO0FBQUEsSUFDNUI7QUFBQSxFQUNGO0FBRUEsUUFBTWlQLHdCQUF3QjdaLFFBQVEsTUFBTTtBQUMxQyxRQUFJLENBQUNpSCxlQUFlO0FBQ2xCLGFBQU87QUFBQSxJQUNUO0FBRUEsUUFDRSxDQUFDQSxjQUFjcVMsZ0JBQ2YsQ0FBQzFLLE1BQU1DLFFBQVE1SCxjQUFjcVMsWUFBWSxHQUN6QztBQUNBLGFBQU87QUFBQSxJQUNUO0FBRUEsUUFBSXJTLGNBQWNxUyxhQUFhWixXQUFXLEdBQUc7QUFDM0MsYUFBTztBQUFBLElBQ1Q7QUFFQSxRQUFJb0IsbUJBQW1CO0FBQ3ZCLFFBQUlDLGFBQWE5UyxjQUFjK1MsWUFBWTVELGtCQUFrQjtBQUU3RCxVQUFNNkQscUJBQXFCLENBQUMsR0FBR2hULGNBQWNxUyxZQUFZLEVBQUVZO0FBQUFBLE1BQ3pELENBQUNDLEdBQUd0RyxNQUFNLElBQUkyQyxLQUFLMkQsRUFBRTlLLElBQUksSUFBSSxJQUFJbUgsS0FBSzNDLEVBQUV4RSxJQUFJO0FBQUEsSUFDOUM7QUFFQSxVQUFNK0ssU0FBUztBQUVmLGVBQVduTCxRQUFRZ0wsb0JBQW9CO0FBQ3JDLFVBQUloTCxLQUFLeEksU0FBUyxXQUFXO0FBQzNCLGNBQU00VCxnQkFBZ0JwTCxLQUFLcUwsVUFBVTtBQUNyQ1IsNEJBQW9CTztBQUFBQSxNQUN0QjtBQUVBLFVBQUlwTCxLQUFLeEksU0FBUyxXQUFXO0FBQzNCLGNBQU0rSyxnQkFBZ0J2QyxLQUFLd0ssU0FBUztBQUNwQ00sc0JBQWN2STtBQUFBQSxNQUNoQjtBQUVBLFVBQUl2QyxLQUFLeEksU0FBUyxZQUFZO0FBQzVCLGNBQU02UixnQkFBZ0JySixLQUFLd0ssU0FBUztBQUNwQ00sc0JBQWN6QjtBQUFBQSxNQUNoQjtBQUVBOEIsYUFBT3ZCLEtBQUs7QUFBQSxRQUNWLEdBQUc1SjtBQUFBQSxRQUNIc0wscUJBQXFCVDtBQUFBQSxRQUNyQlUsaUJBQ0V2TCxLQUFLeEksU0FBUyxhQUFhd0ksS0FBS3hJLFNBQVMsYUFDckN3SSxLQUFLd0ssU0FBUyxJQUNkO0FBQUEsUUFDTmdCLGVBQWVDLEtBQUtDLElBQUlaLFVBQVU7QUFBQSxRQUNsQ2EsV0FBV2I7QUFBQUEsTUFDYixDQUFDO0FBQUEsSUFDSDtBQUVBLFdBQU9LO0FBQUFBLEVBQ1QsR0FBRyxDQUFDblQsYUFBYSxDQUFDO0FBRWxCLFFBQU00VCxxQkFBcUI3YSxRQUFRLE1BQU07QUFDdkMsUUFBSSxDQUFDNE8sTUFBTUMsUUFBUWxGLGtCQUFrQixFQUFHLFFBQU87QUFDL0MsV0FBT0EsbUJBQW1CbVIsT0FBTyxDQUFDQyxLQUFLOUwsU0FBUztBQUM5QyxhQUFPOEwsUUFBUTlMLEtBQUthLGtCQUFrQixNQUFNYixLQUFLb0ksbUJBQW1CO0FBQUEsSUFDdEUsR0FBRyxDQUFDO0FBQUEsRUFDTixHQUFHLENBQUMxTixrQkFBa0IsQ0FBQztBQUV2QixRQUFNcVIsZUFBZWhiLFFBQVEsTUFBTTtBQUNqQyxXQUFPZ0UsT0FBT2dMLElBQUksQ0FBQ2lNLFdBQVc7QUFBQSxNQUM1QjFJLE9BQU8wSSxNQUFNOUw7QUFBQUEsTUFDYmlCLE9BQU82SyxNQUFNdEU7QUFBQUEsSUFDZixFQUFFO0FBQUEsRUFDSixHQUFHLENBQUMzUyxNQUFNLENBQUM7QUFFWCxRQUFNa1gsd0JBQXdCO0FBQUEsSUFDNUI7QUFBQSxNQUNFQyxPQUFPO0FBQUEsTUFDUEMsV0FBVztBQUFBLE1BQ1hqTCxLQUFLO0FBQUEsTUFDTGtMLFFBQVFBLENBQUNoTSxTQUNQLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLCtCQUFDLG9CQUFpQixXQUFVLDZCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFEO0FBQUEsUUFDckQsdUJBQUMsVUFBSyxXQUFVLDZCQUNiM0wsaUJBQU8yTCxJQUFJLEVBQUVHLE9BQU8sa0JBQWtCLEtBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFFRjhMLFFBQVFBLENBQUNuQixHQUFHdEcsTUFBTSxJQUFJMkMsS0FBSzJELEVBQUU1SyxTQUFTLElBQUksSUFBSWlILEtBQUszQyxFQUFFdEUsU0FBUztBQUFBLE1BQzlEZ00sa0JBQWtCO0FBQUEsSUFDcEI7QUFBQSxJQUNBO0FBQUEsTUFDRUosT0FBTztBQUFBLE1BQ1BDLFdBQVc7QUFBQSxNQUNYakwsS0FBSztBQUFBLE1BQ0xxTCxPQUFPO0FBQUEsTUFDUEgsUUFBUUEsQ0FBQ2hRLFdBQ1AsdUJBQUMsU0FBSSxXQUFVLHVDQUNaQTtBQUFBQSxpQkFBUyxLQUNSLG1DQUNFO0FBQUEsaUNBQUMscUJBQWtCLFdBQVUsMEJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1EO0FBQUEsVUFDbkQsdUJBQUMsVUFBSyxXQUFVLDhCQUE2QjtBQUFBO0FBQUEsYUFDeENBLFVBQVUsR0FBR3lMLGVBQWUsT0FBTztBQUFBLGVBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFNBRUEsQ0FBQ3pMLFVBQVVBLFdBQVcsTUFDdEIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFdBVnJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLE1BRUZpUSxRQUFRQSxDQUFDbkIsR0FBR3RHLE9BQU9zRyxFQUFFckssa0JBQWtCLE1BQU0rRCxFQUFFL0Qsa0JBQWtCO0FBQUEsSUFDbkU7QUFBQSxJQUNBO0FBQUEsTUFDRXFMLE9BQU87QUFBQSxNQUNQQyxXQUFXO0FBQUEsTUFDWGpMLEtBQUs7QUFBQSxNQUNMcUwsT0FBTztBQUFBLE1BQ1BILFFBQVFBLENBQUNoUSxXQUNQLHVCQUFDLFNBQUksV0FBVSx1Q0FDWkE7QUFBQUEsaUJBQVMsS0FDUixtQ0FDRTtBQUFBLGlDQUFDLHFCQUFrQixXQUFVLDZCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRDtBQUFBLFVBQ3RELHVCQUFDLFVBQUssV0FBVSxpQ0FBZ0M7QUFBQTtBQUFBLGFBQzNDQSxVQUFVLEdBQUd5TCxlQUFlLE9BQU87QUFBQSxlQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxTQUVBLENBQUN6TCxVQUFVQSxXQUFXLE1BQ3RCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUM7QUFBQSxXQVZyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxNQUVGaVEsUUFBUUEsQ0FBQ25CLEdBQUd0RyxPQUFPc0csRUFBRTlDLG1CQUFtQixNQUFNeEQsRUFBRXdELG1CQUFtQjtBQUFBLElBQ3JFO0FBQUEsSUFDQTtBQUFBLE1BQ0U4RCxPQUFPO0FBQUEsTUFDUGhMLEtBQUs7QUFBQSxNQUNMcUwsT0FBTztBQUFBLE1BQ1BILFFBQVFBLENBQUNsSixHQUFHc0osV0FBVztBQUNyQixjQUFNQyxTQUNIRCxPQUFPM0wsa0JBQWtCLE1BQU0yTCxPQUFPcEUsbUJBQW1CO0FBQzVELGVBQ0UsdUJBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsaUNBQUMsc0JBQW1CLFdBQVUsNkJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVEO0FBQUEsVUFDdkQsdUJBQUMsVUFBSyxXQUFVLDZCQUE0QjtBQUFBO0FBQUEsWUFDeENxRSxNQUFNNUUsZUFBZSxPQUFPO0FBQUEsZUFEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsTUFFSjtBQUFBLE1BQ0F3RSxRQUFRQSxDQUFDbkIsR0FBR3RHLE9BQ1RzRyxFQUFFckssa0JBQWtCLE1BQ3BCcUssRUFBRTlDLG1CQUFtQixPQUNwQnhELEVBQUUvRCxrQkFBa0IsTUFBTStELEVBQUV3RCxtQkFBbUI7QUFBQSxJQUNyRDtBQUFBLElBQ0E7QUFBQSxNQUNFOEQsT0FBTztBQUFBLE1BQ1BDLFdBQVc7QUFBQSxNQUNYakwsS0FBSztBQUFBLE1BQ0xrTCxRQUFRQSxDQUFDL1AsV0FDUCx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwrQkFBQyxvQkFBaUIsV0FBVSwyQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRDtBQUFBLFFBQ25ELHVCQUFDLFVBQUssV0FBVSxpQkFDYkEsb0JBQVUsd0JBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxJQUVKO0FBQUEsSUFDQTtBQUFBLE1BQ0U2UCxPQUFPO0FBQUEsTUFDUEMsV0FBVztBQUFBLE1BQ1hqTCxLQUFLO0FBQUEsTUFDTGtMLFFBQVFBLENBQUMxRCxXQUFXO0FBQ2xCLGNBQU1nRSxlQUFlO0FBQUEsVUFDbkJDLFNBQVM7QUFBQSxZQUNQQyxPQUFPO0FBQUEsWUFDUEMsTUFBTSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQjtBQUFBLFlBQzFCQyxNQUFNO0FBQUEsVUFDUjtBQUFBLFVBQ0ExSSxNQUFNLEVBQUV3SSxPQUFPLFNBQVNDLE1BQU0sdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0IsR0FBS0MsTUFBTSxPQUFPO0FBQUEsVUFDcEVDLFdBQVc7QUFBQSxZQUNUSCxPQUFPO0FBQUEsWUFDUEMsTUFBTSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQjtBQUFBLFlBQzFCQyxNQUFNO0FBQUEsVUFDUjtBQUFBLFFBQ0Y7QUFDQSxjQUFNRSxTQUFTTixhQUFhaEUsTUFBTSxLQUFLZ0UsYUFBYUM7QUFFcEQsZUFDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FBT0ssT0FBT0o7QUFBQUEsWUFDZCxNQUFNSSxPQUFPSDtBQUFBQSxZQUNiLFdBQVU7QUFBQSxZQUVURyxpQkFBT0Y7QUFBQUE7QUFBQUEsVUFMVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNQTtBQUFBLE1BRUo7QUFBQSxNQUNBRyxTQUFTO0FBQUEsUUFDUCxFQUFFSCxNQUFNLFdBQVd4SixPQUFPLFVBQVU7QUFBQSxRQUNwQyxFQUFFd0osTUFBTSxRQUFReEosT0FBTyxPQUFPO0FBQUEsUUFDOUIsRUFBRXdKLE1BQU0sYUFBYXhKLE9BQU8sWUFBWTtBQUFBLE1BQUM7QUFBQSxNQUUzQzRKLFVBQVVBLENBQUM1SixPQUFPa0osV0FBV0EsT0FBTzlELFdBQVdwRjtBQUFBQSxJQUNqRDtBQUFBLEVBQUM7QUFHSCxRQUFNNkoscUJBQXFCO0FBQUEsSUFDekI7QUFBQSxNQUNFakIsT0FBTztBQUFBLE1BQ1BDLFdBQVc7QUFBQSxNQUNYakwsS0FBSztBQUFBLE1BQ0xrTCxRQUFRQSxDQUFDaE0sU0FBUzNMLE9BQU8yTCxJQUFJLEVBQUVHLE9BQU8sa0JBQWtCO0FBQUEsTUFDeEQ4TCxRQUFRQSxDQUFDbkIsR0FBR3RHLE1BQU0sSUFBSTJDLEtBQUsyRCxFQUFFOUssSUFBSSxJQUFJLElBQUltSCxLQUFLM0MsRUFBRXhFLElBQUk7QUFBQSxNQUNwRGtNLGtCQUFrQjtBQUFBLE1BQ2xCYyxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0E7QUFBQSxNQUNFbEIsT0FBTztBQUFBLE1BQ1BDLFdBQVc7QUFBQSxNQUNYakwsS0FBSztBQUFBLE1BQ0xrTCxRQUFRQSxDQUFDNVUsU0FDUDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsT0FDRUEsU0FBUyxZQUFZLFVBQVVBLFNBQVMsWUFBWSxRQUFRO0FBQUEsVUFHN0RBLG1CQUFTLFlBQ04sWUFDQUEsU0FBUyxZQUNQLFlBQ0E7QUFBQTtBQUFBLFFBVFI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BVUE7QUFBQSxNQUVGNFYsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNBO0FBQUEsTUFDRWxCLE9BQU87QUFBQSxNQUNQQyxXQUFXO0FBQUEsTUFDWGpMLEtBQUs7QUFBQSxJQUNQO0FBQUEsSUFDQTtBQUFBLE1BQ0VnTCxPQUFPO0FBQUEsTUFDUEMsV0FBVztBQUFBLE1BQ1hqTCxLQUFLO0FBQUEsTUFDTHFMLE9BQU87QUFBQSxNQUNQSCxRQUFRQSxDQUFDaFEsV0FBVyxLQUFLQSxVQUFVLEdBQUd5TCxlQUFlLE9BQU8sQ0FBQztBQUFBLElBQy9EO0FBQUEsSUFDQTtBQUFBLE1BQ0VxRSxPQUFPO0FBQUEsTUFDUEMsV0FBVztBQUFBLE1BQ1hqTCxLQUFLO0FBQUEsTUFDTHFMLE9BQU87QUFBQSxNQUNQSCxRQUFRQSxDQUFDaFEsV0FDUEEsU0FBUyxJQUNQLHVCQUFDLFVBQUssV0FBVSxnQ0FBK0I7QUFBQTtBQUFBLFFBQzNDQSxPQUFPeUwsZUFBZSxPQUFPO0FBQUEsV0FEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLElBRUE7QUFBQSxJQUVOO0FBQUEsSUFDQTtBQUFBLE1BQ0VxRSxPQUFPO0FBQUEsTUFDUGhMLEtBQUs7QUFBQSxNQUNMcUwsT0FBTztBQUFBLE1BQ1BILFFBQVFBLENBQUNsSixHQUFHc0osV0FBVztBQUNyQixjQUFNcFEsU0FBU29RLE9BQU9qQixtQkFBbUI7QUFDekMsZUFBT25QLFNBQVMsSUFDZCx1QkFBQyxVQUFLLFdBQVUsaUNBQWdDO0FBQUE7QUFBQSxVQUM1Q0EsT0FBT3lMLGVBQWUsT0FBTztBQUFBLGFBRGpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUVBLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUM7QUFBQSxNQUVyQztBQUFBLElBQ0Y7QUFBQSxJQUNBO0FBQUEsTUFDRXFFLE9BQU87QUFBQSxNQUNQaEwsS0FBSztBQUFBLE1BQ0xxTCxPQUFPO0FBQUEsTUFDUEgsUUFBUUEsQ0FBQ2xKLEdBQUdzSixXQUFXO0FBQ3JCLGNBQU1oQyxRQUFRZ0MsT0FBT2pCLG1CQUFtQjtBQUN4QyxZQUFJZixRQUFRLEdBQUc7QUFDYixpQkFDRSx1QkFBQyxVQUFLLFdBQVUsOEJBQTZCO0FBQUE7QUFBQSxhQUN4Q2dDLE9BQU9oQixpQkFBaUIsR0FBRzNELGVBQWUsT0FBTztBQUFBLGVBRHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxRQUVKO0FBQ0EsZUFBTyx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlDO0FBQUEsTUFDMUM7QUFBQSxJQUNGO0FBQUEsRUFBQztBQUdILFFBQU13RixrQkFBa0J0YyxRQUFRLE1BQU07QUFDcEMsUUFBSSxDQUFDMEYsZ0JBQWlCLFFBQU87QUFDN0IsVUFBTTZXLGtCQUFrQixvQkFBSXRFLElBQUk7QUFDaEMvVCxrQkFBY2dVLFFBQVEsQ0FBQ3NFLFNBQVM7QUFDOUIsVUFBSSxDQUFDRCxnQkFBZ0JwRSxJQUFJcUUsS0FBS2pKLE1BQU0sS0FBS2lKLEtBQUtuSSxVQUFVLEdBQUc7QUFDekRrSSx3QkFBZ0JuRSxJQUFJb0UsS0FBS2pKLFFBQVE7QUFBQSxVQUMvQmhCLE9BQU9pSyxLQUFLako7QUFBQUEsVUFDWm5ELE9BQU8sR0FBR29NLEtBQUsxSCxRQUFRLE1BQU0wSCxLQUFLekgsU0FBUyxZQUFZeUgsS0FBS25JLFdBQVcsR0FBR3lDLGVBQWUsT0FBTyxDQUFDO0FBQUEsVUFDakdoQyxVQUFVMEgsS0FBSzFIO0FBQUFBLFVBQ2ZDLFdBQVd5SCxLQUFLekg7QUFBQUEsVUFDaEJWLFNBQVNtSSxLQUFLbkk7QUFBQUEsUUFDaEIsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLENBQUM7QUFDRCxXQUFPekYsTUFBTTRKLEtBQUsrRCxnQkFBZ0J6TCxPQUFPLENBQUM7QUFBQSxFQUM1QyxHQUFHLENBQUM1TSxlQUFld0IsZUFBZSxDQUFDO0FBRW5DLFFBQU0rVyxnQkFBZ0J6YyxRQUFRLE1BQU07QUFDbEMsUUFBSSxDQUFDOEYsc0JBQXNCLENBQUNKLGdCQUFpQixRQUFPO0FBQ3BELFVBQU1nWCxjQUFjeFksY0FBY2dPO0FBQUFBLE1BQ2hDLENBQUNzSyxTQUFTQSxLQUFLakosV0FBV3pOLHNCQUFzQjBXLEtBQUtuSSxVQUFVO0FBQUEsSUFDakU7QUFDQSxXQUFPcUksWUFBWTFOLElBQUksQ0FBQ3lGLFlBQVk7QUFBQSxNQUNsQ2xDLE9BQU9rQyxPQUFPQTtBQUFBQSxNQUNkckUsT0FBTyxXQUFXcUUsT0FBT0EsTUFBTSxhQUFhQSxPQUFPSixXQUFXLEdBQUd5QyxlQUFlLE9BQU8sQ0FBQztBQUFBLE1BQ3hGekMsU0FBU0ksT0FBT0o7QUFBQUEsTUFDaEJhLGNBQWNULE9BQU9TO0FBQUFBLE1BQ3JCQyxjQUFjVixPQUFPVTtBQUFBQSxNQUNyQkwsVUFBVUwsT0FBT0s7QUFBQUEsTUFDakJDLFdBQVdOLE9BQU9NO0FBQUFBLE1BQ2xCQyxXQUFXUCxPQUFPTztBQUFBQSxNQUNsQnpCLFFBQVFrQixPQUFPbEI7QUFBQUEsTUFDZjZCLGNBQWNYLE9BQU9XO0FBQUFBLElBQ3ZCLEVBQUU7QUFBQSxFQUNKLEdBQUcsQ0FBQ2xSLGVBQWU0QixvQkFBb0JKLGVBQWUsQ0FBQztBQUV2RCxRQUFNaVgsb0JBQW9CQSxDQUFDcEssVUFBVTtBQUNuQzVNLHVCQUFtQjRNLFNBQVMsRUFBRTtBQUM5QnhNLDBCQUFzQixFQUFFO0FBQ3hCSSxzQkFBa0IsRUFBRTtBQUNwQkYsNEJBQXdCLEVBQUU7QUFFMUIsVUFBTTJXLGdCQUFnQjVZLE9BQU8yTyxLQUFLLENBQUNrSyxNQUFNQSxFQUFFMU4sUUFBUW9ELEtBQUs7QUFDeEQxTSx5QkFBcUIrVyxlQUFlakcsY0FBYyxFQUFFO0FBQUEsRUFDdEQ7QUFFQSxRQUFNbUcsdUJBQXVCQSxDQUFDdkssVUFBVTtBQUN0Q3hNLDBCQUFzQndNLFNBQVMsRUFBRTtBQUNqQ3BNLHNCQUFrQixFQUFFO0FBRXBCLFVBQU00VyxvQkFBbUJULGdCQUFnQjNKLEtBQUssQ0FBQ00sTUFBTUEsRUFBRVYsVUFBVUEsS0FBSztBQUN0RXRNLDRCQUF3QjhXLG1CQUFrQmpJLFlBQVksRUFBRTtBQUFBLEVBQzFEO0FBRUEsUUFBTWtJLHFCQUFxQkEsQ0FBQ3pLLFVBQVU7QUFDcENwTSxzQkFBa0JvTSxTQUFTLEVBQUU7QUFBQSxFQUMvQjtBQUVBLFFBQU0wSyw0QkFBNEIsT0FBTzFKLFFBQVEzTSxTQUFTNk4sV0FBVztBQUNuRSxRQUFJO0FBQ0YsWUFBTWhHLFdBQVcsTUFBTXZMLElBQUl3TDtBQUFBQSxRQUN6QixpQ0FBaUM2RSxNQUFNLElBQUkzTSxPQUFPLElBQUk2TixNQUFNO0FBQUEsTUFDOUQ7QUFDQSxhQUFPO0FBQUEsUUFDTFMsY0FBY3pHLFNBQVNLLEtBQUtBLEtBQUtvTyxTQUFTaEksZ0JBQWdCO0FBQUEsUUFDMURDLGNBQWMxRyxTQUFTSyxLQUFLQSxLQUFLb08sU0FBUy9ILGdCQUFnQjtBQUFBLFFBQzFEaUIsZ0JBQWdCM0gsU0FBU0ssS0FBS0EsS0FBS2tMLFlBQVk1RCxrQkFBa0I7QUFBQSxNQUNuRTtBQUFBLElBQ0YsU0FBUzNGLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxrQ0FBa0NBLEtBQUs7QUFDckQsYUFBTyxFQUFFeUUsY0FBYyxHQUFHQyxjQUFjLEdBQUdpQixnQkFBZ0IsRUFBRTtBQUFBLElBQy9EO0FBQUEsRUFDRjtBQUVBLFFBQU0rRyx5QkFBeUIsWUFBWTtBQUN6QyxVQUFNQyxxQkFBcUJYLGNBQWM5SjtBQUFBQSxNQUN2QyxDQUFDNEcsTUFBTUEsRUFBRWhILFVBQVVyTTtBQUFBQSxJQUNyQjtBQUVBLFFBQUksQ0FBQ2tYLG9CQUFvQjtBQUN2QjdXLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1poRixTQUFTO0FBQUEsUUFDVGlGLE1BQU07QUFBQSxNQUNSLENBQUM7QUFDRDtBQUFBLElBQ0Y7QUFFQSxVQUFNNFcsZ0JBQWdCLE1BQU1KO0FBQUFBLE1BQzFCblg7QUFBQUEsTUFDQUo7QUFBQUEsTUFDQVE7QUFBQUEsSUFDRjtBQUVBZix5QkFBcUI7QUFBQSxNQUNuQm9PLFFBQVF6TjtBQUFBQSxNQUNSZ1AsVUFBVTlPO0FBQUFBLE1BQ1YrTyxXQUFXcUksbUJBQW1Cckk7QUFBQUEsTUFDOUJuTyxTQUFTbEI7QUFBQUEsTUFDVHNQLFdBQVdwUDtBQUFBQSxNQUNYd1QsZ0JBQWdCbFQ7QUFBQUEsTUFDaEJtTyxTQUFTK0ksbUJBQW1CL0k7QUFBQUEsTUFDNUJhLGNBQWNtSSxjQUFjbkk7QUFBQUEsTUFDNUJDLGNBQWNrSSxjQUFjbEk7QUFBQUEsTUFDNUJpQixnQkFBZ0JpSCxjQUFjakg7QUFBQUEsTUFDOUJoQixjQUFjZ0ksbUJBQW1CaEk7QUFBQUEsSUFDbkMsQ0FBQztBQUVEblEsNEJBQXdCLEtBQUs7QUFBQSxFQUMvQjtBQUVBLFFBQU1xWSxvQkFBb0IsWUFBWTtBQUNwQyxRQUFJLENBQUNsWSxvQkFBb0IsQ0FBQ0Usa0JBQWtCO0FBQzFDaUIscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWmhGLFNBQVM7QUFBQSxRQUNUaUYsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNEO0FBQUEsSUFDRjtBQUVBaEIseUJBQXFCLElBQUk7QUFFekIsUUFBSTtBQUNGLFlBQU1nSixXQUFXLE1BQU12TCxJQUFJb1EsS0FBSyxtQ0FBbUM7QUFBQSxRQUNqRUMsUUFBUXJPLGtCQUFrQnFPO0FBQUFBLFFBQzFCM00sU0FBUzFCLGtCQUFrQjBCO0FBQUFBLFFBQzNCd08sY0FBY2xRLGtCQUFrQmtRO0FBQUFBLFFBQ2hDWCxRQUFRdlAsa0JBQWtCa1U7QUFBQUEsUUFDMUI1SCxlQUFlSCxXQUFXak0sZ0JBQWdCLEtBQUs7QUFBQSxRQUMvQ2tULGVBQWVqSCxXQUFXL0wsZ0JBQWdCLEtBQUs7QUFBQSxRQUMvQ2dHLFFBQVE7QUFBQSxNQUNWLENBQUM7QUFFRCxVQUFJbUQsU0FBU0ssS0FBSzJDLFNBQVM7QUFDekJsTCx1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaaEYsU0FBUztBQUFBLFVBQ1RpRixNQUFNO0FBQUEsUUFDUixDQUFDO0FBRUR0Qiw2QkFBcUIsSUFBSTtBQUN6QkUsNEJBQW9CLEVBQUU7QUFDdEJFLDRCQUFvQixFQUFFO0FBRXRCLGNBQU1vTCxlQUFlO0FBRXJCLFlBQ0VqTCxtQkFDQStJLFNBQVNLLEtBQUtBLE1BQU15TyxxQkFBcUJDLFFBQ3pDO0FBQ0FyWjtBQUFBQSxZQUFpQixDQUFDc1osY0FDaEJBLFVBQVV6TztBQUFBQSxjQUFJLENBQUN3TixTQUNiQSxLQUFLakosV0FBV3JPLGtCQUFrQnFPLFVBQ2hDaUosS0FBSy9ILFdBQVd2UCxrQkFBa0JrVSxpQkFDaEMsRUFBRSxHQUFHb0QsTUFBTW5JLFNBQVM1RixTQUFTSyxLQUFLQSxLQUFLeU8saUJBQWlCLElBQ3hEZjtBQUFBQSxZQUNOO0FBQUEsVUFDRjtBQUVBblk7QUFBQUEsWUFBZ0IsQ0FBQ3FaLGtCQUNmQSxjQUFjMU87QUFBQUEsY0FBSSxDQUFDMkUsYUFDakJBLFNBQVNKLFdBQVdyTyxrQkFBa0JxTyxVQUNwQ0ksU0FBU2MsV0FBV3ZQLGtCQUFrQmtVLGlCQUNwQztBQUFBLGdCQUNBLEdBQUd6RjtBQUFBQSxnQkFDSHNCLFdBQVd4RyxTQUFTSyxLQUFLQSxLQUFLeU87QUFBQUEsY0FDaEMsSUFDRTVKO0FBQUFBLFlBQ047QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0YsT0FBTztBQUNMLGNBQU0sSUFBSWdLLE1BQU1sUCxTQUFTSyxLQUFLdE4sV0FBVyx1QkFBdUI7QUFBQSxNQUNsRTtBQUFBLElBQ0YsU0FBU2lQLE9BQU87QUFDZEMsY0FBUUQsTUFBTSx5QkFBeUJBLEtBQUs7QUFDNUNsSyxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaaEYsU0FDRWlQLE9BQU9oQyxVQUFVSyxNQUFNdE4sV0FDdkJpUCxNQUFNalAsV0FDTjtBQUFBLFFBQ0ZpRixNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSCxVQUFDO0FBQ0NoQiwyQkFBcUIsS0FBSztBQUFBLElBQzVCO0FBQUEsRUFDRjtBQUVBLFFBQU1tWSw0QkFBNEIsT0FBT3JLLFFBQVEzTSxTQUFTNk4sV0FBVztBQUNuRSxRQUFJO0FBQ0YsWUFBTWhHLFdBQVcsTUFBTXZMLElBQUl3TDtBQUFBQSxRQUN6QixpQ0FBaUM2RSxNQUFNLElBQUkzTSxPQUFPLElBQUk2TixNQUFNO0FBQUEsTUFDOUQ7QUFDQSxZQUFNeE4saUJBQWdCd0gsU0FBU0ssS0FBS0E7QUFFcEMsWUFBTXVLLHNCQUNKcFMsZUFBY3FTLGNBQWNwSDtBQUFBQSxRQUMxQixDQUFDcUgsTUFBTUEsRUFBRTlTLFNBQVMsYUFBYThTLEVBQUU5UyxTQUFTO0FBQUEsTUFDNUMsS0FBSztBQUVQLGFBQU87QUFBQSxRQUNMbkMsV0FBVytVO0FBQUFBLFFBQ1huRSxjQUFjak8sZUFBY2lXLFNBQVNoSSxnQkFBZ0I7QUFBQSxRQUNyREMsY0FBY2xPLGVBQWNpVyxTQUFTL0gsZ0JBQWdCO0FBQUEsUUFDckRpQixnQkFBZ0JuUCxlQUFjK1MsWUFBWTVELGtCQUFrQjtBQUFBLFFBQzVEaEIsY0FBY25PLGVBQWMrUyxZQUFZN0s7QUFBQUEsTUFDMUM7QUFBQSxJQUNGLFNBQVNzQixPQUFPO0FBQ2RDLGNBQVFELE1BQU0sc0NBQXNDQSxLQUFLO0FBQ3pELFlBQU1BO0FBQUFBLElBQ1I7QUFBQSxFQUNGO0FBRUEsUUFBTW9OLDBCQUEwQixZQUFZO0FBQzFDLFFBQUksQ0FBQ3BXLGtCQUFrQjRKLFdBQVc1SixjQUFjLEtBQUssR0FBRztBQUN0RGxCLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1poRixTQUFTO0FBQUEsUUFDVGlGLE1BQU07QUFBQSxNQUNSLENBQUM7QUFDRDtBQUFBLElBQ0Y7QUFFQSxVQUFNcVgsZ0JBQWdCek0sV0FBVzVKLGNBQWM7QUFHL0MsUUFDRUUsaUJBQWlCLGFBQ2pCbVcsZ0JBQWdCdlcsYUFBYTJOLGNBQzdCO0FBQ0EzTyxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaaEYsU0FBUyxxREFBcUQrRixhQUFhMk4sYUFBYTRCLGVBQWUsT0FBTyxDQUFDO0FBQUEsUUFDL0dyUSxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQ0Q7QUFBQSxJQUNGO0FBRUEsUUFDRWtCLGlCQUFpQixhQUNqQm1XLGdCQUFnQnZXLGFBQWE0TixjQUM3QjtBQUNBNU8scUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWmhGLFNBQVMsc0RBQXNEK0YsYUFBYTROLGFBQWEyQixlQUFlLE9BQU8sQ0FBQztBQUFBLFFBQ2hIclEsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNEO0FBQUEsSUFDRjtBQUVBLFFBQ0VrQixpQkFBaUIsVUFDakJtVyxnQkFBZ0J2VyxhQUFhMk4sZUFBZTNOLGFBQWE0TixjQUN6RDtBQUNBNU8scUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWmhGLFNBQVMsaUVBQWlFK0YsYUFBYTJOLGVBQWUzTixhQUFhNE4sY0FBYzJCLGVBQWUsT0FBTyxDQUFDO0FBQUEsUUFDeEpyUSxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQ0Q7QUFBQSxJQUNGO0FBRUF1QixvQkFBZ0IsSUFBSTtBQUVwQixRQUFJO0FBQ0YsWUFBTXlHLFdBQVcsTUFBTXZMLElBQUlvUTtBQUFBQSxRQUN6QjtBQUFBLFFBQ0E7QUFBQSxVQUNFQyxRQUFRaE0sYUFBYWdNO0FBQUFBLFVBQ3JCM00sU0FBU1csYUFBYVg7QUFBQUEsVUFDdEJ3TyxjQUFjN04sYUFBYTZOO0FBQUFBLFVBQzNCWCxRQUFRbE4sYUFBYWtOO0FBQUFBLFVBQ3JCaE4sZ0JBQWdCcVc7QUFBQUEsVUFDaEJuVztBQUFBQSxVQUNBMkQsUUFDRXpELGtCQUNBLDBCQUF5QixvQkFBSTJPLEtBQUssR0FBRU0sZUFBZSxDQUFDO0FBQUEsUUFDeEQ7QUFBQSxNQUNGO0FBRUEsVUFBSXJJLFNBQVNLLEtBQUsyQyxTQUFTO0FBQ3pCbEwsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWmhGLFNBQVMsOEJBQThCc2MsY0FBY2hILGVBQWUsT0FBTyxDQUFDO0FBQUEsVUFDNUVyUSxNQUFNO0FBQUEsUUFDUixDQUFDO0FBR0RhLGdDQUF3QixLQUFLO0FBQzdCRSx3QkFBZ0IsSUFBSTtBQUNwQkUsMEJBQWtCLEVBQUU7QUFDcEJJLDBCQUFrQixFQUFFO0FBQ3BCRix3QkFBZ0IsTUFBTTtBQUd0QixjQUFNK0ksZUFBZTtBQUNyQixZQUFJakwsaUJBQWlCO0FBQ25CLGdCQUFNNkksa0JBQWtCN0ksZUFBZTtBQUFBLFFBQ3pDO0FBQUEsTUFDRixPQUFPO0FBQ0wsY0FBTSxJQUFJaVk7QUFBQUEsVUFDUmxQLFNBQVNLLEtBQUt0TixXQUFXO0FBQUEsUUFDM0I7QUFBQSxNQUNGO0FBQUEsSUFDRixTQUFTaVAsT0FBTztBQUNkQyxjQUFRRCxNQUFNLGdDQUFnQ0EsS0FBSztBQUNuRGxLLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1poRixTQUNFaVAsTUFBTWhDLFVBQVVLLE1BQU10TixXQUFXO0FBQUEsUUFDbkNpRixNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSCxVQUFDO0FBQ0N1QixzQkFBZ0IsS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFDRjtBQUVBLFFBQU15UCwwQkFBMEIsT0FBT2dFLFdBQVc7QUFFaEQsVUFBTXNDLGNBQWN0QyxPQUFPekwsZUFBZXlMO0FBRTFDLFFBQUksQ0FBQ3NDLGFBQWE7QUFDaEJyTixjQUFRRCxNQUFNLHVCQUF1QjtBQUNyQ2xLLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1poRixTQUFTO0FBQUEsUUFDVGlGLE1BQU07QUFBQSxNQUNSLENBQUM7QUFDRDtBQUFBLElBQ0Y7QUFFQXlCLGdDQUE0QnVULE1BQU07QUFDbENyVSwwQkFBc0IsSUFBSTtBQUUxQixRQUFJO0FBRUYsWUFBTXFILFdBQVcsTUFBTXZMLElBQUl3TDtBQUFBQSxRQUN6QixpQ0FBaUNxUCxZQUFZblIsUUFBUXVDLEdBQUcsSUFBSTRPLFlBQVluSCxTQUFTekgsR0FBRyxJQUFJNE8sWUFBWXRKLE1BQU07QUFBQSxNQUM1RztBQUVBLFlBQU14TixpQkFBZ0J3SCxTQUFTSyxLQUFLQTtBQUdwQyxZQUFNdUssc0JBQ0pwUyxlQUFjcVMsY0FBY3BIO0FBQUFBLFFBQzFCLENBQUNxSCxNQUFNQSxFQUFFOVMsU0FBUyxhQUFhOFMsRUFBRTlTLFNBQVM7QUFBQSxNQUM1QyxLQUFLO0FBRVAsWUFBTXlPLGVBQWVtRSxvQkFDbEJuSCxPQUFPLENBQUNxSCxNQUFNQSxFQUFFOVMsU0FBUyxTQUFTLEVBQ2xDcVUsT0FBTyxDQUFDQyxLQUFLeEIsTUFBTXdCLE9BQU94QixFQUFFRSxTQUFTLElBQUksQ0FBQztBQUU3QyxZQUFNdEUsZUFBZWtFLG9CQUNsQm5ILE9BQU8sQ0FBQ3FILE1BQU1BLEVBQUU5UyxTQUFTLFVBQVUsRUFDbkNxVSxPQUFPLENBQUNDLEtBQUt4QixNQUFNd0IsT0FBT3hCLEVBQUVFLFNBQVMsSUFBSSxDQUFDO0FBRTdDalMsc0JBQWdCO0FBQUEsUUFDZCtMLFFBQVF3SyxZQUFZblIsUUFBUXVDO0FBQUFBLFFBQzVCMkYsVUFBVWlKLFlBQVluUixRQUFRZ0Q7QUFBQUEsUUFDOUJtRixXQUFXZ0osWUFBWW5SLFFBQVFpRDtBQUFBQSxRQUMvQmpKLFNBQVNtWCxZQUFZbkgsU0FBU3pIO0FBQUFBLFFBQzlCNkYsV0FBVytJLFlBQVluSCxTQUFTRDtBQUFBQSxRQUNoQ2xDLFFBQVFzSixZQUFZdEo7QUFBQUEsUUFDcEJXLGNBQWMySSxZQUFZMUY7QUFBQUEsUUFDMUJuRDtBQUFBQSxRQUNBQztBQUFBQSxRQUNBaUIsZ0JBQWdCblAsZUFBYytTLFlBQVk1RCxrQkFBa0I7QUFBQSxRQUM1RDlSLFdBQVcrVTtBQUFBQSxNQUNiLENBQUM7QUFFRC9SLDhCQUF3QixJQUFJO0FBQUEsSUFDOUIsU0FBU21KLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxzQ0FBc0NBLEtBQUs7QUFDekRsSyxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaaEYsU0FDRSw2Q0FDQ2lQLE1BQU1qUCxXQUFXO0FBQUEsUUFDcEJpRixNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSCxVQUFDO0FBQ0NXLDRCQUFzQixLQUFLO0FBQUEsSUFDN0I7QUFBQSxFQUNGO0FBRUEsUUFBTTRXLHFCQUFxQixPQUFPekssUUFBUTNNLFNBQVM2TixXQUFXO0FBQzVEak0sOEJBQTBCLElBQUk7QUFDOUIsUUFBSTtBQUVGLFlBQU1pRyxXQUFXLE1BQU12TCxJQUFJd0w7QUFBQUEsUUFDekIsc0NBQXNDNkUsTUFBTSxJQUFJM00sT0FBTyxJQUFJNk4sTUFBTTtBQUFBLE1BQ25FO0FBQ0FuTSwyQkFBcUJtRyxTQUFTSyxLQUFLQSxRQUFRLEVBQUU7QUFDN0MxRyxtQ0FBNkIsSUFBSTtBQUFBLElBQ25DLFNBQVNxSSxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sa0NBQWtDQSxLQUFLO0FBQ3JEbEsscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWmhGLFNBQVM7QUFBQSxRQUNUaUYsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDK0IsZ0NBQTBCLEtBQUs7QUFBQSxJQUNqQztBQUFBLEVBQ0Y7QUFFQSxRQUFNa1Asc0JBQXNCLE9BQU9oRyxjQUFjO0FBQy9DLFFBQUk7QUFDRixZQUFNakQsV0FBVyxNQUFNdkwsSUFBSXlPO0FBQUFBLFFBQ3pCLHNDQUFzQ0QsU0FBUztBQUFBLE1BQ2pEO0FBQ0EsVUFBSWpELFNBQVNLLEtBQUsyQyxTQUFTO0FBQ3pCbEwsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWmhGLFNBQVM7QUFBQSxVQUNUaUYsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUNEa0ssdUJBQWU7QUFDZixZQUFJakwsaUJBQWlCO0FBQ25CNkksNEJBQWtCN0ksZUFBZTtBQUFBLFFBQ25DO0FBQUEsTUFDRjtBQUFBLElBQ0YsU0FBUytLLE9BQU87QUFDZEMsY0FBUUQsTUFBTSwyQkFBMkJBLEtBQUs7QUFDOUNsSyxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaaEYsU0FBUztBQUFBLFFBQ1RpRixNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNd1gseUJBQXlCQSxNQUFNO0FBQ25DaFosNEJBQXdCLEtBQUs7QUFDN0IrTCxlQUFXLE1BQU07QUFDZnJMLHlCQUFtQixFQUFFO0FBQ3JCRSwyQkFBcUIsRUFBRTtBQUN2QkUsNEJBQXNCLEVBQUU7QUFDeEJFLDhCQUF3QixFQUFFO0FBQzFCRSx3QkFBa0IsRUFBRTtBQUFBLElBQ3RCLEdBQUcsR0FBRztBQUFBLEVBQ1I7QUFHQSxRQUFNK1gsc0JBQXNCLFlBQVk7QUFDdEN4Viw4QkFBMEIsSUFBSTtBQUU5QixVQUFNa1AsNEJBQTRCO0FBQUEsRUFDcEM7QUFFQSxRQUFNdUcsY0FBYztBQUFBLElBQ2xCLEVBQUVoTyxLQUFLLE1BQU1pTyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFak8sS0FBSyxRQUFRaU8sUUFBUSxPQUFPO0FBQUEsSUFDOUIsRUFBRWpPLEtBQUssV0FBV2lPLFFBQVEsVUFBVTtBQUFBLElBQ3BDLEVBQUVqTyxLQUFLLGlCQUFpQmlPLFFBQVEsZ0JBQWdCO0FBQUEsSUFDaEQsRUFBRWpPLEtBQUssZ0JBQWdCaU8sUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRWpPLEtBQUssa0JBQWtCaU8sUUFBUSxpQkFBaUI7QUFBQSxJQUNsRCxFQUFFak8sS0FBSyxnQkFBZ0JpTyxRQUFRLFFBQVE7QUFBQSxJQUN2QyxFQUFFak8sS0FBSyxVQUFVaU8sUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRWpPLEtBQUssVUFBVWlPLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHckMsUUFBTUMsb0JBQW9CO0FBQUEsSUFDeEIsRUFBRWxPLEtBQUssTUFBTWlPLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVqTyxLQUFLLFFBQVFpTyxRQUFRLE9BQU87QUFBQSxJQUM5QixFQUFFak8sS0FBSyxXQUFXaU8sUUFBUSxVQUFVO0FBQUEsSUFDcEMsRUFBRWpPLEtBQUssaUJBQWlCaU8sUUFBUSxnQkFBZ0I7QUFBQSxJQUNoRCxFQUFFak8sS0FBSyxnQkFBZ0JpTyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFak8sS0FBSyxrQkFBa0JpTyxRQUFRLGlCQUFpQjtBQUFBLElBQ2xELEVBQUVqTyxLQUFLLGdCQUFnQmlPLFFBQVEsUUFBUTtBQUFBLElBQ3ZDLEVBQUVqTyxLQUFLLFVBQVVpTyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBRXJDLFFBQU1FLFVBQVU7QUFBQSxJQUNkLEVBQUVuTyxLQUFLLE1BQU1pTyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFak8sS0FBSyxRQUFRaU8sUUFBUSxPQUFPO0FBQUEsSUFDOUIsRUFBRWpPLEtBQUssY0FBY2lPLFFBQVEsUUFBUTtBQUFBLElBQ3JDLEVBQUVqTyxLQUFLLGlCQUFpQmlPLFFBQVEsV0FBVztBQUFBLElBQzNDLEVBQUVqTyxLQUFLLGdCQUFnQmlPLFFBQVEsUUFBUTtBQUFBLElBQ3ZDLEVBQUVqTyxLQUFLLFVBQVVpTyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFak8sS0FBSyxjQUFjaU8sUUFBUSxhQUFhO0FBQUEsSUFDMUMsRUFBRWpPLEtBQUssV0FBV2lPLFFBQVEsVUFBVTtBQUFBLElBQ3BDLEVBQUVqTyxLQUFLLGtCQUFrQmlPLFFBQVEsU0FBUztBQUFBLElBQzFDLEVBQUVqTyxLQUFLLGtCQUFrQmlPLFFBQVEsVUFBVTtBQUFBLElBQzNDLEVBQUVqTyxLQUFLLG1CQUFtQmlPLFFBQVEsV0FBVztBQUFBLElBQzdDLEVBQUVqTyxLQUFLLGdCQUFnQmlPLFFBQVEsUUFBUTtBQUFBLElBQ3ZDLEVBQUVqTyxLQUFLLG9CQUFvQmlPLFFBQVEsb0JBQW9CO0FBQUEsSUFDdkQsRUFBRWpPLEtBQUssVUFBVWlPLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVqTyxLQUFLLFVBQVVpTyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFFBQU1HLGVBQWU7QUFBQSxJQUNuQixFQUFFcE8sS0FBSyxNQUFNaU8sUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRWpPLEtBQUssUUFBUWlPLFFBQVEsT0FBTztBQUFBLElBQzlCLEVBQUVqTyxLQUFLLGNBQWNpTyxRQUFRLFFBQVE7QUFBQSxJQUNyQyxFQUFFak8sS0FBSyxpQkFBaUJpTyxRQUFRLFdBQVc7QUFBQSxJQUMzQyxFQUFFak8sS0FBSyxnQkFBZ0JpTyxRQUFRLFFBQVE7QUFBQSxJQUN2QyxFQUFFak8sS0FBSyxVQUFVaU8sUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRWpPLEtBQUssa0JBQWtCaU8sUUFBUSxhQUFhO0FBQUEsSUFDOUMsRUFBRWpPLEtBQUssZUFBZWlPLFFBQVEsVUFBVTtBQUFBLElBQ3hDLEVBQUVqTyxLQUFLLGtCQUFrQmlPLFFBQVEsU0FBUztBQUFBLElBQzFDLEVBQUVqTyxLQUFLLHNCQUFzQmlPLFFBQVEsVUFBVTtBQUFBLElBQy9DLEVBQUVqTyxLQUFLLHVCQUF1QmlPLFFBQVEsV0FBVztBQUFBLElBQ2pELEVBQUVqTyxLQUFLLG9CQUFvQmlPLFFBQVEsUUFBUTtBQUFBLElBQzNDLEVBQUVqTyxLQUFLLHdCQUF3QmlPLFFBQVEsb0JBQW9CO0FBQUEsSUFDM0QsRUFBRWpPLEtBQUssVUFBVWlPLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVqTyxLQUFLLFVBQVVpTyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFFBQU1JLGtCQUFrQkEsQ0FBQzFQLE1BQU0yUCxXQUFXO0FBQ3hDLFFBQUksQ0FBQ0EsT0FBUSxRQUFPM1A7QUFDcEIsV0FBT0EsS0FBS29EO0FBQUFBLE1BQ1YsQ0FBQ2pELFNBQ0NBLEtBQUtVLGVBQWUrTyxZQUFZLEVBQUVDLFNBQVNGLE9BQU9DLFlBQVksQ0FBQyxLQUMvRHpQLEtBQUswSCxZQUFZK0gsWUFBWSxFQUFFQyxTQUFTRixPQUFPQyxZQUFZLENBQUMsS0FDNUR6UCxLQUFLd0YsUUFBUWlLLFlBQVksRUFBRUMsU0FBU0YsT0FBT0MsWUFBWSxDQUFDLEtBQ3hEelAsS0FBS1ksY0FBYzZPLFlBQVksRUFBRUMsU0FBU0YsT0FBT0MsWUFBWSxDQUFDO0FBQUEsSUFDbEU7QUFBQSxFQUNGO0FBRUEsUUFBTUUsY0FBYzVlLFFBQVEsTUFBTTtBQUNoQyxVQUFNa1YsZUFBZTVRLFVBQVV3VztBQUFBQSxNQUM3QixDQUFDQyxLQUFLOEQsTUFBTTlELE9BQU84RCxFQUFFL08sa0JBQWtCO0FBQUEsTUFDdkM7QUFBQSxJQUNGO0FBQ0EsVUFBTXFGLGVBQWU3USxVQUFVd1c7QUFBQUEsTUFDN0IsQ0FBQ0MsS0FBSzhELE1BQU05RCxPQUFPOEQsRUFBRXhILG1CQUFtQjtBQUFBLE1BQ3hDO0FBQUEsSUFDRjtBQUNBLFVBQU15SCxpQkFBaUJ4YSxVQUFVb1U7QUFFakMsUUFBSTdDLFdBQVc7QUFDZixRQUFJa0osY0FBYztBQUNsQixRQUFJQyxXQUFXO0FBQ2YsUUFBSUMsY0FBYztBQUVsQjNhLGNBQVU0VCxRQUFRLENBQUN0QyxZQUFZO0FBQzdCLFlBQU12QixVQUFVdUIsUUFBUUUsbUJBQW1CO0FBQzNDLFVBQUl6QixVQUFVLEdBQUc7QUFDZndCLG9CQUFZeEI7QUFDWjJLO0FBQUFBLE1BQ0YsV0FBVzNLLFVBQVUsR0FBRztBQUN0QjBLLHVCQUFlckUsS0FBS0MsSUFBSXRHLE9BQU87QUFDL0I0SztBQUFBQSxNQUNGO0FBQUEsSUFDRixDQUFDO0FBRUQsV0FBTztBQUFBLE1BQ0wvSjtBQUFBQSxNQUNBQztBQUFBQSxNQUNBMko7QUFBQUEsTUFDQWpKO0FBQUFBLE1BQ0FrSjtBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxJQUNGO0FBQUEsRUFDRixHQUFHLENBQUMzYSxTQUFTLENBQUM7QUFFZCxRQUFNNGEsa0JBQWtCbGYsUUFBUSxNQUFNO0FBQ3BDLFVBQU04ZSxpQkFBaUJ4UixjQUFjb0w7QUFDckMsVUFBTW1DLHNCQUFxQnZOLGNBQWN3TixPQUFPLENBQUNDLEtBQUs5TCxTQUFTOEwsT0FBTzlMLEtBQUthLGtCQUFrQixJQUFJLENBQUM7QUFFbEcsVUFBTXlNLGtCQUFrQixJQUFJNEMsSUFBSTdSLGNBQWMwQixJQUFJLENBQUFDLFNBQVFBLEtBQUtVLGFBQWEsQ0FBQyxFQUFFeVA7QUFDL0UsV0FBTztBQUFBLE1BQ0xOO0FBQUFBLE1BQ0FqRTtBQUFBQSxNQUNBMEI7QUFBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxDQUFDalAsYUFBYSxDQUFDO0FBR2xCLFFBQU0rUixvQkFBb0I7QUFBQSxJQUN4QjtBQUFBLE1BQ0VsRSxPQUNFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxVQUFVLENBQUNtRSxNQUFNO0FBQ2YsZ0JBQUlBLEVBQUVDLE9BQU9DLFNBQVM7QUFDcEIxVyxtQ0FBcUJILHNCQUFzQjtBQUFBLFlBQzdDLE9BQU87QUFDTEcsbUNBQXFCLEVBQUU7QUFBQSxZQUN6QjtBQUFBLFVBQ0Y7QUFBQTtBQUFBLFFBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0k7QUFBQSxNQUdOc1MsV0FBVztBQUFBLE1BQ1hqTCxLQUFLO0FBQUEsTUFDTGtNLE9BQU87QUFBQSxNQUNQaEIsUUFBUUEsQ0FBQ2xKLEdBQUdzSixXQUNWO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTNVMsa0JBQWtCbUssS0FBSyxDQUFDQyxNQUFNQSxFQUFFTSxXQUFXa0ksT0FBT2xJLE1BQU07QUFBQSxVQUNqRSxVQUFVLENBQUMrTCxNQUFNO0FBQ2YsZ0JBQUlBLEVBQUVDLE9BQU9DLFNBQVM7QUFDcEIxVyxtQ0FBcUIsQ0FBQyxHQUFHRCxtQkFBbUI0UyxNQUFNLENBQUM7QUFBQSxZQUNyRCxPQUFPO0FBQ0wzUztBQUFBQSxnQkFDRUQsa0JBQWtCcUosT0FBTyxDQUFDZSxNQUFNQSxFQUFFTSxXQUFXa0ksT0FBT2xJLE1BQU07QUFBQSxjQUM1RDtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBQUE7QUFBQSxRQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVVJO0FBQUEsSUFHUjtBQUFBLElBQ0E7QUFBQSxNQUNFNEgsT0FBTztBQUFBLE1BQ1BDLFdBQVc7QUFBQSxNQUNYakwsS0FBSztBQUFBLE1BQ0xtTCxRQUFRQSxDQUFDbkIsR0FBR3RHLE1BQU1zRyxFQUFFckYsU0FBUzJLLGNBQWM1TCxFQUFFaUIsUUFBUTtBQUFBLElBQ3ZEO0FBQUEsSUFDQTtBQUFBLE1BQ0VxRyxPQUFPO0FBQUEsTUFDUEMsV0FBVztBQUFBLE1BQ1hqTCxLQUFLO0FBQUEsSUFDUDtBQUFBLElBQ0E7QUFBQSxNQUNFZ0wsT0FBTztBQUFBLE1BQ1BDLFdBQVc7QUFBQSxNQUNYakwsS0FBSztBQUFBLE1BQ0xxTCxPQUFPO0FBQUEsTUFDUEgsUUFBUUEsQ0FBQ2hRLFdBQ1AsdUJBQUMsVUFBSyxXQUFVLDhCQUE2QjtBQUFBO0FBQUEsUUFDekNBLE9BQU95TCxlQUFlLE9BQU87QUFBQSxXQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVGd0UsUUFBUUEsQ0FBQ25CLEdBQUd0RyxNQUFNc0csRUFBRWpGLGVBQWVyQixFQUFFcUI7QUFBQUEsSUFDdkM7QUFBQSxJQUNBO0FBQUEsTUFDRWlHLE9BQU87QUFBQSxNQUNQQyxXQUFXO0FBQUEsTUFDWGpMLEtBQUs7QUFBQSxNQUNMcUwsT0FBTztBQUFBLE1BQ1BILFFBQVFBLENBQUNoUSxXQUNQLHVCQUFDLFVBQUssV0FBVSxpQ0FBZ0M7QUFBQTtBQUFBLFFBQzVDQSxPQUFPeUwsZUFBZSxPQUFPO0FBQUEsV0FEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFRndFLFFBQVFBLENBQUNuQixHQUFHdEcsTUFBTXNHLEVBQUVoRixlQUFldEIsRUFBRXNCO0FBQUFBLElBQ3ZDO0FBQUEsSUFDQTtBQUFBLE1BQ0VnRyxPQUFPO0FBQUEsTUFDUEMsV0FBVztBQUFBLE1BQ1hqTCxLQUFLO0FBQUEsTUFDTHFMLE9BQU87QUFBQSxNQUNQSCxRQUFRQSxDQUFDaFEsV0FDUCx1QkFBQyxVQUFLLFdBQVUsNkJBQTRCO0FBQUE7QUFBQSxRQUN4Q0EsT0FBT3lMLGVBQWUsT0FBTztBQUFBLFdBRGpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUZ3RSxRQUFRQSxDQUFDbkIsR0FBR3RHLE1BQU1zRyxFQUFFdEUsV0FBV2hDLEVBQUVnQztBQUFBQSxJQUNuQztBQUFBLElBQ0E7QUFBQSxNQUNFc0YsT0FBTztBQUFBLE1BQ1BDLFdBQVc7QUFBQSxNQUNYakwsS0FBSztBQUFBLE1BQ0xxTCxPQUFPO0FBQUEsTUFDUEgsUUFBUUEsQ0FBQ3FFLFlBQVlBLFFBQVFoSDtBQUFBQSxJQUMvQjtBQUFBLEVBQUM7QUFHSCxRQUFNcUUsbUJBQW1CcFIsTUFBTWdIO0FBQUFBLElBQzdCLENBQUM2SixTQUFTQSxLQUFLck4sUUFBUTFEO0FBQUFBLEVBQ3pCO0FBQ0EsUUFBTWtVLGFBQWFBLENBQUM3WSxZQUFZO0FBQzlCLFFBQUksQ0FBQ0EsUUFBUyxRQUFPO0FBRXJCLFVBQU04WSxNQUFNLElBQUlwSixLQUFLMVAsT0FBTztBQUM1QixVQUFNK1ksUUFBUSxvQkFBSXJKLEtBQUs7QUFHdkJvSixRQUFJRSxTQUFTLEdBQUcsR0FBRyxHQUFHLENBQUM7QUFDdkJELFVBQU1DLFNBQVMsR0FBRyxHQUFHLEdBQUcsQ0FBQztBQUV6QixVQUFNQyxXQUFXRixRQUFRRDtBQUN6QixVQUFNSSxXQUFXdEYsS0FBS3VGLE1BQU1GLFlBQVksTUFBTyxLQUFLLEtBQUssR0FBRztBQUU1RCxRQUFJQyxXQUFXLEdBQUc7QUFDaEIsYUFBTztBQUFBLFFBQ0xySSxRQUFRO0FBQUEsUUFDUm9FLE1BQU0sR0FBR2lFLFFBQVE7QUFBQSxNQUNuQjtBQUFBLElBQ0Y7QUFFQSxRQUFJQSxXQUFXLEdBQUc7QUFDaEIsYUFBTztBQUFBLFFBQ0xySSxRQUFRO0FBQUEsUUFDUm9FLE1BQU0sR0FBR3JCLEtBQUtDLElBQUlxRixRQUFRLENBQUM7QUFBQSxNQUM3QjtBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsTUFDTHJJLFFBQVE7QUFBQSxNQUNSb0UsTUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsaUVBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTXpWLFlBQVlHO0FBQUFBLFFBQ2xCLFdBQVdILFlBQVlFO0FBQUFBLFFBQ3ZCLFNBQVNGLFlBQVk5RTtBQUFBQSxRQUNyQixTQUFTLE1BQ1ArRSxlQUFlLENBQUN3TCxVQUFVLEVBQUUsR0FBR0EsTUFBTXZMLFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxNQUw3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNRztBQUFBLElBR0gsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSw2QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BQ1I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLDZCQUE2QixDQUFDOFksTUFBTWpaLGNBQWNpWixFQUFFQyxPQUFPaE4sS0FBSztBQUFBLFVBQ2hFLFlBQVk7QUFBQTtBQUFBLFFBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRW1CO0FBQUEsTUFHbkIsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSx5Q0FBd0Msa0NBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQU1yRixzQkFBc0IsU0FBUyxZQUFZO0FBQUEsa0JBQ2pELFNBQVMsTUFBTUMscUJBQXFCLE1BQU07QUFBQSxrQkFDMUMsTUFBSztBQUFBLGtCQUFPO0FBQUE7QUFBQSxnQkFIZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBTUQsc0JBQXNCLFNBQVMsWUFBWTtBQUFBLGtCQUNqRCxTQUFTLE1BQU1DLHFCQUFxQixNQUFNO0FBQUEsa0JBQzFDLE1BQUs7QUFBQSxrQkFBTztBQUFBO0FBQUEsZ0JBSGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUE7QUFBQSxpQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsaUJBQWdCLG9IQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3QkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBTSx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFhO0FBQUEsZ0JBQ25CLFNBQVMrUTtBQUFBQSxnQkFDVCxVQUFVaFIsc0JBQXNCO0FBQUEsZ0JBQ2hDLE9BQU8sRUFBRWdULGlCQUFpQixXQUFXQyxhQUFhLFVBQVU7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FMaEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQU0sdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUI7QUFBQSxnQkFDekIsU0FBUyxNQUFNbGIsd0JBQXdCLElBQUk7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FIL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxlQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQTtBQUFBLGFBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0Q0E7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSx1Q0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSx5QkFBd0IsOEJBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9EO0FBQUEsWUFDcEQsdUJBQUMsVUFBTyxNQUFNLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWUsR0FBSyxTQUFTMEwsZ0JBQWdCLHVCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUseUNBRWI7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUNkekQsZ0NBQXNCLFNBQVMsVUFBVSxjQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQSxPQUFPeEcsZUFBZUUsV0FBVzRXO0FBQUFBLGtCQUNqQyxVQUFVLENBQUNqTCxVQUNUNUwsa0JBQWtCLENBQUNvTCxVQUFVO0FBQUEsb0JBQzNCLEdBQUdBO0FBQUFBLG9CQUNIbkwsU0FBUzJMLFNBQVM7QUFBQSxrQkFDcEIsRUFBRTtBQUFBLGtCQUVKLGNBQWMsQ0FBQzZOLE9BQU9DLFdBQ3BCQSxRQUFRQyxVQUNKN0ssU0FBUyxFQUNWaUosWUFBWSxFQUNaQyxTQUFTeUIsTUFBTTFCLFlBQVksQ0FBQztBQUFBLGtCQUVqQyxNQUFLO0FBQUEsa0JBRUoxYSxpQkFBT2dMO0FBQUFBLG9CQUFJLENBQUNpTSxVQUNYLHVCQUFDLE9BQU8sUUFBUCxFQUE4QixPQUFPQSxNQUFNOUwsS0FDekM4TCxnQkFBTXRFLGNBRFdzRSxNQUFNOUwsS0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkF4Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBeUJBO0FBQUEsaUJBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOEJBO0FBQUEsWUFHQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQywwQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPekksZUFBZUc7QUFBQUEsa0JBQ3RCLFVBQVUsQ0FBQ3lZLE1BQ1QzWSxrQkFBa0IsQ0FBQ29MLFVBQVU7QUFBQSxvQkFDM0IsR0FBR0E7QUFBQUEsb0JBQ0hsTCxXQUFXeVksRUFBRUMsT0FBT2hOO0FBQUFBLGtCQUN0QixFQUFFO0FBQUE7QUFBQSxnQkFSTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FTRztBQUFBLGlCQWJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxZQUdBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHdCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU83TCxlQUFlSTtBQUFBQSxrQkFDdEIsVUFBVSxDQUFDd1ksTUFDVDNZLGtCQUFrQixDQUFDb0wsVUFBVTtBQUFBLG9CQUMzQixHQUFHQTtBQUFBQSxvQkFDSGpMLFNBQVN3WSxFQUFFQyxPQUFPaE47QUFBQUEsa0JBQ3BCLEVBQUU7QUFBQTtBQUFBLGdCQVJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVNHO0FBQUEsaUJBYkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFlQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMsTUFDUDVMLGtCQUFrQjtBQUFBLGtCQUNoQkMsU0FBUztBQUFBLGtCQUNUQyxXQUFXO0FBQUEsa0JBQ1hDLFNBQVM7QUFBQSxnQkFDWCxDQUFDO0FBQUEsZ0JBQ0Y7QUFBQTtBQUFBLGNBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBV0EsS0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWFBO0FBQUEsZUFwRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxRkE7QUFBQSxhQTdGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOEZBO0FBQUEsUUFHQ29HLHNCQUFzQixVQUNyQix1QkFBQyxTQUFJLFdBQVUsdUNBQ2IsaUNBQUMsU0FBSSxXQUFVLHlDQUViO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDZEQUNiLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsaURBQWdELCtCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0RTtBQUFBLGNBQzVFLHVCQUFDLE9BQUUsV0FBVSxvQ0FBb0MwUixzQkFBWUUsa0JBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRFO0FBQUEsaUJBRjlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxnQ0FDYixpQ0FBQyxzQkFBbUIsV0FBVSwyQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUQsS0FEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSwrREFDYixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsT0FBRSxXQUFVLGlEQUFnRCxnQ0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkU7QUFBQSxjQUM3RSx1QkFBQyxPQUFFLFdBQVUsc0NBQXFDO0FBQUE7QUFBQSxnQkFBRUYsWUFBWS9JLFNBQVNpQixlQUFlLE9BQU87QUFBQSxtQkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUc7QUFBQSxjQUNoRzhILFlBQVlJLFdBQVcsS0FDdEIsdUJBQUMsT0FBRSxXQUFVLDhCQUE4Qko7QUFBQUEsNEJBQVlJO0FBQUFBLGdCQUFTO0FBQUEsbUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1GO0FBQUEsaUJBSnZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxrQ0FDYixpQ0FBQyxzQkFBbUIsV0FBVSw2QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUQsS0FEekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQSxLQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSw0REFDYixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsT0FBRSxXQUFVLGlEQUFnRCxvQ0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUY7QUFBQSxjQUNqRix1QkFBQyxPQUFFLFdBQVUsbUNBQWtDO0FBQUE7QUFBQSxnQkFBRUosWUFBWTFKLGFBQWE0QixlQUFlLE9BQU87QUFBQSxtQkFBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0c7QUFBQSxpQkFGcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLCtCQUNiLGlDQUFDLHNCQUFtQixXQUFVLDBCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRCxLQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLCtEQUNiLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsaURBQWdELDhCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyRTtBQUFBLGNBQzNFLHVCQUFDLE9BQUUsV0FBVSxzQ0FBcUM7QUFBQTtBQUFBLGdCQUFFOEgsWUFBWXpKLGFBQWEyQixlQUFlLE9BQU87QUFBQSxtQkFBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUc7QUFBQSxpQkFGdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGtDQUNiLGlDQUFDLHNCQUFtQixXQUFVLDZCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RCxLQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLGFBbkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvREEsS0FyREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNEQTtBQUFBLFFBR0Q1SixzQkFBc0IsVUFDckIsdUJBQUMsU0FBSSxXQUFVLHVDQUNiLGlDQUFDLFNBQUksV0FBVSx5Q0FFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSw2REFDYixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsT0FBRSxXQUFVLGlEQUFnRCxvQ0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUY7QUFBQSxjQUNqRix1QkFBQyxPQUFFLFdBQVUsb0NBQW9DZ1MsMEJBQWdCSixrQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0Y7QUFBQSxpQkFGbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGdDQUNiLGlDQUFDLHNCQUFtQixXQUFVLDJCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRCxLQUR2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLDREQUNiLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsaURBQWdELG9DQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRjtBQUFBLGNBQ2pGLHVCQUFDLE9BQUUsV0FBVSxtQ0FBa0M7QUFBQTtBQUFBLGdCQUFFSSxnQkFBZ0JyRSxtQkFBbUIvRCxlQUFlLE9BQU87QUFBQSxtQkFBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEc7QUFBQSxpQkFGOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLCtCQUNiLGlDQUFDLHNCQUFtQixXQUFVLDBCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRCxLQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLCtEQUNiLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsaURBQWdELGdDQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2RTtBQUFBLGNBQzdFLHVCQUFDLE9BQUUsV0FBVSxvQ0FBb0NvSSwwQkFBZ0IzQyxtQkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUY7QUFBQSxpQkFGbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGtDQUNiLGlDQUFDLGdCQUFhLFdBQVUsNkJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlELEtBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsYUFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFDQSxLQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUNBO0FBQUEsUUFJRix1QkFBQyxTQUFJLFdBQVUsOEJBQ1pyUCxnQ0FBc0IsU0FDckJwSSxxQkFDRSx1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsK0VBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkY7QUFBQSxVQUMzRix1QkFBQyxPQUFFLFdBQVUsc0JBQXFCLHlDQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRDtBQUFBLGFBRjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQSxJQUNFTixVQUFVa1UsU0FBUyxJQUNyQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBTThGLGdCQUFnQmhhLFdBQVc0QixVQUFVO0FBQUEsWUFDM0M7QUFBQSxZQUNBLFlBQVltWTtBQUFBQSxZQUNaLGtCQUFrQixrQkFBa0I3YSxPQUFPLEVBQUU4TCxPQUFPLFlBQVksQ0FBQztBQUFBO0FBQUEsVUFKbkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSXNFLElBR3RFLHVCQUFDLFNBQUksV0FBVSxrQ0FDYjtBQUFBLGlDQUFDLE9BQUUsNkNBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0M7QUFBQSxVQUNoQyx1QkFBQyxPQUFFLFdBQVUsZ0JBQWUsa0VBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThFO0FBQUEsYUFGaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLElBR0ZoQyx5QkFDRSx1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsK0VBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkY7QUFBQSxVQUMzRix1QkFBQyxPQUFFLFdBQVUsc0JBQXFCLHlDQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRDtBQUFBLGFBRjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQSxJQUNFRixjQUFjb0wsU0FBUyxJQUN6QjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBTThGLGdCQUFnQmxSLGVBQWVsSCxVQUFVO0FBQUEsWUFDL0MsU0FBUytYO0FBQUFBLFlBQ1QsWUFBWUU7QUFBQUEsWUFDWixrQkFBa0Isa0JBQWtCM2EsT0FBTyxFQUFFOEwsT0FBTyxZQUFZLENBQUM7QUFBQTtBQUFBLFVBSm5FO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlzRSxJQUd0RSx1QkFBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSxpQ0FBQyxPQUFFLDZDQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDO0FBQUEsVUFDaEMsdUJBQUMsT0FBRSxXQUFVLGdCQUFlLHVFQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRjtBQUFBLGFBRnJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQSxLQXJDTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0NBO0FBQUEsV0EvUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdTQTtBQUFBLFNBdlNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3U0E7QUFBQSxJQUdBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUNFLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxxRUFDYixpQ0FBQyxnQkFBYSxXQUFVLDZCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRCxLQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHlCQUF3Qix5Q0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLDRDQUEyQyxnRUFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsUUFFRixNQUFNL0c7QUFBQUEsUUFDTixVQUFVLE1BQU07QUFDZEMsb0NBQTBCLEtBQUs7QUFDL0JJLCtCQUFxQixFQUFFO0FBQ3ZCRSw4QkFBb0IsRUFBRTtBQUN0QkksOEJBQW9CLEVBQUU7QUFDdEJGLDRCQUFrQixNQUFNO0FBQ3hCTixvQ0FBMEIsRUFBRTtBQUFBLFFBQzlCO0FBQUEsUUFDQSxPQUFPO0FBQUEsUUFDUCxRQUFRO0FBQUEsVUFDTjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsU0FBUyxNQUFNO0FBQ2JGLDBDQUEwQixLQUFLO0FBQy9CSSxxQ0FBcUIsRUFBRTtBQUN2QkYsMENBQTBCLEVBQUU7QUFBQSxjQUM5QjtBQUFBLGNBQUU7QUFBQTtBQUFBLFlBTEU7QUFBQSxZQUROO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFTQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLE1BQUs7QUFBQSxjQUNMO0FBQUEsY0FDQSxTQUFTUztBQUFBQSxjQUNULFNBQVNvUDtBQUFBQSxjQUNULFVBQ0U1UCxrQkFBa0I2UCxXQUFXLEtBQzdCLENBQUMzUCxvQkFDRHNJLFdBQVd0SSxnQkFBZ0IsS0FBSztBQUFBLGNBRWxDLFdBQVU7QUFBQSxjQUE2QjtBQUFBO0FBQUEsZ0JBRWRGLGtCQUFrQjZQO0FBQUFBLGdCQUFPO0FBQUE7QUFBQTtBQUFBLFlBWjlDO0FBQUEsWUFETjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBY0E7QUFBQSxRQUFTO0FBQUEsUUFFWCxRQUFRO0FBQUEsVUFDTjZILE1BQU0sRUFBRUMsV0FBVyxRQUFRQyxXQUFXLFFBQVFDLFNBQVMsT0FBTztBQUFBLFFBQ2hFO0FBQUEsUUFFQ25YLCtCQUNDLHVCQUFDLFNBQUksV0FBVSxtREFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHNFQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtGO0FBQUEsWUFDbEYsdUJBQUMsU0FBSSxXQUFVLHFEQUNiLGlDQUFDLGdCQUFhLFdBQVUsMkNBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStELEtBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxrQ0FBaUMsbURBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSx5QkFBd0IsbURBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQSxJQUNFWix1QkFBdUIrUCxXQUFXLElBQ3BDLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxvRkFDYixpQ0FBQyxnQkFBYSxXQUFVLDRCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRCxLQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsNkJBQTRCLGlEQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLDZEQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxzRkFDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSw4REFDWjtBQUFBLHFDQUFDLHNCQUFtQixXQUFVLHFCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQztBQUFBLGNBQUc7QUFBQSxpQkFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFDZjtBQUFBLHlDQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxrQkFBTztBQUFBLHFCQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE9BQU96UDtBQUFBQSxvQkFDUCxVQUFVQztBQUFBQSxvQkFDVixNQUFLO0FBQUEsb0JBRUw7QUFBQSw2Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFdBQVUsNEJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTJDO0FBQUEsc0JBQzNDLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sV0FBVSw2QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNEM7QUFBQSxzQkFDNUMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxRQUFPLHVDQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUE7QUFBQTtBQUFBLGtCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFXQTtBQUFBLG1CQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0JBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUNmO0FBQUEseUNBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBLGtCQUFPO0FBQUEscUJBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsT0FBT0g7QUFBQUEsb0JBQ1AsVUFBVSxDQUFDdVcsTUFBTXRXLG9CQUFvQnNXLEVBQUVDLE9BQU9oTixLQUFLO0FBQUEsb0JBQ25ELGFBQVk7QUFBQSxvQkFDWixLQUFLO0FBQUEsb0JBQ0wsTUFBTTtBQUFBLG9CQUNOLFFBQU87QUFBQSxvQkFDUCxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBO0FBQUEsa0JBVFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVN3QjtBQUFBLG1CQWIxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWVBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQyxpQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQU9wSjtBQUFBQSxvQkFDUCxVQUFVLENBQUNtVyxNQUFNbFcsb0JBQW9Ca1csRUFBRUMsT0FBT2hOLEtBQUs7QUFBQSxvQkFDbkQsYUFBWTtBQUFBLG9CQUNaLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUE7QUFBQSxrQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS3dCO0FBQUEsbUJBVDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxpQkE3Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE4Q0E7QUFBQSxlQW5ERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9EQTtBQUFBLFVBR0MxSixrQkFBa0I2UCxTQUFTLEtBQzFCLHVCQUFDLFNBQUksV0FBVSxzRkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSwrQkFBOEI7QUFBQTtBQUFBLGdCQUNqQzdQLGtCQUFrQjZQO0FBQUFBLGdCQUFPO0FBQUEsbUJBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFVBQUssV0FBVSx5QkFBd0I7QUFBQTtBQUFBLGdCQUVyQzdQLGtCQUNFaVMsT0FBTyxDQUFDQyxLQUFLOUgsTUFBTThILE1BQU05SCxFQUFFaUMsY0FBYyxDQUFDLEVBQzFDNEIsZUFBZSxPQUFPO0FBQUEsbUJBSjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBLHVCQUFDLFVBQUssV0FBVSx5QkFBd0I7QUFBQTtBQUFBLGdCQUVyQ2pPLGtCQUNFaVMsT0FBTyxDQUFDQyxLQUFLOUgsTUFBTThILE1BQU05SCxFQUFFa0MsY0FBYyxDQUFDLEVBQzFDMkIsZUFBZSxPQUFPO0FBQUEsbUJBSjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxpQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdCQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBUyxNQUFNaE8scUJBQXFCLEVBQUU7QUFBQSxnQkFDdEMsV0FBVTtBQUFBLGdCQUFlO0FBQUE7QUFBQSxjQUgzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLGVBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUJBO0FBQUEsVUFJRix1QkFBQyxTQUNDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDBDQUNiLGlDQUFDLFFBQUcsV0FBVSwrQkFBOEI7QUFBQTtBQUFBLGNBQ2ZILHVCQUF1QitQO0FBQUFBLGNBQU87QUFBQSxpQkFEM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVM7QUFBQSxrQkFDUDtBQUFBLG9CQUNFeUMsT0FDRTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxTQUNFdFMsa0JBQWtCNlAsV0FDbEIvUCx1QkFBdUIrUCxVQUN2Qi9QLHVCQUF1QitQLFNBQVM7QUFBQSx3QkFFbEMsZUFDRTdQLGtCQUFrQjZQLFNBQVMsS0FDM0I3UCxrQkFBa0I2UCxTQUNsQi9QLHVCQUF1QitQO0FBQUFBLHdCQUV6QixVQUFVLENBQUM0RyxNQUFNO0FBQ2YsOEJBQUlBLEVBQUVDLE9BQU9DLFNBQVM7QUFDcEIxVyxpREFBcUIsQ0FBQyxHQUFHSCxzQkFBc0IsQ0FBQztBQUFBLDBCQUNsRCxPQUFPO0FBQ0xHLGlEQUFxQixFQUFFO0FBQUEsMEJBQ3pCO0FBQUEsd0JBQ0Y7QUFBQTtBQUFBLHNCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBaUJJO0FBQUEsb0JBR05zUyxXQUFXO0FBQUEsb0JBQ1hqTCxLQUFLO0FBQUEsb0JBQ0xrTSxPQUFPO0FBQUEsb0JBQ1BoQixRQUFRQSxDQUFDbEosR0FBR3NKLFdBQ1Y7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsU0FBUzVTLGtCQUFrQm1LO0FBQUFBLDBCQUN6QixDQUFDQyxNQUNDQSxFQUFFTSxXQUFXa0ksT0FBT2xJLFVBQ3BCTixFQUFFd0IsV0FBV2dILE9BQU9oSCxVQUNwQnhCLEVBQUVyTSxZQUFZNlUsT0FBTzdVO0FBQUFBLHdCQUN6QjtBQUFBLHdCQUNBLFVBQVUsQ0FBQzBZLE1BQU07QUFDZiw4QkFBSUEsRUFBRUMsT0FBT0MsU0FBUztBQUNwQjFXO0FBQUFBLDhCQUFxQjtBQUFBLGdDQUNuQixHQUFHRDtBQUFBQSxnQ0FDSDRTO0FBQUFBLDhCQUFNO0FBQUEsNEJBQ1A7QUFBQSwwQkFDSCxPQUFPO0FBQ0wzUztBQUFBQSw4QkFDRUQsa0JBQWtCcUo7QUFBQUEsZ0NBQ2hCLENBQUNlLE1BQ0MsRUFDRUEsRUFBRU0sV0FBV2tJLE9BQU9sSSxVQUNwQk4sRUFBRXdCLFdBQVdnSCxPQUFPaEgsVUFDcEJ4QixFQUFFck0sWUFBWTZVLE9BQU83VTtBQUFBQSw4QkFFM0I7QUFBQSw0QkFDRjtBQUFBLDBCQUNGO0FBQUEsd0JBQ0Y7QUFBQTtBQUFBLHNCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBeUJJO0FBQUEsa0JBR1I7QUFBQSxrQkFDQTtBQUFBLG9CQUNFdVUsT0FBTztBQUFBLG9CQUNQQyxXQUFXO0FBQUEsb0JBQ1hqTCxLQUFLO0FBQUEsb0JBQ0xtTCxRQUFRQSxDQUFDbkIsR0FBR3RHLE1BQU1zRyxFQUFFckYsU0FBUzJLLGNBQWM1TCxFQUFFaUIsUUFBUTtBQUFBLGtCQUN2RDtBQUFBLGtCQUNBO0FBQUEsb0JBQ0VxRyxPQUFPO0FBQUEsb0JBQ1BDLFdBQVc7QUFBQSxvQkFDWGpMLEtBQUs7QUFBQSxrQkFDUDtBQUFBLGtCQUNBO0FBQUEsb0JBQ0VnTCxPQUFPO0FBQUEsb0JBQ1BDLFdBQVc7QUFBQSxvQkFDWGpMLEtBQUs7QUFBQSxrQkFDUDtBQUFBLGtCQUNBO0FBQUEsb0JBQ0VnTCxPQUFPO0FBQUEsb0JBQ1BDLFdBQVc7QUFBQSxvQkFDWGpMLEtBQUs7QUFBQSxrQkFDUDtBQUFBLGtCQUNBO0FBQUEsb0JBQ0VnTCxPQUFPO0FBQUEsb0JBQ1BDLFdBQVc7QUFBQSxvQkFDWGpMLEtBQUs7QUFBQSxvQkFDTHFMLE9BQU87QUFBQSxvQkFDUEgsUUFBUUEsQ0FBQ2hRLFFBQVFvUSxXQUNmLHVCQUFDLFVBQUssV0FBVSw4QkFBNkI7QUFBQTtBQUFBLHVCQUN4Q0EsT0FBT2pLLGlCQUFpQixHQUFHc0YsZUFBZSxPQUFPO0FBQUEseUJBRHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFRndFLFFBQVFBLENBQUNuQixHQUFHdEcsTUFBTXNHLEVBQUUzSSxnQkFBZ0JxQyxFQUFFckM7QUFBQUEsa0JBQ3hDO0FBQUEsa0JBQ0E7QUFBQSxvQkFDRTJKLE9BQU87QUFBQSxvQkFDUEMsV0FBVztBQUFBLG9CQUNYakwsS0FBSztBQUFBLG9CQUNMcUwsT0FBTztBQUFBLG9CQUNQSCxRQUFRQSxDQUFDaFEsUUFBUW9RLFdBQ2YsdUJBQUMsVUFBSyxXQUFVLGlDQUFnQztBQUFBO0FBQUEsdUJBQzNDQSxPQUFPbkQsaUJBQWlCLEdBQUd4QixlQUFlLE9BQU87QUFBQSx5QkFEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUVGd0UsUUFBUUEsQ0FBQ25CLEdBQUd0RyxNQUFNc0csRUFBRTdCLGdCQUFnQnpFLEVBQUV5RTtBQUFBQSxrQkFDeEM7QUFBQSxrQkFDQTtBQUFBLG9CQUNFNkMsT0FBTztBQUFBLG9CQUNQQyxXQUFXO0FBQUEsb0JBQ1hqTCxLQUFLO0FBQUEsb0JBQ0xxTCxPQUFPO0FBQUEsb0JBQ1BILFFBQVFBLENBQUNoUSxXQUNQLHVCQUFDLFVBQUssV0FBVSw2QkFBNEI7QUFBQTtBQUFBLHVCQUN2Q0EsVUFBVSxHQUFHeUwsZUFBZSxPQUFPO0FBQUEseUJBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFRndFLFFBQVFBLENBQUNuQixHQUFHdEcsTUFBTXNHLEVBQUUvRCxpQkFBaUJ2QyxFQUFFdUM7QUFBQUEsa0JBQ3pDO0FBQUEsa0JBQ0E7QUFBQSxvQkFDRStFLE9BQU87QUFBQSxvQkFDUGhMLEtBQUs7QUFBQSxvQkFDTHFMLE9BQU87QUFBQSxvQkFDUEgsUUFBUUEsQ0FBQ2xKLEdBQUdzSixXQUFXO0FBQ3JCLDRCQUFNQyxTQUNIRCxPQUFPckYsa0JBQWtCLE1BQ3pCcUYsT0FBT2pLLGlCQUFpQixNQUN4QmlLLE9BQU9uRCxpQkFBaUI7QUFFM0IsNkJBQ0UsdUJBQUMsVUFBSyxXQUFVLDBCQUF5QjtBQUFBO0FBQUEsd0JBQ3JDb0QsTUFBTTVFLGVBQWUsT0FBTztBQUFBLDJCQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBRUo7QUFBQSxvQkFDQXdFLFFBQVFBLENBQUNuQixHQUFHdEcsTUFBTTtBQUNoQiw0QkFBTThNLFVBQ0h4RyxFQUFFL0Qsa0JBQWtCLE1BQ3BCK0QsRUFBRTNJLGlCQUFpQixNQUNuQjJJLEVBQUU3QixpQkFBaUI7QUFFdEIsNEJBQU1zSSxVQUNIL00sRUFBRXVDLGtCQUFrQixNQUNwQnZDLEVBQUVyQyxpQkFBaUIsTUFDbkJxQyxFQUFFeUUsaUJBQWlCO0FBRXRCLDZCQUFPcUksU0FBU0M7QUFBQUEsb0JBQ2xCO0FBQUEsa0JBQ0Y7QUFBQSxnQkFBQztBQUFBLGdCQUVILFlBQVlqWTtBQUFBQSxnQkFDWixRQUFRLENBQUM4UyxXQUFXLEdBQUdBLE9BQU9sSSxNQUFNLElBQUlrSSxPQUFPaEgsTUFBTTtBQUFBLGdCQUNyRCxZQUFZO0FBQUEsa0JBQ1ZvTSxVQUFVO0FBQUEsa0JBQ1ZDLFdBQVdBLENBQUNwRixPQUFPcUYsVUFDakIsR0FBR0EsTUFBTSxDQUFDLENBQUMsSUFBSUEsTUFBTSxDQUFDLENBQUMsT0FBT3JGLEtBQUs7QUFBQSxrQkFDckNzRixpQkFBaUI7QUFBQSxnQkFDbkI7QUFBQSxnQkFDQSxNQUFLO0FBQUEsZ0JBQ0wsUUFBUSxFQUFFQyxHQUFHLEtBQUs7QUFBQTtBQUFBLGNBMUpwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUEwSnNCLEtBM0p4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZKQTtBQUFBLGVBcktGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0tBO0FBQUEsVUFHQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FDRSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSx1Q0FBQyw2QkFBMEIsV0FBVSwwQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkQ7QUFBQSxnQkFDM0QsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixnQ0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0Q7QUFBQSxtQkFGbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBRUYsYUFDRSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHVDQUFDLE9BQUUsV0FBVSxRQUFPLDJGQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0EsdUJBQUMsT0FBRSxXQUFVLDhCQUE2Qiw4RUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLG1CQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxjQUVGLE1BQUs7QUFBQSxjQUNMLFVBQVU7QUFBQSxjQUNWLFdBQVU7QUFBQTtBQUFBLFlBckJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXFCaUQ7QUFBQSxhQXJSbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVSQTtBQUFBO0FBQUEsTUE1V0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBOFdBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FDRSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsbUVBQ2IsaUNBQUMsZUFBWSxXQUFVLDJCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QyxLQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHlCQUF3QixrQ0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxZQUMxRCx1QkFBQyxPQUFFLFdBQVUsNENBQTJDLGdFQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUVGLE1BQU1sYTtBQUFBQSxRQUNOLFVBQVUsTUFBTUMseUJBQXlCLEtBQUs7QUFBQSxRQUM5QyxPQUFPO0FBQUEsUUFDUCxRQUFRO0FBQUEsVUFDTjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsU0FBUyxNQUFNQSx5QkFBeUIsS0FBSztBQUFBLGNBQzdDLFdBQVU7QUFBQSxjQUNWLE1BQUs7QUFBQSxjQUFPO0FBQUE7QUFBQSxZQUhSO0FBQUEsWUFETjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBT0E7QUFBQSxRQUFTO0FBQUEsUUFFWCxXQUFVO0FBQUEsUUFDVixRQUFRO0FBQUEsVUFDTnVaLE1BQU0sRUFBRUcsU0FBUyxRQUFRRixXQUFXLFFBQVFDLFdBQVcsT0FBTztBQUFBLFFBQ2hFO0FBQUEsUUFFQ3RaLCtCQUNDLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxnQkFDYixpQ0FBQyxTQUFJLFdBQVUsNEVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0YsS0FEMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLGtDQUFpQyw2Q0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BLElBQ0VGLGdCQUNGLHVCQUFDLFNBQUksV0FBVSxhQUViO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDBHQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDBEQUNiLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHFDQUFDLGdCQUFhLFdBQVUsd0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRDO0FBQUEsY0FDNUMsdUJBQUMsUUFBRyxXQUFVLDJDQUEwQyxvQ0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsT0FDYixpQ0FBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsbUVBQ2IsaUNBQUMsZ0JBQWEsV0FBVSxtQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUMsS0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsc0RBQXFELDZCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRSxXQUFVLHlDQUNWQSx3QkFBY3VWLE1BQU1oSSxRQUFRLFNBRC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsbUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLG9FQUNiLGlDQUFDLGlCQUFjLFdBQVUsb0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlDLEtBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsT0FBRSxXQUFVLHNEQUFxRCw0QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLE9BQUUsV0FBVSx5Q0FDVnZOLHdCQUFjdVYsTUFBTTBFLFNBQVMsU0FEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxtQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUscUVBQ2IsaUNBQUMsZ0JBQWEsV0FBVSxxQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUMsS0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsc0RBQXFELDBCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRSxXQUFVLHlDQUNWamEsd0JBQWNnVSxPQUFPekcsUUFBUSxTQURoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFPQTtBQUFBLG1CQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxxRUFDYixpQ0FBQyxzQkFBbUIsV0FBVSxxQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0MsS0FEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsc0RBQXFELDZCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRSxXQUFVLHlDQUNWdk4sd0JBQWN3TixVQUFVLFNBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsbUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQTtBQUFBLGlCQXBERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFEQSxLQXRERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVEQTtBQUFBLGVBaEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUVBO0FBQUEsVUFHQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLHVFQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1GO0FBQUEsY0FDbkYsdUJBQUMsUUFBRyxXQUFVLDhDQUE2QyxpQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSx3REFFYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxpTEFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxpSkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2SjtBQUFBLGdCQUM3Six1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSwyQ0FBQyxPQUFFLFdBQVUsa0RBQ1Y7QUFBQTtBQUFBLHNCQUFJO0FBQUEseUJBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLG9CQUNBLHVCQUFDLGVBQVksV0FBVSw0QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0M7QUFBQSx1QkFMakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBLGtCQUNBLHVCQUFDLE9BQUUsV0FBVSxxQ0FBb0M7QUFBQTtBQUFBLHFCQUU3Q3hOLGNBQWNpVyxTQUFTakosYUFBYSxHQUFHNkM7QUFBQUEsc0JBQ3ZDO0FBQUEsb0JBQ0Y7QUFBQSx1QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRSxXQUFVLCtCQUE4QixpQ0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlCQTtBQUFBLG1CQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW9CQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLDJLQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLCtJQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJKO0FBQUEsZ0JBQzNKLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLDJDQUFDLE9BQUUsV0FBVSxnREFBK0MsdUJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyw2QkFBMEIsV0FBVSwwQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBMkQ7QUFBQSx1QkFKN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGtCQUNBLHVCQUFDLE9BQUUsV0FBVSxtQ0FBa0M7QUFBQTtBQUFBLHFCQUczQzdQLGNBQWNpVyxTQUFTaEksZ0JBQWdCLEdBQ3ZDNEIsZUFBZSxPQUFPO0FBQUEsdUJBSjFCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsNkJBQTRCLHFDQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFnQkE7QUFBQSxtQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFtQkE7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSxvTEFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxrSkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4SjtBQUFBLGdCQUM5Six1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSwyQ0FBQyxPQUFFLFdBQVUsbURBQWtELHdCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsdUJBQW9CLFdBQVUsNkJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXdEO0FBQUEsdUJBSjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsc0NBQXFDO0FBQUE7QUFBQSxxQkFHOUM3UCxjQUFjaVcsU0FBUy9ILGdCQUFnQixHQUN2QzJCLGVBQWUsT0FBTztBQUFBLHVCQUoxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRSxXQUFVLGdDQUErQixzQ0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZ0JBO0FBQUEsbUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbUJBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsOEtBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsZ0pBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEo7QUFBQSxnQkFDNUosdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsMkNBQUMsT0FBRSxXQUFVLGlEQUFnRCwrQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLGtCQUFlLFdBQVUsMkJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlEO0FBQUEsdUJBSm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFXLHVCQUF1QjdQLGNBQWMrUyxZQUFZNUQsa0JBQWtCLEtBQUssSUFBSSxvQkFBb0IsZ0JBQWdCO0FBQUEsc0JBQUc7QUFBQTtBQUFBLHdCQUc3SHNFLEtBQUtDO0FBQUFBLDBCQUNKMVQsY0FBYytTLFlBQVk1RCxrQkFBa0I7QUFBQSx3QkFDOUMsRUFBRVUsZUFBZSxPQUFPO0FBQUE7QUFBQTtBQUFBLG9CQU4xQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBT0E7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFXLDZCQUE2QjdQLGNBQWMrUyxZQUFZNUQsa0JBQWtCLEtBQUssSUFBSSxvQkFBb0IsZ0JBQWdCO0FBQUEsc0JBRS9IblAseUJBQWMrUyxZQUFZNUQsa0JBQWtCLEtBQUssSUFDL0MsZUFDQTtBQUFBO0FBQUEsb0JBTE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU1BO0FBQUEscUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBc0JBO0FBQUEsbUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeUJBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsb0xBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsa0pBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBOEo7QUFBQSxnQkFDOUosdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsMkNBQUMsT0FBRSxXQUFVLG1EQUFrRCw2QkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLHNCQUFtQixXQUFVLDZCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF1RDtBQUFBLHVCQUp6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRSxXQUFVLHNDQUFxQztBQUFBO0FBQUEsc0JBRzdDblAsY0FBYytTLFlBQVk1RCxrQkFBa0IsTUFDNUNuUCxjQUFjaVcsU0FBU2hJLGdCQUFnQixNQUN2Q2pPLGNBQWNpVyxTQUFTL0gsZ0JBQWdCLElBQ3hDMkIsZUFBZSxPQUFPO0FBQUEsdUJBTjFCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBT0E7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsZ0NBQStCLDZDQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0JBO0FBQUEsbUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUEsaUJBdEhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdUhBO0FBQUEsZUE5SEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkErSEE7QUFBQSxVQUdBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsc0VBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0Y7QUFBQSxjQUNsRix1QkFBQyxRQUFHLFdBQVUsOENBQTZDLG1DQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsV0FDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPLEdBQUcrQyx1QkFBdUJuQixVQUFVLENBQUM7QUFBQSxrQkFDNUMsV0FBVTtBQUFBO0FBQUEsZ0JBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRXVDLEtBSHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxpQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVdBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTMEQ7QUFBQUEsZ0JBQ1QsWUFBWXZDLHlCQUF5QjtBQUFBLGdCQUNyQyxRQUFRLENBQUM0QixRQUFReEosVUFBVUE7QUFBQUEsZ0JBQzNCLFlBQVk7QUFBQSxrQkFDVjRPLFVBQVU7QUFBQSxrQkFDVkMsV0FBV0EsQ0FBQ3BGLE9BQU9xRixVQUNqQixHQUFHQSxNQUFNLENBQUMsQ0FBQyxJQUFJQSxNQUFNLENBQUMsQ0FBQyxPQUFPckYsS0FBSztBQUFBLGtCQUNyQ3NGLGlCQUFpQjtBQUFBLGtCQUNqQkcsaUJBQWlCO0FBQUEsZ0JBQ25CO0FBQUEsZ0JBQ0EsTUFBSztBQUFBLGdCQUNMLFFBQVEsRUFBRUYsR0FBRyxLQUFLO0FBQUEsZ0JBQ2xCLFdBQVU7QUFBQSxnQkFDVixjQUFhO0FBQUEsZ0JBQ2IsUUFBUSxFQUFFRyxXQUFXLHdCQUF3QjtBQUFBO0FBQUEsY0FmL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBZWlELEtBaEJuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtCQTtBQUFBLGVBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUNBO0FBQUEsYUF6T0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBPQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxvRkFDYixpQ0FBQyxlQUFZLFdBQVUsNEJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStDLEtBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSw2QkFBNEIsaUNBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBEO0FBQUEsVUFDMUQsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QixpREFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUE7QUFBQSxNQTlSSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFnU0E7QUFBQSxJQUdBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUNFLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxxRUFDYixpQ0FBQyxtQkFBZ0IsV0FBVSw2QkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0QsS0FEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFVBQUssV0FBVSx5QkFBd0IsK0JBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVEO0FBQUEsWUFDdkQsdUJBQUMsT0FBRSxXQUFVLDRDQUEyQyxxREFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLGFBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFFRixNQUFNM1g7QUFBQUEsUUFDTixVQUFVLE1BQU1DLDhCQUE4QixLQUFLO0FBQUEsUUFDbkQsT0FBTztBQUFBLFFBQ1AsUUFBUTtBQUFBLFVBQ047QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLFNBQVMsTUFBTUEsOEJBQThCLEtBQUs7QUFBQSxjQUNsRCxXQUFVO0FBQUEsY0FDVixNQUFLO0FBQUEsY0FBTztBQUFBO0FBQUEsWUFIUjtBQUFBLFlBRE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsUUFBUztBQUFBLFFBRVgsV0FBVTtBQUFBLFFBQ1YsUUFBUTtBQUFBLFVBQ042VyxNQUFNLEVBQUVHLFNBQVMsUUFBUUYsV0FBVyxRQUFRQyxXQUFXLE9BQU87QUFBQSxRQUNoRTtBQUFBLFFBRUM1VyxvQ0FDQyx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsZ0JBQ2IsaUNBQUMsU0FBSSxXQUFVLDhFQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBGLEtBRDVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxrQ0FBaUMsMENBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQSxJQUVBLG1DQUNHRSxxQ0FDQyx1QkFBQyxTQUFJLFdBQVUsYUFFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSw0R0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSwwREFDYixpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxxQ0FBQyxnQkFBYSxXQUFVLHdCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0QztBQUFBLGNBQzVDLHVCQUFDLFFBQUcsV0FBVSwyQ0FBMEMsb0NBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLE9BQ2IsaUNBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLG1FQUNiLGlDQUFDLGdCQUFhLFdBQVUsbUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVDLEtBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsT0FBRSxXQUFVLHNEQUFxRCw2QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLE9BQUUsV0FBVSx5Q0FDVkEsa0NBQXdCK0ssWUFEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxtQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsb0VBQ2IsaUNBQUMsaUJBQWMsV0FBVSxvQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUMsS0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsc0RBQXFELDRCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRSxXQUFVLHlDQUNWL0ssa0NBQXdCZ0wsYUFEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxtQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUscUVBQ2IsaUNBQUMsZ0JBQWEsV0FBVSxxQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUMsS0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsc0RBQXFELDBCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRSxXQUFVLHlDQUNWaEwsa0NBQXdCaUwsYUFEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxtQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUscUVBQ2IsaUNBQUMsc0JBQW1CLFdBQVUscUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStDLEtBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsT0FBRSxXQUFVLHNEQUFxRCw2QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLE9BQUUsV0FBVSx5Q0FDVmpMLGtDQUF3QjBLLFVBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU9BO0FBQUEsbUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHlHQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLGtFQUNiLGlDQUFDLDZCQUEwQixXQUFVLGtCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtRCxLQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FDQztBQUFBLHlDQUFDLE9BQUUsV0FBVSxzREFBcUQsd0NBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsa0NBQWlDO0FBQUE7QUFBQSxvQkFDMUNvRyxtQkFBbUIvRCxlQUFlLE9BQU87QUFBQSx1QkFEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxtQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsaUJBakVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0VBLEtBbkVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0VBO0FBQUEsZUE3RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE4RUE7QUFBQSxVQUdBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsdUVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUY7QUFBQSxjQUNuRix1QkFBQyxRQUFHLFdBQVUsOENBQTZDLDBDQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsV0FDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPLEdBQUduTixtQkFBbUIrTyxNQUFNO0FBQUEsa0JBQ25DLFdBQVU7QUFBQTtBQUFBLGdCQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUUyQyxLQUg3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsaUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLFlBRUMvTyxtQkFBbUIrTyxTQUFTLElBQzNCLHVCQUFDLFNBQUksV0FBVSwrREFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVN3QztBQUFBQSxnQkFDVCxZQUFZdlI7QUFBQUEsZ0JBQ1osUUFBTztBQUFBLGdCQUNQLFlBQVk7QUFBQSxrQkFDVmtYLFVBQVU7QUFBQSxrQkFDVkMsV0FBV0EsQ0FBQ3BGLE9BQU9xRixVQUNqQixHQUFHQSxNQUFNLENBQUMsQ0FBQyxJQUFJQSxNQUFNLENBQUMsQ0FBQyxPQUFPckYsS0FBSztBQUFBLGtCQUNyQ3NGLGlCQUFpQjtBQUFBLGtCQUNqQkcsaUJBQWlCO0FBQUEsZ0JBQ25CO0FBQUEsZ0JBQ0EsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDVixjQUFjLENBQUMxRixXQUFXO0FBQ3hCLHNCQUFJQSxPQUFPaFYsU0FBUyxVQUFXLFFBQU87QUFDdEMsc0JBQUlnVixPQUFPaFYsU0FBUyxXQUFZLFFBQU87QUFDdkMseUJBQU87QUFBQSxnQkFDVDtBQUFBO0FBQUEsY0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBaUJJLEtBbEJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0JBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGtFQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLG9GQUNiLGlDQUFDLG1CQUFnQixXQUFVLDRCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRCxLQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsNkJBQTRCLHdDQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLGdFQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLGVBL0NKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaURBO0FBQUEsYUFwSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFJQSxLQXZJSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeUlBO0FBQUE7QUFBQSxNQW5MSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFxTEE7QUFBQSxJQUdBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFNO0FBQUEsUUFDTixNQUFNaUg7QUFBQUEsUUFDTixVQUFVLE1BQU07QUFDZEMsa0NBQXdCLEtBQUs7QUFDN0JFLGdDQUFzQixJQUFJO0FBQzFCRSw0QkFBa0IsRUFBRTtBQUNwQkUsNEJBQWtCLEVBQUU7QUFBQSxRQUN0QjtBQUFBLFFBQ0EsUUFBUTtBQUFBLFVBQ04sdUJBQUMsVUFBb0IsU0FBUyxNQUFNTix3QkFBd0IsS0FBSyxHQUFHLHNCQUF4RCxVQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBFO0FBQUEsVUFDMUUsdUJBQUMsVUFBb0IsTUFBSyxXQUFVLFNBQVNPLHVCQUF1QixTQUFTa0QseUJBQXlCLDhCQUExRixVQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxRQUFTO0FBQUEsUUFFWCxPQUFPO0FBQUEsUUFFTnhELGdDQUNDLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0Msd0JBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdFO0FBQUEsWUFDeEUsdUJBQUMsU0FBTSxPQUFPQSxtQkFBbUJoQixTQUFTZ0QsYUFBYSxPQUFPLFVBQVEsUUFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0U7QUFBQSxlQUZ4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQyx1QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUU7QUFBQSxZQUN2RSx1QkFBQyxTQUFNLE9BQU9oQyxtQkFBbUI2QixTQUFTQSxXQUFXN0IsbUJBQW1CNkIsU0FBU04sT0FBTyxPQUFPLFVBQVEsUUFBdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUc7QUFBQSxlQUZ6RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQyxrQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0Y7QUFBQSxZQUNsRjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPckI7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDd1IsTUFBTXZSLGtCQUFrQnVSLEVBQUVDLE9BQU9oTixLQUFLO0FBQUEsZ0JBQ2pELGFBQVk7QUFBQSxnQkFDWixLQUFLO0FBQUEsZ0JBQ0wsTUFBTTtBQUFBLGdCQUNOLFdBQVM7QUFBQTtBQUFBLGNBUFg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT1c7QUFBQSxlQVRiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHNCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRTtBQUFBLFlBQ3RFO0FBQUEsY0FBQyxNQUFNO0FBQUEsY0FBTjtBQUFBLGdCQUNDLE9BQU92RTtBQUFBQSxnQkFDUCxVQUFVLENBQUNzUixNQUFNclIsa0JBQWtCcVIsRUFBRUMsT0FBT2hOLEtBQUs7QUFBQSxnQkFDakQsYUFBWTtBQUFBLGdCQUNaLE1BQU07QUFBQTtBQUFBLGNBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSVU7QUFBQSxlQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxhQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBOEJBO0FBQUE7QUFBQSxNQWhESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFrREE7QUFBQSxJQUdBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNbkU7QUFBQUEsUUFDTixVQUFVLE1BQU07QUFDZEMsOEJBQW9CLEtBQUs7QUFDekJuRCx5QkFBZSxJQUFJO0FBQ25CRSw0QkFBa0IsQ0FBQyxFQUFFQyxRQUFRLElBQUlDLFFBQVEsR0FBRyxDQUFDLENBQUM7QUFBQSxRQUNoRDtBQUFBLFFBQ0EsUUFBUTtBQUFBLFFBQ1I7QUFBQSxRQUNBLE9BQU87QUFBQSxRQUNQLE9BQ0UsdUJBQUMsU0FBSSxXQUFVLDJCQUNiLGlDQUFDLFVBQUssV0FBVSxxQ0FBb0Msb0NBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0UsS0FEMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFHRixpQ0FBQyxRQUFLLFVBQVVDLGdCQUFnQixLQUFJLDhCQUNsQyxpQ0FBQyxTQUFJLFdBQVUsT0FFWk47QUFBQUEseUJBQ0MsdUJBQUMsU0FBSSxXQUFVLDZEQUNiLGlDQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsaURBQWdELHdCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFxRTtBQUFBLGNBQ3JFLHVCQUFDLE9BQUUsV0FBVSx1Q0FDVkEsdUJBQWEyQixTQUFTZ0QsYUFBYTNFLGFBQWFvVyxpQkFBaUIsT0FEcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsaURBQWdELHVCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvRTtBQUFBLGNBQ3BFLHVCQUFDLE9BQUUsV0FBVSx1Q0FDVnBXLHVCQUFhd0UsU0FBU0EsV0FBVyxPQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLE9BQUUsV0FBVSxpREFBZ0QsMkJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdFO0FBQUEsY0FDeEUsdUJBQUMsT0FBRSxXQUFVLG9DQUFtQztBQUFBO0FBQUEsZ0JBQzVDeEUsYUFBYXdFLFNBQVNDLGFBQWFvSCxlQUFlLE9BQU8sS0FBSztBQUFBLG1CQURsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLE9BQUUsV0FBVSxpREFBZ0Qsd0JBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFFO0FBQUEsY0FDckUsdUJBQUMsT0FBRSxXQUFVLGtDQUNWN0wsdUJBQWF3RSxTQUFTMkUsVUFBVXRCLE1BQU0sR0FBRyxFQUFFLENBQUMsR0FBR0EsTUFBTSxHQUFHLEdBQUd3TyxRQUFRLEdBQUdDLEtBQUssR0FBRyxLQUFLLE9BRHRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5QkEsS0ExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyQkE7QUFBQSxVQUlEdFcsYUFBYXdFLFNBQVMrUixlQUFlOUksU0FBUyxLQUM3Qyx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSxrREFBaUQsZ0NBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThFO0FBQUEsWUFDOUUsdUJBQUMsU0FBSSxXQUFVLGdEQUNiLGlDQUFDLFdBQU0sV0FBVSxzQkFDZjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxtREFDZixpQ0FBQyxRQUNDO0FBQUEsdUNBQUMsUUFBRyxXQUFVLHVCQUFzQixzQkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEM7QUFBQSxnQkFDMUMsdUJBQUMsUUFBRyxXQUFVLHVCQUFzQixzQkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEM7QUFBQSxnQkFDMUMsdUJBQUMsUUFBRyxXQUFVLHdCQUF1QiwwQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0M7QUFBQSxnQkFDL0MsdUJBQUMsUUFBRyxXQUFVLHdCQUF1Qix3QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkM7QUFBQSxnQkFDN0MsdUJBQUMsUUFBRyxXQUFVLHdCQUF1QiwyQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0Q7QUFBQSxtQkFMbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxjQUNBLHVCQUFDLFdBQU0sV0FBVSw0QkFDZHpOLHNCQUFZd0UsU0FBUytSLGNBQWN4UyxJQUFJLENBQUN5UyxRQUFRdlMsUUFBUTtBQUN2RCxzQkFBTXdTLFNBQVNELE9BQU9wTyxTQUFTO0FBQy9CLHNCQUFNc08sYUFBYUYsT0FBT0csZ0JBQWdCRixTQUFTRCxPQUFPcFcsU0FBUztBQUNuRSxzQkFBTXdXLGdCQUFnQkosT0FBT0ssbUJBQW1CSixTQUFTLElBQUlELE9BQU9wVyxTQUFTc1c7QUFDN0Usb0JBQUlJLGFBQWE7QUFDakIsb0JBQUlDLGNBQWM7QUFDbEIsb0JBQUlOLFFBQVE7QUFDVkssK0JBQWE7QUFDYkMsZ0NBQWM7QUFBQSxnQkFDaEIsV0FBV0wsYUFBYSxLQUFLQSxhQUFhRixPQUFPcFcsUUFBUTtBQUN2RDBXLCtCQUFhO0FBQ2JDLGdDQUFjO0FBQUEsZ0JBQ2hCO0FBQ0EsdUJBQ0UsdUJBQUMsUUFBMkIsV0FBVSxxQkFDcEM7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsYUFDWixpQ0FBQyxVQUFLLFdBQVcsa0RBQWtEQSxXQUFXLElBQzNFRCx3QkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSwyQkFBMkJOLGlCQUFPblcsVUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUQ7QUFBQSxrQkFDdkQsdUJBQUMsUUFBRyxXQUFVLGtEQUFpRDtBQUFBO0FBQUEsb0JBQzNEOEgsT0FBT3FPLE9BQU9wVyxVQUFVLENBQUMsRUFBRXlMLGVBQWUsT0FBTztBQUFBLHVCQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsUUFBRyxXQUFVLHFEQUNYNkssdUJBQWEsSUFBSSxJQUFJQSxXQUFXN0ssZUFBZSxPQUFPLENBQUMsS0FBSyxPQUQvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsUUFBRyxXQUFVLG1EQUNYK0ssMEJBQWdCLElBQUksSUFBSUEsY0FBYy9LLGVBQWUsT0FBTyxDQUFDLEtBQUssT0FEckU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQWZPMkssT0FBT3RTLE9BQU9ELEtBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZ0JBO0FBQUEsY0FFSixDQUFDLEtBakNIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa0NBO0FBQUEsY0FDQSx1QkFBQyxXQUFNLFdBQVUsMENBQ2YsaUNBQUMsUUFDQztBQUFBLHVDQUFDLFFBQUcsU0FBUSxLQUFJLFdBQVUscUJBQW9CLHNCQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRDtBQUFBLGdCQUNwRCx1QkFBQyxRQUFHLFdBQVUsd0JBQXVCO0FBQUE7QUFBQSxrQkFDakNqRSxZQUFZd0UsU0FBUytSLGNBQWMxRyxPQUFPLENBQUNtSCxHQUFHaFAsTUFBTWdQLElBQUk3TyxPQUFPSCxFQUFFNUgsVUFBVSxDQUFDLEdBQUcsQ0FBQyxFQUFFeUwsZUFBZSxPQUFPO0FBQUEscUJBRDVHO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLFdBQVUsd0JBQXVCO0FBQUE7QUFBQSxrQkFDakM3TCxZQUFZd0UsU0FBUytSLGNBQWMxRyxPQUFPLENBQUNtSCxHQUFHaFAsTUFBTWdQLElBQUk3TyxPQUFPSCxFQUFFMk8sZ0JBQWdCM08sRUFBRUksT0FBT0osRUFBRTVILFNBQVMsRUFBRSxHQUFHLENBQUMsRUFBRXlMLGVBQWUsT0FBTztBQUFBLHFCQUR2STtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxXQUFVLHdCQUF1QjtBQUFBO0FBQUEsa0JBQ2pDN0wsWUFBWXdFLFNBQVMrUixjQUFjMUcsT0FBTyxDQUFDbUgsR0FBR2hQLE1BQU1nUCxJQUFJN08sT0FBT0gsRUFBRTZPLG1CQUFtQjdPLEVBQUVJLE9BQU8sSUFBSUosRUFBRTVILFVBQVU0SCxFQUFFMk8sZUFBZSxHQUFHLEdBQUcsQ0FBQyxFQUFFOUssZUFBZSxPQUFPO0FBQUEscUJBRGpLO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFhQTtBQUFBLGlCQTFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJEQSxLQTVERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZEQTtBQUFBLGVBL0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0VBO0FBQUEsVUFJRDNMLGVBQWU2SCxLQUFLLENBQUFDLE1BQUtBLEVBQUU1SCxNQUFNLEtBQ2hDLHVCQUFDLFNBQUksV0FBVSxxREFBb0Q7QUFBQTtBQUFBLFlBQzVDRixlQUFlMlAsT0FBTyxDQUFDbUgsR0FBR2hQLE1BQU1nUCxJQUFJN08sT0FBT0gsRUFBRTVILFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRXlMLGVBQWUsT0FBTztBQUFBLGVBRDNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUdGLHVCQUFDLFNBQUksV0FBVSw2Q0FDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNO0FBQ2J6SSxvQ0FBb0IsS0FBSztBQUN6Qm5ELCtCQUFlLElBQUk7QUFDbkJFLGtDQUFrQixDQUFDLEVBQUVDLFFBQVEsSUFBSUMsUUFBUSxHQUFHLENBQUMsQ0FBQztBQUFBLGNBQ2hEO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FBd0Y7QUFBQTtBQUFBLFlBTnBHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLGFBeEhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5SEEsS0ExSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJIQTtBQUFBO0FBQUEsTUEzSUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBNElBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FDRSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsb0VBQ2IsaUNBQUMsZ0JBQWEsV0FBVSw0QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0QsS0FEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFVBQUssV0FBVSx5QkFBd0IsdUNBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSw0Q0FBMkMsMkRBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxhQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFFBRUYsTUFBTXJCO0FBQUFBLFFBQ04sVUFBVSxNQUFNO0FBQ2RDLDhCQUFvQixLQUFLO0FBQ3pCRSw0QkFBa0IsSUFBSTtBQUN0QkUsK0JBQXFCLEVBQUU7QUFDdkJFLCtCQUFxQixFQUFFO0FBQ3ZCRSx3QkFBYyxFQUFFO0FBQUEsUUFDbEI7QUFBQSxRQUNBLE9BQU87QUFBQSxRQUNQLFFBQVE7QUFBQSxVQUNOO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxTQUFTLE1BQU07QUFDYlIsb0NBQW9CLEtBQUs7QUFDekJFLGtDQUFrQixJQUFJO0FBQ3RCRSxxQ0FBcUIsRUFBRTtBQUN2QkUscUNBQXFCLEVBQUU7QUFDdkJFLDhCQUFjLEVBQUU7QUFBQSxjQUNsQjtBQUFBLGNBQ0EsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQU07QUFBQTtBQUFBLFlBVFo7QUFBQSxZQUROO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFhQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLE1BQUs7QUFBQSxjQUNMLFNBQVNDO0FBQUFBLGNBQ1QsU0FBU2dQO0FBQUFBLGNBQ1QsTUFBSztBQUFBLGNBQ0wsV0FBVTtBQUFBLGNBQ1YsTUFBTSx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFhO0FBQUEsY0FBSTtBQUFBO0FBQUEsWUFObkI7QUFBQSxZQUROO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLFFBQVM7QUFBQSxRQUVYLFdBQVU7QUFBQSxRQUNWLFFBQVE7QUFBQSxVQUNONEcsTUFBTSxFQUFFRyxTQUFTLE9BQU87QUFBQSxRQUMxQjtBQUFBLFFBRUN2Vyw0QkFDQyx1QkFBQyxTQUFJLFdBQVUsYUFFYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxtR0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSw0REFDYixpQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxxQ0FBQyxnQkFBYSxXQUFVLDBCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE4QztBQUFBLGNBQzlDLHVCQUFDLFFBQUcsV0FBVSx5Q0FBd0MsbUNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLE9BQ2IsaUNBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLG1FQUNiLGlDQUFDLGdCQUFhLFdBQVUsMkJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStDLEtBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsT0FBRSxXQUFVLHNEQUFxRCx3QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLE9BQUUsV0FBVSwrQkFDVkEseUJBQWV5QyxTQUFTZ0QsYUFEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0E7QUFBQSxtQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUscUVBQ2IsaUNBQUMsZ0JBQWEsV0FBVSw2QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUQsS0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsc0RBQXFELHFCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRSxXQUFVLCtCQUNWekYseUJBQWV5TSxVQUFVRCxjQUQ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFPQTtBQUFBLG1CQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxxRUFDYixpQ0FBQyxzQkFBbUIsV0FBVSw2QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUQsS0FEekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsc0RBQXFELHNCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsT0FBRSxXQUFVLCtCQUNWeE0seUJBQWVzSyxVQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFPQTtBQUFBLG1CQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWUE7QUFBQSxjQUNBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsMEVBQ2Y7QUFBQSx5Q0FBQyxvQkFBaUIsV0FBVSxvQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEM7QUFBQSxrQkFBRztBQUFBLHFCQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBRUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE1BQUs7QUFBQSxvQkFDTCxPQUFPNUo7QUFBQUEsb0JBQ1AsUUFBTztBQUFBLG9CQUNQLFVBQVUsQ0FBQ3dFLFNBQVN2RSxZQUFZdUUsSUFBSTtBQUFBO0FBQUEsa0JBTHRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLd0M7QUFBQSxtQkFYMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFhQTtBQUFBLGlCQXJERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXNEQSxLQXZERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdEQTtBQUFBLGVBakVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0VBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsd0ZBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSxxQ0FBQyxzQkFBbUIsV0FBVSxxQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0M7QUFBQSxjQUMvQyx1QkFBQyxVQUFLLFdBQVUsdUNBQXNDLCtCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLGlEQUNiO0FBQUEsdUNBQUMsT0FBRSxXQUFVLDhCQUE2QiwrQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUQ7QUFBQSxnQkFDekQsdUJBQUMsT0FBRSxXQUFVLGtDQUFpQztBQUFBO0FBQUEsbUJBRTFDbEYsZUFBZTJGLGtCQUFrQixHQUFHZ0g7QUFBQUEsb0JBQ3BDO0FBQUEsa0JBQ0Y7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsbUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLGlEQUNiO0FBQUEsdUNBQUMsT0FBRSxXQUFVLDhCQUE2QixnQ0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEQ7QUFBQSxnQkFDMUQsdUJBQUMsT0FBRSxXQUFVLHFDQUFvQztBQUFBO0FBQUEsbUJBRTdDM00sZUFBZWtOLG1CQUFtQixHQUFHUDtBQUFBQSxvQkFDckM7QUFBQSxrQkFDRjtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxtQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsaUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbUJBO0FBQUEsZUExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyQkE7QUFBQSxVQUdBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUseUVBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUY7QUFBQSxjQUNyRix1QkFBQyxRQUFHLFdBQVUsOENBQTZDLDRCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLGFBRWI7QUFBQSxxQ0FBQyxTQUNDO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDBFQUNmO0FBQUEseUNBQUMsa0JBQWUsV0FBVSxrQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0M7QUFBQSxrQkFBRztBQUFBLHFCQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE9BQU96TTtBQUFBQSxvQkFDUCxVQUFVLENBQUNpVixNQUFNaFYscUJBQXFCZ1YsRUFBRUMsT0FBT2hOLEtBQUs7QUFBQSxvQkFDcEQsYUFBWTtBQUFBLG9CQUNaLEtBQUs7QUFBQSxvQkFDTCxNQUFNO0FBQUEsb0JBQ04sUUFBTztBQUFBLG9CQUNQLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQ1YsUUFDRWxJLHFCQUNFLHVCQUFDLFVBQUssV0FBVSx5QkFBd0I7QUFBQTtBQUFBLHdCQUduQ0YsZUFBZTJGLGtCQUFrQixLQUNsQ3VCLFdBQVdoSCxxQkFBcUIsQ0FBQyxHQUNqQ3lNLGVBQWUsT0FBTztBQUFBLHlCQUwxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU1BO0FBQUE7QUFBQSxrQkFsQk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQW9CRztBQUFBLG1CQXpCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTJCQTtBQUFBLGNBR0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSwwRUFDZjtBQUFBLHlDQUFDLHVCQUFvQixXQUFVLHFCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnRDtBQUFBLGtCQUFHO0FBQUEscUJBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsT0FBT3ZNO0FBQUFBLG9CQUNQLFVBQVUsQ0FBQytVLE1BQU05VSxxQkFBcUI4VSxFQUFFQyxPQUFPaE4sS0FBSztBQUFBLG9CQUNwRCxhQUFZO0FBQUEsb0JBQ1osS0FBSztBQUFBLG9CQUNMLE1BQU07QUFBQSxvQkFDTixRQUFPO0FBQUEsb0JBQ1AsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDVixRQUNFaEkscUJBQ0UsdUJBQUMsVUFBSyxXQUFVLHlCQUF3QjtBQUFBO0FBQUEsd0JBR25DSixlQUFla04sbUJBQW1CLEtBQ25DaEcsV0FBVzlHLHFCQUFxQixDQUFDLEdBQ2pDdU0sZUFBZSxPQUFPO0FBQUEseUJBTDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTUE7QUFBQTtBQUFBLGtCQWxCTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBb0JHO0FBQUEsbUJBekJMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMkJBO0FBQUEsY0FHQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDBFQUNmO0FBQUEseUNBQUMsb0JBQWlCLFdBQVUsbUJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJDO0FBQUEsa0JBQUc7QUFBQSxxQkFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUMsTUFBTTtBQUFBLGtCQUFOO0FBQUEsb0JBQ0MsT0FBT3JNO0FBQUFBLG9CQUNQLFVBQVUsQ0FBQzZVLE1BQU01VSxjQUFjNFUsRUFBRUMsT0FBT2hOLEtBQUs7QUFBQSxvQkFDN0MsYUFBWTtBQUFBLG9CQUNaLE1BQU07QUFBQSxvQkFDTixXQUFVO0FBQUEsb0JBQ1YsV0FBVztBQUFBLG9CQUNYLFdBQVM7QUFBQTtBQUFBLGtCQVBYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPVztBQUFBLG1CQVpiO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBY0E7QUFBQSxlQUdFbEkscUJBQXFCRSxzQkFDckIsdUJBQUMsU0FBSSxXQUFVLG1HQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEseUNBQUMsc0JBQW1CLFdBQVUsbUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZDO0FBQUEsa0JBQzdDLHVCQUFDLFVBQUssV0FBVSx1Q0FBc0MsdUNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUseUJBQXdCLG1DQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsVUFBSyxXQUFVLDhCQUE2QjtBQUFBO0FBQUEsd0JBR3hDSixlQUFlMkYsa0JBQWtCLEtBQ2xDdUIsV0FBV2hILHFCQUFxQixDQUFDLEdBQ2pDeU0sZUFBZSxPQUFPO0FBQUEseUJBTDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTUE7QUFBQSx1QkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVdBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHlCQUF3QixvQ0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFVBQUssV0FBVSxpQ0FBZ0M7QUFBQTtBQUFBLHdCQUczQzNNLGVBQWVrTixtQkFBbUIsS0FDbkNoRyxXQUFXOUcscUJBQXFCLENBQUMsR0FDakN1TSxlQUFlLE9BQU87QUFBQSx5QkFMMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFNQTtBQUFBLHVCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBV0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsbUVBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsdUNBQXNDLCtCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsVUFBSyxXQUFVLHFDQUFvQztBQUFBO0FBQUEsdUJBR2hEekYsV0FBV2hILHFCQUFxQixDQUFDLElBQ2pDZ0gsV0FBVzlHLHFCQUFxQixDQUFDLEdBQ2pDdU0sZUFBZSxPQUFPO0FBQUEseUJBTDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTUE7QUFBQSx1QkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVdBO0FBQUEscUJBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBcUNBO0FBQUEsbUJBNUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNkNBO0FBQUEsaUJBN0hKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0hBO0FBQUEsZUF2SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3SUE7QUFBQSxVQUdBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFRO0FBQUEsY0FDUixhQUFZO0FBQUEsY0FDWixNQUFLO0FBQUEsY0FDTDtBQUFBLGNBQ0EsV0FBVTtBQUFBO0FBQUEsWUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLdUQ7QUFBQSxhQXJQekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVQQTtBQUFBO0FBQUEsTUFqVEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBbVRBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FDRSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUscUVBQ2IsaUNBQUMsa0JBQWUsV0FBVSw2QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUQsS0FEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFVBQUssV0FBVSx5QkFBd0IsbUNBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJEO0FBQUEsWUFDM0QsdUJBQUMsT0FBRSxXQUFVLDRDQUEyQywwRUFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLGFBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFFRixNQUFNelA7QUFBQUEsUUFDTixVQUFVLE1BQU07QUFDZEMsa0NBQXdCLEtBQUs7QUFDN0JFLDBCQUFnQixJQUFJO0FBQ3BCRSw0QkFBa0IsRUFBRTtBQUNwQkksNEJBQWtCLEVBQUU7QUFDcEJGLDBCQUFnQixNQUFNO0FBQUEsUUFDeEI7QUFBQSxRQUNBLE9BQU87QUFBQSxRQUNQLFFBQVE7QUFBQSxVQUNOO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxTQUFTLE1BQU07QUFDYk4sd0NBQXdCLEtBQUs7QUFDN0JFLGdDQUFnQixJQUFJO0FBQ3BCRSxrQ0FBa0IsRUFBRTtBQUNwQkksa0NBQWtCLEVBQUU7QUFBQSxjQUN0QjtBQUFBLGNBQUU7QUFBQTtBQUFBLFlBTkU7QUFBQSxZQUROO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFVQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUVDLE1BQUs7QUFBQSxjQUNMO0FBQUEsY0FDQSxTQUFTQztBQUFBQSxjQUNULFNBQVM4VjtBQUFBQSxjQUNULFVBQVUsQ0FBQ3BXLGtCQUFrQjRKLFdBQVc1SixjQUFjLEtBQUs7QUFBQSxjQUMzRCxXQUFVO0FBQUEsY0FBNkI7QUFBQTtBQUFBLFlBTm5DO0FBQUEsWUFETjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxRQUFTO0FBQUEsUUFFWCxRQUFRO0FBQUEsVUFDTjhZLE1BQU0sRUFBRUMsV0FBVyxRQUFRQyxXQUFXLFFBQVFDLFNBQVMsT0FBTztBQUFBLFFBQ2hFO0FBQUEsUUFFQ3ZaLCtCQUNDLHVCQUFDLFNBQUksV0FBVSxtREFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHNFQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtGO0FBQUEsWUFDbEYsdUJBQUMsU0FBSSxXQUFVLHFEQUNiLGlDQUFDLGtCQUFlLFdBQVUsMkNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlFLEtBRG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSxrQ0FBaUMsd0NBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLE9BQUUsV0FBVSx5QkFBd0Isc0RBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQSxJQUNFSSxlQUNGLHVCQUFDLFNBQUksV0FBVSxhQUViO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDhGQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDREQUNiLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHFDQUFDLGdCQUFhLFdBQVUsMEJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThDO0FBQUEsY0FDOUMsdUJBQUMsUUFBRyxXQUFVLHlDQUF3QyxvQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsT0FDYixpQ0FBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSx1Q0FBQyxnQkFBYSxXQUFVLDBCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4QztBQUFBLGdCQUM5Qyx1QkFBQyxTQUNDO0FBQUEseUNBQUMsT0FBRSxXQUFVLHlCQUF3Qiw2QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0Q7QUFBQSxrQkFDbEQsdUJBQUMsT0FBRSxXQUFVLCtCQUNWQSx1QkFBYXVOLFlBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsbUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsdUNBQUMsaUJBQWMsV0FBVSwyQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0Q7QUFBQSxnQkFDaEQsdUJBQUMsU0FDQztBQUFBLHlDQUFDLE9BQUUsV0FBVSx5QkFBd0IsNEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlEO0FBQUEsa0JBQ2pELHVCQUFDLE9BQUUsV0FBVSwrQkFDVnZOLHVCQUFhd04sYUFEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxtQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSx1Q0FBQyxnQkFBYSxXQUFVLDRCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnRDtBQUFBLGdCQUNoRCx1QkFBQyxTQUNDO0FBQUEseUNBQUMsT0FBRSxXQUFVLHlCQUF3QiwwQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0M7QUFBQSxrQkFDL0MsdUJBQUMsT0FBRSxXQUFVLCtCQUNWeE4sdUJBQWF5TixhQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLG1CQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLHVDQUFDLHNCQUFtQixXQUFVLDRCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzRDtBQUFBLGdCQUN0RCx1QkFBQyxTQUNDO0FBQUEseUNBQUMsT0FBRSxXQUFVLHlCQUF3Qiw2QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0Q7QUFBQSxrQkFDbEQsdUJBQUMsT0FBRSxXQUFVLCtCQUNWek4sdUJBQWFrTixVQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLG1CQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxpQkFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQ0EsS0F0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1Q0E7QUFBQSxlQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlEQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDZGQUNiO0FBQUEscUNBQUMsT0FBRSxXQUFVLGdEQUErQyw2QkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsT0FBRSxXQUFVLHdDQUF1QztBQUFBO0FBQUEsZ0JBQ2hEbE4sYUFBYTJOLGFBQWE0QixlQUFlLE9BQU87QUFBQSxtQkFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxzR0FDYjtBQUFBLHFDQUFDLE9BQUUsV0FBVSxtREFBa0QsOEJBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSwyQ0FBMEM7QUFBQTtBQUFBLGdCQUNuRHZQLGFBQWE0TixhQUFhMkIsZUFBZSxPQUFPO0FBQUEsbUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsZ0dBQ2I7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsaURBQWdELCtCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUseUNBQXdDO0FBQUE7QUFBQSxnQkFFbEQ0RCxLQUFLQyxJQUFJcFQsYUFBYTZPLGNBQWMsRUFBRVU7QUFBQUEsa0JBQ3JDO0FBQUEsZ0JBQ0Y7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQ1Z2UCx1QkFBYTZPLGlCQUFpQixJQUMzQixlQUNBLG1CQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxpQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWVBO0FBQUEsZUFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQ0E7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxzRkFDYixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsT0FBRSxXQUFVLG1EQUFrRCwrQ0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsT0FBRSxXQUFVLHNDQUFxQztBQUFBO0FBQUEsaUJBRzlDN08sYUFBYTZPLGlCQUNiN08sYUFBYTJOLGVBQ2IzTixhQUFhNE4sY0FDYjJCLGVBQWUsT0FBTztBQUFBLG1CQU4xQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsaUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFZQTtBQUFBLFlBQ0EsdUJBQUMsc0JBQW1CLFdBQVUsOEJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdEO0FBQUEsZUFkMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFlQSxLQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLDhEQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGlEQUNiLGlDQUFDLFFBQUcsV0FBVSx1REFDWjtBQUFBLHFDQUFDLGdCQUFhLFdBQVUscUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlDO0FBQUEsY0FBRztBQUFBLGlCQUQ5QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUViO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFDZjtBQUFBLHlDQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxrQkFBTztBQUFBLHFCQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE9BQU9uUDtBQUFBQSxvQkFDUCxVQUFVQztBQUFBQSxvQkFDVixNQUFLO0FBQUEsb0JBRUw7QUFBQSw2Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFdBQVUsNEJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTJDO0FBQUEsc0JBQzNDLHVCQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sV0FBVSw2QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNEM7QUFBQSxzQkFDNUMsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxRQUFPLHVDQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUE7QUFBQTtBQUFBLGtCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFXQTtBQUFBLG1CQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0JBO0FBQUEsY0FHQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUNmO0FBQUEseUNBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBLGtCQUFPO0FBQUEscUJBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsT0FBT0g7QUFBQUEsb0JBQ1AsVUFBVSxDQUFDNlgsTUFBTTVYLGtCQUFrQjRYLEVBQUVDLE9BQU9oTixLQUFLO0FBQUEsb0JBQ2pELGFBQVk7QUFBQSxvQkFDWixLQUFLO0FBQUEsb0JBQ0wsTUFBTTtBQUFBLG9CQUNOLFFBQU87QUFBQSxvQkFDUCxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLFFBQ0U5SyxrQkFDRSx1QkFBQyxVQUFLLFdBQVUseUJBQXdCO0FBQUE7QUFBQSx1QkFFcENFLGlCQUFpQixZQUNmSixhQUFhMk4sZUFDYnZOLGlCQUFpQixZQUNmSixhQUFhNE4sZUFDYjVOLGFBQWEyTixlQUNmM04sYUFBYTROLGNBQ2YyQixlQUFlLE9BQU87QUFBQSx5QkFSMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFTQTtBQUFBO0FBQUEsa0JBckJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkF1Qkc7QUFBQSxtQkEzQkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE2QkE7QUFBQSxjQUdBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLGlDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQyxNQUFNO0FBQUEsa0JBQU47QUFBQSxvQkFDQyxPQUFPalA7QUFBQUEsb0JBQ1AsVUFBVSxDQUFDeVgsTUFBTXhYLGtCQUFrQndYLEVBQUVDLE9BQU9oTixLQUFLO0FBQUEsb0JBQ2pELGFBQVk7QUFBQSxvQkFDWixNQUFNO0FBQUEsb0JBQ04sV0FBVTtBQUFBLG9CQUNWLFdBQVc7QUFBQSxvQkFDWCxXQUFTO0FBQUE7QUFBQSxrQkFQWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBT1c7QUFBQSxtQkFYYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBO0FBQUEsY0FHQzlLLGtCQUFrQjRKLFdBQVc1SixjQUFjLElBQUksS0FDOUMsdUJBQUMsU0FBSSxXQUFVLG9GQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEseUNBQUMsc0JBQW1CLFdBQVUsb0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThDO0FBQUEsa0JBQzlDLHVCQUFDLFVBQUssV0FBVSx1Q0FBc0Msb0NBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUseUJBQXdCLGdDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsVUFBSyxXQUFVLGtDQUFpQztBQUFBO0FBQUEsc0JBQzdDNEosV0FBVzVKLGNBQWMsRUFBRXFQLGVBQWUsT0FBTztBQUFBLHlCQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFPQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxvRUFDYjtBQUFBLDJDQUFDLFVBQUssV0FBVSx1Q0FBc0MsaUNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxVQUFLLFdBQVUsb0NBQW1DO0FBQUE7QUFBQSx3QkFHOUNuUCxpQkFBaUIsWUFDZEosYUFBYTJOLGVBQ2J2TixpQkFBaUIsWUFDZkosYUFBYTROLGVBQ2I1TixhQUFhMk4sZUFDZjNOLGFBQWE0TixnQkFDakI5RCxXQUFXNUosY0FBYyxHQUN6QnFQLGVBQWUsT0FBTztBQUFBLHlCQVYxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVdBO0FBQUEsdUJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFnQkE7QUFBQSxxQkF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkEwQkE7QUFBQSxtQkFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFrQ0E7QUFBQSxpQkF4R0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwR0E7QUFBQSxlQWpIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtIQTtBQUFBLFVBR0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsdUNBQUMsNkJBQTBCLFdBQVUsMEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJEO0FBQUEsZ0JBQzNELHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsZ0NBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdEO0FBQUEsbUJBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUVGLGFBQ0UsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSx1Q0FBQyxPQUFFLFdBQVUsUUFBTywyRkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsOEVBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxtQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVNBO0FBQUEsY0FFRixNQUFLO0FBQUEsY0FDTCxVQUFVO0FBQUEsY0FDVixXQUFVO0FBQUE7QUFBQSxZQXJCWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFxQmlEO0FBQUEsYUF4UG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwUEEsSUFFQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsb0ZBQ2IsaUNBQUMsa0JBQWUsV0FBVSw0QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0QsS0FEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLDZCQUE0QixpQ0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEQ7QUFBQSxVQUMxRCx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLG9EQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQTtBQUFBLE1BdlVKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXlVQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQ0UsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG1FQUNiLGlDQUFDLG1CQUFnQixXQUFVLDJCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRCxLQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHlCQUF3Qiw4QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0Q7QUFBQSxZQUN0RCx1QkFBQyxPQUFFLFdBQVUsNENBQTJDLHlFQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUVGLE1BQU0zTztBQUFBQSxRQUNOLFVBQVUsTUFBTUMsNkJBQTZCLEtBQUs7QUFBQSxRQUNsRCxPQUFPO0FBQUEsUUFDUCxRQUFRO0FBQUEsVUFDTjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBRUMsU0FBUyxNQUFNQSw2QkFBNkIsS0FBSztBQUFBLGNBQUU7QUFBQTtBQUFBLFlBRC9DO0FBQUEsWUFETjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxRQUFTO0FBQUEsUUFHVkcsbUNBQ0MsdUJBQUMsU0FBSSxXQUFVLG9CQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDBFQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNGO0FBQUEsVUFDdEYsdUJBQUMsT0FBRSxXQUFVLFFBQU8seUNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZDO0FBQUEsYUFGL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLElBQ0VGLGtCQUFrQnFRLFdBQVcsSUFDL0IsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG9GQUNiLGlDQUFDLG1CQUFnQixXQUFVLDRCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRCxLQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxPQUFFLFdBQVUsaUJBQWdCLHVDQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRDtBQUFBLGFBSnREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQSxJQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTO0FBQUEsY0FDUDtBQUFBLGdCQUNFeUMsT0FBTztBQUFBLGdCQUNQQyxXQUFXO0FBQUEsZ0JBQ1hqTCxLQUFLO0FBQUEsZ0JBQ0xrTCxRQUFRQSxDQUFDaE0sU0FBUzNMLE9BQU8yTCxJQUFJLEVBQUVHLE9BQU8scUJBQXFCO0FBQUEsZ0JBQzNEOEwsUUFBUUEsQ0FBQ25CLEdBQUd0RyxNQUFNLElBQUkyQyxLQUFLMkQsRUFBRTVLLFNBQVMsSUFBSSxJQUFJaUgsS0FBSzNDLEVBQUV0RSxTQUFTO0FBQUEsZ0JBQzlEZ00sa0JBQWtCO0FBQUEsY0FDcEI7QUFBQSxjQUNBO0FBQUEsZ0JBQ0VKLE9BQU87QUFBQSxnQkFDUEMsV0FBVztBQUFBLGdCQUNYakwsS0FBSztBQUFBLGdCQUNMcUwsT0FBTztBQUFBLGdCQUNQSCxRQUFRQSxDQUFDaFEsV0FDUCx1QkFBQyxVQUFLLFdBQVUsZ0NBQStCO0FBQUE7QUFBQSxrQkFDM0NBLE9BQU95TCxlQUFlLE9BQU87QUFBQSxxQkFEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVGd0UsUUFBUUEsQ0FBQ25CLEdBQUd0RyxNQUFNc0csRUFBRStILGdCQUFnQnJPLEVBQUVxTztBQUFBQSxjQUN4QztBQUFBLGNBQ0E7QUFBQSxnQkFDRS9HLE9BQU87QUFBQSxnQkFDUEMsV0FBVztBQUFBLGdCQUNYakwsS0FBSztBQUFBLGdCQUNMcUwsT0FBTztBQUFBLGdCQUNQSCxRQUFRQSxDQUFDaFEsV0FDUCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWU7QUFBQTtBQUFBLGtCQUMzQkEsT0FBT3lMLGVBQWUsT0FBTztBQUFBLHFCQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FFSjtBQUFBLGNBQ0E7QUFBQSxnQkFDRXFFLE9BQU87QUFBQSxnQkFDUEMsV0FBVztBQUFBLGdCQUNYakwsS0FBSztBQUFBLGdCQUNMcUwsT0FBTztBQUFBLGdCQUNQSCxRQUFRQSxDQUFDaFEsV0FDUCx1QkFBQyxVQUFLLFdBQVUsbUJBQWtCO0FBQUE7QUFBQSxrQkFDOUJBLE9BQU95TCxlQUFlLE9BQU87QUFBQSxxQkFEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGNBRUo7QUFBQSxjQUNBO0FBQUEsZ0JBQ0VxRSxPQUFPO0FBQUEsZ0JBQ1BDLFdBQVc7QUFBQSxnQkFDWGpMLEtBQUs7QUFBQSxnQkFDTGtMLFFBQVFBLENBQUM1VSxTQUNQO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQ0VBLFNBQVMsU0FDTCxXQUNBQSxTQUFTLFlBQ1AsUUFDQTtBQUFBLG9CQUdQQSxtQkFBUyxTQUNOLFNBQ0FBLFNBQVMsWUFDUCxpQkFDQTtBQUFBO0FBQUEsa0JBYlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWNBO0FBQUEsY0FFSjtBQUFBLGNBQ0E7QUFBQSxnQkFDRTBVLE9BQU87QUFBQSxnQkFDUEMsV0FBVztBQUFBLGdCQUNYakwsS0FBSztBQUFBLGdCQUNMZ1MsVUFBVTtBQUFBLGNBQ1o7QUFBQSxjQUNBO0FBQUEsZ0JBQ0VoSCxPQUFPO0FBQUEsZ0JBQ1BDLFdBQVc7QUFBQSxnQkFDWGpMLEtBQUs7QUFBQSxnQkFDTGtMLFFBQVFBLENBQUNtQixTQUFTQSxNQUFNNU0sYUFBYTtBQUFBLGNBQ3ZDO0FBQUEsWUFBQztBQUFBLFlBRUgsWUFBWXZIO0FBQUFBLFlBQ1osUUFBTztBQUFBLFlBQ1AsWUFBWSxFQUFFd1ksVUFBVSxHQUFHO0FBQUEsWUFDM0IsTUFBSztBQUFBO0FBQUEsVUFsRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBa0ZlO0FBQUE7QUFBQSxNQXpIbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBNEhBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FDRSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxpQ0FBQyxzQkFBbUIsV0FBVSx3QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Q7QUFBQSxVQUNsRCx1QkFBQyxVQUFLLFdBQVUseUJBQXdCLGtDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRDtBQUFBLGFBRjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBRUYsV0FBVTtBQUFBLFFBQ1YsU0FBUzVDO0FBQUFBLFFBQ1QsTUFBTWpaO0FBQUFBLFFBQ04sT0FBTztBQUFBLFFBR1A7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGNBQ2pELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxpQkFEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUE7QUFBQSxjQUFDLE1BQU07QUFBQSxjQUFOO0FBQUEsZ0JBQ0MsT0FBTytGO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ3VVLE1BQU10VSxlQUFlc1UsRUFBRUMsT0FBT2hOLEtBQUs7QUFBQSxnQkFDOUMsYUFBWTtBQUFBLGdCQUVaO0FBQUEseUNBQUMsTUFBTSxRQUFOLEVBQWEsT0FBTSxRQUFPLDRCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1QztBQUFBLGtCQUN2Qyx1QkFBQyxNQUFNLFFBQU4sRUFBYSxPQUFNLFFBQU8sNEJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVDO0FBQUE7QUFBQTtBQUFBLGNBTnpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU9BO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFHQ3hILGdCQUFnQixVQUNmLG1DQUNFO0FBQUEsbUNBQUMsU0FBSSxXQUFVLFFBQ2IsaUNBQUMsU0FBSSxXQUFVLDZFQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLHlCQUF3QixrQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUM7QUFBQSxjQUN6Qyx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsUUFBRyxXQUFVLHVDQUFzQywyQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSx5QkFBd0IsK0RBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsaUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWUE7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsZ0JBQ3hELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBRUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLGFBQVk7QUFBQSxrQkFDWixPQUFPckYsbUJBQW1COFg7QUFBQUEsa0JBQzFCLFVBQVViO0FBQUFBLGtCQUNWO0FBQUEsa0JBQ0EsU0FBU2pZO0FBQUFBLGtCQUNUO0FBQUEsa0JBQ0EsY0FBYyxDQUFDMGIsT0FBT0MsV0FDcEJBLFFBQVFqUSxPQUFPc08sWUFBWSxFQUFFQyxTQUFTeUIsTUFBTTFCLFlBQVksQ0FBQztBQUFBLGtCQUcxRDFELHVCQUFhaE07QUFBQUEsb0JBQUksQ0FBQ2lNLFVBQ2pCLHVCQUFDLE9BQU8sUUFBUCxFQUFnQyxPQUFPQSxNQUFNMUksT0FDM0MwSSxnQkFBTTdLLFNBRFc2SyxNQUFNMUksT0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBaUJBO0FBQUEsaUJBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdUJBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGdCQUNyRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUEsa0JBQ1osT0FBT3pNLHNCQUFzQjBYO0FBQUFBLGtCQUM3QixVQUFVVjtBQUFBQSxrQkFDVixVQUFVLENBQUNwWDtBQUFBQSxrQkFDWDtBQUFBLGtCQUNBLFNBQVNkO0FBQUFBLGtCQUNUO0FBQUEsa0JBQ0EsY0FBYyxDQUFDd2IsT0FBT0MsV0FDcEJBLFFBQVFqUSxPQUFPc08sWUFBWSxFQUFFQyxTQUFTeUIsTUFBTTFCLFlBQVksQ0FBQztBQUFBLGtCQUcxRHBDLDBCQUFnQnROO0FBQUFBLG9CQUFJLENBQUMyRSxhQUNwQix1QkFBQyxPQUFPLFFBQVAsRUFBbUMsT0FBT0EsU0FBU3BCLE9BQ2pEb0IsbUJBQVN2RCxTQURRdUQsU0FBU3BCLE9BQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBakJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWtCQTtBQUFBLGlCQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdCQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxnQkFDdkQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FFQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLE9BQU9yTSxrQkFBa0JzWDtBQUFBQSxrQkFDekIsVUFBVVI7QUFBQUEsa0JBQ1YsVUFBVSxDQUFDbFg7QUFBQUEsa0JBQ1g7QUFBQSxrQkFDQTtBQUFBLGtCQUNBLGNBQWMsQ0FBQ3NhLE9BQU9DLFdBQ3BCQSxRQUFRalEsT0FBT3NPLFlBQVksRUFBRUMsU0FBU3lCLE1BQU0xQixZQUFZLENBQUM7QUFBQSxrQkFHMURqQyx3QkFBY3pOO0FBQUFBLG9CQUFJLENBQUN5RixXQUNsQix1QkFBQyxPQUFPLFFBQVAsRUFBaUMsT0FBT0EsT0FBT2xDLE9BQzdDa0MsaUJBQU9yRSxTQURVcUUsT0FBT2xDLE9BQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWlCQTtBQUFBLGlCQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFDVixVQUFVLENBQUNyTTtBQUFBQSxrQkFDWCxTQUFTaVg7QUFBQUEsa0JBQXVCO0FBQUE7QUFBQSxnQkFKbEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxjQUVBLHVCQUFDLFVBQU8sU0FBU2Msd0JBQXdCLHNCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErQztBQUFBLGlCQVZqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVdBO0FBQUEsZUF6R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwR0E7QUFBQSxVQUlEbFQsZ0JBQWdCLFVBQ2YsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsb0ZBQ2I7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsNENBQTJDLHdDQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnRjtBQUFBLGNBQ2hGLHVCQUFDLE9BQUUsV0FBVSx5QkFBd0IsdUVBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRGO0FBQUEsaUJBRjlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUdBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxnQkFBUyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtIO0FBQUEsY0FDbEg7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsYUFBWTtBQUFBLGtCQUNaO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUNWLGNBQWMsQ0FBQ3FWLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUFTN0ssU0FBUyxFQUFFaUosWUFBWSxFQUFFQyxTQUFTeUIsTUFBTTFCLFlBQVksQ0FBQztBQUFBLGtCQUV2RSxPQUFPalQsa0JBQWtCK1I7QUFBQUEsa0JBQ3pCLFVBQVVoSztBQUFBQSxrQkFDVixNQUFLO0FBQUEsa0JBRUo3SCxnQkFBTXFEO0FBQUFBLG9CQUFJLENBQUN3TixTQUNWLHVCQUFDLE9BQU8sUUFBUCxFQUE2QixPQUFPQSxLQUFLck4sS0FDdkMsYUFBR3FOLEtBQUs1TSxTQUFTLE1BQU00TSxLQUFLM00sWUFBWSxNQUR2QjJNLEtBQUtyTixLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQWZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWdCQTtBQUFBLGlCQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1CQTtBQUFBLFlBR0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLGdCQUFZLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFBOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUg7QUFBQSxjQUNySDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsYUFBWTtBQUFBLGtCQUNaLFVBQVUsQ0FBQ29ELFVBQVU7QUFDbkIxQiwyQ0FBdUIwQixLQUFLO0FBQzVCckcsNEJBQVEsS0FBSztBQUFBLGtCQUNmO0FBQUEsa0JBQ0EsU0FBU0g7QUFBQUEsa0JBQ1QsT0FBT0k7QUFBQUEsa0JBQ1AsV0FBVTtBQUFBLGtCQUNWLE1BQUs7QUFBQSxrQkFFSk4scUJBQVdtRDtBQUFBQSxvQkFBSSxDQUFDNkMsYUFDZix1QkFBQyxPQUFPLFFBQVAsRUFBMkMsT0FBTyxRQUFRQSxTQUFTMUMsR0FBRyxJQUNwRSxhQUFHMEMsU0FBU3BDLE9BQU8sUUFBUW9DLFNBQVNuQyxXQUFXLE1BRDlCLFFBQVFtQyxTQUFTMUMsR0FBRyxJQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQWhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FpQkE7QUFBQSxpQkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQkE7QUFBQSxZQUdDaEQsb0JBQW9CdU0sU0FBUyxLQUM1Qix1QkFBQyxTQUFJLFdBQVUsMkNBQ1p2TSw4QkFBb0I2QyxJQUFJLENBQUNDLFNBQVM7QUFDakMsb0JBQU1tVCxVQUFVeE8saUJBQWlCM0UsSUFBSTtBQUNyQyxrQkFBSSxDQUFDbVQsUUFBUyxRQUFPO0FBQ3JCLG9CQUFNQyxVQUFVMUMsV0FBV3lDLFFBQVF0YixPQUFPO0FBQzFDLHFCQUNFLHVCQUFDLFNBQWUsV0FBVSw2REFDeEI7QUFBQSx1Q0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSx5Q0FBQyxTQUNDO0FBQUEsMkNBQUMsT0FBSSxPQUFNLFFBQU8sb0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXNCO0FBQUEsb0JBQ3RCLHVCQUFDLE9BQUUsV0FBVSxzQkFBc0JzYixrQkFBUTVOLFFBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdEO0FBQUEsdUJBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUscUNBQW9DLDJCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErRDtBQUFBLG9CQUMvRCx1QkFBQyxVQUFLLFdBQVcscUJBQXFCNk4sU0FBUzFLLFdBQVcsWUFDcEQsaUJBQ0EwSyxTQUFTMUssV0FBVyxhQUNsQixtQkFDQSxpQkFBaUIsSUFDbEIwSyxrQkFBUXRHLFFBTGY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFLb0I7QUFBQSx1QkFQdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFRQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxjQUViO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHlCQUF3Qix1QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNEM7QUFBQSxvQkFDNUMsdUJBQUMsT0FBRSxXQUFVLGtDQUFpQztBQUFBO0FBQUEsc0JBQUVxRyxRQUFRL04sUUFBUXlDLGVBQWUsT0FBTztBQUFBLHlCQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF3RjtBQUFBLHVCQUgxRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUlBO0FBQUEscUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBbUJBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHFDQUFvQywyQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLE9BQUUsV0FBVSxtQ0FBa0M7QUFBQTtBQUFBLHNCQUMzQ3NMLFFBQVFwTyxXQUFXOEMsZUFBZSxPQUFPO0FBQUEseUJBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU9BO0FBQUEsa0JBR0EsdUJBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHFDQUFvQyw2QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLE9BQUUsV0FBVSxvQ0FBbUM7QUFBQTtBQUFBLHNCQUM1Q3NMLFFBQVF0TyxhQUFhZ0QsZUFBZSxPQUFPO0FBQUEseUJBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU9BO0FBQUEsa0JBRUEsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHFDQUFvQywwQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLE9BQUUsV0FBVSwrQkFDVnNMLGtCQUFRdmIsV0FDTGlNLE1BQU0sR0FBRyxFQUFFLENBQUMsRUFDYkEsTUFBTSxHQUFHLEVBQ1R3TyxRQUFRLEVBQ1JDLEtBQUssR0FBRyxLQUxiO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTUE7QUFBQSx1QkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVdBO0FBQUEsa0JBRUEsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHFDQUFvQyx3QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLE9BQUUsV0FBVSwrQkFDVmEsa0JBQVF0YixTQUNMZ00sTUFBTSxHQUFHLEVBQUUsQ0FBQyxFQUNiQSxNQUFNLEdBQUcsRUFDVHdPLFFBQVEsRUFDUkMsS0FBSyxHQUFHLEtBTGI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFNQTtBQUFBLHVCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBV0E7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSwyQ0FBQyxPQUFFLFdBQVUscUNBQW9DLDBCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsT0FBRSxXQUFVLHNDQUFxQztBQUFBO0FBQUEsc0JBQzlDYSxRQUFRbk8sVUFBVTZDLGVBQWUsT0FBTztBQUFBLHlCQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFPQTtBQUFBLHFCQXJERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXNEQTtBQUFBLG1CQTNFUTdILE1BQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE0RUE7QUFBQSxZQUVKLENBQUMsS0FwRkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxRkE7QUFBQSxZQUlGLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsNENBQTJDLG1DQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyRTtBQUFBLGNBQzNFLHVCQUFDLFNBQUksV0FBVSxhQUNaOUQseUJBQWU2RDtBQUFBQSxnQkFBSSxDQUFDeVMsUUFBUXhQLFVBQzNCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUVDLFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxhQUFZO0FBQUEsMEJBQ1osT0FBT3dQLE9BQU9wVztBQUFBQSwwQkFDZCxLQUFLO0FBQUEsMEJBQ0wsVUFBVSxDQUFDaVUsTUFDVGpOLG9CQUFvQkosT0FBTyxVQUFVcU4sRUFBRUMsT0FBT2hOLEtBQUs7QUFBQSwwQkFFckQsUUFBTztBQUFBLDBCQUNQLFdBQVU7QUFBQTtBQUFBLHdCQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFTa0IsS0FWcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFZQTtBQUFBLHNCQUVBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxhQUFZO0FBQUEsMEJBQ1osT0FBT2tQLE9BQU9uVztBQUFBQSwwQkFDZCxVQUFVLENBQUNnVSxNQUNUak4sb0JBQW9CSixPQUFPLFVBQVVxTixFQUFFQyxPQUFPaE4sS0FBSztBQUFBLDBCQUVyRCxXQUFVO0FBQUE7QUFBQSx3QkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTWtCLEtBUHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBU0E7QUFBQSxzQkFFQ3BILGVBQWV1TixTQUFTLEtBQ3ZCO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDO0FBQUEsMEJBQ0EsTUFBSztBQUFBLDBCQUNMLFdBQVU7QUFBQSwwQkFDVixTQUFTLE1BQU0xRyx1QkFBdUJDLEtBQUs7QUFBQSwwQkFBRTtBQUFBO0FBQUEsd0JBSi9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFPQTtBQUFBO0FBQUE7QUFBQSxrQkFwQ0dBO0FBQUFBLGtCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBdUNBO0FBQUEsY0FDRCxLQTFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTJDQTtBQUFBLGNBQ0M5RyxlQUFlNkgsS0FBSyxDQUFBQyxNQUFLQSxFQUFFNUgsTUFBTSxLQUNoQyx1QkFBQyxTQUFJLFdBQVUscURBQW9EO0FBQUE7QUFBQSxnQkFDeERGLGVBQWUyUCxPQUFPLENBQUNtSCxHQUFHaFAsTUFBTWdQLElBQUk3TyxPQUFPSCxFQUFFNUgsVUFBVSxDQUFDLEdBQUcsQ0FBQyxFQUFFeUwsZUFBZSxPQUFPO0FBQUEsbUJBRC9GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFqREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFzREE7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSx3Q0FDYjtBQUFBLHFDQUFDLFVBQU8sU0FBU21ILHdCQUF3QixzQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0M7QUFBQSxjQUMvQyx1QkFBQyxVQUFPLE1BQUssV0FBVSxTQUFTMVMsZ0JBQWdCLFNBQVNrSCxxQkFBcUIsb0NBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUE1TUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2TUE7QUFBQTtBQUFBO0FBQUEsTUExVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBNFZBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTztBQUFBLFFBQ1AsV0FBVTtBQUFBLFFBQ1YsU0FBUyxNQUFNO0FBQ2J0TiwrQkFBcUIsSUFBSTtBQUN6QkUsOEJBQW9CLEVBQUU7QUFDdEJFLDhCQUFvQixFQUFFO0FBQUEsUUFDeEI7QUFBQSxRQUNBLE1BQU0sQ0FBQyxDQUFDTDtBQUFBQSxRQUNSLE9BQU87QUFBQSxRQUNQLFVBQVU7QUFBQSxRQUVUQSwrQkFDQyx1QkFBQyxTQUFJLFdBQVUsc0VBRWI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUseUZBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsbUNBQUMsU0FDQztBQUFBLHFDQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSx3Q0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRDtBQUFBLGdCQUNwRCx1QkFBQyxTQUFNLE9BQU8sR0FBRyxXQUFVLG1CQUFrQixrQ0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBLHVCQUFDLFFBQUssV0FBVSwwQkFBeUIsdUVBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBTSx1QkFBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQjtBQUFBLGtCQUN0QixTQUFTaVU7QUFBQUEsa0JBQ1QsV0FBVTtBQUFBLGtCQUEyRTtBQUFBO0FBQUEsZ0JBSHZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU1BO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQztBQUFBLGtCQUNBLE1BQU0sdUJBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0I7QUFBQSxrQkFDeEIsU0FBUyxNQUFNO0FBQ2JoVSx5Q0FBcUIsSUFBSTtBQUN6QkUsd0NBQW9CLEVBQUU7QUFDdEJFLHdDQUFvQixFQUFFO0FBQUEsa0JBQ3hCO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUFrRTtBQUFBO0FBQUEsZ0JBUjlFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVdBO0FBQUEsaUJBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0JBO0FBQUEsZUFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQ0EsS0FsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQ0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxnREFFYjtBQUFBLG1DQUFDLFNBQUksV0FBVSw2RUFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxtRkFDYixpQ0FBQyxTQUFNLE9BQU8sR0FBRyxXQUFVLGdDQUN6QjtBQUFBLHVDQUFDLGdCQUFhLFdBQVUsbUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVDO0FBQUEsZ0JBQUc7QUFBQSxtQkFENUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxPQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLG1FQUNiLGlDQUFDLGdCQUFhLFdBQVUsMkJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQStDLEtBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLFdBQVU7QUFBQSwwQkFBdUM7QUFBQTtBQUFBLHdCQUZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBS0E7QUFBQSxzQkFDQSx1QkFBQyxRQUFLLFFBQU0sTUFBQyxXQUFVLGFBQ3BCTCw0QkFBa0I0UCxZQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFVQTtBQUFBLHVCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBZUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsb0VBQ2IsaUNBQUMsaUJBQWMsV0FBVSw0QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUQsS0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsV0FBVTtBQUFBLDBCQUF1QztBQUFBO0FBQUEsd0JBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFLQTtBQUFBLHNCQUNBLHVCQUFDLFFBQUssUUFBTSxNQUFDLFdBQVUsYUFDcEI1UCw0QkFBa0I2UCxhQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFVQTtBQUFBLHVCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBZUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUscUVBQ2IsaUNBQUMsZ0JBQWEsV0FBVSw2QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUQsS0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsV0FBVTtBQUFBLDBCQUF1QztBQUFBO0FBQUEsd0JBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFLQTtBQUFBLHNCQUNBLHVCQUFDLFFBQUssUUFBTSxNQUFDLFdBQVUsYUFDcEI3UCw0QkFBa0I4UCxhQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFVQTtBQUFBLHVCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBZUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUscUVBQ2IsaUNBQUMsc0JBQW1CLFdBQVUsNkJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXVELEtBRHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLFdBQVU7QUFBQSwwQkFBdUM7QUFBQTtBQUFBLHdCQUZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBS0E7QUFBQSxzQkFDQSx1QkFBQyxRQUFLLFFBQU0sTUFBQyxXQUFVLGFBQ3BCOVAsNEJBQWtCa1Usa0JBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVVBO0FBQUEsdUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFlQTtBQUFBLHFCQWhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlFQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSw0RUFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSwwRkFDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxXQUFVO0FBQUEsd0JBQXVDO0FBQUE7QUFBQSxzQkFGbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGtDQUNiO0FBQUEsNkNBQUMsVUFBSyxXQUFVLHFDQUFvQyxpQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLFVBQUssV0FBVSxzQ0FFWmxVLDZCQUFrQmtSLGtCQUNsQmxSLGtCQUFrQm1QLFdBQ2xCLEdBQ0F5QyxlQUFlLE9BQU8sS0FMMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFNQTtBQUFBLHlCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBV0E7QUFBQSx1QkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFtQkE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsaUZBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsV0FBVTtBQUFBLHdCQUF1QztBQUFBO0FBQUEsc0JBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSxrQ0FDYjtBQUFBLDZDQUFDLFVBQUssV0FBVSxrQ0FBaUMsaUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQSx1QkFBQyxVQUFLLFdBQVUsbUNBQ1o1Uiw2QkFBa0JnUSxnQkFBZ0IsR0FBRzRCO0FBQUFBLHdCQUNyQztBQUFBLHNCQUNGLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFJQTtBQUFBLHlCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBU0E7QUFBQSx1QkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFpQkE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsaUZBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsV0FBVTtBQUFBLHdCQUF1QztBQUFBO0FBQUEsc0JBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSxrQ0FDYjtBQUFBLDZDQUFDLFVBQUssV0FBVSxrQ0FBaUMsaUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQSx1QkFBQyxVQUFLLFdBQVUsbUNBQ1o1Uiw2QkFBa0JpUSxnQkFBZ0IsR0FBRzJCO0FBQUFBLHdCQUNyQztBQUFBLHNCQUNGLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFJQTtBQUFBLHlCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBU0E7QUFBQSx1QkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFpQkE7QUFBQSxxQkF4REY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF5REE7QUFBQSxtQkE5SEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkErSEE7QUFBQSxpQkF0SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1SUE7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSw2RUFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxtRkFDYixpQ0FBQyxTQUFNLE9BQU8sR0FBRyxXQUFVLGdDQUN6QjtBQUFBLHVDQUFDLGdCQUFhLFdBQVUscUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlDO0FBQUEsZ0JBQUc7QUFBQSxtQkFEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxPQUNiLGlDQUFDLFNBQUksV0FBVSx5Q0FFYjtBQUFBLHVDQUFDLFNBQ0M7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsMEVBQ2Y7QUFBQSwyQ0FBQyxrQkFBZSxXQUFVLHFCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUEyQztBQUFBLG9CQUFHO0FBQUEsdUJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsT0FBTzFSO0FBQUFBLHNCQUNQLFVBQVUsQ0FBQ2thLE1BQU1qYSxvQkFBb0JpYSxFQUFFQyxPQUFPaE4sS0FBSztBQUFBLHNCQUNuRCxhQUFZO0FBQUEsc0JBQ1osS0FBSztBQUFBLHNCQUNMLE1BQU07QUFBQSxzQkFDTixNQUFLO0FBQUEsc0JBQ0wsUUFBTztBQUFBLHNCQUNQLFdBQVU7QUFBQTtBQUFBLG9CQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFTc0Y7QUFBQSxrQkFFdEYsdUJBQUMsU0FBSSxXQUFVLDZEQUNiO0FBQUEsMkNBQUMsUUFBSyxNQUFLLGFBQVksV0FBVSxXQUFVLDBDQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsNkNBQUMsVUFBSyxXQUFVLHlDQUF3QyxpQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLFVBQUssV0FBVSx1Q0FFWnJOLDZCQUFrQmdRLGdCQUNqQjdELFdBQVdqTSxnQkFBZ0IsS0FBSyxJQUNqQzBSLGVBQWUsT0FBTyxLQUoxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUtBO0FBQUEseUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFVQTtBQUFBLHVCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBZUE7QUFBQSxxQkEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFnQ0E7QUFBQSxnQkFHQSx1QkFBQyxTQUNDO0FBQUEseUNBQUMsV0FBTSxXQUFVLDBFQUNmO0FBQUEsMkNBQUMsdUJBQW9CLFdBQVUsa0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTZDO0FBQUEsb0JBQUc7QUFBQSx1QkFEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxPQUFPeFI7QUFBQUEsc0JBQ1AsVUFBVSxDQUFDZ2EsTUFBTS9aLG9CQUFvQitaLEVBQUVDLE9BQU9oTixLQUFLO0FBQUEsc0JBQ25ELGFBQVk7QUFBQSxzQkFDWixLQUFLO0FBQUEsc0JBQ0wsTUFBTTtBQUFBLHNCQUNOLE1BQUs7QUFBQSxzQkFDTCxRQUFPO0FBQUEsc0JBQ1AsV0FBVTtBQUFBO0FBQUEsb0JBVFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVNnRjtBQUFBLGtCQUVoRix1QkFBQyxTQUFJLFdBQVUsdURBQ2I7QUFBQSwyQ0FBQyxRQUFLLE1BQUssYUFBWSxXQUFVLFdBQVUsMkNBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSw2Q0FBQyxVQUFLLFdBQVUsc0NBQXFDLGlCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsVUFBSyxXQUFVLG9DQUVack4sNkJBQWtCaVEsZ0JBQ2pCOUQsV0FBVy9MLGdCQUFnQixLQUFLLElBQ2pDd1IsZUFBZSxPQUFPLEtBSjFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBS0E7QUFBQSx5QkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVVBO0FBQUEsdUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFlQTtBQUFBLHFCQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWdDQTtBQUFBLG1CQXJFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNFQSxLQXZFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXdFQTtBQUFBLGlCQS9FRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdGQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLHlHQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDREQUNiLGlDQUFDLFNBQU0sT0FBTyxHQUFHLFdBQVUsZ0NBQ3pCO0FBQUEsdUNBQUMsc0JBQW1CLFdBQVUscUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStDO0FBQUEsZ0JBQUc7QUFBQSxtQkFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxPQUNiLGlDQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxpREFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxXQUFVO0FBQUEsc0JBQXVDO0FBQUE7QUFBQSxvQkFGbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsbUNBQWtDLGlCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsVUFBSyxXQUFVLG9DQUVaNVIsNkJBQWtCa1Isa0JBQ2xCbFIsa0JBQWtCbVAsV0FDbEIsR0FDQXlDLGVBQWUsT0FBTyxLQUwxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU1BO0FBQUEsdUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFXQTtBQUFBLHFCQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW1CQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxpREFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxXQUFVO0FBQUEsc0JBQXVDO0FBQUE7QUFBQSxvQkFGbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsa0NBQWlDLGlCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsVUFBSyxXQUFVLG1DQUVYekYsdUJBQVdqTSxnQkFBZ0IsS0FBSyxNQUNoQ2lNLFdBQVcvTCxnQkFBZ0IsS0FBSyxJQUNqQ3dSLGVBQWUsT0FBTyxLQUoxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsdUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFVQTtBQUFBLHFCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWtCQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxpSkFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxXQUFVO0FBQUEsc0JBQXFEO0FBQUE7QUFBQSxvQkFGakU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsZ0NBQStCLGlCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnRDtBQUFBLG9CQUNoRCx1QkFBQyxVQUFLLFdBQVUsaUNBRVg1Uiw4QkFBa0JrUixrQkFDakJsUixrQkFBa0JtUCxXQUNsQixNQUNEaEQsV0FBV2pNLGdCQUFnQixLQUFLLE1BQ2hDaU0sV0FBVy9MLGdCQUFnQixLQUFLLElBQ2pDd1IsZUFBZSxPQUFPLEtBUDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBUUE7QUFBQSx1QkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVdBO0FBQUEscUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBbUJBO0FBQUEsbUJBM0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNERBLEtBN0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBOERBO0FBQUEsaUJBckVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0VBO0FBQUEsWUFHQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEseUNBQUMsNkJBQTBCLFdBQVUsNkJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThEO0FBQUEsa0JBQzlELHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsZ0NBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdEO0FBQUEscUJBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFFRixhQUNFLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLFFBQU8seUZBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLDBGQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEscUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFTQTtBQUFBLGdCQUVGLE1BQUs7QUFBQSxnQkFDTCxVQUFVO0FBQUEsZ0JBQ1YsV0FBVTtBQUFBO0FBQUEsY0FyQlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBcUI0RDtBQUFBLFlBSTVELHVCQUFDLFNBQUksV0FBVSx1RUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsU0FBUyxNQUFNO0FBQ2IzUix5Q0FBcUIsSUFBSTtBQUN6QkUsd0NBQW9CLEVBQUU7QUFDdEJFLHdDQUFvQixFQUFFO0FBQUEsa0JBQ3hCO0FBQUEsa0JBQUU7QUFBQTtBQUFBLGdCQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLFdBQVcsdUNBQXVDQyxxQkFDL0MsQ0FBQ0osb0JBQW9CLENBQUNFLG1CQUNyQixrQ0FDQSxzRkFBc0Y7QUFBQSxrQkFFMUYsVUFDRUUscUJBQ0MsQ0FBQ0osb0JBQW9CLENBQUNFO0FBQUFBLGtCQUV6QixTQUFTZ1k7QUFBQUEsa0JBQ1QsU0FBUzlYO0FBQUFBLGtCQUNULE1BQU0sdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBYTtBQUFBLGtCQUFJO0FBQUE7QUFBQSxnQkFkekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBaUJBO0FBQUEsaUJBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOEJBO0FBQUEsZUEvVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnV0E7QUFBQSxhQXZZRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd1lBO0FBQUE7QUFBQSxNQXJaSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF1WkE7QUFBQSxPQTN6RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTR6RkE7QUFFSjtBQUFDekIsR0ExdkpRRCxtQkFBaUI7QUFBQXdlLEtBQWpCeGU7QUE0dkpULGVBQWVBO0FBQWtCLElBQUF3ZTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VNZW1vIiwidXNlUmVmIiwidXNlQ2FsbGJhY2siLCJOYXZiYXIiLCJTaWRlYmFyIiwiQnV0dG9uIiwiRHJhd2VyIiwiQWxlcnQiLCJTZWxlY3QiLCJJbnB1dCIsIlR5cG9ncmFwaHkiLCJNb2RhbCIsIkFudE1vZGFsIiwiVGFibGUiLCJQb3Bjb25maXJtIiwiVGFnIiwiU3BhY2UiLCJCYWRnZSIsIkNhcmQiLCJSb3ciLCJDb2wiLCJDaGVja2JveCIsIkRhdGVQaWNrZXIiLCJSYWRpbyIsIm1lc3NhZ2UiLCJTcGluIiwiQ2FsY3VsYXRvck91dGxpbmVkIiwiQXJyb3dMZWZ0T3V0bGluZWQiLCJDaGVja0NpcmNsZU91dGxpbmVkIiwiSW5mb0NpcmNsZU91dGxpbmVkIiwiQ2xvc2VDaXJjbGVPdXRsaW5lZCIsIkZpbGVUZXh0T3V0bGluZWQiLCJSZWxvYWRPdXRsaW5lZCIsIkFycm93RG93bk91dGxpbmVkIiwiQ2FsZW5kYXJPdXRsaW5lZCIsIkV5ZU91dGxpbmVkIiwiRGVsZXRlT3V0bGluZWQiLCJIaXN0b3J5T3V0bGluZWQiLCJXYWxsZXRPdXRsaW5lZCIsIlVzZXJPdXRsaW5lZCIsIlBob25lT3V0bGluZWQiLCJUZWFtT3V0bGluZWQiLCJDcmVkaXRDYXJkT3V0bGluZWQiLCJFZGl0T3V0bGluZWQiLCJEb2xsYXJPdXRsaW5lZCIsIkNsb2NrQ2lyY2xlT3V0bGluZWQiLCJFeGNsYW1hdGlvbkNpcmNsZU91dGxpbmVkIiwiU2F2ZU91dGxpbmVkIiwiR2lmdE91dGxpbmVkIiwiZGF5anMiLCJhcGkiLCJDdXN0b21BbGVydCIsIkRhdGFUYWJsZSIsIkRyb3Bkb3duIiwiSW9NZE1vcmUiLCJGYUV5ZSIsIkZhTW9uZXlCaWxsV2F2ZSIsIkZhUnVwZWVTaWduIiwibW9tZW50IiwiVmlld0ljb24iLCJUaXRsZSIsIlRleHQiLCJQZW5hbHR5TWFuYWdlbWVudCIsIl9zIiwiZ3JvdXBzIiwic2V0R3JvdXBzIiwiZW5yb2xsZWRVc2VycyIsInNldEVucm9sbGVkVXNlcnMiLCJkdWVDdXN0b21lcnMiLCJzZXREdWVDdXN0b21lcnMiLCJwZW5hbHRpZXMiLCJzZXRQZW5hbHRpZXMiLCJ0YWJsZURhdGEiLCJzZXRUYWJsZURhdGEiLCJpc0xvYWRpbmdHcm91cHMiLCJzZXRJc0xvYWRpbmdHcm91cHMiLCJpc0xvYWRpbmdVc2VycyIsInNldElzTG9hZGluZ1VzZXJzIiwiaXNMb2FkaW5nUGVuYWx0aWVzIiwic2V0SXNMb2FkaW5nUGVuYWx0aWVzIiwiYWRkUGVuYWx0eURyYXdlck9wZW4iLCJzZXRBZGRQZW5hbHR5RHJhd2VyT3BlbiIsImFkZFBlbmFsdHlEZXRhaWxzIiwic2V0QWRkUGVuYWx0eURldGFpbHMiLCJhZGRQZW5hbHR5QW1vdW50Iiwic2V0QWRkUGVuYWx0eUFtb3VudCIsImFkZExhdGVGZWVBbW91bnQiLCJzZXRBZGRMYXRlRmVlQW1vdW50IiwiYWRkUGVuYWx0eUxvYWRpbmciLCJzZXRBZGRQZW5hbHR5TG9hZGluZyIsInNlbGVjdGVkR3JvdXBJZCIsInNldFNlbGVjdGVkR3JvdXBJZCIsInNlbGVjdGVkR3JvdXBOYW1lIiwic2V0U2VsZWN0ZWRHcm91cE5hbWUiLCJzZWxlY3RlZEN1c3RvbWVySWQiLCJzZXRTZWxlY3RlZEN1c3RvbWVySWQiLCJzZWxlY3RlZEN1c3RvbWVyTmFtZSIsInNldFNlbGVjdGVkQ3VzdG9tZXJOYW1lIiwic2VsZWN0ZWRUaWNrZXQiLCJzZXRTZWxlY3RlZFRpY2tldCIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJ0eXBlIiwicGVuYWx0eUZpbHRlcnMiLCJzZXRQZW5hbHR5RmlsdGVycyIsImdyb3VwSWQiLCJzdGFydERhdGUiLCJlbmREYXRlIiwic3RhdGVtZW50TW9kYWxWaXNpYmxlIiwic2V0U3RhdGVtZW50TW9kYWxWaXNpYmxlIiwic3RhdGVtZW50RGF0YSIsInNldFN0YXRlbWVudERhdGEiLCJpc0xvYWRpbmdTdGF0ZW1lbnQiLCJzZXRJc0xvYWRpbmdTdGF0ZW1lbnQiLCJ3YWl2ZU9mZk1vZGFsVmlzaWJsZSIsInNldFdhaXZlT2ZmTW9kYWxWaXNpYmxlIiwid2FpdmVPZmZEYXRhIiwic2V0V2FpdmVPZmZEYXRhIiwid2FpdmVPZmZBbW91bnQiLCJzZXRXYWl2ZU9mZkFtb3VudCIsIndhaXZlT2ZmVHlwZSIsInNldFdhaXZlT2ZmVHlwZSIsIndhaXZlT2ZmUmVhc29uIiwic2V0V2FpdmVPZmZSZWFzb24iLCJpc1dhaXZpbmdPZmYiLCJzZXRJc1dhaXZpbmdPZmYiLCJzZWxlY3RlZEN1c3RvbWVyRm9yV2FpdmUiLCJzZXRTZWxlY3RlZEN1c3RvbWVyRm9yV2FpdmUiLCJ3YWl2ZXJIaXN0b3J5TW9kYWxWaXNpYmxlIiwic2V0V2FpdmVySGlzdG9yeU1vZGFsVmlzaWJsZSIsIndhaXZlckhpc3RvcnlEYXRhIiwic2V0V2FpdmVySGlzdG9yeURhdGEiLCJpc0xvYWRpbmdXYWl2ZXJIaXN0b3J5Iiwic2V0SXNMb2FkaW5nV2FpdmVySGlzdG9yeSIsImJhdGNoV2FpdmVNb2RhbFZpc2libGUiLCJzZXRCYXRjaFdhaXZlTW9kYWxWaXNpYmxlIiwiY3VzdG9tZXJzV2l0aFBlbmFsdGllcyIsInNldEN1c3RvbWVyc1dpdGhQZW5hbHRpZXMiLCJzZWxlY3RlZEN1c3RvbWVycyIsInNldFNlbGVjdGVkQ3VzdG9tZXJzIiwiYmF0Y2hXYWl2ZUFtb3VudCIsInNldEJhdGNoV2FpdmVBbW91bnQiLCJiYXRjaFdhaXZlVHlwZSIsInNldEJhdGNoV2FpdmVUeXBlIiwiYmF0Y2hXYWl2ZVJlYXNvbiIsInNldEJhdGNoV2FpdmVSZWFzb24iLCJpc0JhdGNoV2FpdmluZyIsInNldElzQmF0Y2hXYWl2aW5nIiwiaXNMb2FkaW5nQ3VzdG9tZXJzIiwic2V0SXNMb2FkaW5nQ3VzdG9tZXJzIiwicGVuYWx0eUhpc3RvcnlNb2RhbFZpc2libGUiLCJzZXRQZW5hbHR5SGlzdG9yeU1vZGFsVmlzaWJsZSIsInBlbmFsdHlIaXN0b3J5RGF0YSIsInNldFBlbmFsdHlIaXN0b3J5RGF0YSIsImlzTG9hZGluZ1BlbmFsdHlIaXN0b3J5Iiwic2V0SXNMb2FkaW5nUGVuYWx0eUhpc3RvcnkiLCJzZWxlY3RlZFBlbmFsdHlDdXN0b21lciIsInNldFNlbGVjdGVkUGVuYWx0eUN1c3RvbWVyIiwiZWRpdE1vZGFsVmlzaWJsZSIsInNldEVkaXRNb2RhbFZpc2libGUiLCJlZGl0aW5nUGVuYWx0eSIsInNldEVkaXRpbmdQZW5hbHR5IiwiZWRpdFBlbmFsdHlBbW91bnQiLCJzZXRFZGl0UGVuYWx0eUFtb3VudCIsImVkaXRMYXRlRmVlQW1vdW50Iiwic2V0RWRpdExhdGVGZWVBbW91bnQiLCJlZGl0UmVhc29uIiwic2V0RWRpdFJlYXNvbiIsImlzVXBkYXRpbmdQZW5hbHR5Iiwic2V0SXNVcGRhdGluZ1BlbmFsdHkiLCJlZGl0RGF0ZSIsInNldEVkaXREYXRlIiwicGVuYWx0eVR5cGUiLCJzZXRQZW5hbHR5VHlwZSIsInBlbmFsdHlMb2FuIiwic2V0UGVuYWx0eUxvYW4iLCJwZW5hbHR5Q2hhcmdlcyIsInNldFBlbmFsdHlDaGFyZ2VzIiwiYW1vdW50IiwicmVhc29uIiwicGVuYWx0eUxvYWRpbmciLCJzZXRQZW5hbHR5TG9hZGluZyIsInNlbGVjdGVkVXNlcklkIiwic2V0U2VsZWN0ZWRVc2VySWQiLCJ1c2VycyIsInNldFVzZXJzIiwiYm9ycm93ZXJzIiwic2V0Qm9ycm93ZXJzIiwiZW5yb2xsbWVudExvYWRpbmciLCJzZXRFbnJvbGxtZW50TG9hZGluZyIsIm9wZW4iLCJzZXRPcGVuIiwicGF5bWVudEdyb3VwVGlja2V0cyIsInNldFBheW1lbnRHcm91cFRpY2tldHMiLCJmaWx0ZXJlZEVucm9sbG1lbnRzIiwic2V0RmlsdGVyZWRFbnJvbGxtZW50cyIsImZpbHRlcmVkVXNlcnMiLCJzZXRGaWx0ZXJlZFVzZXJzIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInJlbWFya3MiLCJ1c2VyX2lkIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJpc0ZldGNoaW5nUmVmIiwiYWN0aXZlUGVuYWx0eVZpZXciLCJzZXRBY3RpdmVQZW5hbHR5VmlldyIsImxvYW5QZW5hbHRpZXMiLCJzZXRMb2FuUGVuYWx0aWVzIiwibG9hblRhYmxlRGF0YSIsInNldExvYW5UYWJsZURhdGEiLCJpc0xvYWRpbmdMb2FuUGVuYWx0aWVzIiwic2V0SXNMb2FkaW5nTG9hblBlbmFsdGllcyIsImVkaXRMb2FuTW9kYWxWaXNpYmxlIiwic2V0RWRpdExvYW5Nb2RhbFZpc2libGUiLCJlZGl0aW5nTG9hblBlbmFsdHkiLCJzZXRFZGl0aW5nTG9hblBlbmFsdHkiLCJlZGl0TG9hbkFtb3VudCIsInNldEVkaXRMb2FuQW1vdW50IiwiZWRpdExvYW5SZWFzb24iLCJzZXRFZGl0TG9hblJlYXNvbiIsImlzVXBkYXRpbmdMb2FuUGVuYWx0eSIsInNldElzVXBkYXRpbmdMb2FuUGVuYWx0eSIsInNob3dQZW5hbHR5TW9kYWwiLCJzZXRTaG93UGVuYWx0eU1vZGFsIiwiZmV0Y2hHcm91cHMiLCJmZXRjaER1ZUN1c3RvbWVycyIsImZldGNoTG9hblBlbmFsdGllcyIsInJlc3BvbnNlIiwiZ2V0IiwicmF3RGF0YSIsIkFycmF5IiwiaXNBcnJheSIsImRhdGEiLCJmb3JtYXR0ZWQiLCJtYXAiLCJpdGVtIiwiaWR4IiwiX2lkIiwiaWQiLCJkYXRlIiwicGVuYWx0eV9kYXRlIiwiY3JlYXRlZEF0IiwiZm9ybWF0IiwibG9hbl9pZCIsImxvYW5fYW1vdW50IiwiY3VzdG9tZXJfbmFtZSIsImZ1bGxfbmFtZSIsInBob25lX251bWJlciIsInBlbmFsdHlfYW1vdW50IiwidG90YWxfYW1vdW50IiwicmF3X3BlbmFsdHkiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImxhYmVsIiwib25DbGljayIsImhhbmRsZVZpZXdMb2FuUGVuYWx0eSIsImhhbmRsZUVkaXRMb2FuUGVuYWx0eSIsImhhbmRsZURlbGV0ZUxvYW5QZW5hbHR5IiwiZXJyb3IiLCJjb25zb2xlIiwiZmV0Y2hQZW5hbHRpZXMiLCJmZXRjaEFsbEN1c3RvbWVycyIsImhhbmRsZVBheW1lbnRBbnRTZWxlY3QiLCJ2YWx1ZXMiLCJ0aW1lb3V0SWQiLCJzZXRUaW1lb3V0IiwiY3VycmVudCIsImNsZWFyVGltZW91dCIsInBlbmFsdHlJdGVtIiwiaGFuZGxlVXBkYXRlTG9hblBlbmFsdHkiLCJwYXJzZUZsb2F0Iiwid2FybmluZyIsInB1dCIsInBlbmFsdHlBbW91bnQiLCJzdWNjZXNzIiwicGVuYWx0eUlkIiwiZGVsZXRlIiwiaGFuZGxlUGVuYWx0eU1vZGFsT3BlbiIsImJvcnJvd2VyIiwiaGFuZGxlQWRkUGVuYWx0eVJvdyIsInByZXYiLCJoYW5kbGVSZW1vdmVQZW5hbHR5Um93IiwiaW5kZXgiLCJmaWx0ZXIiLCJfIiwiaSIsImhhbmRsZVBlbmFsdHlDaGFuZ2UiLCJmaWVsZCIsInZhbHVlIiwicm93IiwiaGFuZGxlUGVuYWx0eVN1Ym1pdCIsImxvYW5JdGVtIiwiZmluZCIsInN0YXJ0c1dpdGgiLCJsb2FuSWQiLCJzcGxpdCIsImludmFsaWQiLCJzb21lIiwiYyIsInRyaW0iLCJuZXdDaGFyZ2VzIiwiTnVtYmVyIiwicGFpZCIsInBvc3QiLCJ1c2VySWQiLCJoYW5kbGVDdXN0b21lciIsInByZXZGb3JtRGF0YSIsInByZXZEYXRhIiwiY3VzdG9tZXIiLCJnZXRUaWNrZXREZXRhaWxzIiwiYiIsImRhaWx5UGF5bWVudCIsImRhaWx5X3BheW1lbnRfYW1vdW50IiwibG9hbkFtb3VudCIsInRvdGFsUGFpZCIsInRvdGFsX3BheW1lbnRzIiwic3RhcnRfZGF0ZSIsImVuZF9kYXRlIiwiYmFsYW5jZSIsInJlbWFpbmluZ19sb2FuIiwidG90YWxMb2FuIiwibmFtZSIsInRpY2tldCIsInByb2ZpdCIsImF1Y3Rpb25Db3VudCIsImR1ZUN1c3RvbWVyc0RhdGEiLCJ0cmFuc2Zvcm1lZFVzZXJzIiwidXNlck5hbWUiLCJ1c2VyUGhvbmUiLCJncm91cE5hbWUiLCJkdWVBbW91bnQiLCJ0b3RhbFBlbmFsdHkiLCJ0b3RhbExhdGVGZWUiLCJlbnJvbGxtZW50SWQiLCJsb2ciLCJwYXJhbXMiLCJVUkxTZWFyY2hQYXJhbXMiLCJhcHBlbmQiLCJ0b1N0cmluZyIsInBlbmFsdGllc0RhdGEiLCJmb3JtYXR0ZWREYXRhIiwicGVuYWx0eSIsInRvdGFsRHVlIiwiY3VycmVudF9iYWxhbmNlIiwidG90YWxfcGFpZCIsInRvdGFsUGVuYWx0eVN1bSIsInRvdGFsX3BlbmFsdHlfc3VtIiwidG90YWxMYXRlRmVlU3VtIiwidG90YWxfbGF0ZV9mZWVfc3VtIiwiY3VycmVudEJhbGFuY2UiLCJwZW5hbHR5UGx1c0R1ZSIsImdldERpc3BsYXlEYXRlIiwicGVuYWx0eURhdGUiLCJEYXRlIiwiY3JlYXRlZERhdGUiLCJnZXRUaW1lIiwiZ3JvdXBfbmFtZSIsImdyb3VwX2lkIiwiYmFsYW5jZV9yYXciLCJ0b0xvY2FsZVN0cmluZyIsImJhbGFuY2Vfc3RhdHVzIiwidG90YWxfcGFpZF9yYXciLCJwZW5hbHR5X3BsdXNfZHVlX3JhdyIsInBlbmFsdHlfcGx1c19kdWUiLCJwZW5hbHR5X2Ftb3VudF9yYXciLCJsYXRlX2ZlZV9hbW91bnRfcmF3IiwibGF0ZV9mZWVfYW1vdW50IiwidG90YWxfYW1vdW50X3JhdyIsImhhbmRsZVZpZXdTdGF0ZW1lbnQiLCJoYW5kbGVFZGl0UGVuYWx0eSIsImhhbmRsZU9wZW5XYWl2ZU9mZk1vZGFsIiwiaGFuZGxlRGVsZXRlUGVuYWx0eSIsInN0YXR1cyIsImZldGNoQ3VzdG9tZXJzV2l0aFBlbmFsdGllcyIsIlByb21pc2UiLCJyZXNvbHZlIiwiYWxsUGVuYWx0aWVzIiwiY3VzdG9tZXJNYXAiLCJNYXAiLCJmb3JFYWNoIiwiaGFzIiwic2V0IiwiZW5yb2xsbWVudF9pZCIsImxhdGVGZWVBbW91bnQiLCJjdXN0b21lcnNBcnJheSIsImZyb20iLCJoYW5kbGVCYXRjaFdhaXZlT2ZmIiwibGVuZ3RoIiwic3VjY2Vzc0NvdW50IiwiZXJyb3JDb3VudCIsInB1c2giLCJyZXF1ZXN0RGF0YSIsIlN0cmluZyIsImVyciIsImVycm9yTXNnIiwiZmV0Y2hDdXN0b21lckxvYW5EZXRhaWxzIiwiaGFuZGxlVmlld1BlbmFsdHlIaXN0b3J5IiwicGF5bWVudHNUaWNrZXQiLCJwZW5hbHR5VHJhbnNhY3Rpb25zIiwidHJhbnNhY3Rpb25zIiwidCIsImZvcm1hdHRlZFBlbmFsdGllcyIsImRlYml0IiwiZGVzY3JpcHRpb24iLCJoYW5kbGVVcGRhdGVQZW5hbHR5IiwidG9JU09TdHJpbmciLCJwcm9jZXNzZWRUcmFuc2FjdGlvbnMiLCJydW5uaW5nVG90YWxQYWlkIiwicnVubmluZ0R1ZSIsImVucm9sbG1lbnQiLCJzb3J0ZWRUcmFuc2FjdGlvbnMiLCJzb3J0IiwiYSIsInJlc3VsdCIsInBheW1lbnRBbW91bnQiLCJjcmVkaXQiLCJjYWxjdWxhdGVkVG90YWxQYWlkIiwiY2FsY3VsYXRlZERlYml0IiwiY2FsY3VsYXRlZER1ZSIsIk1hdGgiLCJhYnMiLCJhY3R1YWxEdWUiLCJ0b3RhbFBlbmFsdHlBbW91bnQiLCJyZWR1Y2UiLCJzdW0iLCJncm91cE9wdGlvbnMiLCJncm91cCIsInBlbmFsdHlIaXN0b3J5Q29sdW1ucyIsInRpdGxlIiwiZGF0YUluZGV4IiwicmVuZGVyIiwic29ydGVyIiwiZGVmYXVsdFNvcnRPcmRlciIsImFsaWduIiwicmVjb3JkIiwidG90YWwiLCJzdGF0dXNDb25maWciLCJwZW5kaW5nIiwiY29sb3IiLCJpY29uIiwidGV4dCIsImNhbmNlbGxlZCIsImNvbmZpZyIsImZpbHRlcnMiLCJvbkZpbHRlciIsInRyYW5zYWN0aW9uQ29sdW1ucyIsIndpZHRoIiwiY3VzdG9tZXJPcHRpb25zIiwidW5pcXVlQ3VzdG9tZXJzIiwidXNlciIsInRpY2tldE9wdGlvbnMiLCJ1c2VyVGlja2V0cyIsImhhbmRsZUdyb3VwU2VsZWN0Iiwic2VsZWN0ZWRHcm91cCIsImciLCJoYW5kbGVDdXN0b21lclNlbGVjdCIsInNlbGVjdGVkQ3VzdG9tZXIiLCJoYW5kbGVUaWNrZXRTZWxlY3QiLCJmZXRjaEN1cnJlbnRQZW5hbHR5VG90YWxzIiwic3VtbWFyeSIsImhhbmRsZVByb2NlZWRUb1BlbmFsdHkiLCJzZWxlY3RlZFRpY2tldERhdGEiLCJjdXJyZW50VG90YWxzIiwiaGFuZGxlU2F2ZVBlbmFsdHkiLCJyZW1haW5pbmdCYWxhbmNlIiwidW5kZWZpbmVkIiwicHJldlVzZXJzIiwicHJldkN1c3RvbWVycyIsIkVycm9yIiwiZmV0Y2hDdXN0b21lckFsbFBlbmFsdGllcyIsImhhbmRsZVdhaXZlT2ZmUGVuYWx0aWVzIiwiYW1vdW50VG9XYWl2ZSIsInBlbmFsdHlEYXRhIiwiZmV0Y2hXYWl2ZXJIaXN0b3J5IiwiaGFuZGxlQ2xvc2VGaXJzdERyYXdlciIsIm9wZW5CYXRjaFdhaXZlTW9kYWwiLCJsb2FuQ29sdW1ucyIsImhlYWRlciIsImxvYW5FeHBvcnRDb2x1bW5zIiwiY29sdW1ucyIsImV4Y2VsY29sdW1ucyIsImZpbHRlclBlbmFsdGllcyIsInNlYXJjaCIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJzdW1tYXJ5RGF0YSIsInAiLCJ0b3RhbFBlbmFsdGllcyIsInRvdGFsRXhjZXNzIiwiZHVlQ291bnQiLCJleGNlc3NDb3VudCIsImxvYW5TdW1tYXJ5RGF0YSIsIlNldCIsInNpemUiLCJiYXRjaFdhaXZlQ29sdW1ucyIsImUiLCJ0YXJnZXQiLCJjaGVja2VkIiwibG9jYWxlQ29tcGFyZSIsInRpY2tldHMiLCJnZXREdWVJbmZvIiwiZW5kIiwidG9kYXkiLCJzZXRIb3VycyIsImRpZmZUaW1lIiwiZGlmZkRheXMiLCJmbG9vciIsImJhY2tncm91bmRDb2xvciIsImJvcmRlckNvbG9yIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsImJvZHkiLCJtYXhIZWlnaHQiLCJvdmVyZmxvd1kiLCJwYWRkaW5nIiwidG90YWxBIiwidG90YWxCIiwicGFnZVNpemUiLCJzaG93VG90YWwiLCJyYW5nZSIsInNob3dTaXplQ2hhbmdlciIsIngiLCJwaG9uZSIsInNob3dRdWlja0p1bXBlciIsImVtcHR5VGV4dCIsImJvcnJvd2VyX25hbWUiLCJyZXZlcnNlIiwiam9pbiIsImV4dHJhX2NoYXJnZXMiLCJjaGFyZ2UiLCJpc1BhaWQiLCJwYWlkQW1vdW50IiwicGFpZF9hbW91bnQiLCJiYWxhbmNlQW1vdW50IiwiYmFsYW5jZV9hbW91bnQiLCJzdGF0dXNUZXh0Iiwic3RhdHVzQ29sb3IiLCJzIiwid2FpdmVkX2Ftb3VudCIsImVsbGlwc2lzIiwiZGV0YWlscyIsImR1ZUluZm8iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQZW5hbHR5TWFuYWdlbWVudC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7XHJcbiAgdXNlRWZmZWN0LFxyXG4gIHVzZVN0YXRlLFxyXG4gIHVzZU1lbW8sXHJcbiAgdXNlUmVmLFxyXG4gIHVzZUNhbGxiYWNrLFxyXG59IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQge1xyXG4gIEJ1dHRvbixcclxuICBEcmF3ZXIsXHJcbiAgQWxlcnQsXHJcbiAgU2VsZWN0LFxyXG4gIElucHV0LFxyXG4gIFR5cG9ncmFwaHksXHJcbiAgTW9kYWwgYXMgQW50TW9kYWwsXHJcbiAgVGFibGUsXHJcbiAgUG9wY29uZmlybSxcclxuICBUYWcsXHJcbiAgU3BhY2UsXHJcbiAgQmFkZ2UsXHJcbiAgQ2FyZCxcclxuICBSb3csXHJcbiAgQ29sLFxyXG4gIENoZWNrYm94LFxyXG4gIERhdGVQaWNrZXIsXHJcbiAgUmFkaW8sXHJcbiAgbWVzc2FnZSxcclxuICBTcGluLFxyXG59IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7XHJcbiAgQ2FsY3VsYXRvck91dGxpbmVkLFxyXG4gIEFycm93TGVmdE91dGxpbmVkLFxyXG4gIENoZWNrQ2lyY2xlT3V0bGluZWQsXHJcbiAgSW5mb0NpcmNsZU91dGxpbmVkLFxyXG4gIENsb3NlQ2lyY2xlT3V0bGluZWQsXHJcbiAgRmlsZVRleHRPdXRsaW5lZCxcclxuICBSZWxvYWRPdXRsaW5lZCxcclxuICBBcnJvd0Rvd25PdXRsaW5lZCxcclxuICBDYWxlbmRhck91dGxpbmVkLFxyXG4gIEV5ZU91dGxpbmVkLFxyXG4gIERlbGV0ZU91dGxpbmVkLFxyXG4gIEhpc3RvcnlPdXRsaW5lZCxcclxuICBXYWxsZXRPdXRsaW5lZCxcclxuICBVc2VyT3V0bGluZWQsXHJcbiAgUGhvbmVPdXRsaW5lZCxcclxuICBUZWFtT3V0bGluZWQsXHJcbiAgQ3JlZGl0Q2FyZE91dGxpbmVkLFxyXG4gIEVkaXRPdXRsaW5lZCxcclxuICBEb2xsYXJPdXRsaW5lZCxcclxuICBDbG9ja0NpcmNsZU91dGxpbmVkLFxyXG4gIEV4Y2xhbWF0aW9uQ2lyY2xlT3V0bGluZWQsXHJcbiAgU2F2ZU91dGxpbmVkLFxyXG4gIEdpZnRPdXRsaW5lZCxcclxufSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuaW1wb3J0IGRheWpzIGZyb20gXCJkYXlqc1wiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydCBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnRcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgeyBEcm9wZG93biB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IElvTWRNb3JlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCB7IEZhRXllLCBGYU1vbmV5QmlsbFdhdmUsIEZhUnVwZWVTaWduIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCBtb21lbnQgZnJvbSBcIm1vbWVudFwiO1xyXG5pbXBvcnQgeyBWaWV3SWNvbiB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuXHJcbmNvbnN0IHsgVGl0bGUsIFRleHQgfSA9IFR5cG9ncmFwaHk7XHJcblxyXG5mdW5jdGlvbiBQZW5hbHR5TWFuYWdlbWVudCgpIHtcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtlbnJvbGxlZFVzZXJzLCBzZXRFbnJvbGxlZFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZHVlQ3VzdG9tZXJzLCBzZXREdWVDdXN0b21lcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtwZW5hbHRpZXMsIHNldFBlbmFsdGllc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3RhYmxlRGF0YSwgc2V0VGFibGVEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbaXNMb2FkaW5nR3JvdXBzLCBzZXRJc0xvYWRpbmdHcm91cHNdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmdVc2Vycywgc2V0SXNMb2FkaW5nVXNlcnNdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmdQZW5hbHRpZXMsIHNldElzTG9hZGluZ1BlbmFsdGllc10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FkZFBlbmFsdHlEcmF3ZXJPcGVuLCBzZXRBZGRQZW5hbHR5RHJhd2VyT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FkZFBlbmFsdHlEZXRhaWxzLCBzZXRBZGRQZW5hbHR5RGV0YWlsc10gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbYWRkUGVuYWx0eUFtb3VudCwgc2V0QWRkUGVuYWx0eUFtb3VudF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWRkTGF0ZUZlZUFtb3VudCwgc2V0QWRkTGF0ZUZlZUFtb3VudF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWRkUGVuYWx0eUxvYWRpbmcsIHNldEFkZFBlbmFsdHlMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VsZWN0ZWRHcm91cElkLCBzZXRTZWxlY3RlZEdyb3VwSWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXBOYW1lLCBzZXRTZWxlY3RlZEdyb3VwTmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRDdXN0b21lcklkLCBzZXRTZWxlY3RlZEN1c3RvbWVySWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkQ3VzdG9tZXJOYW1lLCBzZXRTZWxlY3RlZEN1c3RvbWVyTmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRUaWNrZXQsIHNldFNlbGVjdGVkVGlja2V0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW3BlbmFsdHlGaWx0ZXJzLCBzZXRQZW5hbHR5RmlsdGVyc10gPSB1c2VTdGF0ZSh7XHJcbiAgICBncm91cElkOiBcIlwiLFxyXG4gICAgc3RhcnREYXRlOiBcIlwiLFxyXG4gICAgZW5kRGF0ZTogXCJcIixcclxuICB9KTtcclxuXHJcbiAgLy8gVmlldyBTdGF0ZW1lbnQgTW9kYWwgU3RhdGVcclxuICBjb25zdCBbc3RhdGVtZW50TW9kYWxWaXNpYmxlLCBzZXRTdGF0ZW1lbnRNb2RhbFZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzdGF0ZW1lbnREYXRhLCBzZXRTdGF0ZW1lbnREYXRhXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmdTdGF0ZW1lbnQsIHNldElzTG9hZGluZ1N0YXRlbWVudF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IFt3YWl2ZU9mZk1vZGFsVmlzaWJsZSwgc2V0V2FpdmVPZmZNb2RhbFZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFt3YWl2ZU9mZkRhdGEsIHNldFdhaXZlT2ZmRGF0YV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbd2FpdmVPZmZBbW91bnQsIHNldFdhaXZlT2ZmQW1vdW50XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFt3YWl2ZU9mZlR5cGUsIHNldFdhaXZlT2ZmVHlwZV0gPSB1c2VTdGF0ZShcImJvdGhcIik7XHJcbiAgY29uc3QgW3dhaXZlT2ZmUmVhc29uLCBzZXRXYWl2ZU9mZlJlYXNvbl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbaXNXYWl2aW5nT2ZmLCBzZXRJc1dhaXZpbmdPZmZdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEN1c3RvbWVyRm9yV2FpdmUsIHNldFNlbGVjdGVkQ3VzdG9tZXJGb3JXYWl2ZV0gPVxyXG4gICAgdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIGNvbnN0IFt3YWl2ZXJIaXN0b3J5TW9kYWxWaXNpYmxlLCBzZXRXYWl2ZXJIaXN0b3J5TW9kYWxWaXNpYmxlXSA9XHJcbiAgICB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3dhaXZlckhpc3RvcnlEYXRhLCBzZXRXYWl2ZXJIaXN0b3J5RGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZ1dhaXZlckhpc3RvcnksIHNldElzTG9hZGluZ1dhaXZlckhpc3RvcnldID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbYmF0Y2hXYWl2ZU1vZGFsVmlzaWJsZSwgc2V0QmF0Y2hXYWl2ZU1vZGFsVmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2N1c3RvbWVyc1dpdGhQZW5hbHRpZXMsIHNldEN1c3RvbWVyc1dpdGhQZW5hbHRpZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEN1c3RvbWVycywgc2V0U2VsZWN0ZWRDdXN0b21lcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtiYXRjaFdhaXZlQW1vdW50LCBzZXRCYXRjaFdhaXZlQW1vdW50XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtiYXRjaFdhaXZlVHlwZSwgc2V0QmF0Y2hXYWl2ZVR5cGVdID0gdXNlU3RhdGUoXCJib3RoXCIpO1xyXG4gIGNvbnN0IFtiYXRjaFdhaXZlUmVhc29uLCBzZXRCYXRjaFdhaXZlUmVhc29uXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtpc0JhdGNoV2FpdmluZywgc2V0SXNCYXRjaFdhaXZpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmdDdXN0b21lcnMsIHNldElzTG9hZGluZ0N1c3RvbWVyc10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG5cclxuICBjb25zdCBbcGVuYWx0eUhpc3RvcnlNb2RhbFZpc2libGUsIHNldFBlbmFsdHlIaXN0b3J5TW9kYWxWaXNpYmxlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcGVuYWx0eUhpc3RvcnlEYXRhLCBzZXRQZW5hbHR5SGlzdG9yeURhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmdQZW5hbHR5SGlzdG9yeSwgc2V0SXNMb2FkaW5nUGVuYWx0eUhpc3RvcnldID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFBlbmFsdHlDdXN0b21lciwgc2V0U2VsZWN0ZWRQZW5hbHR5Q3VzdG9tZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIGNvbnN0IFtlZGl0TW9kYWxWaXNpYmxlLCBzZXRFZGl0TW9kYWxWaXNpYmxlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZWRpdGluZ1BlbmFsdHksIHNldEVkaXRpbmdQZW5hbHR5XSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtlZGl0UGVuYWx0eUFtb3VudCwgc2V0RWRpdFBlbmFsdHlBbW91bnRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2VkaXRMYXRlRmVlQW1vdW50LCBzZXRFZGl0TGF0ZUZlZUFtb3VudF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZWRpdFJlYXNvbiwgc2V0RWRpdFJlYXNvbl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbaXNVcGRhdGluZ1BlbmFsdHksIHNldElzVXBkYXRpbmdQZW5hbHR5XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZWRpdERhdGUsIHNldEVkaXREYXRlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtwZW5hbHR5VHlwZSwgc2V0UGVuYWx0eVR5cGVdID0gdXNlU3RhdGUoXCJjaGl0XCIpO1xyXG4gIGNvbnN0IFtwZW5hbHR5TG9hbiwgc2V0UGVuYWx0eUxvYW5dID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIGNvbnN0IFtwZW5hbHR5Q2hhcmdlcywgc2V0UGVuYWx0eUNoYXJnZXNdID0gdXNlU3RhdGUoW1xyXG4gICAgeyBhbW91bnQ6IFwiXCIsIHJlYXNvbjogXCJcIiB9XHJcbiAgXSk7XHJcbiAgY29uc3QgW3BlbmFsdHlMb2FkaW5nLCBzZXRQZW5hbHR5TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkVXNlcklkLCBzZXRTZWxlY3RlZFVzZXJJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbdXNlcnMsIHNldFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYm9ycm93ZXJzLCBzZXRCb3Jyb3dlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtlbnJvbGxtZW50TG9hZGluZywgc2V0RW5yb2xsbWVudExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcGF5bWVudEdyb3VwVGlja2V0cywgc2V0UGF5bWVudEdyb3VwVGlja2V0c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkRW5yb2xsbWVudHMsIHNldEZpbHRlcmVkRW5yb2xsbWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtmaWx0ZXJlZFVzZXJzLCBzZXRGaWx0ZXJlZFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIHJlbWFya3M6IFwiXCIsXHJcbiAgICB1c2VyX2lkOiBcIlwiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW3JlbG9hZFRyaWdnZXIsIHNldFJlbG9hZFRyaWdnZXJdID0gdXNlU3RhdGUoMCk7XHJcblxyXG4gIGNvbnN0IGlzRmV0Y2hpbmdSZWYgPSB1c2VSZWYoZmFsc2UpO1xyXG5cclxuICAvLyBUb2dnbGUgYmV0d2VlbiBDaGl0IGFuZCBMb2FuIHBlbmFsdGllc1xyXG4gIGNvbnN0IFthY3RpdmVQZW5hbHR5Vmlldywgc2V0QWN0aXZlUGVuYWx0eVZpZXddID0gdXNlU3RhdGUoXCJjaGl0XCIpOyAvLyBcImNoaXRcIiBvciBcImxvYW5cIlxyXG5cclxuICAvLyBMb2FuIHBlbmFsdGllcyBkYXRhXHJcbiAgY29uc3QgW2xvYW5QZW5hbHRpZXMsIHNldExvYW5QZW5hbHRpZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FuVGFibGVEYXRhLCBzZXRMb2FuVGFibGVEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbaXNMb2FkaW5nTG9hblBlbmFsdGllcywgc2V0SXNMb2FkaW5nTG9hblBlbmFsdGllc10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIC8vIEVkaXQgbG9hbiBwZW5hbHR5IG1vZGFsIHN0YXRlXHJcbiAgY29uc3QgW2VkaXRMb2FuTW9kYWxWaXNpYmxlLCBzZXRFZGl0TG9hbk1vZGFsVmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2VkaXRpbmdMb2FuUGVuYWx0eSwgc2V0RWRpdGluZ0xvYW5QZW5hbHR5XSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtlZGl0TG9hbkFtb3VudCwgc2V0RWRpdExvYW5BbW91bnRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2VkaXRMb2FuUmVhc29uLCBzZXRFZGl0TG9hblJlYXNvbl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbaXNVcGRhdGluZ0xvYW5QZW5hbHR5LCBzZXRJc1VwZGF0aW5nTG9hblBlbmFsdHldID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93UGVuYWx0eU1vZGFsLCBzZXRTaG93UGVuYWx0eU1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hHcm91cHMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoc2VsZWN0ZWRHcm91cElkKSB7XHJcbiAgICAgIGZldGNoRHVlQ3VzdG9tZXJzKHNlbGVjdGVkR3JvdXBJZCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXREdWVDdXN0b21lcnMoW10pO1xyXG4gICAgICBzZXRFbnJvbGxlZFVzZXJzKFtdKTtcclxuICAgIH1cclxuICB9LCBbc2VsZWN0ZWRHcm91cElkXSk7XHJcblxyXG4gIGNvbnN0IGZldGNoTG9hblBlbmFsdGllcyA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcclxuICAgIHNldElzTG9hZGluZ0xvYW5QZW5hbHRpZXModHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdjEvYWRtaW4vbG9hbi1wZW5hbHR5cy9sb2FuLXBlbmFsdGllcy9cIik7XHJcbiAgICAgIC8vIFRoZSBBUEkgcmV0dXJucyBhbiBhcnJheSBkaXJlY3RseSwgbm90IHdyYXBwZWQgaW4geyBkYXRhOiB7IGRhdGE6IC4uLiB9IH1cclxuICAgICAgY29uc3QgcmF3RGF0YSA9IEFycmF5LmlzQXJyYXkocmVzcG9uc2UuZGF0YSkgPyByZXNwb25zZS5kYXRhIDogKHJlc3BvbnNlLmRhdGE/LmRhdGEgfHwgW10pO1xyXG4gICAgICBzZXRMb2FuUGVuYWx0aWVzKHJhd0RhdGEpO1xyXG5cclxuICAgICAgY29uc3QgZm9ybWF0dGVkID0gcmF3RGF0YS5tYXAoKGl0ZW0sIGlkeCkgPT4gKHtcclxuICAgICAgICBfaWQ6IGl0ZW0uX2lkLFxyXG4gICAgICAgIGlkOiBpZHggKyAxLFxyXG4gICAgICAgIGRhdGU6IG1vbWVudChpdGVtLnBlbmFsdHlfZGF0ZSB8fCBpdGVtLmNyZWF0ZWRBdCkuZm9ybWF0KFwiREQtTU0tWVlZWSBISDptbVwiKSxcclxuICAgICAgICBsb2FuX2lkOiBpdGVtLmxvYW5faWQ/LmxvYW5faWQgfHwgaXRlbS5sb2FuX2lkPy5faWQgfHwgXCJOL0FcIixcclxuICAgICAgICBsb2FuX2Ftb3VudDogaXRlbS5sb2FuX2lkPy5sb2FuX2Ftb3VudCB8fCBcIjBcIixcclxuICAgICAgICBjdXN0b21lcl9uYW1lOiBpdGVtLnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgIHBob25lX251bWJlcjogaXRlbS51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICBwZW5hbHR5X2Ftb3VudDogaXRlbS5wZW5hbHR5X2Ftb3VudCxcclxuICAgICAgICB0b3RhbF9hbW91bnQ6IGl0ZW0ucGVuYWx0eV9hbW91bnQsXHJcbiAgICAgICAgcmVhc29uOiBpdGVtLnJlYXNvbiB8fCBcIi1cIixcclxuICAgICAgICByYXdfcGVuYWx0eTogaXRlbSxcclxuICAgICAgICAvLyBBY3Rpb24gZHJvcGRvd25cclxuICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAga2V5OiBcInZpZXdcIixcclxuICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNwYWNlIGNsYXNzTmFtZT1cInB4LTIgcHktMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RmFFeWUgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMCB0ZXh0LXNtXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+VmlldyBQZW5hbHR5PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TcGFjZT5cclxuICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s6ICgpID0+IGhhbmRsZVZpZXdMb2FuUGVuYWx0eShpdGVtKSxcclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIGtleTogXCJlZGl0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTcGFjZSBjbGFzc05hbWU9XCJweC0yIHB5LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEVkaXRPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkVkaXQgUGVuYWx0eTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU3BhY2U+XHJcbiAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrOiAoKSA9PiBoYW5kbGVFZGl0TG9hblBlbmFsdHkoaXRlbSksXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBrZXk6IFwiZGVsZXRlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxQb3Bjb25maXJtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSB0aGlzIGxvYW4gcGVuYWx0eT9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNvbmZpcm09eygpID0+IGhhbmRsZURlbGV0ZUxvYW5QZW5hbHR5KGl0ZW0uX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb2tUZXh0PVwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2FuY2VsVGV4dD1cIk5vXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNwYWNlIGNsYXNzTmFtZT1cInB4LTIgcHktMSBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxEZWxldGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkRlbGV0ZSBQZW5hbHR5PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NwYWNlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9Qb3Bjb25maXJtPlxyXG4gICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tUmlnaHRcIlxyXG4gICAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwidGV4dFwiIGljb249ezxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LXhsXCIgLz59IGNsYXNzTmFtZT1cImhvdmVyOmJnLWdyYXktMTAwXCIgLz5cclxuICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICksXHJcbiAgICAgIH0pKTtcclxuICAgICAgc2V0TG9hblRhYmxlRGF0YShmb3JtYXR0ZWQpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGxvYW4gcGVuYWx0aWVzOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIGZldGNoIGxvYW4gcGVuYWx0aWVzXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0TG9hblBlbmFsdGllcyhbXSk7XHJcbiAgICAgIHNldExvYW5UYWJsZURhdGEoW10pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nTG9hblBlbmFsdGllcyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGFjdGl2ZVBlbmFsdHlWaWV3ID09PSBcImNoaXRcIikge1xyXG4gICAgICBmZXRjaFBlbmFsdGllcygpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZmV0Y2hMb2FuUGVuYWx0aWVzKCk7XHJcbiAgICB9XHJcbiAgfSwgW2FjdGl2ZVBlbmFsdHlWaWV3LCBwZW5hbHR5RmlsdGVyc10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hBbGxDdXN0b21lcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwidXNlci92ZXJpZmllZFwiKTtcclxuICAgICAgICBzZXRVc2VycyhyZXNwb25zZT8uZGF0YT8uZGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgc2V0VXNlcnMoW10pO1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEFsbEN1c3RvbWVycygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUGF5bWVudEFudFNlbGVjdCA9ICh2YWx1ZXMpID0+IHtcclxuICAgIHNldFBheW1lbnRHcm91cFRpY2tldHModmFsdWVzKTtcclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdGltZW91dElkID0gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgIGlmICghaXNGZXRjaGluZ1JlZi5jdXJyZW50KSB7XHJcbiAgICAgICAgZmV0Y2hQZW5hbHRpZXMoKTtcclxuICAgICAgfVxyXG4gICAgfSwgMzAwKTtcclxuICAgIHJldHVybiAoKSA9PiBjbGVhclRpbWVvdXQodGltZW91dElkKTtcclxuICB9LCBbcGVuYWx0eUZpbHRlcnNdKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hHcm91cHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBzZXRJc0xvYWRpbmdHcm91cHModHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvZ3JvdXAvZ2V0LWdyb3VwLWFkbWluXCIpO1xyXG4gICAgICBzZXRHcm91cHMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXBzOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGZldGNoIGdyb3Vwc1wiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmdHcm91cHMoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUVkaXRMb2FuUGVuYWx0eSA9IChwZW5hbHR5SXRlbSkgPT4ge1xyXG4gICAgc2V0RWRpdGluZ0xvYW5QZW5hbHR5KHBlbmFsdHlJdGVtKTtcclxuICAgIHNldEVkaXRMb2FuQW1vdW50KHBlbmFsdHlJdGVtLnBlbmFsdHlfYW1vdW50KTtcclxuICAgIHNldEVkaXRMb2FuUmVhc29uKHBlbmFsdHlJdGVtLnJlYXNvbik7XHJcbiAgICBzZXRFZGl0TG9hbk1vZGFsVmlzaWJsZSh0cnVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVWaWV3TG9hblBlbmFsdHkgPSBhc3luYyAoaXRlbSkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0UGVuYWx0eUxvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgdjEvYWRtaW4vbG9hbi1wZW5hbHR5cy8ke2l0ZW0uX2lkfWBcclxuICAgICAgKTtcclxuXHJcbiAgICAgIHNldFBlbmFsdHlMb2FuKGRhdGE/LmRhdGEgfHwgZGF0YSk7XHJcbiAgICAgIHNldFNob3dQZW5hbHR5TW9kYWwodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcGVuYWx0eSBkZXRhaWxzOlwiLCBlcnJvcik7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggcGVuYWx0eSBkZXRhaWxzXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0UGVuYWx0eUxvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG5cclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlTG9hblBlbmFsdHkgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIWVkaXRMb2FuQW1vdW50IHx8IHBhcnNlRmxvYXQoZWRpdExvYW5BbW91bnQpIDw9IDApIHtcclxuICAgICAgbWVzc2FnZS53YXJuaW5nKFwiUGxlYXNlIGVudGVyIGEgdmFsaWQgcGVuYWx0eSBhbW91bnRcIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHNldElzVXBkYXRpbmdMb2FuUGVuYWx0eSh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGFwaS5wdXQoYC92MS9hZG1pbi9sb2FuLXBlbmFsdHlzL2xvYW4tcGVuYWx0eS8ke2VkaXRpbmdMb2FuUGVuYWx0eS5faWR9YCwge1xyXG4gICAgICAgIHBlbmFsdHlBbW91bnQ6IHBhcnNlRmxvYXQoZWRpdExvYW5BbW91bnQpLFxyXG4gICAgICAgIHJlYXNvbjogZWRpdExvYW5SZWFzb24sXHJcbiAgICAgIH0pO1xyXG4gICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJMb2FuIHBlbmFsdHkgdXBkYXRlZCBzdWNjZXNzZnVsbHlcIik7XHJcbiAgICAgIHNldEVkaXRMb2FuTW9kYWxWaXNpYmxlKGZhbHNlKTtcclxuICAgICAgZmV0Y2hMb2FuUGVuYWx0aWVzKCk7IC8vIHJlZnJlc2ggbGlzdFxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIGxvYW4gcGVuYWx0eTpcIiwgZXJyb3IpO1xyXG4gICAgICBtZXNzYWdlLmVycm9yKGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIHVwZGF0ZSBwZW5hbHR5XCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNVcGRhdGluZ0xvYW5QZW5hbHR5KGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVMb2FuUGVuYWx0eSA9IGFzeW5jIChwZW5hbHR5SWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGFwaS5kZWxldGUoYC92MS9hZG1pbi9sb2FuLXBlbmFsdHlzL2xvYW4tcGVuYWx0eS8ke3BlbmFsdHlJZH1gKTtcclxuICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiTG9hbiBwZW5hbHR5IGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5XCIpO1xyXG4gICAgICBmZXRjaExvYW5QZW5hbHRpZXMoKTsgLy8gcmVmcmVzaCBsaXN0XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZGVsZXRpbmcgbG9hbiBwZW5hbHR5OlwiLCBlcnJvcik7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gZGVsZXRlIHBlbmFsdHlcIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUGVuYWx0eU1vZGFsT3BlbiA9IChib3Jyb3dlcikgPT4ge1xyXG4gICAgc2V0UGVuYWx0eUxvYW4oYm9ycm93ZXIpO1xyXG4gICAgc2V0UGVuYWx0eUNoYXJnZXMoW3sgYW1vdW50OiBcIlwiLCByZWFzb246IFwiXCIgfV0pO1xyXG4gICAgc2V0U2hvd1BlbmFsdHlNb2RhbCh0cnVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVBZGRQZW5hbHR5Um93ID0gKCkgPT4ge1xyXG4gICAgc2V0UGVuYWx0eUNoYXJnZXMocHJldiA9PiBbLi4ucHJldiwgeyBhbW91bnQ6IFwiXCIsIHJlYXNvbjogXCJcIiB9XSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUmVtb3ZlUGVuYWx0eVJvdyA9IChpbmRleCkgPT4ge1xyXG4gICAgc2V0UGVuYWx0eUNoYXJnZXMocHJldiA9PiBwcmV2LmZpbHRlcigoXywgaSkgPT4gaSAhPT0gaW5kZXgpKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQZW5hbHR5Q2hhbmdlID0gKGluZGV4LCBmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIHNldFBlbmFsdHlDaGFyZ2VzKHByZXYgPT5cclxuICAgICAgcHJldi5tYXAoKHJvdywgaSkgPT4gaSA9PT0gaW5kZXggPyB7IC4uLnJvdywgW2ZpZWxkXTogdmFsdWUgfSA6IHJvdylcclxuICAgICk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUGVuYWx0eVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IGxvYW5JdGVtID0gcGF5bWVudEdyb3VwVGlja2V0cy5maW5kKGl0ZW0gPT4gaXRlbS5zdGFydHNXaXRoKFwibG9hbi1cIikpO1xyXG4gICAgY29uc3QgbG9hbklkID0gbG9hbkl0ZW0/LnNwbGl0KFwibG9hbi1cIilbMV07XHJcbiAgICBjb25zdCBpbnZhbGlkID0gcGVuYWx0eUNoYXJnZXMuc29tZShjID0+ICFjLmFtb3VudCB8fCAhYy5yZWFzb24udHJpbSgpKTtcclxuICAgIGlmIChpbnZhbGlkKSB7XHJcbiAgICAgIG1lc3NhZ2Uud2FybmluZyhcIlBsZWFzZSBmaWxsIGluIGFsbCBhbW91bnQgYW5kIHJlYXNvbiBmaWVsZHNcIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHNldFBlbmFsdHlMb2FkaW5nKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgbmV3Q2hhcmdlcyA9IHBlbmFsdHlDaGFyZ2VzLm1hcChjID0+ICh7XHJcbiAgICAgICAgcGVuYWx0eUFtb3VudDogTnVtYmVyKGMuYW1vdW50KSxcclxuICAgICAgICByZWFzb246IGMucmVhc29uLnRyaW0oKSxcclxuICAgICAgICBwYWlkOiBmYWxzZSxcclxuICAgICAgfSkpO1xyXG4gICAgICBhd2FpdCBhcGkucG9zdChgL3YxL2FkbWluL2xvYW4tcGVuYWx0eXNgLCB7XHJcbiAgICAgICAgdXNlcklkOiBzZWxlY3RlZFVzZXJJZCxcclxuICAgICAgICBsb2FuSWQ6IGxvYW5JZCxcclxuICAgICAgICBwZW5hbHR5QW1vdW50OiBuZXdDaGFyZ2VzWzBdLnBlbmFsdHlBbW91bnQsXHJcbiAgICAgICAgcmVhc29uOiBuZXdDaGFyZ2VzWzBdLnJlYXNvbixcclxuICAgICAgfSk7XHJcbiAgICAgIG1lc3NhZ2Uuc3VjY2VzcyhcIlBlbmFsdHkgY2hhcmdlcyBhZGRlZCBzdWNjZXNzZnVsbHlcIik7XHJcbiAgICAgIC8vIFJlc2V0IGxvYW4gcGVuYWx0eSBmb3JtIGFuZCBjbG9zZSBkcmF3ZXJcclxuICAgICAgc2V0UGVuYWx0eUxvYW4obnVsbCk7XHJcbiAgICAgIHNldFBlbmFsdHlDaGFyZ2VzKFt7IGFtb3VudDogXCJcIiwgcmVhc29uOiBcIlwiIH1dKTtcclxuICAgICAgc2V0UGF5bWVudEdyb3VwVGlja2V0cyhbXSk7IC8vIGNsZWFyIHNlbGVjdGVkIGxvYW5zXHJcbiAgICAgIHNldFNlbGVjdGVkVXNlcklkKFwiXCIpOyAvLyBvcHRpb25hbGx5IHJlc2V0IGN1c3RvbWVyXHJcbiAgICAgIHNldEFkZFBlbmFsdHlEcmF3ZXJPcGVuKGZhbHNlKTsgLy8gY2xvc2UgdGhlIGRyYXdlclxyXG4gICAgICAvLyBSZWZyZXNoIGxvYW4gcGVuYWx0aWVzIGlmIGN1cnJlbnRseSB2aWV3aW5nIGxvYW5cclxuICAgICAgaWYgKGFjdGl2ZVBlbmFsdHlWaWV3ID09PSBcImxvYW5cIikge1xyXG4gICAgICAgIGZldGNoTG9hblBlbmFsdGllcygpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBhZGQgcGVuYWx0eSBjaGFyZ2VzXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0UGVuYWx0eUxvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUN1c3RvbWVyID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgc2V0RmlsdGVyZWRVc2VycyhbXSk7XHJcbiAgICBzZXRGaWx0ZXJlZEVucm9sbG1lbnRzKFtdKTtcclxuICAgIHNldFNlbGVjdGVkVXNlcklkKHVzZXJJZCk7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkZvcm1EYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2Rm9ybURhdGEsXHJcbiAgICAgIHVzZXJfaWQ6IHVzZXJJZCxcclxuICAgIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldkRhdGEpID0+ICh7IC4uLnByZXZEYXRhLCBjdXN0b21lcjogXCJcIiB9KSk7XHJcbiAgICBzZXRQYXltZW50R3JvdXBUaWNrZXRzKFtdKTtcclxuICAgIC8vIGhhbmRsZUdyb3VwQXVjdGlvbkNoYW5nZSh1c2VySWQpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldFRpY2tldERldGFpbHMgPSAoaXRlbSkgPT4ge1xyXG5cclxuICAgIGNvbnN0IGJvcnJvd2VyID0gYm9ycm93ZXJzPy5maW5kKChiKSA9PiBgbG9hbi0ke2IuX2lkfWAgPT09IGl0ZW0pO1xyXG4gICAgaWYgKGJvcnJvd2VyKSB7XHJcblxyXG4gICAgICAvLyBBc3N1bWluZyBsb2FuIGRhdGEgc3RydWN0dXJlIGhhcyBwYWlkX2Ftb3VudCBhbmQgbG9hbl9hbW91bnRcclxuICAgICAgY29uc3QgZGFpbHlQYXltZW50ID0gYm9ycm93ZXIuZGFpbHlfcGF5bWVudF9hbW91bnQgfHwgMDtcclxuICAgICAgY29uc3QgbG9hbkFtb3VudCA9IGJvcnJvd2VyPy5sb2FuX2Ftb3VudCB8fCAwO1xyXG4gICAgICBjb25zdCB0b3RhbFBhaWQgPSBib3Jyb3dlcj8udG90YWxfcGF5bWVudHMgfHwgMDtcclxuICAgICAgY29uc3Qgc3RhcnREYXRlID0gYm9ycm93ZXI/LnN0YXJ0X2RhdGVcclxuICAgICAgY29uc3QgZW5kRGF0ZSA9IGJvcnJvd2VyPy5lbmRfZGF0ZVxyXG4gICAgICBjb25zdCBiYWxhbmNlID0gYm9ycm93ZXI/LnJlbWFpbmluZ19sb2FuIHx8IDA7XHJcbiAgICAgIGNvbnN0IHRvdGFsTG9hbiA9IGJvcnJvd2VyLmxvYW5fYW1vdW50IHx8IDA7XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgdHlwZTogXCJsb2FuXCIsXHJcbiAgICAgICAgbmFtZTogYm9ycm93ZXIubG9hbl9pZCxcclxuICAgICAgICB0aWNrZXQ6IFwiLVwiLFxyXG4gICAgICAgIGxvYW5BbW91bnQ6IGxvYW5BbW91bnQsXHJcbiAgICAgICAgZGFpbHlQYXltZW50OiBkYWlseVBheW1lbnQsXHJcbiAgICAgICAgc3RhcnREYXRlOiBzdGFydERhdGUsXHJcbiAgICAgICAgZW5kRGF0ZTogZW5kRGF0ZSxcclxuICAgICAgICB0b3RhbFBhaWQ6IHRvdGFsUGFpZCxcclxuICAgICAgICBiYWxhbmNlOiBiYWxhbmNlLFxyXG4gICAgICAgIHByb2ZpdDogMCxcclxuICAgICAgICBhdWN0aW9uQ291bnQ6IDAsXHJcbiAgICAgIH07XHJcbiAgICB9XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcblxyXG4gIGNvbnN0IGZldGNoRHVlQ3VzdG9tZXJzID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHNldElzTG9hZGluZ1VzZXJzKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvcGVuYWx0eS1tYW5hZ2VtZW50L2R1ZS1jdXN0b21lcnMvJHtncm91cElkfWAsXHJcbiAgICAgICk7XHJcbiAgICAgIGNvbnN0IGR1ZUN1c3RvbWVyc0RhdGEgPSByZXNwb25zZS5kYXRhLmRhdGEgfHwgW107XHJcblxyXG4gICAgICBzZXREdWVDdXN0b21lcnMoZHVlQ3VzdG9tZXJzRGF0YSk7XHJcblxyXG4gICAgICBjb25zdCB0cmFuc2Zvcm1lZFVzZXJzID0gZHVlQ3VzdG9tZXJzRGF0YS5tYXAoKGN1c3RvbWVyKSA9PiAoe1xyXG4gICAgICAgIHVzZXJJZDogY3VzdG9tZXIudXNlcklkLFxyXG4gICAgICAgIHVzZXJOYW1lOiBjdXN0b21lci51c2VyTmFtZSxcclxuICAgICAgICB1c2VyUGhvbmU6IGN1c3RvbWVyLnVzZXJQaG9uZSxcclxuICAgICAgICB0aWNrZXQ6IGN1c3RvbWVyLnRpY2tldCxcclxuICAgICAgICBncm91cElkOiBncm91cElkLFxyXG4gICAgICAgIGdyb3VwTmFtZTogc2VsZWN0ZWRHcm91cE5hbWUsXHJcbiAgICAgICAgYmFsYW5jZTogY3VzdG9tZXIuZHVlQW1vdW50LFxyXG4gICAgICAgIHRvdGFsUGVuYWx0eTogY3VzdG9tZXIudG90YWxQZW5hbHR5IHx8IDAsXHJcbiAgICAgICAgdG90YWxMYXRlRmVlOiBjdXN0b21lci50b3RhbExhdGVGZWUgfHwgMCxcclxuICAgICAgICBlbnJvbGxtZW50SWQ6IGN1c3RvbWVyLmVucm9sbG1lbnRJZCxcclxuICAgICAgfSkpO1xyXG5cclxuICAgICAgc2V0RW5yb2xsZWRVc2Vycyh0cmFuc2Zvcm1lZFVzZXJzKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBkdWUgY3VzdG9tZXJzOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6XHJcbiAgICAgICAgICBlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBmZXRjaCBkdWUgY3VzdG9tZXJzXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0RHVlQ3VzdG9tZXJzKFtdKTtcclxuICAgICAgc2V0RW5yb2xsZWRVc2VycyhbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmdVc2VycyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hQZW5hbHRpZXMgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoaXNGZXRjaGluZ1JlZi5jdXJyZW50KSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKFwiRmV0Y2ggYWxyZWFkeSBpbiBwcm9ncmVzcywgc2tpcHBpbmcuLi5cIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBpc0ZldGNoaW5nUmVmLmN1cnJlbnQgPSB0cnVlO1xyXG4gICAgc2V0SXNMb2FkaW5nUGVuYWx0aWVzKHRydWUpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoKTtcclxuICAgICAgaWYgKHBlbmFsdHlGaWx0ZXJzLmdyb3VwSWQpXHJcbiAgICAgICAgcGFyYW1zLmFwcGVuZChcImdyb3VwSWRcIiwgcGVuYWx0eUZpbHRlcnMuZ3JvdXBJZCk7XHJcbiAgICAgIGlmIChwZW5hbHR5RmlsdGVycy5zdGFydERhdGUpXHJcbiAgICAgICAgcGFyYW1zLmFwcGVuZChcInN0YXJ0RGF0ZVwiLCBwZW5hbHR5RmlsdGVycy5zdGFydERhdGUpO1xyXG4gICAgICBpZiAocGVuYWx0eUZpbHRlcnMuZW5kRGF0ZSlcclxuICAgICAgICBwYXJhbXMuYXBwZW5kKFwiZW5kRGF0ZVwiLCBwZW5hbHR5RmlsdGVycy5lbmREYXRlKTtcclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL3BlbmFsdHktbWFuYWdlbWVudC9nZXQtcGVuYWx0aWVzLXdpdGgtdG90YWxzPyR7cGFyYW1zLnRvU3RyaW5nKCl9YCxcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGNvbnN0IHBlbmFsdGllc0RhdGEgPSByZXNwb25zZS5kYXRhLmRhdGEgfHwgW107XHJcbiAgICAgIHNldFBlbmFsdGllcyhwZW5hbHRpZXNEYXRhKTtcclxuXHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSBwZW5hbHRpZXNEYXRhLm1hcCgocGVuYWx0eSwgaW5kZXgpID0+IHtcclxuICAgICAgICAvLyBjb25zdCBjdXJyZW50QmFsYW5jZSA9IHBlbmFsdHkuY3VycmVudF9iYWxhbmNlIHx8IDA7XHJcblxyXG4gICAgICAgIGNvbnN0IHRvdGFsRHVlID0gcGVuYWx0eS5jdXJyZW50X2JhbGFuY2UgfHwgMDtcclxuXHJcbiAgICAgICAgY29uc3QgdG90YWxQYWlkID0gcGVuYWx0eS50b3RhbF9wYWlkIHx8IDA7XHJcbiAgICAgICAgY29uc3QgdG90YWxQZW5hbHR5U3VtID0gcGVuYWx0eS50b3RhbF9wZW5hbHR5X3N1bSB8fCAwO1xyXG4gICAgICAgIGNvbnN0IHRvdGFsTGF0ZUZlZVN1bSA9IHBlbmFsdHkudG90YWxfbGF0ZV9mZWVfc3VtIHx8IDA7XHJcblxyXG4gICAgICAgIGNvbnN0IGN1cnJlbnRCYWxhbmNlID0gdG90YWxEdWUgLSB0b3RhbFBlbmFsdHlTdW0gLSB0b3RhbExhdGVGZWVTdW07XHJcblxyXG4gICAgICAgIGNvbnN0IHBlbmFsdHlQbHVzRHVlID1cclxuICAgICAgICAgIGN1cnJlbnRCYWxhbmNlICsgdG90YWxQZW5hbHR5U3VtICsgdG90YWxMYXRlRmVlU3VtO1xyXG5cclxuICAgICAgICBjb25zdCBnZXREaXNwbGF5RGF0ZSA9IChwZW5hbHR5KSA9PiB7XHJcbiAgICAgICAgICBpZiAocGVuYWx0eS5wZW5hbHR5X2RhdGUgJiYgcGVuYWx0eS5jcmVhdGVkQXQpIHtcclxuICAgICAgICAgICAgY29uc3QgcGVuYWx0eURhdGUgPSBuZXcgRGF0ZShwZW5hbHR5LnBlbmFsdHlfZGF0ZSk7XHJcbiAgICAgICAgICAgIGNvbnN0IGNyZWF0ZWREYXRlID0gbmV3IERhdGUocGVuYWx0eS5jcmVhdGVkQXQpO1xyXG5cclxuICAgICAgICAgICAgaWYgKHBlbmFsdHlEYXRlLmdldFRpbWUoKSAhPT0gY3JlYXRlZERhdGUuZ2V0VGltZSgpKSB7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIG1vbWVudChwZW5hbHR5LnBlbmFsdHlfZGF0ZSkuZm9ybWF0KFwiREQtTU0tWVlZWSBISDptbVwiKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgcmV0dXJuIG1vbWVudChwZW5hbHR5LmNyZWF0ZWRBdCkuZm9ybWF0KFwiREQtTU0tWVlZWSBISDptbVwiKTtcclxuICAgICAgICB9O1xyXG5cclxuXHJcbiAgICAgICAgLy8gY29uc3QgcGVuYWx0eVBsdXNEdWUgPSBjdXJyZW50QmFsYW5jZTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIF9pZDogcGVuYWx0eS5faWQsXHJcbiAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgLy8gZGF0ZTogbW9tZW50KHBlbmFsdHkuY3JlYXRlZEF0KS5mb3JtYXQoXCJERC1NTS1ZWVlZIEhIOm1tXCIpLFxyXG4gICAgICAgICAgLy8gIGRhdGU6IGdldERpc3BsYXlEYXRlKHBlbmFsdHkpLFxyXG4gICAgICAgICAgZGF0ZTogbW9tZW50KHBlbmFsdHkucGVuYWx0eV9kYXRlIHx8IHBlbmFsdHkuY3JlYXRlZEF0KS5mb3JtYXQoXCJERC1NTS1ZWVlZIEhIOm1tXCIpLFxyXG4gICAgICAgICAgZ3JvdXBfbmFtZTogcGVuYWx0eS5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgY3VzdG9tZXJfbmFtZTogcGVuYWx0eS51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIHBob25lX251bWJlcjogcGVuYWx0eS51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICAgIHRpY2tldDogcGVuYWx0eS50aWNrZXQsXHJcbiAgICAgICAgICBiYWxhbmNlX3JhdzogY3VycmVudEJhbGFuY2UsXHJcbiAgICAgICAgICBiYWxhbmNlOiAoXHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtb3JhbmdlLTYwMCBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICDigrl7KGN1cnJlbnRCYWxhbmNlIHx8IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICksXHJcbiAgICAgICAgICBiYWxhbmNlX3N0YXR1czogKGN1cnJlbnRCYWxhbmNlIHx8IDApIDwgMCA/IFwiRXhjZXNzXCIgOiBcIkR1ZVwiLFxyXG4gICAgICAgICAgdG90YWxfcGFpZF9yYXc6IHRvdGFsUGFpZCxcclxuICAgICAgICAgIHRvdGFsX3BhaWQ6IChcclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDAgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAg4oK5eyh0b3RhbFBhaWQgfHwgMCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgKSxcclxuICAgICAgICAgIHBlbmFsdHlfcGx1c19kdWVfcmF3OiBwZW5hbHR5UGx1c0R1ZSxcclxuICAgICAgICAgIHBlbmFsdHlfcGx1c19kdWU6IChcclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwIGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgIOKCuXtwZW5hbHR5UGx1c0R1ZS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICApLFxyXG4gICAgICAgICAgdG90YWxfcGVuYWx0eV9zdW06IGDigrkkeyh0b3RhbFBlbmFsdHlTdW0gfHwgMCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gLFxyXG4gICAgICAgICAgdG90YWxfbGF0ZV9mZWVfc3VtOiBg4oK5JHsodG90YWxMYXRlRmVlU3VtIHx8IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgICAgICAgIHBlbmFsdHlfYW1vdW50X3JhdzogcGVuYWx0eS5wZW5hbHR5X2Ftb3VudCxcclxuICAgICAgICAgIHBlbmFsdHlfYW1vdW50OiBg4oK5JHsocGVuYWx0eS5wZW5hbHR5X2Ftb3VudCB8fCAwKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWAsXHJcbiAgICAgICAgICBsYXRlX2ZlZV9hbW91bnRfcmF3OiBwZW5hbHR5LmxhdGVfZmVlX2Ftb3VudCxcclxuICAgICAgICAgIGxhdGVfZmVlX2Ftb3VudDogYOKCuSR7KHBlbmFsdHkubGF0ZV9mZWVfYW1vdW50IHx8IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgICAgICAgIHRvdGFsX2Ftb3VudF9yYXc6XHJcbiAgICAgICAgICAgIChwZW5hbHR5LnBlbmFsdHlfYW1vdW50IHx8IDApICsgKHBlbmFsdHkubGF0ZV9mZWVfYW1vdW50IHx8IDApLFxyXG4gICAgICAgICAgdG90YWxfYW1vdW50OiBg4oK5JHsoKHBlbmFsdHkucGVuYWx0eV9hbW91bnQgfHwgMCkgKyAocGVuYWx0eS5sYXRlX2ZlZV9hbW91bnQgfHwgMCkpLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgICAgICAgIHJlYXNvbjogcGVuYWx0eS5yZWFzb24gfHwgXCItXCIsXHJcbiAgICAgICAgICByYXdfcGVuYWx0eTogcGVuYWx0eSxcclxuICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwidmlld1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNwYWNlIGNsYXNzTmFtZT1cInB4LTIgcHktMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxFeWVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5WaWV3IFN0YXRlbWVudDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TcGFjZT5cclxuICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrOiAoKSA9PiBoYW5kbGVWaWV3U3RhdGVtZW50KHBlbmFsdHkpLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcImVkaXRcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTcGFjZSBjbGFzc05hbWU9XCJweC0yIHB5LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8RWRpdE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5FZGl0IFBlbmFsdHk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU3BhY2U+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljazogKCkgPT4gaGFuZGxlRWRpdFBlbmFsdHkocGVuYWx0eSksXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwid2FpdmVcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTcGFjZSBjbGFzc05hbWU9XCJweC0yIHB5LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8RG9sbGFyT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1wdXJwbGUtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5XYWl2ZSBPZmYgUGVuYWx0aWVzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NwYWNlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s6ICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlT3BlbldhaXZlT2ZmTW9kYWwocGVuYWx0eSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcImRlbGV0ZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFBvcGNvbmZpcm1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBkZWxldGUgdGhpcyBwZW5hbHR5P1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db25maXJtPXsoKSA9PiBoYW5kbGVEZWxldGVQZW5hbHR5KHBlbmFsdHkuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBva1RleHQ9XCJZZXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNhbmNlbFRleHQ9XCJOb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U3BhY2UgY2xhc3NOYW1lPVwicHgtMiBweS0xIGN1cnNvci1wb2ludGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGVsZXRlT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkRlbGV0ZSBQZW5hbHR5PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvU3BhY2U+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvUG9wY29uZmlybT5cclxuICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21SaWdodFwiXHJcbiAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgaWNvbj17PElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQteGxcIiAvPn1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaG92ZXI6YmctZ3JheS0xMDBcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICksXHJcbiAgICAgICAgfTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBzZXRUYWJsZURhdGEoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcGVuYWx0aWVzOlwiLCBlcnJvcik7XHJcbiAgICAgIGlmIChlcnJvci5yZXNwb25zZT8uc3RhdHVzID09PSA0MDQpIHtcclxuICAgICAgICBzZXRQZW5hbHRpZXMoW10pO1xyXG4gICAgICAgIHNldFRhYmxlRGF0YShbXSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGZldGNoIHBlbmFsdGllc1wiLFxyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldFBlbmFsdGllcyhbXSk7XHJcbiAgICAgICAgc2V0VGFibGVEYXRhKFtdKTtcclxuICAgICAgfVxyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nUGVuYWx0aWVzKGZhbHNlKTtcclxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgaXNGZXRjaGluZ1JlZi5jdXJyZW50ID0gZmFsc2U7XHJcbiAgICAgIH0sIDUwMCk7XHJcbiAgICB9XHJcbiAgfSwgW3BlbmFsdHlGaWx0ZXJzXSk7XHJcblxyXG4gIGNvbnN0IGZldGNoQ3VzdG9tZXJzV2l0aFBlbmFsdGllcyA9IGFzeW5jICgpID0+IHtcclxuICAgIHNldElzTG9hZGluZ0N1c3RvbWVycyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiBzZXRUaW1lb3V0KHJlc29sdmUsIDUwMCkpO1xyXG5cclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvcGVuYWx0eS1tYW5hZ2VtZW50L2dldC1wZW5hbHRpZXMtd2l0aC10b3RhbHM/bGltaXQ9MTAwMGAsXHJcbiAgICAgICk7XHJcbiAgICAgIGNvbnN0IGFsbFBlbmFsdGllcyA9IHJlc3BvbnNlLmRhdGEuZGF0YSB8fCBbXTtcclxuXHJcbiAgICAgIGNvbnN0IGN1c3RvbWVyTWFwID0gbmV3IE1hcCgpO1xyXG4gICAgICBhbGxQZW5hbHRpZXMuZm9yRWFjaCgocGVuYWx0eSkgPT4ge1xyXG4gICAgICAgIC8vIENyZWF0ZSB1bmlxdWUga2V5IGZvciBlYWNoIGN1c3RvbWVyICsgZ3JvdXAgKyB0aWNrZXQgY29tYmluYXRpb25cclxuICAgICAgICBjb25zdCBrZXkgPSBgJHtwZW5hbHR5LnVzZXJfaWQ/Ll9pZH1fJHtwZW5hbHR5Lmdyb3VwX2lkPy5faWR9XyR7cGVuYWx0eS50aWNrZXR9YDtcclxuXHJcbiAgICAgICAgaWYgKCFjdXN0b21lck1hcC5oYXMoa2V5KSkge1xyXG4gICAgICAgICAgY3VzdG9tZXJNYXAuc2V0KGtleSwge1xyXG4gICAgICAgICAgICAvLyBDdXN0b21lciBpbmZvIC0gRklYRUQ6IFVzZSBjb3JyZWN0IHByb3BlcnR5IG5hbWVzIGZyb20gQVBJIHJlc3BvbnNlXHJcbiAgICAgICAgICAgIHVzZXJJZDogcGVuYWx0eS51c2VyX2lkPy5faWQsXHJcbiAgICAgICAgICAgIHVzZXJOYW1lOiBwZW5hbHR5LnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICB1c2VyUGhvbmU6IHBlbmFsdHkudXNlcl9pZD8ucGhvbmVfbnVtYmVyIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIC8vIEdyb3VwIGluZm9cclxuICAgICAgICAgICAgZ3JvdXBJZDogcGVuYWx0eS5ncm91cF9pZD8uX2lkLFxyXG4gICAgICAgICAgICBncm91cE5hbWU6IHBlbmFsdHkuZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgLy8gVGlja2V0IGluZm9cclxuICAgICAgICAgICAgdGlja2V0OiBwZW5hbHR5LnRpY2tldCxcclxuICAgICAgICAgICAgZW5yb2xsbWVudElkOiBwZW5hbHR5LmVucm9sbG1lbnRfaWQsIC8vIFRoaXMgaXMgY3JpdGljYWwhXHJcbiAgICAgICAgICAgIC8vIEFtb3VudHMgLSBGSVhFRDogVXNlIGNvcnJlY3QgcHJvcGVydHkgbmFtZXNcclxuICAgICAgICAgICAgdG90YWxQZW5hbHR5OiAwLFxyXG4gICAgICAgICAgICB0b3RhbExhdGVGZWU6IDAsXHJcbiAgICAgICAgICAgIGN1cnJlbnRCYWxhbmNlOiBwZW5hbHR5LmN1cnJlbnRfYmFsYW5jZSB8fCAwLFxyXG4gICAgICAgICAgICBwZW5hbHR5QW1vdW50OiBwZW5hbHR5LnBlbmFsdHlfYW1vdW50IHx8IDAsXHJcbiAgICAgICAgICAgIGxhdGVGZWVBbW91bnQ6IHBlbmFsdHkubGF0ZV9mZWVfYW1vdW50IHx8IDAsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IGN1c3RvbWVyID0gY3VzdG9tZXJNYXAuZ2V0KGtleSk7XHJcbiAgICAgICAgY3VzdG9tZXIudG90YWxQZW5hbHR5ICs9IHBlbmFsdHkucGVuYWx0eV9hbW91bnQgfHwgMDtcclxuICAgICAgICBjdXN0b21lci50b3RhbExhdGVGZWUgKz0gcGVuYWx0eS5sYXRlX2ZlZV9hbW91bnQgfHwgMDtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCBjdXN0b21lcnNBcnJheSA9IEFycmF5LmZyb20oY3VzdG9tZXJNYXAudmFsdWVzKCkpO1xyXG4gICAgICBzZXRDdXN0b21lcnNXaXRoUGVuYWx0aWVzKGN1c3RvbWVyc0FycmF5KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBjdXN0b21lcnMgd2l0aCBwZW5hbHRpZXM6XCIsIGVycm9yKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gZmV0Y2ggY3VzdG9tZXJzIHdpdGggcGVuYWx0aWVzXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZ0N1c3RvbWVycyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gSGFuZGxlIGJhdGNoIHdhaXZlIG9mZlxyXG4gIGNvbnN0IGhhbmRsZUJhdGNoV2FpdmVPZmYgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoc2VsZWN0ZWRDdXN0b21lcnMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIHNlbGVjdCBhdCBsZWFzdCBvbmUgY3VzdG9tZXJcIixcclxuICAgICAgICB0eXBlOiBcIndhcm5pbmdcIixcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWJhdGNoV2FpdmVBbW91bnQgfHwgcGFyc2VGbG9hdChiYXRjaFdhaXZlQW1vdW50KSA8PSAwKSB7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIGVudGVyIGEgdmFsaWQgYW1vdW50IHRvIHdhaXZlIG9mZlwiLFxyXG4gICAgICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgICB9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldElzQmF0Y2hXYWl2aW5nKHRydWUpO1xyXG4gICAgbGV0IHN1Y2Nlc3NDb3VudCA9IDA7XHJcbiAgICBsZXQgZXJyb3JDb3VudCA9IDA7XHJcbiAgICBjb25zdCBlcnJvcnMgPSBbXTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICAvLyBQcm9jZXNzIGVhY2ggc2VsZWN0ZWQgY3VzdG9tZXJcclxuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzZWxlY3RlZEN1c3RvbWVycy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgIGNvbnN0IGN1c3RvbWVyID0gc2VsZWN0ZWRDdXN0b21lcnNbaV07XHJcblxyXG4gICAgICAgIC8vIFZhbGlkYXRlIGN1c3RvbWVyIGhhcyByZXF1aXJlZCBmaWVsZHNcclxuICAgICAgICBpZiAoIWN1c3RvbWVyLnVzZXJJZCkge1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcihcIk1pc3NpbmcgdXNlcklkIGZvciBjdXN0b21lcjpcIiwgY3VzdG9tZXIpO1xyXG4gICAgICAgICAgZXJyb3JDb3VudCsrO1xyXG4gICAgICAgICAgZXJyb3JzLnB1c2goXHJcbiAgICAgICAgICAgIGBDdXN0b21lciAke2N1c3RvbWVyLnVzZXJOYW1lIHx8IFwiVW5rbm93blwifTogTWlzc2luZyB1c2VySWRgLFxyXG4gICAgICAgICAgKTtcclxuICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKCFjdXN0b21lci5ncm91cElkKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmVycm9yKFwiTWlzc2luZyBncm91cElkIGZvciBjdXN0b21lcjpcIiwgY3VzdG9tZXIpO1xyXG4gICAgICAgICAgZXJyb3JDb3VudCsrO1xyXG4gICAgICAgICAgZXJyb3JzLnB1c2goYCR7Y3VzdG9tZXIudXNlck5hbWV9OiBNaXNzaW5nIGdyb3VwSWRgKTtcclxuICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKCFjdXN0b21lci5lbnJvbGxtZW50SWQpIHtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJNaXNzaW5nIGVucm9sbG1lbnRJZCBmb3IgY3VzdG9tZXI6XCIsIGN1c3RvbWVyKTtcclxuICAgICAgICAgIGVycm9yQ291bnQrKztcclxuICAgICAgICAgIGVycm9ycy5wdXNoKGAke2N1c3RvbWVyLnVzZXJOYW1lfTogTWlzc2luZyBlbnJvbGxtZW50SWRgKTtcclxuICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKCFjdXN0b21lci50aWNrZXQpIHtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJNaXNzaW5nIHRpY2tldCBmb3IgY3VzdG9tZXI6XCIsIGN1c3RvbWVyKTtcclxuICAgICAgICAgIGVycm9yQ291bnQrKztcclxuICAgICAgICAgIGVycm9ycy5wdXNoKGAke2N1c3RvbWVyLnVzZXJOYW1lfTogTWlzc2luZyB0aWNrZXRgKTtcclxuICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgcmVxdWVzdERhdGEgPSB7XHJcbiAgICAgICAgICB1c2VySWQ6IGN1c3RvbWVyLnVzZXJJZCxcclxuICAgICAgICAgIGdyb3VwSWQ6IGN1c3RvbWVyLmdyb3VwSWQsXHJcbiAgICAgICAgICBlbnJvbGxtZW50SWQ6IGN1c3RvbWVyLmVucm9sbG1lbnRJZCxcclxuICAgICAgICAgIHRpY2tldDogU3RyaW5nKGN1c3RvbWVyLnRpY2tldCksIC8vIENvbnZlcnQgdG8gc3RyaW5nXHJcbiAgICAgICAgICB3YWl2ZU9mZkFtb3VudDogcGFyc2VGbG9hdChiYXRjaFdhaXZlQW1vdW50KSxcclxuICAgICAgICAgIHdhaXZlT2ZmVHlwZTogYmF0Y2hXYWl2ZVR5cGUsXHJcbiAgICAgICAgICByZWFzb246XHJcbiAgICAgICAgICAgIGJhdGNoV2FpdmVSZWFzb24gfHwgYEJhdGNoIHdhaXZlciAtICR7bmV3IERhdGUoKS50b0xvY2FsZVN0cmluZygpfWAsXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoXHJcbiAgICAgICAgICAgIFwiL3BlbmFsdHktbWFuYWdlbWVudC93YWl2ZS1vZmYtcGVuYWx0aWVzXCIsXHJcbiAgICAgICAgICAgIHJlcXVlc3REYXRhLFxyXG4gICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YS5zdWNjZXNzKSB7XHJcbiAgICAgICAgICAgIHN1Y2Nlc3NDb3VudCsrO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcclxuICAgICAgICAgICAgICBg4pyFIFN1Y2Nlc3NmdWxseSB3YWl2ZWQgZm9yICR7Y3VzdG9tZXIudXNlck5hbWV9IC0gVGlja2V0ICR7Y3VzdG9tZXIudGlja2V0fWAsXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBlcnJvckNvdW50Kys7XHJcbiAgICAgICAgICAgIGVycm9ycy5wdXNoKFxyXG4gICAgICAgICAgICAgIGAke2N1c3RvbWVyLnVzZXJOYW1lfSAtIFRpY2tldCAke2N1c3RvbWVyLnRpY2tldH06ICR7cmVzcG9uc2UuZGF0YS5tZXNzYWdlfWAsXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICBlcnJvckNvdW50Kys7XHJcbiAgICAgICAgICBjb25zdCBlcnJvck1zZyA9IGVyci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBlcnIubWVzc2FnZTtcclxuICAgICAgICAgIGVycm9ycy5wdXNoKFxyXG4gICAgICAgICAgICBgJHtjdXN0b21lci51c2VyTmFtZX0gLSBUaWNrZXQgJHtjdXN0b21lci50aWNrZXR9OiAke2Vycm9yTXNnfWAsXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcihcclxuICAgICAgICAgICAgYOKdjCBGYWlsZWQgdG8gd2FpdmUgZm9yICR7Y3VzdG9tZXIudXNlck5hbWV9OmAsXHJcbiAgICAgICAgICAgIGVyci5yZXNwb25zZT8uZGF0YSB8fCBlcnIsXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gU2hvdyBmaW5hbCByZXN1bHRcclxuICAgICAgaWYgKHN1Y2Nlc3NDb3VudCA+IDApIHtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogYOKchSBTdWNjZXNzZnVsbHkgd2FpdmVkIG9mZiBmb3IgJHtzdWNjZXNzQ291bnR9IHRpY2tldChzKS4gRmFpbGVkOiAke2Vycm9yQ291bnR9YCxcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICAvLyBDbG9zZSBtb2RhbCBhbmQgcmVmcmVzaCBpZiBhbnkgc3VjY2Vzc1xyXG4gICAgICAgIHNldEJhdGNoV2FpdmVNb2RhbFZpc2libGUoZmFsc2UpO1xyXG4gICAgICAgIHNldFNlbGVjdGVkQ3VzdG9tZXJzKFtdKTtcclxuICAgICAgICBzZXRCYXRjaFdhaXZlQW1vdW50KFwiXCIpO1xyXG4gICAgICAgIHNldEJhdGNoV2FpdmVSZWFzb24oXCJcIik7XHJcbiAgICAgICAgc2V0QmF0Y2hXYWl2ZVR5cGUoXCJib3RoXCIpO1xyXG4gICAgICAgIHNldEN1c3RvbWVyc1dpdGhQZW5hbHRpZXMoW10pO1xyXG5cclxuICAgICAgICAvLyBSZWZyZXNoIGFsbCBkYXRhXHJcbiAgICAgICAgYXdhaXQgZmV0Y2hQZW5hbHRpZXMoKTtcclxuICAgICAgICBpZiAoc2VsZWN0ZWRHcm91cElkKSB7XHJcbiAgICAgICAgICBhd2FpdCBmZXRjaER1ZUN1c3RvbWVycyhzZWxlY3RlZEdyb3VwSWQpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBlbHNlIGlmIChlcnJvckNvdW50ID4gMCkge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBg4p2MIEZhaWxlZCBmb3IgJHtlcnJvckNvdW50fSB0aWNrZXQocykuIFBsZWFzZSBjaGVjayBjb25zb2xlIGZvciBkZXRhaWxzLmAsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBpbiBiYXRjaCB3YWl2ZSBvZmY6XCIsIGVycm9yKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTpcclxuICAgICAgICAgIFwiRmFpbGVkIHRvIHByb2Nlc3MgYmF0Y2ggd2FpdmVyOiBcIiArXHJcbiAgICAgICAgICAoZXJyb3IubWVzc2FnZSB8fCBcIlVua25vd24gZXJyb3JcIiksXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzQmF0Y2hXYWl2aW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBWaWV3IFN0YXRlbWVudCBIYW5kbGVyXHJcbiAgY29uc3QgaGFuZGxlVmlld1N0YXRlbWVudCA9IGFzeW5jIChwZW5hbHR5KSA9PiB7XHJcbiAgICBzZXRTdGF0ZW1lbnRNb2RhbFZpc2libGUodHJ1ZSk7XHJcbiAgICBzZXRJc0xvYWRpbmdTdGF0ZW1lbnQodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgYC9wZW5hbHR5LW1hbmFnZW1lbnQvc3RhdGVtZW50LyR7cGVuYWx0eS51c2VyX2lkLl9pZH0vJHtwZW5hbHR5Lmdyb3VwX2lkLl9pZH0vJHtwZW5hbHR5LnRpY2tldH1gLFxyXG4gICAgICApO1xyXG4gICAgICBzZXRTdGF0ZW1lbnREYXRhKHJlc3BvbnNlLmRhdGEuZGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgc3RhdGVtZW50OlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGZldGNoIHN0YXRlbWVudFwiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmdTdGF0ZW1lbnQoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRCb3Jyb3dlcnMoW10pO1xyXG4gICAgY29uc3QgZmV0Y2hDdXN0b21lckxvYW5EZXRhaWxzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICBpZiAoIXNlbGVjdGVkVXNlcklkKSByZXR1cm47XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvdjEvYWRtaW4vbG9hbnMvZ2V0LWJvcnJvd2VyLWRldGFpbHMvJHtzZWxlY3RlZFVzZXJJZH1gKTtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8uZGF0YSkge1xyXG4gICAgICAgICAgc2V0Qm9ycm93ZXJzKHJlc3BvbnNlLmRhdGEuZGF0YSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldEJvcnJvd2VycyhbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBzZXRCb3Jyb3dlcnMoW10pO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiRXJyb3IgZmV0Y2hpbmcgbG9hbiBkZXRhaWxzOlwiLCBlcnIpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hDdXN0b21lckxvYW5EZXRhaWxzKCk7XHJcbiAgfSwgW3NlbGVjdGVkVXNlcklkXSk7XHJcblxyXG4gIC8vIFZpZXcgUGVuYWx0eSBIaXN0b3J5IEhhbmRsZXJcclxuICBjb25zdCBoYW5kbGVWaWV3UGVuYWx0eUhpc3RvcnkgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIWFkZFBlbmFsdHlEZXRhaWxzKSByZXR1cm47XHJcblxyXG4gICAgc2V0UGVuYWx0eUhpc3RvcnlNb2RhbFZpc2libGUodHJ1ZSk7XHJcbiAgICBzZXRJc0xvYWRpbmdQZW5hbHR5SGlzdG9yeSh0cnVlKTtcclxuICAgIHNldFNlbGVjdGVkUGVuYWx0eUN1c3RvbWVyKHtcclxuICAgICAgdXNlck5hbWU6IGFkZFBlbmFsdHlEZXRhaWxzLnVzZXJOYW1lLFxyXG4gICAgICB1c2VyUGhvbmU6IGFkZFBlbmFsdHlEZXRhaWxzLnVzZXJQaG9uZSxcclxuICAgICAgZ3JvdXBOYW1lOiBhZGRQZW5hbHR5RGV0YWlscy5ncm91cE5hbWUsXHJcbiAgICAgIHRpY2tldDogYWRkUGVuYWx0eURldGFpbHMucGF5bWVudHNUaWNrZXQsXHJcbiAgICB9KTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgYC9wZW5hbHR5LW1hbmFnZW1lbnQvc3RhdGVtZW50LyR7YWRkUGVuYWx0eURldGFpbHMudXNlcklkfS8ke2FkZFBlbmFsdHlEZXRhaWxzLmdyb3VwSWR9LyR7YWRkUGVuYWx0eURldGFpbHMucGF5bWVudHNUaWNrZXR9YCxcclxuICAgICAgKTtcclxuICAgICAgY29uc3Qgc3RhdGVtZW50RGF0YSA9IHJlc3BvbnNlLmRhdGEuZGF0YTtcclxuXHJcbiAgICAgIGNvbnN0IHBlbmFsdHlUcmFuc2FjdGlvbnMgPVxyXG4gICAgICAgIHN0YXRlbWVudERhdGEudHJhbnNhY3Rpb25zPy5maWx0ZXIoXHJcbiAgICAgICAgICAodCkgPT4gdC50eXBlID09PSBcIlBlbmFsdHlcIiB8fCB0LnR5cGUgPT09IFwiTGF0ZSBGZWVcIixcclxuICAgICAgICApIHx8IFtdO1xyXG5cclxuICAgICAgY29uc3QgZm9ybWF0dGVkUGVuYWx0aWVzID0gcGVuYWx0eVRyYW5zYWN0aW9ucy5tYXAoKHQsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgIF9pZDogaW5kZXgsXHJcbiAgICAgICAgY3JlYXRlZEF0OiB0LmRhdGUsXHJcbiAgICAgICAgcGVuYWx0eV9hbW91bnQ6IHQudHlwZSA9PT0gXCJQZW5hbHR5XCIgPyB0LmRlYml0IHx8IDAgOiAwLFxyXG4gICAgICAgIGxhdGVfZmVlX2Ftb3VudDogdC50eXBlID09PSBcIkxhdGUgRmVlXCIgPyB0LmRlYml0IHx8IDAgOiAwLFxyXG4gICAgICAgIHJlYXNvbjogdC5kZXNjcmlwdGlvbiB8fCBcIk1hbnVhbCBwZW5hbHR5IGFkZGVkXCIsXHJcbiAgICAgICAgc3RhdHVzOiBcInBlbmRpbmdcIixcclxuICAgICAgfSkpO1xyXG5cclxuICAgICAgc2V0UGVuYWx0eUhpc3RvcnlEYXRhKGZvcm1hdHRlZFBlbmFsdGllcyk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcGVuYWx0eSBoaXN0b3J5OlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGZldGNoIHBlbmFsdHkgaGlzdG9yeVwiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFBlbmFsdHlIaXN0b3J5RGF0YShbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmdQZW5hbHR5SGlzdG9yeShmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gRWRpdCBQZW5hbHR5IEhhbmRsZXJcclxuICBjb25zdCBoYW5kbGVFZGl0UGVuYWx0eSA9IChwZW5hbHR5KSA9PiB7XHJcbiAgICBzZXRFZGl0aW5nUGVuYWx0eShwZW5hbHR5KTtcclxuICAgIHNldEVkaXRQZW5hbHR5QW1vdW50KHBlbmFsdHkucGVuYWx0eV9hbW91bnQpO1xyXG4gICAgc2V0RWRpdExhdGVGZWVBbW91bnQocGVuYWx0eS5sYXRlX2ZlZV9hbW91bnQpO1xyXG4gICAgc2V0RWRpdFJlYXNvbihwZW5hbHR5LnJlYXNvbiB8fCBcIlwiKTtcclxuICAgIHNldEVkaXREYXRlKGRheWpzKHBlbmFsdHkuY3JlYXRlZEF0KSk7XHJcbiAgICBzZXRFZGl0TW9kYWxWaXNpYmxlKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIC8vIFVwZGF0ZSBQZW5hbHR5IEhhbmRsZXJcclxuICBjb25zdCBoYW5kbGVVcGRhdGVQZW5hbHR5ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCFlZGl0UGVuYWx0eUFtb3VudCAmJiAhZWRpdExhdGVGZWVBbW91bnQpIHtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJQbGVhc2UgZW50ZXIgYXQgbGVhc3Qgb25lIGFtb3VudFwiLFxyXG4gICAgICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgICB9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldElzVXBkYXRpbmdQZW5hbHR5KHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucHV0KFxyXG4gICAgICAgIGAvcGVuYWx0eS1tYW5hZ2VtZW50L3VwZGF0ZS1wZW5hbHR5LyR7ZWRpdGluZ1BlbmFsdHkuX2lkfWAsXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgcGVuYWx0eV9hbW91bnQ6IHBhcnNlRmxvYXQoZWRpdFBlbmFsdHlBbW91bnQpIHx8IDAsXHJcbiAgICAgICAgICBsYXRlX2ZlZV9hbW91bnQ6IHBhcnNlRmxvYXQoZWRpdExhdGVGZWVBbW91bnQpIHx8IDAsXHJcbiAgICAgICAgICByZWFzb246IGVkaXRSZWFzb24sXHJcbiAgICAgICAgICBwZW5hbHR5X2RhdGU6IGVkaXREYXRlID8gZWRpdERhdGUudG9JU09TdHJpbmcoKSA6IG51bGwsXHJcbiAgICAgICAgfSxcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGlmIChyZXNwb25zZS5kYXRhLnN1Y2Nlc3MpIHtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJQZW5hbHR5IHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5IVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2V0RWRpdE1vZGFsVmlzaWJsZShmYWxzZSk7XHJcbiAgICAgICAgc2V0RWRpdGluZ1BlbmFsdHkobnVsbCk7XHJcbiAgICAgICAgZmV0Y2hQZW5hbHRpZXMoKTtcclxuICAgICAgICBpZiAoc2VsZWN0ZWRHcm91cElkKSB7XHJcbiAgICAgICAgICBmZXRjaER1ZUN1c3RvbWVycyhzZWxlY3RlZEdyb3VwSWQpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIHBlbmFsdHk6XCIsIGVycm9yKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gdXBkYXRlIHBlbmFsdHlcIixcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNVcGRhdGluZ1BlbmFsdHkoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHByb2Nlc3NlZFRyYW5zYWN0aW9ucyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgaWYgKCFzdGF0ZW1lbnREYXRhKSB7XHJcbiAgICAgIHJldHVybiBbXTtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoXHJcbiAgICAgICFzdGF0ZW1lbnREYXRhLnRyYW5zYWN0aW9ucyB8fFxyXG4gICAgICAhQXJyYXkuaXNBcnJheShzdGF0ZW1lbnREYXRhLnRyYW5zYWN0aW9ucylcclxuICAgICkge1xyXG4gICAgICByZXR1cm4gW107XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHN0YXRlbWVudERhdGEudHJhbnNhY3Rpb25zLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICByZXR1cm4gW107XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IHJ1bm5pbmdUb3RhbFBhaWQgPSAwO1xyXG4gICAgbGV0IHJ1bm5pbmdEdWUgPSBzdGF0ZW1lbnREYXRhLmVucm9sbG1lbnQ/LmN1cnJlbnRCYWxhbmNlIHx8IDA7XHJcblxyXG4gICAgY29uc3Qgc29ydGVkVHJhbnNhY3Rpb25zID0gWy4uLnN0YXRlbWVudERhdGEudHJhbnNhY3Rpb25zXS5zb3J0KFxyXG4gICAgICAoYSwgYikgPT4gbmV3IERhdGUoYS5kYXRlKSAtIG5ldyBEYXRlKGIuZGF0ZSksXHJcbiAgICApO1xyXG5cclxuICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xyXG5cclxuICAgIGZvciAoY29uc3QgaXRlbSBvZiBzb3J0ZWRUcmFuc2FjdGlvbnMpIHtcclxuICAgICAgaWYgKGl0ZW0udHlwZSA9PT0gXCJQYXltZW50XCIpIHtcclxuICAgICAgICBjb25zdCBwYXltZW50QW1vdW50ID0gaXRlbS5jcmVkaXQgfHwgMDtcclxuICAgICAgICBydW5uaW5nVG90YWxQYWlkICs9IHBheW1lbnRBbW91bnQ7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChpdGVtLnR5cGUgPT09IFwiUGVuYWx0eVwiKSB7XHJcbiAgICAgICAgY29uc3QgcGVuYWx0eUFtb3VudCA9IGl0ZW0uZGViaXQgfHwgMDtcclxuICAgICAgICBydW5uaW5nRHVlICs9IHBlbmFsdHlBbW91bnQ7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChpdGVtLnR5cGUgPT09IFwiTGF0ZSBGZWVcIikge1xyXG4gICAgICAgIGNvbnN0IGxhdGVGZWVBbW91bnQgPSBpdGVtLmRlYml0IHx8IDA7XHJcbiAgICAgICAgcnVubmluZ0R1ZSArPSBsYXRlRmVlQW1vdW50O1xyXG4gICAgICB9XHJcblxyXG4gICAgICByZXN1bHQucHVzaCh7XHJcbiAgICAgICAgLi4uaXRlbSxcclxuICAgICAgICBjYWxjdWxhdGVkVG90YWxQYWlkOiBydW5uaW5nVG90YWxQYWlkLFxyXG4gICAgICAgIGNhbGN1bGF0ZWREZWJpdDpcclxuICAgICAgICAgIGl0ZW0udHlwZSA9PT0gXCJQZW5hbHR5XCIgfHwgaXRlbS50eXBlID09PSBcIkxhdGUgRmVlXCJcclxuICAgICAgICAgICAgPyBpdGVtLmRlYml0IHx8IDBcclxuICAgICAgICAgICAgOiAwLFxyXG4gICAgICAgIGNhbGN1bGF0ZWREdWU6IE1hdGguYWJzKHJ1bm5pbmdEdWUpLFxyXG4gICAgICAgIGFjdHVhbER1ZTogcnVubmluZ0R1ZSxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxuICB9LCBbc3RhdGVtZW50RGF0YV0pO1xyXG5cclxuICBjb25zdCB0b3RhbFBlbmFsdHlBbW91bnQgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGlmICghQXJyYXkuaXNBcnJheShwZW5hbHR5SGlzdG9yeURhdGEpKSByZXR1cm4gMDtcclxuICAgIHJldHVybiBwZW5hbHR5SGlzdG9yeURhdGEucmVkdWNlKChzdW0sIGl0ZW0pID0+IHtcclxuICAgICAgcmV0dXJuIHN1bSArICgoaXRlbS5wZW5hbHR5X2Ftb3VudCB8fCAwKSArIChpdGVtLmxhdGVfZmVlX2Ftb3VudCB8fCAwKSk7XHJcbiAgICB9LCAwKTtcclxuICB9LCBbcGVuYWx0eUhpc3RvcnlEYXRhXSk7XHJcblxyXG4gIGNvbnN0IGdyb3VwT3B0aW9ucyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgcmV0dXJuIGdyb3Vwcy5tYXAoKGdyb3VwKSA9PiAoe1xyXG4gICAgICB2YWx1ZTogZ3JvdXAuX2lkLFxyXG4gICAgICBsYWJlbDogZ3JvdXAuZ3JvdXBfbmFtZSxcclxuICAgIH0pKTtcclxuICB9LCBbZ3JvdXBzXSk7XHJcblxyXG4gIGNvbnN0IHBlbmFsdHlIaXN0b3J5Q29sdW1ucyA9IFtcclxuICAgIHtcclxuICAgICAgdGl0bGU6IFwiRGF0ZVwiLFxyXG4gICAgICBkYXRhSW5kZXg6IFwiY3JlYXRlZEF0XCIsXHJcbiAgICAgIGtleTogXCJkYXRlXCIsXHJcbiAgICAgIHJlbmRlcjogKGRhdGUpID0+IChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICA8Q2FsZW5kYXJPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS00MDAgdGV4dC1zbVwiIC8+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgIHttb21lbnQoZGF0ZSkuZm9ybWF0KFwiREQtTU0tWVlZWSBISDptbVwiKX1cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSxcclxuICAgICAgc29ydGVyOiAoYSwgYikgPT4gbmV3IERhdGUoYS5jcmVhdGVkQXQpIC0gbmV3IERhdGUoYi5jcmVhdGVkQXQpLFxyXG4gICAgICBkZWZhdWx0U29ydE9yZGVyOiBcImRlc2NlbmRcIixcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRpdGxlOiBcIlBlbmFsdHkgQW1vdW50XCIsXHJcbiAgICAgIGRhdGFJbmRleDogXCJwZW5hbHR5X2Ftb3VudFwiLFxyXG4gICAgICBrZXk6IFwicGVuYWx0eV9hbW91bnRcIixcclxuICAgICAgYWxpZ246IFwicmlnaHRcIixcclxuICAgICAgcmVuZGVyOiAoYW1vdW50KSA9PiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMlwiPlxyXG4gICAgICAgICAge2Ftb3VudCA+IDAgJiYgKFxyXG4gICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgIDxBcnJvd0Rvd25PdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14c1wiIC8+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgIOKCuXsoYW1vdW50IHx8IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgICB7KCFhbW91bnQgfHwgYW1vdW50ID09PSAwKSAmJiAoXHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIj4tPC9zcGFuPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSxcclxuICAgICAgc29ydGVyOiAoYSwgYikgPT4gKGEucGVuYWx0eV9hbW91bnQgfHwgMCkgLSAoYi5wZW5hbHR5X2Ftb3VudCB8fCAwKSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRpdGxlOiBcIkxhdGUgRmVlXCIsXHJcbiAgICAgIGRhdGFJbmRleDogXCJsYXRlX2ZlZV9hbW91bnRcIixcclxuICAgICAga2V5OiBcImxhdGVfZmVlX2Ftb3VudFwiLFxyXG4gICAgICBhbGlnbjogXCJyaWdodFwiLFxyXG4gICAgICByZW5kZXI6IChhbW91bnQpID0+IChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0yXCI+XHJcbiAgICAgICAgICB7YW1vdW50ID4gMCAmJiAoXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgPEFycm93RG93bk91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtb3JhbmdlLTUwMCB0ZXh0LXhzXCIgLz5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LW9yYW5nZS02MDAgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAg4oK5eyhhbW91bnQgfHwgMCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICAgIHsoIWFtb3VudCB8fCBhbW91bnQgPT09IDApICYmIChcclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiPi08L3NwYW4+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApLFxyXG4gICAgICBzb3J0ZXI6IChhLCBiKSA9PiAoYS5sYXRlX2ZlZV9hbW91bnQgfHwgMCkgLSAoYi5sYXRlX2ZlZV9hbW91bnQgfHwgMCksXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJUb3RhbCBBbW91bnRcIixcclxuICAgICAga2V5OiBcInRvdGFsXCIsXHJcbiAgICAgIGFsaWduOiBcInJpZ2h0XCIsXHJcbiAgICAgIHJlbmRlcjogKF8sIHJlY29yZCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHRvdGFsID1cclxuICAgICAgICAgIChyZWNvcmQucGVuYWx0eV9hbW91bnQgfHwgMCkgKyAocmVjb3JkLmxhdGVfZmVlX2Ftb3VudCB8fCAwKTtcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMlwiPlxyXG4gICAgICAgICAgICA8Q2FsY3VsYXRvck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTUwMCB0ZXh0LXNtXCIgLz5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtcHVycGxlLTcwMFwiPlxyXG4gICAgICAgICAgICAgIOKCuXt0b3RhbC50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApO1xyXG4gICAgICB9LFxyXG4gICAgICBzb3J0ZXI6IChhLCBiKSA9PlxyXG4gICAgICAgIChhLnBlbmFsdHlfYW1vdW50IHx8IDApICtcclxuICAgICAgICAoYS5sYXRlX2ZlZV9hbW91bnQgfHwgMCkgLVxyXG4gICAgICAgICgoYi5wZW5hbHR5X2Ftb3VudCB8fCAwKSArIChiLmxhdGVfZmVlX2Ftb3VudCB8fCAwKSksXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJSZWFzb25cIixcclxuICAgICAgZGF0YUluZGV4OiBcInJlYXNvblwiLFxyXG4gICAgICBrZXk6IFwicmVhc29uXCIsXHJcbiAgICAgIHJlbmRlcjogKHJlYXNvbikgPT4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgIDxGaWxlVGV4dE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgdGV4dC1zbVwiIC8+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgIHtyZWFzb24gfHwgXCJObyByZWFzb24gcHJvdmlkZWRcIn1cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRpdGxlOiBcIlN0YXR1c1wiLFxyXG4gICAgICBkYXRhSW5kZXg6IFwic3RhdHVzXCIsXHJcbiAgICAgIGtleTogXCJzdGF0dXNcIixcclxuICAgICAgcmVuZGVyOiAoc3RhdHVzKSA9PiB7XHJcbiAgICAgICAgY29uc3Qgc3RhdHVzQ29uZmlnID0ge1xyXG4gICAgICAgICAgcGVuZGluZzoge1xyXG4gICAgICAgICAgICBjb2xvcjogXCJnb2xkXCIsXHJcbiAgICAgICAgICAgIGljb246IDxDbG9ja0NpcmNsZU91dGxpbmVkIC8+LFxyXG4gICAgICAgICAgICB0ZXh0OiBcIlBFTkRJTkdcIixcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBwYWlkOiB7IGNvbG9yOiBcImdyZWVuXCIsIGljb246IDxDaGVja0NpcmNsZU91dGxpbmVkIC8+LCB0ZXh0OiBcIlBBSURcIiB9LFxyXG4gICAgICAgICAgY2FuY2VsbGVkOiB7XHJcbiAgICAgICAgICAgIGNvbG9yOiBcInJlZFwiLFxyXG4gICAgICAgICAgICBpY29uOiA8Q2xvc2VDaXJjbGVPdXRsaW5lZCAvPixcclxuICAgICAgICAgICAgdGV4dDogXCJDQU5DRUxMRURcIixcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb25zdCBjb25maWcgPSBzdGF0dXNDb25maWdbc3RhdHVzXSB8fCBzdGF0dXNDb25maWcucGVuZGluZztcclxuXHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgIDxUYWdcclxuICAgICAgICAgICAgY29sb3I9e2NvbmZpZy5jb2xvcn1cclxuICAgICAgICAgICAgaWNvbj17Y29uZmlnLmljb259XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMSByb3VuZGVkLWZ1bGwgZm9udC1zZW1pYm9sZCB0ZXh0LXhzXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2NvbmZpZy50ZXh0fVxyXG4gICAgICAgICAgPC9UYWc+XHJcbiAgICAgICAgKTtcclxuICAgICAgfSxcclxuICAgICAgZmlsdGVyczogW1xyXG4gICAgICAgIHsgdGV4dDogXCJQZW5kaW5nXCIsIHZhbHVlOiBcInBlbmRpbmdcIiB9LFxyXG4gICAgICAgIHsgdGV4dDogXCJQYWlkXCIsIHZhbHVlOiBcInBhaWRcIiB9LFxyXG4gICAgICAgIHsgdGV4dDogXCJDYW5jZWxsZWRcIiwgdmFsdWU6IFwiY2FuY2VsbGVkXCIgfSxcclxuICAgICAgXSxcclxuICAgICAgb25GaWx0ZXI6ICh2YWx1ZSwgcmVjb3JkKSA9PiByZWNvcmQuc3RhdHVzID09PSB2YWx1ZSxcclxuICAgIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgdHJhbnNhY3Rpb25Db2x1bW5zID0gW1xyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJEYXRlXCIsXHJcbiAgICAgIGRhdGFJbmRleDogXCJkYXRlXCIsXHJcbiAgICAgIGtleTogXCJkYXRlXCIsXHJcbiAgICAgIHJlbmRlcjogKGRhdGUpID0+IG1vbWVudChkYXRlKS5mb3JtYXQoXCJERC1NTS1ZWVlZIEhIOm1tXCIpLFxyXG4gICAgICBzb3J0ZXI6IChhLCBiKSA9PiBuZXcgRGF0ZShhLmRhdGUpIC0gbmV3IERhdGUoYi5kYXRlKSxcclxuICAgICAgZGVmYXVsdFNvcnRPcmRlcjogXCJkZXNjZW5kXCIsXHJcbiAgICAgIHdpZHRoOiAxNTAsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJUeXBlXCIsXHJcbiAgICAgIGRhdGFJbmRleDogXCJ0eXBlXCIsXHJcbiAgICAgIGtleTogXCJ0eXBlXCIsXHJcbiAgICAgIHJlbmRlcjogKHR5cGUpID0+IChcclxuICAgICAgICA8VGFnXHJcbiAgICAgICAgICBjb2xvcj17XHJcbiAgICAgICAgICAgIHR5cGUgPT09IFwiUGF5bWVudFwiID8gXCJncmVlblwiIDogdHlwZSA9PT0gXCJQZW5hbHR5XCIgPyBcInJlZFwiIDogXCJvcmFuZ2VcIlxyXG4gICAgICAgICAgfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHt0eXBlID09PSBcIlBheW1lbnRcIlxyXG4gICAgICAgICAgICA/IFwiUGF5bWVudFwiXHJcbiAgICAgICAgICAgIDogdHlwZSA9PT0gXCJQZW5hbHR5XCJcclxuICAgICAgICAgICAgICA/IFwiUGVuYWx0eVwiXHJcbiAgICAgICAgICAgICAgOiBcIkxhdGUgRmVlXCJ9XHJcbiAgICAgICAgPC9UYWc+XHJcbiAgICAgICksXHJcbiAgICAgIHdpZHRoOiAxMDAsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJEZXNjcmlwdGlvblwiLFxyXG4gICAgICBkYXRhSW5kZXg6IFwiZGVzY3JpcHRpb25cIixcclxuICAgICAga2V5OiBcImRlc2NyaXB0aW9uXCIsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJUb3RhbCBQYWlkXCIsXHJcbiAgICAgIGRhdGFJbmRleDogXCJjYWxjdWxhdGVkVG90YWxQYWlkXCIsXHJcbiAgICAgIGtleTogXCJ0b3RhbFBhaWRcIixcclxuICAgICAgYWxpZ246IFwicmlnaHRcIixcclxuICAgICAgcmVuZGVyOiAoYW1vdW50KSA9PiBg4oK5JHsoYW1vdW50IHx8IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRpdGxlOiBcIlBheW1lbnQgKENyZWRpdClcIixcclxuICAgICAgZGF0YUluZGV4OiBcImNyZWRpdFwiLFxyXG4gICAgICBrZXk6IFwiY3JlZGl0XCIsXHJcbiAgICAgIGFsaWduOiBcInJpZ2h0XCIsXHJcbiAgICAgIHJlbmRlcjogKGFtb3VudCkgPT5cclxuICAgICAgICBhbW91bnQgPiAwID8gKFxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDAgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICDigrl7YW1vdW50LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIFwiLVwiXHJcbiAgICAgICAgKSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRpdGxlOiBcIlBlbmFsdHkvTGF0ZSBGZWVcIixcclxuICAgICAga2V5OiBcImRlYml0XCIsXHJcbiAgICAgIGFsaWduOiBcInJpZ2h0XCIsXHJcbiAgICAgIHJlbmRlcjogKF8sIHJlY29yZCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGFtb3VudCA9IHJlY29yZC5jYWxjdWxhdGVkRGViaXQgfHwgMDtcclxuICAgICAgICByZXR1cm4gYW1vdW50ID4gMCA/IChcclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtb3JhbmdlLTYwMCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgIOKCuXthbW91bnQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiPi08L3NwYW4+XHJcbiAgICAgICAgKTtcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRpdGxlOiBcIk91dHN0YW5kaW5nIER1ZSBCYWxhbmNlXCIsXHJcbiAgICAgIGtleTogXCJkdWVcIixcclxuICAgICAgYWxpZ246IFwicmlnaHRcIixcclxuICAgICAgcmVuZGVyOiAoXywgcmVjb3JkKSA9PiB7XHJcbiAgICAgICAgY29uc3QgZGViaXQgPSByZWNvcmQuY2FsY3VsYXRlZERlYml0IHx8IDA7XHJcbiAgICAgICAgaWYgKGRlYml0ID4gMCkge1xyXG4gICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICDigrl7KHJlY29yZC5jYWxjdWxhdGVkRHVlIHx8IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwXCI+LTwvc3Bhbj47XHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGN1c3RvbWVyT3B0aW9ucyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgaWYgKCFzZWxlY3RlZEdyb3VwSWQpIHJldHVybiBbXTtcclxuICAgIGNvbnN0IHVuaXF1ZUN1c3RvbWVycyA9IG5ldyBNYXAoKTtcclxuICAgIGVucm9sbGVkVXNlcnMuZm9yRWFjaCgodXNlcikgPT4ge1xyXG4gICAgICBpZiAoIXVuaXF1ZUN1c3RvbWVycy5oYXModXNlci51c2VySWQpICYmIHVzZXIuYmFsYW5jZSA+IDApIHtcclxuICAgICAgICB1bmlxdWVDdXN0b21lcnMuc2V0KHVzZXIudXNlcklkLCB7XHJcbiAgICAgICAgICB2YWx1ZTogdXNlci51c2VySWQsXHJcbiAgICAgICAgICBsYWJlbDogYCR7dXNlci51c2VyTmFtZX0gLSAke3VzZXIudXNlclBob25lfSAoRHVlOiDigrkkeyh1c2VyLmJhbGFuY2UgfHwgMCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX0pYCxcclxuICAgICAgICAgIHVzZXJOYW1lOiB1c2VyLnVzZXJOYW1lLFxyXG4gICAgICAgICAgdXNlclBob25lOiB1c2VyLnVzZXJQaG9uZSxcclxuICAgICAgICAgIGJhbGFuY2U6IHVzZXIuYmFsYW5jZSxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gQXJyYXkuZnJvbSh1bmlxdWVDdXN0b21lcnMudmFsdWVzKCkpO1xyXG4gIH0sIFtlbnJvbGxlZFVzZXJzLCBzZWxlY3RlZEdyb3VwSWRdKTtcclxuXHJcbiAgY29uc3QgdGlja2V0T3B0aW9ucyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgaWYgKCFzZWxlY3RlZEN1c3RvbWVySWQgfHwgIXNlbGVjdGVkR3JvdXBJZCkgcmV0dXJuIFtdO1xyXG4gICAgY29uc3QgdXNlclRpY2tldHMgPSBlbnJvbGxlZFVzZXJzLmZpbHRlcihcclxuICAgICAgKHVzZXIpID0+IHVzZXIudXNlcklkID09PSBzZWxlY3RlZEN1c3RvbWVySWQgJiYgdXNlci5iYWxhbmNlID4gMCxcclxuICAgICk7XHJcbiAgICByZXR1cm4gdXNlclRpY2tldHMubWFwKCh0aWNrZXQpID0+ICh7XHJcbiAgICAgIHZhbHVlOiB0aWNrZXQudGlja2V0LFxyXG4gICAgICBsYWJlbDogYFRpY2tldDogJHt0aWNrZXQudGlja2V0fSB8IER1ZTog4oK5JHsodGlja2V0LmJhbGFuY2UgfHwgMCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gLFxyXG4gICAgICBiYWxhbmNlOiB0aWNrZXQuYmFsYW5jZSxcclxuICAgICAgdG90YWxQZW5hbHR5OiB0aWNrZXQudG90YWxQZW5hbHR5LFxyXG4gICAgICB0b3RhbExhdGVGZWU6IHRpY2tldC50b3RhbExhdGVGZWUsXHJcbiAgICAgIHVzZXJOYW1lOiB0aWNrZXQudXNlck5hbWUsXHJcbiAgICAgIHVzZXJQaG9uZTogdGlja2V0LnVzZXJQaG9uZSxcclxuICAgICAgZ3JvdXBOYW1lOiB0aWNrZXQuZ3JvdXBOYW1lLFxyXG4gICAgICB1c2VySWQ6IHRpY2tldC51c2VySWQsXHJcbiAgICAgIGVucm9sbG1lbnRJZDogdGlja2V0LmVucm9sbG1lbnRJZCxcclxuICAgIH0pKTtcclxuICB9LCBbZW5yb2xsZWRVc2Vycywgc2VsZWN0ZWRDdXN0b21lcklkLCBzZWxlY3RlZEdyb3VwSWRdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3JvdXBTZWxlY3QgPSAodmFsdWUpID0+IHtcclxuICAgIHNldFNlbGVjdGVkR3JvdXBJZCh2YWx1ZSB8fCBcIlwiKTtcclxuICAgIHNldFNlbGVjdGVkQ3VzdG9tZXJJZChcIlwiKTtcclxuICAgIHNldFNlbGVjdGVkVGlja2V0KFwiXCIpO1xyXG4gICAgc2V0U2VsZWN0ZWRDdXN0b21lck5hbWUoXCJcIik7XHJcblxyXG4gICAgY29uc3Qgc2VsZWN0ZWRHcm91cCA9IGdyb3Vwcy5maW5kKChnKSA9PiBnLl9pZCA9PT0gdmFsdWUpO1xyXG4gICAgc2V0U2VsZWN0ZWRHcm91cE5hbWUoc2VsZWN0ZWRHcm91cD8uZ3JvdXBfbmFtZSB8fCBcIlwiKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDdXN0b21lclNlbGVjdCA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRDdXN0b21lcklkKHZhbHVlIHx8IFwiXCIpO1xyXG4gICAgc2V0U2VsZWN0ZWRUaWNrZXQoXCJcIik7XHJcblxyXG4gICAgY29uc3Qgc2VsZWN0ZWRDdXN0b21lciA9IGN1c3RvbWVyT3B0aW9ucy5maW5kKChjKSA9PiBjLnZhbHVlID09PSB2YWx1ZSk7XHJcbiAgICBzZXRTZWxlY3RlZEN1c3RvbWVyTmFtZShzZWxlY3RlZEN1c3RvbWVyPy51c2VyTmFtZSB8fCBcIlwiKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVUaWNrZXRTZWxlY3QgPSAodmFsdWUpID0+IHtcclxuICAgIHNldFNlbGVjdGVkVGlja2V0KHZhbHVlIHx8IFwiXCIpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoQ3VycmVudFBlbmFsdHlUb3RhbHMgPSBhc3luYyAodXNlcklkLCBncm91cElkLCB0aWNrZXQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL3BlbmFsdHktbWFuYWdlbWVudC9zdGF0ZW1lbnQvJHt1c2VySWR9LyR7Z3JvdXBJZH0vJHt0aWNrZXR9YCxcclxuICAgICAgKTtcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICB0b3RhbFBlbmFsdHk6IHJlc3BvbnNlLmRhdGEuZGF0YS5zdW1tYXJ5Py50b3RhbFBlbmFsdHkgfHwgMCxcclxuICAgICAgICB0b3RhbExhdGVGZWU6IHJlc3BvbnNlLmRhdGEuZGF0YS5zdW1tYXJ5Py50b3RhbExhdGVGZWUgfHwgMCxcclxuICAgICAgICBjdXJyZW50QmFsYW5jZTogcmVzcG9uc2UuZGF0YS5kYXRhLmVucm9sbG1lbnQ/LmN1cnJlbnRCYWxhbmNlIHx8IDAsXHJcbiAgICAgIH07XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcGVuYWx0eSB0b3RhbHM6XCIsIGVycm9yKTtcclxuICAgICAgcmV0dXJuIHsgdG90YWxQZW5hbHR5OiAwLCB0b3RhbExhdGVGZWU6IDAsIGN1cnJlbnRCYWxhbmNlOiAwIH07XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUHJvY2VlZFRvUGVuYWx0eSA9IGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IHNlbGVjdGVkVGlja2V0RGF0YSA9IHRpY2tldE9wdGlvbnMuZmluZChcclxuICAgICAgKHQpID0+IHQudmFsdWUgPT09IHNlbGVjdGVkVGlja2V0LFxyXG4gICAgKTtcclxuXHJcbiAgICBpZiAoIXNlbGVjdGVkVGlja2V0RGF0YSkge1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBzZWxlY3QgYSB2YWxpZCB0aWNrZXRcIixcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgY3VycmVudFRvdGFscyA9IGF3YWl0IGZldGNoQ3VycmVudFBlbmFsdHlUb3RhbHMoXHJcbiAgICAgIHNlbGVjdGVkQ3VzdG9tZXJJZCxcclxuICAgICAgc2VsZWN0ZWRHcm91cElkLFxyXG4gICAgICBzZWxlY3RlZFRpY2tldCxcclxuICAgICk7XHJcblxyXG4gICAgc2V0QWRkUGVuYWx0eURldGFpbHMoe1xyXG4gICAgICB1c2VySWQ6IHNlbGVjdGVkQ3VzdG9tZXJJZCxcclxuICAgICAgdXNlck5hbWU6IHNlbGVjdGVkQ3VzdG9tZXJOYW1lLFxyXG4gICAgICB1c2VyUGhvbmU6IHNlbGVjdGVkVGlja2V0RGF0YS51c2VyUGhvbmUsXHJcbiAgICAgIGdyb3VwSWQ6IHNlbGVjdGVkR3JvdXBJZCxcclxuICAgICAgZ3JvdXBOYW1lOiBzZWxlY3RlZEdyb3VwTmFtZSxcclxuICAgICAgcGF5bWVudHNUaWNrZXQ6IHNlbGVjdGVkVGlja2V0LFxyXG4gICAgICBiYWxhbmNlOiBzZWxlY3RlZFRpY2tldERhdGEuYmFsYW5jZSxcclxuICAgICAgdG90YWxQZW5hbHR5OiBjdXJyZW50VG90YWxzLnRvdGFsUGVuYWx0eSxcclxuICAgICAgdG90YWxMYXRlRmVlOiBjdXJyZW50VG90YWxzLnRvdGFsTGF0ZUZlZSxcclxuICAgICAgY3VycmVudEJhbGFuY2U6IGN1cnJlbnRUb3RhbHMuY3VycmVudEJhbGFuY2UsXHJcbiAgICAgIGVucm9sbG1lbnRJZDogc2VsZWN0ZWRUaWNrZXREYXRhLmVucm9sbG1lbnRJZCxcclxuICAgIH0pO1xyXG5cclxuICAgIHNldEFkZFBlbmFsdHlEcmF3ZXJPcGVuKGZhbHNlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTYXZlUGVuYWx0eSA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmICghYWRkUGVuYWx0eUFtb3VudCAmJiAhYWRkTGF0ZUZlZUFtb3VudCkge1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBlbnRlciBhdCBsZWFzdCBvbmUgYW1vdW50IChQZW5hbHR5IG9yIExhdGUgRmVlKVwiLFxyXG4gICAgICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgICB9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldEFkZFBlbmFsdHlMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoXCIvcGVuYWx0eS1tYW5hZ2VtZW50L2FkZC1wZW5hbHR5XCIsIHtcclxuICAgICAgICB1c2VySWQ6IGFkZFBlbmFsdHlEZXRhaWxzLnVzZXJJZCxcclxuICAgICAgICBncm91cElkOiBhZGRQZW5hbHR5RGV0YWlscy5ncm91cElkLFxyXG4gICAgICAgIGVucm9sbG1lbnRJZDogYWRkUGVuYWx0eURldGFpbHMuZW5yb2xsbWVudElkLFxyXG4gICAgICAgIHRpY2tldDogYWRkUGVuYWx0eURldGFpbHMucGF5bWVudHNUaWNrZXQsXHJcbiAgICAgICAgcGVuYWx0eUFtb3VudDogcGFyc2VGbG9hdChhZGRQZW5hbHR5QW1vdW50KSB8fCAwLFxyXG4gICAgICAgIGxhdGVGZWVBbW91bnQ6IHBhcnNlRmxvYXQoYWRkTGF0ZUZlZUFtb3VudCkgfHwgMCxcclxuICAgICAgICByZWFzb246IFwiTWFudWFsIHBlbmFsdHkgYWRkZWQgYnkgYWRtaW5cIixcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBpZiAocmVzcG9uc2UuZGF0YS5zdWNjZXNzKSB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiUGVuYWx0eSBhZGRlZCBzdWNjZXNzZnVsbHkhXCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgc2V0QWRkUGVuYWx0eURldGFpbHMobnVsbCk7XHJcbiAgICAgICAgc2V0QWRkUGVuYWx0eUFtb3VudChcIlwiKTtcclxuICAgICAgICBzZXRBZGRMYXRlRmVlQW1vdW50KFwiXCIpO1xyXG5cclxuICAgICAgICBhd2FpdCBmZXRjaFBlbmFsdGllcygpO1xyXG5cclxuICAgICAgICBpZiAoXHJcbiAgICAgICAgICBzZWxlY3RlZEdyb3VwSWQgJiZcclxuICAgICAgICAgIHJlc3BvbnNlLmRhdGEuZGF0YT8ucmVtYWluaW5nQmFsYW5jZSAhPT0gdW5kZWZpbmVkXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICBzZXRFbnJvbGxlZFVzZXJzKChwcmV2VXNlcnMpID0+XHJcbiAgICAgICAgICAgIHByZXZVc2Vycy5tYXAoKHVzZXIpID0+XHJcbiAgICAgICAgICAgICAgdXNlci51c2VySWQgPT09IGFkZFBlbmFsdHlEZXRhaWxzLnVzZXJJZCAmJlxyXG4gICAgICAgICAgICAgICAgdXNlci50aWNrZXQgPT09IGFkZFBlbmFsdHlEZXRhaWxzLnBheW1lbnRzVGlja2V0XHJcbiAgICAgICAgICAgICAgICA/IHsgLi4udXNlciwgYmFsYW5jZTogcmVzcG9uc2UuZGF0YS5kYXRhLnJlbWFpbmluZ0JhbGFuY2UgfVxyXG4gICAgICAgICAgICAgICAgOiB1c2VyLFxyXG4gICAgICAgICAgICApLFxyXG4gICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICBzZXREdWVDdXN0b21lcnMoKHByZXZDdXN0b21lcnMpID0+XHJcbiAgICAgICAgICAgIHByZXZDdXN0b21lcnMubWFwKChjdXN0b21lcikgPT5cclxuICAgICAgICAgICAgICBjdXN0b21lci51c2VySWQgPT09IGFkZFBlbmFsdHlEZXRhaWxzLnVzZXJJZCAmJlxyXG4gICAgICAgICAgICAgICAgY3VzdG9tZXIudGlja2V0ID09PSBhZGRQZW5hbHR5RGV0YWlscy5wYXltZW50c1RpY2tldFxyXG4gICAgICAgICAgICAgICAgPyB7XHJcbiAgICAgICAgICAgICAgICAgIC4uLmN1c3RvbWVyLFxyXG4gICAgICAgICAgICAgICAgICBkdWVBbW91bnQ6IHJlc3BvbnNlLmRhdGEuZGF0YS5yZW1haW5pbmdCYWxhbmNlLFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgOiBjdXN0b21lcixcclxuICAgICAgICAgICAgKSxcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihyZXNwb25zZS5kYXRhLm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gYWRkIHBlbmFsdHlcIik7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBzYXZpbmcgcGVuYWx0eTpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOlxyXG4gICAgICAgICAgZXJyb3I/LnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8XHJcbiAgICAgICAgICBlcnJvci5tZXNzYWdlIHx8XHJcbiAgICAgICAgICBcIkZhaWxlZCB0byBhZGQgcGVuYWx0eVwiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRBZGRQZW5hbHR5TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hDdXN0b21lckFsbFBlbmFsdGllcyA9IGFzeW5jICh1c2VySWQsIGdyb3VwSWQsIHRpY2tldCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvcGVuYWx0eS1tYW5hZ2VtZW50L3N0YXRlbWVudC8ke3VzZXJJZH0vJHtncm91cElkfS8ke3RpY2tldH1gLFxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCBzdGF0ZW1lbnREYXRhID0gcmVzcG9uc2UuZGF0YS5kYXRhO1xyXG5cclxuICAgICAgY29uc3QgcGVuYWx0eVRyYW5zYWN0aW9ucyA9XHJcbiAgICAgICAgc3RhdGVtZW50RGF0YS50cmFuc2FjdGlvbnM/LmZpbHRlcihcclxuICAgICAgICAgICh0KSA9PiB0LnR5cGUgPT09IFwiUGVuYWx0eVwiIHx8IHQudHlwZSA9PT0gXCJMYXRlIEZlZVwiLFxyXG4gICAgICAgICkgfHwgW107XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIHBlbmFsdGllczogcGVuYWx0eVRyYW5zYWN0aW9ucyxcclxuICAgICAgICB0b3RhbFBlbmFsdHk6IHN0YXRlbWVudERhdGEuc3VtbWFyeT8udG90YWxQZW5hbHR5IHx8IDAsXHJcbiAgICAgICAgdG90YWxMYXRlRmVlOiBzdGF0ZW1lbnREYXRhLnN1bW1hcnk/LnRvdGFsTGF0ZUZlZSB8fCAwLFxyXG4gICAgICAgIGN1cnJlbnRCYWxhbmNlOiBzdGF0ZW1lbnREYXRhLmVucm9sbG1lbnQ/LmN1cnJlbnRCYWxhbmNlIHx8IDAsXHJcbiAgICAgICAgZW5yb2xsbWVudElkOiBzdGF0ZW1lbnREYXRhLmVucm9sbG1lbnQ/Ll9pZCxcclxuICAgICAgfTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBjdXN0b21lciBwZW5hbHRpZXM6XCIsIGVycm9yKTtcclxuICAgICAgdGhyb3cgZXJyb3I7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlV2FpdmVPZmZQZW5hbHRpZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIXdhaXZlT2ZmQW1vdW50IHx8IHBhcnNlRmxvYXQod2FpdmVPZmZBbW91bnQpIDw9IDApIHtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJQbGVhc2UgZW50ZXIgYSB2YWxpZCBhbW91bnQgdG8gd2FpdmUgb2ZmXCIsXHJcbiAgICAgICAgdHlwZTogXCJ3YXJuaW5nXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgYW1vdW50VG9XYWl2ZSA9IHBhcnNlRmxvYXQod2FpdmVPZmZBbW91bnQpO1xyXG5cclxuICAgIC8vIFZhbGlkYXRpb24gY2hlY2tzXHJcbiAgICBpZiAoXHJcbiAgICAgIHdhaXZlT2ZmVHlwZSA9PT0gXCJwZW5hbHR5XCIgJiZcclxuICAgICAgYW1vdW50VG9XYWl2ZSA+IHdhaXZlT2ZmRGF0YS50b3RhbFBlbmFsdHlcclxuICAgICkge1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBgQ2Fubm90IHdhaXZlIG9mZiBtb3JlIHRoYW4gdG90YWwgcGVuYWx0eSBhbW91bnQgKOKCuSR7d2FpdmVPZmZEYXRhLnRvdGFsUGVuYWx0eS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfSlgLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoXHJcbiAgICAgIHdhaXZlT2ZmVHlwZSA9PT0gXCJsYXRlZmVlXCIgJiZcclxuICAgICAgYW1vdW50VG9XYWl2ZSA+IHdhaXZlT2ZmRGF0YS50b3RhbExhdGVGZWVcclxuICAgICkge1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBgQ2Fubm90IHdhaXZlIG9mZiBtb3JlIHRoYW4gdG90YWwgbGF0ZSBmZWUgYW1vdW50ICjigrkke3dhaXZlT2ZmRGF0YS50b3RhbExhdGVGZWUudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX0pYCxcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKFxyXG4gICAgICB3YWl2ZU9mZlR5cGUgPT09IFwiYm90aFwiICYmXHJcbiAgICAgIGFtb3VudFRvV2FpdmUgPiB3YWl2ZU9mZkRhdGEudG90YWxQZW5hbHR5ICsgd2FpdmVPZmZEYXRhLnRvdGFsTGF0ZUZlZVxyXG4gICAgKSB7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IGBDYW5ub3Qgd2FpdmUgb2ZmIG1vcmUgdGhhbiB0b3RhbCBwZW5hbHR5ICsgbGF0ZSBmZWUgYW1vdW50ICjigrkkeyh3YWl2ZU9mZkRhdGEudG90YWxQZW5hbHR5ICsgd2FpdmVPZmZEYXRhLnRvdGFsTGF0ZUZlZSkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX0pYCxcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0SXNXYWl2aW5nT2ZmKHRydWUpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoXHJcbiAgICAgICAgXCIvcGVuYWx0eS1tYW5hZ2VtZW50L3dhaXZlLW9mZi1wZW5hbHRpZXNcIixcclxuICAgICAgICB7XHJcbiAgICAgICAgICB1c2VySWQ6IHdhaXZlT2ZmRGF0YS51c2VySWQsXHJcbiAgICAgICAgICBncm91cElkOiB3YWl2ZU9mZkRhdGEuZ3JvdXBJZCxcclxuICAgICAgICAgIGVucm9sbG1lbnRJZDogd2FpdmVPZmZEYXRhLmVucm9sbG1lbnRJZCxcclxuICAgICAgICAgIHRpY2tldDogd2FpdmVPZmZEYXRhLnRpY2tldCxcclxuICAgICAgICAgIHdhaXZlT2ZmQW1vdW50OiBhbW91bnRUb1dhaXZlLFxyXG4gICAgICAgICAgd2FpdmVPZmZUeXBlOiB3YWl2ZU9mZlR5cGUsXHJcbiAgICAgICAgICByZWFzb246XHJcbiAgICAgICAgICAgIHdhaXZlT2ZmUmVhc29uIHx8XHJcbiAgICAgICAgICAgIGBXYWl2ZWQgb2ZmIGJ5IGFkbWluIC0gJHtuZXcgRGF0ZSgpLnRvTG9jYWxlU3RyaW5nKCl9YCxcclxuICAgICAgICB9LFxyXG4gICAgICApO1xyXG5cclxuICAgICAgaWYgKHJlc3BvbnNlLmRhdGEuc3VjY2Vzcykge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBg4pyFIFN1Y2Nlc3NmdWxseSB3YWl2ZWQgb2ZmIOKCuSR7YW1vdW50VG9XYWl2ZS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWAsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgLy8gQ2xvc2UgbW9kYWwgYW5kIHJlZnJlc2hcclxuICAgICAgICBzZXRXYWl2ZU9mZk1vZGFsVmlzaWJsZShmYWxzZSk7XHJcbiAgICAgICAgc2V0V2FpdmVPZmZEYXRhKG51bGwpO1xyXG4gICAgICAgIHNldFdhaXZlT2ZmQW1vdW50KFwiXCIpO1xyXG4gICAgICAgIHNldFdhaXZlT2ZmUmVhc29uKFwiXCIpO1xyXG4gICAgICAgIHNldFdhaXZlT2ZmVHlwZShcImJvdGhcIik7XHJcblxyXG4gICAgICAgIC8vIFJlZnJlc2ggYWxsIGRhdGFcclxuICAgICAgICBhd2FpdCBmZXRjaFBlbmFsdGllcygpO1xyXG4gICAgICAgIGlmIChzZWxlY3RlZEdyb3VwSWQpIHtcclxuICAgICAgICAgIGF3YWl0IGZldGNoRHVlQ3VzdG9tZXJzKHNlbGVjdGVkR3JvdXBJZCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcclxuICAgICAgICAgIHJlc3BvbnNlLmRhdGEubWVzc2FnZSB8fCBcIkZhaWxlZCB0byB3YWl2ZSBvZmYgcGVuYWx0aWVzXCIsXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHdhaXZpbmcgb2ZmIHBlbmFsdGllczpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOlxyXG4gICAgICAgICAgZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gd2FpdmUgb2ZmIHBlbmFsdGllc1wiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc1dhaXZpbmdPZmYoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZU9wZW5XYWl2ZU9mZk1vZGFsID0gYXN5bmMgKHJlY29yZCkgPT4ge1xyXG4gICAgLy8gR2V0IHRoZSBwZW5hbHR5IGRhdGEgZnJvbSB0aGUgcmVjb3JkXHJcbiAgICBjb25zdCBwZW5hbHR5RGF0YSA9IHJlY29yZC5yYXdfcGVuYWx0eSB8fCByZWNvcmQ7XHJcblxyXG4gICAgaWYgKCFwZW5hbHR5RGF0YSkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiTm8gcGVuYWx0eSBkYXRhIGZvdW5kXCIpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIk5vIHBlbmFsdHkgZGF0YSBmb3VuZFwiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRTZWxlY3RlZEN1c3RvbWVyRm9yV2FpdmUocmVjb3JkKTtcclxuICAgIHNldElzTG9hZGluZ1N0YXRlbWVudCh0cnVlKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICAvLyBGZXRjaCBjdXN0b21lciBwZW5hbHRpZXMgdXNpbmcgdGhlIHN0YXRlbWVudCBBUElcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvcGVuYWx0eS1tYW5hZ2VtZW50L3N0YXRlbWVudC8ke3BlbmFsdHlEYXRhLnVzZXJfaWQuX2lkfS8ke3BlbmFsdHlEYXRhLmdyb3VwX2lkLl9pZH0vJHtwZW5hbHR5RGF0YS50aWNrZXR9YCxcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGNvbnN0IHN0YXRlbWVudERhdGEgPSByZXNwb25zZS5kYXRhLmRhdGE7XHJcblxyXG4gICAgICAvLyBDYWxjdWxhdGUgdG90YWwgcGVuYWx0eSBhbmQgbGF0ZSBmZWUgZnJvbSBhbGwgcGVuYWx0aWVzXHJcbiAgICAgIGNvbnN0IHBlbmFsdHlUcmFuc2FjdGlvbnMgPVxyXG4gICAgICAgIHN0YXRlbWVudERhdGEudHJhbnNhY3Rpb25zPy5maWx0ZXIoXHJcbiAgICAgICAgICAodCkgPT4gdC50eXBlID09PSBcIlBlbmFsdHlcIiB8fCB0LnR5cGUgPT09IFwiTGF0ZSBGZWVcIixcclxuICAgICAgICApIHx8IFtdO1xyXG5cclxuICAgICAgY29uc3QgdG90YWxQZW5hbHR5ID0gcGVuYWx0eVRyYW5zYWN0aW9uc1xyXG4gICAgICAgIC5maWx0ZXIoKHQpID0+IHQudHlwZSA9PT0gXCJQZW5hbHR5XCIpXHJcbiAgICAgICAgLnJlZHVjZSgoc3VtLCB0KSA9PiBzdW0gKyAodC5kZWJpdCB8fCAwKSwgMCk7XHJcblxyXG4gICAgICBjb25zdCB0b3RhbExhdGVGZWUgPSBwZW5hbHR5VHJhbnNhY3Rpb25zXHJcbiAgICAgICAgLmZpbHRlcigodCkgPT4gdC50eXBlID09PSBcIkxhdGUgRmVlXCIpXHJcbiAgICAgICAgLnJlZHVjZSgoc3VtLCB0KSA9PiBzdW0gKyAodC5kZWJpdCB8fCAwKSwgMCk7XHJcblxyXG4gICAgICBzZXRXYWl2ZU9mZkRhdGEoe1xyXG4gICAgICAgIHVzZXJJZDogcGVuYWx0eURhdGEudXNlcl9pZC5faWQsXHJcbiAgICAgICAgdXNlck5hbWU6IHBlbmFsdHlEYXRhLnVzZXJfaWQuZnVsbF9uYW1lLFxyXG4gICAgICAgIHVzZXJQaG9uZTogcGVuYWx0eURhdGEudXNlcl9pZC5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgZ3JvdXBJZDogcGVuYWx0eURhdGEuZ3JvdXBfaWQuX2lkLFxyXG4gICAgICAgIGdyb3VwTmFtZTogcGVuYWx0eURhdGEuZ3JvdXBfaWQuZ3JvdXBfbmFtZSxcclxuICAgICAgICB0aWNrZXQ6IHBlbmFsdHlEYXRhLnRpY2tldCxcclxuICAgICAgICBlbnJvbGxtZW50SWQ6IHBlbmFsdHlEYXRhLmVucm9sbG1lbnRfaWQsXHJcbiAgICAgICAgdG90YWxQZW5hbHR5OiB0b3RhbFBlbmFsdHksXHJcbiAgICAgICAgdG90YWxMYXRlRmVlOiB0b3RhbExhdGVGZWUsXHJcbiAgICAgICAgY3VycmVudEJhbGFuY2U6IHN0YXRlbWVudERhdGEuZW5yb2xsbWVudD8uY3VycmVudEJhbGFuY2UgfHwgMCxcclxuICAgICAgICBwZW5hbHRpZXM6IHBlbmFsdHlUcmFuc2FjdGlvbnMsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc2V0V2FpdmVPZmZNb2RhbFZpc2libGUodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgY3VzdG9tZXIgcGVuYWx0aWVzOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6XHJcbiAgICAgICAgICBcIkZhaWxlZCB0byBmZXRjaCBjdXN0b21lciBwZW5hbHR5IGRhdGE6IFwiICtcclxuICAgICAgICAgIChlcnJvci5tZXNzYWdlIHx8IFwiVW5rbm93biBlcnJvclwiKSxcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nU3RhdGVtZW50KGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaFdhaXZlckhpc3RvcnkgPSBhc3luYyAodXNlcklkLCBncm91cElkLCB0aWNrZXQpID0+IHtcclxuICAgIHNldElzTG9hZGluZ1dhaXZlckhpc3RvcnkodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICAvLyBZb3UnbGwgbmVlZCB0byBjcmVhdGUgdGhpcyBlbmRwb2ludCBpbiB5b3VyIGJhY2tlbmRcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvcGVuYWx0eS1tYW5hZ2VtZW50L3dhaXZlci1oaXN0b3J5LyR7dXNlcklkfS8ke2dyb3VwSWR9LyR7dGlja2V0fWAsXHJcbiAgICAgICk7XHJcbiAgICAgIHNldFdhaXZlckhpc3RvcnlEYXRhKHJlc3BvbnNlLmRhdGEuZGF0YSB8fCBbXSk7XHJcbiAgICAgIHNldFdhaXZlckhpc3RvcnlNb2RhbFZpc2libGUodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgd2FpdmVyIGhpc3Rvcnk6XCIsIGVycm9yKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gZmV0Y2ggd2FpdmVyIGhpc3RvcnlcIixcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nV2FpdmVySGlzdG9yeShmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlUGVuYWx0eSA9IGFzeW5jIChwZW5hbHR5SWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmRlbGV0ZShcclxuICAgICAgICBgL3BlbmFsdHktbWFuYWdlbWVudC9kZWxldGUtcGVuYWx0eS8ke3BlbmFsdHlJZH1gLFxyXG4gICAgICApO1xyXG4gICAgICBpZiAocmVzcG9uc2UuZGF0YS5zdWNjZXNzKSB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiUGVuYWx0eSBkZWxldGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgZmV0Y2hQZW5hbHRpZXMoKTtcclxuICAgICAgICBpZiAoc2VsZWN0ZWRHcm91cElkKSB7XHJcbiAgICAgICAgICBmZXRjaER1ZUN1c3RvbWVycyhzZWxlY3RlZEdyb3VwSWQpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIHBlbmFsdHk6XCIsIGVycm9yKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJGYWlsZWQgdG8gZGVsZXRlIHBlbmFsdHlcIixcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNsb3NlRmlyc3REcmF3ZXIgPSAoKSA9PiB7XHJcbiAgICBzZXRBZGRQZW5hbHR5RHJhd2VyT3BlbihmYWxzZSk7XHJcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgc2V0U2VsZWN0ZWRHcm91cElkKFwiXCIpO1xyXG4gICAgICBzZXRTZWxlY3RlZEdyb3VwTmFtZShcIlwiKTtcclxuICAgICAgc2V0U2VsZWN0ZWRDdXN0b21lcklkKFwiXCIpO1xyXG4gICAgICBzZXRTZWxlY3RlZEN1c3RvbWVyTmFtZShcIlwiKTtcclxuICAgICAgc2V0U2VsZWN0ZWRUaWNrZXQoXCJcIik7XHJcbiAgICB9LCAzMDApO1xyXG4gIH07XHJcblxyXG4gIC8vIE9wZW4gYmF0Y2ggd2FpdmUgbW9kYWwgd2l0aCBsb2FkZXJcclxuICBjb25zdCBvcGVuQmF0Y2hXYWl2ZU1vZGFsID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgc2V0QmF0Y2hXYWl2ZU1vZGFsVmlzaWJsZSh0cnVlKTtcclxuICAgIC8vIEZldGNoIGN1c3RvbWVycyBvbmx5IGFmdGVyIG1vZGFsIGlzIG9wZW4gdG8gc2hvdyBsb2FkZXJcclxuICAgIGF3YWl0IGZldGNoQ3VzdG9tZXJzV2l0aFBlbmFsdGllcygpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGxvYW5Db2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJkYXRlXCIsIGhlYWRlcjogXCJEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImxvYW5faWRcIiwgaGVhZGVyOiBcIkxvYW4gSURcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJwZW5hbHR5X2Ftb3VudFwiLCBoZWFkZXI6IFwiUGVuYWx0eSBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxfYW1vdW50XCIsIGhlYWRlcjogXCJUb3RhbFwiIH0sXHJcbiAgICB7IGtleTogXCJyZWFzb25cIiwgaGVhZGVyOiBcIlJlYXNvblwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgbG9hbkV4cG9ydENvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImRhdGVcIiwgaGVhZGVyOiBcIkRhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwibG9hbl9pZFwiLCBoZWFkZXI6IFwiTG9hbiBJRFwiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcl9uYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcInBlbmFsdHlfYW1vdW50XCIsIGhlYWRlcjogXCJQZW5hbHR5IEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJ0b3RhbF9hbW91bnRcIiwgaGVhZGVyOiBcIlRvdGFsXCIgfSxcclxuICAgIHsga2V5OiBcInJlYXNvblwiLCBoZWFkZXI6IFwiUmVhc29uXCIgfSxcclxuICBdO1xyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImRhdGVcIiwgaGVhZGVyOiBcIkRhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBfbmFtZVwiLCBoZWFkZXI6IFwiR3JvdXBcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwiIH0sXHJcbiAgICB7IGtleTogXCJ0b3RhbF9wYWlkXCIsIGhlYWRlcjogXCJUb3RhbCBQYWlkXCIgfSxcclxuICAgIHsga2V5OiBcImJhbGFuY2VcIiwgaGVhZGVyOiBcIkJhbGFuY2VcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmFsYW5jZV9zdGF0dXNcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgICB7IGtleTogXCJwZW5hbHR5X2Ftb3VudFwiLCBoZWFkZXI6IFwiUGVuYWx0eVwiIH0sXHJcbiAgICB7IGtleTogXCJsYXRlX2ZlZV9hbW91bnRcIiwgaGVhZGVyOiBcIkxhdGUgRmVlXCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsX2Ftb3VudFwiLCBoZWFkZXI6IFwiVG90YWxcIiB9LFxyXG4gICAgeyBrZXk6IFwicGVuYWx0eV9wbHVzX2R1ZVwiLCBoZWFkZXI6IFwiYmFsYW5jZSArIFBlbmFsdHlcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVhc29uXCIsIGhlYWRlcjogXCJSZWFzb25cIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGV4Y2VsY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiZGF0ZVwiLCBoZWFkZXI6IFwiRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJHcm91cFwiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcl9uYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lclwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lXCIgfSxcclxuICAgIHsga2V5OiBcInRpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0XCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsX3BhaWRfcmF3XCIsIGhlYWRlcjogXCJUb3RhbCBQYWlkXCIgfSxcclxuICAgIHsga2V5OiBcImJhbGFuY2VfcmF3XCIsIGhlYWRlcjogXCJCYWxhbmNlXCIgfSxcclxuICAgIHsga2V5OiBcImJhbGFuY2Vfc3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwicGVuYWx0eV9hbW91bnRfcmF3XCIsIGhlYWRlcjogXCJQZW5hbHR5XCIgfSxcclxuICAgIHsga2V5OiBcImxhdGVfZmVlX2Ftb3VudF9yYXdcIiwgaGVhZGVyOiBcIkxhdGUgRmVlXCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsX2Ftb3VudF9yYXdcIiwgaGVhZGVyOiBcIlRvdGFsXCIgfSxcclxuICAgIHsga2V5OiBcInBlbmFsdHlfcGx1c19kdWVfcmF3XCIsIGhlYWRlcjogXCJCYWxhbmNlICsgUGVuYWx0eVwiIH0sXHJcbiAgICB7IGtleTogXCJyZWFzb25cIiwgaGVhZGVyOiBcIlJlYXNvblwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgZmlsdGVyUGVuYWx0aWVzID0gKGRhdGEsIHNlYXJjaCkgPT4ge1xyXG4gICAgaWYgKCFzZWFyY2gpIHJldHVybiBkYXRhO1xyXG4gICAgcmV0dXJuIGRhdGEuZmlsdGVyKFxyXG4gICAgICAoaXRlbSkgPT5cclxuICAgICAgICBpdGVtLmN1c3RvbWVyX25hbWU/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoLnRvTG93ZXJDYXNlKCkpIHx8XHJcbiAgICAgICAgaXRlbS5ncm91cF9uYW1lPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaC50b0xvd2VyQ2FzZSgpKSB8fFxyXG4gICAgICAgIGl0ZW0udGlja2V0Py50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaC50b0xvd2VyQ2FzZSgpKSB8fFxyXG4gICAgICAgIGl0ZW0ucGhvbmVfbnVtYmVyPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaC50b0xvd2VyQ2FzZSgpKSxcclxuICAgICk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgc3VtbWFyeURhdGEgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IHRvdGFsUGVuYWx0eSA9IHBlbmFsdGllcy5yZWR1Y2UoXHJcbiAgICAgIChzdW0sIHApID0+IHN1bSArIChwLnBlbmFsdHlfYW1vdW50IHx8IDApLFxyXG4gICAgICAwLFxyXG4gICAgKTtcclxuICAgIGNvbnN0IHRvdGFsTGF0ZUZlZSA9IHBlbmFsdGllcy5yZWR1Y2UoXHJcbiAgICAgIChzdW0sIHApID0+IHN1bSArIChwLmxhdGVfZmVlX2Ftb3VudCB8fCAwKSxcclxuICAgICAgMCxcclxuICAgICk7XHJcbiAgICBjb25zdCB0b3RhbFBlbmFsdGllcyA9IHBlbmFsdGllcy5sZW5ndGg7XHJcblxyXG4gICAgbGV0IHRvdGFsRHVlID0gMDtcclxuICAgIGxldCB0b3RhbEV4Y2VzcyA9IDA7XHJcbiAgICBsZXQgZHVlQ291bnQgPSAwO1xyXG4gICAgbGV0IGV4Y2Vzc0NvdW50ID0gMDtcclxuXHJcbiAgICBwZW5hbHRpZXMuZm9yRWFjaCgocGVuYWx0eSkgPT4ge1xyXG4gICAgICBjb25zdCBiYWxhbmNlID0gcGVuYWx0eS5jdXJyZW50X2JhbGFuY2UgfHwgMDtcclxuICAgICAgaWYgKGJhbGFuY2UgPiAwKSB7XHJcbiAgICAgICAgdG90YWxEdWUgKz0gYmFsYW5jZTtcclxuICAgICAgICBkdWVDb3VudCsrO1xyXG4gICAgICB9IGVsc2UgaWYgKGJhbGFuY2UgPCAwKSB7XHJcbiAgICAgICAgdG90YWxFeGNlc3MgKz0gTWF0aC5hYnMoYmFsYW5jZSk7XHJcbiAgICAgICAgZXhjZXNzQ291bnQrKztcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgdG90YWxQZW5hbHR5LFxyXG4gICAgICB0b3RhbExhdGVGZWUsXHJcbiAgICAgIHRvdGFsUGVuYWx0aWVzLFxyXG4gICAgICB0b3RhbER1ZSxcclxuICAgICAgdG90YWxFeGNlc3MsXHJcbiAgICAgIGR1ZUNvdW50LFxyXG4gICAgICBleGNlc3NDb3VudCxcclxuICAgIH07XHJcbiAgfSwgW3BlbmFsdGllc10pO1xyXG5cclxuICBjb25zdCBsb2FuU3VtbWFyeURhdGEgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIGNvbnN0IHRvdGFsUGVuYWx0aWVzID0gbG9hblRhYmxlRGF0YS5sZW5ndGg7XHJcbiAgICBjb25zdCB0b3RhbFBlbmFsdHlBbW91bnQgPSBsb2FuVGFibGVEYXRhLnJlZHVjZSgoc3VtLCBpdGVtKSA9PiBzdW0gKyAoaXRlbS5wZW5hbHR5X2Ftb3VudCB8fCAwKSwgMCk7XHJcbiAgICAvLyBPcHRpb25hbGx5IGNvdW50IGRpc3RpbmN0IGN1c3RvbWVyc1xyXG4gICAgY29uc3QgdW5pcXVlQ3VzdG9tZXJzID0gbmV3IFNldChsb2FuVGFibGVEYXRhLm1hcChpdGVtID0+IGl0ZW0uY3VzdG9tZXJfbmFtZSkpLnNpemU7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICB0b3RhbFBlbmFsdGllcyxcclxuICAgICAgdG90YWxQZW5hbHR5QW1vdW50LFxyXG4gICAgICB1bmlxdWVDdXN0b21lcnMsXHJcbiAgICB9O1xyXG4gIH0sIFtsb2FuVGFibGVEYXRhXSk7XHJcblxyXG4gIC8vIEJhdGNoIFdhaXZlIENvbHVtbnNcclxuICBjb25zdCBiYXRjaFdhaXZlQ29sdW1ucyA9IFtcclxuICAgIHtcclxuICAgICAgdGl0bGU6IChcclxuICAgICAgICA8Q2hlY2tib3hcclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoZS50YXJnZXQuY2hlY2tlZCkge1xyXG4gICAgICAgICAgICAgIHNldFNlbGVjdGVkQ3VzdG9tZXJzKGN1c3RvbWVyc1dpdGhQZW5hbHRpZXMpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgIHNldFNlbGVjdGVkQ3VzdG9tZXJzKFtdKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfX1cclxuICAgICAgICAvPlxyXG4gICAgICApLFxyXG4gICAgICBkYXRhSW5kZXg6IFwic2VsZWN0aW9uXCIsXHJcbiAgICAgIGtleTogXCJzZWxlY3Rpb25cIixcclxuICAgICAgd2lkdGg6IDUwLFxyXG4gICAgICByZW5kZXI6IChfLCByZWNvcmQpID0+IChcclxuICAgICAgICA8Q2hlY2tib3hcclxuICAgICAgICAgIGNoZWNrZWQ9e3NlbGVjdGVkQ3VzdG9tZXJzLnNvbWUoKGMpID0+IGMudXNlcklkID09PSByZWNvcmQudXNlcklkKX1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoZS50YXJnZXQuY2hlY2tlZCkge1xyXG4gICAgICAgICAgICAgIHNldFNlbGVjdGVkQ3VzdG9tZXJzKFsuLi5zZWxlY3RlZEN1c3RvbWVycywgcmVjb3JkXSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRDdXN0b21lcnMoXHJcbiAgICAgICAgICAgICAgICBzZWxlY3RlZEN1c3RvbWVycy5maWx0ZXIoKGMpID0+IGMudXNlcklkICE9PSByZWNvcmQudXNlcklkKSxcclxuICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICksXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJDdXN0b21lciBOYW1lXCIsXHJcbiAgICAgIGRhdGFJbmRleDogXCJ1c2VyTmFtZVwiLFxyXG4gICAgICBrZXk6IFwidXNlck5hbWVcIixcclxuICAgICAgc29ydGVyOiAoYSwgYikgPT4gYS51c2VyTmFtZS5sb2NhbGVDb21wYXJlKGIudXNlck5hbWUpLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdGl0bGU6IFwiUGhvbmUgTnVtYmVyXCIsXHJcbiAgICAgIGRhdGFJbmRleDogXCJ1c2VyUGhvbmVcIixcclxuICAgICAga2V5OiBcInVzZXJQaG9uZVwiLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgdGl0bGU6IFwiVG90YWwgUGVuYWx0eVwiLFxyXG4gICAgICBkYXRhSW5kZXg6IFwidG90YWxQZW5hbHR5XCIsXHJcbiAgICAgIGtleTogXCJ0b3RhbFBlbmFsdHlcIixcclxuICAgICAgYWxpZ246IFwicmlnaHRcIixcclxuICAgICAgcmVuZGVyOiAoYW1vdW50KSA9PiAoXHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgIOKCuXthbW91bnQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICksXHJcbiAgICAgIHNvcnRlcjogKGEsIGIpID0+IGEudG90YWxQZW5hbHR5IC0gYi50b3RhbFBlbmFsdHksXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJUb3RhbCBMYXRlIEZlZVwiLFxyXG4gICAgICBkYXRhSW5kZXg6IFwidG90YWxMYXRlRmVlXCIsXHJcbiAgICAgIGtleTogXCJ0b3RhbExhdGVGZWVcIixcclxuICAgICAgYWxpZ246IFwicmlnaHRcIixcclxuICAgICAgcmVuZGVyOiAoYW1vdW50KSA9PiAoXHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1vcmFuZ2UtNjAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgIOKCuXthbW91bnQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICA8L3NwYW4+XHJcbiAgICAgICksXHJcbiAgICAgIHNvcnRlcjogKGEsIGIpID0+IGEudG90YWxMYXRlRmVlIC0gYi50b3RhbExhdGVGZWUsXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICB0aXRsZTogXCJUb3RhbCBEdWVcIixcclxuICAgICAgZGF0YUluZGV4OiBcInRvdGFsRHVlXCIsXHJcbiAgICAgIGtleTogXCJ0b3RhbER1ZVwiLFxyXG4gICAgICBhbGlnbjogXCJyaWdodFwiLFxyXG4gICAgICByZW5kZXI6IChhbW91bnQpID0+IChcclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS02MDAgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICDigrl7YW1vdW50LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICApLFxyXG4gICAgICBzb3J0ZXI6IChhLCBiKSA9PiBhLnRvdGFsRHVlIC0gYi50b3RhbER1ZSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHRpdGxlOiBcIlRpY2tldHMgQ291bnRcIixcclxuICAgICAgZGF0YUluZGV4OiBcInRpY2tldHNcIixcclxuICAgICAga2V5OiBcInRpY2tldHNDb3VudFwiLFxyXG4gICAgICBhbGlnbjogXCJjZW50ZXJcIixcclxuICAgICAgcmVuZGVyOiAodGlja2V0cykgPT4gdGlja2V0cy5sZW5ndGgsXHJcbiAgICB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IHNlbGVjdGVkQ3VzdG9tZXIgPSB1c2Vycy5maW5kKFxyXG4gICAgKHVzZXIpID0+IHVzZXIuX2lkID09PSBzZWxlY3RlZFVzZXJJZFxyXG4gICk7XHJcbiAgY29uc3QgZ2V0RHVlSW5mbyA9IChlbmREYXRlKSA9PiB7XHJcbiAgICBpZiAoIWVuZERhdGUpIHJldHVybiBudWxsO1xyXG5cclxuICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKGVuZERhdGUpO1xyXG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG5cclxuICAgIC8vIHJlbW92ZSB0aW1lIHBhcnQgZm9yIGFjY3VyYXRlIGRheSBkaWZmXHJcbiAgICBlbmQuc2V0SG91cnMoMCwgMCwgMCwgMCk7XHJcbiAgICB0b2RheS5zZXRIb3VycygwLCAwLCAwLCAwKTtcclxuXHJcbiAgICBjb25zdCBkaWZmVGltZSA9IHRvZGF5IC0gZW5kO1xyXG4gICAgY29uc3QgZGlmZkRheXMgPSBNYXRoLmZsb29yKGRpZmZUaW1lIC8gKDEwMDAgKiA2MCAqIDYwICogMjQpKTtcclxuXHJcbiAgICBpZiAoZGlmZkRheXMgPiAwKSB7XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgc3RhdHVzOiBcIm92ZXJkdWVcIixcclxuICAgICAgICB0ZXh0OiBgJHtkaWZmRGF5c30gZGF5KHMpIG92ZXJkdWVgLFxyXG4gICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChkaWZmRGF5cyA8IDApIHtcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICBzdGF0dXM6IFwidXBjb21pbmdcIixcclxuICAgICAgICB0ZXh0OiBgJHtNYXRoLmFicyhkaWZmRGF5cyl9IGRheShzKSByZW1haW5pbmdgLFxyXG4gICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN0YXR1czogXCJ0b2RheVwiLFxyXG4gICAgICB0ZXh0OiBcIkR1ZSB0b2RheVwiLFxyXG4gICAgfTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gbXQtMjAgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ncmF5LTUwIHRvLWdyYXktMTAwXCI+XHJcbiAgICAgIDxDdXN0b21BbGVydFxyXG4gICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgICAgb25DbG9zZT17KCkgPT5cclxuICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuICAgICAgICB9XHJcbiAgICAgIC8+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXhcIj5cclxuICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17KGUpID0+IHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAvPlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTZcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOCBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgUGVuYWx0eSBNYW5hZ2VtZW50XHJcbiAgICAgICAgICAgICAgPC9oMT5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgZmxleCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPXthY3RpdmVQZW5hbHR5VmlldyA9PT0gXCJjaGl0XCIgPyBcInByaW1hcnlcIiA6IFwiZGVmYXVsdFwifVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVQZW5hbHR5VmlldyhcImNoaXRcIil9XHJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIENoaXQgUGVuYWx0aWVzXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT17YWN0aXZlUGVuYWx0eVZpZXcgPT09IFwibG9hblwiID8gXCJwcmltYXJ5XCIgOiBcImRlZmF1bHRcIn1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlUGVuYWx0eVZpZXcoXCJsb2FuXCIpfVxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBMb2FuIFBlbmFsdGllc1xyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgTW9uaXRvciBhbmQgZWZmaWNpZW50bHkgbWFuYWdlIGN1c3RvbWVyIHBlbmFsdGllcywgbGF0ZSBmZWVzLFxyXG4gICAgICAgICAgICAgICAgYW5kIG91dHN0YW5kaW5nIGJhbGFuY2VzIGluIG9uZSBwbGFjZS5cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTNcIj5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICBpY29uPXs8R2lmdE91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17b3BlbkJhdGNoV2FpdmVNb2RhbH1cclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXthY3RpdmVQZW5hbHR5VmlldyA9PT0gXCJsb2FuXCJ9XHJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IFwiIzdjM2FlZFwiLCBib3JkZXJDb2xvcjogXCIjN2MzYWVkXCIgfX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBXYWl2ZSBPZmZcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICBpY29uPXs8Q2FsY3VsYXRvck91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWRkUGVuYWx0eURyYXdlck9wZW4odHJ1ZSl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQWRkIFBlbmFsdHlcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogRmlsdGVyIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93IG1iLTYgcC00XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTRcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkXCI+UGVuYWx0eSBGaWx0ZXI8L2gzPlxyXG4gICAgICAgICAgICAgIDxCdXR0b24gaWNvbj17PFJlbG9hZE91dGxpbmVkIC8+fSBvbkNsaWNrPXtmZXRjaFBlbmFsdGllc30+XHJcbiAgICAgICAgICAgICAgICBSZWZyZXNoXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy00IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgey8qIEdyb3VwIEZpbHRlciAqL31cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIHthY3RpdmVQZW5hbHR5VmlldyA9PT0gXCJjaGl0XCIgPyBcIkdyb3VwXCIgOiBcIkN1c3RvbWVyXCJ9XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFsbCBHcm91cHNcIlxyXG4gICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3BlbmFsdHlGaWx0ZXJzLmdyb3VwSWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHNldFBlbmFsdHlGaWx0ZXJzKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgIGdyb3VwSWQ6IHZhbHVlIHx8IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24/LmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICA/LnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBTdGFydCBEYXRlICovfVxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgU3RhcnQgRGF0ZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtwZW5hbHR5RmlsdGVycy5zdGFydERhdGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBzZXRQZW5hbHR5RmlsdGVycygocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdGFydERhdGU6IGUudGFyZ2V0LnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogRW5kIERhdGUgKi99XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICBFbmQgRGF0ZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtwZW5hbHR5RmlsdGVycy5lbmREYXRlfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0UGVuYWx0eUZpbHRlcnMoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgZW5kRGF0ZTogZS50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBDbGVhciBCdXR0b24gKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwibWlkZGxlXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICBzZXRQZW5hbHR5RmlsdGVycyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICBncm91cElkOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgc3RhcnREYXRlOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgZW5kRGF0ZTogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIENsZWFyIEZpbHRlcnNcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBTdW1tYXJ5IENhcmRzICovfVxyXG4gICAgICAgICAge2FjdGl2ZVBlbmFsdHlWaWV3ID09PSBcImNoaXRcIiAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3cgbWItNiBwLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIHsvKiBUb3RhbCBQZW5hbHRpZXMgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93IHAtNCBib3JkZXItbC00IGJvcmRlci1ibHVlLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5Ub3RhbCBQZW5hbHRpZXM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPntzdW1tYXJ5RGF0YS50b3RhbFBlbmFsdGllc308L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ibHVlLTEwMCBwLTIgcm91bmRlZC1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q2FsY3VsYXRvck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgdGV4dC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICB7LyogVG90YWwgRHVlIEFtb3VudCAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3cgcC00IGJvcmRlci1sLTQgYm9yZGVyLW9yYW5nZS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+VG90YWwgRHVlIEFtb3VudDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LW9yYW5nZS02MDBcIj7igrl7c3VtbWFyeURhdGEudG90YWxEdWUudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c3VtbWFyeURhdGEuZHVlQ291bnQgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTFcIj57c3VtbWFyeURhdGEuZHVlQ291bnR9IGN1c3RvbWVycyBoYXZlIGR1ZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1vcmFuZ2UtMTAwIHAtMiByb3VuZGVkLWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDYWxjdWxhdG9yT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1vcmFuZ2UtNjAwIHRleHQtbGdcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgey8qIFRvdGFsIFBlbmFsdHkgQW1vdW50ICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdyBwLTQgYm9yZGVyLWwtNCBib3JkZXItcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5Ub3RhbCBQZW5hbHR5IEFtb3VudDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXJlZC02MDBcIj7igrl7c3VtbWFyeURhdGEudG90YWxQZW5hbHR5LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcmVkLTEwMCBwLTIgcm91bmRlZC1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q2FsY3VsYXRvck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMCB0ZXh0LWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIHsvKiBUb3RhbCBMYXRlIEZlZSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3cgcC00IGJvcmRlci1sLTQgYm9yZGVyLXB1cnBsZS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+VG90YWwgTGF0ZSBGZWU8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1wdXJwbGUtNjAwXCI+4oK5e3N1bW1hcnlEYXRhLnRvdGFsTGF0ZUZlZS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXB1cnBsZS0xMDAgcC0yIHJvdW5kZWQtZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENhbGN1bGF0b3JPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS02MDAgdGV4dC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7YWN0aXZlUGVuYWx0eVZpZXcgPT09IFwibG9hblwiICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdyBtYi02IHAtNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgey8qIFRvdGFsIExvYW4gUGVuYWx0aWVzICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdyBwLTQgYm9yZGVyLWwtNCBib3JkZXItYmx1ZS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+VG90YWwgTG9hbiBQZW5hbHRpZXM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPntsb2FuU3VtbWFyeURhdGEudG90YWxQZW5hbHRpZXN9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS0xMDAgcC0yIHJvdW5kZWQtZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENhbGN1bGF0b3JPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIHRleHQtbGdcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgey8qIFRvdGFsIFBlbmFsdHkgQW1vdW50ICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdyBwLTQgYm9yZGVyLWwtNCBib3JkZXItcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVcIj5Ub3RhbCBQZW5hbHR5IEFtb3VudDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXJlZC02MDBcIj7igrl7bG9hblN1bW1hcnlEYXRhLnRvdGFsUGVuYWx0eUFtb3VudC50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXJlZC0xMDAgcC0yIHJvdW5kZWQtZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENhbGN1bGF0b3JPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDAgdGV4dC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICB7LyogVW5pcXVlIEN1c3RvbWVycyAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3cgcC00IGJvcmRlci1sLTQgYm9yZGVyLXB1cnBsZS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+VW5pcXVlIEN1c3RvbWVyczwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+e2xvYW5TdW1tYXJ5RGF0YS51bmlxdWVDdXN0b21lcnN9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcHVycGxlLTEwMCBwLTIgcm91bmRlZC1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8VXNlck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTYwMCB0ZXh0LWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHsvKiBQZW5hbHRpZXMgRGF0YVRhYmxlICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvd1wiPlxyXG4gICAgICAgICAgICB7YWN0aXZlUGVuYWx0eVZpZXcgPT09IFwiY2hpdFwiID8gKFxyXG4gICAgICAgICAgICAgIGlzTG9hZGluZ1BlbmFsdGllcyA/IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktOFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1ibG9jayBhbmltYXRlLXNwaW4gcm91bmRlZC1mdWxsIGgtOCB3LTggYm9yZGVyLWItMiBib3JkZXItYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LWdyYXktNTAwXCI+TG9hZGluZyBjaGl0IHBlbmFsdGllcy4uLjwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkgOiB0YWJsZURhdGEubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyUGVuYWx0aWVzKHRhYmxlRGF0YSwgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydENvbHM9e2V4Y2VsY29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YENoaXRfUGVuYWx0aWVzXyR7bW9tZW50KCkuZm9ybWF0KFwiREQtTU0tWVlZWVwiKX1gfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS04IHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgPHA+Tm8gY2hpdCBwZW5hbHR5IHJlY29yZHMgZm91bmQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gbXQtMlwiPkNsaWNrIFwiQWRkIFBlbmFsdHlcIiB0byBjcmVhdGUgYSBuZXcgcGVuYWx0eSByZWNvcmQ8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgaXNMb2FkaW5nTG9hblBlbmFsdGllcyA/IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktOFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1ibG9jayBhbmltYXRlLXNwaW4gcm91bmRlZC1mdWxsIGgtOCB3LTggYm9yZGVyLWItMiBib3JkZXItYmx1ZS02MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LWdyYXktNTAwXCI+TG9hZGluZyBsb2FuIHBlbmFsdGllcy4uLjwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkgOiBsb2FuVGFibGVEYXRhLmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlclBlbmFsdGllcyhsb2FuVGFibGVEYXRhLCBzZWFyY2hUZXh0KX1cclxuICAgICAgICAgICAgICAgICAgY29sdW1ucz17bG9hbkNvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydENvbHM9e2xvYW5FeHBvcnRDb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgTG9hbl9QZW5hbHRpZXNfJHttb21lbnQoKS5mb3JtYXQoXCJERC1NTS1ZWVlZXCIpfWB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTggdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8cD5ObyBsb2FuIHBlbmFsdHkgcmVjb3JkcyBmb3VuZDwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBtdC0yXCI+Q2xpY2sgXCJBZGQgUGVuYWx0eVwiIGFuZCBzZWxlY3QgXCJMb2FuIFBlbmFsdHlcIiB0byBjcmVhdGU8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogQmF0Y2ggV2FpdmUgT2ZmIE1vZGFsICovfVxyXG4gICAgICA8QW50TW9kYWxcclxuICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCBiZy1wdXJwbGUtMTAwIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8R2lmdE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTYwMCB0ZXh0LWxnXCIgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICBCYXRjaCBXYWl2ZSBPZmYgUGVuYWx0aWVzXHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBmb250LW5vcm1hbCBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgIFNlbGVjdCBjdXN0b21lcnMgYW5kIHdhaXZlIG9mZiBwZW5hbHRpZXMgaW4gYnVsa1xyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICB9XHJcbiAgICAgICAgb3Blbj17YmF0Y2hXYWl2ZU1vZGFsVmlzaWJsZX1cclxuICAgICAgICBvbkNhbmNlbD17KCkgPT4ge1xyXG4gICAgICAgICAgc2V0QmF0Y2hXYWl2ZU1vZGFsVmlzaWJsZShmYWxzZSk7XHJcbiAgICAgICAgICBzZXRTZWxlY3RlZEN1c3RvbWVycyhbXSk7XHJcbiAgICAgICAgICBzZXRCYXRjaFdhaXZlQW1vdW50KFwiXCIpO1xyXG4gICAgICAgICAgc2V0QmF0Y2hXYWl2ZVJlYXNvbihcIlwiKTtcclxuICAgICAgICAgIHNldEJhdGNoV2FpdmVUeXBlKFwiYm90aFwiKTtcclxuICAgICAgICAgIHNldEN1c3RvbWVyc1dpdGhQZW5hbHRpZXMoW10pO1xyXG4gICAgICAgIH19XHJcbiAgICAgICAgd2lkdGg9ezEyMDB9XHJcbiAgICAgICAgZm9vdGVyPXtbXHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIGtleT1cImNhbmNlbFwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICBzZXRCYXRjaFdhaXZlTW9kYWxWaXNpYmxlKGZhbHNlKTtcclxuICAgICAgICAgICAgICBzZXRTZWxlY3RlZEN1c3RvbWVycyhbXSk7XHJcbiAgICAgICAgICAgICAgc2V0Q3VzdG9tZXJzV2l0aFBlbmFsdGllcyhbXSk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgPC9CdXR0b24+LFxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICBrZXk9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgIGRhbmdlclxyXG4gICAgICAgICAgICBsb2FkaW5nPXtpc0JhdGNoV2FpdmluZ31cclxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQmF0Y2hXYWl2ZU9mZn1cclxuICAgICAgICAgICAgZGlzYWJsZWQ9e1xyXG4gICAgICAgICAgICAgIHNlbGVjdGVkQ3VzdG9tZXJzLmxlbmd0aCA9PT0gMCB8fFxyXG4gICAgICAgICAgICAgICFiYXRjaFdhaXZlQW1vdW50IHx8XHJcbiAgICAgICAgICAgICAgcGFyc2VGbG9hdChiYXRjaFdhaXZlQW1vdW50KSA8PSAwXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctcmVkLTYwMCBob3ZlcjpiZy1yZWQtNzAwXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgV2FpdmUgT2ZmIGZvciBTZWxlY3RlZCAoe3NlbGVjdGVkQ3VzdG9tZXJzLmxlbmd0aH0pXHJcbiAgICAgICAgICA8L0J1dHRvbj4sXHJcbiAgICAgICAgXX1cclxuICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgIGJvZHk6IHsgbWF4SGVpZ2h0OiBcIjcwdmhcIiwgb3ZlcmZsb3dZOiBcImF1dG9cIiwgcGFkZGluZzogXCIyMHB4XCIgfSxcclxuICAgICAgICB9fVxyXG4gICAgICA+XHJcbiAgICAgICAge2lzTG9hZGluZ0N1c3RvbWVycyA/IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcHktMTJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBoLTE2IHctMTYgYm9yZGVyLWItMiBib3JkZXItcHVycGxlLTYwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPEdpZnRPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS00MDAgdGV4dC14bCBhbmltYXRlLXB1bHNlXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTQgdGV4dC1ncmF5LTYwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgIExvYWRpbmcgY3VzdG9tZXJzIHdpdGggcGVuYWx0aWVzLi4uXHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNDAwXCI+XHJcbiAgICAgICAgICAgICAgUGxlYXNlIHdhaXQgd2hpbGUgd2UgZmV0Y2ggdGhlIGRhdGFcclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IGN1c3RvbWVyc1dpdGhQZW5hbHRpZXMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMjAgaC0yMCBiZy1ncmF5LTEwMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbXgtYXV0byBtYi00XCI+XHJcbiAgICAgICAgICAgICAgPEdpZnRPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIHRleHQtM3hsXCIgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICBObyBjdXN0b21lcnMgd2l0aCBwZW5hbHRpZXMgZm91bmRcclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS00MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgIEFsbCBwZW5hbHRpZXMgaGF2ZSBiZWVuIGNsZWFyZWQgb3Igd2FpdmVkIG9mZlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgey8qIFdhaXZlIE9mZiBDb25maWd1cmF0aW9uICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1wdXJwbGUtNTAgdG8tcGluay01MCByb3VuZGVkLWxnIHAtNCBib3JkZXIgYm9yZGVyLXB1cnBsZS0yMDBcIj5cclxuICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXB1cnBsZS04MDAgbWItMyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgPENhbGN1bGF0b3JPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgV2FpdmUgT2ZmIENvbmZpZ3VyYXRpb25cclxuICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj4gV2FpdmUgT2ZmIFR5cGVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2JhdGNoV2FpdmVUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXRCYXRjaFdhaXZlVHlwZX1cclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJwZW5hbHR5XCI+UGVuYWx0eSBPbmx5PC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwibGF0ZWZlZVwiPkxhdGUgRmVlIE9ubHk8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJib3RoXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBCb3RoIFBlbmFsdHkgJiBMYXRlIEZlZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+IEFtb3VudCB0byBXYWl2ZSAo4oK5KVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YmF0Y2hXYWl2ZUFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEJhdGNoV2FpdmVBbW91bnQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICBtaW49ezB9XHJcbiAgICAgICAgICAgICAgICAgICAgc3RlcD17MC4wMX1cclxuICAgICAgICAgICAgICAgICAgICBwcmVmaXg9XCLigrlcIlxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFJlYXNvbiAoT3B0aW9uYWwpXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtiYXRjaFdhaXZlUmVhc29ufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QmF0Y2hXYWl2ZVJlYXNvbihlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciByZWFzb24gZm9yIHdhaXZlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBTZWxlY3Rpb24gU3VtbWFyeSBCYXIgKi99XHJcbiAgICAgICAgICAgIHtzZWxlY3RlZEN1c3RvbWVycy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtNTAgcm91bmRlZC1sZyBwLTMgYm9yZGVyIGJvcmRlci1ibHVlLTIwMCBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWJsdWUtODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgU2VsZWN0ZWQ6IHtzZWxlY3RlZEN1c3RvbWVycy5sZW5ndGh9IGN1c3RvbWVyKHMpXHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVG90YWwgUGVuYWx0eTog4oK5XHJcbiAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkQ3VzdG9tZXJzXHJcbiAgICAgICAgICAgICAgICAgICAgICAucmVkdWNlKChzdW0sIGMpID0+IHN1bSArIGMudG90YWxQZW5hbHR5LCAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVG90YWwgTGF0ZSBGZWU6IOKCuVxyXG4gICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZEN1c3RvbWVyc1xyXG4gICAgICAgICAgICAgICAgICAgICAgLnJlZHVjZSgoc3VtLCBjKSA9PiBzdW0gKyBjLnRvdGFsTGF0ZUZlZSwgMClcclxuICAgICAgICAgICAgICAgICAgICAgIC50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRDdXN0b21lcnMoW10pfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQ2xlYXIgQWxsXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHsvKiBDdXN0b21lcnMgVGFibGUgKi99XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBDdXN0b21lcnMgd2l0aCBQZW5hbHRpZXMgKHtjdXN0b21lcnNXaXRoUGVuYWx0aWVzLmxlbmd0aH0pXHJcbiAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgey8qIFJFTU9WRSB0aGUgUmVmcmVzaCBCdXR0b24gc2VjdGlvbiBjb21wbGV0ZWx5ICovfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciByb3VuZGVkLWxnIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAgPFRhYmxlXHJcbiAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e1tcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tib3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkQ3VzdG9tZXJzLmxlbmd0aCA9PT1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1c3RvbWVyc1dpdGhQZW5hbHRpZXMubGVuZ3RoICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXN0b21lcnNXaXRoUGVuYWx0aWVzLmxlbmd0aCA+IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXRlcm1pbmF0ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEN1c3RvbWVycy5sZW5ndGggPiAwICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEN1c3RvbWVycy5sZW5ndGggPFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VzdG9tZXJzV2l0aFBlbmFsdGllcy5sZW5ndGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZS50YXJnZXQuY2hlY2tlZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZEN1c3RvbWVycyhbLi4uY3VzdG9tZXJzV2l0aFBlbmFsdGllc10pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRDdXN0b21lcnMoW10pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgZGF0YUluZGV4OiBcInNlbGVjdGlvblwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcInNlbGVjdGlvblwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDUwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVuZGVyOiAoXywgcmVjb3JkKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja2JveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3NlbGVjdGVkQ3VzdG9tZXJzLnNvbWUoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoYykgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYy51c2VySWQgPT09IHJlY29yZC51c2VySWQgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYy50aWNrZXQgPT09IHJlY29yZC50aWNrZXQgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYy5ncm91cElkID09PSByZWNvcmQuZ3JvdXBJZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGUudGFyZ2V0LmNoZWNrZWQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRDdXN0b21lcnMoW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnNlbGVjdGVkQ3VzdG9tZXJzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlY29yZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZEN1c3RvbWVycyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZEN1c3RvbWVycy5maWx0ZXIoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoYykgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjLnVzZXJJZCA9PT0gcmVjb3JkLnVzZXJJZCAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGMudGlja2V0ID09PSByZWNvcmQudGlja2V0ICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYy5ncm91cElkID09PSByZWNvcmQuZ3JvdXBJZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCJDdXN0b21lciBOYW1lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBkYXRhSW5kZXg6IFwidXNlck5hbWVcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGtleTogXCJ1c2VyTmFtZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgc29ydGVyOiAoYSwgYikgPT4gYS51c2VyTmFtZS5sb2NhbGVDb21wYXJlKGIudXNlck5hbWUpLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiUGhvbmUgTnVtYmVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBkYXRhSW5kZXg6IFwidXNlclBob25lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwidXNlclBob25lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCJHcm91cFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgZGF0YUluZGV4OiBcImdyb3VwTmFtZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcImdyb3VwTmFtZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiVGlja2V0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBkYXRhSW5kZXg6IFwidGlja2V0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwidGlja2V0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCJQZW5hbHR5IEFtb3VudFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgZGF0YUluZGV4OiBcInBlbmFsdHlBbW91bnRcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGtleTogXCJwZW5hbHR5QW1vdW50XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBhbGlnbjogXCJyaWdodFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVuZGVyOiAoYW1vdW50LCByZWNvcmQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7KHJlY29yZC5wZW5hbHR5QW1vdW50IHx8IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICBzb3J0ZXI6IChhLCBiKSA9PiBhLnBlbmFsdHlBbW91bnQgLSBiLnBlbmFsdHlBbW91bnQsXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCJMYXRlIEZlZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgZGF0YUluZGV4OiBcImxhdGVGZWVBbW91bnRcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGtleTogXCJsYXRlRmVlQW1vdW50XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBhbGlnbjogXCJyaWdodFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVuZGVyOiAoYW1vdW50LCByZWNvcmQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1vcmFuZ2UtNjAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7KHJlY29yZC5sYXRlRmVlQW1vdW50IHx8IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICBzb3J0ZXI6IChhLCBiKSA9PiBhLmxhdGVGZWVBbW91bnQgLSBiLmxhdGVGZWVBbW91bnQsXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCJDdXJyZW50IEJhbGFuY2VcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGRhdGFJbmRleDogXCJjdXJyZW50QmFsYW5jZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcImN1cnJlbnRCYWxhbmNlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBhbGlnbjogXCJyaWdodFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVuZGVyOiAoYW1vdW50KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTYwMCBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7KGFtb3VudCB8fCAwKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgc29ydGVyOiAoYSwgYikgPT4gYS5jdXJyZW50QmFsYW5jZSAtIGIuY3VycmVudEJhbGFuY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCJEdWUgKyBQZW5hbHR5XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiZHVlUGx1c1BlbmFsdHlcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGFsaWduOiBcInJpZ2h0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICByZW5kZXI6IChfLCByZWNvcmQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdG90YWwgPVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIChyZWNvcmQuY3VycmVudEJhbGFuY2UgfHwgMCkgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIChyZWNvcmQucGVuYWx0eUFtb3VudCB8fCAwKSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKHJlY29yZC5sYXRlRmVlQW1vdW50IHx8IDApO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDAgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7dG90YWwudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgc29ydGVyOiAoYSwgYikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0b3RhbEEgPVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIChhLmN1cnJlbnRCYWxhbmNlIHx8IDApICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAoYS5wZW5hbHR5QW1vdW50IHx8IDApICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAoYS5sYXRlRmVlQW1vdW50IHx8IDApO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdG90YWxCID1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAoYi5jdXJyZW50QmFsYW5jZSB8fCAwKSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKGIucGVuYWx0eUFtb3VudCB8fCAwKSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKGIubGF0ZUZlZUFtb3VudCB8fCAwKTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0b3RhbEEgLSB0b3RhbEI7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgIGRhdGFTb3VyY2U9e2N1c3RvbWVyc1dpdGhQZW5hbHRpZXN9XHJcbiAgICAgICAgICAgICAgICAgIHJvd0tleT17KHJlY29yZCkgPT4gYCR7cmVjb3JkLnVzZXJJZH1fJHtyZWNvcmQudGlja2V0fWB9XHJcbiAgICAgICAgICAgICAgICAgIHBhZ2luYXRpb249e3tcclxuICAgICAgICAgICAgICAgICAgICBwYWdlU2l6ZTogMTAsXHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1RvdGFsOiAodG90YWwsIHJhbmdlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgYCR7cmFuZ2VbMF19LSR7cmFuZ2VbMV19IG9mICR7dG90YWx9IGN1c3RvbWVyc2AsXHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NpemVDaGFuZ2VyOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwibWlkZGxlXCJcclxuICAgICAgICAgICAgICAgICAgc2Nyb2xsPXt7IHg6IHRydWUgfX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFdhcm5pbmcgQWxlcnQgKi99XHJcbiAgICAgICAgICAgIDxBbGVydFxyXG4gICAgICAgICAgICAgIG1lc3NhZ2U9e1xyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8RXhjbGFtYXRpb25DaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5JbXBvcnRhbnQgTm90aWNlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIGRlc2NyaXB0aW9uPXtcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWwtNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVGhpcyBhY3Rpb24gd2lsbCB3YWl2ZSBvZmYgdGhlIHNwZWNpZmllZCBhbW91bnQgZm9yIEFMTFxyXG4gICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkIGN1c3RvbWVycy5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDAgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFRoaXMgYWN0aW9uIGNhbm5vdCBiZSB1bmRvbmUuIFBsZWFzZSB2ZXJpZnkgYmVmb3JlXHJcbiAgICAgICAgICAgICAgICAgICAgcHJvY2VlZGluZy5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIHR5cGU9XCJ3YXJuaW5nXCJcclxuICAgICAgICAgICAgICBzaG93SWNvbj17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyLWwtNCBib3JkZXItcmVkLTUwMCBiZy1yZWQtNTBcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9BbnRNb2RhbD5cclxuXHJcbiAgICAgIHsvKiBWaWV3IFN0YXRlbWVudCBNb2RhbCAqL31cclxuICAgICAgPEFudE1vZGFsXHJcbiAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggYmctYmx1ZS0xMDAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxFeWVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIHRleHQtbGdcIiAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGRcIj5DdXN0b21lciBTdGF0ZW1lbnQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIGZvbnQtbm9ybWFsIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgQ29tcGxldGUgdHJhbnNhY3Rpb24gaGlzdG9yeSBhbmQgYWNjb3VudCBzdW1tYXJ5XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIH1cclxuICAgICAgICBvcGVuPXtzdGF0ZW1lbnRNb2RhbFZpc2libGV9XHJcbiAgICAgICAgb25DYW5jZWw9eygpID0+IHNldFN0YXRlbWVudE1vZGFsVmlzaWJsZShmYWxzZSl9XHJcbiAgICAgICAgd2lkdGg9ezEyMDB9XHJcbiAgICAgICAgZm9vdGVyPXtbXHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIGtleT1cImNsb3NlXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U3RhdGVtZW50TW9kYWxWaXNpYmxlKGZhbHNlKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNlwiXHJcbiAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIENsb3NlXHJcbiAgICAgICAgICA8L0J1dHRvbj4sXHJcbiAgICAgICAgXX1cclxuICAgICAgICBjbGFzc05hbWU9XCJjdXN0b21lci1zdGF0ZW1lbnQtbW9kYWxcIlxyXG4gICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgYm9keTogeyBwYWRkaW5nOiBcIjI0cHhcIiwgbWF4SGVpZ2h0OiBcIjcwdmhcIiwgb3ZlcmZsb3dZOiBcImF1dG9cIiB9LFxyXG4gICAgICAgIH19XHJcbiAgICAgID5cclxuICAgICAgICB7aXNMb2FkaW5nU3RhdGVtZW50ID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1ibG9ja1wiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBoLTEyIHctMTIgYm9yZGVyLWItMiBib3JkZXItYmx1ZS02MDAgbXgtYXV0b1wiPjwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LWdyYXktNTAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgTG9hZGluZyBjdXN0b21lciBzdGF0ZW1lbnQuLi5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IHN0YXRlbWVudERhdGEgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgICB7LyogQ3VzdG9tZXIgSW5mb3JtYXRpb24gQ2FyZCAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS01MCB0by1pbmRpZ28tNTAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWJsdWUtMTAwIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB0by1pbmRpZ28tNjAwIHB4LTUgcHktM1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8VXNlck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgdGV4dC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtd2hpdGUgdGV4dC1iYXNlIG1iLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICBDdXN0b21lciBJbmZvcm1hdGlvblxyXG4gICAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTVcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNVwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOSBoLTkgYmctYmx1ZS0xMDAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFVzZXJPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXIgTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIHRleHQtYmFzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c3RhdGVtZW50RGF0YS51c2VyPy5uYW1lIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOSBoLTkgYmctZ3JlZW4tMTAwIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxQaG9uZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUGhvbmUgTnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1iYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtzdGF0ZW1lbnREYXRhLnVzZXI/LnBob25lIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOSBoLTkgYmctcHVycGxlLTEwMCByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8VGVhbU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEdyb3VwIE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCB0ZXh0LWJhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3N0YXRlbWVudERhdGEuZ3JvdXA/Lm5hbWUgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy05IGgtOSBiZy1vcmFuZ2UtMTAwIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDcmVkaXRDYXJkT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1vcmFuZ2UtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgVGlja2V0IE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIHRleHQtYmFzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c3RhdGVtZW50RGF0YS50aWNrZXQgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogU3VtbWFyeSBDYXJkcyBHcmlkICovfVxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEgaC02IGJnLWdyYWRpZW50LXRvLWIgZnJvbS1ibHVlLTUwMCB0by1wdXJwbGUtNTAwIHJvdW5kZWQtZnVsbFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCB0ZXh0LWJhc2UgbWItMFwiPlxyXG4gICAgICAgICAgICAgICAgICBGaW5hbmNpYWwgU3VtbWFyeVxyXG4gICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTUgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIHsvKiBUb3RhbCBQYWlkIENhcmQgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3VwIHJlbGF0aXZlIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tZ3JlZW4tNTAgdG8tZ3JlZW4tMTAwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmVlbi0yMDAgcC00IGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgY3Vyc29yLXBvaW50ZXIgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCB3LTIwIGgtMjAgYmctZ3JlZW4tMjAwIHJvdW5kZWQtZnVsbCAtbXItMTAgLW10LTEwIG9wYWNpdHktNTAgZ3JvdXAtaG92ZXI6c2NhbGUtMTUwIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTUwMFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmVlbi03MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgUGFpZFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEZhUnVwZWVTaWduIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwIHRleHQtbGdcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAg4oK5XHJcbiAgICAgICAgICAgICAgICAgICAgICB7KHN0YXRlbWVudERhdGEuc3VtbWFyeT8udG90YWxQYWlkIHx8IDApLnRvTG9jYWxlU3RyaW5nKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBcImVuLUlOXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JlZW4tNjAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIGFtb3VudCBwYWlkXHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBUb3RhbCBQZW5hbHR5IENhcmQgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3VwIHJlbGF0aXZlIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tcmVkLTUwIHRvLXJlZC0xMDAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXJlZC0yMDAgcC00IGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgY3Vyc29yLXBvaW50ZXIgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCB3LTIwIGgtMjAgYmctcmVkLTIwMCByb3VuZGVkLWZ1bGwgLW1yLTEwIC1tdC0xMCBvcGFjaXR5LTUwIGdyb3VwLWhvdmVyOnNjYWxlLTE1MCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi01MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB6LTEwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtcmVkLTcwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUGVuYWx0eVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEV4Y2xhbWF0aW9uQ2lyY2xlT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwIHRleHQtbGdcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXJlZC03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgeyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGVtZW50RGF0YS5zdW1tYXJ5Py50b3RhbFBlbmFsdHkgfHwgMFxyXG4gICAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtcmVkLTYwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBwZW5hbHR5IGNoYXJnZWRcclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFRvdGFsIExhdGUgRmVlIENhcmQgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3VwIHJlbGF0aXZlIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tb3JhbmdlLTUwIHRvLW9yYW5nZS0xMDAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLW9yYW5nZS0yMDAgcC00IGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgY3Vyc29yLXBvaW50ZXIgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCB3LTIwIGgtMjAgYmctb3JhbmdlLTIwMCByb3VuZGVkLWZ1bGwgLW1yLTEwIC1tdC0xMCBvcGFjaXR5LTUwIGdyb3VwLWhvdmVyOnNjYWxlLTE1MCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi01MDBcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB6LTEwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtb3JhbmdlLTcwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTGF0ZSBGZWVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDbG9ja0NpcmNsZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtb3JhbmdlLTYwMCB0ZXh0LWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1vcmFuZ2UtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgICAgICAgIHsoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXRlbWVudERhdGEuc3VtbWFyeT8udG90YWxMYXRlRmVlIHx8IDBcclxuICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW9yYW5nZS02MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgVG90YWwgbGF0ZSBmZWUgY2hhcmdlZFxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogQ3VycmVudCBCYWxhbmNlIENhcmQgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyb3VwIHJlbGF0aXZlIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tYmx1ZS01MCB0by1ibHVlLTEwMCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYmx1ZS0yMDAgcC00IGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgY3Vyc29yLXBvaW50ZXIgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCB3LTIwIGgtMjAgYmctYmx1ZS0yMDAgcm91bmRlZC1mdWxsIC1tci0xMCAtbXQtMTAgb3BhY2l0eS01MCBncm91cC1ob3ZlcjpzY2FsZS0xNTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tNTAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWJsdWUtNzAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDdXJyZW50IEJhbGFuY2VcclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxXYWxsZXRPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIHRleHQtbGdcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxwXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LTJ4bCBmb250LWJvbGQgJHsoc3RhdGVtZW50RGF0YS5lbnJvbGxtZW50Py5jdXJyZW50QmFsYW5jZSB8fCAwKSA+IDAgPyBcInRleHQtb3JhbmdlLTYwMFwiIDogXCJ0ZXh0LWdyZWVuLTYwMFwifWB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAg4oK5XHJcbiAgICAgICAgICAgICAgICAgICAgICB7TWF0aC5hYnMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXRlbWVudERhdGEuZW5yb2xsbWVudD8uY3VycmVudEJhbGFuY2UgfHwgMCxcclxuICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPHBcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQteHMgbXQtMSBmb250LW1lZGl1bSAkeyhzdGF0ZW1lbnREYXRhLmVucm9sbG1lbnQ/LmN1cnJlbnRCYWxhbmNlIHx8IDApID4gMCA/IFwidGV4dC1vcmFuZ2UtNjAwXCIgOiBcInRleHQtZ3JlZW4tNjAwXCJ9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7KHN0YXRlbWVudERhdGEuZW5yb2xsbWVudD8uY3VycmVudEJhbGFuY2UgfHwgMCkgPiAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJBbW91bnQgRHVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcIkV4Y2VzcyBBbW91bnRcIn1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFRvdGFsIER1ZSBDYXJkICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm91cCByZWxhdGl2ZSBiZy1ncmFkaWVudC10by1iciBmcm9tLXB1cnBsZS01MCB0by1wdXJwbGUtMTAwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1wdXJwbGUtMjAwIHAtNCBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGN1cnNvci1wb2ludGVyIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0wIHJpZ2h0LTAgdy0yMCBoLTIwIGJnLXB1cnBsZS0yMDAgcm91bmRlZC1mdWxsIC1tci0xMCAtbXQtMTAgb3BhY2l0eS01MCBncm91cC1ob3ZlcjpzY2FsZS0xNTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tNTAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXB1cnBsZS03MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFBlbmFsdHkgKyBEdWVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDYWxjdWxhdG9yT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1wdXJwbGUtNjAwIHRleHQtbGdcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXB1cnBsZS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgeyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgKHN0YXRlbWVudERhdGEuZW5yb2xsbWVudD8uY3VycmVudEJhbGFuY2UgfHwgMCkgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAoc3RhdGVtZW50RGF0YS5zdW1tYXJ5Py50b3RhbFBlbmFsdHkgfHwgMCkgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAoc3RhdGVtZW50RGF0YS5zdW1tYXJ5Py50b3RhbExhdGVGZWUgfHwgMClcclxuICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXB1cnBsZS02MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgVG90YWwgb3V0c3RhbmRpbmcgRHVlIGJhbGFuY2VcclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFRyYW5zYWN0aW9ucyBUYWJsZSBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEgaC02IGJnLWdyYWRpZW50LXRvLWIgZnJvbS1ncmVlbi01MDAgdG8tYmx1ZS01MDAgcm91bmRlZC1mdWxsXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIHRleHQtYmFzZSBtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgIFRyYW5zYWN0aW9uIEhpc3RvcnlcclxuICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLWF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgPEJhZGdlXHJcbiAgICAgICAgICAgICAgICAgICAgY291bnQ9e2Ake3Byb2Nlc3NlZFRyYW5zYWN0aW9ucz8ubGVuZ3RoIHx8IDB9IFRyYW5zYWN0aW9uc2B9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYmx1ZS0xMDAgdGV4dC1ibHVlLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQteGwgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgPFRhYmxlXHJcbiAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e3RyYW5zYWN0aW9uQ29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgZGF0YVNvdXJjZT17cHJvY2Vzc2VkVHJhbnNhY3Rpb25zIHx8IFtdfVxyXG4gICAgICAgICAgICAgICAgICByb3dLZXk9eyhyZWNvcmQsIGluZGV4KSA9PiBpbmRleH1cclxuICAgICAgICAgICAgICAgICAgcGFnaW5hdGlvbj17e1xyXG4gICAgICAgICAgICAgICAgICAgIHBhZ2VTaXplOiAxMCxcclxuICAgICAgICAgICAgICAgICAgICBzaG93VG90YWw6ICh0b3RhbCwgcmFuZ2UpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBgJHtyYW5nZVswXX0tJHtyYW5nZVsxXX0gb2YgJHt0b3RhbH0gdHJhbnNhY3Rpb25zYCxcclxuICAgICAgICAgICAgICAgICAgICBzaG93U2l6ZUNoYW5nZXI6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1F1aWNrSnVtcGVyOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBzaXplPVwibWlkZGxlXCJcclxuICAgICAgICAgICAgICAgICAgc2Nyb2xsPXt7IHg6IHRydWUgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidHJhbnNhY3Rpb24tdGFibGVcIlxyXG4gICAgICAgICAgICAgICAgICByb3dDbGFzc05hbWU9XCJob3ZlcjpiZy1ncmF5LTUwIHRyYW5zaXRpb24tY29sb3JzIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGxvY2FsZT17eyBlbXB0eVRleHQ6IFwiTm8gdHJhbnNhY3Rpb25zIGZvdW5kXCIgfX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE2IGgtMTYgYmctZ3JheS0xMDAgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG14LWF1dG8gbWItNFwiPlxyXG4gICAgICAgICAgICAgIDxFeWVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIHRleHQtMnhsXCIgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgZm9udC1tZWRpdW1cIj5ObyBkYXRhIGF2YWlsYWJsZTwvcD5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICBVbmFibGUgdG8gbG9hZCBjdXN0b21lciBzdGF0ZW1lbnRcclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9BbnRNb2RhbD5cclxuXHJcbiAgICAgIHsvKiBQZW5hbHR5IEhpc3RvcnkgTW9kYWwgKi99XHJcbiAgICAgIDxBbnRNb2RhbFxyXG4gICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IGJnLXB1cnBsZS0xMDAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxIaXN0b3J5T3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1wdXJwbGUtNjAwIHRleHQtbGdcIiAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGRcIj5QZW5hbHR5IEhpc3Rvcnk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIGZvbnQtbm9ybWFsIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgQ29tcGxldGUgcGVuYWx0eSBhbmQgbGF0ZSBmZWUgcmVjb3Jkc1xyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICB9XHJcbiAgICAgICAgb3Blbj17cGVuYWx0eUhpc3RvcnlNb2RhbFZpc2libGV9XHJcbiAgICAgICAgb25DYW5jZWw9eygpID0+IHNldFBlbmFsdHlIaXN0b3J5TW9kYWxWaXNpYmxlKGZhbHNlKX1cclxuICAgICAgICB3aWR0aD17MTAwMH1cclxuICAgICAgICBmb290ZXI9e1tcclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAga2V5PVwiY2xvc2VcIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRQZW5hbHR5SGlzdG9yeU1vZGFsVmlzaWJsZShmYWxzZSl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTZcIlxyXG4gICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBDbG9zZVxyXG4gICAgICAgICAgPC9CdXR0b24+LFxyXG4gICAgICAgIF19XHJcbiAgICAgICAgY2xhc3NOYW1lPVwicGVuYWx0eS1oaXN0b3J5LW1vZGFsXCJcclxuICAgICAgICBzdHlsZXM9e3tcclxuICAgICAgICAgIGJvZHk6IHsgcGFkZGluZzogXCIyNHB4XCIsIG1heEhlaWdodDogXCI3MHZoXCIsIG92ZXJmbG93WTogXCJhdXRvXCIgfSxcclxuICAgICAgICB9fVxyXG4gICAgICA+XHJcbiAgICAgICAge2lzTG9hZGluZ1BlbmFsdHlIaXN0b3J5ID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1ibG9ja1wiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBoLTEyIHctMTIgYm9yZGVyLWItMiBib3JkZXItcHVycGxlLTYwMCBteC1hdXRvXCI+PC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC00IHRleHQtZ3JheS01MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICBMb2FkaW5nIHBlbmFsdHkgaGlzdG9yeS4uLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPD5cclxuICAgICAgICAgICAge3NlbGVjdGVkUGVuYWx0eUN1c3RvbWVyICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgICAgICAgey8qIEN1c3RvbWVyIEluZm9ybWF0aW9uIENhcmQgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1wdXJwbGUtNTAgdG8tcGluay01MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItcHVycGxlLTEwMCBvdmVyZmxvdy1oaWRkZW4gc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLXB1cnBsZS02MDAgdG8tcGluay02MDAgcHgtNSBweS0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFVzZXJPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIHRleHQtbGdcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSB0ZXh0LWJhc2UgbWItMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lciBJbmZvcm1hdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy01IGdhcC01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTkgaC05IGJnLWJsdWUtMTAwIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8VXNlck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXIgTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1iYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRQZW5hbHR5Q3VzdG9tZXIudXNlck5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy05IGgtOSBiZy1ncmVlbi0xMDAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxQaG9uZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBob25lIE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1iYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRQZW5hbHR5Q3VzdG9tZXIudXNlclBob25lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOSBoLTkgYmctcHVycGxlLTEwMCByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFRlYW1PdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgR3JvdXAgTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1iYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRQZW5hbHR5Q3VzdG9tZXIuZ3JvdXBOYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOSBoLTkgYmctb3JhbmdlLTEwMCByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENyZWRpdENhcmRPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LW9yYW5nZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVGlja2V0IE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1iYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRQZW5hbHR5Q3VzdG9tZXIudGlja2V0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMyBiZy1ncmFkaWVudC10by1yIGZyb20tcmVkLTUwIHRvLW9yYW5nZS01MCBwLTMgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXJlZC0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTkgaC05IGJnLXJlZC0xMDAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxFeGNsYW1hdGlvbkNpcmNsZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBQZW5hbHR5ICYgTGF0ZSBGZWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtcmVkLTYwMCB0ZXh0LXhsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7dG90YWxQZW5hbHR5QW1vdW50LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBQZW5hbHR5IEhpc3RvcnkgVGFibGUgU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xIGgtNiBiZy1ncmFkaWVudC10by1iIGZyb20tcHVycGxlLTUwMCB0by1waW5rLTUwMCByb3VuZGVkLWZ1bGxcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIHRleHQtYmFzZSBtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBQZW5hbHR5ICYgTGF0ZSBGZWUgUmVjb3Jkc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtbC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8QmFkZ2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgY291bnQ9e2Ake3BlbmFsdHlIaXN0b3J5RGF0YS5sZW5ndGh9IFJlY29yZHNgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1wdXJwbGUtMTAwIHRleHQtcHVycGxlLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHtwZW5hbHR5SGlzdG9yeURhdGEubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC14bCBvdmVyZmxvdy1oaWRkZW4gc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8VGFibGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17cGVuYWx0eUhpc3RvcnlDb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkYXRhU291cmNlPXtwZW5hbHR5SGlzdG9yeURhdGF9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvd0tleT1cIl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZ2luYXRpb249e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwYWdlU2l6ZTogMTAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1RvdGFsOiAodG90YWwsIHJhbmdlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYCR7cmFuZ2VbMF19LSR7cmFuZ2VbMV19IG9mICR7dG90YWx9IHJlY29yZHNgLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTaXplQ2hhbmdlcjogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93UXVpY2tKdW1wZXI6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJtaWRkbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwZW5hbHR5LXRhYmxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcm93Q2xhc3NOYW1lPXsocmVjb3JkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlY29yZC50eXBlID09PSBcIlBlbmFsdHlcIikgcmV0dXJuIFwicGVuYWx0eS1yb3dcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVjb3JkLnR5cGUgPT09IFwiTGF0ZSBGZWVcIikgcmV0dXJuIFwibGF0ZWZlZS1yb3dcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gXCJcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMiBiZy1ncmF5LTUwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE2IGgtMTYgYmctZ3JheS0xMDAgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG14LWF1dG8gbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SGlzdG9yeU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgdGV4dC0yeGxcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE5vIHBlbmFsdHkgaGlzdG9yeSBmb3VuZFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCB0ZXh0LXNtIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgVGhpcyBjdXN0b21lciBoYXMgbm8gcGVuYWx0eSBvciBsYXRlIGZlZSByZWNvcmRzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvQW50TW9kYWw+XHJcblxyXG4gICAgICB7LyogRWRpdCBMb2FuIFBlbmFsdHkgTW9kYWwgKi99XHJcbiAgICAgIDxBbnRNb2RhbFxyXG4gICAgICAgIHRpdGxlPVwiRWRpdCBMb2FuIFBlbmFsdHlcIlxyXG4gICAgICAgIG9wZW49e2VkaXRMb2FuTW9kYWxWaXNpYmxlfVxyXG4gICAgICAgIG9uQ2FuY2VsPXsoKSA9PiB7XHJcbiAgICAgICAgICBzZXRFZGl0TG9hbk1vZGFsVmlzaWJsZShmYWxzZSk7XHJcbiAgICAgICAgICBzZXRFZGl0aW5nTG9hblBlbmFsdHkobnVsbCk7XHJcbiAgICAgICAgICBzZXRFZGl0TG9hbkFtb3VudChcIlwiKTtcclxuICAgICAgICAgIHNldEVkaXRMb2FuUmVhc29uKFwiXCIpO1xyXG4gICAgICAgIH19XHJcbiAgICAgICAgZm9vdGVyPXtbXHJcbiAgICAgICAgICA8QnV0dG9uIGtleT1cImNhbmNlbFwiIG9uQ2xpY2s9eygpID0+IHNldEVkaXRMb2FuTW9kYWxWaXNpYmxlKGZhbHNlKX0+Q2FuY2VsPC9CdXR0b24+LFxyXG4gICAgICAgICAgPEJ1dHRvbiBrZXk9XCJzdWJtaXRcIiB0eXBlPVwicHJpbWFyeVwiIGxvYWRpbmc9e2lzVXBkYXRpbmdMb2FuUGVuYWx0eX0gb25DbGljaz17aGFuZGxlVXBkYXRlTG9hblBlbmFsdHl9PlxyXG4gICAgICAgICAgICBVcGRhdGUgUGVuYWx0eVxyXG4gICAgICAgICAgPC9CdXR0b24+LFxyXG4gICAgICAgIF19XHJcbiAgICAgICAgd2lkdGg9ezUwMH1cclxuICAgICAgPlxyXG4gICAgICAgIHtlZGl0aW5nTG9hblBlbmFsdHkgJiYgKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5DdXN0b21lcjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPElucHV0IHZhbHVlPXtlZGl0aW5nTG9hblBlbmFsdHkudXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiTi9BXCJ9IGRpc2FibGVkIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPkxvYW4gSUQ8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxJbnB1dCB2YWx1ZT17ZWRpdGluZ0xvYW5QZW5hbHR5LmxvYW5faWQ/LmxvYW5faWQgfHwgZWRpdGluZ0xvYW5QZW5hbHR5LmxvYW5faWQ/Ll9pZCB8fCBcIk4vQVwifSBkaXNhYmxlZCAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5QZW5hbHR5IEFtb3VudCAo4oK5KTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtlZGl0TG9hbkFtb3VudH1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RWRpdExvYW5BbW91bnQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBwZW5hbHR5IGFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICBtaW49ezB9XHJcbiAgICAgICAgICAgICAgICBzdGVwPXswLjAxfVxyXG4gICAgICAgICAgICAgICAgYXV0b0ZvY3VzXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+UmVhc29uPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8SW5wdXQuVGV4dEFyZWFcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtlZGl0TG9hblJlYXNvbn1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RWRpdExvYW5SZWFzb24oZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJSZWFzb24gZm9yIHBlbmFsdHlcIlxyXG4gICAgICAgICAgICAgICAgcm93cz17M31cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvQW50TW9kYWw+XHJcblxyXG4gICAgICB7LyogVmlldyAgUGVuYWx0eSAvIEV4dHJhIENoYXJnZXMgTW9kYWwgKi99XHJcbiAgICAgIDxBbnRNb2RhbFxyXG4gICAgICAgIG9wZW49e3Nob3dQZW5hbHR5TW9kYWx9XHJcbiAgICAgICAgb25DYW5jZWw9eygpID0+IHtcclxuICAgICAgICAgIHNldFNob3dQZW5hbHR5TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0UGVuYWx0eUxvYW4obnVsbCk7XHJcbiAgICAgICAgICBzZXRQZW5hbHR5Q2hhcmdlcyhbeyBhbW91bnQ6IFwiXCIsIHJlYXNvbjogXCJcIiB9XSk7XHJcbiAgICAgICAgfX1cclxuICAgICAgICBmb290ZXI9e251bGx9XHJcbiAgICAgICAgY2VudGVyZWRcclxuICAgICAgICB3aWR0aD17NzAwfVxyXG4gICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1vcmFuZ2UtNjAwIGZvbnQtYm9sZCB0ZXh0LWxnXCI+VmlldyBQZW5hbHR5IENoYXJnZXM8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICB9XHJcbiAgICAgID5cclxuICAgICAgICA8U3BpbiBzcGlubmluZz17cGVuYWx0eUxvYWRpbmd9IHRpcD1cIkxvYWRpbmcgcGVuYWx0eSBkZXRhaWxzLi4uXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMlwiPlxyXG4gICAgICAgICAgICB7LyogTG9hbiBTdW1tYXJ5ICovfVxyXG4gICAgICAgICAgICB7cGVuYWx0eUxvYW4gJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctb3JhbmdlLTUwIGJvcmRlciBib3JkZXItb3JhbmdlLTIwMCByb3VuZGVkLXhsIHAtNCBtYi01XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdGV4dC1ncmF5LTUwMCBmb250LWJvbGRcIj5Cb3Jyb3dlcjwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3BlbmFsdHlMb2FuPy51c2VyX2lkPy5mdWxsX25hbWUgfHwgcGVuYWx0eUxvYW4/LmJvcnJvd2VyX25hbWUgfHwgXCLigJRcIn1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSB0ZXh0LWdyYXktNTAwIGZvbnQtYm9sZFwiPkxvYW4gSUQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtwZW5hbHR5TG9hbj8ubG9hbl9pZD8ubG9hbl9pZCB8fCBcIuKAlFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRleHQtZ3JheS01MDAgZm9udC1ib2xkXCI+TG9hbiBBbW91bnQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmVlbi02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIOKCuXtwZW5hbHR5TG9hbj8ubG9hbl9pZD8ubG9hbl9hbW91bnQ/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIikgfHwgMH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSB0ZXh0LWdyYXktNTAwIGZvbnQtYm9sZFwiPkR1ZSBEYXRlPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3BlbmFsdHlMb2FuPy5sb2FuX2lkPy5lbmRfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdPy5zcGxpdChcIi1cIik/LnJldmVyc2UoKT8uam9pbihcIi1cIikgfHwgXCLigJRcIn1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7LyogRXhpc3RpbmcgRXh0cmEgQ2hhcmdlcyAqL31cclxuICAgICAgICAgICAge3BlbmFsdHlMb2FuPy5sb2FuX2lkPy5leHRyYV9jaGFyZ2VzPy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTVcIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtZ3JheS02MDAgdXBwZXJjYXNlIG1iLTJcIj5FeGlzdGluZyBDaGFyZ2VzPC9wPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQtbGcgYm9yZGVyIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktMTAwIHRleHQtZ3JheS02MDAgdGV4dC14cyBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1sZWZ0XCI+U3RhdHVzPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LWxlZnRcIj5SZWFzb248L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtcmlnaHRcIj5DaGFyZ2UgKOKCuSk8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtcmlnaHRcIj5QYWlkICjigrkpPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LXJpZ2h0XCI+QmFsYW5jZSAo4oK5KTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3BlbmFsdHlMb2FuLmxvYW5faWQ/LmV4dHJhX2NoYXJnZXMubWFwKChjaGFyZ2UsIGlkeCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc1BhaWQgPSBjaGFyZ2UucGFpZCA9PT0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcGFpZEFtb3VudCA9IGNoYXJnZS5wYWlkX2Ftb3VudCB8fCAoaXNQYWlkID8gY2hhcmdlLmFtb3VudCA6IDApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBiYWxhbmNlQW1vdW50ID0gY2hhcmdlLmJhbGFuY2VfYW1vdW50IHx8IChpc1BhaWQgPyAwIDogY2hhcmdlLmFtb3VudCAtIHBhaWRBbW91bnQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgc3RhdHVzVGV4dCA9IFwiVW5wYWlkXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzdGF0dXNDb2xvciA9IFwiYmctcmVkLTEwMCB0ZXh0LXJlZC03MDBcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGlzUGFpZCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1c1RleHQgPSBcIlBhaWRcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXNDb2xvciA9IFwiYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tNzAwXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAocGFpZEFtb3VudCA+IDAgJiYgcGFpZEFtb3VudCA8IGNoYXJnZS5hbW91bnQpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXNUZXh0ID0gXCJQYXJ0aWFsbHkgUGFpZFwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1c0NvbG9yID0gXCJiZy15ZWxsb3ctMTAwIHRleHQteWVsbG93LTcwMFwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17Y2hhcmdlLl9pZCB8fCBpZHh9IGNsYXNzTmFtZT1cImhvdmVyOmJnLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtWzEwcHhdIGZvbnQtYm9sZCBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgJHtzdGF0dXNDb2xvcn1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RhdHVzVGV4dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1ncmF5LTcwMFwiPntjaGFyZ2UucmVhc29ufTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtcmlnaHQgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7TnVtYmVyKGNoYXJnZS5hbW91bnQgfHwgMCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtcmlnaHQgdGV4dC1ncmVlbi02MDAgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGFpZEFtb3VudCA+IDAgPyBg4oK5JHtwYWlkQW1vdW50LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCA6IFwi4oCUXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LXJpZ2h0IHRleHQtcmVkLTYwMCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtiYWxhbmNlQW1vdW50ID4gMCA/IGDigrkke2JhbGFuY2VBbW91bnQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gIDogXCLigJRcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRmb290IGNsYXNzTmFtZT1cImJnLW9yYW5nZS01MCB0ZXh0LW9yYW5nZS04MDAgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjb2xTcGFuPVwiMlwiIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LXNtXCI+VG90YWxzPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTMgcHktMiB0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e3BlbmFsdHlMb2FuLmxvYW5faWQ/LmV4dHJhX2NoYXJnZXMucmVkdWNlKChzLCBjKSA9PiBzICsgTnVtYmVyKGMuYW1vdW50IHx8IDApLCAwKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtMyBweS0yIHRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7cGVuYWx0eUxvYW4ubG9hbl9pZD8uZXh0cmFfY2hhcmdlcy5yZWR1Y2UoKHMsIGMpID0+IHMgKyBOdW1iZXIoYy5wYWlkX2Ftb3VudCB8fCAoYy5wYWlkID8gYy5hbW91bnQgOiAwKSksIDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1yaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtwZW5hbHR5TG9hbi5sb2FuX2lkPy5leHRyYV9jaGFyZ2VzLnJlZHVjZSgocywgYykgPT4gcyArIE51bWJlcihjLmJhbGFuY2VfYW1vdW50IHx8IChjLnBhaWQgPyAwIDogYy5hbW91bnQgLSAoYy5wYWlkX2Ftb3VudCB8fCAwKSkpLCAwKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICA8L3Rmb290PlxyXG4gICAgICAgICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7LyogTmV3IENoYXJnZXMgVG90YWwgUHJldmlldyAqL31cclxuICAgICAgICAgICAge3BlbmFsdHlDaGFyZ2VzLnNvbWUoYyA9PiBjLmFtb3VudCkgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1ib2xkIHRleHQtb3JhbmdlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgTmV3IENoYXJnZXMgVG90YWw6IOKCuXtwZW5hbHR5Q2hhcmdlcy5yZWR1Y2UoKHMsIGMpID0+IHMgKyBOdW1iZXIoYy5hbW91bnQgfHwgMCksIDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTMgbXQtNiBwdC00IGJvcmRlci10XCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBzZXRTaG93UGVuYWx0eU1vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgc2V0UGVuYWx0eUxvYW4obnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgIHNldFBlbmFsdHlDaGFyZ2VzKFt7IGFtb3VudDogXCJcIiwgcmVhc29uOiBcIlwiIH1dKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC01IHB5LTIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS02MDAgaG92ZXI6YmctZ3JheS01MCBmb250LW1lZGl1bVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9TcGluPlxyXG4gICAgICA8L0FudE1vZGFsPlxyXG5cclxuICAgICAgey8qIEVkaXQgUGVuYWx0eSBNb2RhbCAqL31cclxuICAgICAgPEFudE1vZGFsXHJcbiAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggYmctZ3JlZW4tMTAwIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICA8RWRpdE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwIHRleHQtbGdcIiAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgIEVkaXQgUGVuYWx0eSAmIExhdGUgRmVlXHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBmb250LW5vcm1hbCBtdC0wLjVcIj5cclxuICAgICAgICAgICAgICAgIE1vZGlmeSBwZW5hbHR5IGRldGFpbHMgZm9yIHRoaXMgdHJhbnNhY3Rpb25cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgfVxyXG4gICAgICAgIG9wZW49e2VkaXRNb2RhbFZpc2libGV9XHJcbiAgICAgICAgb25DYW5jZWw9eygpID0+IHtcclxuICAgICAgICAgIHNldEVkaXRNb2RhbFZpc2libGUoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0RWRpdGluZ1BlbmFsdHkobnVsbCk7XHJcbiAgICAgICAgICBzZXRFZGl0UGVuYWx0eUFtb3VudChcIlwiKTtcclxuICAgICAgICAgIHNldEVkaXRMYXRlRmVlQW1vdW50KFwiXCIpO1xyXG4gICAgICAgICAgc2V0RWRpdFJlYXNvbihcIlwiKTtcclxuICAgICAgICB9fVxyXG4gICAgICAgIHdpZHRoPXs2MDB9XHJcbiAgICAgICAgZm9vdGVyPXtbXHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIGtleT1cImNhbmNlbFwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICBzZXRFZGl0TW9kYWxWaXNpYmxlKGZhbHNlKTtcclxuICAgICAgICAgICAgICBzZXRFZGl0aW5nUGVuYWx0eShudWxsKTtcclxuICAgICAgICAgICAgICBzZXRFZGl0UGVuYWx0eUFtb3VudChcIlwiKTtcclxuICAgICAgICAgICAgICBzZXRFZGl0TGF0ZUZlZUFtb3VudChcIlwiKTtcclxuICAgICAgICAgICAgICBzZXRFZGl0UmVhc29uKFwiXCIpO1xyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC02XCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICA8L0J1dHRvbj4sXHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIGtleT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgbG9hZGluZz17aXNVcGRhdGluZ1BlbmFsdHl9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVVwZGF0ZVBlbmFsdHl9XHJcbiAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTYgYmctZ3JhZGllbnQtdG8tciBmcm9tLWdyZWVuLTYwMCB0by1ncmVlbi03MDAgaG92ZXI6ZnJvbS1ncmVlbi03MDAgaG92ZXI6dG8tZ3JlZW4tODAwIGJvcmRlci1ub25lXCJcclxuICAgICAgICAgICAgaWNvbj17PFNhdmVPdXRsaW5lZCAvPn1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgVXBkYXRlIFBlbmFsdHlcclxuICAgICAgICAgIDwvQnV0dG9uPixcclxuICAgICAgICBdfVxyXG4gICAgICAgIGNsYXNzTmFtZT1cImVkaXQtcGVuYWx0eS1tb2RhbFwiXHJcbiAgICAgICAgc3R5bGVzPXt7XHJcbiAgICAgICAgICBib2R5OiB7IHBhZGRpbmc6IFwiMjRweFwiIH0sXHJcbiAgICAgICAgfX1cclxuICAgICAgPlxyXG4gICAgICAgIHtlZGl0aW5nUGVuYWx0eSAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgICB7LyogQ3VzdG9tZXIgSW5mb3JtYXRpb24gQ2FyZCAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tZ3JlZW4tNTAgdG8tZW1lcmFsZC01MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JlZW4tMTAwIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLWdyZWVuLTYwMCB0by1lbWVyYWxkLTYwMCBweC00IHB5LTNcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPFVzZXJPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIHRleHQtYmFzZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtd2hpdGUgdGV4dC1zbSBtYi0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVHJhbnNhY3Rpb24gRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggYmctYmx1ZS0xMDAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFVzZXJPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIHRleHQtc21cIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lclxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlZGl0aW5nUGVuYWx0eS51c2VyX2lkPy5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggYmctcHVycGxlLTEwMCByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8VGVhbU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTYwMCB0ZXh0LXNtXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgR3JvdXBcclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZWRpdGluZ1BlbmFsdHkuZ3JvdXBfaWQ/Lmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggYmctb3JhbmdlLTEwMCByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8Q3JlZGl0Q2FyZE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtb3JhbmdlLTYwMCB0ZXh0LXNtXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgVGlja2V0XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2VkaXRpbmdQZW5hbHR5LnRpY2tldH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxDYWxlbmRhck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIFBlbmFsdHkgRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxEYXRlUGlja2VyXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlZGl0RGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGZvcm1hdD1cIkRELU1NLVlZWVlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhkYXRlKSA9PiBzZXRFZGl0RGF0ZShkYXRlKX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBDdXJyZW50IEFtb3VudHMgU3VtbWFyeSAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20teWVsbG93LTUwIHRvLW9yYW5nZS01MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXIteWVsbG93LTIwMCBwLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgIDxJbmZvQ2lyY2xlT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC15ZWxsb3ctNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEN1cnJlbnQgQW1vdW50c1xyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBwLTMgYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG1iLTFcIj5DdXJyZW50IFBlbmFsdHk8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgIHsoZWRpdGluZ1BlbmFsdHkucGVuYWx0eV9hbW91bnQgfHwgMCkudG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICBcImVuLUlOXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHAtMyBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgbWItMVwiPkN1cnJlbnQgTGF0ZSBGZWU8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtb3JhbmdlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgIHsoZWRpdGluZ1BlbmFsdHkubGF0ZV9mZWVfYW1vdW50IHx8IDApLnRvTG9jYWxlU3RyaW5nKFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJlbi1JTlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBFZGl0IEZvcm0gKi99XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMSBoLTUgYmctZ3JhZGllbnQtdG8tYiBmcm9tLWdyZWVuLTUwMCB0by1lbWVyYWxkLTUwMCByb3VuZGVkLWZ1bGxcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1iYXNlIG1iLTBcIj5cclxuICAgICAgICAgICAgICAgICAgRWRpdCBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgey8qIFBlbmFsdHkgQW1vdW50IEZpZWxkICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8RG9sbGFyT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICBQZW5hbHR5IEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdFBlbmFsdHlBbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFZGl0UGVuYWx0eUFtb3VudChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBwZW5hbHR5IGFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbWluPXswfVxyXG4gICAgICAgICAgICAgICAgICAgIHN0ZXA9ezAuMDF9XHJcbiAgICAgICAgICAgICAgICAgICAgcHJlZml4PVwi4oK5XCJcclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYm9yZGVyLWdyYXktMzAwIGZvY3VzOmJvcmRlci1yZWQtNDAwIGZvY3VzOnJpbmctcmVkLTQwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3VmZml4PXtcclxuICAgICAgICAgICAgICAgICAgICAgIGVkaXRQZW5hbHR5QW1vdW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTmV3IHRvdGFsOiDigrlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKGVkaXRpbmdQZW5hbHR5LnBlbmFsdHlfYW1vdW50IHx8IDApICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlRmxvYXQoZWRpdFBlbmFsdHlBbW91bnQgfHwgMClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogTGF0ZSBGZWUgQW1vdW50IEZpZWxkICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Q2xvY2tDaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LW9yYW5nZS01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIExhdGUgRmVlIEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZWRpdExhdGVGZWVBbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFZGl0TGF0ZUZlZUFtb3VudChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBsYXRlIGZlZSBhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG1pbj17MH1cclxuICAgICAgICAgICAgICAgICAgICBzdGVwPXswLjAxfVxyXG4gICAgICAgICAgICAgICAgICAgIHByZWZpeD1cIuKCuVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlci1ncmF5LTMwMCBmb2N1czpib3JkZXItb3JhbmdlLTQwMCBmb2N1czpyaW5nLW9yYW5nZS00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN1ZmZpeD17XHJcbiAgICAgICAgICAgICAgICAgICAgICBlZGl0TGF0ZUZlZUFtb3VudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIE5ldyB0b3RhbDog4oK5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgeyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChlZGl0aW5nUGVuYWx0eS5sYXRlX2ZlZV9hbW91bnQgfHwgMCkgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VGbG9hdChlZGl0TGF0ZUZlZUFtb3VudCB8fCAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBSZWFzb24gRmllbGQgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGaWxlVGV4dE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIFJlYXNvbiBmb3IgVXBkYXRlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dC5UZXh0QXJlYVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlZGl0UmVhc29ufVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RWRpdFJlYXNvbihlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciByZWFzb24gZm9yIHVwZGF0aW5nIHBlbmFsdHkvbGF0ZSBmZWUuLi5cIlxyXG4gICAgICAgICAgICAgICAgICAgIHJvd3M9ezN9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXItZ3JheS0zMDAgZm9jdXM6Ym9yZGVyLWJsdWUtNDAwIGZvY3VzOnJpbmctYmx1ZS00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIG1heExlbmd0aD17MjAwfVxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dDb3VudFxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFByZXZpZXcgU3VtbWFyeSAqL31cclxuICAgICAgICAgICAgICAgIHsoZWRpdFBlbmFsdHlBbW91bnQgfHwgZWRpdExhdGVGZWVBbW91bnQpICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS01MCB0by1pbmRpZ28tNTAgcm91bmRlZC1sZyBwLTQgYm9yZGVyIGJvcmRlci1ibHVlLTIwMCBhbmltYXRlLWZhZGVJblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENhbGN1bGF0b3JPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFVwZGF0ZWQgU3VtbWFyeSBQcmV2aWV3XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIE5ldyBQZW5hbHR5IEFtb3VudDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZWRpdGluZ1BlbmFsdHkucGVuYWx0eV9hbW91bnQgfHwgMCkgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VGbG9hdChlZGl0UGVuYWx0eUFtb3VudCB8fCAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBOZXcgTGF0ZSBGZWUgQW1vdW50OlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1vcmFuZ2UtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgeyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChlZGl0aW5nUGVuYWx0eS5sYXRlX2ZlZV9hbW91bnQgfHwgMCkgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFyc2VGbG9hdChlZGl0TGF0ZUZlZUFtb3VudCB8fCAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwdC0yIGJvcmRlci10IGJvcmRlci1ibHVlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIEFkZGl0aW9uOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXB1cnBsZS02MDAgdGV4dC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJzZUZsb2F0KGVkaXRQZW5hbHR5QW1vdW50IHx8IDApICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhcnNlRmxvYXQoZWRpdExhdGVGZWVBbW91bnQgfHwgMClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFdhcm5pbmcgQWxlcnQgKi99XHJcbiAgICAgICAgICAgIDxBbGVydFxyXG4gICAgICAgICAgICAgIG1lc3NhZ2U9XCJJbXBvcnRhbnQgTm90aWNlXCJcclxuICAgICAgICAgICAgICBkZXNjcmlwdGlvbj1cIkVkaXRpbmcgcGVuYWx0eSBhbW91bnRzIHdpbGwgYWZmZWN0IHRoZSBjdXN0b21lcidzIHRvdGFsIGR1ZSBiYWxhbmNlLiBQbGVhc2UgdmVyaWZ5IHRoZSBjaGFuZ2VzIGJlZm9yZSB1cGRhdGluZy5cIlxyXG4gICAgICAgICAgICAgIHR5cGU9XCJ3YXJuaW5nXCJcclxuICAgICAgICAgICAgICBzaG93SWNvblxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlci1sLTQgYm9yZGVyLXllbGxvdy01MDAgYmcteWVsbG93LTUwXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvQW50TW9kYWw+XHJcblxyXG4gICAgICB7LyogV2FpdmUgT2ZmIE1vZGFsIC0gSW5kaXZpZHVhbCBDdXN0b21lciBXYWl2ZSBPZmYgKi99XHJcbiAgICAgIDxBbnRNb2RhbFxyXG4gICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IGJnLXB1cnBsZS0xMDAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxEb2xsYXJPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS02MDAgdGV4dC1sZ1wiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZFwiPldhaXZlIE9mZiBQZW5hbHRpZXM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIGZvbnQtbm9ybWFsIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgUmVkdWNlIG9yIHJlbW92ZSBwZW5hbHRpZXMgYW5kIGxhdGUgZmVlcyBmb3IgdGhpcyBjdXN0b21lclxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICB9XHJcbiAgICAgICAgb3Blbj17d2FpdmVPZmZNb2RhbFZpc2libGV9XHJcbiAgICAgICAgb25DYW5jZWw9eygpID0+IHtcclxuICAgICAgICAgIHNldFdhaXZlT2ZmTW9kYWxWaXNpYmxlKGZhbHNlKTtcclxuICAgICAgICAgIHNldFdhaXZlT2ZmRGF0YShudWxsKTtcclxuICAgICAgICAgIHNldFdhaXZlT2ZmQW1vdW50KFwiXCIpO1xyXG4gICAgICAgICAgc2V0V2FpdmVPZmZSZWFzb24oXCJcIik7XHJcbiAgICAgICAgICBzZXRXYWl2ZU9mZlR5cGUoXCJib3RoXCIpO1xyXG4gICAgICAgIH19XHJcbiAgICAgICAgd2lkdGg9ezcwMH1cclxuICAgICAgICBmb290ZXI9e1tcclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAga2V5PVwiY2FuY2VsXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgIHNldFdhaXZlT2ZmTW9kYWxWaXNpYmxlKGZhbHNlKTtcclxuICAgICAgICAgICAgICBzZXRXYWl2ZU9mZkRhdGEobnVsbCk7XHJcbiAgICAgICAgICAgICAgc2V0V2FpdmVPZmZBbW91bnQoXCJcIik7XHJcbiAgICAgICAgICAgICAgc2V0V2FpdmVPZmZSZWFzb24oXCJcIik7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgPC9CdXR0b24+LFxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICBrZXk9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgIGRhbmdlclxyXG4gICAgICAgICAgICBsb2FkaW5nPXtpc1dhaXZpbmdPZmZ9XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVdhaXZlT2ZmUGVuYWx0aWVzfVxyXG4gICAgICAgICAgICBkaXNhYmxlZD17IXdhaXZlT2ZmQW1vdW50IHx8IHBhcnNlRmxvYXQod2FpdmVPZmZBbW91bnQpIDw9IDB9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXJlZC02MDAgaG92ZXI6YmctcmVkLTcwMFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIFdhaXZlIE9mZiBBbW91bnRcclxuICAgICAgICAgIDwvQnV0dG9uPixcclxuICAgICAgICBdfVxyXG4gICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgYm9keTogeyBtYXhIZWlnaHQ6IFwiNzB2aFwiLCBvdmVyZmxvd1k6IFwiYXV0b1wiLCBwYWRkaW5nOiBcIjIwcHhcIiB9LFxyXG4gICAgICAgIH19XHJcbiAgICAgID5cclxuICAgICAgICB7aXNMb2FkaW5nU3RhdGVtZW50ID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBweS0xMlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gcm91bmRlZC1mdWxsIGgtMTYgdy0xNiBib3JkZXItYi0yIGJvcmRlci1wdXJwbGUtNjAwXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8RG9sbGFyT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1wdXJwbGUtNDAwIHRleHQteGwgYW5pbWF0ZS1wdWxzZVwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC00IHRleHQtZ3JheS02MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICBMb2FkaW5nIGN1c3RvbWVyIGRhdGEuLi5cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAgICBQbGVhc2Ugd2FpdCB3aGlsZSB3ZSBmZXRjaCB0aGUgZGV0YWlsc1xyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogd2FpdmVPZmZEYXRhID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTVcIj5cclxuICAgICAgICAgICAgey8qIEN1c3RvbWVyIEluZm9ybWF0aW9uIENhcmQgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLWdyYXktNTAgdG8tYmx1ZS01MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tcHVycGxlLTYwMCB0by1pbmRpZ28tNjAwIHB4LTQgcHktM1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8VXNlck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgdGV4dC1iYXNlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSB0ZXh0LXNtIG1iLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICBDdXN0b21lciBJbmZvcm1hdGlvblxyXG4gICAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8VXNlck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDAgbXQtMC41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+Q3VzdG9tZXIgTmFtZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7d2FpdmVPZmZEYXRhLnVzZXJOYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFBob25lT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi01MDAgbXQtMC41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+UGhvbmUgTnVtYmVyPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt3YWl2ZU9mZkRhdGEudXNlclBob25lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRlYW1PdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS01MDAgbXQtMC41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+R3JvdXAgTmFtZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7d2FpdmVPZmZEYXRhLmdyb3VwTmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDcmVkaXRDYXJkT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1vcmFuZ2UtNTAwIG10LTAuNVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlRpY2tldCBOdW1iZXI8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3dhaXZlT2ZmRGF0YS50aWNrZXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIEN1cnJlbnQgQW1vdW50cyBTdW1tYXJ5ICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tcmVkLTUwIHRvLXJlZC0xMDAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXJlZC0yMDAgcC00IHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1yZWQtNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICBUb3RhbCBQZW5hbHR5XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1yZWQtNjAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAg4oK5e3dhaXZlT2ZmRGF0YS50b3RhbFBlbmFsdHkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tb3JhbmdlLTUwIHRvLW9yYW5nZS0xMDAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLW9yYW5nZS0yMDAgcC00IHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1vcmFuZ2UtNjAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICBUb3RhbCBMYXRlIEZlZVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtb3JhbmdlLTYwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIOKCuXt3YWl2ZU9mZkRhdGEudG90YWxMYXRlRmVlLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWJsdWUtNTAgdG8tYmx1ZS0xMDAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWJsdWUtMjAwIHAtNCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtYmx1ZS02MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgIEN1cnJlbnQgQmFsYW5jZVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtYmx1ZS02MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgICAge01hdGguYWJzKHdhaXZlT2ZmRGF0YS5jdXJyZW50QmFsYW5jZSkudG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgXCJlbi1JTlwiLFxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAge3dhaXZlT2ZmRGF0YS5jdXJyZW50QmFsYW5jZSA+IDBcclxuICAgICAgICAgICAgICAgICAgICA/IFwiQW1vdW50IER1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcIkV4Y2VzcyBBbW91bnRcIn1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogR3JhbmQgVG90YWwgQ2FyZCAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tcHVycGxlLTUwIHRvLXBpbmstNTAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXB1cnBsZS0yMDAgcC00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXB1cnBsZS02MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVG90YWwgRHVlIChJbmNsdWRpbmcgUGVuYWx0aWVzKVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXB1cnBsZS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgICAgICB7KFxyXG4gICAgICAgICAgICAgICAgICAgICAgd2FpdmVPZmZEYXRhLmN1cnJlbnRCYWxhbmNlICtcclxuICAgICAgICAgICAgICAgICAgICAgIHdhaXZlT2ZmRGF0YS50b3RhbFBlbmFsdHkgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgd2FpdmVPZmZEYXRhLnRvdGFsTGF0ZUZlZVxyXG4gICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8Q2FsY3VsYXRvck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTUwMCB0ZXh0LTN4bFwiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFdhaXZlIE9mZiBDb25maWd1cmF0aW9uICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcHgtNCBweS0zIGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8RWRpdE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIFdhaXZlIE9mZiBDb25maWd1cmF0aW9uXHJcbiAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgey8qIFdhaXZlIE9mZiBUeXBlICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj4gV2FpdmUgT2ZmIFR5cGVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3dhaXZlT2ZmVHlwZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0V2FpdmVPZmZUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cInBlbmFsdHlcIj5QZW5hbHR5IE9ubHk8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJsYXRlZmVlXCI+TGF0ZSBGZWUgT25seTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cImJvdGhcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEJvdGggUGVuYWx0eSAmIExhdGUgRmVlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBBbW91bnQgdG8gV2FpdmUgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPiBBbW91bnQgdG8gV2FpdmUgKOKCuSlcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3dhaXZlT2ZmQW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0V2FpdmVPZmZBbW91bnQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgYW1vdW50IHRvIHdhaXZlIG9mZlwiXHJcbiAgICAgICAgICAgICAgICAgICAgbWluPXswfVxyXG4gICAgICAgICAgICAgICAgICAgIHN0ZXA9ezAuMDF9XHJcbiAgICAgICAgICAgICAgICAgICAgcHJlZml4PVwi4oK5XCJcclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN1ZmZpeD17XHJcbiAgICAgICAgICAgICAgICAgICAgICB3YWl2ZU9mZkFtb3VudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIE1heDog4oK5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgeyh3YWl2ZU9mZlR5cGUgPT09IFwicGVuYWx0eVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHdhaXZlT2ZmRGF0YS50b3RhbFBlbmFsdHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogd2FpdmVPZmZUeXBlID09PSBcImxhdGVmZWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHdhaXZlT2ZmRGF0YS50b3RhbExhdGVGZWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiB3YWl2ZU9mZkRhdGEudG90YWxQZW5hbHR5ICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd2FpdmVPZmZEYXRhLnRvdGFsTGF0ZUZlZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBSZWFzb24gKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBSZWFzb24gKE9wdGlvbmFsKVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXQuVGV4dEFyZWFcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17d2FpdmVPZmZSZWFzb259XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRXYWl2ZU9mZlJlYXNvbihlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciByZWFzb24gZm9yIHdhaXZpbmcgb2ZmIHBlbmFsdGllcy4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgcm93cz17M31cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezIwMH1cclxuICAgICAgICAgICAgICAgICAgICBzaG93Q291bnRcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBQcmV2aWV3IFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgICB7d2FpdmVPZmZBbW91bnQgJiYgcGFyc2VGbG9hdCh3YWl2ZU9mZkFtb3VudCkgPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tZ3JlZW4tNTAgdG8tdGVhbC01MCByb3VuZGVkLWxnIHAtNCBib3JkZXIgYm9yZGVyLWdyZWVuLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPENhbGN1bGF0b3JPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBQcmV2aWV3IEFmdGVyIFdhaXZlclxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBBbW91bnQgdG8gV2FpdmU6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtcmVkLTYwMCB0ZXh0LWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e3BhcnNlRmxvYXQod2FpdmVPZmZBbW91bnQpLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcHQtMiBib3JkZXItdCBib3JkZXItZ3JlZW4tMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUmVtYWluaW5nIEFtb3VudDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ncmVlbi02MDAgdGV4dC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAod2FpdmVPZmZUeXBlID09PSBcInBlbmFsdHlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHdhaXZlT2ZmRGF0YS50b3RhbFBlbmFsdHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiB3YWl2ZU9mZlR5cGUgPT09IFwibGF0ZWZlZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB3YWl2ZU9mZkRhdGEudG90YWxMYXRlRmVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiB3YWl2ZU9mZkRhdGEudG90YWxQZW5hbHR5ICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3YWl2ZU9mZkRhdGEudG90YWxMYXRlRmVlKSAtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJzZUZsb2F0KHdhaXZlT2ZmQW1vdW50KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogV2FybmluZyBBbGVydCAqL31cclxuICAgICAgICAgICAgPEFsZXJ0XHJcbiAgICAgICAgICAgICAgbWVzc2FnZT17XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxFeGNsYW1hdGlvbkNpcmNsZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPkltcG9ydGFudCBOb3RpY2U8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgZGVzY3JpcHRpb249e1xyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtbC02XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBUaGlzIGFjdGlvbiB3aWxsIHBlcm1hbmVudGx5IHJlZHVjZSB0aGUgY3VzdG9tZXInc1xyXG4gICAgICAgICAgICAgICAgICAgIHBlbmFsdHkvbGF0ZSBmZWUgYW1vdW50LlxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVGhpcyBhY3Rpb24gY2Fubm90IGJlIHVuZG9uZS4gUGxlYXNlIHZlcmlmeSBiZWZvcmVcclxuICAgICAgICAgICAgICAgICAgICBwcm9jZWVkaW5nLlxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgdHlwZT1cIndhcm5pbmdcIlxyXG4gICAgICAgICAgICAgIHNob3dJY29uPXtmYWxzZX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItbC00IGJvcmRlci1yZWQtNTAwIGJnLXJlZC01MFwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTYgaC0xNiBiZy1ncmF5LTEwMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbXgtYXV0byBtYi00XCI+XHJcbiAgICAgICAgICAgICAgPERvbGxhck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgdGV4dC0yeGxcIiAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPk5vIGRhdGEgYXZhaWxhYmxlPC9wPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIHRleHQtc20gbXQtMVwiPlxyXG4gICAgICAgICAgICAgIFVuYWJsZSB0byBsb2FkIGN1c3RvbWVyIHBlbmFsdHkgZGF0YVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L0FudE1vZGFsPlxyXG5cclxuICAgICAgPEFudE1vZGFsXHJcbiAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggYmctYmx1ZS0xMDAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxIaXN0b3J5T3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMCB0ZXh0LWxnXCIgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkXCI+V2FpdmVyIEhpc3Rvcnk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIGZvbnQtbm9ybWFsIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAgQ29tcGxldGUgcmVjb3JkIG9mIGFsbCB3YWl2ZWQgb2ZmIHBlbmFsdGllcyBhbmQgbGF0ZSBmZWVzXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIH1cclxuICAgICAgICBvcGVuPXt3YWl2ZXJIaXN0b3J5TW9kYWxWaXNpYmxlfVxyXG4gICAgICAgIG9uQ2FuY2VsPXsoKSA9PiBzZXRXYWl2ZXJIaXN0b3J5TW9kYWxWaXNpYmxlKGZhbHNlKX1cclxuICAgICAgICB3aWR0aD17MTAwMH1cclxuICAgICAgICBmb290ZXI9e1tcclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAga2V5PVwiY2xvc2VcIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRXYWl2ZXJIaXN0b3J5TW9kYWxWaXNpYmxlKGZhbHNlKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgQ2xvc2VcclxuICAgICAgICAgIDwvQnV0dG9uPixcclxuICAgICAgICBdfVxyXG4gICAgICA+XHJcbiAgICAgICAge2lzTG9hZGluZ1dhaXZlckhpc3RvcnkgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LThcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gcm91bmRlZC1mdWxsIGgtOCB3LTggYm9yZGVyLWItMiBib3JkZXItYmx1ZS02MDAgbXgtYXV0b1wiPjwvZGl2PlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yXCI+TG9hZGluZyB3YWl2ZXIgaGlzdG9yeS4uLjwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiB3YWl2ZXJIaXN0b3J5RGF0YS5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTEyXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNiBoLTE2IGJnLWdyYXktMTAwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBteC1hdXRvIG1iLTRcIj5cclxuICAgICAgICAgICAgICA8SGlzdG9yeU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgdGV4dC0yeGxcIiAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMFwiPk5vIHdhaXZlciBoaXN0b3J5IGZvdW5kPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxUYWJsZVxyXG4gICAgICAgICAgICBjb2x1bW5zPXtbXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgdGl0bGU6IFwiRGF0ZVwiLFxyXG4gICAgICAgICAgICAgICAgZGF0YUluZGV4OiBcImNyZWF0ZWRBdFwiLFxyXG4gICAgICAgICAgICAgICAga2V5OiBcImRhdGVcIixcclxuICAgICAgICAgICAgICAgIHJlbmRlcjogKGRhdGUpID0+IG1vbWVudChkYXRlKS5mb3JtYXQoXCJERC1NTS1ZWVlZIEhIOm1tOnNzXCIpLFxyXG4gICAgICAgICAgICAgICAgc29ydGVyOiAoYSwgYikgPT4gbmV3IERhdGUoYS5jcmVhdGVkQXQpIC0gbmV3IERhdGUoYi5jcmVhdGVkQXQpLFxyXG4gICAgICAgICAgICAgICAgZGVmYXVsdFNvcnRPcmRlcjogXCJkZXNjZW5kXCIsXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogXCJXYWl2ZWQgQW1vdW50XCIsXHJcbiAgICAgICAgICAgICAgICBkYXRhSW5kZXg6IFwid2FpdmVkX2Ftb3VudFwiLFxyXG4gICAgICAgICAgICAgICAga2V5OiBcIndhaXZlZF9hbW91bnRcIixcclxuICAgICAgICAgICAgICAgIGFsaWduOiBcInJpZ2h0XCIsXHJcbiAgICAgICAgICAgICAgICByZW5kZXI6IChhbW91bnQpID0+IChcclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDAgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIOKCuXthbW91bnQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgIHNvcnRlcjogKGEsIGIpID0+IGEud2FpdmVkX2Ftb3VudCAtIGIud2FpdmVkX2Ftb3VudCxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIHRpdGxlOiBcIlBlbmFsdHkgV2FpdmVkXCIsXHJcbiAgICAgICAgICAgICAgICBkYXRhSW5kZXg6IFwid2FpdmVkX3BlbmFsdHlfYW1vdW50XCIsXHJcbiAgICAgICAgICAgICAgICBrZXk6IFwid2FpdmVkX3BlbmFsdHlfYW1vdW50XCIsXHJcbiAgICAgICAgICAgICAgICBhbGlnbjogXCJyaWdodFwiLFxyXG4gICAgICAgICAgICAgICAgcmVuZGVyOiAoYW1vdW50KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIOKCuXthbW91bnQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIHRpdGxlOiBcIkxhdGUgRmVlIFdhaXZlZFwiLFxyXG4gICAgICAgICAgICAgICAgZGF0YUluZGV4OiBcIndhaXZlZF9sYXRlX2ZlZV9hbW91bnRcIixcclxuICAgICAgICAgICAgICAgIGtleTogXCJ3YWl2ZWRfbGF0ZV9mZWVfYW1vdW50XCIsXHJcbiAgICAgICAgICAgICAgICBhbGlnbjogXCJyaWdodFwiLFxyXG4gICAgICAgICAgICAgICAgcmVuZGVyOiAoYW1vdW50KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtb3JhbmdlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIOKCuXthbW91bnQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIHRpdGxlOiBcIlR5cGVcIixcclxuICAgICAgICAgICAgICAgIGRhdGFJbmRleDogXCJ3YWl2ZV9vZmZfdHlwZVwiLFxyXG4gICAgICAgICAgICAgICAga2V5OiBcInR5cGVcIixcclxuICAgICAgICAgICAgICAgIHJlbmRlcjogKHR5cGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgPFRhZ1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yPXtcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGUgPT09IFwiYm90aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJwdXJwbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHR5cGUgPT09IFwicGVuYWx0eVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcInJlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIm9yYW5nZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3R5cGUgPT09IFwiYm90aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA/IFwiQm90aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IHR5cGUgPT09IFwicGVuYWx0eVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8gXCJQZW5hbHR5IE9ubHlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiTGF0ZSBGZWUgT25seVwifVxyXG4gICAgICAgICAgICAgICAgICA8L1RhZz5cclxuICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICB0aXRsZTogXCJSZWFzb25cIixcclxuICAgICAgICAgICAgICAgIGRhdGFJbmRleDogXCJyZWFzb25cIixcclxuICAgICAgICAgICAgICAgIGtleTogXCJyZWFzb25cIixcclxuICAgICAgICAgICAgICAgIGVsbGlwc2lzOiB0cnVlLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgdGl0bGU6IFwiV2FpdmVkIEJ5XCIsXHJcbiAgICAgICAgICAgICAgICBkYXRhSW5kZXg6IFwid2FpdmVkX2J5XCIsXHJcbiAgICAgICAgICAgICAgICBrZXk6IFwid2FpdmVkX2J5XCIsXHJcbiAgICAgICAgICAgICAgICByZW5kZXI6ICh1c2VyKSA9PiB1c2VyPy5mdWxsX25hbWUgfHwgXCJTeXN0ZW1cIixcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICBkYXRhU291cmNlPXt3YWl2ZXJIaXN0b3J5RGF0YX1cclxuICAgICAgICAgICAgcm93S2V5PVwiX2lkXCJcclxuICAgICAgICAgICAgcGFnaW5hdGlvbj17eyBwYWdlU2l6ZTogMTAgfX1cclxuICAgICAgICAgICAgc2l6ZT1cIm1pZGRsZVwiXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvQW50TW9kYWw+XHJcblxyXG4gICAgICB7LyogRmlyc3QgRHJhd2VyIC0gU2VsZWN0aW9uIERyYXdlciAqL31cclxuICAgICAgPERyYXdlclxyXG4gICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgPENhbGN1bGF0b3JPdXRsaW5lZCBjbGFzc05hbWU9XCJtci0yIHRleHQtYmx1ZS02MDBcIiAvPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGRcIj5BZGQgTWFudWFsIFBlbmFsdHk8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICB9XHJcbiAgICAgICAgcGxhY2VtZW50PVwicmlnaHRcIlxyXG4gICAgICAgIG9uQ2xvc2U9e2hhbmRsZUNsb3NlRmlyc3REcmF3ZXJ9XHJcbiAgICAgICAgb3Blbj17YWRkUGVuYWx0eURyYXdlck9wZW59XHJcbiAgICAgICAgd2lkdGg9ezcwMH1cclxuICAgICAgPlxyXG4gICAgICAgIHsvKiBQZW5hbHR5IFR5cGUgU2VsZWN0aW9uICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNVwiPlxyXG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgIFBlbmFsdHkgVHlwZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICA8UmFkaW8uR3JvdXBcclxuICAgICAgICAgICAgdmFsdWU9e3BlbmFsdHlUeXBlfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFBlbmFsdHlUeXBlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgYnV0dG9uU3R5bGU9XCJzb2xpZFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxSYWRpby5CdXR0b24gdmFsdWU9XCJjaGl0XCI+Q2hpdCBQZW5hbHR5PC9SYWRpby5CdXR0b24+XHJcbiAgICAgICAgICAgIDxSYWRpby5CdXR0b24gdmFsdWU9XCJsb2FuXCI+TG9hbiBQZW5hbHR5PC9SYWRpby5CdXR0b24+XHJcbiAgICAgICAgICA8L1JhZGlvLkdyb3VwPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PSBDSElUIFBFTkFMVFkgPT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cclxuICAgICAgICB7cGVuYWx0eVR5cGUgPT09IFwiY2hpdFwiICYmIChcclxuICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNCBwLTQgcm91bmRlZC14bCBiZy1ibHVlLTUwIGJvcmRlci1sLTQgYm9yZGVyLWJsdWUtNTAwIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIHRleHQteGxcIj7ihLnvuI88L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtYmx1ZS04MDAgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFNlbGVjdCBDdXN0b21lciBmb3IgUGVuYWx0eVxyXG4gICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNzAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICBPbmx5IGN1c3RvbWVycyB3aXRoIG91dHN0YW5kaW5nIGR1ZXMgYXJlIHNob3duLlxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogR3JvdXAgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNVwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgR3JvdXAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgR3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkR3JvdXBJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlR3JvdXBTZWxlY3R9XHJcbiAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICBsb2FkaW5nPXtpc0xvYWRpbmdHcm91cHN9XHJcbiAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICBvcHRpb24/LmxhYmVsPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge2dyb3VwT3B0aW9ucy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXAudmFsdWV9IHZhbHVlPXtncm91cC52YWx1ZX0+XHJcbiAgICAgICAgICAgICAgICAgICAge2dyb3VwLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogQ3VzdG9tZXIgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNVwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgQ3VzdG9tZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkQ3VzdG9tZXJJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ3VzdG9tZXJTZWxlY3R9XHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17IXNlbGVjdGVkR3JvdXBJZH1cclxuICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICAgIGxvYWRpbmc9e2lzTG9hZGluZ1VzZXJzfVxyXG4gICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgb3B0aW9uPy5sYWJlbD8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtjdXN0b21lck9wdGlvbnMubWFwKChjdXN0b21lcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2N1c3RvbWVyLnZhbHVlfSB2YWx1ZT17Y3VzdG9tZXIudmFsdWV9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtjdXN0b21lci5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFRpY2tldCAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi01XCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICBUaWNrZXQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgVGlja2V0XCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFRpY2tldCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlVGlja2V0U2VsZWN0fVxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFzZWxlY3RlZEN1c3RvbWVySWR9XHJcbiAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICBvcHRpb24/LmxhYmVsPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3RpY2tldE9wdGlvbnMubWFwKCh0aWNrZXQpID0+IChcclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt0aWNrZXQudmFsdWV9IHZhbHVlPXt0aWNrZXQudmFsdWV9PlxyXG4gICAgICAgICAgICAgICAgICAgIHt0aWNrZXQubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBmbGV4IGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xXCJcclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXshc2VsZWN0ZWRUaWNrZXR9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVQcm9jZWVkVG9QZW5hbHR5fVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFByb2NlZWQgdG8gQWRkIFBlbmFsdHlcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVDbG9zZUZpcnN0RHJhd2VyfT5DYW5jZWw8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8Lz5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICB7LyogPT09PT09PT09PT09PT09PT09PT09PT09PSBMT0FOIFBFTkFMVFkgPT09PT09PT09PT09PT09PT09PT09PT09PSAqL31cclxuICAgICAgICB7cGVuYWx0eVR5cGUgPT09IFwibG9hblwiICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS01XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNTAgdG8taW5kaWdvLTUwIHAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYmx1ZS0yMDBcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ibHVlLTgwMCBtYi0yXCI+TG9hbiBQZW5hbHR5IEluZm9ybWF0aW9uPC9wPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTYwMFwiPlNlbGVjdCBhIGN1c3RvbWVyIGFuZCBhIGxvYW4sIHRoZW4gYWRkIHBlbmFsdHkgY2hhcmdlcy48L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIEN1c3RvbWVyIFNlbGVjdGlvbiAqL31cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPkN1c3RvbWVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+PC9sYWJlbD5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b1N0cmluZygpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFVzZXJJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ3VzdG9tZXJ9XHJcbiAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt1c2VyLl9pZH0gdmFsdWU9e3VzZXIuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICB7YCR7dXNlci5mdWxsX25hbWV9IHwgJHt1c2VyLnBob25lX251bWJlcn1gfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogTG9hbiBTZWxlY3Rpb24gKi99XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5TZWxlY3QgTG9hbiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgbW9kZT1cIm11bHRpcGxlXCJcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IExvYW5cIlxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBoYW5kbGVQYXltZW50QW50U2VsZWN0KHZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgc2V0T3BlbihmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgbG9hZGluZz17ZW5yb2xsbWVudExvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17cGF5bWVudEdyb3VwVGlja2V0c31cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtib3Jyb3dlcnM/Lm1hcCgoYm9ycm93ZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtgbG9hbi0ke2JvcnJvd2VyLl9pZH1gfSB2YWx1ZT17YGxvYW4tJHtib3Jyb3dlci5faWR9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAge2Ake2JvcnJvd2VyLmxvYW5faWR9IHwg4oK5ICR7Ym9ycm93ZXIubG9hbl9hbW91bnR9YH1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFNlbGVjdGVkIExvYW4gRGV0YWlscyBDYXJkICovfVxyXG4gICAgICAgICAgICB7cGF5bWVudEdyb3VwVGlja2V0cy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciByb3VuZGVkLWxnIGJnLWdyYXktNTAgIHNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAge3BheW1lbnRHcm91cFRpY2tldHMubWFwKChpdGVtKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGRldGFpbHMgPSBnZXRUaWNrZXREZXRhaWxzKGl0ZW0pO1xyXG4gICAgICAgICAgICAgICAgICBpZiAoIWRldGFpbHMpIHJldHVybiBudWxsO1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBkdWVJbmZvID0gZ2V0RHVlSW5mbyhkZXRhaWxzLmVuZERhdGUpO1xyXG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpdGVtfSBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTMgcm91bmRlZCBzaGFkb3ctc20gYm9yZGVyLWwtNCBib3JkZXItYmx1ZS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFRhZyBjb2xvcj1cImJsdWVcIj5MT0FOPC9UYWc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCBtdC0xXCI+e2RldGFpbHMubmFtZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIGZvbnQtbWVkaXVtXCI+RHVlIFN0YXR1czo8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgZm9udC1ib2xkIHRleHQtc20gJHtkdWVJbmZvPy5zdGF0dXMgPT09IFwib3ZlcmR1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGR1ZUluZm8/LnN0YXR1cyA9PT0gXCJ1cGNvbWluZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcInRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1vcmFuZ2UtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfT57ZHVlSW5mby50ZXh0fTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5CYWxhbmNlPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtcmVkLTYwMFwiPuKCuXtkZXRhaWxzLmJhbGFuY2UudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTUgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ibHVlLTUwIHJvdW5kZWQteGwgcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBMb2FuIEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ibHVlLTcwMCB0ZXh0LWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7ZGV0YWlscy5sb2FuQW1vdW50LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyZWVuLTUwIHJvdW5kZWQteGwgcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBEYWlseSBQYXltZW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMCB0ZXh0LWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7ZGV0YWlscy5kYWlseVBheW1lbnQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1wdXJwbGUtNTAgcm91bmRlZC14bCBwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFN0YXJ0IERhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZGV0YWlscy5zdGFydERhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPy5zcGxpdChcIlRcIilbMF1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnNwbGl0KFwiLVwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAucmV2ZXJzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5qb2luKFwiLVwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1vcmFuZ2UtNTAgcm91bmRlZC14bCBwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVuZCBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2RldGFpbHMuZW5kRGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/LnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuc3BsaXQoXCItXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5yZXZlcnNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmpvaW4oXCItXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWVtZXJhbGQtNTAgcm91bmRlZC14bCBwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIFBhaWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZW1lcmFsZC03MDAgdGV4dC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2RldGFpbHMudG90YWxQYWlkLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7LyogUGVuYWx0eSBDaGFyZ2VzIElucHV0ICovfVxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5BZGQgUGVuYWx0eSBDaGFyZ2VzPC9wPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICB7cGVuYWx0eUNoYXJnZXMubWFwKChjaGFyZ2UsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBrZXk9e2luZGV4fVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFtb3VudCDigrlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y2hhcmdlLmFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgbWluPXswfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlUGVuYWx0eUNoYW5nZShpbmRleCwgXCJhbW91bnRcIiwgZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcHJlZml4PVwi4oK5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy1bNDUwcHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJSZWFzb24gKGUuZy4gTGF0ZSBmZWUsIFBlbmFsdHkpXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NoYXJnZS5yZWFzb259XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVQZW5hbHR5Q2hhbmdlKGluZGV4LCBcInJlYXNvblwiLCBlLnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTExXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHtwZW5hbHR5Q2hhcmdlcy5sZW5ndGggPiAxICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGFuZ2VyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LWxnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUmVtb3ZlUGVuYWx0eVJvdyhpbmRleCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIMOXXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIHtwZW5hbHR5Q2hhcmdlcy5zb21lKGMgPT4gYy5hbW91bnQpICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXJpZ2h0IHRleHQtc20gZm9udC1ib2xkIHRleHQtb3JhbmdlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBUb3RhbDog4oK5e3BlbmFsdHlDaGFyZ2VzLnJlZHVjZSgocywgYykgPT4gcyArIE51bWJlcihjLmFtb3VudCB8fCAwKSwgMCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgey8qIDxCdXR0b24gdHlwZT1cImxpbmtcIiBjbGFzc05hbWU9XCJwLTAgbXQtMlwiIG9uQ2xpY2s9e2hhbmRsZUFkZFBlbmFsdHlSb3d9PlxyXG4gICAgICAgICAgICAgICAgKyBBZGQgQW5vdGhlciBDaGFyZ2VcclxuICAgICAgICAgICAgICA8L0J1dHRvbj4gKi99XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIEFjdGlvbiBCdXR0b25zICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTMgcHQtNCBib3JkZXItdFwiPlxyXG4gICAgICAgICAgICAgIDxCdXR0b24gb25DbGljaz17aGFuZGxlQ2xvc2VGaXJzdERyYXdlcn0+Q2FuY2VsPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwicHJpbWFyeVwiIGxvYWRpbmc9e3BlbmFsdHlMb2FkaW5nfSBvbkNsaWNrPXtoYW5kbGVQZW5hbHR5U3VibWl0fT5cclxuICAgICAgICAgICAgICAgIFNhdmUgUGVuYWx0eSBDaGFyZ2VzXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9EcmF3ZXI+XHJcblxyXG4gICAgICB7LyogU2Vjb25kIERyYXdlciAtIFBlbmFsdHkgRW50cnkgRHJhd2VyICovfVxyXG4gICAgICA8RHJhd2VyXHJcbiAgICAgICAgdGl0bGU9e251bGx9XHJcbiAgICAgICAgcGxhY2VtZW50PVwicmlnaHRcIlxyXG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgIHNldEFkZFBlbmFsdHlEZXRhaWxzKG51bGwpO1xyXG4gICAgICAgICAgc2V0QWRkUGVuYWx0eUFtb3VudChcIlwiKTtcclxuICAgICAgICAgIHNldEFkZExhdGVGZWVBbW91bnQoXCJcIik7XHJcbiAgICAgICAgfX1cclxuICAgICAgICBvcGVuPXshIWFkZFBlbmFsdHlEZXRhaWxzfVxyXG4gICAgICAgIHdpZHRoPXs4MDB9XHJcbiAgICAgICAgY2xvc2FibGU9e2ZhbHNlfVxyXG4gICAgICA+XHJcbiAgICAgICAge2FkZFBlbmFsdHlEZXRhaWxzICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1mdWxsIGZsZXggZmxleC1jb2wgYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctbGcgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgIHsvKiBIZWFkZXIgU2VjdGlvbiB3aXRoIEdyYWRpZW50ICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1ncmVlbi02MDAgdG8tZ3JlZW4tNzAwIHRleHQtd2hpdGUgcC02IGJvcmRlci1iIGJvcmRlci1ncmVlbi01MDBcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEgaC04IGJnLXllbGxvdy00MDAgcm91bmRlZC1mdWxsXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRpdGxlIGxldmVsPXszfSBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIG1iLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEFkZCBNYW51YWwgUGVuYWx0eVxyXG4gICAgICAgICAgICAgICAgICAgIDwvVGl0bGU+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8VGV4dCBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTEwMCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgRW50ZXIgcGVuYWx0eSBhbmQgbGF0ZSBmZWUgYW1vdW50cyBmb3IgY3VzdG9tZXIgYWNjb3VudFxyXG4gICAgICAgICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxTcGFjZT5cclxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIGljb249ezxIaXN0b3J5T3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlVmlld1BlbmFsdHlIaXN0b3J5fVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlLzEwIGJvcmRlci13aGl0ZS8yMCB0ZXh0LXdoaXRlIGhvdmVyOmJnLXdoaXRlLzIwIGhvdmVyOnRleHQtd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgVmlldyBQZW5hbHR5IEhpc3RvcnlcclxuICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICBkYW5nZXJcclxuICAgICAgICAgICAgICAgICAgICBpY29uPXs8QXJyb3dMZWZ0T3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0QWRkUGVuYWx0eURldGFpbHMobnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRBZGRQZW5hbHR5QW1vdW50KFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0QWRkTGF0ZUZlZUFtb3VudChcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXJlZC01MDAvMTAgYm9yZGVyLXJlZC01MDAvMjAgdGV4dC1yZWQtNTAwIGhvdmVyOmJnLXJlZC01MDAvMjBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQ2xvc2VcclxuICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L1NwYWNlPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS02IGZsZXgtZ3JvdyBvdmVyZmxvdy1hdXRvIGJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICB7LyogQ3VzdG9tZXIgSW5mb3JtYXRpb24gQ2FyZCAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNTAwIHRvLWluZGlnby01MDAgcHgtNSBweS0zIGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8VGl0bGUgbGV2ZWw9ezV9IGNsYXNzTmFtZT1cIm1iLTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8VXNlck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIEN1c3RvbWVyIEluZm9ybWF0aW9uXHJcbiAgICAgICAgICAgICAgICAgIDwvVGl0bGU+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IGJnLWJsdWUtMTAwIHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFVzZXJPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIHRleHQtc21cIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8VGV4dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgdXBwZXJjYXNlIGJsb2NrIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8VGV4dCBzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1iYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2FkZFBlbmFsdHlEZXRhaWxzLnVzZXJOYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCBiZy1ncmVlbi0xMDAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8UGhvbmVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMCB0ZXh0LXNtXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIHVwcGVyY2FzZSBibG9jayBmb250LXNlbWlib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFBob25lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRleHQgc3Ryb25nIGNsYXNzTmFtZT1cInRleHQtYmFzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHthZGRQZW5hbHR5RGV0YWlscy51c2VyUGhvbmV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IGJnLXB1cnBsZS0xMDAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8VGVhbU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTYwMCB0ZXh0LXNtXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIHVwcGVyY2FzZSBibG9jayBmb250LXNlbWlib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEdyb3VwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRleHQgc3Ryb25nIGNsYXNzTmFtZT1cInRleHQtYmFzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHthZGRQZW5hbHR5RGV0YWlscy5ncm91cE5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IGJnLW9yYW5nZS0xMDAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q3JlZGl0Q2FyZE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtb3JhbmdlLTYwMCB0ZXh0LXNtXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIHVwcGVyY2FzZSBibG9jayBmb250LXNlbWlib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFRpY2tldFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0IHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7YWRkUGVuYWx0eURldGFpbHMucGF5bWVudHNUaWNrZXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBGaW5hbmNpYWwgU3VtbWFyeSBDYXJkcyAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC00IG10LTUgcHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tb3JhbmdlLTUwIHRvLW9yYW5nZS0xMDAgcm91bmRlZC1sZyBwLTMgYm9yZGVyIGJvcmRlci1vcmFuZ2UtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8VGV4dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyB1cHBlcmNhc2UgYmxvY2sgZm9udC1zZW1pYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEN1cnJlbnQgRHVlIEJhbGFuY2VcclxuICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1iYXNlbGluZSBnYXAtMSBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtb3JhbmdlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LW9yYW5nZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkUGVuYWx0eURldGFpbHMuY3VycmVudEJhbGFuY2UgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZFBlbmFsdHlEZXRhaWxzLmJhbGFuY2UgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1yZWQtNTAgdG8tcmVkLTEwMCByb3VuZGVkLWxnIHAtMyBib3JkZXIgYm9yZGVyLXJlZC0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxUZXh0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIHVwcGVyY2FzZSBibG9jayBmb250LXNlbWlib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ3VycmVudCBQZW5hbHR5XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtYmFzZWxpbmUgZ2FwLTEgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgeyhhZGRQZW5hbHR5RGV0YWlscy50b3RhbFBlbmFsdHkgfHwgMCkudG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImVuLUlOXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLXJlZC01MCB0by1yZWQtMTAwIHJvdW5kZWQtbGcgcC0zIGJvcmRlciBib3JkZXItcmVkLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFRleHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgdXBwZXJjYXNlIGJsb2NrIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDdXJyZW50IExhdGUgRmVlXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1RleHQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtYmFzZWxpbmUgZ2FwLTEgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgeyhhZGRQZW5hbHR5RGV0YWlscy50b3RhbExhdGVGZWUgfHwgMCkudG9Mb2NhbGVTdHJpbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImVuLUlOXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBFbnRlciBQZW5hbHR5IERldGFpbHMgQ2FyZCAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLXB1cnBsZS0zMDAgdG8tcGluay0zMDAgcHgtNSBweS0zIGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8VGl0bGUgbGV2ZWw9ezR9IGNsYXNzTmFtZT1cIm1iLTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8RWRpdE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgRW50ZXIgUGVuYWx0eSBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgIDwvVGl0bGU+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBQZW5hbHR5IEFtb3VudCBGaWVsZCAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPERvbGxhck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtb3JhbmdlLTUwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFBlbmFsdHkgQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YWRkUGVuYWx0eUFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRBZGRQZW5hbHR5QW1vdW50KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBwZW5hbHR5IGFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1pbj17MH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD17MC4wMX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcHJlZml4PVwi4oK5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1sZyBib3JkZXItZ3JheS0zMDAgZm9jdXM6Ym9yZGVyLW9yYW5nZS00MDAgZm9jdXM6cmluZy1vcmFuZ2UtNDAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgcC0yIGJnLW9yYW5nZS01MCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItb3JhbmdlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8VGV4dCB0eXBlPVwic2Vjb25kYXJ5XCIgY2xhc3NOYW1lPVwidGV4dC14c1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIE5ldyB0b3RhbCBwZW5hbHR5IHdpbGwgYmU6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWJhc2VsaW5lIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtb3JhbmdlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1vcmFuZ2UtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZGRQZW5hbHR5RGV0YWlscy50b3RhbFBlbmFsdHkgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAocGFyc2VGbG9hdChhZGRQZW5hbHR5QW1vdW50KSB8fCAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIExhdGUgRmVlIEFtb3VudCBGaWVsZCAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPENsb2NrQ2lyY2xlT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTGF0ZSBGZWUgQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YWRkTGF0ZUZlZUFtb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRBZGRMYXRlRmVlQW1vdW50KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBsYXRlIGZlZSBhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtaW49ezB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0ZXA9ezAuMDF9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHByZWZpeD1cIuKCuVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYm9yZGVyLWdyYXktMzAwIGZvY3VzOmJvcmRlci1yZWQtNDAwIGZvY3VzOnJpbmctcmVkLTQwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIHAtMiBiZy1yZWQtNTAgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXJlZC0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFRleHQgdHlwZT1cInNlY29uZGFyeVwiIGNsYXNzTmFtZT1cInRleHQteHNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBOZXcgdG90YWwgbGF0ZSBmZWUgd2lsbCBiZTpcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9UZXh0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtYmFzZWxpbmUgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZFBlbmFsdHlEZXRhaWxzLnRvdGFsTGF0ZUZlZSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChwYXJzZUZsb2F0KGFkZExhdGVGZWVBbW91bnQpIHx8IDApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogU3VtbWFyeSBDYXJkICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNiBiZy1ncmFkaWVudC10by1yIGZyb20teWVsbG93LTUwIHRvLW9yYW5nZS01MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXIteWVsbG93LTIwMCBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLXllbGxvdy0xMDAgdG8tb3JhbmdlLTEwMCBweC01IHB5LTNcIj5cclxuICAgICAgICAgICAgICAgICAgPFRpdGxlIGxldmVsPXs1fSBjbGFzc05hbWU9XCJtYi0wIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPENhbGN1bGF0b3JPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXllbGxvdy03MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIFN1bW1hcnkgQWZ0ZXIgQWRkaW5nXHJcbiAgICAgICAgICAgICAgICAgIDwvVGl0bGU+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcC0zIGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8VGV4dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyB1cHBlcmNhc2UgYmxvY2sgZm9udC1zZW1pYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEN1cnJlbnQgRHVlIEJhbGFuY2VcclxuICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkUGVuYWx0eURldGFpbHMuY3VycmVudEJhbGFuY2UgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZFBlbmFsdHlEZXRhaWxzLmJhbGFuY2UgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcC0zIGJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8VGV4dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyB1cHBlcmNhc2UgYmxvY2sgZm9udC1zZW1pYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE5ldyBQZW5hbHR5ICsgTGF0ZSBGZWVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICDigrlcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgeyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChwYXJzZUZsb2F0KGFkZFBlbmFsdHlBbW91bnQpIHx8IDApICtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChwYXJzZUZsb2F0KGFkZExhdGVGZWVBbW91bnQpIHx8IDApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHAtNCBiZy1ncmFkaWVudC10by1iciBmcm9tLW9yYW5nZS01MDAgdG8tcmVkLTUwMCByb3VuZGVkLWxnIHNoYWRvdy1sZyB0cmFuc2Zvcm0gaG92ZXI6c2NhbGUtMTA1IHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTMwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFRleHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgdXBwZXJjYXNlIGJsb2NrIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZS85MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE5ldyBUb3RhbCBEdWVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvVGV4dD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXdoaXRlXCI+4oK5PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC13aGl0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoYWRkUGVuYWx0eURldGFpbHMuY3VycmVudEJhbGFuY2UgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWRkUGVuYWx0eURldGFpbHMuYmFsYW5jZSB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAwKSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAocGFyc2VGbG9hdChhZGRQZW5hbHR5QW1vdW50KSB8fCAwKSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAocGFyc2VGbG9hdChhZGRMYXRlRmVlQW1vdW50KSB8fCAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBXYXJuaW5nIEFsZXJ0ICovfVxyXG4gICAgICAgICAgICAgIDxBbGVydFxyXG4gICAgICAgICAgICAgICAgbWVzc2FnZT17XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8RXhjbGFtYXRpb25DaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXllbGxvdy02MDAgdGV4dC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPkltcG9ydGFudCBOb3RpY2U8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb249e1xyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBUaGUgcGVuYWx0eSBhbmQgbGF0ZSBmZWUgYW1vdW50cyB3aWxsIGJlIGFkZGVkIHRvIHRoZVxyXG4gICAgICAgICAgICAgICAgICAgICAgY3VzdG9tZXIncyBhY2NvdW50LlxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDAgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgVGhpcyBhY3Rpb24gY2Fubm90IGJlIHVuZG9uZS4gUGxlYXNlIHZlcmlmeSB0aGUgYW1vdW50c1xyXG4gICAgICAgICAgICAgICAgICAgICAgYmVmb3JlIHByb2NlZWRpbmcuXHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJ3YXJuaW5nXCJcclxuICAgICAgICAgICAgICAgIHNob3dJY29uPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1iLTYgYm9yZGVyLWwtNCBib3JkZXIteWVsbG93LTUwMCBiZy15ZWxsb3ctNTBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgIHsvKiBBY3Rpb24gQnV0dG9ucyAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTQgc3RpY2t5IGJvdHRvbS0wIGJnLWdyYXktNTAgcHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIGgtMTIgdGV4dC1iYXNlIGZvbnQtc2VtaWJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0QWRkUGVuYWx0eURldGFpbHMobnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0QWRkUGVuYWx0eUFtb3VudChcIlwiKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRBZGRMYXRlRmVlQW1vdW50KFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXgtMSBoLTEyIHRleHQtYmFzZSBmb250LXNlbWlib2xkICR7YWRkUGVuYWx0eUxvYWRpbmcgfHxcclxuICAgICAgICAgICAgICAgICAgICAoIWFkZFBlbmFsdHlBbW91bnQgJiYgIWFkZExhdGVGZWVBbW91bnQpXHJcbiAgICAgICAgICAgICAgICAgICAgPyBcIm9wYWNpdHktNTAgY3Vyc29yLW5vdC1hbGxvd2VkXCJcclxuICAgICAgICAgICAgICAgICAgICA6IFwiYmctZ3JhZGllbnQtdG8tciBmcm9tLWdyZWVuLTYwMCB0by1ncmVlbi03MDAgaG92ZXI6ZnJvbS1ncmVlbi03MDAgaG92ZXI6dG8tZ3JlZW4tODAwXCJcclxuICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e1xyXG4gICAgICAgICAgICAgICAgICAgIGFkZFBlbmFsdHlMb2FkaW5nIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgKCFhZGRQZW5hbHR5QW1vdW50ICYmICFhZGRMYXRlRmVlQW1vdW50KVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNhdmVQZW5hbHR5fVxyXG4gICAgICAgICAgICAgICAgICBsb2FkaW5nPXthZGRQZW5hbHR5TG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgaWNvbj17PFNhdmVPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQWRkIFBlbmFsdHkgJiBMYXRlIEZlZVxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9EcmF3ZXI+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQZW5hbHR5TWFuYWdlbWVudDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1BlbmFsdHlNYW5hZ2VtZW50LmpzeCJ9